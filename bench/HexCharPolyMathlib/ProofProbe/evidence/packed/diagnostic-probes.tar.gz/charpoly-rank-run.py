import os,fcntl,subprocess,json,time
from pathlib import Path
cpus=sorted(os.sched_getaffinity(0)); offset=os.getpid()%len(cpus)
for cpu in cpus[offset:]+cpus[:offset]:
    lease=open(f'/tmp/hex-bench-cpu-{cpu}.lock','a')
    try: fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);break
    except BlockingIOError: lease.close()
else: raise RuntimeError('all CPU leases held')
os.sched_setaffinity(0,{cpu});os.environ['LEAN_NUM_THREADS']='1'
print(json.dumps({'cpu':cpu,'load':os.getloadavg(),'host':os.uname().nodename}),flush=True)
for n in [4,8,16,32]:
    start=time.monotonic()
    p=subprocess.run(['lake','build',f'HexCharPolyMathlib.ProofProbe.Dense{n}Rank'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    Path(f'/tmp/charpoly-rank-dense{n}.log').write_text(p.stdout)
    print(json.dumps({'n':n,'wall_s':time.monotonic()-start,'exit':p.returncode,'log':p.stdout}),flush=True)
    if p.returncode:break
