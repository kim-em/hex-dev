import os,fcntl,subprocess,json,time,re
from pathlib import Path
root=Path('bench/HexCharPolyMathlib/ProofProbe')
for src,dst in [('Dense16Quoted','Dense16Candidate'),('Dense16Rank','Dense16Reference')]:
    s=(root/(src+'.lean')).read_text()
    s=re.sub(r'set_option profiler[^\n]*\n','',s)
    (root/(dst+'.lean')).write_text(s)
cpus=sorted(os.sched_getaffinity(0)); offset=os.getpid()%len(cpus)
for cpu in cpus[offset:]+cpus[:offset]:
    lease=open(f'/tmp/hex-bench-cpu-{cpu}.lock','a')
    try: fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);break
    except BlockingIOError: lease.close()
else: raise RuntimeError('all CPU leases held')
os.sched_setaffinity(0,{cpu});os.environ['LEAN_NUM_THREADS']='1'
report={'cpu':cpu,'host':os.uname().nodename,'initial_load':os.getloadavg(),'samples':[]}
print(json.dumps(report),flush=True)
# Six adjacent samples, alternating orientation, followed by one diagnostic profile pair.
for i in range(7):
    order=['Candidate','Reference'] if i%2==0 else ['Reference','Candidate']
    for arm in order:
        name=('Dense16Quoted' if arm=='Candidate' else 'Dense16Rank') if i==6 else 'Dense16'+arm
        for p in Path('.lake/build/lib/lean/HexCharPolyMathlib/ProofProbe').glob(name+'.*'):
            p.unlink()
        start=time.monotonic()
        p=subprocess.run(['lake','build',f'HexCharPolyMathlib.ProofProbe.{name}:olean'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        log=f'/tmp/charpoly-paired-{i}-{arm}.log';Path(log).write_text(p.stdout)
        row={'sample':i,'arm':arm,'profile':i==6,'wall_s':time.monotonic()-start,'exit':p.returncode,'load':os.getloadavg(),'log':log,'kernel':re.findall(r'type checking ([0-9.]+[mu]?s)',p.stdout)}
        report['samples'].append(row);print(json.dumps(row),flush=True)
        Path('/tmp/charpoly-paired.json').write_text(json.dumps(report,indent=2)+'\n')
        if p.returncode: raise SystemExit(p.returncode)
