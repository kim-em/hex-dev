import HexCharPolyMathlib.ProofProbe.ComputedSupport
open CharPolyComputedProbe
example : moments [[2,3],[4,5]] [1,2] [-5,-36] [1,2] = true := by check_computed_kernel
