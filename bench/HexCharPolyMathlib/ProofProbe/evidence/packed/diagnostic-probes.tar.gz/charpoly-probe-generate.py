from pathlib import Path
import random
root=Path('bench/HexCharPolyMathlib/ProofProbe')
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def certify(A):
    if not A: return [],[1]
    a,*r=A[0]
    B=[row[1:] for row in A[1:]]
    w=[row[0] for row in A[1:]]
    steps,p=certify(B)
    t=[1,-a]; vs=[]
    for j in range(len(r)):
        t.append(-dot(r,w))
        if j+1<len(r):
            w=[dot(row,w) for row in B]; vs.append(w)
    q=[dot(t[:i+1][::-1],p) for i in range(len(t))]
    return [(t,vs,q)]+steps,q
for n in [4,8,16,32]:
    rng=random.Random(10212+n)
    A=[[rng.randrange(-128,128) for _ in range(n)] for _ in range(n)]
    steps,p=certify(A)
    witness='['+',\n'.join('{ column := '+str(t)+', vectors := '+str(vs)+', coefficients := '+str(q)+' }' for t,vs,q in steps)+']'
    (root/f'Dense{n}Check.lean').write_text('import HexCharPolyMathlib.ProofProbe.Support\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\nset_option profiler true\nset_option profiler.threshold 1000000\nopen CharPolyProbe\n'+f'theorem result : check {n} {A} {witness} {p} = true := by check_kernel\n#print axioms result\n')
