// Lean compiler output
// Module: HexRealRoots.Sign
// Imports: public import Init public meta import Init public import Std
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
lean_object* lean_int_neg(lean_object*);
static lean_once_cell_t lp_Hex_Hex_signInt___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_signInt___closed__0;
static lean_once_cell_t lp_Hex_Hex_signInt___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_signInt___closed__1;
static lean_once_cell_t lp_Hex_Hex_signInt___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_signInt___closed__2;
LEAN_EXPORT lean_object* lp_Hex_Hex_signInt(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_signInt___boxed(lean_object*);
static lean_object* _init_lp_Hex_Hex_signInt___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_Hex_Hex_signInt___closed__1(void){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lean_unsigned_to_nat(1u);
v___x_4_ = lean_nat_to_int(v___x_3_);
return v___x_4_;
}
}
static lean_object* _init_lp_Hex_Hex_signInt___closed__2(void){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_5_ = lean_obj_once(&lp_Hex_Hex_signInt___closed__1, &lp_Hex_Hex_signInt___closed__1_once, _init_lp_Hex_Hex_signInt___closed__1);
v___x_6_ = lean_int_neg(v___x_5_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_signInt(lean_object* v_z_7_){
_start:
{
lean_object* v___x_8_; uint8_t v___x_9_; 
v___x_8_ = lean_obj_once(&lp_Hex_Hex_signInt___closed__0, &lp_Hex_Hex_signInt___closed__0_once, _init_lp_Hex_Hex_signInt___closed__0);
v___x_9_ = lean_int_dec_lt(v_z_7_, v___x_8_);
if (v___x_9_ == 0)
{
uint8_t v___x_10_; 
v___x_10_ = lean_int_dec_eq(v_z_7_, v___x_8_);
if (v___x_10_ == 0)
{
lean_object* v___x_11_; 
v___x_11_ = lean_obj_once(&lp_Hex_Hex_signInt___closed__1, &lp_Hex_Hex_signInt___closed__1_once, _init_lp_Hex_Hex_signInt___closed__1);
return v___x_11_;
}
else
{
return v___x_8_;
}
}
else
{
lean_object* v___x_12_; 
v___x_12_ = lean_obj_once(&lp_Hex_Hex_signInt___closed__2, &lp_Hex_Hex_signInt___closed__2_once, _init_lp_Hex_Hex_signInt___closed__2);
return v___x_12_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_signInt___boxed(lean_object* v_z_13_){
_start:
{
lean_object* v_res_14_; 
v_res_14_ = lp_Hex_Hex_signInt(v_z_13_);
lean_dec(v_z_13_);
return v_res_14_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Std(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexRealRoots_Sign(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Std(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexRealRoots_Sign(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Std(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexRealRoots_Sign(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Std(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealRoots_Sign(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexRealRoots_Sign(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexRealRoots_Sign(builtin);
}
#ifdef __cplusplus
}
#endif
