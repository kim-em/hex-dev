// Lean compiler output
// Module: HexRealRoots.Tarski
// Imports: public import Init public meta import Init public import HexRealRoots.SignedRemainderChain public import HexRealRoots.Var
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_usize_dec_eq(size_t, size_t);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* l_Int_instDecidableEq___boxed(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint8_t l_Option_instDecidableEq___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_pop(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_DensePoly_zero___redArg(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_DensePoly_isZero___redArg(lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_DensePoly_C___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lp_Hex_Hex_SignedRemainderChain_check___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* l_Array_range(lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_DensePoly_leadingCoeff___redArg(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lean_int_neg(lean_object*);
lean_object* lp_Hex_Hex_DensePoly_degree_x3f___redArg(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* lp_Hex_Hex_signVar(lean_object*);
uint8_t lean_int_dec_le(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* l_List_range(lean_object*);
lean_object* lean_array_set(lean_object*, lean_object*, lean_object*);
lean_object* l_Array_ofFn___redArg(lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_DensePoly_content(lean_object*);
lean_object* lp_Hex_Hex_DensePoly_primitivePartImpl(lean_object*);
lean_object* lp_Hex_Hex_SignedRemainderChain_build___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__6(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__3(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__2___boxed(lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t);
uint8_t l_Array_instDecidableEqImpl___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_ZPoly_evalDyadic(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_dyadicSign(lean_object*);
lean_object* l_Dyadic_sub(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Int_signImpl(lean_object*);
uint8_t lp_Hex_Hex_instDecidableEqSignedRemainderChain___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Int_signImpl___boxed(lean_object*);
lean_object* l_instDecidableEqDyadic___boxed(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_DensePoly_evalImpl___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorIdx___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorIdx___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorIdx(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorIdx___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_negInf_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_negInf_elim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_finite_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_finite_elim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_posInf_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_posInf_elim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_instDecidableEqEndpoint___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_instDecidableEqEndpoint___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_instDecidableEqEndpoint(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_instDecidableEqEndpoint___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Endpoint_lt___redArg___closed__0;
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_lt___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_lt___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_lt(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_lt___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Endpoint_signAt___redArg___closed__0;
static lean_once_cell_t lp_Hex_Hex_Endpoint_signAt___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Endpoint_signAt___redArg___closed__1;
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_nonvanishing___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_nonvanishing___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_nonvanishing(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_nonvanishing___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_instDecidableEqTarskiCertificate___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_instDecidableEqTarskiCertificate___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_instDecidableEqTarskiCertificate(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_instDecidableEqTarskiCertificate___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_lastIsConstant___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_lastIsConstant___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_lastIsConstant(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_lastIsConstant___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__0, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__0_value;
static const lean_closure_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__1___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__1 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__1_value;
static const lean_closure_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__2___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__2 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__2_value;
static const lean_closure_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__3, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__3 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__3_value;
static const lean_closure_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__4___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__4 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__4_value;
static const lean_closure_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__5___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__5 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__5_value;
static const lean_closure_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__6, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__6 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__6_value;
static const lean_ctor_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__0_value),((lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__1_value)}};
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__7 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__7_value;
static const lean_ctor_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__7_value),((lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__2_value),((lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__3_value),((lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__4_value),((lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__5_value)}};
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__8 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__8_value),((lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__6_value)}};
static const lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__9 = (const lean_object*)&lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__9_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkEndpoints___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkEndpoints___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkEndpoints(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkEndpoints___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query___boxed(lean_object**);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkBindings___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkBindings___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkBindings(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkBindings___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkDomain___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkDomain___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkDomain(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkDomain___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__0(uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__1(uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___boxed(lean_object**);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_check___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_check___redArg___boxed(lean_object**);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_check(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_check___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_intDyadic___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_intDyadic___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_intDyadic___lam__1___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_EndpointSigns_intDyadic___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_EndpointSigns_intDyadic___lam__0, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_EndpointSigns_intDyadic___closed__0 = (const lean_object*)&lp_Hex_Hex_EndpointSigns_intDyadic___closed__0_value;
static const lean_closure_object lp_Hex_Hex_EndpointSigns_intDyadic___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_EndpointSigns_intDyadic___lam__1___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_EndpointSigns_intDyadic___closed__1 = (const lean_object*)&lp_Hex_Hex_EndpointSigns_intDyadic___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_EndpointSigns_intDyadic___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_EndpointSigns_intDyadic___closed__0_value),((lean_object*)&lp_Hex_Hex_EndpointSigns_intDyadic___closed__1_value)}};
static const lean_object* lp_Hex_Hex_EndpointSigns_intDyadic___closed__2 = (const lean_object*)&lp_Hex_Hex_EndpointSigns_intDyadic___closed__2_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_EndpointSigns_intDyadic = (const lean_object*)&lp_Hex_Hex_EndpointSigns_intDyadic___closed__2_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_normalizeContent(lean_object*);
static lean_once_cell_t lp_Hex_Hex_DensePoly_trimTrailingZerosGo___at___00Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7_spec__13___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_DensePoly_trimTrailingZerosGo___at___00Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7_spec__13___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_trimTrailingZerosGo___at___00Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7_spec__13(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_size___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__15(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_size___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__15___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoExponent___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__17(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoExponent___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__17___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__30(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__30___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31_spec__36(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31_spec__36___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__29(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__29___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33_spec__39(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33_spec__39___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34___redArg(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__32(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__32___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18___boxed(lean_object*);
static const lean_array_object lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__0 = (const lean_object*)&lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__0_value;
static lean_once_cell_t lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__1;
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
static lean_once_cell_t lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_npowRec___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__24(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_npowRec___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__24___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19_spec__28(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19_spec__28___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__13(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__13___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_buildAux___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__12(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__13(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__13___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14_spec__20(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14_spec__20___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10___boxed(lean_object*, lean_object*);
static const lean_array_object lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___closed__0 = (const lean_object*)&lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___redArg(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_ZPoly_tarskiQuery___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Int_signImpl___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_ZPoly_tarskiQuery___closed__0 = (const lean_object*)&lp_Hex_Hex_ZPoly_tarskiQuery___closed__0_value;
static const lean_closure_object lp_Hex_Hex_ZPoly_tarskiQuery___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_ZPoly_normalizeContent, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_ZPoly_tarskiQuery___closed__1 = (const lean_object*)&lp_Hex_Hex_ZPoly_tarskiQuery___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_tarskiQuery(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_tarskiQuery___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__19(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5_spec__6___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_buildAux___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__12___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_IntTarskiCertificate_certify(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_IntTarskiCertificate_certify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5_spec__6(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5_spec__8(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5_spec__8___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1_spec__5(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1_spec__5___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__10(uint8_t, lean_object*, lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_checkStep___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__8(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_checkStep___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__8___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9___closed__0;
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__11(uint8_t, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_addImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__6___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_addImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__6___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_addImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__6(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1_spec__5___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3___closed__0 = (const lean_object*)&lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__1(uint8_t, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_IntTarskiCertificate_check(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_IntTarskiCertificate_check___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorIdx___redArg(lean_object* v_x_1_){
_start:
{
switch(lean_obj_tag(v_x_1_))
{
case 0:
{
lean_object* v___x_2_; 
v___x_2_ = lean_unsigned_to_nat(0u);
return v___x_2_;
}
case 1:
{
lean_object* v___x_3_; 
v___x_3_ = lean_unsigned_to_nat(1u);
return v___x_3_;
}
default: 
{
lean_object* v___x_4_; 
v___x_4_ = lean_unsigned_to_nat(2u);
return v___x_4_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorIdx___redArg___boxed(lean_object* v_x_5_){
_start:
{
lean_object* v_res_6_; 
v_res_6_ = lp_Hex_Hex_Endpoint_ctorIdx___redArg(v_x_5_);
lean_dec(v_x_5_);
return v_res_6_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorIdx(lean_object* v_E_7_, lean_object* v_x_8_){
_start:
{
lean_object* v___x_9_; 
v___x_9_ = lp_Hex_Hex_Endpoint_ctorIdx___redArg(v_x_8_);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorIdx___boxed(lean_object* v_E_10_, lean_object* v_x_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_Hex_Hex_Endpoint_ctorIdx(v_E_10_, v_x_11_);
lean_dec(v_x_11_);
return v_res_12_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorElim___redArg(lean_object* v_t_13_, lean_object* v_k_14_){
_start:
{
if (lean_obj_tag(v_t_13_) == 1)
{
lean_object* v_value_15_; lean_object* v___x_16_; 
v_value_15_ = lean_ctor_get(v_t_13_, 0);
lean_inc(v_value_15_);
lean_dec_ref_known(v_t_13_, 1);
v___x_16_ = lean_apply_1(v_k_14_, v_value_15_);
return v___x_16_;
}
else
{
lean_dec(v_t_13_);
return v_k_14_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorElim(lean_object* v_E_17_, lean_object* v_motive_18_, lean_object* v_ctorIdx_19_, lean_object* v_t_20_, lean_object* v_h_21_, lean_object* v_k_22_){
_start:
{
lean_object* v___x_23_; 
v___x_23_ = lp_Hex_Hex_Endpoint_ctorElim___redArg(v_t_20_, v_k_22_);
return v___x_23_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_ctorElim___boxed(lean_object* v_E_24_, lean_object* v_motive_25_, lean_object* v_ctorIdx_26_, lean_object* v_t_27_, lean_object* v_h_28_, lean_object* v_k_29_){
_start:
{
lean_object* v_res_30_; 
v_res_30_ = lp_Hex_Hex_Endpoint_ctorElim(v_E_24_, v_motive_25_, v_ctorIdx_26_, v_t_27_, v_h_28_, v_k_29_);
lean_dec(v_ctorIdx_26_);
return v_res_30_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_negInf_elim___redArg(lean_object* v_t_31_, lean_object* v_negInf_32_){
_start:
{
lean_object* v___x_33_; 
v___x_33_ = lp_Hex_Hex_Endpoint_ctorElim___redArg(v_t_31_, v_negInf_32_);
return v___x_33_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_negInf_elim(lean_object* v_E_34_, lean_object* v_motive_35_, lean_object* v_t_36_, lean_object* v_h_37_, lean_object* v_negInf_38_){
_start:
{
lean_object* v___x_39_; 
v___x_39_ = lp_Hex_Hex_Endpoint_ctorElim___redArg(v_t_36_, v_negInf_38_);
return v___x_39_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_finite_elim___redArg(lean_object* v_t_40_, lean_object* v_finite_41_){
_start:
{
lean_object* v___x_42_; 
v___x_42_ = lp_Hex_Hex_Endpoint_ctorElim___redArg(v_t_40_, v_finite_41_);
return v___x_42_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_finite_elim(lean_object* v_E_43_, lean_object* v_motive_44_, lean_object* v_t_45_, lean_object* v_h_46_, lean_object* v_finite_47_){
_start:
{
lean_object* v___x_48_; 
v___x_48_ = lp_Hex_Hex_Endpoint_ctorElim___redArg(v_t_45_, v_finite_47_);
return v___x_48_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_posInf_elim___redArg(lean_object* v_t_49_, lean_object* v_posInf_50_){
_start:
{
lean_object* v___x_51_; 
v___x_51_ = lp_Hex_Hex_Endpoint_ctorElim___redArg(v_t_49_, v_posInf_50_);
return v___x_51_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_posInf_elim(lean_object* v_E_52_, lean_object* v_motive_53_, lean_object* v_t_54_, lean_object* v_h_55_, lean_object* v_posInf_56_){
_start:
{
lean_object* v___x_57_; 
v___x_57_ = lp_Hex_Hex_Endpoint_ctorElim___redArg(v_t_54_, v_posInf_56_);
return v___x_57_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_instDecidableEqEndpoint___redArg(lean_object* v_inst_58_, lean_object* v_x_59_, lean_object* v_x_60_){
_start:
{
switch(lean_obj_tag(v_x_59_))
{
case 0:
{
lean_dec_ref(v_inst_58_);
if (lean_obj_tag(v_x_60_) == 0)
{
uint8_t v___x_61_; 
v___x_61_ = 1;
return v___x_61_;
}
else
{
uint8_t v___x_62_; 
lean_dec(v_x_60_);
v___x_62_ = 0;
return v___x_62_;
}
}
case 1:
{
if (lean_obj_tag(v_x_60_) == 1)
{
lean_object* v_value_63_; lean_object* v_value_64_; lean_object* v_decide_65_; uint8_t v___x_66_; 
v_value_63_ = lean_ctor_get(v_x_59_, 0);
lean_inc(v_value_63_);
lean_dec_ref_known(v_x_59_, 1);
v_value_64_ = lean_ctor_get(v_x_60_, 0);
lean_inc(v_value_64_);
lean_dec_ref_known(v_x_60_, 1);
v_decide_65_ = lean_apply_2(v_inst_58_, v_value_63_, v_value_64_);
v___x_66_ = lean_unbox(v_decide_65_);
return v___x_66_;
}
else
{
uint8_t v___x_67_; 
lean_dec_ref_known(v_x_59_, 1);
lean_dec(v_x_60_);
lean_dec_ref(v_inst_58_);
v___x_67_ = 0;
return v___x_67_;
}
}
default: 
{
lean_dec_ref(v_inst_58_);
if (lean_obj_tag(v_x_60_) == 2)
{
uint8_t v___x_68_; 
v___x_68_ = 1;
return v___x_68_;
}
else
{
uint8_t v___x_69_; 
lean_dec(v_x_60_);
v___x_69_ = 0;
return v___x_69_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_instDecidableEqEndpoint___redArg___boxed(lean_object* v_inst_70_, lean_object* v_x_71_, lean_object* v_x_72_){
_start:
{
uint8_t v_res_73_; lean_object* v_r_74_; 
v_res_73_ = lp_Hex_Hex_instDecidableEqEndpoint___redArg(v_inst_70_, v_x_71_, v_x_72_);
v_r_74_ = lean_box(v_res_73_);
return v_r_74_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_instDecidableEqEndpoint(lean_object* v_E_75_, lean_object* v_inst_76_, lean_object* v_x_77_, lean_object* v_x_78_){
_start:
{
uint8_t v___x_79_; 
v___x_79_ = lp_Hex_Hex_instDecidableEqEndpoint___redArg(v_inst_76_, v_x_77_, v_x_78_);
return v___x_79_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_instDecidableEqEndpoint___boxed(lean_object* v_E_80_, lean_object* v_inst_81_, lean_object* v_x_82_, lean_object* v_x_83_){
_start:
{
uint8_t v_res_84_; lean_object* v_r_85_; 
v_res_84_ = lp_Hex_Hex_instDecidableEqEndpoint(v_E_80_, v_inst_81_, v_x_82_, v_x_83_);
v_r_85_ = lean_box(v_res_84_);
return v_r_85_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign___redArg___lam__0(lean_object* v_inst_86_, lean_object* v_sign_87_, lean_object* v_a_88_, lean_object* v_b_89_){
_start:
{
lean_object* v___x_90_; lean_object* v___x_91_; 
v___x_90_ = lean_apply_2(v_inst_86_, v_a_88_, v_b_89_);
v___x_91_ = lean_apply_1(v_sign_87_, v___x_90_);
return v___x_91_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign___redArg___lam__1(lean_object* v_inst_92_, lean_object* v_inst_93_, lean_object* v_inst_94_, lean_object* v_sign_95_, lean_object* v_p_96_, lean_object* v_a_97_){
_start:
{
lean_object* v___x_98_; lean_object* v___x_99_; 
v___x_98_ = lp_Hex_Hex_DensePoly_evalImpl___redArg(v_inst_92_, v_inst_93_, v_inst_94_, v_p_96_, v_a_97_);
v___x_99_ = lean_apply_1(v_sign_95_, v___x_98_);
return v___x_99_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign___redArg(lean_object* v_inst_100_, lean_object* v_inst_101_, lean_object* v_inst_102_, lean_object* v_inst_103_, lean_object* v_sign_104_){
_start:
{
lean_object* v___f_105_; lean_object* v___f_106_; lean_object* v___x_107_; 
lean_inc_ref(v_sign_104_);
v___f_105_ = lean_alloc_closure((void*)(lp_Hex_Hex_EndpointSigns_ofSign___redArg___lam__0), 4, 2);
lean_closure_set(v___f_105_, 0, v_inst_101_);
lean_closure_set(v___f_105_, 1, v_sign_104_);
v___f_106_ = lean_alloc_closure((void*)(lp_Hex_Hex_EndpointSigns_ofSign___redArg___lam__1), 6, 4);
lean_closure_set(v___f_106_, 0, v_inst_100_);
lean_closure_set(v___f_106_, 1, v_inst_102_);
lean_closure_set(v___f_106_, 2, v_inst_103_);
lean_closure_set(v___f_106_, 3, v_sign_104_);
v___x_107_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_107_, 0, v___f_105_);
lean_ctor_set(v___x_107_, 1, v___f_106_);
return v___x_107_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign(lean_object* v_E_108_, lean_object* v_inst_109_, lean_object* v_inst_110_, lean_object* v_inst_111_, lean_object* v_inst_112_, lean_object* v_inst_113_, lean_object* v_sign_114_){
_start:
{
lean_object* v___x_115_; 
v___x_115_ = lp_Hex_Hex_EndpointSigns_ofSign___redArg(v_inst_109_, v_inst_111_, v_inst_112_, v_inst_113_, v_sign_114_);
return v___x_115_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_ofSign___boxed(lean_object* v_E_116_, lean_object* v_inst_117_, lean_object* v_inst_118_, lean_object* v_inst_119_, lean_object* v_inst_120_, lean_object* v_inst_121_, lean_object* v_sign_122_){
_start:
{
lean_object* v_res_123_; 
v_res_123_ = lp_Hex_Hex_EndpointSigns_ofSign(v_E_116_, v_inst_117_, v_inst_118_, v_inst_119_, v_inst_120_, v_inst_121_, v_sign_122_);
lean_dec_ref(v_inst_118_);
return v_res_123_;
}
}
static lean_object* _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0(void){
_start:
{
lean_object* v___x_124_; lean_object* v___x_125_; 
v___x_124_ = lean_unsigned_to_nat(0u);
v___x_125_ = lean_nat_to_int(v___x_124_);
return v___x_125_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_lt___redArg(lean_object* v_endpointSigns_126_, lean_object* v_x_127_, lean_object* v_x_128_){
_start:
{
switch(lean_obj_tag(v_x_127_))
{
case 0:
{
lean_dec_ref(v_endpointSigns_126_);
switch(lean_obj_tag(v_x_128_))
{
case 1:
{
uint8_t v___x_129_; 
lean_dec_ref_known(v_x_128_, 1);
v___x_129_ = 1;
return v___x_129_;
}
case 2:
{
uint8_t v___x_130_; 
v___x_130_ = 1;
return v___x_130_;
}
default: 
{
uint8_t v___x_131_; 
lean_dec(v_x_128_);
v___x_131_ = 0;
return v___x_131_;
}
}
}
case 1:
{
switch(lean_obj_tag(v_x_128_))
{
case 2:
{
uint8_t v___x_132_; 
lean_dec_ref_known(v_x_127_, 1);
lean_dec_ref(v_endpointSigns_126_);
v___x_132_ = 1;
return v___x_132_;
}
case 1:
{
lean_object* v_value_133_; lean_object* v_value_134_; lean_object* v_compare_135_; lean_object* v___x_136_; lean_object* v___x_137_; uint8_t v___x_138_; 
v_value_133_ = lean_ctor_get(v_x_127_, 0);
lean_inc(v_value_133_);
lean_dec_ref_known(v_x_127_, 1);
v_value_134_ = lean_ctor_get(v_x_128_, 0);
lean_inc(v_value_134_);
lean_dec_ref_known(v_x_128_, 1);
v_compare_135_ = lean_ctor_get(v_endpointSigns_126_, 0);
lean_inc_ref(v_compare_135_);
lean_dec_ref(v_endpointSigns_126_);
v___x_136_ = lean_apply_2(v_compare_135_, v_value_133_, v_value_134_);
v___x_137_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_138_ = lean_int_dec_lt(v___x_136_, v___x_137_);
lean_dec(v___x_136_);
return v___x_138_;
}
default: 
{
uint8_t v___x_139_; 
lean_dec_ref_known(v_x_127_, 1);
lean_dec(v_x_128_);
lean_dec_ref(v_endpointSigns_126_);
v___x_139_ = 0;
return v___x_139_;
}
}
}
default: 
{
uint8_t v___x_140_; 
lean_dec(v_x_128_);
lean_dec(v_x_127_);
lean_dec_ref(v_endpointSigns_126_);
v___x_140_ = 0;
return v___x_140_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_lt___redArg___boxed(lean_object* v_endpointSigns_141_, lean_object* v_x_142_, lean_object* v_x_143_){
_start:
{
uint8_t v_res_144_; lean_object* v_r_145_; 
v_res_144_ = lp_Hex_Hex_Endpoint_lt___redArg(v_endpointSigns_141_, v_x_142_, v_x_143_);
v_r_145_ = lean_box(v_res_144_);
return v_r_145_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_lt(lean_object* v_D_146_, lean_object* v_E_147_, lean_object* v_inst_148_, lean_object* v_inst_149_, lean_object* v_endpointSigns_150_, lean_object* v_x_151_, lean_object* v_x_152_){
_start:
{
uint8_t v___x_153_; 
v___x_153_ = lp_Hex_Hex_Endpoint_lt___redArg(v_endpointSigns_150_, v_x_151_, v_x_152_);
return v___x_153_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_lt___boxed(lean_object* v_D_154_, lean_object* v_E_155_, lean_object* v_inst_156_, lean_object* v_inst_157_, lean_object* v_endpointSigns_158_, lean_object* v_x_159_, lean_object* v_x_160_){
_start:
{
uint8_t v_res_161_; lean_object* v_r_162_; 
v_res_161_ = lp_Hex_Hex_Endpoint_lt(v_D_154_, v_E_155_, v_inst_156_, v_inst_157_, v_endpointSigns_158_, v_x_159_, v_x_160_);
lean_dec_ref(v_inst_157_);
lean_dec(v_inst_156_);
v_r_162_ = lean_box(v_res_161_);
return v_r_162_;
}
}
static lean_object* _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0(void){
_start:
{
lean_object* v___x_163_; lean_object* v___x_164_; 
v___x_163_ = lean_unsigned_to_nat(1u);
v___x_164_ = lean_nat_to_int(v___x_163_);
return v___x_164_;
}
}
static lean_object* _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__1(void){
_start:
{
lean_object* v___x_165_; lean_object* v___x_166_; 
v___x_165_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_166_ = lean_int_neg(v___x_165_);
return v___x_166_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___redArg(lean_object* v_inst_167_, lean_object* v_sign_168_, lean_object* v_endpointSigns_169_, lean_object* v_p_170_, lean_object* v_x_171_){
_start:
{
switch(lean_obj_tag(v_x_171_))
{
case 0:
{
lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___y_175_; lean_object* v___x_184_; 
lean_dec_ref(v_endpointSigns_169_);
v___x_172_ = lp_Hex_Hex_DensePoly_leadingCoeff___redArg(v_inst_167_, v_p_170_);
v___x_173_ = lean_apply_1(v_sign_168_, v___x_172_);
v___x_184_ = lp_Hex_Hex_DensePoly_degree_x3f___redArg(v_p_170_);
lean_dec_ref(v_p_170_);
if (lean_obj_tag(v___x_184_) == 0)
{
lean_object* v___x_185_; 
v___x_185_ = lean_unsigned_to_nat(0u);
v___y_175_ = v___x_185_;
goto v___jp_174_;
}
else
{
lean_object* v_val_186_; 
v_val_186_ = lean_ctor_get(v___x_184_, 0);
lean_inc(v_val_186_);
lean_dec_ref_known(v___x_184_, 1);
v___y_175_ = v_val_186_;
goto v___jp_174_;
}
v___jp_174_:
{
lean_object* v___x_176_; lean_object* v___x_177_; lean_object* v___x_178_; uint8_t v___x_179_; 
v___x_176_ = lean_unsigned_to_nat(2u);
v___x_177_ = lean_nat_mod(v___y_175_, v___x_176_);
lean_dec(v___y_175_);
v___x_178_ = lean_unsigned_to_nat(1u);
v___x_179_ = lean_nat_dec_eq(v___x_177_, v___x_178_);
lean_dec(v___x_177_);
if (v___x_179_ == 0)
{
lean_object* v___x_180_; lean_object* v___x_181_; 
v___x_180_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_181_ = lean_int_mul(v___x_173_, v___x_180_);
lean_dec(v___x_173_);
return v___x_181_;
}
else
{
lean_object* v___x_182_; lean_object* v___x_183_; 
v___x_182_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__1, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__1_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__1);
v___x_183_ = lean_int_mul(v___x_173_, v___x_182_);
lean_dec(v___x_173_);
return v___x_183_;
}
}
}
case 1:
{
lean_object* v_value_187_; lean_object* v_evalSign_188_; lean_object* v___x_189_; 
lean_dec_ref(v_sign_168_);
v_value_187_ = lean_ctor_get(v_x_171_, 0);
lean_inc(v_value_187_);
lean_dec_ref_known(v_x_171_, 1);
v_evalSign_188_ = lean_ctor_get(v_endpointSigns_169_, 1);
lean_inc_ref(v_evalSign_188_);
lean_dec_ref(v_endpointSigns_169_);
v___x_189_ = lean_apply_2(v_evalSign_188_, v_p_170_, v_value_187_);
return v___x_189_;
}
default: 
{
lean_object* v___x_190_; lean_object* v___x_191_; 
lean_dec_ref(v_endpointSigns_169_);
v___x_190_ = lp_Hex_Hex_DensePoly_leadingCoeff___redArg(v_inst_167_, v_p_170_);
lean_dec_ref(v_p_170_);
v___x_191_ = lean_apply_1(v_sign_168_, v___x_190_);
return v___x_191_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___redArg___boxed(lean_object* v_inst_192_, lean_object* v_sign_193_, lean_object* v_endpointSigns_194_, lean_object* v_p_195_, lean_object* v_x_196_){
_start:
{
lean_object* v_res_197_; 
v_res_197_ = lp_Hex_Hex_Endpoint_signAt___redArg(v_inst_192_, v_sign_193_, v_endpointSigns_194_, v_p_195_, v_x_196_);
lean_dec(v_inst_192_);
return v_res_197_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt(lean_object* v_D_198_, lean_object* v_E_199_, lean_object* v_inst_200_, lean_object* v_inst_201_, lean_object* v_sign_202_, lean_object* v_endpointSigns_203_, lean_object* v_p_204_, lean_object* v_x_205_){
_start:
{
lean_object* v___x_206_; 
v___x_206_ = lp_Hex_Hex_Endpoint_signAt___redArg(v_inst_200_, v_sign_202_, v_endpointSigns_203_, v_p_204_, v_x_205_);
return v___x_206_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___boxed(lean_object* v_D_207_, lean_object* v_E_208_, lean_object* v_inst_209_, lean_object* v_inst_210_, lean_object* v_sign_211_, lean_object* v_endpointSigns_212_, lean_object* v_p_213_, lean_object* v_x_214_){
_start:
{
lean_object* v_res_215_; 
v_res_215_ = lp_Hex_Hex_Endpoint_signAt(v_D_207_, v_E_208_, v_inst_209_, v_inst_210_, v_sign_211_, v_endpointSigns_212_, v_p_213_, v_x_214_);
lean_dec_ref(v_inst_210_);
lean_dec(v_inst_209_);
return v_res_215_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_nonvanishing___redArg(lean_object* v_endpointSigns_216_, lean_object* v_p_217_, lean_object* v_x_218_){
_start:
{
if (lean_obj_tag(v_x_218_) == 1)
{
lean_object* v_value_219_; lean_object* v_evalSign_220_; lean_object* v___x_221_; lean_object* v___x_222_; uint8_t v___x_223_; 
v_value_219_ = lean_ctor_get(v_x_218_, 0);
lean_inc(v_value_219_);
lean_dec_ref_known(v_x_218_, 1);
v_evalSign_220_ = lean_ctor_get(v_endpointSigns_216_, 1);
lean_inc_ref(v_evalSign_220_);
lean_dec_ref(v_endpointSigns_216_);
v___x_221_ = lean_apply_2(v_evalSign_220_, v_p_217_, v_value_219_);
v___x_222_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_223_ = lean_int_dec_eq(v___x_221_, v___x_222_);
lean_dec(v___x_221_);
if (v___x_223_ == 0)
{
uint8_t v___x_224_; 
v___x_224_ = 1;
return v___x_224_;
}
else
{
uint8_t v___x_225_; 
v___x_225_ = 0;
return v___x_225_;
}
}
else
{
uint8_t v___x_226_; 
lean_dec(v_x_218_);
lean_dec_ref(v_p_217_);
lean_dec_ref(v_endpointSigns_216_);
v___x_226_ = 1;
return v___x_226_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_nonvanishing___redArg___boxed(lean_object* v_endpointSigns_227_, lean_object* v_p_228_, lean_object* v_x_229_){
_start:
{
uint8_t v_res_230_; lean_object* v_r_231_; 
v_res_230_ = lp_Hex_Hex_Endpoint_nonvanishing___redArg(v_endpointSigns_227_, v_p_228_, v_x_229_);
v_r_231_ = lean_box(v_res_230_);
return v_r_231_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_nonvanishing(lean_object* v_D_232_, lean_object* v_E_233_, lean_object* v_inst_234_, lean_object* v_inst_235_, lean_object* v_endpointSigns_236_, lean_object* v_p_237_, lean_object* v_x_238_){
_start:
{
uint8_t v___x_239_; 
v___x_239_ = lp_Hex_Hex_Endpoint_nonvanishing___redArg(v_endpointSigns_236_, v_p_237_, v_x_238_);
return v___x_239_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_nonvanishing___boxed(lean_object* v_D_240_, lean_object* v_E_241_, lean_object* v_inst_242_, lean_object* v_inst_243_, lean_object* v_endpointSigns_244_, lean_object* v_p_245_, lean_object* v_x_246_){
_start:
{
uint8_t v_res_247_; lean_object* v_r_248_; 
v_res_247_ = lp_Hex_Hex_Endpoint_nonvanishing(v_D_240_, v_E_241_, v_inst_242_, v_inst_243_, v_endpointSigns_244_, v_p_245_, v_x_246_);
lean_dec_ref(v_inst_243_);
lean_dec(v_inst_242_);
v_r_248_ = lean_box(v_res_247_);
return v_r_248_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_instDecidableEqTarskiCertificate___redArg(lean_object* v_inst_249_, lean_object* v_inst_250_, lean_object* v_inst_251_, lean_object* v_inst_252_, lean_object* v_a_253_, lean_object* v_b_254_){
_start:
{
lean_object* v_ac_255_; lean_object* v_ah_256_; lean_object* v_aq_257_; lean_object* v_al_258_; lean_object* v_au_259_; lean_object* v_asf_260_; lean_object* v_ar_261_; lean_object* v_als_262_; lean_object* v_aus_263_; lean_object* v_alv_264_; lean_object* v_auv_265_; lean_object* v_av_266_; lean_object* v_bc_267_; lean_object* v_bh_268_; lean_object* v_bq_269_; lean_object* v_bl_270_; lean_object* v_bu_271_; lean_object* v_bsf_272_; lean_object* v_br_273_; lean_object* v_bls_274_; lean_object* v_bus_275_; lean_object* v_blv_276_; lean_object* v_buv_277_; lean_object* v_bv_278_; lean_object* v___x_279_; uint8_t v_decide_280_; uint8_t v___y_282_; uint8_t v_decide_287_; uint8_t v___y_289_; uint8_t v___x_290_; uint8_t v___y_292_; uint8_t v___x_293_; uint8_t v___y_295_; uint8_t v___x_296_; uint8_t v___y_298_; uint8_t v___x_299_; uint8_t v___y_301_; lean_object* v___x_302_; uint8_t v___x_303_; uint8_t v___y_305_; uint8_t v___x_306_; uint8_t v___y_308_; uint8_t v___x_309_; uint8_t v___y_311_; uint8_t v___x_312_; 
v_ac_255_ = lean_ctor_get(v_a_253_, 0);
lean_inc(v_ac_255_);
v_ah_256_ = lean_ctor_get(v_a_253_, 1);
lean_inc_ref(v_ah_256_);
v_aq_257_ = lean_ctor_get(v_a_253_, 2);
lean_inc_ref(v_aq_257_);
v_al_258_ = lean_ctor_get(v_a_253_, 3);
lean_inc(v_al_258_);
v_au_259_ = lean_ctor_get(v_a_253_, 4);
lean_inc(v_au_259_);
v_asf_260_ = lean_ctor_get(v_a_253_, 5);
lean_inc_ref(v_asf_260_);
v_ar_261_ = lean_ctor_get(v_a_253_, 6);
lean_inc_ref(v_ar_261_);
v_als_262_ = lean_ctor_get(v_a_253_, 7);
lean_inc_ref(v_als_262_);
v_aus_263_ = lean_ctor_get(v_a_253_, 8);
lean_inc_ref(v_aus_263_);
v_alv_264_ = lean_ctor_get(v_a_253_, 9);
lean_inc(v_alv_264_);
v_auv_265_ = lean_ctor_get(v_a_253_, 10);
lean_inc(v_auv_265_);
v_av_266_ = lean_ctor_get(v_a_253_, 11);
lean_inc(v_av_266_);
lean_dec_ref(v_a_253_);
v_bc_267_ = lean_ctor_get(v_b_254_, 0);
lean_inc(v_bc_267_);
v_bh_268_ = lean_ctor_get(v_b_254_, 1);
lean_inc_ref(v_bh_268_);
v_bq_269_ = lean_ctor_get(v_b_254_, 2);
lean_inc_ref(v_bq_269_);
v_bl_270_ = lean_ctor_get(v_b_254_, 3);
lean_inc(v_bl_270_);
v_bu_271_ = lean_ctor_get(v_b_254_, 4);
lean_inc(v_bu_271_);
v_bsf_272_ = lean_ctor_get(v_b_254_, 5);
lean_inc_ref(v_bsf_272_);
v_br_273_ = lean_ctor_get(v_b_254_, 6);
lean_inc_ref(v_br_273_);
v_bls_274_ = lean_ctor_get(v_b_254_, 7);
lean_inc_ref(v_bls_274_);
v_bus_275_ = lean_ctor_get(v_b_254_, 8);
lean_inc_ref(v_bus_275_);
v_blv_276_ = lean_ctor_get(v_b_254_, 9);
lean_inc(v_blv_276_);
v_buv_277_ = lean_ctor_get(v_b_254_, 10);
lean_inc(v_buv_277_);
v_bv_278_ = lean_ctor_get(v_b_254_, 11);
lean_inc(v_bv_278_);
lean_dec_ref(v_b_254_);
v___x_279_ = lean_apply_2(v_inst_252_, v_ac_255_, v_bc_267_);
lean_inc_ref_n(v_inst_250_, 3);
v_decide_280_ = l_Array_instDecidableEqImpl___redArg(v_inst_250_, v_ah_256_, v_bh_268_);
lean_dec_ref(v_bh_268_);
lean_dec_ref(v_ah_256_);
v_decide_287_ = l_Array_instDecidableEqImpl___redArg(v_inst_250_, v_aq_257_, v_bq_269_);
lean_dec_ref(v_bq_269_);
lean_dec_ref(v_aq_257_);
lean_inc_ref(v_inst_251_);
v___x_290_ = lp_Hex_Hex_instDecidableEqEndpoint___redArg(v_inst_251_, v_al_258_, v_bl_270_);
v___x_293_ = lp_Hex_Hex_instDecidableEqEndpoint___redArg(v_inst_251_, v_au_259_, v_bu_271_);
lean_inc(v_inst_249_);
v___x_296_ = lp_Hex_Hex_instDecidableEqSignedRemainderChain___redArg(v_inst_249_, v_inst_250_, v_asf_260_, v_bsf_272_);
v___x_299_ = lp_Hex_Hex_instDecidableEqSignedRemainderChain___redArg(v_inst_249_, v_inst_250_, v_ar_261_, v_br_273_);
v___x_302_ = lean_alloc_closure((void*)(l_Int_instDecidableEq___boxed), 2, 0);
lean_inc_ref(v___x_302_);
v___x_303_ = l_Array_instDecidableEqImpl___redArg(v___x_302_, v_als_262_, v_bls_274_);
lean_dec_ref(v_bls_274_);
lean_dec_ref(v_als_262_);
v___x_306_ = l_Array_instDecidableEqImpl___redArg(v___x_302_, v_aus_263_, v_bus_275_);
lean_dec_ref(v_bus_275_);
lean_dec_ref(v_aus_263_);
v___x_309_ = lean_nat_dec_eq(v_alv_264_, v_blv_276_);
lean_dec(v_blv_276_);
lean_dec(v_alv_264_);
v___x_312_ = lean_nat_dec_eq(v_auv_265_, v_buv_277_);
lean_dec(v_buv_277_);
lean_dec(v_auv_265_);
if (v___x_312_ == 0)
{
lean_dec(v_bv_278_);
lean_dec(v_av_266_);
v___y_311_ = v___x_312_;
goto v___jp_310_;
}
else
{
uint8_t v___x_313_; 
v___x_313_ = lean_int_dec_eq(v_av_266_, v_bv_278_);
lean_dec(v_bv_278_);
lean_dec(v_av_266_);
v___y_311_ = v___x_313_;
goto v___jp_310_;
}
v___jp_281_:
{
if (v_decide_280_ == 0)
{
uint8_t v___x_283_; 
v___x_283_ = lean_unbox(v___x_279_);
if (v___x_283_ == 0)
{
uint8_t v___x_284_; 
v___x_284_ = lean_unbox(v___x_279_);
return v___x_284_;
}
else
{
return v_decide_280_;
}
}
else
{
uint8_t v___x_285_; 
v___x_285_ = lean_unbox(v___x_279_);
if (v___x_285_ == 0)
{
uint8_t v___x_286_; 
v___x_286_ = lean_unbox(v___x_279_);
return v___x_286_;
}
else
{
return v___y_282_;
}
}
}
v___jp_288_:
{
if (v_decide_287_ == 0)
{
v___y_282_ = v_decide_287_;
goto v___jp_281_;
}
else
{
v___y_282_ = v___y_289_;
goto v___jp_281_;
}
}
v___jp_291_:
{
if (v___x_290_ == 0)
{
v___y_289_ = v___x_290_;
goto v___jp_288_;
}
else
{
v___y_289_ = v___y_292_;
goto v___jp_288_;
}
}
v___jp_294_:
{
if (v___x_293_ == 0)
{
v___y_292_ = v___x_293_;
goto v___jp_291_;
}
else
{
v___y_292_ = v___y_295_;
goto v___jp_291_;
}
}
v___jp_297_:
{
if (v___x_296_ == 0)
{
v___y_295_ = v___x_296_;
goto v___jp_294_;
}
else
{
v___y_295_ = v___y_298_;
goto v___jp_294_;
}
}
v___jp_300_:
{
if (v___x_299_ == 0)
{
v___y_298_ = v___x_299_;
goto v___jp_297_;
}
else
{
v___y_298_ = v___y_301_;
goto v___jp_297_;
}
}
v___jp_304_:
{
if (v___x_303_ == 0)
{
v___y_301_ = v___x_303_;
goto v___jp_300_;
}
else
{
v___y_301_ = v___y_305_;
goto v___jp_300_;
}
}
v___jp_307_:
{
if (v___x_306_ == 0)
{
v___y_305_ = v___x_306_;
goto v___jp_304_;
}
else
{
v___y_305_ = v___y_308_;
goto v___jp_304_;
}
}
v___jp_310_:
{
if (v___x_309_ == 0)
{
v___y_308_ = v___x_309_;
goto v___jp_307_;
}
else
{
v___y_308_ = v___y_311_;
goto v___jp_307_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_instDecidableEqTarskiCertificate___redArg___boxed(lean_object* v_inst_314_, lean_object* v_inst_315_, lean_object* v_inst_316_, lean_object* v_inst_317_, lean_object* v_a_318_, lean_object* v_b_319_){
_start:
{
uint8_t v_res_320_; lean_object* v_r_321_; 
v_res_320_ = lp_Hex_Hex_instDecidableEqTarskiCertificate___redArg(v_inst_314_, v_inst_315_, v_inst_316_, v_inst_317_, v_a_318_, v_b_319_);
v_r_321_ = lean_box(v_res_320_);
return v_r_321_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_instDecidableEqTarskiCertificate(lean_object* v_D_322_, lean_object* v_E_323_, lean_object* v_Ctx_324_, lean_object* v_inst_325_, lean_object* v_inst_326_, lean_object* v_inst_327_, lean_object* v_inst_328_, lean_object* v_a_329_, lean_object* v_b_330_){
_start:
{
uint8_t v___x_331_; 
v___x_331_ = lp_Hex_Hex_instDecidableEqTarskiCertificate___redArg(v_inst_325_, v_inst_326_, v_inst_327_, v_inst_328_, v_a_329_, v_b_330_);
return v___x_331_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_instDecidableEqTarskiCertificate___boxed(lean_object* v_D_332_, lean_object* v_E_333_, lean_object* v_Ctx_334_, lean_object* v_inst_335_, lean_object* v_inst_336_, lean_object* v_inst_337_, lean_object* v_inst_338_, lean_object* v_a_339_, lean_object* v_b_340_){
_start:
{
uint8_t v_res_341_; lean_object* v_r_342_; 
v_res_341_ = lp_Hex_Hex_instDecidableEqTarskiCertificate(v_D_332_, v_E_333_, v_Ctx_334_, v_inst_335_, v_inst_336_, v_inst_337_, v_inst_338_, v_a_339_, v_b_340_);
v_r_342_ = lean_box(v_res_341_);
return v_r_342_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_lastIsConstant___redArg(lean_object* v_inst_343_, lean_object* v_inst_344_, lean_object* v_chain_345_){
_start:
{
lean_object* v_chain_346_; lean_object* v___x_347_; lean_object* v___x_348_; lean_object* v___y_350_; lean_object* v___x_353_; uint8_t v___x_354_; 
v_chain_346_ = lean_ctor_get(v_chain_345_, 0);
v___x_347_ = lean_array_get_size(v_chain_346_);
v___x_348_ = lean_unsigned_to_nat(1u);
v___x_353_ = lean_nat_sub(v___x_347_, v___x_348_);
v___x_354_ = lean_nat_dec_lt(v___x_353_, v___x_347_);
if (v___x_354_ == 0)
{
lean_object* v___x_355_; 
lean_dec(v___x_353_);
v___x_355_ = lp_Hex_Hex_DensePoly_zero___redArg(v_inst_343_, v_inst_344_);
v___y_350_ = v___x_355_;
goto v___jp_349_;
}
else
{
lean_object* v___x_356_; 
lean_dec_ref(v_inst_344_);
lean_dec(v_inst_343_);
v___x_356_ = lean_array_fget_borrowed(v_chain_346_, v___x_353_);
lean_dec(v___x_353_);
lean_inc(v___x_356_);
v___y_350_ = v___x_356_;
goto v___jp_349_;
}
v___jp_349_:
{
lean_object* v___x_351_; uint8_t v___x_352_; 
v___x_351_ = lean_array_get_size(v___y_350_);
lean_dec_ref(v___y_350_);
v___x_352_ = lean_nat_dec_eq(v___x_351_, v___x_348_);
return v___x_352_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_lastIsConstant___redArg___boxed(lean_object* v_inst_357_, lean_object* v_inst_358_, lean_object* v_chain_359_){
_start:
{
uint8_t v_res_360_; lean_object* v_r_361_; 
v_res_360_ = lp_Hex_Hex_SignedRemainderChain_lastIsConstant___redArg(v_inst_357_, v_inst_358_, v_chain_359_);
lean_dec_ref(v_chain_359_);
v_r_361_ = lean_box(v_res_360_);
return v_r_361_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_lastIsConstant(lean_object* v_D_362_, lean_object* v_inst_363_, lean_object* v_inst_364_, lean_object* v_chain_365_){
_start:
{
uint8_t v___x_366_; 
v___x_366_ = lp_Hex_Hex_SignedRemainderChain_lastIsConstant___redArg(v_inst_363_, v_inst_364_, v_chain_365_);
return v___x_366_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_lastIsConstant___boxed(lean_object* v_D_367_, lean_object* v_inst_368_, lean_object* v_inst_369_, lean_object* v_chain_370_){
_start:
{
uint8_t v_res_371_; lean_object* v_r_372_; 
v_res_371_ = lp_Hex_Hex_SignedRemainderChain_lastIsConstant(v_D_367_, v_inst_368_, v_inst_369_, v_chain_370_);
lean_dec_ref(v_chain_370_);
v_r_372_ = lean_box(v_res_371_);
return v_r_372_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___lam__0(lean_object* v_inst_373_, lean_object* v_sign_374_, lean_object* v_endpointSigns_375_, lean_object* v_endpoint_376_, lean_object* v_x_377_){
_start:
{
lean_object* v___x_378_; 
v___x_378_ = lp_Hex_Hex_Endpoint_signAt___redArg(v_inst_373_, v_sign_374_, v_endpointSigns_375_, v_x_377_, v_endpoint_376_);
return v___x_378_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg___lam__0___boxed(lean_object* v_inst_379_, lean_object* v_sign_380_, lean_object* v_endpointSigns_381_, lean_object* v_endpoint_382_, lean_object* v_x_383_){
_start:
{
lean_object* v_res_384_; 
v_res_384_ = lp_Hex_Hex_TarskiCertificate_signs___redArg___lam__0(v_inst_379_, v_sign_380_, v_endpointSigns_381_, v_endpoint_382_, v_x_383_);
lean_dec(v_inst_379_);
return v_res_384_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___redArg(lean_object* v_inst_404_, lean_object* v_sign_405_, lean_object* v_endpointSigns_406_, lean_object* v_chain_407_, lean_object* v_endpoint_408_){
_start:
{
lean_object* v___f_409_; lean_object* v___x_410_; size_t v_sz_411_; size_t v___x_412_; lean_object* v___x_413_; 
v___f_409_ = lean_alloc_closure((void*)(lp_Hex_Hex_TarskiCertificate_signs___redArg___lam__0___boxed), 5, 4);
lean_closure_set(v___f_409_, 0, v_inst_404_);
lean_closure_set(v___f_409_, 1, v_sign_405_);
lean_closure_set(v___f_409_, 2, v_endpointSigns_406_);
lean_closure_set(v___f_409_, 3, v_endpoint_408_);
v___x_410_ = ((lean_object*)(lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__9));
v_sz_411_ = lean_array_size(v_chain_407_);
v___x_412_ = ((size_t)0ULL);
v___x_413_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map(lean_box(0), lean_box(0), lean_box(0), v___x_410_, v___f_409_, v_sz_411_, v___x_412_, v_chain_407_);
return v___x_413_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs(lean_object* v_D_414_, lean_object* v_E_415_, lean_object* v_inst_416_, lean_object* v_inst_417_, lean_object* v_sign_418_, lean_object* v_endpointSigns_419_, lean_object* v_chain_420_, lean_object* v_endpoint_421_){
_start:
{
lean_object* v___x_422_; 
v___x_422_ = lp_Hex_Hex_TarskiCertificate_signs___redArg(v_inst_416_, v_sign_418_, v_endpointSigns_419_, v_chain_420_, v_endpoint_421_);
return v___x_422_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___boxed(lean_object* v_D_423_, lean_object* v_E_424_, lean_object* v_inst_425_, lean_object* v_inst_426_, lean_object* v_sign_427_, lean_object* v_endpointSigns_428_, lean_object* v_chain_429_, lean_object* v_endpoint_430_){
_start:
{
lean_object* v_res_431_; 
v_res_431_ = lp_Hex_Hex_TarskiCertificate_signs(v_D_423_, v_E_424_, v_inst_425_, v_inst_426_, v_sign_427_, v_endpointSigns_428_, v_chain_429_, v_endpoint_430_);
lean_dec_ref(v_inst_426_);
return v_res_431_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkEndpoints___redArg(lean_object* v_endpointSigns_432_, lean_object* v_p_433_, lean_object* v_a_434_, lean_object* v_b_435_){
_start:
{
uint8_t v___x_436_; 
v___x_436_ = lp_Hex_Hex_DensePoly_isZero___redArg(v_p_433_);
if (v___x_436_ == 0)
{
uint8_t v___x_437_; 
lean_inc(v_b_435_);
lean_inc(v_a_434_);
lean_inc_ref(v_endpointSigns_432_);
v___x_437_ = lp_Hex_Hex_Endpoint_lt___redArg(v_endpointSigns_432_, v_a_434_, v_b_435_);
if (v___x_437_ == 0)
{
lean_dec(v_b_435_);
lean_dec(v_a_434_);
lean_dec_ref(v_p_433_);
lean_dec_ref(v_endpointSigns_432_);
return v___x_437_;
}
else
{
uint8_t v___x_438_; 
lean_inc_ref(v_p_433_);
lean_inc_ref(v_endpointSigns_432_);
v___x_438_ = lp_Hex_Hex_Endpoint_nonvanishing___redArg(v_endpointSigns_432_, v_p_433_, v_a_434_);
if (v___x_438_ == 0)
{
lean_dec(v_b_435_);
lean_dec_ref(v_p_433_);
lean_dec_ref(v_endpointSigns_432_);
return v___x_438_;
}
else
{
uint8_t v___x_439_; 
v___x_439_ = lp_Hex_Hex_Endpoint_nonvanishing___redArg(v_endpointSigns_432_, v_p_433_, v_b_435_);
return v___x_439_;
}
}
}
else
{
uint8_t v___x_440_; 
lean_dec(v_b_435_);
lean_dec(v_a_434_);
lean_dec_ref(v_p_433_);
lean_dec_ref(v_endpointSigns_432_);
v___x_440_ = 0;
return v___x_440_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkEndpoints___redArg___boxed(lean_object* v_endpointSigns_441_, lean_object* v_p_442_, lean_object* v_a_443_, lean_object* v_b_444_){
_start:
{
uint8_t v_res_445_; lean_object* v_r_446_; 
v_res_445_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___redArg(v_endpointSigns_441_, v_p_442_, v_a_443_, v_b_444_);
v_r_446_ = lean_box(v_res_445_);
return v_r_446_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkEndpoints(lean_object* v_D_447_, lean_object* v_E_448_, lean_object* v_inst_449_, lean_object* v_inst_450_, lean_object* v_endpointSigns_451_, lean_object* v_p_452_, lean_object* v_a_453_, lean_object* v_b_454_){
_start:
{
uint8_t v___x_455_; 
v___x_455_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___redArg(v_endpointSigns_451_, v_p_452_, v_a_453_, v_b_454_);
return v___x_455_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkEndpoints___boxed(lean_object* v_D_456_, lean_object* v_E_457_, lean_object* v_inst_458_, lean_object* v_inst_459_, lean_object* v_endpointSigns_460_, lean_object* v_p_461_, lean_object* v_a_462_, lean_object* v_b_463_){
_start:
{
uint8_t v_res_464_; lean_object* v_r_465_; 
v_res_464_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints(v_D_456_, v_E_457_, v_inst_458_, v_inst_459_, v_endpointSigns_460_, v_p_461_, v_a_462_, v_b_463_);
lean_dec_ref(v_inst_459_);
lean_dec(v_inst_458_);
v_r_465_ = lean_box(v_res_464_);
return v_r_465_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___redArg(lean_object* v_inst_466_, lean_object* v_sign_467_, lean_object* v_endpointSigns_468_, lean_object* v_context_469_, lean_object* v_p_470_, lean_object* v_f_471_, lean_object* v_a_472_, lean_object* v_b_473_, lean_object* v_squarefree_474_, lean_object* v_remainders_475_){
_start:
{
lean_object* v_chain_476_; lean_object* v_lowerSigns_477_; lean_object* v_upperSigns_478_; lean_object* v___x_479_; lean_object* v_lowerVariations_480_; lean_object* v___x_481_; lean_object* v_upperVariations_482_; lean_object* v___x_483_; lean_object* v___x_484_; lean_object* v___x_485_; lean_object* v___x_486_; 
v_chain_476_ = lean_ctor_get(v_remainders_475_, 0);
lean_inc(v_a_472_);
lean_inc_ref_n(v_chain_476_, 2);
lean_inc_ref(v_endpointSigns_468_);
lean_inc_ref(v_sign_467_);
lean_inc(v_inst_466_);
v_lowerSigns_477_ = lp_Hex_Hex_TarskiCertificate_signs___redArg(v_inst_466_, v_sign_467_, v_endpointSigns_468_, v_chain_476_, v_a_472_);
lean_inc(v_b_473_);
v_upperSigns_478_ = lp_Hex_Hex_TarskiCertificate_signs___redArg(v_inst_466_, v_sign_467_, v_endpointSigns_468_, v_chain_476_, v_b_473_);
lean_inc_ref(v_lowerSigns_477_);
v___x_479_ = lean_array_to_list(v_lowerSigns_477_);
v_lowerVariations_480_ = lp_Hex_Hex_signVar(v___x_479_);
lean_inc_ref(v_upperSigns_478_);
v___x_481_ = lean_array_to_list(v_upperSigns_478_);
v_upperVariations_482_ = lp_Hex_Hex_signVar(v___x_481_);
lean_inc(v_lowerVariations_480_);
v___x_483_ = lean_nat_to_int(v_lowerVariations_480_);
lean_inc(v_upperVariations_482_);
v___x_484_ = lean_nat_to_int(v_upperVariations_482_);
v___x_485_ = lean_int_sub(v___x_483_, v___x_484_);
lean_dec(v___x_484_);
lean_dec(v___x_483_);
v___x_486_ = lean_alloc_ctor(0, 12, 0);
lean_ctor_set(v___x_486_, 0, v_context_469_);
lean_ctor_set(v___x_486_, 1, v_p_470_);
lean_ctor_set(v___x_486_, 2, v_f_471_);
lean_ctor_set(v___x_486_, 3, v_a_472_);
lean_ctor_set(v___x_486_, 4, v_b_473_);
lean_ctor_set(v___x_486_, 5, v_squarefree_474_);
lean_ctor_set(v___x_486_, 6, v_remainders_475_);
lean_ctor_set(v___x_486_, 7, v_lowerSigns_477_);
lean_ctor_set(v___x_486_, 8, v_upperSigns_478_);
lean_ctor_set(v___x_486_, 9, v_lowerVariations_480_);
lean_ctor_set(v___x_486_, 10, v_upperVariations_482_);
lean_ctor_set(v___x_486_, 11, v___x_485_);
return v___x_486_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains(lean_object* v_D_487_, lean_object* v_E_488_, lean_object* v_Ctx_489_, lean_object* v_inst_490_, lean_object* v_inst_491_, lean_object* v_sign_492_, lean_object* v_endpointSigns_493_, lean_object* v_context_494_, lean_object* v_p_495_, lean_object* v_f_496_, lean_object* v_a_497_, lean_object* v_b_498_, lean_object* v_squarefree_499_, lean_object* v_remainders_500_){
_start:
{
lean_object* v___x_501_; 
v___x_501_ = lp_Hex_Hex_TarskiCertificate_fromChains___redArg(v_inst_490_, v_sign_492_, v_endpointSigns_493_, v_context_494_, v_p_495_, v_f_496_, v_a_497_, v_b_498_, v_squarefree_499_, v_remainders_500_);
return v___x_501_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___boxed(lean_object* v_D_502_, lean_object* v_E_503_, lean_object* v_Ctx_504_, lean_object* v_inst_505_, lean_object* v_inst_506_, lean_object* v_sign_507_, lean_object* v_endpointSigns_508_, lean_object* v_context_509_, lean_object* v_p_510_, lean_object* v_f_511_, lean_object* v_a_512_, lean_object* v_b_513_, lean_object* v_squarefree_514_, lean_object* v_remainders_515_){
_start:
{
lean_object* v_res_516_; 
v_res_516_ = lp_Hex_Hex_TarskiCertificate_fromChains(v_D_502_, v_E_503_, v_Ctx_504_, v_inst_505_, v_inst_506_, v_sign_507_, v_endpointSigns_508_, v_context_509_, v_p_510_, v_f_511_, v_a_512_, v_b_513_, v_squarefree_514_, v_remainders_515_);
lean_dec_ref(v_inst_506_);
return v_res_516_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___redArg(lean_object* v_inst_517_, lean_object* v_inst_518_, lean_object* v_inst_519_, lean_object* v_inst_520_, lean_object* v_inst_521_, lean_object* v_inst_522_, lean_object* v_inst_523_, lean_object* v_inst_524_, lean_object* v_sign_525_, lean_object* v_endpointSigns_526_, lean_object* v_normalize_527_, lean_object* v_context_528_, lean_object* v_p_529_, lean_object* v_f_530_, lean_object* v_a_531_, lean_object* v_b_532_){
_start:
{
uint8_t v___x_533_; 
lean_inc(v_b_532_);
lean_inc(v_a_531_);
lean_inc_ref(v_p_529_);
lean_inc_ref(v_endpointSigns_526_);
v___x_533_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___redArg(v_endpointSigns_526_, v_p_529_, v_a_531_, v_b_532_);
if (v___x_533_ == 0)
{
lean_object* v___x_534_; 
lean_dec(v_b_532_);
lean_dec(v_a_531_);
lean_dec_ref(v_f_530_);
lean_dec_ref(v_p_529_);
lean_dec(v_context_528_);
lean_dec_ref(v_normalize_527_);
lean_dec_ref(v_endpointSigns_526_);
lean_dec_ref(v_sign_525_);
lean_dec(v_inst_524_);
lean_dec(v_inst_523_);
lean_dec(v_inst_522_);
lean_dec(v_inst_521_);
lean_dec(v_inst_520_);
lean_dec(v_inst_519_);
lean_dec_ref(v_inst_518_);
lean_dec(v_inst_517_);
v___x_534_ = lean_box(0);
return v___x_534_;
}
else
{
lean_object* v___x_535_; lean_object* v_squarefree_536_; uint8_t v___x_537_; 
lean_inc_n(v_inst_519_, 2);
lean_inc_ref_n(v_inst_518_, 3);
lean_inc_n(v_inst_517_, 3);
v___x_535_ = lp_Hex_Hex_DensePoly_C___redArg(v_inst_517_, v_inst_518_, v_inst_519_);
lean_inc_ref(v_p_529_);
lean_inc_ref(v_normalize_527_);
lean_inc_ref(v_sign_525_);
lean_inc(v_inst_523_);
lean_inc(v_inst_524_);
lean_inc(v_inst_522_);
lean_inc(v_inst_521_);
lean_inc(v_inst_520_);
v_squarefree_536_ = lp_Hex_Hex_SignedRemainderChain_build___redArg(v_inst_517_, v_inst_518_, v_inst_519_, v_inst_520_, v_inst_521_, v_inst_522_, v_inst_524_, v_inst_523_, v_sign_525_, v_normalize_527_, v_p_529_, v___x_535_);
v___x_537_ = lp_Hex_Hex_SignedRemainderChain_lastIsConstant___redArg(v_inst_517_, v_inst_518_, v_squarefree_536_);
if (v___x_537_ == 0)
{
lean_object* v___x_538_; 
lean_dec_ref(v_squarefree_536_);
lean_dec(v_b_532_);
lean_dec(v_a_531_);
lean_dec_ref(v_f_530_);
lean_dec_ref(v_p_529_);
lean_dec(v_context_528_);
lean_dec_ref(v_normalize_527_);
lean_dec_ref(v_endpointSigns_526_);
lean_dec_ref(v_sign_525_);
lean_dec(v_inst_524_);
lean_dec(v_inst_523_);
lean_dec(v_inst_522_);
lean_dec(v_inst_521_);
lean_dec(v_inst_520_);
lean_dec(v_inst_519_);
lean_dec_ref(v_inst_518_);
lean_dec(v_inst_517_);
v___x_538_ = lean_box(0);
return v___x_538_;
}
else
{
lean_object* v___x_539_; lean_object* v___x_540_; lean_object* v___x_541_; 
lean_inc_ref(v_f_530_);
lean_inc_ref(v_p_529_);
lean_inc_ref(v_sign_525_);
lean_inc(v_inst_517_);
v___x_539_ = lp_Hex_Hex_SignedRemainderChain_build___redArg(v_inst_517_, v_inst_518_, v_inst_519_, v_inst_520_, v_inst_521_, v_inst_522_, v_inst_524_, v_inst_523_, v_sign_525_, v_normalize_527_, v_p_529_, v_f_530_);
v___x_540_ = lp_Hex_Hex_TarskiCertificate_fromChains___redArg(v_inst_517_, v_sign_525_, v_endpointSigns_526_, v_context_528_, v_p_529_, v_f_530_, v_a_531_, v_b_532_, v_squarefree_536_, v___x_539_);
v___x_541_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_541_, 0, v___x_540_);
return v___x_541_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify(lean_object* v_D_542_, lean_object* v_E_543_, lean_object* v_Ctx_544_, lean_object* v_inst_545_, lean_object* v_inst_546_, lean_object* v_inst_547_, lean_object* v_inst_548_, lean_object* v_inst_549_, lean_object* v_inst_550_, lean_object* v_inst_551_, lean_object* v_inst_552_, lean_object* v_sign_553_, lean_object* v_endpointSigns_554_, lean_object* v_normalize_555_, lean_object* v_context_556_, lean_object* v_p_557_, lean_object* v_f_558_, lean_object* v_a_559_, lean_object* v_b_560_){
_start:
{
lean_object* v___x_561_; 
v___x_561_ = lp_Hex_Hex_TarskiCertificate_certify___redArg(v_inst_545_, v_inst_546_, v_inst_547_, v_inst_548_, v_inst_549_, v_inst_550_, v_inst_551_, v_inst_552_, v_sign_553_, v_endpointSigns_554_, v_normalize_555_, v_context_556_, v_p_557_, v_f_558_, v_a_559_, v_b_560_);
return v___x_561_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___boxed(lean_object** _args){
lean_object* v_D_562_ = _args[0];
lean_object* v_E_563_ = _args[1];
lean_object* v_Ctx_564_ = _args[2];
lean_object* v_inst_565_ = _args[3];
lean_object* v_inst_566_ = _args[4];
lean_object* v_inst_567_ = _args[5];
lean_object* v_inst_568_ = _args[6];
lean_object* v_inst_569_ = _args[7];
lean_object* v_inst_570_ = _args[8];
lean_object* v_inst_571_ = _args[9];
lean_object* v_inst_572_ = _args[10];
lean_object* v_sign_573_ = _args[11];
lean_object* v_endpointSigns_574_ = _args[12];
lean_object* v_normalize_575_ = _args[13];
lean_object* v_context_576_ = _args[14];
lean_object* v_p_577_ = _args[15];
lean_object* v_f_578_ = _args[16];
lean_object* v_a_579_ = _args[17];
lean_object* v_b_580_ = _args[18];
_start:
{
lean_object* v_res_581_; 
v_res_581_ = lp_Hex_Hex_TarskiCertificate_certify(v_D_562_, v_E_563_, v_Ctx_564_, v_inst_565_, v_inst_566_, v_inst_567_, v_inst_568_, v_inst_569_, v_inst_570_, v_inst_571_, v_inst_572_, v_sign_573_, v_endpointSigns_574_, v_normalize_575_, v_context_576_, v_p_577_, v_f_578_, v_a_579_, v_b_580_);
return v_res_581_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query___redArg(lean_object* v_inst_582_, lean_object* v_inst_583_, lean_object* v_inst_584_, lean_object* v_inst_585_, lean_object* v_inst_586_, lean_object* v_inst_587_, lean_object* v_inst_588_, lean_object* v_inst_589_, lean_object* v_sign_590_, lean_object* v_endpointSigns_591_, lean_object* v_normalize_592_, lean_object* v_p_593_, lean_object* v_f_594_, lean_object* v_a_595_, lean_object* v_b_596_){
_start:
{
lean_object* v___x_597_; lean_object* v___x_598_; 
v___x_597_ = lean_box(0);
v___x_598_ = lp_Hex_Hex_TarskiCertificate_certify___redArg(v_inst_582_, v_inst_583_, v_inst_584_, v_inst_585_, v_inst_586_, v_inst_587_, v_inst_588_, v_inst_589_, v_sign_590_, v_endpointSigns_591_, v_normalize_592_, v___x_597_, v_p_593_, v_f_594_, v_a_595_, v_b_596_);
if (lean_obj_tag(v___x_598_) == 0)
{
lean_object* v___x_599_; 
v___x_599_ = lean_box(0);
return v___x_599_;
}
else
{
lean_object* v_val_600_; lean_object* v___x_602_; uint8_t v_isShared_603_; uint8_t v_isSharedCheck_608_; 
v_val_600_ = lean_ctor_get(v___x_598_, 0);
v_isSharedCheck_608_ = !lean_is_exclusive(v___x_598_);
if (v_isSharedCheck_608_ == 0)
{
v___x_602_ = v___x_598_;
v_isShared_603_ = v_isSharedCheck_608_;
goto v_resetjp_601_;
}
else
{
lean_inc(v_val_600_);
lean_dec(v___x_598_);
v___x_602_ = lean_box(0);
v_isShared_603_ = v_isSharedCheck_608_;
goto v_resetjp_601_;
}
v_resetjp_601_:
{
lean_object* v_value_604_; lean_object* v___x_606_; 
v_value_604_ = lean_ctor_get(v_val_600_, 11);
lean_inc(v_value_604_);
lean_dec(v_val_600_);
if (v_isShared_603_ == 0)
{
lean_ctor_set(v___x_602_, 0, v_value_604_);
v___x_606_ = v___x_602_;
goto v_reusejp_605_;
}
else
{
lean_object* v_reuseFailAlloc_607_; 
v_reuseFailAlloc_607_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_607_, 0, v_value_604_);
v___x_606_ = v_reuseFailAlloc_607_;
goto v_reusejp_605_;
}
v_reusejp_605_:
{
return v___x_606_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query(lean_object* v_D_609_, lean_object* v_E_610_, lean_object* v_inst_611_, lean_object* v_inst_612_, lean_object* v_inst_613_, lean_object* v_inst_614_, lean_object* v_inst_615_, lean_object* v_inst_616_, lean_object* v_inst_617_, lean_object* v_inst_618_, lean_object* v_sign_619_, lean_object* v_endpointSigns_620_, lean_object* v_normalize_621_, lean_object* v_p_622_, lean_object* v_f_623_, lean_object* v_a_624_, lean_object* v_b_625_){
_start:
{
lean_object* v___x_626_; 
v___x_626_ = lp_Hex_Hex_TarskiCertificate_query___redArg(v_inst_611_, v_inst_612_, v_inst_613_, v_inst_614_, v_inst_615_, v_inst_616_, v_inst_617_, v_inst_618_, v_sign_619_, v_endpointSigns_620_, v_normalize_621_, v_p_622_, v_f_623_, v_a_624_, v_b_625_);
return v___x_626_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query___boxed(lean_object** _args){
lean_object* v_D_627_ = _args[0];
lean_object* v_E_628_ = _args[1];
lean_object* v_inst_629_ = _args[2];
lean_object* v_inst_630_ = _args[3];
lean_object* v_inst_631_ = _args[4];
lean_object* v_inst_632_ = _args[5];
lean_object* v_inst_633_ = _args[6];
lean_object* v_inst_634_ = _args[7];
lean_object* v_inst_635_ = _args[8];
lean_object* v_inst_636_ = _args[9];
lean_object* v_sign_637_ = _args[10];
lean_object* v_endpointSigns_638_ = _args[11];
lean_object* v_normalize_639_ = _args[12];
lean_object* v_p_640_ = _args[13];
lean_object* v_f_641_ = _args[14];
lean_object* v_a_642_ = _args[15];
lean_object* v_b_643_ = _args[16];
_start:
{
lean_object* v_res_644_; 
v_res_644_ = lp_Hex_Hex_TarskiCertificate_query(v_D_627_, v_E_628_, v_inst_629_, v_inst_630_, v_inst_631_, v_inst_632_, v_inst_633_, v_inst_634_, v_inst_635_, v_inst_636_, v_sign_637_, v_endpointSigns_638_, v_normalize_639_, v_p_640_, v_f_641_, v_a_642_, v_b_643_);
return v_res_644_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkBindings___redArg(lean_object* v_inst_645_, lean_object* v_inst_646_, lean_object* v_inst_647_, lean_object* v_context_648_, lean_object* v_p_649_, lean_object* v_f_650_, lean_object* v_a_651_, lean_object* v_b_652_, lean_object* v_value_653_, lean_object* v_cert_654_){
_start:
{
lean_object* v_context_655_; lean_object* v_head_656_; lean_object* v_queryPoly_657_; lean_object* v_lower_658_; lean_object* v_upper_659_; lean_object* v_value_660_; lean_object* v___x_661_; uint8_t v___x_662_; 
v_context_655_ = lean_ctor_get(v_cert_654_, 0);
lean_inc(v_context_655_);
v_head_656_ = lean_ctor_get(v_cert_654_, 1);
lean_inc_ref(v_head_656_);
v_queryPoly_657_ = lean_ctor_get(v_cert_654_, 2);
lean_inc_ref(v_queryPoly_657_);
v_lower_658_ = lean_ctor_get(v_cert_654_, 3);
lean_inc(v_lower_658_);
v_upper_659_ = lean_ctor_get(v_cert_654_, 4);
lean_inc(v_upper_659_);
v_value_660_ = lean_ctor_get(v_cert_654_, 11);
lean_inc(v_value_660_);
lean_dec_ref(v_cert_654_);
v___x_661_ = lean_apply_2(v_inst_647_, v_context_655_, v_context_648_);
v___x_662_ = lean_unbox(v___x_661_);
if (v___x_662_ == 0)
{
uint8_t v___x_663_; 
lean_dec(v_value_660_);
lean_dec(v_upper_659_);
lean_dec(v_lower_658_);
lean_dec_ref(v_queryPoly_657_);
lean_dec_ref(v_head_656_);
lean_dec(v_b_652_);
lean_dec(v_a_651_);
lean_dec_ref(v_inst_646_);
lean_dec_ref(v_inst_645_);
v___x_663_ = lean_unbox(v___x_661_);
return v___x_663_;
}
else
{
uint8_t v_decide_664_; 
lean_inc_ref(v_inst_645_);
v_decide_664_ = l_Array_instDecidableEqImpl___redArg(v_inst_645_, v_head_656_, v_p_649_);
lean_dec_ref(v_head_656_);
if (v_decide_664_ == 0)
{
lean_dec(v_value_660_);
lean_dec(v_upper_659_);
lean_dec(v_lower_658_);
lean_dec_ref(v_queryPoly_657_);
lean_dec(v_b_652_);
lean_dec(v_a_651_);
lean_dec_ref(v_inst_646_);
lean_dec_ref(v_inst_645_);
return v_decide_664_;
}
else
{
uint8_t v_decide_665_; 
v_decide_665_ = l_Array_instDecidableEqImpl___redArg(v_inst_645_, v_queryPoly_657_, v_f_650_);
lean_dec_ref(v_queryPoly_657_);
if (v_decide_665_ == 0)
{
lean_dec(v_value_660_);
lean_dec(v_upper_659_);
lean_dec(v_lower_658_);
lean_dec(v_b_652_);
lean_dec(v_a_651_);
lean_dec_ref(v_inst_646_);
return v_decide_665_;
}
else
{
uint8_t v___x_666_; 
lean_inc_ref(v_inst_646_);
v___x_666_ = lp_Hex_Hex_instDecidableEqEndpoint___redArg(v_inst_646_, v_lower_658_, v_a_651_);
if (v___x_666_ == 0)
{
lean_dec(v_value_660_);
lean_dec(v_upper_659_);
lean_dec(v_b_652_);
lean_dec_ref(v_inst_646_);
return v___x_666_;
}
else
{
uint8_t v___x_667_; 
v___x_667_ = lp_Hex_Hex_instDecidableEqEndpoint___redArg(v_inst_646_, v_upper_659_, v_b_652_);
if (v___x_667_ == 0)
{
lean_dec(v_value_660_);
return v___x_667_;
}
else
{
uint8_t v___x_668_; 
v___x_668_ = lean_int_dec_eq(v_value_660_, v_value_653_);
lean_dec(v_value_660_);
return v___x_668_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkBindings___redArg___boxed(lean_object* v_inst_669_, lean_object* v_inst_670_, lean_object* v_inst_671_, lean_object* v_context_672_, lean_object* v_p_673_, lean_object* v_f_674_, lean_object* v_a_675_, lean_object* v_b_676_, lean_object* v_value_677_, lean_object* v_cert_678_){
_start:
{
uint8_t v_res_679_; lean_object* v_r_680_; 
v_res_679_ = lp_Hex_Hex_TarskiCertificate_checkBindings___redArg(v_inst_669_, v_inst_670_, v_inst_671_, v_context_672_, v_p_673_, v_f_674_, v_a_675_, v_b_676_, v_value_677_, v_cert_678_);
lean_dec(v_value_677_);
lean_dec_ref(v_f_674_);
lean_dec_ref(v_p_673_);
v_r_680_ = lean_box(v_res_679_);
return v_r_680_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkBindings(lean_object* v_D_681_, lean_object* v_E_682_, lean_object* v_Ctx_683_, lean_object* v_inst_684_, lean_object* v_inst_685_, lean_object* v_inst_686_, lean_object* v_inst_687_, lean_object* v_context_688_, lean_object* v_p_689_, lean_object* v_f_690_, lean_object* v_a_691_, lean_object* v_b_692_, lean_object* v_value_693_, lean_object* v_cert_694_){
_start:
{
uint8_t v___x_695_; 
v___x_695_ = lp_Hex_Hex_TarskiCertificate_checkBindings___redArg(v_inst_685_, v_inst_686_, v_inst_687_, v_context_688_, v_p_689_, v_f_690_, v_a_691_, v_b_692_, v_value_693_, v_cert_694_);
return v___x_695_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkBindings___boxed(lean_object* v_D_696_, lean_object* v_E_697_, lean_object* v_Ctx_698_, lean_object* v_inst_699_, lean_object* v_inst_700_, lean_object* v_inst_701_, lean_object* v_inst_702_, lean_object* v_context_703_, lean_object* v_p_704_, lean_object* v_f_705_, lean_object* v_a_706_, lean_object* v_b_707_, lean_object* v_value_708_, lean_object* v_cert_709_){
_start:
{
uint8_t v_res_710_; lean_object* v_r_711_; 
v_res_710_ = lp_Hex_Hex_TarskiCertificate_checkBindings(v_D_696_, v_E_697_, v_Ctx_698_, v_inst_699_, v_inst_700_, v_inst_701_, v_inst_702_, v_context_703_, v_p_704_, v_f_705_, v_a_706_, v_b_707_, v_value_708_, v_cert_709_);
lean_dec(v_value_708_);
lean_dec_ref(v_f_705_);
lean_dec_ref(v_p_704_);
lean_dec(v_inst_699_);
v_r_711_ = lean_box(v_res_710_);
return v_r_711_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkDomain___redArg(lean_object* v_inst_712_, lean_object* v_inst_713_, lean_object* v_inst_714_, lean_object* v_inst_715_, lean_object* v_inst_716_, lean_object* v_inst_717_, lean_object* v_inst_718_, lean_object* v_sign_719_, lean_object* v_endpointSigns_720_, lean_object* v_p_721_, lean_object* v_a_722_, lean_object* v_b_723_, lean_object* v_squarefree_724_){
_start:
{
uint8_t v___y_726_; uint8_t v___x_728_; 
lean_inc_ref(v_p_721_);
v___x_728_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___redArg(v_endpointSigns_720_, v_p_721_, v_a_722_, v_b_723_);
if (v___x_728_ == 0)
{
lean_dec_ref(v_p_721_);
lean_dec_ref(v_sign_719_);
lean_dec(v_inst_718_);
lean_dec(v_inst_717_);
lean_dec(v_inst_716_);
lean_dec(v_inst_715_);
lean_dec(v_inst_714_);
v___y_726_ = v___x_728_;
goto v___jp_725_;
}
else
{
lean_object* v___x_729_; uint8_t v___x_730_; 
lean_inc_ref_n(v_inst_713_, 2);
lean_inc_n(v_inst_712_, 2);
v___x_729_ = lp_Hex_Hex_DensePoly_C___redArg(v_inst_712_, v_inst_713_, v_inst_714_);
lean_inc_ref(v_squarefree_724_);
v___x_730_ = lp_Hex_Hex_SignedRemainderChain_check___redArg(v_inst_712_, v_inst_713_, v_inst_715_, v_inst_716_, v_inst_717_, v_inst_718_, v_sign_719_, v_p_721_, v___x_729_, v_squarefree_724_);
v___y_726_ = v___x_730_;
goto v___jp_725_;
}
v___jp_725_:
{
if (v___y_726_ == 0)
{
lean_dec_ref(v_squarefree_724_);
lean_dec_ref(v_inst_713_);
lean_dec(v_inst_712_);
return v___y_726_;
}
else
{
uint8_t v___x_727_; 
v___x_727_ = lp_Hex_Hex_SignedRemainderChain_lastIsConstant___redArg(v_inst_712_, v_inst_713_, v_squarefree_724_);
lean_dec_ref(v_squarefree_724_);
return v___x_727_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkDomain___redArg___boxed(lean_object* v_inst_731_, lean_object* v_inst_732_, lean_object* v_inst_733_, lean_object* v_inst_734_, lean_object* v_inst_735_, lean_object* v_inst_736_, lean_object* v_inst_737_, lean_object* v_sign_738_, lean_object* v_endpointSigns_739_, lean_object* v_p_740_, lean_object* v_a_741_, lean_object* v_b_742_, lean_object* v_squarefree_743_){
_start:
{
uint8_t v_res_744_; lean_object* v_r_745_; 
v_res_744_ = lp_Hex_Hex_TarskiCertificate_checkDomain___redArg(v_inst_731_, v_inst_732_, v_inst_733_, v_inst_734_, v_inst_735_, v_inst_736_, v_inst_737_, v_sign_738_, v_endpointSigns_739_, v_p_740_, v_a_741_, v_b_742_, v_squarefree_743_);
v_r_745_ = lean_box(v_res_744_);
return v_r_745_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkDomain(lean_object* v_D_746_, lean_object* v_E_747_, lean_object* v_inst_748_, lean_object* v_inst_749_, lean_object* v_inst_750_, lean_object* v_inst_751_, lean_object* v_inst_752_, lean_object* v_inst_753_, lean_object* v_inst_754_, lean_object* v_sign_755_, lean_object* v_endpointSigns_756_, lean_object* v_p_757_, lean_object* v_a_758_, lean_object* v_b_759_, lean_object* v_squarefree_760_){
_start:
{
uint8_t v___x_761_; 
v___x_761_ = lp_Hex_Hex_TarskiCertificate_checkDomain___redArg(v_inst_748_, v_inst_749_, v_inst_750_, v_inst_751_, v_inst_752_, v_inst_753_, v_inst_754_, v_sign_755_, v_endpointSigns_756_, v_p_757_, v_a_758_, v_b_759_, v_squarefree_760_);
return v___x_761_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkDomain___boxed(lean_object* v_D_762_, lean_object* v_E_763_, lean_object* v_inst_764_, lean_object* v_inst_765_, lean_object* v_inst_766_, lean_object* v_inst_767_, lean_object* v_inst_768_, lean_object* v_inst_769_, lean_object* v_inst_770_, lean_object* v_sign_771_, lean_object* v_endpointSigns_772_, lean_object* v_p_773_, lean_object* v_a_774_, lean_object* v_b_775_, lean_object* v_squarefree_776_){
_start:
{
uint8_t v_res_777_; lean_object* v_r_778_; 
v_res_777_ = lp_Hex_Hex_TarskiCertificate_checkDomain(v_D_762_, v_E_763_, v_inst_764_, v_inst_765_, v_inst_766_, v_inst_767_, v_inst_768_, v_inst_769_, v_inst_770_, v_sign_771_, v_endpointSigns_772_, v_p_773_, v_a_774_, v_b_775_, v_squarefree_776_);
v_r_778_ = lean_box(v_res_777_);
return v_r_778_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__0(uint8_t v___y_779_, lean_object* v_v_780_){
_start:
{
lean_object* v___x_781_; lean_object* v___x_782_; uint8_t v___x_783_; 
v___x_781_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_782_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__1, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__1_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__1);
v___x_783_ = lean_int_dec_le(v___x_782_, v_v_780_);
if (v___x_783_ == 0)
{
return v___y_779_;
}
else
{
uint8_t v___x_784_; 
v___x_784_ = lean_int_dec_le(v_v_780_, v___x_781_);
if (v___x_784_ == 0)
{
return v___y_779_;
}
else
{
uint8_t v___x_785_; 
v___x_785_ = 0;
return v___x_785_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__0___boxed(lean_object* v___y_786_, lean_object* v_v_787_){
_start:
{
uint8_t v___y_770__boxed_788_; uint8_t v_res_789_; lean_object* v_r_790_; 
v___y_770__boxed_788_ = lean_unbox(v___y_786_);
v_res_789_ = lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__0(v___y_770__boxed_788_, v_v_787_);
lean_dec(v_v_787_);
v_r_790_ = lean_box(v_res_789_);
return v_r_790_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__1(uint8_t v___x_791_, lean_object* v_v_792_){
_start:
{
lean_object* v___x_793_; lean_object* v___x_794_; uint8_t v___x_795_; 
v___x_793_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_794_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__1, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__1_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__1);
v___x_795_ = lean_int_dec_le(v___x_794_, v_v_792_);
if (v___x_795_ == 0)
{
return v___x_791_;
}
else
{
uint8_t v___x_796_; 
v___x_796_ = lean_int_dec_le(v_v_792_, v___x_793_);
if (v___x_796_ == 0)
{
return v___x_791_;
}
else
{
uint8_t v___x_797_; 
v___x_797_ = 0;
return v___x_797_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__1___boxed(lean_object* v___x_798_, lean_object* v_v_799_){
_start:
{
uint8_t v___x_788__boxed_800_; uint8_t v_res_801_; lean_object* v_r_802_; 
v___x_788__boxed_800_ = lean_unbox(v___x_798_);
v_res_801_ = lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__1(v___x_788__boxed_800_, v_v_799_);
lean_dec(v_v_799_);
v_r_802_ = lean_box(v_res_801_);
return v_r_802_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___redArg(lean_object* v_inst_803_, lean_object* v_inst_804_, lean_object* v_inst_805_, lean_object* v_inst_806_, lean_object* v_inst_807_, lean_object* v_inst_808_, lean_object* v_sign_809_, lean_object* v_endpointSigns_810_, lean_object* v_p_811_, lean_object* v_f_812_, lean_object* v_a_813_, lean_object* v_b_814_, lean_object* v_value_815_, lean_object* v_cert_816_){
_start:
{
lean_object* v_remainders_817_; lean_object* v_lowerSigns_818_; lean_object* v_upperSigns_819_; lean_object* v_lowerVariations_820_; lean_object* v_upperVariations_821_; uint8_t v___y_834_; uint8_t v___y_847_; uint8_t v___x_863_; 
v_remainders_817_ = lean_ctor_get(v_cert_816_, 6);
lean_inc_ref_n(v_remainders_817_, 2);
v_lowerSigns_818_ = lean_ctor_get(v_cert_816_, 7);
lean_inc_ref(v_lowerSigns_818_);
v_upperSigns_819_ = lean_ctor_get(v_cert_816_, 8);
lean_inc_ref(v_upperSigns_819_);
v_lowerVariations_820_ = lean_ctor_get(v_cert_816_, 9);
lean_inc(v_lowerVariations_820_);
v_upperVariations_821_ = lean_ctor_get(v_cert_816_, 10);
lean_inc(v_upperVariations_821_);
lean_dec_ref(v_cert_816_);
lean_inc_ref(v_sign_809_);
lean_inc(v_inst_803_);
v___x_863_ = lp_Hex_Hex_SignedRemainderChain_check___redArg(v_inst_803_, v_inst_804_, v_inst_805_, v_inst_806_, v_inst_807_, v_inst_808_, v_sign_809_, v_p_811_, v_f_812_, v_remainders_817_);
if (v___x_863_ == 0)
{
lean_dec(v_a_813_);
v___y_847_ = v___x_863_;
goto v___jp_846_;
}
else
{
lean_object* v_chain_864_; lean_object* v___x_865_; lean_object* v___x_866_; uint8_t v___x_867_; 
v_chain_864_ = lean_ctor_get(v_remainders_817_, 0);
v___x_865_ = lean_alloc_closure((void*)(l_Int_instDecidableEq___boxed), 2, 0);
lean_inc_ref(v_chain_864_);
lean_inc_ref(v_endpointSigns_810_);
lean_inc_ref(v_sign_809_);
lean_inc(v_inst_803_);
v___x_866_ = lp_Hex_Hex_TarskiCertificate_signs___redArg(v_inst_803_, v_sign_809_, v_endpointSigns_810_, v_chain_864_, v_a_813_);
v___x_867_ = l_Array_instDecidableEqImpl___redArg(v___x_865_, v_lowerSigns_818_, v___x_866_);
lean_dec_ref(v___x_866_);
v___y_847_ = v___x_867_;
goto v___jp_846_;
}
v___jp_822_:
{
lean_object* v___x_823_; lean_object* v___x_824_; uint8_t v___x_825_; 
v___x_823_ = lean_array_to_list(v_lowerSigns_818_);
v___x_824_ = lp_Hex_Hex_signVar(v___x_823_);
v___x_825_ = lean_nat_dec_eq(v_lowerVariations_820_, v___x_824_);
lean_dec(v___x_824_);
if (v___x_825_ == 0)
{
lean_dec(v_upperVariations_821_);
lean_dec(v_lowerVariations_820_);
lean_dec_ref(v_upperSigns_819_);
return v___x_825_;
}
else
{
lean_object* v___x_826_; lean_object* v___x_827_; uint8_t v___x_828_; 
v___x_826_ = lean_array_to_list(v_upperSigns_819_);
v___x_827_ = lp_Hex_Hex_signVar(v___x_826_);
v___x_828_ = lean_nat_dec_eq(v_upperVariations_821_, v___x_827_);
lean_dec(v___x_827_);
if (v___x_828_ == 0)
{
lean_dec(v_upperVariations_821_);
lean_dec(v_lowerVariations_820_);
return v___x_828_;
}
else
{
lean_object* v___x_829_; lean_object* v___x_830_; lean_object* v___x_831_; uint8_t v___x_832_; 
v___x_829_ = lean_nat_to_int(v_lowerVariations_820_);
v___x_830_ = lean_nat_to_int(v_upperVariations_821_);
v___x_831_ = lean_int_sub(v___x_829_, v___x_830_);
lean_dec(v___x_830_);
lean_dec(v___x_829_);
v___x_832_ = lean_int_dec_eq(v_value_815_, v___x_831_);
lean_dec(v___x_831_);
return v___x_832_;
}
}
}
v___jp_833_:
{
lean_object* v___x_835_; lean_object* v___x_836_; lean_object* v___x_837_; uint8_t v___x_838_; 
v___x_835_ = lean_unsigned_to_nat(0u);
v___x_836_ = lean_array_get_size(v_upperSigns_819_);
v___x_837_ = ((lean_object*)(lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__9));
v___x_838_ = lean_nat_dec_lt(v___x_835_, v___x_836_);
if (v___x_838_ == 0)
{
goto v___jp_822_;
}
else
{
if (v___x_838_ == 0)
{
goto v___jp_822_;
}
else
{
lean_object* v___x_839_; lean_object* v___f_840_; size_t v___x_841_; size_t v___x_842_; lean_object* v___x_843_; uint8_t v___x_844_; 
v___x_839_ = lean_box(v___y_834_);
v___f_840_ = lean_alloc_closure((void*)(lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_840_, 0, v___x_839_);
v___x_841_ = ((size_t)0ULL);
v___x_842_ = lean_usize_of_nat(v___x_836_);
lean_inc_ref(v_upperSigns_819_);
v___x_843_ = l___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any(lean_box(0), lean_box(0), v___x_837_, v___f_840_, v_upperSigns_819_, v___x_841_, v___x_842_);
v___x_844_ = lean_unbox(v___x_843_);
lean_dec(v___x_843_);
if (v___x_844_ == 0)
{
goto v___jp_822_;
}
else
{
uint8_t v___x_845_; 
lean_dec(v_upperVariations_821_);
lean_dec(v_lowerVariations_820_);
lean_dec_ref(v_upperSigns_819_);
lean_dec_ref(v_lowerSigns_818_);
v___x_845_ = 0;
return v___x_845_;
}
}
}
}
v___jp_846_:
{
if (v___y_847_ == 0)
{
lean_dec(v_upperVariations_821_);
lean_dec(v_lowerVariations_820_);
lean_dec_ref(v_upperSigns_819_);
lean_dec_ref(v_lowerSigns_818_);
lean_dec_ref(v_remainders_817_);
lean_dec(v_b_814_);
lean_dec_ref(v_endpointSigns_810_);
lean_dec_ref(v_sign_809_);
lean_dec(v_inst_803_);
return v___y_847_;
}
else
{
lean_object* v_chain_848_; lean_object* v___x_849_; lean_object* v___x_850_; uint8_t v___x_851_; 
v_chain_848_ = lean_ctor_get(v_remainders_817_, 0);
lean_inc_ref(v_chain_848_);
lean_dec_ref(v_remainders_817_);
v___x_849_ = lean_alloc_closure((void*)(l_Int_instDecidableEq___boxed), 2, 0);
v___x_850_ = lp_Hex_Hex_TarskiCertificate_signs___redArg(v_inst_803_, v_sign_809_, v_endpointSigns_810_, v_chain_848_, v_b_814_);
v___x_851_ = l_Array_instDecidableEqImpl___redArg(v___x_849_, v_upperSigns_819_, v___x_850_);
lean_dec_ref(v___x_850_);
if (v___x_851_ == 0)
{
lean_dec(v_upperVariations_821_);
lean_dec(v_lowerVariations_820_);
lean_dec_ref(v_upperSigns_819_);
lean_dec_ref(v_lowerSigns_818_);
return v___x_851_;
}
else
{
lean_object* v___x_852_; lean_object* v___x_853_; lean_object* v___x_854_; uint8_t v___x_855_; 
v___x_852_ = lean_unsigned_to_nat(0u);
v___x_853_ = lean_array_get_size(v_lowerSigns_818_);
v___x_854_ = ((lean_object*)(lp_Hex_Hex_TarskiCertificate_signs___redArg___closed__9));
v___x_855_ = lean_nat_dec_lt(v___x_852_, v___x_853_);
if (v___x_855_ == 0)
{
v___y_834_ = v___x_851_;
goto v___jp_833_;
}
else
{
if (v___x_855_ == 0)
{
v___y_834_ = v___x_851_;
goto v___jp_833_;
}
else
{
lean_object* v___x_856_; lean_object* v___f_857_; size_t v___x_858_; size_t v___x_859_; lean_object* v___x_860_; uint8_t v___x_861_; 
v___x_856_ = lean_box(v___x_851_);
v___f_857_ = lean_alloc_closure((void*)(lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_857_, 0, v___x_856_);
v___x_858_ = ((size_t)0ULL);
v___x_859_ = lean_usize_of_nat(v___x_853_);
lean_inc_ref(v_lowerSigns_818_);
v___x_860_ = l___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any(lean_box(0), lean_box(0), v___x_854_, v___f_857_, v_lowerSigns_818_, v___x_858_, v___x_859_);
v___x_861_ = lean_unbox(v___x_860_);
lean_dec(v___x_860_);
if (v___x_861_ == 0)
{
if (v___x_855_ == 0)
{
lean_dec(v_upperVariations_821_);
lean_dec(v_lowerVariations_820_);
lean_dec_ref(v_upperSigns_819_);
lean_dec_ref(v_lowerSigns_818_);
return v___x_855_;
}
else
{
v___y_834_ = v___x_855_;
goto v___jp_833_;
}
}
else
{
uint8_t v___x_862_; 
lean_dec(v_upperVariations_821_);
lean_dec(v_lowerVariations_820_);
lean_dec_ref(v_upperSigns_819_);
lean_dec_ref(v_lowerSigns_818_);
v___x_862_ = 0;
return v___x_862_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___redArg___boxed(lean_object* v_inst_868_, lean_object* v_inst_869_, lean_object* v_inst_870_, lean_object* v_inst_871_, lean_object* v_inst_872_, lean_object* v_inst_873_, lean_object* v_sign_874_, lean_object* v_endpointSigns_875_, lean_object* v_p_876_, lean_object* v_f_877_, lean_object* v_a_878_, lean_object* v_b_879_, lean_object* v_value_880_, lean_object* v_cert_881_){
_start:
{
uint8_t v_res_882_; lean_object* v_r_883_; 
v_res_882_ = lp_Hex_Hex_TarskiCertificate_checkQuery___redArg(v_inst_868_, v_inst_869_, v_inst_870_, v_inst_871_, v_inst_872_, v_inst_873_, v_sign_874_, v_endpointSigns_875_, v_p_876_, v_f_877_, v_a_878_, v_b_879_, v_value_880_, v_cert_881_);
lean_dec(v_value_880_);
v_r_883_ = lean_box(v_res_882_);
return v_r_883_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery(lean_object* v_D_884_, lean_object* v_E_885_, lean_object* v_Ctx_886_, lean_object* v_inst_887_, lean_object* v_inst_888_, lean_object* v_inst_889_, lean_object* v_inst_890_, lean_object* v_inst_891_, lean_object* v_inst_892_, lean_object* v_sign_893_, lean_object* v_endpointSigns_894_, lean_object* v_p_895_, lean_object* v_f_896_, lean_object* v_a_897_, lean_object* v_b_898_, lean_object* v_value_899_, lean_object* v_cert_900_){
_start:
{
uint8_t v___x_901_; 
v___x_901_ = lp_Hex_Hex_TarskiCertificate_checkQuery___redArg(v_inst_887_, v_inst_888_, v_inst_889_, v_inst_890_, v_inst_891_, v_inst_892_, v_sign_893_, v_endpointSigns_894_, v_p_895_, v_f_896_, v_a_897_, v_b_898_, v_value_899_, v_cert_900_);
return v___x_901_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___boxed(lean_object** _args){
lean_object* v_D_902_ = _args[0];
lean_object* v_E_903_ = _args[1];
lean_object* v_Ctx_904_ = _args[2];
lean_object* v_inst_905_ = _args[3];
lean_object* v_inst_906_ = _args[4];
lean_object* v_inst_907_ = _args[5];
lean_object* v_inst_908_ = _args[6];
lean_object* v_inst_909_ = _args[7];
lean_object* v_inst_910_ = _args[8];
lean_object* v_sign_911_ = _args[9];
lean_object* v_endpointSigns_912_ = _args[10];
lean_object* v_p_913_ = _args[11];
lean_object* v_f_914_ = _args[12];
lean_object* v_a_915_ = _args[13];
lean_object* v_b_916_ = _args[14];
lean_object* v_value_917_ = _args[15];
lean_object* v_cert_918_ = _args[16];
_start:
{
uint8_t v_res_919_; lean_object* v_r_920_; 
v_res_919_ = lp_Hex_Hex_TarskiCertificate_checkQuery(v_D_902_, v_E_903_, v_Ctx_904_, v_inst_905_, v_inst_906_, v_inst_907_, v_inst_908_, v_inst_909_, v_inst_910_, v_sign_911_, v_endpointSigns_912_, v_p_913_, v_f_914_, v_a_915_, v_b_916_, v_value_917_, v_cert_918_);
lean_dec(v_value_917_);
v_r_920_ = lean_box(v_res_919_);
return v_r_920_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_check___redArg(lean_object* v_inst_921_, lean_object* v_inst_922_, lean_object* v_inst_923_, lean_object* v_inst_924_, lean_object* v_inst_925_, lean_object* v_inst_926_, lean_object* v_inst_927_, lean_object* v_inst_928_, lean_object* v_inst_929_, lean_object* v_sign_930_, lean_object* v_endpointSigns_931_, lean_object* v_context_932_, lean_object* v_p_933_, lean_object* v_f_934_, lean_object* v_a_935_, lean_object* v_b_936_, lean_object* v_value_937_, lean_object* v_cert_938_){
_start:
{
uint8_t v___y_940_; uint8_t v___x_942_; 
lean_inc_ref(v_cert_938_);
lean_inc(v_b_936_);
lean_inc(v_a_935_);
lean_inc_ref(v_inst_922_);
v___x_942_ = lp_Hex_Hex_TarskiCertificate_checkBindings___redArg(v_inst_922_, v_inst_928_, v_inst_929_, v_context_932_, v_p_933_, v_f_934_, v_a_935_, v_b_936_, v_value_937_, v_cert_938_);
if (v___x_942_ == 0)
{
lean_dec(v_inst_923_);
v___y_940_ = v___x_942_;
goto v___jp_939_;
}
else
{
lean_object* v_squarefree_943_; uint8_t v___x_944_; 
v_squarefree_943_ = lean_ctor_get(v_cert_938_, 5);
lean_inc_ref(v_squarefree_943_);
lean_inc(v_b_936_);
lean_inc(v_a_935_);
lean_inc_ref(v_p_933_);
lean_inc_ref(v_endpointSigns_931_);
lean_inc_ref(v_sign_930_);
lean_inc(v_inst_927_);
lean_inc(v_inst_926_);
lean_inc(v_inst_925_);
lean_inc(v_inst_924_);
lean_inc_ref(v_inst_922_);
lean_inc(v_inst_921_);
v___x_944_ = lp_Hex_Hex_TarskiCertificate_checkDomain___redArg(v_inst_921_, v_inst_922_, v_inst_923_, v_inst_924_, v_inst_925_, v_inst_926_, v_inst_927_, v_sign_930_, v_endpointSigns_931_, v_p_933_, v_a_935_, v_b_936_, v_squarefree_943_);
v___y_940_ = v___x_944_;
goto v___jp_939_;
}
v___jp_939_:
{
if (v___y_940_ == 0)
{
lean_dec_ref(v_cert_938_);
lean_dec(v_b_936_);
lean_dec(v_a_935_);
lean_dec_ref(v_f_934_);
lean_dec_ref(v_p_933_);
lean_dec_ref(v_endpointSigns_931_);
lean_dec_ref(v_sign_930_);
lean_dec(v_inst_927_);
lean_dec(v_inst_926_);
lean_dec(v_inst_925_);
lean_dec(v_inst_924_);
lean_dec_ref(v_inst_922_);
lean_dec(v_inst_921_);
return v___y_940_;
}
else
{
uint8_t v___x_941_; 
v___x_941_ = lp_Hex_Hex_TarskiCertificate_checkQuery___redArg(v_inst_921_, v_inst_922_, v_inst_924_, v_inst_925_, v_inst_926_, v_inst_927_, v_sign_930_, v_endpointSigns_931_, v_p_933_, v_f_934_, v_a_935_, v_b_936_, v_value_937_, v_cert_938_);
return v___x_941_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_check___redArg___boxed(lean_object** _args){
lean_object* v_inst_945_ = _args[0];
lean_object* v_inst_946_ = _args[1];
lean_object* v_inst_947_ = _args[2];
lean_object* v_inst_948_ = _args[3];
lean_object* v_inst_949_ = _args[4];
lean_object* v_inst_950_ = _args[5];
lean_object* v_inst_951_ = _args[6];
lean_object* v_inst_952_ = _args[7];
lean_object* v_inst_953_ = _args[8];
lean_object* v_sign_954_ = _args[9];
lean_object* v_endpointSigns_955_ = _args[10];
lean_object* v_context_956_ = _args[11];
lean_object* v_p_957_ = _args[12];
lean_object* v_f_958_ = _args[13];
lean_object* v_a_959_ = _args[14];
lean_object* v_b_960_ = _args[15];
lean_object* v_value_961_ = _args[16];
lean_object* v_cert_962_ = _args[17];
_start:
{
uint8_t v_res_963_; lean_object* v_r_964_; 
v_res_963_ = lp_Hex_Hex_TarskiCertificate_check___redArg(v_inst_945_, v_inst_946_, v_inst_947_, v_inst_948_, v_inst_949_, v_inst_950_, v_inst_951_, v_inst_952_, v_inst_953_, v_sign_954_, v_endpointSigns_955_, v_context_956_, v_p_957_, v_f_958_, v_a_959_, v_b_960_, v_value_961_, v_cert_962_);
lean_dec(v_value_961_);
v_r_964_ = lean_box(v_res_963_);
return v_r_964_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_check(lean_object* v_D_965_, lean_object* v_E_966_, lean_object* v_Ctx_967_, lean_object* v_inst_968_, lean_object* v_inst_969_, lean_object* v_inst_970_, lean_object* v_inst_971_, lean_object* v_inst_972_, lean_object* v_inst_973_, lean_object* v_inst_974_, lean_object* v_inst_975_, lean_object* v_inst_976_, lean_object* v_sign_977_, lean_object* v_endpointSigns_978_, lean_object* v_context_979_, lean_object* v_p_980_, lean_object* v_f_981_, lean_object* v_a_982_, lean_object* v_b_983_, lean_object* v_value_984_, lean_object* v_cert_985_){
_start:
{
uint8_t v___x_986_; 
v___x_986_ = lp_Hex_Hex_TarskiCertificate_check___redArg(v_inst_968_, v_inst_969_, v_inst_970_, v_inst_971_, v_inst_972_, v_inst_973_, v_inst_974_, v_inst_975_, v_inst_976_, v_sign_977_, v_endpointSigns_978_, v_context_979_, v_p_980_, v_f_981_, v_a_982_, v_b_983_, v_value_984_, v_cert_985_);
return v___x_986_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_check___boxed(lean_object** _args){
lean_object* v_D_987_ = _args[0];
lean_object* v_E_988_ = _args[1];
lean_object* v_Ctx_989_ = _args[2];
lean_object* v_inst_990_ = _args[3];
lean_object* v_inst_991_ = _args[4];
lean_object* v_inst_992_ = _args[5];
lean_object* v_inst_993_ = _args[6];
lean_object* v_inst_994_ = _args[7];
lean_object* v_inst_995_ = _args[8];
lean_object* v_inst_996_ = _args[9];
lean_object* v_inst_997_ = _args[10];
lean_object* v_inst_998_ = _args[11];
lean_object* v_sign_999_ = _args[12];
lean_object* v_endpointSigns_1000_ = _args[13];
lean_object* v_context_1001_ = _args[14];
lean_object* v_p_1002_ = _args[15];
lean_object* v_f_1003_ = _args[16];
lean_object* v_a_1004_ = _args[17];
lean_object* v_b_1005_ = _args[18];
lean_object* v_value_1006_ = _args[19];
lean_object* v_cert_1007_ = _args[20];
_start:
{
uint8_t v_res_1008_; lean_object* v_r_1009_; 
v_res_1008_ = lp_Hex_Hex_TarskiCertificate_check(v_D_987_, v_E_988_, v_Ctx_989_, v_inst_990_, v_inst_991_, v_inst_992_, v_inst_993_, v_inst_994_, v_inst_995_, v_inst_996_, v_inst_997_, v_inst_998_, v_sign_999_, v_endpointSigns_1000_, v_context_1001_, v_p_1002_, v_f_1003_, v_a_1004_, v_b_1005_, v_value_1006_, v_cert_1007_);
lean_dec(v_value_1006_);
v_r_1009_ = lean_box(v_res_1008_);
return v_r_1009_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_intDyadic___lam__0(lean_object* v_a_1010_, lean_object* v_b_1011_){
_start:
{
lean_object* v___x_1012_; lean_object* v___x_1013_; 
v___x_1012_ = l_Dyadic_sub(v_a_1010_, v_b_1011_);
v___x_1013_ = lp_Hex_Hex_dyadicSign(v___x_1012_);
lean_dec(v___x_1012_);
return v___x_1013_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_intDyadic___lam__1(lean_object* v_p_1014_, lean_object* v_a_1015_){
_start:
{
lean_object* v___x_1016_; lean_object* v___x_1017_; 
v___x_1016_ = lp_Hex_Hex_ZPoly_evalDyadic(v_p_1014_, v_a_1015_);
v___x_1017_ = lp_Hex_Hex_dyadicSign(v___x_1016_);
lean_dec(v___x_1016_);
return v___x_1017_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_EndpointSigns_intDyadic___lam__1___boxed(lean_object* v_p_1018_, lean_object* v_a_1019_){
_start:
{
lean_object* v_res_1020_; 
v_res_1020_ = lp_Hex_Hex_EndpointSigns_intDyadic___lam__1(v_p_1018_, v_a_1019_);
lean_dec(v_a_1019_);
lean_dec_ref(v_p_1018_);
return v_res_1020_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_normalizeContent(lean_object* v_p_1027_){
_start:
{
lean_object* v___x_1028_; lean_object* v___x_1029_; lean_object* v___x_1030_; 
v___x_1028_ = lp_Hex_Hex_DensePoly_content(v_p_1027_);
v___x_1029_ = lp_Hex_Hex_DensePoly_primitivePartImpl(v_p_1027_);
v___x_1030_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1030_, 0, v___x_1028_);
lean_ctor_set(v___x_1030_, 1, v___x_1029_);
return v___x_1030_;
}
}
static lean_object* _init_lp_Hex_Hex_DensePoly_trimTrailingZerosGo___at___00Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7_spec__13___closed__0(void){
_start:
{
lean_object* v___x_1031_; lean_object* v___x_1032_; 
v___x_1031_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1032_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1032_, 0, v___x_1031_);
return v___x_1032_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_trimTrailingZerosGo___at___00Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7_spec__13(lean_object* v_coeffs_1033_, lean_object* v_x_1034_){
_start:
{
lean_object* v_zero_1035_; uint8_t v_isZero_1036_; 
v_zero_1035_ = lean_unsigned_to_nat(0u);
v_isZero_1036_ = lean_nat_dec_eq(v_x_1034_, v_zero_1035_);
if (v_isZero_1036_ == 1)
{
lean_dec(v_x_1034_);
return v_coeffs_1033_;
}
else
{
lean_object* v___x_1037_; lean_object* v_one_1038_; lean_object* v_n_1039_; lean_object* v___y_1041_; lean_object* v___x_1046_; lean_object* v___x_1047_; uint8_t v___x_1048_; 
v___x_1037_ = lean_alloc_closure((void*)(l_Int_instDecidableEq___boxed), 2, 0);
v_one_1038_ = lean_unsigned_to_nat(1u);
v_n_1039_ = lean_nat_sub(v_x_1034_, v_one_1038_);
lean_dec(v_x_1034_);
v___x_1046_ = lean_array_get_size(v_coeffs_1033_);
v___x_1047_ = lean_nat_sub(v___x_1046_, v_one_1038_);
v___x_1048_ = lean_nat_dec_lt(v___x_1047_, v___x_1046_);
if (v___x_1048_ == 0)
{
lean_object* v___x_1049_; 
lean_dec(v___x_1047_);
v___x_1049_ = lean_box(0);
v___y_1041_ = v___x_1049_;
goto v___jp_1040_;
}
else
{
lean_object* v___x_1050_; lean_object* v___x_1051_; 
v___x_1050_ = lean_array_fget_borrowed(v_coeffs_1033_, v___x_1047_);
lean_dec(v___x_1047_);
lean_inc(v___x_1050_);
v___x_1051_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1051_, 0, v___x_1050_);
v___y_1041_ = v___x_1051_;
goto v___jp_1040_;
}
v___jp_1040_:
{
lean_object* v___x_1042_; uint8_t v___x_1043_; 
v___x_1042_ = lean_obj_once(&lp_Hex_Hex_DensePoly_trimTrailingZerosGo___at___00Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7_spec__13___closed__0, &lp_Hex_Hex_DensePoly_trimTrailingZerosGo___at___00Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7_spec__13___closed__0_once, _init_lp_Hex_Hex_DensePoly_trimTrailingZerosGo___at___00Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7_spec__13___closed__0);
v___x_1043_ = l_Option_instDecidableEq___redArg(v___x_1037_, v___y_1041_, v___x_1042_);
if (v___x_1043_ == 0)
{
lean_dec(v_n_1039_);
return v_coeffs_1033_;
}
else
{
lean_object* v___x_1044_; 
v___x_1044_ = lean_array_pop(v_coeffs_1033_);
v_coeffs_1033_ = v___x_1044_;
v_x_1034_ = v_n_1039_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(lean_object* v_coeffs_1052_){
_start:
{
lean_object* v___x_1053_; lean_object* v___x_1054_; 
v___x_1053_ = lean_array_get_size(v_coeffs_1052_);
v___x_1054_ = lp_Hex_Hex_DensePoly_trimTrailingZerosGo___at___00Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7_spec__13(v_coeffs_1052_, v___x_1053_);
return v___x_1054_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6(lean_object* v_coeffs_1055_){
_start:
{
lean_object* v___x_1056_; 
v___x_1056_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v_coeffs_1055_);
return v___x_1056_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2(lean_object* v_c_1057_){
_start:
{
lean_object* v___x_1058_; lean_object* v___x_1059_; lean_object* v___x_1060_; lean_object* v___x_1061_; 
v___x_1058_ = lean_unsigned_to_nat(1u);
v___x_1059_ = lean_mk_empty_array_with_capacity(v___x_1058_);
v___x_1060_ = lean_array_push(v___x_1059_, v_c_1057_);
v___x_1061_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v___x_1060_);
return v___x_1061_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(lean_object* v_p_1062_){
_start:
{
lean_object* v___x_1063_; lean_object* v___x_1064_; uint8_t v___x_1065_; 
v___x_1063_ = lean_array_get_size(v_p_1062_);
v___x_1064_ = lean_unsigned_to_nat(0u);
v___x_1065_ = lean_nat_dec_eq(v___x_1063_, v___x_1064_);
return v___x_1065_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2___boxed(lean_object* v_p_1066_){
_start:
{
uint8_t v_res_1067_; lean_object* v_r_1068_; 
v_res_1067_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_p_1066_);
lean_dec_ref(v_p_1066_);
v_r_1068_ = lean_box(v_res_1067_);
return v_r_1068_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___redArg(lean_object* v_endpointSigns_1069_, lean_object* v_p_1070_, lean_object* v_x_1071_){
_start:
{
if (lean_obj_tag(v_x_1071_) == 1)
{
lean_object* v_value_1072_; lean_object* v_evalSign_1073_; lean_object* v___x_1074_; lean_object* v___x_1075_; uint8_t v___x_1076_; 
v_value_1072_ = lean_ctor_get(v_x_1071_, 0);
lean_inc(v_value_1072_);
lean_dec_ref_known(v_x_1071_, 1);
v_evalSign_1073_ = lean_ctor_get(v_endpointSigns_1069_, 1);
lean_inc_ref(v_evalSign_1073_);
lean_dec_ref(v_endpointSigns_1069_);
v___x_1074_ = lean_apply_2(v_evalSign_1073_, v_p_1070_, v_value_1072_);
v___x_1075_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1076_ = lean_int_dec_eq(v___x_1074_, v___x_1075_);
lean_dec(v___x_1074_);
if (v___x_1076_ == 0)
{
uint8_t v___x_1077_; 
v___x_1077_ = 1;
return v___x_1077_;
}
else
{
uint8_t v___x_1078_; 
v___x_1078_ = 0;
return v___x_1078_;
}
}
else
{
uint8_t v___x_1079_; 
lean_dec(v_x_1071_);
lean_dec_ref(v_p_1070_);
lean_dec_ref(v_endpointSigns_1069_);
v___x_1079_ = 1;
return v___x_1079_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___redArg___boxed(lean_object* v_endpointSigns_1080_, lean_object* v_p_1081_, lean_object* v_x_1082_){
_start:
{
uint8_t v_res_1083_; lean_object* v_r_1084_; 
v_res_1083_ = lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___redArg(v_endpointSigns_1080_, v_p_1081_, v_x_1082_);
v_r_1084_ = lean_box(v_res_1083_);
return v_r_1084_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3___redArg(lean_object* v_endpointSigns_1085_, lean_object* v_x_1086_, lean_object* v_x_1087_){
_start:
{
switch(lean_obj_tag(v_x_1086_))
{
case 0:
{
lean_dec_ref(v_endpointSigns_1085_);
switch(lean_obj_tag(v_x_1087_))
{
case 1:
{
uint8_t v___x_1088_; 
lean_dec_ref_known(v_x_1087_, 1);
v___x_1088_ = 1;
return v___x_1088_;
}
case 2:
{
uint8_t v___x_1089_; 
v___x_1089_ = 1;
return v___x_1089_;
}
default: 
{
uint8_t v___x_1090_; 
lean_dec(v_x_1087_);
v___x_1090_ = 0;
return v___x_1090_;
}
}
}
case 1:
{
switch(lean_obj_tag(v_x_1087_))
{
case 2:
{
uint8_t v___x_1091_; 
lean_dec_ref_known(v_x_1086_, 1);
lean_dec_ref(v_endpointSigns_1085_);
v___x_1091_ = 1;
return v___x_1091_;
}
case 1:
{
lean_object* v_value_1092_; lean_object* v_value_1093_; lean_object* v_compare_1094_; lean_object* v___x_1095_; lean_object* v___x_1096_; uint8_t v___x_1097_; 
v_value_1092_ = lean_ctor_get(v_x_1086_, 0);
lean_inc(v_value_1092_);
lean_dec_ref_known(v_x_1086_, 1);
v_value_1093_ = lean_ctor_get(v_x_1087_, 0);
lean_inc(v_value_1093_);
lean_dec_ref_known(v_x_1087_, 1);
v_compare_1094_ = lean_ctor_get(v_endpointSigns_1085_, 0);
lean_inc_ref(v_compare_1094_);
lean_dec_ref(v_endpointSigns_1085_);
v___x_1095_ = lean_apply_2(v_compare_1094_, v_value_1092_, v_value_1093_);
v___x_1096_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1097_ = lean_int_dec_lt(v___x_1095_, v___x_1096_);
lean_dec(v___x_1095_);
return v___x_1097_;
}
default: 
{
uint8_t v___x_1098_; 
lean_dec_ref_known(v_x_1086_, 1);
lean_dec(v_x_1087_);
lean_dec_ref(v_endpointSigns_1085_);
v___x_1098_ = 0;
return v___x_1098_;
}
}
}
default: 
{
uint8_t v___x_1099_; 
lean_dec(v_x_1087_);
lean_dec(v_x_1086_);
lean_dec_ref(v_endpointSigns_1085_);
v___x_1099_ = 0;
return v___x_1099_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3___redArg___boxed(lean_object* v_endpointSigns_1100_, lean_object* v_x_1101_, lean_object* v_x_1102_){
_start:
{
uint8_t v_res_1103_; lean_object* v_r_1104_; 
v_res_1103_ = lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3___redArg(v_endpointSigns_1100_, v_x_1101_, v_x_1102_);
v_r_1104_ = lean_box(v_res_1103_);
return v_r_1104_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___redArg(lean_object* v_endpointSigns_1105_, lean_object* v_p_1106_, lean_object* v_a_1107_, lean_object* v_b_1108_){
_start:
{
uint8_t v___x_1109_; 
v___x_1109_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_p_1106_);
if (v___x_1109_ == 0)
{
uint8_t v___x_1110_; 
lean_inc(v_b_1108_);
lean_inc(v_a_1107_);
lean_inc_ref(v_endpointSigns_1105_);
v___x_1110_ = lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3___redArg(v_endpointSigns_1105_, v_a_1107_, v_b_1108_);
if (v___x_1110_ == 0)
{
lean_dec(v_b_1108_);
lean_dec(v_a_1107_);
lean_dec_ref(v_p_1106_);
lean_dec_ref(v_endpointSigns_1105_);
return v___x_1110_;
}
else
{
uint8_t v___x_1111_; 
lean_inc_ref(v_p_1106_);
lean_inc_ref(v_endpointSigns_1105_);
v___x_1111_ = lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___redArg(v_endpointSigns_1105_, v_p_1106_, v_a_1107_);
if (v___x_1111_ == 0)
{
lean_dec(v_b_1108_);
lean_dec_ref(v_p_1106_);
lean_dec_ref(v_endpointSigns_1105_);
return v___x_1111_;
}
else
{
uint8_t v___x_1112_; 
v___x_1112_ = lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___redArg(v_endpointSigns_1105_, v_p_1106_, v_b_1108_);
return v___x_1112_;
}
}
}
else
{
uint8_t v___x_1113_; 
lean_dec(v_b_1108_);
lean_dec(v_a_1107_);
lean_dec_ref(v_p_1106_);
lean_dec_ref(v_endpointSigns_1105_);
v___x_1113_ = 0;
return v___x_1113_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___redArg___boxed(lean_object* v_endpointSigns_1114_, lean_object* v_p_1115_, lean_object* v_a_1116_, lean_object* v_b_1117_){
_start:
{
uint8_t v_res_1118_; lean_object* v_r_1119_; 
v_res_1118_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___redArg(v_endpointSigns_1114_, v_p_1115_, v_a_1116_, v_b_1117_);
v_r_1119_ = lean_box(v_res_1118_);
return v_r_1119_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_size___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__15(lean_object* v_p_1120_){
_start:
{
lean_object* v___x_1121_; 
v___x_1121_ = lean_array_get_size(v_p_1120_);
return v___x_1121_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_size___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__15___boxed(lean_object* v_p_1122_){
_start:
{
lean_object* v_res_1123_; 
v_res_1123_ = lp_Hex_Hex_DensePoly_size___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__15(v_p_1122_);
lean_dec_ref(v_p_1122_);
return v_res_1123_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoExponent___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__17(lean_object* v_p_1124_, lean_object* v_q_1125_){
_start:
{
uint8_t v___y_1127_; uint8_t v___x_1134_; 
v___x_1134_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_q_1125_);
if (v___x_1134_ == 0)
{
lean_object* v___x_1135_; lean_object* v___x_1136_; uint8_t v___x_1137_; 
v___x_1135_ = lean_array_get_size(v_p_1124_);
v___x_1136_ = lean_array_get_size(v_q_1125_);
v___x_1137_ = lean_nat_dec_lt(v___x_1135_, v___x_1136_);
v___y_1127_ = v___x_1137_;
goto v___jp_1126_;
}
else
{
v___y_1127_ = v___x_1134_;
goto v___jp_1126_;
}
v___jp_1126_:
{
if (v___y_1127_ == 0)
{
lean_object* v___x_1128_; lean_object* v___x_1129_; lean_object* v___x_1130_; lean_object* v___x_1131_; lean_object* v___x_1132_; 
v___x_1128_ = lean_array_get_size(v_p_1124_);
v___x_1129_ = lean_array_get_size(v_q_1125_);
v___x_1130_ = lean_nat_sub(v___x_1128_, v___x_1129_);
v___x_1131_ = lean_unsigned_to_nat(1u);
v___x_1132_ = lean_nat_add(v___x_1130_, v___x_1131_);
lean_dec(v___x_1130_);
return v___x_1132_;
}
else
{
lean_object* v___x_1133_; 
v___x_1133_ = lean_unsigned_to_nat(0u);
return v___x_1133_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoExponent___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__17___boxed(lean_object* v_p_1138_, lean_object* v_q_1139_){
_start:
{
lean_object* v_res_1140_; 
v_res_1140_ = lp_Hex_Hex_DensePoly_pseudoExponent___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__17(v_p_1138_, v_q_1139_);
lean_dec_ref(v_q_1139_);
lean_dec_ref(v_p_1138_);
return v_res_1140_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(lean_object* v_p_1141_, lean_object* v_n_1142_){
_start:
{
lean_object* v___x_1143_; uint8_t v___x_1144_; 
v___x_1143_ = lean_array_get_size(v_p_1141_);
v___x_1144_ = lean_nat_dec_lt(v_n_1142_, v___x_1143_);
if (v___x_1144_ == 0)
{
lean_object* v___x_1145_; 
v___x_1145_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
return v___x_1145_;
}
else
{
lean_object* v___x_1146_; 
v___x_1146_ = lean_array_fget_borrowed(v_p_1141_, v_n_1142_);
lean_inc(v___x_1146_);
return v___x_1146_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11___boxed(lean_object* v_p_1147_, lean_object* v_n_1148_){
_start:
{
lean_object* v_res_1149_; 
v_res_1149_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_p_1147_, v_n_1148_);
lean_dec(v_n_1148_);
lean_dec_ref(v_p_1147_);
return v_res_1149_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__30(lean_object* v_x2_1150_, lean_object* v_g_1151_, lean_object* v___y_1152_, lean_object* v_as_1153_, size_t v_i_1154_, size_t v_stop_1155_, lean_object* v_b_1156_){
_start:
{
uint8_t v___x_1157_; 
v___x_1157_ = lean_usize_dec_eq(v_i_1154_, v_stop_1155_);
if (v___x_1157_ == 0)
{
lean_object* v___x_1158_; lean_object* v___y_1160_; lean_object* v___x_1168_; uint8_t v___x_1169_; 
v___x_1158_ = lean_array_uget_borrowed(v_as_1153_, v_i_1154_);
v___x_1168_ = lean_array_get_size(v___y_1152_);
v___x_1169_ = lean_nat_dec_lt(v___x_1158_, v___x_1168_);
if (v___x_1169_ == 0)
{
lean_object* v___x_1170_; 
v___x_1170_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___y_1160_ = v___x_1170_;
goto v___jp_1159_;
}
else
{
lean_object* v___x_1171_; 
v___x_1171_ = lean_array_fget_borrowed(v___y_1152_, v___x_1158_);
v___y_1160_ = v___x_1171_;
goto v___jp_1159_;
}
v___jp_1159_:
{
lean_object* v___x_1161_; lean_object* v___x_1162_; lean_object* v___x_1163_; lean_object* v___x_1164_; size_t v___x_1165_; size_t v___x_1166_; 
v___x_1161_ = lean_nat_sub(v_x2_1150_, v___x_1158_);
v___x_1162_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_g_1151_, v___x_1161_);
lean_dec(v___x_1161_);
v___x_1163_ = lean_int_mul(v___y_1160_, v___x_1162_);
lean_dec(v___x_1162_);
v___x_1164_ = lean_int_add(v_b_1156_, v___x_1163_);
lean_dec(v___x_1163_);
lean_dec(v_b_1156_);
v___x_1165_ = ((size_t)1ULL);
v___x_1166_ = lean_usize_add(v_i_1154_, v___x_1165_);
v_i_1154_ = v___x_1166_;
v_b_1156_ = v___x_1164_;
goto _start;
}
}
else
{
return v_b_1156_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__30___boxed(lean_object* v_x2_1172_, lean_object* v_g_1173_, lean_object* v___y_1174_, lean_object* v_as_1175_, lean_object* v_i_1176_, lean_object* v_stop_1177_, lean_object* v_b_1178_){
_start:
{
size_t v_i_boxed_1179_; size_t v_stop_boxed_1180_; lean_object* v_res_1181_; 
v_i_boxed_1179_ = lean_unbox_usize(v_i_1176_);
lean_dec(v_i_1176_);
v_stop_boxed_1180_ = lean_unbox_usize(v_stop_1177_);
lean_dec(v_stop_1177_);
v_res_1181_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__30(v_x2_1172_, v_g_1173_, v___y_1174_, v_as_1175_, v_i_boxed_1179_, v_stop_boxed_1180_, v_b_1178_);
lean_dec_ref(v_as_1175_);
lean_dec_ref(v___y_1174_);
lean_dec_ref(v_g_1173_);
lean_dec(v_x2_1172_);
return v_res_1181_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31_spec__36(lean_object* v_f_1182_, lean_object* v___y_1183_, lean_object* v_d_1184_, lean_object* v_g_1185_, lean_object* v___y_1186_, lean_object* v_as_1187_, size_t v_i_1188_, size_t v_stop_1189_, lean_object* v_b_1190_){
_start:
{
uint8_t v___x_1191_; 
v___x_1191_ = lean_usize_dec_eq(v_i_1188_, v_stop_1189_);
if (v___x_1191_ == 0)
{
lean_object* v___x_1192_; lean_object* v___x_1193_; lean_object* v___x_1194_; lean_object* v___y_1196_; lean_object* v___y_1197_; lean_object* v___x_1205_; lean_object* v___y_1207_; lean_object* v___y_1212_; lean_object* v___x_1219_; uint8_t v___x_1220_; 
v___x_1192_ = lean_unsigned_to_nat(0u);
v___x_1193_ = lean_unsigned_to_nat(1u);
v___x_1194_ = lean_array_uget_borrowed(v_as_1187_, v_i_1188_);
v___x_1205_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1219_ = lean_nat_add(v___x_1194_, v___x_1193_);
v___x_1220_ = lean_nat_dec_le(v___x_1219_, v_d_1184_);
if (v___x_1220_ == 0)
{
lean_dec(v___x_1219_);
lean_inc(v_d_1184_);
v___y_1212_ = v_d_1184_;
goto v___jp_1211_;
}
else
{
v___y_1212_ = v___x_1219_;
goto v___jp_1211_;
}
v___jp_1195_:
{
lean_object* v___x_1198_; lean_object* v___x_1199_; lean_object* v___x_1200_; lean_object* v___x_1201_; size_t v___x_1202_; size_t v___x_1203_; 
v___x_1198_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_f_1182_, v___x_1194_);
v___x_1199_ = lean_int_mul(v___y_1197_, v___x_1198_);
lean_dec(v___x_1198_);
lean_dec(v___y_1197_);
v___x_1200_ = lean_int_sub(v___x_1199_, v___y_1196_);
lean_dec(v___y_1196_);
lean_dec(v___x_1199_);
v___x_1201_ = lean_array_push(v_b_1190_, v___x_1200_);
v___x_1202_ = ((size_t)1ULL);
v___x_1203_ = lean_usize_add(v_i_1188_, v___x_1202_);
v_i_1188_ = v___x_1203_;
v_b_1190_ = v___x_1201_;
goto _start;
}
v___jp_1206_:
{
lean_object* v___x_1208_; uint8_t v___x_1209_; 
v___x_1208_ = lean_array_get_size(v___y_1183_);
v___x_1209_ = lean_nat_dec_lt(v_d_1184_, v___x_1208_);
if (v___x_1209_ == 0)
{
v___y_1196_ = v___y_1207_;
v___y_1197_ = v___x_1205_;
goto v___jp_1195_;
}
else
{
lean_object* v___x_1210_; 
v___x_1210_ = lean_array_fget_borrowed(v___y_1183_, v_d_1184_);
lean_inc(v___x_1210_);
v___y_1196_ = v___y_1207_;
v___y_1197_ = v___x_1210_;
goto v___jp_1195_;
}
}
v___jp_1211_:
{
lean_object* v___x_1213_; lean_object* v___x_1214_; uint8_t v___x_1215_; 
v___x_1213_ = l_Array_range(v___y_1212_);
v___x_1214_ = lean_array_get_size(v___x_1213_);
v___x_1215_ = lean_nat_dec_lt(v___x_1192_, v___x_1214_);
if (v___x_1215_ == 0)
{
lean_dec_ref(v___x_1213_);
v___y_1207_ = v___x_1205_;
goto v___jp_1206_;
}
else
{
size_t v___x_1216_; size_t v___x_1217_; lean_object* v___x_1218_; 
v___x_1216_ = ((size_t)0ULL);
v___x_1217_ = lean_usize_of_nat(v___x_1214_);
v___x_1218_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__30(v___x_1194_, v_g_1185_, v___y_1186_, v___x_1213_, v___x_1216_, v___x_1217_, v___x_1205_);
lean_dec_ref(v___x_1213_);
v___y_1207_ = v___x_1218_;
goto v___jp_1206_;
}
}
}
else
{
lean_dec(v_d_1184_);
return v_b_1190_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31_spec__36___boxed(lean_object* v_f_1221_, lean_object* v___y_1222_, lean_object* v_d_1223_, lean_object* v_g_1224_, lean_object* v___y_1225_, lean_object* v_as_1226_, lean_object* v_i_1227_, lean_object* v_stop_1228_, lean_object* v_b_1229_){
_start:
{
size_t v_i_boxed_1230_; size_t v_stop_boxed_1231_; lean_object* v_res_1232_; 
v_i_boxed_1230_ = lean_unbox_usize(v_i_1227_);
lean_dec(v_i_1227_);
v_stop_boxed_1231_ = lean_unbox_usize(v_stop_1228_);
lean_dec(v_stop_1228_);
v_res_1232_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31_spec__36(v_f_1221_, v___y_1222_, v_d_1223_, v_g_1224_, v___y_1225_, v_as_1226_, v_i_boxed_1230_, v_stop_boxed_1231_, v_b_1229_);
lean_dec_ref(v_as_1226_);
lean_dec_ref(v___y_1225_);
lean_dec_ref(v_g_1224_);
lean_dec_ref(v___y_1222_);
lean_dec_ref(v_f_1221_);
return v_res_1232_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31(lean_object* v_g_1233_, lean_object* v___y_1234_, lean_object* v_f_1235_, lean_object* v___y_1236_, lean_object* v_d_1237_, lean_object* v_as_1238_, size_t v_i_1239_, size_t v_stop_1240_, lean_object* v_b_1241_){
_start:
{
uint8_t v___x_1242_; 
v___x_1242_ = lean_usize_dec_eq(v_i_1239_, v_stop_1240_);
if (v___x_1242_ == 0)
{
lean_object* v___x_1243_; lean_object* v___x_1244_; lean_object* v___x_1245_; lean_object* v___y_1247_; lean_object* v___y_1248_; lean_object* v___x_1256_; lean_object* v___y_1258_; lean_object* v___y_1263_; lean_object* v___x_1270_; uint8_t v___x_1271_; 
v___x_1243_ = lean_unsigned_to_nat(0u);
v___x_1244_ = lean_unsigned_to_nat(1u);
v___x_1245_ = lean_array_uget_borrowed(v_as_1238_, v_i_1239_);
v___x_1256_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1270_ = lean_nat_add(v___x_1245_, v___x_1244_);
v___x_1271_ = lean_nat_dec_le(v___x_1270_, v_d_1237_);
if (v___x_1271_ == 0)
{
lean_dec(v___x_1270_);
lean_inc(v_d_1237_);
v___y_1263_ = v_d_1237_;
goto v___jp_1262_;
}
else
{
v___y_1263_ = v___x_1270_;
goto v___jp_1262_;
}
v___jp_1246_:
{
lean_object* v___x_1249_; lean_object* v___x_1250_; lean_object* v___x_1251_; lean_object* v___x_1252_; size_t v___x_1253_; size_t v___x_1254_; lean_object* v___x_1255_; 
v___x_1249_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_f_1235_, v___x_1245_);
v___x_1250_ = lean_int_mul(v___y_1248_, v___x_1249_);
lean_dec(v___x_1249_);
lean_dec(v___y_1248_);
v___x_1251_ = lean_int_sub(v___x_1250_, v___y_1247_);
lean_dec(v___y_1247_);
lean_dec(v___x_1250_);
v___x_1252_ = lean_array_push(v_b_1241_, v___x_1251_);
v___x_1253_ = ((size_t)1ULL);
v___x_1254_ = lean_usize_add(v_i_1239_, v___x_1253_);
v___x_1255_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31_spec__36(v_f_1235_, v___y_1236_, v_d_1237_, v_g_1233_, v___y_1234_, v_as_1238_, v___x_1254_, v_stop_1240_, v___x_1252_);
return v___x_1255_;
}
v___jp_1257_:
{
lean_object* v___x_1259_; uint8_t v___x_1260_; 
v___x_1259_ = lean_array_get_size(v___y_1236_);
v___x_1260_ = lean_nat_dec_lt(v_d_1237_, v___x_1259_);
if (v___x_1260_ == 0)
{
v___y_1247_ = v___y_1258_;
v___y_1248_ = v___x_1256_;
goto v___jp_1246_;
}
else
{
lean_object* v___x_1261_; 
v___x_1261_ = lean_array_fget_borrowed(v___y_1236_, v_d_1237_);
lean_inc(v___x_1261_);
v___y_1247_ = v___y_1258_;
v___y_1248_ = v___x_1261_;
goto v___jp_1246_;
}
}
v___jp_1262_:
{
lean_object* v___x_1264_; lean_object* v___x_1265_; uint8_t v___x_1266_; 
v___x_1264_ = l_Array_range(v___y_1263_);
v___x_1265_ = lean_array_get_size(v___x_1264_);
v___x_1266_ = lean_nat_dec_lt(v___x_1243_, v___x_1265_);
if (v___x_1266_ == 0)
{
lean_dec_ref(v___x_1264_);
v___y_1258_ = v___x_1256_;
goto v___jp_1257_;
}
else
{
size_t v___x_1267_; size_t v___x_1268_; lean_object* v___x_1269_; 
v___x_1267_ = ((size_t)0ULL);
v___x_1268_ = lean_usize_of_nat(v___x_1265_);
v___x_1269_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__30(v___x_1245_, v_g_1233_, v___y_1234_, v___x_1264_, v___x_1267_, v___x_1268_, v___x_1256_);
lean_dec_ref(v___x_1264_);
v___y_1258_ = v___x_1269_;
goto v___jp_1257_;
}
}
}
else
{
lean_dec(v_d_1237_);
return v_b_1241_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31___boxed(lean_object* v_g_1272_, lean_object* v___y_1273_, lean_object* v_f_1274_, lean_object* v___y_1275_, lean_object* v_d_1276_, lean_object* v_as_1277_, lean_object* v_i_1278_, lean_object* v_stop_1279_, lean_object* v_b_1280_){
_start:
{
size_t v_i_boxed_1281_; size_t v_stop_boxed_1282_; lean_object* v_res_1283_; 
v_i_boxed_1281_ = lean_unbox_usize(v_i_1278_);
lean_dec(v_i_1278_);
v_stop_boxed_1282_ = lean_unbox_usize(v_stop_1279_);
lean_dec(v_stop_1279_);
v_res_1283_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31(v_g_1272_, v___y_1273_, v_f_1274_, v___y_1275_, v_d_1276_, v_as_1277_, v_i_boxed_1281_, v_stop_boxed_1282_, v_b_1280_);
lean_dec_ref(v_as_1277_);
lean_dec_ref(v___y_1275_);
lean_dec_ref(v_f_1274_);
lean_dec_ref(v___y_1273_);
lean_dec_ref(v_g_1272_);
return v_res_1283_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__29(lean_object* v_first_1284_, lean_object* v_m_1285_, lean_object* v_x2_1286_, lean_object* v_g_1287_, lean_object* v___y_1288_, lean_object* v_x1_1289_, lean_object* v_as_1290_, size_t v_i_1291_, size_t v_stop_1292_, lean_object* v_b_1293_){
_start:
{
uint8_t v___x_1294_; 
v___x_1294_ = lean_usize_dec_eq(v_i_1291_, v_stop_1292_);
if (v___x_1294_ == 0)
{
lean_object* v___x_1295_; lean_object* v___x_1296_; lean_object* v_j_1297_; lean_object* v___y_1299_; lean_object* v___y_1300_; lean_object* v___x_1310_; lean_object* v___y_1312_; lean_object* v___x_1318_; uint8_t v___x_1319_; 
v___x_1295_ = lean_unsigned_to_nat(1u);
v___x_1296_ = lean_array_uget_borrowed(v_as_1290_, v_i_1291_);
v_j_1297_ = lean_nat_add(v_first_1284_, v___x_1296_);
v___x_1310_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1318_ = lean_array_get_size(v_x1_1289_);
v___x_1319_ = lean_nat_dec_lt(v_j_1297_, v___x_1318_);
if (v___x_1319_ == 0)
{
v___y_1312_ = v___x_1310_;
goto v___jp_1311_;
}
else
{
lean_object* v___x_1320_; 
v___x_1320_ = lean_array_fget_borrowed(v_x1_1289_, v_j_1297_);
v___y_1312_ = v___x_1320_;
goto v___jp_1311_;
}
v___jp_1298_:
{
lean_object* v___x_1301_; lean_object* v___x_1302_; lean_object* v___x_1303_; lean_object* v___x_1304_; lean_object* v___x_1305_; lean_object* v___x_1306_; size_t v___x_1307_; size_t v___x_1308_; 
v___x_1301_ = lean_int_mul(v___y_1299_, v___y_1300_);
v___x_1302_ = lean_nat_add(v_m_1285_, v_j_1297_);
lean_dec(v_j_1297_);
v___x_1303_ = lean_nat_sub(v___x_1302_, v_x2_1286_);
lean_dec(v___x_1302_);
v___x_1304_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_g_1287_, v___x_1303_);
lean_dec(v___x_1303_);
v___x_1305_ = lean_int_mul(v___x_1301_, v___x_1304_);
lean_dec(v___x_1304_);
lean_dec(v___x_1301_);
v___x_1306_ = lean_int_add(v_b_1293_, v___x_1305_);
lean_dec(v___x_1305_);
lean_dec(v_b_1293_);
v___x_1307_ = ((size_t)1ULL);
v___x_1308_ = lean_usize_add(v_i_1291_, v___x_1307_);
v_i_1291_ = v___x_1308_;
v_b_1293_ = v___x_1306_;
goto _start;
}
v___jp_1311_:
{
lean_object* v___x_1313_; lean_object* v___x_1314_; lean_object* v___x_1315_; uint8_t v___x_1316_; 
v___x_1313_ = lean_nat_sub(v_x2_1286_, v___x_1295_);
v___x_1314_ = lean_nat_sub(v___x_1313_, v_j_1297_);
lean_dec(v___x_1313_);
v___x_1315_ = lean_array_get_size(v___y_1288_);
v___x_1316_ = lean_nat_dec_lt(v___x_1314_, v___x_1315_);
if (v___x_1316_ == 0)
{
lean_dec(v___x_1314_);
v___y_1299_ = v___y_1312_;
v___y_1300_ = v___x_1310_;
goto v___jp_1298_;
}
else
{
lean_object* v___x_1317_; 
v___x_1317_ = lean_array_fget_borrowed(v___y_1288_, v___x_1314_);
lean_dec(v___x_1314_);
v___y_1299_ = v___y_1312_;
v___y_1300_ = v___x_1317_;
goto v___jp_1298_;
}
}
}
else
{
return v_b_1293_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__29___boxed(lean_object* v_first_1321_, lean_object* v_m_1322_, lean_object* v_x2_1323_, lean_object* v_g_1324_, lean_object* v___y_1325_, lean_object* v_x1_1326_, lean_object* v_as_1327_, lean_object* v_i_1328_, lean_object* v_stop_1329_, lean_object* v_b_1330_){
_start:
{
size_t v_i_boxed_1331_; size_t v_stop_boxed_1332_; lean_object* v_res_1333_; 
v_i_boxed_1331_ = lean_unbox_usize(v_i_1328_);
lean_dec(v_i_1328_);
v_stop_boxed_1332_ = lean_unbox_usize(v_stop_1329_);
lean_dec(v_stop_1329_);
v_res_1333_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__29(v_first_1321_, v_m_1322_, v_x2_1323_, v_g_1324_, v___y_1325_, v_x1_1326_, v_as_1327_, v_i_boxed_1331_, v_stop_boxed_1332_, v_b_1330_);
lean_dec_ref(v_as_1327_);
lean_dec_ref(v_x1_1326_);
lean_dec_ref(v___y_1325_);
lean_dec_ref(v_g_1324_);
lean_dec(v_x2_1323_);
lean_dec(v_m_1322_);
lean_dec(v_first_1321_);
return v_res_1333_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33_spec__39(lean_object* v_m_1334_, lean_object* v_n_1335_, lean_object* v_f_1336_, lean_object* v___y_1337_, lean_object* v_g_1338_, lean_object* v_as_1339_, size_t v_i_1340_, size_t v_stop_1341_, lean_object* v_b_1342_){
_start:
{
uint8_t v___x_1343_; 
v___x_1343_ = lean_usize_dec_eq(v_i_1340_, v_stop_1341_);
if (v___x_1343_ == 0)
{
lean_object* v___x_1344_; lean_object* v___x_1345_; lean_object* v___y_1347_; lean_object* v___y_1348_; lean_object* v_first_1357_; lean_object* v___x_1358_; lean_object* v___y_1360_; lean_object* v___x_1364_; lean_object* v___x_1365_; lean_object* v___x_1366_; uint8_t v___x_1367_; 
v___x_1344_ = lean_unsigned_to_nat(0u);
v___x_1345_ = lean_array_uget_borrowed(v_as_1339_, v_i_1340_);
v_first_1357_ = lean_nat_sub(v___x_1345_, v_m_1334_);
v___x_1358_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1364_ = lean_nat_sub(v___x_1345_, v_first_1357_);
v___x_1365_ = l_Array_range(v___x_1364_);
v___x_1366_ = lean_array_get_size(v___x_1365_);
v___x_1367_ = lean_nat_dec_lt(v___x_1344_, v___x_1366_);
if (v___x_1367_ == 0)
{
lean_dec_ref(v___x_1365_);
lean_dec(v_first_1357_);
v___y_1360_ = v___x_1358_;
goto v___jp_1359_;
}
else
{
size_t v___x_1368_; size_t v___x_1369_; lean_object* v___x_1370_; 
v___x_1368_ = ((size_t)0ULL);
v___x_1369_ = lean_usize_of_nat(v___x_1366_);
v___x_1370_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__29(v_first_1357_, v_m_1334_, v___x_1345_, v_g_1338_, v___y_1337_, v_b_1342_, v___x_1365_, v___x_1368_, v___x_1369_, v___x_1358_);
lean_dec_ref(v___x_1365_);
lean_dec(v_first_1357_);
v___y_1360_ = v___x_1370_;
goto v___jp_1359_;
}
v___jp_1346_:
{
lean_object* v___x_1349_; lean_object* v___x_1350_; lean_object* v___x_1351_; lean_object* v___x_1352_; lean_object* v___x_1353_; size_t v___x_1354_; size_t v___x_1355_; 
v___x_1349_ = lean_nat_sub(v_n_1335_, v___x_1345_);
v___x_1350_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_f_1336_, v___x_1349_);
lean_dec(v___x_1349_);
v___x_1351_ = lean_int_mul(v___y_1348_, v___x_1350_);
lean_dec(v___x_1350_);
lean_dec(v___y_1348_);
v___x_1352_ = lean_int_sub(v___x_1351_, v___y_1347_);
lean_dec(v___y_1347_);
lean_dec(v___x_1351_);
v___x_1353_ = lean_array_push(v_b_1342_, v___x_1352_);
v___x_1354_ = ((size_t)1ULL);
v___x_1355_ = lean_usize_add(v_i_1340_, v___x_1354_);
v_i_1340_ = v___x_1355_;
v_b_1342_ = v___x_1353_;
goto _start;
}
v___jp_1359_:
{
lean_object* v___x_1361_; uint8_t v___x_1362_; 
v___x_1361_ = lean_array_get_size(v___y_1337_);
v___x_1362_ = lean_nat_dec_lt(v___x_1345_, v___x_1361_);
if (v___x_1362_ == 0)
{
v___y_1347_ = v___y_1360_;
v___y_1348_ = v___x_1358_;
goto v___jp_1346_;
}
else
{
lean_object* v___x_1363_; 
v___x_1363_ = lean_array_fget_borrowed(v___y_1337_, v___x_1345_);
lean_inc(v___x_1363_);
v___y_1347_ = v___y_1360_;
v___y_1348_ = v___x_1363_;
goto v___jp_1346_;
}
}
}
else
{
return v_b_1342_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33_spec__39___boxed(lean_object* v_m_1371_, lean_object* v_n_1372_, lean_object* v_f_1373_, lean_object* v___y_1374_, lean_object* v_g_1375_, lean_object* v_as_1376_, lean_object* v_i_1377_, lean_object* v_stop_1378_, lean_object* v_b_1379_){
_start:
{
size_t v_i_boxed_1380_; size_t v_stop_boxed_1381_; lean_object* v_res_1382_; 
v_i_boxed_1380_ = lean_unbox_usize(v_i_1377_);
lean_dec(v_i_1377_);
v_stop_boxed_1381_ = lean_unbox_usize(v_stop_1378_);
lean_dec(v_stop_1378_);
v_res_1382_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33_spec__39(v_m_1371_, v_n_1372_, v_f_1373_, v___y_1374_, v_g_1375_, v_as_1376_, v_i_boxed_1380_, v_stop_boxed_1381_, v_b_1379_);
lean_dec_ref(v_as_1376_);
lean_dec_ref(v_g_1375_);
lean_dec_ref(v___y_1374_);
lean_dec_ref(v_f_1373_);
lean_dec(v_n_1372_);
lean_dec(v_m_1371_);
return v_res_1382_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33(lean_object* v_m_1383_, lean_object* v_g_1384_, lean_object* v___y_1385_, lean_object* v_n_1386_, lean_object* v_f_1387_, lean_object* v_as_1388_, size_t v_i_1389_, size_t v_stop_1390_, lean_object* v_b_1391_){
_start:
{
uint8_t v___x_1392_; 
v___x_1392_ = lean_usize_dec_eq(v_i_1389_, v_stop_1390_);
if (v___x_1392_ == 0)
{
lean_object* v___x_1393_; lean_object* v___x_1394_; lean_object* v___y_1396_; lean_object* v___y_1397_; lean_object* v_first_1406_; lean_object* v___x_1407_; lean_object* v___y_1409_; lean_object* v___x_1413_; lean_object* v___x_1414_; lean_object* v___x_1415_; uint8_t v___x_1416_; 
v___x_1393_ = lean_unsigned_to_nat(0u);
v___x_1394_ = lean_array_uget_borrowed(v_as_1388_, v_i_1389_);
v_first_1406_ = lean_nat_sub(v___x_1394_, v_m_1383_);
v___x_1407_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1413_ = lean_nat_sub(v___x_1394_, v_first_1406_);
v___x_1414_ = l_Array_range(v___x_1413_);
v___x_1415_ = lean_array_get_size(v___x_1414_);
v___x_1416_ = lean_nat_dec_lt(v___x_1393_, v___x_1415_);
if (v___x_1416_ == 0)
{
lean_dec_ref(v___x_1414_);
lean_dec(v_first_1406_);
v___y_1409_ = v___x_1407_;
goto v___jp_1408_;
}
else
{
size_t v___x_1417_; size_t v___x_1418_; lean_object* v___x_1419_; 
v___x_1417_ = ((size_t)0ULL);
v___x_1418_ = lean_usize_of_nat(v___x_1415_);
v___x_1419_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__29(v_first_1406_, v_m_1383_, v___x_1394_, v_g_1384_, v___y_1385_, v_b_1391_, v___x_1414_, v___x_1417_, v___x_1418_, v___x_1407_);
lean_dec_ref(v___x_1414_);
lean_dec(v_first_1406_);
v___y_1409_ = v___x_1419_;
goto v___jp_1408_;
}
v___jp_1395_:
{
lean_object* v___x_1398_; lean_object* v___x_1399_; lean_object* v___x_1400_; lean_object* v___x_1401_; lean_object* v___x_1402_; size_t v___x_1403_; size_t v___x_1404_; lean_object* v___x_1405_; 
v___x_1398_ = lean_nat_sub(v_n_1386_, v___x_1394_);
v___x_1399_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_f_1387_, v___x_1398_);
lean_dec(v___x_1398_);
v___x_1400_ = lean_int_mul(v___y_1397_, v___x_1399_);
lean_dec(v___x_1399_);
lean_dec(v___y_1397_);
v___x_1401_ = lean_int_sub(v___x_1400_, v___y_1396_);
lean_dec(v___y_1396_);
lean_dec(v___x_1400_);
v___x_1402_ = lean_array_push(v_b_1391_, v___x_1401_);
v___x_1403_ = ((size_t)1ULL);
v___x_1404_ = lean_usize_add(v_i_1389_, v___x_1403_);
v___x_1405_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33_spec__39(v_m_1383_, v_n_1386_, v_f_1387_, v___y_1385_, v_g_1384_, v_as_1388_, v___x_1404_, v_stop_1390_, v___x_1402_);
return v___x_1405_;
}
v___jp_1408_:
{
lean_object* v___x_1410_; uint8_t v___x_1411_; 
v___x_1410_ = lean_array_get_size(v___y_1385_);
v___x_1411_ = lean_nat_dec_lt(v___x_1394_, v___x_1410_);
if (v___x_1411_ == 0)
{
v___y_1396_ = v___y_1409_;
v___y_1397_ = v___x_1407_;
goto v___jp_1395_;
}
else
{
lean_object* v___x_1412_; 
v___x_1412_ = lean_array_fget_borrowed(v___y_1385_, v___x_1394_);
lean_inc(v___x_1412_);
v___y_1396_ = v___y_1409_;
v___y_1397_ = v___x_1412_;
goto v___jp_1395_;
}
}
}
else
{
return v_b_1391_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33___boxed(lean_object* v_m_1420_, lean_object* v_g_1421_, lean_object* v___y_1422_, lean_object* v_n_1423_, lean_object* v_f_1424_, lean_object* v_as_1425_, lean_object* v_i_1426_, lean_object* v_stop_1427_, lean_object* v_b_1428_){
_start:
{
size_t v_i_boxed_1429_; size_t v_stop_boxed_1430_; lean_object* v_res_1431_; 
v_i_boxed_1429_ = lean_unbox_usize(v_i_1426_);
lean_dec(v_i_1426_);
v_stop_boxed_1430_ = lean_unbox_usize(v_stop_1427_);
lean_dec(v_stop_1427_);
v_res_1431_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33(v_m_1420_, v_g_1421_, v___y_1422_, v_n_1423_, v_f_1424_, v_as_1425_, v_i_boxed_1429_, v_stop_boxed_1430_, v_b_1428_);
lean_dec_ref(v_as_1425_);
lean_dec_ref(v_f_1424_);
lean_dec(v_n_1423_);
lean_dec_ref(v___y_1422_);
lean_dec_ref(v_g_1421_);
lean_dec(v_m_1420_);
return v_res_1431_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34___redArg(lean_object* v_b_1432_, size_t v_i_1433_, size_t v_stop_1434_, lean_object* v_b_1435_){
_start:
{
lean_object* v___y_1437_; uint8_t v___x_1443_; 
v___x_1443_ = lean_usize_dec_eq(v_i_1433_, v_stop_1434_);
if (v___x_1443_ == 0)
{
lean_object* v___x_1444_; lean_object* v___x_1445_; lean_object* v___x_1446_; uint8_t v___x_1447_; 
v___x_1444_ = lean_unsigned_to_nat(1u);
v___x_1445_ = lean_array_get_size(v_b_1435_);
v___x_1446_ = lean_nat_sub(v___x_1445_, v___x_1444_);
v___x_1447_ = lean_nat_dec_lt(v___x_1446_, v___x_1445_);
if (v___x_1447_ == 0)
{
lean_object* v___x_1448_; 
lean_dec(v___x_1446_);
v___x_1448_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___y_1437_ = v___x_1448_;
goto v___jp_1436_;
}
else
{
lean_object* v___x_1449_; 
v___x_1449_ = lean_array_fget_borrowed(v_b_1435_, v___x_1446_);
lean_dec(v___x_1446_);
lean_inc(v___x_1449_);
v___y_1437_ = v___x_1449_;
goto v___jp_1436_;
}
}
else
{
return v_b_1435_;
}
v___jp_1436_:
{
lean_object* v___x_1438_; lean_object* v___x_1439_; size_t v___x_1440_; size_t v___x_1441_; 
v___x_1438_ = lean_int_mul(v___y_1437_, v_b_1432_);
lean_dec(v___y_1437_);
v___x_1439_ = lean_array_push(v_b_1435_, v___x_1438_);
v___x_1440_ = ((size_t)1ULL);
v___x_1441_ = lean_usize_add(v_i_1433_, v___x_1440_);
v_i_1433_ = v___x_1441_;
v_b_1435_ = v___x_1439_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34___redArg___boxed(lean_object* v_b_1450_, lean_object* v_i_1451_, lean_object* v_stop_1452_, lean_object* v_b_1453_){
_start:
{
size_t v_i_boxed_1454_; size_t v_stop_boxed_1455_; lean_object* v_res_1456_; 
v_i_boxed_1454_ = lean_unbox_usize(v_i_1451_);
lean_dec(v_i_1451_);
v_stop_boxed_1455_ = lean_unbox_usize(v_stop_1452_);
lean_dec(v_stop_1452_);
v_res_1456_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34___redArg(v_b_1450_, v_i_boxed_1454_, v_stop_boxed_1455_, v_b_1453_);
lean_dec(v_b_1450_);
return v_res_1456_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__32(lean_object* v_d_1457_, lean_object* v___y_1458_, lean_object* v___y_1459_, lean_object* v_as_1460_, size_t v_i_1461_, size_t v_stop_1462_, lean_object* v_b_1463_){
_start:
{
lean_object* v___y_1465_; lean_object* v___y_1466_; uint8_t v___x_1472_; 
v___x_1472_ = lean_usize_dec_eq(v_i_1461_, v_stop_1462_);
if (v___x_1472_ == 0)
{
lean_object* v___x_1473_; lean_object* v___x_1474_; lean_object* v___x_1475_; lean_object* v___x_1476_; lean_object* v___x_1477_; lean_object* v___y_1479_; lean_object* v___x_1483_; uint8_t v___x_1484_; 
v___x_1473_ = lean_unsigned_to_nat(1u);
v___x_1474_ = lean_array_uget_borrowed(v_as_1460_, v_i_1461_);
v___x_1475_ = lean_nat_sub(v_d_1457_, v___x_1473_);
v___x_1476_ = lean_nat_sub(v___x_1475_, v___x_1474_);
lean_dec(v___x_1475_);
v___x_1477_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1483_ = lean_array_get_size(v___y_1459_);
v___x_1484_ = lean_nat_dec_lt(v___x_1476_, v___x_1483_);
if (v___x_1484_ == 0)
{
lean_dec(v___x_1476_);
v___y_1479_ = v___x_1477_;
goto v___jp_1478_;
}
else
{
lean_object* v___x_1485_; 
v___x_1485_ = lean_array_fget_borrowed(v___y_1459_, v___x_1476_);
lean_dec(v___x_1476_);
v___y_1479_ = v___x_1485_;
goto v___jp_1478_;
}
v___jp_1478_:
{
lean_object* v___x_1480_; uint8_t v___x_1481_; 
v___x_1480_ = lean_array_get_size(v___y_1458_);
v___x_1481_ = lean_nat_dec_lt(v___x_1474_, v___x_1480_);
if (v___x_1481_ == 0)
{
v___y_1465_ = v___y_1479_;
v___y_1466_ = v___x_1477_;
goto v___jp_1464_;
}
else
{
lean_object* v___x_1482_; 
v___x_1482_ = lean_array_fget_borrowed(v___y_1458_, v___x_1474_);
v___y_1465_ = v___y_1479_;
v___y_1466_ = v___x_1482_;
goto v___jp_1464_;
}
}
}
else
{
return v_b_1463_;
}
v___jp_1464_:
{
lean_object* v___x_1467_; lean_object* v___x_1468_; size_t v___x_1469_; size_t v___x_1470_; 
v___x_1467_ = lean_int_mul(v___y_1465_, v___y_1466_);
v___x_1468_ = lean_array_push(v_b_1463_, v___x_1467_);
v___x_1469_ = ((size_t)1ULL);
v___x_1470_ = lean_usize_add(v_i_1461_, v___x_1469_);
v_i_1461_ = v___x_1470_;
v_b_1463_ = v___x_1468_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__32___boxed(lean_object* v_d_1486_, lean_object* v___y_1487_, lean_object* v___y_1488_, lean_object* v_as_1489_, lean_object* v_i_1490_, lean_object* v_stop_1491_, lean_object* v_b_1492_){
_start:
{
size_t v_i_boxed_1493_; size_t v_stop_boxed_1494_; lean_object* v_res_1495_; 
v_i_boxed_1493_ = lean_unbox_usize(v_i_1490_);
lean_dec(v_i_1490_);
v_stop_boxed_1494_ = lean_unbox_usize(v_stop_1491_);
lean_dec(v_stop_1491_);
v_res_1495_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__32(v_d_1486_, v___y_1487_, v___y_1488_, v_as_1489_, v_i_boxed_1493_, v_stop_boxed_1494_, v_b_1492_);
lean_dec_ref(v_as_1489_);
lean_dec_ref(v___y_1488_);
lean_dec_ref(v___y_1487_);
lean_dec(v_d_1486_);
return v_res_1495_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(lean_object* v_p_1496_){
_start:
{
lean_object* v___x_1497_; lean_object* v___x_1498_; lean_object* v___x_1499_; uint8_t v___x_1500_; 
v___x_1497_ = lean_array_get_size(v_p_1496_);
v___x_1498_ = lean_unsigned_to_nat(1u);
v___x_1499_ = lean_nat_sub(v___x_1497_, v___x_1498_);
v___x_1500_ = lean_nat_dec_lt(v___x_1499_, v___x_1497_);
if (v___x_1500_ == 0)
{
lean_object* v___x_1501_; 
lean_dec(v___x_1499_);
v___x_1501_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
return v___x_1501_;
}
else
{
lean_object* v___x_1502_; 
v___x_1502_ = lean_array_fget_borrowed(v_p_1496_, v___x_1499_);
lean_dec(v___x_1499_);
lean_inc(v___x_1502_);
return v___x_1502_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18___boxed(lean_object* v_p_1503_){
_start:
{
lean_object* v_res_1504_; 
v_res_1504_ = lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(v_p_1503_);
lean_dec_ref(v_p_1503_);
return v_res_1504_;
}
}
static lean_object* _init_lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__1(void){
_start:
{
lean_object* v___x_1507_; lean_object* v___x_1508_; 
v___x_1507_ = ((lean_object*)(lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__0));
v___x_1508_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v___x_1507_);
return v___x_1508_;
}
}
static lean_object* _init_lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16(void){
_start:
{
lean_object* v___x_1509_; 
v___x_1509_ = lean_obj_once(&lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__1, &lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__1_once, _init_lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__1);
return v___x_1509_;
}
}
static lean_object* _init_lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23___closed__0(void){
_start:
{
lean_object* v___x_1510_; lean_object* v___x_1511_; lean_object* v___x_1512_; lean_object* v___x_1513_; 
v___x_1510_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_1511_ = lean_unsigned_to_nat(1u);
v___x_1512_ = lean_mk_empty_array_with_capacity(v___x_1511_);
v___x_1513_ = lean_array_push(v___x_1512_, v___x_1510_);
return v___x_1513_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23(lean_object* v_f_1514_, lean_object* v_g_1515_){
_start:
{
lean_object* v___y_1517_; lean_object* v___y_1518_; uint8_t v___x_1522_; 
v___x_1522_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_g_1515_);
if (v___x_1522_ == 0)
{
lean_object* v___x_1523_; lean_object* v___x_1524_; uint8_t v___x_1525_; 
v___x_1523_ = lean_array_get_size(v_f_1514_);
v___x_1524_ = lean_array_get_size(v_g_1515_);
v___x_1525_ = lean_nat_dec_lt(v___x_1523_, v___x_1524_);
if (v___x_1525_ == 0)
{
lean_object* v___x_1526_; lean_object* v_n_1527_; lean_object* v_m_1528_; lean_object* v___x_1529_; lean_object* v_d_1530_; lean_object* v___x_1531_; lean_object* v___x_1532_; lean_object* v___x_1533_; lean_object* v___y_1535_; lean_object* v___y_1536_; lean_object* v___y_1537_; lean_object* v___x_1544_; lean_object* v___y_1546_; lean_object* v___y_1547_; lean_object* v___y_1548_; lean_object* v___y_1554_; uint8_t v___x_1560_; 
v___x_1526_ = lean_unsigned_to_nat(1u);
v_n_1527_ = lean_nat_sub(v___x_1523_, v___x_1526_);
v_m_1528_ = lean_nat_sub(v___x_1524_, v___x_1526_);
v___x_1529_ = lean_nat_sub(v___x_1523_, v___x_1524_);
v_d_1530_ = lean_nat_add(v___x_1529_, v___x_1526_);
lean_dec(v___x_1529_);
v___x_1531_ = lean_obj_once(&lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23___closed__0, &lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23___closed__0_once, _init_lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23___closed__0);
lean_inc(v_d_1530_);
v___x_1532_ = l_Array_range(v_d_1530_);
v___x_1533_ = lean_unsigned_to_nat(0u);
v___x_1544_ = lean_array_get_size(v___x_1532_);
v___x_1560_ = lean_nat_dec_lt(v___x_1533_, v___x_1544_);
if (v___x_1560_ == 0)
{
v___y_1554_ = v___x_1531_;
goto v___jp_1553_;
}
else
{
lean_object* v_b_1561_; size_t v___x_1562_; size_t v___x_1563_; lean_object* v___x_1564_; 
v_b_1561_ = lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(v_g_1515_);
v___x_1562_ = ((size_t)0ULL);
v___x_1563_ = lean_usize_of_nat(v___x_1544_);
v___x_1564_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34___redArg(v_b_1561_, v___x_1562_, v___x_1563_, v___x_1531_);
lean_dec(v_b_1561_);
v___y_1554_ = v___x_1564_;
goto v___jp_1553_;
}
v___jp_1534_:
{
lean_object* v___x_1538_; lean_object* v___x_1539_; uint8_t v___x_1540_; 
v___x_1538_ = l_Array_range(v_m_1528_);
v___x_1539_ = lean_array_get_size(v___x_1538_);
v___x_1540_ = lean_nat_dec_lt(v___x_1533_, v___x_1539_);
if (v___x_1540_ == 0)
{
lean_dec_ref(v___x_1538_);
lean_dec_ref(v___y_1536_);
lean_dec(v_d_1530_);
lean_dec_ref(v_f_1514_);
v___y_1517_ = v___y_1537_;
v___y_1518_ = v___y_1535_;
goto v___jp_1516_;
}
else
{
size_t v___x_1541_; size_t v___x_1542_; lean_object* v___x_1543_; 
v___x_1541_ = ((size_t)0ULL);
v___x_1542_ = lean_usize_of_nat(v___x_1539_);
v___x_1543_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__31(v_g_1515_, v___y_1537_, v_f_1514_, v___y_1536_, v_d_1530_, v___x_1538_, v___x_1541_, v___x_1542_, v___y_1535_);
lean_dec_ref(v___x_1538_);
lean_dec_ref(v___y_1536_);
lean_dec_ref(v_f_1514_);
v___y_1517_ = v___y_1537_;
v___y_1518_ = v___x_1543_;
goto v___jp_1516_;
}
}
v___jp_1545_:
{
uint8_t v___x_1549_; 
v___x_1549_ = lean_nat_dec_lt(v___x_1533_, v___x_1544_);
if (v___x_1549_ == 0)
{
lean_dec_ref(v___y_1548_);
lean_dec_ref(v___x_1532_);
lean_inc_ref(v___y_1546_);
v___y_1535_ = v___y_1546_;
v___y_1536_ = v___y_1547_;
v___y_1537_ = v___y_1546_;
goto v___jp_1534_;
}
else
{
size_t v___x_1550_; size_t v___x_1551_; lean_object* v___x_1552_; 
v___x_1550_ = ((size_t)0ULL);
v___x_1551_ = lean_usize_of_nat(v___x_1544_);
lean_inc_ref(v___y_1546_);
v___x_1552_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__32(v_d_1530_, v___y_1547_, v___y_1548_, v___x_1532_, v___x_1550_, v___x_1551_, v___y_1546_);
lean_dec_ref(v___x_1532_);
lean_dec_ref(v___y_1548_);
v___y_1535_ = v___y_1546_;
v___y_1536_ = v___y_1547_;
v___y_1537_ = v___x_1552_;
goto v___jp_1534_;
}
}
v___jp_1553_:
{
lean_object* v___x_1555_; uint8_t v___x_1556_; 
v___x_1555_ = ((lean_object*)(lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16___closed__0));
v___x_1556_ = lean_nat_dec_lt(v___x_1533_, v___x_1544_);
if (v___x_1556_ == 0)
{
lean_dec(v_n_1527_);
v___y_1546_ = v___x_1555_;
v___y_1547_ = v___y_1554_;
v___y_1548_ = v___x_1555_;
goto v___jp_1545_;
}
else
{
size_t v___x_1557_; size_t v___x_1558_; lean_object* v___x_1559_; 
v___x_1557_ = ((size_t)0ULL);
v___x_1558_ = lean_usize_of_nat(v___x_1544_);
v___x_1559_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__33(v_m_1528_, v_g_1515_, v___y_1554_, v_n_1527_, v_f_1514_, v___x_1532_, v___x_1557_, v___x_1558_, v___x_1555_);
lean_dec(v_n_1527_);
v___y_1546_ = v___x_1555_;
v___y_1547_ = v___y_1554_;
v___y_1548_ = v___x_1559_;
goto v___jp_1545_;
}
}
}
else
{
lean_object* v___x_1565_; lean_object* v___x_1566_; 
v___x_1565_ = lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
v___x_1566_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1566_, 0, v___x_1565_);
lean_ctor_set(v___x_1566_, 1, v_f_1514_);
return v___x_1566_;
}
}
else
{
lean_object* v___x_1567_; lean_object* v___x_1568_; 
v___x_1567_ = lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
v___x_1568_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1568_, 0, v___x_1567_);
lean_ctor_set(v___x_1568_, 1, v_f_1514_);
return v___x_1568_;
}
v___jp_1516_:
{
lean_object* v___x_1519_; lean_object* v___x_1520_; lean_object* v___x_1521_; 
v___x_1519_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v___y_1517_);
v___x_1520_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v___y_1518_);
v___x_1521_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1521_, 0, v___x_1519_);
lean_ctor_set(v___x_1521_, 1, v___x_1520_);
return v___x_1521_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23___boxed(lean_object* v_f_1569_, lean_object* v_g_1570_){
_start:
{
lean_object* v_res_1571_; 
v_res_1571_ = lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23(v_f_1569_, v_g_1570_);
lean_dec_ref(v_g_1570_);
return v_res_1571_;
}
}
LEAN_EXPORT lean_object* lp_Hex_npowRec___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__24(lean_object* v_x_1572_, lean_object* v_x_1573_){
_start:
{
lean_object* v_zero_1574_; uint8_t v_isZero_1575_; 
v_zero_1574_ = lean_unsigned_to_nat(0u);
v_isZero_1575_ = lean_nat_dec_eq(v_x_1572_, v_zero_1574_);
if (v_isZero_1575_ == 1)
{
lean_object* v___x_1576_; 
v___x_1576_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
return v___x_1576_;
}
else
{
lean_object* v_one_1577_; lean_object* v_n_1578_; lean_object* v___x_1579_; lean_object* v___x_1580_; 
v_one_1577_ = lean_unsigned_to_nat(1u);
v_n_1578_ = lean_nat_sub(v_x_1572_, v_one_1577_);
v___x_1579_ = lp_Hex_npowRec___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__24(v_n_1578_, v_x_1573_);
lean_dec(v_n_1578_);
v___x_1580_ = lean_int_mul(v___x_1579_, v_x_1573_);
lean_dec(v___x_1579_);
return v___x_1580_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_npowRec___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__24___boxed(lean_object* v_x_1581_, lean_object* v_x_1582_){
_start:
{
lean_object* v_res_1583_; 
v_res_1583_ = lp_Hex_npowRec___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__24(v_x_1581_, v_x_1582_);
lean_dec(v_x_1582_);
lean_dec(v_x_1581_);
return v_res_1583_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16(lean_object* v_p_1584_, lean_object* v_q_1585_){
_start:
{
lean_object* v_qr_1586_; lean_object* v_fst_1587_; lean_object* v_snd_1588_; lean_object* v___x_1589_; lean_object* v___x_1590_; lean_object* v___x_1591_; lean_object* v___x_1592_; 
lean_inc_ref(v_p_1584_);
v_qr_1586_ = lp_Hex_Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23(v_p_1584_, v_q_1585_);
v_fst_1587_ = lean_ctor_get(v_qr_1586_, 0);
lean_inc(v_fst_1587_);
v_snd_1588_ = lean_ctor_get(v_qr_1586_, 1);
lean_inc(v_snd_1588_);
lean_dec_ref(v_qr_1586_);
v___x_1589_ = lp_Hex_Hex_DensePoly_pseudoExponent___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__17(v_p_1584_, v_q_1585_);
lean_dec_ref(v_p_1584_);
v___x_1590_ = lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(v_q_1585_);
v___x_1591_ = lp_Hex_npowRec___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__24(v___x_1589_, v___x_1590_);
lean_dec(v___x_1590_);
lean_dec(v___x_1589_);
v___x_1592_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1592_, 0, v___x_1591_);
lean_ctor_set(v___x_1592_, 1, v_fst_1587_);
lean_ctor_set(v___x_1592_, 2, v_snd_1588_);
return v___x_1592_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16___boxed(lean_object* v_p_1593_, lean_object* v_q_1594_){
_start:
{
lean_object* v_res_1595_; 
v_res_1595_ = lp_Hex_Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16(v_p_1593_, v_q_1594_);
lean_dec_ref(v_q_1594_);
return v_res_1595_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19_spec__28(size_t v_sz_1596_, size_t v_i_1597_, lean_object* v_bs_1598_){
_start:
{
uint8_t v___x_1599_; 
v___x_1599_ = lean_usize_dec_lt(v_i_1597_, v_sz_1596_);
if (v___x_1599_ == 0)
{
return v_bs_1598_;
}
else
{
lean_object* v___x_1600_; lean_object* v_v_1601_; lean_object* v_bs_x27_1602_; lean_object* v___x_1603_; lean_object* v___x_1604_; size_t v___x_1605_; size_t v___x_1606_; lean_object* v___x_1607_; 
v___x_1600_ = lean_unsigned_to_nat(0u);
v_v_1601_ = lean_array_uget(v_bs_1598_, v_i_1597_);
v_bs_x27_1602_ = lean_array_uset(v_bs_1598_, v_i_1597_, v___x_1600_);
v___x_1603_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1604_ = lean_int_sub(v___x_1603_, v_v_1601_);
lean_dec(v_v_1601_);
v___x_1605_ = ((size_t)1ULL);
v___x_1606_ = lean_usize_add(v_i_1597_, v___x_1605_);
v___x_1607_ = lean_array_uset(v_bs_x27_1602_, v_i_1597_, v___x_1604_);
v_i_1597_ = v___x_1606_;
v_bs_1598_ = v___x_1607_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19_spec__28___boxed(lean_object* v_sz_1609_, lean_object* v_i_1610_, lean_object* v_bs_1611_){
_start:
{
size_t v_sz_boxed_1612_; size_t v_i_boxed_1613_; lean_object* v_res_1614_; 
v_sz_boxed_1612_ = lean_unbox_usize(v_sz_1609_);
lean_dec(v_sz_1609_);
v_i_boxed_1613_ = lean_unbox_usize(v_i_1610_);
lean_dec(v_i_1610_);
v_res_1614_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19_spec__28(v_sz_boxed_1612_, v_i_boxed_1613_, v_bs_1611_);
return v_res_1614_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19(lean_object* v_p_1615_){
_start:
{
size_t v_sz_1616_; size_t v___x_1617_; lean_object* v___x_1618_; lean_object* v___x_1619_; 
v_sz_1616_ = lean_array_size(v_p_1615_);
v___x_1617_ = ((size_t)0ULL);
v___x_1618_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19_spec__28(v_sz_1616_, v___x_1617_, v_p_1615_);
v___x_1619_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v___x_1618_);
return v___x_1619_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11(lean_object* v_sign_1620_, lean_object* v_p_1621_, lean_object* v_q_1622_){
_start:
{
lean_object* v_r_1623_; uint8_t v___y_1625_; lean_object* v___x_1639_; lean_object* v___x_1640_; lean_object* v___x_1641_; lean_object* v___x_1642_; uint8_t v___x_1643_; 
lean_inc_ref(v_p_1621_);
v_r_1623_ = lp_Hex_Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16(v_p_1621_, v_q_1622_);
v___x_1639_ = lp_Hex_Hex_DensePoly_pseudoExponent___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__17(v_p_1621_, v_q_1622_);
lean_dec_ref(v_p_1621_);
v___x_1640_ = lean_unsigned_to_nat(2u);
v___x_1641_ = lean_nat_mod(v___x_1639_, v___x_1640_);
lean_dec(v___x_1639_);
v___x_1642_ = lean_unsigned_to_nat(1u);
v___x_1643_ = lean_nat_dec_eq(v___x_1641_, v___x_1642_);
lean_dec(v___x_1641_);
if (v___x_1643_ == 0)
{
lean_dec_ref(v_sign_1620_);
v___y_1625_ = v___x_1643_;
goto v___jp_1624_;
}
else
{
lean_object* v___x_1644_; lean_object* v___x_1645_; lean_object* v___x_1646_; uint8_t v___x_1647_; 
v___x_1644_ = lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(v_q_1622_);
v___x_1645_ = lean_apply_1(v_sign_1620_, v___x_1644_);
v___x_1646_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1647_ = lean_int_dec_lt(v___x_1645_, v___x_1646_);
lean_dec(v___x_1645_);
v___y_1625_ = v___x_1647_;
goto v___jp_1624_;
}
v___jp_1624_:
{
if (v___y_1625_ == 0)
{
return v_r_1623_;
}
else
{
lean_object* v_multiplier_1626_; lean_object* v_quotient_1627_; lean_object* v_remainder_1628_; lean_object* v___x_1630_; uint8_t v_isShared_1631_; uint8_t v_isSharedCheck_1638_; 
v_multiplier_1626_ = lean_ctor_get(v_r_1623_, 0);
v_quotient_1627_ = lean_ctor_get(v_r_1623_, 1);
v_remainder_1628_ = lean_ctor_get(v_r_1623_, 2);
v_isSharedCheck_1638_ = !lean_is_exclusive(v_r_1623_);
if (v_isSharedCheck_1638_ == 0)
{
v___x_1630_ = v_r_1623_;
v_isShared_1631_ = v_isSharedCheck_1638_;
goto v_resetjp_1629_;
}
else
{
lean_inc(v_remainder_1628_);
lean_inc(v_quotient_1627_);
lean_inc(v_multiplier_1626_);
lean_dec(v_r_1623_);
v___x_1630_ = lean_box(0);
v_isShared_1631_ = v_isSharedCheck_1638_;
goto v_resetjp_1629_;
}
v_resetjp_1629_:
{
lean_object* v___x_1632_; lean_object* v___x_1633_; lean_object* v___x_1634_; lean_object* v___x_1636_; 
v___x_1632_ = lean_int_neg(v_multiplier_1626_);
lean_dec(v_multiplier_1626_);
v___x_1633_ = lp_Hex_Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19(v_quotient_1627_);
v___x_1634_ = lp_Hex_Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19(v_remainder_1628_);
if (v_isShared_1631_ == 0)
{
lean_ctor_set(v___x_1630_, 2, v___x_1634_);
lean_ctor_set(v___x_1630_, 1, v___x_1633_);
lean_ctor_set(v___x_1630_, 0, v___x_1632_);
v___x_1636_ = v___x_1630_;
goto v_reusejp_1635_;
}
else
{
lean_object* v_reuseFailAlloc_1637_; 
v_reuseFailAlloc_1637_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_1637_, 0, v___x_1632_);
lean_ctor_set(v_reuseFailAlloc_1637_, 1, v___x_1633_);
lean_ctor_set(v_reuseFailAlloc_1637_, 2, v___x_1634_);
v___x_1636_ = v_reuseFailAlloc_1637_;
goto v_reusejp_1635_;
}
v_reusejp_1635_:
{
return v___x_1636_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11___boxed(lean_object* v_sign_1648_, lean_object* v_p_1649_, lean_object* v_q_1650_){
_start:
{
lean_object* v_res_1651_; 
v_res_1651_ = lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11(v_sign_1648_, v_p_1649_, v_q_1650_);
lean_dec_ref(v_q_1650_);
return v_res_1651_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9___lam__0(lean_object* v___x_1652_, lean_object* v_p_1653_, lean_object* v_i_1654_){
_start:
{
lean_object* v___x_1655_; lean_object* v___x_1656_; lean_object* v___x_1657_; lean_object* v___x_1658_; 
v___x_1655_ = lean_nat_add(v_i_1654_, v___x_1652_);
lean_inc(v___x_1655_);
v___x_1656_ = lean_nat_to_int(v___x_1655_);
v___x_1657_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_p_1653_, v___x_1655_);
lean_dec(v___x_1655_);
v___x_1658_ = lean_int_mul(v___x_1656_, v___x_1657_);
lean_dec(v___x_1657_);
lean_dec(v___x_1656_);
return v___x_1658_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9___lam__0___boxed(lean_object* v___x_1659_, lean_object* v_p_1660_, lean_object* v_i_1661_){
_start:
{
lean_object* v_res_1662_; 
v_res_1662_ = lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9___lam__0(v___x_1659_, v_p_1660_, v_i_1661_);
lean_dec(v_i_1661_);
lean_dec_ref(v_p_1660_);
lean_dec(v___x_1659_);
return v_res_1662_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9(lean_object* v_p_1663_){
_start:
{
lean_object* v___x_1664_; lean_object* v___x_1665_; lean_object* v___f_1666_; lean_object* v___x_1667_; lean_object* v___x_1668_; lean_object* v___x_1669_; 
v___x_1664_ = lean_array_get_size(v_p_1663_);
v___x_1665_ = lean_unsigned_to_nat(1u);
v___f_1666_ = lean_alloc_closure((void*)(lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9___lam__0___boxed), 3, 2);
lean_closure_set(v___f_1666_, 0, v___x_1665_);
lean_closure_set(v___f_1666_, 1, v_p_1663_);
v___x_1667_ = lean_nat_sub(v___x_1664_, v___x_1665_);
v___x_1668_ = l_Array_ofFn___redArg(v___x_1667_, v___f_1666_);
v___x_1669_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v___x_1668_);
return v___x_1669_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(lean_object* v_p_1670_){
_start:
{
lean_object* v___x_1671_; lean_object* v___x_1672_; uint8_t v___x_1673_; 
v___x_1671_ = lean_array_get_size(v_p_1670_);
v___x_1672_ = lean_unsigned_to_nat(0u);
v___x_1673_ = lean_nat_dec_eq(v___x_1671_, v___x_1672_);
if (v___x_1673_ == 0)
{
lean_object* v___x_1674_; lean_object* v___x_1675_; lean_object* v___x_1676_; 
v___x_1674_ = lean_unsigned_to_nat(1u);
v___x_1675_ = lean_nat_sub(v___x_1671_, v___x_1674_);
v___x_1676_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1676_, 0, v___x_1675_);
return v___x_1676_;
}
else
{
lean_object* v___x_1677_; 
v___x_1677_ = lean_box(0);
return v___x_1677_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8___boxed(lean_object* v_p_1678_){
_start:
{
lean_object* v_res_1679_; 
v_res_1679_ = lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(v_p_1678_);
lean_dec_ref(v_p_1678_);
return v_res_1679_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__13(size_t v_sz_1680_, size_t v_i_1681_, lean_object* v_bs_1682_){
_start:
{
uint8_t v___x_1683_; 
v___x_1683_ = lean_usize_dec_lt(v_i_1681_, v_sz_1680_);
if (v___x_1683_ == 0)
{
return v_bs_1682_;
}
else
{
lean_object* v_v_1684_; lean_object* v___x_1685_; lean_object* v_bs_x27_1686_; lean_object* v___y_1688_; lean_object* v___x_1693_; 
v_v_1684_ = lean_array_uget(v_bs_1682_, v_i_1681_);
v___x_1685_ = lean_unsigned_to_nat(0u);
v_bs_x27_1686_ = lean_array_uset(v_bs_1682_, v_i_1681_, v___x_1685_);
v___x_1693_ = lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(v_v_1684_);
lean_dec(v_v_1684_);
if (lean_obj_tag(v___x_1693_) == 0)
{
v___y_1688_ = v___x_1685_;
goto v___jp_1687_;
}
else
{
lean_object* v_val_1694_; 
v_val_1694_ = lean_ctor_get(v___x_1693_, 0);
lean_inc(v_val_1694_);
lean_dec_ref_known(v___x_1693_, 1);
v___y_1688_ = v_val_1694_;
goto v___jp_1687_;
}
v___jp_1687_:
{
size_t v___x_1689_; size_t v___x_1690_; lean_object* v___x_1691_; 
v___x_1689_ = ((size_t)1ULL);
v___x_1690_ = lean_usize_add(v_i_1681_, v___x_1689_);
v___x_1691_ = lean_array_uset(v_bs_x27_1686_, v_i_1681_, v___y_1688_);
v_i_1681_ = v___x_1690_;
v_bs_1682_ = v___x_1691_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__13___boxed(lean_object* v_sz_1695_, lean_object* v_i_1696_, lean_object* v_bs_1697_){
_start:
{
size_t v_sz_boxed_1698_; size_t v_i_boxed_1699_; lean_object* v_res_1700_; 
v_sz_boxed_1698_ = lean_unbox_usize(v_sz_1695_);
lean_dec(v_sz_1695_);
v_i_boxed_1699_ = lean_unbox_usize(v_i_1696_);
lean_dec(v_i_1696_);
v_res_1700_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__13(v_sz_boxed_1698_, v_i_boxed_1699_, v_bs_1697_);
return v_res_1700_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_buildAux___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__12(lean_object* v_sign_1701_, lean_object* v_normalize_1702_, lean_object* v_x_1703_, lean_object* v_x_1704_, lean_object* v_x_1705_, lean_object* v_x_1706_, lean_object* v_x_1707_){
_start:
{
lean_object* v_zero_1708_; uint8_t v_isZero_1709_; 
v_zero_1708_ = lean_unsigned_to_nat(0u);
v_isZero_1709_ = lean_nat_dec_eq(v_x_1703_, v_zero_1708_);
if (v_isZero_1709_ == 1)
{
lean_object* v___x_1710_; lean_object* v___x_1711_; lean_object* v___x_1712_; 
lean_dec_ref(v_x_1705_);
lean_dec_ref(v_x_1704_);
lean_dec(v_x_1703_);
lean_dec_ref(v_normalize_1702_);
lean_dec_ref(v_sign_1701_);
v___x_1710_ = lean_box(0);
v___x_1711_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1711_, 0, v_x_1707_);
lean_ctor_set(v___x_1711_, 1, v___x_1710_);
v___x_1712_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1712_, 0, v_x_1706_);
lean_ctor_set(v___x_1712_, 1, v___x_1711_);
return v___x_1712_;
}
else
{
lean_object* v_r_1713_; lean_object* v_multiplier_1714_; lean_object* v_quotient_1715_; lean_object* v_remainder_1716_; lean_object* v___x_1718_; uint8_t v_isShared_1719_; uint8_t v_isSharedCheck_1737_; 
lean_inc_ref(v_sign_1701_);
v_r_1713_ = lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11(v_sign_1701_, v_x_1704_, v_x_1705_);
v_multiplier_1714_ = lean_ctor_get(v_r_1713_, 0);
v_quotient_1715_ = lean_ctor_get(v_r_1713_, 1);
v_remainder_1716_ = lean_ctor_get(v_r_1713_, 2);
v_isSharedCheck_1737_ = !lean_is_exclusive(v_r_1713_);
if (v_isSharedCheck_1737_ == 0)
{
v___x_1718_ = v_r_1713_;
v_isShared_1719_ = v_isSharedCheck_1737_;
goto v_resetjp_1717_;
}
else
{
lean_inc(v_remainder_1716_);
lean_inc(v_quotient_1715_);
lean_inc(v_multiplier_1714_);
lean_dec(v_r_1713_);
v___x_1718_ = lean_box(0);
v_isShared_1719_ = v_isSharedCheck_1737_;
goto v_resetjp_1717_;
}
v_resetjp_1717_:
{
uint8_t v___x_1720_; 
v___x_1720_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_remainder_1716_);
if (v___x_1720_ == 0)
{
lean_object* v___x_1721_; lean_object* v_fst_1722_; lean_object* v_snd_1723_; lean_object* v_one_1724_; lean_object* v_n_1725_; lean_object* v_next_1726_; lean_object* v___x_1727_; lean_object* v___x_1729_; 
lean_inc_ref(v_normalize_1702_);
v___x_1721_ = lean_apply_1(v_normalize_1702_, v_remainder_1716_);
v_fst_1722_ = lean_ctor_get(v___x_1721_, 0);
lean_inc(v_fst_1722_);
v_snd_1723_ = lean_ctor_get(v___x_1721_, 1);
lean_inc(v_snd_1723_);
lean_dec_ref(v___x_1721_);
v_one_1724_ = lean_unsigned_to_nat(1u);
v_n_1725_ = lean_nat_sub(v_x_1703_, v_one_1724_);
lean_dec(v_x_1703_);
v_next_1726_ = lp_Hex_Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19(v_snd_1723_);
lean_inc_ref(v_next_1726_);
v___x_1727_ = lean_array_push(v_x_1706_, v_next_1726_);
if (v_isShared_1719_ == 0)
{
lean_ctor_set(v___x_1718_, 2, v_fst_1722_);
v___x_1729_ = v___x_1718_;
goto v_reusejp_1728_;
}
else
{
lean_object* v_reuseFailAlloc_1732_; 
v_reuseFailAlloc_1732_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_1732_, 0, v_multiplier_1714_);
lean_ctor_set(v_reuseFailAlloc_1732_, 1, v_quotient_1715_);
lean_ctor_set(v_reuseFailAlloc_1732_, 2, v_fst_1722_);
v___x_1729_ = v_reuseFailAlloc_1732_;
goto v_reusejp_1728_;
}
v_reusejp_1728_:
{
lean_object* v___x_1730_; 
v___x_1730_ = lean_array_push(v_x_1707_, v___x_1729_);
v_x_1703_ = v_n_1725_;
v_x_1704_ = v_x_1705_;
v_x_1705_ = v_next_1726_;
v_x_1706_ = v___x_1727_;
v_x_1707_ = v___x_1730_;
goto _start;
}
}
else
{
lean_object* v___x_1733_; lean_object* v___x_1734_; lean_object* v___x_1735_; lean_object* v___x_1736_; 
lean_del_object(v___x_1718_);
lean_dec_ref(v_remainder_1716_);
lean_dec_ref(v_x_1705_);
lean_dec(v_x_1703_);
lean_dec_ref(v_normalize_1702_);
lean_dec_ref(v_sign_1701_);
v___x_1733_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1733_, 0, v_multiplier_1714_);
lean_ctor_set(v___x_1733_, 1, v_quotient_1715_);
v___x_1734_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1734_, 0, v___x_1733_);
v___x_1735_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1735_, 0, v_x_1707_);
lean_ctor_set(v___x_1735_, 1, v___x_1734_);
v___x_1736_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1736_, 0, v_x_1706_);
lean_ctor_set(v___x_1736_, 1, v___x_1735_);
return v___x_1736_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__13(lean_object* v_i_1738_, lean_object* v_q_1739_, lean_object* v_pi_1740_, lean_object* v_x_1741_, lean_object* v_x_1742_){
_start:
{
if (lean_obj_tag(v_x_1742_) == 0)
{
return v_x_1741_;
}
else
{
lean_object* v_head_1743_; lean_object* v_tail_1744_; lean_object* v_k_1745_; lean_object* v___y_1747_; lean_object* v___x_1753_; uint8_t v___x_1754_; 
v_head_1743_ = lean_ctor_get(v_x_1742_, 0);
v_tail_1744_ = lean_ctor_get(v_x_1742_, 1);
v_k_1745_ = lean_nat_add(v_i_1738_, v_head_1743_);
v___x_1753_ = lean_array_get_size(v_x_1741_);
v___x_1754_ = lean_nat_dec_lt(v_k_1745_, v___x_1753_);
if (v___x_1754_ == 0)
{
lean_object* v___x_1755_; 
v___x_1755_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___y_1747_ = v___x_1755_;
goto v___jp_1746_;
}
else
{
lean_object* v___x_1756_; 
v___x_1756_ = lean_array_fget_borrowed(v_x_1741_, v_k_1745_);
lean_inc(v___x_1756_);
v___y_1747_ = v___x_1756_;
goto v___jp_1746_;
}
v___jp_1746_:
{
lean_object* v___x_1748_; lean_object* v___x_1749_; lean_object* v___x_1750_; lean_object* v___x_1751_; 
v___x_1748_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_q_1739_, v_head_1743_);
v___x_1749_ = lean_int_mul(v_pi_1740_, v___x_1748_);
lean_dec(v___x_1748_);
v___x_1750_ = lean_int_add(v___y_1747_, v___x_1749_);
lean_dec(v___x_1749_);
lean_dec(v___y_1747_);
v___x_1751_ = lean_array_set(v_x_1741_, v_k_1745_, v___x_1750_);
lean_dec(v_k_1745_);
v_x_1741_ = v___x_1751_;
v_x_1742_ = v_tail_1744_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__13___boxed(lean_object* v_i_1757_, lean_object* v_q_1758_, lean_object* v_pi_1759_, lean_object* v_x_1760_, lean_object* v_x_1761_){
_start:
{
lean_object* v_res_1762_; 
v_res_1762_ = lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__13(v_i_1757_, v_q_1758_, v_pi_1759_, v_x_1760_, v_x_1761_);
lean_dec(v_x_1761_);
lean_dec(v_pi_1759_);
lean_dec_ref(v_q_1758_);
lean_dec(v_i_1757_);
return v_res_1762_;
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14_spec__20(lean_object* v_p_1763_, lean_object* v___x_1764_, lean_object* v_q_1765_, lean_object* v_x_1766_, lean_object* v_x_1767_){
_start:
{
if (lean_obj_tag(v_x_1767_) == 0)
{
lean_dec(v___x_1764_);
return v_x_1766_;
}
else
{
lean_object* v_head_1768_; lean_object* v_tail_1769_; lean_object* v_pi_1770_; lean_object* v___x_1771_; lean_object* v___x_1772_; 
v_head_1768_ = lean_ctor_get(v_x_1767_, 0);
v_tail_1769_ = lean_ctor_get(v_x_1767_, 1);
v_pi_1770_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_p_1763_, v_head_1768_);
lean_inc(v___x_1764_);
v___x_1771_ = l_List_range(v___x_1764_);
v___x_1772_ = lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__13(v_head_1768_, v_q_1765_, v_pi_1770_, v_x_1766_, v___x_1771_);
lean_dec(v___x_1771_);
lean_dec(v_pi_1770_);
v_x_1766_ = v___x_1772_;
v_x_1767_ = v_tail_1769_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14_spec__20___boxed(lean_object* v_p_1774_, lean_object* v___x_1775_, lean_object* v_q_1776_, lean_object* v_x_1777_, lean_object* v_x_1778_){
_start:
{
lean_object* v_res_1779_; 
v_res_1779_ = lp_Hex_List_foldl___at___00List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14_spec__20(v_p_1774_, v___x_1775_, v_q_1776_, v_x_1777_, v_x_1778_);
lean_dec(v_x_1778_);
lean_dec_ref(v_q_1776_);
lean_dec_ref(v_p_1774_);
return v_res_1779_;
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14(lean_object* v_p_1780_, lean_object* v_q_1781_, lean_object* v___x_1782_, lean_object* v_x_1783_, lean_object* v_x_1784_){
_start:
{
if (lean_obj_tag(v_x_1784_) == 0)
{
lean_dec(v___x_1782_);
return v_x_1783_;
}
else
{
lean_object* v_head_1785_; lean_object* v_tail_1786_; lean_object* v_pi_1787_; lean_object* v___x_1788_; lean_object* v___x_1789_; lean_object* v___x_1790_; 
v_head_1785_ = lean_ctor_get(v_x_1784_, 0);
v_tail_1786_ = lean_ctor_get(v_x_1784_, 1);
v_pi_1787_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_p_1780_, v_head_1785_);
lean_inc(v___x_1782_);
v___x_1788_ = l_List_range(v___x_1782_);
v___x_1789_ = lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__13(v_head_1785_, v_q_1781_, v_pi_1787_, v_x_1783_, v___x_1788_);
lean_dec(v___x_1788_);
lean_dec(v_pi_1787_);
v___x_1790_ = lp_Hex_List_foldl___at___00List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14_spec__20(v_p_1780_, v___x_1782_, v_q_1781_, v___x_1789_, v_tail_1786_);
return v___x_1790_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14___boxed(lean_object* v_p_1791_, lean_object* v_q_1792_, lean_object* v___x_1793_, lean_object* v_x_1794_, lean_object* v_x_1795_){
_start:
{
lean_object* v_res_1796_; 
v_res_1796_ = lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14(v_p_1791_, v_q_1792_, v___x_1793_, v_x_1794_, v_x_1795_);
lean_dec(v_x_1795_);
lean_dec_ref(v_q_1792_);
lean_dec_ref(v_p_1791_);
return v_res_1796_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10(lean_object* v_p_1797_, lean_object* v_q_1798_){
_start:
{
uint8_t v___y_1800_; uint8_t v___x_1812_; 
v___x_1812_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_p_1797_);
if (v___x_1812_ == 0)
{
uint8_t v___x_1813_; 
v___x_1813_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_q_1798_);
v___y_1800_ = v___x_1813_;
goto v___jp_1799_;
}
else
{
v___y_1800_ = v___x_1812_;
goto v___jp_1799_;
}
v___jp_1799_:
{
if (v___y_1800_ == 0)
{
lean_object* v___x_1801_; lean_object* v___x_1802_; lean_object* v___x_1803_; lean_object* v___x_1804_; lean_object* v_size_1805_; lean_object* v___x_1806_; lean_object* v___x_1807_; lean_object* v___x_1808_; lean_object* v_coeffs_1809_; lean_object* v___x_1810_; 
v___x_1801_ = lean_array_get_size(v_p_1797_);
v___x_1802_ = lean_array_get_size(v_q_1798_);
v___x_1803_ = lean_nat_add(v___x_1801_, v___x_1802_);
v___x_1804_ = lean_unsigned_to_nat(1u);
v_size_1805_ = lean_nat_sub(v___x_1803_, v___x_1804_);
lean_dec(v___x_1803_);
v___x_1806_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_1807_ = lean_mk_array(v_size_1805_, v___x_1806_);
v___x_1808_ = l_List_range(v___x_1801_);
v_coeffs_1809_ = lp_Hex_List_foldl___at___00Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10_spec__14(v_p_1797_, v_q_1798_, v___x_1802_, v___x_1807_, v___x_1808_);
lean_dec(v___x_1808_);
v___x_1810_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v_coeffs_1809_);
return v___x_1810_;
}
else
{
lean_object* v___x_1811_; 
v___x_1811_ = lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
return v___x_1811_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10___boxed(lean_object* v_p_1814_, lean_object* v_q_1815_){
_start:
{
lean_object* v_res_1816_; 
v_res_1816_ = lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10(v_p_1814_, v_q_1815_);
lean_dec_ref(v_q_1815_);
lean_dec_ref(v_p_1814_);
return v_res_1816_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3(lean_object* v_sign_1819_, lean_object* v_normalize_1820_, lean_object* v_p_1821_, lean_object* v_f_1822_){
_start:
{
lean_object* v___x_1823_; lean_object* v___x_1824_; lean_object* v_r_1825_; lean_object* v_multiplier_1826_; lean_object* v_quotient_1827_; lean_object* v_remainder_1828_; lean_object* v___x_1830_; uint8_t v_isShared_1831_; uint8_t v_isSharedCheck_1873_; 
lean_inc_ref(v_p_1821_);
v___x_1823_ = lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9(v_p_1821_);
v___x_1824_ = lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10(v_f_1822_, v___x_1823_);
lean_dec_ref(v___x_1823_);
lean_inc_ref(v_sign_1819_);
v_r_1825_ = lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11(v_sign_1819_, v___x_1824_, v_p_1821_);
v_multiplier_1826_ = lean_ctor_get(v_r_1825_, 0);
v_quotient_1827_ = lean_ctor_get(v_r_1825_, 1);
v_remainder_1828_ = lean_ctor_get(v_r_1825_, 2);
v_isSharedCheck_1873_ = !lean_is_exclusive(v_r_1825_);
if (v_isSharedCheck_1873_ == 0)
{
v___x_1830_ = v_r_1825_;
v_isShared_1831_ = v_isSharedCheck_1873_;
goto v_resetjp_1829_;
}
else
{
lean_inc(v_remainder_1828_);
lean_inc(v_quotient_1827_);
lean_inc(v_multiplier_1826_);
lean_dec(v_r_1825_);
v___x_1830_ = lean_box(0);
v_isShared_1831_ = v_isSharedCheck_1873_;
goto v_resetjp_1829_;
}
v_resetjp_1829_:
{
lean_object* v___x_1832_; uint8_t v___x_1833_; 
v___x_1832_ = lean_unsigned_to_nat(0u);
v___x_1833_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_remainder_1828_);
if (v___x_1833_ == 0)
{
lean_object* v___x_1834_; lean_object* v_fst_1835_; lean_object* v_snd_1836_; lean_object* v___y_1838_; lean_object* v___x_1856_; 
lean_inc_ref(v_normalize_1820_);
v___x_1834_ = lean_apply_1(v_normalize_1820_, v_remainder_1828_);
v_fst_1835_ = lean_ctor_get(v___x_1834_, 0);
lean_inc(v_fst_1835_);
v_snd_1836_ = lean_ctor_get(v___x_1834_, 1);
lean_inc(v_snd_1836_);
lean_dec_ref(v___x_1834_);
v___x_1856_ = lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(v_p_1821_);
if (lean_obj_tag(v___x_1856_) == 0)
{
v___y_1838_ = v___x_1832_;
goto v___jp_1837_;
}
else
{
lean_object* v_val_1857_; 
v_val_1857_ = lean_ctor_get(v___x_1856_, 0);
lean_inc(v_val_1857_);
lean_dec_ref_known(v___x_1856_, 1);
v___y_1838_ = v_val_1857_;
goto v___jp_1837_;
}
v___jp_1837_:
{
lean_object* v___x_1839_; lean_object* v___x_1840_; lean_object* v___x_1841_; lean_object* v___x_1842_; lean_object* v___x_1843_; lean_object* v_result_1844_; lean_object* v_snd_1845_; lean_object* v_fst_1846_; lean_object* v_fst_1847_; lean_object* v_snd_1848_; size_t v_sz_1849_; size_t v___x_1850_; lean_object* v___x_1851_; lean_object* v___x_1853_; 
v___x_1839_ = lean_unsigned_to_nat(2u);
v___x_1840_ = lean_mk_empty_array_with_capacity(v___x_1839_);
lean_inc_ref(v_p_1821_);
v___x_1841_ = lean_array_push(v___x_1840_, v_p_1821_);
lean_inc(v_snd_1836_);
v___x_1842_ = lean_array_push(v___x_1841_, v_snd_1836_);
v___x_1843_ = ((lean_object*)(lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___closed__0));
v_result_1844_ = lp_Hex_Hex_SignedRemainderChain_buildAux___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__12(v_sign_1819_, v_normalize_1820_, v___y_1838_, v_p_1821_, v_snd_1836_, v___x_1842_, v___x_1843_);
v_snd_1845_ = lean_ctor_get(v_result_1844_, 1);
lean_inc(v_snd_1845_);
v_fst_1846_ = lean_ctor_get(v_result_1844_, 0);
lean_inc_n(v_fst_1846_, 2);
lean_dec_ref(v_result_1844_);
v_fst_1847_ = lean_ctor_get(v_snd_1845_, 0);
lean_inc(v_fst_1847_);
v_snd_1848_ = lean_ctor_get(v_snd_1845_, 1);
lean_inc(v_snd_1848_);
lean_dec(v_snd_1845_);
v_sz_1849_ = lean_array_size(v_fst_1846_);
v___x_1850_ = ((size_t)0ULL);
v___x_1851_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__13(v_sz_1849_, v___x_1850_, v_fst_1846_);
if (v_isShared_1831_ == 0)
{
lean_ctor_set(v___x_1830_, 2, v_fst_1835_);
v___x_1853_ = v___x_1830_;
goto v_reusejp_1852_;
}
else
{
lean_object* v_reuseFailAlloc_1855_; 
v_reuseFailAlloc_1855_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_1855_, 0, v_multiplier_1826_);
lean_ctor_set(v_reuseFailAlloc_1855_, 1, v_quotient_1827_);
lean_ctor_set(v_reuseFailAlloc_1855_, 2, v_fst_1835_);
v___x_1853_ = v_reuseFailAlloc_1855_;
goto v_reusejp_1852_;
}
v_reusejp_1852_:
{
lean_object* v___x_1854_; 
v___x_1854_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1854_, 0, v_fst_1846_);
lean_ctor_set(v___x_1854_, 1, v___x_1851_);
lean_ctor_set(v___x_1854_, 2, v___x_1853_);
lean_ctor_set(v___x_1854_, 3, v_fst_1847_);
lean_ctor_set(v___x_1854_, 4, v_snd_1848_);
return v___x_1854_;
}
}
}
else
{
lean_object* v___x_1858_; lean_object* v___x_1859_; lean_object* v___x_1860_; lean_object* v___y_1862_; lean_object* v___x_1871_; 
lean_dec_ref(v_remainder_1828_);
lean_dec_ref(v_normalize_1820_);
lean_dec_ref(v_sign_1819_);
v___x_1858_ = lean_unsigned_to_nat(1u);
v___x_1859_ = lean_mk_empty_array_with_capacity(v___x_1858_);
lean_inc_ref(v_p_1821_);
lean_inc_ref(v___x_1859_);
v___x_1860_ = lean_array_push(v___x_1859_, v_p_1821_);
v___x_1871_ = lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(v_p_1821_);
lean_dec_ref(v_p_1821_);
if (lean_obj_tag(v___x_1871_) == 0)
{
v___y_1862_ = v___x_1832_;
goto v___jp_1861_;
}
else
{
lean_object* v_val_1872_; 
v_val_1872_ = lean_ctor_get(v___x_1871_, 0);
lean_inc(v_val_1872_);
lean_dec_ref_known(v___x_1871_, 1);
v___y_1862_ = v_val_1872_;
goto v___jp_1861_;
}
v___jp_1861_:
{
lean_object* v___x_1863_; lean_object* v___x_1864_; lean_object* v___x_1866_; 
v___x_1863_ = lean_array_push(v___x_1859_, v___y_1862_);
v___x_1864_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
if (v_isShared_1831_ == 0)
{
lean_ctor_set(v___x_1830_, 2, v___x_1864_);
v___x_1866_ = v___x_1830_;
goto v_reusejp_1865_;
}
else
{
lean_object* v_reuseFailAlloc_1870_; 
v_reuseFailAlloc_1870_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_1870_, 0, v_multiplier_1826_);
lean_ctor_set(v_reuseFailAlloc_1870_, 1, v_quotient_1827_);
lean_ctor_set(v_reuseFailAlloc_1870_, 2, v___x_1864_);
v___x_1866_ = v_reuseFailAlloc_1870_;
goto v_reusejp_1865_;
}
v_reusejp_1865_:
{
lean_object* v___x_1867_; lean_object* v___x_1868_; lean_object* v___x_1869_; 
v___x_1867_ = ((lean_object*)(lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___closed__0));
v___x_1868_ = lean_box(0);
v___x_1869_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_1869_, 0, v___x_1860_);
lean_ctor_set(v___x_1869_, 1, v___x_1863_);
lean_ctor_set(v___x_1869_, 2, v___x_1866_);
lean_ctor_set(v___x_1869_, 3, v___x_1867_);
lean_ctor_set(v___x_1869_, 4, v___x_1868_);
return v___x_1869_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___boxed(lean_object* v_sign_1874_, lean_object* v_normalize_1875_, lean_object* v_p_1876_, lean_object* v_f_1877_){
_start:
{
lean_object* v_res_1878_; 
v_res_1878_ = lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3(v_sign_1874_, v_normalize_1875_, v_p_1876_, v_f_1877_);
lean_dec_ref(v_f_1877_);
return v_res_1878_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4(lean_object* v_chain_1879_){
_start:
{
lean_object* v_chain_1880_; lean_object* v___x_1881_; lean_object* v___x_1882_; lean_object* v___y_1884_; lean_object* v___x_1887_; uint8_t v___x_1888_; 
v_chain_1880_ = lean_ctor_get(v_chain_1879_, 0);
v___x_1881_ = lean_array_get_size(v_chain_1880_);
v___x_1882_ = lean_unsigned_to_nat(1u);
v___x_1887_ = lean_nat_sub(v___x_1881_, v___x_1882_);
v___x_1888_ = lean_nat_dec_lt(v___x_1887_, v___x_1881_);
if (v___x_1888_ == 0)
{
lean_object* v___x_1889_; 
lean_dec(v___x_1887_);
v___x_1889_ = lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
v___y_1884_ = v___x_1889_;
goto v___jp_1883_;
}
else
{
lean_object* v___x_1890_; 
v___x_1890_ = lean_array_fget_borrowed(v_chain_1880_, v___x_1887_);
lean_dec(v___x_1887_);
v___y_1884_ = v___x_1890_;
goto v___jp_1883_;
}
v___jp_1883_:
{
lean_object* v___x_1885_; uint8_t v___x_1886_; 
v___x_1885_ = lean_array_get_size(v___y_1884_);
v___x_1886_ = lean_nat_dec_eq(v___x_1885_, v___x_1882_);
return v___x_1886_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4___boxed(lean_object* v_chain_1891_){
_start:
{
uint8_t v_res_1892_; lean_object* v_r_1893_; 
v_res_1892_ = lp_Hex_Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4(v_chain_1891_);
lean_dec_ref(v_chain_1891_);
v_r_1893_ = lean_box(v_res_1892_);
return v_r_1893_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___redArg(lean_object* v_sign_1894_, lean_object* v_endpointSigns_1895_, lean_object* v_p_1896_, lean_object* v_x_1897_){
_start:
{
switch(lean_obj_tag(v_x_1897_))
{
case 0:
{
lean_object* v___x_1898_; lean_object* v___x_1899_; lean_object* v___y_1901_; lean_object* v___x_1910_; 
lean_dec_ref(v_endpointSigns_1895_);
v___x_1898_ = lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(v_p_1896_);
v___x_1899_ = lean_apply_1(v_sign_1894_, v___x_1898_);
v___x_1910_ = lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(v_p_1896_);
lean_dec_ref(v_p_1896_);
if (lean_obj_tag(v___x_1910_) == 0)
{
lean_object* v___x_1911_; 
v___x_1911_ = lean_unsigned_to_nat(0u);
v___y_1901_ = v___x_1911_;
goto v___jp_1900_;
}
else
{
lean_object* v_val_1912_; 
v_val_1912_ = lean_ctor_get(v___x_1910_, 0);
lean_inc(v_val_1912_);
lean_dec_ref_known(v___x_1910_, 1);
v___y_1901_ = v_val_1912_;
goto v___jp_1900_;
}
v___jp_1900_:
{
lean_object* v___x_1902_; lean_object* v___x_1903_; lean_object* v___x_1904_; uint8_t v___x_1905_; 
v___x_1902_ = lean_unsigned_to_nat(2u);
v___x_1903_ = lean_nat_mod(v___y_1901_, v___x_1902_);
lean_dec(v___y_1901_);
v___x_1904_ = lean_unsigned_to_nat(1u);
v___x_1905_ = lean_nat_dec_eq(v___x_1903_, v___x_1904_);
lean_dec(v___x_1903_);
if (v___x_1905_ == 0)
{
lean_object* v___x_1906_; lean_object* v___x_1907_; 
v___x_1906_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_1907_ = lean_int_mul(v___x_1899_, v___x_1906_);
lean_dec(v___x_1899_);
return v___x_1907_;
}
else
{
lean_object* v___x_1908_; lean_object* v___x_1909_; 
v___x_1908_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__1, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__1_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__1);
v___x_1909_ = lean_int_mul(v___x_1899_, v___x_1908_);
lean_dec(v___x_1899_);
return v___x_1909_;
}
}
}
case 1:
{
lean_object* v_value_1913_; lean_object* v_evalSign_1914_; lean_object* v___x_1915_; 
lean_dec_ref(v_sign_1894_);
v_value_1913_ = lean_ctor_get(v_x_1897_, 0);
lean_inc(v_value_1913_);
lean_dec_ref_known(v_x_1897_, 1);
v_evalSign_1914_ = lean_ctor_get(v_endpointSigns_1895_, 1);
lean_inc_ref(v_evalSign_1914_);
lean_dec_ref(v_endpointSigns_1895_);
v___x_1915_ = lean_apply_2(v_evalSign_1914_, v_p_1896_, v_value_1913_);
return v___x_1915_;
}
default: 
{
lean_object* v___x_1916_; lean_object* v___x_1917_; 
lean_dec_ref(v_endpointSigns_1895_);
v___x_1916_ = lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(v_p_1896_);
lean_dec_ref(v_p_1896_);
v___x_1917_ = lean_apply_1(v_sign_1894_, v___x_1916_);
return v___x_1917_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___redArg(lean_object* v_sign_1918_, lean_object* v_endpointSigns_1919_, lean_object* v_endpoint_1920_, size_t v_sz_1921_, size_t v_i_1922_, lean_object* v_bs_1923_){
_start:
{
uint8_t v___x_1924_; 
v___x_1924_ = lean_usize_dec_lt(v_i_1922_, v_sz_1921_);
if (v___x_1924_ == 0)
{
lean_dec(v_endpoint_1920_);
lean_dec_ref(v_endpointSigns_1919_);
lean_dec_ref(v_sign_1918_);
return v_bs_1923_;
}
else
{
lean_object* v_v_1925_; lean_object* v___x_1926_; lean_object* v_bs_x27_1927_; lean_object* v___x_1928_; size_t v___x_1929_; size_t v___x_1930_; lean_object* v___x_1931_; 
v_v_1925_ = lean_array_uget(v_bs_1923_, v_i_1922_);
v___x_1926_ = lean_unsigned_to_nat(0u);
v_bs_x27_1927_ = lean_array_uset(v_bs_1923_, v_i_1922_, v___x_1926_);
lean_inc(v_endpoint_1920_);
lean_inc_ref(v_endpointSigns_1919_);
lean_inc_ref(v_sign_1918_);
v___x_1928_ = lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___redArg(v_sign_1918_, v_endpointSigns_1919_, v_v_1925_, v_endpoint_1920_);
v___x_1929_ = ((size_t)1ULL);
v___x_1930_ = lean_usize_add(v_i_1922_, v___x_1929_);
v___x_1931_ = lean_array_uset(v_bs_x27_1927_, v_i_1922_, v___x_1928_);
v_i_1922_ = v___x_1930_;
v_bs_1923_ = v___x_1931_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___redArg___boxed(lean_object* v_sign_1933_, lean_object* v_endpointSigns_1934_, lean_object* v_endpoint_1935_, lean_object* v_sz_1936_, lean_object* v_i_1937_, lean_object* v_bs_1938_){
_start:
{
size_t v_sz_boxed_1939_; size_t v_i_boxed_1940_; lean_object* v_res_1941_; 
v_sz_boxed_1939_ = lean_unbox_usize(v_sz_1936_);
lean_dec(v_sz_1936_);
v_i_boxed_1940_ = lean_unbox_usize(v_i_1937_);
lean_dec(v_i_1937_);
v_res_1941_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___redArg(v_sign_1933_, v_endpointSigns_1934_, v_endpoint_1935_, v_sz_boxed_1939_, v_i_boxed_1940_, v_bs_1938_);
return v_res_1941_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___redArg(lean_object* v_sign_1942_, lean_object* v_endpointSigns_1943_, lean_object* v_chain_1944_, lean_object* v_endpoint_1945_){
_start:
{
size_t v_sz_1946_; size_t v___x_1947_; lean_object* v___x_1948_; 
v_sz_1946_ = lean_array_size(v_chain_1944_);
v___x_1947_ = ((size_t)0ULL);
v___x_1948_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___redArg(v_sign_1942_, v_endpointSigns_1943_, v_endpoint_1945_, v_sz_1946_, v___x_1947_, v_chain_1944_);
return v___x_1948_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___redArg(lean_object* v_sign_1949_, lean_object* v_endpointSigns_1950_, lean_object* v_context_1951_, lean_object* v_p_1952_, lean_object* v_f_1953_, lean_object* v_a_1954_, lean_object* v_b_1955_, lean_object* v_squarefree_1956_, lean_object* v_remainders_1957_){
_start:
{
lean_object* v_chain_1958_; lean_object* v_lowerSigns_1959_; lean_object* v_upperSigns_1960_; lean_object* v___x_1961_; lean_object* v_lowerVariations_1962_; lean_object* v___x_1963_; lean_object* v_upperVariations_1964_; lean_object* v___x_1965_; lean_object* v___x_1966_; lean_object* v___x_1967_; lean_object* v___x_1968_; 
v_chain_1958_ = lean_ctor_get(v_remainders_1957_, 0);
lean_inc(v_a_1954_);
lean_inc_ref_n(v_chain_1958_, 2);
lean_inc_ref(v_endpointSigns_1950_);
lean_inc_ref(v_sign_1949_);
v_lowerSigns_1959_ = lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___redArg(v_sign_1949_, v_endpointSigns_1950_, v_chain_1958_, v_a_1954_);
lean_inc(v_b_1955_);
v_upperSigns_1960_ = lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___redArg(v_sign_1949_, v_endpointSigns_1950_, v_chain_1958_, v_b_1955_);
lean_inc_ref(v_lowerSigns_1959_);
v___x_1961_ = lean_array_to_list(v_lowerSigns_1959_);
v_lowerVariations_1962_ = lp_Hex_Hex_signVar(v___x_1961_);
lean_inc_ref(v_upperSigns_1960_);
v___x_1963_ = lean_array_to_list(v_upperSigns_1960_);
v_upperVariations_1964_ = lp_Hex_Hex_signVar(v___x_1963_);
lean_inc(v_lowerVariations_1962_);
v___x_1965_ = lean_nat_to_int(v_lowerVariations_1962_);
lean_inc(v_upperVariations_1964_);
v___x_1966_ = lean_nat_to_int(v_upperVariations_1964_);
v___x_1967_ = lean_int_sub(v___x_1965_, v___x_1966_);
lean_dec(v___x_1966_);
lean_dec(v___x_1965_);
v___x_1968_ = lean_alloc_ctor(0, 12, 0);
lean_ctor_set(v___x_1968_, 0, v_context_1951_);
lean_ctor_set(v___x_1968_, 1, v_p_1952_);
lean_ctor_set(v___x_1968_, 2, v_f_1953_);
lean_ctor_set(v___x_1968_, 3, v_a_1954_);
lean_ctor_set(v___x_1968_, 4, v_b_1955_);
lean_ctor_set(v___x_1968_, 5, v_squarefree_1956_);
lean_ctor_set(v___x_1968_, 6, v_remainders_1957_);
lean_ctor_set(v___x_1968_, 7, v_lowerSigns_1959_);
lean_ctor_set(v___x_1968_, 8, v_upperSigns_1960_);
lean_ctor_set(v___x_1968_, 9, v_lowerVariations_1962_);
lean_ctor_set(v___x_1968_, 10, v_upperVariations_1964_);
lean_ctor_set(v___x_1968_, 11, v___x_1967_);
return v___x_1968_;
}
}
static lean_object* _init_lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0(void){
_start:
{
lean_object* v___x_1969_; lean_object* v___x_1970_; 
v___x_1969_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_1970_ = lp_Hex_Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2(v___x_1969_);
return v___x_1970_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg(lean_object* v_sign_1971_, lean_object* v_endpointSigns_1972_, lean_object* v_normalize_1973_, lean_object* v_context_1974_, lean_object* v_p_1975_, lean_object* v_f_1976_, lean_object* v_a_1977_, lean_object* v_b_1978_){
_start:
{
uint8_t v___x_1979_; 
lean_inc(v_b_1978_);
lean_inc(v_a_1977_);
lean_inc_ref(v_p_1975_);
lean_inc_ref(v_endpointSigns_1972_);
v___x_1979_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___redArg(v_endpointSigns_1972_, v_p_1975_, v_a_1977_, v_b_1978_);
if (v___x_1979_ == 0)
{
lean_object* v___x_1980_; 
lean_dec(v_b_1978_);
lean_dec(v_a_1977_);
lean_dec_ref(v_f_1976_);
lean_dec_ref(v_p_1975_);
lean_dec(v_context_1974_);
lean_dec_ref(v_normalize_1973_);
lean_dec_ref(v_endpointSigns_1972_);
lean_dec_ref(v_sign_1971_);
v___x_1980_ = lean_box(0);
return v___x_1980_;
}
else
{
lean_object* v___x_1981_; lean_object* v_squarefree_1982_; uint8_t v___x_1983_; 
v___x_1981_ = lean_obj_once(&lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0, &lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0_once, _init_lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0);
lean_inc_ref(v_p_1975_);
lean_inc_ref(v_normalize_1973_);
lean_inc_ref(v_sign_1971_);
v_squarefree_1982_ = lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3(v_sign_1971_, v_normalize_1973_, v_p_1975_, v___x_1981_);
v___x_1983_ = lp_Hex_Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4(v_squarefree_1982_);
if (v___x_1983_ == 0)
{
lean_object* v___x_1984_; 
lean_dec_ref(v_squarefree_1982_);
lean_dec(v_b_1978_);
lean_dec(v_a_1977_);
lean_dec_ref(v_f_1976_);
lean_dec_ref(v_p_1975_);
lean_dec(v_context_1974_);
lean_dec_ref(v_normalize_1973_);
lean_dec_ref(v_endpointSigns_1972_);
lean_dec_ref(v_sign_1971_);
v___x_1984_ = lean_box(0);
return v___x_1984_;
}
else
{
lean_object* v___x_1985_; lean_object* v___x_1986_; lean_object* v___x_1987_; 
lean_inc_ref(v_p_1975_);
lean_inc_ref(v_sign_1971_);
v___x_1985_ = lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3(v_sign_1971_, v_normalize_1973_, v_p_1975_, v_f_1976_);
v___x_1986_ = lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___redArg(v_sign_1971_, v_endpointSigns_1972_, v_context_1974_, v_p_1975_, v_f_1976_, v_a_1977_, v_b_1978_, v_squarefree_1982_, v___x_1985_);
v___x_1987_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1987_, 0, v___x_1986_);
return v___x_1987_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0___redArg(lean_object* v_sign_1988_, lean_object* v_endpointSigns_1989_, lean_object* v_normalize_1990_, lean_object* v_p_1991_, lean_object* v_f_1992_, lean_object* v_a_1993_, lean_object* v_b_1994_){
_start:
{
lean_object* v___x_1995_; lean_object* v___x_1996_; 
v___x_1995_ = lean_box(0);
v___x_1996_ = lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg(v_sign_1988_, v_endpointSigns_1989_, v_normalize_1990_, v___x_1995_, v_p_1991_, v_f_1992_, v_a_1993_, v_b_1994_);
if (lean_obj_tag(v___x_1996_) == 0)
{
lean_object* v___x_1997_; 
v___x_1997_ = lean_box(0);
return v___x_1997_;
}
else
{
lean_object* v_val_1998_; lean_object* v___x_2000_; uint8_t v_isShared_2001_; uint8_t v_isSharedCheck_2006_; 
v_val_1998_ = lean_ctor_get(v___x_1996_, 0);
v_isSharedCheck_2006_ = !lean_is_exclusive(v___x_1996_);
if (v_isSharedCheck_2006_ == 0)
{
v___x_2000_ = v___x_1996_;
v_isShared_2001_ = v_isSharedCheck_2006_;
goto v_resetjp_1999_;
}
else
{
lean_inc(v_val_1998_);
lean_dec(v___x_1996_);
v___x_2000_ = lean_box(0);
v_isShared_2001_ = v_isSharedCheck_2006_;
goto v_resetjp_1999_;
}
v_resetjp_1999_:
{
lean_object* v_value_2002_; lean_object* v___x_2004_; 
v_value_2002_ = lean_ctor_get(v_val_1998_, 11);
lean_inc(v_value_2002_);
lean_dec(v_val_1998_);
if (v_isShared_2001_ == 0)
{
lean_ctor_set(v___x_2000_, 0, v_value_2002_);
v___x_2004_ = v___x_2000_;
goto v_reusejp_2003_;
}
else
{
lean_object* v_reuseFailAlloc_2005_; 
v_reuseFailAlloc_2005_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2005_, 0, v_value_2002_);
v___x_2004_ = v_reuseFailAlloc_2005_;
goto v_reusejp_2003_;
}
v_reusejp_2003_:
{
return v___x_2004_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_tarskiQuery(lean_object* v_p_2009_, lean_object* v_f_2010_, lean_object* v_I_2011_){
_start:
{
lean_object* v_lower_2012_; lean_object* v_upper_2013_; lean_object* v___x_2014_; lean_object* v___x_2015_; lean_object* v___x_2016_; lean_object* v___x_2017_; lean_object* v___x_2018_; lean_object* v___x_2019_; 
v_lower_2012_ = lean_ctor_get(v_I_2011_, 0);
v_upper_2013_ = lean_ctor_get(v_I_2011_, 1);
v___x_2014_ = ((lean_object*)(lp_Hex_Hex_ZPoly_tarskiQuery___closed__0));
v___x_2015_ = ((lean_object*)(lp_Hex_Hex_EndpointSigns_intDyadic));
v___x_2016_ = ((lean_object*)(lp_Hex_Hex_ZPoly_tarskiQuery___closed__1));
lean_inc(v_lower_2012_);
v___x_2017_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2017_, 0, v_lower_2012_);
lean_inc(v_upper_2013_);
v___x_2018_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2018_, 0, v_upper_2013_);
v___x_2019_ = lp_Hex_Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0___redArg(v___x_2014_, v___x_2015_, v___x_2016_, v_p_2009_, v_f_2010_, v___x_2017_, v___x_2018_);
return v___x_2019_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_tarskiQuery___boxed(lean_object* v_p_2020_, lean_object* v_f_2021_, lean_object* v_I_2022_){
_start:
{
lean_object* v_res_2023_; 
v_res_2023_ = lp_Hex_Hex_ZPoly_tarskiQuery(v_p_2020_, v_f_2021_, v_I_2022_);
lean_dec_ref(v_I_2022_);
return v_res_2023_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0(lean_object* v_E_2024_, lean_object* v_sign_2025_, lean_object* v_endpointSigns_2026_, lean_object* v_normalize_2027_, lean_object* v_p_2028_, lean_object* v_f_2029_, lean_object* v_a_2030_, lean_object* v_b_2031_){
_start:
{
lean_object* v___x_2032_; 
v___x_2032_ = lp_Hex_Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0___redArg(v_sign_2025_, v_endpointSigns_2026_, v_normalize_2027_, v_p_2028_, v_f_2029_, v_a_2030_, v_b_2031_);
return v___x_2032_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0(lean_object* v_E_2033_, lean_object* v_Ctx_2034_, lean_object* v_sign_2035_, lean_object* v_endpointSigns_2036_, lean_object* v_normalize_2037_, lean_object* v_context_2038_, lean_object* v_p_2039_, lean_object* v_f_2040_, lean_object* v_a_2041_, lean_object* v_b_2042_){
_start:
{
lean_object* v___x_2043_; 
v___x_2043_ = lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg(v_sign_2035_, v_endpointSigns_2036_, v_normalize_2037_, v_context_2038_, v_p_2039_, v_f_2040_, v_a_2041_, v_b_2042_);
return v___x_2043_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3(lean_object* v_E_2044_, lean_object* v_endpointSigns_2045_, lean_object* v_x_2046_, lean_object* v_x_2047_){
_start:
{
uint8_t v___x_2048_; 
v___x_2048_ = lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3___redArg(v_endpointSigns_2045_, v_x_2046_, v_x_2047_);
return v___x_2048_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3___boxed(lean_object* v_E_2049_, lean_object* v_endpointSigns_2050_, lean_object* v_x_2051_, lean_object* v_x_2052_){
_start:
{
uint8_t v_res_2053_; lean_object* v_r_2054_; 
v_res_2053_ = lp_Hex_Hex_Endpoint_lt___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__3(v_E_2049_, v_endpointSigns_2050_, v_x_2051_, v_x_2052_);
v_r_2054_ = lean_box(v_res_2053_);
return v_r_2054_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4(lean_object* v_E_2055_, lean_object* v_endpointSigns_2056_, lean_object* v_p_2057_, lean_object* v_x_2058_){
_start:
{
uint8_t v___x_2059_; 
v___x_2059_ = lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___redArg(v_endpointSigns_2056_, v_p_2057_, v_x_2058_);
return v___x_2059_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4___boxed(lean_object* v_E_2060_, lean_object* v_endpointSigns_2061_, lean_object* v_p_2062_, lean_object* v_x_2063_){
_start:
{
uint8_t v_res_2064_; lean_object* v_r_2065_; 
v_res_2064_ = lp_Hex_Hex_Endpoint_nonvanishing___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__4(v_E_2060_, v_endpointSigns_2061_, v_p_2062_, v_x_2063_);
v_r_2065_ = lean_box(v_res_2064_);
return v_r_2065_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1(lean_object* v_E_2066_, lean_object* v_endpointSigns_2067_, lean_object* v_p_2068_, lean_object* v_a_2069_, lean_object* v_b_2070_){
_start:
{
uint8_t v___x_2071_; 
v___x_2071_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___redArg(v_endpointSigns_2067_, v_p_2068_, v_a_2069_, v_b_2070_);
return v___x_2071_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___boxed(lean_object* v_E_2072_, lean_object* v_endpointSigns_2073_, lean_object* v_p_2074_, lean_object* v_a_2075_, lean_object* v_b_2076_){
_start:
{
uint8_t v_res_2077_; lean_object* v_r_2078_; 
v_res_2077_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1(v_E_2072_, v_endpointSigns_2073_, v_p_2074_, v_a_2075_, v_b_2076_);
v_r_2078_ = lean_box(v_res_2077_);
return v_r_2078_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__19(lean_object* v_a_2079_){
_start:
{
lean_object* v___x_2080_; 
v___x_2080_ = lean_nat_to_int(v_a_2079_);
return v___x_2080_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5(lean_object* v_E_2081_, lean_object* v_Ctx_2082_, lean_object* v_sign_2083_, lean_object* v_endpointSigns_2084_, lean_object* v_context_2085_, lean_object* v_p_2086_, lean_object* v_f_2087_, lean_object* v_a_2088_, lean_object* v_b_2089_, lean_object* v_squarefree_2090_, lean_object* v_remainders_2091_){
_start:
{
lean_object* v___x_2092_; 
v___x_2092_ = lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___redArg(v_sign_2083_, v_endpointSigns_2084_, v_context_2085_, v_p_2086_, v_f_2087_, v_a_2088_, v_b_2089_, v_squarefree_2090_, v_remainders_2091_);
return v___x_2092_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18(lean_object* v_E_2093_, lean_object* v_sign_2094_, lean_object* v_endpointSigns_2095_, lean_object* v_chain_2096_, lean_object* v_endpoint_2097_){
_start:
{
lean_object* v___x_2098_; 
v___x_2098_ = lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___redArg(v_sign_2094_, v_endpointSigns_2095_, v_chain_2096_, v_endpoint_2097_);
return v___x_2098_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27(lean_object* v_E_2099_, lean_object* v_sign_2100_, lean_object* v_endpointSigns_2101_, lean_object* v_p_2102_, lean_object* v_x_2103_){
_start:
{
lean_object* v___x_2104_; 
v___x_2104_ = lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___redArg(v_sign_2100_, v_endpointSigns_2101_, v_p_2102_, v_x_2103_);
return v___x_2104_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28(lean_object* v_E_2105_, lean_object* v_sign_2106_, lean_object* v_endpointSigns_2107_, lean_object* v_endpoint_2108_, size_t v_sz_2109_, size_t v_i_2110_, lean_object* v_bs_2111_){
_start:
{
lean_object* v___x_2112_; 
v___x_2112_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___redArg(v_sign_2106_, v_endpointSigns_2107_, v_endpoint_2108_, v_sz_2109_, v_i_2110_, v_bs_2111_);
return v___x_2112_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___boxed(lean_object* v_E_2113_, lean_object* v_sign_2114_, lean_object* v_endpointSigns_2115_, lean_object* v_endpoint_2116_, lean_object* v_sz_2117_, lean_object* v_i_2118_, lean_object* v_bs_2119_){
_start:
{
size_t v_sz_boxed_2120_; size_t v_i_boxed_2121_; lean_object* v_res_2122_; 
v_sz_boxed_2120_ = lean_unbox_usize(v_sz_2117_);
lean_dec(v_sz_2117_);
v_i_boxed_2121_ = lean_unbox_usize(v_i_2118_);
lean_dec(v_i_2118_);
v_res_2122_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28(v_E_2113_, v_sign_2114_, v_endpointSigns_2115_, v_endpoint_2116_, v_sz_boxed_2120_, v_i_boxed_2121_, v_bs_2119_);
return v_res_2122_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34(lean_object* v_b_2123_, lean_object* v_as_2124_, size_t v_i_2125_, size_t v_stop_2126_, lean_object* v_b_2127_){
_start:
{
lean_object* v___x_2128_; 
v___x_2128_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34___redArg(v_b_2123_, v_i_2125_, v_stop_2126_, v_b_2127_);
return v___x_2128_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34___boxed(lean_object* v_b_2129_, lean_object* v_as_2130_, lean_object* v_i_2131_, lean_object* v_stop_2132_, lean_object* v_b_2133_){
_start:
{
size_t v_i_boxed_2134_; size_t v_stop_boxed_2135_; lean_object* v_res_2136_; 
v_i_boxed_2134_ = lean_unbox_usize(v_i_2131_);
lean_dec(v_i_2131_);
v_stop_boxed_2135_ = lean_unbox_usize(v_stop_2132_);
lean_dec(v_stop_2132_);
v_res_2136_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_DensePoly_pseudoDivMod___at___00Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16_spec__23_spec__34(v_b_2129_, v_as_2130_, v_i_boxed_2134_, v_stop_boxed_2135_, v_b_2133_);
lean_dec_ref(v_as_2130_);
lean_dec(v_b_2129_);
return v_res_2136_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5_spec__6___redArg(lean_object* v_endpointSigns_2137_, lean_object* v_p_2138_, lean_object* v_x_2139_){
_start:
{
switch(lean_obj_tag(v_x_2139_))
{
case 0:
{
lean_object* v___x_2140_; lean_object* v___x_2141_; lean_object* v___y_2143_; lean_object* v___x_2152_; 
lean_dec_ref(v_endpointSigns_2137_);
v___x_2140_ = lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(v_p_2138_);
v___x_2141_ = lp_Hex_Hex_Int_signImpl(v___x_2140_);
lean_dec(v___x_2140_);
v___x_2152_ = lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(v_p_2138_);
lean_dec_ref(v_p_2138_);
if (lean_obj_tag(v___x_2152_) == 0)
{
lean_object* v___x_2153_; 
v___x_2153_ = lean_unsigned_to_nat(0u);
v___y_2143_ = v___x_2153_;
goto v___jp_2142_;
}
else
{
lean_object* v_val_2154_; 
v_val_2154_ = lean_ctor_get(v___x_2152_, 0);
lean_inc(v_val_2154_);
lean_dec_ref_known(v___x_2152_, 1);
v___y_2143_ = v_val_2154_;
goto v___jp_2142_;
}
v___jp_2142_:
{
lean_object* v___x_2144_; lean_object* v___x_2145_; lean_object* v___x_2146_; uint8_t v___x_2147_; 
v___x_2144_ = lean_unsigned_to_nat(2u);
v___x_2145_ = lean_nat_mod(v___y_2143_, v___x_2144_);
lean_dec(v___y_2143_);
v___x_2146_ = lean_unsigned_to_nat(1u);
v___x_2147_ = lean_nat_dec_eq(v___x_2145_, v___x_2146_);
lean_dec(v___x_2145_);
if (v___x_2147_ == 0)
{
lean_object* v___x_2148_; lean_object* v___x_2149_; 
v___x_2148_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_2149_ = lean_int_mul(v___x_2141_, v___x_2148_);
lean_dec(v___x_2141_);
return v___x_2149_;
}
else
{
lean_object* v___x_2150_; lean_object* v___x_2151_; 
v___x_2150_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__1, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__1_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__1);
v___x_2151_ = lean_int_mul(v___x_2141_, v___x_2150_);
lean_dec(v___x_2141_);
return v___x_2151_;
}
}
}
case 1:
{
lean_object* v_value_2155_; lean_object* v_evalSign_2156_; lean_object* v___x_2157_; 
v_value_2155_ = lean_ctor_get(v_x_2139_, 0);
lean_inc(v_value_2155_);
lean_dec_ref_known(v_x_2139_, 1);
v_evalSign_2156_ = lean_ctor_get(v_endpointSigns_2137_, 1);
lean_inc_ref(v_evalSign_2156_);
lean_dec_ref(v_endpointSigns_2137_);
v___x_2157_ = lean_apply_2(v_evalSign_2156_, v_p_2138_, v_value_2155_);
return v___x_2157_;
}
default: 
{
lean_object* v___x_2158_; lean_object* v___x_2159_; 
lean_dec_ref(v_endpointSigns_2137_);
v___x_2158_ = lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(v_p_2138_);
lean_dec_ref(v_p_2138_);
v___x_2159_ = lp_Hex_Hex_Int_signImpl(v___x_2158_);
lean_dec(v___x_2158_);
return v___x_2159_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5___redArg(lean_object* v_endpointSigns_2160_, lean_object* v_endpoint_2161_, size_t v_sz_2162_, size_t v_i_2163_, lean_object* v_bs_2164_){
_start:
{
uint8_t v___x_2165_; 
v___x_2165_ = lean_usize_dec_lt(v_i_2163_, v_sz_2162_);
if (v___x_2165_ == 0)
{
lean_dec(v_endpoint_2161_);
lean_dec_ref(v_endpointSigns_2160_);
return v_bs_2164_;
}
else
{
lean_object* v_v_2166_; lean_object* v___x_2167_; lean_object* v_bs_x27_2168_; lean_object* v___x_2169_; size_t v___x_2170_; size_t v___x_2171_; lean_object* v___x_2172_; 
v_v_2166_ = lean_array_uget(v_bs_2164_, v_i_2163_);
v___x_2167_ = lean_unsigned_to_nat(0u);
v_bs_x27_2168_ = lean_array_uset(v_bs_2164_, v_i_2163_, v___x_2167_);
lean_inc(v_endpoint_2161_);
lean_inc_ref(v_endpointSigns_2160_);
v___x_2169_ = lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5_spec__6___redArg(v_endpointSigns_2160_, v_v_2166_, v_endpoint_2161_);
v___x_2170_ = ((size_t)1ULL);
v___x_2171_ = lean_usize_add(v_i_2163_, v___x_2170_);
v___x_2172_ = lean_array_uset(v_bs_x27_2168_, v_i_2163_, v___x_2169_);
v_i_2163_ = v___x_2171_;
v_bs_2164_ = v___x_2172_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5___redArg___boxed(lean_object* v_endpointSigns_2174_, lean_object* v_endpoint_2175_, lean_object* v_sz_2176_, lean_object* v_i_2177_, lean_object* v_bs_2178_){
_start:
{
size_t v_sz_boxed_2179_; size_t v_i_boxed_2180_; lean_object* v_res_2181_; 
v_sz_boxed_2179_ = lean_unbox_usize(v_sz_2176_);
lean_dec(v_sz_2176_);
v_i_boxed_2180_ = lean_unbox_usize(v_i_2177_);
lean_dec(v_i_2177_);
v_res_2181_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5___redArg(v_endpointSigns_2174_, v_endpoint_2175_, v_sz_boxed_2179_, v_i_boxed_2180_, v_bs_2178_);
return v_res_2181_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4___redArg(lean_object* v_endpointSigns_2182_, lean_object* v_chain_2183_, lean_object* v_endpoint_2184_){
_start:
{
size_t v_sz_2185_; size_t v___x_2186_; lean_object* v___x_2187_; 
v_sz_2185_ = lean_array_size(v_chain_2183_);
v___x_2186_ = ((size_t)0ULL);
v___x_2187_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5___redArg(v_endpointSigns_2182_, v_endpoint_2184_, v_sz_2185_, v___x_2186_, v_chain_2183_);
return v___x_2187_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1___redArg(lean_object* v_endpointSigns_2188_, lean_object* v_context_2189_, lean_object* v_p_2190_, lean_object* v_f_2191_, lean_object* v_a_2192_, lean_object* v_b_2193_, lean_object* v_squarefree_2194_, lean_object* v_remainders_2195_){
_start:
{
lean_object* v_chain_2196_; lean_object* v_lowerSigns_2197_; lean_object* v_upperSigns_2198_; lean_object* v___x_2199_; lean_object* v_lowerVariations_2200_; lean_object* v___x_2201_; lean_object* v_upperVariations_2202_; lean_object* v___x_2203_; lean_object* v___x_2204_; lean_object* v___x_2205_; lean_object* v___x_2206_; 
v_chain_2196_ = lean_ctor_get(v_remainders_2195_, 0);
lean_inc(v_a_2192_);
lean_inc_ref_n(v_chain_2196_, 2);
lean_inc_ref(v_endpointSigns_2188_);
v_lowerSigns_2197_ = lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4___redArg(v_endpointSigns_2188_, v_chain_2196_, v_a_2192_);
lean_inc(v_b_2193_);
v_upperSigns_2198_ = lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4___redArg(v_endpointSigns_2188_, v_chain_2196_, v_b_2193_);
lean_inc_ref(v_lowerSigns_2197_);
v___x_2199_ = lean_array_to_list(v_lowerSigns_2197_);
v_lowerVariations_2200_ = lp_Hex_Hex_signVar(v___x_2199_);
lean_inc_ref(v_upperSigns_2198_);
v___x_2201_ = lean_array_to_list(v_upperSigns_2198_);
v_upperVariations_2202_ = lp_Hex_Hex_signVar(v___x_2201_);
lean_inc(v_lowerVariations_2200_);
v___x_2203_ = lean_nat_to_int(v_lowerVariations_2200_);
lean_inc(v_upperVariations_2202_);
v___x_2204_ = lean_nat_to_int(v_upperVariations_2202_);
v___x_2205_ = lean_int_sub(v___x_2203_, v___x_2204_);
lean_dec(v___x_2204_);
lean_dec(v___x_2203_);
v___x_2206_ = lean_alloc_ctor(0, 12, 0);
lean_ctor_set(v___x_2206_, 0, v_context_2189_);
lean_ctor_set(v___x_2206_, 1, v_p_2190_);
lean_ctor_set(v___x_2206_, 2, v_f_2191_);
lean_ctor_set(v___x_2206_, 3, v_a_2192_);
lean_ctor_set(v___x_2206_, 4, v_b_2193_);
lean_ctor_set(v___x_2206_, 5, v_squarefree_2194_);
lean_ctor_set(v___x_2206_, 6, v_remainders_2195_);
lean_ctor_set(v___x_2206_, 7, v_lowerSigns_2197_);
lean_ctor_set(v___x_2206_, 8, v_upperSigns_2198_);
lean_ctor_set(v___x_2206_, 9, v_lowerVariations_2200_);
lean_ctor_set(v___x_2206_, 10, v_upperVariations_2202_);
lean_ctor_set(v___x_2206_, 11, v___x_2205_);
return v___x_2206_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__1(lean_object* v_p_2207_, lean_object* v_q_2208_){
_start:
{
lean_object* v_r_2209_; uint8_t v___y_2211_; lean_object* v___x_2225_; lean_object* v___x_2226_; lean_object* v___x_2227_; lean_object* v___x_2228_; uint8_t v___x_2229_; 
lean_inc_ref(v_p_2207_);
v_r_2209_ = lp_Hex_Hex_DensePoly_pseudoDiv___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__16(v_p_2207_, v_q_2208_);
v___x_2225_ = lp_Hex_Hex_DensePoly_pseudoExponent___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__17(v_p_2207_, v_q_2208_);
lean_dec_ref(v_p_2207_);
v___x_2226_ = lean_unsigned_to_nat(2u);
v___x_2227_ = lean_nat_mod(v___x_2225_, v___x_2226_);
lean_dec(v___x_2225_);
v___x_2228_ = lean_unsigned_to_nat(1u);
v___x_2229_ = lean_nat_dec_eq(v___x_2227_, v___x_2228_);
lean_dec(v___x_2227_);
if (v___x_2229_ == 0)
{
v___y_2211_ = v___x_2229_;
goto v___jp_2210_;
}
else
{
lean_object* v___x_2230_; lean_object* v___x_2231_; lean_object* v___x_2232_; uint8_t v___x_2233_; 
v___x_2230_ = lp_Hex_Hex_DensePoly_leadingCoeff___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__18(v_q_2208_);
v___x_2231_ = lp_Hex_Hex_Int_signImpl(v___x_2230_);
lean_dec(v___x_2230_);
v___x_2232_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_2233_ = lean_int_dec_lt(v___x_2231_, v___x_2232_);
lean_dec(v___x_2231_);
v___y_2211_ = v___x_2233_;
goto v___jp_2210_;
}
v___jp_2210_:
{
if (v___y_2211_ == 0)
{
return v_r_2209_;
}
else
{
lean_object* v_multiplier_2212_; lean_object* v_quotient_2213_; lean_object* v_remainder_2214_; lean_object* v___x_2216_; uint8_t v_isShared_2217_; uint8_t v_isSharedCheck_2224_; 
v_multiplier_2212_ = lean_ctor_get(v_r_2209_, 0);
v_quotient_2213_ = lean_ctor_get(v_r_2209_, 1);
v_remainder_2214_ = lean_ctor_get(v_r_2209_, 2);
v_isSharedCheck_2224_ = !lean_is_exclusive(v_r_2209_);
if (v_isSharedCheck_2224_ == 0)
{
v___x_2216_ = v_r_2209_;
v_isShared_2217_ = v_isSharedCheck_2224_;
goto v_resetjp_2215_;
}
else
{
lean_inc(v_remainder_2214_);
lean_inc(v_quotient_2213_);
lean_inc(v_multiplier_2212_);
lean_dec(v_r_2209_);
v___x_2216_ = lean_box(0);
v_isShared_2217_ = v_isSharedCheck_2224_;
goto v_resetjp_2215_;
}
v_resetjp_2215_:
{
lean_object* v___x_2218_; lean_object* v___x_2219_; lean_object* v___x_2220_; lean_object* v___x_2222_; 
v___x_2218_ = lean_int_neg(v_multiplier_2212_);
lean_dec(v_multiplier_2212_);
v___x_2219_ = lp_Hex_Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19(v_quotient_2213_);
v___x_2220_ = lp_Hex_Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19(v_remainder_2214_);
if (v_isShared_2217_ == 0)
{
lean_ctor_set(v___x_2216_, 2, v___x_2220_);
lean_ctor_set(v___x_2216_, 1, v___x_2219_);
lean_ctor_set(v___x_2216_, 0, v___x_2218_);
v___x_2222_ = v___x_2216_;
goto v_reusejp_2221_;
}
else
{
lean_object* v_reuseFailAlloc_2223_; 
v_reuseFailAlloc_2223_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_2223_, 0, v___x_2218_);
lean_ctor_set(v_reuseFailAlloc_2223_, 1, v___x_2219_);
lean_ctor_set(v_reuseFailAlloc_2223_, 2, v___x_2220_);
v___x_2222_ = v_reuseFailAlloc_2223_;
goto v_reusejp_2221_;
}
v_reusejp_2221_:
{
return v___x_2222_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__1___boxed(lean_object* v_p_2234_, lean_object* v_q_2235_){
_start:
{
lean_object* v_res_2236_; 
v_res_2236_ = lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__1(v_p_2234_, v_q_2235_);
lean_dec_ref(v_q_2235_);
return v_res_2236_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_buildAux___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__12___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__2(lean_object* v_x_2237_, lean_object* v_x_2238_, lean_object* v_x_2239_, lean_object* v_x_2240_, lean_object* v_x_2241_){
_start:
{
lean_object* v_zero_2242_; uint8_t v_isZero_2243_; 
v_zero_2242_ = lean_unsigned_to_nat(0u);
v_isZero_2243_ = lean_nat_dec_eq(v_x_2237_, v_zero_2242_);
if (v_isZero_2243_ == 1)
{
lean_object* v___x_2244_; lean_object* v___x_2245_; lean_object* v___x_2246_; 
lean_dec_ref(v_x_2239_);
lean_dec_ref(v_x_2238_);
lean_dec(v_x_2237_);
v___x_2244_ = lean_box(0);
v___x_2245_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2245_, 0, v_x_2241_);
lean_ctor_set(v___x_2245_, 1, v___x_2244_);
v___x_2246_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2246_, 0, v_x_2240_);
lean_ctor_set(v___x_2246_, 1, v___x_2245_);
return v___x_2246_;
}
else
{
lean_object* v_r_2247_; lean_object* v_multiplier_2248_; lean_object* v_quotient_2249_; lean_object* v_remainder_2250_; lean_object* v___x_2252_; uint8_t v_isShared_2253_; uint8_t v_isSharedCheck_2271_; 
v_r_2247_ = lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__1(v_x_2238_, v_x_2239_);
v_multiplier_2248_ = lean_ctor_get(v_r_2247_, 0);
v_quotient_2249_ = lean_ctor_get(v_r_2247_, 1);
v_remainder_2250_ = lean_ctor_get(v_r_2247_, 2);
v_isSharedCheck_2271_ = !lean_is_exclusive(v_r_2247_);
if (v_isSharedCheck_2271_ == 0)
{
v___x_2252_ = v_r_2247_;
v_isShared_2253_ = v_isSharedCheck_2271_;
goto v_resetjp_2251_;
}
else
{
lean_inc(v_remainder_2250_);
lean_inc(v_quotient_2249_);
lean_inc(v_multiplier_2248_);
lean_dec(v_r_2247_);
v___x_2252_ = lean_box(0);
v_isShared_2253_ = v_isSharedCheck_2271_;
goto v_resetjp_2251_;
}
v_resetjp_2251_:
{
uint8_t v___x_2254_; 
v___x_2254_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_remainder_2250_);
if (v___x_2254_ == 0)
{
lean_object* v___x_2255_; lean_object* v_fst_2256_; lean_object* v_snd_2257_; lean_object* v_one_2258_; lean_object* v_n_2259_; lean_object* v_next_2260_; lean_object* v___x_2261_; lean_object* v___x_2263_; 
v___x_2255_ = lp_Hex_Hex_ZPoly_normalizeContent(v_remainder_2250_);
v_fst_2256_ = lean_ctor_get(v___x_2255_, 0);
lean_inc(v_fst_2256_);
v_snd_2257_ = lean_ctor_get(v___x_2255_, 1);
lean_inc(v_snd_2257_);
lean_dec_ref(v___x_2255_);
v_one_2258_ = lean_unsigned_to_nat(1u);
v_n_2259_ = lean_nat_sub(v_x_2237_, v_one_2258_);
lean_dec(v_x_2237_);
v_next_2260_ = lp_Hex_Hex_DensePoly_negImpl___at___00Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11_spec__19(v_snd_2257_);
lean_inc_ref(v_next_2260_);
v___x_2261_ = lean_array_push(v_x_2240_, v_next_2260_);
if (v_isShared_2253_ == 0)
{
lean_ctor_set(v___x_2252_, 2, v_fst_2256_);
v___x_2263_ = v___x_2252_;
goto v_reusejp_2262_;
}
else
{
lean_object* v_reuseFailAlloc_2266_; 
v_reuseFailAlloc_2266_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_2266_, 0, v_multiplier_2248_);
lean_ctor_set(v_reuseFailAlloc_2266_, 1, v_quotient_2249_);
lean_ctor_set(v_reuseFailAlloc_2266_, 2, v_fst_2256_);
v___x_2263_ = v_reuseFailAlloc_2266_;
goto v_reusejp_2262_;
}
v_reusejp_2262_:
{
lean_object* v___x_2264_; 
v___x_2264_ = lean_array_push(v_x_2241_, v___x_2263_);
v_x_2237_ = v_n_2259_;
v_x_2238_ = v_x_2239_;
v_x_2239_ = v_next_2260_;
v_x_2240_ = v___x_2261_;
v_x_2241_ = v___x_2264_;
goto _start;
}
}
else
{
lean_object* v___x_2267_; lean_object* v___x_2268_; lean_object* v___x_2269_; lean_object* v___x_2270_; 
lean_del_object(v___x_2252_);
lean_dec_ref(v_remainder_2250_);
lean_dec_ref(v_x_2239_);
lean_dec(v_x_2237_);
v___x_2267_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2267_, 0, v_multiplier_2248_);
lean_ctor_set(v___x_2267_, 1, v_quotient_2249_);
v___x_2268_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2268_, 0, v___x_2267_);
v___x_2269_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2269_, 0, v_x_2241_);
lean_ctor_set(v___x_2269_, 1, v___x_2268_);
v___x_2270_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2270_, 0, v_x_2240_);
lean_ctor_set(v___x_2270_, 1, v___x_2269_);
return v___x_2270_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0(lean_object* v_p_2272_, lean_object* v_f_2273_){
_start:
{
lean_object* v___x_2274_; lean_object* v___x_2275_; lean_object* v_r_2276_; lean_object* v_multiplier_2277_; lean_object* v_quotient_2278_; lean_object* v_remainder_2279_; lean_object* v___x_2281_; uint8_t v_isShared_2282_; uint8_t v_isSharedCheck_2324_; 
lean_inc_ref(v_p_2272_);
v___x_2274_ = lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9(v_p_2272_);
v___x_2275_ = lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10(v_f_2273_, v___x_2274_);
lean_dec_ref(v___x_2274_);
v_r_2276_ = lp_Hex_Hex_DensePoly_positivePseudoDiv___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__11___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__1(v___x_2275_, v_p_2272_);
v_multiplier_2277_ = lean_ctor_get(v_r_2276_, 0);
v_quotient_2278_ = lean_ctor_get(v_r_2276_, 1);
v_remainder_2279_ = lean_ctor_get(v_r_2276_, 2);
v_isSharedCheck_2324_ = !lean_is_exclusive(v_r_2276_);
if (v_isSharedCheck_2324_ == 0)
{
v___x_2281_ = v_r_2276_;
v_isShared_2282_ = v_isSharedCheck_2324_;
goto v_resetjp_2280_;
}
else
{
lean_inc(v_remainder_2279_);
lean_inc(v_quotient_2278_);
lean_inc(v_multiplier_2277_);
lean_dec(v_r_2276_);
v___x_2281_ = lean_box(0);
v_isShared_2282_ = v_isSharedCheck_2324_;
goto v_resetjp_2280_;
}
v_resetjp_2280_:
{
lean_object* v___x_2283_; uint8_t v___x_2284_; 
v___x_2283_ = lean_unsigned_to_nat(0u);
v___x_2284_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_remainder_2279_);
if (v___x_2284_ == 0)
{
lean_object* v___x_2285_; lean_object* v_fst_2286_; lean_object* v_snd_2287_; lean_object* v___y_2289_; lean_object* v___x_2307_; 
v___x_2285_ = lp_Hex_Hex_ZPoly_normalizeContent(v_remainder_2279_);
v_fst_2286_ = lean_ctor_get(v___x_2285_, 0);
lean_inc(v_fst_2286_);
v_snd_2287_ = lean_ctor_get(v___x_2285_, 1);
lean_inc(v_snd_2287_);
lean_dec_ref(v___x_2285_);
v___x_2307_ = lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(v_p_2272_);
if (lean_obj_tag(v___x_2307_) == 0)
{
v___y_2289_ = v___x_2283_;
goto v___jp_2288_;
}
else
{
lean_object* v_val_2308_; 
v_val_2308_ = lean_ctor_get(v___x_2307_, 0);
lean_inc(v_val_2308_);
lean_dec_ref_known(v___x_2307_, 1);
v___y_2289_ = v_val_2308_;
goto v___jp_2288_;
}
v___jp_2288_:
{
lean_object* v___x_2290_; lean_object* v___x_2291_; lean_object* v___x_2292_; lean_object* v___x_2293_; lean_object* v___x_2294_; lean_object* v_result_2295_; lean_object* v_snd_2296_; lean_object* v_fst_2297_; lean_object* v_fst_2298_; lean_object* v_snd_2299_; size_t v_sz_2300_; size_t v___x_2301_; lean_object* v___x_2302_; lean_object* v___x_2304_; 
v___x_2290_ = lean_unsigned_to_nat(2u);
v___x_2291_ = lean_mk_empty_array_with_capacity(v___x_2290_);
lean_inc_ref(v_p_2272_);
v___x_2292_ = lean_array_push(v___x_2291_, v_p_2272_);
lean_inc(v_snd_2287_);
v___x_2293_ = lean_array_push(v___x_2292_, v_snd_2287_);
v___x_2294_ = ((lean_object*)(lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___closed__0));
v_result_2295_ = lp_Hex_Hex_SignedRemainderChain_buildAux___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__12___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0_spec__2(v___y_2289_, v_p_2272_, v_snd_2287_, v___x_2293_, v___x_2294_);
v_snd_2296_ = lean_ctor_get(v_result_2295_, 1);
lean_inc(v_snd_2296_);
v_fst_2297_ = lean_ctor_get(v_result_2295_, 0);
lean_inc_n(v_fst_2297_, 2);
lean_dec_ref(v_result_2295_);
v_fst_2298_ = lean_ctor_get(v_snd_2296_, 0);
lean_inc(v_fst_2298_);
v_snd_2299_ = lean_ctor_get(v_snd_2296_, 1);
lean_inc(v_snd_2299_);
lean_dec(v_snd_2296_);
v_sz_2300_ = lean_array_size(v_fst_2297_);
v___x_2301_ = ((size_t)0ULL);
v___x_2302_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__13(v_sz_2300_, v___x_2301_, v_fst_2297_);
if (v_isShared_2282_ == 0)
{
lean_ctor_set(v___x_2281_, 2, v_fst_2286_);
v___x_2304_ = v___x_2281_;
goto v_reusejp_2303_;
}
else
{
lean_object* v_reuseFailAlloc_2306_; 
v_reuseFailAlloc_2306_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_2306_, 0, v_multiplier_2277_);
lean_ctor_set(v_reuseFailAlloc_2306_, 1, v_quotient_2278_);
lean_ctor_set(v_reuseFailAlloc_2306_, 2, v_fst_2286_);
v___x_2304_ = v_reuseFailAlloc_2306_;
goto v_reusejp_2303_;
}
v_reusejp_2303_:
{
lean_object* v___x_2305_; 
v___x_2305_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_2305_, 0, v_fst_2297_);
lean_ctor_set(v___x_2305_, 1, v___x_2302_);
lean_ctor_set(v___x_2305_, 2, v___x_2304_);
lean_ctor_set(v___x_2305_, 3, v_fst_2298_);
lean_ctor_set(v___x_2305_, 4, v_snd_2299_);
return v___x_2305_;
}
}
}
else
{
lean_object* v___x_2309_; lean_object* v___x_2310_; lean_object* v___x_2311_; lean_object* v___y_2313_; lean_object* v___x_2322_; 
lean_dec_ref(v_remainder_2279_);
v___x_2309_ = lean_unsigned_to_nat(1u);
v___x_2310_ = lean_mk_empty_array_with_capacity(v___x_2309_);
lean_inc_ref(v_p_2272_);
lean_inc_ref(v___x_2310_);
v___x_2311_ = lean_array_push(v___x_2310_, v_p_2272_);
v___x_2322_ = lp_Hex_Hex_DensePoly_degree_x3f___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__8(v_p_2272_);
lean_dec_ref(v_p_2272_);
if (lean_obj_tag(v___x_2322_) == 0)
{
v___y_2313_ = v___x_2283_;
goto v___jp_2312_;
}
else
{
lean_object* v_val_2323_; 
v_val_2323_ = lean_ctor_get(v___x_2322_, 0);
lean_inc(v_val_2323_);
lean_dec_ref_known(v___x_2322_, 1);
v___y_2313_ = v_val_2323_;
goto v___jp_2312_;
}
v___jp_2312_:
{
lean_object* v___x_2314_; lean_object* v___x_2315_; lean_object* v___x_2317_; 
v___x_2314_ = lean_array_push(v___x_2310_, v___y_2313_);
v___x_2315_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
if (v_isShared_2282_ == 0)
{
lean_ctor_set(v___x_2281_, 2, v___x_2315_);
v___x_2317_ = v___x_2281_;
goto v_reusejp_2316_;
}
else
{
lean_object* v_reuseFailAlloc_2321_; 
v_reuseFailAlloc_2321_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_2321_, 0, v_multiplier_2277_);
lean_ctor_set(v_reuseFailAlloc_2321_, 1, v_quotient_2278_);
lean_ctor_set(v_reuseFailAlloc_2321_, 2, v___x_2315_);
v___x_2317_ = v_reuseFailAlloc_2321_;
goto v_reusejp_2316_;
}
v_reusejp_2316_:
{
lean_object* v___x_2318_; lean_object* v___x_2319_; lean_object* v___x_2320_; 
v___x_2318_ = ((lean_object*)(lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___closed__0));
v___x_2319_ = lean_box(0);
v___x_2320_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_2320_, 0, v___x_2311_);
lean_ctor_set(v___x_2320_, 1, v___x_2314_);
lean_ctor_set(v___x_2320_, 2, v___x_2317_);
lean_ctor_set(v___x_2320_, 3, v___x_2318_);
lean_ctor_set(v___x_2320_, 4, v___x_2319_);
return v___x_2320_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0___boxed(lean_object* v_p_2325_, lean_object* v_f_2326_){
_start:
{
lean_object* v_res_2327_; 
v_res_2327_ = lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0(v_p_2325_, v_f_2326_);
lean_dec_ref(v_f_2326_);
return v_res_2327_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0___redArg(lean_object* v_endpointSigns_2328_, lean_object* v_context_2329_, lean_object* v_p_2330_, lean_object* v_f_2331_, lean_object* v_a_2332_, lean_object* v_b_2333_){
_start:
{
uint8_t v___x_2334_; 
lean_inc(v_b_2333_);
lean_inc(v_a_2332_);
lean_inc_ref(v_p_2330_);
lean_inc_ref(v_endpointSigns_2328_);
v___x_2334_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___redArg(v_endpointSigns_2328_, v_p_2330_, v_a_2332_, v_b_2333_);
if (v___x_2334_ == 0)
{
lean_object* v___x_2335_; 
lean_dec(v_b_2333_);
lean_dec(v_a_2332_);
lean_dec_ref(v_f_2331_);
lean_dec_ref(v_p_2330_);
lean_dec(v_context_2329_);
lean_dec_ref(v_endpointSigns_2328_);
v___x_2335_ = lean_box(0);
return v___x_2335_;
}
else
{
lean_object* v___x_2336_; lean_object* v_squarefree_2337_; uint8_t v___x_2338_; 
v___x_2336_ = lean_obj_once(&lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0, &lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0_once, _init_lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0);
lean_inc_ref(v_p_2330_);
v_squarefree_2337_ = lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0(v_p_2330_, v___x_2336_);
v___x_2338_ = lp_Hex_Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4(v_squarefree_2337_);
if (v___x_2338_ == 0)
{
lean_object* v___x_2339_; 
lean_dec_ref(v_squarefree_2337_);
lean_dec(v_b_2333_);
lean_dec(v_a_2332_);
lean_dec_ref(v_f_2331_);
lean_dec_ref(v_p_2330_);
lean_dec(v_context_2329_);
lean_dec_ref(v_endpointSigns_2328_);
v___x_2339_ = lean_box(0);
return v___x_2339_;
}
else
{
lean_object* v___x_2340_; lean_object* v___x_2341_; lean_object* v___x_2342_; 
lean_inc_ref(v_p_2330_);
v___x_2340_ = lp_Hex_Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__0(v_p_2330_, v_f_2331_);
v___x_2341_ = lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1___redArg(v_endpointSigns_2328_, v_context_2329_, v_p_2330_, v_f_2331_, v_a_2332_, v_b_2333_, v_squarefree_2337_, v___x_2340_);
v___x_2342_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2342_, 0, v___x_2341_);
return v___x_2342_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_IntTarskiCertificate_certify(lean_object* v_p_2343_, lean_object* v_f_2344_, lean_object* v_I_2345_){
_start:
{
lean_object* v_lower_2346_; lean_object* v_upper_2347_; lean_object* v___x_2348_; lean_object* v___x_2349_; lean_object* v___x_2350_; lean_object* v___x_2351_; lean_object* v___x_2352_; 
v_lower_2346_ = lean_ctor_get(v_I_2345_, 0);
v_upper_2347_ = lean_ctor_get(v_I_2345_, 1);
v___x_2348_ = ((lean_object*)(lp_Hex_Hex_EndpointSigns_intDyadic));
v___x_2349_ = lean_box(0);
lean_inc(v_lower_2346_);
v___x_2350_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2350_, 0, v_lower_2346_);
lean_inc(v_upper_2347_);
v___x_2351_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2351_, 0, v_upper_2347_);
v___x_2352_ = lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0___redArg(v___x_2348_, v___x_2349_, v_p_2343_, v_f_2344_, v___x_2350_, v___x_2351_);
return v___x_2352_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_IntTarskiCertificate_certify___boxed(lean_object* v_p_2353_, lean_object* v_f_2354_, lean_object* v_I_2355_){
_start:
{
lean_object* v_res_2356_; 
v_res_2356_ = lp_Hex_Hex_IntTarskiCertificate_certify(v_p_2353_, v_f_2354_, v_I_2355_);
lean_dec_ref(v_I_2355_);
return v_res_2356_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0(lean_object* v_E_2357_, lean_object* v_Ctx_2358_, lean_object* v_endpointSigns_2359_, lean_object* v_context_2360_, lean_object* v_p_2361_, lean_object* v_f_2362_, lean_object* v_a_2363_, lean_object* v_b_2364_){
_start:
{
lean_object* v___x_2365_; 
v___x_2365_ = lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0___redArg(v_endpointSigns_2359_, v_context_2360_, v_p_2361_, v_f_2362_, v_a_2363_, v_b_2364_);
return v___x_2365_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1(lean_object* v_E_2366_, lean_object* v_Ctx_2367_, lean_object* v_endpointSigns_2368_, lean_object* v_context_2369_, lean_object* v_p_2370_, lean_object* v_f_2371_, lean_object* v_a_2372_, lean_object* v_b_2373_, lean_object* v_squarefree_2374_, lean_object* v_remainders_2375_){
_start:
{
lean_object* v___x_2376_; 
v___x_2376_ = lp_Hex_Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1___redArg(v_endpointSigns_2368_, v_context_2369_, v_p_2370_, v_f_2371_, v_a_2372_, v_b_2373_, v_squarefree_2374_, v_remainders_2375_);
return v___x_2376_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4(lean_object* v_E_2377_, lean_object* v_endpointSigns_2378_, lean_object* v_chain_2379_, lean_object* v_endpoint_2380_){
_start:
{
lean_object* v___x_2381_; 
v___x_2381_ = lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4___redArg(v_endpointSigns_2378_, v_chain_2379_, v_endpoint_2380_);
return v___x_2381_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5_spec__6(lean_object* v_E_2382_, lean_object* v_endpointSigns_2383_, lean_object* v_p_2384_, lean_object* v_x_2385_){
_start:
{
lean_object* v___x_2386_; 
v___x_2386_ = lp_Hex_Hex_Endpoint_signAt___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__27___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5_spec__6___redArg(v_endpointSigns_2383_, v_p_2384_, v_x_2385_);
return v___x_2386_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5(lean_object* v_E_2387_, lean_object* v_endpointSigns_2388_, lean_object* v_endpoint_2389_, size_t v_sz_2390_, size_t v_i_2391_, lean_object* v_bs_2392_){
_start:
{
lean_object* v___x_2393_; 
v___x_2393_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5___redArg(v_endpointSigns_2388_, v_endpoint_2389_, v_sz_2390_, v_i_2391_, v_bs_2392_);
return v___x_2393_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5___boxed(lean_object* v_E_2394_, lean_object* v_endpointSigns_2395_, lean_object* v_endpoint_2396_, lean_object* v_sz_2397_, lean_object* v_i_2398_, lean_object* v_bs_2399_){
_start:
{
size_t v_sz_boxed_2400_; size_t v_i_boxed_2401_; lean_object* v_res_2402_; 
v_sz_boxed_2400_ = lean_unbox_usize(v_sz_2397_);
lean_dec(v_sz_2397_);
v_i_boxed_2401_ = lean_unbox_usize(v_i_2398_);
lean_dec(v_i_2398_);
v_res_2402_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18_spec__28___at___00Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___at___00Hex_IntTarskiCertificate_certify_spec__0_spec__1_spec__4_spec__5(v_E_2394_, v_endpointSigns_2395_, v_endpoint_2396_, v_sz_boxed_2400_, v_i_boxed_2401_, v_bs_2399_);
return v_res_2402_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3___redArg(lean_object* v_xs_2403_, lean_object* v_ys_2404_, lean_object* v_x_2405_){
_start:
{
lean_object* v_zero_2406_; uint8_t v_isZero_2407_; 
v_zero_2406_ = lean_unsigned_to_nat(0u);
v_isZero_2407_ = lean_nat_dec_eq(v_x_2405_, v_zero_2406_);
if (v_isZero_2407_ == 1)
{
lean_dec(v_x_2405_);
return v_isZero_2407_;
}
else
{
lean_object* v_one_2408_; lean_object* v_n_2409_; lean_object* v___x_2410_; lean_object* v___x_2411_; uint8_t v___x_2412_; 
v_one_2408_ = lean_unsigned_to_nat(1u);
v_n_2409_ = lean_nat_sub(v_x_2405_, v_one_2408_);
lean_dec(v_x_2405_);
v___x_2410_ = lean_array_fget_borrowed(v_xs_2403_, v_n_2409_);
v___x_2411_ = lean_array_fget_borrowed(v_ys_2404_, v_n_2409_);
v___x_2412_ = lean_int_dec_eq(v___x_2410_, v___x_2411_);
if (v___x_2412_ == 0)
{
lean_dec(v_n_2409_);
return v___x_2412_;
}
else
{
v_x_2405_ = v_n_2409_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3___redArg___boxed(lean_object* v_xs_2414_, lean_object* v_ys_2415_, lean_object* v_x_2416_){
_start:
{
uint8_t v_res_2417_; lean_object* v_r_2418_; 
v_res_2417_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3___redArg(v_xs_2414_, v_ys_2415_, v_x_2416_);
lean_dec_ref(v_ys_2415_);
lean_dec_ref(v_xs_2414_);
v_r_2418_ = lean_box(v_res_2417_);
return v_r_2418_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2(lean_object* v_xs_2419_, lean_object* v_ys_2420_){
_start:
{
lean_object* v___x_2421_; lean_object* v___x_2422_; uint8_t v___x_2423_; 
v___x_2421_ = lean_array_get_size(v_xs_2419_);
v___x_2422_ = lean_array_get_size(v_ys_2420_);
v___x_2423_ = lean_nat_dec_eq(v___x_2421_, v___x_2422_);
if (v___x_2423_ == 0)
{
return v___x_2423_;
}
else
{
uint8_t v___x_2424_; 
v___x_2424_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3___redArg(v_xs_2419_, v_ys_2420_, v___x_2421_);
return v___x_2424_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2___boxed(lean_object* v_xs_2425_, lean_object* v_ys_2426_){
_start:
{
uint8_t v_res_2427_; lean_object* v_r_2428_; 
v_res_2427_ = lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2(v_xs_2425_, v_ys_2426_);
lean_dec_ref(v_ys_2426_);
lean_dec_ref(v_xs_2425_);
v_r_2428_ = lean_box(v_res_2427_);
return v_r_2428_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5_spec__8(lean_object* v_c_2429_, size_t v_sz_2430_, size_t v_i_2431_, lean_object* v_bs_2432_){
_start:
{
uint8_t v___x_2433_; 
v___x_2433_ = lean_usize_dec_lt(v_i_2431_, v_sz_2430_);
if (v___x_2433_ == 0)
{
return v_bs_2432_;
}
else
{
lean_object* v_v_2434_; lean_object* v___x_2435_; lean_object* v_bs_x27_2436_; lean_object* v___x_2437_; size_t v___x_2438_; size_t v___x_2439_; lean_object* v___x_2440_; 
v_v_2434_ = lean_array_uget(v_bs_2432_, v_i_2431_);
v___x_2435_ = lean_unsigned_to_nat(0u);
v_bs_x27_2436_ = lean_array_uset(v_bs_2432_, v_i_2431_, v___x_2435_);
v___x_2437_ = lean_int_mul(v_c_2429_, v_v_2434_);
lean_dec(v_v_2434_);
v___x_2438_ = ((size_t)1ULL);
v___x_2439_ = lean_usize_add(v_i_2431_, v___x_2438_);
v___x_2440_ = lean_array_uset(v_bs_x27_2436_, v_i_2431_, v___x_2437_);
v_i_2431_ = v___x_2439_;
v_bs_2432_ = v___x_2440_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5_spec__8___boxed(lean_object* v_c_2442_, lean_object* v_sz_2443_, lean_object* v_i_2444_, lean_object* v_bs_2445_){
_start:
{
size_t v_sz_boxed_2446_; size_t v_i_boxed_2447_; lean_object* v_res_2448_; 
v_sz_boxed_2446_ = lean_unbox_usize(v_sz_2443_);
lean_dec(v_sz_2443_);
v_i_boxed_2447_ = lean_unbox_usize(v_i_2444_);
lean_dec(v_i_2444_);
v_res_2448_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5_spec__8(v_c_2442_, v_sz_boxed_2446_, v_i_boxed_2447_, v_bs_2445_);
lean_dec(v_c_2442_);
return v_res_2448_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5(lean_object* v_c_2449_, lean_object* v_p_2450_){
_start:
{
size_t v_sz_2451_; size_t v___x_2452_; lean_object* v___x_2453_; lean_object* v___x_2454_; 
v_sz_2451_ = lean_array_size(v_p_2450_);
v___x_2452_ = ((size_t)0ULL);
v___x_2453_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5_spec__8(v_c_2449_, v_sz_2451_, v___x_2452_, v_p_2450_);
v___x_2454_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v___x_2453_);
return v___x_2454_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5___boxed(lean_object* v_c_2455_, lean_object* v_p_2456_){
_start:
{
lean_object* v_res_2457_; 
v_res_2457_ = lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5(v_c_2455_, v_p_2456_);
lean_dec(v_c_2455_);
return v_res_2457_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1_spec__5(lean_object* v_a_2458_, lean_object* v_b_2459_){
_start:
{
uint8_t v_decide_2460_; 
v_decide_2460_ = lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2(v_a_2458_, v_b_2459_);
return v_decide_2460_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1_spec__5___boxed(lean_object* v_a_2461_, lean_object* v_b_2462_){
_start:
{
uint8_t v_res_2463_; lean_object* v_r_2464_; 
v_res_2463_ = lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1_spec__5(v_a_2461_, v_b_2462_);
lean_dec_ref(v_b_2462_);
lean_dec_ref(v_a_2461_);
v_r_2464_ = lean_box(v_res_2463_);
return v_r_2464_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__10(uint8_t v___y_2465_, lean_object* v_n_2466_, lean_object* v___x_2467_, lean_object* v_as_2468_, size_t v_i_2469_, size_t v_stop_2470_){
_start:
{
uint8_t v___x_2475_; 
v___x_2475_ = lean_usize_dec_eq(v_i_2469_, v_stop_2470_);
if (v___x_2475_ == 0)
{
lean_object* v___x_2476_; uint8_t v___x_2477_; lean_object* v___y_2479_; lean_object* v___y_2480_; lean_object* v___x_2483_; lean_object* v___x_2484_; lean_object* v___x_2485_; lean_object* v___y_2487_; uint8_t v___x_2491_; 
v___x_2476_ = lean_unsigned_to_nat(1u);
v___x_2477_ = 1;
v___x_2483_ = lean_array_uget_borrowed(v_as_2468_, v_i_2469_);
v___x_2484_ = lean_nat_add(v___x_2483_, v___x_2476_);
v___x_2485_ = lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
v___x_2491_ = lean_nat_dec_lt(v___x_2484_, v_n_2466_);
if (v___x_2491_ == 0)
{
lean_dec(v___x_2484_);
v___y_2487_ = v___x_2485_;
goto v___jp_2486_;
}
else
{
lean_object* v___x_2492_; 
v___x_2492_ = lean_array_fget_borrowed(v___x_2467_, v___x_2484_);
lean_dec(v___x_2484_);
v___y_2487_ = v___x_2492_;
goto v___jp_2486_;
}
v___jp_2478_:
{
lean_object* v___x_2481_; uint8_t v___x_2482_; 
v___x_2481_ = lean_array_get_size(v___y_2480_);
v___x_2482_ = lean_nat_dec_lt(v___y_2479_, v___x_2481_);
lean_dec(v___y_2479_);
if (v___x_2482_ == 0)
{
if (v___y_2465_ == 0)
{
goto v___jp_2471_;
}
else
{
return v___x_2477_;
}
}
else
{
goto v___jp_2471_;
}
}
v___jp_2486_:
{
lean_object* v___x_2488_; uint8_t v___x_2489_; 
v___x_2488_ = lean_array_get_size(v___y_2487_);
v___x_2489_ = lean_nat_dec_lt(v___x_2483_, v_n_2466_);
if (v___x_2489_ == 0)
{
v___y_2479_ = v___x_2488_;
v___y_2480_ = v___x_2485_;
goto v___jp_2478_;
}
else
{
lean_object* v___x_2490_; 
v___x_2490_ = lean_array_fget_borrowed(v___x_2467_, v___x_2483_);
v___y_2479_ = v___x_2488_;
v___y_2480_ = v___x_2490_;
goto v___jp_2478_;
}
}
}
else
{
uint8_t v___x_2493_; 
v___x_2493_ = 0;
return v___x_2493_;
}
v___jp_2471_:
{
size_t v___x_2472_; size_t v___x_2473_; 
v___x_2472_ = ((size_t)1ULL);
v___x_2473_ = lean_usize_add(v_i_2469_, v___x_2472_);
v_i_2469_ = v___x_2473_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__10___boxed(lean_object* v___y_2494_, lean_object* v_n_2495_, lean_object* v___x_2496_, lean_object* v_as_2497_, lean_object* v_i_2498_, lean_object* v_stop_2499_){
_start:
{
uint8_t v___y_2894__boxed_2500_; size_t v_i_boxed_2501_; size_t v_stop_boxed_2502_; uint8_t v_res_2503_; lean_object* v_r_2504_; 
v___y_2894__boxed_2500_ = lean_unbox(v___y_2494_);
v_i_boxed_2501_ = lean_unbox_usize(v_i_2498_);
lean_dec(v_i_2498_);
v_stop_boxed_2502_ = lean_unbox_usize(v_stop_2499_);
lean_dec(v_stop_2499_);
v_res_2503_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__10(v___y_2894__boxed_2500_, v_n_2495_, v___x_2496_, v_as_2497_, v_i_boxed_2501_, v_stop_boxed_2502_);
lean_dec_ref(v_as_2497_);
lean_dec_ref(v___x_2496_);
lean_dec(v_n_2495_);
v_r_2504_ = lean_box(v_res_2503_);
return v_r_2504_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11___lam__0(lean_object* v_p_2505_, lean_object* v_q_2506_, lean_object* v_i_2507_){
_start:
{
lean_object* v___x_2508_; lean_object* v___x_2509_; lean_object* v___x_2510_; 
v___x_2508_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_p_2505_, v_i_2507_);
v___x_2509_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_q_2506_, v_i_2507_);
v___x_2510_ = lean_int_sub(v___x_2508_, v___x_2509_);
lean_dec(v___x_2509_);
lean_dec(v___x_2508_);
return v___x_2510_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11___lam__0___boxed(lean_object* v_p_2511_, lean_object* v_q_2512_, lean_object* v_i_2513_){
_start:
{
lean_object* v_res_2514_; 
v_res_2514_ = lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11___lam__0(v_p_2511_, v_q_2512_, v_i_2513_);
lean_dec(v_i_2513_);
lean_dec_ref(v_q_2512_);
lean_dec_ref(v_p_2511_);
return v_res_2514_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11(lean_object* v_p_2515_, lean_object* v_q_2516_){
_start:
{
lean_object* v___f_2517_; lean_object* v___y_2519_; lean_object* v___x_2522_; lean_object* v___x_2523_; uint8_t v___x_2524_; 
lean_inc_ref(v_q_2516_);
lean_inc_ref(v_p_2515_);
v___f_2517_ = lean_alloc_closure((void*)(lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11___lam__0___boxed), 3, 2);
lean_closure_set(v___f_2517_, 0, v_p_2515_);
lean_closure_set(v___f_2517_, 1, v_q_2516_);
v___x_2522_ = lean_array_get_size(v_p_2515_);
lean_dec_ref(v_p_2515_);
v___x_2523_ = lean_array_get_size(v_q_2516_);
lean_dec_ref(v_q_2516_);
v___x_2524_ = lean_nat_dec_le(v___x_2522_, v___x_2523_);
if (v___x_2524_ == 0)
{
v___y_2519_ = v___x_2522_;
goto v___jp_2518_;
}
else
{
v___y_2519_ = v___x_2523_;
goto v___jp_2518_;
}
v___jp_2518_:
{
lean_object* v___x_2520_; lean_object* v___x_2521_; 
v___x_2520_ = l_Array_ofFn___redArg(v___y_2519_, v___f_2517_);
v___x_2521_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v___x_2520_);
return v___x_2521_;
}
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7(lean_object* v_p_2525_, lean_object* v_q_2526_){
_start:
{
lean_object* v___x_2527_; uint8_t v___x_2528_; 
v___x_2527_ = lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11(v_p_2525_, v_q_2526_);
v___x_2528_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v___x_2527_);
lean_dec_ref(v___x_2527_);
return v___x_2528_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7___boxed(lean_object* v_p_2529_, lean_object* v_q_2530_){
_start:
{
uint8_t v_res_2531_; lean_object* v_r_2532_; 
v_res_2531_ = lp_Hex_Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7(v_p_2529_, v_q_2530_);
v_r_2532_ = lean_box(v_res_2531_);
return v_r_2532_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_checkStep___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__8(lean_object* v_sign_2533_, lean_object* v_a_2534_, lean_object* v_b_2535_, lean_object* v_c_2536_, lean_object* v_s_2537_){
_start:
{
lean_object* v_leftScale_2538_; lean_object* v_quotient_2539_; lean_object* v_rightScale_2540_; lean_object* v___x_2541_; lean_object* v___x_2542_; uint8_t v___x_2543_; 
v_leftScale_2538_ = lean_ctor_get(v_s_2537_, 0);
lean_inc_n(v_leftScale_2538_, 2);
v_quotient_2539_ = lean_ctor_get(v_s_2537_, 1);
lean_inc_ref(v_quotient_2539_);
v_rightScale_2540_ = lean_ctor_get(v_s_2537_, 2);
lean_inc(v_rightScale_2540_);
lean_dec_ref(v_s_2537_);
lean_inc_ref(v_sign_2533_);
v___x_2541_ = lean_apply_1(v_sign_2533_, v_leftScale_2538_);
v___x_2542_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_2543_ = lean_int_dec_eq(v___x_2541_, v___x_2542_);
lean_dec(v___x_2541_);
if (v___x_2543_ == 0)
{
lean_dec(v_rightScale_2540_);
lean_dec_ref(v_quotient_2539_);
lean_dec(v_leftScale_2538_);
lean_dec_ref(v_c_2536_);
lean_dec_ref(v_a_2534_);
lean_dec_ref(v_sign_2533_);
return v___x_2543_;
}
else
{
lean_object* v___x_2544_; uint8_t v___x_2545_; 
lean_inc(v_rightScale_2540_);
v___x_2544_ = lean_apply_1(v_sign_2533_, v_rightScale_2540_);
v___x_2545_ = lean_int_dec_eq(v___x_2544_, v___x_2542_);
lean_dec(v___x_2544_);
if (v___x_2545_ == 0)
{
lean_dec(v_rightScale_2540_);
lean_dec_ref(v_quotient_2539_);
lean_dec(v_leftScale_2538_);
lean_dec_ref(v_c_2536_);
lean_dec_ref(v_a_2534_);
return v___x_2545_;
}
else
{
lean_object* v___x_2546_; lean_object* v___x_2547_; lean_object* v___x_2548_; lean_object* v___x_2549_; uint8_t v___x_2550_; 
v___x_2546_ = lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5(v_leftScale_2538_, v_a_2534_);
lean_dec(v_leftScale_2538_);
v___x_2547_ = lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10(v_quotient_2539_, v_b_2535_);
lean_dec_ref(v_quotient_2539_);
v___x_2548_ = lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5(v_rightScale_2540_, v_c_2536_);
lean_dec(v_rightScale_2540_);
v___x_2549_ = lp_Hex_Hex_DensePoly_subImpl___at___00Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7_spec__11(v___x_2547_, v___x_2548_);
v___x_2550_ = lp_Hex_Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7(v___x_2546_, v___x_2549_);
return v___x_2550_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_checkStep___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__8___boxed(lean_object* v_sign_2551_, lean_object* v_a_2552_, lean_object* v_b_2553_, lean_object* v_c_2554_, lean_object* v_s_2555_){
_start:
{
uint8_t v_res_2556_; lean_object* v_r_2557_; 
v_res_2556_ = lp_Hex_Hex_SignedRemainderChain_checkStep___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__8(v_sign_2551_, v_a_2552_, v_b_2553_, v_c_2554_, v_s_2555_);
lean_dec_ref(v_b_2553_);
v_r_2557_ = lean_box(v_res_2556_);
return v_r_2557_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9___closed__0(void){
_start:
{
lean_object* v___x_2558_; lean_object* v___x_2559_; lean_object* v___x_2560_; 
v___x_2558_ = lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
v___x_2559_ = lean_obj_once(&lp_Hex_Hex_Endpoint_lt___redArg___closed__0, &lp_Hex_Hex_Endpoint_lt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_lt___redArg___closed__0);
v___x_2560_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2560_, 0, v___x_2559_);
lean_ctor_set(v___x_2560_, 1, v___x_2558_);
lean_ctor_set(v___x_2560_, 2, v___x_2559_);
return v___x_2560_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9(lean_object* v___x_2561_, lean_object* v_sign_2562_, lean_object* v___x_2563_, lean_object* v_n_2564_, lean_object* v___x_2565_, lean_object* v___x_2566_, lean_object* v_as_2567_, size_t v_i_2568_, size_t v_stop_2569_){
_start:
{
uint8_t v___x_2570_; 
v___x_2570_ = lean_usize_dec_eq(v_i_2568_, v_stop_2569_);
if (v___x_2570_ == 0)
{
uint8_t v___x_2571_; lean_object* v___x_2572_; uint8_t v___x_2573_; lean_object* v___x_2574_; uint8_t v___x_2575_; uint8_t v___y_2577_; lean_object* v___x_2581_; lean_object* v___x_2582_; lean_object* v___y_2584_; lean_object* v___y_2585_; lean_object* v___y_2586_; lean_object* v___y_2593_; lean_object* v___y_2594_; lean_object* v___y_2599_; uint8_t v___x_2603_; 
v___x_2571_ = lean_nat_dec_eq(v___x_2563_, v_n_2564_);
v___x_2572_ = lean_unsigned_to_nat(1u);
v___x_2573_ = lean_nat_dec_eq(v_n_2564_, v___x_2572_);
v___x_2574_ = lean_unsigned_to_nat(2u);
v___x_2575_ = 1;
v___x_2581_ = lean_array_uget_borrowed(v_as_2567_, v_i_2568_);
v___x_2582_ = lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
v___x_2603_ = lean_nat_dec_lt(v___x_2581_, v_n_2564_);
if (v___x_2603_ == 0)
{
v___y_2599_ = v___x_2582_;
goto v___jp_2598_;
}
else
{
lean_object* v___x_2604_; 
v___x_2604_ = lean_array_fget_borrowed(v___x_2566_, v___x_2581_);
lean_inc(v___x_2604_);
v___y_2599_ = v___x_2604_;
goto v___jp_2598_;
}
v___jp_2576_:
{
if (v___y_2577_ == 0)
{
size_t v___x_2578_; size_t v___x_2579_; 
v___x_2578_ = ((size_t)1ULL);
v___x_2579_ = lean_usize_add(v_i_2568_, v___x_2578_);
v_i_2568_ = v___x_2579_;
goto _start;
}
else
{
lean_dec_ref(v_sign_2562_);
return v___x_2575_;
}
}
v___jp_2583_:
{
lean_object* v___x_2587_; uint8_t v___x_2588_; 
v___x_2587_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9___closed__0, &lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9___closed__0_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9___closed__0);
v___x_2588_ = lean_nat_dec_lt(v___x_2581_, v___x_2561_);
if (v___x_2588_ == 0)
{
uint8_t v___x_2589_; 
lean_inc_ref(v_sign_2562_);
v___x_2589_ = lp_Hex_Hex_SignedRemainderChain_checkStep___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__8(v_sign_2562_, v___y_2585_, v___y_2584_, v___y_2586_, v___x_2587_);
lean_dec_ref(v___y_2584_);
if (v___x_2589_ == 0)
{
v___y_2577_ = v___x_2571_;
goto v___jp_2576_;
}
else
{
v___y_2577_ = v___x_2573_;
goto v___jp_2576_;
}
}
else
{
lean_object* v___x_2590_; uint8_t v___x_2591_; 
v___x_2590_ = lean_array_fget_borrowed(v___x_2565_, v___x_2581_);
lean_inc(v___x_2590_);
lean_inc_ref(v_sign_2562_);
v___x_2591_ = lp_Hex_Hex_SignedRemainderChain_checkStep___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__8(v_sign_2562_, v___y_2585_, v___y_2584_, v___y_2586_, v___x_2590_);
lean_dec_ref(v___y_2584_);
if (v___x_2591_ == 0)
{
v___y_2577_ = v___x_2571_;
goto v___jp_2576_;
}
else
{
v___y_2577_ = v___x_2573_;
goto v___jp_2576_;
}
}
}
v___jp_2592_:
{
lean_object* v___x_2595_; uint8_t v___x_2596_; 
v___x_2595_ = lean_nat_add(v___x_2581_, v___x_2574_);
v___x_2596_ = lean_nat_dec_lt(v___x_2595_, v_n_2564_);
if (v___x_2596_ == 0)
{
lean_dec(v___x_2595_);
v___y_2584_ = v___y_2594_;
v___y_2585_ = v___y_2593_;
v___y_2586_ = v___x_2582_;
goto v___jp_2583_;
}
else
{
lean_object* v___x_2597_; 
v___x_2597_ = lean_array_fget_borrowed(v___x_2566_, v___x_2595_);
lean_dec(v___x_2595_);
lean_inc(v___x_2597_);
v___y_2584_ = v___y_2594_;
v___y_2585_ = v___y_2593_;
v___y_2586_ = v___x_2597_;
goto v___jp_2583_;
}
}
v___jp_2598_:
{
lean_object* v___x_2600_; uint8_t v___x_2601_; 
v___x_2600_ = lean_nat_add(v___x_2581_, v___x_2572_);
v___x_2601_ = lean_nat_dec_lt(v___x_2600_, v_n_2564_);
if (v___x_2601_ == 0)
{
lean_dec(v___x_2600_);
v___y_2593_ = v___y_2599_;
v___y_2594_ = v___x_2582_;
goto v___jp_2592_;
}
else
{
lean_object* v___x_2602_; 
v___x_2602_ = lean_array_fget_borrowed(v___x_2566_, v___x_2600_);
lean_dec(v___x_2600_);
lean_inc(v___x_2602_);
v___y_2593_ = v___y_2599_;
v___y_2594_ = v___x_2602_;
goto v___jp_2592_;
}
}
}
else
{
uint8_t v___x_2605_; 
lean_dec_ref(v_sign_2562_);
v___x_2605_ = 0;
return v___x_2605_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9___boxed(lean_object* v___x_2606_, lean_object* v_sign_2607_, lean_object* v___x_2608_, lean_object* v_n_2609_, lean_object* v___x_2610_, lean_object* v___x_2611_, lean_object* v_as_2612_, lean_object* v_i_2613_, lean_object* v_stop_2614_){
_start:
{
size_t v_i_boxed_2615_; size_t v_stop_boxed_2616_; uint8_t v_res_2617_; lean_object* v_r_2618_; 
v_i_boxed_2615_ = lean_unbox_usize(v_i_2613_);
lean_dec(v_i_2613_);
v_stop_boxed_2616_ = lean_unbox_usize(v_stop_2614_);
lean_dec(v_stop_2614_);
v_res_2617_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9(v___x_2606_, v_sign_2607_, v___x_2608_, v_n_2609_, v___x_2610_, v___x_2611_, v_as_2612_, v_i_boxed_2615_, v_stop_boxed_2616_);
lean_dec_ref(v_as_2612_);
lean_dec_ref(v___x_2611_);
lean_dec_ref(v___x_2610_);
lean_dec(v_n_2609_);
lean_dec(v___x_2608_);
lean_dec(v___x_2606_);
v_r_2618_ = lean_box(v_res_2617_);
return v_r_2618_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__11(uint8_t v___y_2619_, lean_object* v_as_2620_, size_t v_i_2621_, size_t v_stop_2622_){
_start:
{
uint8_t v___x_2623_; 
v___x_2623_ = lean_usize_dec_eq(v_i_2621_, v_stop_2622_);
if (v___x_2623_ == 0)
{
uint8_t v___x_2624_; uint8_t v___y_2626_; lean_object* v___x_2630_; uint8_t v___x_2631_; 
v___x_2624_ = 1;
v___x_2630_ = lean_array_uget_borrowed(v_as_2620_, v_i_2621_);
v___x_2631_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v___x_2630_);
if (v___x_2631_ == 0)
{
v___y_2626_ = v___x_2631_;
goto v___jp_2625_;
}
else
{
v___y_2626_ = v___y_2619_;
goto v___jp_2625_;
}
v___jp_2625_:
{
if (v___y_2626_ == 0)
{
size_t v___x_2627_; size_t v___x_2628_; 
v___x_2627_ = ((size_t)1ULL);
v___x_2628_ = lean_usize_add(v_i_2621_, v___x_2627_);
v_i_2621_ = v___x_2628_;
goto _start;
}
else
{
return v___x_2624_;
}
}
}
else
{
uint8_t v___x_2632_; 
v___x_2632_ = 0;
return v___x_2632_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__11___boxed(lean_object* v___y_2633_, lean_object* v_as_2634_, lean_object* v_i_2635_, lean_object* v_stop_2636_){
_start:
{
uint8_t v___y_3092__boxed_2637_; size_t v_i_boxed_2638_; size_t v_stop_boxed_2639_; uint8_t v_res_2640_; lean_object* v_r_2641_; 
v___y_3092__boxed_2637_ = lean_unbox(v___y_2633_);
v_i_boxed_2638_ = lean_unbox_usize(v_i_2635_);
lean_dec(v_i_2635_);
v_stop_boxed_2639_ = lean_unbox_usize(v_stop_2636_);
lean_dec(v_stop_2636_);
v_res_2640_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__11(v___y_3092__boxed_2637_, v_as_2634_, v_i_boxed_2638_, v_stop_boxed_2639_);
lean_dec_ref(v_as_2634_);
v_r_2641_ = lean_box(v_res_2640_);
return v_r_2641_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_addImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__6___lam__0(lean_object* v_p_2642_, lean_object* v_q_2643_, lean_object* v_i_2644_){
_start:
{
lean_object* v___x_2645_; lean_object* v___x_2646_; lean_object* v___x_2647_; 
v___x_2645_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_p_2642_, v_i_2644_);
v___x_2646_ = lp_Hex_Hex_DensePoly_coeff___at___00Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9_spec__11(v_q_2643_, v_i_2644_);
v___x_2647_ = lean_int_add(v___x_2645_, v___x_2646_);
lean_dec(v___x_2646_);
lean_dec(v___x_2645_);
return v___x_2647_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_addImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__6___lam__0___boxed(lean_object* v_p_2648_, lean_object* v_q_2649_, lean_object* v_i_2650_){
_start:
{
lean_object* v_res_2651_; 
v_res_2651_ = lp_Hex_Hex_DensePoly_addImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__6___lam__0(v_p_2648_, v_q_2649_, v_i_2650_);
lean_dec(v_i_2650_);
lean_dec_ref(v_q_2649_);
lean_dec_ref(v_p_2648_);
return v_res_2651_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_DensePoly_addImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__6(lean_object* v_p_2652_, lean_object* v_q_2653_){
_start:
{
lean_object* v___f_2654_; lean_object* v___y_2656_; lean_object* v___x_2659_; lean_object* v___x_2660_; uint8_t v___x_2661_; 
lean_inc_ref(v_q_2653_);
lean_inc_ref(v_p_2652_);
v___f_2654_ = lean_alloc_closure((void*)(lp_Hex_Hex_DensePoly_addImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__6___lam__0___boxed), 3, 2);
lean_closure_set(v___f_2654_, 0, v_p_2652_);
lean_closure_set(v___f_2654_, 1, v_q_2653_);
v___x_2659_ = lean_array_get_size(v_p_2652_);
lean_dec_ref(v_p_2652_);
v___x_2660_ = lean_array_get_size(v_q_2653_);
lean_dec_ref(v_q_2653_);
v___x_2661_ = lean_nat_dec_le(v___x_2659_, v___x_2660_);
if (v___x_2661_ == 0)
{
v___y_2656_ = v___x_2659_;
goto v___jp_2655_;
}
else
{
v___y_2656_ = v___x_2660_;
goto v___jp_2655_;
}
v___jp_2655_:
{
lean_object* v___x_2657_; lean_object* v___x_2658_; 
v___x_2657_ = l_Array_ofFn___redArg(v___y_2656_, v___f_2654_);
v___x_2658_ = lp_Hex_Hex_DensePoly_trimTrailingZerosImpl___at___00Hex_DensePoly_ofCoeffs___at___00Hex_DensePoly_C___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__2_spec__6_spec__7(v___x_2657_);
return v___x_2658_;
}
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17___redArg(lean_object* v_xs_2662_, lean_object* v_ys_2663_, lean_object* v_x_2664_){
_start:
{
lean_object* v_zero_2665_; uint8_t v_isZero_2666_; 
v_zero_2665_ = lean_unsigned_to_nat(0u);
v_isZero_2666_ = lean_nat_dec_eq(v_x_2664_, v_zero_2665_);
if (v_isZero_2666_ == 1)
{
lean_dec(v_x_2664_);
return v_isZero_2666_;
}
else
{
lean_object* v_one_2667_; lean_object* v_n_2668_; lean_object* v___x_2669_; lean_object* v___x_2670_; uint8_t v___x_2671_; 
v_one_2667_ = lean_unsigned_to_nat(1u);
v_n_2668_ = lean_nat_sub(v_x_2664_, v_one_2667_);
lean_dec(v_x_2664_);
v___x_2669_ = lean_array_fget_borrowed(v_xs_2662_, v_n_2668_);
v___x_2670_ = lean_array_fget_borrowed(v_ys_2663_, v_n_2668_);
v___x_2671_ = lean_nat_dec_eq(v___x_2669_, v___x_2670_);
if (v___x_2671_ == 0)
{
lean_dec(v_n_2668_);
return v___x_2671_;
}
else
{
v_x_2664_ = v_n_2668_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17___redArg___boxed(lean_object* v_xs_2673_, lean_object* v_ys_2674_, lean_object* v_x_2675_){
_start:
{
uint8_t v_res_2676_; lean_object* v_r_2677_; 
v_res_2676_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17___redArg(v_xs_2673_, v_ys_2674_, v_x_2675_);
lean_dec_ref(v_ys_2674_);
lean_dec_ref(v_xs_2673_);
v_r_2677_ = lean_box(v_res_2676_);
return v_r_2677_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12(lean_object* v_xs_2678_, lean_object* v_ys_2679_){
_start:
{
lean_object* v___x_2680_; lean_object* v___x_2681_; uint8_t v___x_2682_; 
v___x_2680_ = lean_array_get_size(v_xs_2678_);
v___x_2681_ = lean_array_get_size(v_ys_2679_);
v___x_2682_ = lean_nat_dec_eq(v___x_2680_, v___x_2681_);
if (v___x_2682_ == 0)
{
return v___x_2682_;
}
else
{
uint8_t v___x_2683_; 
v___x_2683_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17___redArg(v_xs_2678_, v_ys_2679_, v___x_2680_);
return v___x_2683_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12___boxed(lean_object* v_xs_2684_, lean_object* v_ys_2685_){
_start:
{
uint8_t v_res_2686_; lean_object* v_r_2687_; 
v_res_2686_ = lp_Hex_Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12(v_xs_2684_, v_ys_2685_);
lean_dec_ref(v_ys_2685_);
lean_dec_ref(v_xs_2684_);
v_r_2687_ = lean_box(v_res_2686_);
return v_r_2687_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3(lean_object* v_sign_2689_, lean_object* v_p_2690_, lean_object* v_f_2691_, lean_object* v_cert_2692_){
_start:
{
lean_object* v___y_2694_; lean_object* v___y_2695_; lean_object* v___y_2696_; lean_object* v_chain_2699_; lean_object* v_degrees_2700_; lean_object* v_initial_2701_; lean_object* v_steps_2702_; lean_object* v_terminal_2703_; uint8_t v___x_2704_; 
v_chain_2699_ = lean_ctor_get(v_cert_2692_, 0);
lean_inc_ref(v_chain_2699_);
v_degrees_2700_ = lean_ctor_get(v_cert_2692_, 1);
lean_inc_ref(v_degrees_2700_);
v_initial_2701_ = lean_ctor_get(v_cert_2692_, 2);
lean_inc_ref(v_initial_2701_);
v_steps_2702_ = lean_ctor_get(v_cert_2692_, 3);
lean_inc_ref(v_steps_2702_);
v_terminal_2703_ = lean_ctor_get(v_cert_2692_, 4);
lean_inc(v_terminal_2703_);
lean_dec_ref(v_cert_2692_);
v___x_2704_ = lp_Hex_Hex_DensePoly_isZero___at___00Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1_spec__2(v_p_2690_);
if (v___x_2704_ == 0)
{
lean_object* v_n_2705_; lean_object* v___y_2707_; lean_object* v___y_2708_; lean_object* v___y_2709_; lean_object* v___y_2710_; lean_object* v___y_2711_; lean_object* v___y_2717_; lean_object* v___y_2718_; uint8_t v___y_2719_; lean_object* v___y_2731_; lean_object* v___y_2732_; lean_object* v___y_2733_; lean_object* v___y_2734_; lean_object* v___y_2735_; lean_object* v___y_2736_; uint8_t v___y_2773_; lean_object* v___x_2783_; uint8_t v___x_2784_; 
v_n_2705_ = lean_array_get_size(v_chain_2699_);
v___x_2783_ = lean_unsigned_to_nat(0u);
v___x_2784_ = lean_nat_dec_lt(v___x_2783_, v_n_2705_);
if (v___x_2784_ == 0)
{
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_initial_2701_);
lean_dec_ref(v_degrees_2700_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_sign_2689_);
return v___x_2784_;
}
else
{
lean_object* v___x_2785_; uint8_t v___x_2786_; 
v___x_2785_ = lean_array_get_size(v_p_2690_);
v___x_2786_ = lean_nat_dec_le(v_n_2705_, v___x_2785_);
if (v___x_2786_ == 0)
{
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_initial_2701_);
lean_dec_ref(v_degrees_2700_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_sign_2689_);
return v___x_2786_;
}
else
{
lean_object* v___x_2787_; lean_object* v___x_2788_; lean_object* v___x_2789_; lean_object* v___x_2790_; uint8_t v___x_2791_; 
v___x_2787_ = ((lean_object*)(lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3___closed__0));
v___x_2788_ = lean_array_fget_borrowed(v_chain_2699_, v___x_2783_);
lean_inc(v___x_2788_);
v___x_2789_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2789_, 0, v___x_2788_);
lean_inc_ref(v_p_2690_);
v___x_2790_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2790_, 0, v_p_2690_);
v___x_2791_ = l_Option_instDecidableEq___redArg(v___x_2787_, v___x_2789_, v___x_2790_);
if (v___x_2791_ == 0)
{
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_initial_2701_);
lean_dec_ref(v_degrees_2700_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_sign_2689_);
return v___x_2791_;
}
else
{
size_t v_sz_2792_; size_t v___x_2793_; lean_object* v___x_2794_; uint8_t v___x_2795_; 
v_sz_2792_ = lean_array_size(v_chain_2699_);
v___x_2793_ = ((size_t)0ULL);
lean_inc_ref(v_chain_2699_);
v___x_2794_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__13(v_sz_2792_, v___x_2793_, v_chain_2699_);
v___x_2795_ = lp_Hex_Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12(v_degrees_2700_, v___x_2794_);
lean_dec_ref(v___x_2794_);
lean_dec_ref(v_degrees_2700_);
if (v___x_2795_ == 0)
{
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_initial_2701_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_sign_2689_);
return v___x_2795_;
}
else
{
if (v___x_2784_ == 0)
{
v___y_2773_ = v___x_2795_;
goto v___jp_2772_;
}
else
{
if (v___x_2784_ == 0)
{
v___y_2773_ = v___x_2795_;
goto v___jp_2772_;
}
else
{
size_t v___x_2796_; uint8_t v___x_2797_; 
v___x_2796_ = lean_usize_of_nat(v_n_2705_);
v___x_2797_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__11(v___x_2795_, v_chain_2699_, v___x_2793_, v___x_2796_);
if (v___x_2797_ == 0)
{
v___y_2773_ = v___x_2784_;
goto v___jp_2772_;
}
else
{
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_initial_2701_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_sign_2689_);
return v___x_2704_;
}
}
}
}
}
}
}
v___jp_2706_:
{
lean_object* v___x_2712_; lean_object* v___x_2713_; uint8_t v___x_2714_; 
v___x_2712_ = lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5(v___y_2707_, v___y_2711_);
lean_dec(v___y_2707_);
v___x_2713_ = lean_nat_sub(v_n_2705_, v___y_2710_);
v___x_2714_ = lean_nat_dec_lt(v___x_2713_, v_n_2705_);
if (v___x_2714_ == 0)
{
lean_dec(v___x_2713_);
lean_dec_ref(v_chain_2699_);
v___y_2694_ = v___x_2712_;
v___y_2695_ = v___y_2709_;
v___y_2696_ = v___y_2708_;
goto v___jp_2693_;
}
else
{
lean_object* v___x_2715_; 
lean_dec_ref(v___y_2708_);
v___x_2715_ = lean_array_fget(v_chain_2699_, v___x_2713_);
lean_dec(v___x_2713_);
lean_dec_ref(v_chain_2699_);
v___y_2694_ = v___x_2712_;
v___y_2695_ = v___y_2709_;
v___y_2696_ = v___x_2715_;
goto v___jp_2693_;
}
}
v___jp_2716_:
{
if (lean_obj_tag(v_terminal_2703_) == 0)
{
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_sign_2689_);
return v___y_2719_;
}
else
{
lean_object* v_val_2720_; lean_object* v_fst_2721_; lean_object* v_snd_2722_; lean_object* v___x_2723_; uint8_t v___x_2724_; 
v_val_2720_ = lean_ctor_get(v_terminal_2703_, 0);
lean_inc(v_val_2720_);
lean_dec_ref_known(v_terminal_2703_, 1);
v_fst_2721_ = lean_ctor_get(v_val_2720_, 0);
lean_inc_n(v_fst_2721_, 2);
v_snd_2722_ = lean_ctor_get(v_val_2720_, 1);
lean_inc(v_snd_2722_);
lean_dec(v_val_2720_);
v___x_2723_ = lean_apply_1(v_sign_2689_, v_fst_2721_);
v___x_2724_ = lean_int_dec_eq(v___x_2723_, v___y_2717_);
lean_dec(v___x_2723_);
if (v___x_2724_ == 0)
{
lean_dec(v_snd_2722_);
lean_dec(v_fst_2721_);
lean_dec_ref(v_chain_2699_);
return v___x_2724_;
}
else
{
lean_object* v___x_2725_; lean_object* v___x_2726_; lean_object* v___x_2727_; uint8_t v___x_2728_; 
v___x_2725_ = lean_unsigned_to_nat(2u);
v___x_2726_ = lean_nat_sub(v_n_2705_, v___x_2725_);
v___x_2727_ = lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
v___x_2728_ = lean_nat_dec_lt(v___x_2726_, v_n_2705_);
if (v___x_2728_ == 0)
{
lean_dec(v___x_2726_);
v___y_2707_ = v_fst_2721_;
v___y_2708_ = v___x_2727_;
v___y_2709_ = v_snd_2722_;
v___y_2710_ = v___y_2718_;
v___y_2711_ = v___x_2727_;
goto v___jp_2706_;
}
else
{
lean_object* v___x_2729_; 
v___x_2729_ = lean_array_fget_borrowed(v_chain_2699_, v___x_2726_);
lean_dec(v___x_2726_);
lean_inc(v___x_2729_);
v___y_2707_ = v_fst_2721_;
v___y_2708_ = v___x_2727_;
v___y_2709_ = v_snd_2722_;
v___y_2710_ = v___y_2718_;
v___y_2711_ = v___x_2729_;
goto v___jp_2706_;
}
}
}
}
v___jp_2730_:
{
lean_object* v___x_2737_; lean_object* v___x_2738_; uint8_t v___x_2739_; 
v___x_2737_ = lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5(v___y_2735_, v___y_2736_);
lean_dec(v___y_2735_);
v___x_2738_ = lp_Hex_Hex_DensePoly_addImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__6(v___y_2732_, v___x_2737_);
v___x_2739_ = lp_Hex_Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7(v___y_2731_, v___x_2738_);
if (v___x_2739_ == 0)
{
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_sign_2689_);
return v___x_2739_;
}
else
{
uint8_t v___x_2740_; 
v___x_2740_ = lean_nat_dec_eq(v_n_2705_, v___y_2734_);
if (v___x_2740_ == 0)
{
lean_object* v___x_2741_; lean_object* v___x_2742_; lean_object* v___x_2743_; uint8_t v___x_2744_; 
v___x_2741_ = lean_array_get_size(v_steps_2702_);
v___x_2742_ = lean_unsigned_to_nat(2u);
v___x_2743_ = lean_nat_add(v___x_2741_, v___x_2742_);
v___x_2744_ = lean_nat_dec_eq(v___x_2743_, v_n_2705_);
if (v___x_2744_ == 0)
{
lean_dec(v___x_2743_);
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_sign_2689_);
return v___x_2744_;
}
else
{
lean_object* v___x_2745_; lean_object* v___x_2746_; lean_object* v___x_2747_; uint8_t v___x_2748_; 
v___x_2745_ = l_Array_range(v___x_2741_);
v___x_2746_ = lean_unsigned_to_nat(0u);
v___x_2747_ = lean_array_get_size(v___x_2745_);
v___x_2748_ = lean_nat_dec_lt(v___x_2746_, v___x_2747_);
if (v___x_2748_ == 0)
{
lean_dec_ref(v___x_2745_);
lean_dec(v___x_2743_);
lean_dec_ref(v_steps_2702_);
v___y_2717_ = v___y_2733_;
v___y_2718_ = v___y_2734_;
v___y_2719_ = v___x_2740_;
goto v___jp_2716_;
}
else
{
if (v___x_2748_ == 0)
{
lean_dec_ref(v___x_2745_);
lean_dec(v___x_2743_);
lean_dec_ref(v_steps_2702_);
v___y_2717_ = v___y_2733_;
v___y_2718_ = v___y_2734_;
v___y_2719_ = v___x_2740_;
goto v___jp_2716_;
}
else
{
size_t v___x_2749_; size_t v___x_2750_; uint8_t v___x_2751_; 
v___x_2749_ = ((size_t)0ULL);
v___x_2750_ = lean_usize_of_nat(v___x_2747_);
lean_inc_ref(v_sign_2689_);
v___x_2751_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__9(v___x_2741_, v_sign_2689_, v___x_2743_, v_n_2705_, v_steps_2702_, v_chain_2699_, v___x_2745_, v___x_2749_, v___x_2750_);
lean_dec_ref(v___x_2745_);
lean_dec_ref(v_steps_2702_);
lean_dec(v___x_2743_);
if (v___x_2751_ == 0)
{
v___y_2717_ = v___y_2733_;
v___y_2718_ = v___y_2734_;
v___y_2719_ = v___x_2740_;
goto v___jp_2716_;
}
else
{
lean_dec(v_terminal_2703_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_sign_2689_);
return v___x_2740_;
}
}
}
}
}
else
{
lean_object* v___x_2752_; lean_object* v___x_2753_; uint8_t v___x_2754_; 
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_sign_2689_);
v___x_2752_ = lean_array_get_size(v_steps_2702_);
lean_dec_ref(v_steps_2702_);
v___x_2753_ = lean_unsigned_to_nat(0u);
v___x_2754_ = lean_nat_dec_eq(v___x_2752_, v___x_2753_);
if (v___x_2754_ == 0)
{
lean_dec(v_terminal_2703_);
return v___x_2754_;
}
else
{
if (lean_obj_tag(v_terminal_2703_) == 0)
{
return v___x_2740_;
}
else
{
lean_dec_ref_known(v_terminal_2703_, 1);
return v___x_2704_;
}
}
}
}
}
v___jp_2755_:
{
lean_object* v_leftScale_2756_; lean_object* v_quotient_2757_; lean_object* v_rightScale_2758_; lean_object* v___x_2759_; lean_object* v___x_2760_; lean_object* v___x_2761_; uint8_t v___x_2762_; 
v_leftScale_2756_ = lean_ctor_get(v_initial_2701_, 0);
lean_inc_n(v_leftScale_2756_, 2);
v_quotient_2757_ = lean_ctor_get(v_initial_2701_, 1);
lean_inc_ref(v_quotient_2757_);
v_rightScale_2758_ = lean_ctor_get(v_initial_2701_, 2);
lean_inc(v_rightScale_2758_);
lean_dec_ref(v_initial_2701_);
lean_inc_ref(v_sign_2689_);
v___x_2759_ = lean_apply_1(v_sign_2689_, v_leftScale_2756_);
v___x_2760_ = lean_unsigned_to_nat(1u);
v___x_2761_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_2762_ = lean_int_dec_eq(v___x_2759_, v___x_2761_);
lean_dec(v___x_2759_);
if (v___x_2762_ == 0)
{
lean_dec(v_rightScale_2758_);
lean_dec_ref(v_quotient_2757_);
lean_dec(v_leftScale_2756_);
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_sign_2689_);
return v___x_2762_;
}
else
{
lean_object* v___x_2763_; uint8_t v___x_2764_; 
lean_inc_ref(v_sign_2689_);
lean_inc(v_rightScale_2758_);
v___x_2763_ = lean_apply_1(v_sign_2689_, v_rightScale_2758_);
v___x_2764_ = lean_int_dec_eq(v___x_2763_, v___x_2761_);
lean_dec(v___x_2763_);
if (v___x_2764_ == 0)
{
lean_dec(v_rightScale_2758_);
lean_dec_ref(v_quotient_2757_);
lean_dec(v_leftScale_2756_);
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_sign_2689_);
return v___x_2764_;
}
else
{
lean_object* v___x_2765_; lean_object* v___x_2766_; lean_object* v___x_2767_; lean_object* v___x_2768_; uint8_t v___x_2769_; 
lean_inc_ref(v_p_2690_);
v___x_2765_ = lp_Hex_Hex_DensePoly_derivativeImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__9(v_p_2690_);
v___x_2766_ = lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10(v_f_2691_, v___x_2765_);
lean_dec_ref(v___x_2765_);
v___x_2767_ = lp_Hex_Hex_DensePoly_scaleImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__5(v_leftScale_2756_, v___x_2766_);
lean_dec(v_leftScale_2756_);
v___x_2768_ = lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10(v_quotient_2757_, v_p_2690_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_quotient_2757_);
v___x_2769_ = lean_nat_dec_lt(v___x_2760_, v_n_2705_);
if (v___x_2769_ == 0)
{
lean_object* v___x_2770_; 
v___x_2770_ = lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16;
v___y_2731_ = v___x_2767_;
v___y_2732_ = v___x_2768_;
v___y_2733_ = v___x_2761_;
v___y_2734_ = v___x_2760_;
v___y_2735_ = v_rightScale_2758_;
v___y_2736_ = v___x_2770_;
goto v___jp_2730_;
}
else
{
lean_object* v___x_2771_; 
v___x_2771_ = lean_array_fget_borrowed(v_chain_2699_, v___x_2760_);
lean_inc(v___x_2771_);
v___y_2731_ = v___x_2767_;
v___y_2732_ = v___x_2768_;
v___y_2733_ = v___x_2761_;
v___y_2734_ = v___x_2760_;
v___y_2735_ = v_rightScale_2758_;
v___y_2736_ = v___x_2771_;
goto v___jp_2730_;
}
}
}
}
v___jp_2772_:
{
lean_object* v___x_2774_; lean_object* v___x_2775_; lean_object* v___x_2776_; lean_object* v___x_2777_; lean_object* v___x_2778_; uint8_t v___x_2779_; 
v___x_2774_ = lean_unsigned_to_nat(1u);
v___x_2775_ = lean_nat_sub(v_n_2705_, v___x_2774_);
v___x_2776_ = l_Array_range(v___x_2775_);
v___x_2777_ = lean_unsigned_to_nat(0u);
v___x_2778_ = lean_array_get_size(v___x_2776_);
v___x_2779_ = lean_nat_dec_lt(v___x_2777_, v___x_2778_);
if (v___x_2779_ == 0)
{
lean_dec_ref(v___x_2776_);
goto v___jp_2755_;
}
else
{
if (v___x_2779_ == 0)
{
lean_dec_ref(v___x_2776_);
goto v___jp_2755_;
}
else
{
size_t v___x_2780_; size_t v___x_2781_; uint8_t v___x_2782_; 
v___x_2780_ = ((size_t)0ULL);
v___x_2781_ = lean_usize_of_nat(v___x_2778_);
v___x_2782_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__10(v___y_2773_, v_n_2705_, v_chain_2699_, v___x_2776_, v___x_2780_, v___x_2781_);
lean_dec_ref(v___x_2776_);
if (v___x_2782_ == 0)
{
goto v___jp_2755_;
}
else
{
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_initial_2701_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_sign_2689_);
return v___x_2704_;
}
}
}
}
}
else
{
uint8_t v___x_2798_; 
lean_dec(v_terminal_2703_);
lean_dec_ref(v_steps_2702_);
lean_dec_ref(v_initial_2701_);
lean_dec_ref(v_degrees_2700_);
lean_dec_ref(v_chain_2699_);
lean_dec_ref(v_p_2690_);
lean_dec_ref(v_sign_2689_);
v___x_2798_ = 0;
return v___x_2798_;
}
v___jp_2693_:
{
lean_object* v___x_2697_; uint8_t v___x_2698_; 
v___x_2697_ = lp_Hex_Hex_DensePoly_mulImpl___at___00Hex_SignedRemainderChain_build___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__3_spec__10(v___y_2695_, v___y_2696_);
lean_dec_ref(v___y_2696_);
lean_dec_ref(v___y_2695_);
v___x_2698_ = lp_Hex_Hex_SignedRemainderChain_subIsZero___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__7(v___y_2694_, v___x_2697_);
return v___x_2698_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3___boxed(lean_object* v_sign_2799_, lean_object* v_p_2800_, lean_object* v_f_2801_, lean_object* v_cert_2802_){
_start:
{
uint8_t v_res_2803_; lean_object* v_r_2804_; 
v_res_2803_ = lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3(v_sign_2799_, v_p_2800_, v_f_2801_, v_cert_2802_);
lean_dec_ref(v_f_2801_);
v_r_2804_ = lean_box(v_res_2803_);
return v_r_2804_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__1(uint8_t v___y_2805_, lean_object* v_as_2806_, size_t v_i_2807_, size_t v_stop_2808_){
_start:
{
uint8_t v___x_2813_; 
v___x_2813_ = lean_usize_dec_eq(v_i_2807_, v_stop_2808_);
if (v___x_2813_ == 0)
{
uint8_t v___x_2814_; uint8_t v___y_2816_; lean_object* v___x_2817_; lean_object* v___x_2818_; lean_object* v___x_2819_; uint8_t v___x_2820_; 
v___x_2814_ = 1;
v___x_2817_ = lean_array_uget_borrowed(v_as_2806_, v_i_2807_);
v___x_2818_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__0, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__0_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__0);
v___x_2819_ = lean_obj_once(&lp_Hex_Hex_Endpoint_signAt___redArg___closed__1, &lp_Hex_Hex_Endpoint_signAt___redArg___closed__1_once, _init_lp_Hex_Hex_Endpoint_signAt___redArg___closed__1);
v___x_2820_ = lean_int_dec_le(v___x_2819_, v___x_2817_);
if (v___x_2820_ == 0)
{
v___y_2816_ = v___y_2805_;
goto v___jp_2815_;
}
else
{
uint8_t v___x_2821_; 
v___x_2821_ = lean_int_dec_le(v___x_2817_, v___x_2818_);
if (v___x_2821_ == 0)
{
v___y_2816_ = v___y_2805_;
goto v___jp_2815_;
}
else
{
goto v___jp_2809_;
}
}
v___jp_2815_:
{
if (v___y_2816_ == 0)
{
goto v___jp_2809_;
}
else
{
return v___x_2814_;
}
}
}
else
{
uint8_t v___x_2822_; 
v___x_2822_ = 0;
return v___x_2822_;
}
v___jp_2809_:
{
size_t v___x_2810_; size_t v___x_2811_; 
v___x_2810_ = ((size_t)1ULL);
v___x_2811_ = lean_usize_add(v_i_2807_, v___x_2810_);
v_i_2807_ = v___x_2811_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__1___boxed(lean_object* v___y_2823_, lean_object* v_as_2824_, lean_object* v_i_2825_, lean_object* v_stop_2826_){
_start:
{
uint8_t v___y_3360__boxed_2827_; size_t v_i_boxed_2828_; size_t v_stop_boxed_2829_; uint8_t v_res_2830_; lean_object* v_r_2831_; 
v___y_3360__boxed_2827_ = lean_unbox(v___y_2823_);
v_i_boxed_2828_ = lean_unbox_usize(v_i_2825_);
lean_dec(v_i_2825_);
v_stop_boxed_2829_ = lean_unbox_usize(v_stop_2826_);
lean_dec(v_stop_2826_);
v_res_2830_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__1(v___y_3360__boxed_2827_, v_as_2824_, v_i_boxed_2828_, v_stop_boxed_2829_);
lean_dec_ref(v_as_2824_);
v_r_2831_ = lean_box(v_res_2830_);
return v_r_2831_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0___redArg(lean_object* v_sign_2832_, lean_object* v_endpointSigns_2833_, lean_object* v_p_2834_, lean_object* v_f_2835_, lean_object* v_a_2836_, lean_object* v_b_2837_, lean_object* v_value_2838_, lean_object* v_cert_2839_){
_start:
{
lean_object* v_remainders_2840_; lean_object* v_lowerSigns_2841_; lean_object* v_upperSigns_2842_; lean_object* v_lowerVariations_2843_; lean_object* v_upperVariations_2844_; uint8_t v___y_2857_; uint8_t v___y_2866_; uint8_t v___x_2877_; 
v_remainders_2840_ = lean_ctor_get(v_cert_2839_, 6);
lean_inc_ref_n(v_remainders_2840_, 2);
v_lowerSigns_2841_ = lean_ctor_get(v_cert_2839_, 7);
lean_inc_ref(v_lowerSigns_2841_);
v_upperSigns_2842_ = lean_ctor_get(v_cert_2839_, 8);
lean_inc_ref(v_upperSigns_2842_);
v_lowerVariations_2843_ = lean_ctor_get(v_cert_2839_, 9);
lean_inc(v_lowerVariations_2843_);
v_upperVariations_2844_ = lean_ctor_get(v_cert_2839_, 10);
lean_inc(v_upperVariations_2844_);
lean_dec_ref(v_cert_2839_);
lean_inc_ref(v_sign_2832_);
v___x_2877_ = lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3(v_sign_2832_, v_p_2834_, v_f_2835_, v_remainders_2840_);
if (v___x_2877_ == 0)
{
lean_dec(v_a_2836_);
v___y_2866_ = v___x_2877_;
goto v___jp_2865_;
}
else
{
lean_object* v_chain_2878_; lean_object* v___x_2879_; uint8_t v___x_2880_; 
v_chain_2878_ = lean_ctor_get(v_remainders_2840_, 0);
lean_inc_ref(v_chain_2878_);
lean_inc_ref(v_endpointSigns_2833_);
lean_inc_ref(v_sign_2832_);
v___x_2879_ = lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___redArg(v_sign_2832_, v_endpointSigns_2833_, v_chain_2878_, v_a_2836_);
v___x_2880_ = lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2(v_lowerSigns_2841_, v___x_2879_);
lean_dec_ref(v___x_2879_);
v___y_2866_ = v___x_2880_;
goto v___jp_2865_;
}
v___jp_2845_:
{
lean_object* v___x_2846_; lean_object* v___x_2847_; uint8_t v___x_2848_; 
v___x_2846_ = lean_array_to_list(v_lowerSigns_2841_);
v___x_2847_ = lp_Hex_Hex_signVar(v___x_2846_);
v___x_2848_ = lean_nat_dec_eq(v_lowerVariations_2843_, v___x_2847_);
lean_dec(v___x_2847_);
if (v___x_2848_ == 0)
{
lean_dec(v_upperVariations_2844_);
lean_dec(v_lowerVariations_2843_);
lean_dec_ref(v_upperSigns_2842_);
return v___x_2848_;
}
else
{
lean_object* v___x_2849_; lean_object* v___x_2850_; uint8_t v___x_2851_; 
v___x_2849_ = lean_array_to_list(v_upperSigns_2842_);
v___x_2850_ = lp_Hex_Hex_signVar(v___x_2849_);
v___x_2851_ = lean_nat_dec_eq(v_upperVariations_2844_, v___x_2850_);
lean_dec(v___x_2850_);
if (v___x_2851_ == 0)
{
lean_dec(v_upperVariations_2844_);
lean_dec(v_lowerVariations_2843_);
return v___x_2851_;
}
else
{
lean_object* v___x_2852_; lean_object* v___x_2853_; lean_object* v___x_2854_; uint8_t v___x_2855_; 
v___x_2852_ = lean_nat_to_int(v_lowerVariations_2843_);
v___x_2853_ = lean_nat_to_int(v_upperVariations_2844_);
v___x_2854_ = lean_int_sub(v___x_2852_, v___x_2853_);
lean_dec(v___x_2853_);
lean_dec(v___x_2852_);
v___x_2855_ = lean_int_dec_eq(v_value_2838_, v___x_2854_);
lean_dec(v___x_2854_);
return v___x_2855_;
}
}
}
v___jp_2856_:
{
lean_object* v___x_2858_; lean_object* v___x_2859_; uint8_t v___x_2860_; 
v___x_2858_ = lean_unsigned_to_nat(0u);
v___x_2859_ = lean_array_get_size(v_upperSigns_2842_);
v___x_2860_ = lean_nat_dec_lt(v___x_2858_, v___x_2859_);
if (v___x_2860_ == 0)
{
goto v___jp_2845_;
}
else
{
if (v___x_2860_ == 0)
{
goto v___jp_2845_;
}
else
{
size_t v___x_2861_; size_t v___x_2862_; uint8_t v___x_2863_; 
v___x_2861_ = ((size_t)0ULL);
v___x_2862_ = lean_usize_of_nat(v___x_2859_);
v___x_2863_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__1(v___y_2857_, v_upperSigns_2842_, v___x_2861_, v___x_2862_);
if (v___x_2863_ == 0)
{
goto v___jp_2845_;
}
else
{
uint8_t v___x_2864_; 
lean_dec(v_upperVariations_2844_);
lean_dec(v_lowerVariations_2843_);
lean_dec_ref(v_upperSigns_2842_);
lean_dec_ref(v_lowerSigns_2841_);
v___x_2864_ = 0;
return v___x_2864_;
}
}
}
}
v___jp_2865_:
{
if (v___y_2866_ == 0)
{
lean_dec(v_upperVariations_2844_);
lean_dec(v_lowerVariations_2843_);
lean_dec_ref(v_upperSigns_2842_);
lean_dec_ref(v_lowerSigns_2841_);
lean_dec_ref(v_remainders_2840_);
lean_dec(v_b_2837_);
lean_dec_ref(v_endpointSigns_2833_);
lean_dec_ref(v_sign_2832_);
return v___y_2866_;
}
else
{
lean_object* v_chain_2867_; lean_object* v___x_2868_; uint8_t v___x_2869_; 
v_chain_2867_ = lean_ctor_get(v_remainders_2840_, 0);
lean_inc_ref(v_chain_2867_);
lean_dec_ref(v_remainders_2840_);
v___x_2868_ = lp_Hex_Hex_TarskiCertificate_signs___at___00Hex_TarskiCertificate_fromChains___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__5_spec__18___redArg(v_sign_2832_, v_endpointSigns_2833_, v_chain_2867_, v_b_2837_);
v___x_2869_ = lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2(v_upperSigns_2842_, v___x_2868_);
lean_dec_ref(v___x_2868_);
if (v___x_2869_ == 0)
{
lean_dec(v_upperVariations_2844_);
lean_dec(v_lowerVariations_2843_);
lean_dec_ref(v_upperSigns_2842_);
lean_dec_ref(v_lowerSigns_2841_);
return v___x_2869_;
}
else
{
lean_object* v___x_2870_; lean_object* v___x_2871_; uint8_t v___x_2872_; 
v___x_2870_ = lean_unsigned_to_nat(0u);
v___x_2871_ = lean_array_get_size(v_lowerSigns_2841_);
v___x_2872_ = lean_nat_dec_lt(v___x_2870_, v___x_2871_);
if (v___x_2872_ == 0)
{
v___y_2857_ = v___x_2869_;
goto v___jp_2856_;
}
else
{
if (v___x_2872_ == 0)
{
v___y_2857_ = v___x_2869_;
goto v___jp_2856_;
}
else
{
size_t v___x_2873_; size_t v___x_2874_; uint8_t v___x_2875_; 
v___x_2873_ = ((size_t)0ULL);
v___x_2874_ = lean_usize_of_nat(v___x_2871_);
v___x_2875_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__1(v___x_2869_, v_lowerSigns_2841_, v___x_2873_, v___x_2874_);
if (v___x_2875_ == 0)
{
v___y_2857_ = v___x_2872_;
goto v___jp_2856_;
}
else
{
uint8_t v___x_2876_; 
lean_dec(v_upperVariations_2844_);
lean_dec(v_lowerVariations_2843_);
lean_dec_ref(v_upperSigns_2842_);
lean_dec_ref(v_lowerSigns_2841_);
v___x_2876_ = 0;
return v___x_2876_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0___redArg___boxed(lean_object* v_sign_2881_, lean_object* v_endpointSigns_2882_, lean_object* v_p_2883_, lean_object* v_f_2884_, lean_object* v_a_2885_, lean_object* v_b_2886_, lean_object* v_value_2887_, lean_object* v_cert_2888_){
_start:
{
uint8_t v_res_2889_; lean_object* v_r_2890_; 
v_res_2889_ = lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0___redArg(v_sign_2881_, v_endpointSigns_2882_, v_p_2883_, v_f_2884_, v_a_2885_, v_b_2886_, v_value_2887_, v_cert_2888_);
lean_dec(v_value_2887_);
lean_dec_ref(v_f_2884_);
v_r_2890_ = lean_box(v_res_2889_);
return v_r_2890_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2___redArg(lean_object* v_sign_2891_, lean_object* v_endpointSigns_2892_, lean_object* v_p_2893_, lean_object* v_a_2894_, lean_object* v_b_2895_, lean_object* v_squarefree_2896_){
_start:
{
uint8_t v___y_2898_; uint8_t v___x_2900_; 
lean_inc_ref(v_p_2893_);
v___x_2900_ = lp_Hex_Hex_TarskiCertificate_checkEndpoints___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__1___redArg(v_endpointSigns_2892_, v_p_2893_, v_a_2894_, v_b_2895_);
if (v___x_2900_ == 0)
{
lean_dec_ref(v_p_2893_);
lean_dec_ref(v_sign_2891_);
v___y_2898_ = v___x_2900_;
goto v___jp_2897_;
}
else
{
lean_object* v___x_2901_; uint8_t v___x_2902_; 
v___x_2901_ = lean_obj_once(&lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0, &lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0_once, _init_lp_Hex_Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0___redArg___closed__0);
lean_inc_ref(v_squarefree_2896_);
v___x_2902_ = lp_Hex_Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3(v_sign_2891_, v_p_2893_, v___x_2901_, v_squarefree_2896_);
v___y_2898_ = v___x_2902_;
goto v___jp_2897_;
}
v___jp_2897_:
{
if (v___y_2898_ == 0)
{
lean_dec_ref(v_squarefree_2896_);
return v___y_2898_;
}
else
{
uint8_t v___x_2899_; 
v___x_2899_ = lp_Hex_Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4(v_squarefree_2896_);
lean_dec_ref(v_squarefree_2896_);
return v___x_2899_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2___redArg___boxed(lean_object* v_sign_2903_, lean_object* v_endpointSigns_2904_, lean_object* v_p_2905_, lean_object* v_a_2906_, lean_object* v_b_2907_, lean_object* v_squarefree_2908_){
_start:
{
uint8_t v_res_2909_; lean_object* v_r_2910_; 
v_res_2909_ = lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2___redArg(v_sign_2903_, v_endpointSigns_2904_, v_p_2905_, v_a_2906_, v_b_2907_, v_squarefree_2908_);
v_r_2910_ = lean_box(v_res_2909_);
return v_r_2910_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1___redArg(lean_object* v_p_2911_, lean_object* v_f_2912_, lean_object* v_a_2913_, lean_object* v_b_2914_, lean_object* v_value_2915_, lean_object* v_cert_2916_){
_start:
{
lean_object* v_head_2917_; lean_object* v_queryPoly_2918_; lean_object* v_lower_2919_; lean_object* v_upper_2920_; lean_object* v_value_2921_; uint8_t v_decide_2922_; 
v_head_2917_ = lean_ctor_get(v_cert_2916_, 1);
lean_inc_ref(v_head_2917_);
v_queryPoly_2918_ = lean_ctor_get(v_cert_2916_, 2);
lean_inc_ref(v_queryPoly_2918_);
v_lower_2919_ = lean_ctor_get(v_cert_2916_, 3);
lean_inc(v_lower_2919_);
v_upper_2920_ = lean_ctor_get(v_cert_2916_, 4);
lean_inc(v_upper_2920_);
v_value_2921_ = lean_ctor_get(v_cert_2916_, 11);
lean_inc(v_value_2921_);
lean_dec_ref(v_cert_2916_);
v_decide_2922_ = lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2(v_head_2917_, v_p_2911_);
lean_dec_ref(v_head_2917_);
if (v_decide_2922_ == 0)
{
lean_dec(v_value_2921_);
lean_dec(v_upper_2920_);
lean_dec(v_lower_2919_);
lean_dec_ref(v_queryPoly_2918_);
lean_dec(v_b_2914_);
lean_dec(v_a_2913_);
return v_decide_2922_;
}
else
{
uint8_t v_decide_2923_; 
v_decide_2923_ = lp_Hex_Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2(v_queryPoly_2918_, v_f_2912_);
lean_dec_ref(v_queryPoly_2918_);
if (v_decide_2923_ == 0)
{
lean_dec(v_value_2921_);
lean_dec(v_upper_2920_);
lean_dec(v_lower_2919_);
lean_dec(v_b_2914_);
lean_dec(v_a_2913_);
return v_decide_2923_;
}
else
{
lean_object* v___x_2924_; uint8_t v___x_2925_; 
v___x_2924_ = lean_alloc_closure((void*)(l_instDecidableEqDyadic___boxed), 2, 0);
lean_inc_ref(v___x_2924_);
v___x_2925_ = lp_Hex_Hex_instDecidableEqEndpoint___redArg(v___x_2924_, v_lower_2919_, v_a_2913_);
if (v___x_2925_ == 0)
{
lean_dec_ref(v___x_2924_);
lean_dec(v_value_2921_);
lean_dec(v_upper_2920_);
lean_dec(v_b_2914_);
return v___x_2925_;
}
else
{
uint8_t v___x_2926_; 
v___x_2926_ = lp_Hex_Hex_instDecidableEqEndpoint___redArg(v___x_2924_, v_upper_2920_, v_b_2914_);
if (v___x_2926_ == 0)
{
lean_dec(v_value_2921_);
return v___x_2926_;
}
else
{
uint8_t v___x_2927_; 
v___x_2927_ = lean_int_dec_eq(v_value_2921_, v_value_2915_);
lean_dec(v_value_2921_);
return v___x_2927_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1___redArg___boxed(lean_object* v_p_2928_, lean_object* v_f_2929_, lean_object* v_a_2930_, lean_object* v_b_2931_, lean_object* v_value_2932_, lean_object* v_cert_2933_){
_start:
{
uint8_t v_res_2934_; lean_object* v_r_2935_; 
v_res_2934_ = lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1___redArg(v_p_2928_, v_f_2929_, v_a_2930_, v_b_2931_, v_value_2932_, v_cert_2933_);
lean_dec(v_value_2932_);
lean_dec_ref(v_f_2929_);
lean_dec_ref(v_p_2928_);
v_r_2935_ = lean_box(v_res_2934_);
return v_r_2935_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0(lean_object* v_sign_2936_, lean_object* v_endpointSigns_2937_, lean_object* v_context_2938_, lean_object* v_p_2939_, lean_object* v_f_2940_, lean_object* v_a_2941_, lean_object* v_b_2942_, lean_object* v_value_2943_, lean_object* v_cert_2944_){
_start:
{
uint8_t v___y_2946_; uint8_t v___x_2948_; 
lean_inc_ref(v_cert_2944_);
lean_inc(v_b_2942_);
lean_inc(v_a_2941_);
v___x_2948_ = lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1___redArg(v_p_2939_, v_f_2940_, v_a_2941_, v_b_2942_, v_value_2943_, v_cert_2944_);
if (v___x_2948_ == 0)
{
v___y_2946_ = v___x_2948_;
goto v___jp_2945_;
}
else
{
lean_object* v_squarefree_2949_; uint8_t v___x_2950_; 
v_squarefree_2949_ = lean_ctor_get(v_cert_2944_, 5);
lean_inc_ref(v_squarefree_2949_);
lean_inc(v_b_2942_);
lean_inc(v_a_2941_);
lean_inc_ref(v_p_2939_);
lean_inc_ref(v_endpointSigns_2937_);
lean_inc_ref(v_sign_2936_);
v___x_2950_ = lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2___redArg(v_sign_2936_, v_endpointSigns_2937_, v_p_2939_, v_a_2941_, v_b_2942_, v_squarefree_2949_);
v___y_2946_ = v___x_2950_;
goto v___jp_2945_;
}
v___jp_2945_:
{
if (v___y_2946_ == 0)
{
lean_dec_ref(v_cert_2944_);
lean_dec(v_b_2942_);
lean_dec(v_a_2941_);
lean_dec_ref(v_p_2939_);
lean_dec_ref(v_endpointSigns_2937_);
lean_dec_ref(v_sign_2936_);
return v___y_2946_;
}
else
{
uint8_t v___x_2947_; 
v___x_2947_ = lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0___redArg(v_sign_2936_, v_endpointSigns_2937_, v_p_2939_, v_f_2940_, v_a_2941_, v_b_2942_, v_value_2943_, v_cert_2944_);
return v___x_2947_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0___boxed(lean_object* v_sign_2951_, lean_object* v_endpointSigns_2952_, lean_object* v_context_2953_, lean_object* v_p_2954_, lean_object* v_f_2955_, lean_object* v_a_2956_, lean_object* v_b_2957_, lean_object* v_value_2958_, lean_object* v_cert_2959_){
_start:
{
uint8_t v_res_2960_; lean_object* v_r_2961_; 
v_res_2960_ = lp_Hex_Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0(v_sign_2951_, v_endpointSigns_2952_, v_context_2953_, v_p_2954_, v_f_2955_, v_a_2956_, v_b_2957_, v_value_2958_, v_cert_2959_);
lean_dec(v_value_2958_);
lean_dec_ref(v_f_2955_);
v_r_2961_ = lean_box(v_res_2960_);
return v_r_2961_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_IntTarskiCertificate_check(lean_object* v_p_2962_, lean_object* v_f_2963_, lean_object* v_I_2964_, lean_object* v_value_2965_, lean_object* v_cert_2966_){
_start:
{
lean_object* v_lower_2967_; lean_object* v_upper_2968_; lean_object* v___x_2969_; lean_object* v___x_2970_; lean_object* v___x_2971_; lean_object* v___x_2972_; lean_object* v___x_2973_; uint8_t v___x_2974_; 
v_lower_2967_ = lean_ctor_get(v_I_2964_, 0);
v_upper_2968_ = lean_ctor_get(v_I_2964_, 1);
v___x_2969_ = ((lean_object*)(lp_Hex_Hex_ZPoly_tarskiQuery___closed__0));
v___x_2970_ = ((lean_object*)(lp_Hex_Hex_EndpointSigns_intDyadic));
v___x_2971_ = lean_box(0);
lean_inc(v_lower_2967_);
v___x_2972_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2972_, 0, v_lower_2967_);
lean_inc(v_upper_2968_);
v___x_2973_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2973_, 0, v_upper_2968_);
v___x_2974_ = lp_Hex_Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0(v___x_2969_, v___x_2970_, v___x_2971_, v_p_2962_, v_f_2963_, v___x_2972_, v___x_2973_, v_value_2965_, v_cert_2966_);
return v___x_2974_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_IntTarskiCertificate_check___boxed(lean_object* v_p_2975_, lean_object* v_f_2976_, lean_object* v_I_2977_, lean_object* v_value_2978_, lean_object* v_cert_2979_){
_start:
{
uint8_t v_res_2980_; lean_object* v_r_2981_; 
v_res_2980_ = lp_Hex_Hex_IntTarskiCertificate_check(v_p_2975_, v_f_2976_, v_I_2977_, v_value_2978_, v_cert_2979_);
lean_dec(v_value_2978_);
lean_dec_ref(v_I_2977_);
lean_dec_ref(v_f_2976_);
v_r_2981_ = lean_box(v_res_2980_);
return v_r_2981_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0(lean_object* v_E_2982_, lean_object* v_Ctx_2983_, lean_object* v_sign_2984_, lean_object* v_endpointSigns_2985_, lean_object* v_p_2986_, lean_object* v_f_2987_, lean_object* v_a_2988_, lean_object* v_b_2989_, lean_object* v_value_2990_, lean_object* v_cert_2991_){
_start:
{
uint8_t v___x_2992_; 
v___x_2992_ = lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0___redArg(v_sign_2984_, v_endpointSigns_2985_, v_p_2986_, v_f_2987_, v_a_2988_, v_b_2989_, v_value_2990_, v_cert_2991_);
return v___x_2992_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0___boxed(lean_object* v_E_2993_, lean_object* v_Ctx_2994_, lean_object* v_sign_2995_, lean_object* v_endpointSigns_2996_, lean_object* v_p_2997_, lean_object* v_f_2998_, lean_object* v_a_2999_, lean_object* v_b_3000_, lean_object* v_value_3001_, lean_object* v_cert_3002_){
_start:
{
uint8_t v_res_3003_; lean_object* v_r_3004_; 
v_res_3003_ = lp_Hex_Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0(v_E_2993_, v_Ctx_2994_, v_sign_2995_, v_endpointSigns_2996_, v_p_2997_, v_f_2998_, v_a_2999_, v_b_3000_, v_value_3001_, v_cert_3002_);
lean_dec(v_value_3001_);
lean_dec_ref(v_f_2998_);
v_r_3004_ = lean_box(v_res_3003_);
return v_r_3004_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1(lean_object* v_context_3005_, lean_object* v_p_3006_, lean_object* v_f_3007_, lean_object* v_a_3008_, lean_object* v_b_3009_, lean_object* v_value_3010_, lean_object* v_cert_3011_){
_start:
{
uint8_t v___x_3012_; 
v___x_3012_ = lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1___redArg(v_p_3006_, v_f_3007_, v_a_3008_, v_b_3009_, v_value_3010_, v_cert_3011_);
return v___x_3012_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1___boxed(lean_object* v_context_3013_, lean_object* v_p_3014_, lean_object* v_f_3015_, lean_object* v_a_3016_, lean_object* v_b_3017_, lean_object* v_value_3018_, lean_object* v_cert_3019_){
_start:
{
uint8_t v_res_3020_; lean_object* v_r_3021_; 
v_res_3020_ = lp_Hex_Hex_TarskiCertificate_checkBindings___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__1(v_context_3013_, v_p_3014_, v_f_3015_, v_a_3016_, v_b_3017_, v_value_3018_, v_cert_3019_);
lean_dec(v_value_3018_);
lean_dec_ref(v_f_3015_);
lean_dec_ref(v_p_3014_);
v_r_3021_ = lean_box(v_res_3020_);
return v_r_3021_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2(lean_object* v_E_3022_, lean_object* v_sign_3023_, lean_object* v_endpointSigns_3024_, lean_object* v_p_3025_, lean_object* v_a_3026_, lean_object* v_b_3027_, lean_object* v_squarefree_3028_){
_start:
{
uint8_t v___x_3029_; 
v___x_3029_ = lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2___redArg(v_sign_3023_, v_endpointSigns_3024_, v_p_3025_, v_a_3026_, v_b_3027_, v_squarefree_3028_);
return v___x_3029_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2___boxed(lean_object* v_E_3030_, lean_object* v_sign_3031_, lean_object* v_endpointSigns_3032_, lean_object* v_p_3033_, lean_object* v_a_3034_, lean_object* v_b_3035_, lean_object* v_squarefree_3036_){
_start:
{
uint8_t v_res_3037_; lean_object* v_r_3038_; 
v_res_3037_ = lp_Hex_Hex_TarskiCertificate_checkDomain___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__2(v_E_3030_, v_sign_3031_, v_endpointSigns_3032_, v_p_3033_, v_a_3034_, v_b_3035_, v_squarefree_3036_);
v_r_3038_ = lean_box(v_res_3037_);
return v_r_3038_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3(lean_object* v_xs_3039_, lean_object* v_ys_3040_, lean_object* v_hsz_3041_, lean_object* v_x_3042_, lean_object* v_x_3043_){
_start:
{
uint8_t v___x_3044_; 
v___x_3044_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3___redArg(v_xs_3039_, v_ys_3040_, v_x_3042_);
return v___x_3044_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3___boxed(lean_object* v_xs_3045_, lean_object* v_ys_3046_, lean_object* v_hsz_3047_, lean_object* v_x_3048_, lean_object* v_x_3049_){
_start:
{
uint8_t v_res_3050_; lean_object* v_r_3051_; 
v_res_3050_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__2_spec__3(v_xs_3045_, v_ys_3046_, v_hsz_3047_, v_x_3048_, v_x_3049_);
lean_dec_ref(v_ys_3046_);
lean_dec_ref(v_xs_3045_);
v_r_3051_ = lean_box(v_res_3050_);
return v_r_3051_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17(lean_object* v_xs_3052_, lean_object* v_ys_3053_, lean_object* v_hsz_3054_, lean_object* v_x_3055_, lean_object* v_x_3056_){
_start:
{
uint8_t v___x_3057_; 
v___x_3057_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17___redArg(v_xs_3052_, v_ys_3053_, v_x_3055_);
return v___x_3057_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17___boxed(lean_object* v_xs_3058_, lean_object* v_ys_3059_, lean_object* v_hsz_3060_, lean_object* v_x_3061_, lean_object* v_x_3062_){
_start:
{
uint8_t v_res_3063_; lean_object* v_r_3064_; 
v_res_3063_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00Hex_SignedRemainderChain_check___at___00Hex_TarskiCertificate_checkQuery___at___00Hex_TarskiCertificate_check___at___00Hex_IntTarskiCertificate_check_spec__0_spec__0_spec__3_spec__12_spec__17(v_xs_3058_, v_ys_3059_, v_hsz_3060_, v_x_3061_, v_x_3062_);
lean_dec_ref(v_ys_3059_);
lean_dec_ref(v_xs_3058_);
v_r_3064_ = lean_box(v_res_3063_);
return v_r_3064_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexRealRoots_SignedRemainderChain(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexRealRoots_Var(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexRealRoots_Tarski(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealRoots_SignedRemainderChain(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealRoots_Var(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16 = _init_lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16();
lean_mark_persistent(lp_Hex_Hex_DensePoly_zero___at___00Hex_SignedRemainderChain_lastIsConstant___at___00Hex_TarskiCertificate_certify___at___00Hex_TarskiCertificate_query___at___00Hex_ZPoly_tarskiQuery_spec__0_spec__0_spec__4_spec__16);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexRealRoots_Tarski(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexRealRoots_SignedRemainderChain(uint8_t builtin);
lean_object* initialize_Hex_HexRealRoots_Var(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexRealRoots_Tarski(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexRealRoots_SignedRemainderChain(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexRealRoots_Var(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealRoots_Tarski(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexRealRoots_Tarski(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexRealRoots_Tarski(builtin);
}
#ifdef __cplusplus
}
#endif
