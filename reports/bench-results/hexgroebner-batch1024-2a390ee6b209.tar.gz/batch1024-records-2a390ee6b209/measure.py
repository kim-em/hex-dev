import ctypes,hashlib,json,os,pathlib,resource,select,signal,subprocess,sys,time
sys.path.insert(0,'/home/kim/worktrees/hex-dev/hex-dev-issue-10987')
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import fingerprint,index_listing
listing=index_listing(FAMILY);fp=fingerprint(listing)
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/f'batch1024-records-{fp}';OUT.mkdir(exist_ok=False)
plan=json.loads((ROOT/'diagnostic-suite.json').read_text()); protocol=plan['protocol']
binary=ROOT/'.lake/build/bin/f4_compare'; sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
meta=dict(source_fingerprint=fp,source_manifest=listing,suite_sha256=sha(ROOT/'diagnostic-suite.json'),cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),binary_sha256=sha(binary),driver_sha256=sha(ROOT/'Main.lean'),script=pathlib.Path(__file__).read_text(),contract='same binary and limits; A batchSize256; B batchSize1024; both native monomials and shared final reductions; unchecked canonical reduced candidate output; whole process and internal candidate time recorded separately; certification and kernel checking excluded',schedule='two blocks, adjacent AB then BA per input; retain every completed sample',samples=[])
def limits():
 os.setsid()
 resource.setrlimit(resource.RLIMIT_AS,(protocol['address_space_bytes'],)*2)
 resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,)*2)
try:
 for block,order in enumerate(['AB','BA']):
  for case in plan['cases']:
   outputs={}
   for arm in order:
    prefix=f"{case['name']}-b{block}-{arm}"
    command=[str(binary),str(ROOT/(case['name']+'.json'))]+(['--batch1024'] if arm=='B' else ['--batch256'])
    start=time.monotonic_ns()
    with (OUT/(prefix+'.stdout')).open('wb') as stdout,(OUT/(prefix+'.stderr')).open('wb') as stderr:
     proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env,preexec_fn=limits)
     libc=ctypes.CDLL(None,use_errno=True)
     libc.pidfd_open.argtypes=[ctypes.c_int,ctypes.c_uint];libc.pidfd_open.restype=ctypes.c_int
     fd=libc.pidfd_open(proc.pid,0)
     if fd<0: raise OSError(ctypes.get_errno(),'pidfd_open')
     ready,_,_=select.select([fd],[],[],10)
     if not ready:os.killpg(proc.pid,signal.SIGKILL)
     _,status,usage=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status)
     os.close(fd)
    elapsed=time.monotonic_ns()-start
    record=dict(case=case['name'],family=case['family'],p=case['p'],block=block,arm=arm,command=command,wall_nanos=elapsed,returncode=proc.returncode,peak_rss_kib=usage.ru_maxrss,status='timeout' if not ready else 'ok' if proc.returncode==0 else 'failed')
    if proc.returncode==0:
     data=json.loads((OUT/(prefix+'.stdout')).read_text());outputs[arm]=data['basis'];record['statistics']={k:v for k,v in data.items() if k!='basis'}
    meta['samples'].append(record);print(prefix,record['status'],round(elapsed/1e6,2),flush=True)
   if len(outputs)==2 and outputs['A']!=outputs['B']:raise RuntimeError('complete basis mismatch '+case['name'])
   for arm in order:meta['samples'][-2 if arm==order[0] else -1]['complete_basis_equal']=len(outputs)==2 and outputs['A']==outputs['B']
finally:
 meta['load_end']=os.getloadavg();(OUT/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
