// Lean compiler output
// Module: HexRealAlgebraic.Roots
// Imports: public import Init public meta import Init public import HexRealAlgebraic.Order public import HexNumberField.Radical
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_Hex_Hex_RealAlgebraicNumber_ofRoot_x3f(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
uint8_t lp_Hex_Hex_AlgebraicNumber_isReal(lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lp_Hex_Hex_DyadicRootIsolation_toRefined_x3f(lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
size_t lean_usize_sub(size_t, size_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_AlgebraicRoot_isReal(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_AlgebraicPoly_roots(lean_object*);
lean_object* lp_Hex_Hex_ZPoly_factorize(lean_object*);
extern lean_object* lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
lean_object* lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_AlgebraicRoot_exactFactor_x3f(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_separationDepth(lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lp_Hex_Hex_ZPoly_isolateComplexRoots_x3f___redArg(lean_object*, lean_object*, uint8_t);
size_t lean_array_size(lean_object*);
lean_object* lp_Hex_Hex_AlgebraicRoot_exactIn_x3f___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE(lean_object*, lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(lean_object*, lean_object*);
lean_object* lean_array_mk(lean_object*);
uint8_t lp_Hex_Hex_AlgebraicNumber_realCompare(lean_object*, lean_object*);
lean_object* l_Ordering_ctorIdx(uint8_t);
lean_object* lp_Hex_Hex_AlgebraicNumber_sqrt(lean_object*);
uint8_t lp_Hex_Hex_AlgebraicNumber_beq(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE___boxed(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_ZPoly_algebraicRoots(lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lp_Hex_Hex_AlgebraicPoly_ofArray(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofArray(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofAlgebraic_x3f(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_x3f(lean_object*);
static const lean_array_object lp_Hex_Hex_RealRootSet_toArray___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_RealRootSet_toArray___closed__0 = (const lean_object*)&lp_Hex_Hex_RealRootSet_toArray___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_toArray(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_RealRootSet_contains(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_contains___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0___boxed(lean_object*, lean_object*);
static const lean_string_object lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 42, .m_capacity = 42, .m_length = 41, .m_data = "AlgebraicRoot.exact: certification failed"};
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__2(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1(lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4(uint8_t, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__0_value;
static const lean_closure_object lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__1 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__0_value),((lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__1_value)}};
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__2 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__2_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__3_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__3_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__3_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_roots(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0 = (const lean_object*)&lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_realAlgebraicRoots(lean_object*);
static lean_once_cell_t lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt_x3f(lean_object*);
static const lean_string_object lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 53, .m_capacity = 53, .m_length = 52, .m_data = "RealAlgebraicNumber.sqrt: nonnegative root not found"};
static const lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic(lean_object* v_f_1_){
_start:
{
lean_inc_ref(v_f_1_);
return v_f_1_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic___boxed(lean_object* v_f_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic(v_f_2_);
lean_dec_ref(v_f_2_);
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(size_t v_sz_4_, size_t v_i_5_, lean_object* v_bs_6_){
_start:
{
uint8_t v___x_7_; 
v___x_7_ = lean_usize_dec_lt(v_i_5_, v_sz_4_);
if (v___x_7_ == 0)
{
return v_bs_6_;
}
else
{
lean_object* v_v_8_; lean_object* v___x_9_; lean_object* v_bs_x27_10_; size_t v___x_11_; size_t v___x_12_; lean_object* v___x_13_; 
v_v_8_ = lean_array_uget(v_bs_6_, v_i_5_);
v___x_9_ = lean_unsigned_to_nat(0u);
v_bs_x27_10_ = lean_array_uset(v_bs_6_, v_i_5_, v___x_9_);
v___x_11_ = ((size_t)1ULL);
v___x_12_ = lean_usize_add(v_i_5_, v___x_11_);
v___x_13_ = lean_array_uset(v_bs_x27_10_, v_i_5_, v_v_8_);
v_i_5_ = v___x_12_;
v_bs_6_ = v___x_13_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0___boxed(lean_object* v_sz_15_, lean_object* v_i_16_, lean_object* v_bs_17_){
_start:
{
size_t v_sz_boxed_18_; size_t v_i_boxed_19_; lean_object* v_res_20_; 
v_sz_boxed_18_ = lean_unbox_usize(v_sz_15_);
lean_dec(v_sz_15_);
v_i_boxed_19_ = lean_unbox_usize(v_i_16_);
lean_dec(v_i_16_);
v_res_20_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(v_sz_boxed_18_, v_i_boxed_19_, v_bs_17_);
return v_res_20_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofArray(lean_object* v_coeffs_21_){
_start:
{
size_t v_sz_22_; size_t v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; 
v_sz_22_ = lean_array_size(v_coeffs_21_);
v___x_23_ = ((size_t)0ULL);
v___x_24_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(v_sz_22_, v___x_23_, v_coeffs_21_);
v___x_25_ = lp_Hex_Hex_AlgebraicPoly_ofArray(v___x_24_);
return v___x_25_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(lean_object* v_as_26_, size_t v_i_27_, size_t v_stop_28_){
_start:
{
uint8_t v___x_29_; 
v___x_29_ = lean_usize_dec_eq(v_i_27_, v_stop_28_);
if (v___x_29_ == 0)
{
lean_object* v___x_30_; uint8_t v___x_31_; 
v___x_30_ = lean_array_uget_borrowed(v_as_26_, v_i_27_);
v___x_31_ = lp_Hex_Hex_AlgebraicNumber_isReal(v___x_30_);
if (v___x_31_ == 0)
{
uint8_t v___x_32_; 
v___x_32_ = 1;
return v___x_32_;
}
else
{
size_t v___x_33_; size_t v___x_34_; 
v___x_33_ = ((size_t)1ULL);
v___x_34_ = lean_usize_add(v_i_27_, v___x_33_);
v_i_27_ = v___x_34_;
goto _start;
}
}
else
{
uint8_t v___x_36_; 
v___x_36_ = 0;
return v___x_36_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0___boxed(lean_object* v_as_37_, lean_object* v_i_38_, lean_object* v_stop_39_){
_start:
{
size_t v_i_boxed_40_; size_t v_stop_boxed_41_; uint8_t v_res_42_; lean_object* v_r_43_; 
v_i_boxed_40_ = lean_unbox_usize(v_i_38_);
lean_dec(v_i_38_);
v_stop_boxed_41_ = lean_unbox_usize(v_stop_39_);
lean_dec(v_stop_39_);
v_res_42_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(v_as_37_, v_i_boxed_40_, v_stop_boxed_41_);
lean_dec_ref(v_as_37_);
v_r_43_ = lean_box(v_res_42_);
return v_r_43_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofAlgebraic_x3f(lean_object* v_f_44_){
_start:
{
lean_object* v___x_45_; lean_object* v___x_46_; uint8_t v___x_47_; 
v___x_45_ = lean_unsigned_to_nat(0u);
v___x_46_ = lean_array_get_size(v_f_44_);
v___x_47_ = lean_nat_dec_lt(v___x_45_, v___x_46_);
if (v___x_47_ == 0)
{
lean_object* v___x_48_; 
v___x_48_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_48_, 0, v_f_44_);
return v___x_48_;
}
else
{
if (v___x_47_ == 0)
{
lean_object* v___x_49_; 
v___x_49_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_49_, 0, v_f_44_);
return v___x_49_;
}
else
{
size_t v___x_50_; size_t v___x_51_; uint8_t v___x_52_; 
v___x_50_ = ((size_t)0ULL);
v___x_51_ = lean_usize_of_nat(v___x_46_);
v___x_52_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(v_f_44_, v___x_50_, v___x_51_);
if (v___x_52_ == 0)
{
lean_object* v___x_53_; 
v___x_53_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_53_, 0, v_f_44_);
return v___x_53_;
}
else
{
lean_object* v___x_54_; 
lean_dec_ref(v_f_44_);
v___x_54_ = lean_box(0);
return v___x_54_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx(lean_object* v_x_55_){
_start:
{
if (lean_obj_tag(v_x_55_) == 0)
{
lean_object* v___x_56_; 
v___x_56_ = lean_unsigned_to_nat(0u);
return v___x_56_;
}
else
{
lean_object* v___x_57_; 
v___x_57_ = lean_unsigned_to_nat(1u);
return v___x_57_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx___boxed(lean_object* v_x_58_){
_start:
{
lean_object* v_res_59_; 
v_res_59_ = lp_Hex_Hex_RealRootSet_ctorIdx(v_x_58_);
lean_dec(v_x_58_);
return v_res_59_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___redArg(lean_object* v_t_60_, lean_object* v_k_61_){
_start:
{
if (lean_obj_tag(v_t_60_) == 0)
{
return v_k_61_;
}
else
{
lean_object* v_roots_62_; lean_object* v___x_63_; 
v_roots_62_ = lean_ctor_get(v_t_60_, 0);
lean_inc_ref(v_roots_62_);
lean_dec_ref_known(v_t_60_, 1);
v___x_63_ = lean_apply_1(v_k_61_, v_roots_62_);
return v___x_63_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim(lean_object* v_motive_64_, lean_object* v_ctorIdx_65_, lean_object* v_t_66_, lean_object* v_h_67_, lean_object* v_k_68_){
_start:
{
lean_object* v___x_69_; 
v___x_69_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_66_, v_k_68_);
return v___x_69_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___boxed(lean_object* v_motive_70_, lean_object* v_ctorIdx_71_, lean_object* v_t_72_, lean_object* v_h_73_, lean_object* v_k_74_){
_start:
{
lean_object* v_res_75_; 
v_res_75_ = lp_Hex_Hex_RealRootSet_ctorElim(v_motive_70_, v_ctorIdx_71_, v_t_72_, v_h_73_, v_k_74_);
lean_dec(v_ctorIdx_71_);
return v_res_75_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim___redArg(lean_object* v_t_76_, lean_object* v_all_77_){
_start:
{
lean_object* v___x_78_; 
v___x_78_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_76_, v_all_77_);
return v___x_78_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim(lean_object* v_motive_79_, lean_object* v_t_80_, lean_object* v_h_81_, lean_object* v_all_82_){
_start:
{
lean_object* v___x_83_; 
v___x_83_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_80_, v_all_82_);
return v___x_83_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim___redArg(lean_object* v_t_84_, lean_object* v_finite_85_){
_start:
{
lean_object* v___x_86_; 
v___x_86_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_84_, v_finite_85_);
return v___x_86_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim(lean_object* v_motive_87_, lean_object* v_t_88_, lean_object* v_h_89_, lean_object* v_finite_90_){
_start:
{
lean_object* v___x_91_; 
v___x_91_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_88_, v_finite_90_);
return v___x_91_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_x3f(lean_object* v_x_92_){
_start:
{
if (lean_obj_tag(v_x_92_) == 0)
{
lean_object* v___x_93_; 
v___x_93_ = lean_box(0);
return v___x_93_;
}
else
{
lean_object* v_roots_94_; lean_object* v___x_96_; uint8_t v_isShared_97_; uint8_t v_isSharedCheck_101_; 
v_roots_94_ = lean_ctor_get(v_x_92_, 0);
v_isSharedCheck_101_ = !lean_is_exclusive(v_x_92_);
if (v_isSharedCheck_101_ == 0)
{
v___x_96_ = v_x_92_;
v_isShared_97_ = v_isSharedCheck_101_;
goto v_resetjp_95_;
}
else
{
lean_inc(v_roots_94_);
lean_dec(v_x_92_);
v___x_96_ = lean_box(0);
v_isShared_97_ = v_isSharedCheck_101_;
goto v_resetjp_95_;
}
v_resetjp_95_:
{
lean_object* v___x_99_; 
if (v_isShared_97_ == 0)
{
v___x_99_ = v___x_96_;
goto v_reusejp_98_;
}
else
{
lean_object* v_reuseFailAlloc_100_; 
v_reuseFailAlloc_100_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_100_, 0, v_roots_94_);
v___x_99_ = v_reuseFailAlloc_100_;
goto v_reusejp_98_;
}
v_reusejp_98_:
{
return v___x_99_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_toArray(lean_object* v_roots_104_){
_start:
{
lean_object* v___x_105_; 
v___x_105_ = lp_Hex_Hex_RealRootSet_finite_x3f(v_roots_104_);
if (lean_obj_tag(v___x_105_) == 0)
{
lean_object* v___x_106_; 
v___x_106_ = ((lean_object*)(lp_Hex_Hex_RealRootSet_toArray___closed__0));
return v___x_106_;
}
else
{
lean_object* v_val_107_; 
v_val_107_ = lean_ctor_get(v___x_105_, 0);
lean_inc(v_val_107_);
lean_dec_ref_known(v___x_105_, 1);
return v_val_107_;
}
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(lean_object* v_a_108_, lean_object* v_as_109_, size_t v_i_110_, size_t v_stop_111_){
_start:
{
uint8_t v___x_112_; 
v___x_112_ = lean_usize_dec_eq(v_i_110_, v_stop_111_);
if (v___x_112_ == 0)
{
lean_object* v___x_113_; lean_object* v_root_114_; uint8_t v___x_115_; 
v___x_113_ = lean_array_uget_borrowed(v_as_109_, v_i_110_);
v_root_114_ = lean_ctor_get(v___x_113_, 0);
lean_inc_ref(v_a_108_);
lean_inc_ref(v_root_114_);
v___x_115_ = lp_Hex_Hex_AlgebraicNumber_beq(v_root_114_, v_a_108_);
if (v___x_115_ == 0)
{
size_t v___x_116_; size_t v___x_117_; 
v___x_116_ = ((size_t)1ULL);
v___x_117_ = lean_usize_add(v_i_110_, v___x_116_);
v_i_110_ = v___x_117_;
goto _start;
}
else
{
lean_dec_ref(v_a_108_);
return v___x_115_;
}
}
else
{
uint8_t v___x_119_; 
lean_dec_ref(v_a_108_);
v___x_119_ = 0;
return v___x_119_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0___boxed(lean_object* v_a_120_, lean_object* v_as_121_, lean_object* v_i_122_, lean_object* v_stop_123_){
_start:
{
size_t v_i_boxed_124_; size_t v_stop_boxed_125_; uint8_t v_res_126_; lean_object* v_r_127_; 
v_i_boxed_124_ = lean_unbox_usize(v_i_122_);
lean_dec(v_i_122_);
v_stop_boxed_125_ = lean_unbox_usize(v_stop_123_);
lean_dec(v_stop_123_);
v_res_126_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(v_a_120_, v_as_121_, v_i_boxed_124_, v_stop_boxed_125_);
lean_dec_ref(v_as_121_);
v_r_127_ = lean_box(v_res_126_);
return v_r_127_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_RealRootSet_contains(lean_object* v_roots_128_, lean_object* v_a_129_){
_start:
{
if (lean_obj_tag(v_roots_128_) == 0)
{
uint8_t v___x_130_; 
lean_dec_ref(v_a_129_);
v___x_130_ = 1;
return v___x_130_;
}
else
{
lean_object* v_roots_131_; lean_object* v___x_132_; lean_object* v___x_133_; uint8_t v___x_134_; 
v_roots_131_ = lean_ctor_get(v_roots_128_, 0);
v___x_132_ = lean_unsigned_to_nat(0u);
v___x_133_ = lean_array_get_size(v_roots_131_);
v___x_134_ = lean_nat_dec_lt(v___x_132_, v___x_133_);
if (v___x_134_ == 0)
{
lean_dec_ref(v_a_129_);
return v___x_134_;
}
else
{
if (v___x_134_ == 0)
{
lean_dec_ref(v_a_129_);
return v___x_134_;
}
else
{
size_t v___x_135_; size_t v___x_136_; uint8_t v___x_137_; 
v___x_135_ = ((size_t)0ULL);
v___x_136_ = lean_usize_of_nat(v___x_133_);
v___x_137_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(v_a_129_, v_roots_131_, v___x_135_, v___x_136_);
return v___x_137_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_contains___boxed(lean_object* v_roots_138_, lean_object* v_a_139_){
_start:
{
uint8_t v_res_140_; lean_object* v_r_141_; 
v_res_140_ = lp_Hex_Hex_RealRootSet_contains(v_roots_138_, v_a_139_);
lean_dec(v_roots_138_);
v_r_141_ = lean_box(v_res_140_);
return v_r_141_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f(lean_object* v_r_142_){
_start:
{
lean_object* v_root_143_; lean_object* v_multiplicity_144_; lean_object* v___x_146_; uint8_t v_isShared_147_; uint8_t v_isSharedCheck_161_; 
v_root_143_ = lean_ctor_get(v_r_142_, 0);
v_multiplicity_144_ = lean_ctor_get(v_r_142_, 1);
v_isSharedCheck_161_ = !lean_is_exclusive(v_r_142_);
if (v_isSharedCheck_161_ == 0)
{
v___x_146_ = v_r_142_;
v_isShared_147_ = v_isSharedCheck_161_;
goto v_resetjp_145_;
}
else
{
lean_inc(v_multiplicity_144_);
lean_inc(v_root_143_);
lean_dec(v_r_142_);
v___x_146_ = lean_box(0);
v_isShared_147_ = v_isSharedCheck_161_;
goto v_resetjp_145_;
}
v_resetjp_145_:
{
lean_object* v___x_148_; 
v___x_148_ = lp_Hex_Hex_RealAlgebraicNumber_ofRoot_x3f(v_root_143_);
if (lean_obj_tag(v___x_148_) == 0)
{
lean_object* v___x_149_; 
lean_del_object(v___x_146_);
lean_dec(v_multiplicity_144_);
v___x_149_ = lean_box(0);
return v___x_149_;
}
else
{
lean_object* v_val_150_; lean_object* v___x_152_; uint8_t v_isShared_153_; uint8_t v_isSharedCheck_160_; 
v_val_150_ = lean_ctor_get(v___x_148_, 0);
v_isSharedCheck_160_ = !lean_is_exclusive(v___x_148_);
if (v_isSharedCheck_160_ == 0)
{
v___x_152_ = v___x_148_;
v_isShared_153_ = v_isSharedCheck_160_;
goto v_resetjp_151_;
}
else
{
lean_inc(v_val_150_);
lean_dec(v___x_148_);
v___x_152_ = lean_box(0);
v_isShared_153_ = v_isSharedCheck_160_;
goto v_resetjp_151_;
}
v_resetjp_151_:
{
lean_object* v___x_155_; 
if (v_isShared_147_ == 0)
{
lean_ctor_set(v___x_146_, 0, v_val_150_);
v___x_155_ = v___x_146_;
goto v_reusejp_154_;
}
else
{
lean_object* v_reuseFailAlloc_159_; 
v_reuseFailAlloc_159_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_159_, 0, v_val_150_);
lean_ctor_set(v_reuseFailAlloc_159_, 1, v_multiplicity_144_);
v___x_155_ = v_reuseFailAlloc_159_;
goto v_reusejp_154_;
}
v_reusejp_154_:
{
lean_object* v___x_157_; 
if (v_isShared_153_ == 0)
{
lean_ctor_set(v___x_152_, 0, v___x_155_);
v___x_157_ = v___x_152_;
goto v_reusejp_156_;
}
else
{
lean_object* v_reuseFailAlloc_158_; 
v_reuseFailAlloc_158_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_158_, 0, v___x_155_);
v___x_157_ = v_reuseFailAlloc_158_;
goto v_reusejp_156_;
}
v_reusejp_156_:
{
return v___x_157_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(lean_object* v___x_162_, lean_object* v_as_163_, size_t v_i_164_, size_t v_stop_165_, lean_object* v_b_166_){
_start:
{
lean_object* v___y_168_; uint8_t v___x_172_; 
v___x_172_ = lean_usize_dec_eq(v_i_164_, v_stop_165_);
if (v___x_172_ == 0)
{
if (lean_obj_tag(v_b_166_) == 0)
{
lean_object* v___x_173_; lean_object* v_fst_174_; lean_object* v___x_175_; 
v___x_173_ = lean_array_uget_borrowed(v_as_163_, v_i_164_);
v_fst_174_ = lean_ctor_get(v___x_173_, 0);
lean_inc(v_fst_174_);
v___x_175_ = lp_Hex_Hex_AlgebraicRoot_exactFactor_x3f(v___x_162_, v_fst_174_);
v___y_168_ = v___x_175_;
goto v___jp_167_;
}
else
{
v___y_168_ = v_b_166_;
goto v___jp_167_;
}
}
else
{
return v_b_166_;
}
v___jp_167_:
{
size_t v___x_169_; size_t v___x_170_; 
v___x_169_ = ((size_t)1ULL);
v___x_170_ = lean_usize_add(v_i_164_, v___x_169_);
v_i_164_ = v___x_170_;
v_b_166_ = v___y_168_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1___boxed(lean_object* v___x_176_, lean_object* v_as_177_, lean_object* v_i_178_, lean_object* v_stop_179_, lean_object* v_b_180_){
_start:
{
size_t v_i_boxed_181_; size_t v_stop_boxed_182_; lean_object* v_res_183_; 
v_i_boxed_181_ = lean_unbox_usize(v_i_178_);
lean_dec(v_i_178_);
v_stop_boxed_182_ = lean_unbox_usize(v_stop_179_);
lean_dec(v_stop_179_);
v_res_183_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(v___x_176_, v_as_177_, v_i_boxed_181_, v_stop_boxed_182_, v_b_180_);
lean_dec_ref(v_as_177_);
lean_dec_ref(v___x_176_);
return v_res_183_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(lean_object* v_xs_184_, lean_object* v_ys_185_, lean_object* v_x_186_){
_start:
{
lean_object* v_zero_187_; uint8_t v_isZero_188_; 
v_zero_187_ = lean_unsigned_to_nat(0u);
v_isZero_188_ = lean_nat_dec_eq(v_x_186_, v_zero_187_);
if (v_isZero_188_ == 1)
{
lean_dec(v_x_186_);
return v_isZero_188_;
}
else
{
lean_object* v_one_189_; lean_object* v_n_190_; lean_object* v___x_191_; lean_object* v___x_192_; uint8_t v___x_193_; 
v_one_189_ = lean_unsigned_to_nat(1u);
v_n_190_ = lean_nat_sub(v_x_186_, v_one_189_);
lean_dec(v_x_186_);
v___x_191_ = lean_array_fget_borrowed(v_xs_184_, v_n_190_);
v___x_192_ = lean_array_fget_borrowed(v_ys_185_, v_n_190_);
v___x_193_ = lean_int_dec_eq(v___x_191_, v___x_192_);
if (v___x_193_ == 0)
{
lean_dec(v_n_190_);
return v___x_193_;
}
else
{
v_x_186_ = v_n_190_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg___boxed(lean_object* v_xs_195_, lean_object* v_ys_196_, lean_object* v_x_197_){
_start:
{
uint8_t v_res_198_; lean_object* v_r_199_; 
v_res_198_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(v_xs_195_, v_ys_196_, v_x_197_);
lean_dec_ref(v_ys_196_);
lean_dec_ref(v_xs_195_);
v_r_199_ = lean_box(v_res_198_);
return v_r_199_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(lean_object* v_xs_200_, lean_object* v_ys_201_){
_start:
{
lean_object* v___x_202_; lean_object* v___x_203_; uint8_t v___x_204_; 
v___x_202_ = lean_array_get_size(v_xs_200_);
v___x_203_ = lean_array_get_size(v_ys_201_);
v___x_204_ = lean_nat_dec_eq(v___x_202_, v___x_203_);
if (v___x_204_ == 0)
{
return v___x_204_;
}
else
{
uint8_t v___x_205_; 
v___x_205_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(v_xs_200_, v_ys_201_, v___x_202_);
return v___x_205_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0___boxed(lean_object* v_xs_206_, lean_object* v_ys_207_){
_start:
{
uint8_t v_res_208_; lean_object* v_r_209_; 
v_res_208_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_xs_206_, v_ys_207_);
lean_dec_ref(v_ys_207_);
lean_dec_ref(v_xs_206_);
v_r_209_ = lean_box(v_res_208_);
return v_r_209_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0(lean_object* v_a_210_, lean_object* v_b_211_){
_start:
{
uint8_t v_decide_212_; 
v_decide_212_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_a_210_, v_b_211_);
return v_decide_212_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0___boxed(lean_object* v_a_213_, lean_object* v_b_214_){
_start:
{
uint8_t v_res_215_; lean_object* v_r_216_; 
v_res_215_ = lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0(v_a_213_, v_b_214_);
lean_dec_ref(v_b_214_);
lean_dec_ref(v_a_213_);
v_r_216_ = lean_box(v_res_215_);
return v_r_216_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg(lean_object* v_p_218_, lean_object* v_factors_219_, lean_object* v_fallback_220_, lean_object* v_r_221_){
_start:
{
lean_object* v_root_222_; lean_object* v_multiplicity_223_; lean_object* v___y_225_; lean_object* v___y_242_; lean_object* v_p_244_; uint8_t v_decide_245_; 
v_root_222_ = lean_ctor_get(v_r_221_, 0);
v_multiplicity_223_ = lean_ctor_get(v_r_221_, 1);
v_p_244_ = lean_ctor_get(v_root_222_, 0);
v_decide_245_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_p_218_, v_p_244_);
if (v_decide_245_ == 0)
{
lean_object* v___x_246_; 
v___x_246_ = lean_apply_1(v_fallback_220_, v_r_221_);
return v___x_246_;
}
else
{
uint8_t v___x_247_; 
lean_inc(v_multiplicity_223_);
lean_inc_ref(v_root_222_);
lean_dec_ref(v_r_221_);
lean_dec_ref(v_fallback_220_);
v___x_247_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_222_);
if (v___x_247_ == 0)
{
lean_object* v___x_248_; 
lean_dec(v_multiplicity_223_);
lean_dec_ref(v_root_222_);
v___x_248_ = lean_box(0);
return v___x_248_;
}
else
{
lean_object* v_factors_249_; lean_object* v___x_250_; lean_object* v___x_251_; uint8_t v___x_252_; 
v_factors_249_ = lean_ctor_get(v_factors_219_, 1);
v___x_250_ = lean_unsigned_to_nat(0u);
v___x_251_ = lean_array_get_size(v_factors_249_);
v___x_252_ = lean_nat_dec_lt(v___x_250_, v___x_251_);
if (v___x_252_ == 0)
{
lean_dec_ref(v_root_222_);
goto v___jp_237_;
}
else
{
lean_object* v___x_253_; uint8_t v___x_254_; 
v___x_253_ = lean_box(0);
v___x_254_ = lean_nat_dec_le(v___x_251_, v___x_251_);
if (v___x_254_ == 0)
{
if (v___x_252_ == 0)
{
lean_dec_ref(v_root_222_);
goto v___jp_237_;
}
else
{
size_t v___x_255_; size_t v___x_256_; lean_object* v___x_257_; 
v___x_255_ = ((size_t)0ULL);
v___x_256_ = lean_usize_of_nat(v___x_251_);
v___x_257_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(v_root_222_, v_factors_249_, v___x_255_, v___x_256_, v___x_253_);
lean_dec_ref(v_root_222_);
v___y_242_ = v___x_257_;
goto v___jp_241_;
}
}
else
{
size_t v___x_258_; size_t v___x_259_; lean_object* v___x_260_; 
v___x_258_ = ((size_t)0ULL);
v___x_259_ = lean_usize_of_nat(v___x_251_);
v___x_260_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(v_root_222_, v_factors_249_, v___x_258_, v___x_259_, v___x_253_);
lean_dec_ref(v_root_222_);
v___y_242_ = v___x_260_;
goto v___jp_241_;
}
}
}
}
v___jp_224_:
{
lean_object* v___x_226_; 
v___x_226_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___y_225_);
if (lean_obj_tag(v___x_226_) == 0)
{
lean_object* v___x_227_; 
lean_dec(v_multiplicity_223_);
v___x_227_ = lean_box(0);
return v___x_227_;
}
else
{
lean_object* v_val_228_; lean_object* v___x_230_; uint8_t v_isShared_231_; uint8_t v_isSharedCheck_236_; 
v_val_228_ = lean_ctor_get(v___x_226_, 0);
v_isSharedCheck_236_ = !lean_is_exclusive(v___x_226_);
if (v_isSharedCheck_236_ == 0)
{
v___x_230_ = v___x_226_;
v_isShared_231_ = v_isSharedCheck_236_;
goto v_resetjp_229_;
}
else
{
lean_inc(v_val_228_);
lean_dec(v___x_226_);
v___x_230_ = lean_box(0);
v_isShared_231_ = v_isSharedCheck_236_;
goto v_resetjp_229_;
}
v_resetjp_229_:
{
lean_object* v___x_232_; lean_object* v___x_234_; 
v___x_232_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_232_, 0, v_val_228_);
lean_ctor_set(v___x_232_, 1, v_multiplicity_223_);
if (v_isShared_231_ == 0)
{
lean_ctor_set(v___x_230_, 0, v___x_232_);
v___x_234_ = v___x_230_;
goto v_reusejp_233_;
}
else
{
lean_object* v_reuseFailAlloc_235_; 
v_reuseFailAlloc_235_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_235_, 0, v___x_232_);
v___x_234_ = v_reuseFailAlloc_235_;
goto v_reusejp_233_;
}
v_reusejp_233_:
{
return v___x_234_;
}
}
}
}
v___jp_237_:
{
lean_object* v___x_238_; lean_object* v___x_239_; lean_object* v___x_240_; 
v___x_238_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
v___x_239_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0));
v___x_240_ = lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_box(0), v___x_238_, v___x_239_);
v___y_225_ = v___x_240_;
goto v___jp_224_;
}
v___jp_241_:
{
if (lean_obj_tag(v___y_242_) == 0)
{
goto v___jp_237_;
}
else
{
lean_object* v_val_243_; 
v_val_243_ = lean_ctor_get(v___y_242_, 0);
lean_inc(v_val_243_);
lean_dec_ref_known(v___y_242_, 1);
v___y_225_ = v_val_243_;
goto v___jp_224_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___boxed(lean_object* v_p_261_, lean_object* v_factors_262_, lean_object* v_fallback_263_, lean_object* v_r_264_){
_start:
{
lean_object* v_res_265_; 
v_res_265_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg(v_p_261_, v_factors_262_, v_fallback_263_, v_r_264_);
lean_dec_ref(v_factors_262_);
lean_dec_ref(v_p_261_);
return v_res_265_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker(lean_object* v_p_266_, lean_object* v_factors_267_, lean_object* v___hfactor_268_, lean_object* v_fallback_269_, lean_object* v_r_270_){
_start:
{
lean_object* v___x_271_; 
v___x_271_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg(v_p_266_, v_factors_267_, v_fallback_269_, v_r_270_);
return v___x_271_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___boxed(lean_object* v_p_272_, lean_object* v_factors_273_, lean_object* v___hfactor_274_, lean_object* v_fallback_275_, lean_object* v_r_276_){
_start:
{
lean_object* v_res_277_; 
v_res_277_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker(v_p_272_, v_factors_273_, v___hfactor_274_, v_fallback_275_, v_r_276_);
lean_dec_ref(v_factors_273_);
lean_dec_ref(v_p_272_);
return v_res_277_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1(lean_object* v_xs_278_, lean_object* v_ys_279_, lean_object* v_hsz_280_, lean_object* v_x_281_, lean_object* v_x_282_){
_start:
{
uint8_t v___x_283_; 
v___x_283_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(v_xs_278_, v_ys_279_, v_x_281_);
return v___x_283_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___boxed(lean_object* v_xs_284_, lean_object* v_ys_285_, lean_object* v_hsz_286_, lean_object* v_x_287_, lean_object* v_x_288_){
_start:
{
uint8_t v_res_289_; lean_object* v_r_290_; 
v_res_289_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1(v_xs_284_, v_ys_285_, v_hsz_286_, v_x_287_, v_x_288_);
lean_dec_ref(v_ys_285_);
lean_dec_ref(v_xs_284_);
v_r_290_ = lean_box(v_res_289_);
return v_r_290_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg(lean_object* v_p_291_, lean_object* v_isolations_292_, lean_object* v_refined_293_, lean_object* v_fallback_294_, lean_object* v_r_295_){
_start:
{
lean_object* v_root_296_; lean_object* v_multiplicity_297_; lean_object* v___y_299_; lean_object* v_p_311_; uint8_t v_decide_312_; 
v_root_296_ = lean_ctor_get(v_r_295_, 0);
v_multiplicity_297_ = lean_ctor_get(v_r_295_, 1);
v_p_311_ = lean_ctor_get(v_root_296_, 0);
v_decide_312_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_p_291_, v_p_311_);
if (v_decide_312_ == 0)
{
lean_object* v___x_313_; 
lean_dec_ref(v_refined_293_);
v___x_313_ = lean_apply_1(v_fallback_294_, v_r_295_);
return v___x_313_;
}
else
{
uint8_t v___x_314_; 
lean_inc(v_multiplicity_297_);
lean_inc_ref(v_root_296_);
lean_dec_ref(v_r_295_);
lean_dec_ref(v_fallback_294_);
v___x_314_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_296_);
if (v___x_314_ == 0)
{
lean_object* v___x_315_; 
lean_dec(v_multiplicity_297_);
lean_dec_ref(v_root_296_);
lean_dec_ref(v_refined_293_);
v___x_315_ = lean_box(0);
return v___x_315_;
}
else
{
lean_object* v_exact_316_; 
v_exact_316_ = lp_Hex_Hex_AlgebraicRoot_exactIn_x3f___redArg(v_root_296_, v_isolations_292_, v_refined_293_);
if (lean_obj_tag(v_exact_316_) == 0)
{
lean_object* v___x_317_; lean_object* v___x_318_; lean_object* v___x_319_; 
v___x_317_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
v___x_318_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0));
v___x_319_ = lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_box(0), v___x_317_, v___x_318_);
v___y_299_ = v___x_319_;
goto v___jp_298_;
}
else
{
lean_object* v_val_320_; 
v_val_320_ = lean_ctor_get(v_exact_316_, 0);
lean_inc(v_val_320_);
lean_dec_ref_known(v_exact_316_, 1);
v___y_299_ = v_val_320_;
goto v___jp_298_;
}
}
}
v___jp_298_:
{
lean_object* v___x_300_; 
v___x_300_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___y_299_);
if (lean_obj_tag(v___x_300_) == 0)
{
lean_object* v___x_301_; 
lean_dec(v_multiplicity_297_);
v___x_301_ = lean_box(0);
return v___x_301_;
}
else
{
lean_object* v_val_302_; lean_object* v___x_304_; uint8_t v_isShared_305_; uint8_t v_isSharedCheck_310_; 
v_val_302_ = lean_ctor_get(v___x_300_, 0);
v_isSharedCheck_310_ = !lean_is_exclusive(v___x_300_);
if (v_isSharedCheck_310_ == 0)
{
v___x_304_ = v___x_300_;
v_isShared_305_ = v_isSharedCheck_310_;
goto v_resetjp_303_;
}
else
{
lean_inc(v_val_302_);
lean_dec(v___x_300_);
v___x_304_ = lean_box(0);
v_isShared_305_ = v_isSharedCheck_310_;
goto v_resetjp_303_;
}
v_resetjp_303_:
{
lean_object* v___x_306_; lean_object* v___x_308_; 
v___x_306_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_306_, 0, v_val_302_);
lean_ctor_set(v___x_306_, 1, v_multiplicity_297_);
if (v_isShared_305_ == 0)
{
lean_ctor_set(v___x_304_, 0, v___x_306_);
v___x_308_ = v___x_304_;
goto v_reusejp_307_;
}
else
{
lean_object* v_reuseFailAlloc_309_; 
v_reuseFailAlloc_309_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_309_, 0, v___x_306_);
v___x_308_ = v_reuseFailAlloc_309_;
goto v_reusejp_307_;
}
v_reusejp_307_:
{
return v___x_308_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg___boxed(lean_object* v_p_321_, lean_object* v_isolations_322_, lean_object* v_refined_323_, lean_object* v_fallback_324_, lean_object* v_r_325_){
_start:
{
lean_object* v_res_326_; 
v_res_326_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg(v_p_321_, v_isolations_322_, v_refined_323_, v_fallback_324_, v_r_325_);
lean_dec_ref(v_isolations_322_);
lean_dec_ref(v_p_321_);
return v_res_326_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker(lean_object* v_p_327_, lean_object* v_squarefree_328_, lean_object* v_isolations_329_, lean_object* v_refined_330_, lean_object* v_hisolate_331_, lean_object* v_hrefine_332_, lean_object* v_fallback_333_, lean_object* v_r_334_){
_start:
{
lean_object* v___x_335_; 
v___x_335_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg(v_p_327_, v_isolations_329_, v_refined_330_, v_fallback_333_, v_r_334_);
return v___x_335_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___boxed(lean_object* v_p_336_, lean_object* v_squarefree_337_, lean_object* v_isolations_338_, lean_object* v_refined_339_, lean_object* v_hisolate_340_, lean_object* v_hrefine_341_, lean_object* v_fallback_342_, lean_object* v_r_343_){
_start:
{
lean_object* v_res_344_; 
v_res_344_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker(v_p_336_, v_squarefree_337_, v_isolations_338_, v_refined_339_, v_hisolate_340_, v_hrefine_341_, v_fallback_342_, v_r_343_);
lean_dec_ref(v_isolations_338_);
lean_dec_ref(v_p_336_);
return v_res_344_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__2(lean_object* v_a_345_){
_start:
{
lean_object* v___x_346_; 
v___x_346_ = lean_nat_to_int(v_a_345_);
return v___x_346_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0(lean_object* v_a_347_, lean_object* v_as_348_, size_t v_i_349_, size_t v_stop_350_){
_start:
{
uint8_t v___x_351_; 
v___x_351_ = lean_usize_dec_eq(v_i_349_, v_stop_350_);
if (v___x_351_ == 0)
{
lean_object* v___x_352_; uint8_t v_decide_353_; 
v___x_352_ = lean_array_uget_borrowed(v_as_348_, v_i_349_);
v_decide_353_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_a_347_, v___x_352_);
if (v_decide_353_ == 0)
{
size_t v___x_354_; size_t v___x_355_; 
v___x_354_ = ((size_t)1ULL);
v___x_355_ = lean_usize_add(v_i_349_, v___x_354_);
v_i_349_ = v___x_355_;
goto _start;
}
else
{
return v_decide_353_;
}
}
else
{
uint8_t v___x_357_; 
v___x_357_ = 0;
return v___x_357_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0___boxed(lean_object* v_a_358_, lean_object* v_as_359_, lean_object* v_i_360_, lean_object* v_stop_361_){
_start:
{
size_t v_i_boxed_362_; size_t v_stop_boxed_363_; uint8_t v_res_364_; lean_object* v_r_365_; 
v_i_boxed_362_ = lean_unbox_usize(v_i_360_);
lean_dec(v_i_360_);
v_stop_boxed_363_ = lean_unbox_usize(v_stop_361_);
lean_dec(v_stop_361_);
v_res_364_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0(v_a_358_, v_as_359_, v_i_boxed_362_, v_stop_boxed_363_);
lean_dec_ref(v_as_359_);
lean_dec_ref(v_a_358_);
v_r_365_ = lean_box(v_res_364_);
return v_r_365_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0(lean_object* v_as_366_, lean_object* v_a_367_){
_start:
{
lean_object* v___x_368_; lean_object* v___x_369_; uint8_t v___x_370_; 
v___x_368_ = lean_unsigned_to_nat(0u);
v___x_369_ = lean_array_get_size(v_as_366_);
v___x_370_ = lean_nat_dec_lt(v___x_368_, v___x_369_);
if (v___x_370_ == 0)
{
return v___x_370_;
}
else
{
if (v___x_370_ == 0)
{
return v___x_370_;
}
else
{
size_t v___x_371_; size_t v___x_372_; uint8_t v___x_373_; 
v___x_371_ = ((size_t)0ULL);
v___x_372_ = lean_usize_of_nat(v___x_369_);
v___x_373_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0(v_a_367_, v_as_366_, v___x_371_, v___x_372_);
return v___x_373_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0___boxed(lean_object* v_as_374_, lean_object* v_a_375_){
_start:
{
uint8_t v_res_376_; lean_object* v_r_377_; 
v_res_376_ = lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0(v_as_374_, v_a_375_);
lean_dec_ref(v_a_375_);
lean_dec_ref(v_as_374_);
v_r_377_ = lean_box(v_res_376_);
return v_r_377_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1(lean_object* v___x_378_, lean_object* v_as_379_, size_t v_i_380_, size_t v_stop_381_){
_start:
{
uint8_t v___x_382_; 
v___x_382_ = lean_usize_dec_eq(v_i_380_, v_stop_381_);
if (v___x_382_ == 0)
{
lean_object* v___x_383_; lean_object* v_fst_384_; uint8_t v_decide_385_; 
v___x_383_ = lean_array_uget_borrowed(v_as_379_, v_i_380_);
v_fst_384_ = lean_ctor_get(v___x_383_, 0);
v_decide_385_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_fst_384_, v___x_378_);
if (v_decide_385_ == 0)
{
size_t v___x_386_; size_t v___x_387_; 
v___x_386_ = ((size_t)1ULL);
v___x_387_ = lean_usize_add(v_i_380_, v___x_386_);
v_i_380_ = v___x_387_;
goto _start;
}
else
{
return v_decide_385_;
}
}
else
{
uint8_t v___x_389_; 
v___x_389_ = 0;
return v___x_389_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1___boxed(lean_object* v___x_390_, lean_object* v_as_391_, lean_object* v_i_392_, lean_object* v_stop_393_){
_start:
{
size_t v_i_boxed_394_; size_t v_stop_boxed_395_; uint8_t v_res_396_; lean_object* v_r_397_; 
v_i_boxed_394_ = lean_unbox_usize(v_i_392_);
lean_dec(v_i_392_);
v_stop_boxed_395_ = lean_unbox_usize(v_stop_393_);
lean_dec(v_stop_393_);
v_res_396_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1(v___x_390_, v_as_391_, v_i_boxed_394_, v_stop_boxed_395_);
lean_dec_ref(v_as_391_);
lean_dec_ref(v___x_390_);
v_r_397_ = lean_box(v_res_396_);
return v_r_397_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4(uint8_t v___x_398_, lean_object* v___x_399_, lean_object* v_as_400_, size_t v_i_401_, size_t v_stop_402_, lean_object* v_b_403_){
_start:
{
uint8_t v___x_404_; 
v___x_404_ = lean_usize_dec_eq(v_i_401_, v_stop_402_);
if (v___x_404_ == 0)
{
size_t v___x_405_; size_t v___x_406_; uint8_t v___y_408_; lean_object* v___x_413_; lean_object* v_root_414_; uint8_t v___x_415_; 
v___x_405_ = ((size_t)1ULL);
v___x_406_ = lean_usize_sub(v_i_401_, v___x_405_);
v___x_413_ = lean_array_uget_borrowed(v_as_400_, v___x_406_);
v_root_414_ = lean_ctor_get(v___x_413_, 0);
v___x_415_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_414_);
if (v___x_415_ == 0)
{
v___y_408_ = v___x_398_;
goto v___jp_407_;
}
else
{
lean_object* v_p_416_; uint8_t v_decide_417_; 
v_p_416_ = lean_ctor_get(v_root_414_, 0);
v_decide_417_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_p_416_, v___x_399_);
v___y_408_ = v_decide_417_;
goto v___jp_407_;
}
v___jp_407_:
{
if (v___y_408_ == 0)
{
v_i_401_ = v___x_406_;
goto _start;
}
else
{
lean_object* v___x_410_; lean_object* v___x_411_; 
v___x_410_ = lean_unsigned_to_nat(1u);
v___x_411_ = lean_nat_add(v_b_403_, v___x_410_);
lean_dec(v_b_403_);
v_i_401_ = v___x_406_;
v_b_403_ = v___x_411_;
goto _start;
}
}
}
else
{
return v_b_403_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4___boxed(lean_object* v___x_418_, lean_object* v___x_419_, lean_object* v_as_420_, lean_object* v_i_421_, lean_object* v_stop_422_, lean_object* v_b_423_){
_start:
{
uint8_t v___x_2037__boxed_424_; size_t v_i_boxed_425_; size_t v_stop_boxed_426_; lean_object* v_res_427_; 
v___x_2037__boxed_424_ = lean_unbox(v___x_418_);
v_i_boxed_425_ = lean_unbox_usize(v_i_421_);
lean_dec(v_i_421_);
v_stop_boxed_426_ = lean_unbox_usize(v_stop_422_);
lean_dec(v_stop_422_);
v_res_427_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4(v___x_2037__boxed_424_, v___x_419_, v_as_420_, v_i_boxed_425_, v_stop_boxed_426_, v_b_423_);
lean_dec_ref(v_as_420_);
lean_dec_ref(v___x_419_);
return v_res_427_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3(lean_object* v___x_428_, size_t v_sz_429_, size_t v_i_430_, lean_object* v_bs_431_){
_start:
{
uint8_t v___x_432_; 
v___x_432_ = lean_usize_dec_lt(v_i_430_, v_sz_429_);
if (v___x_432_ == 0)
{
lean_object* v___x_433_; 
v___x_433_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_433_, 0, v_bs_431_);
return v___x_433_;
}
else
{
lean_object* v_v_434_; lean_object* v___x_435_; 
v_v_434_ = lean_array_uget_borrowed(v_bs_431_, v_i_430_);
lean_inc(v_v_434_);
v___x_435_ = lp_Hex_Hex_DyadicRootIsolation_toRefined_x3f(v___x_428_, v_v_434_);
if (lean_obj_tag(v___x_435_) == 0)
{
lean_object* v___x_436_; 
lean_dec_ref(v_bs_431_);
v___x_436_ = lean_box(0);
return v___x_436_;
}
else
{
lean_object* v_val_437_; lean_object* v___x_438_; lean_object* v_bs_x27_439_; size_t v___x_440_; size_t v___x_441_; lean_object* v___x_442_; 
v_val_437_ = lean_ctor_get(v___x_435_, 0);
lean_inc(v_val_437_);
lean_dec_ref_known(v___x_435_, 1);
v___x_438_ = lean_unsigned_to_nat(0u);
v_bs_x27_439_ = lean_array_uset(v_bs_431_, v_i_430_, v___x_438_);
v___x_440_ = ((size_t)1ULL);
v___x_441_ = lean_usize_add(v_i_430_, v___x_440_);
v___x_442_ = lean_array_uset(v_bs_x27_439_, v_i_430_, v_val_437_);
v_i_430_ = v___x_441_;
v_bs_431_ = v___x_442_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3___boxed(lean_object* v___x_444_, lean_object* v_sz_445_, lean_object* v_i_446_, lean_object* v_bs_447_){
_start:
{
size_t v_sz_boxed_448_; size_t v_i_boxed_449_; lean_object* v_res_450_; 
v_sz_boxed_448_ = lean_unbox_usize(v_sz_445_);
lean_dec(v_sz_445_);
v_i_boxed_449_ = lean_unbox_usize(v_i_446_);
lean_dec(v_i_446_);
v_res_450_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3(v___x_444_, v_sz_boxed_448_, v_i_boxed_449_, v_bs_447_);
lean_dec_ref(v___x_444_);
return v_res_450_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(lean_object* v_roots_451_, lean_object* v_as_452_, size_t v_i_453_, size_t v_stop_454_, lean_object* v_b_455_){
_start:
{
lean_object* v___y_457_; uint8_t v___x_461_; 
v___x_461_ = lean_usize_dec_eq(v_i_453_, v_stop_454_);
if (v___x_461_ == 0)
{
lean_object* v___x_462_; lean_object* v_root_463_; uint8_t v___x_464_; 
v___x_462_ = lean_array_uget_borrowed(v_as_452_, v_i_453_);
v_root_463_ = lean_ctor_get(v___x_462_, 0);
v___x_464_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_463_);
if (v___x_464_ == 0)
{
v___y_457_ = v_b_455_;
goto v___jp_456_;
}
else
{
lean_object* v_fst_465_; lean_object* v_snd_466_; lean_object* v_p_467_; uint8_t v___x_468_; 
v_fst_465_ = lean_ctor_get(v_b_455_, 0);
v_snd_466_ = lean_ctor_get(v_b_455_, 1);
v_p_467_ = lean_ctor_get(v_root_463_, 0);
v___x_468_ = lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0(v_fst_465_, v_p_467_);
if (v___x_468_ == 0)
{
lean_object* v___x_470_; uint8_t v_isShared_471_; uint8_t v_isSharedCheck_522_; 
lean_inc(v_snd_466_);
lean_inc(v_fst_465_);
v_isSharedCheck_522_ = !lean_is_exclusive(v_b_455_);
if (v_isSharedCheck_522_ == 0)
{
lean_object* v_unused_523_; lean_object* v_unused_524_; 
v_unused_523_ = lean_ctor_get(v_b_455_, 1);
lean_dec(v_unused_523_);
v_unused_524_ = lean_ctor_get(v_b_455_, 0);
lean_dec(v_unused_524_);
v___x_470_ = v_b_455_;
v_isShared_471_ = v_isSharedCheck_522_;
goto v_resetjp_469_;
}
else
{
lean_dec(v_b_455_);
v___x_470_ = lean_box(0);
v_isShared_471_ = v_isSharedCheck_522_;
goto v_resetjp_469_;
}
v_resetjp_469_:
{
lean_object* v_seen_472_; lean_object* v___y_474_; lean_object* v___x_516_; lean_object* v___x_517_; uint8_t v___x_518_; 
lean_inc_ref(v_p_467_);
v_seen_472_ = lean_array_push(v_fst_465_, v_p_467_);
v___x_516_ = lean_unsigned_to_nat(0u);
v___x_517_ = lean_array_get_size(v_roots_451_);
v___x_518_ = lean_nat_dec_lt(v___x_516_, v___x_517_);
if (v___x_518_ == 0)
{
v___y_474_ = v___x_516_;
goto v___jp_473_;
}
else
{
size_t v___x_519_; size_t v___x_520_; lean_object* v___x_521_; 
v___x_519_ = lean_usize_of_nat(v___x_517_);
v___x_520_ = ((size_t)0ULL);
v___x_521_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4(v___x_468_, v_p_467_, v_roots_451_, v___x_519_, v___x_520_, v___x_516_);
v___y_474_ = v___x_521_;
goto v___jp_473_;
}
v___jp_473_:
{
lean_object* v___x_475_; uint8_t v___x_476_; 
v___x_475_ = lean_unsigned_to_nat(2u);
v___x_476_ = lean_nat_dec_lt(v___y_474_, v___x_475_);
lean_dec(v___y_474_);
if (v___x_476_ == 0)
{
lean_object* v_factors_477_; lean_object* v_factors_478_; lean_object* v_fallback_479_; lean_object* v___x_480_; lean_object* v___x_481_; uint8_t v___x_482_; 
lean_inc_ref_n(v_p_467_, 2);
v_factors_477_ = lp_Hex_Hex_ZPoly_factorize(v_p_467_);
v_factors_478_ = lean_ctor_get(v_factors_477_, 1);
lean_inc_ref(v_factors_478_);
v_fallback_479_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___boxed), 5, 4);
lean_closure_set(v_fallback_479_, 0, v_p_467_);
lean_closure_set(v_fallback_479_, 1, v_factors_477_);
lean_closure_set(v_fallback_479_, 2, lean_box(0));
lean_closure_set(v_fallback_479_, 3, v_snd_466_);
v___x_480_ = lean_unsigned_to_nat(0u);
v___x_481_ = lean_array_get_size(v_factors_478_);
v___x_482_ = lean_nat_dec_lt(v___x_480_, v___x_481_);
if (v___x_482_ == 0)
{
lean_object* v___x_484_; 
lean_dec_ref(v_factors_478_);
if (v_isShared_471_ == 0)
{
lean_ctor_set(v___x_470_, 1, v_fallback_479_);
lean_ctor_set(v___x_470_, 0, v_seen_472_);
v___x_484_ = v___x_470_;
goto v_reusejp_483_;
}
else
{
lean_object* v_reuseFailAlloc_485_; 
v_reuseFailAlloc_485_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_485_, 0, v_seen_472_);
lean_ctor_set(v_reuseFailAlloc_485_, 1, v_fallback_479_);
v___x_484_ = v_reuseFailAlloc_485_;
goto v_reusejp_483_;
}
v_reusejp_483_:
{
v___y_457_ = v___x_484_;
goto v___jp_456_;
}
}
else
{
if (v___x_482_ == 0)
{
lean_object* v___x_487_; 
lean_dec_ref(v_factors_478_);
if (v_isShared_471_ == 0)
{
lean_ctor_set(v___x_470_, 1, v_fallback_479_);
lean_ctor_set(v___x_470_, 0, v_seen_472_);
v___x_487_ = v___x_470_;
goto v_reusejp_486_;
}
else
{
lean_object* v_reuseFailAlloc_488_; 
v_reuseFailAlloc_488_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_488_, 0, v_seen_472_);
lean_ctor_set(v_reuseFailAlloc_488_, 1, v_fallback_479_);
v___x_487_ = v_reuseFailAlloc_488_;
goto v_reusejp_486_;
}
v_reusejp_486_:
{
v___y_457_ = v___x_487_;
goto v___jp_456_;
}
}
else
{
size_t v___x_489_; size_t v___x_490_; uint8_t v___x_491_; 
v___x_489_ = ((size_t)0ULL);
v___x_490_ = lean_usize_of_nat(v___x_481_);
v___x_491_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1(v_p_467_, v_factors_478_, v___x_489_, v___x_490_);
lean_dec_ref(v_factors_478_);
if (v___x_491_ == 0)
{
lean_object* v___x_493_; 
if (v_isShared_471_ == 0)
{
lean_ctor_set(v___x_470_, 1, v_fallback_479_);
lean_ctor_set(v___x_470_, 0, v_seen_472_);
v___x_493_ = v___x_470_;
goto v_reusejp_492_;
}
else
{
lean_object* v_reuseFailAlloc_494_; 
v_reuseFailAlloc_494_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_494_, 0, v_seen_472_);
lean_ctor_set(v_reuseFailAlloc_494_, 1, v_fallback_479_);
v___x_493_ = v_reuseFailAlloc_494_;
goto v_reusejp_492_;
}
v_reusejp_492_:
{
v___y_457_ = v___x_493_;
goto v___jp_456_;
}
}
else
{
lean_object* v___x_495_; lean_object* v___x_496_; uint8_t v___x_497_; lean_object* v___x_498_; 
v___x_495_ = lp_Hex_Hex_separationDepth(v_p_467_);
v___x_496_ = lean_nat_to_int(v___x_495_);
v___x_497_ = 2;
lean_inc_ref(v_p_467_);
v___x_498_ = lp_Hex_Hex_ZPoly_isolateComplexRoots_x3f___redArg(v_p_467_, v___x_496_, v___x_497_);
if (lean_obj_tag(v___x_498_) == 0)
{
lean_object* v___x_500_; 
if (v_isShared_471_ == 0)
{
lean_ctor_set(v___x_470_, 1, v_fallback_479_);
lean_ctor_set(v___x_470_, 0, v_seen_472_);
v___x_500_ = v___x_470_;
goto v_reusejp_499_;
}
else
{
lean_object* v_reuseFailAlloc_501_; 
v_reuseFailAlloc_501_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_501_, 0, v_seen_472_);
lean_ctor_set(v_reuseFailAlloc_501_, 1, v_fallback_479_);
v___x_500_ = v_reuseFailAlloc_501_;
goto v_reusejp_499_;
}
v_reusejp_499_:
{
v___y_457_ = v___x_500_;
goto v___jp_456_;
}
}
else
{
lean_object* v_val_502_; size_t v_sz_503_; lean_object* v___x_504_; 
v_val_502_ = lean_ctor_get(v___x_498_, 0);
lean_inc_n(v_val_502_, 2);
lean_dec_ref_known(v___x_498_, 1);
v_sz_503_ = lean_array_size(v_val_502_);
v___x_504_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3(v_p_467_, v_sz_503_, v___x_489_, v_val_502_);
if (lean_obj_tag(v___x_504_) == 0)
{
lean_object* v___x_506_; 
lean_dec(v_val_502_);
if (v_isShared_471_ == 0)
{
lean_ctor_set(v___x_470_, 1, v_fallback_479_);
lean_ctor_set(v___x_470_, 0, v_seen_472_);
v___x_506_ = v___x_470_;
goto v_reusejp_505_;
}
else
{
lean_object* v_reuseFailAlloc_507_; 
v_reuseFailAlloc_507_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_507_, 0, v_seen_472_);
lean_ctor_set(v_reuseFailAlloc_507_, 1, v_fallback_479_);
v___x_506_ = v_reuseFailAlloc_507_;
goto v_reusejp_505_;
}
v_reusejp_505_:
{
v___y_457_ = v___x_506_;
goto v___jp_456_;
}
}
else
{
lean_object* v_val_508_; lean_object* v___x_509_; lean_object* v___x_511_; 
v_val_508_ = lean_ctor_get(v___x_504_, 0);
lean_inc(v_val_508_);
lean_dec_ref_known(v___x_504_, 1);
lean_inc_ref(v_p_467_);
v___x_509_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___boxed), 8, 7);
lean_closure_set(v___x_509_, 0, v_p_467_);
lean_closure_set(v___x_509_, 1, lean_box(0));
lean_closure_set(v___x_509_, 2, v_val_502_);
lean_closure_set(v___x_509_, 3, v_val_508_);
lean_closure_set(v___x_509_, 4, lean_box(0));
lean_closure_set(v___x_509_, 5, lean_box(0));
lean_closure_set(v___x_509_, 6, v_fallback_479_);
if (v_isShared_471_ == 0)
{
lean_ctor_set(v___x_470_, 1, v___x_509_);
lean_ctor_set(v___x_470_, 0, v_seen_472_);
v___x_511_ = v___x_470_;
goto v_reusejp_510_;
}
else
{
lean_object* v_reuseFailAlloc_512_; 
v_reuseFailAlloc_512_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_512_, 0, v_seen_472_);
lean_ctor_set(v_reuseFailAlloc_512_, 1, v___x_509_);
v___x_511_ = v_reuseFailAlloc_512_;
goto v_reusejp_510_;
}
v_reusejp_510_:
{
v___y_457_ = v___x_511_;
goto v___jp_456_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_514_; 
if (v_isShared_471_ == 0)
{
lean_ctor_set(v___x_470_, 0, v_seen_472_);
v___x_514_ = v___x_470_;
goto v_reusejp_513_;
}
else
{
lean_object* v_reuseFailAlloc_515_; 
v_reuseFailAlloc_515_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_515_, 0, v_seen_472_);
lean_ctor_set(v_reuseFailAlloc_515_, 1, v_snd_466_);
v___x_514_ = v_reuseFailAlloc_515_;
goto v_reusejp_513_;
}
v_reusejp_513_:
{
v___y_457_ = v___x_514_;
goto v___jp_456_;
}
}
}
}
}
else
{
v___y_457_ = v_b_455_;
goto v___jp_456_;
}
}
}
else
{
return v_b_455_;
}
v___jp_456_:
{
size_t v___x_458_; size_t v___x_459_; 
v___x_458_ = ((size_t)1ULL);
v___x_459_ = lean_usize_add(v_i_453_, v___x_458_);
v_i_453_ = v___x_459_;
v_b_455_ = v___y_457_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5___boxed(lean_object* v_roots_525_, lean_object* v_as_526_, lean_object* v_i_527_, lean_object* v_stop_528_, lean_object* v_b_529_){
_start:
{
size_t v_i_boxed_530_; size_t v_stop_boxed_531_; lean_object* v_res_532_; 
v_i_boxed_530_ = lean_unbox_usize(v_i_527_);
lean_dec(v_i_527_);
v_stop_boxed_531_ = lean_unbox_usize(v_stop_528_);
lean_dec(v_stop_528_);
v_res_532_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(v_roots_525_, v_as_526_, v_i_boxed_530_, v_stop_boxed_531_, v_b_529_);
lean_dec_ref(v_as_526_);
lean_dec_ref(v_roots_525_);
return v_res_532_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors(lean_object* v_roots_539_){
_start:
{
lean_object* v___x_540_; lean_object* v___x_541_; lean_object* v___x_542_; uint8_t v___x_543_; 
v___x_540_ = lean_unsigned_to_nat(0u);
v___x_541_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__2));
v___x_542_ = lean_array_get_size(v_roots_539_);
v___x_543_ = lean_nat_dec_lt(v___x_540_, v___x_542_);
if (v___x_543_ == 0)
{
return v___x_541_;
}
else
{
uint8_t v___x_544_; 
v___x_544_ = lean_nat_dec_le(v___x_542_, v___x_542_);
if (v___x_544_ == 0)
{
if (v___x_543_ == 0)
{
return v___x_541_;
}
else
{
size_t v___x_545_; size_t v___x_546_; lean_object* v___x_547_; 
v___x_545_ = ((size_t)0ULL);
v___x_546_ = lean_usize_of_nat(v___x_542_);
v___x_547_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(v_roots_539_, v_roots_539_, v___x_545_, v___x_546_, v___x_541_);
return v___x_547_;
}
}
else
{
size_t v___x_548_; size_t v___x_549_; lean_object* v___x_550_; 
v___x_548_ = ((size_t)0ULL);
v___x_549_ = lean_usize_of_nat(v___x_542_);
v___x_550_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(v_roots_539_, v_roots_539_, v___x_548_, v___x_549_, v___x_541_);
return v___x_550_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___boxed(lean_object* v_roots_551_){
_start:
{
lean_object* v_res_552_; 
v_res_552_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors(v_roots_551_);
lean_dec_ref(v_roots_551_);
return v_res_552_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__3_splitter___redArg(lean_object* v_x_553_, lean_object* v_h__1_554_, lean_object* v_h__2_555_){
_start:
{
if (lean_obj_tag(v_x_553_) == 0)
{
lean_object* v___x_556_; 
lean_dec(v_h__2_555_);
v___x_556_ = lean_apply_1(v_h__1_554_, lean_box(0));
return v___x_556_;
}
else
{
lean_object* v_val_557_; lean_object* v___x_558_; 
lean_dec(v_h__1_554_);
v_val_557_ = lean_ctor_get(v_x_553_, 0);
lean_inc(v_val_557_);
lean_dec_ref_known(v_x_553_, 1);
v___x_558_ = lean_apply_2(v_h__2_555_, v_val_557_, lean_box(0));
return v___x_558_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__3_splitter(lean_object* v_r_559_, lean_object* v_motive_560_, lean_object* v_x_561_, lean_object* v_h__1_562_, lean_object* v_h__2_563_){
_start:
{
if (lean_obj_tag(v_x_561_) == 0)
{
lean_object* v___x_564_; 
lean_dec(v_h__2_563_);
v___x_564_ = lean_apply_1(v_h__1_562_, lean_box(0));
return v___x_564_;
}
else
{
lean_object* v_val_565_; lean_object* v___x_566_; 
lean_dec(v_h__1_562_);
v_val_565_ = lean_ctor_get(v_x_561_, 0);
lean_inc(v_val_565_);
lean_dec_ref_known(v_x_561_, 1);
v___x_566_ = lean_apply_2(v_h__2_563_, v_val_565_, lean_box(0));
return v___x_566_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__3_splitter___boxed(lean_object* v_r_567_, lean_object* v_motive_568_, lean_object* v_x_569_, lean_object* v_h__1_570_, lean_object* v_h__2_571_){
_start:
{
lean_object* v_res_572_; 
v_res_572_ = lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__3_splitter(v_r_567_, v_motive_568_, v_x_569_, v_h__1_570_, v_h__2_571_);
lean_dec_ref(v_r_567_);
return v_res_572_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter___redArg(lean_object* v_x_573_, lean_object* v_h__1_574_, lean_object* v_h__2_575_){
_start:
{
if (lean_obj_tag(v_x_573_) == 0)
{
lean_object* v___x_576_; 
lean_dec(v_h__2_575_);
v___x_576_ = lean_apply_1(v_h__1_574_, lean_box(0));
return v___x_576_;
}
else
{
lean_object* v_val_577_; lean_object* v___x_578_; 
lean_dec(v_h__1_574_);
v_val_577_ = lean_ctor_get(v_x_573_, 0);
lean_inc(v_val_577_);
lean_dec_ref_known(v_x_573_, 1);
v___x_578_ = lean_apply_2(v_h__2_575_, v_val_577_, lean_box(0));
return v___x_578_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter(lean_object* v_r_579_, lean_object* v_motive_580_, lean_object* v_x_581_, lean_object* v_h__1_582_, lean_object* v_h__2_583_){
_start:
{
if (lean_obj_tag(v_x_581_) == 0)
{
lean_object* v___x_584_; 
lean_dec(v_h__2_583_);
v___x_584_ = lean_apply_1(v_h__1_582_, lean_box(0));
return v___x_584_;
}
else
{
lean_object* v_val_585_; lean_object* v___x_586_; 
lean_dec(v_h__1_582_);
v_val_585_ = lean_ctor_get(v_x_581_, 0);
lean_inc(v_val_585_);
lean_dec_ref_known(v_x_581_, 1);
v___x_586_ = lean_apply_2(v_h__2_583_, v_val_585_, lean_box(0));
return v___x_586_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter___boxed(lean_object* v_r_587_, lean_object* v_motive_588_, lean_object* v_x_589_, lean_object* v_h__1_590_, lean_object* v_h__2_591_){
_start:
{
lean_object* v_res_592_; 
v_res_592_ = lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter(v_r_587_, v_motive_588_, v_x_589_, v_h__1_590_, v_h__2_591_);
lean_dec_ref(v_r_587_);
return v_res_592_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0(lean_object* v_a_593_, lean_object* v_b_594_){
_start:
{
lean_object* v_root_595_; lean_object* v_root_596_; uint8_t v___x_597_; 
v_root_595_ = lean_ctor_get(v_a_593_, 0);
lean_inc_ref(v_root_595_);
lean_dec_ref(v_a_593_);
v_root_596_ = lean_ctor_get(v_b_594_, 0);
lean_inc_ref(v_root_596_);
lean_dec_ref(v_b_594_);
v___x_597_ = lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE(v_root_595_, v_root_596_);
return v___x_597_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0___boxed(lean_object* v_a_598_, lean_object* v_b_599_){
_start:
{
uint8_t v_res_600_; lean_object* v_r_601_; 
v_res_600_ = lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0(v_a_598_, v_b_599_);
v_r_601_ = lean_box(v_res_600_);
return v_r_601_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(lean_object* v___x_602_, lean_object* v_as_603_, size_t v_i_604_, size_t v_stop_605_, lean_object* v_b_606_){
_start:
{
lean_object* v___y_608_; uint8_t v___x_612_; 
v___x_612_ = lean_usize_dec_eq(v_i_604_, v_stop_605_);
if (v___x_612_ == 0)
{
lean_object* v___x_613_; lean_object* v___x_614_; 
v___x_613_ = lean_array_uget_borrowed(v_as_603_, v_i_604_);
lean_inc_ref(v___x_602_);
lean_inc(v___x_613_);
v___x_614_ = lean_apply_1(v___x_602_, v___x_613_);
if (lean_obj_tag(v___x_614_) == 0)
{
v___y_608_ = v_b_606_;
goto v___jp_607_;
}
else
{
lean_object* v_val_615_; lean_object* v___x_616_; 
v_val_615_ = lean_ctor_get(v___x_614_, 0);
lean_inc(v_val_615_);
lean_dec_ref_known(v___x_614_, 1);
v___x_616_ = lean_array_push(v_b_606_, v_val_615_);
v___y_608_ = v___x_616_;
goto v___jp_607_;
}
}
else
{
lean_dec_ref(v___x_602_);
return v_b_606_;
}
v___jp_607_:
{
size_t v___x_609_; size_t v___x_610_; 
v___x_609_ = ((size_t)1ULL);
v___x_610_ = lean_usize_add(v_i_604_, v___x_609_);
v_i_604_ = v___x_610_;
v_b_606_ = v___y_608_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0___boxed(lean_object* v___x_617_, lean_object* v_as_618_, lean_object* v_i_619_, lean_object* v_stop_620_, lean_object* v_b_621_){
_start:
{
size_t v_i_boxed_622_; size_t v_stop_boxed_623_; lean_object* v_res_624_; 
v_i_boxed_622_ = lean_unbox_usize(v_i_619_);
lean_dec(v_i_619_);
v_stop_boxed_623_ = lean_unbox_usize(v_stop_620_);
lean_dec(v_stop_620_);
v_res_624_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(v___x_617_, v_as_618_, v_i_boxed_622_, v_stop_boxed_623_, v_b_621_);
lean_dec_ref(v_as_618_);
return v_res_624_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0(lean_object* v___x_625_, lean_object* v_as_626_, lean_object* v_start_627_, lean_object* v_stop_628_){
_start:
{
lean_object* v___x_629_; uint8_t v___x_630_; 
v___x_629_ = ((lean_object*)(lp_Hex_Hex_RealRootSet_toArray___closed__0));
v___x_630_ = lean_nat_dec_lt(v_start_627_, v_stop_628_);
if (v___x_630_ == 0)
{
lean_dec_ref(v___x_625_);
return v___x_629_;
}
else
{
lean_object* v___x_631_; uint8_t v___x_632_; 
v___x_631_ = lean_array_get_size(v_as_626_);
v___x_632_ = lean_nat_dec_le(v_stop_628_, v___x_631_);
if (v___x_632_ == 0)
{
uint8_t v___x_633_; 
v___x_633_ = lean_nat_dec_lt(v_start_627_, v___x_631_);
if (v___x_633_ == 0)
{
lean_dec_ref(v___x_625_);
return v___x_629_;
}
else
{
size_t v___x_634_; size_t v___x_635_; lean_object* v___x_636_; 
v___x_634_ = lean_usize_of_nat(v_start_627_);
v___x_635_ = lean_usize_of_nat(v___x_631_);
v___x_636_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(v___x_625_, v_as_626_, v___x_634_, v___x_635_, v___x_629_);
return v___x_636_;
}
}
else
{
size_t v___x_637_; size_t v___x_638_; lean_object* v___x_639_; 
v___x_637_ = lean_usize_of_nat(v_start_627_);
v___x_638_ = lean_usize_of_nat(v_stop_628_);
v___x_639_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(v___x_625_, v_as_626_, v___x_637_, v___x_638_, v___x_629_);
return v___x_639_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0___boxed(lean_object* v___x_640_, lean_object* v_as_641_, lean_object* v_start_642_, lean_object* v_stop_643_){
_start:
{
lean_object* v_res_644_; 
v_res_644_ = lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0(v___x_640_, v_as_641_, v_start_642_, v_stop_643_);
lean_dec(v_stop_643_);
lean_dec(v_start_642_);
lean_dec_ref(v_as_641_);
return v_res_644_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl(lean_object* v_x_646_){
_start:
{
if (lean_obj_tag(v_x_646_) == 0)
{
lean_object* v___x_647_; 
v___x_647_ = lean_box(0);
return v___x_647_;
}
else
{
lean_object* v_roots_648_; lean_object* v___x_650_; uint8_t v_isShared_651_; uint8_t v_isSharedCheck_664_; 
v_roots_648_ = lean_ctor_get(v_x_646_, 0);
v_isSharedCheck_664_ = !lean_is_exclusive(v_x_646_);
if (v_isSharedCheck_664_ == 0)
{
v___x_650_ = v_x_646_;
v_isShared_651_ = v_isSharedCheck_664_;
goto v_resetjp_649_;
}
else
{
lean_inc(v_roots_648_);
lean_dec(v_x_646_);
v___x_650_ = lean_box(0);
v_isShared_651_ = v_isSharedCheck_664_;
goto v_resetjp_649_;
}
v_resetjp_649_:
{
lean_object* v___x_652_; lean_object* v_snd_653_; lean_object* v___f_654_; lean_object* v___x_655_; lean_object* v___x_656_; lean_object* v___x_657_; lean_object* v___x_658_; lean_object* v___x_659_; lean_object* v___x_660_; lean_object* v___x_662_; 
v___x_652_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors(v_roots_648_);
v_snd_653_ = lean_ctor_get(v___x_652_, 1);
lean_inc(v_snd_653_);
lean_dec_ref(v___x_652_);
v___f_654_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___closed__0));
v___x_655_ = lean_unsigned_to_nat(0u);
v___x_656_ = lean_array_get_size(v_roots_648_);
v___x_657_ = lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0(v_snd_653_, v_roots_648_, v___x_655_, v___x_656_);
lean_dec_ref(v_roots_648_);
v___x_658_ = lean_array_to_list(v___x_657_);
v___x_659_ = l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(v___x_658_, v___f_654_);
v___x_660_ = lean_array_mk(v___x_659_);
if (v_isShared_651_ == 0)
{
lean_ctor_set(v___x_650_, 0, v___x_660_);
v___x_662_ = v___x_650_;
goto v_reusejp_661_;
}
else
{
lean_object* v_reuseFailAlloc_663_; 
v_reuseFailAlloc_663_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_663_, 0, v___x_660_);
v___x_662_ = v_reuseFailAlloc_663_;
goto v_reusejp_661_;
}
v_reusejp_661_:
{
return v___x_662_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter___redArg(lean_object* v_x_665_, lean_object* v_h__1_666_, lean_object* v_h__2_667_){
_start:
{
if (lean_obj_tag(v_x_665_) == 0)
{
lean_object* v___x_668_; lean_object* v___x_669_; 
lean_dec(v_h__2_667_);
v___x_668_ = lean_box(0);
v___x_669_ = lean_apply_1(v_h__1_666_, v___x_668_);
return v___x_669_;
}
else
{
lean_object* v_roots_670_; lean_object* v___x_671_; 
lean_dec(v_h__1_666_);
v_roots_670_ = lean_ctor_get(v_x_665_, 0);
lean_inc_ref(v_roots_670_);
lean_dec_ref_known(v_x_665_, 1);
v___x_671_ = lean_apply_1(v_h__2_667_, v_roots_670_);
return v___x_671_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter(lean_object* v_motive_672_, lean_object* v_x_673_, lean_object* v_h__1_674_, lean_object* v_h__2_675_){
_start:
{
if (lean_obj_tag(v_x_673_) == 0)
{
lean_object* v___x_676_; lean_object* v___x_677_; 
lean_dec(v_h__2_675_);
v___x_676_ = lean_box(0);
v___x_677_ = lean_apply_1(v_h__1_674_, v___x_676_);
return v___x_677_;
}
else
{
lean_object* v_roots_678_; lean_object* v___x_679_; 
lean_dec(v_h__1_674_);
v_roots_678_ = lean_ctor_get(v_x_673_, 0);
lean_inc_ref(v_roots_678_);
lean_dec_ref_known(v_x_673_, 1);
v___x_679_ = lean_apply_1(v_h__2_675_, v_roots_678_);
return v___x_679_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_roots(lean_object* v_f_680_){
_start:
{
lean_object* v___x_681_; lean_object* v___x_682_; 
v___x_681_ = lp_Hex_Hex_AlgebraicPoly_roots(v_f_680_);
v___x_682_ = lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl(v___x_681_);
return v___x_682_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(lean_object* v_as_683_, size_t v_i_684_, size_t v_stop_685_, lean_object* v_b_686_){
_start:
{
lean_object* v___y_688_; uint8_t v___x_692_; 
v___x_692_ = lean_usize_dec_eq(v_i_684_, v_stop_685_);
if (v___x_692_ == 0)
{
lean_object* v___x_693_; lean_object* v___x_694_; 
v___x_693_ = lean_array_uget_borrowed(v_as_683_, v_i_684_);
lean_inc(v___x_693_);
v___x_694_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___x_693_);
if (lean_obj_tag(v___x_694_) == 0)
{
v___y_688_ = v_b_686_;
goto v___jp_687_;
}
else
{
lean_object* v_val_695_; lean_object* v___x_696_; 
v_val_695_ = lean_ctor_get(v___x_694_, 0);
lean_inc(v_val_695_);
lean_dec_ref_known(v___x_694_, 1);
v___x_696_ = lean_array_push(v_b_686_, v_val_695_);
v___y_688_ = v___x_696_;
goto v___jp_687_;
}
}
else
{
return v_b_686_;
}
v___jp_687_:
{
size_t v___x_689_; size_t v___x_690_; 
v___x_689_ = ((size_t)1ULL);
v___x_690_ = lean_usize_add(v_i_684_, v___x_689_);
v_i_684_ = v___x_690_;
v_b_686_ = v___y_688_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0___boxed(lean_object* v_as_697_, lean_object* v_i_698_, lean_object* v_stop_699_, lean_object* v_b_700_){
_start:
{
size_t v_i_boxed_701_; size_t v_stop_boxed_702_; lean_object* v_res_703_; 
v_i_boxed_701_ = lean_unbox_usize(v_i_698_);
lean_dec(v_i_698_);
v_stop_boxed_702_ = lean_unbox_usize(v_stop_699_);
lean_dec(v_stop_699_);
v_res_703_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(v_as_697_, v_i_boxed_701_, v_stop_boxed_702_, v_b_700_);
lean_dec_ref(v_as_697_);
return v_res_703_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(lean_object* v_as_706_, lean_object* v_start_707_, lean_object* v_stop_708_){
_start:
{
lean_object* v___x_709_; uint8_t v___x_710_; 
v___x_709_ = ((lean_object*)(lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0));
v___x_710_ = lean_nat_dec_lt(v_start_707_, v_stop_708_);
if (v___x_710_ == 0)
{
return v___x_709_;
}
else
{
lean_object* v___x_711_; uint8_t v___x_712_; 
v___x_711_ = lean_array_get_size(v_as_706_);
v___x_712_ = lean_nat_dec_le(v_stop_708_, v___x_711_);
if (v___x_712_ == 0)
{
uint8_t v___x_713_; 
v___x_713_ = lean_nat_dec_lt(v_start_707_, v___x_711_);
if (v___x_713_ == 0)
{
return v___x_709_;
}
else
{
size_t v___x_714_; size_t v___x_715_; lean_object* v___x_716_; 
v___x_714_ = lean_usize_of_nat(v_start_707_);
v___x_715_ = lean_usize_of_nat(v___x_711_);
v___x_716_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(v_as_706_, v___x_714_, v___x_715_, v___x_709_);
return v___x_716_;
}
}
else
{
size_t v___x_717_; size_t v___x_718_; lean_object* v___x_719_; 
v___x_717_ = lean_usize_of_nat(v_start_707_);
v___x_718_ = lean_usize_of_nat(v_stop_708_);
v___x_719_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(v_as_706_, v___x_717_, v___x_718_, v___x_709_);
return v___x_719_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___boxed(lean_object* v_as_720_, lean_object* v_start_721_, lean_object* v_stop_722_){
_start:
{
lean_object* v_res_723_; 
v_res_723_ = lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(v_as_720_, v_start_721_, v_stop_722_);
lean_dec(v_stop_722_);
lean_dec(v_start_721_);
lean_dec_ref(v_as_720_);
return v_res_723_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_realAlgebraicRoots(lean_object* v_p_724_){
_start:
{
lean_object* v___f_725_; lean_object* v___x_726_; lean_object* v___x_727_; lean_object* v___x_728_; lean_object* v___x_729_; lean_object* v___x_730_; lean_object* v___x_731_; lean_object* v___x_732_; 
v___f_725_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE___boxed), 2, 0);
v___x_726_ = lp_Hex_Hex_ZPoly_algebraicRoots(v_p_724_);
v___x_727_ = lean_unsigned_to_nat(0u);
v___x_728_ = lean_array_get_size(v___x_726_);
v___x_729_ = lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(v___x_726_, v___x_727_, v___x_728_);
lean_dec_ref(v___x_726_);
v___x_730_ = lean_array_to_list(v___x_729_);
v___x_731_ = l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(v___x_730_, v___f_725_);
v___x_732_ = lean_array_mk(v___x_731_);
return v___x_732_;
}
}
static lean_object* _init_lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0(void){
_start:
{
uint8_t v___x_733_; lean_object* v___x_734_; 
v___x_733_ = 0;
v___x_734_ = l_Ordering_ctorIdx(v___x_733_);
return v___x_734_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(lean_object* v_a_735_){
_start:
{
lean_object* v___x_736_; uint8_t v___x_737_; lean_object* v___x_738_; lean_object* v___x_739_; uint8_t v___x_740_; 
v___x_736_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
lean_inc_ref(v_a_735_);
v___x_737_ = lp_Hex_Hex_AlgebraicNumber_realCompare(v_a_735_, v___x_736_);
v___x_738_ = l_Ordering_ctorIdx(v___x_737_);
v___x_739_ = lean_obj_once(&lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0, &lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0_once, _init_lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0);
v___x_740_ = lean_nat_dec_eq(v___x_738_, v___x_739_);
lean_dec(v___x_738_);
if (v___x_740_ == 0)
{
lean_object* v___x_741_; lean_object* v___x_742_; 
v___x_741_ = lp_Hex_Hex_AlgebraicNumber_sqrt(v_a_735_);
v___x_742_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___x_741_);
return v___x_742_;
}
else
{
lean_object* v___x_743_; 
lean_dec_ref(v_a_735_);
v___x_743_ = lean_box(0);
return v___x_743_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt_x3f(lean_object* v_a_744_){
_start:
{
lean_object* v___x_745_; 
v___x_745_ = lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(v_a_744_);
return v___x_745_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg(lean_object* v_a_747_){
_start:
{
lean_object* v___x_748_; 
v___x_748_ = lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(v_a_747_);
if (lean_obj_tag(v___x_748_) == 0)
{
lean_object* v___x_749_; lean_object* v___x_750_; lean_object* v___x_751_; 
v___x_749_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
v___x_750_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0));
v___x_751_ = lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_box(0), v___x_749_, v___x_750_);
return v___x_751_;
}
else
{
lean_object* v_val_752_; 
v_val_752_ = lean_ctor_get(v___x_748_, 0);
lean_inc(v_val_752_);
lean_dec_ref_known(v___x_748_, 1);
return v_val_752_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt(lean_object* v_a_753_, lean_object* v___h_754_){
_start:
{
lean_object* v___x_755_; 
v___x_755_ = lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg(v_a_753_);
return v___x_755_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexRealAlgebraic_Order(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexNumberField_Radical(uint8_t builtin);
void lean_initialize();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexRealAlgebraic_Roots(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealAlgebraic_Order(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexNumberField_Radical(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexRealAlgebraic_Roots(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexRealAlgebraic_Order(uint8_t builtin);
lean_object* initialize_Hex_HexNumberField_Radical(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexRealAlgebraic_Roots(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexRealAlgebraic_Order(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexNumberField_Radical(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealAlgebraic_Roots(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexRealAlgebraic_Roots(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexRealAlgebraic_Roots(builtin);
}
#ifdef __cplusplus
}
#endif
