// Lean compiler output
// Module: HexRealAlgebraic.Roots
// Imports: public import Init public meta import Init public import HexRealAlgebraic.Order public import HexNumberField.Radical
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lp_Hex_Hex_RealAlgebraicNumber_ofRoot_x3f(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_AlgebraicNumber_isReal(lean_object*);
lean_object* lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(lean_object*);
uint8_t lp_Hex_Hex_AlgebraicRoot_isReal(lean_object*);
lean_object* lp_Hex_Hex_AlgebraicPoly_roots(lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
uint8_t lp_Hex_Hex_ZPoly_isIrreducible(lean_object*);
lean_object* lp_Hex_Hex_separationDepth(lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lp_Hex_Hex_ZPoly_isolateComplexRoots_x3f___redArg(lean_object*, lean_object*, uint8_t);
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lp_Hex_Hex_DyadicRootIsolation_toRefined_x3f(lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lp_Hex_Hex_AlgebraicRoot_exactIn_x3f___redArg(lean_object*, lean_object*, lean_object*);
extern lean_object* lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
lean_object* lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(lean_object*, lean_object*);
lean_object* lean_array_mk(lean_object*);
uint8_t lp_Hex_Hex_AlgebraicNumber_realCompare(lean_object*, lean_object*);
lean_object* l_Ordering_ctorIdx(uint8_t);
lean_object* lp_Hex_Hex_AlgebraicNumber_sqrt(lean_object*);
uint8_t lp_Hex_Hex_AlgebraicNumber_beq(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE___boxed(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_ZPoly_algebraicRoots(lean_object*);
lean_object* lp_Hex_Hex_AlgebraicPoly_ofArray(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofArray(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofAlgebraic_x3f(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_x3f(lean_object*);
static const lean_array_object lp_Hex_Hex_RealRootSet_toArray___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_RealRootSet_toArray___closed__0 = (const lean_object*)&lp_Hex_Hex_RealRootSet_toArray___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_toArray(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_RealRootSet_contains(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_contains___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_RealAlgebraicPoly_realRoots___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoots___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_RealAlgebraicPoly_realRoots___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_RealAlgebraicPoly_realRoots___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoots___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_realRoots___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoots(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0___boxed(lean_object*, lean_object*);
static const lean_string_object lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 42, .m_capacity = 42, .m_length = 41, .m_data = "AlgebraicRoot.exact: certification failed"};
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootPicker(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootPicker___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__1(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__3(uint8_t, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__2(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__0_value;
static const lean_closure_object lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__1 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__0_value),((lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__1_value)}};
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__2 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__2_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootSelectors(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__3_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__3_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__3_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsCached(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_roots(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0 = (const lean_object*)&lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_realAlgebraicRoots(lean_object*);
static lean_once_cell_t lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt_x3f(lean_object*);
static const lean_string_object lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 53, .m_capacity = 53, .m_length = 52, .m_data = "RealAlgebraicNumber.sqrt: nonnegative root not found"};
static const lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic(lean_object* v_f_1_){
_start:
{
lean_inc_ref(v_f_1_);
return v_f_1_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic___boxed(lean_object* v_f_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic(v_f_2_);
lean_dec_ref(v_f_2_);
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(size_t v_sz_4_, size_t v_i_5_, lean_object* v_bs_6_){
_start:
{
uint8_t v___x_7_; 
v___x_7_ = lean_usize_dec_lt(v_i_5_, v_sz_4_);
if (v___x_7_ == 0)
{
return v_bs_6_;
}
else
{
lean_object* v_v_8_; lean_object* v___x_9_; lean_object* v_bs_x27_10_; size_t v___x_11_; size_t v___x_12_; lean_object* v___x_13_; 
v_v_8_ = lean_array_uget(v_bs_6_, v_i_5_);
v___x_9_ = lean_unsigned_to_nat(0u);
v_bs_x27_10_ = lean_array_uset(v_bs_6_, v_i_5_, v___x_9_);
v___x_11_ = ((size_t)1ULL);
v___x_12_ = lean_usize_add(v_i_5_, v___x_11_);
v___x_13_ = lean_array_uset(v_bs_x27_10_, v_i_5_, v_v_8_);
v_i_5_ = v___x_12_;
v_bs_6_ = v___x_13_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0___boxed(lean_object* v_sz_15_, lean_object* v_i_16_, lean_object* v_bs_17_){
_start:
{
size_t v_sz_boxed_18_; size_t v_i_boxed_19_; lean_object* v_res_20_; 
v_sz_boxed_18_ = lean_unbox_usize(v_sz_15_);
lean_dec(v_sz_15_);
v_i_boxed_19_ = lean_unbox_usize(v_i_16_);
lean_dec(v_i_16_);
v_res_20_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(v_sz_boxed_18_, v_i_boxed_19_, v_bs_17_);
return v_res_20_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofArray(lean_object* v_coeffs_21_){
_start:
{
size_t v_sz_22_; size_t v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; 
v_sz_22_ = lean_array_size(v_coeffs_21_);
v___x_23_ = ((size_t)0ULL);
v___x_24_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(v_sz_22_, v___x_23_, v_coeffs_21_);
v___x_25_ = lp_Hex_Hex_AlgebraicPoly_ofArray(v___x_24_);
return v___x_25_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(lean_object* v_as_26_, size_t v_i_27_, size_t v_stop_28_){
_start:
{
uint8_t v___x_29_; 
v___x_29_ = lean_usize_dec_eq(v_i_27_, v_stop_28_);
if (v___x_29_ == 0)
{
lean_object* v___x_30_; uint8_t v___x_31_; 
v___x_30_ = lean_array_uget_borrowed(v_as_26_, v_i_27_);
v___x_31_ = lp_Hex_Hex_AlgebraicNumber_isReal(v___x_30_);
if (v___x_31_ == 0)
{
uint8_t v___x_32_; 
v___x_32_ = 1;
return v___x_32_;
}
else
{
size_t v___x_33_; size_t v___x_34_; 
v___x_33_ = ((size_t)1ULL);
v___x_34_ = lean_usize_add(v_i_27_, v___x_33_);
v_i_27_ = v___x_34_;
goto _start;
}
}
else
{
uint8_t v___x_36_; 
v___x_36_ = 0;
return v___x_36_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0___boxed(lean_object* v_as_37_, lean_object* v_i_38_, lean_object* v_stop_39_){
_start:
{
size_t v_i_boxed_40_; size_t v_stop_boxed_41_; uint8_t v_res_42_; lean_object* v_r_43_; 
v_i_boxed_40_ = lean_unbox_usize(v_i_38_);
lean_dec(v_i_38_);
v_stop_boxed_41_ = lean_unbox_usize(v_stop_39_);
lean_dec(v_stop_39_);
v_res_42_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(v_as_37_, v_i_boxed_40_, v_stop_boxed_41_);
lean_dec_ref(v_as_37_);
v_r_43_ = lean_box(v_res_42_);
return v_r_43_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofAlgebraic_x3f(lean_object* v_f_44_){
_start:
{
lean_object* v___x_45_; lean_object* v___x_46_; uint8_t v___x_47_; 
v___x_45_ = lean_unsigned_to_nat(0u);
v___x_46_ = lean_array_get_size(v_f_44_);
v___x_47_ = lean_nat_dec_lt(v___x_45_, v___x_46_);
if (v___x_47_ == 0)
{
lean_object* v___x_48_; 
v___x_48_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_48_, 0, v_f_44_);
return v___x_48_;
}
else
{
if (v___x_47_ == 0)
{
lean_object* v___x_49_; 
v___x_49_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_49_, 0, v_f_44_);
return v___x_49_;
}
else
{
size_t v___x_50_; size_t v___x_51_; uint8_t v___x_52_; 
v___x_50_ = ((size_t)0ULL);
v___x_51_ = lean_usize_of_nat(v___x_46_);
v___x_52_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(v_f_44_, v___x_50_, v___x_51_);
if (v___x_52_ == 0)
{
lean_object* v___x_53_; 
v___x_53_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_53_, 0, v_f_44_);
return v___x_53_;
}
else
{
lean_object* v___x_54_; 
lean_dec_ref(v_f_44_);
v___x_54_ = lean_box(0);
return v___x_54_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx(lean_object* v_x_55_){
_start:
{
if (lean_obj_tag(v_x_55_) == 0)
{
lean_object* v___x_56_; 
v___x_56_ = lean_unsigned_to_nat(0u);
return v___x_56_;
}
else
{
lean_object* v___x_57_; 
v___x_57_ = lean_unsigned_to_nat(1u);
return v___x_57_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx___boxed(lean_object* v_x_58_){
_start:
{
lean_object* v_res_59_; 
v_res_59_ = lp_Hex_Hex_RealRootSet_ctorIdx(v_x_58_);
lean_dec(v_x_58_);
return v_res_59_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___redArg(lean_object* v_t_60_, lean_object* v_k_61_){
_start:
{
if (lean_obj_tag(v_t_60_) == 0)
{
return v_k_61_;
}
else
{
lean_object* v_roots_62_; lean_object* v___x_63_; 
v_roots_62_ = lean_ctor_get(v_t_60_, 0);
lean_inc_ref(v_roots_62_);
lean_dec_ref_known(v_t_60_, 1);
v___x_63_ = lean_apply_1(v_k_61_, v_roots_62_);
return v___x_63_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim(lean_object* v_motive_64_, lean_object* v_ctorIdx_65_, lean_object* v_t_66_, lean_object* v_h_67_, lean_object* v_k_68_){
_start:
{
lean_object* v___x_69_; 
v___x_69_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_66_, v_k_68_);
return v___x_69_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___boxed(lean_object* v_motive_70_, lean_object* v_ctorIdx_71_, lean_object* v_t_72_, lean_object* v_h_73_, lean_object* v_k_74_){
_start:
{
lean_object* v_res_75_; 
v_res_75_ = lp_Hex_Hex_RealRootSet_ctorElim(v_motive_70_, v_ctorIdx_71_, v_t_72_, v_h_73_, v_k_74_);
lean_dec(v_ctorIdx_71_);
return v_res_75_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim___redArg(lean_object* v_t_76_, lean_object* v_all_77_){
_start:
{
lean_object* v___x_78_; 
v___x_78_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_76_, v_all_77_);
return v___x_78_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim(lean_object* v_motive_79_, lean_object* v_t_80_, lean_object* v_h_81_, lean_object* v_all_82_){
_start:
{
lean_object* v___x_83_; 
v___x_83_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_80_, v_all_82_);
return v___x_83_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim___redArg(lean_object* v_t_84_, lean_object* v_finite_85_){
_start:
{
lean_object* v___x_86_; 
v___x_86_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_84_, v_finite_85_);
return v___x_86_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim(lean_object* v_motive_87_, lean_object* v_t_88_, lean_object* v_h_89_, lean_object* v_finite_90_){
_start:
{
lean_object* v___x_91_; 
v___x_91_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_88_, v_finite_90_);
return v___x_91_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_x3f(lean_object* v_x_92_){
_start:
{
if (lean_obj_tag(v_x_92_) == 0)
{
lean_object* v___x_93_; 
v___x_93_ = lean_box(0);
return v___x_93_;
}
else
{
lean_object* v_roots_94_; lean_object* v___x_96_; uint8_t v_isShared_97_; uint8_t v_isSharedCheck_101_; 
v_roots_94_ = lean_ctor_get(v_x_92_, 0);
v_isSharedCheck_101_ = !lean_is_exclusive(v_x_92_);
if (v_isSharedCheck_101_ == 0)
{
v___x_96_ = v_x_92_;
v_isShared_97_ = v_isSharedCheck_101_;
goto v_resetjp_95_;
}
else
{
lean_inc(v_roots_94_);
lean_dec(v_x_92_);
v___x_96_ = lean_box(0);
v_isShared_97_ = v_isSharedCheck_101_;
goto v_resetjp_95_;
}
v_resetjp_95_:
{
lean_object* v___x_99_; 
if (v_isShared_97_ == 0)
{
v___x_99_ = v___x_96_;
goto v_reusejp_98_;
}
else
{
lean_object* v_reuseFailAlloc_100_; 
v_reuseFailAlloc_100_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_100_, 0, v_roots_94_);
v___x_99_ = v_reuseFailAlloc_100_;
goto v_reusejp_98_;
}
v_reusejp_98_:
{
return v___x_99_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_toArray(lean_object* v_roots_104_){
_start:
{
lean_object* v___x_105_; 
v___x_105_ = lp_Hex_Hex_RealRootSet_finite_x3f(v_roots_104_);
if (lean_obj_tag(v___x_105_) == 0)
{
lean_object* v___x_106_; 
v___x_106_ = ((lean_object*)(lp_Hex_Hex_RealRootSet_toArray___closed__0));
return v___x_106_;
}
else
{
lean_object* v_val_107_; 
v_val_107_ = lean_ctor_get(v___x_105_, 0);
lean_inc(v_val_107_);
lean_dec_ref_known(v___x_105_, 1);
return v_val_107_;
}
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(lean_object* v_a_108_, lean_object* v_as_109_, size_t v_i_110_, size_t v_stop_111_){
_start:
{
uint8_t v___x_112_; 
v___x_112_ = lean_usize_dec_eq(v_i_110_, v_stop_111_);
if (v___x_112_ == 0)
{
lean_object* v___x_113_; lean_object* v_root_114_; uint8_t v___x_115_; 
v___x_113_ = lean_array_uget_borrowed(v_as_109_, v_i_110_);
v_root_114_ = lean_ctor_get(v___x_113_, 0);
lean_inc_ref(v_a_108_);
lean_inc_ref(v_root_114_);
v___x_115_ = lp_Hex_Hex_AlgebraicNumber_beq(v_root_114_, v_a_108_);
if (v___x_115_ == 0)
{
size_t v___x_116_; size_t v___x_117_; 
v___x_116_ = ((size_t)1ULL);
v___x_117_ = lean_usize_add(v_i_110_, v___x_116_);
v_i_110_ = v___x_117_;
goto _start;
}
else
{
lean_dec_ref(v_a_108_);
return v___x_115_;
}
}
else
{
uint8_t v___x_119_; 
lean_dec_ref(v_a_108_);
v___x_119_ = 0;
return v___x_119_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0___boxed(lean_object* v_a_120_, lean_object* v_as_121_, lean_object* v_i_122_, lean_object* v_stop_123_){
_start:
{
size_t v_i_boxed_124_; size_t v_stop_boxed_125_; uint8_t v_res_126_; lean_object* v_r_127_; 
v_i_boxed_124_ = lean_unbox_usize(v_i_122_);
lean_dec(v_i_122_);
v_stop_boxed_125_ = lean_unbox_usize(v_stop_123_);
lean_dec(v_stop_123_);
v_res_126_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(v_a_120_, v_as_121_, v_i_boxed_124_, v_stop_boxed_125_);
lean_dec_ref(v_as_121_);
v_r_127_ = lean_box(v_res_126_);
return v_r_127_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_RealRootSet_contains(lean_object* v_roots_128_, lean_object* v_a_129_){
_start:
{
if (lean_obj_tag(v_roots_128_) == 0)
{
uint8_t v___x_130_; 
lean_dec_ref(v_a_129_);
v___x_130_ = 1;
return v___x_130_;
}
else
{
lean_object* v_roots_131_; lean_object* v___x_132_; lean_object* v___x_133_; uint8_t v___x_134_; 
v_roots_131_ = lean_ctor_get(v_roots_128_, 0);
v___x_132_ = lean_unsigned_to_nat(0u);
v___x_133_ = lean_array_get_size(v_roots_131_);
v___x_134_ = lean_nat_dec_lt(v___x_132_, v___x_133_);
if (v___x_134_ == 0)
{
lean_dec_ref(v_a_129_);
return v___x_134_;
}
else
{
if (v___x_134_ == 0)
{
lean_dec_ref(v_a_129_);
return v___x_134_;
}
else
{
size_t v___x_135_; size_t v___x_136_; uint8_t v___x_137_; 
v___x_135_ = ((size_t)0ULL);
v___x_136_ = lean_usize_of_nat(v___x_133_);
v___x_137_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(v_a_129_, v_roots_131_, v___x_135_, v___x_136_);
return v___x_137_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_contains___boxed(lean_object* v_roots_138_, lean_object* v_a_139_){
_start:
{
uint8_t v_res_140_; lean_object* v_r_141_; 
v_res_140_ = lp_Hex_Hex_RealRootSet_contains(v_roots_138_, v_a_139_);
lean_dec(v_roots_138_);
v_r_141_ = lean_box(v_res_140_);
return v_r_141_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f(lean_object* v_r_142_){
_start:
{
lean_object* v_root_143_; lean_object* v_multiplicity_144_; lean_object* v___x_146_; uint8_t v_isShared_147_; uint8_t v_isSharedCheck_161_; 
v_root_143_ = lean_ctor_get(v_r_142_, 0);
v_multiplicity_144_ = lean_ctor_get(v_r_142_, 1);
v_isSharedCheck_161_ = !lean_is_exclusive(v_r_142_);
if (v_isSharedCheck_161_ == 0)
{
v___x_146_ = v_r_142_;
v_isShared_147_ = v_isSharedCheck_161_;
goto v_resetjp_145_;
}
else
{
lean_inc(v_multiplicity_144_);
lean_inc(v_root_143_);
lean_dec(v_r_142_);
v___x_146_ = lean_box(0);
v_isShared_147_ = v_isSharedCheck_161_;
goto v_resetjp_145_;
}
v_resetjp_145_:
{
lean_object* v___x_148_; 
v___x_148_ = lp_Hex_Hex_RealAlgebraicNumber_ofRoot_x3f(v_root_143_);
if (lean_obj_tag(v___x_148_) == 0)
{
lean_object* v___x_149_; 
lean_del_object(v___x_146_);
lean_dec(v_multiplicity_144_);
v___x_149_ = lean_box(0);
return v___x_149_;
}
else
{
lean_object* v_val_150_; lean_object* v___x_152_; uint8_t v_isShared_153_; uint8_t v_isSharedCheck_160_; 
v_val_150_ = lean_ctor_get(v___x_148_, 0);
v_isSharedCheck_160_ = !lean_is_exclusive(v___x_148_);
if (v_isSharedCheck_160_ == 0)
{
v___x_152_ = v___x_148_;
v_isShared_153_ = v_isSharedCheck_160_;
goto v_resetjp_151_;
}
else
{
lean_inc(v_val_150_);
lean_dec(v___x_148_);
v___x_152_ = lean_box(0);
v_isShared_153_ = v_isSharedCheck_160_;
goto v_resetjp_151_;
}
v_resetjp_151_:
{
lean_object* v___x_155_; 
if (v_isShared_147_ == 0)
{
lean_ctor_set(v___x_146_, 0, v_val_150_);
v___x_155_ = v___x_146_;
goto v_reusejp_154_;
}
else
{
lean_object* v_reuseFailAlloc_159_; 
v_reuseFailAlloc_159_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_159_, 0, v_val_150_);
lean_ctor_set(v_reuseFailAlloc_159_, 1, v_multiplicity_144_);
v___x_155_ = v_reuseFailAlloc_159_;
goto v_reusejp_154_;
}
v_reusejp_154_:
{
lean_object* v___x_157_; 
if (v_isShared_153_ == 0)
{
lean_ctor_set(v___x_152_, 0, v___x_155_);
v___x_157_ = v___x_152_;
goto v_reusejp_156_;
}
else
{
lean_object* v_reuseFailAlloc_158_; 
v_reuseFailAlloc_158_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_158_, 0, v___x_155_);
v___x_157_ = v_reuseFailAlloc_158_;
goto v_reusejp_156_;
}
v_reusejp_156_:
{
return v___x_157_;
}
}
}
}
}
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_RealAlgebraicPoly_realRoots___lam__0(lean_object* v_a_162_, lean_object* v_b_163_){
_start:
{
lean_object* v_root_164_; lean_object* v_root_165_; uint8_t v___x_166_; 
v_root_164_ = lean_ctor_get(v_a_162_, 0);
lean_inc_ref(v_root_164_);
lean_dec_ref(v_a_162_);
v_root_165_ = lean_ctor_get(v_b_163_, 0);
lean_inc_ref(v_root_165_);
lean_dec_ref(v_b_163_);
v___x_166_ = lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE(v_root_164_, v_root_165_);
return v___x_166_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoots___lam__0___boxed(lean_object* v_a_167_, lean_object* v_b_168_){
_start:
{
uint8_t v_res_169_; lean_object* v_r_170_; 
v_res_169_ = lp_Hex_Hex_RealAlgebraicPoly_realRoots___lam__0(v_a_167_, v_b_168_);
v_r_170_ = lean_box(v_res_169_);
return v_r_170_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0_spec__0(lean_object* v_as_171_, size_t v_i_172_, size_t v_stop_173_, lean_object* v_b_174_){
_start:
{
lean_object* v___y_176_; uint8_t v___x_180_; 
v___x_180_ = lean_usize_dec_eq(v_i_172_, v_stop_173_);
if (v___x_180_ == 0)
{
lean_object* v___x_181_; lean_object* v___x_182_; 
v___x_181_ = lean_array_uget_borrowed(v_as_171_, v_i_172_);
lean_inc(v___x_181_);
v___x_182_ = lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f(v___x_181_);
if (lean_obj_tag(v___x_182_) == 0)
{
v___y_176_ = v_b_174_;
goto v___jp_175_;
}
else
{
lean_object* v_val_183_; lean_object* v___x_184_; 
v_val_183_ = lean_ctor_get(v___x_182_, 0);
lean_inc(v_val_183_);
lean_dec_ref_known(v___x_182_, 1);
v___x_184_ = lean_array_push(v_b_174_, v_val_183_);
v___y_176_ = v___x_184_;
goto v___jp_175_;
}
}
else
{
return v_b_174_;
}
v___jp_175_:
{
size_t v___x_177_; size_t v___x_178_; 
v___x_177_ = ((size_t)1ULL);
v___x_178_ = lean_usize_add(v_i_172_, v___x_177_);
v_i_172_ = v___x_178_;
v_b_174_ = v___y_176_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0_spec__0___boxed(lean_object* v_as_185_, lean_object* v_i_186_, lean_object* v_stop_187_, lean_object* v_b_188_){
_start:
{
size_t v_i_boxed_189_; size_t v_stop_boxed_190_; lean_object* v_res_191_; 
v_i_boxed_189_ = lean_unbox_usize(v_i_186_);
lean_dec(v_i_186_);
v_stop_boxed_190_ = lean_unbox_usize(v_stop_187_);
lean_dec(v_stop_187_);
v_res_191_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0_spec__0(v_as_185_, v_i_boxed_189_, v_stop_boxed_190_, v_b_188_);
lean_dec_ref(v_as_185_);
return v_res_191_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0(lean_object* v_as_192_, lean_object* v_start_193_, lean_object* v_stop_194_){
_start:
{
lean_object* v___x_195_; uint8_t v___x_196_; 
v___x_195_ = ((lean_object*)(lp_Hex_Hex_RealRootSet_toArray___closed__0));
v___x_196_ = lean_nat_dec_lt(v_start_193_, v_stop_194_);
if (v___x_196_ == 0)
{
return v___x_195_;
}
else
{
lean_object* v___x_197_; uint8_t v___x_198_; 
v___x_197_ = lean_array_get_size(v_as_192_);
v___x_198_ = lean_nat_dec_le(v_stop_194_, v___x_197_);
if (v___x_198_ == 0)
{
uint8_t v___x_199_; 
v___x_199_ = lean_nat_dec_lt(v_start_193_, v___x_197_);
if (v___x_199_ == 0)
{
return v___x_195_;
}
else
{
size_t v___x_200_; size_t v___x_201_; lean_object* v___x_202_; 
v___x_200_ = lean_usize_of_nat(v_start_193_);
v___x_201_ = lean_usize_of_nat(v___x_197_);
v___x_202_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0_spec__0(v_as_192_, v___x_200_, v___x_201_, v___x_195_);
return v___x_202_;
}
}
else
{
size_t v___x_203_; size_t v___x_204_; lean_object* v___x_205_; 
v___x_203_ = lean_usize_of_nat(v_start_193_);
v___x_204_ = lean_usize_of_nat(v_stop_194_);
v___x_205_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0_spec__0(v_as_192_, v___x_203_, v___x_204_, v___x_195_);
return v___x_205_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0___boxed(lean_object* v_as_206_, lean_object* v_start_207_, lean_object* v_stop_208_){
_start:
{
lean_object* v_res_209_; 
v_res_209_ = lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0(v_as_206_, v_start_207_, v_stop_208_);
lean_dec(v_stop_208_);
lean_dec(v_start_207_);
lean_dec_ref(v_as_206_);
return v_res_209_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoots(lean_object* v_x_211_){
_start:
{
if (lean_obj_tag(v_x_211_) == 0)
{
lean_object* v___x_212_; 
v___x_212_ = lean_box(0);
return v___x_212_;
}
else
{
lean_object* v_roots_213_; lean_object* v___x_215_; uint8_t v_isShared_216_; uint8_t v_isSharedCheck_227_; 
v_roots_213_ = lean_ctor_get(v_x_211_, 0);
v_isSharedCheck_227_ = !lean_is_exclusive(v_x_211_);
if (v_isSharedCheck_227_ == 0)
{
v___x_215_ = v_x_211_;
v_isShared_216_ = v_isSharedCheck_227_;
goto v_resetjp_214_;
}
else
{
lean_inc(v_roots_213_);
lean_dec(v_x_211_);
v___x_215_ = lean_box(0);
v_isShared_216_ = v_isSharedCheck_227_;
goto v_resetjp_214_;
}
v_resetjp_214_:
{
lean_object* v___f_217_; lean_object* v___x_218_; lean_object* v___x_219_; lean_object* v___x_220_; lean_object* v___x_221_; lean_object* v___x_222_; lean_object* v___x_223_; lean_object* v___x_225_; 
v___f_217_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_realRoots___closed__0));
v___x_218_ = lean_unsigned_to_nat(0u);
v___x_219_ = lean_array_get_size(v_roots_213_);
v___x_220_ = lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRoots_spec__0(v_roots_213_, v___x_218_, v___x_219_);
lean_dec_ref(v_roots_213_);
v___x_221_ = lean_array_to_list(v___x_220_);
v___x_222_ = l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(v___x_221_, v___f_217_);
v___x_223_ = lean_array_mk(v___x_222_);
if (v_isShared_216_ == 0)
{
lean_ctor_set(v___x_215_, 0, v___x_223_);
v___x_225_ = v___x_215_;
goto v_reusejp_224_;
}
else
{
lean_object* v_reuseFailAlloc_226_; 
v_reuseFailAlloc_226_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_226_, 0, v___x_223_);
v___x_225_ = v_reuseFailAlloc_226_;
goto v_reusejp_224_;
}
v_reusejp_224_:
{
return v___x_225_;
}
}
}
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1___redArg(lean_object* v_xs_228_, lean_object* v_ys_229_, lean_object* v_x_230_){
_start:
{
lean_object* v_zero_231_; uint8_t v_isZero_232_; 
v_zero_231_ = lean_unsigned_to_nat(0u);
v_isZero_232_ = lean_nat_dec_eq(v_x_230_, v_zero_231_);
if (v_isZero_232_ == 1)
{
lean_dec(v_x_230_);
return v_isZero_232_;
}
else
{
lean_object* v_one_233_; lean_object* v_n_234_; lean_object* v___x_235_; lean_object* v___x_236_; uint8_t v___x_237_; 
v_one_233_ = lean_unsigned_to_nat(1u);
v_n_234_ = lean_nat_sub(v_x_230_, v_one_233_);
lean_dec(v_x_230_);
v___x_235_ = lean_array_fget_borrowed(v_xs_228_, v_n_234_);
v___x_236_ = lean_array_fget_borrowed(v_ys_229_, v_n_234_);
v___x_237_ = lean_int_dec_eq(v___x_235_, v___x_236_);
if (v___x_237_ == 0)
{
lean_dec(v_n_234_);
return v___x_237_;
}
else
{
v_x_230_ = v_n_234_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1___redArg___boxed(lean_object* v_xs_239_, lean_object* v_ys_240_, lean_object* v_x_241_){
_start:
{
uint8_t v_res_242_; lean_object* v_r_243_; 
v_res_242_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1___redArg(v_xs_239_, v_ys_240_, v_x_241_);
lean_dec_ref(v_ys_240_);
lean_dec_ref(v_xs_239_);
v_r_243_ = lean_box(v_res_242_);
return v_r_243_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0(lean_object* v_xs_244_, lean_object* v_ys_245_){
_start:
{
lean_object* v___x_246_; lean_object* v___x_247_; uint8_t v___x_248_; 
v___x_246_ = lean_array_get_size(v_xs_244_);
v___x_247_ = lean_array_get_size(v_ys_245_);
v___x_248_ = lean_nat_dec_eq(v___x_246_, v___x_247_);
if (v___x_248_ == 0)
{
return v___x_248_;
}
else
{
uint8_t v___x_249_; 
v___x_249_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1___redArg(v_xs_244_, v_ys_245_, v___x_246_);
return v___x_249_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0___boxed(lean_object* v_xs_250_, lean_object* v_ys_251_){
_start:
{
uint8_t v_res_252_; lean_object* v_r_253_; 
v_res_252_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0(v_xs_250_, v_ys_251_);
lean_dec_ref(v_ys_251_);
lean_dec_ref(v_xs_250_);
v_r_253_ = lean_box(v_res_252_);
return v_r_253_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0(lean_object* v_a_254_, lean_object* v_b_255_){
_start:
{
uint8_t v_decide_256_; 
v_decide_256_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0(v_a_254_, v_b_255_);
return v_decide_256_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0___boxed(lean_object* v_a_257_, lean_object* v_b_258_){
_start:
{
uint8_t v_res_259_; lean_object* v_r_260_; 
v_res_259_ = lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0(v_a_257_, v_b_258_);
lean_dec_ref(v_b_258_);
lean_dec_ref(v_a_257_);
v_r_260_ = lean_box(v_res_259_);
return v_r_260_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg(lean_object* v_p_262_, lean_object* v_isolations_263_, lean_object* v_refined_264_, lean_object* v_fallback_265_, lean_object* v_r_266_){
_start:
{
lean_object* v_root_267_; lean_object* v_multiplicity_268_; lean_object* v___y_270_; lean_object* v_p_282_; uint8_t v_decide_283_; 
v_root_267_ = lean_ctor_get(v_r_266_, 0);
v_multiplicity_268_ = lean_ctor_get(v_r_266_, 1);
v_p_282_ = lean_ctor_get(v_root_267_, 0);
v_decide_283_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0(v_p_262_, v_p_282_);
if (v_decide_283_ == 0)
{
lean_object* v___x_284_; 
lean_dec_ref(v_refined_264_);
v___x_284_ = lean_apply_1(v_fallback_265_, v_r_266_);
return v___x_284_;
}
else
{
uint8_t v___x_285_; 
lean_inc(v_multiplicity_268_);
lean_inc_ref(v_root_267_);
lean_dec_ref(v_r_266_);
lean_dec_ref(v_fallback_265_);
v___x_285_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_267_);
if (v___x_285_ == 0)
{
lean_object* v___x_286_; 
lean_dec(v_multiplicity_268_);
lean_dec_ref(v_root_267_);
lean_dec_ref(v_refined_264_);
v___x_286_ = lean_box(0);
return v___x_286_;
}
else
{
lean_object* v_exact_287_; 
v_exact_287_ = lp_Hex_Hex_AlgebraicRoot_exactIn_x3f___redArg(v_root_267_, v_isolations_263_, v_refined_264_);
if (lean_obj_tag(v_exact_287_) == 0)
{
lean_object* v___x_288_; lean_object* v___x_289_; lean_object* v___x_290_; 
v___x_288_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
v___x_289_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg___closed__0));
v___x_290_ = lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_box(0), v___x_288_, v___x_289_);
v___y_270_ = v___x_290_;
goto v___jp_269_;
}
else
{
lean_object* v_val_291_; 
v_val_291_ = lean_ctor_get(v_exact_287_, 0);
lean_inc(v_val_291_);
lean_dec_ref_known(v_exact_287_, 1);
v___y_270_ = v_val_291_;
goto v___jp_269_;
}
}
}
v___jp_269_:
{
lean_object* v___x_271_; 
v___x_271_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___y_270_);
if (lean_obj_tag(v___x_271_) == 0)
{
lean_object* v___x_272_; 
lean_dec(v_multiplicity_268_);
v___x_272_ = lean_box(0);
return v___x_272_;
}
else
{
lean_object* v_val_273_; lean_object* v___x_275_; uint8_t v_isShared_276_; uint8_t v_isSharedCheck_281_; 
v_val_273_ = lean_ctor_get(v___x_271_, 0);
v_isSharedCheck_281_ = !lean_is_exclusive(v___x_271_);
if (v_isSharedCheck_281_ == 0)
{
v___x_275_ = v___x_271_;
v_isShared_276_ = v_isSharedCheck_281_;
goto v_resetjp_274_;
}
else
{
lean_inc(v_val_273_);
lean_dec(v___x_271_);
v___x_275_ = lean_box(0);
v_isShared_276_ = v_isSharedCheck_281_;
goto v_resetjp_274_;
}
v_resetjp_274_:
{
lean_object* v___x_277_; lean_object* v___x_279_; 
v___x_277_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_277_, 0, v_val_273_);
lean_ctor_set(v___x_277_, 1, v_multiplicity_268_);
if (v_isShared_276_ == 0)
{
lean_ctor_set(v___x_275_, 0, v___x_277_);
v___x_279_ = v___x_275_;
goto v_reusejp_278_;
}
else
{
lean_object* v_reuseFailAlloc_280_; 
v_reuseFailAlloc_280_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_280_, 0, v___x_277_);
v___x_279_ = v_reuseFailAlloc_280_;
goto v_reusejp_278_;
}
v_reusejp_278_:
{
return v___x_279_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg___boxed(lean_object* v_p_292_, lean_object* v_isolations_293_, lean_object* v_refined_294_, lean_object* v_fallback_295_, lean_object* v_r_296_){
_start:
{
lean_object* v_res_297_; 
v_res_297_ = lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg(v_p_292_, v_isolations_293_, v_refined_294_, v_fallback_295_, v_r_296_);
lean_dec_ref(v_isolations_293_);
lean_dec_ref(v_p_292_);
return v_res_297_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootPicker(lean_object* v_p_298_, lean_object* v_squarefree_299_, lean_object* v_isolations_300_, lean_object* v_refined_301_, lean_object* v_hisolate_302_, lean_object* v_hrefine_303_, lean_object* v_fallback_304_, lean_object* v_r_305_){
_start:
{
lean_object* v___x_306_; 
v___x_306_ = lp_Hex_Hex_RealAlgebraicPoly_rootPicker___redArg(v_p_298_, v_isolations_300_, v_refined_301_, v_fallback_304_, v_r_305_);
return v___x_306_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootPicker___boxed(lean_object* v_p_307_, lean_object* v_squarefree_308_, lean_object* v_isolations_309_, lean_object* v_refined_310_, lean_object* v_hisolate_311_, lean_object* v_hrefine_312_, lean_object* v_fallback_313_, lean_object* v_r_314_){
_start:
{
lean_object* v_res_315_; 
v_res_315_ = lp_Hex_Hex_RealAlgebraicPoly_rootPicker(v_p_307_, v_squarefree_308_, v_isolations_309_, v_refined_310_, v_hisolate_311_, v_hrefine_312_, v_fallback_313_, v_r_314_);
lean_dec_ref(v_isolations_309_);
lean_dec_ref(v_p_307_);
return v_res_315_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1(lean_object* v_xs_316_, lean_object* v_ys_317_, lean_object* v_hsz_318_, lean_object* v_x_319_, lean_object* v_x_320_){
_start:
{
uint8_t v___x_321_; 
v___x_321_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1___redArg(v_xs_316_, v_ys_317_, v_x_319_);
return v___x_321_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1___boxed(lean_object* v_xs_322_, lean_object* v_ys_323_, lean_object* v_hsz_324_, lean_object* v_x_325_, lean_object* v_x_326_){
_start:
{
uint8_t v_res_327_; lean_object* v_r_328_; 
v_res_327_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0_spec__1(v_xs_322_, v_ys_323_, v_hsz_324_, v_x_325_, v_x_326_);
lean_dec_ref(v_ys_323_);
lean_dec_ref(v_xs_322_);
v_r_328_ = lean_box(v_res_327_);
return v_r_328_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__1(lean_object* v_a_329_){
_start:
{
lean_object* v___x_330_; 
v___x_330_ = lean_nat_to_int(v_a_329_);
return v___x_330_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0_spec__0(lean_object* v_a_331_, lean_object* v_as_332_, size_t v_i_333_, size_t v_stop_334_){
_start:
{
uint8_t v___x_335_; 
v___x_335_ = lean_usize_dec_eq(v_i_333_, v_stop_334_);
if (v___x_335_ == 0)
{
lean_object* v___x_336_; uint8_t v_decide_337_; 
v___x_336_ = lean_array_uget_borrowed(v_as_332_, v_i_333_);
v_decide_337_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0(v_a_331_, v___x_336_);
if (v_decide_337_ == 0)
{
size_t v___x_338_; size_t v___x_339_; 
v___x_338_ = ((size_t)1ULL);
v___x_339_ = lean_usize_add(v_i_333_, v___x_338_);
v_i_333_ = v___x_339_;
goto _start;
}
else
{
return v_decide_337_;
}
}
else
{
uint8_t v___x_341_; 
v___x_341_ = 0;
return v___x_341_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0_spec__0___boxed(lean_object* v_a_342_, lean_object* v_as_343_, lean_object* v_i_344_, lean_object* v_stop_345_){
_start:
{
size_t v_i_boxed_346_; size_t v_stop_boxed_347_; uint8_t v_res_348_; lean_object* v_r_349_; 
v_i_boxed_346_ = lean_unbox_usize(v_i_344_);
lean_dec(v_i_344_);
v_stop_boxed_347_ = lean_unbox_usize(v_stop_345_);
lean_dec(v_stop_345_);
v_res_348_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0_spec__0(v_a_342_, v_as_343_, v_i_boxed_346_, v_stop_boxed_347_);
lean_dec_ref(v_as_343_);
lean_dec_ref(v_a_342_);
v_r_349_ = lean_box(v_res_348_);
return v_r_349_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0(lean_object* v_as_350_, lean_object* v_a_351_){
_start:
{
lean_object* v___x_352_; lean_object* v___x_353_; uint8_t v___x_354_; 
v___x_352_ = lean_unsigned_to_nat(0u);
v___x_353_ = lean_array_get_size(v_as_350_);
v___x_354_ = lean_nat_dec_lt(v___x_352_, v___x_353_);
if (v___x_354_ == 0)
{
return v___x_354_;
}
else
{
if (v___x_354_ == 0)
{
return v___x_354_;
}
else
{
size_t v___x_355_; size_t v___x_356_; uint8_t v___x_357_; 
v___x_355_ = ((size_t)0ULL);
v___x_356_ = lean_usize_of_nat(v___x_353_);
v___x_357_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0_spec__0(v_a_351_, v_as_350_, v___x_355_, v___x_356_);
return v___x_357_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0___boxed(lean_object* v_as_358_, lean_object* v_a_359_){
_start:
{
uint8_t v_res_360_; lean_object* v_r_361_; 
v_res_360_ = lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0(v_as_358_, v_a_359_);
lean_dec_ref(v_a_359_);
lean_dec_ref(v_as_358_);
v_r_361_ = lean_box(v_res_360_);
return v_r_361_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__3(uint8_t v___x_362_, lean_object* v___x_363_, lean_object* v_as_364_, size_t v_i_365_, size_t v_stop_366_, lean_object* v_b_367_){
_start:
{
lean_object* v___y_369_; uint8_t v___x_373_; 
v___x_373_ = lean_usize_dec_eq(v_i_365_, v_stop_366_);
if (v___x_373_ == 0)
{
lean_object* v___x_374_; uint8_t v___y_376_; lean_object* v_root_378_; uint8_t v___x_379_; 
v___x_374_ = lean_array_uget_borrowed(v_as_364_, v_i_365_);
v_root_378_ = lean_ctor_get(v___x_374_, 0);
v___x_379_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_378_);
if (v___x_379_ == 0)
{
v___y_376_ = v___x_362_;
goto v___jp_375_;
}
else
{
lean_object* v_p_380_; uint8_t v_decide_381_; 
v_p_380_ = lean_ctor_get(v_root_378_, 0);
v_decide_381_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_rootPicker_spec__0_spec__0(v_p_380_, v___x_363_);
v___y_376_ = v_decide_381_;
goto v___jp_375_;
}
v___jp_375_:
{
if (v___y_376_ == 0)
{
v___y_369_ = v_b_367_;
goto v___jp_368_;
}
else
{
lean_object* v___x_377_; 
lean_inc(v___x_374_);
v___x_377_ = lean_array_push(v_b_367_, v___x_374_);
v___y_369_ = v___x_377_;
goto v___jp_368_;
}
}
}
else
{
return v_b_367_;
}
v___jp_368_:
{
size_t v___x_370_; size_t v___x_371_; 
v___x_370_ = ((size_t)1ULL);
v___x_371_ = lean_usize_add(v_i_365_, v___x_370_);
v_i_365_ = v___x_371_;
v_b_367_ = v___y_369_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__3___boxed(lean_object* v___x_382_, lean_object* v___x_383_, lean_object* v_as_384_, lean_object* v_i_385_, lean_object* v_stop_386_, lean_object* v_b_387_){
_start:
{
uint8_t v___x_1658__boxed_388_; size_t v_i_boxed_389_; size_t v_stop_boxed_390_; lean_object* v_res_391_; 
v___x_1658__boxed_388_ = lean_unbox(v___x_382_);
v_i_boxed_389_ = lean_unbox_usize(v_i_385_);
lean_dec(v_i_385_);
v_stop_boxed_390_ = lean_unbox_usize(v_stop_386_);
lean_dec(v_stop_386_);
v_res_391_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__3(v___x_1658__boxed_388_, v___x_383_, v_as_384_, v_i_boxed_389_, v_stop_boxed_390_, v_b_387_);
lean_dec_ref(v_as_384_);
lean_dec_ref(v___x_383_);
return v_res_391_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__2(lean_object* v___x_392_, size_t v_sz_393_, size_t v_i_394_, lean_object* v_bs_395_){
_start:
{
uint8_t v___x_396_; 
v___x_396_ = lean_usize_dec_lt(v_i_394_, v_sz_393_);
if (v___x_396_ == 0)
{
lean_object* v___x_397_; 
v___x_397_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_397_, 0, v_bs_395_);
return v___x_397_;
}
else
{
lean_object* v_v_398_; lean_object* v___x_399_; 
v_v_398_ = lean_array_uget_borrowed(v_bs_395_, v_i_394_);
lean_inc(v_v_398_);
v___x_399_ = lp_Hex_Hex_DyadicRootIsolation_toRefined_x3f(v___x_392_, v_v_398_);
if (lean_obj_tag(v___x_399_) == 0)
{
lean_object* v___x_400_; 
lean_dec_ref(v_bs_395_);
v___x_400_ = lean_box(0);
return v___x_400_;
}
else
{
lean_object* v_val_401_; lean_object* v___x_402_; lean_object* v_bs_x27_403_; size_t v___x_404_; size_t v___x_405_; lean_object* v___x_406_; 
v_val_401_ = lean_ctor_get(v___x_399_, 0);
lean_inc(v_val_401_);
lean_dec_ref_known(v___x_399_, 1);
v___x_402_ = lean_unsigned_to_nat(0u);
v_bs_x27_403_ = lean_array_uset(v_bs_395_, v_i_394_, v___x_402_);
v___x_404_ = ((size_t)1ULL);
v___x_405_ = lean_usize_add(v_i_394_, v___x_404_);
v___x_406_ = lean_array_uset(v_bs_x27_403_, v_i_394_, v_val_401_);
v_i_394_ = v___x_405_;
v_bs_395_ = v___x_406_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__2___boxed(lean_object* v___x_408_, lean_object* v_sz_409_, lean_object* v_i_410_, lean_object* v_bs_411_){
_start:
{
size_t v_sz_boxed_412_; size_t v_i_boxed_413_; lean_object* v_res_414_; 
v_sz_boxed_412_ = lean_unbox_usize(v_sz_409_);
lean_dec(v_sz_409_);
v_i_boxed_413_ = lean_unbox_usize(v_i_410_);
lean_dec(v_i_410_);
v_res_414_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__2(v___x_408_, v_sz_boxed_412_, v_i_boxed_413_, v_bs_411_);
lean_dec_ref(v___x_408_);
return v_res_414_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4(lean_object* v_roots_417_, lean_object* v_as_418_, size_t v_i_419_, size_t v_stop_420_, lean_object* v_b_421_){
_start:
{
lean_object* v___y_423_; uint8_t v___x_427_; 
v___x_427_ = lean_usize_dec_eq(v_i_419_, v_stop_420_);
if (v___x_427_ == 0)
{
lean_object* v___x_428_; lean_object* v_root_429_; lean_object* v___x_431_; uint8_t v_isShared_432_; uint8_t v_isSharedCheck_485_; 
v___x_428_ = lean_array_uget(v_as_418_, v_i_419_);
v_root_429_ = lean_ctor_get(v___x_428_, 0);
v_isSharedCheck_485_ = !lean_is_exclusive(v___x_428_);
if (v_isSharedCheck_485_ == 0)
{
lean_object* v_unused_486_; 
v_unused_486_ = lean_ctor_get(v___x_428_, 1);
lean_dec(v_unused_486_);
v___x_431_ = v___x_428_;
v_isShared_432_ = v_isSharedCheck_485_;
goto v_resetjp_430_;
}
else
{
lean_inc(v_root_429_);
lean_dec(v___x_428_);
v___x_431_ = lean_box(0);
v_isShared_432_ = v_isSharedCheck_485_;
goto v_resetjp_430_;
}
v_resetjp_430_:
{
uint8_t v___x_433_; 
v___x_433_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_429_);
if (v___x_433_ == 0)
{
lean_del_object(v___x_431_);
lean_dec_ref(v_root_429_);
v___y_423_ = v_b_421_;
goto v___jp_422_;
}
else
{
lean_object* v_fst_434_; lean_object* v_snd_435_; lean_object* v_p_436_; uint8_t v___x_437_; 
v_fst_434_ = lean_ctor_get(v_b_421_, 0);
v_snd_435_ = lean_ctor_get(v_b_421_, 1);
v_p_436_ = lean_ctor_get(v_root_429_, 0);
lean_inc_ref(v_p_436_);
lean_dec_ref(v_root_429_);
v___x_437_ = lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__0(v_fst_434_, v_p_436_);
if (v___x_437_ == 0)
{
lean_object* v___x_439_; uint8_t v_isShared_440_; uint8_t v_isSharedCheck_482_; 
lean_inc(v_snd_435_);
lean_inc(v_fst_434_);
v_isSharedCheck_482_ = !lean_is_exclusive(v_b_421_);
if (v_isSharedCheck_482_ == 0)
{
lean_object* v_unused_483_; lean_object* v_unused_484_; 
v_unused_483_ = lean_ctor_get(v_b_421_, 1);
lean_dec(v_unused_483_);
v_unused_484_ = lean_ctor_get(v_b_421_, 0);
lean_dec(v_unused_484_);
v___x_439_ = v_b_421_;
v_isShared_440_ = v_isSharedCheck_482_;
goto v_resetjp_438_;
}
else
{
lean_dec(v_b_421_);
v___x_439_ = lean_box(0);
v_isShared_440_ = v_isSharedCheck_482_;
goto v_resetjp_438_;
}
v_resetjp_438_:
{
lean_object* v_seen_441_; lean_object* v___y_447_; lean_object* v___x_471_; lean_object* v___x_472_; lean_object* v___x_473_; uint8_t v___x_474_; 
lean_inc_ref(v_p_436_);
v_seen_441_ = lean_array_push(v_fst_434_, v_p_436_);
v___x_471_ = lean_unsigned_to_nat(0u);
v___x_472_ = lean_array_get_size(v_roots_417_);
v___x_473_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4___closed__0));
v___x_474_ = lean_nat_dec_lt(v___x_471_, v___x_472_);
if (v___x_474_ == 0)
{
v___y_447_ = v___x_473_;
goto v___jp_446_;
}
else
{
uint8_t v___x_475_; 
v___x_475_ = lean_nat_dec_le(v___x_472_, v___x_472_);
if (v___x_475_ == 0)
{
if (v___x_474_ == 0)
{
v___y_447_ = v___x_473_;
goto v___jp_446_;
}
else
{
size_t v___x_476_; size_t v___x_477_; lean_object* v___x_478_; 
v___x_476_ = ((size_t)0ULL);
v___x_477_ = lean_usize_of_nat(v___x_472_);
v___x_478_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__3(v___x_437_, v_p_436_, v_roots_417_, v___x_476_, v___x_477_, v___x_473_);
v___y_447_ = v___x_478_;
goto v___jp_446_;
}
}
else
{
size_t v___x_479_; size_t v___x_480_; lean_object* v___x_481_; 
v___x_479_ = ((size_t)0ULL);
v___x_480_ = lean_usize_of_nat(v___x_472_);
v___x_481_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__3(v___x_437_, v_p_436_, v_roots_417_, v___x_479_, v___x_480_, v___x_473_);
v___y_447_ = v___x_481_;
goto v___jp_446_;
}
}
v___jp_442_:
{
lean_object* v___x_444_; 
if (v_isShared_440_ == 0)
{
lean_ctor_set(v___x_439_, 0, v_seen_441_);
v___x_444_ = v___x_439_;
goto v_reusejp_443_;
}
else
{
lean_object* v_reuseFailAlloc_445_; 
v_reuseFailAlloc_445_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_445_, 0, v_seen_441_);
lean_ctor_set(v_reuseFailAlloc_445_, 1, v_snd_435_);
v___x_444_ = v_reuseFailAlloc_445_;
goto v_reusejp_443_;
}
v_reusejp_443_:
{
v___y_423_ = v___x_444_;
goto v___jp_422_;
}
}
v___jp_446_:
{
lean_object* v___x_448_; lean_object* v___x_449_; uint8_t v___x_450_; 
v___x_448_ = lean_array_get_size(v___y_447_);
lean_dec_ref(v___y_447_);
v___x_449_ = lean_unsigned_to_nat(2u);
v___x_450_ = lean_nat_dec_lt(v___x_448_, v___x_449_);
if (v___x_450_ == 0)
{
uint8_t v___x_451_; 
lean_inc_ref(v_p_436_);
v___x_451_ = lp_Hex_Hex_ZPoly_isIrreducible(v_p_436_);
if (v___x_451_ == 0)
{
lean_dec_ref(v_p_436_);
lean_del_object(v___x_431_);
goto v___jp_442_;
}
else
{
if (v___x_437_ == 0)
{
lean_object* v___x_452_; lean_object* v___x_453_; uint8_t v___x_454_; lean_object* v___x_455_; 
lean_del_object(v___x_439_);
v___x_452_ = lp_Hex_Hex_separationDepth(v_p_436_);
v___x_453_ = lean_nat_to_int(v___x_452_);
v___x_454_ = 2;
lean_inc_ref(v_p_436_);
v___x_455_ = lp_Hex_Hex_ZPoly_isolateComplexRoots_x3f___redArg(v_p_436_, v___x_453_, v___x_454_);
if (lean_obj_tag(v___x_455_) == 0)
{
lean_object* v___x_457_; 
lean_dec_ref(v_p_436_);
if (v_isShared_432_ == 0)
{
lean_ctor_set(v___x_431_, 1, v_snd_435_);
lean_ctor_set(v___x_431_, 0, v_seen_441_);
v___x_457_ = v___x_431_;
goto v_reusejp_456_;
}
else
{
lean_object* v_reuseFailAlloc_458_; 
v_reuseFailAlloc_458_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_458_, 0, v_seen_441_);
lean_ctor_set(v_reuseFailAlloc_458_, 1, v_snd_435_);
v___x_457_ = v_reuseFailAlloc_458_;
goto v_reusejp_456_;
}
v_reusejp_456_:
{
v___y_423_ = v___x_457_;
goto v___jp_422_;
}
}
else
{
lean_object* v_val_459_; size_t v_sz_460_; size_t v___x_461_; lean_object* v___x_462_; 
v_val_459_ = lean_ctor_get(v___x_455_, 0);
lean_inc_n(v_val_459_, 2);
lean_dec_ref_known(v___x_455_, 1);
v_sz_460_ = lean_array_size(v_val_459_);
v___x_461_ = ((size_t)0ULL);
v___x_462_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__2(v_p_436_, v_sz_460_, v___x_461_, v_val_459_);
if (lean_obj_tag(v___x_462_) == 0)
{
lean_object* v___x_464_; 
lean_dec(v_val_459_);
lean_dec_ref(v_p_436_);
if (v_isShared_432_ == 0)
{
lean_ctor_set(v___x_431_, 1, v_snd_435_);
lean_ctor_set(v___x_431_, 0, v_seen_441_);
v___x_464_ = v___x_431_;
goto v_reusejp_463_;
}
else
{
lean_object* v_reuseFailAlloc_465_; 
v_reuseFailAlloc_465_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_465_, 0, v_seen_441_);
lean_ctor_set(v_reuseFailAlloc_465_, 1, v_snd_435_);
v___x_464_ = v_reuseFailAlloc_465_;
goto v_reusejp_463_;
}
v_reusejp_463_:
{
v___y_423_ = v___x_464_;
goto v___jp_422_;
}
}
else
{
lean_object* v_val_466_; lean_object* v___x_467_; lean_object* v___x_469_; 
v_val_466_ = lean_ctor_get(v___x_462_, 0);
lean_inc(v_val_466_);
lean_dec_ref_known(v___x_462_, 1);
v___x_467_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicPoly_rootPicker___boxed), 8, 7);
lean_closure_set(v___x_467_, 0, v_p_436_);
lean_closure_set(v___x_467_, 1, lean_box(0));
lean_closure_set(v___x_467_, 2, v_val_459_);
lean_closure_set(v___x_467_, 3, v_val_466_);
lean_closure_set(v___x_467_, 4, lean_box(0));
lean_closure_set(v___x_467_, 5, lean_box(0));
lean_closure_set(v___x_467_, 6, v_snd_435_);
if (v_isShared_432_ == 0)
{
lean_ctor_set(v___x_431_, 1, v___x_467_);
lean_ctor_set(v___x_431_, 0, v_seen_441_);
v___x_469_ = v___x_431_;
goto v_reusejp_468_;
}
else
{
lean_object* v_reuseFailAlloc_470_; 
v_reuseFailAlloc_470_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_470_, 0, v_seen_441_);
lean_ctor_set(v_reuseFailAlloc_470_, 1, v___x_467_);
v___x_469_ = v_reuseFailAlloc_470_;
goto v_reusejp_468_;
}
v_reusejp_468_:
{
v___y_423_ = v___x_469_;
goto v___jp_422_;
}
}
}
}
else
{
lean_dec_ref(v_p_436_);
lean_del_object(v___x_431_);
goto v___jp_442_;
}
}
}
else
{
lean_dec_ref(v_p_436_);
lean_del_object(v___x_431_);
goto v___jp_442_;
}
}
}
}
else
{
lean_dec_ref(v_p_436_);
lean_del_object(v___x_431_);
v___y_423_ = v_b_421_;
goto v___jp_422_;
}
}
}
}
else
{
return v_b_421_;
}
v___jp_422_:
{
size_t v___x_424_; size_t v___x_425_; 
v___x_424_ = ((size_t)1ULL);
v___x_425_ = lean_usize_add(v_i_419_, v___x_424_);
v_i_419_ = v___x_425_;
v_b_421_ = v___y_423_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4___boxed(lean_object* v_roots_487_, lean_object* v_as_488_, lean_object* v_i_489_, lean_object* v_stop_490_, lean_object* v_b_491_){
_start:
{
size_t v_i_boxed_492_; size_t v_stop_boxed_493_; lean_object* v_res_494_; 
v_i_boxed_492_ = lean_unbox_usize(v_i_489_);
lean_dec(v_i_489_);
v_stop_boxed_493_ = lean_unbox_usize(v_stop_490_);
lean_dec(v_stop_490_);
v_res_494_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4(v_roots_487_, v_as_488_, v_i_boxed_492_, v_stop_boxed_493_, v_b_491_);
lean_dec_ref(v_as_488_);
lean_dec_ref(v_roots_487_);
return v_res_494_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootSelectors(lean_object* v_roots_501_){
_start:
{
lean_object* v___x_502_; lean_object* v___x_503_; lean_object* v___x_504_; uint8_t v___x_505_; 
v___x_502_ = lean_unsigned_to_nat(0u);
v___x_503_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___closed__2));
v___x_504_ = lean_array_get_size(v_roots_501_);
v___x_505_ = lean_nat_dec_lt(v___x_502_, v___x_504_);
if (v___x_505_ == 0)
{
return v___x_503_;
}
else
{
uint8_t v___x_506_; 
v___x_506_ = lean_nat_dec_le(v___x_504_, v___x_504_);
if (v___x_506_ == 0)
{
if (v___x_505_ == 0)
{
return v___x_503_;
}
else
{
size_t v___x_507_; size_t v___x_508_; lean_object* v___x_509_; 
v___x_507_ = ((size_t)0ULL);
v___x_508_ = lean_usize_of_nat(v___x_504_);
v___x_509_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4(v_roots_501_, v_roots_501_, v___x_507_, v___x_508_, v___x_503_);
return v___x_509_;
}
}
else
{
size_t v___x_510_; size_t v___x_511_; lean_object* v___x_512_; 
v___x_510_ = ((size_t)0ULL);
v___x_511_ = lean_usize_of_nat(v___x_504_);
v___x_512_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_rootSelectors_spec__4(v_roots_501_, v_roots_501_, v___x_510_, v___x_511_, v___x_503_);
return v___x_512_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_rootSelectors___boxed(lean_object* v_roots_513_){
_start:
{
lean_object* v_res_514_; 
v_res_514_ = lp_Hex_Hex_RealAlgebraicPoly_rootSelectors(v_roots_513_);
lean_dec_ref(v_roots_513_);
return v_res_514_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__3_splitter___redArg(lean_object* v_x_515_, lean_object* v_h__1_516_, lean_object* v_h__2_517_){
_start:
{
if (lean_obj_tag(v_x_515_) == 0)
{
lean_object* v___x_518_; 
lean_dec(v_h__2_517_);
v___x_518_ = lean_apply_1(v_h__1_516_, lean_box(0));
return v___x_518_;
}
else
{
lean_object* v_val_519_; lean_object* v___x_520_; 
lean_dec(v_h__1_516_);
v_val_519_ = lean_ctor_get(v_x_515_, 0);
lean_inc(v_val_519_);
lean_dec_ref_known(v_x_515_, 1);
v___x_520_ = lean_apply_2(v_h__2_517_, v_val_519_, lean_box(0));
return v___x_520_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__3_splitter(lean_object* v_r_521_, lean_object* v_motive_522_, lean_object* v_x_523_, lean_object* v_h__1_524_, lean_object* v_h__2_525_){
_start:
{
if (lean_obj_tag(v_x_523_) == 0)
{
lean_object* v___x_526_; 
lean_dec(v_h__2_525_);
v___x_526_ = lean_apply_1(v_h__1_524_, lean_box(0));
return v___x_526_;
}
else
{
lean_object* v_val_527_; lean_object* v___x_528_; 
lean_dec(v_h__1_524_);
v_val_527_ = lean_ctor_get(v_x_523_, 0);
lean_inc(v_val_527_);
lean_dec_ref_known(v_x_523_, 1);
v___x_528_ = lean_apply_2(v_h__2_525_, v_val_527_, lean_box(0));
return v___x_528_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__3_splitter___boxed(lean_object* v_r_529_, lean_object* v_motive_530_, lean_object* v_x_531_, lean_object* v_h__1_532_, lean_object* v_h__2_533_){
_start:
{
lean_object* v_res_534_; 
v_res_534_ = lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__3_splitter(v_r_529_, v_motive_530_, v_x_531_, v_h__1_532_, v_h__2_533_);
lean_dec_ref(v_r_529_);
return v_res_534_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__1_splitter___redArg(lean_object* v_x_535_, lean_object* v_h__1_536_, lean_object* v_h__2_537_){
_start:
{
if (lean_obj_tag(v_x_535_) == 0)
{
lean_object* v___x_538_; 
lean_dec(v_h__2_537_);
v___x_538_ = lean_apply_1(v_h__1_536_, lean_box(0));
return v___x_538_;
}
else
{
lean_object* v_val_539_; lean_object* v___x_540_; 
lean_dec(v_h__1_536_);
v_val_539_ = lean_ctor_get(v_x_535_, 0);
lean_inc(v_val_539_);
lean_dec_ref_known(v_x_535_, 1);
v___x_540_ = lean_apply_2(v_h__2_537_, v_val_539_, lean_box(0));
return v___x_540_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__1_splitter(lean_object* v_r_541_, lean_object* v_motive_542_, lean_object* v_x_543_, lean_object* v_h__1_544_, lean_object* v_h__2_545_){
_start:
{
if (lean_obj_tag(v_x_543_) == 0)
{
lean_object* v___x_546_; 
lean_dec(v_h__2_545_);
v___x_546_ = lean_apply_1(v_h__1_544_, lean_box(0));
return v___x_546_;
}
else
{
lean_object* v_val_547_; lean_object* v___x_548_; 
lean_dec(v_h__1_544_);
v_val_547_ = lean_ctor_get(v_x_543_, 0);
lean_inc(v_val_547_);
lean_dec_ref_known(v_x_543_, 1);
v___x_548_ = lean_apply_2(v_h__2_545_, v_val_547_, lean_box(0));
return v___x_548_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__1_splitter___boxed(lean_object* v_r_549_, lean_object* v_motive_550_, lean_object* v_x_551_, lean_object* v_h__1_552_, lean_object* v_h__2_553_){
_start:
{
lean_object* v_res_554_; 
v_res_554_ = lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_rootSelectors_match__1_splitter(v_r_549_, v_motive_550_, v_x_551_, v_h__1_552_, v_h__2_553_);
lean_dec_ref(v_r_549_);
return v_res_554_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0_spec__0(lean_object* v___x_555_, lean_object* v_as_556_, size_t v_i_557_, size_t v_stop_558_, lean_object* v_b_559_){
_start:
{
lean_object* v___y_561_; uint8_t v___x_565_; 
v___x_565_ = lean_usize_dec_eq(v_i_557_, v_stop_558_);
if (v___x_565_ == 0)
{
lean_object* v___x_566_; lean_object* v___x_567_; 
v___x_566_ = lean_array_uget_borrowed(v_as_556_, v_i_557_);
lean_inc_ref(v___x_555_);
lean_inc(v___x_566_);
v___x_567_ = lean_apply_1(v___x_555_, v___x_566_);
if (lean_obj_tag(v___x_567_) == 0)
{
v___y_561_ = v_b_559_;
goto v___jp_560_;
}
else
{
lean_object* v_val_568_; lean_object* v___x_569_; 
v_val_568_ = lean_ctor_get(v___x_567_, 0);
lean_inc(v_val_568_);
lean_dec_ref_known(v___x_567_, 1);
v___x_569_ = lean_array_push(v_b_559_, v_val_568_);
v___y_561_ = v___x_569_;
goto v___jp_560_;
}
}
else
{
lean_dec_ref(v___x_555_);
return v_b_559_;
}
v___jp_560_:
{
size_t v___x_562_; size_t v___x_563_; 
v___x_562_ = ((size_t)1ULL);
v___x_563_ = lean_usize_add(v_i_557_, v___x_562_);
v_i_557_ = v___x_563_;
v_b_559_ = v___y_561_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0_spec__0___boxed(lean_object* v___x_570_, lean_object* v_as_571_, lean_object* v_i_572_, lean_object* v_stop_573_, lean_object* v_b_574_){
_start:
{
size_t v_i_boxed_575_; size_t v_stop_boxed_576_; lean_object* v_res_577_; 
v_i_boxed_575_ = lean_unbox_usize(v_i_572_);
lean_dec(v_i_572_);
v_stop_boxed_576_ = lean_unbox_usize(v_stop_573_);
lean_dec(v_stop_573_);
v_res_577_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0_spec__0(v___x_570_, v_as_571_, v_i_boxed_575_, v_stop_boxed_576_, v_b_574_);
lean_dec_ref(v_as_571_);
return v_res_577_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0(lean_object* v___x_578_, lean_object* v_as_579_, lean_object* v_start_580_, lean_object* v_stop_581_){
_start:
{
lean_object* v___x_582_; uint8_t v___x_583_; 
v___x_582_ = ((lean_object*)(lp_Hex_Hex_RealRootSet_toArray___closed__0));
v___x_583_ = lean_nat_dec_lt(v_start_580_, v_stop_581_);
if (v___x_583_ == 0)
{
lean_dec_ref(v___x_578_);
return v___x_582_;
}
else
{
lean_object* v___x_584_; uint8_t v___x_585_; 
v___x_584_ = lean_array_get_size(v_as_579_);
v___x_585_ = lean_nat_dec_le(v_stop_581_, v___x_584_);
if (v___x_585_ == 0)
{
uint8_t v___x_586_; 
v___x_586_ = lean_nat_dec_lt(v_start_580_, v___x_584_);
if (v___x_586_ == 0)
{
lean_dec_ref(v___x_578_);
return v___x_582_;
}
else
{
size_t v___x_587_; size_t v___x_588_; lean_object* v___x_589_; 
v___x_587_ = lean_usize_of_nat(v_start_580_);
v___x_588_ = lean_usize_of_nat(v___x_584_);
v___x_589_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0_spec__0(v___x_578_, v_as_579_, v___x_587_, v___x_588_, v___x_582_);
return v___x_589_;
}
}
else
{
size_t v___x_590_; size_t v___x_591_; lean_object* v___x_592_; 
v___x_590_ = lean_usize_of_nat(v_start_580_);
v___x_591_ = lean_usize_of_nat(v_stop_581_);
v___x_592_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0_spec__0(v___x_578_, v_as_579_, v___x_590_, v___x_591_, v___x_582_);
return v___x_592_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0___boxed(lean_object* v___x_593_, lean_object* v_as_594_, lean_object* v_start_595_, lean_object* v_stop_596_){
_start:
{
lean_object* v_res_597_; 
v_res_597_ = lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0(v___x_593_, v_as_594_, v_start_595_, v_stop_596_);
lean_dec(v_stop_596_);
lean_dec(v_start_595_);
lean_dec_ref(v_as_594_);
return v_res_597_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsCached(lean_object* v_x_598_){
_start:
{
if (lean_obj_tag(v_x_598_) == 0)
{
lean_object* v___x_599_; 
v___x_599_ = lean_box(0);
return v___x_599_;
}
else
{
lean_object* v_roots_600_; lean_object* v___x_602_; uint8_t v_isShared_603_; uint8_t v_isSharedCheck_616_; 
v_roots_600_ = lean_ctor_get(v_x_598_, 0);
v_isSharedCheck_616_ = !lean_is_exclusive(v_x_598_);
if (v_isSharedCheck_616_ == 0)
{
v___x_602_ = v_x_598_;
v_isShared_603_ = v_isSharedCheck_616_;
goto v_resetjp_601_;
}
else
{
lean_inc(v_roots_600_);
lean_dec(v_x_598_);
v___x_602_ = lean_box(0);
v_isShared_603_ = v_isSharedCheck_616_;
goto v_resetjp_601_;
}
v_resetjp_601_:
{
lean_object* v___x_604_; lean_object* v_snd_605_; lean_object* v___f_606_; lean_object* v___x_607_; lean_object* v___x_608_; lean_object* v___x_609_; lean_object* v___x_610_; lean_object* v___x_611_; lean_object* v___x_612_; lean_object* v___x_614_; 
v___x_604_ = lp_Hex_Hex_RealAlgebraicPoly_rootSelectors(v_roots_600_);
v_snd_605_ = lean_ctor_get(v___x_604_, 1);
lean_inc(v_snd_605_);
lean_dec_ref(v___x_604_);
v___f_606_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_realRoots___closed__0));
v___x_607_ = lean_unsigned_to_nat(0u);
v___x_608_ = lean_array_get_size(v_roots_600_);
v___x_609_ = lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsCached_spec__0(v_snd_605_, v_roots_600_, v___x_607_, v___x_608_);
lean_dec_ref(v_roots_600_);
v___x_610_ = lean_array_to_list(v___x_609_);
v___x_611_ = l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(v___x_610_, v___f_606_);
v___x_612_ = lean_array_mk(v___x_611_);
if (v_isShared_603_ == 0)
{
lean_ctor_set(v___x_602_, 0, v___x_612_);
v___x_614_ = v___x_602_;
goto v_reusejp_613_;
}
else
{
lean_object* v_reuseFailAlloc_615_; 
v_reuseFailAlloc_615_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_615_, 0, v___x_612_);
v___x_614_ = v_reuseFailAlloc_615_;
goto v_reusejp_613_;
}
v_reusejp_613_:
{
return v___x_614_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter___redArg(lean_object* v_x_617_, lean_object* v_h__1_618_, lean_object* v_h__2_619_){
_start:
{
if (lean_obj_tag(v_x_617_) == 0)
{
lean_object* v___x_620_; lean_object* v___x_621_; 
lean_dec(v_h__2_619_);
v___x_620_ = lean_box(0);
v___x_621_ = lean_apply_1(v_h__1_618_, v___x_620_);
return v___x_621_;
}
else
{
lean_object* v_roots_622_; lean_object* v___x_623_; 
lean_dec(v_h__1_618_);
v_roots_622_ = lean_ctor_get(v_x_617_, 0);
lean_inc_ref(v_roots_622_);
lean_dec_ref_known(v_x_617_, 1);
v___x_623_ = lean_apply_1(v_h__2_619_, v_roots_622_);
return v___x_623_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter(lean_object* v_motive_624_, lean_object* v_x_625_, lean_object* v_h__1_626_, lean_object* v_h__2_627_){
_start:
{
if (lean_obj_tag(v_x_625_) == 0)
{
lean_object* v___x_628_; lean_object* v___x_629_; 
lean_dec(v_h__2_627_);
v___x_628_ = lean_box(0);
v___x_629_ = lean_apply_1(v_h__1_626_, v___x_628_);
return v___x_629_;
}
else
{
lean_object* v_roots_630_; lean_object* v___x_631_; 
lean_dec(v_h__1_626_);
v_roots_630_ = lean_ctor_get(v_x_625_, 0);
lean_inc_ref(v_roots_630_);
lean_dec_ref_known(v_x_625_, 1);
v___x_631_ = lean_apply_1(v_h__2_627_, v_roots_630_);
return v___x_631_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_roots(lean_object* v_f_632_){
_start:
{
lean_object* v___x_633_; lean_object* v___x_634_; 
v___x_633_ = lp_Hex_Hex_AlgebraicPoly_roots(v_f_632_);
v___x_634_ = lp_Hex_Hex_RealAlgebraicPoly_realRootsCached(v___x_633_);
return v___x_634_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(lean_object* v_as_635_, size_t v_i_636_, size_t v_stop_637_, lean_object* v_b_638_){
_start:
{
lean_object* v___y_640_; uint8_t v___x_644_; 
v___x_644_ = lean_usize_dec_eq(v_i_636_, v_stop_637_);
if (v___x_644_ == 0)
{
lean_object* v___x_645_; lean_object* v___x_646_; 
v___x_645_ = lean_array_uget_borrowed(v_as_635_, v_i_636_);
lean_inc(v___x_645_);
v___x_646_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___x_645_);
if (lean_obj_tag(v___x_646_) == 0)
{
v___y_640_ = v_b_638_;
goto v___jp_639_;
}
else
{
lean_object* v_val_647_; lean_object* v___x_648_; 
v_val_647_ = lean_ctor_get(v___x_646_, 0);
lean_inc(v_val_647_);
lean_dec_ref_known(v___x_646_, 1);
v___x_648_ = lean_array_push(v_b_638_, v_val_647_);
v___y_640_ = v___x_648_;
goto v___jp_639_;
}
}
else
{
return v_b_638_;
}
v___jp_639_:
{
size_t v___x_641_; size_t v___x_642_; 
v___x_641_ = ((size_t)1ULL);
v___x_642_ = lean_usize_add(v_i_636_, v___x_641_);
v_i_636_ = v___x_642_;
v_b_638_ = v___y_640_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0___boxed(lean_object* v_as_649_, lean_object* v_i_650_, lean_object* v_stop_651_, lean_object* v_b_652_){
_start:
{
size_t v_i_boxed_653_; size_t v_stop_boxed_654_; lean_object* v_res_655_; 
v_i_boxed_653_ = lean_unbox_usize(v_i_650_);
lean_dec(v_i_650_);
v_stop_boxed_654_ = lean_unbox_usize(v_stop_651_);
lean_dec(v_stop_651_);
v_res_655_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(v_as_649_, v_i_boxed_653_, v_stop_boxed_654_, v_b_652_);
lean_dec_ref(v_as_649_);
return v_res_655_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(lean_object* v_as_658_, lean_object* v_start_659_, lean_object* v_stop_660_){
_start:
{
lean_object* v___x_661_; uint8_t v___x_662_; 
v___x_661_ = ((lean_object*)(lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0));
v___x_662_ = lean_nat_dec_lt(v_start_659_, v_stop_660_);
if (v___x_662_ == 0)
{
return v___x_661_;
}
else
{
lean_object* v___x_663_; uint8_t v___x_664_; 
v___x_663_ = lean_array_get_size(v_as_658_);
v___x_664_ = lean_nat_dec_le(v_stop_660_, v___x_663_);
if (v___x_664_ == 0)
{
uint8_t v___x_665_; 
v___x_665_ = lean_nat_dec_lt(v_start_659_, v___x_663_);
if (v___x_665_ == 0)
{
return v___x_661_;
}
else
{
size_t v___x_666_; size_t v___x_667_; lean_object* v___x_668_; 
v___x_666_ = lean_usize_of_nat(v_start_659_);
v___x_667_ = lean_usize_of_nat(v___x_663_);
v___x_668_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(v_as_658_, v___x_666_, v___x_667_, v___x_661_);
return v___x_668_;
}
}
else
{
size_t v___x_669_; size_t v___x_670_; lean_object* v___x_671_; 
v___x_669_ = lean_usize_of_nat(v_start_659_);
v___x_670_ = lean_usize_of_nat(v_stop_660_);
v___x_671_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(v_as_658_, v___x_669_, v___x_670_, v___x_661_);
return v___x_671_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___boxed(lean_object* v_as_672_, lean_object* v_start_673_, lean_object* v_stop_674_){
_start:
{
lean_object* v_res_675_; 
v_res_675_ = lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(v_as_672_, v_start_673_, v_stop_674_);
lean_dec(v_stop_674_);
lean_dec(v_start_673_);
lean_dec_ref(v_as_672_);
return v_res_675_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_realAlgebraicRoots(lean_object* v_p_676_){
_start:
{
lean_object* v___f_677_; lean_object* v___x_678_; lean_object* v___x_679_; lean_object* v___x_680_; lean_object* v___x_681_; lean_object* v___x_682_; lean_object* v___x_683_; lean_object* v___x_684_; 
v___f_677_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE___boxed), 2, 0);
v___x_678_ = lp_Hex_Hex_ZPoly_algebraicRoots(v_p_676_);
v___x_679_ = lean_unsigned_to_nat(0u);
v___x_680_ = lean_array_get_size(v___x_678_);
v___x_681_ = lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(v___x_678_, v___x_679_, v___x_680_);
lean_dec_ref(v___x_678_);
v___x_682_ = lean_array_to_list(v___x_681_);
v___x_683_ = l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(v___x_682_, v___f_677_);
v___x_684_ = lean_array_mk(v___x_683_);
return v___x_684_;
}
}
static lean_object* _init_lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0(void){
_start:
{
uint8_t v___x_685_; lean_object* v___x_686_; 
v___x_685_ = 0;
v___x_686_ = l_Ordering_ctorIdx(v___x_685_);
return v___x_686_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(lean_object* v_a_687_){
_start:
{
lean_object* v___x_688_; uint8_t v___x_689_; lean_object* v___x_690_; lean_object* v___x_691_; uint8_t v___x_692_; 
v___x_688_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
lean_inc_ref(v_a_687_);
v___x_689_ = lp_Hex_Hex_AlgebraicNumber_realCompare(v_a_687_, v___x_688_);
v___x_690_ = l_Ordering_ctorIdx(v___x_689_);
v___x_691_ = lean_obj_once(&lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0, &lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0_once, _init_lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0);
v___x_692_ = lean_nat_dec_eq(v___x_690_, v___x_691_);
lean_dec(v___x_690_);
if (v___x_692_ == 0)
{
lean_object* v___x_693_; lean_object* v___x_694_; 
v___x_693_ = lp_Hex_Hex_AlgebraicNumber_sqrt(v_a_687_);
v___x_694_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___x_693_);
return v___x_694_;
}
else
{
lean_object* v___x_695_; 
lean_dec_ref(v_a_687_);
v___x_695_ = lean_box(0);
return v___x_695_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt_x3f(lean_object* v_a_696_){
_start:
{
lean_object* v___x_697_; 
v___x_697_ = lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(v_a_696_);
return v___x_697_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg(lean_object* v_a_699_){
_start:
{
lean_object* v___x_700_; 
v___x_700_ = lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(v_a_699_);
if (lean_obj_tag(v___x_700_) == 0)
{
lean_object* v___x_701_; lean_object* v___x_702_; lean_object* v___x_703_; 
v___x_701_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
v___x_702_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0));
v___x_703_ = lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_box(0), v___x_701_, v___x_702_);
return v___x_703_;
}
else
{
lean_object* v_val_704_; 
v_val_704_ = lean_ctor_get(v___x_700_, 0);
lean_inc(v_val_704_);
lean_dec_ref_known(v___x_700_, 1);
return v_val_704_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt(lean_object* v_a_705_, lean_object* v___h_706_){
_start:
{
lean_object* v___x_707_; 
v___x_707_ = lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg(v_a_705_);
return v___x_707_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexRealAlgebraic_Order(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexNumberField_Radical(uint8_t builtin);
void lean_initialize();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexRealAlgebraic_Roots(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealAlgebraic_Order(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexNumberField_Radical(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexRealAlgebraic_Roots(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexRealAlgebraic_Order(uint8_t builtin);
lean_object* initialize_Hex_HexNumberField_Radical(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexRealAlgebraic_Roots(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexRealAlgebraic_Order(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexNumberField_Radical(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealAlgebraic_Roots(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexRealAlgebraic_Roots(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexRealAlgebraic_Roots(builtin);
}
#ifdef __cplusplus
}
#endif
