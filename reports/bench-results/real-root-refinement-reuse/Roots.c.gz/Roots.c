// Lean compiler output
// Module: HexRealAlgebraic.Roots
// Imports: public import Init public meta import Init public import HexRealAlgebraic.Order public import HexNumberField.Radical
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_Hex_Hex_RealAlgebraicNumber_ofRoot_x3f(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
uint8_t lp_Hex_Hex_AlgebraicNumber_isReal(lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lp_Hex_Hex_mahlerPrec(lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lp_Hex_Hex_RefinedIsolation_refineTo_x3f(lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* l_Option_unattach___redArg(lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
size_t lean_usize_sub(size_t, size_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_AlgebraicRoot_isReal(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_AlgebraicPoly_roots(lean_object*);
lean_object* lp_Hex_Hex_ZPoly_factorize(lean_object*);
extern lean_object* lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
lean_object* lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_AlgebraicRoot_exactFactor_x3f(lean_object*, lean_object*);
lean_object* lean_nat_abs(lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* lp_Hex_Hex_separationDepth(lean_object*);
lean_object* lp_Hex_Hex_ZPoly_isolateComplexRoots_x3f___redArg(lean_object*, lean_object*, uint8_t);
size_t lean_array_size(lean_object*);
lean_object* lp_Hex_Hex_DyadicRootIsolation_toRefined_x3f(lean_object*, lean_object*);
uint8_t lean_int_dec_le(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_DyadicSquare_discsMeet(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_AlgebraicNumber_ofNormalizedIn_x3f___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE(lean_object*, lean_object*);
lean_object* l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(lean_object*, lean_object*);
lean_object* lean_array_mk(lean_object*);
uint8_t lp_Hex_Hex_AlgebraicNumber_realCompare(lean_object*, lean_object*);
lean_object* l_Ordering_ctorIdx(uint8_t);
lean_object* lp_Hex_Hex_AlgebraicNumber_sqrt(lean_object*);
uint8_t lp_Hex_Hex_AlgebraicNumber_beq(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE___boxed(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_ZPoly_algebraicRoots(lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lp_Hex_Hex_AlgebraicPoly_ofArray(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofArray(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofAlgebraic_x3f(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_x3f(lean_object*);
static const lean_array_object lp_Hex_Hex_RealRootSet_toArray___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_RealRootSet_toArray___closed__0 = (const lean_object*)&lp_Hex_Hex_RealRootSet_toArray___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_toArray(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_RealRootSet_contains(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_contains___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0___boxed(lean_object*, lean_object*);
static const lean_string_object lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 42, .m_capacity = 42, .m_length = 41, .m_data = "AlgebraicRoot.exact: certification failed"};
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_RealAlgebraicPoly_Internal_parentExact_x3f_spec__0(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_find_x3f___at___00Hex_RealAlgebraicPoly_Internal_parentExact_x3f_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_find_x3f___at___00Hex_RealAlgebraicPoly_Internal_parentExact_x3f_spec__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_parentExact_x3f___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_parentExact_x3f(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_parentExact_x3f___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_ZPoly_isIrreducible_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_ZPoly_isIrreducible_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1(lean_object*, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4(uint8_t, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__2(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3_spec__4(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5_spec__7(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__0_value;
static const lean_closure_object lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__1 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__0_value),((lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__1_value)}};
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__2 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__2_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__7_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__7_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__7_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__5_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__5_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__5_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_roots(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0 = (const lean_object*)&lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_realAlgebraicRoots(lean_object*);
static lean_once_cell_t lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt_x3f(lean_object*);
static const lean_string_object lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 53, .m_capacity = 53, .m_length = 52, .m_data = "RealAlgebraicNumber.sqrt: nonnegative root not found"};
static const lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic(lean_object* v_f_1_){
_start:
{
lean_inc_ref(v_f_1_);
return v_f_1_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic___boxed(lean_object* v_f_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = lp_Hex_Hex_RealAlgebraicPoly_toAlgebraic(v_f_2_);
lean_dec_ref(v_f_2_);
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(size_t v_sz_4_, size_t v_i_5_, lean_object* v_bs_6_){
_start:
{
uint8_t v___x_7_; 
v___x_7_ = lean_usize_dec_lt(v_i_5_, v_sz_4_);
if (v___x_7_ == 0)
{
return v_bs_6_;
}
else
{
lean_object* v_v_8_; lean_object* v___x_9_; lean_object* v_bs_x27_10_; size_t v___x_11_; size_t v___x_12_; lean_object* v___x_13_; 
v_v_8_ = lean_array_uget(v_bs_6_, v_i_5_);
v___x_9_ = lean_unsigned_to_nat(0u);
v_bs_x27_10_ = lean_array_uset(v_bs_6_, v_i_5_, v___x_9_);
v___x_11_ = ((size_t)1ULL);
v___x_12_ = lean_usize_add(v_i_5_, v___x_11_);
v___x_13_ = lean_array_uset(v_bs_x27_10_, v_i_5_, v_v_8_);
v_i_5_ = v___x_12_;
v_bs_6_ = v___x_13_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0___boxed(lean_object* v_sz_15_, lean_object* v_i_16_, lean_object* v_bs_17_){
_start:
{
size_t v_sz_boxed_18_; size_t v_i_boxed_19_; lean_object* v_res_20_; 
v_sz_boxed_18_ = lean_unbox_usize(v_sz_15_);
lean_dec(v_sz_15_);
v_i_boxed_19_ = lean_unbox_usize(v_i_16_);
lean_dec(v_i_16_);
v_res_20_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(v_sz_boxed_18_, v_i_boxed_19_, v_bs_17_);
return v_res_20_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofArray(lean_object* v_coeffs_21_){
_start:
{
size_t v_sz_22_; size_t v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; 
v_sz_22_ = lean_array_size(v_coeffs_21_);
v___x_23_ = ((size_t)0ULL);
v___x_24_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_ofArray_spec__0(v_sz_22_, v___x_23_, v_coeffs_21_);
v___x_25_ = lp_Hex_Hex_AlgebraicPoly_ofArray(v___x_24_);
return v___x_25_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(lean_object* v_as_26_, size_t v_i_27_, size_t v_stop_28_){
_start:
{
uint8_t v___x_29_; 
v___x_29_ = lean_usize_dec_eq(v_i_27_, v_stop_28_);
if (v___x_29_ == 0)
{
lean_object* v___x_30_; uint8_t v___x_31_; 
v___x_30_ = lean_array_uget_borrowed(v_as_26_, v_i_27_);
v___x_31_ = lp_Hex_Hex_AlgebraicNumber_isReal(v___x_30_);
if (v___x_31_ == 0)
{
uint8_t v___x_32_; 
v___x_32_ = 1;
return v___x_32_;
}
else
{
size_t v___x_33_; size_t v___x_34_; 
v___x_33_ = ((size_t)1ULL);
v___x_34_ = lean_usize_add(v_i_27_, v___x_33_);
v_i_27_ = v___x_34_;
goto _start;
}
}
else
{
uint8_t v___x_36_; 
v___x_36_ = 0;
return v___x_36_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0___boxed(lean_object* v_as_37_, lean_object* v_i_38_, lean_object* v_stop_39_){
_start:
{
size_t v_i_boxed_40_; size_t v_stop_boxed_41_; uint8_t v_res_42_; lean_object* v_r_43_; 
v_i_boxed_40_ = lean_unbox_usize(v_i_38_);
lean_dec(v_i_38_);
v_stop_boxed_41_ = lean_unbox_usize(v_stop_39_);
lean_dec(v_stop_39_);
v_res_42_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(v_as_37_, v_i_boxed_40_, v_stop_boxed_41_);
lean_dec_ref(v_as_37_);
v_r_43_ = lean_box(v_res_42_);
return v_r_43_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_ofAlgebraic_x3f(lean_object* v_f_44_){
_start:
{
lean_object* v___x_45_; lean_object* v___x_46_; uint8_t v___x_47_; 
v___x_45_ = lean_unsigned_to_nat(0u);
v___x_46_ = lean_array_get_size(v_f_44_);
v___x_47_ = lean_nat_dec_lt(v___x_45_, v___x_46_);
if (v___x_47_ == 0)
{
lean_object* v___x_48_; 
v___x_48_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_48_, 0, v_f_44_);
return v___x_48_;
}
else
{
if (v___x_47_ == 0)
{
lean_object* v___x_49_; 
v___x_49_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_49_, 0, v_f_44_);
return v___x_49_;
}
else
{
size_t v___x_50_; size_t v___x_51_; uint8_t v___x_52_; 
v___x_50_ = ((size_t)0ULL);
v___x_51_ = lean_usize_of_nat(v___x_46_);
v___x_52_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_ofAlgebraic_x3f_spec__0(v_f_44_, v___x_50_, v___x_51_);
if (v___x_52_ == 0)
{
lean_object* v___x_53_; 
v___x_53_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_53_, 0, v_f_44_);
return v___x_53_;
}
else
{
lean_object* v___x_54_; 
lean_dec_ref(v_f_44_);
v___x_54_ = lean_box(0);
return v___x_54_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx(lean_object* v_x_55_){
_start:
{
if (lean_obj_tag(v_x_55_) == 0)
{
lean_object* v___x_56_; 
v___x_56_ = lean_unsigned_to_nat(0u);
return v___x_56_;
}
else
{
lean_object* v___x_57_; 
v___x_57_ = lean_unsigned_to_nat(1u);
return v___x_57_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorIdx___boxed(lean_object* v_x_58_){
_start:
{
lean_object* v_res_59_; 
v_res_59_ = lp_Hex_Hex_RealRootSet_ctorIdx(v_x_58_);
lean_dec(v_x_58_);
return v_res_59_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___redArg(lean_object* v_t_60_, lean_object* v_k_61_){
_start:
{
if (lean_obj_tag(v_t_60_) == 0)
{
return v_k_61_;
}
else
{
lean_object* v_roots_62_; lean_object* v___x_63_; 
v_roots_62_ = lean_ctor_get(v_t_60_, 0);
lean_inc_ref(v_roots_62_);
lean_dec_ref_known(v_t_60_, 1);
v___x_63_ = lean_apply_1(v_k_61_, v_roots_62_);
return v___x_63_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim(lean_object* v_motive_64_, lean_object* v_ctorIdx_65_, lean_object* v_t_66_, lean_object* v_h_67_, lean_object* v_k_68_){
_start:
{
lean_object* v___x_69_; 
v___x_69_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_66_, v_k_68_);
return v___x_69_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_ctorElim___boxed(lean_object* v_motive_70_, lean_object* v_ctorIdx_71_, lean_object* v_t_72_, lean_object* v_h_73_, lean_object* v_k_74_){
_start:
{
lean_object* v_res_75_; 
v_res_75_ = lp_Hex_Hex_RealRootSet_ctorElim(v_motive_70_, v_ctorIdx_71_, v_t_72_, v_h_73_, v_k_74_);
lean_dec(v_ctorIdx_71_);
return v_res_75_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim___redArg(lean_object* v_t_76_, lean_object* v_all_77_){
_start:
{
lean_object* v___x_78_; 
v___x_78_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_76_, v_all_77_);
return v___x_78_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_all_elim(lean_object* v_motive_79_, lean_object* v_t_80_, lean_object* v_h_81_, lean_object* v_all_82_){
_start:
{
lean_object* v___x_83_; 
v___x_83_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_80_, v_all_82_);
return v___x_83_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim___redArg(lean_object* v_t_84_, lean_object* v_finite_85_){
_start:
{
lean_object* v___x_86_; 
v___x_86_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_84_, v_finite_85_);
return v___x_86_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_elim(lean_object* v_motive_87_, lean_object* v_t_88_, lean_object* v_h_89_, lean_object* v_finite_90_){
_start:
{
lean_object* v___x_91_; 
v___x_91_ = lp_Hex_Hex_RealRootSet_ctorElim___redArg(v_t_88_, v_finite_90_);
return v___x_91_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_finite_x3f(lean_object* v_x_92_){
_start:
{
if (lean_obj_tag(v_x_92_) == 0)
{
lean_object* v___x_93_; 
v___x_93_ = lean_box(0);
return v___x_93_;
}
else
{
lean_object* v_roots_94_; lean_object* v___x_96_; uint8_t v_isShared_97_; uint8_t v_isSharedCheck_101_; 
v_roots_94_ = lean_ctor_get(v_x_92_, 0);
v_isSharedCheck_101_ = !lean_is_exclusive(v_x_92_);
if (v_isSharedCheck_101_ == 0)
{
v___x_96_ = v_x_92_;
v_isShared_97_ = v_isSharedCheck_101_;
goto v_resetjp_95_;
}
else
{
lean_inc(v_roots_94_);
lean_dec(v_x_92_);
v___x_96_ = lean_box(0);
v_isShared_97_ = v_isSharedCheck_101_;
goto v_resetjp_95_;
}
v_resetjp_95_:
{
lean_object* v___x_99_; 
if (v_isShared_97_ == 0)
{
v___x_99_ = v___x_96_;
goto v_reusejp_98_;
}
else
{
lean_object* v_reuseFailAlloc_100_; 
v_reuseFailAlloc_100_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_100_, 0, v_roots_94_);
v___x_99_ = v_reuseFailAlloc_100_;
goto v_reusejp_98_;
}
v_reusejp_98_:
{
return v___x_99_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_toArray(lean_object* v_roots_104_){
_start:
{
lean_object* v___x_105_; 
v___x_105_ = lp_Hex_Hex_RealRootSet_finite_x3f(v_roots_104_);
if (lean_obj_tag(v___x_105_) == 0)
{
lean_object* v___x_106_; 
v___x_106_ = ((lean_object*)(lp_Hex_Hex_RealRootSet_toArray___closed__0));
return v___x_106_;
}
else
{
lean_object* v_val_107_; 
v_val_107_ = lean_ctor_get(v___x_105_, 0);
lean_inc(v_val_107_);
lean_dec_ref_known(v___x_105_, 1);
return v_val_107_;
}
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(lean_object* v_a_108_, lean_object* v_as_109_, size_t v_i_110_, size_t v_stop_111_){
_start:
{
uint8_t v___x_112_; 
v___x_112_ = lean_usize_dec_eq(v_i_110_, v_stop_111_);
if (v___x_112_ == 0)
{
lean_object* v___x_113_; lean_object* v_root_114_; uint8_t v___x_115_; 
v___x_113_ = lean_array_uget_borrowed(v_as_109_, v_i_110_);
v_root_114_ = lean_ctor_get(v___x_113_, 0);
lean_inc_ref(v_a_108_);
lean_inc_ref(v_root_114_);
v___x_115_ = lp_Hex_Hex_AlgebraicNumber_beq(v_root_114_, v_a_108_);
if (v___x_115_ == 0)
{
size_t v___x_116_; size_t v___x_117_; 
v___x_116_ = ((size_t)1ULL);
v___x_117_ = lean_usize_add(v_i_110_, v___x_116_);
v_i_110_ = v___x_117_;
goto _start;
}
else
{
lean_dec_ref(v_a_108_);
return v___x_115_;
}
}
else
{
uint8_t v___x_119_; 
lean_dec_ref(v_a_108_);
v___x_119_ = 0;
return v___x_119_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0___boxed(lean_object* v_a_120_, lean_object* v_as_121_, lean_object* v_i_122_, lean_object* v_stop_123_){
_start:
{
size_t v_i_boxed_124_; size_t v_stop_boxed_125_; uint8_t v_res_126_; lean_object* v_r_127_; 
v_i_boxed_124_ = lean_unbox_usize(v_i_122_);
lean_dec(v_i_122_);
v_stop_boxed_125_ = lean_unbox_usize(v_stop_123_);
lean_dec(v_stop_123_);
v_res_126_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(v_a_120_, v_as_121_, v_i_boxed_124_, v_stop_boxed_125_);
lean_dec_ref(v_as_121_);
v_r_127_ = lean_box(v_res_126_);
return v_r_127_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_RealRootSet_contains(lean_object* v_roots_128_, lean_object* v_a_129_){
_start:
{
if (lean_obj_tag(v_roots_128_) == 0)
{
uint8_t v___x_130_; 
lean_dec_ref(v_a_129_);
v___x_130_ = 1;
return v___x_130_;
}
else
{
lean_object* v_roots_131_; lean_object* v___x_132_; lean_object* v___x_133_; uint8_t v___x_134_; 
v_roots_131_ = lean_ctor_get(v_roots_128_, 0);
v___x_132_ = lean_unsigned_to_nat(0u);
v___x_133_ = lean_array_get_size(v_roots_131_);
v___x_134_ = lean_nat_dec_lt(v___x_132_, v___x_133_);
if (v___x_134_ == 0)
{
lean_dec_ref(v_a_129_);
return v___x_134_;
}
else
{
if (v___x_134_ == 0)
{
lean_dec_ref(v_a_129_);
return v___x_134_;
}
else
{
size_t v___x_135_; size_t v___x_136_; uint8_t v___x_137_; 
v___x_135_ = ((size_t)0ULL);
v___x_136_ = lean_usize_of_nat(v___x_133_);
v___x_137_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealRootSet_contains_spec__0(v_a_129_, v_roots_131_, v___x_135_, v___x_136_);
return v___x_137_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealRootSet_contains___boxed(lean_object* v_roots_138_, lean_object* v_a_139_){
_start:
{
uint8_t v_res_140_; lean_object* v_r_141_; 
v_res_140_ = lp_Hex_Hex_RealRootSet_contains(v_roots_138_, v_a_139_);
lean_dec(v_roots_138_);
v_r_141_ = lean_box(v_res_140_);
return v_r_141_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRoot_x3f(lean_object* v_r_142_){
_start:
{
lean_object* v_root_143_; lean_object* v_multiplicity_144_; lean_object* v___x_146_; uint8_t v_isShared_147_; uint8_t v_isSharedCheck_161_; 
v_root_143_ = lean_ctor_get(v_r_142_, 0);
v_multiplicity_144_ = lean_ctor_get(v_r_142_, 1);
v_isSharedCheck_161_ = !lean_is_exclusive(v_r_142_);
if (v_isSharedCheck_161_ == 0)
{
v___x_146_ = v_r_142_;
v_isShared_147_ = v_isSharedCheck_161_;
goto v_resetjp_145_;
}
else
{
lean_inc(v_multiplicity_144_);
lean_inc(v_root_143_);
lean_dec(v_r_142_);
v___x_146_ = lean_box(0);
v_isShared_147_ = v_isSharedCheck_161_;
goto v_resetjp_145_;
}
v_resetjp_145_:
{
lean_object* v___x_148_; 
v___x_148_ = lp_Hex_Hex_RealAlgebraicNumber_ofRoot_x3f(v_root_143_);
if (lean_obj_tag(v___x_148_) == 0)
{
lean_object* v___x_149_; 
lean_del_object(v___x_146_);
lean_dec(v_multiplicity_144_);
v___x_149_ = lean_box(0);
return v___x_149_;
}
else
{
lean_object* v_val_150_; lean_object* v___x_152_; uint8_t v_isShared_153_; uint8_t v_isSharedCheck_160_; 
v_val_150_ = lean_ctor_get(v___x_148_, 0);
v_isSharedCheck_160_ = !lean_is_exclusive(v___x_148_);
if (v_isSharedCheck_160_ == 0)
{
v___x_152_ = v___x_148_;
v_isShared_153_ = v_isSharedCheck_160_;
goto v_resetjp_151_;
}
else
{
lean_inc(v_val_150_);
lean_dec(v___x_148_);
v___x_152_ = lean_box(0);
v_isShared_153_ = v_isSharedCheck_160_;
goto v_resetjp_151_;
}
v_resetjp_151_:
{
lean_object* v___x_155_; 
if (v_isShared_147_ == 0)
{
lean_ctor_set(v___x_146_, 0, v_val_150_);
v___x_155_ = v___x_146_;
goto v_reusejp_154_;
}
else
{
lean_object* v_reuseFailAlloc_159_; 
v_reuseFailAlloc_159_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_159_, 0, v_val_150_);
lean_ctor_set(v_reuseFailAlloc_159_, 1, v_multiplicity_144_);
v___x_155_ = v_reuseFailAlloc_159_;
goto v_reusejp_154_;
}
v_reusejp_154_:
{
lean_object* v___x_157_; 
if (v_isShared_153_ == 0)
{
lean_ctor_set(v___x_152_, 0, v___x_155_);
v___x_157_ = v___x_152_;
goto v_reusejp_156_;
}
else
{
lean_object* v_reuseFailAlloc_158_; 
v_reuseFailAlloc_158_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_158_, 0, v___x_155_);
v___x_157_ = v_reuseFailAlloc_158_;
goto v_reusejp_156_;
}
v_reusejp_156_:
{
return v___x_157_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(lean_object* v___x_162_, lean_object* v_as_163_, size_t v_i_164_, size_t v_stop_165_, lean_object* v_b_166_){
_start:
{
lean_object* v___y_168_; uint8_t v___x_172_; 
v___x_172_ = lean_usize_dec_eq(v_i_164_, v_stop_165_);
if (v___x_172_ == 0)
{
if (lean_obj_tag(v_b_166_) == 0)
{
lean_object* v___x_173_; lean_object* v_fst_174_; lean_object* v___x_175_; 
v___x_173_ = lean_array_uget_borrowed(v_as_163_, v_i_164_);
v_fst_174_ = lean_ctor_get(v___x_173_, 0);
lean_inc(v_fst_174_);
v___x_175_ = lp_Hex_Hex_AlgebraicRoot_exactFactor_x3f(v___x_162_, v_fst_174_);
v___y_168_ = v___x_175_;
goto v___jp_167_;
}
else
{
v___y_168_ = v_b_166_;
goto v___jp_167_;
}
}
else
{
return v_b_166_;
}
v___jp_167_:
{
size_t v___x_169_; size_t v___x_170_; 
v___x_169_ = ((size_t)1ULL);
v___x_170_ = lean_usize_add(v_i_164_, v___x_169_);
v_i_164_ = v___x_170_;
v_b_166_ = v___y_168_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1___boxed(lean_object* v___x_176_, lean_object* v_as_177_, lean_object* v_i_178_, lean_object* v_stop_179_, lean_object* v_b_180_){
_start:
{
size_t v_i_boxed_181_; size_t v_stop_boxed_182_; lean_object* v_res_183_; 
v_i_boxed_181_ = lean_unbox_usize(v_i_178_);
lean_dec(v_i_178_);
v_stop_boxed_182_ = lean_unbox_usize(v_stop_179_);
lean_dec(v_stop_179_);
v_res_183_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(v___x_176_, v_as_177_, v_i_boxed_181_, v_stop_boxed_182_, v_b_180_);
lean_dec_ref(v_as_177_);
lean_dec_ref(v___x_176_);
return v_res_183_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(lean_object* v_xs_184_, lean_object* v_ys_185_, lean_object* v_x_186_){
_start:
{
lean_object* v_zero_187_; uint8_t v_isZero_188_; 
v_zero_187_ = lean_unsigned_to_nat(0u);
v_isZero_188_ = lean_nat_dec_eq(v_x_186_, v_zero_187_);
if (v_isZero_188_ == 1)
{
lean_dec(v_x_186_);
return v_isZero_188_;
}
else
{
lean_object* v_one_189_; lean_object* v_n_190_; lean_object* v___x_191_; lean_object* v___x_192_; uint8_t v___x_193_; 
v_one_189_ = lean_unsigned_to_nat(1u);
v_n_190_ = lean_nat_sub(v_x_186_, v_one_189_);
lean_dec(v_x_186_);
v___x_191_ = lean_array_fget_borrowed(v_xs_184_, v_n_190_);
v___x_192_ = lean_array_fget_borrowed(v_ys_185_, v_n_190_);
v___x_193_ = lean_int_dec_eq(v___x_191_, v___x_192_);
if (v___x_193_ == 0)
{
lean_dec(v_n_190_);
return v___x_193_;
}
else
{
v_x_186_ = v_n_190_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg___boxed(lean_object* v_xs_195_, lean_object* v_ys_196_, lean_object* v_x_197_){
_start:
{
uint8_t v_res_198_; lean_object* v_r_199_; 
v_res_198_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(v_xs_195_, v_ys_196_, v_x_197_);
lean_dec_ref(v_ys_196_);
lean_dec_ref(v_xs_195_);
v_r_199_ = lean_box(v_res_198_);
return v_r_199_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(lean_object* v_xs_200_, lean_object* v_ys_201_){
_start:
{
lean_object* v___x_202_; lean_object* v___x_203_; uint8_t v___x_204_; 
v___x_202_ = lean_array_get_size(v_xs_200_);
v___x_203_ = lean_array_get_size(v_ys_201_);
v___x_204_ = lean_nat_dec_eq(v___x_202_, v___x_203_);
if (v___x_204_ == 0)
{
return v___x_204_;
}
else
{
uint8_t v___x_205_; 
v___x_205_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(v_xs_200_, v_ys_201_, v___x_202_);
return v___x_205_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0___boxed(lean_object* v_xs_206_, lean_object* v_ys_207_){
_start:
{
uint8_t v_res_208_; lean_object* v_r_209_; 
v_res_208_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_xs_206_, v_ys_207_);
lean_dec_ref(v_ys_207_);
lean_dec_ref(v_xs_206_);
v_r_209_ = lean_box(v_res_208_);
return v_r_209_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0(lean_object* v_a_210_, lean_object* v_b_211_){
_start:
{
uint8_t v_decide_212_; 
v_decide_212_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_a_210_, v_b_211_);
return v_decide_212_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0___boxed(lean_object* v_a_213_, lean_object* v_b_214_){
_start:
{
uint8_t v_res_215_; lean_object* v_r_216_; 
v_res_215_ = lp_Hex___private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0(v_a_213_, v_b_214_);
lean_dec_ref(v_b_214_);
lean_dec_ref(v_a_213_);
v_r_216_ = lean_box(v_res_215_);
return v_r_216_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg(lean_object* v_p_218_, lean_object* v_factors_219_, lean_object* v_fallback_220_, lean_object* v_r_221_){
_start:
{
lean_object* v_root_222_; lean_object* v_multiplicity_223_; lean_object* v___y_225_; lean_object* v___y_242_; lean_object* v_p_244_; uint8_t v_decide_245_; 
v_root_222_ = lean_ctor_get(v_r_221_, 0);
v_multiplicity_223_ = lean_ctor_get(v_r_221_, 1);
v_p_244_ = lean_ctor_get(v_root_222_, 0);
v_decide_245_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_p_218_, v_p_244_);
if (v_decide_245_ == 0)
{
lean_object* v___x_246_; 
v___x_246_ = lean_apply_1(v_fallback_220_, v_r_221_);
return v___x_246_;
}
else
{
uint8_t v___x_247_; 
lean_inc(v_multiplicity_223_);
lean_inc_ref(v_root_222_);
lean_dec_ref(v_r_221_);
lean_dec_ref(v_fallback_220_);
v___x_247_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_222_);
if (v___x_247_ == 0)
{
lean_object* v___x_248_; 
lean_dec(v_multiplicity_223_);
lean_dec_ref(v_root_222_);
v___x_248_ = lean_box(0);
return v___x_248_;
}
else
{
lean_object* v_factors_249_; lean_object* v___x_250_; lean_object* v___x_251_; uint8_t v___x_252_; 
v_factors_249_ = lean_ctor_get(v_factors_219_, 1);
v___x_250_ = lean_unsigned_to_nat(0u);
v___x_251_ = lean_array_get_size(v_factors_249_);
v___x_252_ = lean_nat_dec_lt(v___x_250_, v___x_251_);
if (v___x_252_ == 0)
{
lean_dec_ref(v_root_222_);
goto v___jp_237_;
}
else
{
lean_object* v___x_253_; uint8_t v___x_254_; 
v___x_253_ = lean_box(0);
v___x_254_ = lean_nat_dec_le(v___x_251_, v___x_251_);
if (v___x_254_ == 0)
{
if (v___x_252_ == 0)
{
lean_dec_ref(v_root_222_);
goto v___jp_237_;
}
else
{
size_t v___x_255_; size_t v___x_256_; lean_object* v___x_257_; 
v___x_255_ = ((size_t)0ULL);
v___x_256_ = lean_usize_of_nat(v___x_251_);
v___x_257_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(v_root_222_, v_factors_249_, v___x_255_, v___x_256_, v___x_253_);
lean_dec_ref(v_root_222_);
v___y_242_ = v___x_257_;
goto v___jp_241_;
}
}
else
{
size_t v___x_258_; size_t v___x_259_; lean_object* v___x_260_; 
v___x_258_ = ((size_t)0ULL);
v___x_259_ = lean_usize_of_nat(v___x_251_);
v___x_260_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__1(v_root_222_, v_factors_249_, v___x_258_, v___x_259_, v___x_253_);
lean_dec_ref(v_root_222_);
v___y_242_ = v___x_260_;
goto v___jp_241_;
}
}
}
}
v___jp_224_:
{
lean_object* v___x_226_; 
v___x_226_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___y_225_);
if (lean_obj_tag(v___x_226_) == 0)
{
lean_object* v___x_227_; 
lean_dec(v_multiplicity_223_);
v___x_227_ = lean_box(0);
return v___x_227_;
}
else
{
lean_object* v_val_228_; lean_object* v___x_230_; uint8_t v_isShared_231_; uint8_t v_isSharedCheck_236_; 
v_val_228_ = lean_ctor_get(v___x_226_, 0);
v_isSharedCheck_236_ = !lean_is_exclusive(v___x_226_);
if (v_isSharedCheck_236_ == 0)
{
v___x_230_ = v___x_226_;
v_isShared_231_ = v_isSharedCheck_236_;
goto v_resetjp_229_;
}
else
{
lean_inc(v_val_228_);
lean_dec(v___x_226_);
v___x_230_ = lean_box(0);
v_isShared_231_ = v_isSharedCheck_236_;
goto v_resetjp_229_;
}
v_resetjp_229_:
{
lean_object* v___x_232_; lean_object* v___x_234_; 
v___x_232_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_232_, 0, v_val_228_);
lean_ctor_set(v___x_232_, 1, v_multiplicity_223_);
if (v_isShared_231_ == 0)
{
lean_ctor_set(v___x_230_, 0, v___x_232_);
v___x_234_ = v___x_230_;
goto v_reusejp_233_;
}
else
{
lean_object* v_reuseFailAlloc_235_; 
v_reuseFailAlloc_235_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_235_, 0, v___x_232_);
v___x_234_ = v_reuseFailAlloc_235_;
goto v_reusejp_233_;
}
v_reusejp_233_:
{
return v___x_234_;
}
}
}
}
v___jp_237_:
{
lean_object* v___x_238_; lean_object* v___x_239_; lean_object* v___x_240_; 
v___x_238_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
v___x_239_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0));
v___x_240_ = lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_box(0), v___x_238_, v___x_239_);
v___y_225_ = v___x_240_;
goto v___jp_224_;
}
v___jp_241_:
{
if (lean_obj_tag(v___y_242_) == 0)
{
goto v___jp_237_;
}
else
{
lean_object* v_val_243_; 
v_val_243_ = lean_ctor_get(v___y_242_, 0);
lean_inc(v_val_243_);
lean_dec_ref_known(v___y_242_, 1);
v___y_225_ = v_val_243_;
goto v___jp_224_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___boxed(lean_object* v_p_261_, lean_object* v_factors_262_, lean_object* v_fallback_263_, lean_object* v_r_264_){
_start:
{
lean_object* v_res_265_; 
v_res_265_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg(v_p_261_, v_factors_262_, v_fallback_263_, v_r_264_);
lean_dec_ref(v_factors_262_);
lean_dec_ref(v_p_261_);
return v_res_265_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker(lean_object* v_p_266_, lean_object* v_factors_267_, lean_object* v___hfactor_268_, lean_object* v_fallback_269_, lean_object* v_r_270_){
_start:
{
lean_object* v___x_271_; 
v___x_271_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg(v_p_266_, v_factors_267_, v_fallback_269_, v_r_270_);
return v___x_271_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___boxed(lean_object* v_p_272_, lean_object* v_factors_273_, lean_object* v___hfactor_274_, lean_object* v_fallback_275_, lean_object* v_r_276_){
_start:
{
lean_object* v_res_277_; 
v_res_277_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker(v_p_272_, v_factors_273_, v___hfactor_274_, v_fallback_275_, v_r_276_);
lean_dec_ref(v_factors_273_);
lean_dec_ref(v_p_272_);
return v_res_277_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1(lean_object* v_xs_278_, lean_object* v_ys_279_, lean_object* v_hsz_280_, lean_object* v_x_281_, lean_object* v_x_282_){
_start:
{
uint8_t v___x_283_; 
v___x_283_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___redArg(v_xs_278_, v_ys_279_, v_x_281_);
return v___x_283_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1___boxed(lean_object* v_xs_284_, lean_object* v_ys_285_, lean_object* v_hsz_286_, lean_object* v_x_287_, lean_object* v_x_288_){
_start:
{
uint8_t v_res_289_; lean_object* v_r_290_; 
v_res_289_ = lp_Hex_Array_isEqvAux___at___00Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0_spec__1(v_xs_284_, v_ys_285_, v_hsz_286_, v_x_287_, v_x_288_);
lean_dec_ref(v_ys_285_);
lean_dec_ref(v_xs_284_);
v_r_290_ = lean_box(v_res_289_);
return v_r_290_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_RealAlgebraicPoly_Internal_parentExact_x3f_spec__0(lean_object* v_a_291_){
_start:
{
lean_object* v___x_292_; 
v___x_292_ = lean_nat_to_int(v_a_291_);
return v___x_292_;
}
}
LEAN_EXPORT lean_object* lp_Hex_List_find_x3f___at___00Hex_RealAlgebraicPoly_Internal_parentExact_x3f_spec__1(lean_object* v_a_293_, lean_object* v_x_294_){
_start:
{
if (lean_obj_tag(v_x_294_) == 0)
{
lean_object* v___x_295_; 
v___x_295_ = lean_box(0);
return v___x_295_;
}
else
{
lean_object* v_head_296_; lean_object* v_square_297_; lean_object* v_tail_298_; lean_object* v_p_299_; lean_object* v_rep_300_; lean_object* v_prec_301_; lean_object* v___x_302_; lean_object* v___x_303_; uint8_t v___x_304_; 
v_head_296_ = lean_ctor_get(v_x_294_, 0);
v_square_297_ = lean_ctor_get(v_head_296_, 0);
v_tail_298_ = lean_ctor_get(v_x_294_, 1);
v_p_299_ = lean_ctor_get(v_a_293_, 0);
v_rep_300_ = lean_ctor_get(v_a_293_, 2);
v_prec_301_ = lean_ctor_get(v_square_297_, 2);
v___x_302_ = lp_Hex_Hex_mahlerPrec(v_p_299_);
v___x_303_ = lean_nat_to_int(v___x_302_);
v___x_304_ = lean_int_dec_le(v___x_303_, v_prec_301_);
lean_dec(v___x_303_);
if (v___x_304_ == 0)
{
v_x_294_ = v_tail_298_;
goto _start;
}
else
{
lean_object* v_square_306_; uint8_t v___x_307_; 
v_square_306_ = lean_ctor_get(v_rep_300_, 0);
v___x_307_ = lp_Hex_Hex_DyadicSquare_discsMeet(v_square_297_, v_square_306_);
if (v___x_307_ == 0)
{
v_x_294_ = v_tail_298_;
goto _start;
}
else
{
lean_object* v___x_309_; 
lean_inc(v_head_296_);
v___x_309_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_309_, 0, v_head_296_);
return v___x_309_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_find_x3f___at___00Hex_RealAlgebraicPoly_Internal_parentExact_x3f_spec__1___boxed(lean_object* v_a_310_, lean_object* v_x_311_){
_start:
{
lean_object* v_res_312_; 
v_res_312_ = lp_Hex_List_find_x3f___at___00Hex_RealAlgebraicPoly_Internal_parentExact_x3f_spec__1(v_a_310_, v_x_311_);
lean_dec(v_x_311_);
lean_dec_ref(v_a_310_);
return v_res_312_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_parentExact_x3f___redArg(lean_object* v_a_313_, lean_object* v_refined_314_, lean_object* v_comparable_315_){
_start:
{
lean_object* v___x_316_; lean_object* v___x_317_; 
v___x_316_ = lean_array_to_list(v_comparable_315_);
v___x_317_ = lp_Hex_List_find_x3f___at___00Hex_RealAlgebraicPoly_Internal_parentExact_x3f_spec__1(v_a_313_, v___x_316_);
lean_dec(v___x_316_);
if (lean_obj_tag(v___x_317_) == 0)
{
lean_object* v___x_318_; 
lean_dec_ref(v_refined_314_);
lean_dec_ref(v_a_313_);
v___x_318_ = lean_box(0);
return v___x_318_;
}
else
{
lean_object* v_val_319_; lean_object* v_p_320_; lean_object* v___x_321_; 
v_val_319_ = lean_ctor_get(v___x_317_, 0);
lean_inc(v_val_319_);
lean_dec_ref_known(v___x_317_, 1);
v_p_320_ = lean_ctor_get(v_a_313_, 0);
lean_inc_ref(v_p_320_);
lean_dec_ref(v_a_313_);
v___x_321_ = lp_Hex_Hex_AlgebraicNumber_ofNormalizedIn_x3f___redArg(v_p_320_, v_val_319_, v_refined_314_);
return v___x_321_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_parentExact_x3f(lean_object* v_a_322_, lean_object* v_isolations_323_, lean_object* v_refined_324_, lean_object* v_hisolate_325_, lean_object* v_hrefine_326_, lean_object* v_hirred_327_, lean_object* v_comparable_328_, lean_object* v___hcomparable_329_){
_start:
{
lean_object* v___x_330_; 
v___x_330_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_parentExact_x3f___redArg(v_a_322_, v_refined_324_, v_comparable_328_);
return v___x_330_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_parentExact_x3f___boxed(lean_object* v_a_331_, lean_object* v_isolations_332_, lean_object* v_refined_333_, lean_object* v_hisolate_334_, lean_object* v_hrefine_335_, lean_object* v_hirred_336_, lean_object* v_comparable_337_, lean_object* v___hcomparable_338_){
_start:
{
lean_object* v_res_339_; 
v_res_339_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_parentExact_x3f(v_a_331_, v_isolations_332_, v_refined_333_, v_hisolate_334_, v_hrefine_335_, v_hirred_336_, v_comparable_337_, v___hcomparable_338_);
lean_dec_ref(v_isolations_332_);
return v_res_339_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___redArg(lean_object* v_p_340_, lean_object* v___x_341_, lean_object* v_refined_342_, lean_object* v_comparable_343_, lean_object* v_as_344_, size_t v_i_345_, size_t v_stop_346_, lean_object* v_b_347_){
_start:
{
lean_object* v___y_349_; uint8_t v___x_353_; 
v___x_353_ = lean_usize_dec_eq(v_i_345_, v_stop_346_);
if (v___x_353_ == 0)
{
if (lean_obj_tag(v_b_347_) == 0)
{
lean_object* v___x_354_; lean_object* v_fst_355_; uint8_t v_decide_356_; 
v___x_354_ = lean_array_uget_borrowed(v_as_344_, v_i_345_);
v_fst_355_ = lean_ctor_get(v___x_354_, 0);
v_decide_356_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_fst_355_, v_p_340_);
if (v_decide_356_ == 0)
{
lean_object* v___x_357_; 
lean_inc(v_fst_355_);
v___x_357_ = lp_Hex_Hex_AlgebraicRoot_exactFactor_x3f(v___x_341_, v_fst_355_);
v___y_349_ = v___x_357_;
goto v___jp_348_;
}
else
{
lean_object* v___x_358_; 
lean_inc_ref(v_comparable_343_);
lean_inc_ref(v_refined_342_);
lean_inc_ref(v___x_341_);
v___x_358_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_parentExact_x3f___redArg(v___x_341_, v_refined_342_, v_comparable_343_);
v___y_349_ = v___x_358_;
goto v___jp_348_;
}
}
else
{
v___y_349_ = v_b_347_;
goto v___jp_348_;
}
}
else
{
lean_dec_ref(v_comparable_343_);
lean_dec_ref(v_refined_342_);
lean_dec_ref(v___x_341_);
return v_b_347_;
}
v___jp_348_:
{
size_t v___x_350_; size_t v___x_351_; 
v___x_350_ = ((size_t)1ULL);
v___x_351_ = lean_usize_add(v_i_345_, v___x_350_);
v_i_345_ = v___x_351_;
v_b_347_ = v___y_349_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___redArg___boxed(lean_object* v_p_359_, lean_object* v___x_360_, lean_object* v_refined_361_, lean_object* v_comparable_362_, lean_object* v_as_363_, lean_object* v_i_364_, lean_object* v_stop_365_, lean_object* v_b_366_){
_start:
{
size_t v_i_boxed_367_; size_t v_stop_boxed_368_; lean_object* v_res_369_; 
v_i_boxed_367_ = lean_unbox_usize(v_i_364_);
lean_dec(v_i_364_);
v_stop_boxed_368_ = lean_unbox_usize(v_stop_365_);
lean_dec(v_stop_365_);
v_res_369_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___redArg(v_p_359_, v___x_360_, v_refined_361_, v_comparable_362_, v_as_363_, v_i_boxed_367_, v_stop_boxed_368_, v_b_366_);
lean_dec_ref(v_as_363_);
lean_dec_ref(v_p_359_);
return v_res_369_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg(lean_object* v_p_370_, lean_object* v_isolations_371_, lean_object* v_refined_372_, lean_object* v_factors_373_, lean_object* v_comparable_374_, lean_object* v_fallback_375_, lean_object* v_r_376_){
_start:
{
lean_object* v_root_377_; lean_object* v_multiplicity_378_; lean_object* v___y_380_; lean_object* v___y_397_; lean_object* v_p_399_; uint8_t v_decide_400_; 
v_root_377_ = lean_ctor_get(v_r_376_, 0);
v_multiplicity_378_ = lean_ctor_get(v_r_376_, 1);
v_p_399_ = lean_ctor_get(v_root_377_, 0);
v_decide_400_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_p_370_, v_p_399_);
if (v_decide_400_ == 0)
{
lean_object* v___x_401_; 
lean_dec_ref(v_comparable_374_);
lean_dec_ref(v_refined_372_);
v___x_401_ = lean_apply_1(v_fallback_375_, v_r_376_);
return v___x_401_;
}
else
{
uint8_t v___x_402_; 
lean_inc(v_multiplicity_378_);
lean_inc_ref(v_root_377_);
lean_dec_ref(v_r_376_);
lean_dec_ref(v_fallback_375_);
v___x_402_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_377_);
if (v___x_402_ == 0)
{
lean_object* v___x_403_; 
lean_dec(v_multiplicity_378_);
lean_dec_ref(v_root_377_);
lean_dec_ref(v_comparable_374_);
lean_dec_ref(v_refined_372_);
v___x_403_ = lean_box(0);
return v___x_403_;
}
else
{
lean_object* v_factors_404_; lean_object* v___x_405_; lean_object* v___x_406_; uint8_t v___x_407_; 
v_factors_404_ = lean_ctor_get(v_factors_373_, 1);
v___x_405_ = lean_unsigned_to_nat(0u);
v___x_406_ = lean_array_get_size(v_factors_404_);
v___x_407_ = lean_nat_dec_lt(v___x_405_, v___x_406_);
if (v___x_407_ == 0)
{
lean_dec_ref(v_root_377_);
lean_dec_ref(v_comparable_374_);
lean_dec_ref(v_refined_372_);
goto v___jp_392_;
}
else
{
lean_object* v___x_408_; uint8_t v___x_409_; 
v___x_408_ = lean_box(0);
v___x_409_ = lean_nat_dec_le(v___x_406_, v___x_406_);
if (v___x_409_ == 0)
{
if (v___x_407_ == 0)
{
lean_dec_ref(v_root_377_);
lean_dec_ref(v_comparable_374_);
lean_dec_ref(v_refined_372_);
goto v___jp_392_;
}
else
{
size_t v___x_410_; size_t v___x_411_; lean_object* v___x_412_; 
v___x_410_ = ((size_t)0ULL);
v___x_411_ = lean_usize_of_nat(v___x_406_);
v___x_412_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___redArg(v_p_370_, v_root_377_, v_refined_372_, v_comparable_374_, v_factors_404_, v___x_410_, v___x_411_, v___x_408_);
v___y_397_ = v___x_412_;
goto v___jp_396_;
}
}
else
{
size_t v___x_413_; size_t v___x_414_; lean_object* v___x_415_; 
v___x_413_ = ((size_t)0ULL);
v___x_414_ = lean_usize_of_nat(v___x_406_);
v___x_415_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___redArg(v_p_370_, v_root_377_, v_refined_372_, v_comparable_374_, v_factors_404_, v___x_413_, v___x_414_, v___x_408_);
v___y_397_ = v___x_415_;
goto v___jp_396_;
}
}
}
}
v___jp_379_:
{
lean_object* v___x_381_; 
v___x_381_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___y_380_);
if (lean_obj_tag(v___x_381_) == 0)
{
lean_object* v___x_382_; 
lean_dec(v_multiplicity_378_);
v___x_382_ = lean_box(0);
return v___x_382_;
}
else
{
lean_object* v_val_383_; lean_object* v___x_385_; uint8_t v_isShared_386_; uint8_t v_isSharedCheck_391_; 
v_val_383_ = lean_ctor_get(v___x_381_, 0);
v_isSharedCheck_391_ = !lean_is_exclusive(v___x_381_);
if (v_isSharedCheck_391_ == 0)
{
v___x_385_ = v___x_381_;
v_isShared_386_ = v_isSharedCheck_391_;
goto v_resetjp_384_;
}
else
{
lean_inc(v_val_383_);
lean_dec(v___x_381_);
v___x_385_ = lean_box(0);
v_isShared_386_ = v_isSharedCheck_391_;
goto v_resetjp_384_;
}
v_resetjp_384_:
{
lean_object* v___x_387_; lean_object* v___x_389_; 
v___x_387_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_387_, 0, v_val_383_);
lean_ctor_set(v___x_387_, 1, v_multiplicity_378_);
if (v_isShared_386_ == 0)
{
lean_ctor_set(v___x_385_, 0, v___x_387_);
v___x_389_ = v___x_385_;
goto v_reusejp_388_;
}
else
{
lean_object* v_reuseFailAlloc_390_; 
v_reuseFailAlloc_390_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_390_, 0, v___x_387_);
v___x_389_ = v_reuseFailAlloc_390_;
goto v_reusejp_388_;
}
v_reusejp_388_:
{
return v___x_389_;
}
}
}
}
v___jp_392_:
{
lean_object* v___x_393_; lean_object* v___x_394_; lean_object* v___x_395_; 
v___x_393_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
v___x_394_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___redArg___closed__0));
v___x_395_ = lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_box(0), v___x_393_, v___x_394_);
v___y_380_ = v___x_395_;
goto v___jp_379_;
}
v___jp_396_:
{
if (lean_obj_tag(v___y_397_) == 0)
{
goto v___jp_392_;
}
else
{
lean_object* v_val_398_; 
v_val_398_ = lean_ctor_get(v___y_397_, 0);
lean_inc(v_val_398_);
lean_dec_ref_known(v___y_397_, 1);
v___y_380_ = v_val_398_;
goto v___jp_379_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg___boxed(lean_object* v_p_416_, lean_object* v_isolations_417_, lean_object* v_refined_418_, lean_object* v_factors_419_, lean_object* v_comparable_420_, lean_object* v_fallback_421_, lean_object* v_r_422_){
_start:
{
lean_object* v_res_423_; 
v_res_423_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg(v_p_416_, v_isolations_417_, v_refined_418_, v_factors_419_, v_comparable_420_, v_fallback_421_, v_r_422_);
lean_dec_ref(v_factors_419_);
lean_dec_ref(v_isolations_417_);
lean_dec_ref(v_p_416_);
return v_res_423_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker(lean_object* v_p_424_, lean_object* v_squarefree_425_, lean_object* v_isolations_426_, lean_object* v_refined_427_, lean_object* v_hisolate_428_, lean_object* v_hrefine_429_, lean_object* v_factors_430_, lean_object* v___hfactor_431_, lean_object* v_hirred_432_, lean_object* v_comparable_433_, lean_object* v_hcomparable_434_, lean_object* v_fallback_435_, lean_object* v_r_436_){
_start:
{
lean_object* v___x_437_; 
v___x_437_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___redArg(v_p_424_, v_isolations_426_, v_refined_427_, v_factors_430_, v_comparable_433_, v_fallback_435_, v_r_436_);
return v___x_437_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___boxed(lean_object* v_p_438_, lean_object* v_squarefree_439_, lean_object* v_isolations_440_, lean_object* v_refined_441_, lean_object* v_hisolate_442_, lean_object* v_hrefine_443_, lean_object* v_factors_444_, lean_object* v___hfactor_445_, lean_object* v_hirred_446_, lean_object* v_comparable_447_, lean_object* v_hcomparable_448_, lean_object* v_fallback_449_, lean_object* v_r_450_){
_start:
{
lean_object* v_res_451_; 
v_res_451_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker(v_p_438_, v_squarefree_439_, v_isolations_440_, v_refined_441_, v_hisolate_442_, v_hrefine_443_, v_factors_444_, v___hfactor_445_, v_hirred_446_, v_comparable_447_, v_hcomparable_448_, v_fallback_449_, v_r_450_);
lean_dec_ref(v_factors_444_);
lean_dec_ref(v_isolations_440_);
lean_dec_ref(v_p_438_);
return v_res_451_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0(lean_object* v_p_452_, lean_object* v___x_453_, lean_object* v_isolations_454_, lean_object* v_refined_455_, lean_object* v_comparable_456_, lean_object* v_as_457_, size_t v_i_458_, size_t v_stop_459_, lean_object* v_b_460_){
_start:
{
lean_object* v___x_461_; 
v___x_461_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___redArg(v_p_452_, v___x_453_, v_refined_455_, v_comparable_456_, v_as_457_, v_i_458_, v_stop_459_, v_b_460_);
return v___x_461_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0___boxed(lean_object* v_p_462_, lean_object* v___x_463_, lean_object* v_isolations_464_, lean_object* v_refined_465_, lean_object* v_comparable_466_, lean_object* v_as_467_, lean_object* v_i_468_, lean_object* v_stop_469_, lean_object* v_b_470_){
_start:
{
size_t v_i_boxed_471_; size_t v_stop_boxed_472_; lean_object* v_res_473_; 
v_i_boxed_471_ = lean_unbox_usize(v_i_468_);
lean_dec(v_i_468_);
v_stop_boxed_472_ = lean_unbox_usize(v_stop_469_);
lean_dec(v_stop_469_);
v_res_473_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootPicker_spec__0(v_p_462_, v___x_463_, v_isolations_464_, v_refined_465_, v_comparable_466_, v_as_467_, v_i_boxed_471_, v_stop_boxed_472_, v_b_470_);
lean_dec_ref(v_as_467_);
lean_dec_ref(v_isolations_464_);
lean_dec_ref(v_p_462_);
return v_res_473_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_ZPoly_isIrreducible_match__1_splitter___redArg(lean_object* v_x_474_, lean_object* v_h__1_475_, lean_object* v_h__2_476_){
_start:
{
if (lean_obj_tag(v_x_474_) == 1)
{
lean_object* v_tail_477_; 
v_tail_477_ = lean_ctor_get(v_x_474_, 1);
if (lean_obj_tag(v_tail_477_) == 0)
{
lean_object* v_head_478_; lean_object* v___x_479_; 
lean_dec(v_h__2_476_);
v_head_478_ = lean_ctor_get(v_x_474_, 0);
lean_inc(v_head_478_);
lean_dec_ref_known(v_x_474_, 2);
v___x_479_ = lean_apply_1(v_h__1_475_, v_head_478_);
return v___x_479_;
}
else
{
lean_object* v___x_480_; 
lean_dec(v_h__1_475_);
v___x_480_ = lean_apply_2(v_h__2_476_, v_x_474_, lean_box(0));
return v___x_480_;
}
}
else
{
lean_object* v___x_481_; 
lean_dec(v_h__1_475_);
v___x_481_ = lean_apply_2(v_h__2_476_, v_x_474_, lean_box(0));
return v___x_481_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_ZPoly_isIrreducible_match__1_splitter(lean_object* v_motive_482_, lean_object* v_x_483_, lean_object* v_h__1_484_, lean_object* v_h__2_485_){
_start:
{
if (lean_obj_tag(v_x_483_) == 1)
{
lean_object* v_tail_486_; 
v_tail_486_ = lean_ctor_get(v_x_483_, 1);
if (lean_obj_tag(v_tail_486_) == 0)
{
lean_object* v_head_487_; lean_object* v___x_488_; 
lean_dec(v_h__2_485_);
v_head_487_ = lean_ctor_get(v_x_483_, 0);
lean_inc(v_head_487_);
lean_dec_ref_known(v_x_483_, 2);
v___x_488_ = lean_apply_1(v_h__1_484_, v_head_487_);
return v___x_488_;
}
else
{
lean_object* v___x_489_; 
lean_dec(v_h__1_484_);
v___x_489_ = lean_apply_2(v_h__2_485_, v_x_483_, lean_box(0));
return v___x_489_;
}
}
else
{
lean_object* v___x_490_; 
lean_dec(v_h__1_484_);
v___x_490_ = lean_apply_2(v_h__2_485_, v_x_483_, lean_box(0));
return v___x_490_;
}
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0(lean_object* v_a_491_, lean_object* v_as_492_, size_t v_i_493_, size_t v_stop_494_){
_start:
{
uint8_t v___x_495_; 
v___x_495_ = lean_usize_dec_eq(v_i_493_, v_stop_494_);
if (v___x_495_ == 0)
{
lean_object* v___x_496_; uint8_t v_decide_497_; 
v___x_496_ = lean_array_uget_borrowed(v_as_492_, v_i_493_);
v_decide_497_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_a_491_, v___x_496_);
if (v_decide_497_ == 0)
{
size_t v___x_498_; size_t v___x_499_; 
v___x_498_ = ((size_t)1ULL);
v___x_499_ = lean_usize_add(v_i_493_, v___x_498_);
v_i_493_ = v___x_499_;
goto _start;
}
else
{
return v_decide_497_;
}
}
else
{
uint8_t v___x_501_; 
v___x_501_ = 0;
return v___x_501_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0___boxed(lean_object* v_a_502_, lean_object* v_as_503_, lean_object* v_i_504_, lean_object* v_stop_505_){
_start:
{
size_t v_i_boxed_506_; size_t v_stop_boxed_507_; uint8_t v_res_508_; lean_object* v_r_509_; 
v_i_boxed_506_ = lean_unbox_usize(v_i_504_);
lean_dec(v_i_504_);
v_stop_boxed_507_ = lean_unbox_usize(v_stop_505_);
lean_dec(v_stop_505_);
v_res_508_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0(v_a_502_, v_as_503_, v_i_boxed_506_, v_stop_boxed_507_);
lean_dec_ref(v_as_503_);
lean_dec_ref(v_a_502_);
v_r_509_ = lean_box(v_res_508_);
return v_r_509_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0(lean_object* v_as_510_, lean_object* v_a_511_){
_start:
{
lean_object* v___x_512_; lean_object* v___x_513_; uint8_t v___x_514_; 
v___x_512_ = lean_unsigned_to_nat(0u);
v___x_513_ = lean_array_get_size(v_as_510_);
v___x_514_ = lean_nat_dec_lt(v___x_512_, v___x_513_);
if (v___x_514_ == 0)
{
return v___x_514_;
}
else
{
if (v___x_514_ == 0)
{
return v___x_514_;
}
else
{
size_t v___x_515_; size_t v___x_516_; uint8_t v___x_517_; 
v___x_515_ = ((size_t)0ULL);
v___x_516_ = lean_usize_of_nat(v___x_513_);
v___x_517_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0_spec__0(v_a_511_, v_as_510_, v___x_515_, v___x_516_);
return v___x_517_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0___boxed(lean_object* v_as_518_, lean_object* v_a_519_){
_start:
{
uint8_t v_res_520_; lean_object* v_r_521_; 
v_res_520_ = lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0(v_as_518_, v_a_519_);
lean_dec_ref(v_a_519_);
lean_dec_ref(v_as_518_);
v_r_521_ = lean_box(v_res_520_);
return v_r_521_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1(lean_object* v___x_522_, lean_object* v_as_523_, size_t v_i_524_, size_t v_stop_525_){
_start:
{
uint8_t v___x_526_; 
v___x_526_ = lean_usize_dec_eq(v_i_524_, v_stop_525_);
if (v___x_526_ == 0)
{
lean_object* v___x_527_; lean_object* v_fst_528_; uint8_t v_decide_529_; 
v___x_527_ = lean_array_uget_borrowed(v_as_523_, v_i_524_);
v_fst_528_ = lean_ctor_get(v___x_527_, 0);
v_decide_529_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_fst_528_, v___x_522_);
if (v_decide_529_ == 0)
{
size_t v___x_530_; size_t v___x_531_; 
v___x_530_ = ((size_t)1ULL);
v___x_531_ = lean_usize_add(v_i_524_, v___x_530_);
v_i_524_ = v___x_531_;
goto _start;
}
else
{
return v_decide_529_;
}
}
else
{
uint8_t v___x_533_; 
v___x_533_ = 0;
return v___x_533_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1___boxed(lean_object* v___x_534_, lean_object* v_as_535_, lean_object* v_i_536_, lean_object* v_stop_537_){
_start:
{
size_t v_i_boxed_538_; size_t v_stop_boxed_539_; uint8_t v_res_540_; lean_object* v_r_541_; 
v_i_boxed_538_ = lean_unbox_usize(v_i_536_);
lean_dec(v_i_536_);
v_stop_boxed_539_ = lean_unbox_usize(v_stop_537_);
lean_dec(v_stop_537_);
v_res_540_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1(v___x_534_, v_as_535_, v_i_boxed_538_, v_stop_boxed_539_);
lean_dec_ref(v_as_535_);
lean_dec_ref(v___x_534_);
v_r_541_ = lean_box(v_res_540_);
return v_r_541_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4(uint8_t v___x_542_, lean_object* v___x_543_, lean_object* v_as_544_, size_t v_i_545_, size_t v_stop_546_, lean_object* v_b_547_){
_start:
{
uint8_t v___x_548_; 
v___x_548_ = lean_usize_dec_eq(v_i_545_, v_stop_546_);
if (v___x_548_ == 0)
{
size_t v___x_549_; size_t v___x_550_; uint8_t v___y_552_; lean_object* v___x_557_; lean_object* v_root_558_; uint8_t v___x_559_; 
v___x_549_ = ((size_t)1ULL);
v___x_550_ = lean_usize_sub(v_i_545_, v___x_549_);
v___x_557_ = lean_array_uget_borrowed(v_as_544_, v___x_550_);
v_root_558_ = lean_ctor_get(v___x_557_, 0);
v___x_559_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_558_);
if (v___x_559_ == 0)
{
v___y_552_ = v___x_542_;
goto v___jp_551_;
}
else
{
lean_object* v_p_560_; uint8_t v_decide_561_; 
v_p_560_ = lean_ctor_get(v_root_558_, 0);
v_decide_561_ = lp_Hex_Array_instDecidableEqImpl___at___00__private_HexPoly_Dense_0__Hex_DensePoly_decEqRuntime___at___00Hex_RealAlgebraicPoly_Internal_factorPicker_spec__0_spec__0(v_p_560_, v___x_543_);
v___y_552_ = v_decide_561_;
goto v___jp_551_;
}
v___jp_551_:
{
if (v___y_552_ == 0)
{
v_i_545_ = v___x_550_;
goto _start;
}
else
{
lean_object* v___x_554_; lean_object* v___x_555_; 
v___x_554_ = lean_unsigned_to_nat(1u);
v___x_555_ = lean_nat_add(v_b_547_, v___x_554_);
lean_dec(v_b_547_);
v_i_545_ = v___x_550_;
v_b_547_ = v___x_555_;
goto _start;
}
}
}
else
{
return v_b_547_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4___boxed(lean_object* v___x_562_, lean_object* v___x_563_, lean_object* v_as_564_, lean_object* v_i_565_, lean_object* v_stop_566_, lean_object* v_b_567_){
_start:
{
uint8_t v___x_3371__boxed_568_; size_t v_i_boxed_569_; size_t v_stop_boxed_570_; lean_object* v_res_571_; 
v___x_3371__boxed_568_ = lean_unbox(v___x_562_);
v_i_boxed_569_ = lean_unbox_usize(v_i_565_);
lean_dec(v_i_565_);
v_stop_boxed_570_ = lean_unbox_usize(v_stop_566_);
lean_dec(v_stop_566_);
v_res_571_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4(v___x_3371__boxed_568_, v___x_563_, v_as_564_, v_i_boxed_569_, v_stop_boxed_570_, v_b_567_);
lean_dec_ref(v_as_564_);
lean_dec_ref(v___x_563_);
return v_res_571_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__2(lean_object* v___x_572_, size_t v_sz_573_, size_t v_i_574_, lean_object* v_bs_575_){
_start:
{
uint8_t v___x_576_; 
v___x_576_ = lean_usize_dec_lt(v_i_574_, v_sz_573_);
if (v___x_576_ == 0)
{
lean_object* v___x_577_; 
v___x_577_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_577_, 0, v_bs_575_);
return v___x_577_;
}
else
{
lean_object* v_v_578_; lean_object* v___x_579_; 
v_v_578_ = lean_array_uget_borrowed(v_bs_575_, v_i_574_);
lean_inc(v_v_578_);
v___x_579_ = lp_Hex_Hex_DyadicRootIsolation_toRefined_x3f(v___x_572_, v_v_578_);
if (lean_obj_tag(v___x_579_) == 0)
{
lean_object* v___x_580_; 
lean_dec_ref(v_bs_575_);
v___x_580_ = lean_box(0);
return v___x_580_;
}
else
{
lean_object* v_val_581_; lean_object* v___x_582_; lean_object* v_bs_x27_583_; size_t v___x_584_; size_t v___x_585_; lean_object* v___x_586_; 
v_val_581_ = lean_ctor_get(v___x_579_, 0);
lean_inc(v_val_581_);
lean_dec_ref_known(v___x_579_, 1);
v___x_582_ = lean_unsigned_to_nat(0u);
v_bs_x27_583_ = lean_array_uset(v_bs_575_, v_i_574_, v___x_582_);
v___x_584_ = ((size_t)1ULL);
v___x_585_ = lean_usize_add(v_i_574_, v___x_584_);
v___x_586_ = lean_array_uset(v_bs_x27_583_, v_i_574_, v_val_581_);
v_i_574_ = v___x_585_;
v_bs_575_ = v___x_586_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__2___boxed(lean_object* v___x_588_, lean_object* v_sz_589_, lean_object* v_i_590_, lean_object* v_bs_591_){
_start:
{
size_t v_sz_boxed_592_; size_t v_i_boxed_593_; lean_object* v_res_594_; 
v_sz_boxed_592_ = lean_unbox_usize(v_sz_589_);
lean_dec(v_sz_589_);
v_i_boxed_593_ = lean_unbox_usize(v_i_590_);
lean_dec(v_i_590_);
v_res_594_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__2(v___x_588_, v_sz_boxed_592_, v_i_boxed_593_, v_bs_591_);
lean_dec_ref(v___x_588_);
return v_res_594_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3_spec__4(lean_object* v___x_595_, size_t v_sz_596_, size_t v_i_597_, lean_object* v_bs_598_){
_start:
{
uint8_t v___x_599_; 
v___x_599_ = lean_usize_dec_lt(v_i_597_, v_sz_596_);
if (v___x_599_ == 0)
{
lean_object* v___x_600_; 
lean_dec_ref(v___x_595_);
v___x_600_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_600_, 0, v_bs_598_);
return v___x_600_;
}
else
{
lean_object* v_v_601_; lean_object* v___x_602_; lean_object* v___x_603_; uint8_t v___x_604_; lean_object* v___x_605_; lean_object* v___x_606_; 
v_v_601_ = lean_array_uget_borrowed(v_bs_598_, v_i_597_);
v___x_602_ = lp_Hex_Hex_mahlerPrec(v___x_595_);
v___x_603_ = lean_nat_to_int(v___x_602_);
v___x_604_ = 2;
lean_inc(v_v_601_);
lean_inc_ref(v___x_595_);
v___x_605_ = lp_Hex_Hex_RefinedIsolation_refineTo_x3f(v___x_595_, v_v_601_, v___x_603_, v___x_604_);
v___x_606_ = l_Option_unattach___redArg(v___x_605_);
if (lean_obj_tag(v___x_606_) == 0)
{
lean_object* v___x_607_; 
lean_dec_ref(v_bs_598_);
lean_dec_ref(v___x_595_);
v___x_607_ = lean_box(0);
return v___x_607_;
}
else
{
lean_object* v_val_608_; lean_object* v___x_609_; lean_object* v_bs_x27_610_; size_t v___x_611_; size_t v___x_612_; lean_object* v___x_613_; 
v_val_608_ = lean_ctor_get(v___x_606_, 0);
lean_inc(v_val_608_);
lean_dec_ref_known(v___x_606_, 1);
v___x_609_ = lean_unsigned_to_nat(0u);
v_bs_x27_610_ = lean_array_uset(v_bs_598_, v_i_597_, v___x_609_);
v___x_611_ = ((size_t)1ULL);
v___x_612_ = lean_usize_add(v_i_597_, v___x_611_);
v___x_613_ = lean_array_uset(v_bs_x27_610_, v_i_597_, v_val_608_);
v_i_597_ = v___x_612_;
v_bs_598_ = v___x_613_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3_spec__4___boxed(lean_object* v___x_615_, lean_object* v_sz_616_, lean_object* v_i_617_, lean_object* v_bs_618_){
_start:
{
size_t v_sz_boxed_619_; size_t v_i_boxed_620_; lean_object* v_res_621_; 
v_sz_boxed_619_ = lean_unbox_usize(v_sz_616_);
lean_dec(v_sz_616_);
v_i_boxed_620_ = lean_unbox_usize(v_i_617_);
lean_dec(v_i_617_);
v_res_621_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3_spec__4(v___x_615_, v_sz_boxed_619_, v_i_boxed_620_, v_bs_618_);
return v_res_621_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3(lean_object* v___x_622_, size_t v_sz_623_, size_t v_i_624_, lean_object* v_bs_625_){
_start:
{
uint8_t v___x_626_; 
v___x_626_ = lean_usize_dec_lt(v_i_624_, v_sz_623_);
if (v___x_626_ == 0)
{
lean_object* v___x_627_; 
lean_dec_ref(v___x_622_);
v___x_627_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_627_, 0, v_bs_625_);
return v___x_627_;
}
else
{
lean_object* v_v_628_; lean_object* v___x_629_; lean_object* v___x_630_; uint8_t v___x_631_; lean_object* v___x_632_; lean_object* v___x_633_; 
v_v_628_ = lean_array_uget_borrowed(v_bs_625_, v_i_624_);
v___x_629_ = lp_Hex_Hex_mahlerPrec(v___x_622_);
v___x_630_ = lean_nat_to_int(v___x_629_);
v___x_631_ = 2;
lean_inc(v_v_628_);
lean_inc_ref(v___x_622_);
v___x_632_ = lp_Hex_Hex_RefinedIsolation_refineTo_x3f(v___x_622_, v_v_628_, v___x_630_, v___x_631_);
v___x_633_ = l_Option_unattach___redArg(v___x_632_);
if (lean_obj_tag(v___x_633_) == 0)
{
lean_object* v___x_634_; 
lean_dec_ref(v_bs_625_);
lean_dec_ref(v___x_622_);
v___x_634_ = lean_box(0);
return v___x_634_;
}
else
{
lean_object* v_val_635_; lean_object* v___x_636_; lean_object* v_bs_x27_637_; size_t v___x_638_; size_t v___x_639_; lean_object* v___x_640_; lean_object* v___x_641_; 
v_val_635_ = lean_ctor_get(v___x_633_, 0);
lean_inc(v_val_635_);
lean_dec_ref_known(v___x_633_, 1);
v___x_636_ = lean_unsigned_to_nat(0u);
v_bs_x27_637_ = lean_array_uset(v_bs_625_, v_i_624_, v___x_636_);
v___x_638_ = ((size_t)1ULL);
v___x_639_ = lean_usize_add(v_i_624_, v___x_638_);
v___x_640_ = lean_array_uset(v_bs_x27_637_, v_i_624_, v_val_635_);
v___x_641_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00__private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3_spec__4(v___x_622_, v_sz_623_, v___x_639_, v___x_640_);
return v___x_641_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3___boxed(lean_object* v___x_642_, lean_object* v_sz_643_, lean_object* v_i_644_, lean_object* v_bs_645_){
_start:
{
size_t v_sz_boxed_646_; size_t v_i_boxed_647_; lean_object* v_res_648_; 
v_sz_boxed_646_ = lean_unbox_usize(v_sz_643_);
lean_dec(v_sz_643_);
v_i_boxed_647_ = lean_unbox_usize(v_i_644_);
lean_dec(v_i_644_);
v_res_648_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3(v___x_642_, v_sz_boxed_646_, v_i_boxed_647_, v_bs_645_);
return v_res_648_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5_spec__7(lean_object* v_roots_649_, lean_object* v_as_650_, size_t v_i_651_, size_t v_stop_652_, lean_object* v_b_653_){
_start:
{
lean_object* v___y_655_; uint8_t v___x_659_; 
v___x_659_ = lean_usize_dec_eq(v_i_651_, v_stop_652_);
if (v___x_659_ == 0)
{
lean_object* v___x_660_; lean_object* v_root_661_; uint8_t v___x_662_; 
v___x_660_ = lean_array_uget_borrowed(v_as_650_, v_i_651_);
v_root_661_ = lean_ctor_get(v___x_660_, 0);
v___x_662_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_661_);
if (v___x_662_ == 0)
{
v___y_655_ = v_b_653_;
goto v___jp_654_;
}
else
{
lean_object* v_fst_663_; lean_object* v_snd_664_; lean_object* v_p_665_; uint8_t v___x_666_; 
v_fst_663_ = lean_ctor_get(v_b_653_, 0);
v_snd_664_ = lean_ctor_get(v_b_653_, 1);
v_p_665_ = lean_ctor_get(v_root_661_, 0);
v___x_666_ = lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0(v_fst_663_, v_p_665_);
if (v___x_666_ == 0)
{
lean_object* v___x_668_; uint8_t v_isShared_669_; uint8_t v_isSharedCheck_756_; 
lean_inc(v_snd_664_);
lean_inc(v_fst_663_);
v_isSharedCheck_756_ = !lean_is_exclusive(v_b_653_);
if (v_isSharedCheck_756_ == 0)
{
lean_object* v_unused_757_; lean_object* v_unused_758_; 
v_unused_757_ = lean_ctor_get(v_b_653_, 1);
lean_dec(v_unused_757_);
v_unused_758_ = lean_ctor_get(v_b_653_, 0);
lean_dec(v_unused_758_);
v___x_668_ = v_b_653_;
v_isShared_669_ = v_isSharedCheck_756_;
goto v_resetjp_667_;
}
else
{
lean_dec(v_b_653_);
v___x_668_ = lean_box(0);
v_isShared_669_ = v_isSharedCheck_756_;
goto v_resetjp_667_;
}
v_resetjp_667_:
{
lean_object* v_seen_670_; lean_object* v___y_672_; lean_object* v___x_750_; lean_object* v___x_751_; uint8_t v___x_752_; 
lean_inc_ref(v_p_665_);
v_seen_670_ = lean_array_push(v_fst_663_, v_p_665_);
v___x_750_ = lean_unsigned_to_nat(0u);
v___x_751_ = lean_array_get_size(v_roots_649_);
v___x_752_ = lean_nat_dec_lt(v___x_750_, v___x_751_);
if (v___x_752_ == 0)
{
v___y_672_ = v___x_750_;
goto v___jp_671_;
}
else
{
size_t v___x_753_; size_t v___x_754_; lean_object* v___x_755_; 
v___x_753_ = lean_usize_of_nat(v___x_751_);
v___x_754_ = ((size_t)0ULL);
v___x_755_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4(v___x_666_, v_p_665_, v_roots_649_, v___x_753_, v___x_754_, v___x_750_);
v___y_672_ = v___x_755_;
goto v___jp_671_;
}
v___jp_671_:
{
lean_object* v___x_673_; uint8_t v___x_674_; 
v___x_673_ = lean_unsigned_to_nat(2u);
v___x_674_ = lean_nat_dec_lt(v___y_672_, v___x_673_);
lean_dec(v___y_672_);
if (v___x_674_ == 0)
{
lean_object* v_factors_675_; lean_object* v_scalar_676_; lean_object* v_factors_677_; lean_object* v_fallback_678_; lean_object* v___x_679_; lean_object* v___x_680_; uint8_t v___x_681_; 
lean_inc_ref_n(v_p_665_, 2);
v_factors_675_ = lp_Hex_Hex_ZPoly_factorize(v_p_665_);
v_scalar_676_ = lean_ctor_get(v_factors_675_, 0);
lean_inc(v_scalar_676_);
v_factors_677_ = lean_ctor_get(v_factors_675_, 1);
lean_inc_ref(v_factors_677_);
lean_inc_ref(v_factors_675_);
v_fallback_678_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___boxed), 5, 4);
lean_closure_set(v_fallback_678_, 0, v_p_665_);
lean_closure_set(v_fallback_678_, 1, v_factors_675_);
lean_closure_set(v_fallback_678_, 2, lean_box(0));
lean_closure_set(v_fallback_678_, 3, v_snd_664_);
v___x_679_ = lean_unsigned_to_nat(0u);
v___x_680_ = lean_array_get_size(v_factors_677_);
v___x_681_ = lean_nat_dec_lt(v___x_679_, v___x_680_);
if (v___x_681_ == 0)
{
lean_object* v___x_683_; 
lean_dec_ref(v_factors_677_);
lean_dec(v_scalar_676_);
lean_dec_ref(v_factors_675_);
if (v_isShared_669_ == 0)
{
lean_ctor_set(v___x_668_, 1, v_fallback_678_);
lean_ctor_set(v___x_668_, 0, v_seen_670_);
v___x_683_ = v___x_668_;
goto v_reusejp_682_;
}
else
{
lean_object* v_reuseFailAlloc_684_; 
v_reuseFailAlloc_684_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_684_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_684_, 1, v_fallback_678_);
v___x_683_ = v_reuseFailAlloc_684_;
goto v_reusejp_682_;
}
v_reusejp_682_:
{
v___y_655_ = v___x_683_;
goto v___jp_654_;
}
}
else
{
if (v___x_681_ == 0)
{
lean_object* v___x_686_; 
lean_dec_ref(v_factors_677_);
lean_dec(v_scalar_676_);
lean_dec_ref(v_factors_675_);
if (v_isShared_669_ == 0)
{
lean_ctor_set(v___x_668_, 1, v_fallback_678_);
lean_ctor_set(v___x_668_, 0, v_seen_670_);
v___x_686_ = v___x_668_;
goto v_reusejp_685_;
}
else
{
lean_object* v_reuseFailAlloc_687_; 
v_reuseFailAlloc_687_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_687_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_687_, 1, v_fallback_678_);
v___x_686_ = v_reuseFailAlloc_687_;
goto v_reusejp_685_;
}
v_reusejp_685_:
{
v___y_655_ = v___x_686_;
goto v___jp_654_;
}
}
else
{
size_t v___x_688_; size_t v___x_689_; uint8_t v___x_690_; 
v___x_688_ = ((size_t)0ULL);
v___x_689_ = lean_usize_of_nat(v___x_680_);
v___x_690_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1(v_p_665_, v_factors_677_, v___x_688_, v___x_689_);
if (v___x_690_ == 0)
{
lean_object* v___x_692_; 
lean_dec_ref(v_factors_677_);
lean_dec(v_scalar_676_);
lean_dec_ref(v_factors_675_);
if (v_isShared_669_ == 0)
{
lean_ctor_set(v___x_668_, 1, v_fallback_678_);
lean_ctor_set(v___x_668_, 0, v_seen_670_);
v___x_692_ = v___x_668_;
goto v_reusejp_691_;
}
else
{
lean_object* v_reuseFailAlloc_693_; 
v_reuseFailAlloc_693_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_693_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_693_, 1, v_fallback_678_);
v___x_692_ = v_reuseFailAlloc_693_;
goto v_reusejp_691_;
}
v_reusejp_691_:
{
v___y_655_ = v___x_692_;
goto v___jp_654_;
}
}
else
{
lean_object* v___x_694_; lean_object* v___x_695_; uint8_t v___x_696_; 
v___x_694_ = lean_nat_abs(v_scalar_676_);
lean_dec(v_scalar_676_);
v___x_695_ = lean_unsigned_to_nat(1u);
v___x_696_ = lean_nat_dec_eq(v___x_694_, v___x_695_);
lean_dec(v___x_694_);
if (v___x_696_ == 0)
{
lean_object* v___x_698_; 
lean_dec_ref(v_factors_677_);
lean_dec_ref(v_factors_675_);
if (v_isShared_669_ == 0)
{
lean_ctor_set(v___x_668_, 1, v_fallback_678_);
lean_ctor_set(v___x_668_, 0, v_seen_670_);
v___x_698_ = v___x_668_;
goto v_reusejp_697_;
}
else
{
lean_object* v_reuseFailAlloc_699_; 
v_reuseFailAlloc_699_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_699_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_699_, 1, v_fallback_678_);
v___x_698_ = v_reuseFailAlloc_699_;
goto v_reusejp_697_;
}
v_reusejp_697_:
{
v___y_655_ = v___x_698_;
goto v___jp_654_;
}
}
else
{
uint8_t v___x_700_; 
v___x_700_ = lean_nat_dec_eq(v___x_680_, v___x_695_);
if (v___x_700_ == 0)
{
lean_object* v___x_702_; 
lean_dec_ref(v_factors_677_);
lean_dec_ref(v_factors_675_);
if (v_isShared_669_ == 0)
{
lean_ctor_set(v___x_668_, 1, v_fallback_678_);
lean_ctor_set(v___x_668_, 0, v_seen_670_);
v___x_702_ = v___x_668_;
goto v_reusejp_701_;
}
else
{
lean_object* v_reuseFailAlloc_703_; 
v_reuseFailAlloc_703_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_703_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_703_, 1, v_fallback_678_);
v___x_702_ = v_reuseFailAlloc_703_;
goto v_reusejp_701_;
}
v_reusejp_701_:
{
v___y_655_ = v___x_702_;
goto v___jp_654_;
}
}
else
{
lean_object* v___x_704_; 
v___x_704_ = lean_array_to_list(v_factors_677_);
if (lean_obj_tag(v___x_704_) == 1)
{
lean_object* v_tail_705_; 
v_tail_705_ = lean_ctor_get(v___x_704_, 1);
lean_inc(v_tail_705_);
if (lean_obj_tag(v_tail_705_) == 0)
{
lean_object* v_head_706_; lean_object* v_snd_707_; lean_object* v___x_709_; uint8_t v_isShared_710_; uint8_t v_isSharedCheck_739_; 
lean_del_object(v___x_668_);
v_head_706_ = lean_ctor_get(v___x_704_, 0);
lean_inc(v_head_706_);
lean_dec_ref_known(v___x_704_, 2);
v_snd_707_ = lean_ctor_get(v_head_706_, 1);
v_isSharedCheck_739_ = !lean_is_exclusive(v_head_706_);
if (v_isSharedCheck_739_ == 0)
{
lean_object* v_unused_740_; 
v_unused_740_ = lean_ctor_get(v_head_706_, 0);
lean_dec(v_unused_740_);
v___x_709_ = v_head_706_;
v_isShared_710_ = v_isSharedCheck_739_;
goto v_resetjp_708_;
}
else
{
lean_inc(v_snd_707_);
lean_dec(v_head_706_);
v___x_709_ = lean_box(0);
v_isShared_710_ = v_isSharedCheck_739_;
goto v_resetjp_708_;
}
v_resetjp_708_:
{
uint8_t v___x_711_; 
v___x_711_ = lean_nat_dec_eq(v_snd_707_, v___x_695_);
lean_dec(v_snd_707_);
if (v___x_711_ == 0)
{
lean_object* v___x_713_; 
lean_dec_ref(v_factors_675_);
if (v_isShared_710_ == 0)
{
lean_ctor_set(v___x_709_, 1, v_fallback_678_);
lean_ctor_set(v___x_709_, 0, v_seen_670_);
v___x_713_ = v___x_709_;
goto v_reusejp_712_;
}
else
{
lean_object* v_reuseFailAlloc_714_; 
v_reuseFailAlloc_714_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_714_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_714_, 1, v_fallback_678_);
v___x_713_ = v_reuseFailAlloc_714_;
goto v_reusejp_712_;
}
v_reusejp_712_:
{
v___y_655_ = v___x_713_;
goto v___jp_654_;
}
}
else
{
lean_object* v___x_715_; lean_object* v___x_716_; uint8_t v___x_717_; lean_object* v___x_718_; 
v___x_715_ = lp_Hex_Hex_separationDepth(v_p_665_);
v___x_716_ = lean_nat_to_int(v___x_715_);
v___x_717_ = 2;
lean_inc_ref(v_p_665_);
v___x_718_ = lp_Hex_Hex_ZPoly_isolateComplexRoots_x3f___redArg(v_p_665_, v___x_716_, v___x_717_);
if (lean_obj_tag(v___x_718_) == 0)
{
lean_object* v___x_720_; 
lean_dec_ref(v_factors_675_);
if (v_isShared_710_ == 0)
{
lean_ctor_set(v___x_709_, 1, v_fallback_678_);
lean_ctor_set(v___x_709_, 0, v_seen_670_);
v___x_720_ = v___x_709_;
goto v_reusejp_719_;
}
else
{
lean_object* v_reuseFailAlloc_721_; 
v_reuseFailAlloc_721_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_721_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_721_, 1, v_fallback_678_);
v___x_720_ = v_reuseFailAlloc_721_;
goto v_reusejp_719_;
}
v_reusejp_719_:
{
v___y_655_ = v___x_720_;
goto v___jp_654_;
}
}
else
{
lean_object* v_val_722_; size_t v_sz_723_; lean_object* v___x_724_; 
v_val_722_ = lean_ctor_get(v___x_718_, 0);
lean_inc_n(v_val_722_, 2);
lean_dec_ref_known(v___x_718_, 1);
v_sz_723_ = lean_array_size(v_val_722_);
v___x_724_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__2(v_p_665_, v_sz_723_, v___x_688_, v_val_722_);
if (lean_obj_tag(v___x_724_) == 0)
{
lean_object* v___x_726_; 
lean_dec(v_val_722_);
lean_dec_ref(v_factors_675_);
if (v_isShared_710_ == 0)
{
lean_ctor_set(v___x_709_, 1, v_fallback_678_);
lean_ctor_set(v___x_709_, 0, v_seen_670_);
v___x_726_ = v___x_709_;
goto v_reusejp_725_;
}
else
{
lean_object* v_reuseFailAlloc_727_; 
v_reuseFailAlloc_727_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_727_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_727_, 1, v_fallback_678_);
v___x_726_ = v_reuseFailAlloc_727_;
goto v_reusejp_725_;
}
v_reusejp_725_:
{
v___y_655_ = v___x_726_;
goto v___jp_654_;
}
}
else
{
lean_object* v_val_728_; size_t v_sz_729_; lean_object* v___x_730_; 
v_val_728_ = lean_ctor_get(v___x_724_, 0);
lean_inc_n(v_val_728_, 2);
lean_dec_ref_known(v___x_724_, 1);
v_sz_729_ = lean_array_size(v_val_728_);
lean_inc_ref(v_p_665_);
v___x_730_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3(v_p_665_, v_sz_729_, v___x_688_, v_val_728_);
if (lean_obj_tag(v___x_730_) == 0)
{
lean_object* v___x_732_; 
lean_dec(v_val_728_);
lean_dec(v_val_722_);
lean_dec_ref(v_factors_675_);
if (v_isShared_710_ == 0)
{
lean_ctor_set(v___x_709_, 1, v_fallback_678_);
lean_ctor_set(v___x_709_, 0, v_seen_670_);
v___x_732_ = v___x_709_;
goto v_reusejp_731_;
}
else
{
lean_object* v_reuseFailAlloc_733_; 
v_reuseFailAlloc_733_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_733_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_733_, 1, v_fallback_678_);
v___x_732_ = v_reuseFailAlloc_733_;
goto v_reusejp_731_;
}
v_reusejp_731_:
{
v___y_655_ = v___x_732_;
goto v___jp_654_;
}
}
else
{
lean_object* v_val_734_; lean_object* v___x_735_; lean_object* v___x_737_; 
v_val_734_ = lean_ctor_get(v___x_730_, 0);
lean_inc(v_val_734_);
lean_dec_ref_known(v___x_730_, 1);
lean_inc_ref(v_p_665_);
v___x_735_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___boxed), 13, 12);
lean_closure_set(v___x_735_, 0, v_p_665_);
lean_closure_set(v___x_735_, 1, lean_box(0));
lean_closure_set(v___x_735_, 2, v_val_722_);
lean_closure_set(v___x_735_, 3, v_val_728_);
lean_closure_set(v___x_735_, 4, lean_box(0));
lean_closure_set(v___x_735_, 5, lean_box(0));
lean_closure_set(v___x_735_, 6, v_factors_675_);
lean_closure_set(v___x_735_, 7, lean_box(0));
lean_closure_set(v___x_735_, 8, lean_box(0));
lean_closure_set(v___x_735_, 9, v_val_734_);
lean_closure_set(v___x_735_, 10, lean_box(0));
lean_closure_set(v___x_735_, 11, v_fallback_678_);
if (v_isShared_710_ == 0)
{
lean_ctor_set(v___x_709_, 1, v___x_735_);
lean_ctor_set(v___x_709_, 0, v_seen_670_);
v___x_737_ = v___x_709_;
goto v_reusejp_736_;
}
else
{
lean_object* v_reuseFailAlloc_738_; 
v_reuseFailAlloc_738_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_738_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_738_, 1, v___x_735_);
v___x_737_ = v_reuseFailAlloc_738_;
goto v_reusejp_736_;
}
v_reusejp_736_:
{
v___y_655_ = v___x_737_;
goto v___jp_654_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_742_; 
lean_dec_ref_known(v___x_704_, 2);
lean_dec(v_tail_705_);
lean_dec_ref(v_factors_675_);
if (v_isShared_669_ == 0)
{
lean_ctor_set(v___x_668_, 1, v_fallback_678_);
lean_ctor_set(v___x_668_, 0, v_seen_670_);
v___x_742_ = v___x_668_;
goto v_reusejp_741_;
}
else
{
lean_object* v_reuseFailAlloc_743_; 
v_reuseFailAlloc_743_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_743_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_743_, 1, v_fallback_678_);
v___x_742_ = v_reuseFailAlloc_743_;
goto v_reusejp_741_;
}
v_reusejp_741_:
{
v___y_655_ = v___x_742_;
goto v___jp_654_;
}
}
}
else
{
lean_object* v___x_745_; 
lean_dec(v___x_704_);
lean_dec_ref(v_factors_675_);
if (v_isShared_669_ == 0)
{
lean_ctor_set(v___x_668_, 1, v_fallback_678_);
lean_ctor_set(v___x_668_, 0, v_seen_670_);
v___x_745_ = v___x_668_;
goto v_reusejp_744_;
}
else
{
lean_object* v_reuseFailAlloc_746_; 
v_reuseFailAlloc_746_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_746_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_746_, 1, v_fallback_678_);
v___x_745_ = v_reuseFailAlloc_746_;
goto v_reusejp_744_;
}
v_reusejp_744_:
{
v___y_655_ = v___x_745_;
goto v___jp_654_;
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_748_; 
if (v_isShared_669_ == 0)
{
lean_ctor_set(v___x_668_, 0, v_seen_670_);
v___x_748_ = v___x_668_;
goto v_reusejp_747_;
}
else
{
lean_object* v_reuseFailAlloc_749_; 
v_reuseFailAlloc_749_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_749_, 0, v_seen_670_);
lean_ctor_set(v_reuseFailAlloc_749_, 1, v_snd_664_);
v___x_748_ = v_reuseFailAlloc_749_;
goto v_reusejp_747_;
}
v_reusejp_747_:
{
v___y_655_ = v___x_748_;
goto v___jp_654_;
}
}
}
}
}
else
{
v___y_655_ = v_b_653_;
goto v___jp_654_;
}
}
}
else
{
return v_b_653_;
}
v___jp_654_:
{
size_t v___x_656_; size_t v___x_657_; 
v___x_656_ = ((size_t)1ULL);
v___x_657_ = lean_usize_add(v_i_651_, v___x_656_);
v_i_651_ = v___x_657_;
v_b_653_ = v___y_655_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5_spec__7___boxed(lean_object* v_roots_759_, lean_object* v_as_760_, lean_object* v_i_761_, lean_object* v_stop_762_, lean_object* v_b_763_){
_start:
{
size_t v_i_boxed_764_; size_t v_stop_boxed_765_; lean_object* v_res_766_; 
v_i_boxed_764_ = lean_unbox_usize(v_i_761_);
lean_dec(v_i_761_);
v_stop_boxed_765_ = lean_unbox_usize(v_stop_762_);
lean_dec(v_stop_762_);
v_res_766_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5_spec__7(v_roots_759_, v_as_760_, v_i_boxed_764_, v_stop_boxed_765_, v_b_763_);
lean_dec_ref(v_as_760_);
lean_dec_ref(v_roots_759_);
return v_res_766_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(lean_object* v_roots_767_, lean_object* v_as_768_, size_t v_i_769_, size_t v_stop_770_, lean_object* v_b_771_){
_start:
{
lean_object* v___y_773_; uint8_t v___x_777_; 
v___x_777_ = lean_usize_dec_eq(v_i_769_, v_stop_770_);
if (v___x_777_ == 0)
{
lean_object* v___x_778_; lean_object* v_root_779_; uint8_t v___x_780_; 
v___x_778_ = lean_array_uget_borrowed(v_as_768_, v_i_769_);
v_root_779_ = lean_ctor_get(v___x_778_, 0);
v___x_780_ = lp_Hex_Hex_AlgebraicRoot_isReal(v_root_779_);
if (v___x_780_ == 0)
{
v___y_773_ = v_b_771_;
goto v___jp_772_;
}
else
{
lean_object* v_fst_781_; lean_object* v_snd_782_; lean_object* v_p_783_; uint8_t v___x_784_; 
v_fst_781_ = lean_ctor_get(v_b_771_, 0);
v_snd_782_ = lean_ctor_get(v_b_771_, 1);
v_p_783_ = lean_ctor_get(v_root_779_, 0);
v___x_784_ = lp_Hex_Array_contains___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__0(v_fst_781_, v_p_783_);
if (v___x_784_ == 0)
{
lean_object* v___x_786_; uint8_t v_isShared_787_; uint8_t v_isSharedCheck_874_; 
lean_inc(v_snd_782_);
lean_inc(v_fst_781_);
v_isSharedCheck_874_ = !lean_is_exclusive(v_b_771_);
if (v_isSharedCheck_874_ == 0)
{
lean_object* v_unused_875_; lean_object* v_unused_876_; 
v_unused_875_ = lean_ctor_get(v_b_771_, 1);
lean_dec(v_unused_875_);
v_unused_876_ = lean_ctor_get(v_b_771_, 0);
lean_dec(v_unused_876_);
v___x_786_ = v_b_771_;
v_isShared_787_ = v_isSharedCheck_874_;
goto v_resetjp_785_;
}
else
{
lean_dec(v_b_771_);
v___x_786_ = lean_box(0);
v_isShared_787_ = v_isSharedCheck_874_;
goto v_resetjp_785_;
}
v_resetjp_785_:
{
lean_object* v_seen_788_; lean_object* v___y_790_; lean_object* v___x_868_; lean_object* v___x_869_; uint8_t v___x_870_; 
lean_inc_ref(v_p_783_);
v_seen_788_ = lean_array_push(v_fst_781_, v_p_783_);
v___x_868_ = lean_unsigned_to_nat(0u);
v___x_869_ = lean_array_get_size(v_roots_767_);
v___x_870_ = lean_nat_dec_lt(v___x_868_, v___x_869_);
if (v___x_870_ == 0)
{
v___y_790_ = v___x_868_;
goto v___jp_789_;
}
else
{
size_t v___x_871_; size_t v___x_872_; lean_object* v___x_873_; 
v___x_871_ = lean_usize_of_nat(v___x_869_);
v___x_872_ = ((size_t)0ULL);
v___x_873_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__4(v___x_784_, v_p_783_, v_roots_767_, v___x_871_, v___x_872_, v___x_868_);
v___y_790_ = v___x_873_;
goto v___jp_789_;
}
v___jp_789_:
{
lean_object* v___x_791_; uint8_t v___x_792_; 
v___x_791_ = lean_unsigned_to_nat(2u);
v___x_792_ = lean_nat_dec_lt(v___y_790_, v___x_791_);
lean_dec(v___y_790_);
if (v___x_792_ == 0)
{
lean_object* v_factors_793_; lean_object* v_scalar_794_; lean_object* v_factors_795_; lean_object* v_fallback_796_; lean_object* v___x_797_; lean_object* v___x_798_; uint8_t v___x_799_; 
lean_inc_ref_n(v_p_783_, 2);
v_factors_793_ = lp_Hex_Hex_ZPoly_factorize(v_p_783_);
v_scalar_794_ = lean_ctor_get(v_factors_793_, 0);
lean_inc(v_scalar_794_);
v_factors_795_ = lean_ctor_get(v_factors_793_, 1);
lean_inc_ref(v_factors_795_);
lean_inc_ref(v_factors_793_);
v_fallback_796_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_factorPicker___boxed), 5, 4);
lean_closure_set(v_fallback_796_, 0, v_p_783_);
lean_closure_set(v_fallback_796_, 1, v_factors_793_);
lean_closure_set(v_fallback_796_, 2, lean_box(0));
lean_closure_set(v_fallback_796_, 3, v_snd_782_);
v___x_797_ = lean_unsigned_to_nat(0u);
v___x_798_ = lean_array_get_size(v_factors_795_);
v___x_799_ = lean_nat_dec_lt(v___x_797_, v___x_798_);
if (v___x_799_ == 0)
{
lean_object* v___x_801_; 
lean_dec_ref(v_factors_795_);
lean_dec(v_scalar_794_);
lean_dec_ref(v_factors_793_);
if (v_isShared_787_ == 0)
{
lean_ctor_set(v___x_786_, 1, v_fallback_796_);
lean_ctor_set(v___x_786_, 0, v_seen_788_);
v___x_801_ = v___x_786_;
goto v_reusejp_800_;
}
else
{
lean_object* v_reuseFailAlloc_802_; 
v_reuseFailAlloc_802_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_802_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_802_, 1, v_fallback_796_);
v___x_801_ = v_reuseFailAlloc_802_;
goto v_reusejp_800_;
}
v_reusejp_800_:
{
v___y_773_ = v___x_801_;
goto v___jp_772_;
}
}
else
{
if (v___x_799_ == 0)
{
lean_object* v___x_804_; 
lean_dec_ref(v_factors_795_);
lean_dec(v_scalar_794_);
lean_dec_ref(v_factors_793_);
if (v_isShared_787_ == 0)
{
lean_ctor_set(v___x_786_, 1, v_fallback_796_);
lean_ctor_set(v___x_786_, 0, v_seen_788_);
v___x_804_ = v___x_786_;
goto v_reusejp_803_;
}
else
{
lean_object* v_reuseFailAlloc_805_; 
v_reuseFailAlloc_805_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_805_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_805_, 1, v_fallback_796_);
v___x_804_ = v_reuseFailAlloc_805_;
goto v_reusejp_803_;
}
v_reusejp_803_:
{
v___y_773_ = v___x_804_;
goto v___jp_772_;
}
}
else
{
size_t v___x_806_; size_t v___x_807_; uint8_t v___x_808_; 
v___x_806_ = ((size_t)0ULL);
v___x_807_ = lean_usize_of_nat(v___x_798_);
v___x_808_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__1(v_p_783_, v_factors_795_, v___x_806_, v___x_807_);
if (v___x_808_ == 0)
{
lean_object* v___x_810_; 
lean_dec_ref(v_factors_795_);
lean_dec(v_scalar_794_);
lean_dec_ref(v_factors_793_);
if (v_isShared_787_ == 0)
{
lean_ctor_set(v___x_786_, 1, v_fallback_796_);
lean_ctor_set(v___x_786_, 0, v_seen_788_);
v___x_810_ = v___x_786_;
goto v_reusejp_809_;
}
else
{
lean_object* v_reuseFailAlloc_811_; 
v_reuseFailAlloc_811_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_811_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_811_, 1, v_fallback_796_);
v___x_810_ = v_reuseFailAlloc_811_;
goto v_reusejp_809_;
}
v_reusejp_809_:
{
v___y_773_ = v___x_810_;
goto v___jp_772_;
}
}
else
{
lean_object* v___x_812_; lean_object* v___x_813_; uint8_t v___x_814_; 
v___x_812_ = lean_nat_abs(v_scalar_794_);
lean_dec(v_scalar_794_);
v___x_813_ = lean_unsigned_to_nat(1u);
v___x_814_ = lean_nat_dec_eq(v___x_812_, v___x_813_);
lean_dec(v___x_812_);
if (v___x_814_ == 0)
{
lean_object* v___x_816_; 
lean_dec_ref(v_factors_795_);
lean_dec_ref(v_factors_793_);
if (v_isShared_787_ == 0)
{
lean_ctor_set(v___x_786_, 1, v_fallback_796_);
lean_ctor_set(v___x_786_, 0, v_seen_788_);
v___x_816_ = v___x_786_;
goto v_reusejp_815_;
}
else
{
lean_object* v_reuseFailAlloc_817_; 
v_reuseFailAlloc_817_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_817_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_817_, 1, v_fallback_796_);
v___x_816_ = v_reuseFailAlloc_817_;
goto v_reusejp_815_;
}
v_reusejp_815_:
{
v___y_773_ = v___x_816_;
goto v___jp_772_;
}
}
else
{
uint8_t v___x_818_; 
v___x_818_ = lean_nat_dec_eq(v___x_798_, v___x_813_);
if (v___x_818_ == 0)
{
lean_object* v___x_820_; 
lean_dec_ref(v_factors_795_);
lean_dec_ref(v_factors_793_);
if (v_isShared_787_ == 0)
{
lean_ctor_set(v___x_786_, 1, v_fallback_796_);
lean_ctor_set(v___x_786_, 0, v_seen_788_);
v___x_820_ = v___x_786_;
goto v_reusejp_819_;
}
else
{
lean_object* v_reuseFailAlloc_821_; 
v_reuseFailAlloc_821_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_821_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_821_, 1, v_fallback_796_);
v___x_820_ = v_reuseFailAlloc_821_;
goto v_reusejp_819_;
}
v_reusejp_819_:
{
v___y_773_ = v___x_820_;
goto v___jp_772_;
}
}
else
{
lean_object* v___x_822_; 
v___x_822_ = lean_array_to_list(v_factors_795_);
if (lean_obj_tag(v___x_822_) == 1)
{
lean_object* v_tail_823_; 
v_tail_823_ = lean_ctor_get(v___x_822_, 1);
lean_inc(v_tail_823_);
if (lean_obj_tag(v_tail_823_) == 0)
{
lean_object* v_head_824_; lean_object* v_snd_825_; lean_object* v___x_827_; uint8_t v_isShared_828_; uint8_t v_isSharedCheck_857_; 
lean_del_object(v___x_786_);
v_head_824_ = lean_ctor_get(v___x_822_, 0);
lean_inc(v_head_824_);
lean_dec_ref_known(v___x_822_, 2);
v_snd_825_ = lean_ctor_get(v_head_824_, 1);
v_isSharedCheck_857_ = !lean_is_exclusive(v_head_824_);
if (v_isSharedCheck_857_ == 0)
{
lean_object* v_unused_858_; 
v_unused_858_ = lean_ctor_get(v_head_824_, 0);
lean_dec(v_unused_858_);
v___x_827_ = v_head_824_;
v_isShared_828_ = v_isSharedCheck_857_;
goto v_resetjp_826_;
}
else
{
lean_inc(v_snd_825_);
lean_dec(v_head_824_);
v___x_827_ = lean_box(0);
v_isShared_828_ = v_isSharedCheck_857_;
goto v_resetjp_826_;
}
v_resetjp_826_:
{
uint8_t v___x_829_; 
v___x_829_ = lean_nat_dec_eq(v_snd_825_, v___x_813_);
lean_dec(v_snd_825_);
if (v___x_829_ == 0)
{
lean_object* v___x_831_; 
lean_dec_ref(v_factors_793_);
if (v_isShared_828_ == 0)
{
lean_ctor_set(v___x_827_, 1, v_fallback_796_);
lean_ctor_set(v___x_827_, 0, v_seen_788_);
v___x_831_ = v___x_827_;
goto v_reusejp_830_;
}
else
{
lean_object* v_reuseFailAlloc_832_; 
v_reuseFailAlloc_832_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_832_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_832_, 1, v_fallback_796_);
v___x_831_ = v_reuseFailAlloc_832_;
goto v_reusejp_830_;
}
v_reusejp_830_:
{
v___y_773_ = v___x_831_;
goto v___jp_772_;
}
}
else
{
lean_object* v___x_833_; lean_object* v___x_834_; uint8_t v___x_835_; lean_object* v___x_836_; 
v___x_833_ = lp_Hex_Hex_separationDepth(v_p_783_);
v___x_834_ = lean_nat_to_int(v___x_833_);
v___x_835_ = 2;
lean_inc_ref(v_p_783_);
v___x_836_ = lp_Hex_Hex_ZPoly_isolateComplexRoots_x3f___redArg(v_p_783_, v___x_834_, v___x_835_);
if (lean_obj_tag(v___x_836_) == 0)
{
lean_object* v___x_838_; 
lean_dec_ref(v_factors_793_);
if (v_isShared_828_ == 0)
{
lean_ctor_set(v___x_827_, 1, v_fallback_796_);
lean_ctor_set(v___x_827_, 0, v_seen_788_);
v___x_838_ = v___x_827_;
goto v_reusejp_837_;
}
else
{
lean_object* v_reuseFailAlloc_839_; 
v_reuseFailAlloc_839_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_839_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_839_, 1, v_fallback_796_);
v___x_838_ = v_reuseFailAlloc_839_;
goto v_reusejp_837_;
}
v_reusejp_837_:
{
v___y_773_ = v___x_838_;
goto v___jp_772_;
}
}
else
{
lean_object* v_val_840_; size_t v_sz_841_; lean_object* v___x_842_; 
v_val_840_ = lean_ctor_get(v___x_836_, 0);
lean_inc_n(v_val_840_, 2);
lean_dec_ref_known(v___x_836_, 1);
v_sz_841_ = lean_array_size(v_val_840_);
v___x_842_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__2(v_p_783_, v_sz_841_, v___x_806_, v_val_840_);
if (lean_obj_tag(v___x_842_) == 0)
{
lean_object* v___x_844_; 
lean_dec(v_val_840_);
lean_dec_ref(v_factors_793_);
if (v_isShared_828_ == 0)
{
lean_ctor_set(v___x_827_, 1, v_fallback_796_);
lean_ctor_set(v___x_827_, 0, v_seen_788_);
v___x_844_ = v___x_827_;
goto v_reusejp_843_;
}
else
{
lean_object* v_reuseFailAlloc_845_; 
v_reuseFailAlloc_845_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_845_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_845_, 1, v_fallback_796_);
v___x_844_ = v_reuseFailAlloc_845_;
goto v_reusejp_843_;
}
v_reusejp_843_:
{
v___y_773_ = v___x_844_;
goto v___jp_772_;
}
}
else
{
lean_object* v_val_846_; size_t v_sz_847_; lean_object* v___x_848_; 
v_val_846_ = lean_ctor_get(v___x_842_, 0);
lean_inc_n(v_val_846_, 2);
lean_dec_ref_known(v___x_842_, 1);
v_sz_847_ = lean_array_size(v_val_846_);
lean_inc_ref(v_p_783_);
v___x_848_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__3(v_p_783_, v_sz_847_, v___x_806_, v_val_846_);
if (lean_obj_tag(v___x_848_) == 0)
{
lean_object* v___x_850_; 
lean_dec(v_val_846_);
lean_dec(v_val_840_);
lean_dec_ref(v_factors_793_);
if (v_isShared_828_ == 0)
{
lean_ctor_set(v___x_827_, 1, v_fallback_796_);
lean_ctor_set(v___x_827_, 0, v_seen_788_);
v___x_850_ = v___x_827_;
goto v_reusejp_849_;
}
else
{
lean_object* v_reuseFailAlloc_851_; 
v_reuseFailAlloc_851_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_851_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_851_, 1, v_fallback_796_);
v___x_850_ = v_reuseFailAlloc_851_;
goto v_reusejp_849_;
}
v_reusejp_849_:
{
v___y_773_ = v___x_850_;
goto v___jp_772_;
}
}
else
{
lean_object* v_val_852_; lean_object* v___x_853_; lean_object* v___x_855_; 
v_val_852_ = lean_ctor_get(v___x_848_, 0);
lean_inc(v_val_852_);
lean_dec_ref_known(v___x_848_, 1);
lean_inc_ref(v_p_783_);
v___x_853_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_rootPicker___boxed), 13, 12);
lean_closure_set(v___x_853_, 0, v_p_783_);
lean_closure_set(v___x_853_, 1, lean_box(0));
lean_closure_set(v___x_853_, 2, v_val_840_);
lean_closure_set(v___x_853_, 3, v_val_846_);
lean_closure_set(v___x_853_, 4, lean_box(0));
lean_closure_set(v___x_853_, 5, lean_box(0));
lean_closure_set(v___x_853_, 6, v_factors_793_);
lean_closure_set(v___x_853_, 7, lean_box(0));
lean_closure_set(v___x_853_, 8, lean_box(0));
lean_closure_set(v___x_853_, 9, v_val_852_);
lean_closure_set(v___x_853_, 10, lean_box(0));
lean_closure_set(v___x_853_, 11, v_fallback_796_);
if (v_isShared_828_ == 0)
{
lean_ctor_set(v___x_827_, 1, v___x_853_);
lean_ctor_set(v___x_827_, 0, v_seen_788_);
v___x_855_ = v___x_827_;
goto v_reusejp_854_;
}
else
{
lean_object* v_reuseFailAlloc_856_; 
v_reuseFailAlloc_856_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_856_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_856_, 1, v___x_853_);
v___x_855_ = v_reuseFailAlloc_856_;
goto v_reusejp_854_;
}
v_reusejp_854_:
{
v___y_773_ = v___x_855_;
goto v___jp_772_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_860_; 
lean_dec(v_tail_823_);
lean_dec_ref_known(v___x_822_, 2);
lean_dec_ref(v_factors_793_);
if (v_isShared_787_ == 0)
{
lean_ctor_set(v___x_786_, 1, v_fallback_796_);
lean_ctor_set(v___x_786_, 0, v_seen_788_);
v___x_860_ = v___x_786_;
goto v_reusejp_859_;
}
else
{
lean_object* v_reuseFailAlloc_861_; 
v_reuseFailAlloc_861_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_861_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_861_, 1, v_fallback_796_);
v___x_860_ = v_reuseFailAlloc_861_;
goto v_reusejp_859_;
}
v_reusejp_859_:
{
v___y_773_ = v___x_860_;
goto v___jp_772_;
}
}
}
else
{
lean_object* v___x_863_; 
lean_dec(v___x_822_);
lean_dec_ref(v_factors_793_);
if (v_isShared_787_ == 0)
{
lean_ctor_set(v___x_786_, 1, v_fallback_796_);
lean_ctor_set(v___x_786_, 0, v_seen_788_);
v___x_863_ = v___x_786_;
goto v_reusejp_862_;
}
else
{
lean_object* v_reuseFailAlloc_864_; 
v_reuseFailAlloc_864_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_864_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_864_, 1, v_fallback_796_);
v___x_863_ = v_reuseFailAlloc_864_;
goto v_reusejp_862_;
}
v_reusejp_862_:
{
v___y_773_ = v___x_863_;
goto v___jp_772_;
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_866_; 
if (v_isShared_787_ == 0)
{
lean_ctor_set(v___x_786_, 0, v_seen_788_);
v___x_866_ = v___x_786_;
goto v_reusejp_865_;
}
else
{
lean_object* v_reuseFailAlloc_867_; 
v_reuseFailAlloc_867_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_867_, 0, v_seen_788_);
lean_ctor_set(v_reuseFailAlloc_867_, 1, v_snd_782_);
v___x_866_ = v_reuseFailAlloc_867_;
goto v_reusejp_865_;
}
v_reusejp_865_:
{
v___y_773_ = v___x_866_;
goto v___jp_772_;
}
}
}
}
}
else
{
v___y_773_ = v_b_771_;
goto v___jp_772_;
}
}
}
else
{
return v_b_771_;
}
v___jp_772_:
{
size_t v___x_774_; size_t v___x_775_; lean_object* v___x_776_; 
v___x_774_ = ((size_t)1ULL);
v___x_775_ = lean_usize_add(v_i_769_, v___x_774_);
v___x_776_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5_spec__7(v_roots_767_, v_as_768_, v___x_775_, v_stop_770_, v___y_773_);
return v___x_776_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5___boxed(lean_object* v_roots_877_, lean_object* v_as_878_, lean_object* v_i_879_, lean_object* v_stop_880_, lean_object* v_b_881_){
_start:
{
size_t v_i_boxed_882_; size_t v_stop_boxed_883_; lean_object* v_res_884_; 
v_i_boxed_882_ = lean_unbox_usize(v_i_879_);
lean_dec(v_i_879_);
v_stop_boxed_883_ = lean_unbox_usize(v_stop_880_);
lean_dec(v_stop_880_);
v_res_884_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(v_roots_877_, v_as_878_, v_i_boxed_882_, v_stop_boxed_883_, v_b_881_);
lean_dec_ref(v_as_878_);
lean_dec_ref(v_roots_877_);
return v_res_884_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors(lean_object* v_roots_891_){
_start:
{
lean_object* v___x_892_; lean_object* v___x_893_; lean_object* v___x_894_; uint8_t v___x_895_; 
v___x_892_ = lean_unsigned_to_nat(0u);
v___x_893_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___closed__2));
v___x_894_ = lean_array_get_size(v_roots_891_);
v___x_895_ = lean_nat_dec_lt(v___x_892_, v___x_894_);
if (v___x_895_ == 0)
{
return v___x_893_;
}
else
{
uint8_t v___x_896_; 
v___x_896_ = lean_nat_dec_le(v___x_894_, v___x_894_);
if (v___x_896_ == 0)
{
if (v___x_895_ == 0)
{
return v___x_893_;
}
else
{
size_t v___x_897_; size_t v___x_898_; lean_object* v___x_899_; 
v___x_897_ = ((size_t)0ULL);
v___x_898_ = lean_usize_of_nat(v___x_894_);
v___x_899_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(v_roots_891_, v_roots_891_, v___x_897_, v___x_898_, v___x_893_);
return v___x_899_;
}
}
else
{
size_t v___x_900_; size_t v___x_901_; lean_object* v___x_902_; 
v___x_900_ = ((size_t)0ULL);
v___x_901_ = lean_usize_of_nat(v___x_894_);
v___x_902_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_RealAlgebraicPoly_Internal_rootSelectors_spec__5(v_roots_891_, v_roots_891_, v___x_900_, v___x_901_, v___x_893_);
return v___x_902_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors___boxed(lean_object* v_roots_903_){
_start:
{
lean_object* v_res_904_; 
v_res_904_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors(v_roots_903_);
lean_dec_ref(v_roots_903_);
return v_res_904_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter___redArg(lean_object* v_x_905_, lean_object* v_h__1_906_, lean_object* v_h__2_907_){
_start:
{
if (lean_obj_tag(v_x_905_) == 1)
{
lean_object* v_tail_908_; 
v_tail_908_ = lean_ctor_get(v_x_905_, 1);
if (lean_obj_tag(v_tail_908_) == 0)
{
lean_object* v_head_909_; lean_object* v___x_910_; 
lean_dec(v_h__2_907_);
v_head_909_ = lean_ctor_get(v_x_905_, 0);
lean_inc(v_head_909_);
lean_dec_ref_known(v_x_905_, 2);
v___x_910_ = lean_apply_1(v_h__1_906_, v_head_909_);
return v___x_910_;
}
else
{
lean_object* v___x_911_; 
lean_dec(v_h__1_906_);
v___x_911_ = lean_apply_2(v_h__2_907_, v_x_905_, lean_box(0));
return v___x_911_;
}
}
else
{
lean_object* v___x_912_; 
lean_dec(v_h__1_906_);
v___x_912_ = lean_apply_2(v_h__2_907_, v_x_905_, lean_box(0));
return v___x_912_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__1_splitter(lean_object* v_motive_913_, lean_object* v_x_914_, lean_object* v_h__1_915_, lean_object* v_h__2_916_){
_start:
{
if (lean_obj_tag(v_x_914_) == 1)
{
lean_object* v_tail_917_; 
v_tail_917_ = lean_ctor_get(v_x_914_, 1);
if (lean_obj_tag(v_tail_917_) == 0)
{
lean_object* v_head_918_; lean_object* v___x_919_; 
lean_dec(v_h__2_916_);
v_head_918_ = lean_ctor_get(v_x_914_, 0);
lean_inc(v_head_918_);
lean_dec_ref_known(v_x_914_, 2);
v___x_919_ = lean_apply_1(v_h__1_915_, v_head_918_);
return v___x_919_;
}
else
{
lean_object* v___x_920_; 
lean_dec(v_h__1_915_);
v___x_920_ = lean_apply_2(v_h__2_916_, v_x_914_, lean_box(0));
return v___x_920_;
}
}
else
{
lean_object* v___x_921_; 
lean_dec(v_h__1_915_);
v___x_921_ = lean_apply_2(v_h__2_916_, v_x_914_, lean_box(0));
return v___x_921_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__7_splitter___redArg(lean_object* v_x_922_, lean_object* v_h__1_923_, lean_object* v_h__2_924_){
_start:
{
if (lean_obj_tag(v_x_922_) == 0)
{
lean_object* v___x_925_; 
lean_dec(v_h__2_924_);
v___x_925_ = lean_apply_1(v_h__1_923_, lean_box(0));
return v___x_925_;
}
else
{
lean_object* v_val_926_; lean_object* v___x_927_; 
lean_dec(v_h__1_923_);
v_val_926_ = lean_ctor_get(v_x_922_, 0);
lean_inc(v_val_926_);
lean_dec_ref_known(v_x_922_, 1);
v___x_927_ = lean_apply_2(v_h__2_924_, v_val_926_, lean_box(0));
return v___x_927_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__7_splitter(lean_object* v_r_928_, lean_object* v_motive_929_, lean_object* v_x_930_, lean_object* v_h__1_931_, lean_object* v_h__2_932_){
_start:
{
if (lean_obj_tag(v_x_930_) == 0)
{
lean_object* v___x_933_; 
lean_dec(v_h__2_932_);
v___x_933_ = lean_apply_1(v_h__1_931_, lean_box(0));
return v___x_933_;
}
else
{
lean_object* v_val_934_; lean_object* v___x_935_; 
lean_dec(v_h__1_931_);
v_val_934_ = lean_ctor_get(v_x_930_, 0);
lean_inc(v_val_934_);
lean_dec_ref_known(v_x_930_, 1);
v___x_935_ = lean_apply_2(v_h__2_932_, v_val_934_, lean_box(0));
return v___x_935_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__7_splitter___boxed(lean_object* v_r_936_, lean_object* v_motive_937_, lean_object* v_x_938_, lean_object* v_h__1_939_, lean_object* v_h__2_940_){
_start:
{
lean_object* v_res_941_; 
v_res_941_ = lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__7_splitter(v_r_936_, v_motive_937_, v_x_938_, v_h__1_939_, v_h__2_940_);
lean_dec_ref(v_r_936_);
return v_res_941_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__5_splitter___redArg(lean_object* v_x_942_, lean_object* v_h__1_943_, lean_object* v_h__2_944_){
_start:
{
if (lean_obj_tag(v_x_942_) == 0)
{
lean_object* v___x_945_; 
lean_dec(v_h__2_944_);
v___x_945_ = lean_apply_1(v_h__1_943_, lean_box(0));
return v___x_945_;
}
else
{
lean_object* v_val_946_; lean_object* v___x_947_; 
lean_dec(v_h__1_943_);
v_val_946_ = lean_ctor_get(v_x_942_, 0);
lean_inc(v_val_946_);
lean_dec_ref_known(v_x_942_, 1);
v___x_947_ = lean_apply_2(v_h__2_944_, v_val_946_, lean_box(0));
return v___x_947_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__5_splitter(lean_object* v_r_948_, lean_object* v_motive_949_, lean_object* v_x_950_, lean_object* v_h__1_951_, lean_object* v_h__2_952_){
_start:
{
if (lean_obj_tag(v_x_950_) == 0)
{
lean_object* v___x_953_; 
lean_dec(v_h__2_952_);
v___x_953_ = lean_apply_1(v_h__1_951_, lean_box(0));
return v___x_953_;
}
else
{
lean_object* v_val_954_; lean_object* v___x_955_; 
lean_dec(v_h__1_951_);
v_val_954_ = lean_ctor_get(v_x_950_, 0);
lean_inc(v_val_954_);
lean_dec_ref_known(v_x_950_, 1);
v___x_955_ = lean_apply_2(v_h__2_952_, v_val_954_, lean_box(0));
return v___x_955_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__5_splitter___boxed(lean_object* v_r_956_, lean_object* v_motive_957_, lean_object* v_x_958_, lean_object* v_h__1_959_, lean_object* v_h__2_960_){
_start:
{
lean_object* v_res_961_; 
v_res_961_ = lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_Internal_rootSelectors_match__5_splitter(v_r_956_, v_motive_957_, v_x_958_, v_h__1_959_, v_h__2_960_);
lean_dec_ref(v_r_956_);
return v_res_961_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0(lean_object* v_a_962_, lean_object* v_b_963_){
_start:
{
lean_object* v_root_964_; lean_object* v_root_965_; uint8_t v___x_966_; 
v_root_964_ = lean_ctor_get(v_a_962_, 0);
lean_inc_ref(v_root_964_);
lean_dec_ref(v_a_962_);
v_root_965_ = lean_ctor_get(v_b_963_, 0);
lean_inc_ref(v_root_965_);
lean_dec_ref(v_b_963_);
v___x_966_ = lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE(v_root_964_, v_root_965_);
return v___x_966_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0___boxed(lean_object* v_a_967_, lean_object* v_b_968_){
_start:
{
uint8_t v_res_969_; lean_object* v_r_970_; 
v_res_969_ = lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___lam__0(v_a_967_, v_b_968_);
v_r_970_ = lean_box(v_res_969_);
return v_r_970_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(lean_object* v___x_971_, lean_object* v_as_972_, size_t v_i_973_, size_t v_stop_974_, lean_object* v_b_975_){
_start:
{
lean_object* v___y_977_; uint8_t v___x_981_; 
v___x_981_ = lean_usize_dec_eq(v_i_973_, v_stop_974_);
if (v___x_981_ == 0)
{
lean_object* v___x_982_; lean_object* v___x_983_; 
v___x_982_ = lean_array_uget_borrowed(v_as_972_, v_i_973_);
lean_inc_ref(v___x_971_);
lean_inc(v___x_982_);
v___x_983_ = lean_apply_1(v___x_971_, v___x_982_);
if (lean_obj_tag(v___x_983_) == 0)
{
v___y_977_ = v_b_975_;
goto v___jp_976_;
}
else
{
lean_object* v_val_984_; lean_object* v___x_985_; 
v_val_984_ = lean_ctor_get(v___x_983_, 0);
lean_inc(v_val_984_);
lean_dec_ref_known(v___x_983_, 1);
v___x_985_ = lean_array_push(v_b_975_, v_val_984_);
v___y_977_ = v___x_985_;
goto v___jp_976_;
}
}
else
{
lean_dec_ref(v___x_971_);
return v_b_975_;
}
v___jp_976_:
{
size_t v___x_978_; size_t v___x_979_; 
v___x_978_ = ((size_t)1ULL);
v___x_979_ = lean_usize_add(v_i_973_, v___x_978_);
v_i_973_ = v___x_979_;
v_b_975_ = v___y_977_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0___boxed(lean_object* v___x_986_, lean_object* v_as_987_, lean_object* v_i_988_, lean_object* v_stop_989_, lean_object* v_b_990_){
_start:
{
size_t v_i_boxed_991_; size_t v_stop_boxed_992_; lean_object* v_res_993_; 
v_i_boxed_991_ = lean_unbox_usize(v_i_988_);
lean_dec(v_i_988_);
v_stop_boxed_992_ = lean_unbox_usize(v_stop_989_);
lean_dec(v_stop_989_);
v_res_993_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(v___x_986_, v_as_987_, v_i_boxed_991_, v_stop_boxed_992_, v_b_990_);
lean_dec_ref(v_as_987_);
return v_res_993_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0(lean_object* v___x_994_, lean_object* v_as_995_, lean_object* v_start_996_, lean_object* v_stop_997_){
_start:
{
lean_object* v___x_998_; uint8_t v___x_999_; 
v___x_998_ = ((lean_object*)(lp_Hex_Hex_RealRootSet_toArray___closed__0));
v___x_999_ = lean_nat_dec_lt(v_start_996_, v_stop_997_);
if (v___x_999_ == 0)
{
lean_dec_ref(v___x_994_);
return v___x_998_;
}
else
{
lean_object* v___x_1000_; uint8_t v___x_1001_; 
v___x_1000_ = lean_array_get_size(v_as_995_);
v___x_1001_ = lean_nat_dec_le(v_stop_997_, v___x_1000_);
if (v___x_1001_ == 0)
{
uint8_t v___x_1002_; 
v___x_1002_ = lean_nat_dec_lt(v_start_996_, v___x_1000_);
if (v___x_1002_ == 0)
{
lean_dec_ref(v___x_994_);
return v___x_998_;
}
else
{
size_t v___x_1003_; size_t v___x_1004_; lean_object* v___x_1005_; 
v___x_1003_ = lean_usize_of_nat(v_start_996_);
v___x_1004_ = lean_usize_of_nat(v___x_1000_);
v___x_1005_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(v___x_994_, v_as_995_, v___x_1003_, v___x_1004_, v___x_998_);
return v___x_1005_;
}
}
else
{
size_t v___x_1006_; size_t v___x_1007_; lean_object* v___x_1008_; 
v___x_1006_ = lean_usize_of_nat(v_start_996_);
v___x_1007_ = lean_usize_of_nat(v_stop_997_);
v___x_1008_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0_spec__0(v___x_994_, v_as_995_, v___x_1006_, v___x_1007_, v___x_998_);
return v___x_1008_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0___boxed(lean_object* v___x_1009_, lean_object* v_as_1010_, lean_object* v_start_1011_, lean_object* v_stop_1012_){
_start:
{
lean_object* v_res_1013_; 
v_res_1013_ = lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0(v___x_1009_, v_as_1010_, v_start_1011_, v_stop_1012_);
lean_dec(v_stop_1012_);
lean_dec(v_start_1011_);
lean_dec_ref(v_as_1010_);
return v_res_1013_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl(lean_object* v_x_1015_){
_start:
{
if (lean_obj_tag(v_x_1015_) == 0)
{
lean_object* v___x_1016_; 
v___x_1016_ = lean_box(0);
return v___x_1016_;
}
else
{
lean_object* v_roots_1017_; lean_object* v___x_1019_; uint8_t v_isShared_1020_; uint8_t v_isSharedCheck_1033_; 
v_roots_1017_ = lean_ctor_get(v_x_1015_, 0);
v_isSharedCheck_1033_ = !lean_is_exclusive(v_x_1015_);
if (v_isSharedCheck_1033_ == 0)
{
v___x_1019_ = v_x_1015_;
v_isShared_1020_ = v_isSharedCheck_1033_;
goto v_resetjp_1018_;
}
else
{
lean_inc(v_roots_1017_);
lean_dec(v_x_1015_);
v___x_1019_ = lean_box(0);
v_isShared_1020_ = v_isSharedCheck_1033_;
goto v_resetjp_1018_;
}
v_resetjp_1018_:
{
lean_object* v___x_1021_; lean_object* v_snd_1022_; lean_object* v___f_1023_; lean_object* v___x_1024_; lean_object* v___x_1025_; lean_object* v___x_1026_; lean_object* v___x_1027_; lean_object* v___x_1028_; lean_object* v___x_1029_; lean_object* v___x_1031_; 
v___x_1021_ = lp_Hex_Hex_RealAlgebraicPoly_Internal_rootSelectors(v_roots_1017_);
v_snd_1022_ = lean_ctor_get(v___x_1021_, 1);
lean_inc(v_snd_1022_);
lean_dec_ref(v___x_1021_);
v___f_1023_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl___closed__0));
v___x_1024_ = lean_unsigned_to_nat(0u);
v___x_1025_ = lean_array_get_size(v_roots_1017_);
v___x_1026_ = lp_Hex_Array_filterMapM___at___00Hex_RealAlgebraicPoly_realRootsImpl_spec__0(v_snd_1022_, v_roots_1017_, v___x_1024_, v___x_1025_);
lean_dec_ref(v_roots_1017_);
v___x_1027_ = lean_array_to_list(v___x_1026_);
v___x_1028_ = l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(v___x_1027_, v___f_1023_);
v___x_1029_ = lean_array_mk(v___x_1028_);
if (v_isShared_1020_ == 0)
{
lean_ctor_set(v___x_1019_, 0, v___x_1029_);
v___x_1031_ = v___x_1019_;
goto v_reusejp_1030_;
}
else
{
lean_object* v_reuseFailAlloc_1032_; 
v_reuseFailAlloc_1032_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1032_, 0, v___x_1029_);
v___x_1031_ = v_reuseFailAlloc_1032_;
goto v_reusejp_1030_;
}
v_reusejp_1030_:
{
return v___x_1031_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter___redArg(lean_object* v_x_1034_, lean_object* v_h__1_1035_, lean_object* v_h__2_1036_){
_start:
{
if (lean_obj_tag(v_x_1034_) == 0)
{
lean_object* v___x_1037_; lean_object* v___x_1038_; 
lean_dec(v_h__2_1036_);
v___x_1037_ = lean_box(0);
v___x_1038_ = lean_apply_1(v_h__1_1035_, v___x_1037_);
return v___x_1038_;
}
else
{
lean_object* v_roots_1039_; lean_object* v___x_1040_; 
lean_dec(v_h__1_1035_);
v_roots_1039_ = lean_ctor_get(v_x_1034_, 0);
lean_inc_ref(v_roots_1039_);
lean_dec_ref_known(v_x_1034_, 1);
v___x_1040_ = lean_apply_1(v_h__2_1036_, v_roots_1039_);
return v___x_1040_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexRealAlgebraic_Roots_0__Hex_RealAlgebraicPoly_realRoots_match__1_splitter(lean_object* v_motive_1041_, lean_object* v_x_1042_, lean_object* v_h__1_1043_, lean_object* v_h__2_1044_){
_start:
{
if (lean_obj_tag(v_x_1042_) == 0)
{
lean_object* v___x_1045_; lean_object* v___x_1046_; 
lean_dec(v_h__2_1044_);
v___x_1045_ = lean_box(0);
v___x_1046_ = lean_apply_1(v_h__1_1043_, v___x_1045_);
return v___x_1046_;
}
else
{
lean_object* v_roots_1047_; lean_object* v___x_1048_; 
lean_dec(v_h__1_1043_);
v_roots_1047_ = lean_ctor_get(v_x_1042_, 0);
lean_inc_ref(v_roots_1047_);
lean_dec_ref_known(v_x_1042_, 1);
v___x_1048_ = lean_apply_1(v_h__2_1044_, v_roots_1047_);
return v___x_1048_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicPoly_roots(lean_object* v_f_1049_){
_start:
{
lean_object* v___x_1050_; lean_object* v___x_1051_; 
v___x_1050_ = lp_Hex_Hex_AlgebraicPoly_roots(v_f_1049_);
v___x_1051_ = lp_Hex_Hex_RealAlgebraicPoly_realRootsImpl(v___x_1050_);
return v___x_1051_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(lean_object* v_as_1052_, size_t v_i_1053_, size_t v_stop_1054_, lean_object* v_b_1055_){
_start:
{
lean_object* v___y_1057_; uint8_t v___x_1061_; 
v___x_1061_ = lean_usize_dec_eq(v_i_1053_, v_stop_1054_);
if (v___x_1061_ == 0)
{
lean_object* v___x_1062_; lean_object* v___x_1063_; 
v___x_1062_ = lean_array_uget_borrowed(v_as_1052_, v_i_1053_);
lean_inc(v___x_1062_);
v___x_1063_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___x_1062_);
if (lean_obj_tag(v___x_1063_) == 0)
{
v___y_1057_ = v_b_1055_;
goto v___jp_1056_;
}
else
{
lean_object* v_val_1064_; lean_object* v___x_1065_; 
v_val_1064_ = lean_ctor_get(v___x_1063_, 0);
lean_inc(v_val_1064_);
lean_dec_ref_known(v___x_1063_, 1);
v___x_1065_ = lean_array_push(v_b_1055_, v_val_1064_);
v___y_1057_ = v___x_1065_;
goto v___jp_1056_;
}
}
else
{
return v_b_1055_;
}
v___jp_1056_:
{
size_t v___x_1058_; size_t v___x_1059_; 
v___x_1058_ = ((size_t)1ULL);
v___x_1059_ = lean_usize_add(v_i_1053_, v___x_1058_);
v_i_1053_ = v___x_1059_;
v_b_1055_ = v___y_1057_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0___boxed(lean_object* v_as_1066_, lean_object* v_i_1067_, lean_object* v_stop_1068_, lean_object* v_b_1069_){
_start:
{
size_t v_i_boxed_1070_; size_t v_stop_boxed_1071_; lean_object* v_res_1072_; 
v_i_boxed_1070_ = lean_unbox_usize(v_i_1067_);
lean_dec(v_i_1067_);
v_stop_boxed_1071_ = lean_unbox_usize(v_stop_1068_);
lean_dec(v_stop_1068_);
v_res_1072_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(v_as_1066_, v_i_boxed_1070_, v_stop_boxed_1071_, v_b_1069_);
lean_dec_ref(v_as_1066_);
return v_res_1072_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(lean_object* v_as_1075_, lean_object* v_start_1076_, lean_object* v_stop_1077_){
_start:
{
lean_object* v___x_1078_; uint8_t v___x_1079_; 
v___x_1078_ = ((lean_object*)(lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___closed__0));
v___x_1079_ = lean_nat_dec_lt(v_start_1076_, v_stop_1077_);
if (v___x_1079_ == 0)
{
return v___x_1078_;
}
else
{
lean_object* v___x_1080_; uint8_t v___x_1081_; 
v___x_1080_ = lean_array_get_size(v_as_1075_);
v___x_1081_ = lean_nat_dec_le(v_stop_1077_, v___x_1080_);
if (v___x_1081_ == 0)
{
uint8_t v___x_1082_; 
v___x_1082_ = lean_nat_dec_lt(v_start_1076_, v___x_1080_);
if (v___x_1082_ == 0)
{
return v___x_1078_;
}
else
{
size_t v___x_1083_; size_t v___x_1084_; lean_object* v___x_1085_; 
v___x_1083_ = lean_usize_of_nat(v_start_1076_);
v___x_1084_ = lean_usize_of_nat(v___x_1080_);
v___x_1085_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(v_as_1075_, v___x_1083_, v___x_1084_, v___x_1078_);
return v___x_1085_;
}
}
else
{
size_t v___x_1086_; size_t v___x_1087_; lean_object* v___x_1088_; 
v___x_1086_ = lean_usize_of_nat(v_start_1076_);
v___x_1087_ = lean_usize_of_nat(v_stop_1077_);
v___x_1088_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0_spec__0(v_as_1075_, v___x_1086_, v___x_1087_, v___x_1078_);
return v___x_1088_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0___boxed(lean_object* v_as_1089_, lean_object* v_start_1090_, lean_object* v_stop_1091_){
_start:
{
lean_object* v_res_1092_; 
v_res_1092_ = lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(v_as_1089_, v_start_1090_, v_stop_1091_);
lean_dec(v_stop_1091_);
lean_dec(v_start_1090_);
lean_dec_ref(v_as_1089_);
return v_res_1092_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_ZPoly_realAlgebraicRoots(lean_object* v_p_1093_){
_start:
{
lean_object* v___f_1094_; lean_object* v___x_1095_; lean_object* v___x_1096_; lean_object* v___x_1097_; lean_object* v___x_1098_; lean_object* v___x_1099_; lean_object* v___x_1100_; lean_object* v___x_1101_; 
v___f_1094_ = lean_alloc_closure((void*)(lp_Hex_Hex_RealAlgebraicNumber_instDecidableLE___boxed), 2, 0);
v___x_1095_ = lp_Hex_Hex_ZPoly_algebraicRoots(v_p_1093_);
v___x_1096_ = lean_unsigned_to_nat(0u);
v___x_1097_ = lean_array_get_size(v___x_1095_);
v___x_1098_ = lp_Hex_Array_filterMapM___at___00Hex_ZPoly_realAlgebraicRoots_spec__0(v___x_1095_, v___x_1096_, v___x_1097_);
lean_dec_ref(v___x_1095_);
v___x_1099_ = lean_array_to_list(v___x_1098_);
v___x_1100_ = l_List_MergeSort_Internal_mergeSortTR_u2082___redArg(v___x_1099_, v___f_1094_);
v___x_1101_ = lean_array_mk(v___x_1100_);
return v___x_1101_;
}
}
static lean_object* _init_lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0(void){
_start:
{
uint8_t v___x_1102_; lean_object* v___x_1103_; 
v___x_1102_ = 0;
v___x_1103_ = l_Ordering_ctorIdx(v___x_1102_);
return v___x_1103_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(lean_object* v_a_1104_){
_start:
{
lean_object* v___x_1105_; uint8_t v___x_1106_; lean_object* v___x_1107_; lean_object* v___x_1108_; uint8_t v___x_1109_; 
v___x_1105_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
lean_inc_ref(v_a_1104_);
v___x_1106_ = lp_Hex_Hex_AlgebraicNumber_realCompare(v_a_1104_, v___x_1105_);
v___x_1107_ = l_Ordering_ctorIdx(v___x_1106_);
v___x_1108_ = lean_obj_once(&lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0, &lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0_once, _init_lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f___closed__0);
v___x_1109_ = lean_nat_dec_eq(v___x_1107_, v___x_1108_);
lean_dec(v___x_1107_);
if (v___x_1109_ == 0)
{
lean_object* v___x_1110_; lean_object* v___x_1111_; 
v___x_1110_ = lp_Hex_Hex_AlgebraicNumber_sqrt(v_a_1104_);
v___x_1111_ = lp_Hex_Hex_RealAlgebraicNumber_ofAlgebraic_x3f(v___x_1110_);
return v___x_1111_;
}
else
{
lean_object* v___x_1112_; 
lean_dec_ref(v_a_1104_);
v___x_1112_ = lean_box(0);
return v___x_1112_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt_x3f(lean_object* v_a_1113_){
_start:
{
lean_object* v___x_1114_; 
v___x_1114_ = lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(v_a_1113_);
return v___x_1114_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg(lean_object* v_a_1116_){
_start:
{
lean_object* v___x_1117_; 
v___x_1117_ = lp_Hex_Hex_RealAlgebraicNumber_sqrtRoot_x3f(v_a_1116_);
if (lean_obj_tag(v___x_1117_) == 0)
{
lean_object* v___x_1118_; lean_object* v___x_1119_; lean_object* v___x_1120_; 
v___x_1118_ = lp_Hex___private_HexNumberField_Basic_0__Hex_AlgebraicNumber_zeroRaw;
v___x_1119_ = ((lean_object*)(lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg___closed__0));
v___x_1120_ = lp_batteries_panic___at___00Batteries_panicWith_spec__0(lean_box(0), v___x_1118_, v___x_1119_);
return v___x_1120_;
}
else
{
lean_object* v_val_1121_; 
v_val_1121_ = lean_ctor_get(v___x_1117_, 0);
lean_inc(v_val_1121_);
lean_dec_ref_known(v___x_1117_, 1);
return v_val_1121_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_RealAlgebraicNumber_sqrt(lean_object* v_a_1122_, lean_object* v___h_1123_){
_start:
{
lean_object* v___x_1124_; 
v___x_1124_ = lp_Hex_Hex_RealAlgebraicNumber_sqrt___redArg(v_a_1122_);
return v___x_1124_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexRealAlgebraic_Order(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexNumberField_Radical(uint8_t builtin);
void lean_initialize();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexRealAlgebraic_Roots(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealAlgebraic_Order(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexNumberField_Radical(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexRealAlgebraic_Roots(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexRealAlgebraic_Order(uint8_t builtin);
lean_object* initialize_Hex_HexNumberField_Radical(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexRealAlgebraic_Roots(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexRealAlgebraic_Order(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexNumberField_Radical(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRealAlgebraic_Roots(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexRealAlgebraic_Roots(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexRealAlgebraic_Roots(builtin);
}
#ifdef __cplusplus
}
#endif
