
.cache/issue-10352/profile-bin/hexrank_bench:     file format elf64-x86-64


Disassembly of section .text:

0000000000d6ebe0 <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc>:
  d6ebe0:	41 57                	push   %r15
  d6ebe2:	41 56                	push   %r14
  d6ebe4:	53                   	push   %rbx
  d6ebe5:	48 89 d0             	mov    %rdx,%rax
  d6ebe8:	48 89 f3             	mov    %rsi,%rbx
  d6ebeb:	49 89 fe             	mov    %rdi,%r14
  d6ebee:	66 90                	xchg   %ax,%ax
  d6ebf0:	49 89 c7             	mov    %rax,%r15
  d6ebf3:	41 f6 c6 01          	test   $0x1,%r14b
  d6ebf7:	75 17                	jne    d6ec10 <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x30>
  d6ebf9:	41 0f b6 46 07       	movzbl 0x7(%r14),%eax
  d6ebfe:	83 f8 01             	cmp    $0x1,%eax
  d6ec01:	74 1c                	je     d6ec1f <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x3f>
  d6ec03:	e9 d6 00 00 00       	jmp    d6ecde <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0xfe>
  d6ec08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  d6ec0f:	00 
  d6ec10:	4c 89 f0             	mov    %r14,%rax
  d6ec13:	48 d1 e8             	shr    $1,%rax
  d6ec16:	83 f8 01             	cmp    $0x1,%eax
  d6ec19:	0f 85 bf 00 00 00    	jne    d6ecde <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0xfe>
  d6ec1f:	f6 c3 01             	test   $0x1,%bl
  d6ec22:	75 1c                	jne    d6ec40 <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x60>
  d6ec24:	0f b6 43 07          	movzbl 0x7(%rbx),%eax
  d6ec28:	83 f8 01             	cmp    $0x1,%eax
  d6ec2b:	74 22                	je     d6ec4f <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x6f>
  d6ec2d:	e9 ac 00 00 00       	jmp    d6ecde <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0xfe>
  d6ec32:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  d6ec39:	1f 84 00 00 00 00 00 
  d6ec40:	48 89 d8             	mov    %rbx,%rax
  d6ec43:	48 d1 e8             	shr    $1,%rax
  d6ec46:	83 f8 01             	cmp    $0x1,%eax
  d6ec49:	0f 85 8f 00 00 00    	jne    d6ecde <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0xfe>
  d6ec4f:	49 8b 7e 08          	mov    0x8(%r14),%rdi
  d6ec53:	4d 8b 76 10          	mov    0x10(%r14),%r14
  d6ec57:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  d6ec5b:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
  d6ec5f:	40 f6 c6 01          	test   $0x1,%sil
  d6ec63:	75 0a                	jne    d6ec6f <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x8f>
  d6ec65:	8b 06                	mov    (%rsi),%eax
  d6ec67:	85 c0                	test   %eax,%eax
  d6ec69:	7e 40                	jle    d6ecab <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0xcb>
  d6ec6b:	ff c0                	inc    %eax
  d6ec6d:	89 06                	mov    %eax,(%rsi)
  d6ec6f:	40 f6 c7 01          	test   $0x1,%dil
  d6ec73:	75 0a                	jne    d6ec7f <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x9f>
  d6ec75:	8b 07                	mov    (%rdi),%eax
  d6ec77:	85 c0                	test   %eax,%eax
  d6ec79:	7e 3c                	jle    d6ecb7 <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0xd7>
  d6ec7b:	ff c0                	inc    %eax
  d6ec7d:	89 07                	mov    %eax,(%rdi)
  d6ec7f:	e8 ec f4 ff ff       	call   d6e170 <lp_Hex_Hex_Matrix_PolyWitness_mul>
  d6ec84:	4c 89 ff             	mov    %r15,%rdi
  d6ec87:	48 89 c6             	mov    %rax,%rsi
  d6ec8a:	e8 31 f1 ff ff       	call   d6ddc0 <lp_Hex_Hex_Matrix_PolyWitness_add>
  d6ec8f:	41 f6 c7 01          	test   $0x1,%r15b
  d6ec93:	0f 85 57 ff ff ff    	jne    d6ebf0 <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x10>
  d6ec99:	41 8b 0f             	mov    (%r15),%ecx
  d6ec9c:	83 f9 02             	cmp    $0x2,%ecx
  d6ec9f:	7c 22                	jl     d6ecc3 <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0xe3>
  d6eca1:	ff c9                	dec    %ecx
  d6eca3:	41 89 0f             	mov    %ecx,(%r15)
  d6eca6:	e9 45 ff ff ff       	jmp    d6ebf0 <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x10>
  d6ecab:	3d 01 00 00 90       	cmp    $0x90000001,%eax
  d6ecb0:	72 bd                	jb     d6ec6f <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x8f>
  d6ecb2:	f0 ff 0e             	lock decl (%rsi)
  d6ecb5:	eb b8                	jmp    d6ec6f <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x8f>
  d6ecb7:	3d 01 00 00 90       	cmp    $0x90000001,%eax
  d6ecbc:	72 c1                	jb     d6ec7f <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x9f>
  d6ecbe:	f0 ff 0f             	lock decl (%rdi)
  d6ecc1:	eb bc                	jmp    d6ec7f <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x9f>
  d6ecc3:	85 c9                	test   %ecx,%ecx
  d6ecc5:	0f 84 25 ff ff ff    	je     d6ebf0 <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x10>
  d6eccb:	4c 89 ff             	mov    %r15,%rdi
  d6ecce:	49 89 c7             	mov    %rax,%r15
  d6ecd1:	e8 da a8 e3 03       	call   4ba95b0 <lean_dec_ref_cold>
  d6ecd6:	4c 89 f8             	mov    %r15,%rax
  d6ecd9:	e9 12 ff ff ff       	jmp    d6ebf0 <lp_Hex___private_HexRank_Polynomial_0__Hex_Matrix_PolyWitness_dotAcc+0x10>
