/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

import HexPolyDetMathlib.ProofProbe.ResultIdentity4Mathlib

#print axioms HexPolyDetMathlib.ProofProbe.ResultIdentity4Mathlib.certificate
