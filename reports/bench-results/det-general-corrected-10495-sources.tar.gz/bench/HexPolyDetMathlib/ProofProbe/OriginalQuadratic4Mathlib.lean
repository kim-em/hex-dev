/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/
import HexPolyDetMathlib
import Mathlib.Tactic.NormDet
import Mathlib.Tactic.Ring

set_option maxHeartbeats 2000000
set_option maxRecDepth 100000

theorem HexPolyDetMathlib.ProofProbe.OriginalQuadratic4Mathlib.result (x0 x1 : Int) : Matrix.det (R := Int) (!![(-3) * (1 * (x0 ^ 2) + 2 * (x0) + 3 * (x1) + 1 * (1)), (-2) * (1 * (x0 ^ 2) + 2 * (x0) + 3 * (x1) + 1 * (1)), (-3) * (1 * (x0 ^ 2) + 2 * (x0) + 3 * (x1) + 1 * (1)), (3) * (1 * (x0 ^ 2) + 2 * (x0) + 3 * (x1) + 1 * (1)); (-1) * (2 * (x1 ^ 2) + 3 * (x1) + 1 * (x0) + 2 * (1)), (1) * (2 * (x1 ^ 2) + 3 * (x1) + 1 * (x0) + 2 * (1)), (-3) * (2 * (x1 ^ 2) + 3 * (x1) + 1 * (x0) + 2 * (1)), (-1) * (2 * (x1 ^ 2) + 3 * (x1) + 1 * (x0) + 2 * (1)); (3) * (3 * (x0 ^ 2) + 1 * (x0) + 2 * (x1) + 3 * (x1 ^ 2)), (3) * (3 * (x0 ^ 2) + 1 * (x0) + 2 * (x1) + 3 * (x1 ^ 2)), (-2) * (3 * (x0 ^ 2) + 1 * (x0) + 2 * (x1) + 3 * (x1 ^ 2)), (-1) * (3 * (x0 ^ 2) + 1 * (x0) + 2 * (x1) + 3 * (x1 ^ 2)); (3) * (1 * (x1 ^ 2) + 2 * (x1) + 3 * (x0) + 1 * (x0 ^ 2)), (2) * (1 * (x1 ^ 2) + 2 * (x1) + 3 * (x0) + 1 * (x0 ^ 2)), (-1) * (1 * (x1 ^ 2) + 2 * (x1) + 3 * (x0) + 1 * (x0 ^ 2)), (-1) * (1 * (x1 ^ 2) + 2 * (x1) + 3 * (x0) + 1 * (x0 ^ 2))]) = (-26) * (1 * (x0 ^ 2) + 2 * (x0) + 3 * (x1) + 1 * (1)) * (2 * (x1 ^ 2) + 3 * (x1) + 1 * (x0) + 2 * (1)) * (3 * (x0 ^ 2) + 1 * (x0) + 2 * (x1) + 3 * (x1 ^ 2)) * (1 * (x1 ^ 2) + 2 * (x1) + 3 * (x0) + 1 * (x0 ^ 2)) := by
  simp only [norm_det] <;> ring
