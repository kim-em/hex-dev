"""Exercise the real comparison orchestration with synthetic executable rows."""
from contextlib import redirect_stdout, redirect_stderr
import hashlib
import io
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch

REAL = Path(__file__).resolve().parent
LIBRARY = Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10575-orderedfn-sign-scan-frozen')
sys.path[:0] = [str(LIBRARY), str(LIBRARY / 'scripts/bench')]
import cpu_lease
import scripts.bench.sturm_regression as helpers


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixture(base, mode='ok'):
    root = base / 'source'
    root.mkdir(parents=True)
    subprocess.run(['git', 'init', '-q'], cwd=root, check=True)
    (root / 'test.txt').write_text('synthetic source, no native benchmark\n')
    subprocess.run(['git', 'add', '.'], cwd=root, check=True)
    subprocess.run(['git', '-c', 'user.name=Control', '-c', 'user.email=control@example.test',
                    'commit', '-qm', 'synthetic source'], cwd=root, check=True)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    out = base / 'comparison-tool'
    out.mkdir()
    for name in ['measure.py', 'analyze_guard.py', 'schedule.json']:
        shutil.copy2(REAL / name, out / name)
    retained = root / 'reports/bench-results/ordered-fn-regression-followup/schedule.json'
    retained.parent.mkdir(parents=True)
    shutil.copy2(out / 'schedule.json', retained)
    subprocess.run(['git', 'add', '.'], cwd=root, check=True)
    subprocess.run(['git', '-c', 'user.name=Control', '-c', 'user.email=control@example.test',
                    'commit', '-qm', 'synthetic retained schedule'], cwd=root, check=True)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    for arm in ['baseline', 'candidate']:
        binary = base / (arm + '-stub')
        program = '''#!/usr/bin/env python3
import json,os,sys
if any(k.startswith('LEAN_BENCH_') for k in os.environ):raise RuntimeError('profiling mode leaked')
a=sys.argv
name=a[a.index('--bench')+1];param=int(a[a.index('--param')+1])
if MODE=='one-error' and ARM=='candidate' and name.endswith('.scan') and param==128:sys.exit(7)
print(json.dumps({'kind':'parametric','status':'ok','error':None,'function':name,'param':param,
 'cache_mode':'warm','env':{'lean_version':'synthetic'},'inner_repeats':1,'total_nanos':100,
 'per_call_nanos':100,'result_hash':'same'}))
'''.replace('MODE', repr(mode)).replace('ARM', repr(arm))
        binary.write_text(program)
        binary.chmod(0o755)
        source = dict(root=str(root), head=head, status='', sources={}, packages={},
                      binary=str(binary), binary_sha256=sha(binary),
                      sdk={name:dict(path=sys.executable, sha256=sha(Path(sys.executable)))
                           for name in ['lean', 'lake']})
        (out / (arm + '-source.json')).write_text(json.dumps(source))
    for name in ['proposal.json', 'build-provenance.json', 'benchmark-source-reconciliation.json']:
        (out / name).write_text('{}')
    decision = dict(candidate_root=str(root), historical_source=head, candidate_source=head,
                    schedule_sha256=sha(out / 'schedule.json'),
                    source_manifests={arm:sha(out / (arm + '-source.json')) for arm in ['baseline', 'candidate']},
                    compiler_versions={arm:'synthetic' for arm in ['baseline', 'candidate']},
                    tools={str(out / name):sha(out / name) for name in ['measure.py','analyze_guard.py']},
                    baseline_selection_record_sha256=sha(out / 'build-provenance.json'),
                    benchmark_source_reconciliation_sha256=sha(out / 'benchmark-source-reconciliation.json'),
                    proposal_sha256=sha(out / 'proposal.json'))
    (out / 'decision.json').write_text(json.dumps(decision))
    return out


def run(out, state, lease_error=None):
    original_affinity = os.sched_getaffinity(0)
    try:
        with patch.object(helpers, 'state_directory', return_value=state), \
             patch.object(cpu_lease, 'cpu_lease', return_value=(min(original_affinity),io.StringIO()),
                          side_effect=lease_error), \
             patch.object(sys, 'argv', [str(out / 'measure.py')]), \
             patch.dict(os.environ, {'LEAN_BENCH_PROFILE_KERNEL':'1'}), \
             redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            try:
                runpy.run_path(str(out / 'measure.py'))
            except SystemExit as error:
                return error.code
    finally:
        os.sched_setaffinity(0, original_affinity)


with tempfile.TemporaryDirectory() as temporary:
    base = Path(temporary)
    out = fixture(base / 'stable')
    state = base / 'stable-state'
    try:
        run(out, state, RuntimeError('all synthetic leases held'))
    except RuntimeError as error:
        assert 'leases held' in str(error)
    else:
        raise AssertionError('lease failure was not retained')
    assert not (out / 'comparison').exists() and not state.exists()
    assert run(out, state) == 0
    context = json.loads((out / 'comparison/context.json').read_text())
    assert context['completed_arms'] == 816 and context['outcome'] == 'pass'
    assert len((out / 'comparison/observations.jsonl').read_text().splitlines()) == 816
    assert (out / 'comparison/analyze_guard.py').read_bytes() == (out / 'analyze_guard.py').read_bytes()
    # A different executable for the same source pair must not create a fresh slot.
    source_path = out / 'baseline-source.json'
    source = json.loads(source_path.read_text())
    binary = Path(source['binary']);binary.write_text(binary.read_text()+'\n# another build\n')
    source['binary_sha256'] = sha(binary);source_path.write_text(json.dumps(source))
    decision_path = out / 'decision.json';decision = json.loads(decision_path.read_text())
    decision['source_manifests']['baseline'] = sha(source_path);decision_path.write_text(json.dumps(decision))
    try:
        run(out, state)
    except RuntimeError as error:
        assert 'source pair has consumed' in str(error)
    else:
        raise AssertionError('changed baseline bytes reset the consumed attempt')
    out = fixture(base / 'failed', 'one-error')
    assert run(out, base / 'failed-state') == 2
    context = json.loads((out / 'comparison/context.json').read_text())
    assert context['status'] == 'completed' and context['outcome'] == 'failed'
    assert context['completed_arms'] == 813 and context['failed_arms'] == 3
    assert len((out / 'comparison/observations.jsonl').read_text().splitlines()) == 816
print('PASS: 816-arm synthetic success; lease failure leaves no output/slot; source-pair slot blocks binary swapping; all816 arms retained despite3 synthetic failures; profiling environment removed.')
