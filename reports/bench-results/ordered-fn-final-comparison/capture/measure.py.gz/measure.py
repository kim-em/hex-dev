"""One bound full OrderedFn source comparison, using the retained child schedule."""
from pathlib import Path
import hashlib
import json
import math
import os
import platform
import signal
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
DECISION_BYTES = (OUT / 'decision.json').read_bytes()
DECISION = json.loads(DECISION_BYTES)
ROOT = Path(DECISION['candidate_root'])
sys.path[:0] = [str(ROOT), str(ROOT / 'scripts/bench')]
from cpu_lease import cpu_lease
from scripts.bench.sturm_regression import memory_context, run_process, state_directory


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


SOURCES = {arm: json.loads((OUT / (arm + '-source.json')).read_text())
           for arm in ('baseline', 'candidate')}
BINARIES = {arm: Path(source['binary']) for arm, source in SOURCES.items()}
SCHEDULE = json.loads((OUT / 'schedule.json').read_text())


def source_checks():
    require(sha(OUT / 'decision.json') == hashlib.sha256(DECISION_BYTES).hexdigest(), 'changed decision')
    require(sha(OUT / 'schedule.json') == DECISION['schedule_sha256'], 'changed schedule')
    for filename, field in [('build-provenance.json', 'baseline_selection_record_sha256'),
                            ('benchmark-source-reconciliation.json', 'benchmark_source_reconciliation_sha256'),
                            ('proposal.json', 'proposal_sha256')]:
        require(sha(OUT / filename) == DECISION[field], 'changed provenance record: ' + filename)
    require(SOURCES['baseline']['head'] == DECISION['historical_source'] and
            SOURCES['candidate']['head'] == DECISION['candidate_source'], 'changed frozen source pair')
    require(sha(ROOT / 'reports/bench-results/ordered-fn-regression-followup/schedule.json') ==
            DECISION['schedule_sha256'], 'schedule differs from retained full comparison')
    for arm, source in SOURCES.items():
        require(sha(OUT / (arm + '-source.json')) == DECISION['source_manifests'][arm],
                'changed source manifest: ' + arm)
        root = Path(source['root'])
        git = lambda *args, cwd=root: subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()
        require(git('rev-parse', 'HEAD') == source['head'] and not git('status', '--porcelain'),
                'changed or dirty source: ' + arm)
        for path, expected in source['sources'].items():
            require(sha(root / path) == expected, 'changed source input: ' + arm + '/' + path)
        for name, package in source['packages'].items():
            directory = root / '.lake/packages' / name
            require(git('rev-parse', 'HEAD', cwd=directory) == package['head'] and
                    not git('status', '--porcelain', cwd=directory), 'changed dependency: ' + name)
        for name in ('lean', 'lake'):
            sdk = source['sdk'][name]
            require(sha(Path(sdk['path'])) == sdk['sha256'], 'changed pinned SDK executable')
        require(sha(BINARIES[arm]) == source['binary_sha256'] and os.access(BINARIES[arm], os.X_OK),
                'changed or non-executable native binary: ' + arm)
    for path, expected in DECISION['tools'].items():
        require(sha(Path(path)) == expected, 'changed comparison tool: ' + path)


source_checks()
require(SCHEDULE['trials'] == 3 and len(SCHEDULE['workloads']) == 17 and
        all(len(w['parameters']) == 8 for w in SCHEDULE['workloads']), 'incomplete original scope')
require(sum(len(w['parameters']) for w in SCHEDULE['workloads']) * 3 * 2 == 816,
        'incorrect original arm count')
identity = hashlib.sha256(json.dumps({arm: source['head']
                                    for arm, source in SOURCES.items()}, sort_keys=True).encode()).hexdigest()
marker = state_directory() / 'hex/orderedfn-full-comparisons' / (identity + '.json')
require(not marker.exists(), 'this frozen source pair has consumed a full-comparison attempt')
if sys.argv[1:] == ['--preflight']:
    print('PASS: full source/SDK/pin/tool/binary bindings, complete816arm schedule and unused slot; no lease or measurements.')
    raise SystemExit(0)
require(not sys.argv[1:], 'unsupported comparison arguments')
capture = OUT / 'comparison'
require(not capture.exists(), 'capture directory already exists; preserve its evidence')
cpu, lease = cpu_lease()
affinity_before = sorted(os.sched_getaffinity(0))
try:
    os.sched_setaffinity(0, {cpu})
    affinity_after = sorted(os.sched_getaffinity(0))
    require(affinity_after == [cpu], 'CPU affinity was not applied')
    capture.mkdir(exist_ok=False)
    for name in ['decision.json', 'schedule.json', 'baseline-source.json', 'candidate-source.json',
                 'measure.py', 'analyze_guard.py', 'proposal.json', 'build-provenance.json',
                 'benchmark-source-reconciliation.json']:
        with (capture / name).open('xb') as handle:
            handle.write((OUT / name).read_bytes())
    (capture / 'sources.json').write_text(json.dumps(SOURCES, indent=2) + '\n')
except BaseException:
    lease.close()
    raise
# Profiling/sidecar modes change the timed loop; remove them symmetrically.
environment = {key:value for key,value in os.environ.items() if not key.startswith('LEAN_BENCH_')}
environment['LEAN_NUM_THREADS'] = '4'
context = dict(status='setup', cpu=cpu, host=platform.node(), platform=platform.platform(),
               affinity_before=affinity_before, affinity_after=affinity_after, load_before=os.getloadavg(),
               memory_before=memory_context(), started_unix=time.time(), commands=[],
               script_sha256=sha(Path(__file__)), decision_sha256=sha(OUT / 'decision.json'),
               source_heads={arm: source['head'] for arm, source in SOURCES.items()},
               binaries={arm: source['binary_sha256'] for arm, source in SOURCES.items()},
               lean_num_threads='4', measurement_environment={'LEAN_NUM_THREADS':'4', 'LEAN_BENCH_*':'unset'},
               comparison_identity=identity, failed_arms=0, completed_arms=0, attempt_reserved=False,
               reservation=str(marker), invocation_root=str(ROOT))


def save():
    (capture / 'context.json').write_text(json.dumps(context, indent=2) + '\n')


def interrupt(signum, _frame):
    if signum == signal.SIGALRM:
        raise TimeoutError('parent timeout')
    raise KeyboardInterrupt('signal ' + str(signum))


for signum in (signal.SIGTERM, signal.SIGHUP, signal.SIGALRM):
    signal.signal(signum, interrupt)
try:
    marker.parent.mkdir(parents=True, exist_ok=True)
    with marker.open('x') as handle:
        json.dump({'output': str(capture), 'decision_sha256': context['decision_sha256']}, handle)
    context.update(status='running', attempt_reserved=True)
    save()
    with (capture / 'observations.jsonl').open('x') as rows:
        for trial in range(3):
            for work in SCHEDULE['workloads']:
                name = work['name']
                short = name.rsplit('.', 1)[-1]
                for param in work['parameters']:
                    for arm in (('baseline', 'candidate') if trial % 2 == 0 else ('candidate', 'baseline')):
                        require(sha(BINARIES[arm]) == SOURCES[arm]['binary_sha256'], 'binary changed')
                        stem = f'{trial}-{short}-{param}-{arm}'
                        command = [str(BINARIES[arm]), '_child', '--bench', name, '--param', str(param),
                                   '--target-nanos', str(work['target_nanos'])]
                        row = dict(trial=trial, name=name, param=param, arm=arm, command=command,
                                   stdout=stem + '.stdout', stderr=stem + '.stderr', load_before=os.getloadavg())
                        context['commands'].append(dict(command=command, stdout=row['stdout'], stderr=row['stderr']))
                        save()
                        try:
                            signal.alarm(SCHEDULE['timeout_seconds'])
                            with (capture / row['stdout']).open('x') as stdout, (capture / row['stderr']).open('x') as stderr:
                                row['returncode'] = run_process(command, ROOT, environment, stdout, stderr)
                            signal.alarm(0)
                            require(row['returncode'] == 0, 'native child failed: ' + stem)
                            observation = json.loads((capture / row['stdout']).read_text())
                            row['observation'] = observation
                            require(observation['status'] == 'ok' and observation['error'] is None and
                                    observation['function'] == name and observation['param'] == param and
                                    observation['kind'] == 'parametric' and observation['cache_mode'] == 'warm' and
                                    observation['env']['lean_version'] == DECISION['compiler_versions'][arm] and
                                    observation['inner_repeats'] > 0 and observation['total_nanos'] > 0 and
                                    math.isfinite(observation['per_call_nanos']) and observation['per_call_nanos'] > 0 and
                                    observation['result_hash'] is not None, 'invalid native observation: ' + stem)
                            context['completed_arms'] += 1
                        except BaseException as error:
                            context['failed_arms'] += 1
                            row.setdefault('returncode', None)
                            row['failure'] = str(error)
                            if not isinstance(error, Exception):
                                raise
                        finally:
                            signal.alarm(0)
                            row['load_after'] = os.getloadavg()
                            rows.write(json.dumps(row) + '\n')
                            rows.flush()
                            save()
                print(f'trial {trial}: {short} complete', flush=True)
    context['status'] = 'completed'
except BaseException as error:
    context.update(status='failed', error=str(error))
    raise
finally:
    try:
        source_checks()
        context['inputs_unchanged'] = True
    except BaseException as error:
        context.update(status='invalid', integrity_error=str(error))
    context.update(finished_unix=time.time(), load_after=os.getloadavg(), memory_after=memory_context(),
                   affinity_final=sorted(os.sched_getaffinity(0)),
                   binaries_after={arm: sha(binary) for arm, binary in BINARIES.items()})
    save()
    lease.close()
require(context['status'] == 'completed' and context['inputs_unchanged'], 'incomplete or changed-input comparison')
try:
    with (capture / 'guard-analysis.stdout').open('x') as stdout, (capture / 'guard-analysis.stderr').open('x') as stderr:
        analysis = subprocess.run([sys.executable, str(OUT / 'analyze_guard.py'), str(capture),
                                   '--output', str(capture / 'guard-analysis.json')], cwd=ROOT,
                                  stdout=stdout, stderr=stderr)
    context['comparison_analysis_returncode'] = analysis.returncode
    report = json.loads((capture / 'guard-analysis.json').read_text())
    require(report['completed_arms'] == 816 and len(report['failures']) == context['failed_arms'],
            'incomplete or inconsistent native comparison')
    if context['failed_arms']:
        context['outcome'] = 'failed'
    else:
        require(report['parameters_compared'] == 136 and report['all_hashes_agree'],
                'incomplete or inconsistent native comparison')
        require(analysis.returncode in (0, 2), 'unexpected analysis result')
        context.update(outcome='pass' if analysis.returncode == 0 else 'regression',
                       regression_count=report['regression_count'])
except Exception as error:
    context.update(outcome='invalid', analysis_error=str(error))
    save()
    raise
save()
print('Full comparison:', context['outcome'], flush=True)
raise SystemExit(0 if context['outcome'] == 'pass' else 2)
