import json,sys
from pathlib import Path
from scripts.oracle.groebner_singular import run
root=Path(sys.argv[1]); x=json.loads((root/'input.json').read_text()); x['basis']=json.loads((root/'output.json').read_text())['basis']
assert run([{'case':'reimer5-17','value':x}],sys.argv[2])==1
print('Reimer-5 p65537: every reduced-basis coefficient and exponent agrees with Singular')
