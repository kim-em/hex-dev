LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Oracle_Bounds_divImpl(lean_object* v_a_277_, lean_object* v_b_278_){
_start:
{
lean_object* v_lower_279_; lean_object* v_upper_280_; lean_object* v_lower_281_; lean_object* v_upper_282_; uint8_t v___y_284_; lean_object* v___x_305_; uint8_t v___x_306_; 
v_lower_279_ = lean_ctor_get(v_a_277_, 0);
lean_inc_ref_n(v_lower_279_, 2);
v_upper_280_ = lean_ctor_get(v_a_277_, 1);
lean_inc_ref(v_upper_280_);
lean_dec_ref(v_a_277_);
v_lower_281_ = lean_ctor_get(v_b_278_, 0);
lean_inc_ref(v_lower_281_);
v_upper_282_ = lean_ctor_get(v_b_278_, 1);
lean_inc_ref(v_upper_282_);
v___x_305_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_Oracle_Bounds_separated___closed__0, &lp_Hex_Hex_OrderedFn_Oracle_Bounds_separated___closed__0_once, _init_lp_Hex_Hex_OrderedFn_Oracle_Bounds_separated___closed__0);
v___x_306_ = l_Rat_instDecidableLe(v___x_305_, v_lower_279_);
if (v___x_306_ == 0)
{
v___y_284_ = v___x_306_;
goto v___jp_283_;
}
else
{
uint8_t v___x_307_; 
lean_inc_ref(v_lower_281_);
v___x_307_ = l_Rat_blt(v___x_305_, v_lower_281_);
v___y_284_ = v___x_307_;
goto v___jp_283_;
}
v___jp_283_:
{
if (v___y_284_ == 0)
{
uint8_t v___x_285_; 
v___x_285_ = lp_Hex_Hex_OrderedFn_Oracle_Bounds_separated(v_b_278_);
if (v___x_285_ == 0)
{
lean_object* v___x_286_; 
lean_dec_ref(v_upper_282_);
lean_dec_ref(v_lower_281_);
lean_dec_ref(v_upper_280_);
lean_dec_ref(v_lower_279_);
v___x_286_ = lean_box(0);
return v___x_286_;
}
else
{
lean_object* v___x_287_; lean_object* v___x_288_; lean_object* v___x_289_; lean_object* v___x_290_; lean_object* v___x_291_; lean_object* v___x_292_; 
lean_inc_ref(v_lower_281_);
v___x_287_ = l_Rat_div(v_lower_279_, v_lower_281_);
lean_inc_ref(v_upper_282_);
v___x_288_ = l_Rat_div(v_lower_279_, v_upper_282_);
lean_dec_ref(v_lower_279_);
v___x_289_ = l_Rat_div(v_upper_280_, v_lower_281_);
v___x_290_ = l_Rat_div(v_upper_280_, v_upper_282_);
lean_dec_ref(v_upper_280_);
v___x_291_ = lp_Hex_Hex_OrderedFn_Oracle_Bounds_hull4(v___x_287_, v___x_288_, v___x_289_, v___x_290_);
v___x_292_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_292_, 0, v___x_291_);
return v___x_292_;
}
}
else
{
lean_object* v___x_294_; uint8_t v_isShared_295_; uint8_t v_isSharedCheck_302_; 
v_isSharedCheck_302_ = !lean_is_exclusive(v_b_278_);
if (v_isSharedCheck_302_ == 0)
{
lean_object* v_unused_303_; lean_object* v_unused_304_; 
v_unused_303_ = lean_ctor_get(v_b_278_, 1);
lean_dec(v_unused_303_);
v_unused_304_ = lean_ctor_get(v_b_278_, 0);
lean_dec(v_unused_304_);
v___x_294_ = v_b_278_;
v_isShared_295_ = v_isSharedCheck_302_;
goto v_resetjp_293_;
}
else
{
lean_dec(v_b_278_);
v___x_294_ = lean_box(0);
v_isShared_295_ = v_isSharedCheck_302_;
goto v_resetjp_293_;
}
v_resetjp_293_:
{
lean_object* v___x_296_; lean_object* v___x_297_; lean_object* v___x_299_; 
v___x_296_ = l_Rat_div(v_lower_279_, v_upper_282_);
lean_dec_ref(v_lower_279_);
v___x_297_ = l_Rat_div(v_upper_280_, v_lower_281_);
lean_dec_ref(v_upper_280_);
if (v_isShared_295_ == 0)
{
lean_ctor_set(v___x_294_, 1, v___x_297_);
lean_ctor_set(v___x_294_, 0, v___x_296_);
v___x_299_ = v___x_294_;
goto v_reusejp_298_;
}
else
{
lean_object* v_reuseFailAlloc_301_; 
v_reuseFailAlloc_301_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_301_, 0, v___x_296_);
lean_ctor_set(v_reuseFailAlloc_301_, 1, v___x_297_);
v___x_299_ = v_reuseFailAlloc_301_;
goto v_reusejp_298_;
}
v_reusejp_298_:
{
lean_object* v___x_300_; 
v___x_300_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_300_, 0, v___x_299_);
return v___x_300_;
}
}
}
}
}
}
