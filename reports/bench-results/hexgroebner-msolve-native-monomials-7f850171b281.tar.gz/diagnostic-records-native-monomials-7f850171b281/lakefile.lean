import Lake
open Lake DSL
package F4Compare
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
lean_exe f4_compare where
  root := `Main
lean_lib F4OrderProbe where
  roots := #[`Order]

lean_lib GroebnerUpstream where
  roots := #[`Upstream.Groebner]
  globs := #[.submodules `Upstream]
