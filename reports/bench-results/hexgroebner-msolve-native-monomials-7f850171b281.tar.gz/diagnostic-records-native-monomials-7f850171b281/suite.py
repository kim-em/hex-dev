import hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path('/tmp/hex-groebner-compare')
PUBLIC=pathlib.Path('/tmp/hex-groebner-gamba')

def polynomial(text,variables,p):
    values={}
    text=re.sub(r'\s+','',text)
    if text.startswith('+'):text=text[1:]
    for term in re.findall(r'[+-]?[^+-]+',text):
        c=-1 if term.startswith('-') else 1
        if term[:1] in '+-':term=term[1:]
        powers=[0]*len(variables)
        for factor in term.split('*'):
            if factor.isdigit():c*=int(factor)
            else:
                match=re.fullmatch(r'([a-zA-Z_][a-zA-Z_0-9]*)(?:\^(\d+))?',factor)
                if not match or match[1] not in variables:raise ValueError(factor)
                powers[variables.index(match[1])]+=int(match[2] or 1)
        key=tuple(powers);values[key]=(values.get(key,0)+c)%p
    return [[list(k),c] for k,c in sorted(values.items(),reverse=True) if c]

def public_case(name,width):
    path=PUBLIC/'examples'/f'{name}-{width}.txt'
    text=path.read_text();lines=text.strip().splitlines()
    variables=[s.strip() for s in lines[0].strip().rstrip(',').split(',')]
    p=int(lines[1].rstrip(","));generators=[polynomial(s,variables,p) for s in ''.join(lines[2:]).split(',') if s.strip()]
    return dict(name=f'{name}-{width}',family=name.split('_')[0] if name.startswith('minrank') else re.sub(r'\d+$','',name),p=p,variables=len(variables),order='grevlex',generators=generators,
      provenance=dict(repository='https://github.com/gblanco92/gamba',commit=subprocess.check_output(['git','-C',str(PUBLIC),'rev-parse','HEAD'],text=True).strip(),path=str(path.relative_to(PUBLIC)),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))

if __name__=='__main__':
    names=['cyclic5','cyclic6','kat6','eco10','noon4','reimer5','minrank_d_2_p_2_q_3_r_2']
    cases=[public_case(name,width) for name in names for width in ['15','31']]
    for p in [32003,2147483647]:
        # Fixed LCG, dense homogeneous+linear+constant degree-two terms.
        n=5;state=10987;monomials=[]
        for i in range(n):
            for j in range(i,n):
                e=[0]*n;e[i]+=1;e[j]+=1;monomials.append(e)
        monomials += [[int(j==i) for j in range(n)] for i in range(n)]+[[0]*n]
        polys=[]
        for i in range(n):
            terms=[]
            for e in monomials:
                state=(1664525*state+1013904223)%2**32
                c=state%p
                if c:terms.append([e,c])
            polys.append(terms)
        cases.append(dict(name=f'quadratic5-{p}',family='dense-quadratic',p=p,variables=n,order='grevlex',generators=polys,seed=10987))
    plan=dict(schema=1,cases=cases,protocol=dict(pairs=2,orders=['AB','BA'],A='Hex candidate',B='msolve exact sparse',threads=1,timeout_seconds=10,address_space_bytes=16*1024**3,output='full reduced grevlex basis over the explicit prime field',times='whole process wall including parse and output; Hex internal candidate separately',retention='all samples, failures and outputs; no host-activity filtering'),scope='diagnostic portable baseline, not a performance milestone')
    data=json.dumps(plan,indent=2)+'\n';path=ROOT/'diagnostic-suite.json'
    if path.exists() and path.read_text()!=data:raise SystemExit('preserve frozen diagnostic suite')
    path.write_text(data)
    for c in cases:
        (ROOT/(c['name']+'.json')).write_text(json.dumps(c)+'\n')
        variables=[f'x{i}' for i in range(c['variables'])]
        lines=[]
        for f in c['generators']:
            lines.append('+'.join(str(co)+'*'+'*'.join(f'x{i}^{e}' for i,e in enumerate(es) if e) if any(es) else str(co) for es,co in f) or '0')
        (ROOT/(c['name']+'.ms')).write_text(','.join(variables)+'\n'+str(c['p'])+'\n'+',\n'.join(lines)+'\n')
    print(path,hashlib.sha256(path.read_bytes()).hexdigest())
