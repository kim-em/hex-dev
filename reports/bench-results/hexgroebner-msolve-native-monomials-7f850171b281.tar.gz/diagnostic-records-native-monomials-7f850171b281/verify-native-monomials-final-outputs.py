import json,pathlib,sys
sys.path.insert(0,'/home/kim/worktrees/hex-dev/hex-dev-issue-10987')
from scripts.oracle.groebner_singular import polynomial,canonical
root=pathlib.Path(__file__).resolve().parent
out=root/'diagnostic-records-native-monomials-7f850171b281'
plan=json.loads((root/'diagnostic-suite.json').read_text())
rows=[]
for case in plan['cases']:
 for block in [0,1]:
  a=out/f"{case['name']}-b{block}-A.stdout"
  b=out/f"{case['name']}-b{block}-B.basis"
  payload=''.join(s for s in b.read_text().splitlines() if not s.startswith('#')).strip()
  assert payload.endswith(']:') and payload.startswith('[')
  parsed=sorted(polynomial(s,case['variables'],case['p']) for s in payload[1:-2].split(','))
  hex_basis=canonical(json.loads(a.read_text())['basis'])
  row=dict(case=case['name'],block=block,equal=hex_basis==parsed,polynomials=len(hex_basis))
  rows.append(row)
  assert row['equal'],row
(out/'output-comparisons.json').write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),'complete reduced bases agree with msolve, every exponent and coefficient')
