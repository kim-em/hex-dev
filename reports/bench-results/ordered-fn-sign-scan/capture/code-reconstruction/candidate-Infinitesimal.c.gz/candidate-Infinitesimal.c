// Lean compiler output
// Module: HexOrderedFn.Infinitesimal
// Imports: public import Init public meta import Init public import HexRationalFn import all Init.Util
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_neg(lean_object*);
size_t lean_ptr_addr(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
uint8_t lp_Hex_Hex_DensePoly_isZero___redArg(lean_object*);
lean_object* l_Array_findIdx_x3f_loop___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* lp_Hex_Hex_DensePoly_coeff___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_RationalFn_defaultPlan___redArg(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_RationalFn_subWith___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
uint8_t lean_int_dec_le(lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0;
static lean_once_cell_t lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1;
static lean_once_cell_t lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2;
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_orderSign(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_compare(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_compare___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg();
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg();
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(1u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1(void){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lean_unsigned_to_nat(0u);
v___x_4_ = lean_nat_to_int(v___x_3_);
return v___x_4_;
}
}
static lean_object* _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2(void){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_5_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0);
v___x_6_ = lean_int_neg(v___x_5_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg(lean_object* v_inst_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_a_10_){
_start:
{
lean_object* v___x_11_; uint8_t v___x_12_; 
lean_inc(v_inst_7_);
lean_inc(v_a_10_);
v___x_11_ = lean_apply_2(v_inst_8_, v_a_10_, v_inst_7_);
v___x_12_ = lean_unbox(v___x_11_);
if (v___x_12_ == 0)
{
lean_object* v___x_13_; uint8_t v___x_14_; 
v___x_13_ = lean_apply_2(v_inst_9_, v_a_10_, v_inst_7_);
v___x_14_ = lean_unbox(v___x_13_);
if (v___x_14_ == 0)
{
lean_object* v___x_15_; 
v___x_15_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0);
return v___x_15_;
}
else
{
lean_object* v___x_16_; 
v___x_16_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
return v___x_16_;
}
}
else
{
lean_object* v___x_17_; 
lean_dec(v_a_10_);
lean_dec_ref(v_inst_9_);
lean_dec(v_inst_7_);
v___x_17_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2);
return v___x_17_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_orderSign(lean_object* v_K_18_, lean_object* v_inst_19_, lean_object* v_inst_20_, lean_object* v_inst_21_, lean_object* v_inst_22_, lean_object* v_a_23_){
_start:
{
lean_object* v___x_24_; 
v___x_24_ = lp_Hex_Hex_OrderedFn_orderSign___redArg(v_inst_19_, v_inst_21_, v_inst_22_, v_a_23_);
return v___x_24_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg___lam__0(lean_object* v_inst_25_, lean_object* v_inst_26_, lean_object* v_c_27_){
_start:
{
size_t v___x_28_; size_t v___x_29_; uint8_t v___x_30_; 
v___x_28_ = lean_ptr_addr(v_c_27_);
v___x_29_ = lean_ptr_addr(v_inst_25_);
v___x_30_ = lean_usize_dec_eq(v___x_28_, v___x_29_);
if (v___x_30_ == 0)
{
lean_object* v___x_31_; uint8_t v___x_32_; 
v___x_31_ = lean_apply_2(v_inst_26_, v_c_27_, v_inst_25_);
v___x_32_ = lean_unbox(v___x_31_);
if (v___x_32_ == 0)
{
uint8_t v___x_33_; 
v___x_33_ = 1;
return v___x_33_;
}
else
{
return v___x_30_;
}
}
else
{
uint8_t v___x_34_; 
lean_dec(v_c_27_);
lean_dec_ref(v_inst_26_);
lean_dec(v_inst_25_);
v___x_34_ = 0;
return v___x_34_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg___lam__0___boxed(lean_object* v_inst_35_, lean_object* v_inst_36_, lean_object* v_c_37_){
_start:
{
uint8_t v_res_38_; lean_object* v_r_39_; 
v_res_38_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg___lam__0(v_inst_35_, v_inst_36_, v_c_37_);
v_r_39_ = lean_box(v_res_38_);
return v_r_39_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg(lean_object* v_inst_40_, lean_object* v_inst_41_, lean_object* v_p_42_){
_start:
{
lean_object* v___f_43_; lean_object* v___x_44_; lean_object* v___x_45_; 
v___f_43_ = lean_alloc_closure((void*)(lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg___lam__0___boxed), 3, 2);
lean_closure_set(v___f_43_, 0, v_inst_40_);
lean_closure_set(v___f_43_, 1, v_inst_41_);
v___x_44_ = lean_unsigned_to_nat(0u);
v___x_45_ = l_Array_findIdx_x3f_loop___redArg(v___f_43_, v_p_42_, v___x_44_);
if (lean_obj_tag(v___x_45_) == 0)
{
lean_object* v___x_46_; 
v___x_46_ = lean_array_get_size(v_p_42_);
return v___x_46_;
}
else
{
lean_object* v_val_47_; 
v_val_47_ = lean_ctor_get(v___x_45_, 0);
lean_inc(v_val_47_);
lean_dec_ref_known(v___x_45_, 1);
return v_val_47_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg___boxed(lean_object* v_inst_48_, lean_object* v_inst_49_, lean_object* v_p_50_){
_start:
{
lean_object* v_res_51_; 
v_res_51_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg(v_inst_48_, v_inst_49_, v_p_50_);
lean_dec_ref(v_p_50_);
return v_res_51_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl(lean_object* v_K_52_, lean_object* v_inst_53_, lean_object* v_inst_54_, lean_object* v_p_55_){
_start:
{
lean_object* v___x_56_; 
v___x_56_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg(v_inst_53_, v_inst_54_, v_p_55_);
return v___x_56_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___boxed(lean_object* v_K_57_, lean_object* v_inst_58_, lean_object* v_inst_59_, lean_object* v_p_60_){
_start:
{
lean_object* v_res_61_; 
v_res_61_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl(v_K_57_, v_inst_58_, v_inst_59_, v_p_60_);
lean_dec_ref(v_p_60_);
return v_res_61_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(lean_object* v_inst_62_, lean_object* v_inst_63_, lean_object* v_p_64_){
_start:
{
lean_object* v___x_65_; lean_object* v___x_66_; 
lean_inc(v_inst_62_);
v___x_65_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndexImpl___redArg(v_inst_62_, v_inst_63_, v_p_64_);
v___x_66_ = lp_Hex_Hex_DensePoly_coeff___redArg(v_inst_62_, v_p_64_, v___x_65_);
lean_dec(v___x_65_);
lean_dec(v_inst_62_);
return v___x_66_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg___boxed(lean_object* v_inst_67_, lean_object* v_inst_68_, lean_object* v_p_69_){
_start:
{
lean_object* v_res_70_; 
v_res_70_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(v_inst_67_, v_inst_68_, v_p_69_);
lean_dec_ref(v_p_69_);
return v_res_70_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff(lean_object* v_K_71_, lean_object* v_inst_72_, lean_object* v_inst_73_, lean_object* v_p_74_){
_start:
{
lean_object* v___x_75_; 
v___x_75_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(v_inst_72_, v_inst_73_, v_p_74_);
return v___x_75_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___boxed(lean_object* v_K_76_, lean_object* v_inst_77_, lean_object* v_inst_78_, lean_object* v_p_79_){
_start:
{
lean_object* v_res_80_; 
v_res_80_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff(v_K_76_, v_inst_77_, v_inst_78_, v_p_79_);
lean_dec_ref(v_p_79_);
return v_res_80_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___redArg(lean_object* v_inst_81_, lean_object* v_inst_82_, lean_object* v_baseSign_83_, lean_object* v_f_84_){
_start:
{
lean_object* v_toCommRing_85_; lean_object* v_toSemiring_86_; lean_object* v_ofNat_87_; lean_object* v_num_88_; lean_object* v_den_89_; lean_object* v___x_90_; uint8_t v___x_91_; 
v_toCommRing_85_ = lean_ctor_get(v_inst_81_, 0);
lean_inc_ref(v_toCommRing_85_);
lean_dec_ref(v_inst_81_);
v_toSemiring_86_ = lean_ctor_get(v_toCommRing_85_, 0);
lean_inc_ref(v_toSemiring_86_);
lean_dec_ref(v_toCommRing_85_);
v_ofNat_87_ = lean_ctor_get(v_toSemiring_86_, 3);
lean_inc(v_ofNat_87_);
lean_dec_ref(v_toSemiring_86_);
v_num_88_ = lean_ctor_get(v_f_84_, 0);
v_den_89_ = lean_ctor_get(v_f_84_, 1);
v___x_90_ = lean_unsigned_to_nat(0u);
v___x_91_ = lp_Hex_Hex_DensePoly_isZero___redArg(v_num_88_);
if (v___x_91_ == 0)
{
lean_object* v___x_92_; lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; 
v___x_92_ = lean_apply_1(v_ofNat_87_, v___x_90_);
lean_inc_ref(v_inst_82_);
lean_inc(v___x_92_);
v___x_93_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(v___x_92_, v_inst_82_, v_num_88_);
lean_inc_ref(v_baseSign_83_);
v___x_94_ = lean_apply_1(v_baseSign_83_, v___x_93_);
v___x_95_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(v___x_92_, v_inst_82_, v_den_89_);
v___x_96_ = lean_apply_1(v_baseSign_83_, v___x_95_);
v___x_97_ = lean_int_mul(v___x_94_, v___x_96_);
lean_dec(v___x_96_);
lean_dec(v___x_94_);
return v___x_97_;
}
else
{
lean_object* v___x_98_; 
lean_dec(v_ofNat_87_);
lean_dec_ref(v_baseSign_83_);
lean_dec_ref(v_inst_82_);
v___x_98_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
return v___x_98_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___redArg___boxed(lean_object* v_inst_99_, lean_object* v_inst_100_, lean_object* v_baseSign_101_, lean_object* v_f_102_){
_start:
{
lean_object* v_res_103_; 
v_res_103_ = lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___redArg(v_inst_99_, v_inst_100_, v_baseSign_101_, v_f_102_);
lean_dec_ref(v_f_102_);
return v_res_103_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl(lean_object* v_K_104_, lean_object* v_inst_105_, lean_object* v_inst_106_, lean_object* v_baseSign_107_, lean_object* v_f_108_){
_start:
{
lean_object* v___x_109_; 
v___x_109_ = lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___redArg(v_inst_105_, v_inst_106_, v_baseSign_107_, v_f_108_);
return v___x_109_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___boxed(lean_object* v_K_110_, lean_object* v_inst_111_, lean_object* v_inst_112_, lean_object* v_baseSign_113_, lean_object* v_f_114_){
_start:
{
lean_object* v_res_115_; 
v_res_115_ = lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl(v_K_110_, v_inst_111_, v_inst_112_, v_baseSign_113_, v_f_114_);
lean_dec_ref(v_f_114_);
return v_res_115_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg(lean_object* v_inst_116_, lean_object* v_inst_117_, lean_object* v_baseSign_118_, lean_object* v_f_119_, lean_object* v_g_120_){
_start:
{
lean_object* v___x_121_; lean_object* v___x_122_; lean_object* v_s_123_; lean_object* v___x_124_; uint8_t v___x_125_; 
lean_inc_ref_n(v_inst_117_, 2);
lean_inc_ref_n(v_inst_116_, 2);
v___x_121_ = lp_Hex_Hex_RationalFn_defaultPlan___redArg(v_inst_116_, v_inst_117_);
v___x_122_ = lp_Hex_Hex_RationalFn_subWith___redArg(v_inst_116_, v_inst_117_, v___x_121_, v_f_119_, v_g_120_);
v_s_123_ = lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___redArg(v_inst_116_, v_inst_117_, v_baseSign_118_, v___x_122_);
lean_dec_ref(v___x_122_);
v___x_124_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
v___x_125_ = lean_int_dec_lt(v_s_123_, v___x_124_);
if (v___x_125_ == 0)
{
uint8_t v___x_126_; 
v___x_126_ = lean_int_dec_eq(v_s_123_, v___x_124_);
lean_dec(v_s_123_);
if (v___x_126_ == 0)
{
uint8_t v___x_127_; 
v___x_127_ = 2;
return v___x_127_;
}
else
{
uint8_t v___x_128_; 
v___x_128_ = 1;
return v___x_128_;
}
}
else
{
uint8_t v___x_129_; 
lean_dec(v_s_123_);
v___x_129_ = 0;
return v___x_129_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg___boxed(lean_object* v_inst_130_, lean_object* v_inst_131_, lean_object* v_baseSign_132_, lean_object* v_f_133_, lean_object* v_g_134_){
_start:
{
uint8_t v_res_135_; lean_object* v_r_136_; 
v_res_135_ = lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg(v_inst_130_, v_inst_131_, v_baseSign_132_, v_f_133_, v_g_134_);
v_r_136_ = lean_box(v_res_135_);
return v_r_136_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_compare(lean_object* v_K_137_, lean_object* v_inst_138_, lean_object* v_inst_139_, lean_object* v_baseSign_140_, lean_object* v_f_141_, lean_object* v_g_142_){
_start:
{
uint8_t v___x_143_; 
v___x_143_ = lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg(v_inst_138_, v_inst_139_, v_baseSign_140_, v_f_141_, v_g_142_);
return v___x_143_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_compare___boxed(lean_object* v_K_144_, lean_object* v_inst_145_, lean_object* v_inst_146_, lean_object* v_baseSign_147_, lean_object* v_f_148_, lean_object* v_g_149_){
_start:
{
uint8_t v_res_150_; lean_object* v_r_151_; 
v_res_150_ = lp_Hex_Hex_OrderedFn_Infinitesimal_compare(v_K_144_, v_inst_145_, v_inst_146_, v_baseSign_147_, v_f_148_, v_g_149_);
v_r_151_ = lean_box(v_res_150_);
return v_r_151_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg(){
_start:
{
lean_object* v___x_153_; 
v___x_153_ = lean_box(0);
return v___x_153_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg___boxed(lean_object* v___dummy_154_){
_start:
{
lean_object* v_res_155_; 
v_res_155_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg();
return v_res_155_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE(lean_object* v_K_156_, lean_object* v_inst_157_, lean_object* v_inst_158_, lean_object* v_inst_159_, lean_object* v_inst_160_){
_start:
{
lean_object* v___x_161_; 
v___x_161_ = lean_box(0);
return v___x_161_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___boxed(lean_object* v_K_162_, lean_object* v_inst_163_, lean_object* v_inst_164_, lean_object* v_inst_165_, lean_object* v_inst_166_){
_start:
{
lean_object* v_res_167_; 
v_res_167_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instLE(v_K_162_, v_inst_163_, v_inst_164_, v_inst_165_, v_inst_166_);
lean_dec_ref(v_inst_166_);
lean_dec_ref(v_inst_164_);
lean_dec_ref(v_inst_163_);
return v_res_167_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg(){
_start:
{
lean_object* v___x_169_; 
v___x_169_ = lean_box(0);
return v___x_169_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg___boxed(lean_object* v___dummy_170_){
_start:
{
lean_object* v_res_171_; 
v_res_171_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg();
return v_res_171_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT(lean_object* v_K_172_, lean_object* v_inst_173_, lean_object* v_inst_174_, lean_object* v_inst_175_, lean_object* v_inst_176_){
_start:
{
lean_object* v___x_177_; 
v___x_177_ = lean_box(0);
return v___x_177_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___boxed(lean_object* v_K_178_, lean_object* v_inst_179_, lean_object* v_inst_180_, lean_object* v_inst_181_, lean_object* v_inst_182_){
_start:
{
lean_object* v_res_183_; 
v_res_183_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instLT(v_K_178_, v_inst_179_, v_inst_180_, v_inst_181_, v_inst_182_);
lean_dec_ref(v_inst_182_);
lean_dec_ref(v_inst_180_);
lean_dec_ref(v_inst_179_);
return v_res_183_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg(lean_object* v_inst_184_, lean_object* v_inst_185_, lean_object* v_inst_186_, lean_object* v_inst_187_, lean_object* v_x_188_, lean_object* v_x_189_){
_start:
{
lean_object* v_toCommRing_190_; lean_object* v_toSemiring_191_; lean_object* v_ofNat_192_; lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_196_; lean_object* v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; uint8_t v___x_200_; 
v_toCommRing_190_ = lean_ctor_get(v_inst_184_, 0);
v_toSemiring_191_ = lean_ctor_get(v_toCommRing_190_, 0);
v_ofNat_192_ = lean_ctor_get(v_toSemiring_191_, 3);
v___x_193_ = lean_unsigned_to_nat(0u);
lean_inc(v_ofNat_192_);
v___x_194_ = lean_apply_1(v_ofNat_192_, v___x_193_);
lean_inc_ref_n(v_inst_185_, 3);
v___x_195_ = lean_alloc_closure((void*)(lp_Hex_Hex_OrderedFn_orderSign), 6, 5);
lean_closure_set(v___x_195_, 0, lean_box(0));
lean_closure_set(v___x_195_, 1, v___x_194_);
lean_closure_set(v___x_195_, 2, v_inst_186_);
lean_closure_set(v___x_195_, 3, v_inst_187_);
lean_closure_set(v___x_195_, 4, v_inst_185_);
lean_inc_ref_n(v_inst_184_, 2);
v___x_196_ = lp_Hex_Hex_RationalFn_defaultPlan___redArg(v_inst_184_, v_inst_185_);
v___x_197_ = lp_Hex_Hex_RationalFn_subWith___redArg(v_inst_184_, v_inst_185_, v___x_196_, v_x_188_, v_x_189_);
v___x_198_ = lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___redArg(v_inst_184_, v_inst_185_, v___x_195_, v___x_197_);
lean_dec_ref(v___x_197_);
v___x_199_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
v___x_200_ = lean_int_dec_le(v___x_198_, v___x_199_);
lean_dec(v___x_198_);
return v___x_200_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg___boxed(lean_object* v_inst_201_, lean_object* v_inst_202_, lean_object* v_inst_203_, lean_object* v_inst_204_, lean_object* v_x_205_, lean_object* v_x_206_){
_start:
{
uint8_t v_res_207_; lean_object* v_r_208_; 
v_res_207_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg(v_inst_201_, v_inst_202_, v_inst_203_, v_inst_204_, v_x_205_, v_x_206_);
v_r_208_ = lean_box(v_res_207_);
return v_r_208_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE(lean_object* v_K_209_, lean_object* v_inst_210_, lean_object* v_inst_211_, lean_object* v_inst_212_, lean_object* v_inst_213_, lean_object* v_x_214_, lean_object* v_x_215_){
_start:
{
uint8_t v___x_216_; 
v___x_216_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg(v_inst_210_, v_inst_211_, v_inst_212_, v_inst_213_, v_x_214_, v_x_215_);
return v___x_216_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___boxed(lean_object* v_K_217_, lean_object* v_inst_218_, lean_object* v_inst_219_, lean_object* v_inst_220_, lean_object* v_inst_221_, lean_object* v_x_222_, lean_object* v_x_223_){
_start:
{
uint8_t v_res_224_; lean_object* v_r_225_; 
v_res_224_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE(v_K_217_, v_inst_218_, v_inst_219_, v_inst_220_, v_inst_221_, v_x_222_, v_x_223_);
v_r_225_ = lean_box(v_res_224_);
return v_r_225_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg(lean_object* v_inst_226_, lean_object* v_inst_227_, lean_object* v_inst_228_, lean_object* v_inst_229_, lean_object* v_x_230_, lean_object* v_x_231_){
_start:
{
lean_object* v_toCommRing_232_; lean_object* v_toSemiring_233_; lean_object* v_ofNat_234_; lean_object* v___x_235_; lean_object* v___x_236_; lean_object* v___x_237_; lean_object* v___x_238_; lean_object* v___x_239_; lean_object* v___x_240_; lean_object* v___x_241_; uint8_t v___x_242_; 
v_toCommRing_232_ = lean_ctor_get(v_inst_226_, 0);
v_toSemiring_233_ = lean_ctor_get(v_toCommRing_232_, 0);
v_ofNat_234_ = lean_ctor_get(v_toSemiring_233_, 3);
v___x_235_ = lean_unsigned_to_nat(0u);
lean_inc(v_ofNat_234_);
v___x_236_ = lean_apply_1(v_ofNat_234_, v___x_235_);
lean_inc_ref_n(v_inst_227_, 3);
v___x_237_ = lean_alloc_closure((void*)(lp_Hex_Hex_OrderedFn_orderSign), 6, 5);
lean_closure_set(v___x_237_, 0, lean_box(0));
lean_closure_set(v___x_237_, 1, v___x_236_);
lean_closure_set(v___x_237_, 2, v_inst_228_);
lean_closure_set(v___x_237_, 3, v_inst_229_);
lean_closure_set(v___x_237_, 4, v_inst_227_);
lean_inc_ref_n(v_inst_226_, 2);
v___x_238_ = lp_Hex_Hex_RationalFn_defaultPlan___redArg(v_inst_226_, v_inst_227_);
v___x_239_ = lp_Hex_Hex_RationalFn_subWith___redArg(v_inst_226_, v_inst_227_, v___x_238_, v_x_230_, v_x_231_);
v___x_240_ = lp_Hex_Hex_OrderedFn_Infinitesimal_signImpl___redArg(v_inst_226_, v_inst_227_, v___x_237_, v___x_239_);
lean_dec_ref(v___x_239_);
v___x_241_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
v___x_242_ = lean_int_dec_lt(v___x_240_, v___x_241_);
lean_dec(v___x_240_);
return v___x_242_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg___boxed(lean_object* v_inst_243_, lean_object* v_inst_244_, lean_object* v_inst_245_, lean_object* v_inst_246_, lean_object* v_x_247_, lean_object* v_x_248_){
_start:
{
uint8_t v_res_249_; lean_object* v_r_250_; 
v_res_249_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg(v_inst_243_, v_inst_244_, v_inst_245_, v_inst_246_, v_x_247_, v_x_248_);
v_r_250_ = lean_box(v_res_249_);
return v_r_250_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT(lean_object* v_K_251_, lean_object* v_inst_252_, lean_object* v_inst_253_, lean_object* v_inst_254_, lean_object* v_inst_255_, lean_object* v_x_256_, lean_object* v_x_257_){
_start:
{
uint8_t v___x_258_; 
v___x_258_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg(v_inst_252_, v_inst_253_, v_inst_254_, v_inst_255_, v_x_256_, v_x_257_);
return v___x_258_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___boxed(lean_object* v_K_259_, lean_object* v_inst_260_, lean_object* v_inst_261_, lean_object* v_inst_262_, lean_object* v_inst_263_, lean_object* v_x_264_, lean_object* v_x_265_){
_start:
{
uint8_t v_res_266_; lean_object* v_r_267_; 
v_res_266_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT(v_K_259_, v_inst_260_, v_inst_261_, v_inst_262_, v_inst_263_, v_x_264_, v_x_265_);
v_r_267_ = lean_box(v_res_266_);
return v_r_267_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexRationalFn(uint8_t builtin);
lean_object* runtime_initialize_Init_Util(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexOrderedFn_Infinitesimal(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRationalFn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Init_Util(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexOrderedFn_Infinitesimal(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexRationalFn(uint8_t builtin);
lean_object* initialize_Init_Util(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexOrderedFn_Infinitesimal(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexRationalFn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init_Util(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexOrderedFn_Infinitesimal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexOrderedFn_Infinitesimal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexOrderedFn_Infinitesimal(builtin);
}
#ifdef __cplusplus
}
#endif
