// Lean compiler output
// Module: HexOrderedFn.Infinitesimal
// Imports: public import Init public meta import Init public import HexRationalFn
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_neg(lean_object*);
lean_object* lp_Hex_Hex_DensePoly_instOfNat___redArg(lean_object*, lean_object*, lean_object*);
uint8_t l_Array_instDecidableEqImpl___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Array_findIdx_x3f_loop___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* lp_Hex_Hex_DensePoly_coeff___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_RationalFn_defaultPlan___redArg(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_RationalFn_subWith___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
uint8_t lean_int_dec_le(lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0;
static lean_once_cell_t lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1;
static lean_once_cell_t lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2;
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_orderSign(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_sign___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_sign___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_sign(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_sign___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_compare(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_compare___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg();
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg();
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(1u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1(void){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lean_unsigned_to_nat(0u);
v___x_4_ = lean_nat_to_int(v___x_3_);
return v___x_4_;
}
}
static lean_object* _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2(void){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_5_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0);
v___x_6_ = lean_int_neg(v___x_5_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_orderSign___redArg(lean_object* v_inst_7_, lean_object* v_inst_8_, lean_object* v_inst_9_, lean_object* v_a_10_){
_start:
{
lean_object* v___x_11_; uint8_t v___x_12_; 
lean_inc(v_inst_7_);
lean_inc(v_a_10_);
v___x_11_ = lean_apply_2(v_inst_8_, v_a_10_, v_inst_7_);
v___x_12_ = lean_unbox(v___x_11_);
if (v___x_12_ == 0)
{
lean_object* v___x_13_; uint8_t v___x_14_; 
v___x_13_ = lean_apply_2(v_inst_9_, v_a_10_, v_inst_7_);
v___x_14_ = lean_unbox(v___x_13_);
if (v___x_14_ == 0)
{
lean_object* v___x_15_; 
v___x_15_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__0);
return v___x_15_;
}
else
{
lean_object* v___x_16_; 
v___x_16_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
return v___x_16_;
}
}
else
{
lean_object* v___x_17_; 
lean_dec(v_a_10_);
lean_dec_ref(v_inst_9_);
lean_dec(v_inst_7_);
v___x_17_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__2);
return v___x_17_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_orderSign(lean_object* v_K_18_, lean_object* v_inst_19_, lean_object* v_inst_20_, lean_object* v_inst_21_, lean_object* v_inst_22_, lean_object* v_a_23_){
_start:
{
lean_object* v___x_24_; 
v___x_24_ = lp_Hex_Hex_OrderedFn_orderSign___redArg(v_inst_19_, v_inst_21_, v_inst_22_, v_a_23_);
return v___x_24_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg___lam__0(lean_object* v_inst_25_, lean_object* v_inst_26_, lean_object* v_c_27_){
_start:
{
lean_object* v___x_28_; uint8_t v___x_29_; 
v___x_28_ = lean_apply_2(v_inst_25_, v_c_27_, v_inst_26_);
v___x_29_ = lean_unbox(v___x_28_);
if (v___x_29_ == 0)
{
uint8_t v___x_30_; 
v___x_30_ = 1;
return v___x_30_;
}
else
{
uint8_t v___x_31_; 
v___x_31_ = 0;
return v___x_31_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg___lam__0___boxed(lean_object* v_inst_32_, lean_object* v_inst_33_, lean_object* v_c_34_){
_start:
{
uint8_t v_res_35_; lean_object* v_r_36_; 
v_res_35_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg___lam__0(v_inst_32_, v_inst_33_, v_c_34_);
v_r_36_ = lean_box(v_res_35_);
return v_r_36_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg(lean_object* v_inst_37_, lean_object* v_inst_38_, lean_object* v_p_39_){
_start:
{
lean_object* v___f_40_; lean_object* v___x_41_; lean_object* v___x_42_; 
v___f_40_ = lean_alloc_closure((void*)(lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg___lam__0___boxed), 3, 2);
lean_closure_set(v___f_40_, 0, v_inst_38_);
lean_closure_set(v___f_40_, 1, v_inst_37_);
v___x_41_ = lean_unsigned_to_nat(0u);
v___x_42_ = l_Array_findIdx_x3f_loop___redArg(v___f_40_, v_p_39_, v___x_41_);
if (lean_obj_tag(v___x_42_) == 0)
{
lean_object* v___x_43_; 
v___x_43_ = lean_array_get_size(v_p_39_);
return v___x_43_;
}
else
{
lean_object* v_val_44_; 
v_val_44_ = lean_ctor_get(v___x_42_, 0);
lean_inc(v_val_44_);
lean_dec_ref_known(v___x_42_, 1);
return v_val_44_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg___boxed(lean_object* v_inst_45_, lean_object* v_inst_46_, lean_object* v_p_47_){
_start:
{
lean_object* v_res_48_; 
v_res_48_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg(v_inst_45_, v_inst_46_, v_p_47_);
lean_dec_ref(v_p_47_);
return v_res_48_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex(lean_object* v_K_49_, lean_object* v_inst_50_, lean_object* v_inst_51_, lean_object* v_p_52_){
_start:
{
lean_object* v___x_53_; 
v___x_53_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg(v_inst_50_, v_inst_51_, v_p_52_);
return v___x_53_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___boxed(lean_object* v_K_54_, lean_object* v_inst_55_, lean_object* v_inst_56_, lean_object* v_p_57_){
_start:
{
lean_object* v_res_58_; 
v_res_58_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex(v_K_54_, v_inst_55_, v_inst_56_, v_p_57_);
lean_dec_ref(v_p_57_);
return v_res_58_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(lean_object* v_inst_59_, lean_object* v_inst_60_, lean_object* v_p_61_){
_start:
{
lean_object* v___x_62_; lean_object* v___x_63_; 
lean_inc(v_inst_59_);
v___x_62_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestIndex___redArg(v_inst_59_, v_inst_60_, v_p_61_);
v___x_63_ = lp_Hex_Hex_DensePoly_coeff___redArg(v_inst_59_, v_p_61_, v___x_62_);
lean_dec(v___x_62_);
lean_dec(v_inst_59_);
return v___x_63_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg___boxed(lean_object* v_inst_64_, lean_object* v_inst_65_, lean_object* v_p_66_){
_start:
{
lean_object* v_res_67_; 
v_res_67_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(v_inst_64_, v_inst_65_, v_p_66_);
lean_dec_ref(v_p_66_);
return v_res_67_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff(lean_object* v_K_68_, lean_object* v_inst_69_, lean_object* v_inst_70_, lean_object* v_p_71_){
_start:
{
lean_object* v___x_72_; 
v___x_72_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(v_inst_69_, v_inst_70_, v_p_71_);
return v___x_72_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___boxed(lean_object* v_K_73_, lean_object* v_inst_74_, lean_object* v_inst_75_, lean_object* v_p_76_){
_start:
{
lean_object* v_res_77_; 
v_res_77_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff(v_K_73_, v_inst_74_, v_inst_75_, v_p_76_);
lean_dec_ref(v_p_76_);
return v_res_77_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_sign___redArg(lean_object* v_inst_78_, lean_object* v_inst_79_, lean_object* v_baseSign_80_, lean_object* v_f_81_){
_start:
{
lean_object* v_toCommRing_82_; lean_object* v_toSemiring_83_; lean_object* v_ofNat_84_; lean_object* v_num_85_; lean_object* v_den_86_; lean_object* v___x_87_; lean_object* v___x_88_; uint8_t v_decide_89_; 
v_toCommRing_82_ = lean_ctor_get(v_inst_78_, 0);
lean_inc_ref(v_toCommRing_82_);
lean_dec_ref(v_inst_78_);
v_toSemiring_83_ = lean_ctor_get(v_toCommRing_82_, 0);
v_ofNat_84_ = lean_ctor_get(v_toSemiring_83_, 3);
lean_inc(v_ofNat_84_);
v_num_85_ = lean_ctor_get(v_f_81_, 0);
v_den_86_ = lean_ctor_get(v_f_81_, 1);
v___x_87_ = lean_unsigned_to_nat(0u);
lean_inc_ref_n(v_inst_79_, 2);
v___x_88_ = lp_Hex_Hex_DensePoly_instOfNat___redArg(v_toCommRing_82_, v_inst_79_, v___x_87_);
v_decide_89_ = l_Array_instDecidableEqImpl___redArg(v_inst_79_, v_num_85_, v___x_88_);
lean_dec_ref(v___x_88_);
if (v_decide_89_ == 0)
{
lean_object* v___x_90_; lean_object* v___x_91_; lean_object* v___x_92_; lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; 
v___x_90_ = lean_apply_1(v_ofNat_84_, v___x_87_);
lean_inc_ref(v_inst_79_);
lean_inc(v___x_90_);
v___x_91_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(v___x_90_, v_inst_79_, v_num_85_);
lean_inc_ref(v_baseSign_80_);
v___x_92_ = lean_apply_1(v_baseSign_80_, v___x_91_);
v___x_93_ = lp_Hex_Hex_OrderedFn_Infinitesimal_lowestCoeff___redArg(v___x_90_, v_inst_79_, v_den_86_);
v___x_94_ = lean_apply_1(v_baseSign_80_, v___x_93_);
v___x_95_ = lean_int_mul(v___x_92_, v___x_94_);
lean_dec(v___x_94_);
lean_dec(v___x_92_);
return v___x_95_;
}
else
{
lean_object* v___x_96_; 
lean_dec(v_ofNat_84_);
lean_dec_ref(v_baseSign_80_);
lean_dec_ref(v_inst_79_);
v___x_96_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
return v___x_96_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_sign___redArg___boxed(lean_object* v_inst_97_, lean_object* v_inst_98_, lean_object* v_baseSign_99_, lean_object* v_f_100_){
_start:
{
lean_object* v_res_101_; 
v_res_101_ = lp_Hex_Hex_OrderedFn_Infinitesimal_sign___redArg(v_inst_97_, v_inst_98_, v_baseSign_99_, v_f_100_);
lean_dec_ref(v_f_100_);
return v_res_101_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_sign(lean_object* v_K_102_, lean_object* v_inst_103_, lean_object* v_inst_104_, lean_object* v_baseSign_105_, lean_object* v_f_106_){
_start:
{
lean_object* v___x_107_; 
v___x_107_ = lp_Hex_Hex_OrderedFn_Infinitesimal_sign___redArg(v_inst_103_, v_inst_104_, v_baseSign_105_, v_f_106_);
return v___x_107_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_sign___boxed(lean_object* v_K_108_, lean_object* v_inst_109_, lean_object* v_inst_110_, lean_object* v_baseSign_111_, lean_object* v_f_112_){
_start:
{
lean_object* v_res_113_; 
v_res_113_ = lp_Hex_Hex_OrderedFn_Infinitesimal_sign(v_K_108_, v_inst_109_, v_inst_110_, v_baseSign_111_, v_f_112_);
lean_dec_ref(v_f_112_);
return v_res_113_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg(lean_object* v_inst_114_, lean_object* v_inst_115_, lean_object* v_baseSign_116_, lean_object* v_f_117_, lean_object* v_g_118_){
_start:
{
lean_object* v___x_119_; lean_object* v___x_120_; lean_object* v_s_121_; lean_object* v___x_122_; uint8_t v___x_123_; 
lean_inc_ref_n(v_inst_115_, 2);
lean_inc_ref_n(v_inst_114_, 2);
v___x_119_ = lp_Hex_Hex_RationalFn_defaultPlan___redArg(v_inst_114_, v_inst_115_);
v___x_120_ = lp_Hex_Hex_RationalFn_subWith___redArg(v_inst_114_, v_inst_115_, v___x_119_, v_f_117_, v_g_118_);
v_s_121_ = lp_Hex_Hex_OrderedFn_Infinitesimal_sign___redArg(v_inst_114_, v_inst_115_, v_baseSign_116_, v___x_120_);
lean_dec_ref(v___x_120_);
v___x_122_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
v___x_123_ = lean_int_dec_lt(v_s_121_, v___x_122_);
if (v___x_123_ == 0)
{
uint8_t v___x_124_; 
v___x_124_ = lean_int_dec_eq(v_s_121_, v___x_122_);
lean_dec(v_s_121_);
if (v___x_124_ == 0)
{
uint8_t v___x_125_; 
v___x_125_ = 2;
return v___x_125_;
}
else
{
uint8_t v___x_126_; 
v___x_126_ = 1;
return v___x_126_;
}
}
else
{
uint8_t v___x_127_; 
lean_dec(v_s_121_);
v___x_127_ = 0;
return v___x_127_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg___boxed(lean_object* v_inst_128_, lean_object* v_inst_129_, lean_object* v_baseSign_130_, lean_object* v_f_131_, lean_object* v_g_132_){
_start:
{
uint8_t v_res_133_; lean_object* v_r_134_; 
v_res_133_ = lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg(v_inst_128_, v_inst_129_, v_baseSign_130_, v_f_131_, v_g_132_);
v_r_134_ = lean_box(v_res_133_);
return v_r_134_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_compare(lean_object* v_K_135_, lean_object* v_inst_136_, lean_object* v_inst_137_, lean_object* v_baseSign_138_, lean_object* v_f_139_, lean_object* v_g_140_){
_start:
{
uint8_t v___x_141_; 
v___x_141_ = lp_Hex_Hex_OrderedFn_Infinitesimal_compare___redArg(v_inst_136_, v_inst_137_, v_baseSign_138_, v_f_139_, v_g_140_);
return v___x_141_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_compare___boxed(lean_object* v_K_142_, lean_object* v_inst_143_, lean_object* v_inst_144_, lean_object* v_baseSign_145_, lean_object* v_f_146_, lean_object* v_g_147_){
_start:
{
uint8_t v_res_148_; lean_object* v_r_149_; 
v_res_148_ = lp_Hex_Hex_OrderedFn_Infinitesimal_compare(v_K_142_, v_inst_143_, v_inst_144_, v_baseSign_145_, v_f_146_, v_g_147_);
v_r_149_ = lean_box(v_res_148_);
return v_r_149_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg(){
_start:
{
lean_object* v___x_151_; 
v___x_151_ = lean_box(0);
return v___x_151_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg___boxed(lean_object* v___dummy_152_){
_start:
{
lean_object* v_res_153_; 
v_res_153_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___redArg();
return v_res_153_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE(lean_object* v_K_154_, lean_object* v_inst_155_, lean_object* v_inst_156_, lean_object* v_inst_157_, lean_object* v_inst_158_){
_start:
{
lean_object* v___x_159_; 
v___x_159_ = lean_box(0);
return v___x_159_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLE___boxed(lean_object* v_K_160_, lean_object* v_inst_161_, lean_object* v_inst_162_, lean_object* v_inst_163_, lean_object* v_inst_164_){
_start:
{
lean_object* v_res_165_; 
v_res_165_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instLE(v_K_160_, v_inst_161_, v_inst_162_, v_inst_163_, v_inst_164_);
lean_dec_ref(v_inst_164_);
lean_dec_ref(v_inst_162_);
lean_dec_ref(v_inst_161_);
return v_res_165_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg(){
_start:
{
lean_object* v___x_167_; 
v___x_167_ = lean_box(0);
return v___x_167_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg___boxed(lean_object* v___dummy_168_){
_start:
{
lean_object* v_res_169_; 
v_res_169_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___redArg();
return v_res_169_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT(lean_object* v_K_170_, lean_object* v_inst_171_, lean_object* v_inst_172_, lean_object* v_inst_173_, lean_object* v_inst_174_){
_start:
{
lean_object* v___x_175_; 
v___x_175_ = lean_box(0);
return v___x_175_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instLT___boxed(lean_object* v_K_176_, lean_object* v_inst_177_, lean_object* v_inst_178_, lean_object* v_inst_179_, lean_object* v_inst_180_){
_start:
{
lean_object* v_res_181_; 
v_res_181_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instLT(v_K_176_, v_inst_177_, v_inst_178_, v_inst_179_, v_inst_180_);
lean_dec_ref(v_inst_180_);
lean_dec_ref(v_inst_178_);
lean_dec_ref(v_inst_177_);
return v_res_181_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg(lean_object* v_inst_182_, lean_object* v_inst_183_, lean_object* v_inst_184_, lean_object* v_inst_185_, lean_object* v_x_186_, lean_object* v_x_187_){
_start:
{
lean_object* v_toCommRing_188_; lean_object* v_toSemiring_189_; lean_object* v_ofNat_190_; lean_object* v___x_191_; lean_object* v___x_192_; lean_object* v___x_193_; lean_object* v___x_194_; lean_object* v___x_195_; lean_object* v___x_196_; lean_object* v___x_197_; uint8_t v___x_198_; 
v_toCommRing_188_ = lean_ctor_get(v_inst_182_, 0);
v_toSemiring_189_ = lean_ctor_get(v_toCommRing_188_, 0);
v_ofNat_190_ = lean_ctor_get(v_toSemiring_189_, 3);
v___x_191_ = lean_unsigned_to_nat(0u);
lean_inc(v_ofNat_190_);
v___x_192_ = lean_apply_1(v_ofNat_190_, v___x_191_);
lean_inc_ref_n(v_inst_183_, 3);
v___x_193_ = lean_alloc_closure((void*)(lp_Hex_Hex_OrderedFn_orderSign), 6, 5);
lean_closure_set(v___x_193_, 0, lean_box(0));
lean_closure_set(v___x_193_, 1, v___x_192_);
lean_closure_set(v___x_193_, 2, v_inst_184_);
lean_closure_set(v___x_193_, 3, v_inst_185_);
lean_closure_set(v___x_193_, 4, v_inst_183_);
lean_inc_ref_n(v_inst_182_, 2);
v___x_194_ = lp_Hex_Hex_RationalFn_defaultPlan___redArg(v_inst_182_, v_inst_183_);
v___x_195_ = lp_Hex_Hex_RationalFn_subWith___redArg(v_inst_182_, v_inst_183_, v___x_194_, v_x_186_, v_x_187_);
v___x_196_ = lp_Hex_Hex_OrderedFn_Infinitesimal_sign___redArg(v_inst_182_, v_inst_183_, v___x_193_, v___x_195_);
lean_dec_ref(v___x_195_);
v___x_197_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
v___x_198_ = lean_int_dec_le(v___x_196_, v___x_197_);
lean_dec(v___x_196_);
return v___x_198_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg___boxed(lean_object* v_inst_199_, lean_object* v_inst_200_, lean_object* v_inst_201_, lean_object* v_inst_202_, lean_object* v_x_203_, lean_object* v_x_204_){
_start:
{
uint8_t v_res_205_; lean_object* v_r_206_; 
v_res_205_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg(v_inst_199_, v_inst_200_, v_inst_201_, v_inst_202_, v_x_203_, v_x_204_);
v_r_206_ = lean_box(v_res_205_);
return v_r_206_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE(lean_object* v_K_207_, lean_object* v_inst_208_, lean_object* v_inst_209_, lean_object* v_inst_210_, lean_object* v_inst_211_, lean_object* v_x_212_, lean_object* v_x_213_){
_start:
{
uint8_t v___x_214_; 
v___x_214_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___redArg(v_inst_208_, v_inst_209_, v_inst_210_, v_inst_211_, v_x_212_, v_x_213_);
return v___x_214_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE___boxed(lean_object* v_K_215_, lean_object* v_inst_216_, lean_object* v_inst_217_, lean_object* v_inst_218_, lean_object* v_inst_219_, lean_object* v_x_220_, lean_object* v_x_221_){
_start:
{
uint8_t v_res_222_; lean_object* v_r_223_; 
v_res_222_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLE(v_K_215_, v_inst_216_, v_inst_217_, v_inst_218_, v_inst_219_, v_x_220_, v_x_221_);
v_r_223_ = lean_box(v_res_222_);
return v_r_223_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg(lean_object* v_inst_224_, lean_object* v_inst_225_, lean_object* v_inst_226_, lean_object* v_inst_227_, lean_object* v_x_228_, lean_object* v_x_229_){
_start:
{
lean_object* v_toCommRing_230_; lean_object* v_toSemiring_231_; lean_object* v_ofNat_232_; lean_object* v___x_233_; lean_object* v___x_234_; lean_object* v___x_235_; lean_object* v___x_236_; lean_object* v___x_237_; lean_object* v___x_238_; lean_object* v___x_239_; uint8_t v___x_240_; 
v_toCommRing_230_ = lean_ctor_get(v_inst_224_, 0);
v_toSemiring_231_ = lean_ctor_get(v_toCommRing_230_, 0);
v_ofNat_232_ = lean_ctor_get(v_toSemiring_231_, 3);
v___x_233_ = lean_unsigned_to_nat(0u);
lean_inc(v_ofNat_232_);
v___x_234_ = lean_apply_1(v_ofNat_232_, v___x_233_);
lean_inc_ref_n(v_inst_225_, 3);
v___x_235_ = lean_alloc_closure((void*)(lp_Hex_Hex_OrderedFn_orderSign), 6, 5);
lean_closure_set(v___x_235_, 0, lean_box(0));
lean_closure_set(v___x_235_, 1, v___x_234_);
lean_closure_set(v___x_235_, 2, v_inst_226_);
lean_closure_set(v___x_235_, 3, v_inst_227_);
lean_closure_set(v___x_235_, 4, v_inst_225_);
lean_inc_ref_n(v_inst_224_, 2);
v___x_236_ = lp_Hex_Hex_RationalFn_defaultPlan___redArg(v_inst_224_, v_inst_225_);
v___x_237_ = lp_Hex_Hex_RationalFn_subWith___redArg(v_inst_224_, v_inst_225_, v___x_236_, v_x_228_, v_x_229_);
v___x_238_ = lp_Hex_Hex_OrderedFn_Infinitesimal_sign___redArg(v_inst_224_, v_inst_225_, v___x_235_, v___x_237_);
lean_dec_ref(v___x_237_);
v___x_239_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1, &lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_orderSign___redArg___closed__1);
v___x_240_ = lean_int_dec_lt(v___x_238_, v___x_239_);
lean_dec(v___x_238_);
return v___x_240_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg___boxed(lean_object* v_inst_241_, lean_object* v_inst_242_, lean_object* v_inst_243_, lean_object* v_inst_244_, lean_object* v_x_245_, lean_object* v_x_246_){
_start:
{
uint8_t v_res_247_; lean_object* v_r_248_; 
v_res_247_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg(v_inst_241_, v_inst_242_, v_inst_243_, v_inst_244_, v_x_245_, v_x_246_);
v_r_248_ = lean_box(v_res_247_);
return v_r_248_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT(lean_object* v_K_249_, lean_object* v_inst_250_, lean_object* v_inst_251_, lean_object* v_inst_252_, lean_object* v_inst_253_, lean_object* v_x_254_, lean_object* v_x_255_){
_start:
{
uint8_t v___x_256_; 
v___x_256_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___redArg(v_inst_250_, v_inst_251_, v_inst_252_, v_inst_253_, v_x_254_, v_x_255_);
return v___x_256_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT___boxed(lean_object* v_K_257_, lean_object* v_inst_258_, lean_object* v_inst_259_, lean_object* v_inst_260_, lean_object* v_inst_261_, lean_object* v_x_262_, lean_object* v_x_263_){
_start:
{
uint8_t v_res_264_; lean_object* v_r_265_; 
v_res_264_ = lp_Hex_Hex_OrderedFn_Infinitesimal_instDecidableLT(v_K_257_, v_inst_258_, v_inst_259_, v_inst_260_, v_inst_261_, v_x_262_, v_x_263_);
v_r_265_ = lean_box(v_res_264_);
return v_r_265_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexRationalFn(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexOrderedFn_Infinitesimal(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexRationalFn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexOrderedFn_Infinitesimal(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexRationalFn(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexOrderedFn_Infinitesimal(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexRationalFn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexOrderedFn_Infinitesimal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexOrderedFn_Infinitesimal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexOrderedFn_Infinitesimal(builtin);
}
#ifdef __cplusplus
}
#endif
