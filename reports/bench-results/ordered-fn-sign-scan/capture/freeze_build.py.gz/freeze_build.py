"""Bind the concrete OrderedFn source-change builds; collects no timing samples."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT = Path(sys.argv[1]).resolve()
LABEL = sys.argv[2]
if LABEL not in {'baseline', 'candidate'}:
    raise RuntimeError('expected baseline or candidate build')
OUT = Path(__file__).resolve().parent

def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def selected(path):
    return path.suffix in {'.lean', '.c', '.h', '.cpp', '.hpp'} or path.name in {
        'lakefile.lean', 'lakefile.toml', 'lake-manifest.json', 'lean-toolchain'}

sys.path.insert(0, str(ROOT))
from scripts.ci import check_benches_mathlib_free as boundary

def snapshot():
    status = git('status', '--porcelain')
    if status:
        raise RuntimeError('uncommitted source: ' + status)
    sources = {name: sha(ROOT / name) for name in git('ls-files').splitlines()
               if selected(Path(name))}
    packages = {}
    manifest = json.loads((ROOT / 'lake-manifest.json').read_text())
    for item in manifest['packages']:
        name = item['name'].strip('«»')
        directory = ROOT / '.lake/packages' / name
        head = git('rev-parse', 'HEAD', cwd=directory)
        dirty = git('status', '--porcelain', cwd=directory)
        if head != item['rev'] or dirty:
            raise RuntimeError('dirty or unpinned dependency: ' + name)
        packages[name] = {'head': head, 'status': dirty}
        for relative in git('ls-files', cwd=directory).splitlines():
            path = directory / relative
            if path.name in {'lakefile.lean', 'lakefile.toml', 'lake-manifest.json', 'lean-toolchain'}:
                sources[str(path.relative_to(ROOT))] = sha(path)
    target = boundary._parse_exe_targets(ROOT / 'lakefile.lean')['hexorderedfn_bench']
    pending, visited, files, builtins = [target.root], set(), {}, []
    native_packages = set()
    while pending:
        module = pending.pop()
        if module in visited:
            continue
        visited.add(module)
        if module.split('.')[0] in {'Mathlib', 'TauCeti'}:
            raise RuntimeError('companion in native closure: ' + module)
        path = boundary._resolve_module(module, target, ROOT)
        if path is None:
            if module.split('.')[0] not in {'Init', 'Std', 'Lean'}:
                raise RuntimeError('unresolved native import: ' + module)
            builtins.append(module)
            continue
        relative = path.relative_to(ROOT)
        files[str(relative)] = sha(path)
        sources[str(relative)] = files[str(relative)]
        if relative.parts[:2] == ('.lake', 'packages'):
            if relative.parts[2].lower() in {'mathlib', 'tauceti'}:
                raise RuntimeError('companion source in native closure: ' + str(relative))
            native_packages.add(relative.parts[2])
        pending.extend(boundary._parse_imports(path))
    for name in native_packages:
        if name not in packages:
            raise RuntimeError('native dependency absent from pinned manifest: ' + name)
        directory = ROOT / '.lake/packages' / name
        for relative in git('ls-files', cwd=directory).splitlines():
            path = directory / relative
            if selected(path):
                sources[str(path.relative_to(ROOT))] = sha(path)
    return {'root': str(ROOT), 'head': git('rev-parse', 'HEAD'), 'status': status,
            'sources': sources, 'packages': packages,
            'native_import_closure': {'root': target.root, 'files': files,
                'builtins': sorted(builtins), 'mathlib_tau_ceti_free': True,
                'resolver_sha256': sha(Path(boundary.__file__))}}

before_path = OUT / (LABEL + '-inputs-before.json')
before = snapshot()
with before_path.open('x') as handle:
    json.dump(before, handle, indent=2)
    handle.write('\n')
command = ['env', 'LEAN_NUM_THREADS=2', 'lake', 'build', 'hexorderedfn_bench']
if LABEL == 'candidate':
    command.append('HexOrderedFnTests')
with (OUT / (LABEL + '-build.log')).open('x') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
if result.returncode:
    raise RuntimeError('build failed; retained log: ' + LABEL)
after = snapshot()
with (OUT / (LABEL + '-inputs-after.json')).open('x') as handle:
    json.dump(after, handle, indent=2)
    handle.write('\n')
if before != after:
    raise RuntimeError('build inputs changed')
binary = OUT / (LABEL + '-bench')
if binary.exists():
    raise RuntimeError('refusing to replace frozen executable')
shutil.copy2(ROOT / '.lake/build/bin/hexorderedfn_bench', binary)
if not os.access(binary, os.X_OK):
    raise RuntimeError('copied executable lacks execute permission')
before.update(binary=str(binary), binary_sha256=sha(binary), executable=True,
              command=command, build_result='success', inputs_unchanged=True,
              measurements_collected=False)
for action in ['list', 'verify']:
    with (OUT / (LABEL + '-' + action + '.stdout')).open('x') as stdout, \
            (OUT / (LABEL + '-' + action + '.stderr')).open('x') as stderr:
        subprocess.run([str(binary), action], cwd=ROOT, stdout=stdout, stderr=stderr, check=True)
with (OUT / (LABEL + '-source.json')).open('x') as handle:
    json.dump(before, handle, indent=2)
    handle.write('\n')
print(LABEL, 'build/verify PASS;', len(before['sources']), 'bound inputs;',
      len(before['native_import_closure']['files']), 'native files; SHA', sha(binary), flush=True)
