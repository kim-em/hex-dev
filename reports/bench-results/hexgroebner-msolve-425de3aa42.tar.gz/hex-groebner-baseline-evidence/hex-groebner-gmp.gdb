set pagination off
set confirm off
set $calls=0
break __gmpz_set_str
commands
 silent
 set $calls=$calls+1
 if $calls==1000
  printf "GMP decimal input at call %d: %s\n",$calls,(char*)$rsi
  bt 14
  quit
 end
 continue
end
run /tmp/hex-groebner-compare/eco10-15.json
