import Lake
open Lake DSL
package F4Compare
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
lean_exe f4_compare where
  root := `Main
