LEAN_EXPORT lean_object* lp_Hex_Hex_OrderedFn_Real_encloseImpl___redArg(lean_object* v_a_54_, lean_object* v_p_55_, lean_object* v_00_u03b4_56_){
_start:
{
lean_object* v___x_57_; lean_object* v___x_58_; uint8_t v___x_59_; 
v___x_57_ = lean_array_get_size(v_p_55_);
v___x_58_ = lean_unsigned_to_nat(0u);
v___x_59_ = lean_nat_dec_eq(v___x_57_, v___x_58_);
if (v___x_59_ == 0)
{
lean_object* v___x_60_; uint8_t v___x_61_; 
v___x_60_ = lean_unsigned_to_nat(1u);
v___x_61_ = lean_nat_dec_eq(v___x_57_, v___x_60_);
if (v___x_61_ == 0)
{
lean_object* v_coeff_62_; lean_object* v_constant_63_; lean_object* v___x_64_; lean_object* v___x_65_; uint8_t v___x_66_; 
v_coeff_62_ = lean_ctor_get(v_a_54_, 0);
lean_inc_ref(v_coeff_62_);
v_constant_63_ = lean_ctor_get(v_a_54_, 1);
lean_inc_ref(v_constant_63_);
lean_dec_ref(v_a_54_);
v___x_64_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_Real_encloseImpl___redArg___closed__1, &lp_Hex_Hex_OrderedFn_Real_encloseImpl___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_Real_encloseImpl___redArg___closed__1);
v___x_65_ = ((lean_object*)(lp_Hex_Hex_OrderedFn_Real_encloseImpl___redArg___closed__11));
v___x_66_ = lean_nat_dec_lt(v___x_58_, v___x_57_);
if (v___x_66_ == 0)
{
lean_dec_ref(v_constant_63_);
lean_dec_ref(v_coeff_62_);
lean_dec_ref(v_00_u03b4_56_);
lean_dec_ref(v_p_55_);
return v___x_64_;
}
else
{
lean_object* v_x_67_; lean_object* v___f_68_; size_t v___x_69_; size_t v___x_70_; lean_object* v___x_71_; 
lean_inc_ref(v_00_u03b4_56_);
v_x_67_ = lean_apply_1(v_constant_63_, v_00_u03b4_56_);
v___f_68_ = lean_alloc_closure((void*)(lp_Hex_Hex_OrderedFn_Real_encloseImpl___redArg___lam__0___boxed), 5, 3);
lean_closure_set(v___f_68_, 0, v_coeff_62_);
lean_closure_set(v___f_68_, 1, v_00_u03b4_56_);
lean_closure_set(v___f_68_, 2, v_x_67_);
v___x_69_ = lean_usize_of_nat(v___x_57_);
v___x_70_ = ((size_t)0ULL);
v___x_71_ = l___private_Init_Data_Array_Basic_0__Array_foldrMUnsafe_fold(lean_box(0), lean_box(0), lean_box(0), v___x_65_, v___f_68_, v_p_55_, v___x_69_, v___x_70_, v___x_64_);
return v___x_71_;
}
}
else
{
lean_object* v_coeff_72_; lean_object* v___x_73_; lean_object* v___x_74_; 
v_coeff_72_ = lean_ctor_get(v_a_54_, 0);
lean_inc_ref(v_coeff_72_);
lean_dec_ref(v_a_54_);
v___x_73_ = lean_array_fget(v_p_55_, v___x_58_);
lean_dec_ref(v_p_55_);
v___x_74_ = lean_apply_2(v_coeff_72_, v___x_73_, v_00_u03b4_56_);
return v___x_74_;
}
}
else
{
lean_object* v___x_75_; 
lean_dec_ref(v_00_u03b4_56_);
lean_dec_ref(v_p_55_);
lean_dec_ref(v_a_54_);
v___x_75_ = lean_obj_once(&lp_Hex_Hex_OrderedFn_Real_encloseImpl___redArg___closed__1, &lp_Hex_Hex_OrderedFn_Real_encloseImpl___redArg___closed__1_once, _init_lp_Hex_Hex_OrderedFn_Real_encloseImpl___redArg___closed__1);
return v___x_75_;
}
}
}
