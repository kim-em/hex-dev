"""One bound, adjacent-arm comparison for the changed constant-enclosure code."""
from pathlib import Path
import hashlib
import json
import math
import os
import signal
import statistics
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
DECISION = json.loads((OUT / 'decision.json').read_text())
ROOT = Path(DECISION['candidate_root'])
sys.path.insert(0, str(ROOT))
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.sturm_regression import memory_context, run_process, state_directory

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_checks():
    for arm, source in SOURCES.items():
        root = Path(source['root'])
        git = lambda *args, cwd=root: subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()
        require(git('rev-parse', 'HEAD') == source['head'], 'changed source head: ' + arm)
        require(not git('status', '--porcelain'), 'dirty source: ' + arm)
        for path, expected in source['sources'].items():
            require(sha(root / path) == expected, 'changed input: ' + arm + '/' + path)
        for name, package in source['packages'].items():
            directory = root / '.lake/packages' / name
            require(git('rev-parse', 'HEAD', cwd=directory) == package['head'] and
                    not git('status', '--porcelain', cwd=directory), 'changed package: ' + name)
        require(sha(ARMS[arm]) == source['binary_sha256'] and os.access(ARMS[arm], os.X_OK),
                'changed or non-executable binary: ' + arm)
    for path, expected in DECISION['tools'].items():
        require(sha(Path(path)) == expected, 'changed tool: ' + path)

SOURCES = {}
ARMS = {}
for arm in ('baseline', 'candidate'):
    path = OUT / (arm + '-source.json')
    require(sha(path) == DECISION['source_manifests'][arm], 'changed source manifest: ' + arm)
    SOURCES[arm] = json.loads(path.read_text())
    ARMS[arm] = Path(SOURCES[arm]['binary'])
source_checks()
require(SOURCES['baseline']['packages'] == SOURCES['candidate']['packages'], 'different dependency pins')
require(SOURCES['baseline']['sources']['lean-toolchain'] == SOURCES['candidate']['sources']['lean-toolchain'],
        'different toolchains')
identity = hashlib.sha256(json.dumps([SOURCES[a]['binary_sha256'] for a in ('baseline', 'candidate')]).encode()).hexdigest()
marker = state_directory() / ('orderedfn-constant-enclosure-' + identity + '.json')
marker.parent.mkdir(parents=True, exist_ok=True)
require(not marker.exists(), 'comparison binaries already consumed an attempt')
if sys.argv[1:] == ['--preflight']:
    print('Source/binary/tool/execute-mode/reservation preflight PASS; no measurements collected.')
    raise SystemExit(0)
require(not sys.argv[1:], 'unsupported probe arguments')
capture = OUT / 'comparison'
capture.mkdir(exist_ok=False)
cpu, lease = cpu_lease()
context = dict(status='setup', cpu=cpu, affinity_before=sorted(os.sched_getaffinity(0)),
               load_before=os.getloadavg(), memory_before=memory_context(),
               source_heads={a:s['head'] for a,s in SOURCES.items()},
               binaries={a:s['binary_sha256'] for a,s in SOURCES.items()},
               decision_sha256=sha(OUT / 'decision.json'), reservation=str(marker),
               invocation_root=str(ROOT), rows=[], started_unix=time.time())

def save():
    (capture / 'context.json').write_text(json.dumps(context, indent=2) + '\n')

def interrupt(signum, frame):
    raise InterruptedError('signal ' + str(signum))

for sig in (signal.SIGTERM, signal.SIGALRM):
    signal.signal(sig, interrupt)

try:
    os.sched_setaffinity(0, {cpu})
    with marker.open('x') as handle:
        json.dump({'output':str(capture), 'decision_sha256':context['decision_sha256']}, handle)
    context['status'] = 'running'
    save()
    for trial in range(DECISION['trials']):
        for name, param in DECISION['scope']:
            for arm in (('baseline', 'candidate') if trial % 2 == 0 else ('candidate', 'baseline')):
                require(sha(ARMS[arm]) == SOURCES[arm]['binary_sha256'], 'binary changed')
                stem = f'{trial}-{name}-{param}-{arm}'
                stdout = capture / (stem + '.stdout')
                stderr = capture / (stem + '.stderr')
                command = [str(ARMS[arm]), '_child', '--bench', 'Hex.OrderedFnBench.' + name,
                           '--param', str(param), '--target-nanos', str(DECISION['target_inner_nanos'])]
                row = dict(trial=trial, name=name, param=param, arm=arm, command=command,
                           stdout=stdout.name, stderr=stderr.name, load_before=os.getloadavg())
                context['rows'].append(row)
                save()
                try:
                    signal.alarm(180)
                    with stdout.open('x') as so, stderr.open('x') as se:
                        row['returncode'] = run_process(command, ROOT, os.environ.copy(), so, se)
                    signal.alarm(0)
                    require(row['returncode'] == 0, 'child failed: ' + stem)
                    observation = json.loads(stdout.read_text())
                    row['observation'] = observation
                    require(observation['status'] == 'ok' and observation['error'] is None and
                            observation['function'] == 'Hex.OrderedFnBench.' + name and
                            observation['param'] == param and observation['kind'] == 'parametric' and
                            observation['env']['lean_version'] == DECISION['compiler_version'] and
                            observation['inner_repeats'] > 0 and observation['total_nanos'] > 0 and
                            math.isfinite(observation['per_call_nanos']) and observation['per_call_nanos'] > 0 and
                            observation['result_hash'] is not None, 'invalid child observation: ' + stem)
                except BaseException as exc:
                    row['error'] = str(exc)
                    raise
                finally:
                    signal.alarm(0)
                    row['load_after'] = os.getloadavg()
                    save()
        print('trial', trial, 'complete', flush=True)
    analyses = []
    for name, param in DECISION['scope']:
        rows = [r for r in context['rows'] if r['name'] == name and r['param'] == param]
        hashes = {r['observation']['result_hash'] for r in rows}
        require(len(hashes) == 1, 'different result hashes at ' + str(param))
        medians = {arm:statistics.median(r['observation']['per_call_nanos'] for r in rows if r['arm'] == arm)
                   for arm in ARMS}
        analyses.append(dict(name=name,param=param,medians=medians,
                             pct_change=100*(medians['candidate']/medians['baseline']-1)))
    context['analysis'] = analyses
    center = next(x for x in analyses if x['param'] == 12288)
    context['expansion_criterion_passed'] = center['pct_change'] < -10 and all(
        x['pct_change'] <= 10 for x in analyses if x['param'] != 12288)
    context['status'] = 'completed'
except BaseException as exc:
    context.update(status='failed', error=str(exc))
    raise
finally:
    try:
        source_checks()
        context['inputs_unchanged'] = True
    except BaseException as exc:
        context.update(status='invalid', integrity_error=str(exc), expansion_criterion_passed=False)
    context.update(load_after=os.getloadavg(), memory_after=memory_context(), finished_unix=time.time())
    save()
    lease.close()
print(json.dumps(context.get('analysis', []), indent=2), flush=True)
raise SystemExit(0 if context['status'] == 'completed' and context.get('expansion_criterion_passed') else 1)
