import HexGroebner
import Lean.Data.Json

open Hex.Groebner Lean

def parseTerm (j : Json) : Except String RawTerm := do
  let values ← j.getArr?
  if values.size != 2 then throw "term needs [exponents,coefficient]"
  let powers ← values[0]!.getArr? >>= fun a => a.mapM Json.getNat?
  let c ← values[1]!.getNat?
  if c ≥ 2^64 then throw "coefficient exceeds UInt64"
  return ⟨powers, c.toUInt64⟩

def parseInput (j : Json) : Except String (Context × Array RawPolynomial) := do
  let modulus ← j.getObjValAs? Nat "p"
  if h : Hex.Nat.isPrimeTrial modulus = true then
    if bound : modulus < 2^31 then
      let field : PrimeField := ⟨modulus.toUInt64, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using Hex.Nat.isPrimeTrial_isPrime h, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using bound⟩
      let variables ← j.getObjValAs? Nat "variables"
      let order ← j.getObjValAs? String "order"
      let order ← match order with
        | "grevlex" => pure TermOrder.grevlex
        | "grlex" => pure TermOrder.grlex
        | "lex" => pure TermOrder.lex
        | _ => throw "unknown order"
      let generators ← j.getObjVal? "generators" >>= Json.getArr? >>= fun a =>
        a.mapM fun p => p.getArr? >>= fun a => a.mapM parseTerm
      return (⟨field, variables, order⟩, generators)
    else throw "modulus out of bounds"
  else throw "not prime"

def emitPolynomial (p : RawPolynomial) : Json := .arr (p.map fun t =>
  .arr #[toJson t.exponents, toJson t.coefficient.toNat])

def main (args : List String) : IO Unit := do
  let (filename, batchInterreduce, nativeMonomials, batchSize) ← match args with
    | [s] => pure (s, true, true, 64)
    | [s, "--separate"] => pure (s, false, true, 64)
    | [s, "--arrays"] => pure (s, true, false, 64)
    | [s, "--batch256"] => pure (s, true, true, 256)
    | _ => throw (IO.userError "f4_compare input.json")
  let json ← IO.ofExcept (Json.parse (← IO.FS.readFile filename))
  let (context, generators) ← IO.ofExcept (parseInput json)
  let limits : Limits := {
    batchInterreduce, nativeMonomials, batchSize
    work := 100000000000
    packedBytes := 16 * 1024 * 1024 * 1024
    matrixEntries := 1000000000
    pairs := 100000000
    monomials := 10000000 }
  let start ← IO.monoNanosNow
  let result := computeWith context limits generators
  let forced ← match result with
    | .candidate candidate statistics => pure (candidate, statistics)
    | .internal e _ => throw (IO.userError s!"internal {reprStr e}")
    | .invalid e _ => throw (IO.userError s!"invalid {reprStr e}")
    | .exhausted r state => throw (IO.userError s!"exhausted {reprStr r}: {reprStr state.workspace.statistics}")
    | .representation e _ => throw (IO.userError s!"representation {reprStr e}")
  let stop ← IO.monoNanosNow
  let (candidate, statistics) := forced
  let output := Json.mkObj [
    ("basis", .arr (candidate.polynomials.map emitPolynomial)),
    ("candidate_nanos", toJson (stop-start)),
    ("work", toJson statistics.work), ("pairs", toJson statistics.pairs),
    ("rounds", toJson statistics.rounds), ("matrix_calls", toJson statistics.matrixCalls),
    ("matrix_entries", toJson statistics.matrixEntries),
    ("allocated_bytes", toJson statistics.allocatedBytes)]
  IO.println output.compress
