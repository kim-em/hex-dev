import Mathlib.Tactic.NormDet
import Mathlib.Tactic.Ring

open Matrix

private theorem result : Matrix.det (!![(1 : Int), 2; 3, 4] : Matrix (Fin 2) (Fin 2) Int) = -2 := by
  simp only [norm_det] <;> ring

#print axioms result
