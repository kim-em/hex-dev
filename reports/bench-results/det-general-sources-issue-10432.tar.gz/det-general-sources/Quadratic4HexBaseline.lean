import HexPolyDetMathlib
import HexPolyDetMathlib.ProofProbe.GeneralSupport

open Matrix

