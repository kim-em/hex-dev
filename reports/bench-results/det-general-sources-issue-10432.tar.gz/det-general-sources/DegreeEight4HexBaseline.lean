import HexPolyDetMathlib

open Matrix

