from pathlib import Path
p=Path('HexGroebner/Symbolic.lean');s=p.read_text();anchor='/-- Close every selected term under the required reducers.'
helper='''/-- Queue each arena identifier once. The bitmap grows with the current
arena, including products interned during preprocessing; initialization and
payload growth count against the parent allowances. Pending order is unchanged. -/
private def queueSupport (limits : Limits) (p : Polynomial) (bits : ByteArray)
    (pending : Array Nat) : Computation (ByteArray × Array Nat) := do
  if p.size == 0 then return (bits,pending)
  let count := (← get).table.count
  let size := (count+7)/8
  if size ≥ USize.size then throw (.representation .address)
  let mut bits := bits
  if bits.size < size then
    let extra := size-bits.size
    spend limits extra
    allocate limits extra
    for chunk in [:(extra+4095)/4096] do
      let amount := min 4096 (extra-chunk*4096)
      let some next := if limits.nativeMonomials then Native.Columns.zeros bits amount
        else Native.Columns.zerosPortable bits amount | throw (.representation .address)
      bits := next
  let mut pending := pending
  for i in [:p.size] do
    let id := p.monomial i
    if id ≥ count then throw (.representation .index)
    let pos := id/8
    let mask : UInt8 := 1 <<< (id%8).toUInt8
    let value := bits[pos]!
    if value &&& mask == 0 then
      bits := bits.set! pos (value ||| mask)
      pending := pending.push id
  return (bits,pending)

''';assert anchor in s;s=s.replace(anchor,helper+anchor);s=s.replace('let mut support : Std.HashSet Nat := {}','let mut support : ByteArray := {}',1)
old='''    for i in [:p.size] do
      let id := p.monomial i
      if !support.contains id then
        support := support.insert id
        pending := pending.push id'''
assert s.count(old)==2,s.count(old)
s=s.replace(old,'''    let (next, queued) ← queueSupport limits p support pending
    support := next
    pending := queued''')
old='''      for i in [:p.size] do
        let id := p.monomial i
        if !support.contains id then
          support := support.insert id
          pending := pending.push id''';assert old in s;s=s.replace(old,'''      let (next, queued) ← queueSupport limits p support pending
      support := next
      pending := queued''',1);p.write_text(s)
