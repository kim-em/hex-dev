// Lean compiler output
// Module: HexGroebner.Native
// Imports: public import Init public meta import Init
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_uint8_to_nat(uint8_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_byte_array_size(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
lean_object* lean_uint64_to_nat(uint64_t);
uint8_t lean_uint64_dec_le(uint64_t, uint64_t);
uint8_t lean_uint8_of_nat(lean_object*);
lean_object* lean_byte_array_set(lean_object*, lean_object*, uint8_t);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
uint64_t lean_uint64_add(uint64_t, uint64_t);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
uint64_t lean_uint64_mul(uint64_t, uint64_t);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
lean_object* lean_nat_mod(lean_object*, lean_object*);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
uint64_t lean_uint64_sub(uint64_t, uint64_t);
uint8_t lean_uint64_dec_lt(uint64_t, uint64_t);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
uint8_t lean_uint8_dec_eq(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_width(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_width___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_read(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_read___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_write(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_update(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_update___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_subtractPortable(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_subtractPortable___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_hex_groebner_subtract_row(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_subtract___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___lam__0___boxed(lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Native_Bytes_equalPortable(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Bytes_equalPortable___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_hex_groebner_equal_bytes(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Bytes_equal___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Native_Monomial_productsPortable(uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_productsPortable___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_hex_groebner_equal_products(uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_products___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_fill(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_fill___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_preparePortable(uint8_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_preparePortable___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_hex_groebner_prepare_monomial(uint8_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_prepare___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Native_Monomial_equalAux(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_equalAux___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Native_Monomial_equalPortable(uint8_t, uint64_t, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_equalPortable___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_hex_groebner_equal_monomial(uint8_t, uint64_t, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_equal___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_width(lean_object* v_modulus_1_){
_start:
{
lean_object* v___x_2_; uint8_t v___x_3_; 
v___x_2_ = lean_unsigned_to_nat(256u);
v___x_3_ = lean_nat_dec_le(v_modulus_1_, v___x_2_);
if (v___x_3_ == 0)
{
lean_object* v___x_4_; uint8_t v___x_5_; 
v___x_4_ = lean_unsigned_to_nat(65536u);
v___x_5_ = lean_nat_dec_le(v_modulus_1_, v___x_4_);
if (v___x_5_ == 0)
{
lean_object* v___x_6_; 
v___x_6_ = lean_unsigned_to_nat(4u);
return v___x_6_;
}
else
{
lean_object* v___x_7_; 
v___x_7_ = lean_unsigned_to_nat(2u);
return v___x_7_;
}
}
else
{
lean_object* v___x_8_; 
v___x_8_ = lean_unsigned_to_nat(1u);
return v___x_8_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_width___boxed(lean_object* v_modulus_9_){
_start:
{
lean_object* v_res_10_; 
v_res_10_ = lp_Hex_Hex_Groebner_Native_width(v_modulus_9_);
lean_dec(v_modulus_9_);
return v_res_10_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_read(lean_object* v_bytes_11_, lean_object* v_width_12_, lean_object* v_offset_13_){
_start:
{
lean_object* v_zero_14_; uint8_t v_isZero_15_; 
v_zero_14_ = lean_unsigned_to_nat(0u);
v_isZero_15_ = lean_nat_dec_eq(v_width_12_, v_zero_14_);
if (v_isZero_15_ == 1)
{
return v_zero_14_;
}
else
{
lean_object* v_one_16_; lean_object* v_n_17_; uint8_t v___y_19_; lean_object* v___x_26_; uint8_t v___x_27_; 
v_one_16_ = lean_unsigned_to_nat(1u);
v_n_17_ = lean_nat_sub(v_width_12_, v_one_16_);
v___x_26_ = lean_byte_array_size(v_bytes_11_);
v___x_27_ = lean_nat_dec_lt(v_offset_13_, v___x_26_);
if (v___x_27_ == 0)
{
uint8_t v___x_28_; lean_object* v___x_29_; lean_object* v___x_30_; uint8_t v___x_31_; 
v___x_28_ = 0;
v___x_29_ = lean_box(v___x_28_);
v___x_30_ = l_outOfBounds___redArg(v___x_29_);
lean_dec(v___x_29_);
v___x_31_ = lean_unbox(v___x_30_);
lean_dec(v___x_30_);
v___y_19_ = v___x_31_;
goto v___jp_18_;
}
else
{
uint8_t v___x_32_; 
v___x_32_ = lean_byte_array_fget(v_bytes_11_, v_offset_13_);
v___y_19_ = v___x_32_;
goto v___jp_18_;
}
v___jp_18_:
{
lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; 
v___x_20_ = lean_uint8_to_nat(v___y_19_);
v___x_21_ = lean_unsigned_to_nat(256u);
v___x_22_ = lean_nat_add(v_offset_13_, v_one_16_);
v___x_23_ = lp_Hex_Hex_Groebner_Native_read(v_bytes_11_, v_n_17_, v___x_22_);
lean_dec(v___x_22_);
lean_dec(v_n_17_);
v___x_24_ = lean_nat_mul(v___x_21_, v___x_23_);
lean_dec(v___x_23_);
v___x_25_ = lean_nat_add(v___x_20_, v___x_24_);
lean_dec(v___x_24_);
return v___x_25_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_read___boxed(lean_object* v_bytes_33_, lean_object* v_width_34_, lean_object* v_offset_35_){
_start:
{
lean_object* v_res_36_; 
v_res_36_ = lp_Hex_Hex_Groebner_Native_read(v_bytes_33_, v_width_34_, v_offset_35_);
lean_dec(v_offset_35_);
lean_dec(v_width_34_);
lean_dec_ref(v_bytes_33_);
return v_res_36_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_write(lean_object* v_bytes_37_, lean_object* v_width_38_, lean_object* v_offset_39_, lean_object* v_value_40_){
_start:
{
lean_object* v_zero_41_; uint8_t v_isZero_42_; 
v_zero_41_ = lean_unsigned_to_nat(0u);
v_isZero_42_ = lean_nat_dec_eq(v_width_38_, v_zero_41_);
if (v_isZero_42_ == 1)
{
lean_dec(v_value_40_);
lean_dec(v_offset_39_);
lean_dec(v_width_38_);
return v_bytes_37_;
}
else
{
lean_object* v_one_43_; lean_object* v_n_44_; uint8_t v___x_45_; lean_object* v___x_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; 
v_one_43_ = lean_unsigned_to_nat(1u);
v_n_44_ = lean_nat_sub(v_width_38_, v_one_43_);
lean_dec(v_width_38_);
v___x_45_ = lean_uint8_of_nat(v_value_40_);
v___x_46_ = lean_byte_array_set(v_bytes_37_, v_offset_39_, v___x_45_);
v___x_47_ = lean_nat_add(v_offset_39_, v_one_43_);
lean_dec(v_offset_39_);
v___x_48_ = lean_unsigned_to_nat(8u);
v___x_49_ = lean_nat_shiftr(v_value_40_, v___x_48_);
lean_dec(v_value_40_);
v_bytes_37_ = v___x_46_;
v_width_38_ = v_n_44_;
v_offset_39_ = v___x_47_;
v_value_40_ = v___x_49_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_update(lean_object* v_modulus_51_, lean_object* v_factor_52_, lean_object* v_width_53_, lean_object* v_columns_54_, lean_object* v_coefficients_55_, lean_object* v_remaining_56_, lean_object* v_start_57_, lean_object* v_dense_58_){
_start:
{
lean_object* v_zero_59_; uint8_t v_isZero_60_; 
v_zero_59_ = lean_unsigned_to_nat(0u);
v_isZero_60_ = lean_nat_dec_eq(v_remaining_56_, v_zero_59_);
if (v_isZero_60_ == 1)
{
lean_object* v___x_61_; 
lean_dec(v_start_57_);
lean_dec(v_remaining_56_);
lean_dec(v_width_53_);
v___x_61_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_61_, 0, v_dense_58_);
return v___x_61_;
}
else
{
lean_object* v___x_62_; lean_object* v___x_63_; lean_object* v_column_64_; lean_object* v___x_65_; lean_object* v___x_66_; uint8_t v___x_67_; 
v___x_62_ = lean_unsigned_to_nat(4u);
v___x_63_ = lean_nat_mul(v___x_62_, v_start_57_);
v_column_64_ = lp_Hex_Hex_Groebner_Native_read(v_columns_54_, v___x_62_, v___x_63_);
lean_dec(v___x_63_);
v___x_65_ = lean_byte_array_size(v_dense_58_);
v___x_66_ = lean_nat_div(v___x_65_, v_width_53_);
v___x_67_ = lean_nat_dec_le(v___x_66_, v_column_64_);
lean_dec(v___x_66_);
if (v___x_67_ == 0)
{
lean_object* v___x_68_; lean_object* v_b_69_; uint8_t v___x_70_; 
v___x_68_ = lean_nat_mul(v_start_57_, v_width_53_);
v_b_69_ = lp_Hex_Hex_Groebner_Native_read(v_coefficients_55_, v_width_53_, v___x_68_);
lean_dec(v___x_68_);
v___x_70_ = lean_nat_dec_le(v_modulus_51_, v_b_69_);
if (v___x_70_ == 0)
{
lean_object* v___x_71_; lean_object* v_a_72_; uint8_t v___x_73_; 
v___x_71_ = lean_nat_mul(v_column_64_, v_width_53_);
lean_dec(v_column_64_);
v_a_72_ = lp_Hex_Hex_Groebner_Native_read(v_dense_58_, v_width_53_, v___x_71_);
v___x_73_ = lean_nat_dec_le(v_modulus_51_, v_a_72_);
if (v___x_73_ == 0)
{
lean_object* v_one_74_; lean_object* v_n_75_; lean_object* v___y_77_; lean_object* v___x_81_; lean_object* v_product_82_; lean_object* v___x_83_; lean_object* v_difference_84_; uint8_t v___x_85_; 
v_one_74_ = lean_unsigned_to_nat(1u);
v_n_75_ = lean_nat_sub(v_remaining_56_, v_one_74_);
lean_dec(v_remaining_56_);
v___x_81_ = lean_nat_mul(v_factor_52_, v_b_69_);
lean_dec(v_b_69_);
v_product_82_ = lean_nat_mod(v___x_81_, v_modulus_51_);
lean_dec(v___x_81_);
v___x_83_ = lean_nat_add(v_a_72_, v_modulus_51_);
lean_dec(v_a_72_);
v_difference_84_ = lean_nat_sub(v___x_83_, v_product_82_);
lean_dec(v_product_82_);
lean_dec(v___x_83_);
v___x_85_ = lean_nat_dec_le(v_modulus_51_, v_difference_84_);
if (v___x_85_ == 0)
{
v___y_77_ = v_difference_84_;
goto v___jp_76_;
}
else
{
lean_object* v___x_86_; 
v___x_86_ = lean_nat_sub(v_difference_84_, v_modulus_51_);
lean_dec(v_difference_84_);
v___y_77_ = v___x_86_;
goto v___jp_76_;
}
v___jp_76_:
{
lean_object* v___x_78_; lean_object* v___x_79_; 
v___x_78_ = lean_nat_add(v_start_57_, v_one_74_);
lean_dec(v_start_57_);
lean_inc(v_width_53_);
v___x_79_ = lp_Hex_Hex_Groebner_Native_write(v_dense_58_, v_width_53_, v___x_71_, v___y_77_);
v_remaining_56_ = v_n_75_;
v_start_57_ = v___x_78_;
v_dense_58_ = v___x_79_;
goto _start;
}
}
else
{
lean_object* v___x_87_; 
lean_dec(v_a_72_);
lean_dec(v___x_71_);
lean_dec(v_b_69_);
lean_dec_ref(v_dense_58_);
lean_dec(v_start_57_);
lean_dec(v_remaining_56_);
lean_dec(v_width_53_);
v___x_87_ = lean_box(0);
return v___x_87_;
}
}
else
{
lean_object* v___x_88_; 
lean_dec(v_b_69_);
lean_dec(v_column_64_);
lean_dec_ref(v_dense_58_);
lean_dec(v_start_57_);
lean_dec(v_remaining_56_);
lean_dec(v_width_53_);
v___x_88_ = lean_box(0);
return v___x_88_;
}
}
else
{
lean_object* v___x_89_; 
lean_dec(v_column_64_);
lean_dec_ref(v_dense_58_);
lean_dec(v_start_57_);
lean_dec(v_remaining_56_);
lean_dec(v_width_53_);
v___x_89_ = lean_box(0);
return v___x_89_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_update___boxed(lean_object* v_modulus_90_, lean_object* v_factor_91_, lean_object* v_width_92_, lean_object* v_columns_93_, lean_object* v_coefficients_94_, lean_object* v_remaining_95_, lean_object* v_start_96_, lean_object* v_dense_97_){
_start:
{
lean_object* v_res_98_; 
v_res_98_ = lp_Hex_Hex_Groebner_Native_update(v_modulus_90_, v_factor_91_, v_width_92_, v_columns_93_, v_coefficients_94_, v_remaining_95_, v_start_96_, v_dense_97_);
lean_dec_ref(v_coefficients_94_);
lean_dec_ref(v_columns_93_);
lean_dec(v_factor_91_);
lean_dec(v_modulus_90_);
return v_res_98_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_subtractPortable(uint64_t v_modulus_99_, lean_object* v_dense_100_, lean_object* v_columns_101_, lean_object* v_coefficients_102_, lean_object* v_start_103_, lean_object* v_count_104_, uint64_t v_factor_105_){
_start:
{
lean_object* v_modulus_106_; lean_object* v___x_107_; uint8_t v___x_108_; 
v_modulus_106_ = lean_uint64_to_nat(v_modulus_99_);
v___x_107_ = lean_unsigned_to_nat(2u);
v___x_108_ = lean_nat_dec_lt(v_modulus_106_, v___x_107_);
if (v___x_108_ == 0)
{
lean_object* v___x_109_; uint8_t v___x_110_; 
v___x_109_ = lean_unsigned_to_nat(2147483648u);
v___x_110_ = lean_nat_dec_le(v___x_109_, v_modulus_106_);
if (v___x_110_ == 0)
{
lean_object* v_factor_111_; uint8_t v___x_112_; 
v_factor_111_ = lean_uint64_to_nat(v_factor_105_);
v___x_112_ = lean_nat_dec_le(v_modulus_106_, v_factor_111_);
if (v___x_112_ == 0)
{
lean_object* v___x_113_; uint8_t v___x_114_; 
v___x_113_ = lean_unsigned_to_nat(4096u);
v___x_114_ = lean_nat_dec_lt(v___x_113_, v_count_104_);
if (v___x_114_ == 0)
{
lean_object* v___x_115_; lean_object* v___x_116_; lean_object* v___x_117_; lean_object* v___x_118_; uint8_t v___x_119_; 
v___x_115_ = lean_byte_array_size(v_columns_101_);
v___x_116_ = lean_unsigned_to_nat(4u);
v___x_117_ = lean_nat_mod(v___x_115_, v___x_116_);
v___x_118_ = lean_unsigned_to_nat(0u);
v___x_119_ = lean_nat_dec_eq(v___x_117_, v___x_118_);
lean_dec(v___x_117_);
if (v___x_119_ == 0)
{
lean_object* v___x_120_; 
lean_dec(v_factor_111_);
lean_dec(v_modulus_106_);
lean_dec_ref(v_dense_100_);
v___x_120_ = lean_box(0);
return v___x_120_;
}
else
{
lean_object* v_width_121_; lean_object* v_rows_122_; lean_object* v___x_123_; lean_object* v___x_124_; uint8_t v___x_125_; 
v_width_121_ = lp_Hex_Hex_Groebner_Native_width(v_modulus_106_);
v_rows_122_ = lean_nat_shiftr(v___x_115_, v___x_107_);
v___x_123_ = lean_byte_array_size(v_coefficients_102_);
v___x_124_ = lean_nat_mul(v_rows_122_, v_width_121_);
v___x_125_ = lean_nat_dec_eq(v___x_123_, v___x_124_);
lean_dec(v___x_124_);
if (v___x_125_ == 0)
{
lean_object* v___x_126_; 
lean_dec(v_rows_122_);
lean_dec(v_width_121_);
lean_dec(v_factor_111_);
lean_dec(v_modulus_106_);
lean_dec_ref(v_dense_100_);
v___x_126_ = lean_box(0);
return v___x_126_;
}
else
{
lean_object* v___x_127_; lean_object* v___x_128_; uint8_t v___x_129_; 
v___x_127_ = lean_byte_array_size(v_dense_100_);
v___x_128_ = lean_nat_mod(v___x_127_, v_width_121_);
v___x_129_ = lean_nat_dec_eq(v___x_128_, v___x_118_);
lean_dec(v___x_128_);
if (v___x_129_ == 0)
{
lean_object* v___x_130_; 
lean_dec(v_rows_122_);
lean_dec(v_width_121_);
lean_dec(v_factor_111_);
lean_dec(v_modulus_106_);
lean_dec_ref(v_dense_100_);
v___x_130_ = lean_box(0);
return v___x_130_;
}
else
{
uint8_t v___x_131_; 
v___x_131_ = lean_nat_dec_lt(v_rows_122_, v_start_103_);
if (v___x_131_ == 0)
{
lean_object* v___x_132_; uint8_t v___x_133_; 
v___x_132_ = lean_nat_sub(v_rows_122_, v_start_103_);
lean_dec(v_rows_122_);
v___x_133_ = lean_nat_dec_lt(v___x_132_, v_count_104_);
lean_dec(v___x_132_);
if (v___x_133_ == 0)
{
lean_object* v___x_134_; 
lean_inc(v_start_103_);
lean_inc(v_count_104_);
v___x_134_ = lp_Hex_Hex_Groebner_Native_update(v_modulus_106_, v_factor_111_, v_width_121_, v_columns_101_, v_coefficients_102_, v_count_104_, v_start_103_, v_dense_100_);
lean_dec(v_factor_111_);
lean_dec(v_modulus_106_);
return v___x_134_;
}
else
{
lean_object* v___x_135_; 
lean_dec(v_width_121_);
lean_dec(v_factor_111_);
lean_dec(v_modulus_106_);
lean_dec_ref(v_dense_100_);
v___x_135_ = lean_box(0);
return v___x_135_;
}
}
else
{
lean_object* v___x_136_; 
lean_dec(v_rows_122_);
lean_dec(v_width_121_);
lean_dec(v_factor_111_);
lean_dec(v_modulus_106_);
lean_dec_ref(v_dense_100_);
v___x_136_ = lean_box(0);
return v___x_136_;
}
}
}
}
}
else
{
lean_object* v___x_137_; 
lean_dec(v_factor_111_);
lean_dec(v_modulus_106_);
lean_dec_ref(v_dense_100_);
v___x_137_ = lean_box(0);
return v___x_137_;
}
}
else
{
lean_object* v___x_138_; 
lean_dec(v_factor_111_);
lean_dec(v_modulus_106_);
lean_dec_ref(v_dense_100_);
v___x_138_ = lean_box(0);
return v___x_138_;
}
}
else
{
lean_object* v___x_139_; 
lean_dec(v_modulus_106_);
lean_dec_ref(v_dense_100_);
v___x_139_ = lean_box(0);
return v___x_139_;
}
}
else
{
lean_object* v___x_140_; 
lean_dec(v_modulus_106_);
lean_dec_ref(v_dense_100_);
v___x_140_ = lean_box(0);
return v___x_140_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_subtractPortable___boxed(lean_object* v_modulus_141_, lean_object* v_dense_142_, lean_object* v_columns_143_, lean_object* v_coefficients_144_, lean_object* v_start_145_, lean_object* v_count_146_, lean_object* v_factor_147_){
_start:
{
uint64_t v_modulus_boxed_148_; uint64_t v_factor_boxed_149_; lean_object* v_res_150_; 
v_modulus_boxed_148_ = lean_unbox_uint64(v_modulus_141_);
lean_dec_ref(v_modulus_141_);
v_factor_boxed_149_ = lean_unbox_uint64(v_factor_147_);
lean_dec_ref(v_factor_147_);
v_res_150_ = lp_Hex_Hex_Groebner_Native_subtractPortable(v_modulus_boxed_148_, v_dense_142_, v_columns_143_, v_coefficients_144_, v_start_145_, v_count_146_, v_factor_boxed_149_);
lean_dec(v_count_146_);
lean_dec(v_start_145_);
lean_dec_ref(v_coefficients_144_);
lean_dec_ref(v_columns_143_);
return v_res_150_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_subtract___boxed(lean_object* v_modulus_158_, lean_object* v_dense_159_, lean_object* v_columns_160_, lean_object* v_coefficients_161_, lean_object* v_start_162_, lean_object* v_count_163_, lean_object* v_factor_164_){
_start:
{
uint64_t v_modulus_boxed_165_; uint64_t v_factor_boxed_166_; lean_object* v_res_167_; 
v_modulus_boxed_165_ = lean_unbox_uint64(v_modulus_158_);
lean_dec_ref(v_modulus_158_);
v_factor_boxed_166_ = lean_unbox_uint64(v_factor_164_);
lean_dec_ref(v_factor_164_);
v_res_167_ = lean_hex_groebner_subtract_row(v_modulus_boxed_165_, v_dense_159_, v_columns_160_, v_coefficients_161_, v_start_162_, v_count_163_, v_factor_boxed_166_);
lean_dec(v_count_163_);
lean_dec(v_start_162_);
lean_dec_ref(v_coefficients_161_);
lean_dec_ref(v_columns_160_);
return v_res_167_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___lam__0(lean_object* v_xs_168_, lean_object* v_i_169_){
_start:
{
lean_object* v___x_170_; uint8_t v___x_171_; 
v___x_170_ = lean_byte_array_size(v_xs_168_);
v___x_171_ = lean_nat_dec_lt(v_i_169_, v___x_170_);
return v___x_171_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___lam__0___boxed(lean_object* v_xs_172_, lean_object* v_i_173_){
_start:
{
uint8_t v_res_174_; lean_object* v_r_175_; 
v_res_174_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___lam__0(v_xs_172_, v_i_173_);
lean_dec(v_i_173_);
lean_dec_ref(v_xs_172_);
v_r_175_ = lean_box(v_res_174_);
return v_r_175_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg(lean_object* v_start_179_, lean_object* v___x_180_, lean_object* v_count_181_, lean_object* v_right_182_, lean_object* v_left_183_, lean_object* v_range_184_, lean_object* v_b_185_, lean_object* v_i_186_){
_start:
{
lean_object* v_stop_187_; lean_object* v_step_188_; uint8_t v___x_189_; 
v_stop_187_ = lean_ctor_get(v_range_184_, 1);
v_step_188_ = lean_ctor_get(v_range_184_, 2);
v___x_189_ = lean_nat_dec_lt(v_i_186_, v_stop_187_);
if (v___x_189_ == 0)
{
lean_dec(v_i_186_);
lean_inc_ref(v_b_185_);
return v_b_185_;
}
else
{
uint8_t v___x_190_; lean_object* v___x_191_; lean_object* v___x_192_; uint8_t v___y_194_; uint8_t v___y_195_; uint8_t v___x_202_; lean_object* v___x_203_; uint8_t v___y_205_; uint8_t v___x_211_; 
v___x_190_ = lean_nat_dec_lt(v___x_180_, v_count_181_);
v___x_191_ = lean_box(0);
v___x_192_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___closed__0));
v___x_202_ = 0;
v___x_203_ = lean_nat_add(v_start_179_, v_i_186_);
v___x_211_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___lam__0(v_left_183_, v___x_203_);
if (v___x_211_ == 0)
{
lean_object* v___x_212_; lean_object* v___x_213_; uint8_t v___x_214_; 
v___x_212_ = lean_box(v___x_202_);
v___x_213_ = l_outOfBounds___redArg(v___x_212_);
lean_dec(v___x_212_);
v___x_214_ = lean_unbox(v___x_213_);
lean_dec(v___x_213_);
v___y_205_ = v___x_214_;
goto v___jp_204_;
}
else
{
uint8_t v___x_215_; 
v___x_215_ = lean_byte_array_fget(v_left_183_, v___x_203_);
v___y_205_ = v___x_215_;
goto v___jp_204_;
}
v___jp_193_:
{
uint8_t v___x_196_; 
v___x_196_ = lean_uint8_dec_eq(v___y_194_, v___y_195_);
if (v___x_196_ == 0)
{
lean_object* v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; 
lean_dec(v_i_186_);
v___x_197_ = lean_box(v___x_190_);
v___x_198_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_198_, 0, v___x_197_);
v___x_199_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_199_, 0, v___x_198_);
lean_ctor_set(v___x_199_, 1, v___x_191_);
return v___x_199_;
}
else
{
lean_object* v___x_200_; 
v___x_200_ = lean_nat_add(v_i_186_, v_step_188_);
lean_dec(v_i_186_);
v_b_185_ = v___x_192_;
v_i_186_ = v___x_200_;
goto _start;
}
}
v___jp_204_:
{
uint8_t v___x_206_; 
v___x_206_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___lam__0(v_right_182_, v___x_203_);
if (v___x_206_ == 0)
{
lean_object* v___x_207_; lean_object* v___x_208_; uint8_t v___x_209_; 
lean_dec(v___x_203_);
v___x_207_ = lean_box(v___x_202_);
v___x_208_ = l_outOfBounds___redArg(v___x_207_);
lean_dec(v___x_207_);
v___x_209_ = lean_unbox(v___x_208_);
lean_dec(v___x_208_);
v___y_194_ = v___y_205_;
v___y_195_ = v___x_209_;
goto v___jp_193_;
}
else
{
uint8_t v___x_210_; 
v___x_210_ = lean_byte_array_fget(v_right_182_, v___x_203_);
lean_dec(v___x_203_);
v___y_194_ = v___y_205_;
v___y_195_ = v___x_210_;
goto v___jp_193_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___boxed(lean_object* v_start_216_, lean_object* v___x_217_, lean_object* v_count_218_, lean_object* v_right_219_, lean_object* v_left_220_, lean_object* v_range_221_, lean_object* v_b_222_, lean_object* v_i_223_){
_start:
{
lean_object* v_res_224_; 
v_res_224_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg(v_start_216_, v___x_217_, v_count_218_, v_right_219_, v_left_220_, v_range_221_, v_b_222_, v_i_223_);
lean_dec_ref(v_b_222_);
lean_dec_ref(v_range_221_);
lean_dec_ref(v_left_220_);
lean_dec_ref(v_right_219_);
lean_dec(v_count_218_);
lean_dec(v___x_217_);
lean_dec(v_start_216_);
return v_res_224_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Native_Bytes_equalPortable(lean_object* v_left_225_, lean_object* v_right_226_, lean_object* v_start_227_, lean_object* v_count_228_){
_start:
{
lean_object* v___x_229_; uint8_t v___x_230_; 
v___x_229_ = lean_unsigned_to_nat(4096u);
v___x_230_ = lean_nat_dec_lt(v___x_229_, v_count_228_);
if (v___x_230_ == 0)
{
lean_object* v___x_231_; uint8_t v___x_232_; 
v___x_231_ = lean_byte_array_size(v_left_225_);
v___x_232_ = lean_nat_dec_lt(v___x_231_, v_start_227_);
if (v___x_232_ == 0)
{
lean_object* v___x_233_; uint8_t v___x_234_; 
v___x_233_ = lean_byte_array_size(v_right_226_);
v___x_234_ = lean_nat_dec_lt(v___x_233_, v_start_227_);
if (v___x_234_ == 0)
{
lean_object* v___x_235_; uint8_t v___x_236_; 
v___x_235_ = lean_nat_sub(v___x_231_, v_start_227_);
v___x_236_ = lean_nat_dec_lt(v___x_235_, v_count_228_);
lean_dec(v___x_235_);
if (v___x_236_ == 0)
{
lean_object* v___x_237_; uint8_t v___x_238_; 
v___x_237_ = lean_nat_sub(v___x_233_, v_start_227_);
v___x_238_ = lean_nat_dec_lt(v___x_237_, v_count_228_);
if (v___x_238_ == 0)
{
lean_object* v___x_239_; lean_object* v___x_240_; lean_object* v___x_241_; lean_object* v___x_242_; lean_object* v___x_243_; lean_object* v_fst_244_; 
v___x_239_ = lean_unsigned_to_nat(0u);
v___x_240_ = lean_unsigned_to_nat(1u);
lean_inc(v_count_228_);
v___x_241_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_241_, 0, v___x_239_);
lean_ctor_set(v___x_241_, 1, v_count_228_);
lean_ctor_set(v___x_241_, 2, v___x_240_);
v___x_242_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___closed__0));
v___x_243_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg(v_start_227_, v___x_237_, v_count_228_, v_right_226_, v_left_225_, v___x_241_, v___x_242_, v___x_239_);
lean_dec_ref_known(v___x_241_, 3);
lean_dec(v_count_228_);
lean_dec(v___x_237_);
v_fst_244_ = lean_ctor_get(v___x_243_, 0);
lean_inc(v_fst_244_);
lean_dec_ref(v___x_243_);
if (lean_obj_tag(v_fst_244_) == 0)
{
uint8_t v___x_245_; 
v___x_245_ = 1;
return v___x_245_;
}
else
{
lean_object* v_val_246_; uint8_t v___x_247_; 
v_val_246_ = lean_ctor_get(v_fst_244_, 0);
lean_inc(v_val_246_);
lean_dec_ref_known(v_fst_244_, 1);
v___x_247_ = lean_unbox(v_val_246_);
lean_dec(v_val_246_);
return v___x_247_;
}
}
else
{
lean_dec(v___x_237_);
lean_dec(v_count_228_);
return v___x_236_;
}
}
else
{
lean_dec(v_count_228_);
return v___x_234_;
}
}
else
{
lean_dec(v_count_228_);
return v___x_232_;
}
}
else
{
lean_dec(v_count_228_);
return v___x_230_;
}
}
else
{
uint8_t v___x_248_; 
lean_dec(v_count_228_);
v___x_248_ = 0;
return v___x_248_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Bytes_equalPortable___boxed(lean_object* v_left_249_, lean_object* v_right_250_, lean_object* v_start_251_, lean_object* v_count_252_){
_start:
{
uint8_t v_res_253_; lean_object* v_r_254_; 
v_res_253_ = lp_Hex_Hex_Groebner_Native_Bytes_equalPortable(v_left_249_, v_right_250_, v_start_251_, v_count_252_);
lean_dec(v_start_251_);
lean_dec_ref(v_right_250_);
lean_dec_ref(v_left_249_);
v_r_254_ = lean_box(v_res_253_);
return v_r_254_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0(lean_object* v_start_255_, lean_object* v___x_256_, lean_object* v_count_257_, lean_object* v_right_258_, lean_object* v_left_259_, lean_object* v_range_260_, lean_object* v_b_261_, lean_object* v_i_262_, lean_object* v_hs_263_, lean_object* v_hl_264_){
_start:
{
lean_object* v___x_265_; 
v___x_265_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg(v_start_255_, v___x_256_, v_count_257_, v_right_258_, v_left_259_, v_range_260_, v_b_261_, v_i_262_);
return v___x_265_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___boxed(lean_object* v_start_266_, lean_object* v___x_267_, lean_object* v_count_268_, lean_object* v_right_269_, lean_object* v_left_270_, lean_object* v_range_271_, lean_object* v_b_272_, lean_object* v_i_273_, lean_object* v_hs_274_, lean_object* v_hl_275_){
_start:
{
lean_object* v_res_276_; 
v_res_276_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0(v_start_266_, v___x_267_, v_count_268_, v_right_269_, v_left_270_, v_range_271_, v_b_272_, v_i_273_, v_hs_274_, v_hl_275_);
lean_dec_ref(v_b_272_);
lean_dec_ref(v_range_271_);
lean_dec_ref(v_left_270_);
lean_dec_ref(v_right_269_);
lean_dec(v_count_268_);
lean_dec(v___x_267_);
lean_dec(v_start_266_);
return v_res_276_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Bytes_equal___boxed(lean_object* v_left_281_, lean_object* v_right_282_, lean_object* v_start_283_, lean_object* v_count_284_){
_start:
{
uint8_t v_res_285_; lean_object* v_r_286_; 
v_res_285_ = lean_hex_groebner_equal_bytes(v_left_281_, v_right_282_, v_start_283_, v_count_284_);
lean_dec(v_count_284_);
lean_dec(v_start_283_);
lean_dec_ref(v_right_282_);
lean_dec_ref(v_left_281_);
v_r_286_ = lean_box(v_res_285_);
return v_r_286_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0___redArg(lean_object* v___x_287_, lean_object* v_n_288_, lean_object* v_w_289_, lean_object* v_arena_290_, uint64_t v_multiplier_291_, lean_object* v___x_292_, lean_object* v_count_293_, lean_object* v_range_294_, lean_object* v_b_295_, lean_object* v_i_296_){
_start:
{
lean_object* v_stop_297_; lean_object* v_step_298_; uint8_t v___x_299_; 
v_stop_297_ = lean_ctor_get(v_range_294_, 1);
v_step_298_ = lean_ctor_get(v_range_294_, 2);
v___x_299_ = lean_nat_dec_lt(v_i_296_, v_stop_297_);
if (v___x_299_ == 0)
{
lean_dec(v_i_296_);
lean_inc_ref(v_b_295_);
return v_b_295_;
}
else
{
lean_object* v___x_300_; lean_object* v___x_301_; lean_object* v___x_302_; lean_object* v___x_303_; lean_object* v___x_304_; lean_object* v___x_305_; lean_object* v___x_306_; lean_object* v___x_307_; lean_object* v___x_308_; lean_object* v___x_309_; lean_object* v___x_310_; lean_object* v___x_311_; lean_object* v___x_312_; lean_object* v___x_313_; lean_object* v___x_314_; uint8_t v___x_315_; 
v___x_300_ = lean_box(0);
v___x_301_ = lean_nat_mul(v___x_287_, v_n_288_);
v___x_302_ = lean_nat_add(v___x_301_, v_i_296_);
lean_dec(v___x_301_);
v___x_303_ = lean_nat_mul(v___x_302_, v_w_289_);
lean_dec(v___x_302_);
v___x_304_ = lp_Hex_Hex_Groebner_Native_read(v_arena_290_, v_w_289_, v___x_303_);
lean_dec(v___x_303_);
v___x_305_ = lean_uint64_to_nat(v_multiplier_291_);
v___x_306_ = lean_nat_mul(v___x_305_, v_n_288_);
lean_dec(v___x_305_);
v___x_307_ = lean_nat_add(v___x_306_, v_i_296_);
lean_dec(v___x_306_);
v___x_308_ = lean_nat_mul(v___x_307_, v_w_289_);
lean_dec(v___x_307_);
v___x_309_ = lp_Hex_Hex_Groebner_Native_read(v_arena_290_, v_w_289_, v___x_308_);
lean_dec(v___x_308_);
v___x_310_ = lean_nat_add(v___x_304_, v___x_309_);
lean_dec(v___x_309_);
lean_dec(v___x_304_);
v___x_311_ = lean_nat_mul(v___x_292_, v_n_288_);
v___x_312_ = lean_nat_add(v___x_311_, v_i_296_);
lean_dec(v___x_311_);
v___x_313_ = lean_nat_mul(v___x_312_, v_w_289_);
lean_dec(v___x_312_);
v___x_314_ = lp_Hex_Hex_Groebner_Native_read(v_arena_290_, v_w_289_, v___x_313_);
lean_dec(v___x_313_);
v___x_315_ = lean_nat_dec_eq(v___x_310_, v___x_314_);
lean_dec(v___x_314_);
lean_dec(v___x_310_);
if (v___x_315_ == 0)
{
uint8_t v___x_316_; lean_object* v___x_317_; lean_object* v___x_318_; lean_object* v___x_319_; 
lean_dec(v_i_296_);
v___x_316_ = lean_nat_dec_le(v_count_293_, v___x_292_);
v___x_317_ = lean_box(v___x_316_);
v___x_318_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_318_, 0, v___x_317_);
v___x_319_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_319_, 0, v___x_318_);
lean_ctor_set(v___x_319_, 1, v___x_300_);
return v___x_319_;
}
else
{
lean_object* v___x_320_; lean_object* v___x_321_; 
v___x_320_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___closed__0));
v___x_321_ = lean_nat_add(v_i_296_, v_step_298_);
lean_dec(v_i_296_);
v_b_295_ = v___x_320_;
v_i_296_ = v___x_321_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0___redArg___boxed(lean_object* v___x_323_, lean_object* v_n_324_, lean_object* v_w_325_, lean_object* v_arena_326_, lean_object* v_multiplier_327_, lean_object* v___x_328_, lean_object* v_count_329_, lean_object* v_range_330_, lean_object* v_b_331_, lean_object* v_i_332_){
_start:
{
uint64_t v_multiplier_boxed_333_; lean_object* v_res_334_; 
v_multiplier_boxed_333_ = lean_unbox_uint64(v_multiplier_327_);
lean_dec_ref(v_multiplier_327_);
v_res_334_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0___redArg(v___x_323_, v_n_324_, v_w_325_, v_arena_326_, v_multiplier_boxed_333_, v___x_328_, v_count_329_, v_range_330_, v_b_331_, v_i_332_);
lean_dec_ref(v_b_331_);
lean_dec_ref(v_range_330_);
lean_dec(v_count_329_);
lean_dec(v___x_328_);
lean_dec_ref(v_arena_326_);
lean_dec(v_w_325_);
lean_dec(v_n_324_);
lean_dec(v___x_323_);
return v_res_334_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1___redArg(lean_object* v___x_335_, lean_object* v_terms_336_, lean_object* v_base_337_, lean_object* v_count_338_, lean_object* v_result_339_, lean_object* v_n_340_, lean_object* v_w_341_, lean_object* v_arena_342_, uint64_t v_multiplier_343_, lean_object* v_range_344_, lean_object* v_b_345_, lean_object* v_i_346_){
_start:
{
lean_object* v_stop_347_; lean_object* v_step_348_; uint8_t v___x_349_; 
v_stop_347_ = lean_ctor_get(v_range_344_, 1);
v_step_348_ = lean_ctor_get(v_range_344_, 2);
v___x_349_ = lean_nat_dec_lt(v_i_346_, v_stop_347_);
if (v___x_349_ == 0)
{
lean_dec(v_i_346_);
lean_dec(v_n_340_);
lean_inc_ref(v_b_345_);
return v_b_345_;
}
else
{
uint8_t v___x_350_; lean_object* v___x_351_; lean_object* v___x_356_; lean_object* v___x_357_; lean_object* v___x_358_; uint8_t v___x_359_; 
v___x_350_ = lean_nat_dec_lt(v___x_335_, v_terms_336_);
v___x_351_ = lean_box(0);
v___x_356_ = lean_unsigned_to_nat(4u);
v___x_357_ = lean_nat_mul(v___x_356_, v_i_346_);
v___x_358_ = lp_Hex_Hex_Groebner_Native_read(v_base_337_, v___x_356_, v___x_357_);
v___x_359_ = lean_nat_dec_le(v_count_338_, v___x_358_);
if (v___x_359_ == 0)
{
lean_object* v___x_360_; uint8_t v___x_361_; 
v___x_360_ = lp_Hex_Hex_Groebner_Native_read(v_result_339_, v___x_356_, v___x_357_);
lean_dec(v___x_357_);
v___x_361_ = lean_nat_dec_le(v_count_338_, v___x_360_);
if (v___x_361_ == 0)
{
lean_object* v___x_362_; lean_object* v___x_363_; lean_object* v___x_364_; lean_object* v___x_365_; lean_object* v___x_366_; lean_object* v_fst_367_; lean_object* v___x_369_; uint8_t v_isShared_370_; uint8_t v_isSharedCheck_376_; 
v___x_362_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___closed__0));
v___x_363_ = lean_unsigned_to_nat(1u);
v___x_364_ = lean_unsigned_to_nat(0u);
lean_inc(v_n_340_);
v___x_365_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_365_, 0, v___x_364_);
lean_ctor_set(v___x_365_, 1, v_n_340_);
lean_ctor_set(v___x_365_, 2, v___x_363_);
v___x_366_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0___redArg(v___x_358_, v_n_340_, v_w_341_, v_arena_342_, v_multiplier_343_, v___x_360_, v_count_338_, v___x_365_, v___x_362_, v___x_364_);
lean_dec_ref_known(v___x_365_, 3);
lean_dec(v___x_360_);
lean_dec(v___x_358_);
v_fst_367_ = lean_ctor_get(v___x_366_, 0);
v_isSharedCheck_376_ = !lean_is_exclusive(v___x_366_);
if (v_isSharedCheck_376_ == 0)
{
lean_object* v_unused_377_; 
v_unused_377_ = lean_ctor_get(v___x_366_, 1);
lean_dec(v_unused_377_);
v___x_369_ = v___x_366_;
v_isShared_370_ = v_isSharedCheck_376_;
goto v_resetjp_368_;
}
else
{
lean_inc(v_fst_367_);
lean_dec(v___x_366_);
v___x_369_ = lean_box(0);
v_isShared_370_ = v_isSharedCheck_376_;
goto v_resetjp_368_;
}
v_resetjp_368_:
{
if (lean_obj_tag(v_fst_367_) == 0)
{
lean_object* v___x_371_; 
lean_del_object(v___x_369_);
v___x_371_ = lean_nat_add(v_i_346_, v_step_348_);
lean_dec(v_i_346_);
v_b_345_ = v___x_362_;
v_i_346_ = v___x_371_;
goto _start;
}
else
{
lean_object* v___x_374_; 
lean_dec(v_i_346_);
lean_dec(v_n_340_);
if (v_isShared_370_ == 0)
{
lean_ctor_set(v___x_369_, 1, v___x_351_);
v___x_374_ = v___x_369_;
goto v_reusejp_373_;
}
else
{
lean_object* v_reuseFailAlloc_375_; 
v_reuseFailAlloc_375_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_375_, 0, v_fst_367_);
lean_ctor_set(v_reuseFailAlloc_375_, 1, v___x_351_);
v___x_374_ = v_reuseFailAlloc_375_;
goto v_reusejp_373_;
}
v_reusejp_373_:
{
return v___x_374_;
}
}
}
}
else
{
lean_dec(v___x_360_);
lean_dec(v___x_358_);
lean_dec(v_i_346_);
lean_dec(v_n_340_);
goto v___jp_352_;
}
}
else
{
lean_dec(v___x_358_);
lean_dec(v___x_357_);
lean_dec(v_i_346_);
lean_dec(v_n_340_);
goto v___jp_352_;
}
v___jp_352_:
{
lean_object* v___x_353_; lean_object* v___x_354_; lean_object* v___x_355_; 
v___x_353_ = lean_box(v___x_350_);
v___x_354_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_354_, 0, v___x_353_);
v___x_355_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_355_, 0, v___x_354_);
lean_ctor_set(v___x_355_, 1, v___x_351_);
return v___x_355_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1___redArg___boxed(lean_object* v___x_378_, lean_object* v_terms_379_, lean_object* v_base_380_, lean_object* v_count_381_, lean_object* v_result_382_, lean_object* v_n_383_, lean_object* v_w_384_, lean_object* v_arena_385_, lean_object* v_multiplier_386_, lean_object* v_range_387_, lean_object* v_b_388_, lean_object* v_i_389_){
_start:
{
uint64_t v_multiplier_boxed_390_; lean_object* v_res_391_; 
v_multiplier_boxed_390_ = lean_unbox_uint64(v_multiplier_386_);
lean_dec_ref(v_multiplier_386_);
v_res_391_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1___redArg(v___x_378_, v_terms_379_, v_base_380_, v_count_381_, v_result_382_, v_n_383_, v_w_384_, v_arena_385_, v_multiplier_boxed_390_, v_range_387_, v_b_388_, v_i_389_);
lean_dec_ref(v_b_388_);
lean_dec_ref(v_range_387_);
lean_dec_ref(v_arena_385_);
lean_dec(v_w_384_);
lean_dec_ref(v_result_382_);
lean_dec(v_count_381_);
lean_dec_ref(v_base_380_);
lean_dec(v_terms_379_);
lean_dec(v___x_378_);
return v_res_391_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Native_Monomial_productsPortable(uint8_t v_width_392_, uint64_t v_arity_393_, uint64_t v_count_394_, uint64_t v_multiplier_395_, uint64_t v_start_396_, uint64_t v_terms_397_, lean_object* v_arena_398_, lean_object* v_base_399_, lean_object* v_result_400_){
_start:
{
lean_object* v_w_401_; lean_object* v_n_402_; lean_object* v_count_403_; lean_object* v_start_404_; lean_object* v_terms_405_; lean_object* v___x_406_; uint8_t v___y_408_; uint8_t v___x_439_; 
v_w_401_ = lean_uint8_to_nat(v_width_392_);
v_n_402_ = lean_uint64_to_nat(v_arity_393_);
v_count_403_ = lean_uint64_to_nat(v_count_394_);
v_start_404_ = lean_uint64_to_nat(v_start_396_);
v_terms_405_ = lean_uint64_to_nat(v_terms_397_);
v___x_406_ = lean_unsigned_to_nat(1u);
v___x_439_ = lean_nat_dec_eq(v_w_401_, v___x_406_);
if (v___x_439_ == 0)
{
lean_object* v___x_440_; uint8_t v___x_441_; 
v___x_440_ = lean_unsigned_to_nat(2u);
v___x_441_ = lean_nat_dec_eq(v_w_401_, v___x_440_);
if (v___x_441_ == 0)
{
lean_object* v___x_442_; uint8_t v___x_443_; 
v___x_442_ = lean_unsigned_to_nat(4u);
v___x_443_ = lean_nat_dec_eq(v_w_401_, v___x_442_);
if (v___x_443_ == 0)
{
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___x_443_;
}
else
{
v___y_408_ = v___x_441_;
goto v___jp_407_;
}
}
else
{
v___y_408_ = v___x_439_;
goto v___jp_407_;
}
}
else
{
uint8_t v___x_444_; 
v___x_444_ = 0;
v___y_408_ = v___x_444_;
goto v___jp_407_;
}
v___jp_407_:
{
lean_object* v___x_409_; uint8_t v___x_410_; 
v___x_409_ = lean_unsigned_to_nat(0u);
v___x_410_ = lean_nat_dec_eq(v_n_402_, v___x_409_);
if (v___x_410_ == 0)
{
lean_object* v___x_411_; uint8_t v___x_412_; 
v___x_411_ = lean_unsigned_to_nat(4096u);
v___x_412_ = lean_nat_dec_lt(v___x_411_, v_n_402_);
if (v___x_412_ == 0)
{
lean_object* v___x_413_; uint8_t v___x_414_; 
v___x_413_ = lean_nat_mul(v_terms_405_, v_n_402_);
v___x_414_ = lean_nat_dec_lt(v___x_411_, v___x_413_);
lean_dec(v___x_413_);
if (v___x_414_ == 0)
{
lean_object* v___x_415_; uint8_t v___x_416_; 
v___x_415_ = lean_uint64_to_nat(v_multiplier_395_);
v___x_416_ = lean_nat_dec_le(v_count_403_, v___x_415_);
lean_dec(v___x_415_);
if (v___x_416_ == 0)
{
lean_object* v___x_417_; lean_object* v___x_418_; lean_object* v___x_419_; uint8_t v___x_420_; 
v___x_417_ = lean_byte_array_size(v_arena_398_);
v___x_418_ = lean_nat_mul(v_count_403_, v_n_402_);
v___x_419_ = lean_nat_mul(v___x_418_, v_w_401_);
lean_dec(v___x_418_);
v___x_420_ = lean_nat_dec_eq(v___x_417_, v___x_419_);
lean_dec(v___x_419_);
if (v___x_420_ == 0)
{
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___x_420_;
}
else
{
lean_object* v___x_421_; lean_object* v___x_422_; lean_object* v___x_423_; uint8_t v___x_424_; 
v___x_421_ = lean_byte_array_size(v_base_399_);
v___x_422_ = lean_unsigned_to_nat(4u);
v___x_423_ = lean_nat_mod(v___x_421_, v___x_422_);
v___x_424_ = lean_nat_dec_eq(v___x_423_, v___x_409_);
lean_dec(v___x_423_);
if (v___x_424_ == 0)
{
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___x_424_;
}
else
{
lean_object* v___x_425_; uint8_t v___x_426_; 
v___x_425_ = lean_byte_array_size(v_result_400_);
v___x_426_ = lean_nat_dec_eq(v___x_425_, v___x_421_);
if (v___x_426_ == 0)
{
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___x_426_;
}
else
{
lean_object* v___x_427_; lean_object* v___x_428_; uint8_t v___x_429_; 
v___x_427_ = lean_unsigned_to_nat(2u);
v___x_428_ = lean_nat_shiftr(v___x_421_, v___x_427_);
v___x_429_ = lean_nat_dec_lt(v___x_428_, v_start_404_);
if (v___x_429_ == 0)
{
lean_object* v___x_430_; uint8_t v___x_431_; 
v___x_430_ = lean_nat_sub(v___x_428_, v_start_404_);
lean_dec(v___x_428_);
v___x_431_ = lean_nat_dec_lt(v___x_430_, v_terms_405_);
if (v___x_431_ == 0)
{
lean_object* v___x_432_; lean_object* v___x_433_; lean_object* v___x_434_; lean_object* v___x_435_; lean_object* v_fst_436_; 
v___x_432_ = lean_nat_add(v_start_404_, v_terms_405_);
lean_inc(v_start_404_);
v___x_433_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_433_, 0, v_start_404_);
lean_ctor_set(v___x_433_, 1, v___x_432_);
lean_ctor_set(v___x_433_, 2, v___x_406_);
v___x_434_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Bytes_equalPortable_spec__0___redArg___closed__0));
v___x_435_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1___redArg(v___x_430_, v_terms_405_, v_base_399_, v_count_403_, v_result_400_, v_n_402_, v_w_401_, v_arena_398_, v_multiplier_395_, v___x_433_, v___x_434_, v_start_404_);
lean_dec_ref_known(v___x_433_, 3);
lean_dec(v_count_403_);
lean_dec(v_terms_405_);
lean_dec(v___x_430_);
v_fst_436_ = lean_ctor_get(v___x_435_, 0);
lean_inc(v_fst_436_);
lean_dec_ref(v___x_435_);
if (lean_obj_tag(v_fst_436_) == 0)
{
return v___x_426_;
}
else
{
lean_object* v_val_437_; uint8_t v___x_438_; 
v_val_437_ = lean_ctor_get(v_fst_436_, 0);
lean_inc(v_val_437_);
lean_dec_ref_known(v_fst_436_, 1);
v___x_438_ = lean_unbox(v_val_437_);
lean_dec(v_val_437_);
return v___x_438_;
}
}
else
{
lean_dec(v___x_430_);
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___x_429_;
}
}
else
{
lean_dec(v___x_428_);
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___x_416_;
}
}
}
}
}
else
{
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___x_414_;
}
}
else
{
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___x_412_;
}
}
else
{
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___x_410_;
}
}
else
{
lean_dec(v_terms_405_);
lean_dec(v_start_404_);
lean_dec(v_count_403_);
lean_dec(v_n_402_);
return v___y_408_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_productsPortable___boxed(lean_object* v_width_445_, lean_object* v_arity_446_, lean_object* v_count_447_, lean_object* v_multiplier_448_, lean_object* v_start_449_, lean_object* v_terms_450_, lean_object* v_arena_451_, lean_object* v_base_452_, lean_object* v_result_453_){
_start:
{
uint8_t v_width_boxed_454_; uint64_t v_arity_boxed_455_; uint64_t v_count_boxed_456_; uint64_t v_multiplier_boxed_457_; uint64_t v_start_boxed_458_; uint64_t v_terms_boxed_459_; uint8_t v_res_460_; lean_object* v_r_461_; 
v_width_boxed_454_ = lean_unbox(v_width_445_);
v_arity_boxed_455_ = lean_unbox_uint64(v_arity_446_);
lean_dec_ref(v_arity_446_);
v_count_boxed_456_ = lean_unbox_uint64(v_count_447_);
lean_dec_ref(v_count_447_);
v_multiplier_boxed_457_ = lean_unbox_uint64(v_multiplier_448_);
lean_dec_ref(v_multiplier_448_);
v_start_boxed_458_ = lean_unbox_uint64(v_start_449_);
lean_dec_ref(v_start_449_);
v_terms_boxed_459_ = lean_unbox_uint64(v_terms_450_);
lean_dec_ref(v_terms_450_);
v_res_460_ = lp_Hex_Hex_Groebner_Native_Monomial_productsPortable(v_width_boxed_454_, v_arity_boxed_455_, v_count_boxed_456_, v_multiplier_boxed_457_, v_start_boxed_458_, v_terms_boxed_459_, v_arena_451_, v_base_452_, v_result_453_);
lean_dec_ref(v_result_453_);
lean_dec_ref(v_base_452_);
lean_dec_ref(v_arena_451_);
v_r_461_ = lean_box(v_res_460_);
return v_r_461_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0(lean_object* v___x_462_, lean_object* v_n_463_, lean_object* v_w_464_, lean_object* v_arena_465_, uint64_t v_multiplier_466_, lean_object* v___x_467_, lean_object* v_count_468_, lean_object* v_range_469_, lean_object* v_b_470_, lean_object* v_i_471_, lean_object* v_hs_472_, lean_object* v_hl_473_){
_start:
{
lean_object* v___x_474_; 
v___x_474_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0___redArg(v___x_462_, v_n_463_, v_w_464_, v_arena_465_, v_multiplier_466_, v___x_467_, v_count_468_, v_range_469_, v_b_470_, v_i_471_);
return v___x_474_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0___boxed(lean_object* v___x_475_, lean_object* v_n_476_, lean_object* v_w_477_, lean_object* v_arena_478_, lean_object* v_multiplier_479_, lean_object* v___x_480_, lean_object* v_count_481_, lean_object* v_range_482_, lean_object* v_b_483_, lean_object* v_i_484_, lean_object* v_hs_485_, lean_object* v_hl_486_){
_start:
{
uint64_t v_multiplier_boxed_487_; lean_object* v_res_488_; 
v_multiplier_boxed_487_ = lean_unbox_uint64(v_multiplier_479_);
lean_dec_ref(v_multiplier_479_);
v_res_488_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__0(v___x_475_, v_n_476_, v_w_477_, v_arena_478_, v_multiplier_boxed_487_, v___x_480_, v_count_481_, v_range_482_, v_b_483_, v_i_484_, v_hs_485_, v_hl_486_);
lean_dec_ref(v_b_483_);
lean_dec_ref(v_range_482_);
lean_dec(v_count_481_);
lean_dec(v___x_480_);
lean_dec_ref(v_arena_478_);
lean_dec(v_w_477_);
lean_dec(v_n_476_);
lean_dec(v___x_475_);
return v_res_488_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1(lean_object* v___x_489_, lean_object* v_terms_490_, lean_object* v_base_491_, lean_object* v_count_492_, lean_object* v_result_493_, lean_object* v_n_494_, lean_object* v_w_495_, lean_object* v_arena_496_, uint64_t v_multiplier_497_, lean_object* v_range_498_, lean_object* v_b_499_, lean_object* v_i_500_, lean_object* v_hs_501_, lean_object* v_hl_502_){
_start:
{
lean_object* v___x_503_; 
v___x_503_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1___redArg(v___x_489_, v_terms_490_, v_base_491_, v_count_492_, v_result_493_, v_n_494_, v_w_495_, v_arena_496_, v_multiplier_497_, v_range_498_, v_b_499_, v_i_500_);
return v___x_503_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1___boxed(lean_object* v___x_504_, lean_object* v_terms_505_, lean_object* v_base_506_, lean_object* v_count_507_, lean_object* v_result_508_, lean_object* v_n_509_, lean_object* v_w_510_, lean_object* v_arena_511_, lean_object* v_multiplier_512_, lean_object* v_range_513_, lean_object* v_b_514_, lean_object* v_i_515_, lean_object* v_hs_516_, lean_object* v_hl_517_){
_start:
{
uint64_t v_multiplier_boxed_518_; lean_object* v_res_519_; 
v_multiplier_boxed_518_ = lean_unbox_uint64(v_multiplier_512_);
lean_dec_ref(v_multiplier_512_);
v_res_519_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Native_Monomial_productsPortable_spec__1(v___x_504_, v_terms_505_, v_base_506_, v_count_507_, v_result_508_, v_n_509_, v_w_510_, v_arena_511_, v_multiplier_boxed_518_, v_range_513_, v_b_514_, v_i_515_, v_hs_516_, v_hl_517_);
lean_dec_ref(v_b_514_);
lean_dec_ref(v_range_513_);
lean_dec_ref(v_arena_511_);
lean_dec(v_w_510_);
lean_dec_ref(v_result_508_);
lean_dec(v_count_507_);
lean_dec_ref(v_base_506_);
lean_dec(v_terms_505_);
lean_dec(v___x_504_);
return v_res_519_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_products___boxed(lean_object* v_width_529_, lean_object* v_arity_530_, lean_object* v_count_531_, lean_object* v_multiplier_532_, lean_object* v_start_533_, lean_object* v_terms_534_, lean_object* v_arena_535_, lean_object* v_base_536_, lean_object* v_result_537_){
_start:
{
uint8_t v_width_boxed_538_; uint64_t v_arity_boxed_539_; uint64_t v_count_boxed_540_; uint64_t v_multiplier_boxed_541_; uint64_t v_start_boxed_542_; uint64_t v_terms_boxed_543_; uint8_t v_res_544_; lean_object* v_r_545_; 
v_width_boxed_538_ = lean_unbox(v_width_529_);
v_arity_boxed_539_ = lean_unbox_uint64(v_arity_530_);
lean_dec_ref(v_arity_530_);
v_count_boxed_540_ = lean_unbox_uint64(v_count_531_);
lean_dec_ref(v_count_531_);
v_multiplier_boxed_541_ = lean_unbox_uint64(v_multiplier_532_);
lean_dec_ref(v_multiplier_532_);
v_start_boxed_542_ = lean_unbox_uint64(v_start_533_);
lean_dec_ref(v_start_533_);
v_terms_boxed_543_ = lean_unbox_uint64(v_terms_534_);
lean_dec_ref(v_terms_534_);
v_res_544_ = lean_hex_groebner_equal_products(v_width_boxed_538_, v_arity_boxed_539_, v_count_boxed_540_, v_multiplier_boxed_541_, v_start_boxed_542_, v_terms_boxed_543_, v_arena_535_, v_base_536_, v_result_537_);
lean_dec_ref(v_result_537_);
lean_dec_ref(v_base_536_);
lean_dec_ref(v_arena_535_);
v_r_545_ = lean_box(v_res_544_);
return v_r_545_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_fill(lean_object* v_operation_546_, lean_object* v_width_547_, lean_object* v_arity_548_, lean_object* v_left_549_, lean_object* v_right_550_, lean_object* v_index_551_, lean_object* v_source_552_, uint64_t v_degree_553_, uint64_t v_mask_554_, uint64_t v_hash_555_, uint64_t v_largest_556_, lean_object* v_x_557_, lean_object* v_x_558_){
_start:
{
lean_object* v_zero_559_; uint8_t v_isZero_560_; 
v_zero_559_ = lean_unsigned_to_nat(0u);
v_isZero_560_ = lean_nat_dec_eq(v_x_557_, v_zero_559_);
if (v_isZero_560_ == 1)
{
lean_object* v___x_561_; lean_object* v_offset_562_; lean_object* v___x_563_; lean_object* v___x_564_; lean_object* v_workspace_565_; lean_object* v___x_566_; lean_object* v___x_567_; lean_object* v_workspace_568_; lean_object* v___x_569_; lean_object* v___x_570_; lean_object* v___x_571_; lean_object* v_workspace_572_; lean_object* v___x_573_; lean_object* v___x_574_; lean_object* v___x_575_; lean_object* v___x_576_; lean_object* v___x_577_; 
lean_dec(v_x_557_);
lean_dec(v_index_551_);
v___x_561_ = lean_unsigned_to_nat(4u);
v_offset_562_ = lean_nat_mul(v_arity_548_, v___x_561_);
v___x_563_ = lean_unsigned_to_nat(8u);
v___x_564_ = lean_uint64_to_nat(v_degree_553_);
lean_inc(v_offset_562_);
v_workspace_565_ = lp_Hex_Hex_Groebner_Native_write(v_x_558_, v___x_563_, v_offset_562_, v___x_564_);
v___x_566_ = lean_nat_add(v_offset_562_, v___x_563_);
v___x_567_ = lean_uint64_to_nat(v_mask_554_);
v_workspace_568_ = lp_Hex_Hex_Groebner_Native_write(v_workspace_565_, v___x_563_, v___x_566_, v___x_567_);
v___x_569_ = lean_unsigned_to_nat(16u);
v___x_570_ = lean_nat_add(v_offset_562_, v___x_569_);
v___x_571_ = lean_uint64_to_nat(v_hash_555_);
v_workspace_572_ = lp_Hex_Hex_Groebner_Native_write(v_workspace_568_, v___x_563_, v___x_570_, v___x_571_);
v___x_573_ = lean_unsigned_to_nat(24u);
v___x_574_ = lean_nat_add(v_offset_562_, v___x_573_);
lean_dec(v_offset_562_);
v___x_575_ = lean_uint64_to_nat(v_largest_556_);
v___x_576_ = lp_Hex_Hex_Groebner_Native_write(v_workspace_572_, v___x_561_, v___x_574_, v___x_575_);
v___x_577_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_577_, 0, v___x_576_);
return v___x_577_;
}
else
{
lean_object* v_one_578_; lean_object* v_n_579_; lean_object* v___x_580_; lean_object* v___x_581_; lean_object* v___x_582_; lean_object* v___x_583_; uint64_t v_x_584_; lean_object* v___x_585_; lean_object* v___x_586_; lean_object* v___x_587_; lean_object* v___x_588_; uint64_t v_y_589_; uint64_t v___y_591_; lean_object* v___y_592_; uint64_t v___y_593_; uint64_t v___y_603_; uint8_t v___x_616_; 
v_one_578_ = lean_unsigned_to_nat(1u);
v_n_579_ = lean_nat_sub(v_x_557_, v_one_578_);
lean_dec(v_x_557_);
v___x_580_ = lean_nat_mul(v_left_549_, v_arity_548_);
v___x_581_ = lean_nat_add(v___x_580_, v_index_551_);
lean_dec(v___x_580_);
v___x_582_ = lean_nat_mul(v___x_581_, v_width_547_);
lean_dec(v___x_581_);
v___x_583_ = lp_Hex_Hex_Groebner_Native_read(v_source_552_, v_width_547_, v___x_582_);
lean_dec(v___x_582_);
v_x_584_ = lean_uint64_of_nat(v___x_583_);
lean_dec(v___x_583_);
v___x_585_ = lean_nat_mul(v_right_550_, v_arity_548_);
v___x_586_ = lean_nat_add(v___x_585_, v_index_551_);
lean_dec(v___x_585_);
v___x_587_ = lean_nat_mul(v___x_586_, v_width_547_);
lean_dec(v___x_586_);
v___x_588_ = lp_Hex_Hex_Groebner_Native_read(v_source_552_, v_width_547_, v___x_587_);
lean_dec(v___x_587_);
v_y_589_ = lean_uint64_of_nat(v___x_588_);
lean_dec(v___x_588_);
v___x_616_ = lean_nat_dec_eq(v_operation_546_, v_one_578_);
if (v___x_616_ == 0)
{
goto v___jp_622_;
}
else
{
uint64_t v___x_627_; uint64_t v___x_628_; uint8_t v___x_629_; 
v___x_627_ = 4294967295ULL;
v___x_628_ = lean_uint64_add(v_x_584_, v_y_589_);
v___x_629_ = lean_uint64_dec_lt(v___x_627_, v___x_628_);
if (v___x_629_ == 0)
{
goto v___jp_622_;
}
else
{
lean_object* v___x_630_; 
lean_dec(v_n_579_);
lean_dec_ref(v_x_558_);
lean_dec(v_index_551_);
v___x_630_ = lean_box(0);
return v___x_630_;
}
}
v___jp_590_:
{
lean_object* v___x_594_; uint64_t v___x_595_; uint64_t v___x_596_; uint64_t v___x_597_; uint64_t v___x_598_; uint8_t v___x_599_; 
v___x_594_ = lean_nat_add(v_index_551_, v_one_578_);
lean_dec(v_index_551_);
v___x_595_ = lean_uint64_add(v_degree_553_, v___y_591_);
v___x_596_ = lean_uint64_xor(v_hash_555_, v___y_591_);
v___x_597_ = 1099511628211ULL;
v___x_598_ = lean_uint64_mul(v___x_596_, v___x_597_);
v___x_599_ = lean_uint64_dec_le(v_largest_556_, v___y_591_);
if (v___x_599_ == 0)
{
v_index_551_ = v___x_594_;
v_degree_553_ = v___x_595_;
v_mask_554_ = v___y_593_;
v_hash_555_ = v___x_598_;
v_x_557_ = v_n_579_;
v_x_558_ = v___y_592_;
goto _start;
}
else
{
v_index_551_ = v___x_594_;
v_degree_553_ = v___x_595_;
v_mask_554_ = v___y_593_;
v_hash_555_ = v___x_598_;
v_largest_556_ = v___y_591_;
v_x_557_ = v_n_579_;
v_x_558_ = v___y_592_;
goto _start;
}
}
v___jp_602_:
{
lean_object* v___x_604_; lean_object* v___x_605_; lean_object* v___x_606_; lean_object* v_workspace_607_; uint64_t v___x_608_; uint8_t v___x_609_; 
v___x_604_ = lean_unsigned_to_nat(4u);
v___x_605_ = lean_nat_mul(v_index_551_, v___x_604_);
v___x_606_ = lean_uint64_to_nat(v___y_603_);
v_workspace_607_ = lp_Hex_Hex_Groebner_Native_write(v_x_558_, v___x_604_, v___x_605_, v___x_606_);
v___x_608_ = 0ULL;
v___x_609_ = lean_uint64_dec_eq(v___y_603_, v___x_608_);
if (v___x_609_ == 0)
{
uint64_t v___x_610_; lean_object* v___x_611_; lean_object* v___x_612_; uint64_t v___x_613_; uint64_t v___x_614_; uint64_t v___x_615_; 
v___x_610_ = 1ULL;
v___x_611_ = lean_unsigned_to_nat(64u);
v___x_612_ = lean_nat_mod(v_index_551_, v___x_611_);
v___x_613_ = lean_uint64_of_nat(v___x_612_);
lean_dec(v___x_612_);
v___x_614_ = lean_uint64_shift_left(v___x_610_, v___x_613_);
v___x_615_ = lean_uint64_lor(v_mask_554_, v___x_614_);
v___y_591_ = v___y_603_;
v___y_592_ = v_workspace_607_;
v___y_593_ = v___x_615_;
goto v___jp_590_;
}
else
{
v___y_591_ = v___y_603_;
v___y_592_ = v_workspace_607_;
v___y_593_ = v_mask_554_;
goto v___jp_590_;
}
}
v___jp_617_:
{
uint8_t v___x_618_; 
v___x_618_ = lean_nat_dec_eq(v_operation_546_, v_zero_559_);
if (v___x_618_ == 0)
{
if (v___x_616_ == 0)
{
uint64_t v___x_619_; 
v___x_619_ = lean_uint64_sub(v_x_584_, v_y_589_);
v___y_603_ = v___x_619_;
goto v___jp_602_;
}
else
{
uint64_t v___x_620_; 
v___x_620_ = lean_uint64_add(v_x_584_, v_y_589_);
v___y_603_ = v___x_620_;
goto v___jp_602_;
}
}
else
{
uint8_t v___x_621_; 
v___x_621_ = lean_uint64_dec_le(v_x_584_, v_y_589_);
if (v___x_621_ == 0)
{
v___y_603_ = v_x_584_;
goto v___jp_602_;
}
else
{
v___y_603_ = v_y_589_;
goto v___jp_602_;
}
}
}
v___jp_622_:
{
lean_object* v___x_623_; uint8_t v___x_624_; 
v___x_623_ = lean_unsigned_to_nat(2u);
v___x_624_ = lean_nat_dec_eq(v_operation_546_, v___x_623_);
if (v___x_624_ == 0)
{
goto v___jp_617_;
}
else
{
uint8_t v___x_625_; 
v___x_625_ = lean_uint64_dec_lt(v_x_584_, v_y_589_);
if (v___x_625_ == 0)
{
goto v___jp_617_;
}
else
{
lean_object* v___x_626_; 
lean_dec(v_n_579_);
lean_dec_ref(v_x_558_);
lean_dec(v_index_551_);
v___x_626_ = lean_box(0);
return v___x_626_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_fill___boxed(lean_object* v_operation_631_, lean_object* v_width_632_, lean_object* v_arity_633_, lean_object* v_left_634_, lean_object* v_right_635_, lean_object* v_index_636_, lean_object* v_source_637_, lean_object* v_degree_638_, lean_object* v_mask_639_, lean_object* v_hash_640_, lean_object* v_largest_641_, lean_object* v_x_642_, lean_object* v_x_643_){
_start:
{
uint64_t v_degree_boxed_644_; uint64_t v_mask_boxed_645_; uint64_t v_hash_boxed_646_; uint64_t v_largest_boxed_647_; lean_object* v_res_648_; 
v_degree_boxed_644_ = lean_unbox_uint64(v_degree_638_);
lean_dec_ref(v_degree_638_);
v_mask_boxed_645_ = lean_unbox_uint64(v_mask_639_);
lean_dec_ref(v_mask_639_);
v_hash_boxed_646_ = lean_unbox_uint64(v_hash_640_);
lean_dec_ref(v_hash_640_);
v_largest_boxed_647_ = lean_unbox_uint64(v_largest_641_);
lean_dec_ref(v_largest_641_);
v_res_648_ = lp_Hex_Hex_Groebner_Native_Monomial_fill(v_operation_631_, v_width_632_, v_arity_633_, v_left_634_, v_right_635_, v_index_636_, v_source_637_, v_degree_boxed_644_, v_mask_boxed_645_, v_hash_boxed_646_, v_largest_boxed_647_, v_x_642_, v_x_643_);
lean_dec_ref(v_source_637_);
lean_dec(v_right_635_);
lean_dec(v_left_634_);
lean_dec(v_arity_633_);
lean_dec(v_width_632_);
lean_dec(v_operation_631_);
return v_res_648_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_preparePortable(uint8_t v_operation_649_, uint8_t v_width_650_, uint64_t v_arity_651_, uint64_t v_count_652_, uint64_t v_left_653_, uint64_t v_right_654_, lean_object* v_source_655_, lean_object* v_workspace_656_){
_start:
{
lean_object* v___x_657_; lean_object* v___x_658_; uint8_t v___x_659_; 
v___x_657_ = lean_unsigned_to_nat(2u);
v___x_658_ = lean_uint8_to_nat(v_operation_649_);
v___x_659_ = lean_nat_dec_lt(v___x_657_, v___x_658_);
if (v___x_659_ == 0)
{
lean_object* v_n_660_; lean_object* v_w_661_; lean_object* v___x_691_; uint8_t v___x_692_; 
v_n_660_ = lean_uint64_to_nat(v_arity_651_);
v_w_661_ = lean_uint8_to_nat(v_width_650_);
v___x_691_ = lean_unsigned_to_nat(1u);
v___x_692_ = lean_nat_dec_eq(v_w_661_, v___x_691_);
if (v___x_692_ == 0)
{
uint8_t v___x_693_; 
v___x_693_ = lean_nat_dec_eq(v_w_661_, v___x_657_);
if (v___x_693_ == 0)
{
lean_object* v___x_694_; uint8_t v___x_695_; 
v___x_694_ = lean_unsigned_to_nat(4u);
v___x_695_ = lean_nat_dec_eq(v_w_661_, v___x_694_);
if (v___x_695_ == 0)
{
lean_object* v___x_696_; 
lean_dec(v_n_660_);
lean_dec_ref(v_workspace_656_);
v___x_696_ = lean_box(0);
return v___x_696_;
}
else
{
goto v___jp_662_;
}
}
else
{
goto v___jp_662_;
}
}
else
{
goto v___jp_662_;
}
v___jp_662_:
{
lean_object* v___x_663_; uint8_t v___x_664_; 
v___x_663_ = lean_unsigned_to_nat(0u);
v___x_664_ = lean_nat_dec_eq(v_n_660_, v___x_663_);
if (v___x_664_ == 0)
{
lean_object* v___x_665_; uint8_t v___x_666_; 
v___x_665_ = lean_unsigned_to_nat(4096u);
v___x_666_ = lean_nat_dec_lt(v___x_665_, v_n_660_);
if (v___x_666_ == 0)
{
uint8_t v___x_667_; 
v___x_667_ = lean_uint64_dec_le(v_count_652_, v_left_653_);
if (v___x_667_ == 0)
{
uint8_t v___x_668_; 
v___x_668_ = lean_uint64_dec_le(v_count_652_, v_right_654_);
if (v___x_668_ == 0)
{
lean_object* v___x_669_; lean_object* v___x_670_; lean_object* v___x_671_; lean_object* v___x_672_; uint8_t v___x_673_; 
v___x_669_ = lean_byte_array_size(v_source_655_);
v___x_670_ = lean_uint64_to_nat(v_count_652_);
v___x_671_ = lean_nat_mul(v___x_670_, v_n_660_);
lean_dec(v___x_670_);
v___x_672_ = lean_nat_mul(v___x_671_, v_w_661_);
lean_dec(v___x_671_);
v___x_673_ = lean_nat_dec_eq(v___x_669_, v___x_672_);
lean_dec(v___x_672_);
if (v___x_673_ == 0)
{
lean_object* v___x_674_; 
lean_dec(v_n_660_);
lean_dec_ref(v_workspace_656_);
v___x_674_ = lean_box(0);
return v___x_674_;
}
else
{
lean_object* v___x_675_; lean_object* v___x_676_; lean_object* v___x_677_; lean_object* v___x_678_; lean_object* v___x_679_; uint8_t v___x_680_; 
v___x_675_ = lean_byte_array_size(v_workspace_656_);
v___x_676_ = lean_unsigned_to_nat(4u);
v___x_677_ = lean_nat_mul(v_n_660_, v___x_676_);
v___x_678_ = lean_unsigned_to_nat(28u);
v___x_679_ = lean_nat_add(v___x_677_, v___x_678_);
lean_dec(v___x_677_);
v___x_680_ = lean_nat_dec_eq(v___x_675_, v___x_679_);
lean_dec(v___x_679_);
if (v___x_680_ == 0)
{
lean_object* v___x_681_; 
lean_dec(v_n_660_);
lean_dec_ref(v_workspace_656_);
v___x_681_ = lean_box(0);
return v___x_681_;
}
else
{
lean_object* v___x_682_; lean_object* v___x_683_; uint64_t v___x_684_; uint64_t v___x_685_; lean_object* v___x_686_; 
v___x_682_ = lean_uint64_to_nat(v_left_653_);
v___x_683_ = lean_uint64_to_nat(v_right_654_);
v___x_684_ = 0ULL;
v___x_685_ = 14695981039346656037ULL;
lean_inc(v_n_660_);
v___x_686_ = lp_Hex_Hex_Groebner_Native_Monomial_fill(v___x_658_, v_w_661_, v_n_660_, v___x_682_, v___x_683_, v___x_663_, v_source_655_, v___x_684_, v___x_684_, v___x_685_, v___x_684_, v_n_660_, v_workspace_656_);
lean_dec(v___x_683_);
lean_dec(v___x_682_);
lean_dec(v_n_660_);
return v___x_686_;
}
}
}
else
{
lean_object* v___x_687_; 
lean_dec(v_n_660_);
lean_dec_ref(v_workspace_656_);
v___x_687_ = lean_box(0);
return v___x_687_;
}
}
else
{
lean_object* v___x_688_; 
lean_dec(v_n_660_);
lean_dec_ref(v_workspace_656_);
v___x_688_ = lean_box(0);
return v___x_688_;
}
}
else
{
lean_object* v___x_689_; 
lean_dec(v_n_660_);
lean_dec_ref(v_workspace_656_);
v___x_689_ = lean_box(0);
return v___x_689_;
}
}
else
{
lean_object* v___x_690_; 
lean_dec(v_n_660_);
lean_dec_ref(v_workspace_656_);
v___x_690_ = lean_box(0);
return v___x_690_;
}
}
}
else
{
lean_object* v___x_697_; 
lean_dec_ref(v_workspace_656_);
v___x_697_ = lean_box(0);
return v___x_697_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_preparePortable___boxed(lean_object* v_operation_698_, lean_object* v_width_699_, lean_object* v_arity_700_, lean_object* v_count_701_, lean_object* v_left_702_, lean_object* v_right_703_, lean_object* v_source_704_, lean_object* v_workspace_705_){
_start:
{
uint8_t v_operation_boxed_706_; uint8_t v_width_boxed_707_; uint64_t v_arity_boxed_708_; uint64_t v_count_boxed_709_; uint64_t v_left_boxed_710_; uint64_t v_right_boxed_711_; lean_object* v_res_712_; 
v_operation_boxed_706_ = lean_unbox(v_operation_698_);
v_width_boxed_707_ = lean_unbox(v_width_699_);
v_arity_boxed_708_ = lean_unbox_uint64(v_arity_700_);
lean_dec_ref(v_arity_700_);
v_count_boxed_709_ = lean_unbox_uint64(v_count_701_);
lean_dec_ref(v_count_701_);
v_left_boxed_710_ = lean_unbox_uint64(v_left_702_);
lean_dec_ref(v_left_702_);
v_right_boxed_711_ = lean_unbox_uint64(v_right_703_);
lean_dec_ref(v_right_703_);
v_res_712_ = lp_Hex_Hex_Groebner_Native_Monomial_preparePortable(v_operation_boxed_706_, v_width_boxed_707_, v_arity_boxed_708_, v_count_boxed_709_, v_left_boxed_710_, v_right_boxed_711_, v_source_704_, v_workspace_705_);
lean_dec_ref(v_source_704_);
return v_res_712_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_prepare___boxed(lean_object* v_operation_721_, lean_object* v_width_722_, lean_object* v_arity_723_, lean_object* v_count_724_, lean_object* v_left_725_, lean_object* v_right_726_, lean_object* v_source_727_, lean_object* v_workspace_728_){
_start:
{
uint8_t v_operation_boxed_729_; uint8_t v_width_boxed_730_; uint64_t v_arity_boxed_731_; uint64_t v_count_boxed_732_; uint64_t v_left_boxed_733_; uint64_t v_right_boxed_734_; lean_object* v_res_735_; 
v_operation_boxed_729_ = lean_unbox(v_operation_721_);
v_width_boxed_730_ = lean_unbox(v_width_722_);
v_arity_boxed_731_ = lean_unbox_uint64(v_arity_723_);
lean_dec_ref(v_arity_723_);
v_count_boxed_732_ = lean_unbox_uint64(v_count_724_);
lean_dec_ref(v_count_724_);
v_left_boxed_733_ = lean_unbox_uint64(v_left_725_);
lean_dec_ref(v_left_725_);
v_right_boxed_734_ = lean_unbox_uint64(v_right_726_);
lean_dec_ref(v_right_726_);
v_res_735_ = lean_hex_groebner_prepare_monomial(v_operation_boxed_729_, v_width_boxed_730_, v_arity_boxed_731_, v_count_boxed_732_, v_left_boxed_733_, v_right_boxed_734_, v_source_727_, v_workspace_728_);
lean_dec_ref(v_source_727_);
return v_res_735_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Native_Monomial_equalAux(lean_object* v_width_736_, lean_object* v_arity_737_, lean_object* v_id_738_, lean_object* v_index_739_, lean_object* v_source_740_, lean_object* v_candidate_741_, lean_object* v_x_742_){
_start:
{
lean_object* v_zero_743_; uint8_t v_isZero_744_; 
v_zero_743_ = lean_unsigned_to_nat(0u);
v_isZero_744_ = lean_nat_dec_eq(v_x_742_, v_zero_743_);
if (v_isZero_744_ == 1)
{
lean_dec(v_x_742_);
lean_dec(v_index_739_);
return v_isZero_744_;
}
else
{
lean_object* v___x_745_; lean_object* v___x_746_; lean_object* v___x_747_; lean_object* v___x_748_; lean_object* v___x_749_; lean_object* v___x_750_; lean_object* v___x_751_; uint8_t v___x_752_; 
v___x_745_ = lean_nat_mul(v_id_738_, v_arity_737_);
v___x_746_ = lean_nat_add(v___x_745_, v_index_739_);
lean_dec(v___x_745_);
v___x_747_ = lean_nat_mul(v___x_746_, v_width_736_);
lean_dec(v___x_746_);
v___x_748_ = lp_Hex_Hex_Groebner_Native_read(v_source_740_, v_width_736_, v___x_747_);
lean_dec(v___x_747_);
v___x_749_ = lean_unsigned_to_nat(4u);
v___x_750_ = lean_nat_mul(v_index_739_, v___x_749_);
v___x_751_ = lp_Hex_Hex_Groebner_Native_read(v_candidate_741_, v___x_749_, v___x_750_);
lean_dec(v___x_750_);
v___x_752_ = lean_nat_dec_eq(v___x_748_, v___x_751_);
lean_dec(v___x_751_);
lean_dec(v___x_748_);
if (v___x_752_ == 0)
{
lean_dec(v_x_742_);
lean_dec(v_index_739_);
return v___x_752_;
}
else
{
lean_object* v_one_753_; lean_object* v_n_754_; lean_object* v___x_755_; 
v_one_753_ = lean_unsigned_to_nat(1u);
v_n_754_ = lean_nat_sub(v_x_742_, v_one_753_);
lean_dec(v_x_742_);
v___x_755_ = lean_nat_add(v_index_739_, v_one_753_);
lean_dec(v_index_739_);
v_index_739_ = v___x_755_;
v_x_742_ = v_n_754_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_equalAux___boxed(lean_object* v_width_757_, lean_object* v_arity_758_, lean_object* v_id_759_, lean_object* v_index_760_, lean_object* v_source_761_, lean_object* v_candidate_762_, lean_object* v_x_763_){
_start:
{
uint8_t v_res_764_; lean_object* v_r_765_; 
v_res_764_ = lp_Hex_Hex_Groebner_Native_Monomial_equalAux(v_width_757_, v_arity_758_, v_id_759_, v_index_760_, v_source_761_, v_candidate_762_, v_x_763_);
lean_dec_ref(v_candidate_762_);
lean_dec_ref(v_source_761_);
lean_dec(v_id_759_);
lean_dec(v_arity_758_);
lean_dec(v_width_757_);
v_r_765_ = lean_box(v_res_764_);
return v_r_765_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Native_Monomial_equalPortable(uint8_t v_width_766_, uint64_t v_arity_767_, uint64_t v_id_768_, lean_object* v_source_769_, lean_object* v_candidate_770_){
_start:
{
lean_object* v_n_771_; lean_object* v_w_772_; uint8_t v___y_774_; lean_object* v___x_793_; uint8_t v___x_794_; 
v_n_771_ = lean_uint64_to_nat(v_arity_767_);
v_w_772_ = lean_uint8_to_nat(v_width_766_);
v___x_793_ = lean_unsigned_to_nat(1u);
v___x_794_ = lean_nat_dec_eq(v_w_772_, v___x_793_);
if (v___x_794_ == 0)
{
lean_object* v___x_795_; uint8_t v___x_796_; 
v___x_795_ = lean_unsigned_to_nat(2u);
v___x_796_ = lean_nat_dec_eq(v_w_772_, v___x_795_);
if (v___x_796_ == 0)
{
lean_object* v___x_797_; uint8_t v___x_798_; 
v___x_797_ = lean_unsigned_to_nat(4u);
v___x_798_ = lean_nat_dec_eq(v_w_772_, v___x_797_);
if (v___x_798_ == 0)
{
lean_dec(v_n_771_);
return v___x_798_;
}
else
{
v___y_774_ = v___x_796_;
goto v___jp_773_;
}
}
else
{
v___y_774_ = v___x_794_;
goto v___jp_773_;
}
}
else
{
uint8_t v___x_799_; 
v___x_799_ = 0;
v___y_774_ = v___x_799_;
goto v___jp_773_;
}
v___jp_773_:
{
lean_object* v___x_775_; uint8_t v___x_776_; 
v___x_775_ = lean_unsigned_to_nat(0u);
v___x_776_ = lean_nat_dec_eq(v_n_771_, v___x_775_);
if (v___x_776_ == 0)
{
lean_object* v___x_777_; uint8_t v___x_778_; 
v___x_777_ = lean_unsigned_to_nat(4096u);
v___x_778_ = lean_nat_dec_lt(v___x_777_, v_n_771_);
if (v___x_778_ == 0)
{
lean_object* v___x_779_; lean_object* v___x_780_; lean_object* v___x_781_; uint8_t v___x_782_; 
v___x_779_ = lean_byte_array_size(v_source_769_);
v___x_780_ = lean_nat_mul(v_n_771_, v_w_772_);
v___x_781_ = lean_nat_mod(v___x_779_, v___x_780_);
v___x_782_ = lean_nat_dec_eq(v___x_781_, v___x_775_);
lean_dec(v___x_781_);
if (v___x_782_ == 0)
{
lean_dec(v___x_780_);
lean_dec(v_n_771_);
return v___x_782_;
}
else
{
lean_object* v___x_783_; lean_object* v___x_784_; uint8_t v___x_785_; 
v___x_783_ = lean_nat_div(v___x_779_, v___x_780_);
lean_dec(v___x_780_);
v___x_784_ = lean_uint64_to_nat(v_id_768_);
v___x_785_ = lean_nat_dec_le(v___x_783_, v___x_784_);
lean_dec(v___x_783_);
if (v___x_785_ == 0)
{
lean_object* v___x_786_; lean_object* v___x_787_; lean_object* v___x_788_; lean_object* v___x_789_; lean_object* v___x_790_; uint8_t v___x_791_; 
v___x_786_ = lean_byte_array_size(v_candidate_770_);
v___x_787_ = lean_unsigned_to_nat(4u);
v___x_788_ = lean_nat_mul(v_n_771_, v___x_787_);
v___x_789_ = lean_unsigned_to_nat(28u);
v___x_790_ = lean_nat_add(v___x_788_, v___x_789_);
lean_dec(v___x_788_);
v___x_791_ = lean_nat_dec_eq(v___x_786_, v___x_790_);
lean_dec(v___x_790_);
if (v___x_791_ == 0)
{
lean_dec(v___x_784_);
lean_dec(v_n_771_);
return v___x_785_;
}
else
{
uint8_t v___x_792_; 
lean_inc(v_n_771_);
v___x_792_ = lp_Hex_Hex_Groebner_Native_Monomial_equalAux(v_w_772_, v_n_771_, v___x_784_, v___x_775_, v_source_769_, v_candidate_770_, v_n_771_);
lean_dec(v___x_784_);
lean_dec(v_n_771_);
return v___x_792_;
}
}
else
{
lean_dec(v___x_784_);
lean_dec(v_n_771_);
return v___x_778_;
}
}
}
else
{
lean_dec(v_n_771_);
return v___x_776_;
}
}
else
{
lean_dec(v_n_771_);
return v___y_774_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_equalPortable___boxed(lean_object* v_width_800_, lean_object* v_arity_801_, lean_object* v_id_802_, lean_object* v_source_803_, lean_object* v_candidate_804_){
_start:
{
uint8_t v_width_boxed_805_; uint64_t v_arity_boxed_806_; uint64_t v_id_boxed_807_; uint8_t v_res_808_; lean_object* v_r_809_; 
v_width_boxed_805_ = lean_unbox(v_width_800_);
v_arity_boxed_806_ = lean_unbox_uint64(v_arity_801_);
lean_dec_ref(v_arity_801_);
v_id_boxed_807_ = lean_unbox_uint64(v_id_802_);
lean_dec_ref(v_id_802_);
v_res_808_ = lp_Hex_Hex_Groebner_Native_Monomial_equalPortable(v_width_boxed_805_, v_arity_boxed_806_, v_id_boxed_807_, v_source_803_, v_candidate_804_);
lean_dec_ref(v_candidate_804_);
lean_dec_ref(v_source_803_);
v_r_809_ = lean_box(v_res_808_);
return v_r_809_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Native_Monomial_equal___boxed(lean_object* v_width_815_, lean_object* v_arity_816_, lean_object* v_id_817_, lean_object* v_source_818_, lean_object* v_candidate_819_){
_start:
{
uint8_t v_width_boxed_820_; uint64_t v_arity_boxed_821_; uint64_t v_id_boxed_822_; uint8_t v_res_823_; lean_object* v_r_824_; 
v_width_boxed_820_ = lean_unbox(v_width_815_);
v_arity_boxed_821_ = lean_unbox_uint64(v_arity_816_);
lean_dec_ref(v_arity_816_);
v_id_boxed_822_ = lean_unbox_uint64(v_id_817_);
lean_dec_ref(v_id_817_);
v_res_823_ = lean_hex_groebner_equal_monomial(v_width_boxed_820_, v_arity_boxed_821_, v_id_boxed_822_, v_source_818_, v_candidate_819_);
lean_dec_ref(v_candidate_819_);
lean_dec_ref(v_source_818_);
v_r_824_ = lean_box(v_res_823_);
return v_r_824_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_Native(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_Native(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_Native(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Native(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_Native(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_Native(builtin);
}
#ifdef __cplusplus
}
#endif
