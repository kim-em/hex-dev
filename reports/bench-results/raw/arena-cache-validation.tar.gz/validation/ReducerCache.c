// Lean compiler output
// Module: HexGroebner.ReducerCache
// Imports: public import Init public meta import Init public import HexGroebner.Polynomial
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_mk_array(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
lean_object* lean_byte_array_size(lean_object*);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_byte_array_uget(lean_object*, size_t);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_usize_to_nat(size_t);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint64_t lean_uint64_add(uint64_t, uint64_t);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* lean_array_get_size(lean_object*);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
size_t lean_uint64_to_usize(uint64_t);
size_t lean_usize_sub(size_t, size_t);
size_t lean_usize_land(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* lean_array_fset(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
lean_object* lean_array_propagate_mark(lean_object*, lean_object*);
uint8_t lean_hex_groebner_equal_bytes(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
uint8_t lean_uint8_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
uint8_t lp_Hex_Hex_Groebner_Native_Monomial_productsPortable(uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*);
uint8_t lean_hex_groebner_equal_products(uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*);
uint8_t lp_Hex_Hex_Groebner_instDecidableEqContext_decEq(lean_object*, lean_object*);
uint64_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Computation_allocate(lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Polynomial_multiply___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Groebner_ReducerCache_empty___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_ReducerCache_empty___closed__0;
static lean_once_cell_t lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1;
static lean_once_cell_t lp_Hex_Hex_Groebner_ReducerCache_empty___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_ReducerCache_empty___closed__2;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerCache_empty;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerCache_instInhabited;
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_bind(lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes___closed__0 = (const lean_object*)&lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0___boxed(lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___redArg(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1___redArg(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5___redArg(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2___redArg(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2_spec__5___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___redArg(uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0___redArg(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 3}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerCache_multiply(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0(lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1(lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2(lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2(lean_object*, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2_spec__5(lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_Hex_Hex_Groebner_ReducerCache_empty___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; lean_object* v___x_3_; 
v___x_1_ = lean_box(0);
v___x_2_ = lean_unsigned_to_nat(16u);
v___x_3_ = lean_mk_array(v___x_2_, v___x_1_);
return v___x_3_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1(void){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_4_ = lean_obj_once(&lp_Hex_Hex_Groebner_ReducerCache_empty___closed__0, &lp_Hex_Hex_Groebner_ReducerCache_empty___closed__0_once, _init_lp_Hex_Hex_Groebner_ReducerCache_empty___closed__0);
v___x_5_ = lean_unsigned_to_nat(0u);
v___x_6_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6_, 0, v___x_5_);
lean_ctor_set(v___x_6_, 1, v___x_4_);
return v___x_6_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_ReducerCache_empty___closed__2(void){
_start:
{
lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; 
v___x_7_ = lean_obj_once(&lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1, &lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1_once, _init_lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1);
v___x_8_ = lean_box(0);
v___x_9_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_9_, 0, v___x_8_);
lean_ctor_set(v___x_9_, 1, v___x_7_);
return v___x_9_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_ReducerCache_empty(void){
_start:
{
lean_object* v___x_10_; 
v___x_10_ = lean_obj_once(&lp_Hex_Hex_Groebner_ReducerCache_empty___closed__2, &lp_Hex_Hex_Groebner_ReducerCache_empty___closed__2_once, _init_lp_Hex_Hex_Groebner_ReducerCache_empty___closed__2);
return v___x_10_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_ReducerCache_instInhabited(void){
_start:
{
lean_object* v___x_11_; 
v___x_11_ = lp_Hex_Hex_Groebner_ReducerCache_empty;
return v___x_11_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_bind(lean_object* v_cache_12_, lean_object* v_context_13_){
_start:
{
lean_object* v_context_14_; 
v_context_14_ = lean_ctor_get(v_cache_12_, 0);
lean_inc(v_context_14_);
if (lean_obj_tag(v_context_14_) == 0)
{
lean_object* v___x_16_; uint8_t v_isShared_17_; uint8_t v_isSharedCheck_23_; 
v_isSharedCheck_23_ = !lean_is_exclusive(v_cache_12_);
if (v_isSharedCheck_23_ == 0)
{
lean_object* v_unused_24_; lean_object* v_unused_25_; 
v_unused_24_ = lean_ctor_get(v_cache_12_, 1);
lean_dec(v_unused_24_);
v_unused_25_ = lean_ctor_get(v_cache_12_, 0);
lean_dec(v_unused_25_);
v___x_16_ = v_cache_12_;
v_isShared_17_ = v_isSharedCheck_23_;
goto v_resetjp_15_;
}
else
{
lean_dec(v_cache_12_);
v___x_16_ = lean_box(0);
v_isShared_17_ = v_isSharedCheck_23_;
goto v_resetjp_15_;
}
v_resetjp_15_:
{
lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_21_; 
v___x_18_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_18_, 0, v_context_13_);
v___x_19_ = lean_obj_once(&lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1, &lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1_once, _init_lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1);
if (v_isShared_17_ == 0)
{
lean_ctor_set(v___x_16_, 1, v___x_19_);
lean_ctor_set(v___x_16_, 0, v___x_18_);
v___x_21_ = v___x_16_;
goto v_reusejp_20_;
}
else
{
lean_object* v_reuseFailAlloc_22_; 
v_reuseFailAlloc_22_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_22_, 0, v___x_18_);
lean_ctor_set(v_reuseFailAlloc_22_, 1, v___x_19_);
v___x_21_ = v_reuseFailAlloc_22_;
goto v_reusejp_20_;
}
v_reusejp_20_:
{
return v___x_21_;
}
}
}
else
{
lean_object* v_val_26_; lean_object* v___x_28_; uint8_t v_isShared_29_; uint8_t v_isSharedCheck_44_; 
v_val_26_ = lean_ctor_get(v_context_14_, 0);
v_isSharedCheck_44_ = !lean_is_exclusive(v_context_14_);
if (v_isSharedCheck_44_ == 0)
{
v___x_28_ = v_context_14_;
v_isShared_29_ = v_isSharedCheck_44_;
goto v_resetjp_27_;
}
else
{
lean_inc(v_val_26_);
lean_dec(v_context_14_);
v___x_28_ = lean_box(0);
v_isShared_29_ = v_isSharedCheck_44_;
goto v_resetjp_27_;
}
v_resetjp_27_:
{
uint8_t v___x_30_; 
v___x_30_ = lp_Hex_Hex_Groebner_instDecidableEqContext_decEq(v_val_26_, v_context_13_);
lean_dec(v_val_26_);
if (v___x_30_ == 0)
{
lean_object* v___x_32_; uint8_t v_isShared_33_; uint8_t v_isSharedCheck_41_; 
v_isSharedCheck_41_ = !lean_is_exclusive(v_cache_12_);
if (v_isSharedCheck_41_ == 0)
{
lean_object* v_unused_42_; lean_object* v_unused_43_; 
v_unused_42_ = lean_ctor_get(v_cache_12_, 1);
lean_dec(v_unused_42_);
v_unused_43_ = lean_ctor_get(v_cache_12_, 0);
lean_dec(v_unused_43_);
v___x_32_ = v_cache_12_;
v_isShared_33_ = v_isSharedCheck_41_;
goto v_resetjp_31_;
}
else
{
lean_dec(v_cache_12_);
v___x_32_ = lean_box(0);
v_isShared_33_ = v_isSharedCheck_41_;
goto v_resetjp_31_;
}
v_resetjp_31_:
{
lean_object* v___x_35_; 
if (v_isShared_29_ == 0)
{
lean_ctor_set(v___x_28_, 0, v_context_13_);
v___x_35_ = v___x_28_;
goto v_reusejp_34_;
}
else
{
lean_object* v_reuseFailAlloc_40_; 
v_reuseFailAlloc_40_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_40_, 0, v_context_13_);
v___x_35_ = v_reuseFailAlloc_40_;
goto v_reusejp_34_;
}
v_reusejp_34_:
{
lean_object* v___x_36_; lean_object* v___x_38_; 
v___x_36_ = lean_obj_once(&lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1, &lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1_once, _init_lp_Hex_Hex_Groebner_ReducerCache_empty___closed__1);
if (v_isShared_33_ == 0)
{
lean_ctor_set(v___x_32_, 1, v___x_36_);
lean_ctor_set(v___x_32_, 0, v___x_35_);
v___x_38_ = v___x_32_;
goto v_reusejp_37_;
}
else
{
lean_object* v_reuseFailAlloc_39_; 
v_reuseFailAlloc_39_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_39_, 0, v___x_35_);
lean_ctor_set(v_reuseFailAlloc_39_, 1, v___x_36_);
v___x_38_ = v_reuseFailAlloc_39_;
goto v_reusejp_37_;
}
v_reusejp_37_:
{
return v___x_38_;
}
}
}
}
else
{
lean_del_object(v___x_28_);
lean_dec_ref(v_context_13_);
return v_cache_12_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg(lean_object* v_left_48_, lean_object* v_right_49_, lean_object* v___x_50_, lean_object* v_range_51_, lean_object* v_b_52_, lean_object* v_i_53_){
_start:
{
lean_object* v_stop_54_; lean_object* v_step_55_; uint8_t v___x_56_; 
v_stop_54_ = lean_ctor_get(v_range_51_, 1);
v_step_55_ = lean_ctor_get(v_range_51_, 2);
v___x_56_ = lean_nat_dec_lt(v_i_53_, v_stop_54_);
if (v___x_56_ == 0)
{
lean_dec(v_i_53_);
return v_b_52_;
}
else
{
lean_object* v_snd_57_; lean_object* v___x_59_; uint8_t v_isShared_60_; uint8_t v_isSharedCheck_78_; 
v_snd_57_ = lean_ctor_get(v_b_52_, 1);
v_isSharedCheck_78_ = !lean_is_exclusive(v_b_52_);
if (v_isSharedCheck_78_ == 0)
{
lean_object* v_unused_79_; 
v_unused_79_ = lean_ctor_get(v_b_52_, 0);
lean_dec(v_unused_79_);
v___x_59_ = v_b_52_;
v_isShared_60_ = v_isSharedCheck_78_;
goto v_resetjp_58_;
}
else
{
lean_inc(v_snd_57_);
lean_dec(v_b_52_);
v___x_59_ = lean_box(0);
v_isShared_60_ = v_isSharedCheck_78_;
goto v_resetjp_58_;
}
v_resetjp_58_:
{
lean_object* v___x_61_; lean_object* v___y_63_; lean_object* v___x_75_; lean_object* v___x_76_; uint8_t v___x_77_; 
v___x_61_ = lean_box(0);
v___x_75_ = lean_unsigned_to_nat(4096u);
v___x_76_ = lean_nat_sub(v___x_50_, v_snd_57_);
v___x_77_ = lean_nat_dec_le(v___x_75_, v___x_76_);
if (v___x_77_ == 0)
{
v___y_63_ = v___x_76_;
goto v___jp_62_;
}
else
{
lean_dec(v___x_76_);
v___y_63_ = v___x_75_;
goto v___jp_62_;
}
v___jp_62_:
{
uint8_t v___x_64_; 
v___x_64_ = lean_hex_groebner_equal_bytes(v_left_48_, v_right_49_, v_snd_57_, v___y_63_);
if (v___x_64_ == 0)
{
lean_object* v___x_65_; lean_object* v___x_67_; 
lean_dec(v___y_63_);
lean_dec(v_i_53_);
v___x_65_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg___closed__0));
if (v_isShared_60_ == 0)
{
lean_ctor_set(v___x_59_, 0, v___x_65_);
v___x_67_ = v___x_59_;
goto v_reusejp_66_;
}
else
{
lean_object* v_reuseFailAlloc_68_; 
v_reuseFailAlloc_68_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_68_, 0, v___x_65_);
lean_ctor_set(v_reuseFailAlloc_68_, 1, v_snd_57_);
v___x_67_ = v_reuseFailAlloc_68_;
goto v_reusejp_66_;
}
v_reusejp_66_:
{
return v___x_67_;
}
}
else
{
lean_object* v___x_69_; lean_object* v___x_71_; 
v___x_69_ = lean_nat_add(v_snd_57_, v___y_63_);
lean_dec(v___y_63_);
lean_dec(v_snd_57_);
if (v_isShared_60_ == 0)
{
lean_ctor_set(v___x_59_, 1, v___x_69_);
lean_ctor_set(v___x_59_, 0, v___x_61_);
v___x_71_ = v___x_59_;
goto v_reusejp_70_;
}
else
{
lean_object* v_reuseFailAlloc_74_; 
v_reuseFailAlloc_74_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_74_, 0, v___x_61_);
lean_ctor_set(v_reuseFailAlloc_74_, 1, v___x_69_);
v___x_71_ = v_reuseFailAlloc_74_;
goto v_reusejp_70_;
}
v_reusejp_70_:
{
lean_object* v___x_72_; 
v___x_72_ = lean_nat_add(v_i_53_, v_step_55_);
lean_dec(v_i_53_);
v_b_52_ = v___x_71_;
v_i_53_ = v___x_72_;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg___boxed(lean_object* v_left_80_, lean_object* v_right_81_, lean_object* v___x_82_, lean_object* v_range_83_, lean_object* v_b_84_, lean_object* v_i_85_){
_start:
{
lean_object* v_res_86_; 
v_res_86_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg(v_left_80_, v_right_81_, v___x_82_, v_range_83_, v_b_84_, v_i_85_);
lean_dec_ref(v_range_83_);
lean_dec(v___x_82_);
lean_dec_ref(v_right_81_);
lean_dec_ref(v_left_80_);
return v_res_86_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes(lean_object* v_left_90_, lean_object* v_right_91_){
_start:
{
lean_object* v___x_92_; lean_object* v___x_93_; uint8_t v___x_94_; 
v___x_92_ = lean_byte_array_size(v_left_90_);
v___x_93_ = lean_byte_array_size(v_right_91_);
v___x_94_ = lean_nat_dec_eq(v___x_92_, v___x_93_);
if (v___x_94_ == 0)
{
return v___x_94_;
}
else
{
lean_object* v_start_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___x_98_; lean_object* v___x_99_; lean_object* v___x_100_; lean_object* v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; lean_object* v_fst_104_; 
v_start_95_ = lean_unsigned_to_nat(0u);
v___x_96_ = lean_unsigned_to_nat(4095u);
v___x_97_ = lean_nat_add(v___x_92_, v___x_96_);
v___x_98_ = lean_unsigned_to_nat(12u);
v___x_99_ = lean_nat_shiftr(v___x_97_, v___x_98_);
lean_dec(v___x_97_);
v___x_100_ = lean_unsigned_to_nat(1u);
v___x_101_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_101_, 0, v_start_95_);
lean_ctor_set(v___x_101_, 1, v___x_99_);
lean_ctor_set(v___x_101_, 2, v___x_100_);
v___x_102_ = ((lean_object*)(lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes___closed__0));
v___x_103_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg(v_left_90_, v_right_91_, v___x_92_, v___x_101_, v___x_102_, v_start_95_);
lean_dec_ref_known(v___x_101_, 3);
v_fst_104_ = lean_ctor_get(v___x_103_, 0);
lean_inc(v_fst_104_);
lean_dec_ref(v___x_103_);
if (lean_obj_tag(v_fst_104_) == 0)
{
return v___x_94_;
}
else
{
lean_object* v_val_105_; uint8_t v___x_106_; 
v_val_105_ = lean_ctor_get(v_fst_104_, 0);
lean_inc(v_val_105_);
lean_dec_ref_known(v_fst_104_, 1);
v___x_106_ = lean_unbox(v_val_105_);
lean_dec(v_val_105_);
return v___x_106_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes___boxed(lean_object* v_left_107_, lean_object* v_right_108_){
_start:
{
uint8_t v_res_109_; lean_object* v_r_110_; 
v_res_109_ = lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes(v_left_107_, v_right_108_);
lean_dec_ref(v_right_108_);
lean_dec_ref(v_left_107_);
v_r_110_ = lean_box(v_res_109_);
return v_r_110_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0(lean_object* v_left_111_, lean_object* v_right_112_, lean_object* v___x_113_, lean_object* v_range_114_, lean_object* v_b_115_, lean_object* v_i_116_, lean_object* v_hs_117_, lean_object* v_hl_118_){
_start:
{
lean_object* v___x_119_; 
v___x_119_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___redArg(v_left_111_, v_right_112_, v___x_113_, v_range_114_, v_b_115_, v_i_116_);
return v___x_119_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0___boxed(lean_object* v_left_120_, lean_object* v_right_121_, lean_object* v___x_122_, lean_object* v_range_123_, lean_object* v_b_124_, lean_object* v_i_125_, lean_object* v_hs_126_, lean_object* v_hl_127_){
_start:
{
lean_object* v_res_128_; 
v_res_128_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes_spec__0(v_left_120_, v_right_121_, v___x_122_, v_range_123_, v_b_124_, v_i_125_, v_hs_126_, v_hl_127_);
lean_dec_ref(v_range_123_);
lean_dec(v___x_122_);
lean_dec_ref(v_right_121_);
lean_dec_ref(v_left_120_);
return v_res_128_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2___redArg(lean_object* v___x_129_, lean_object* v___x_130_, lean_object* v_table_131_, lean_object* v_multiplier_132_, lean_object* v_base_133_, lean_object* v_product_134_, uint8_t v_native_135_, lean_object* v___x_136_, lean_object* v_quantum_137_, lean_object* v_range_138_, lean_object* v_b_139_, lean_object* v_i_140_){
_start:
{
lean_object* v_stop_141_; lean_object* v_step_142_; uint8_t v___x_143_; 
v_stop_141_ = lean_ctor_get(v_range_138_, 1);
v_step_142_ = lean_ctor_get(v_range_138_, 2);
v___x_143_ = lean_nat_dec_lt(v_i_140_, v_stop_141_);
if (v___x_143_ == 0)
{
lean_dec(v_i_140_);
lean_dec(v_quantum_137_);
return v_b_139_;
}
else
{
lean_object* v_snd_144_; lean_object* v___x_146_; uint8_t v_isShared_147_; uint8_t v_isSharedCheck_205_; 
v_snd_144_ = lean_ctor_get(v_b_139_, 1);
v_isSharedCheck_205_ = !lean_is_exclusive(v_b_139_);
if (v_isSharedCheck_205_ == 0)
{
lean_object* v_unused_206_; 
v_unused_206_ = lean_ctor_get(v_b_139_, 0);
lean_dec(v_unused_206_);
v___x_146_ = v_b_139_;
v_isShared_147_ = v_isSharedCheck_205_;
goto v_resetjp_145_;
}
else
{
lean_inc(v_snd_144_);
lean_dec(v_b_139_);
v___x_146_ = lean_box(0);
v_isShared_147_ = v_isSharedCheck_205_;
goto v_resetjp_145_;
}
v_resetjp_145_:
{
lean_object* v___x_148_; uint8_t v___x_149_; lean_object* v___x_150_; lean_object* v___y_152_; uint8_t v___y_153_; lean_object* v___y_166_; lean_object* v___y_167_; lean_object* v___y_180_; lean_object* v___y_181_; lean_object* v___y_194_; lean_object* v___x_203_; uint8_t v___x_204_; 
v___x_148_ = lean_unsigned_to_nat(4294967295u);
v___x_149_ = lean_nat_dec_lt(v___x_148_, v___x_129_);
v___x_150_ = lean_box(0);
v___x_203_ = lean_nat_sub(v___x_136_, v_snd_144_);
v___x_204_ = lean_nat_dec_le(v_quantum_137_, v___x_203_);
if (v___x_204_ == 0)
{
v___y_194_ = v___x_203_;
goto v___jp_193_;
}
else
{
lean_dec(v___x_203_);
lean_inc(v_quantum_137_);
v___y_194_ = v_quantum_137_;
goto v___jp_193_;
}
v___jp_151_:
{
if (v___y_153_ == 0)
{
lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_157_; 
lean_dec(v___y_152_);
lean_dec(v_i_140_);
lean_dec(v_quantum_137_);
v___x_154_ = lean_box(v___x_149_);
v___x_155_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_155_, 0, v___x_154_);
if (v_isShared_147_ == 0)
{
lean_ctor_set(v___x_146_, 0, v___x_155_);
v___x_157_ = v___x_146_;
goto v_reusejp_156_;
}
else
{
lean_object* v_reuseFailAlloc_158_; 
v_reuseFailAlloc_158_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_158_, 0, v___x_155_);
lean_ctor_set(v_reuseFailAlloc_158_, 1, v_snd_144_);
v___x_157_ = v_reuseFailAlloc_158_;
goto v_reusejp_156_;
}
v_reusejp_156_:
{
return v___x_157_;
}
}
else
{
lean_object* v___x_159_; lean_object* v___x_161_; 
v___x_159_ = lean_nat_add(v_snd_144_, v___y_152_);
lean_dec(v___y_152_);
lean_dec(v_snd_144_);
if (v_isShared_147_ == 0)
{
lean_ctor_set(v___x_146_, 1, v___x_159_);
lean_ctor_set(v___x_146_, 0, v___x_150_);
v___x_161_ = v___x_146_;
goto v_reusejp_160_;
}
else
{
lean_object* v_reuseFailAlloc_164_; 
v_reuseFailAlloc_164_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_164_, 0, v___x_150_);
lean_ctor_set(v_reuseFailAlloc_164_, 1, v___x_159_);
v___x_161_ = v_reuseFailAlloc_164_;
goto v_reusejp_160_;
}
v_reusejp_160_:
{
lean_object* v___x_162_; 
v___x_162_ = lean_nat_add(v_i_140_, v_step_142_);
lean_dec(v_i_140_);
v_b_139_ = v___x_161_;
v_i_140_ = v___x_162_;
goto _start;
}
}
}
v___jp_165_:
{
lean_object* v_exponents_168_; lean_object* v_count_169_; lean_object* v_support_170_; lean_object* v_support_171_; uint8_t v___x_172_; uint64_t v___x_173_; uint64_t v___x_174_; uint64_t v___x_175_; uint64_t v___x_176_; uint64_t v___x_177_; uint8_t v___x_178_; 
v_exponents_168_ = lean_ctor_get(v_table_131_, 1);
v_count_169_ = lean_ctor_get(v_table_131_, 3);
v_support_170_ = lean_ctor_get(v_base_133_, 0);
v_support_171_ = lean_ctor_get(v_product_134_, 0);
v___x_172_ = lean_uint8_of_nat(v___y_167_);
v___x_173_ = lean_uint64_of_nat(v___x_130_);
v___x_174_ = lean_uint64_of_nat(v_count_169_);
v___x_175_ = lean_uint64_of_nat(v_multiplier_132_);
v___x_176_ = lean_uint64_of_nat(v_snd_144_);
v___x_177_ = lean_uint64_of_nat(v___y_166_);
v___x_178_ = lp_Hex_Hex_Groebner_Native_Monomial_productsPortable(v___x_172_, v___x_173_, v___x_174_, v___x_175_, v___x_176_, v___x_177_, v_exponents_168_, v_support_170_, v_support_171_);
v___y_152_ = v___y_166_;
v___y_153_ = v___x_178_;
goto v___jp_151_;
}
v___jp_179_:
{
lean_object* v_exponents_182_; lean_object* v_count_183_; lean_object* v_support_184_; lean_object* v_support_185_; uint8_t v___x_186_; uint64_t v___x_187_; uint64_t v___x_188_; uint64_t v___x_189_; uint64_t v___x_190_; uint64_t v___x_191_; uint8_t v___x_192_; 
v_exponents_182_ = lean_ctor_get(v_table_131_, 1);
v_count_183_ = lean_ctor_get(v_table_131_, 3);
v_support_184_ = lean_ctor_get(v_base_133_, 0);
v_support_185_ = lean_ctor_get(v_product_134_, 0);
v___x_186_ = lean_uint8_of_nat(v___y_181_);
v___x_187_ = lean_uint64_of_nat(v___x_130_);
v___x_188_ = lean_uint64_of_nat(v_count_183_);
v___x_189_ = lean_uint64_of_nat(v_multiplier_132_);
v___x_190_ = lean_uint64_of_nat(v_snd_144_);
v___x_191_ = lean_uint64_of_nat(v___y_180_);
v___x_192_ = lean_hex_groebner_equal_products(v___x_186_, v___x_187_, v___x_188_, v___x_189_, v___x_190_, v___x_191_, v_exponents_182_, v_support_184_, v_support_185_);
v___y_152_ = v___y_180_;
v___y_153_ = v___x_192_;
goto v___jp_151_;
}
v___jp_193_:
{
if (v_native_135_ == 0)
{
uint8_t v_width_195_; 
v_width_195_ = lean_ctor_get_uint8(v_table_131_, sizeof(void*)*8);
switch(v_width_195_)
{
case 0:
{
lean_object* v___x_196_; 
v___x_196_ = lean_unsigned_to_nat(1u);
v___y_166_ = v___y_194_;
v___y_167_ = v___x_196_;
goto v___jp_165_;
}
case 1:
{
lean_object* v___x_197_; 
v___x_197_ = lean_unsigned_to_nat(2u);
v___y_166_ = v___y_194_;
v___y_167_ = v___x_197_;
goto v___jp_165_;
}
default: 
{
lean_object* v___x_198_; 
v___x_198_ = lean_unsigned_to_nat(4u);
v___y_166_ = v___y_194_;
v___y_167_ = v___x_198_;
goto v___jp_165_;
}
}
}
else
{
uint8_t v_width_199_; 
v_width_199_ = lean_ctor_get_uint8(v_table_131_, sizeof(void*)*8);
switch(v_width_199_)
{
case 0:
{
lean_object* v___x_200_; 
v___x_200_ = lean_unsigned_to_nat(1u);
v___y_180_ = v___y_194_;
v___y_181_ = v___x_200_;
goto v___jp_179_;
}
case 1:
{
lean_object* v___x_201_; 
v___x_201_ = lean_unsigned_to_nat(2u);
v___y_180_ = v___y_194_;
v___y_181_ = v___x_201_;
goto v___jp_179_;
}
default: 
{
lean_object* v___x_202_; 
v___x_202_ = lean_unsigned_to_nat(4u);
v___y_180_ = v___y_194_;
v___y_181_ = v___x_202_;
goto v___jp_179_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2___redArg___boxed(lean_object* v___x_207_, lean_object* v___x_208_, lean_object* v_table_209_, lean_object* v_multiplier_210_, lean_object* v_base_211_, lean_object* v_product_212_, lean_object* v_native_213_, lean_object* v___x_214_, lean_object* v_quantum_215_, lean_object* v_range_216_, lean_object* v_b_217_, lean_object* v_i_218_){
_start:
{
uint8_t v_native_boxed_219_; lean_object* v_res_220_; 
v_native_boxed_219_ = lean_unbox(v_native_213_);
v_res_220_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2___redArg(v___x_207_, v___x_208_, v_table_209_, v_multiplier_210_, v_base_211_, v_product_212_, v_native_boxed_219_, v___x_214_, v_quantum_215_, v_range_216_, v_b_217_, v_i_218_);
lean_dec_ref(v_range_216_);
lean_dec(v___x_214_);
lean_dec_ref(v_product_212_);
lean_dec_ref(v_base_211_);
lean_dec(v_multiplier_210_);
lean_dec_ref(v_table_209_);
lean_dec(v___x_208_);
lean_dec(v___x_207_);
return v_res_220_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(lean_object* v_xs_221_, lean_object* v_i_222_){
_start:
{
lean_object* v___x_223_; uint8_t v___x_224_; 
v___x_223_ = lean_byte_array_size(v_xs_221_);
v___x_224_ = lean_nat_dec_lt(v_i_222_, v___x_223_);
return v___x_224_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0___boxed(lean_object* v_xs_225_, lean_object* v_i_226_){
_start:
{
uint8_t v_res_227_; lean_object* v_r_228_; 
v_res_227_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_xs_225_, v_i_226_);
lean_dec(v_i_226_);
lean_dec_ref(v_xs_225_);
v_r_228_ = lean_box(v_res_227_);
return v_r_228_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg(lean_object* v___x_232_, lean_object* v_multiplier_233_, lean_object* v_table_234_, lean_object* v___y_235_, lean_object* v___y_236_, lean_object* v_range_237_, lean_object* v_b_238_, lean_object* v_i_239_){
_start:
{
lean_object* v_stop_240_; lean_object* v_step_241_; uint8_t v___x_242_; 
v_stop_240_ = lean_ctor_get(v_range_237_, 1);
v_step_241_ = lean_ctor_get(v_range_237_, 2);
v___x_242_ = lean_nat_dec_lt(v_i_239_, v_stop_240_);
if (v___x_242_ == 0)
{
lean_dec(v_i_239_);
lean_inc_ref(v_b_238_);
return v_b_238_;
}
else
{
lean_object* v_arity_243_; uint8_t v_width_244_; lean_object* v_exponents_245_; uint8_t v___x_246_; lean_object* v___x_247_; lean_object* v___x_248_; uint64_t v___y_250_; uint64_t v___y_251_; uint64_t v___y_259_; uint64_t v___y_260_; uint8_t v___y_261_; uint8_t v___y_267_; lean_object* v___y_268_; uint64_t v___y_269_; uint64_t v___y_270_; lean_object* v___y_271_; uint8_t v___y_272_; uint8_t v___y_285_; uint64_t v___y_286_; lean_object* v___y_287_; uint64_t v___y_288_; lean_object* v___y_289_; uint8_t v___y_290_; uint64_t v___y_303_; uint64_t v___y_304_; uint8_t v___y_305_; uint8_t v___y_311_; lean_object* v___y_312_; uint64_t v___y_313_; lean_object* v___y_314_; uint8_t v___y_315_; uint8_t v___y_316_; uint8_t v___y_333_; uint64_t v___y_334_; lean_object* v___y_335_; lean_object* v___y_336_; uint8_t v___y_337_; uint8_t v___y_338_; uint8_t v___y_376_; uint64_t v___y_377_; lean_object* v___y_378_; uint8_t v___y_379_; lean_object* v___y_380_; lean_object* v___y_381_; uint64_t v___y_390_; uint64_t v___y_391_; uint64_t v___y_400_; uint64_t v___y_401_; uint8_t v___y_402_; uint64_t v___y_408_; lean_object* v___y_409_; uint64_t v___y_410_; uint8_t v___y_411_; lean_object* v___y_412_; uint8_t v___y_413_; uint64_t v___y_426_; lean_object* v___y_427_; uint64_t v___y_428_; lean_object* v___y_429_; uint8_t v___y_430_; uint8_t v___y_431_; uint64_t v___y_444_; uint64_t v___y_445_; uint8_t v___y_446_; uint8_t v___y_452_; lean_object* v___y_453_; uint64_t v___y_454_; uint8_t v___y_455_; lean_object* v___y_456_; uint8_t v___y_457_; uint8_t v___y_474_; uint64_t v___y_475_; lean_object* v___y_476_; uint8_t v___y_477_; lean_object* v___y_478_; uint8_t v___y_479_; lean_object* v___y_517_; uint8_t v___y_518_; uint64_t v___y_519_; lean_object* v___y_520_; uint8_t v___y_521_; lean_object* v___y_522_; uint64_t v___y_531_; uint64_t v___y_539_; uint8_t v___y_540_; uint64_t v___y_546_; uint8_t v___y_547_; lean_object* v___x_552_; lean_object* v___x_553_; uint8_t v___x_554_; uint64_t v___y_556_; lean_object* v___y_557_; uint8_t v___y_558_; uint64_t v___y_571_; lean_object* v___y_572_; uint8_t v___y_573_; lean_object* v___y_586_; uint8_t v___y_587_; lean_object* v___y_604_; uint8_t v___y_605_; lean_object* v___y_643_; 
v_arity_243_ = lean_ctor_get(v_table_234_, 0);
v_width_244_ = lean_ctor_get_uint8(v_table_234_, sizeof(void*)*8);
v_exponents_245_ = lean_ctor_get(v_table_234_, 1);
v___x_246_ = lean_nat_dec_le(v___x_232_, v_multiplier_233_);
v___x_247_ = lean_box(0);
v___x_248_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___closed__0));
v___x_552_ = lean_nat_mul(v___y_236_, v_arity_243_);
v___x_553_ = lean_nat_add(v___x_552_, v_i_239_);
lean_dec(v___x_552_);
v___x_554_ = 0;
switch(v_width_244_)
{
case 0:
{
lean_object* v___x_651_; 
v___x_651_ = lean_unsigned_to_nat(1u);
v___y_643_ = v___x_651_;
goto v___jp_642_;
}
case 1:
{
lean_object* v___x_652_; 
v___x_652_ = lean_unsigned_to_nat(2u);
v___y_643_ = v___x_652_;
goto v___jp_642_;
}
default: 
{
lean_object* v___x_653_; 
v___x_653_ = lean_unsigned_to_nat(4u);
v___y_643_ = v___x_653_;
goto v___jp_642_;
}
}
v___jp_249_:
{
uint8_t v___x_252_; 
v___x_252_ = lean_uint64_dec_eq(v___y_250_, v___y_251_);
if (v___x_252_ == 0)
{
lean_object* v___x_253_; lean_object* v___x_254_; lean_object* v___x_255_; 
lean_dec(v_i_239_);
v___x_253_ = lean_box(v___x_246_);
v___x_254_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_254_, 0, v___x_253_);
v___x_255_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_255_, 0, v___x_254_);
lean_ctor_set(v___x_255_, 1, v___x_247_);
return v___x_255_;
}
else
{
lean_object* v___x_256_; 
v___x_256_ = lean_nat_add(v_i_239_, v_step_241_);
lean_dec(v_i_239_);
v_b_238_ = v___x_248_;
v_i_239_ = v___x_256_;
goto _start;
}
}
v___jp_258_:
{
uint64_t v___x_262_; uint64_t v___x_263_; uint64_t v___x_264_; uint64_t v___x_265_; 
v___x_262_ = lean_uint8_to_uint64(v___y_261_);
v___x_263_ = 24ULL;
v___x_264_ = lean_uint64_shift_left(v___x_262_, v___x_263_);
v___x_265_ = lean_uint64_lor(v___y_260_, v___x_264_);
v___y_250_ = v___y_259_;
v___y_251_ = v___x_265_;
goto v___jp_249_;
}
v___jp_266_:
{
uint64_t v___x_273_; uint64_t v___x_274_; uint64_t v___x_275_; uint64_t v___x_276_; lean_object* v___x_277_; lean_object* v___x_278_; uint8_t v___x_279_; 
v___x_273_ = lean_uint8_to_uint64(v___y_272_);
v___x_274_ = 16ULL;
v___x_275_ = lean_uint64_shift_left(v___x_273_, v___x_274_);
v___x_276_ = lean_uint64_lor(v___y_270_, v___x_275_);
v___x_277_ = lean_unsigned_to_nat(3u);
v___x_278_ = lean_nat_add(v___y_268_, v___x_277_);
lean_dec(v___y_268_);
v___x_279_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_271_, v___x_278_);
if (v___x_279_ == 0)
{
lean_object* v___x_280_; lean_object* v___x_281_; uint8_t v___x_282_; 
lean_dec(v___x_278_);
v___x_280_ = lean_box(v___y_267_);
v___x_281_ = l_outOfBounds___redArg(v___x_280_);
lean_dec(v___x_280_);
v___x_282_ = lean_unbox(v___x_281_);
lean_dec(v___x_281_);
v___y_259_ = v___y_269_;
v___y_260_ = v___x_276_;
v___y_261_ = v___x_282_;
goto v___jp_258_;
}
else
{
uint8_t v___x_283_; 
v___x_283_ = lean_byte_array_fget(v___y_271_, v___x_278_);
lean_dec(v___x_278_);
v___y_259_ = v___y_269_;
v___y_260_ = v___x_276_;
v___y_261_ = v___x_283_;
goto v___jp_258_;
}
}
v___jp_284_:
{
uint64_t v___x_291_; uint64_t v___x_292_; uint64_t v___x_293_; uint64_t v___x_294_; lean_object* v___x_295_; lean_object* v___x_296_; uint8_t v___x_297_; 
v___x_291_ = lean_uint8_to_uint64(v___y_290_);
v___x_292_ = 8ULL;
v___x_293_ = lean_uint64_shift_left(v___x_291_, v___x_292_);
v___x_294_ = lean_uint64_lor(v___y_288_, v___x_293_);
v___x_295_ = lean_unsigned_to_nat(2u);
v___x_296_ = lean_nat_add(v___y_287_, v___x_295_);
v___x_297_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_289_, v___x_296_);
if (v___x_297_ == 0)
{
lean_object* v___x_298_; lean_object* v___x_299_; uint8_t v___x_300_; 
lean_dec(v___x_296_);
v___x_298_ = lean_box(v___y_285_);
v___x_299_ = l_outOfBounds___redArg(v___x_298_);
lean_dec(v___x_298_);
v___x_300_ = lean_unbox(v___x_299_);
lean_dec(v___x_299_);
v___y_267_ = v___y_285_;
v___y_268_ = v___y_287_;
v___y_269_ = v___y_286_;
v___y_270_ = v___x_294_;
v___y_271_ = v___y_289_;
v___y_272_ = v___x_300_;
goto v___jp_266_;
}
else
{
uint8_t v___x_301_; 
v___x_301_ = lean_byte_array_fget(v___y_289_, v___x_296_);
lean_dec(v___x_296_);
v___y_267_ = v___y_285_;
v___y_268_ = v___y_287_;
v___y_269_ = v___y_286_;
v___y_270_ = v___x_294_;
v___y_271_ = v___y_289_;
v___y_272_ = v___x_301_;
goto v___jp_266_;
}
}
v___jp_302_:
{
uint64_t v___x_306_; uint64_t v___x_307_; uint64_t v___x_308_; uint64_t v___x_309_; 
v___x_306_ = lean_uint8_to_uint64(v___y_305_);
v___x_307_ = 8ULL;
v___x_308_ = lean_uint64_shift_left(v___x_306_, v___x_307_);
v___x_309_ = lean_uint64_lor(v___y_304_, v___x_308_);
v___y_250_ = v___y_303_;
v___y_251_ = v___x_309_;
goto v___jp_249_;
}
v___jp_310_:
{
uint64_t v_a_317_; 
v_a_317_ = lean_uint8_to_uint64(v___y_316_);
switch(v___y_315_)
{
case 0:
{
lean_dec(v___y_312_);
v___y_250_ = v___y_313_;
v___y_251_ = v_a_317_;
goto v___jp_249_;
}
case 1:
{
lean_object* v___x_318_; lean_object* v___x_319_; uint8_t v___x_320_; 
v___x_318_ = lean_unsigned_to_nat(1u);
v___x_319_ = lean_nat_add(v___y_312_, v___x_318_);
lean_dec(v___y_312_);
v___x_320_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_314_, v___x_319_);
if (v___x_320_ == 0)
{
lean_object* v___x_321_; lean_object* v___x_322_; uint8_t v___x_323_; 
lean_dec(v___x_319_);
v___x_321_ = lean_box(v___y_311_);
v___x_322_ = l_outOfBounds___redArg(v___x_321_);
lean_dec(v___x_321_);
v___x_323_ = lean_unbox(v___x_322_);
lean_dec(v___x_322_);
v___y_303_ = v___y_313_;
v___y_304_ = v_a_317_;
v___y_305_ = v___x_323_;
goto v___jp_302_;
}
else
{
uint8_t v___x_324_; 
v___x_324_ = lean_byte_array_fget(v___y_314_, v___x_319_);
lean_dec(v___x_319_);
v___y_303_ = v___y_313_;
v___y_304_ = v_a_317_;
v___y_305_ = v___x_324_;
goto v___jp_302_;
}
}
default: 
{
lean_object* v___x_325_; lean_object* v___x_326_; uint8_t v___x_327_; 
v___x_325_ = lean_unsigned_to_nat(1u);
v___x_326_ = lean_nat_add(v___y_312_, v___x_325_);
v___x_327_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_314_, v___x_326_);
if (v___x_327_ == 0)
{
lean_object* v___x_328_; lean_object* v___x_329_; uint8_t v___x_330_; 
lean_dec(v___x_326_);
v___x_328_ = lean_box(v___y_311_);
v___x_329_ = l_outOfBounds___redArg(v___x_328_);
lean_dec(v___x_328_);
v___x_330_ = lean_unbox(v___x_329_);
lean_dec(v___x_329_);
v___y_285_ = v___y_311_;
v___y_286_ = v___y_313_;
v___y_287_ = v___y_312_;
v___y_288_ = v_a_317_;
v___y_289_ = v___y_314_;
v___y_290_ = v___x_330_;
goto v___jp_284_;
}
else
{
uint8_t v___x_331_; 
v___x_331_ = lean_byte_array_fget(v___y_314_, v___x_326_);
lean_dec(v___x_326_);
v___y_285_ = v___y_311_;
v___y_286_ = v___y_313_;
v___y_287_ = v___y_312_;
v___y_288_ = v_a_317_;
v___y_289_ = v___y_314_;
v___y_290_ = v___x_331_;
goto v___jp_284_;
}
}
}
}
v___jp_332_:
{
if (v___y_338_ == 0)
{
uint8_t v___x_339_; 
v___x_339_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_336_, v___y_335_);
if (v___x_339_ == 0)
{
lean_object* v___x_340_; lean_object* v___x_341_; uint8_t v___x_342_; 
v___x_340_ = lean_box(v___y_333_);
v___x_341_ = l_outOfBounds___redArg(v___x_340_);
lean_dec(v___x_340_);
v___x_342_ = lean_unbox(v___x_341_);
lean_dec(v___x_341_);
v___y_311_ = v___y_333_;
v___y_312_ = v___y_335_;
v___y_313_ = v___y_334_;
v___y_314_ = v___y_336_;
v___y_315_ = v___y_337_;
v___y_316_ = v___x_342_;
goto v___jp_310_;
}
else
{
uint8_t v___x_343_; 
v___x_343_ = lean_byte_array_fget(v___y_336_, v___y_335_);
v___y_311_ = v___y_333_;
v___y_312_ = v___y_335_;
v___y_313_ = v___y_334_;
v___y_314_ = v___y_336_;
v___y_315_ = v___y_337_;
v___y_316_ = v___x_343_;
goto v___jp_310_;
}
}
else
{
size_t v_pos_344_; uint8_t v___x_345_; uint64_t v_a_346_; 
v_pos_344_ = lean_usize_of_nat(v___y_335_);
lean_dec(v___y_335_);
v___x_345_ = lean_byte_array_uget(v___y_336_, v_pos_344_);
v_a_346_ = lean_uint8_to_uint64(v___x_345_);
switch(v___y_337_)
{
case 0:
{
v___y_250_ = v___y_334_;
v___y_251_ = v_a_346_;
goto v___jp_249_;
}
case 1:
{
size_t v___x_347_; size_t v___x_348_; uint8_t v___x_349_; uint64_t v___x_350_; uint64_t v___x_351_; uint64_t v___x_352_; uint64_t v___x_353_; 
v___x_347_ = ((size_t)1ULL);
v___x_348_ = lean_usize_add(v_pos_344_, v___x_347_);
v___x_349_ = lean_byte_array_uget(v___y_336_, v___x_348_);
v___x_350_ = lean_uint8_to_uint64(v___x_349_);
v___x_351_ = 8ULL;
v___x_352_ = lean_uint64_shift_left(v___x_350_, v___x_351_);
v___x_353_ = lean_uint64_lor(v_a_346_, v___x_352_);
v___y_250_ = v___y_334_;
v___y_251_ = v___x_353_;
goto v___jp_249_;
}
default: 
{
size_t v___x_354_; size_t v___x_355_; uint8_t v___x_356_; uint64_t v___x_357_; uint64_t v___x_358_; uint64_t v___x_359_; uint64_t v___x_360_; size_t v___x_361_; size_t v___x_362_; uint8_t v___x_363_; uint64_t v___x_364_; uint64_t v___x_365_; uint64_t v___x_366_; uint64_t v___x_367_; size_t v___x_368_; size_t v___x_369_; uint8_t v___x_370_; uint64_t v___x_371_; uint64_t v___x_372_; uint64_t v___x_373_; uint64_t v___x_374_; 
v___x_354_ = ((size_t)1ULL);
v___x_355_ = lean_usize_add(v_pos_344_, v___x_354_);
v___x_356_ = lean_byte_array_uget(v___y_336_, v___x_355_);
v___x_357_ = lean_uint8_to_uint64(v___x_356_);
v___x_358_ = 8ULL;
v___x_359_ = lean_uint64_shift_left(v___x_357_, v___x_358_);
v___x_360_ = lean_uint64_lor(v_a_346_, v___x_359_);
v___x_361_ = ((size_t)2ULL);
v___x_362_ = lean_usize_add(v_pos_344_, v___x_361_);
v___x_363_ = lean_byte_array_uget(v___y_336_, v___x_362_);
v___x_364_ = lean_uint8_to_uint64(v___x_363_);
v___x_365_ = 16ULL;
v___x_366_ = lean_uint64_shift_left(v___x_364_, v___x_365_);
v___x_367_ = lean_uint64_lor(v___x_360_, v___x_366_);
v___x_368_ = ((size_t)3ULL);
v___x_369_ = lean_usize_add(v_pos_344_, v___x_368_);
v___x_370_ = lean_byte_array_uget(v___y_336_, v___x_369_);
v___x_371_ = lean_uint8_to_uint64(v___x_370_);
v___x_372_ = 24ULL;
v___x_373_ = lean_uint64_shift_left(v___x_371_, v___x_372_);
v___x_374_ = lean_uint64_lor(v___x_367_, v___x_373_);
v___y_250_ = v___y_334_;
v___y_251_ = v___x_374_;
goto v___jp_249_;
}
}
}
}
v___jp_375_:
{
lean_object* v_offset_382_; lean_object* v___x_383_; lean_object* v___x_384_; uint8_t v___x_385_; 
v_offset_382_ = lean_nat_mul(v___y_380_, v___y_381_);
lean_dec(v___y_380_);
v___x_383_ = lean_nat_add(v_offset_382_, v___y_381_);
v___x_384_ = lean_byte_array_size(v___y_378_);
v___x_385_ = lean_nat_dec_le(v___x_383_, v___x_384_);
if (v___x_385_ == 0)
{
lean_dec(v___x_383_);
v___y_333_ = v___y_376_;
v___y_334_ = v___y_377_;
v___y_335_ = v_offset_382_;
v___y_336_ = v___y_378_;
v___y_337_ = v___y_379_;
v___y_338_ = v___x_385_;
goto v___jp_332_;
}
else
{
size_t v___x_386_; lean_object* v___x_387_; uint8_t v___x_388_; 
v___x_386_ = lean_usize_of_nat(v___x_383_);
v___x_387_ = lean_usize_to_nat(v___x_386_);
v___x_388_ = lean_nat_dec_eq(v___x_387_, v___x_383_);
lean_dec(v___x_383_);
lean_dec(v___x_387_);
v___y_333_ = v___y_376_;
v___y_334_ = v___y_377_;
v___y_335_ = v_offset_382_;
v___y_336_ = v___y_378_;
v___y_337_ = v___y_379_;
v___y_338_ = v___x_388_;
goto v___jp_332_;
}
}
v___jp_389_:
{
uint64_t v___x_392_; lean_object* v___x_393_; lean_object* v___x_394_; uint8_t v___x_395_; 
v___x_392_ = lean_uint64_add(v___y_390_, v___y_391_);
v___x_393_ = lean_nat_mul(v___y_235_, v_arity_243_);
v___x_394_ = lean_nat_add(v___x_393_, v_i_239_);
lean_dec(v___x_393_);
v___x_395_ = 0;
switch(v_width_244_)
{
case 0:
{
lean_object* v___x_396_; 
v___x_396_ = lean_unsigned_to_nat(1u);
v___y_376_ = v___x_395_;
v___y_377_ = v___x_392_;
v___y_378_ = v_exponents_245_;
v___y_379_ = v_width_244_;
v___y_380_ = v___x_394_;
v___y_381_ = v___x_396_;
goto v___jp_375_;
}
case 1:
{
lean_object* v___x_397_; 
v___x_397_ = lean_unsigned_to_nat(2u);
v___y_376_ = v___x_395_;
v___y_377_ = v___x_392_;
v___y_378_ = v_exponents_245_;
v___y_379_ = v_width_244_;
v___y_380_ = v___x_394_;
v___y_381_ = v___x_397_;
goto v___jp_375_;
}
default: 
{
lean_object* v___x_398_; 
v___x_398_ = lean_unsigned_to_nat(4u);
v___y_376_ = v___x_395_;
v___y_377_ = v___x_392_;
v___y_378_ = v_exponents_245_;
v___y_379_ = v_width_244_;
v___y_380_ = v___x_394_;
v___y_381_ = v___x_398_;
goto v___jp_375_;
}
}
}
v___jp_399_:
{
uint64_t v___x_403_; uint64_t v___x_404_; uint64_t v___x_405_; uint64_t v___x_406_; 
v___x_403_ = lean_uint8_to_uint64(v___y_402_);
v___x_404_ = 24ULL;
v___x_405_ = lean_uint64_shift_left(v___x_403_, v___x_404_);
v___x_406_ = lean_uint64_lor(v___y_400_, v___x_405_);
v___y_390_ = v___y_401_;
v___y_391_ = v___x_406_;
goto v___jp_389_;
}
v___jp_407_:
{
uint64_t v___x_414_; uint64_t v___x_415_; uint64_t v___x_416_; uint64_t v___x_417_; lean_object* v___x_418_; lean_object* v___x_419_; uint8_t v___x_420_; 
v___x_414_ = lean_uint8_to_uint64(v___y_413_);
v___x_415_ = 16ULL;
v___x_416_ = lean_uint64_shift_left(v___x_414_, v___x_415_);
v___x_417_ = lean_uint64_lor(v___y_408_, v___x_416_);
v___x_418_ = lean_unsigned_to_nat(3u);
v___x_419_ = lean_nat_add(v___y_409_, v___x_418_);
lean_dec(v___y_409_);
v___x_420_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_412_, v___x_419_);
if (v___x_420_ == 0)
{
lean_object* v___x_421_; lean_object* v___x_422_; uint8_t v___x_423_; 
lean_dec(v___x_419_);
v___x_421_ = lean_box(v___y_411_);
v___x_422_ = l_outOfBounds___redArg(v___x_421_);
lean_dec(v___x_421_);
v___x_423_ = lean_unbox(v___x_422_);
lean_dec(v___x_422_);
v___y_400_ = v___x_417_;
v___y_401_ = v___y_410_;
v___y_402_ = v___x_423_;
goto v___jp_399_;
}
else
{
uint8_t v___x_424_; 
v___x_424_ = lean_byte_array_fget(v___y_412_, v___x_419_);
lean_dec(v___x_419_);
v___y_400_ = v___x_417_;
v___y_401_ = v___y_410_;
v___y_402_ = v___x_424_;
goto v___jp_399_;
}
}
v___jp_425_:
{
uint64_t v___x_432_; uint64_t v___x_433_; uint64_t v___x_434_; uint64_t v___x_435_; lean_object* v___x_436_; lean_object* v___x_437_; uint8_t v___x_438_; 
v___x_432_ = lean_uint8_to_uint64(v___y_431_);
v___x_433_ = 8ULL;
v___x_434_ = lean_uint64_shift_left(v___x_432_, v___x_433_);
v___x_435_ = lean_uint64_lor(v___y_428_, v___x_434_);
v___x_436_ = lean_unsigned_to_nat(2u);
v___x_437_ = lean_nat_add(v___y_427_, v___x_436_);
v___x_438_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_429_, v___x_437_);
if (v___x_438_ == 0)
{
lean_object* v___x_439_; lean_object* v___x_440_; uint8_t v___x_441_; 
lean_dec(v___x_437_);
v___x_439_ = lean_box(v___y_430_);
v___x_440_ = l_outOfBounds___redArg(v___x_439_);
lean_dec(v___x_439_);
v___x_441_ = lean_unbox(v___x_440_);
lean_dec(v___x_440_);
v___y_408_ = v___x_435_;
v___y_409_ = v___y_427_;
v___y_410_ = v___y_426_;
v___y_411_ = v___y_430_;
v___y_412_ = v___y_429_;
v___y_413_ = v___x_441_;
goto v___jp_407_;
}
else
{
uint8_t v___x_442_; 
v___x_442_ = lean_byte_array_fget(v___y_429_, v___x_437_);
lean_dec(v___x_437_);
v___y_408_ = v___x_435_;
v___y_409_ = v___y_427_;
v___y_410_ = v___y_426_;
v___y_411_ = v___y_430_;
v___y_412_ = v___y_429_;
v___y_413_ = v___x_442_;
goto v___jp_407_;
}
}
v___jp_443_:
{
uint64_t v___x_447_; uint64_t v___x_448_; uint64_t v___x_449_; uint64_t v___x_450_; 
v___x_447_ = lean_uint8_to_uint64(v___y_446_);
v___x_448_ = 8ULL;
v___x_449_ = lean_uint64_shift_left(v___x_447_, v___x_448_);
v___x_450_ = lean_uint64_lor(v___y_445_, v___x_449_);
v___y_390_ = v___y_444_;
v___y_391_ = v___x_450_;
goto v___jp_389_;
}
v___jp_451_:
{
uint64_t v_a_458_; 
v_a_458_ = lean_uint8_to_uint64(v___y_457_);
switch(v___y_452_)
{
case 0:
{
lean_dec(v___y_453_);
v___y_390_ = v___y_454_;
v___y_391_ = v_a_458_;
goto v___jp_389_;
}
case 1:
{
lean_object* v___x_459_; lean_object* v___x_460_; uint8_t v___x_461_; 
v___x_459_ = lean_unsigned_to_nat(1u);
v___x_460_ = lean_nat_add(v___y_453_, v___x_459_);
lean_dec(v___y_453_);
v___x_461_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_456_, v___x_460_);
if (v___x_461_ == 0)
{
lean_object* v___x_462_; lean_object* v___x_463_; uint8_t v___x_464_; 
lean_dec(v___x_460_);
v___x_462_ = lean_box(v___y_455_);
v___x_463_ = l_outOfBounds___redArg(v___x_462_);
lean_dec(v___x_462_);
v___x_464_ = lean_unbox(v___x_463_);
lean_dec(v___x_463_);
v___y_444_ = v___y_454_;
v___y_445_ = v_a_458_;
v___y_446_ = v___x_464_;
goto v___jp_443_;
}
else
{
uint8_t v___x_465_; 
v___x_465_ = lean_byte_array_fget(v___y_456_, v___x_460_);
lean_dec(v___x_460_);
v___y_444_ = v___y_454_;
v___y_445_ = v_a_458_;
v___y_446_ = v___x_465_;
goto v___jp_443_;
}
}
default: 
{
lean_object* v___x_466_; lean_object* v___x_467_; uint8_t v___x_468_; 
v___x_466_ = lean_unsigned_to_nat(1u);
v___x_467_ = lean_nat_add(v___y_453_, v___x_466_);
v___x_468_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_456_, v___x_467_);
if (v___x_468_ == 0)
{
lean_object* v___x_469_; lean_object* v___x_470_; uint8_t v___x_471_; 
lean_dec(v___x_467_);
v___x_469_ = lean_box(v___y_455_);
v___x_470_ = l_outOfBounds___redArg(v___x_469_);
lean_dec(v___x_469_);
v___x_471_ = lean_unbox(v___x_470_);
lean_dec(v___x_470_);
v___y_426_ = v___y_454_;
v___y_427_ = v___y_453_;
v___y_428_ = v_a_458_;
v___y_429_ = v___y_456_;
v___y_430_ = v___y_455_;
v___y_431_ = v___x_471_;
goto v___jp_425_;
}
else
{
uint8_t v___x_472_; 
v___x_472_ = lean_byte_array_fget(v___y_456_, v___x_467_);
lean_dec(v___x_467_);
v___y_426_ = v___y_454_;
v___y_427_ = v___y_453_;
v___y_428_ = v_a_458_;
v___y_429_ = v___y_456_;
v___y_430_ = v___y_455_;
v___y_431_ = v___x_472_;
goto v___jp_425_;
}
}
}
}
v___jp_473_:
{
if (v___y_479_ == 0)
{
uint8_t v___x_480_; 
v___x_480_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_478_, v___y_476_);
if (v___x_480_ == 0)
{
lean_object* v___x_481_; lean_object* v___x_482_; uint8_t v___x_483_; 
v___x_481_ = lean_box(v___y_477_);
v___x_482_ = l_outOfBounds___redArg(v___x_481_);
lean_dec(v___x_481_);
v___x_483_ = lean_unbox(v___x_482_);
lean_dec(v___x_482_);
v___y_452_ = v___y_474_;
v___y_453_ = v___y_476_;
v___y_454_ = v___y_475_;
v___y_455_ = v___y_477_;
v___y_456_ = v___y_478_;
v___y_457_ = v___x_483_;
goto v___jp_451_;
}
else
{
uint8_t v___x_484_; 
v___x_484_ = lean_byte_array_fget(v___y_478_, v___y_476_);
v___y_452_ = v___y_474_;
v___y_453_ = v___y_476_;
v___y_454_ = v___y_475_;
v___y_455_ = v___y_477_;
v___y_456_ = v___y_478_;
v___y_457_ = v___x_484_;
goto v___jp_451_;
}
}
else
{
size_t v_pos_485_; uint8_t v___x_486_; uint64_t v_a_487_; 
v_pos_485_ = lean_usize_of_nat(v___y_476_);
lean_dec(v___y_476_);
v___x_486_ = lean_byte_array_uget(v___y_478_, v_pos_485_);
v_a_487_ = lean_uint8_to_uint64(v___x_486_);
switch(v___y_474_)
{
case 0:
{
v___y_390_ = v___y_475_;
v___y_391_ = v_a_487_;
goto v___jp_389_;
}
case 1:
{
size_t v___x_488_; size_t v___x_489_; uint8_t v___x_490_; uint64_t v___x_491_; uint64_t v___x_492_; uint64_t v___x_493_; uint64_t v___x_494_; 
v___x_488_ = ((size_t)1ULL);
v___x_489_ = lean_usize_add(v_pos_485_, v___x_488_);
v___x_490_ = lean_byte_array_uget(v___y_478_, v___x_489_);
v___x_491_ = lean_uint8_to_uint64(v___x_490_);
v___x_492_ = 8ULL;
v___x_493_ = lean_uint64_shift_left(v___x_491_, v___x_492_);
v___x_494_ = lean_uint64_lor(v_a_487_, v___x_493_);
v___y_390_ = v___y_475_;
v___y_391_ = v___x_494_;
goto v___jp_389_;
}
default: 
{
size_t v___x_495_; size_t v___x_496_; uint8_t v___x_497_; uint64_t v___x_498_; uint64_t v___x_499_; uint64_t v___x_500_; uint64_t v___x_501_; size_t v___x_502_; size_t v___x_503_; uint8_t v___x_504_; uint64_t v___x_505_; uint64_t v___x_506_; uint64_t v___x_507_; uint64_t v___x_508_; size_t v___x_509_; size_t v___x_510_; uint8_t v___x_511_; uint64_t v___x_512_; uint64_t v___x_513_; uint64_t v___x_514_; uint64_t v___x_515_; 
v___x_495_ = ((size_t)1ULL);
v___x_496_ = lean_usize_add(v_pos_485_, v___x_495_);
v___x_497_ = lean_byte_array_uget(v___y_478_, v___x_496_);
v___x_498_ = lean_uint8_to_uint64(v___x_497_);
v___x_499_ = 8ULL;
v___x_500_ = lean_uint64_shift_left(v___x_498_, v___x_499_);
v___x_501_ = lean_uint64_lor(v_a_487_, v___x_500_);
v___x_502_ = ((size_t)2ULL);
v___x_503_ = lean_usize_add(v_pos_485_, v___x_502_);
v___x_504_ = lean_byte_array_uget(v___y_478_, v___x_503_);
v___x_505_ = lean_uint8_to_uint64(v___x_504_);
v___x_506_ = 16ULL;
v___x_507_ = lean_uint64_shift_left(v___x_505_, v___x_506_);
v___x_508_ = lean_uint64_lor(v___x_501_, v___x_507_);
v___x_509_ = ((size_t)3ULL);
v___x_510_ = lean_usize_add(v_pos_485_, v___x_509_);
v___x_511_ = lean_byte_array_uget(v___y_478_, v___x_510_);
v___x_512_ = lean_uint8_to_uint64(v___x_511_);
v___x_513_ = 24ULL;
v___x_514_ = lean_uint64_shift_left(v___x_512_, v___x_513_);
v___x_515_ = lean_uint64_lor(v___x_508_, v___x_514_);
v___y_390_ = v___y_475_;
v___y_391_ = v___x_515_;
goto v___jp_389_;
}
}
}
}
v___jp_516_:
{
lean_object* v_offset_523_; lean_object* v___x_524_; lean_object* v___x_525_; uint8_t v___x_526_; 
v_offset_523_ = lean_nat_mul(v___y_517_, v___y_522_);
lean_dec(v___y_517_);
v___x_524_ = lean_nat_add(v_offset_523_, v___y_522_);
v___x_525_ = lean_byte_array_size(v___y_520_);
v___x_526_ = lean_nat_dec_le(v___x_524_, v___x_525_);
if (v___x_526_ == 0)
{
lean_dec(v___x_524_);
v___y_474_ = v___y_518_;
v___y_475_ = v___y_519_;
v___y_476_ = v_offset_523_;
v___y_477_ = v___y_521_;
v___y_478_ = v___y_520_;
v___y_479_ = v___x_526_;
goto v___jp_473_;
}
else
{
size_t v___x_527_; lean_object* v___x_528_; uint8_t v___x_529_; 
v___x_527_ = lean_usize_of_nat(v___x_524_);
v___x_528_ = lean_usize_to_nat(v___x_527_);
v___x_529_ = lean_nat_dec_eq(v___x_528_, v___x_524_);
lean_dec(v___x_524_);
lean_dec(v___x_528_);
v___y_474_ = v___y_518_;
v___y_475_ = v___y_519_;
v___y_476_ = v_offset_523_;
v___y_477_ = v___y_521_;
v___y_478_ = v___y_520_;
v___y_479_ = v___x_529_;
goto v___jp_473_;
}
}
v___jp_530_:
{
lean_object* v___x_532_; lean_object* v___x_533_; uint8_t v___x_534_; 
v___x_532_ = lean_nat_mul(v_multiplier_233_, v_arity_243_);
v___x_533_ = lean_nat_add(v___x_532_, v_i_239_);
lean_dec(v___x_532_);
v___x_534_ = 0;
switch(v_width_244_)
{
case 0:
{
lean_object* v___x_535_; 
v___x_535_ = lean_unsigned_to_nat(1u);
v___y_517_ = v___x_533_;
v___y_518_ = v_width_244_;
v___y_519_ = v___y_531_;
v___y_520_ = v_exponents_245_;
v___y_521_ = v___x_534_;
v___y_522_ = v___x_535_;
goto v___jp_516_;
}
case 1:
{
lean_object* v___x_536_; 
v___x_536_ = lean_unsigned_to_nat(2u);
v___y_517_ = v___x_533_;
v___y_518_ = v_width_244_;
v___y_519_ = v___y_531_;
v___y_520_ = v_exponents_245_;
v___y_521_ = v___x_534_;
v___y_522_ = v___x_536_;
goto v___jp_516_;
}
default: 
{
lean_object* v___x_537_; 
v___x_537_ = lean_unsigned_to_nat(4u);
v___y_517_ = v___x_533_;
v___y_518_ = v_width_244_;
v___y_519_ = v___y_531_;
v___y_520_ = v_exponents_245_;
v___y_521_ = v___x_534_;
v___y_522_ = v___x_537_;
goto v___jp_516_;
}
}
}
v___jp_538_:
{
uint64_t v___x_541_; uint64_t v___x_542_; uint64_t v___x_543_; uint64_t v___x_544_; 
v___x_541_ = lean_uint8_to_uint64(v___y_540_);
v___x_542_ = 24ULL;
v___x_543_ = lean_uint64_shift_left(v___x_541_, v___x_542_);
v___x_544_ = lean_uint64_lor(v___y_539_, v___x_543_);
v___y_531_ = v___x_544_;
goto v___jp_530_;
}
v___jp_545_:
{
uint64_t v___x_548_; uint64_t v___x_549_; uint64_t v___x_550_; uint64_t v___x_551_; 
v___x_548_ = lean_uint8_to_uint64(v___y_547_);
v___x_549_ = 8ULL;
v___x_550_ = lean_uint64_shift_left(v___x_548_, v___x_549_);
v___x_551_ = lean_uint64_lor(v___y_546_, v___x_550_);
v___y_531_ = v___x_551_;
goto v___jp_530_;
}
v___jp_555_:
{
uint64_t v___x_559_; uint64_t v___x_560_; uint64_t v___x_561_; uint64_t v___x_562_; lean_object* v___x_563_; lean_object* v___x_564_; uint8_t v___x_565_; 
v___x_559_ = lean_uint8_to_uint64(v___y_558_);
v___x_560_ = 16ULL;
v___x_561_ = lean_uint64_shift_left(v___x_559_, v___x_560_);
v___x_562_ = lean_uint64_lor(v___y_556_, v___x_561_);
v___x_563_ = lean_unsigned_to_nat(3u);
v___x_564_ = lean_nat_add(v___y_557_, v___x_563_);
lean_dec(v___y_557_);
v___x_565_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_exponents_245_, v___x_564_);
if (v___x_565_ == 0)
{
lean_object* v___x_566_; lean_object* v___x_567_; uint8_t v___x_568_; 
lean_dec(v___x_564_);
v___x_566_ = lean_box(v___x_554_);
v___x_567_ = l_outOfBounds___redArg(v___x_566_);
lean_dec(v___x_566_);
v___x_568_ = lean_unbox(v___x_567_);
lean_dec(v___x_567_);
v___y_539_ = v___x_562_;
v___y_540_ = v___x_568_;
goto v___jp_538_;
}
else
{
uint8_t v___x_569_; 
v___x_569_ = lean_byte_array_fget(v_exponents_245_, v___x_564_);
lean_dec(v___x_564_);
v___y_539_ = v___x_562_;
v___y_540_ = v___x_569_;
goto v___jp_538_;
}
}
v___jp_570_:
{
uint64_t v___x_574_; uint64_t v___x_575_; uint64_t v___x_576_; uint64_t v___x_577_; lean_object* v___x_578_; lean_object* v___x_579_; uint8_t v___x_580_; 
v___x_574_ = lean_uint8_to_uint64(v___y_573_);
v___x_575_ = 8ULL;
v___x_576_ = lean_uint64_shift_left(v___x_574_, v___x_575_);
v___x_577_ = lean_uint64_lor(v___y_571_, v___x_576_);
v___x_578_ = lean_unsigned_to_nat(2u);
v___x_579_ = lean_nat_add(v___y_572_, v___x_578_);
v___x_580_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_exponents_245_, v___x_579_);
if (v___x_580_ == 0)
{
lean_object* v___x_581_; lean_object* v___x_582_; uint8_t v___x_583_; 
lean_dec(v___x_579_);
v___x_581_ = lean_box(v___x_554_);
v___x_582_ = l_outOfBounds___redArg(v___x_581_);
lean_dec(v___x_581_);
v___x_583_ = lean_unbox(v___x_582_);
lean_dec(v___x_582_);
v___y_556_ = v___x_577_;
v___y_557_ = v___y_572_;
v___y_558_ = v___x_583_;
goto v___jp_555_;
}
else
{
uint8_t v___x_584_; 
v___x_584_ = lean_byte_array_fget(v_exponents_245_, v___x_579_);
lean_dec(v___x_579_);
v___y_556_ = v___x_577_;
v___y_557_ = v___y_572_;
v___y_558_ = v___x_584_;
goto v___jp_555_;
}
}
v___jp_585_:
{
uint64_t v_a_588_; 
v_a_588_ = lean_uint8_to_uint64(v___y_587_);
switch(v_width_244_)
{
case 0:
{
lean_dec(v___y_586_);
v___y_531_ = v_a_588_;
goto v___jp_530_;
}
case 1:
{
lean_object* v___x_589_; lean_object* v___x_590_; uint8_t v___x_591_; 
v___x_589_ = lean_unsigned_to_nat(1u);
v___x_590_ = lean_nat_add(v___y_586_, v___x_589_);
lean_dec(v___y_586_);
v___x_591_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_exponents_245_, v___x_590_);
if (v___x_591_ == 0)
{
lean_object* v___x_592_; lean_object* v___x_593_; uint8_t v___x_594_; 
lean_dec(v___x_590_);
v___x_592_ = lean_box(v___x_554_);
v___x_593_ = l_outOfBounds___redArg(v___x_592_);
lean_dec(v___x_592_);
v___x_594_ = lean_unbox(v___x_593_);
lean_dec(v___x_593_);
v___y_546_ = v_a_588_;
v___y_547_ = v___x_594_;
goto v___jp_545_;
}
else
{
uint8_t v___x_595_; 
v___x_595_ = lean_byte_array_fget(v_exponents_245_, v___x_590_);
lean_dec(v___x_590_);
v___y_546_ = v_a_588_;
v___y_547_ = v___x_595_;
goto v___jp_545_;
}
}
default: 
{
lean_object* v___x_596_; lean_object* v___x_597_; uint8_t v___x_598_; 
v___x_596_ = lean_unsigned_to_nat(1u);
v___x_597_ = lean_nat_add(v___y_586_, v___x_596_);
v___x_598_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_exponents_245_, v___x_597_);
if (v___x_598_ == 0)
{
lean_object* v___x_599_; lean_object* v___x_600_; uint8_t v___x_601_; 
lean_dec(v___x_597_);
v___x_599_ = lean_box(v___x_554_);
v___x_600_ = l_outOfBounds___redArg(v___x_599_);
lean_dec(v___x_599_);
v___x_601_ = lean_unbox(v___x_600_);
lean_dec(v___x_600_);
v___y_571_ = v_a_588_;
v___y_572_ = v___y_586_;
v___y_573_ = v___x_601_;
goto v___jp_570_;
}
else
{
uint8_t v___x_602_; 
v___x_602_ = lean_byte_array_fget(v_exponents_245_, v___x_597_);
lean_dec(v___x_597_);
v___y_571_ = v_a_588_;
v___y_572_ = v___y_586_;
v___y_573_ = v___x_602_;
goto v___jp_570_;
}
}
}
}
v___jp_603_:
{
if (v___y_605_ == 0)
{
uint8_t v___x_606_; 
v___x_606_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_exponents_245_, v___y_604_);
if (v___x_606_ == 0)
{
lean_object* v___x_607_; lean_object* v___x_608_; uint8_t v___x_609_; 
v___x_607_ = lean_box(v___x_554_);
v___x_608_ = l_outOfBounds___redArg(v___x_607_);
lean_dec(v___x_607_);
v___x_609_ = lean_unbox(v___x_608_);
lean_dec(v___x_608_);
v___y_586_ = v___y_604_;
v___y_587_ = v___x_609_;
goto v___jp_585_;
}
else
{
uint8_t v___x_610_; 
v___x_610_ = lean_byte_array_fget(v_exponents_245_, v___y_604_);
v___y_586_ = v___y_604_;
v___y_587_ = v___x_610_;
goto v___jp_585_;
}
}
else
{
size_t v_pos_611_; uint8_t v___x_612_; uint64_t v_a_613_; 
v_pos_611_ = lean_usize_of_nat(v___y_604_);
lean_dec(v___y_604_);
v___x_612_ = lean_byte_array_uget(v_exponents_245_, v_pos_611_);
v_a_613_ = lean_uint8_to_uint64(v___x_612_);
switch(v_width_244_)
{
case 0:
{
v___y_531_ = v_a_613_;
goto v___jp_530_;
}
case 1:
{
size_t v___x_614_; size_t v___x_615_; uint8_t v___x_616_; uint64_t v___x_617_; uint64_t v___x_618_; uint64_t v___x_619_; uint64_t v___x_620_; 
v___x_614_ = ((size_t)1ULL);
v___x_615_ = lean_usize_add(v_pos_611_, v___x_614_);
v___x_616_ = lean_byte_array_uget(v_exponents_245_, v___x_615_);
v___x_617_ = lean_uint8_to_uint64(v___x_616_);
v___x_618_ = 8ULL;
v___x_619_ = lean_uint64_shift_left(v___x_617_, v___x_618_);
v___x_620_ = lean_uint64_lor(v_a_613_, v___x_619_);
v___y_531_ = v___x_620_;
goto v___jp_530_;
}
default: 
{
size_t v___x_621_; size_t v___x_622_; uint8_t v___x_623_; uint64_t v___x_624_; uint64_t v___x_625_; uint64_t v___x_626_; uint64_t v___x_627_; size_t v___x_628_; size_t v___x_629_; uint8_t v___x_630_; uint64_t v___x_631_; uint64_t v___x_632_; uint64_t v___x_633_; uint64_t v___x_634_; size_t v___x_635_; size_t v___x_636_; uint8_t v___x_637_; uint64_t v___x_638_; uint64_t v___x_639_; uint64_t v___x_640_; uint64_t v___x_641_; 
v___x_621_ = ((size_t)1ULL);
v___x_622_ = lean_usize_add(v_pos_611_, v___x_621_);
v___x_623_ = lean_byte_array_uget(v_exponents_245_, v___x_622_);
v___x_624_ = lean_uint8_to_uint64(v___x_623_);
v___x_625_ = 8ULL;
v___x_626_ = lean_uint64_shift_left(v___x_624_, v___x_625_);
v___x_627_ = lean_uint64_lor(v_a_613_, v___x_626_);
v___x_628_ = ((size_t)2ULL);
v___x_629_ = lean_usize_add(v_pos_611_, v___x_628_);
v___x_630_ = lean_byte_array_uget(v_exponents_245_, v___x_629_);
v___x_631_ = lean_uint8_to_uint64(v___x_630_);
v___x_632_ = 16ULL;
v___x_633_ = lean_uint64_shift_left(v___x_631_, v___x_632_);
v___x_634_ = lean_uint64_lor(v___x_627_, v___x_633_);
v___x_635_ = ((size_t)3ULL);
v___x_636_ = lean_usize_add(v_pos_611_, v___x_635_);
v___x_637_ = lean_byte_array_uget(v_exponents_245_, v___x_636_);
v___x_638_ = lean_uint8_to_uint64(v___x_637_);
v___x_639_ = 24ULL;
v___x_640_ = lean_uint64_shift_left(v___x_638_, v___x_639_);
v___x_641_ = lean_uint64_lor(v___x_634_, v___x_640_);
v___y_531_ = v___x_641_;
goto v___jp_530_;
}
}
}
}
v___jp_642_:
{
lean_object* v_offset_644_; lean_object* v___x_645_; lean_object* v___x_646_; uint8_t v___x_647_; 
v_offset_644_ = lean_nat_mul(v___x_553_, v___y_643_);
lean_dec(v___x_553_);
v___x_645_ = lean_nat_add(v_offset_644_, v___y_643_);
v___x_646_ = lean_byte_array_size(v_exponents_245_);
v___x_647_ = lean_nat_dec_le(v___x_645_, v___x_646_);
if (v___x_647_ == 0)
{
lean_dec(v___x_645_);
v___y_604_ = v_offset_644_;
v___y_605_ = v___x_647_;
goto v___jp_603_;
}
else
{
size_t v___x_648_; lean_object* v___x_649_; uint8_t v___x_650_; 
v___x_648_ = lean_usize_of_nat(v___x_645_);
v___x_649_ = lean_usize_to_nat(v___x_648_);
v___x_650_ = lean_nat_dec_eq(v___x_649_, v___x_645_);
lean_dec(v___x_645_);
lean_dec(v___x_649_);
v___y_604_ = v_offset_644_;
v___y_605_ = v___x_650_;
goto v___jp_603_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___boxed(lean_object* v___x_654_, lean_object* v_multiplier_655_, lean_object* v_table_656_, lean_object* v___y_657_, lean_object* v___y_658_, lean_object* v_range_659_, lean_object* v_b_660_, lean_object* v_i_661_){
_start:
{
lean_object* v_res_662_; 
v_res_662_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg(v___x_654_, v_multiplier_655_, v_table_656_, v___y_657_, v___y_658_, v_range_659_, v_b_660_, v_i_661_);
lean_dec_ref(v_b_660_);
lean_dec_ref(v_range_659_);
lean_dec(v___y_658_);
lean_dec(v___y_657_);
lean_dec_ref(v_table_656_);
lean_dec(v_multiplier_655_);
lean_dec(v___x_654_);
return v_res_662_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg(lean_object* v_table_666_, lean_object* v_multiplier_667_, lean_object* v___x_668_, lean_object* v_product_669_, lean_object* v_base_670_, lean_object* v_range_671_, lean_object* v_b_672_, lean_object* v_i_673_){
_start:
{
lean_object* v_stop_674_; lean_object* v_step_675_; uint8_t v___x_676_; 
v_stop_674_ = lean_ctor_get(v_range_671_, 1);
v_step_675_ = lean_ctor_get(v_range_671_, 2);
v___x_676_ = lean_nat_dec_lt(v_i_673_, v_stop_674_);
if (v___x_676_ == 0)
{
lean_dec(v_i_673_);
lean_dec(v___x_668_);
lean_inc_ref(v_b_672_);
return v_b_672_;
}
else
{
lean_object* v_support_677_; lean_object* v___x_678_; lean_object* v___x_681_; lean_object* v_start_682_; lean_object* v___x_683_; lean_object* v___y_685_; lean_object* v___y_686_; uint64_t v___y_705_; lean_object* v___y_706_; uint8_t v___y_707_; lean_object* v___y_714_; uint64_t v___y_715_; lean_object* v___y_716_; uint8_t v___y_717_; lean_object* v___y_718_; uint8_t v___y_719_; lean_object* v___y_732_; uint64_t v___y_733_; lean_object* v___y_734_; uint8_t v___y_735_; lean_object* v___y_736_; uint8_t v___y_737_; lean_object* v___y_750_; lean_object* v___y_751_; uint8_t v___y_752_; lean_object* v___y_753_; uint8_t v___y_754_; lean_object* v___y_763_; lean_object* v___y_764_; uint8_t v___y_765_; lean_object* v___y_766_; uint8_t v___y_767_; lean_object* v___y_799_; uint64_t v___y_811_; uint8_t v___y_812_; uint8_t v___x_818_; lean_object* v___x_819_; lean_object* v_offset_820_; uint64_t v___y_822_; uint8_t v___y_823_; uint64_t v___y_836_; uint8_t v___y_837_; uint8_t v___y_850_; uint8_t v___y_859_; lean_object* v___x_890_; lean_object* v___x_891_; uint8_t v___x_892_; 
v_support_677_ = lean_ctor_get(v_base_670_, 0);
v___x_678_ = lean_box(0);
v___x_681_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___closed__0));
v_start_682_ = lean_unsigned_to_nat(0u);
v___x_683_ = lean_unsigned_to_nat(1u);
v___x_818_ = 0;
v___x_819_ = lean_unsigned_to_nat(4u);
v_offset_820_ = lean_nat_mul(v_i_673_, v___x_819_);
v___x_890_ = lean_nat_add(v_offset_820_, v___x_819_);
v___x_891_ = lean_byte_array_size(v_support_677_);
v___x_892_ = lean_nat_dec_le(v___x_890_, v___x_891_);
if (v___x_892_ == 0)
{
lean_dec(v___x_890_);
v___y_859_ = v___x_892_;
goto v___jp_858_;
}
else
{
size_t v___x_893_; lean_object* v___x_894_; uint8_t v___x_895_; 
v___x_893_ = lean_usize_of_nat(v___x_890_);
v___x_894_ = lean_usize_to_nat(v___x_893_);
v___x_895_ = lean_nat_dec_eq(v___x_894_, v___x_890_);
lean_dec(v___x_890_);
lean_dec(v___x_894_);
v___y_859_ = v___x_895_;
goto v___jp_858_;
}
v___jp_679_:
{
lean_object* v___x_680_; 
v___x_680_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg___closed__0));
return v___x_680_;
}
v___jp_684_:
{
lean_object* v_count_687_; uint8_t v___x_688_; 
v_count_687_ = lean_ctor_get(v_table_666_, 3);
v___x_688_ = lean_nat_dec_le(v_count_687_, v___y_685_);
if (v___x_688_ == 0)
{
uint8_t v___x_689_; 
v___x_689_ = lean_nat_dec_le(v_count_687_, v___y_686_);
if (v___x_689_ == 0)
{
uint8_t v___x_690_; 
v___x_690_ = lean_nat_dec_le(v_count_687_, v_multiplier_667_);
if (v___x_690_ == 0)
{
lean_object* v___x_691_; lean_object* v___x_692_; lean_object* v_fst_693_; lean_object* v___x_695_; uint8_t v_isShared_696_; uint8_t v_isSharedCheck_702_; 
lean_inc(v___x_668_);
v___x_691_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_691_, 0, v_start_682_);
lean_ctor_set(v___x_691_, 1, v___x_668_);
lean_ctor_set(v___x_691_, 2, v___x_683_);
v___x_692_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg(v_count_687_, v_multiplier_667_, v_table_666_, v___y_686_, v___y_685_, v___x_691_, v___x_681_, v_start_682_);
lean_dec_ref_known(v___x_691_, 3);
lean_dec(v___y_685_);
lean_dec(v___y_686_);
v_fst_693_ = lean_ctor_get(v___x_692_, 0);
v_isSharedCheck_702_ = !lean_is_exclusive(v___x_692_);
if (v_isSharedCheck_702_ == 0)
{
lean_object* v_unused_703_; 
v_unused_703_ = lean_ctor_get(v___x_692_, 1);
lean_dec(v_unused_703_);
v___x_695_ = v___x_692_;
v_isShared_696_ = v_isSharedCheck_702_;
goto v_resetjp_694_;
}
else
{
lean_inc(v_fst_693_);
lean_dec(v___x_692_);
v___x_695_ = lean_box(0);
v_isShared_696_ = v_isSharedCheck_702_;
goto v_resetjp_694_;
}
v_resetjp_694_:
{
if (lean_obj_tag(v_fst_693_) == 0)
{
lean_object* v___x_697_; 
lean_del_object(v___x_695_);
v___x_697_ = lean_nat_add(v_i_673_, v_step_675_);
lean_dec(v_i_673_);
v_b_672_ = v___x_681_;
v_i_673_ = v___x_697_;
goto _start;
}
else
{
lean_object* v___x_700_; 
lean_dec(v_i_673_);
lean_dec(v___x_668_);
if (v_isShared_696_ == 0)
{
lean_ctor_set(v___x_695_, 1, v___x_678_);
v___x_700_ = v___x_695_;
goto v_reusejp_699_;
}
else
{
lean_object* v_reuseFailAlloc_701_; 
v_reuseFailAlloc_701_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_701_, 0, v_fst_693_);
lean_ctor_set(v_reuseFailAlloc_701_, 1, v___x_678_);
v___x_700_ = v_reuseFailAlloc_701_;
goto v_reusejp_699_;
}
v_reusejp_699_:
{
return v___x_700_;
}
}
}
}
else
{
lean_dec(v___y_686_);
lean_dec(v___y_685_);
lean_dec(v_i_673_);
lean_dec(v___x_668_);
goto v___jp_679_;
}
}
else
{
lean_dec(v___y_686_);
lean_dec(v___y_685_);
lean_dec(v_i_673_);
lean_dec(v___x_668_);
goto v___jp_679_;
}
}
else
{
lean_dec(v___y_686_);
lean_dec(v___y_685_);
lean_dec(v_i_673_);
lean_dec(v___x_668_);
goto v___jp_679_;
}
}
v___jp_704_:
{
uint64_t v___x_708_; uint64_t v___x_709_; uint64_t v___x_710_; uint64_t v___x_711_; lean_object* v___x_712_; 
v___x_708_ = lean_uint8_to_uint64(v___y_707_);
v___x_709_ = 24ULL;
v___x_710_ = lean_uint64_shift_left(v___x_708_, v___x_709_);
v___x_711_ = lean_uint64_lor(v___y_705_, v___x_710_);
v___x_712_ = lean_uint64_to_nat(v___x_711_);
v___y_685_ = v___y_706_;
v___y_686_ = v___x_712_;
goto v___jp_684_;
}
v___jp_713_:
{
uint64_t v___x_720_; uint64_t v___x_721_; uint64_t v___x_722_; uint64_t v___x_723_; lean_object* v___x_724_; lean_object* v___x_725_; uint8_t v___x_726_; 
v___x_720_ = lean_uint8_to_uint64(v___y_719_);
v___x_721_ = 16ULL;
v___x_722_ = lean_uint64_shift_left(v___x_720_, v___x_721_);
v___x_723_ = lean_uint64_lor(v___y_715_, v___x_722_);
v___x_724_ = lean_unsigned_to_nat(3u);
v___x_725_ = lean_nat_add(v___y_716_, v___x_724_);
lean_dec(v___y_716_);
v___x_726_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_714_, v___x_725_);
if (v___x_726_ == 0)
{
lean_object* v___x_727_; lean_object* v___x_728_; uint8_t v___x_729_; 
lean_dec(v___x_725_);
v___x_727_ = lean_box(v___y_717_);
v___x_728_ = l_outOfBounds___redArg(v___x_727_);
lean_dec(v___x_727_);
v___x_729_ = lean_unbox(v___x_728_);
lean_dec(v___x_728_);
v___y_705_ = v___x_723_;
v___y_706_ = v___y_718_;
v___y_707_ = v___x_729_;
goto v___jp_704_;
}
else
{
uint8_t v___x_730_; 
v___x_730_ = lean_byte_array_fget(v___y_714_, v___x_725_);
lean_dec(v___x_725_);
v___y_705_ = v___x_723_;
v___y_706_ = v___y_718_;
v___y_707_ = v___x_730_;
goto v___jp_704_;
}
}
v___jp_731_:
{
uint64_t v___x_738_; uint64_t v___x_739_; uint64_t v___x_740_; uint64_t v___x_741_; lean_object* v___x_742_; lean_object* v___x_743_; uint8_t v___x_744_; 
v___x_738_ = lean_uint8_to_uint64(v___y_737_);
v___x_739_ = 8ULL;
v___x_740_ = lean_uint64_shift_left(v___x_738_, v___x_739_);
v___x_741_ = lean_uint64_lor(v___y_733_, v___x_740_);
v___x_742_ = lean_unsigned_to_nat(2u);
v___x_743_ = lean_nat_add(v___y_734_, v___x_742_);
v___x_744_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_732_, v___x_743_);
if (v___x_744_ == 0)
{
lean_object* v___x_745_; lean_object* v___x_746_; uint8_t v___x_747_; 
lean_dec(v___x_743_);
v___x_745_ = lean_box(v___y_735_);
v___x_746_ = l_outOfBounds___redArg(v___x_745_);
lean_dec(v___x_745_);
v___x_747_ = lean_unbox(v___x_746_);
lean_dec(v___x_746_);
v___y_714_ = v___y_732_;
v___y_715_ = v___x_741_;
v___y_716_ = v___y_734_;
v___y_717_ = v___y_735_;
v___y_718_ = v___y_736_;
v___y_719_ = v___x_747_;
goto v___jp_713_;
}
else
{
uint8_t v___x_748_; 
v___x_748_ = lean_byte_array_fget(v___y_732_, v___x_743_);
lean_dec(v___x_743_);
v___y_714_ = v___y_732_;
v___y_715_ = v___x_741_;
v___y_716_ = v___y_734_;
v___y_717_ = v___y_735_;
v___y_718_ = v___y_736_;
v___y_719_ = v___x_748_;
goto v___jp_713_;
}
}
v___jp_749_:
{
uint64_t v_a_755_; lean_object* v___x_756_; uint8_t v___x_757_; 
v_a_755_ = lean_uint8_to_uint64(v___y_754_);
v___x_756_ = lean_nat_add(v___y_751_, v___x_683_);
v___x_757_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_750_, v___x_756_);
if (v___x_757_ == 0)
{
lean_object* v___x_758_; lean_object* v___x_759_; uint8_t v___x_760_; 
lean_dec(v___x_756_);
v___x_758_ = lean_box(v___y_752_);
v___x_759_ = l_outOfBounds___redArg(v___x_758_);
lean_dec(v___x_758_);
v___x_760_ = lean_unbox(v___x_759_);
lean_dec(v___x_759_);
v___y_732_ = v___y_750_;
v___y_733_ = v_a_755_;
v___y_734_ = v___y_751_;
v___y_735_ = v___y_752_;
v___y_736_ = v___y_753_;
v___y_737_ = v___x_760_;
goto v___jp_731_;
}
else
{
uint8_t v___x_761_; 
v___x_761_ = lean_byte_array_fget(v___y_750_, v___x_756_);
lean_dec(v___x_756_);
v___y_732_ = v___y_750_;
v___y_733_ = v_a_755_;
v___y_734_ = v___y_751_;
v___y_735_ = v___y_752_;
v___y_736_ = v___y_753_;
v___y_737_ = v___x_761_;
goto v___jp_731_;
}
}
v___jp_762_:
{
if (v___y_767_ == 0)
{
uint8_t v___x_768_; 
v___x_768_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v___y_763_, v___y_764_);
if (v___x_768_ == 0)
{
lean_object* v___x_769_; lean_object* v___x_770_; uint8_t v___x_771_; 
v___x_769_ = lean_box(v___y_765_);
v___x_770_ = l_outOfBounds___redArg(v___x_769_);
lean_dec(v___x_769_);
v___x_771_ = lean_unbox(v___x_770_);
lean_dec(v___x_770_);
v___y_750_ = v___y_763_;
v___y_751_ = v___y_764_;
v___y_752_ = v___y_765_;
v___y_753_ = v___y_766_;
v___y_754_ = v___x_771_;
goto v___jp_749_;
}
else
{
uint8_t v___x_772_; 
v___x_772_ = lean_byte_array_fget(v___y_763_, v___y_764_);
v___y_750_ = v___y_763_;
v___y_751_ = v___y_764_;
v___y_752_ = v___y_765_;
v___y_753_ = v___y_766_;
v___y_754_ = v___x_772_;
goto v___jp_749_;
}
}
else
{
size_t v_pos_773_; uint8_t v___x_774_; uint64_t v_a_775_; size_t v___x_776_; size_t v___x_777_; uint8_t v___x_778_; uint64_t v___x_779_; uint64_t v___x_780_; uint64_t v___x_781_; uint64_t v___x_782_; size_t v___x_783_; size_t v___x_784_; uint8_t v___x_785_; uint64_t v___x_786_; uint64_t v___x_787_; uint64_t v___x_788_; uint64_t v___x_789_; size_t v___x_790_; size_t v___x_791_; uint8_t v___x_792_; uint64_t v___x_793_; uint64_t v___x_794_; uint64_t v___x_795_; uint64_t v___x_796_; lean_object* v___x_797_; 
v_pos_773_ = lean_usize_of_nat(v___y_764_);
lean_dec(v___y_764_);
v___x_774_ = lean_byte_array_uget(v___y_763_, v_pos_773_);
v_a_775_ = lean_uint8_to_uint64(v___x_774_);
v___x_776_ = ((size_t)1ULL);
v___x_777_ = lean_usize_add(v_pos_773_, v___x_776_);
v___x_778_ = lean_byte_array_uget(v___y_763_, v___x_777_);
v___x_779_ = lean_uint8_to_uint64(v___x_778_);
v___x_780_ = 8ULL;
v___x_781_ = lean_uint64_shift_left(v___x_779_, v___x_780_);
v___x_782_ = lean_uint64_lor(v_a_775_, v___x_781_);
v___x_783_ = ((size_t)2ULL);
v___x_784_ = lean_usize_add(v_pos_773_, v___x_783_);
v___x_785_ = lean_byte_array_uget(v___y_763_, v___x_784_);
v___x_786_ = lean_uint8_to_uint64(v___x_785_);
v___x_787_ = 16ULL;
v___x_788_ = lean_uint64_shift_left(v___x_786_, v___x_787_);
v___x_789_ = lean_uint64_lor(v___x_782_, v___x_788_);
v___x_790_ = ((size_t)3ULL);
v___x_791_ = lean_usize_add(v_pos_773_, v___x_790_);
v___x_792_ = lean_byte_array_uget(v___y_763_, v___x_791_);
v___x_793_ = lean_uint8_to_uint64(v___x_792_);
v___x_794_ = 24ULL;
v___x_795_ = lean_uint64_shift_left(v___x_793_, v___x_794_);
v___x_796_ = lean_uint64_lor(v___x_789_, v___x_795_);
v___x_797_ = lean_uint64_to_nat(v___x_796_);
v___y_685_ = v___y_766_;
v___y_686_ = v___x_797_;
goto v___jp_684_;
}
}
v___jp_798_:
{
lean_object* v_support_800_; uint8_t v___x_801_; lean_object* v___x_802_; lean_object* v_offset_803_; lean_object* v___x_804_; lean_object* v___x_805_; uint8_t v___x_806_; 
v_support_800_ = lean_ctor_get(v_product_669_, 0);
v___x_801_ = 0;
v___x_802_ = lean_unsigned_to_nat(4u);
v_offset_803_ = lean_nat_mul(v_i_673_, v___x_802_);
v___x_804_ = lean_nat_add(v_offset_803_, v___x_802_);
v___x_805_ = lean_byte_array_size(v_support_800_);
v___x_806_ = lean_nat_dec_le(v___x_804_, v___x_805_);
if (v___x_806_ == 0)
{
lean_dec(v___x_804_);
v___y_763_ = v_support_800_;
v___y_764_ = v_offset_803_;
v___y_765_ = v___x_801_;
v___y_766_ = v___y_799_;
v___y_767_ = v___x_806_;
goto v___jp_762_;
}
else
{
size_t v___x_807_; lean_object* v___x_808_; uint8_t v___x_809_; 
v___x_807_ = lean_usize_of_nat(v___x_804_);
v___x_808_ = lean_usize_to_nat(v___x_807_);
v___x_809_ = lean_nat_dec_eq(v___x_808_, v___x_804_);
lean_dec(v___x_804_);
lean_dec(v___x_808_);
v___y_763_ = v_support_800_;
v___y_764_ = v_offset_803_;
v___y_765_ = v___x_801_;
v___y_766_ = v___y_799_;
v___y_767_ = v___x_809_;
goto v___jp_762_;
}
}
v___jp_810_:
{
uint64_t v___x_813_; uint64_t v___x_814_; uint64_t v___x_815_; uint64_t v___x_816_; lean_object* v___x_817_; 
v___x_813_ = lean_uint8_to_uint64(v___y_812_);
v___x_814_ = 24ULL;
v___x_815_ = lean_uint64_shift_left(v___x_813_, v___x_814_);
v___x_816_ = lean_uint64_lor(v___y_811_, v___x_815_);
v___x_817_ = lean_uint64_to_nat(v___x_816_);
v___y_799_ = v___x_817_;
goto v___jp_798_;
}
v___jp_821_:
{
uint64_t v___x_824_; uint64_t v___x_825_; uint64_t v___x_826_; uint64_t v___x_827_; lean_object* v___x_828_; lean_object* v___x_829_; uint8_t v___x_830_; 
v___x_824_ = lean_uint8_to_uint64(v___y_823_);
v___x_825_ = 16ULL;
v___x_826_ = lean_uint64_shift_left(v___x_824_, v___x_825_);
v___x_827_ = lean_uint64_lor(v___y_822_, v___x_826_);
v___x_828_ = lean_unsigned_to_nat(3u);
v___x_829_ = lean_nat_add(v_offset_820_, v___x_828_);
lean_dec(v_offset_820_);
v___x_830_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_support_677_, v___x_829_);
if (v___x_830_ == 0)
{
lean_object* v___x_831_; lean_object* v___x_832_; uint8_t v___x_833_; 
lean_dec(v___x_829_);
v___x_831_ = lean_box(v___x_818_);
v___x_832_ = l_outOfBounds___redArg(v___x_831_);
lean_dec(v___x_831_);
v___x_833_ = lean_unbox(v___x_832_);
lean_dec(v___x_832_);
v___y_811_ = v___x_827_;
v___y_812_ = v___x_833_;
goto v___jp_810_;
}
else
{
uint8_t v___x_834_; 
v___x_834_ = lean_byte_array_fget(v_support_677_, v___x_829_);
lean_dec(v___x_829_);
v___y_811_ = v___x_827_;
v___y_812_ = v___x_834_;
goto v___jp_810_;
}
}
v___jp_835_:
{
uint64_t v___x_838_; uint64_t v___x_839_; uint64_t v___x_840_; uint64_t v___x_841_; lean_object* v___x_842_; lean_object* v___x_843_; uint8_t v___x_844_; 
v___x_838_ = lean_uint8_to_uint64(v___y_837_);
v___x_839_ = 8ULL;
v___x_840_ = lean_uint64_shift_left(v___x_838_, v___x_839_);
v___x_841_ = lean_uint64_lor(v___y_836_, v___x_840_);
v___x_842_ = lean_unsigned_to_nat(2u);
v___x_843_ = lean_nat_add(v_offset_820_, v___x_842_);
v___x_844_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_support_677_, v___x_843_);
if (v___x_844_ == 0)
{
lean_object* v___x_845_; lean_object* v___x_846_; uint8_t v___x_847_; 
lean_dec(v___x_843_);
v___x_845_ = lean_box(v___x_818_);
v___x_846_ = l_outOfBounds___redArg(v___x_845_);
lean_dec(v___x_845_);
v___x_847_ = lean_unbox(v___x_846_);
lean_dec(v___x_846_);
v___y_822_ = v___x_841_;
v___y_823_ = v___x_847_;
goto v___jp_821_;
}
else
{
uint8_t v___x_848_; 
v___x_848_ = lean_byte_array_fget(v_support_677_, v___x_843_);
lean_dec(v___x_843_);
v___y_822_ = v___x_841_;
v___y_823_ = v___x_848_;
goto v___jp_821_;
}
}
v___jp_849_:
{
uint64_t v_a_851_; lean_object* v___x_852_; uint8_t v___x_853_; 
v_a_851_ = lean_uint8_to_uint64(v___y_850_);
v___x_852_ = lean_nat_add(v_offset_820_, v___x_683_);
v___x_853_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_support_677_, v___x_852_);
if (v___x_853_ == 0)
{
lean_object* v___x_854_; lean_object* v___x_855_; uint8_t v___x_856_; 
lean_dec(v___x_852_);
v___x_854_ = lean_box(v___x_818_);
v___x_855_ = l_outOfBounds___redArg(v___x_854_);
lean_dec(v___x_854_);
v___x_856_ = lean_unbox(v___x_855_);
lean_dec(v___x_855_);
v___y_836_ = v_a_851_;
v___y_837_ = v___x_856_;
goto v___jp_835_;
}
else
{
uint8_t v___x_857_; 
v___x_857_ = lean_byte_array_fget(v_support_677_, v___x_852_);
lean_dec(v___x_852_);
v___y_836_ = v_a_851_;
v___y_837_ = v___x_857_;
goto v___jp_835_;
}
}
v___jp_858_:
{
if (v___y_859_ == 0)
{
uint8_t v___x_860_; 
v___x_860_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_support_677_, v_offset_820_);
if (v___x_860_ == 0)
{
lean_object* v___x_861_; lean_object* v___x_862_; uint8_t v___x_863_; 
v___x_861_ = lean_box(v___x_818_);
v___x_862_ = l_outOfBounds___redArg(v___x_861_);
lean_dec(v___x_861_);
v___x_863_ = lean_unbox(v___x_862_);
lean_dec(v___x_862_);
v___y_850_ = v___x_863_;
goto v___jp_849_;
}
else
{
uint8_t v___x_864_; 
v___x_864_ = lean_byte_array_fget(v_support_677_, v_offset_820_);
v___y_850_ = v___x_864_;
goto v___jp_849_;
}
}
else
{
size_t v_pos_865_; uint8_t v___x_866_; uint64_t v_a_867_; size_t v___x_868_; size_t v___x_869_; uint8_t v___x_870_; uint64_t v___x_871_; uint64_t v___x_872_; uint64_t v___x_873_; uint64_t v___x_874_; size_t v___x_875_; size_t v___x_876_; uint8_t v___x_877_; uint64_t v___x_878_; uint64_t v___x_879_; uint64_t v___x_880_; uint64_t v___x_881_; size_t v___x_882_; size_t v___x_883_; uint8_t v___x_884_; uint64_t v___x_885_; uint64_t v___x_886_; uint64_t v___x_887_; uint64_t v___x_888_; lean_object* v___x_889_; 
v_pos_865_ = lean_usize_of_nat(v_offset_820_);
lean_dec(v_offset_820_);
v___x_866_ = lean_byte_array_uget(v_support_677_, v_pos_865_);
v_a_867_ = lean_uint8_to_uint64(v___x_866_);
v___x_868_ = ((size_t)1ULL);
v___x_869_ = lean_usize_add(v_pos_865_, v___x_868_);
v___x_870_ = lean_byte_array_uget(v_support_677_, v___x_869_);
v___x_871_ = lean_uint8_to_uint64(v___x_870_);
v___x_872_ = 8ULL;
v___x_873_ = lean_uint64_shift_left(v___x_871_, v___x_872_);
v___x_874_ = lean_uint64_lor(v_a_867_, v___x_873_);
v___x_875_ = ((size_t)2ULL);
v___x_876_ = lean_usize_add(v_pos_865_, v___x_875_);
v___x_877_ = lean_byte_array_uget(v_support_677_, v___x_876_);
v___x_878_ = lean_uint8_to_uint64(v___x_877_);
v___x_879_ = 16ULL;
v___x_880_ = lean_uint64_shift_left(v___x_878_, v___x_879_);
v___x_881_ = lean_uint64_lor(v___x_874_, v___x_880_);
v___x_882_ = ((size_t)3ULL);
v___x_883_ = lean_usize_add(v_pos_865_, v___x_882_);
v___x_884_ = lean_byte_array_uget(v_support_677_, v___x_883_);
v___x_885_ = lean_uint8_to_uint64(v___x_884_);
v___x_886_ = 24ULL;
v___x_887_ = lean_uint64_shift_left(v___x_885_, v___x_886_);
v___x_888_ = lean_uint64_lor(v___x_881_, v___x_887_);
v___x_889_ = lean_uint64_to_nat(v___x_888_);
v___y_799_ = v___x_889_;
goto v___jp_798_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg___boxed(lean_object* v_table_896_, lean_object* v_multiplier_897_, lean_object* v___x_898_, lean_object* v_product_899_, lean_object* v_base_900_, lean_object* v_range_901_, lean_object* v_b_902_, lean_object* v_i_903_){
_start:
{
lean_object* v_res_904_; 
v_res_904_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg(v_table_896_, v_multiplier_897_, v___x_898_, v_product_899_, v_base_900_, v_range_901_, v_b_902_, v_i_903_);
lean_dec_ref(v_b_902_);
lean_dec_ref(v_range_901_);
lean_dec_ref(v_base_900_);
lean_dec_ref(v_product_899_);
lean_dec(v_multiplier_897_);
lean_dec_ref(v_table_896_);
return v_res_904_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts(lean_object* v_table_905_, uint8_t v_native_906_, lean_object* v_base_907_, lean_object* v_product_908_, lean_object* v_multiplier_909_){
_start:
{
lean_object* v_support_910_; lean_object* v_support_911_; lean_object* v___x_912_; lean_object* v___x_913_; lean_object* v___x_914_; lean_object* v___x_915_; lean_object* v___x_916_; uint8_t v___x_917_; 
v_support_910_ = lean_ctor_get(v_base_907_, 0);
v_support_911_ = lean_ctor_get(v_product_908_, 0);
v___x_912_ = lean_byte_array_size(v_support_910_);
v___x_913_ = lean_unsigned_to_nat(2u);
v___x_914_ = lean_nat_shiftr(v___x_912_, v___x_913_);
v___x_915_ = lean_byte_array_size(v_support_911_);
v___x_916_ = lean_nat_shiftr(v___x_915_, v___x_913_);
v___x_917_ = lean_nat_dec_eq(v___x_914_, v___x_916_);
lean_dec(v___x_916_);
if (v___x_917_ == 0)
{
lean_dec(v___x_914_);
lean_dec_ref(v_table_905_);
return v___x_917_;
}
else
{
lean_object* v_arity_918_; lean_object* v_count_919_; lean_object* v_start_920_; uint8_t v___x_929_; 
v_arity_918_ = lean_ctor_get(v_table_905_, 0);
lean_inc(v_arity_918_);
v_count_919_ = lean_ctor_get(v_table_905_, 3);
v_start_920_ = lean_unsigned_to_nat(0u);
v___x_929_ = lean_nat_dec_eq(v_arity_918_, v_start_920_);
if (v___x_929_ == 0)
{
lean_object* v___x_930_; uint8_t v___x_931_; 
v___x_930_ = lean_unsigned_to_nat(4096u);
v___x_931_ = lean_nat_dec_lt(v___x_930_, v_arity_918_);
if (v___x_931_ == 0)
{
lean_object* v___x_932_; uint8_t v___x_933_; 
v___x_932_ = lean_unsigned_to_nat(4294967295u);
v___x_933_ = lean_nat_dec_lt(v___x_932_, v_count_919_);
if (v___x_933_ == 0)
{
lean_object* v_quantum_934_; lean_object* v___x_935_; lean_object* v___x_936_; lean_object* v___x_937_; lean_object* v___x_938_; lean_object* v___x_939_; lean_object* v___x_940_; lean_object* v___x_941_; lean_object* v_fst_942_; 
lean_inc(v_count_919_);
v_quantum_934_ = lean_nat_div(v___x_930_, v_arity_918_);
v___x_935_ = lean_nat_add(v___x_914_, v_quantum_934_);
v___x_936_ = lean_unsigned_to_nat(1u);
v___x_937_ = lean_nat_sub(v___x_935_, v___x_936_);
lean_dec(v___x_935_);
v___x_938_ = lean_nat_div(v___x_937_, v_quantum_934_);
lean_dec(v___x_937_);
v___x_939_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_939_, 0, v_start_920_);
lean_ctor_set(v___x_939_, 1, v___x_938_);
lean_ctor_set(v___x_939_, 2, v___x_936_);
v___x_940_ = ((lean_object*)(lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes___closed__0));
v___x_941_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2___redArg(v_count_919_, v_arity_918_, v_table_905_, v_multiplier_909_, v_base_907_, v_product_908_, v_native_906_, v___x_914_, v_quantum_934_, v___x_939_, v___x_940_, v_start_920_);
lean_dec_ref_known(v___x_939_, 3);
lean_dec(v___x_914_);
lean_dec_ref(v_table_905_);
lean_dec(v_arity_918_);
lean_dec(v_count_919_);
v_fst_942_ = lean_ctor_get(v___x_941_, 0);
lean_inc(v_fst_942_);
lean_dec_ref(v___x_941_);
if (lean_obj_tag(v_fst_942_) == 0)
{
return v___x_917_;
}
else
{
lean_object* v_val_943_; uint8_t v___x_944_; 
v_val_943_ = lean_ctor_get(v_fst_942_, 0);
lean_inc(v_val_943_);
lean_dec_ref_known(v_fst_942_, 1);
v___x_944_ = lean_unbox(v_val_943_);
lean_dec(v_val_943_);
return v___x_944_;
}
}
else
{
goto v___jp_921_;
}
}
else
{
goto v___jp_921_;
}
}
else
{
goto v___jp_921_;
}
v___jp_921_:
{
lean_object* v___x_922_; lean_object* v___x_923_; lean_object* v___x_924_; lean_object* v___x_925_; lean_object* v_fst_926_; 
v___x_922_ = lean_unsigned_to_nat(1u);
v___x_923_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_923_, 0, v_start_920_);
lean_ctor_set(v___x_923_, 1, v___x_914_);
lean_ctor_set(v___x_923_, 2, v___x_922_);
v___x_924_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___closed__0));
v___x_925_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg(v_table_905_, v_multiplier_909_, v_arity_918_, v_product_908_, v_base_907_, v___x_923_, v___x_924_, v_start_920_);
lean_dec_ref_known(v___x_923_, 3);
lean_dec_ref(v_table_905_);
v_fst_926_ = lean_ctor_get(v___x_925_, 0);
lean_inc(v_fst_926_);
lean_dec_ref(v___x_925_);
if (lean_obj_tag(v_fst_926_) == 0)
{
return v___x_917_;
}
else
{
lean_object* v_val_927_; uint8_t v___x_928_; 
v_val_927_ = lean_ctor_get(v_fst_926_, 0);
lean_inc(v_val_927_);
lean_dec_ref_known(v_fst_926_, 1);
v___x_928_ = lean_unbox(v_val_927_);
lean_dec(v_val_927_);
return v___x_928_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts___boxed(lean_object* v_table_945_, lean_object* v_native_946_, lean_object* v_base_947_, lean_object* v_product_948_, lean_object* v_multiplier_949_){
_start:
{
uint8_t v_native_boxed_950_; uint8_t v_res_951_; lean_object* v_r_952_; 
v_native_boxed_950_ = lean_unbox(v_native_946_);
v_res_951_ = lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts(v_table_945_, v_native_boxed_950_, v_base_947_, v_product_948_, v_multiplier_949_);
lean_dec(v_multiplier_949_);
lean_dec_ref(v_product_948_);
lean_dec_ref(v_base_947_);
v_r_952_ = lean_box(v_res_951_);
return v_r_952_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0(lean_object* v___x_953_, lean_object* v_multiplier_954_, lean_object* v_table_955_, lean_object* v___y_956_, lean_object* v___y_957_, lean_object* v_range_958_, lean_object* v_b_959_, lean_object* v_i_960_, lean_object* v_hs_961_, lean_object* v_hl_962_){
_start:
{
lean_object* v___x_963_; 
v___x_963_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg(v___x_953_, v_multiplier_954_, v_table_955_, v___y_956_, v___y_957_, v_range_958_, v_b_959_, v_i_960_);
return v___x_963_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___boxed(lean_object* v___x_964_, lean_object* v_multiplier_965_, lean_object* v_table_966_, lean_object* v___y_967_, lean_object* v___y_968_, lean_object* v_range_969_, lean_object* v_b_970_, lean_object* v_i_971_, lean_object* v_hs_972_, lean_object* v_hl_973_){
_start:
{
lean_object* v_res_974_; 
v_res_974_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0(v___x_964_, v_multiplier_965_, v_table_966_, v___y_967_, v___y_968_, v_range_969_, v_b_970_, v_i_971_, v_hs_972_, v_hl_973_);
lean_dec_ref(v_b_970_);
lean_dec_ref(v_range_969_);
lean_dec(v___y_968_);
lean_dec(v___y_967_);
lean_dec_ref(v_table_966_);
lean_dec(v_multiplier_965_);
lean_dec(v___x_964_);
return v_res_974_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1(lean_object* v_table_975_, lean_object* v_multiplier_976_, lean_object* v___x_977_, lean_object* v_product_978_, lean_object* v_base_979_, lean_object* v_range_980_, lean_object* v_b_981_, lean_object* v_i_982_, lean_object* v_hs_983_, lean_object* v_hl_984_){
_start:
{
lean_object* v___x_985_; 
v___x_985_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___redArg(v_table_975_, v_multiplier_976_, v___x_977_, v_product_978_, v_base_979_, v_range_980_, v_b_981_, v_i_982_);
return v___x_985_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1___boxed(lean_object* v_table_986_, lean_object* v_multiplier_987_, lean_object* v___x_988_, lean_object* v_product_989_, lean_object* v_base_990_, lean_object* v_range_991_, lean_object* v_b_992_, lean_object* v_i_993_, lean_object* v_hs_994_, lean_object* v_hl_995_){
_start:
{
lean_object* v_res_996_; 
v_res_996_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__1(v_table_986_, v_multiplier_987_, v___x_988_, v_product_989_, v_base_990_, v_range_991_, v_b_992_, v_i_993_, v_hs_994_, v_hl_995_);
lean_dec_ref(v_b_992_);
lean_dec_ref(v_range_991_);
lean_dec_ref(v_base_990_);
lean_dec_ref(v_product_989_);
lean_dec(v_multiplier_987_);
lean_dec_ref(v_table_986_);
return v_res_996_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2(lean_object* v___x_997_, lean_object* v___x_998_, lean_object* v_table_999_, lean_object* v_multiplier_1000_, lean_object* v_base_1001_, lean_object* v_product_1002_, uint8_t v_native_1003_, lean_object* v___x_1004_, lean_object* v_quantum_1005_, lean_object* v_range_1006_, lean_object* v_b_1007_, lean_object* v_i_1008_, lean_object* v_hs_1009_, lean_object* v_hl_1010_){
_start:
{
lean_object* v___x_1011_; 
v___x_1011_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2___redArg(v___x_997_, v___x_998_, v_table_999_, v_multiplier_1000_, v_base_1001_, v_product_1002_, v_native_1003_, v___x_1004_, v_quantum_1005_, v_range_1006_, v_b_1007_, v_i_1008_);
return v___x_1011_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2___boxed(lean_object* v___x_1012_, lean_object* v___x_1013_, lean_object* v_table_1014_, lean_object* v_multiplier_1015_, lean_object* v_base_1016_, lean_object* v_product_1017_, lean_object* v_native_1018_, lean_object* v___x_1019_, lean_object* v_quantum_1020_, lean_object* v_range_1021_, lean_object* v_b_1022_, lean_object* v_i_1023_, lean_object* v_hs_1024_, lean_object* v_hl_1025_){
_start:
{
uint8_t v_native_boxed_1026_; lean_object* v_res_1027_; 
v_native_boxed_1026_ = lean_unbox(v_native_1018_);
v_res_1027_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__2(v___x_1012_, v___x_1013_, v_table_1014_, v_multiplier_1015_, v_base_1016_, v_product_1017_, v_native_boxed_1026_, v___x_1019_, v_quantum_1020_, v_range_1021_, v_b_1022_, v_i_1023_, v_hs_1024_, v_hl_1025_);
lean_dec_ref(v_range_1021_);
lean_dec(v___x_1019_);
lean_dec_ref(v_product_1017_);
lean_dec_ref(v_base_1016_);
lean_dec(v_multiplier_1015_);
lean_dec_ref(v_table_1014_);
lean_dec(v___x_1013_);
lean_dec(v___x_1012_);
return v_res_1027_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___redArg(uint64_t v_a_1028_, lean_object* v_x_1029_){
_start:
{
if (lean_obj_tag(v_x_1029_) == 0)
{
uint8_t v___x_1030_; 
v___x_1030_ = 0;
return v___x_1030_;
}
else
{
lean_object* v_key_1031_; lean_object* v_tail_1032_; uint64_t v___x_1033_; uint8_t v___x_1034_; 
v_key_1031_ = lean_ctor_get(v_x_1029_, 0);
v_tail_1032_ = lean_ctor_get(v_x_1029_, 2);
v___x_1033_ = lean_unbox_uint64(v_key_1031_);
v___x_1034_ = lean_uint64_dec_eq(v___x_1033_, v_a_1028_);
if (v___x_1034_ == 0)
{
v_x_1029_ = v_tail_1032_;
goto _start;
}
else
{
return v___x_1034_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___redArg___boxed(lean_object* v_a_1036_, lean_object* v_x_1037_){
_start:
{
uint64_t v_a_boxed_1038_; uint8_t v_res_1039_; lean_object* v_r_1040_; 
v_a_boxed_1038_ = lean_unbox_uint64(v_a_1036_);
lean_dec_ref(v_a_1036_);
v_res_1039_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___redArg(v_a_boxed_1038_, v_x_1037_);
lean_dec(v_x_1037_);
v_r_1040_ = lean_box(v_res_1039_);
return v_r_1040_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1___redArg(lean_object* v_m_1041_, uint64_t v_a_1042_){
_start:
{
lean_object* v_buckets_1043_; lean_object* v___x_1044_; uint64_t v___x_1045_; uint64_t v___x_1046_; uint64_t v_fold_1047_; uint64_t v___x_1048_; uint64_t v___x_1049_; uint64_t v___x_1050_; size_t v___x_1051_; size_t v___x_1052_; size_t v___x_1053_; size_t v___x_1054_; size_t v___x_1055_; lean_object* v___x_1056_; uint8_t v___x_1057_; 
v_buckets_1043_ = lean_ctor_get(v_m_1041_, 1);
v___x_1044_ = lean_array_get_size(v_buckets_1043_);
v___x_1045_ = 32ULL;
v___x_1046_ = lean_uint64_shift_right(v_a_1042_, v___x_1045_);
v_fold_1047_ = lean_uint64_xor(v_a_1042_, v___x_1046_);
v___x_1048_ = 16ULL;
v___x_1049_ = lean_uint64_shift_right(v_fold_1047_, v___x_1048_);
v___x_1050_ = lean_uint64_xor(v_fold_1047_, v___x_1049_);
v___x_1051_ = lean_uint64_to_usize(v___x_1050_);
v___x_1052_ = lean_usize_of_nat(v___x_1044_);
v___x_1053_ = ((size_t)1ULL);
v___x_1054_ = lean_usize_sub(v___x_1052_, v___x_1053_);
v___x_1055_ = lean_usize_land(v___x_1051_, v___x_1054_);
v___x_1056_ = lean_array_uget_borrowed(v_buckets_1043_, v___x_1055_);
v___x_1057_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___redArg(v_a_1042_, v___x_1056_);
return v___x_1057_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1___redArg___boxed(lean_object* v_m_1058_, lean_object* v_a_1059_){
_start:
{
uint64_t v_a_boxed_1060_; uint8_t v_res_1061_; lean_object* v_r_1062_; 
v_a_boxed_1060_ = lean_unbox_uint64(v_a_1059_);
lean_dec_ref(v_a_1059_);
v_res_1061_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1___redArg(v_m_1058_, v_a_boxed_1060_);
lean_dec_ref(v_m_1058_);
v_r_1062_ = lean_box(v_res_1061_);
return v_r_1062_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5___redArg(uint64_t v_a_1063_, lean_object* v_x_1064_){
_start:
{
if (lean_obj_tag(v_x_1064_) == 0)
{
lean_object* v___x_1065_; 
v___x_1065_ = lean_box(0);
return v___x_1065_;
}
else
{
lean_object* v_key_1066_; lean_object* v_value_1067_; lean_object* v_tail_1068_; uint64_t v___x_1069_; uint8_t v___x_1070_; 
v_key_1066_ = lean_ctor_get(v_x_1064_, 0);
v_value_1067_ = lean_ctor_get(v_x_1064_, 1);
v_tail_1068_ = lean_ctor_get(v_x_1064_, 2);
v___x_1069_ = lean_unbox_uint64(v_key_1066_);
v___x_1070_ = lean_uint64_dec_eq(v___x_1069_, v_a_1063_);
if (v___x_1070_ == 0)
{
v_x_1064_ = v_tail_1068_;
goto _start;
}
else
{
lean_object* v___x_1072_; 
lean_inc(v_value_1067_);
v___x_1072_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1072_, 0, v_value_1067_);
return v___x_1072_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5___redArg___boxed(lean_object* v_a_1073_, lean_object* v_x_1074_){
_start:
{
uint64_t v_a_boxed_1075_; lean_object* v_res_1076_; 
v_a_boxed_1075_ = lean_unbox_uint64(v_a_1073_);
lean_dec_ref(v_a_1073_);
v_res_1076_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5___redArg(v_a_boxed_1075_, v_x_1074_);
lean_dec(v_x_1074_);
return v_res_1076_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2___redArg(lean_object* v_m_1077_, uint64_t v_a_1078_){
_start:
{
lean_object* v_buckets_1079_; lean_object* v___x_1080_; uint64_t v___x_1081_; uint64_t v___x_1082_; uint64_t v_fold_1083_; uint64_t v___x_1084_; uint64_t v___x_1085_; uint64_t v___x_1086_; size_t v___x_1087_; size_t v___x_1088_; size_t v___x_1089_; size_t v___x_1090_; size_t v___x_1091_; lean_object* v___x_1092_; lean_object* v___x_1093_; 
v_buckets_1079_ = lean_ctor_get(v_m_1077_, 1);
v___x_1080_ = lean_array_get_size(v_buckets_1079_);
v___x_1081_ = 32ULL;
v___x_1082_ = lean_uint64_shift_right(v_a_1078_, v___x_1081_);
v_fold_1083_ = lean_uint64_xor(v_a_1078_, v___x_1082_);
v___x_1084_ = 16ULL;
v___x_1085_ = lean_uint64_shift_right(v_fold_1083_, v___x_1084_);
v___x_1086_ = lean_uint64_xor(v_fold_1083_, v___x_1085_);
v___x_1087_ = lean_uint64_to_usize(v___x_1086_);
v___x_1088_ = lean_usize_of_nat(v___x_1080_);
v___x_1089_ = ((size_t)1ULL);
v___x_1090_ = lean_usize_sub(v___x_1088_, v___x_1089_);
v___x_1091_ = lean_usize_land(v___x_1087_, v___x_1090_);
v___x_1092_ = lean_array_uget_borrowed(v_buckets_1079_, v___x_1091_);
v___x_1093_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5___redArg(v_a_1078_, v___x_1092_);
return v___x_1093_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2___redArg___boxed(lean_object* v_m_1094_, lean_object* v_a_1095_){
_start:
{
uint64_t v_a_boxed_1096_; lean_object* v_res_1097_; 
v_a_boxed_1096_ = lean_unbox_uint64(v_a_1095_);
lean_dec_ref(v_a_1095_);
v_res_1097_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2___redArg(v_m_1094_, v_a_boxed_1096_);
lean_dec_ref(v_m_1094_);
return v_res_1097_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2_spec__5___redArg(lean_object* v_x_1098_, lean_object* v_x_1099_){
_start:
{
if (lean_obj_tag(v_x_1099_) == 0)
{
return v_x_1098_;
}
else
{
lean_object* v_key_1100_; lean_object* v_value_1101_; lean_object* v_tail_1102_; lean_object* v___x_1104_; uint8_t v_isShared_1105_; uint8_t v_isSharedCheck_1126_; 
v_key_1100_ = lean_ctor_get(v_x_1099_, 0);
v_value_1101_ = lean_ctor_get(v_x_1099_, 1);
v_tail_1102_ = lean_ctor_get(v_x_1099_, 2);
v_isSharedCheck_1126_ = !lean_is_exclusive(v_x_1099_);
if (v_isSharedCheck_1126_ == 0)
{
v___x_1104_ = v_x_1099_;
v_isShared_1105_ = v_isSharedCheck_1126_;
goto v_resetjp_1103_;
}
else
{
lean_inc(v_tail_1102_);
lean_inc(v_value_1101_);
lean_inc(v_key_1100_);
lean_dec(v_x_1099_);
v___x_1104_ = lean_box(0);
v_isShared_1105_ = v_isSharedCheck_1126_;
goto v_resetjp_1103_;
}
v_resetjp_1103_:
{
lean_object* v___x_1106_; uint64_t v___x_1107_; uint64_t v___x_1108_; uint64_t v___x_1109_; uint64_t v___x_1110_; uint64_t v_fold_1111_; uint64_t v___x_1112_; uint64_t v___x_1113_; uint64_t v___x_1114_; size_t v___x_1115_; size_t v___x_1116_; size_t v___x_1117_; size_t v___x_1118_; size_t v___x_1119_; lean_object* v___x_1120_; lean_object* v___x_1122_; 
v___x_1106_ = lean_array_get_size(v_x_1098_);
v___x_1107_ = 32ULL;
v___x_1108_ = lean_unbox_uint64(v_key_1100_);
v___x_1109_ = lean_uint64_shift_right(v___x_1108_, v___x_1107_);
v___x_1110_ = lean_unbox_uint64(v_key_1100_);
v_fold_1111_ = lean_uint64_xor(v___x_1110_, v___x_1109_);
v___x_1112_ = 16ULL;
v___x_1113_ = lean_uint64_shift_right(v_fold_1111_, v___x_1112_);
v___x_1114_ = lean_uint64_xor(v_fold_1111_, v___x_1113_);
v___x_1115_ = lean_uint64_to_usize(v___x_1114_);
v___x_1116_ = lean_usize_of_nat(v___x_1106_);
v___x_1117_ = ((size_t)1ULL);
v___x_1118_ = lean_usize_sub(v___x_1116_, v___x_1117_);
v___x_1119_ = lean_usize_land(v___x_1115_, v___x_1118_);
v___x_1120_ = lean_array_uget_borrowed(v_x_1098_, v___x_1119_);
lean_inc(v___x_1120_);
if (v_isShared_1105_ == 0)
{
lean_ctor_set(v___x_1104_, 2, v___x_1120_);
v___x_1122_ = v___x_1104_;
goto v_reusejp_1121_;
}
else
{
lean_object* v_reuseFailAlloc_1125_; 
v_reuseFailAlloc_1125_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_1125_, 0, v_key_1100_);
lean_ctor_set(v_reuseFailAlloc_1125_, 1, v_value_1101_);
lean_ctor_set(v_reuseFailAlloc_1125_, 2, v___x_1120_);
v___x_1122_ = v_reuseFailAlloc_1125_;
goto v_reusejp_1121_;
}
v_reusejp_1121_:
{
lean_object* v___x_1123_; 
v___x_1123_ = lean_array_uset(v_x_1098_, v___x_1119_, v___x_1122_);
v_x_1098_ = v___x_1123_;
v_x_1099_ = v_tail_1102_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2___redArg(lean_object* v_i_1127_, lean_object* v_source_1128_, lean_object* v_target_1129_){
_start:
{
lean_object* v___x_1130_; uint8_t v___x_1131_; 
v___x_1130_ = lean_array_get_size(v_source_1128_);
v___x_1131_ = lean_nat_dec_lt(v_i_1127_, v___x_1130_);
if (v___x_1131_ == 0)
{
lean_dec_ref(v_source_1128_);
lean_dec(v_i_1127_);
return v_target_1129_;
}
else
{
lean_object* v_es_1132_; lean_object* v___x_1133_; lean_object* v_source_1134_; lean_object* v_target_1135_; lean_object* v___x_1136_; lean_object* v___x_1137_; 
v_es_1132_ = lean_array_fget(v_source_1128_, v_i_1127_);
v___x_1133_ = lean_box(0);
v_source_1134_ = lean_array_fset(v_source_1128_, v_i_1127_, v___x_1133_);
v_target_1135_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2_spec__5___redArg(v_target_1129_, v_es_1132_);
v___x_1136_ = lean_unsigned_to_nat(1u);
v___x_1137_ = lean_nat_add(v_i_1127_, v___x_1136_);
lean_dec(v_i_1127_);
v_i_1127_ = v___x_1137_;
v_source_1128_ = v_source_1134_;
v_target_1129_ = v_target_1135_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1___redArg(lean_object* v_data_1139_){
_start:
{
lean_object* v___x_1140_; lean_object* v___x_1141_; lean_object* v_nbuckets_1142_; lean_object* v___x_1143_; lean_object* v___x_1144_; lean_object* v___x_1145_; lean_object* v___x_1146_; lean_object* v___x_1147_; 
v___x_1140_ = lean_array_get_size(v_data_1139_);
v___x_1141_ = lean_unsigned_to_nat(2u);
v_nbuckets_1142_ = lean_nat_mul(v___x_1140_, v___x_1141_);
v___x_1143_ = lean_unsigned_to_nat(0u);
v___x_1144_ = lean_box(0);
v___x_1145_ = lean_mk_array(v_nbuckets_1142_, v___x_1144_);
v___x_1146_ = lean_array_propagate_mark(v_data_1139_, v___x_1145_);
v___x_1147_ = lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2___redArg(v___x_1143_, v_data_1139_, v___x_1146_);
return v___x_1147_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___redArg(uint64_t v_a_1148_, lean_object* v_b_1149_, lean_object* v_x_1150_){
_start:
{
if (lean_obj_tag(v_x_1150_) == 0)
{
lean_dec(v_b_1149_);
return v_x_1150_;
}
else
{
lean_object* v_key_1151_; lean_object* v_value_1152_; lean_object* v_tail_1153_; lean_object* v___x_1155_; uint8_t v_isShared_1156_; uint8_t v_isSharedCheck_1167_; 
v_key_1151_ = lean_ctor_get(v_x_1150_, 0);
v_value_1152_ = lean_ctor_get(v_x_1150_, 1);
v_tail_1153_ = lean_ctor_get(v_x_1150_, 2);
v_isSharedCheck_1167_ = !lean_is_exclusive(v_x_1150_);
if (v_isSharedCheck_1167_ == 0)
{
v___x_1155_ = v_x_1150_;
v_isShared_1156_ = v_isSharedCheck_1167_;
goto v_resetjp_1154_;
}
else
{
lean_inc(v_tail_1153_);
lean_inc(v_value_1152_);
lean_inc(v_key_1151_);
lean_dec(v_x_1150_);
v___x_1155_ = lean_box(0);
v_isShared_1156_ = v_isSharedCheck_1167_;
goto v_resetjp_1154_;
}
v_resetjp_1154_:
{
uint64_t v___x_1157_; uint8_t v___x_1158_; 
v___x_1157_ = lean_unbox_uint64(v_key_1151_);
v___x_1158_ = lean_uint64_dec_eq(v___x_1157_, v_a_1148_);
if (v___x_1158_ == 0)
{
lean_object* v___x_1159_; lean_object* v___x_1161_; 
v___x_1159_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___redArg(v_a_1148_, v_b_1149_, v_tail_1153_);
if (v_isShared_1156_ == 0)
{
lean_ctor_set(v___x_1155_, 2, v___x_1159_);
v___x_1161_ = v___x_1155_;
goto v_reusejp_1160_;
}
else
{
lean_object* v_reuseFailAlloc_1162_; 
v_reuseFailAlloc_1162_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_1162_, 0, v_key_1151_);
lean_ctor_set(v_reuseFailAlloc_1162_, 1, v_value_1152_);
lean_ctor_set(v_reuseFailAlloc_1162_, 2, v___x_1159_);
v___x_1161_ = v_reuseFailAlloc_1162_;
goto v_reusejp_1160_;
}
v_reusejp_1160_:
{
return v___x_1161_;
}
}
else
{
lean_object* v___x_1163_; lean_object* v___x_1165_; 
lean_dec(v_value_1152_);
lean_dec(v_key_1151_);
v___x_1163_ = lean_box_uint64(v_a_1148_);
if (v_isShared_1156_ == 0)
{
lean_ctor_set(v___x_1155_, 1, v_b_1149_);
lean_ctor_set(v___x_1155_, 0, v___x_1163_);
v___x_1165_ = v___x_1155_;
goto v_reusejp_1164_;
}
else
{
lean_object* v_reuseFailAlloc_1166_; 
v_reuseFailAlloc_1166_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_1166_, 0, v___x_1163_);
lean_ctor_set(v_reuseFailAlloc_1166_, 1, v_b_1149_);
lean_ctor_set(v_reuseFailAlloc_1166_, 2, v_tail_1153_);
v___x_1165_ = v_reuseFailAlloc_1166_;
goto v_reusejp_1164_;
}
v_reusejp_1164_:
{
return v___x_1165_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___redArg___boxed(lean_object* v_a_1168_, lean_object* v_b_1169_, lean_object* v_x_1170_){
_start:
{
uint64_t v_a_boxed_1171_; lean_object* v_res_1172_; 
v_a_boxed_1171_ = lean_unbox_uint64(v_a_1168_);
lean_dec_ref(v_a_1168_);
v_res_1172_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___redArg(v_a_boxed_1171_, v_b_1169_, v_x_1170_);
return v_res_1172_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0___redArg(lean_object* v_m_1173_, uint64_t v_a_1174_, lean_object* v_b_1175_){
_start:
{
lean_object* v_size_1176_; lean_object* v_buckets_1177_; lean_object* v___x_1179_; uint8_t v_isShared_1180_; uint8_t v_isSharedCheck_1220_; 
v_size_1176_ = lean_ctor_get(v_m_1173_, 0);
v_buckets_1177_ = lean_ctor_get(v_m_1173_, 1);
v_isSharedCheck_1220_ = !lean_is_exclusive(v_m_1173_);
if (v_isSharedCheck_1220_ == 0)
{
v___x_1179_ = v_m_1173_;
v_isShared_1180_ = v_isSharedCheck_1220_;
goto v_resetjp_1178_;
}
else
{
lean_inc(v_buckets_1177_);
lean_inc(v_size_1176_);
lean_dec(v_m_1173_);
v___x_1179_ = lean_box(0);
v_isShared_1180_ = v_isSharedCheck_1220_;
goto v_resetjp_1178_;
}
v_resetjp_1178_:
{
lean_object* v___x_1181_; uint64_t v___x_1182_; uint64_t v___x_1183_; uint64_t v_fold_1184_; uint64_t v___x_1185_; uint64_t v___x_1186_; uint64_t v___x_1187_; size_t v___x_1188_; size_t v___x_1189_; size_t v___x_1190_; size_t v___x_1191_; size_t v___x_1192_; lean_object* v_bkt_1193_; uint8_t v___x_1194_; 
v___x_1181_ = lean_array_get_size(v_buckets_1177_);
v___x_1182_ = 32ULL;
v___x_1183_ = lean_uint64_shift_right(v_a_1174_, v___x_1182_);
v_fold_1184_ = lean_uint64_xor(v_a_1174_, v___x_1183_);
v___x_1185_ = 16ULL;
v___x_1186_ = lean_uint64_shift_right(v_fold_1184_, v___x_1185_);
v___x_1187_ = lean_uint64_xor(v_fold_1184_, v___x_1186_);
v___x_1188_ = lean_uint64_to_usize(v___x_1187_);
v___x_1189_ = lean_usize_of_nat(v___x_1181_);
v___x_1190_ = ((size_t)1ULL);
v___x_1191_ = lean_usize_sub(v___x_1189_, v___x_1190_);
v___x_1192_ = lean_usize_land(v___x_1188_, v___x_1191_);
v_bkt_1193_ = lean_array_uget_borrowed(v_buckets_1177_, v___x_1192_);
v___x_1194_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___redArg(v_a_1174_, v_bkt_1193_);
if (v___x_1194_ == 0)
{
lean_object* v___x_1195_; lean_object* v_size_x27_1196_; lean_object* v___x_1197_; lean_object* v___x_1198_; lean_object* v_buckets_x27_1199_; lean_object* v___x_1200_; lean_object* v___x_1201_; lean_object* v___x_1202_; lean_object* v___x_1203_; lean_object* v___x_1204_; uint8_t v___x_1205_; 
v___x_1195_ = lean_unsigned_to_nat(1u);
v_size_x27_1196_ = lean_nat_add(v_size_1176_, v___x_1195_);
lean_dec(v_size_1176_);
v___x_1197_ = lean_box_uint64(v_a_1174_);
lean_inc(v_bkt_1193_);
v___x_1198_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v___x_1198_, 0, v___x_1197_);
lean_ctor_set(v___x_1198_, 1, v_b_1175_);
lean_ctor_set(v___x_1198_, 2, v_bkt_1193_);
v_buckets_x27_1199_ = lean_array_uset(v_buckets_1177_, v___x_1192_, v___x_1198_);
v___x_1200_ = lean_unsigned_to_nat(4u);
v___x_1201_ = lean_nat_mul(v_size_x27_1196_, v___x_1200_);
v___x_1202_ = lean_unsigned_to_nat(3u);
v___x_1203_ = lean_nat_div(v___x_1201_, v___x_1202_);
lean_dec(v___x_1201_);
v___x_1204_ = lean_array_get_size(v_buckets_x27_1199_);
v___x_1205_ = lean_nat_dec_le(v___x_1203_, v___x_1204_);
lean_dec(v___x_1203_);
if (v___x_1205_ == 0)
{
lean_object* v_val_1206_; lean_object* v___x_1208_; 
v_val_1206_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1___redArg(v_buckets_x27_1199_);
if (v_isShared_1180_ == 0)
{
lean_ctor_set(v___x_1179_, 1, v_val_1206_);
lean_ctor_set(v___x_1179_, 0, v_size_x27_1196_);
v___x_1208_ = v___x_1179_;
goto v_reusejp_1207_;
}
else
{
lean_object* v_reuseFailAlloc_1209_; 
v_reuseFailAlloc_1209_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1209_, 0, v_size_x27_1196_);
lean_ctor_set(v_reuseFailAlloc_1209_, 1, v_val_1206_);
v___x_1208_ = v_reuseFailAlloc_1209_;
goto v_reusejp_1207_;
}
v_reusejp_1207_:
{
return v___x_1208_;
}
}
else
{
lean_object* v___x_1211_; 
if (v_isShared_1180_ == 0)
{
lean_ctor_set(v___x_1179_, 1, v_buckets_x27_1199_);
lean_ctor_set(v___x_1179_, 0, v_size_x27_1196_);
v___x_1211_ = v___x_1179_;
goto v_reusejp_1210_;
}
else
{
lean_object* v_reuseFailAlloc_1212_; 
v_reuseFailAlloc_1212_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1212_, 0, v_size_x27_1196_);
lean_ctor_set(v_reuseFailAlloc_1212_, 1, v_buckets_x27_1199_);
v___x_1211_ = v_reuseFailAlloc_1212_;
goto v_reusejp_1210_;
}
v_reusejp_1210_:
{
return v___x_1211_;
}
}
}
else
{
lean_object* v___x_1213_; lean_object* v_buckets_x27_1214_; lean_object* v___x_1215_; lean_object* v___x_1216_; lean_object* v___x_1218_; 
lean_inc(v_bkt_1193_);
v___x_1213_ = lean_box(0);
v_buckets_x27_1214_ = lean_array_uset(v_buckets_1177_, v___x_1192_, v___x_1213_);
v___x_1215_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___redArg(v_a_1174_, v_b_1175_, v_bkt_1193_);
v___x_1216_ = lean_array_uset(v_buckets_x27_1214_, v___x_1192_, v___x_1215_);
if (v_isShared_1180_ == 0)
{
lean_ctor_set(v___x_1179_, 1, v___x_1216_);
v___x_1218_ = v___x_1179_;
goto v_reusejp_1217_;
}
else
{
lean_object* v_reuseFailAlloc_1219_; 
v_reuseFailAlloc_1219_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1219_, 0, v_size_1176_);
lean_ctor_set(v_reuseFailAlloc_1219_, 1, v___x_1216_);
v___x_1218_ = v_reuseFailAlloc_1219_;
goto v_reusejp_1217_;
}
v_reusejp_1217_:
{
return v___x_1218_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0___redArg___boxed(lean_object* v_m_1221_, lean_object* v_a_1222_, lean_object* v_b_1223_){
_start:
{
uint64_t v_a_boxed_1224_; lean_object* v_res_1225_; 
v_a_boxed_1224_ = lean_unbox_uint64(v_a_1222_);
lean_dec_ref(v_a_1222_);
v_res_1225_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0___redArg(v_m_1221_, v_a_boxed_1224_, v_b_1223_);
return v_res_1225_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerCache_multiply(lean_object* v_context_1230_, lean_object* v_limits_1231_, lean_object* v_cache_1232_, lean_object* v_base_1233_, lean_object* v_multiplier_1234_, lean_object* v_a_1235_){
_start:
{
lean_object* v_table_1236_; lean_object* v_statistics_1237_; lean_object* v_arity_1238_; lean_object* v_metadata_1239_; lean_object* v_cache_1240_; lean_object* v___y_1242_; lean_object* v___y_1243_; lean_object* v___x_1247_; lean_object* v___x_1248_; uint64_t v___x_1249_; lean_object* v___x_1250_; lean_object* v___x_1251_; uint8_t v___x_1252_; 
v_table_1236_ = lean_ctor_get(v_a_1235_, 0);
v_statistics_1237_ = lean_ctor_get(v_a_1235_, 1);
lean_inc_ref(v_statistics_1237_);
v_arity_1238_ = lean_ctor_get(v_table_1236_, 0);
v_metadata_1239_ = lean_ctor_get(v_table_1236_, 2);
lean_inc_ref(v_context_1230_);
v_cache_1240_ = lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_bind(v_cache_1232_, v_context_1230_);
v___x_1247_ = lean_unsigned_to_nat(3u);
v___x_1248_ = lean_nat_mul(v___x_1247_, v_multiplier_1234_);
v___x_1249_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1239_, v___x_1248_);
lean_dec(v___x_1248_);
v___x_1250_ = lean_uint64_to_nat(v___x_1249_);
v___x_1251_ = lean_unsigned_to_nat(0u);
v___x_1252_ = lean_nat_dec_eq(v___x_1250_, v___x_1251_);
lean_dec(v___x_1250_);
if (v___x_1252_ == 0)
{
lean_object* v_work_1253_; lean_object* v_allocatedBytes_1254_; lean_object* v_pairs_1255_; lean_object* v_rounds_1256_; lean_object* v_matrixEntries_1257_; lean_object* v_matrixRows_1258_; lean_object* v_matrixCalls_1259_; lean_object* v_peakMatrixRows_1260_; lean_object* v_peakMatrixEntries_1261_; lean_object* v_largestBatch_1262_; lean_object* v_productPairs_1263_; lean_object* v_chainPairs_1264_; lean_object* v_gmPairs_1265_; lean_object* v___x_1267_; uint8_t v_isShared_1268_; uint8_t v_isSharedCheck_1597_; 
v_work_1253_ = lean_ctor_get(v_statistics_1237_, 0);
v_allocatedBytes_1254_ = lean_ctor_get(v_statistics_1237_, 1);
v_pairs_1255_ = lean_ctor_get(v_statistics_1237_, 2);
v_rounds_1256_ = lean_ctor_get(v_statistics_1237_, 3);
v_matrixEntries_1257_ = lean_ctor_get(v_statistics_1237_, 4);
v_matrixRows_1258_ = lean_ctor_get(v_statistics_1237_, 5);
v_matrixCalls_1259_ = lean_ctor_get(v_statistics_1237_, 6);
v_peakMatrixRows_1260_ = lean_ctor_get(v_statistics_1237_, 7);
v_peakMatrixEntries_1261_ = lean_ctor_get(v_statistics_1237_, 8);
v_largestBatch_1262_ = lean_ctor_get(v_statistics_1237_, 9);
v_productPairs_1263_ = lean_ctor_get(v_statistics_1237_, 10);
v_chainPairs_1264_ = lean_ctor_get(v_statistics_1237_, 11);
v_gmPairs_1265_ = lean_ctor_get(v_statistics_1237_, 12);
v_isSharedCheck_1597_ = !lean_is_exclusive(v_statistics_1237_);
if (v_isSharedCheck_1597_ == 0)
{
v___x_1267_ = v_statistics_1237_;
v_isShared_1268_ = v_isSharedCheck_1597_;
goto v_resetjp_1266_;
}
else
{
lean_inc(v_gmPairs_1265_);
lean_inc(v_chainPairs_1264_);
lean_inc(v_productPairs_1263_);
lean_inc(v_largestBatch_1262_);
lean_inc(v_peakMatrixEntries_1261_);
lean_inc(v_peakMatrixRows_1260_);
lean_inc(v_matrixCalls_1259_);
lean_inc(v_matrixRows_1258_);
lean_inc(v_matrixEntries_1257_);
lean_inc(v_rounds_1256_);
lean_inc(v_pairs_1255_);
lean_inc(v_allocatedBytes_1254_);
lean_inc(v_work_1253_);
lean_dec(v_statistics_1237_);
v___x_1267_ = lean_box(0);
v_isShared_1268_ = v_isSharedCheck_1597_;
goto v_resetjp_1266_;
}
v_resetjp_1266_:
{
lean_object* v_work_1269_; lean_object* v_packedBytes_1270_; uint8_t v_nativeMonomials_1271_; lean_object* v___y_1273_; lean_object* v___y_1274_; uint64_t v___y_1275_; lean_object* v___y_1276_; lean_object* v___y_1277_; lean_object* v___y_1278_; lean_object* v___y_1325_; lean_object* v___y_1326_; lean_object* v___y_1327_; lean_object* v___y_1328_; uint64_t v___y_1329_; lean_object* v___y_1330_; lean_object* v___y_1331_; lean_object* v___y_1332_; lean_object* v___y_1337_; lean_object* v___y_1338_; uint64_t v___y_1339_; lean_object* v___y_1340_; uint64_t v___y_1362_; lean_object* v___y_1363_; lean_object* v___x_1390_; lean_object* v_work_1391_; uint8_t v___x_1392_; 
v_work_1269_ = lean_ctor_get(v_limits_1231_, 0);
v_packedBytes_1270_ = lean_ctor_get(v_limits_1231_, 1);
v_nativeMonomials_1271_ = lean_ctor_get_uint8(v_limits_1231_, sizeof(void*)*10 + 1);
v___x_1390_ = lean_unsigned_to_nat(1u);
v_work_1391_ = lean_nat_add(v_work_1253_, v___x_1390_);
lean_dec(v_work_1253_);
v___x_1392_ = lean_nat_dec_lt(v_work_1269_, v_work_1391_);
if (v___x_1392_ == 0)
{
lean_object* v___x_1394_; uint8_t v_isShared_1395_; uint8_t v_isSharedCheck_1592_; 
lean_inc_ref(v_table_1236_);
v_isSharedCheck_1592_ = !lean_is_exclusive(v_a_1235_);
if (v_isSharedCheck_1592_ == 0)
{
lean_object* v_unused_1593_; lean_object* v_unused_1594_; 
v_unused_1593_ = lean_ctor_get(v_a_1235_, 1);
lean_dec(v_unused_1593_);
v_unused_1594_ = lean_ctor_get(v_a_1235_, 0);
lean_dec(v_unused_1594_);
v___x_1394_ = v_a_1235_;
v_isShared_1395_ = v_isSharedCheck_1592_;
goto v_resetjp_1393_;
}
else
{
lean_dec(v_a_1235_);
v___x_1394_ = lean_box(0);
v_isShared_1395_ = v_isSharedCheck_1592_;
goto v_resetjp_1393_;
}
v_resetjp_1393_:
{
lean_object* v_support_1396_; lean_object* v_coefficients_1397_; lean_object* v___x_1399_; 
v_support_1396_ = lean_ctor_get(v_base_1233_, 0);
v_coefficients_1397_ = lean_ctor_get(v_base_1233_, 1);
lean_inc(v_gmPairs_1265_);
lean_inc(v_chainPairs_1264_);
lean_inc(v_productPairs_1263_);
lean_inc(v_largestBatch_1262_);
lean_inc(v_peakMatrixEntries_1261_);
lean_inc(v_peakMatrixRows_1260_);
lean_inc(v_matrixCalls_1259_);
lean_inc(v_matrixRows_1258_);
lean_inc(v_matrixEntries_1257_);
lean_inc(v_rounds_1256_);
lean_inc(v_pairs_1255_);
lean_inc(v_allocatedBytes_1254_);
lean_inc(v_work_1391_);
if (v_isShared_1268_ == 0)
{
lean_ctor_set(v___x_1267_, 0, v_work_1391_);
v___x_1399_ = v___x_1267_;
goto v_reusejp_1398_;
}
else
{
lean_object* v_reuseFailAlloc_1591_; 
v_reuseFailAlloc_1591_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_1591_, 0, v_work_1391_);
lean_ctor_set(v_reuseFailAlloc_1591_, 1, v_allocatedBytes_1254_);
lean_ctor_set(v_reuseFailAlloc_1591_, 2, v_pairs_1255_);
lean_ctor_set(v_reuseFailAlloc_1591_, 3, v_rounds_1256_);
lean_ctor_set(v_reuseFailAlloc_1591_, 4, v_matrixEntries_1257_);
lean_ctor_set(v_reuseFailAlloc_1591_, 5, v_matrixRows_1258_);
lean_ctor_set(v_reuseFailAlloc_1591_, 6, v_matrixCalls_1259_);
lean_ctor_set(v_reuseFailAlloc_1591_, 7, v_peakMatrixRows_1260_);
lean_ctor_set(v_reuseFailAlloc_1591_, 8, v_peakMatrixEntries_1261_);
lean_ctor_set(v_reuseFailAlloc_1591_, 9, v_largestBatch_1262_);
lean_ctor_set(v_reuseFailAlloc_1591_, 10, v_productPairs_1263_);
lean_ctor_set(v_reuseFailAlloc_1591_, 11, v_chainPairs_1264_);
lean_ctor_set(v_reuseFailAlloc_1591_, 12, v_gmPairs_1265_);
v___x_1399_ = v_reuseFailAlloc_1591_;
goto v_reusejp_1398_;
}
v_reusejp_1398_:
{
lean_object* v___x_1401_; 
lean_inc_ref(v_table_1236_);
if (v_isShared_1395_ == 0)
{
lean_ctor_set(v___x_1394_, 1, v___x_1399_);
v___x_1401_ = v___x_1394_;
goto v_reusejp_1400_;
}
else
{
lean_object* v_reuseFailAlloc_1590_; 
v_reuseFailAlloc_1590_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1590_, 0, v_table_1236_);
lean_ctor_set(v_reuseFailAlloc_1590_, 1, v___x_1399_);
v___x_1401_ = v_reuseFailAlloc_1590_;
goto v_reusejp_1400_;
}
v_reusejp_1400_:
{
lean_object* v___y_1441_; uint64_t v___y_1518_; uint8_t v___y_1519_; lean_object* v___x_1548_; lean_object* v___x_1549_; uint8_t v___x_1550_; 
v___x_1548_ = lean_unsigned_to_nat(4u);
v___x_1549_ = lean_byte_array_size(v_support_1396_);
v___x_1550_ = lean_nat_dec_le(v___x_1548_, v___x_1549_);
if (v___x_1550_ == 0)
{
if (v___x_1550_ == 0)
{
uint8_t v___x_1551_; uint64_t v___y_1553_; uint8_t v___y_1554_; uint64_t v___y_1565_; uint8_t v___y_1566_; uint8_t v___y_1578_; uint8_t v___x_1585_; 
v___x_1551_ = 0;
v___x_1585_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_support_1396_, v___x_1251_);
if (v___x_1585_ == 0)
{
lean_object* v___x_1586_; lean_object* v___x_1587_; uint8_t v___x_1588_; 
v___x_1586_ = lean_box(v___x_1551_);
v___x_1587_ = l_outOfBounds___redArg(v___x_1586_);
lean_dec(v___x_1586_);
v___x_1588_ = lean_unbox(v___x_1587_);
lean_dec(v___x_1587_);
v___y_1578_ = v___x_1588_;
goto v___jp_1577_;
}
else
{
uint8_t v___x_1589_; 
v___x_1589_ = lean_byte_array_fget(v_support_1396_, v___x_1251_);
v___y_1578_ = v___x_1589_;
goto v___jp_1577_;
}
v___jp_1552_:
{
uint64_t v___x_1555_; uint64_t v___x_1556_; uint64_t v___x_1557_; uint64_t v___x_1558_; uint8_t v___x_1559_; 
v___x_1555_ = lean_uint8_to_uint64(v___y_1554_);
v___x_1556_ = 16ULL;
v___x_1557_ = lean_uint64_shift_left(v___x_1555_, v___x_1556_);
v___x_1558_ = lean_uint64_lor(v___y_1553_, v___x_1557_);
v___x_1559_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_support_1396_, v___x_1247_);
if (v___x_1559_ == 0)
{
lean_object* v___x_1560_; lean_object* v___x_1561_; uint8_t v___x_1562_; 
v___x_1560_ = lean_box(v___x_1551_);
v___x_1561_ = l_outOfBounds___redArg(v___x_1560_);
lean_dec(v___x_1560_);
v___x_1562_ = lean_unbox(v___x_1561_);
lean_dec(v___x_1561_);
v___y_1518_ = v___x_1558_;
v___y_1519_ = v___x_1562_;
goto v___jp_1517_;
}
else
{
uint8_t v___x_1563_; 
v___x_1563_ = lean_byte_array_fget(v_support_1396_, v___x_1247_);
v___y_1518_ = v___x_1558_;
v___y_1519_ = v___x_1563_;
goto v___jp_1517_;
}
}
v___jp_1564_:
{
uint64_t v___x_1567_; uint64_t v___x_1568_; uint64_t v___x_1569_; uint64_t v___x_1570_; lean_object* v___x_1571_; uint8_t v___x_1572_; 
v___x_1567_ = lean_uint8_to_uint64(v___y_1566_);
v___x_1568_ = 8ULL;
v___x_1569_ = lean_uint64_shift_left(v___x_1567_, v___x_1568_);
v___x_1570_ = lean_uint64_lor(v___y_1565_, v___x_1569_);
v___x_1571_ = lean_unsigned_to_nat(2u);
v___x_1572_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_support_1396_, v___x_1571_);
if (v___x_1572_ == 0)
{
lean_object* v___x_1573_; lean_object* v___x_1574_; uint8_t v___x_1575_; 
v___x_1573_ = lean_box(v___x_1551_);
v___x_1574_ = l_outOfBounds___redArg(v___x_1573_);
lean_dec(v___x_1573_);
v___x_1575_ = lean_unbox(v___x_1574_);
lean_dec(v___x_1574_);
v___y_1553_ = v___x_1570_;
v___y_1554_ = v___x_1575_;
goto v___jp_1552_;
}
else
{
uint8_t v___x_1576_; 
v___x_1576_ = lean_byte_array_fget(v_support_1396_, v___x_1571_);
v___y_1553_ = v___x_1570_;
v___y_1554_ = v___x_1576_;
goto v___jp_1552_;
}
}
v___jp_1577_:
{
uint64_t v_a_1579_; uint8_t v___x_1580_; 
v_a_1579_ = lean_uint8_to_uint64(v___y_1578_);
v___x_1580_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts_spec__0___redArg___lam__0(v_support_1396_, v___x_1390_);
if (v___x_1580_ == 0)
{
lean_object* v___x_1581_; lean_object* v___x_1582_; uint8_t v___x_1583_; 
v___x_1581_ = lean_box(v___x_1551_);
v___x_1582_ = l_outOfBounds___redArg(v___x_1581_);
lean_dec(v___x_1581_);
v___x_1583_ = lean_unbox(v___x_1582_);
lean_dec(v___x_1582_);
v___y_1565_ = v_a_1579_;
v___y_1566_ = v___x_1583_;
goto v___jp_1564_;
}
else
{
uint8_t v___x_1584_; 
v___x_1584_ = lean_byte_array_fget(v_support_1396_, v___x_1390_);
v___y_1565_ = v_a_1579_;
v___y_1566_ = v___x_1584_;
goto v___jp_1564_;
}
}
}
else
{
goto v___jp_1525_;
}
}
else
{
goto v___jp_1525_;
}
v___jp_1402_:
{
lean_object* v___x_1403_; lean_object* v_fst_1404_; 
v___x_1403_ = lp_Hex_Hex_Groebner_Polynomial_multiply___redArg(v_limits_1231_, v_base_1233_, v_multiplier_1234_, v___x_1401_);
v_fst_1404_ = lean_ctor_get(v___x_1403_, 0);
lean_inc(v_fst_1404_);
if (lean_obj_tag(v_fst_1404_) == 0)
{
lean_object* v_snd_1405_; lean_object* v___x_1407_; uint8_t v_isShared_1408_; uint8_t v_isSharedCheck_1420_; 
lean_dec_ref(v_cache_1240_);
v_snd_1405_ = lean_ctor_get(v___x_1403_, 1);
v_isSharedCheck_1420_ = !lean_is_exclusive(v___x_1403_);
if (v_isSharedCheck_1420_ == 0)
{
lean_object* v_unused_1421_; 
v_unused_1421_ = lean_ctor_get(v___x_1403_, 0);
lean_dec(v_unused_1421_);
v___x_1407_ = v___x_1403_;
v_isShared_1408_ = v_isSharedCheck_1420_;
goto v_resetjp_1406_;
}
else
{
lean_inc(v_snd_1405_);
lean_dec(v___x_1403_);
v___x_1407_ = lean_box(0);
v_isShared_1408_ = v_isSharedCheck_1420_;
goto v_resetjp_1406_;
}
v_resetjp_1406_:
{
lean_object* v_a_1409_; lean_object* v___x_1411_; uint8_t v_isShared_1412_; uint8_t v_isSharedCheck_1419_; 
v_a_1409_ = lean_ctor_get(v_fst_1404_, 0);
v_isSharedCheck_1419_ = !lean_is_exclusive(v_fst_1404_);
if (v_isSharedCheck_1419_ == 0)
{
v___x_1411_ = v_fst_1404_;
v_isShared_1412_ = v_isSharedCheck_1419_;
goto v_resetjp_1410_;
}
else
{
lean_inc(v_a_1409_);
lean_dec(v_fst_1404_);
v___x_1411_ = lean_box(0);
v_isShared_1412_ = v_isSharedCheck_1419_;
goto v_resetjp_1410_;
}
v_resetjp_1410_:
{
lean_object* v___x_1414_; 
if (v_isShared_1412_ == 0)
{
v___x_1414_ = v___x_1411_;
goto v_reusejp_1413_;
}
else
{
lean_object* v_reuseFailAlloc_1418_; 
v_reuseFailAlloc_1418_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1418_, 0, v_a_1409_);
v___x_1414_ = v_reuseFailAlloc_1418_;
goto v_reusejp_1413_;
}
v_reusejp_1413_:
{
lean_object* v___x_1416_; 
if (v_isShared_1408_ == 0)
{
lean_ctor_set(v___x_1407_, 0, v___x_1414_);
v___x_1416_ = v___x_1407_;
goto v_reusejp_1415_;
}
else
{
lean_object* v_reuseFailAlloc_1417_; 
v_reuseFailAlloc_1417_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1417_, 0, v___x_1414_);
lean_ctor_set(v_reuseFailAlloc_1417_, 1, v_snd_1405_);
v___x_1416_ = v_reuseFailAlloc_1417_;
goto v_reusejp_1415_;
}
v_reusejp_1415_:
{
return v___x_1416_;
}
}
}
}
}
else
{
lean_object* v_snd_1422_; lean_object* v___x_1424_; uint8_t v_isShared_1425_; uint8_t v_isSharedCheck_1438_; 
v_snd_1422_ = lean_ctor_get(v___x_1403_, 1);
v_isSharedCheck_1438_ = !lean_is_exclusive(v___x_1403_);
if (v_isSharedCheck_1438_ == 0)
{
lean_object* v_unused_1439_; 
v_unused_1439_ = lean_ctor_get(v___x_1403_, 0);
lean_dec(v_unused_1439_);
v___x_1424_ = v___x_1403_;
v_isShared_1425_ = v_isSharedCheck_1438_;
goto v_resetjp_1423_;
}
else
{
lean_inc(v_snd_1422_);
lean_dec(v___x_1403_);
v___x_1424_ = lean_box(0);
v_isShared_1425_ = v_isSharedCheck_1438_;
goto v_resetjp_1423_;
}
v_resetjp_1423_:
{
lean_object* v_a_1426_; lean_object* v___x_1428_; uint8_t v_isShared_1429_; uint8_t v_isSharedCheck_1437_; 
v_a_1426_ = lean_ctor_get(v_fst_1404_, 0);
v_isSharedCheck_1437_ = !lean_is_exclusive(v_fst_1404_);
if (v_isSharedCheck_1437_ == 0)
{
v___x_1428_ = v_fst_1404_;
v_isShared_1429_ = v_isSharedCheck_1437_;
goto v_resetjp_1427_;
}
else
{
lean_inc(v_a_1426_);
lean_dec(v_fst_1404_);
v___x_1428_ = lean_box(0);
v_isShared_1429_ = v_isSharedCheck_1437_;
goto v_resetjp_1427_;
}
v_resetjp_1427_:
{
lean_object* v___x_1431_; 
if (v_isShared_1425_ == 0)
{
lean_ctor_set(v___x_1424_, 1, v_cache_1240_);
lean_ctor_set(v___x_1424_, 0, v_a_1426_);
v___x_1431_ = v___x_1424_;
goto v_reusejp_1430_;
}
else
{
lean_object* v_reuseFailAlloc_1436_; 
v_reuseFailAlloc_1436_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1436_, 0, v_a_1426_);
lean_ctor_set(v_reuseFailAlloc_1436_, 1, v_cache_1240_);
v___x_1431_ = v_reuseFailAlloc_1436_;
goto v_reusejp_1430_;
}
v_reusejp_1430_:
{
lean_object* v___x_1433_; 
if (v_isShared_1429_ == 0)
{
lean_ctor_set(v___x_1428_, 0, v___x_1431_);
v___x_1433_ = v___x_1428_;
goto v_reusejp_1432_;
}
else
{
lean_object* v_reuseFailAlloc_1435_; 
v_reuseFailAlloc_1435_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1435_, 0, v___x_1431_);
v___x_1433_ = v_reuseFailAlloc_1435_;
goto v_reusejp_1432_;
}
v_reusejp_1432_:
{
lean_object* v___x_1434_; 
v___x_1434_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1434_, 0, v___x_1433_);
lean_ctor_set(v___x_1434_, 1, v_snd_1422_);
return v___x_1434_;
}
}
}
}
}
}
v___jp_1440_:
{
lean_object* v___x_1442_; uint8_t v___x_1443_; 
v___x_1442_ = lean_unsigned_to_nat(4294967295u);
v___x_1443_ = lean_nat_dec_lt(v___x_1442_, v_multiplier_1234_);
if (v___x_1443_ == 0)
{
uint8_t v___x_1444_; 
v___x_1444_ = lean_nat_dec_lt(v___x_1442_, v___y_1441_);
if (v___x_1444_ == 0)
{
lean_object* v_rows_1445_; uint64_t v___x_1446_; uint64_t v___x_1447_; uint64_t v___x_1448_; uint64_t v___x_1449_; uint64_t v_key_1450_; lean_object* v___x_1451_; 
v_rows_1445_ = lean_ctor_get(v_cache_1240_, 1);
lean_inc_ref(v_rows_1445_);
v___x_1446_ = lean_uint64_of_nat(v___y_1441_);
lean_dec(v___y_1441_);
v___x_1447_ = 32ULL;
v___x_1448_ = lean_uint64_shift_left(v___x_1446_, v___x_1447_);
v___x_1449_ = lean_uint64_of_nat(v_multiplier_1234_);
v_key_1450_ = lean_uint64_lor(v___x_1448_, v___x_1449_);
v___x_1451_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2___redArg(v_rows_1445_, v_key_1450_);
lean_dec_ref(v_rows_1445_);
if (lean_obj_tag(v___x_1451_) == 1)
{
lean_object* v_val_1452_; lean_object* v___x_1454_; uint8_t v_isShared_1455_; uint8_t v_isSharedCheck_1516_; 
v_val_1452_ = lean_ctor_get(v___x_1451_, 0);
v_isSharedCheck_1516_ = !lean_is_exclusive(v___x_1451_);
if (v_isSharedCheck_1516_ == 0)
{
v___x_1454_ = v___x_1451_;
v_isShared_1455_ = v_isSharedCheck_1516_;
goto v_resetjp_1453_;
}
else
{
lean_inc(v_val_1452_);
lean_dec(v___x_1451_);
v___x_1454_ = lean_box(0);
v_isShared_1455_ = v_isSharedCheck_1516_;
goto v_resetjp_1453_;
}
v_resetjp_1453_:
{
lean_object* v___x_1456_; lean_object* v___x_1457_; lean_object* v___x_1458_; lean_object* v_work_1459_; uint8_t v___x_1460_; 
v___x_1456_ = lean_byte_array_size(v_support_1396_);
v___x_1457_ = lean_byte_array_size(v_coefficients_1397_);
v___x_1458_ = lean_nat_add(v___x_1456_, v___x_1457_);
v_work_1459_ = lean_nat_add(v_work_1391_, v___x_1458_);
lean_dec(v___x_1458_);
lean_dec(v_work_1391_);
v___x_1460_ = lean_nat_dec_lt(v_work_1269_, v_work_1459_);
if (v___x_1460_ == 0)
{
lean_object* v_base_1461_; lean_object* v_product_1462_; lean_object* v___x_1464_; uint8_t v_isShared_1465_; uint8_t v_isSharedCheck_1505_; 
lean_dec_ref(v___x_1401_);
v_base_1461_ = lean_ctor_get(v_val_1452_, 0);
v_product_1462_ = lean_ctor_get(v_val_1452_, 1);
v_isSharedCheck_1505_ = !lean_is_exclusive(v_val_1452_);
if (v_isSharedCheck_1505_ == 0)
{
v___x_1464_ = v_val_1452_;
v_isShared_1465_ = v_isSharedCheck_1505_;
goto v_resetjp_1463_;
}
else
{
lean_inc(v_product_1462_);
lean_inc(v_base_1461_);
lean_dec(v_val_1452_);
v___x_1464_ = lean_box(0);
v_isShared_1465_ = v_isSharedCheck_1505_;
goto v_resetjp_1463_;
}
v_resetjp_1463_:
{
lean_object* v_support_1466_; lean_object* v_coefficients_1467_; lean_object* v___x_1469_; uint8_t v_isShared_1470_; uint8_t v_isSharedCheck_1504_; 
v_support_1466_ = lean_ctor_get(v_base_1461_, 0);
v_coefficients_1467_ = lean_ctor_get(v_base_1461_, 1);
v_isSharedCheck_1504_ = !lean_is_exclusive(v_base_1461_);
if (v_isSharedCheck_1504_ == 0)
{
v___x_1469_ = v_base_1461_;
v_isShared_1470_ = v_isSharedCheck_1504_;
goto v_resetjp_1468_;
}
else
{
lean_inc(v_coefficients_1467_);
lean_inc(v_support_1466_);
lean_dec(v_base_1461_);
v___x_1469_ = lean_box(0);
v_isShared_1470_ = v_isSharedCheck_1504_;
goto v_resetjp_1468_;
}
v_resetjp_1468_:
{
lean_object* v___x_1471_; lean_object* v___x_1473_; 
lean_inc(v_gmPairs_1265_);
lean_inc(v_chainPairs_1264_);
lean_inc(v_productPairs_1263_);
lean_inc(v_largestBatch_1262_);
lean_inc(v_peakMatrixEntries_1261_);
lean_inc(v_peakMatrixRows_1260_);
lean_inc(v_matrixCalls_1259_);
lean_inc(v_matrixRows_1258_);
lean_inc(v_matrixEntries_1257_);
lean_inc(v_rounds_1256_);
lean_inc(v_pairs_1255_);
lean_inc(v_allocatedBytes_1254_);
lean_inc(v_work_1459_);
v___x_1471_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v___x_1471_, 0, v_work_1459_);
lean_ctor_set(v___x_1471_, 1, v_allocatedBytes_1254_);
lean_ctor_set(v___x_1471_, 2, v_pairs_1255_);
lean_ctor_set(v___x_1471_, 3, v_rounds_1256_);
lean_ctor_set(v___x_1471_, 4, v_matrixEntries_1257_);
lean_ctor_set(v___x_1471_, 5, v_matrixRows_1258_);
lean_ctor_set(v___x_1471_, 6, v_matrixCalls_1259_);
lean_ctor_set(v___x_1471_, 7, v_peakMatrixRows_1260_);
lean_ctor_set(v___x_1471_, 8, v_peakMatrixEntries_1261_);
lean_ctor_set(v___x_1471_, 9, v_largestBatch_1262_);
lean_ctor_set(v___x_1471_, 10, v_productPairs_1263_);
lean_ctor_set(v___x_1471_, 11, v_chainPairs_1264_);
lean_ctor_set(v___x_1471_, 12, v_gmPairs_1265_);
lean_inc_ref(v_table_1236_);
if (v_isShared_1470_ == 0)
{
lean_ctor_set(v___x_1469_, 1, v___x_1471_);
lean_ctor_set(v___x_1469_, 0, v_table_1236_);
v___x_1473_ = v___x_1469_;
goto v_reusejp_1472_;
}
else
{
lean_object* v_reuseFailAlloc_1503_; 
v_reuseFailAlloc_1503_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1503_, 0, v_table_1236_);
lean_ctor_set(v_reuseFailAlloc_1503_, 1, v___x_1471_);
v___x_1473_ = v_reuseFailAlloc_1503_;
goto v_reusejp_1472_;
}
v_reusejp_1472_:
{
uint8_t v___x_1474_; 
v___x_1474_ = lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes(v_support_1466_, v_support_1396_);
lean_dec_ref(v_support_1466_);
if (v___x_1474_ == 0)
{
lean_dec_ref(v_coefficients_1467_);
lean_del_object(v___x_1464_);
lean_dec_ref(v_product_1462_);
lean_dec(v_work_1459_);
lean_del_object(v___x_1454_);
lean_dec(v_gmPairs_1265_);
lean_dec(v_chainPairs_1264_);
lean_dec(v_productPairs_1263_);
lean_dec(v_largestBatch_1262_);
lean_dec(v_peakMatrixEntries_1261_);
lean_dec(v_peakMatrixRows_1260_);
lean_dec(v_matrixCalls_1259_);
lean_dec(v_matrixRows_1258_);
lean_dec(v_matrixEntries_1257_);
lean_dec(v_rounds_1256_);
lean_dec(v_pairs_1255_);
lean_dec(v_allocatedBytes_1254_);
lean_dec_ref(v_table_1236_);
v___y_1362_ = v_key_1450_;
v___y_1363_ = v___x_1473_;
goto v___jp_1361_;
}
else
{
uint8_t v___x_1475_; 
v___x_1475_ = lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameBytes(v_coefficients_1467_, v_coefficients_1397_);
lean_dec_ref(v_coefficients_1467_);
if (v___x_1475_ == 0)
{
lean_del_object(v___x_1464_);
lean_dec_ref(v_product_1462_);
lean_dec(v_work_1459_);
lean_del_object(v___x_1454_);
lean_dec(v_gmPairs_1265_);
lean_dec(v_chainPairs_1264_);
lean_dec(v_productPairs_1263_);
lean_dec(v_largestBatch_1262_);
lean_dec(v_peakMatrixEntries_1261_);
lean_dec(v_peakMatrixRows_1260_);
lean_dec(v_matrixCalls_1259_);
lean_dec(v_matrixRows_1258_);
lean_dec(v_matrixEntries_1257_);
lean_dec(v_rounds_1256_);
lean_dec(v_pairs_1255_);
lean_dec(v_allocatedBytes_1254_);
lean_dec_ref(v_table_1236_);
v___y_1362_ = v_key_1450_;
v___y_1363_ = v___x_1473_;
goto v___jp_1361_;
}
else
{
lean_object* v___x_1476_; lean_object* v___x_1477_; lean_object* v___x_1478_; lean_object* v_work_1479_; uint8_t v___x_1480_; 
v___x_1476_ = lean_unsigned_to_nat(2u);
v___x_1477_ = lean_nat_shiftr(v___x_1456_, v___x_1476_);
v___x_1478_ = lean_nat_mul(v___x_1477_, v_arity_1238_);
lean_dec(v___x_1477_);
v_work_1479_ = lean_nat_add(v_work_1459_, v___x_1478_);
lean_dec(v___x_1478_);
lean_dec(v_work_1459_);
v___x_1480_ = lean_nat_dec_lt(v_work_1269_, v_work_1479_);
if (v___x_1480_ == 0)
{
lean_object* v___x_1481_; lean_object* v___x_1483_; 
lean_dec_ref(v___x_1473_);
v___x_1481_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v___x_1481_, 0, v_work_1479_);
lean_ctor_set(v___x_1481_, 1, v_allocatedBytes_1254_);
lean_ctor_set(v___x_1481_, 2, v_pairs_1255_);
lean_ctor_set(v___x_1481_, 3, v_rounds_1256_);
lean_ctor_set(v___x_1481_, 4, v_matrixEntries_1257_);
lean_ctor_set(v___x_1481_, 5, v_matrixRows_1258_);
lean_ctor_set(v___x_1481_, 6, v_matrixCalls_1259_);
lean_ctor_set(v___x_1481_, 7, v_peakMatrixRows_1260_);
lean_ctor_set(v___x_1481_, 8, v_peakMatrixEntries_1261_);
lean_ctor_set(v___x_1481_, 9, v_largestBatch_1262_);
lean_ctor_set(v___x_1481_, 10, v_productPairs_1263_);
lean_ctor_set(v___x_1481_, 11, v_chainPairs_1264_);
lean_ctor_set(v___x_1481_, 12, v_gmPairs_1265_);
lean_inc_ref(v_table_1236_);
if (v_isShared_1465_ == 0)
{
lean_ctor_set(v___x_1464_, 1, v___x_1481_);
lean_ctor_set(v___x_1464_, 0, v_table_1236_);
v___x_1483_ = v___x_1464_;
goto v_reusejp_1482_;
}
else
{
lean_object* v_reuseFailAlloc_1498_; 
v_reuseFailAlloc_1498_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1498_, 0, v_table_1236_);
lean_ctor_set(v_reuseFailAlloc_1498_, 1, v___x_1481_);
v___x_1483_ = v_reuseFailAlloc_1498_;
goto v_reusejp_1482_;
}
v_reusejp_1482_:
{
uint8_t v___x_1484_; 
v___x_1484_ = lp_Hex___private_HexGroebner_ReducerCache_0__Hex_Groebner_ReducerCache_sameProducts(v_table_1236_, v_nativeMonomials_1271_, v_base_1233_, v_product_1462_, v_multiplier_1234_);
if (v___x_1484_ == 0)
{
lean_dec_ref(v_product_1462_);
lean_del_object(v___x_1454_);
v___y_1362_ = v_key_1450_;
v___y_1363_ = v___x_1483_;
goto v___jp_1361_;
}
else
{
lean_object* v___x_1486_; uint8_t v_isShared_1487_; uint8_t v_isSharedCheck_1495_; 
lean_dec(v_multiplier_1234_);
lean_dec_ref(v_limits_1231_);
lean_dec_ref(v_context_1230_);
v_isSharedCheck_1495_ = !lean_is_exclusive(v_base_1233_);
if (v_isSharedCheck_1495_ == 0)
{
lean_object* v_unused_1496_; lean_object* v_unused_1497_; 
v_unused_1496_ = lean_ctor_get(v_base_1233_, 1);
lean_dec(v_unused_1496_);
v_unused_1497_ = lean_ctor_get(v_base_1233_, 0);
lean_dec(v_unused_1497_);
v___x_1486_ = v_base_1233_;
v_isShared_1487_ = v_isSharedCheck_1495_;
goto v_resetjp_1485_;
}
else
{
lean_dec(v_base_1233_);
v___x_1486_ = lean_box(0);
v_isShared_1487_ = v_isSharedCheck_1495_;
goto v_resetjp_1485_;
}
v_resetjp_1485_:
{
lean_object* v___x_1489_; 
if (v_isShared_1487_ == 0)
{
lean_ctor_set(v___x_1486_, 1, v_cache_1240_);
lean_ctor_set(v___x_1486_, 0, v_product_1462_);
v___x_1489_ = v___x_1486_;
goto v_reusejp_1488_;
}
else
{
lean_object* v_reuseFailAlloc_1494_; 
v_reuseFailAlloc_1494_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1494_, 0, v_product_1462_);
lean_ctor_set(v_reuseFailAlloc_1494_, 1, v_cache_1240_);
v___x_1489_ = v_reuseFailAlloc_1494_;
goto v_reusejp_1488_;
}
v_reusejp_1488_:
{
lean_object* v___x_1491_; 
if (v_isShared_1455_ == 0)
{
lean_ctor_set(v___x_1454_, 0, v___x_1489_);
v___x_1491_ = v___x_1454_;
goto v_reusejp_1490_;
}
else
{
lean_object* v_reuseFailAlloc_1493_; 
v_reuseFailAlloc_1493_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1493_, 0, v___x_1489_);
v___x_1491_ = v_reuseFailAlloc_1493_;
goto v_reusejp_1490_;
}
v_reusejp_1490_:
{
lean_object* v___x_1492_; 
v___x_1492_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1492_, 0, v___x_1491_);
lean_ctor_set(v___x_1492_, 1, v___x_1483_);
return v___x_1492_;
}
}
}
}
}
}
else
{
lean_object* v___x_1499_; lean_object* v___x_1501_; 
lean_dec(v_work_1479_);
lean_dec_ref(v_product_1462_);
lean_del_object(v___x_1454_);
lean_dec(v_gmPairs_1265_);
lean_dec(v_chainPairs_1264_);
lean_dec(v_productPairs_1263_);
lean_dec(v_largestBatch_1262_);
lean_dec(v_peakMatrixEntries_1261_);
lean_dec(v_peakMatrixRows_1260_);
lean_dec(v_matrixCalls_1259_);
lean_dec(v_matrixRows_1258_);
lean_dec(v_matrixEntries_1257_);
lean_dec(v_rounds_1256_);
lean_dec(v_pairs_1255_);
lean_dec(v_allocatedBytes_1254_);
lean_dec_ref(v_cache_1240_);
lean_dec_ref(v_table_1236_);
lean_dec(v_multiplier_1234_);
lean_dec_ref(v_base_1233_);
lean_dec_ref(v_limits_1231_);
lean_dec_ref(v_context_1230_);
v___x_1499_ = ((lean_object*)(lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__1));
if (v_isShared_1465_ == 0)
{
lean_ctor_set(v___x_1464_, 1, v___x_1473_);
lean_ctor_set(v___x_1464_, 0, v___x_1499_);
v___x_1501_ = v___x_1464_;
goto v_reusejp_1500_;
}
else
{
lean_object* v_reuseFailAlloc_1502_; 
v_reuseFailAlloc_1502_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1502_, 0, v___x_1499_);
lean_ctor_set(v_reuseFailAlloc_1502_, 1, v___x_1473_);
v___x_1501_ = v_reuseFailAlloc_1502_;
goto v_reusejp_1500_;
}
v_reusejp_1500_:
{
return v___x_1501_;
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_1507_; uint8_t v_isShared_1508_; uint8_t v_isSharedCheck_1513_; 
lean_dec(v_work_1459_);
lean_del_object(v___x_1454_);
lean_dec(v_val_1452_);
lean_dec(v_gmPairs_1265_);
lean_dec(v_chainPairs_1264_);
lean_dec(v_productPairs_1263_);
lean_dec(v_largestBatch_1262_);
lean_dec(v_peakMatrixEntries_1261_);
lean_dec(v_peakMatrixRows_1260_);
lean_dec(v_matrixCalls_1259_);
lean_dec(v_matrixRows_1258_);
lean_dec(v_matrixEntries_1257_);
lean_dec(v_rounds_1256_);
lean_dec(v_pairs_1255_);
lean_dec(v_allocatedBytes_1254_);
lean_dec_ref(v_table_1236_);
lean_dec(v_multiplier_1234_);
lean_dec_ref(v_base_1233_);
lean_dec_ref(v_limits_1231_);
lean_dec_ref(v_context_1230_);
v_isSharedCheck_1513_ = !lean_is_exclusive(v_cache_1240_);
if (v_isSharedCheck_1513_ == 0)
{
lean_object* v_unused_1514_; lean_object* v_unused_1515_; 
v_unused_1514_ = lean_ctor_get(v_cache_1240_, 1);
lean_dec(v_unused_1514_);
v_unused_1515_ = lean_ctor_get(v_cache_1240_, 0);
lean_dec(v_unused_1515_);
v___x_1507_ = v_cache_1240_;
v_isShared_1508_ = v_isSharedCheck_1513_;
goto v_resetjp_1506_;
}
else
{
lean_dec(v_cache_1240_);
v___x_1507_ = lean_box(0);
v_isShared_1508_ = v_isSharedCheck_1513_;
goto v_resetjp_1506_;
}
v_resetjp_1506_:
{
lean_object* v___x_1509_; lean_object* v___x_1511_; 
v___x_1509_ = ((lean_object*)(lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__1));
if (v_isShared_1508_ == 0)
{
lean_ctor_set(v___x_1507_, 1, v___x_1401_);
lean_ctor_set(v___x_1507_, 0, v___x_1509_);
v___x_1511_ = v___x_1507_;
goto v_reusejp_1510_;
}
else
{
lean_object* v_reuseFailAlloc_1512_; 
v_reuseFailAlloc_1512_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1512_, 0, v___x_1509_);
lean_ctor_set(v_reuseFailAlloc_1512_, 1, v___x_1401_);
v___x_1511_ = v_reuseFailAlloc_1512_;
goto v_reusejp_1510_;
}
v_reusejp_1510_:
{
return v___x_1511_;
}
}
}
}
}
else
{
lean_dec(v___x_1451_);
lean_dec(v_work_1391_);
lean_dec(v_gmPairs_1265_);
lean_dec(v_chainPairs_1264_);
lean_dec(v_productPairs_1263_);
lean_dec(v_largestBatch_1262_);
lean_dec(v_peakMatrixEntries_1261_);
lean_dec(v_peakMatrixRows_1260_);
lean_dec(v_matrixCalls_1259_);
lean_dec(v_matrixRows_1258_);
lean_dec(v_matrixEntries_1257_);
lean_dec(v_rounds_1256_);
lean_dec(v_pairs_1255_);
lean_dec(v_allocatedBytes_1254_);
lean_dec_ref(v_table_1236_);
v___y_1362_ = v_key_1450_;
v___y_1363_ = v___x_1401_;
goto v___jp_1361_;
}
}
else
{
lean_dec(v___y_1441_);
lean_dec(v_work_1391_);
lean_dec(v_gmPairs_1265_);
lean_dec(v_chainPairs_1264_);
lean_dec(v_productPairs_1263_);
lean_dec(v_largestBatch_1262_);
lean_dec(v_peakMatrixEntries_1261_);
lean_dec(v_peakMatrixRows_1260_);
lean_dec(v_matrixCalls_1259_);
lean_dec(v_matrixRows_1258_);
lean_dec(v_matrixEntries_1257_);
lean_dec(v_rounds_1256_);
lean_dec(v_pairs_1255_);
lean_dec(v_allocatedBytes_1254_);
lean_dec_ref(v_table_1236_);
lean_dec_ref(v_context_1230_);
goto v___jp_1402_;
}
}
else
{
lean_dec(v___y_1441_);
lean_dec(v_work_1391_);
lean_dec(v_gmPairs_1265_);
lean_dec(v_chainPairs_1264_);
lean_dec(v_productPairs_1263_);
lean_dec(v_largestBatch_1262_);
lean_dec(v_peakMatrixEntries_1261_);
lean_dec(v_peakMatrixRows_1260_);
lean_dec(v_matrixCalls_1259_);
lean_dec(v_matrixRows_1258_);
lean_dec(v_matrixEntries_1257_);
lean_dec(v_rounds_1256_);
lean_dec(v_pairs_1255_);
lean_dec(v_allocatedBytes_1254_);
lean_dec_ref(v_table_1236_);
lean_dec_ref(v_context_1230_);
goto v___jp_1402_;
}
}
v___jp_1517_:
{
uint64_t v___x_1520_; uint64_t v___x_1521_; uint64_t v___x_1522_; uint64_t v___x_1523_; lean_object* v___x_1524_; 
v___x_1520_ = lean_uint8_to_uint64(v___y_1519_);
v___x_1521_ = 24ULL;
v___x_1522_ = lean_uint64_shift_left(v___x_1520_, v___x_1521_);
v___x_1523_ = lean_uint64_lor(v___y_1518_, v___x_1522_);
v___x_1524_ = lean_uint64_to_nat(v___x_1523_);
v___y_1441_ = v___x_1524_;
goto v___jp_1440_;
}
v___jp_1525_:
{
size_t v_pos_1526_; uint8_t v___x_1527_; uint64_t v_a_1528_; size_t v___x_1529_; uint8_t v___x_1530_; uint64_t v___x_1531_; uint64_t v___x_1532_; uint64_t v___x_1533_; uint64_t v___x_1534_; size_t v___x_1535_; uint8_t v___x_1536_; uint64_t v___x_1537_; uint64_t v___x_1538_; uint64_t v___x_1539_; uint64_t v___x_1540_; size_t v___x_1541_; uint8_t v___x_1542_; uint64_t v___x_1543_; uint64_t v___x_1544_; uint64_t v___x_1545_; uint64_t v___x_1546_; lean_object* v___x_1547_; 
v_pos_1526_ = ((size_t)0ULL);
v___x_1527_ = lean_byte_array_uget(v_support_1396_, v_pos_1526_);
v_a_1528_ = lean_uint8_to_uint64(v___x_1527_);
v___x_1529_ = ((size_t)1ULL);
v___x_1530_ = lean_byte_array_uget(v_support_1396_, v___x_1529_);
v___x_1531_ = lean_uint8_to_uint64(v___x_1530_);
v___x_1532_ = 8ULL;
v___x_1533_ = lean_uint64_shift_left(v___x_1531_, v___x_1532_);
v___x_1534_ = lean_uint64_lor(v_a_1528_, v___x_1533_);
v___x_1535_ = ((size_t)2ULL);
v___x_1536_ = lean_byte_array_uget(v_support_1396_, v___x_1535_);
v___x_1537_ = lean_uint8_to_uint64(v___x_1536_);
v___x_1538_ = 16ULL;
v___x_1539_ = lean_uint64_shift_left(v___x_1537_, v___x_1538_);
v___x_1540_ = lean_uint64_lor(v___x_1534_, v___x_1539_);
v___x_1541_ = ((size_t)3ULL);
v___x_1542_ = lean_byte_array_uget(v_support_1396_, v___x_1541_);
v___x_1543_ = lean_uint8_to_uint64(v___x_1542_);
v___x_1544_ = 24ULL;
v___x_1545_ = lean_uint64_shift_left(v___x_1543_, v___x_1544_);
v___x_1546_ = lean_uint64_lor(v___x_1540_, v___x_1545_);
v___x_1547_ = lean_uint64_to_nat(v___x_1546_);
v___y_1441_ = v___x_1547_;
goto v___jp_1440_;
}
}
}
}
}
else
{
lean_object* v___x_1595_; lean_object* v___x_1596_; 
lean_dec(v_work_1391_);
lean_del_object(v___x_1267_);
lean_dec(v_gmPairs_1265_);
lean_dec(v_chainPairs_1264_);
lean_dec(v_productPairs_1263_);
lean_dec(v_largestBatch_1262_);
lean_dec(v_peakMatrixEntries_1261_);
lean_dec(v_peakMatrixRows_1260_);
lean_dec(v_matrixCalls_1259_);
lean_dec(v_matrixRows_1258_);
lean_dec(v_matrixEntries_1257_);
lean_dec(v_rounds_1256_);
lean_dec(v_pairs_1255_);
lean_dec(v_allocatedBytes_1254_);
lean_dec_ref(v_cache_1240_);
lean_dec(v_multiplier_1234_);
lean_dec_ref(v_base_1233_);
lean_dec_ref(v_limits_1231_);
lean_dec_ref(v_context_1230_);
v___x_1595_ = ((lean_object*)(lp_Hex_Hex_Groebner_ReducerCache_multiply___closed__1));
v___x_1596_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1596_, 0, v___x_1595_);
lean_ctor_set(v___x_1596_, 1, v_a_1235_);
return v___x_1596_;
}
v___jp_1272_:
{
lean_object* v___x_1279_; lean_object* v___x_1280_; lean_object* v___x_1281_; uint8_t v___x_1282_; 
v___x_1279_ = lean_nat_add(v___y_1276_, v___y_1278_);
lean_dec(v___y_1278_);
lean_dec(v___y_1276_);
v___x_1280_ = lean_unsigned_to_nat(8u);
v___x_1281_ = lean_nat_add(v___x_1279_, v___x_1280_);
lean_dec(v___x_1279_);
v___x_1282_ = lean_nat_dec_le(v___x_1281_, v_packedBytes_1270_);
lean_dec(v___x_1281_);
if (v___x_1282_ == 0)
{
lean_dec_ref(v___y_1277_);
lean_dec_ref(v_base_1233_);
lean_dec_ref(v_limits_1231_);
lean_dec_ref(v_context_1230_);
v___y_1242_ = v___y_1273_;
v___y_1243_ = v___y_1274_;
goto v___jp_1241_;
}
else
{
lean_object* v___x_1283_; lean_object* v_fst_1284_; 
lean_dec_ref(v_cache_1240_);
v___x_1283_ = lp_Hex_Hex_Groebner_Computation_allocate(v_limits_1231_, v___x_1280_, v___y_1273_);
lean_dec_ref(v_limits_1231_);
v_fst_1284_ = lean_ctor_get(v___x_1283_, 0);
lean_inc(v_fst_1284_);
if (lean_obj_tag(v_fst_1284_) == 0)
{
lean_object* v_snd_1285_; lean_object* v___x_1287_; uint8_t v_isShared_1288_; uint8_t v_isSharedCheck_1300_; 
lean_dec_ref(v___y_1277_);
lean_dec_ref(v___y_1274_);
lean_dec_ref(v_base_1233_);
lean_dec_ref(v_context_1230_);
v_snd_1285_ = lean_ctor_get(v___x_1283_, 1);
v_isSharedCheck_1300_ = !lean_is_exclusive(v___x_1283_);
if (v_isSharedCheck_1300_ == 0)
{
lean_object* v_unused_1301_; 
v_unused_1301_ = lean_ctor_get(v___x_1283_, 0);
lean_dec(v_unused_1301_);
v___x_1287_ = v___x_1283_;
v_isShared_1288_ = v_isSharedCheck_1300_;
goto v_resetjp_1286_;
}
else
{
lean_inc(v_snd_1285_);
lean_dec(v___x_1283_);
v___x_1287_ = lean_box(0);
v_isShared_1288_ = v_isSharedCheck_1300_;
goto v_resetjp_1286_;
}
v_resetjp_1286_:
{
lean_object* v_a_1289_; lean_object* v___x_1291_; uint8_t v_isShared_1292_; uint8_t v_isSharedCheck_1299_; 
v_a_1289_ = lean_ctor_get(v_fst_1284_, 0);
v_isSharedCheck_1299_ = !lean_is_exclusive(v_fst_1284_);
if (v_isSharedCheck_1299_ == 0)
{
v___x_1291_ = v_fst_1284_;
v_isShared_1292_ = v_isSharedCheck_1299_;
goto v_resetjp_1290_;
}
else
{
lean_inc(v_a_1289_);
lean_dec(v_fst_1284_);
v___x_1291_ = lean_box(0);
v_isShared_1292_ = v_isSharedCheck_1299_;
goto v_resetjp_1290_;
}
v_resetjp_1290_:
{
lean_object* v___x_1294_; 
if (v_isShared_1292_ == 0)
{
v___x_1294_ = v___x_1291_;
goto v_reusejp_1293_;
}
else
{
lean_object* v_reuseFailAlloc_1298_; 
v_reuseFailAlloc_1298_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1298_, 0, v_a_1289_);
v___x_1294_ = v_reuseFailAlloc_1298_;
goto v_reusejp_1293_;
}
v_reusejp_1293_:
{
lean_object* v___x_1296_; 
if (v_isShared_1288_ == 0)
{
lean_ctor_set(v___x_1287_, 0, v___x_1294_);
v___x_1296_ = v___x_1287_;
goto v_reusejp_1295_;
}
else
{
lean_object* v_reuseFailAlloc_1297_; 
v_reuseFailAlloc_1297_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1297_, 0, v___x_1294_);
lean_ctor_set(v_reuseFailAlloc_1297_, 1, v_snd_1285_);
v___x_1296_ = v_reuseFailAlloc_1297_;
goto v_reusejp_1295_;
}
v_reusejp_1295_:
{
return v___x_1296_;
}
}
}
}
}
else
{
lean_object* v_snd_1302_; lean_object* v___x_1304_; uint8_t v_isShared_1305_; uint8_t v_isSharedCheck_1322_; 
v_snd_1302_ = lean_ctor_get(v___x_1283_, 1);
v_isSharedCheck_1322_ = !lean_is_exclusive(v___x_1283_);
if (v_isSharedCheck_1322_ == 0)
{
lean_object* v_unused_1323_; 
v_unused_1323_ = lean_ctor_get(v___x_1283_, 0);
lean_dec(v_unused_1323_);
v___x_1304_ = v___x_1283_;
v_isShared_1305_ = v_isSharedCheck_1322_;
goto v_resetjp_1303_;
}
else
{
lean_inc(v_snd_1302_);
lean_dec(v___x_1283_);
v___x_1304_ = lean_box(0);
v_isShared_1305_ = v_isSharedCheck_1322_;
goto v_resetjp_1303_;
}
v_resetjp_1303_:
{
lean_object* v___x_1307_; uint8_t v_isShared_1308_; uint8_t v_isSharedCheck_1320_; 
v_isSharedCheck_1320_ = !lean_is_exclusive(v_fst_1284_);
if (v_isSharedCheck_1320_ == 0)
{
lean_object* v_unused_1321_; 
v_unused_1321_ = lean_ctor_get(v_fst_1284_, 0);
lean_dec(v_unused_1321_);
v___x_1307_ = v_fst_1284_;
v_isShared_1308_ = v_isSharedCheck_1320_;
goto v_resetjp_1306_;
}
else
{
lean_dec(v_fst_1284_);
v___x_1307_ = lean_box(0);
v_isShared_1308_ = v_isSharedCheck_1320_;
goto v_resetjp_1306_;
}
v_resetjp_1306_:
{
lean_object* v___x_1309_; lean_object* v___x_1310_; lean_object* v___x_1311_; lean_object* v___x_1312_; lean_object* v___x_1314_; 
v___x_1309_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1309_, 0, v_context_1230_);
lean_inc_ref(v___y_1274_);
v___x_1310_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1310_, 0, v_base_1233_);
lean_ctor_set(v___x_1310_, 1, v___y_1274_);
v___x_1311_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0___redArg(v___y_1277_, v___y_1275_, v___x_1310_);
v___x_1312_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1312_, 0, v___x_1309_);
lean_ctor_set(v___x_1312_, 1, v___x_1311_);
if (v_isShared_1305_ == 0)
{
lean_ctor_set(v___x_1304_, 1, v___x_1312_);
lean_ctor_set(v___x_1304_, 0, v___y_1274_);
v___x_1314_ = v___x_1304_;
goto v_reusejp_1313_;
}
else
{
lean_object* v_reuseFailAlloc_1319_; 
v_reuseFailAlloc_1319_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1319_, 0, v___y_1274_);
lean_ctor_set(v_reuseFailAlloc_1319_, 1, v___x_1312_);
v___x_1314_ = v_reuseFailAlloc_1319_;
goto v_reusejp_1313_;
}
v_reusejp_1313_:
{
lean_object* v___x_1316_; 
if (v_isShared_1308_ == 0)
{
lean_ctor_set(v___x_1307_, 0, v___x_1314_);
v___x_1316_ = v___x_1307_;
goto v_reusejp_1315_;
}
else
{
lean_object* v_reuseFailAlloc_1318_; 
v_reuseFailAlloc_1318_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1318_, 0, v___x_1314_);
v___x_1316_ = v_reuseFailAlloc_1318_;
goto v_reusejp_1315_;
}
v_reusejp_1315_:
{
lean_object* v___x_1317_; 
v___x_1317_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1317_, 0, v___x_1316_);
lean_ctor_set(v___x_1317_, 1, v_snd_1302_);
return v___x_1317_;
}
}
}
}
}
}
}
v___jp_1324_:
{
uint8_t v___x_1333_; 
v___x_1333_ = lean_nat_dec_le(v___y_1328_, v___y_1332_);
if (v___x_1333_ == 0)
{
lean_object* v___x_1334_; 
lean_dec(v___y_1332_);
v___x_1334_ = lean_nat_add(v___y_1325_, v___y_1328_);
lean_dec(v___y_1328_);
lean_dec(v___y_1325_);
v___y_1273_ = v___y_1326_;
v___y_1274_ = v___y_1327_;
v___y_1275_ = v___y_1329_;
v___y_1276_ = v___y_1330_;
v___y_1277_ = v___y_1331_;
v___y_1278_ = v___x_1334_;
goto v___jp_1272_;
}
else
{
lean_object* v___x_1335_; 
lean_dec(v___y_1328_);
v___x_1335_ = lean_nat_add(v___y_1325_, v___y_1332_);
lean_dec(v___y_1332_);
lean_dec(v___y_1325_);
v___y_1273_ = v___y_1326_;
v___y_1274_ = v___y_1327_;
v___y_1275_ = v___y_1329_;
v___y_1276_ = v___y_1330_;
v___y_1277_ = v___y_1331_;
v___y_1278_ = v___x_1335_;
goto v___jp_1272_;
}
}
v___jp_1336_:
{
lean_object* v_statistics_1341_; lean_object* v_table_1342_; lean_object* v_allocatedBytes_1343_; lean_object* v_arity_1344_; lean_object* v_exponents_1345_; lean_object* v_metadata_1346_; lean_object* v_count_1347_; lean_object* v_workspace_1348_; lean_object* v___x_1349_; lean_object* v___x_1350_; lean_object* v___x_1351_; lean_object* v___x_1352_; uint8_t v___x_1353_; 
v_statistics_1341_ = lean_ctor_get(v___y_1337_, 1);
v_table_1342_ = lean_ctor_get(v___y_1337_, 0);
v_allocatedBytes_1343_ = lean_ctor_get(v_statistics_1341_, 1);
lean_inc(v_allocatedBytes_1343_);
v_arity_1344_ = lean_ctor_get(v_table_1342_, 0);
v_exponents_1345_ = lean_ctor_get(v_table_1342_, 1);
v_metadata_1346_ = lean_ctor_get(v_table_1342_, 2);
v_count_1347_ = lean_ctor_get(v_table_1342_, 3);
v_workspace_1348_ = lean_ctor_get(v_table_1342_, 4);
v___x_1349_ = lean_byte_array_size(v_exponents_1345_);
v___x_1350_ = lean_byte_array_size(v_metadata_1346_);
v___x_1351_ = lean_nat_add(v___x_1349_, v___x_1350_);
v___x_1352_ = lean_byte_array_size(v_workspace_1348_);
v___x_1353_ = lean_nat_dec_eq(v_count_1347_, v___x_1251_);
if (v___x_1353_ == 0)
{
uint8_t v___x_1354_; 
v___x_1354_ = lean_nat_dec_lt(v___x_1251_, v_arity_1344_);
if (v___x_1354_ == 0)
{
v___y_1325_ = v___x_1351_;
v___y_1326_ = v___y_1337_;
v___y_1327_ = v___y_1338_;
v___y_1328_ = v___x_1352_;
v___y_1329_ = v___y_1339_;
v___y_1330_ = v_allocatedBytes_1343_;
v___y_1331_ = v___y_1340_;
v___y_1332_ = v___x_1251_;
goto v___jp_1324_;
}
else
{
lean_object* v___x_1355_; uint8_t v___x_1356_; 
v___x_1355_ = lean_unsigned_to_nat(4096u);
v___x_1356_ = lean_nat_dec_le(v_arity_1344_, v___x_1355_);
if (v___x_1356_ == 0)
{
v___y_1325_ = v___x_1351_;
v___y_1326_ = v___y_1337_;
v___y_1327_ = v___y_1338_;
v___y_1328_ = v___x_1352_;
v___y_1329_ = v___y_1339_;
v___y_1330_ = v_allocatedBytes_1343_;
v___y_1331_ = v___y_1340_;
v___y_1332_ = v___x_1251_;
goto v___jp_1324_;
}
else
{
lean_object* v___x_1357_; lean_object* v___x_1358_; lean_object* v___x_1359_; lean_object* v___x_1360_; 
v___x_1357_ = lean_unsigned_to_nat(4u);
v___x_1358_ = lean_nat_mul(v_arity_1344_, v___x_1357_);
v___x_1359_ = lean_unsigned_to_nat(28u);
v___x_1360_ = lean_nat_add(v___x_1358_, v___x_1359_);
lean_dec(v___x_1358_);
v___y_1325_ = v___x_1351_;
v___y_1326_ = v___y_1337_;
v___y_1327_ = v___y_1338_;
v___y_1328_ = v___x_1352_;
v___y_1329_ = v___y_1339_;
v___y_1330_ = v_allocatedBytes_1343_;
v___y_1331_ = v___y_1340_;
v___y_1332_ = v___x_1360_;
goto v___jp_1324_;
}
}
}
else
{
v___y_1325_ = v___x_1351_;
v___y_1326_ = v___y_1337_;
v___y_1327_ = v___y_1338_;
v___y_1328_ = v___x_1352_;
v___y_1329_ = v___y_1339_;
v___y_1330_ = v_allocatedBytes_1343_;
v___y_1331_ = v___y_1340_;
v___y_1332_ = v___x_1251_;
goto v___jp_1324_;
}
}
v___jp_1361_:
{
lean_object* v___x_1364_; lean_object* v_fst_1365_; 
lean_inc_ref(v_base_1233_);
lean_inc_ref(v_limits_1231_);
v___x_1364_ = lp_Hex_Hex_Groebner_Polynomial_multiply___redArg(v_limits_1231_, v_base_1233_, v_multiplier_1234_, v___y_1363_);
v_fst_1365_ = lean_ctor_get(v___x_1364_, 0);
lean_inc(v_fst_1365_);
if (lean_obj_tag(v_fst_1365_) == 0)
{
lean_object* v_snd_1366_; lean_object* v___x_1368_; uint8_t v_isShared_1369_; uint8_t v_isSharedCheck_1381_; 
lean_dec_ref(v_cache_1240_);
lean_dec_ref(v_base_1233_);
lean_dec_ref(v_limits_1231_);
lean_dec_ref(v_context_1230_);
v_snd_1366_ = lean_ctor_get(v___x_1364_, 1);
v_isSharedCheck_1381_ = !lean_is_exclusive(v___x_1364_);
if (v_isSharedCheck_1381_ == 0)
{
lean_object* v_unused_1382_; 
v_unused_1382_ = lean_ctor_get(v___x_1364_, 0);
lean_dec(v_unused_1382_);
v___x_1368_ = v___x_1364_;
v_isShared_1369_ = v_isSharedCheck_1381_;
goto v_resetjp_1367_;
}
else
{
lean_inc(v_snd_1366_);
lean_dec(v___x_1364_);
v___x_1368_ = lean_box(0);
v_isShared_1369_ = v_isSharedCheck_1381_;
goto v_resetjp_1367_;
}
v_resetjp_1367_:
{
lean_object* v_a_1370_; lean_object* v___x_1372_; uint8_t v_isShared_1373_; uint8_t v_isSharedCheck_1380_; 
v_a_1370_ = lean_ctor_get(v_fst_1365_, 0);
v_isSharedCheck_1380_ = !lean_is_exclusive(v_fst_1365_);
if (v_isSharedCheck_1380_ == 0)
{
v___x_1372_ = v_fst_1365_;
v_isShared_1373_ = v_isSharedCheck_1380_;
goto v_resetjp_1371_;
}
else
{
lean_inc(v_a_1370_);
lean_dec(v_fst_1365_);
v___x_1372_ = lean_box(0);
v_isShared_1373_ = v_isSharedCheck_1380_;
goto v_resetjp_1371_;
}
v_resetjp_1371_:
{
lean_object* v___x_1375_; 
if (v_isShared_1373_ == 0)
{
v___x_1375_ = v___x_1372_;
goto v_reusejp_1374_;
}
else
{
lean_object* v_reuseFailAlloc_1379_; 
v_reuseFailAlloc_1379_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1379_, 0, v_a_1370_);
v___x_1375_ = v_reuseFailAlloc_1379_;
goto v_reusejp_1374_;
}
v_reusejp_1374_:
{
lean_object* v___x_1377_; 
if (v_isShared_1369_ == 0)
{
lean_ctor_set(v___x_1368_, 0, v___x_1375_);
v___x_1377_ = v___x_1368_;
goto v_reusejp_1376_;
}
else
{
lean_object* v_reuseFailAlloc_1378_; 
v_reuseFailAlloc_1378_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1378_, 0, v___x_1375_);
lean_ctor_set(v_reuseFailAlloc_1378_, 1, v_snd_1366_);
v___x_1377_ = v_reuseFailAlloc_1378_;
goto v_reusejp_1376_;
}
v_reusejp_1376_:
{
return v___x_1377_;
}
}
}
}
}
else
{
lean_object* v_rows_1383_; lean_object* v_snd_1384_; lean_object* v_a_1385_; lean_object* v_size_1386_; lean_object* v___x_1387_; uint8_t v___x_1388_; 
v_rows_1383_ = lean_ctor_get(v_cache_1240_, 1);
lean_inc_ref(v_rows_1383_);
v_snd_1384_ = lean_ctor_get(v___x_1364_, 1);
lean_inc(v_snd_1384_);
lean_dec_ref(v___x_1364_);
v_a_1385_ = lean_ctor_get(v_fst_1365_, 0);
lean_inc(v_a_1385_);
lean_dec_ref_known(v_fst_1365_, 1);
v_size_1386_ = lean_ctor_get(v_rows_1383_, 0);
v___x_1387_ = lean_unsigned_to_nat(16384u);
v___x_1388_ = lean_nat_dec_lt(v_size_1386_, v___x_1387_);
if (v___x_1388_ == 0)
{
uint8_t v___x_1389_; 
v___x_1389_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1___redArg(v_rows_1383_, v___y_1362_);
if (v___x_1389_ == 0)
{
lean_dec_ref(v_rows_1383_);
lean_dec_ref(v_base_1233_);
lean_dec_ref(v_limits_1231_);
lean_dec_ref(v_context_1230_);
v___y_1242_ = v_snd_1384_;
v___y_1243_ = v_a_1385_;
goto v___jp_1241_;
}
else
{
v___y_1337_ = v_snd_1384_;
v___y_1338_ = v_a_1385_;
v___y_1339_ = v___y_1362_;
v___y_1340_ = v_rows_1383_;
goto v___jp_1336_;
}
}
else
{
v___y_1337_ = v_snd_1384_;
v___y_1338_ = v_a_1385_;
v___y_1339_ = v___y_1362_;
v___y_1340_ = v_rows_1383_;
goto v___jp_1336_;
}
}
}
}
}
else
{
lean_object* v___x_1598_; lean_object* v___x_1599_; lean_object* v___x_1600_; 
lean_dec_ref(v_statistics_1237_);
lean_dec(v_multiplier_1234_);
lean_dec_ref(v_limits_1231_);
lean_dec_ref(v_context_1230_);
v___x_1598_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1598_, 0, v_base_1233_);
lean_ctor_set(v___x_1598_, 1, v_cache_1240_);
v___x_1599_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1599_, 0, v___x_1598_);
v___x_1600_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1600_, 0, v___x_1599_);
lean_ctor_set(v___x_1600_, 1, v_a_1235_);
return v___x_1600_;
}
v___jp_1241_:
{
lean_object* v___x_1244_; lean_object* v___x_1245_; lean_object* v___x_1246_; 
v___x_1244_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1244_, 0, v___y_1243_);
lean_ctor_set(v___x_1244_, 1, v_cache_1240_);
v___x_1245_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1245_, 0, v___x_1244_);
v___x_1246_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1246_, 0, v___x_1245_);
lean_ctor_set(v___x_1246_, 1, v___y_1242_);
return v___x_1246_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0(lean_object* v_00_u03b2_1601_, lean_object* v_m_1602_, uint64_t v_a_1603_, lean_object* v_b_1604_){
_start:
{
lean_object* v___x_1605_; 
v___x_1605_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0___redArg(v_m_1602_, v_a_1603_, v_b_1604_);
return v___x_1605_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0___boxed(lean_object* v_00_u03b2_1606_, lean_object* v_m_1607_, lean_object* v_a_1608_, lean_object* v_b_1609_){
_start:
{
uint64_t v_a_boxed_1610_; lean_object* v_res_1611_; 
v_a_boxed_1610_ = lean_unbox_uint64(v_a_1608_);
lean_dec_ref(v_a_1608_);
v_res_1611_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0(v_00_u03b2_1606_, v_m_1607_, v_a_boxed_1610_, v_b_1609_);
return v_res_1611_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1(lean_object* v_00_u03b2_1612_, lean_object* v_m_1613_, uint64_t v_a_1614_){
_start:
{
uint8_t v___x_1615_; 
v___x_1615_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1___redArg(v_m_1613_, v_a_1614_);
return v___x_1615_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1___boxed(lean_object* v_00_u03b2_1616_, lean_object* v_m_1617_, lean_object* v_a_1618_){
_start:
{
uint64_t v_a_boxed_1619_; uint8_t v_res_1620_; lean_object* v_r_1621_; 
v_a_boxed_1619_ = lean_unbox_uint64(v_a_1618_);
lean_dec_ref(v_a_1618_);
v_res_1620_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_contains___at___00Hex_Groebner_ReducerCache_multiply_spec__1(v_00_u03b2_1616_, v_m_1617_, v_a_boxed_1619_);
lean_dec_ref(v_m_1617_);
v_r_1621_ = lean_box(v_res_1620_);
return v_r_1621_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2(lean_object* v_00_u03b2_1622_, lean_object* v_m_1623_, uint64_t v_a_1624_){
_start:
{
lean_object* v___x_1625_; 
v___x_1625_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2___redArg(v_m_1623_, v_a_1624_);
return v___x_1625_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2___boxed(lean_object* v_00_u03b2_1626_, lean_object* v_m_1627_, lean_object* v_a_1628_){
_start:
{
uint64_t v_a_boxed_1629_; lean_object* v_res_1630_; 
v_a_boxed_1629_ = lean_unbox_uint64(v_a_1628_);
lean_dec_ref(v_a_1628_);
v_res_1630_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2(v_00_u03b2_1626_, v_m_1627_, v_a_boxed_1629_);
lean_dec_ref(v_m_1627_);
return v_res_1630_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0(lean_object* v_00_u03b2_1631_, uint64_t v_a_1632_, lean_object* v_x_1633_){
_start:
{
uint8_t v___x_1634_; 
v___x_1634_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___redArg(v_a_1632_, v_x_1633_);
return v___x_1634_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0___boxed(lean_object* v_00_u03b2_1635_, lean_object* v_a_1636_, lean_object* v_x_1637_){
_start:
{
uint64_t v_a_boxed_1638_; uint8_t v_res_1639_; lean_object* v_r_1640_; 
v_a_boxed_1638_ = lean_unbox_uint64(v_a_1636_);
lean_dec_ref(v_a_1636_);
v_res_1639_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__0(v_00_u03b2_1635_, v_a_boxed_1638_, v_x_1637_);
lean_dec(v_x_1637_);
v_r_1640_ = lean_box(v_res_1639_);
return v_r_1640_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1(lean_object* v_00_u03b2_1641_, lean_object* v_data_1642_){
_start:
{
lean_object* v___x_1643_; 
v___x_1643_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1___redArg(v_data_1642_);
return v___x_1643_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2(lean_object* v_00_u03b2_1644_, uint64_t v_a_1645_, lean_object* v_b_1646_, lean_object* v_x_1647_){
_start:
{
lean_object* v___x_1648_; 
v___x_1648_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___redArg(v_a_1645_, v_b_1646_, v_x_1647_);
return v___x_1648_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2___boxed(lean_object* v_00_u03b2_1649_, lean_object* v_a_1650_, lean_object* v_b_1651_, lean_object* v_x_1652_){
_start:
{
uint64_t v_a_boxed_1653_; lean_object* v_res_1654_; 
v_a_boxed_1653_ = lean_unbox_uint64(v_a_1650_);
lean_dec_ref(v_a_1650_);
v_res_1654_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__2(v_00_u03b2_1649_, v_a_boxed_1653_, v_b_1651_, v_x_1652_);
return v_res_1654_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5(lean_object* v_00_u03b2_1655_, uint64_t v_a_1656_, lean_object* v_x_1657_){
_start:
{
lean_object* v___x_1658_; 
v___x_1658_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5___redArg(v_a_1656_, v_x_1657_);
return v___x_1658_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5___boxed(lean_object* v_00_u03b2_1659_, lean_object* v_a_1660_, lean_object* v_x_1661_){
_start:
{
uint64_t v_a_boxed_1662_; lean_object* v_res_1663_; 
v_a_boxed_1662_ = lean_unbox_uint64(v_a_1660_);
lean_dec_ref(v_a_1660_);
v_res_1663_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_ReducerCache_multiply_spec__2_spec__5(v_00_u03b2_1659_, v_a_boxed_1662_, v_x_1661_);
lean_dec(v_x_1661_);
return v_res_1663_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2(lean_object* v_00_u03b2_1664_, lean_object* v_i_1665_, lean_object* v_source_1666_, lean_object* v_target_1667_){
_start:
{
lean_object* v___x_1668_; 
v___x_1668_ = lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2___redArg(v_i_1665_, v_source_1666_, v_target_1667_);
return v___x_1668_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2_spec__5(lean_object* v_00_u03b2_1669_, lean_object* v_x_1670_, lean_object* v_x_1671_){
_start:
{
lean_object* v___x_1672_; 
v___x_1672_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_ReducerCache_multiply_spec__0_spec__1_spec__2_spec__5___redArg(v_x_1670_, v_x_1671_);
return v___x_1672_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Polynomial(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_ReducerCache(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Polynomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_Groebner_ReducerCache_empty = _init_lp_Hex_Hex_Groebner_ReducerCache_empty();
lean_mark_persistent(lp_Hex_Hex_Groebner_ReducerCache_empty);
lp_Hex_Hex_Groebner_ReducerCache_instInhabited = _init_lp_Hex_Hex_Groebner_ReducerCache_instInhabited();
lean_mark_persistent(lp_Hex_Hex_Groebner_ReducerCache_instInhabited);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_ReducerCache(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Polynomial(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_ReducerCache(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Polynomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_ReducerCache(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_ReducerCache(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_ReducerCache(builtin);
}
#ifdef __cplusplus
}
#endif
