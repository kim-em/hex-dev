#!/usr/bin/env bash
set -euo pipefail
cd /tmp/hex-groebner-hotloop-review
for arena_compiler in clang gcc; do
  arena_cc=cc
  if [ "$arena_compiler" = gcc ]; then arena_cc=/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/gcc; fi
  for arena_sanitize in 0 1; do
    arena_prefix=/tmp/issue-10987-pr10999-arena-canonical-${arena_compiler}-${arena_sanitize}
    CC="$arena_cc" HEX_GROEBNER_SANITIZE="$arena_sanitize" HEX_GROEBNER_REQUIRE_AVX2=1 HEX_GROEBNER_NATIVE_LOG_DIR="$arena_prefix" HEX_GROEBNER_TEST_LOADER=/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2 HEX_GROEBNER_TEST_LIBRARY_PATH=/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib bash scripts/ci/check_groebner_rows.sh > "$arena_prefix.log" 2>&1
  done
done
