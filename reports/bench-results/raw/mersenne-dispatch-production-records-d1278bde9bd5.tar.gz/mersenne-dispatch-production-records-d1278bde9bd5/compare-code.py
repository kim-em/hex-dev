from pathlib import Path
import subprocess,re,json,hashlib
base=Path(__file__).resolve().parent
paths={'A':base/'binaries/hexgroebner-bench-mersenne-dispatch-baseline','B':base/'binaries/hexgroebner-bench-mersenne-dispatch'}
out=base/'code-comparison';out.mkdir(exist_ok=False);summary={}
for fn in ['hex_scan_avx2_u8','hex_scan_avx2_u16','hex_scan_avx2']:
 normalized={}
 for arm,p in paths.items():
  command=['objdump','-d','-w','--no-show-raw-insn','--disassemble='+fn,str(p)]
  s=subprocess.check_output(command,text=True);(out/(arm+'-'+fn+'.txt')).write_text(s);lines=[]
  for l in s.splitlines():
   m=re.match(r'\s*([0-9a-f]+):\s+(.*)',l)
   if not m:continue
   asm=m[2].split('#',1)[0].strip()
   asm=re.sub(r'\b[0-9a-f]+\s+<([^>]+)>',r'<\1>',asm)
   asm=re.sub(r'-?0x[0-9a-f]+\(%rip\)','RIP',asm)
   lines.append(asm)
  normalized[arm]=lines;(out/(arm+'-'+fn+'-normalized.txt')).write_text('\n'.join(lines)+'\n')
 summary[fn]={'instructions':{a:len(v) for a,v in normalized.items()},'normalized_equal':normalized['A']==normalized['B'],'differences':[(i,x,y) for i,(x,y) in enumerate(zip(normalized['A'],normalized['B'])) if x!=y][:12]}
summary['scope']='Exploratory comparison; call target addresses and RIP displacements normalized. Equality is not a semantic proof and does not invalidate any timing sample.'
summary['binary_sha256']={a:hashlib.sha256(p.read_bytes()).hexdigest() for a,p in paths.items()};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
