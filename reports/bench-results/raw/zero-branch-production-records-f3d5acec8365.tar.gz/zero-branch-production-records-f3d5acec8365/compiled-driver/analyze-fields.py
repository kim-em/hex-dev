from pathlib import Path
import json,math,statistics,sys
base=Path(sys.argv[1]);analysis=json.loads((base/'diagnostic-analysis.json').read_text());fields={}
for experiment in base.glob('*production-records-*'):
 for row in json.loads((experiment/'metadata.json').read_text())['samples']:fields[row['case']]=row['p']
groups={}
for row in analysis['pairs']:groups.setdefault(str(fields[row['case']]),[]).append(row)
result={p:dict(pairs=len(rows),candidate_geomean=math.exp(sum(math.log(r['candidate_ratio']) for r in rows)/len(rows)),candidate_median=statistics.median(r['candidate_ratio'] for r in rows),candidate_minimum=min(r['candidate_ratio'] for r in rows),candidate_maximum=max(r['candidate_ratio'] for r in rows),process_geomean=math.exp(sum(math.log(r['process_ratio']) for r in rows)/len(rows))) for p,rows in groups.items()}
(base/'field-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
