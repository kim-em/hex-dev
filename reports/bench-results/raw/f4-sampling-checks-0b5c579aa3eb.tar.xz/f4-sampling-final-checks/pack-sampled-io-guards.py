from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile,sys
state=Path('/home/kim/tmp/issue-10987');root=Path.cwd();payload={};sys.path.insert(0,str(root))
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();runtime=tree_listing(FAMILY,'HEAD');checks=tree_listing(CHECKS,'HEAD');measured=json.loads((state/'sampled-io-production/manifest.json').read_text());assert runtime==measured['source_manifest']
def add(name,path):
 assert name not in payload
 payload[name]=path.read_bytes()
for name,path in [('native-status.json','sampled-io-native-status.json'),('full-status.json','sampled-io-full-status.json'),('full-checks.py','sampled-io-full-checks.py'),('native-checks.py','sampled-io-native-checks.py')]:add(name,state/path)
payload['final-source.manifest']=runtime.encode();payload['checks-source.manifest']=checks.encode()
for line in checks.splitlines():
 _,oid,rest=line.split(' ',2);_,name=rest.split('\t');payload['checks-sources/'+name]=subprocess.check_output(['git','cat-file','blob',oid])
for row in json.loads((state/'sampled-io-full-status.json').read_text()):
 assert row['exit_code']==0 and row['checks_fingerprint']==identity['checks_fingerprint']
 add(row['name']+'.log',Path(row['log']))
for compiler in ['clang','gcc']:
 add(compiler+'.log',state/f'sampled-io-{compiler}.log')
 for path in sorted((state/f'sampled-io-{compiler}').glob('*')):
  if path.is_file():add('probes/'+compiler+'/'+path.name,path)
add('report-generator.py',Path('scripts/bench/groebner_sampling_report.py'))
payload['implementation.patch']=subprocess.check_output(['git','diff','origin/main...HEAD','--no-ext-diff'])
add('pack-sampled-io-guards.py',Path(__file__))
manifest={k:hashlib.sha256(v).hexdigest()for k,v in sorted(payload.items())};payload['sha256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=Path('reports/bench-results/raw')/f'f4-sampling-checks-{identity["checks_fingerprint"]}.tar.xz'
with lzma.open(out,'wb',preset=6)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-sampling-final-checks/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
