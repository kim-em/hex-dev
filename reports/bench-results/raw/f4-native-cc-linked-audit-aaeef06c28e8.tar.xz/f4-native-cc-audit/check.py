import hashlib,json,subprocess
from pathlib import Path
s=Path('/home/kim/tmp/issue-10987');w=Path.cwd();out=s/'native-cc-review-audit';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result={'gcc':[]}
meta=json.loads((s/'native-cc-option-production/f4/metadata.json').read_text())
for row in meta['samples']:
 if row['block']!=0 or row['arm']!='B':continue
 case=row['case'];cmd=row['command'][5:];cmd[0]=str(s/'native-cc-gcc-production/binaries/compute')
 before=sha(Path(cmd[0]));p=subprocess.run(cmd,capture_output=True);after=sha(Path(cmd[0]));assert before==after;(out/(case+'.stdout')).write_bytes(p.stdout);(out/(case+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==0,(case,p.stderr[-500:])
 got=json.loads(p.stdout);expected=json.loads((s/'native-cc-option-production/f4'/(case+'-b0-B.stdout')).read_text())
 for d in [got,expected]:d.pop('candidateNanos',None)
 assert got==expected,case
 result['gcc'].append({'case':case,'command':cmd,'exit_code':p.returncode,'binary_sha256_before':before,'binary_sha256_after':after,'output_sha256':sha(out/(case+'.stdout')),'complete_non_time_equal':True})
 print(case,flush=True)
result['gcc_binary_sha256']=sha(s/'native-cc-gcc-production/binaries/compute')
result['gcc_object_comments']=json.loads((out/'targeted-status.json').read_text())['gcc_object_comments']
alias=s/'native-cc-alias/clang-alias';driver=alias.resolve()
result['alias_negative_exit']=subprocess.run([str(driver),'--version'],capture_output=True).returncode
assert result['alias_negative_exit']==47
p=subprocess.run([str(alias),'--version'],capture_output=True,text=True);assert p.returncode==0
result['alias_version']=p.stdout;result['alias_command']=str(alias);result['alias_target']=str(driver)
(out/'targeted-status.json').write_text(json.dumps(result,indent=2)+'\n')
