from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import source_identity
identity=source_identity();base=state/'native-cc-review-audit';payload={}
def add(name,path):payload[name]=path.read_bytes()
status=json.loads((base/'targeted-status.json').read_text());names={'compute':'hexgroebner_compute','compute-reference':'hexgroebner_compute_full','bench':'hexgroebner_bench'}
status['default_binary_sha256']={k:hashlib.sha256((root/'.lake/build/bin'/n).read_bytes()).hexdigest()for k,n in names.items()}
expected=json.loads((state/'avx512-default-production/manifest.json').read_text())['binary_sha256'];assert status['default_binary_sha256']==expected
(base/'targeted-status.json').write_text(json.dumps(status,indent=2)+'\n')
for p in sorted(base.iterdir()):
 if p.is_file():add(p.name,p)
frozen=state/'native-cc-alias-production'
for p in sorted(frozen.rglob('*')):
 if p.is_file()and'binaries'not in p.relative_to(frozen).parts:add('alias/'+str(p.relative_to(frozen)),p)
for name,path in [('gcc-build.log',state/'native-cc-gcc-production/build.log'),('default-build.log',state/'native-cc-review-default-build.log'),('check.py',state/'check-native-cc-linked.py'),('compiler-driver',state/'native-cc-alias/driver'),('pack.py',Path(__file__))]:add(name,path)
for p in sorted((state/'native-cc-gcc-production').rglob('*')):
 if p.is_file()and'binaries'not in p.relative_to(state/'native-cc-gcc-production').parts:add('gcc/'+str(p.relative_to(state/'native-cc-gcc-production')),p)
add('cache-status.json',state/'native-compiler-option-final-cache-status.json')
add('cache-check.py',state/'check-native-compiler-option-final.py')
for label in ['default','clang','cached','gcc','restored']:add('cache/'+label+'.log',state/f'native-compiler-option-final-{label}.log')
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode()
out=root/'reports/bench-results/raw'/('f4-native-cc-linked-audit-'+identity['source_fingerprint']+'.tar.xz')
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-native-cc-audit/'+n);entry.size=len(b);entry.mode=0o644;tar.addfile(entry,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size)
