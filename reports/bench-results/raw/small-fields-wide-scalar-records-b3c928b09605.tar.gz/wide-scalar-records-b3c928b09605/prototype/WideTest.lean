import WideF4
import HexGroebner.F4Fixtures
import HexGroebner.ScanConformance

open Hex.Groebner
open Hex.Groebner.ScanConformance (packed)

private def scanEq (a b : Wide.Scan.Result) : Bool :=
  a.state.dense.data == b.state.dense.data && a.state.column == b.state.column &&
  a.state.last == b.state.last && a.state.chargedUntil == b.state.chargedUntil &&
  a.state.leading == b.state.leading && a.state.pending == b.state.pending &&
  a.state.entry == b.state.entry && a.state.sugar == b.state.sugar &&
  a.state.factor == b.state.factor && a.events == b.events && a.work == b.work &&
  a.reductions == b.reductions && a.traceNodes == b.traceNodes && a.status == b.status

private def gatherEq (a b : Wide.Gather.Result) : Bool :=
  a.state.dense.data == b.state.dense.data && a.state.columns.data == b.state.columns.data &&
  a.state.coefficients.data == b.state.coefficients.data && a.state.cursor == b.state.cursor &&
  a.entries == b.entries && a.bytes == b.bytes && a.work == b.work && a.status == b.status

def primitiveChecks : Bool := Id.run do
  for p in [2,251,257,65521,65537,2147483647] do
    let w := Native.width p
    let support := #[0,2,4,7,15,16,23,29,30]
    let coeff := support.map fun i => if i == 0 then 1 else (i*7919)%(p-1)+1
    let slots := packed 4 (#[1] ++ Array.replicate 30 0)
    for seed in [:5] do
      let dense := packed 8 ((Array.range 31).map fun i =>
        if seed == 0 then i%p else if seed == 1 then 2^64-1-i else
        if seed == 2 then (p-1)*(p-1)*(i+1)%(2^64) else
        if seed == 3 then (2^64-1)/p*p else (i*7919*65537)%p)
      for bad in [:4] do
        let cs := if bad == 1 then support.set! 3 0 else if bad == 2 then support.set! 4 4294967295 else support
        let vs := if bad == 3 then coeff.set! 7 p else coeff
        let pivots : Array Wide.Scan.Pivot := #[⟨packed 4 cs,packed w vs,2^90⟩]
        for pending in [0,1] do
          for quantum in [0,1,2,7,8,31,32,4096,4097] do
            for work in [0,1,31,40,100,2^90] do
              for traces in [0,1,2^90] do
                let state : Wide.Scan.State := {dense,column:=0,last:=30,chargedUntil:=0,pending,factor:=(p-1).toUInt64}
                if !scanEq (Wide.Scan.transition p.toUInt64 slots pivots state quantum work traces true)
                    (Wide.Scan.portable p.toUInt64 slots pivots state quantum work traces true) then return false
      for factor in [1,p-1] do
        for quantum in [0,1,7,31,32,4096,4097] do
          for work in [0,1,30,31,2^90] do
            for bytes in [0,4+w,31*(4+w),2^90] do
              for entries in [0,1,30,31,2^90] do
                let state : Wide.Gather.State := ⟨dense,{},{},0⟩
                if !gatherEq (Wide.Gather.gather p.toUInt64 state 31 quantum entries bytes work factor.toUInt64)
                    (Wide.Gather.portable p.toUInt64 state 31 quantum entries bytes work factor.toUInt64) then return false
  return true

#guard primitiveChecks

def f4Checks : Bool := Id.run do
  for field in Fixtures.fields do
    for order in [TermOrder.lex,.grlex,.grevlex] do
      for c in F4Fixtures.cases field do
        let context : Context := ⟨field,c.variables,order⟩
        let .candidate expected stats := computeWith context {} c.generators | return false
        let .candidate actual usage := Wide.computeWith context {} c.generators | return false
        if actual.polynomials != expected.polynomials then return false
        if usage.work-stats.work != usage.allocatedBytes-stats.allocatedBytes then return false
        if {usage with work:=stats.work,allocatedBytes:=stats.allocatedBytes} != stats then return false
  return true

#guard f4Checks

def main : IO Unit := do
  if primitiveChecks && f4Checks then IO.println "wide delayed-reduction scan/gather and all 567 bases match reference"
  else throw (IO.userError "wide mismatch")
