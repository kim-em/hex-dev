module
public import HexGroebner.Elimination
public import WideNativeScan
public import WideNativeGather
public section
namespace Hex.Groebner.Wide
private abbrev Work := ExceptT MatrixError (StateM MatrixStats)

private def charge (resource : Resource) (amount limit : Nat)
    (getCount : MatrixStats → Nat) (setCount : MatrixStats → Nat → MatrixStats) : Work Unit := do
  let stats ← get
  let count := getCount stats + amount
  if count > limit then throw (.exhausted resource)
  set (setCount stats count)

private def work (limits : MatrixLimits) (amount : Nat) : Work Unit :=
  charge .work amount limits.work (·.work) fun s n => { s with work := n }

private def packedBytes (limits : MatrixLimits) (amount : Nat) : Work Unit :=
  charge .packedBytes amount limits.packedBytes (·.packedBytes)
    fun s n => { s with packedBytes := n }

private def validate (field : PrimeField) (limits : MatrixLimits)
    (columns index : Nat) (row : SparseRow) : Work Unit := do
  work limits 1
  if row.columns.size % 4 != 0 || row.coefficients.size != row.size * field.width.bytes then
    throw (.rowLength index)
  charge .inputEntries row.size limits.inputEntries (·.inputEntries)
    fun s n => { s with inputEntries := n }
  packedBytes limits (row.columns.size + row.coefficients.size)
  work limits row.size
  let mut previous : Option Nat := none
  for i in [:row.size] do
    let column := (Packed.read .u32 row.columns i).toNat
    if column ≥ columns then throw (.column index i)
    if let some p := previous then
      if column ≤ p then throw (.column index i)
    let c := Packed.read field.width row.coefficients i
    if c == 0 || c ≥ field.modulus then throw (.coefficient index i)
    previous := some column

private def zeros (size : Nat) : ByteArray := Id.run do
  let mut data := ByteArray.emptyWithCapacity size
  for _ in [:size] do data := data.push 0
  return data

private def record (limits : MatrixLimits) (enabled : Bool)
    (trace : Array RowOp) (op : RowOp) : Work (Array RowOp × Option Nat) := do
  if !enabled then return (trace, none)
  charge .traceNodes 1 limits.traceNodes (·.traceNodes) fun s n => { s with traceNodes := n }
  packedBytes limits 64
  let index := trace.size
  return (trace.push op, some index)

/-- Square-and-multiply, with each multiply charged to the parent allowance.
The modulus bit length bounds the loop; `PrimeField.bound` makes it at most
31 bits. Fermat inversion also covers characteristic two. -/
private def inverse (field : PrimeField) (ctx : BarrettCtx field.modulus)
    (limits : MatrixLimits) (a : UInt64) : Work UInt64 := do
  if a == 1 then return 1
  let mut exponent := field.modulus.toNat - 2
  let mut a := a
  let mut value : UInt64 := 1
  for _ in [:field.modulus.toNat.log2 + 1] do
    if exponent == 0 then break
    if exponent % 2 == 1 then
      work limits 1
      value := ctx.mulMod value a
    exponent := exponent / 2
    if exponent > 0 then
      work limits 1
      a := ctx.mulMod a a
  return value

/-- Install a known sparse reducer without scattering or scanning empty columns.
Its free leading column guarantees independence of the preceding pivots; its
tail need not be reduced to maintain forward echelon form. -/
private def scaleSparse (field : PrimeField) (ctx : BarrettCtx field.modulus)
    (limits : MatrixLimits) (row : SparseRow) (inverse : UInt64) : Work SparseRow := do
  charge .outputEntries row.size limits.outputEntries (·.outputEntries)
    fun s n => { s with outputEntries := n }
  packedBytes limits (row.columns.size + row.coefficients.size)
  if inverse == 1 then return row
  work limits row.size
  let width := field.width
  let mut coefficients := ByteArray.emptyWithCapacity row.coefficients.size
  for i in [:row.size] do
    coefficients := Packed.push width coefficients
      (ctx.mulMod (Packed.read width row.coefficients i) inverse)
  return ⟨row.columns, coefficients⟩

/-- Flat loop state avoids a nested tuple of mutable values at every column.
Keep it uniquely owned through the loop: sharing it can force dense/trace
copies. Changes to its ownership should be checked with the matrix benchmarks. -/
private structure Scan where
  dense : ByteArray
  last : Nat
  chargedUntil : Nat
  leading : Option Nat
  trace : Array RowOp
  node : Option Nat
  sugar : Nat

@[noinline] private def takeDense (scan : Scan) : ByteArray × Scan :=
  (scan.dense,{ scan with dense := {} })

private def nativeScan (field : PrimeField) (limits : MatrixLimits) (columns : Nat)
    (slots : ByteArray) (pivots : Array Pivot) (nativePivots : Array Wide.Scan.Pivot)
    (first : Nat) (scan : Scan) (provenance native : Bool) : Work Scan := do
  let (dense,scan) := takeDense scan
  let mut state : Wide.Scan.State := {
    dense, column := first, last := scan.last, chargedUntil := scan.chargedUntil
    sugar := scan.sugar }
  let mut trace := scan.trace
  let mut node := scan.node
  for _ in [:((columns*(columns+2)+4095)/4096+1)] do
    let stats ← get
    let traces := limits.traceNodes-stats.traceNodes
    let traceBytes := if provenance then (limits.packedBytes-stats.packedBytes)/64 else traces
    let result := (if native then Wide.Scan.transition else Wide.Scan.portable) field.modulus slots nativePivots state 4096
      (limits.work-stats.work) (min traces traceBytes) provenance
    work limits result.work
    modify fun s => { s with reductions := s.reductions+result.reductions }
    for event in result.events do
      let pivot := pivots[event.1]!
      if let (some left,some right) := (node,pivot.derivation) then
        let (nextTrace,nextNode) ← record limits provenance trace
          (.addScaled left right (field.modulus-event.2))
        trace := nextTrace
        node := nextNode
      else throw .rowUpdate
    state := result.state
    if result.status == 1 then
      return { scan with dense := state.dense, last := state.last, chargedUntil := state.chargedUntil, leading := if state.leading == 0 then none else some (state.leading-1), trace, node, sugar := state.sugar }
    if result.status == 2 then throw (.exhausted .work)
    if result.status == 3 then
      if provenance && traceBytes < traces then
        let _ ← record limits provenance trace (.input 0)
        throw .rowUpdate
      throw (.exhausted .traceNodes)
    if result.status != 0 then throw .rowUpdate
  throw .rowUpdate

private def nativeGather (field : PrimeField) (limits : MatrixLimits) (dense : ByteArray)
    (column last : Nat) (factor : UInt64) (native : Bool) : Work (SparseRow × ByteArray) := do
  let mut state : Wide.Gather.State := ⟨dense,{},{},column⟩
  for _ in [:((last+1-column+4095)/4096+1)] do
    let stats ← get
    let result := (if native then Wide.Gather.gather else Wide.Gather.portable) field.modulus state (last+1) 4096
      (limits.outputEntries-stats.outputEntries) (limits.packedBytes-stats.packedBytes)
      (limits.work-stats.work) factor
    charge .outputEntries result.entries limits.outputEntries (·.outputEntries)
      fun s n => { s with outputEntries := n }
    packedBytes limits result.bytes
    work limits result.work
    state := result.state
    if result.status == 1 then return (⟨state.columns,state.coefficients⟩,state.dense)
    if result.status == 2 then throw (.exhausted .outputEntries)
    if result.status == 3 then throw (.exhausted .packedBytes)
    if result.status == 4 then throw (.exhausted .work)
    if result.status == 5 then throw .dimensions
    if result.status != 0 then throw .rowUpdate
  throw .rowUpdate

/-- Reduce against sparse pivots in a fixed column map. Each scalar update uses
canonical residues: `a + p - (b*c mod p)` fits below `2*p < 2^32`, and the
Barrett product fits below `p^2 < 2^62`. No floating-point arithmetic is used. -/
private def eliminate (field : PrimeField) (limits : MatrixLimits) (columns : Nat)
    (reducers targets : Array SparseRow) (provenance : Bool) (sugars : Array Nat)
    (native independent : Bool) : Work (Echelon × Array RemainderRow) := do
  if columns > 4294967295 || reducers.size + targets.size > 4294967295 then
    throw .dimensions
  if columns > limits.columns then throw (.exhausted .columns)
  if reducers.size + targets.size > limits.rows then throw (.exhausted .rows)
  if !sugars.isEmpty && sugars.size != reducers.size + targets.size then throw .dimensions
  for i in [:reducers.size] do validate field limits columns i reducers[i]!
  for i in [:targets.size] do validate field limits columns (reducers.size + i) targets[i]!
  let width := field.width
  let workspaceBytes := columns * 12
  -- Keep all allocation sizes inside both the logical limit and the platform's
  -- addressable range, even on 32-bit hosts. Do not narrow unchecked products.
  if workspaceBytes ≥ USize.size then throw .dimensions
  packedBytes limits workspaceBytes
  work limits workspaceBytes
  let mut dense := zeros (columns * 8)
  -- A slot stores pivot index + 1. Zero means no pivot, never monomial identity.
  let mut slots := zeros (columns * 4)
  let mut pivots : Array Pivot := #[]
  let mut nativePivots : Array Wide.Scan.Pivot := #[]
  let mut trace : Array RowOp := #[]
  let mut remainders : Array RemainderRow := #[]
  let mut reducerRank := 0
  let ctx := field.barrett
  for input in [:reducers.size + targets.size] do
    work limits 1
    let fromTarget := input ≥ reducers.size
    let row := if fromTarget then targets[input - reducers.size]! else reducers[input]!
    let (nextTrace, node) ← record limits provenance trace (.input input)
    trace := nextTrace
    let mut node := node
    let mut sugar := sugars[input]?.getD 0
    if row.size == 0 then
      if independent && fromTarget then remainders := remainders.push ⟨{}, node, sugar⟩
      modify fun s => { s with zeroRows := s.zeroRows + 1 }
    else
      let first := (Packed.read .u32 row.columns 0).toNat
      if !fromTarget && Packed.read .u32 slots first == 0 then
        let inv ← inverse field ctx limits (Packed.read width row.coefficients 0)
        let output ← scaleSparse field ctx limits row inv
        let (nextTrace, nextNode) ← if inv == 1 then pure (trace, node) else
          match node with
          | some n => record limits provenance trace (.scale n inv)
          | none => pure (trace, none)
        trace := nextTrace
        slots := Packed.set .u32 slots first (pivots.size + 1).toUInt64
        pivots := pivots.push ⟨output, false, nextNode, inv, sugar⟩
        nativePivots := nativePivots.push ⟨output.columns,output.coefficients,sugar⟩
        reducerRank := reducerRank + 1
      else
        work limits row.size
        for i in [:row.size] do
          let column := (Packed.read .u32 row.columns i).toNat
          dense := Native.write dense 8 (column*8) (Packed.read width row.coefficients i).toNat
        let mut scan : Scan := ⟨dense, (Packed.read .u32 row.columns (row.size - 1)).toNat,
          first, none, trace, node, sugar⟩
        scan ← nativeScan field limits columns slots pivots nativePivots first scan provenance native
        dense := scan.dense
        trace := scan.trace
        node := scan.node
        sugar := scan.sugar
        let last := scan.last
        let leading := scan.leading
        if let some column := leading then
          let a := (Native.read dense 8 (column*8) % field.modulus.toNat).toUInt64
          let inv ← if independent && fromTarget then pure 1 else inverse field ctx limits a
          let (nextTrace, nextNode) ← if inv == 1 then pure (trace, node) else
            match node with
            | some n => record limits provenance trace (.scale n inv)
            | none => pure (trace, none)
          trace := nextTrace
          let mut output : SparseRow := {}
          work limits (last + 1 - column)
          let (row,nextDense) ← nativeGather field limits dense column last inv native
          output := row
          dense := nextDense
          if independent && fromTarget then
            remainders := remainders.push ⟨output, nextNode, sugar⟩
          else
            slots := Packed.set .u32 slots column (pivots.size + 1).toUInt64
            pivots := pivots.push ⟨output, fromTarget, nextNode, inv, sugar⟩
            nativePivots := nativePivots.push ⟨output.columns,output.coefficients,sugar⟩
            if !fromTarget then reducerRank := reducerRank + 1
        else
          if independent && fromTarget then remainders := remainders.push ⟨{}, node, sugar⟩
          modify fun s => { s with zeroRows := s.zeroRows + 1 }
    modify fun s => { s with processedRows := s.processedRows + 1 }
  if independent then return (⟨#[], reducerRank, trace⟩, remainders)
  let mut ordered := #[]
  work limits columns
  for column in [:columns] do
    let slot := (Packed.read .u32 slots column).toNat
    if slot != 0 then ordered := ordered.push pivots[slot - 1]!
  return (⟨ordered, reducerRank, trace⟩, remainders)

/-- Deterministic finite-prime-field Macaulay elimination, with sparse reducers,
packed dense accumulation, monic output, stable columns and optional provenance.
`native := false` retains scalar Lean updates; the default uses bounded native
chunks with identical rows, provenance and counters. Input rows must be canonical
and use the field's coefficient width. Limits cover
validation and nested arithmetic as well as elimination. Successful rows span
the input row space; they are echelon, not reduced echelon. The polynomial layer
is responsible for supplying columns in the chosen lawful monomial order. -/
def eliminateWith (field : PrimeField) (limits : MatrixLimits)
    (columns : Nat) (reducers targets : Array SparseRow) (provenance : Bool := false)
    (sugars : Array Nat := #[]) (native : Bool := true) : MatrixResult :=
  let (result, stats) := (eliminate field limits columns reducers targets provenance sugars native false).run {}
  ⟨result.map Prod.fst, stats⟩

/-- Reduce each target by the same reducer echelon space, preserving its scalar
and input position. Targets never reduce each other. Validation, sparse reducer
installation, bounded native updates and allowances are shared with elimination.
This is a linear triangular solve; polynomial normal-form claims additionally
require the symbolic closure and a Gröbner basis. -/
def reduceRowsWith (field : PrimeField) (limits : MatrixLimits)
    (columns : Nat) (reducers targets : Array SparseRow) (provenance : Bool := false)
    (sugars : Array Nat := #[]) (native : Bool := true) : RemainderResult :=
  let (result, stats) :=
    (eliminate field limits columns reducers targets provenance sugars native true).run {}
  ⟨result.map (fun (e, rows) => ⟨rows, e.trace⟩), stats⟩

end Hex.Groebner.Wide
