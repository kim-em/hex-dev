import Lake
open Lake DSL System
package GroebnerWideDev
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
target wideO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "wide_scan.c")
  let body ← inputTextFile (pkg.dir / "wide_scan_impl.h")
  buildO (pkg.dir / defaultBuildDir / "wide.o") (source.zipWith (fun s _ => s) body)
    #["-I", (← getLeanIncludeDir).toString]
    #["-O3", "-Wall", "-Wextra", "-fPIC", "-DHEX_GROEBNER_NO_AVX2"]
lean_lib WideNative where
  roots := #[`WideNative]
  globs := #[.one `WideNative,.one `WideNativeScan,.one `WideNativeGather]
  moreLinkObjs := #[wideO]
  precompileModules := true
lean_lib WideDev where
  roots := #[`WideElimination,`WideSymbolic,`WideF4]
lean_exe wide_compare where
  root := `Main
lean_exe wide_checks where
  root := `WideTest
