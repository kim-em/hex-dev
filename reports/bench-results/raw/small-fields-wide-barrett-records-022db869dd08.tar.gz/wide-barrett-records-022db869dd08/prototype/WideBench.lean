import WideElimination
import HexArith.Montgomery.Context
import LeanBench

namespace Hex.Groebner.WideBench

/-- A prime just above the 16-bit storage boundary. -/
def field : PrimeField :=
  ⟨65537, Hex.Nat.isPrimeTrial_isPrime (by decide), by decide⟩

/-- Immutable packed input, with the first half of the rows serving as reducers. -/
structure Input where
  columns : Nat
  reducers : Array SparseRow
  targets : Array SparseRow
  deriving Hashable

/-- Hilbert entries `1 / (i + j + 1)` over the prime field. For the registered
domain `2*n < p`, all square minors are nonzero. Every elimination update visits
a dense trailing support, without rank defects or accidental zero pivots. -/
def prepare (n : Nat) : Input := Id.run do
  let mut rows := #[]
  for i in [:n] do
    let mut row : SparseRow := {}
    for j in [:n] do
      let c := (HexArith.powMod (i + j + 1) 65535 65537).toUInt64
      row := {
        columns := Packed.push .u32 row.columns j.toUInt64
        coefficients := Packed.push .u32 row.coefficients c }
    rows := rows.push row
  return ⟨n, rows.extract 0 (n / 2), rows.extract (n / 2) n⟩

/-- Return the actual decoded result for structural hashing, including an
explicit failure flag. No parameter-only digest replaces the matrix output. -/
def cauchy (input : Input) : Bool × Array (Array (Nat × UInt64)) :=
  match (eliminateWith field { work := 1000000000 } input.columns input.reducers input.targets).result with
  | .ok e => (e.rows.size == input.columns, e.rows.map (·.row.entries field))
  | .error _ => (false, #[])


def wide (input : Input) : Bool × Array (Array (Nat × UInt64)) :=
  match (Wide.eliminateWith field {work:=1000000000} input.columns input.reducers input.targets).result with
  | .ok e => (e.rows.size == input.columns,e.rows.map (·.row.entries field))
  | .error _ => (false,#[])

setup_benchmark cauchy n => n*n*n
  with prep := prepare
  where {
    paramFloor := 32
    paramCeiling := 512
    paramSchedule := .custom #[32,64,128,256,512]
    maxSecondsPerCall := 8.0
    targetInnerNanos := 500000000
  }
setup_benchmark wide n => n*n*n
  with prep := prepare
  where {
    paramFloor := 32
    paramCeiling := 512
    paramSchedule := .custom #[32,64,128,256,512]
    maxSecondsPerCall := 8.0
    targetInnerNanos := 500000000
  }

end Hex.Groebner.WideBench
