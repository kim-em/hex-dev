#include "matrix_simd.h"
#if HEX_GROEBNER_AVX2
/* Four exact wide additions. No mutation on invalid data or an overflowing
   lane: the scalar path then normalizes only the lanes that need it. */
__attribute__((target("avx2"),always_inline))
static inline unsigned hex_wide_scan4(uint8_t *dense,const uint8_t *columns,const uint8_t *coefficients,
        size_t entry,uint64_t column_count,uint32_t p,uint64_t factor,unsigned width) {
    __m128i j=_mm_loadu_si128((const __m128i *)(columns+entry*4));
    int32_t first=_mm_extract_epi32(j,0),last=_mm_extract_epi32(j,3);
    if(first<0 || last<0 || (uint64_t)last>=column_count) return 0;
    if(entry) {uint32_t previous;memcpy(&previous,columns+(entry-1)*4,4);if(previous>=(uint32_t)first) return 0;}
    __m128i before=_mm_shuffle_epi32(j,_MM_SHUFFLE(2,1,0,0));
    __m128i sorted=_mm_or_si128(_mm_cmpgt_epi32(j,before),_mm_setr_epi32(-1,0,0,0));
    __m128i b;
    if(width==1) {uint32_t bytes;memcpy(&bytes,coefficients+entry,4);b=_mm_cvtepu8_epi32(_mm_cvtsi32_si128((int)bytes));}
    else if(width==2) {uint64_t bytes;memcpy(&bytes,coefficients+entry*2,8);b=_mm_cvtepu16_epi32(_mm_cvtsi64_si128((long long)bytes));}
    else b=_mm_loadu_si128((const __m128i *)(coefficients+entry*4));
    __m128i pv=_mm_set1_epi32((int32_t)p);
    __m128i valid=_mm_and_si128(sorted,_mm_and_si128(
        _mm_cmpgt_epi32(b,_mm_setzero_si128()),_mm_cmpgt_epi32(pv,b)));
    if(_mm_movemask_epi8(valid)!=65535) return 0;
    __m128i consecutive=_mm_add_epi32(_mm_set1_epi32(first),_mm_setr_epi32(0,1,2,3));
    int contiguous=_mm_movemask_epi8(_mm_cmpeq_epi32(j,consecutive))==65535;
    __m256i a=contiguous?_mm256_loadu_si256((const __m256i *)(dense+(size_t)first*8)):
        _mm256_i32gather_epi64((const long long *)dense,j,8);
    __m256i complemented=_mm256_cvtepu32_epi64(_mm_sub_epi32(pv,b));
    __m256i product=_mm256_mul_epu32(complemented,_mm256_set1_epi64x((long long)factor));
    __m256i sign=_mm256_set1_epi64x(INT64_MIN),limit=_mm256_sub_epi64(_mm256_set1_epi64x(-1),product);
    if(_mm256_movemask_epi8(_mm256_cmpgt_epi64(_mm256_xor_si256(a,sign),_mm256_xor_si256(limit,sign)))) return 0;
    __m256i sum=_mm256_add_epi64(a,product);
    if(contiguous) {_mm256_storeu_si256((__m256i *)(dense+(size_t)first*8),sum);return 4;}
    uint32_t indices[4];uint64_t values[4];_mm_storeu_si128((__m128i *)indices,j);
    _mm256_storeu_si256((__m256i *)values,sum);
    for(unsigned k=0;k<4;++k) memcpy(dense+(size_t)indices[k]*8,&values[k],8);
    return 4;
}
#endif
