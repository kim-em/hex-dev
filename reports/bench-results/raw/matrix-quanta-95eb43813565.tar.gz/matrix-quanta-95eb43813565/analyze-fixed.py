from pathlib import Path
import json,statistics
base=Path(__file__).resolve().parent;experiments=[];pooled={}
def summary(v):return dict(geomean=statistics.geometric_mean(v),median=statistics.median(v),minimum=min(v),maximum=max(v),ratios=v)
for d in sorted(base.glob('matrix-quanta-bench-*')):
 if not (d/'metadata.json').exists():continue
 out={};n=0
 for case in ['cyclic4','cyclic5','cyclic6','katsura3','reimer5','cyclic6Small']:
  v=[]
  for block in range(2):
   ap=json.loads((d/f'{case}-b{block}-A.json').read_text())['results'][0]['points'];bp=json.loads((d/f'{case}-b{block}-B.json').read_text())['results'][0]['points'];assert len(ap)==len(bp)==5
   for a,b in zip(ap,bp):
    assert a['status']==b['status']=='ok' and a['result_hash']==b['result_hash'];n+=2;v.append((b['total_nanos']/b['inner_repeats'])/(a['total_nanos']/a['inner_repeats']))
  out[case]=summary(v);pooled.setdefault(case,[]).extend(v)
 experiments.append(dict(name=d.name,cpu=json.loads((d/'metadata.json').read_text())['cpu'],points=n,all_full_output_hashes_equal=True,cases=out))
result=dict(experiments=experiments,points=sum(e['points'] for e in experiments),cases={k:summary(v) for k,v in pooled.items()});(base/'fixed-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
for case,v in result['cases'].items():print(case,{k:v for k,v in v.items() if k!='ratios'})
