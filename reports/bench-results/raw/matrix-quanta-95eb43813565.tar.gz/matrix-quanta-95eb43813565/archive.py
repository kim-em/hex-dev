from pathlib import Path
import subprocess,json,hashlib,tarfile,shutil
repo=Path('/tmp/hex-groebner-matrix-quanta-dev');base=Path('/tmp/hex-groebner-matrix-quanta-production');destination=Path('/tmp/hex-groebner-evidence-review/reports/bench-results');m=json.loads((base/'manifest.json').read_text());checks=json.loads(Path('/tmp/issue-10987-matrix-quanta-full-status.json').read_text());assert len(checks)==9 and all(v['exit_code']==0 for v in checks)
name='matrix-quanta-'+m['source_fingerprint'];stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
for p in base.iterdir():
 if p.name=='binaries':continue
 if p.name=='bench-binaries':
  d=stage/p.name;d.mkdir()
  for q in p.iterdir():
   if q.is_file() and q.name not in ['A','B']:shutil.copy2(q,d/q.name)
 elif p.is_dir():shutil.copytree(p,stage/p.name)
 else:shutil.copy2(p,stage/p.name)
for label,source in [('root',m),('baseline',json.loads(Path('/tmp/hex-groebner-whole-matrix-reviewed-production/manifest.json').read_text()))]:
 (stage/(label+'-manifest.json')).write_text(json.dumps(source,indent=2)+'\n')
 for line in source['source_manifest'].splitlines():
  mode,n=line.split('\t',1);oid=mode.split()[1];b=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;p=stage/(label+'-sources')/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(repo/folder,stage/'validation-sources'/folder)
for p in Path('/tmp').glob('issue-10987-matrix-quanta-*.log'):shutil.copy2(p,stage/p.name)
for n in ['issue-10987-matrix-quanta-full-status.json','issue-10987-lean-cc','issue-10987-lean-cc-flags.json','measure-groebner-matrix-quanta.py','build-groebner-quanta-benches.py','run-issue-10987-full-checks.py']:shutil.copy2(Path('/tmp')/n,stage/n)
(stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=m['source_fingerprint'],decision='Do not adopt: no consistent full-system gain; fixed Reimer5 regresses in both campaigns.',scope='Increase ordinary/traced native scan/gather transition quantum4096to65536, including exact trace/entry/byte/work saturation and caller fuel; whole matrix caps and inner4096chunks unchanged.147source files perarm. All9localchecksteps and8Clang/GCCASanUBSan variants pass. New direct tests exercise5000events/entries,pending5000-entryrow,allfieldwidths,4096/4097/65535/65536/65537quantum boundaries and distinct work/trace/output-entry/byte failure prefixes. First and sole unchanged repeats forsmall/mediumCLI andfixedbenchmarks are complete; all240CLIprocesses/120basis and counter pairs and240fixed structural hashes agree. Retain allcompleted samples,outliers,failures,memory,loadandCPU context; no further unchanged repeat. Source/build variants kept separate; development evidence only,unchecked candidate production excludes certificates/nativecertification/kernelchecking. WrapperSDKClang23.1.0/LLD23.1.0,newnativeFFIClang23.1.3. No fastest-open-source or language-limit claim.'),indent=2)+'\n')
shutil.copy2(__file__,stage/'archive.py');target=destination/'raw'/(name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
a=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source_fingerprint=m['source_fingerprint']);Path('/tmp/issue-10987-matrix-quanta-catalog.json').write_text(json.dumps(a,indent=2)+'\n');print(a)
