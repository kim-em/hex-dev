from pathlib import Path
import json,statistics,sys
base=Path(sys.argv[1]);result={}
def summary(v):return dict(geomean=statistics.geometric_mean(v),median=statistics.median(v),minimum=min(v),maximum=max(v))
for mode in ['small','medium']:
 selected=sorted(base.glob('before-after-'+mode+'*'));rows=[]
 for d in selected:
  meta=json.loads((d/'metadata.json').read_text());samples=meta['samples'];assert all(s['status']=='ok' and s.get('complete_basis_equal',True) for s in samples)
  grouped={}
  for s in samples:grouped.setdefault((s['case'],s['block']),{})[s['arm']]=s
  for (case,block),pair in grouped.items():
   assert set(pair)=={'A','B'};a,b=pair['A'],pair['B'];rows.append(dict(case=case,block=block,campaign=d.name,cpu=meta['cpu'],family=a['family'],candidate_ratio=b['statistics']['candidate_nanos']/a['statistics']['candidate_nanos'],process_ratio=b['wall_nanos']/a['wall_nanos'],baseline=a['statistics'],candidate=b['statistics']))
 families={f:{kind:summary([r[kind+'_ratio'] for r in rows if r['family']==f]) for kind in ['candidate','process']} for f in sorted({r['family'] for r in rows})}
 cases={}
 for case in sorted({r['case'] for r in rows}):
  cr=[r for r in rows if r['case']==case];v={kind:summary([r[kind+'_ratio'] for r in cr]) for kind in ['candidate','process']};v['counters']={}
  for arm in ['baseline','candidate']:
   counts=[{k:v for k,v in r[arm].items() if k!='candidate_nanos'} for r in cr];assert all(x==counts[0] for x in counts);v['counters'][arm]=counts[0]
  cases[case]=v
 result[mode]=dict(campaigns=[d.name for d in selected],pairs=len(rows),processes=2*len(rows),all_complete_bases_equal=True,failures=0,timeouts=0,candidate=summary([r['candidate_ratio'] for r in rows]),process=summary([r['process_ratio'] for r in rows]),family_balanced_process=statistics.geometric_mean(v['process']['geomean'] for v in families.values()),families=families,cases=cases,ratios=rows)
 print(mode,{k:v for k,v in result[mode].items() if k not in ['families','cases','ratios']})
(base/'pooled-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
