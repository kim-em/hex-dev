from pathlib import Path
import os,json,subprocess,hashlib,sys
root=Path('/tmp/hex-groebner-matrix-state-dev');sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
base=Path('/tmp/hex-groebner-state-reviewed-production');out=base/'kernel-paired';out.mkdir(exist_ok=False)
build=json.loads((base/'bench-binaries/builds.json').read_text());binary=base/'bench-binaries/frame';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256'];cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[];all_points={a:[]for a in 'AB'}
try:
 for block,order in enumerate(['AB','BA']):
  for arm in order:
   name='matrixFrameReference' if arm=='A' else 'matrixFrame';prefix=f'block{block}-{arm}';command=[str(binary),'run','Hex.Groebner.Bench.'+name,'--outer-trials','1','--export-file',str(out/(prefix+'.json'))]
   with (out/(prefix+'.log')).open('w')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
   runs.append(dict(block=block,arm=arm,command=command,returncode=r.returncode));assert r.returncode in [0,2]
   value=json.loads((out/(prefix+'.json')).read_text())['results'][0];points=value['points'];assert len(points)==4 and all(p['status']=='ok'for p in points);all_points[arm]+=points;print(prefix,value['verdict'],flush=True)
 for n in [64,128,256,512]:
  hashes={p['result_hash']for points in all_points.values()for p in points if p['param']==n};assert len(hashes)==1,(n,hashes)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),source_fingerprint=build['source_fingerprint'],binary_sha256=build['binary_sha256'],scope='Matched standalone Cauchy matrix kernels at prime65537, complete decoded rows, multipliers, sugars and every resource counter structurally hashed. Both functions in the same fresh detached ELF. Preparation excluded; validation, allocation, elimination and full result consumption included. Fixed four-size trial-major sweeps in adjacent AB/BA arms, one trial per sweep; retain all sixteen completed rows, signal-floor flags, failures and host context. Candidate/certificate/kernel proof performance not measured. Measured twenty-object state sourcec5e1f57fbe8c is distinct from initial nineteen-object source87692e081b76; no pooling. First campaign, no unchanged repeat.',runs=runs),indent=2)+'\n');lease.close()
(out/'measure.py').write_bytes(Path(__file__).read_bytes());(out/'builds.json').write_bytes((base/'bench-binaries/builds.json').read_bytes())
