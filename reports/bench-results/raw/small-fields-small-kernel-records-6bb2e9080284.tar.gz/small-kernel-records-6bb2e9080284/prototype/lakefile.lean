import Lake
open Lake DSL System
package GroebnerSmallDev
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
target wideO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "small_scan.c")
  let body ← inputTextFile (pkg.dir / "matrix_scan_impl.h")
  let common ← inputTextFile (pkg.dir / "matrix_simd.h")
  buildO (pkg.dir / defaultBuildDir / "wide.o") ((source.zipWith (fun s _ => s) body).zipWith (fun s _ => s) common)
    #["-I", (← getLeanIncludeDir).toString]
    #["-O3", "-Wall", "-Wextra", "-fPIC"]
lean_lib SmallNative where
  roots := #[`SmallNative]
  globs := #[.one `SmallNative,.one `SmallScan]
  moreLinkObjs := #[wideO]
  precompileModules := true
lean_lib SmallDev where
  roots := #[`SmallElimination,`SmallSymbolic,`SmallF4,`SmallScanConformance,`SmallBench]
lean_exe small_compare where
  root := `Main
lean_exe small_checks where
  root := `SmallTest

lean_exe small_bench where
  root := `SmallBenchMain
