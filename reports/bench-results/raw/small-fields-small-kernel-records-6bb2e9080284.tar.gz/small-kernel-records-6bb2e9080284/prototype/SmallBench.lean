import SmallElimination
import HexArith.Montgomery.Context
import LeanBench
namespace Hex.Groebner.SmallBench

def field8 : PrimeField := ⟨251,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
def field16 : PrimeField := ⟨32003,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
structure Input where
  columns : Nat
  reducers : Array SparseRow
  targets : Array SparseRow
  deriving Hashable

def prepareWith (field : PrimeField) (n : Nat) : Input := Id.run do
  let mut rows := #[]
  for i in [:n] do
    let mut row : SparseRow := {}
    for j in [:n] do
      let c := (HexArith.powMod (i+j+1) (field.modulus.toNat-2) field.modulus.toNat).toUInt64
      row := {
        columns := Packed.push .u32 row.columns j.toUInt64
        coefficients := Packed.push field.width row.coefficients c }
    rows := rows.push row
  return ⟨n,rows.extract 0 (n/2),rows.extract (n/2) n⟩
def prepare8 := prepareWith field8
def prepare16 := prepareWith field16
private def wireOp : RowOp → Array UInt64
  | .input i => #[0,i.toUInt64]
  | .addScaled l r c => #[1,l.toUInt64,r.toUInt64,c]
  | .scale i c => #[2,i.toUInt64,c]

def run (field : PrimeField) (simd trace : Bool) (input : Input) :
    Bool × Array (Array (Nat × UInt64)) × Array (Array UInt64) :=
  let result := if simd then Small.eliminateWith field {work:=1000000000} input.columns input.reducers input.targets trace
    else eliminateWith field {work:=1000000000} input.columns input.reducers input.targets trace
  match result.result with
  | .ok e => (e.rows.size==input.columns,e.rows.map (·.row.entries field),e.trace.map wireOp)
  | .error _ => (false,#[],#[])
def reference8 := run field8 false false
def simd8 := run field8 true false
def reference16 := run field16 false false
def simd16 := run field16 true false
def reference16Trace := run field16 false true
def simd16Trace := run field16 true true

setup_benchmark reference8 n => n*n*n with prep := prepare8 where {
  paramFloor:=32,paramCeiling:=96,paramSchedule:=.custom #[32,64,96],maxSecondsPerCall:=8.0,targetInnerNanos:=500000000 }
setup_benchmark simd8 n => n*n*n with prep := prepare8 where {
  paramFloor:=32,paramCeiling:=96,paramSchedule:=.custom #[32,64,96],maxSecondsPerCall:=8.0,targetInnerNanos:=500000000 }
setup_benchmark reference16 n => n*n*n with prep := prepare16 where {
  paramFloor:=64,paramCeiling:=512,paramSchedule:=.custom #[64,128,256,512],maxSecondsPerCall:=8.0,targetInnerNanos:=500000000 }
setup_benchmark simd16 n => n*n*n with prep := prepare16 where {
  paramFloor:=64,paramCeiling:=512,paramSchedule:=.custom #[64,128,256,512],maxSecondsPerCall:=8.0,targetInnerNanos:=500000000 }
setup_benchmark reference16Trace n => n*n*n with prep := prepare16 where {
  paramFloor:=64,paramCeiling:=512,paramSchedule:=.custom #[64,128,256,512],maxSecondsPerCall:=8.0,targetInnerNanos:=500000000 }
setup_benchmark simd16Trace n => n*n*n with prep := prepare16 where {
  paramFloor:=64,paramCeiling:=512,paramSchedule:=.custom #[64,128,256,512],maxSecondsPerCall:=8.0,targetInnerNanos:=500000000 }
end Hex.Groebner.SmallBench
