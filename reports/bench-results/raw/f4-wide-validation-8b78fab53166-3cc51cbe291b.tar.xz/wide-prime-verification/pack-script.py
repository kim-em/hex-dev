"""Retain source-bound sparse-F2 production evidence without executables/caches."""
from pathlib import Path
import argparse,hashlib,io,json,lzma,subprocess,sys,tarfile

S=Path('/home/kim/tmp/issue-10987')
ROOT=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-prime')
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
p.add_argument('--prefix',default='wide-opus-r3');p.add_argument('--freeze',default='delayed-contiguous-production')
a=p.parse_args();files={}
def add(name,path):
    assert name not in files
    files[name]=Path(path).read_bytes()
def tree(prefix,path):
    for path in sorted(Path(path).rglob('*')):
        if path.is_file():add(prefix+'/'+str(path.relative_to(base_paths[prefix])),path)
def directory(prefix,path):
    base_paths[prefix]=Path(path);tree(prefix,path)
base_paths={}
for label,freeze in [('candidate',a.freeze)]:
    base=S/freeze
    for name in ['manifest.json','build.log','source.manifest','groebner_freeze.py']:
        if (base/name).is_file():add(label+'/'+name,base/name)
    directory(label+'/root-sources',base/'root-sources')
full=json.loads((S/(a.prefix+'-full-status.json')).read_text())
native=json.loads((S/(a.prefix+'-native-status.json')).read_text())
assert len(full)==9 and len(native)==2 and all(r['exit_code']==0 for r in full+native)
identity={k:full[0][k]for k in ['source_commit','source_fingerprint','source_manifest_sha256','checks_fingerprint','checks_manifest_sha256']}
assert all(all(row[k]==v for k,v in identity.items())for row in full+native)
sys.path.insert(0,str(ROOT))
from scripts.bench.groebner_checks import CHECKS
from scripts.bench.sweep_freshness import tree_listing
listing=tree_listing(CHECKS,identity['source_commit'])
files['checks/source-manifest.txt']=listing.encode()
for line in listing.splitlines():
    name=line.split('\t',1)[1]
    files['checks/sources/'+name]=subprocess.check_output(['git','show',identity['source_commit']+':'+name],cwd=ROOT)
add('checks/full/status.json',S/(a.prefix+'-full-status.json'))
for row in full:add('checks/full/'+row['name']+'.log',row['log'])
add('checks/native/status.json',S/(a.prefix+'-native-status.json'))
for kind in ['regular','forced','packed']:
    for cc in ['clang','gcc']:
        tag=a.prefix+('-'if kind=='regular'else'-'+kind+'-')+cc
        project=S/tag;add('checks/'+kind+'/'+cc+'.log',S/(tag+'.log'))
        if kind!='regular':
            status=json.loads((project/(kind+'-status.json')).read_text())
            assert status['build_exit_code']==0 and len(status['results'])==6
            assert all(r['exit_code']==0 for r in status['results'])
            assert all(status[k]==v for k,v in identity.items())
        for path in sorted(project.iterdir()):
            if path.is_file():add('checks/'+kind+'/'+cc+'/'+path.name,path)
for name in [a.prefix+'-native-checks.py',a.prefix+'-special-checks.py',a.prefix+'-full-checks.py']:
    add('checks/runners/'+name,S/name)
directory('candidate/compiler-inputs',S/a.freeze/'compiler-inputs')
for prefix in ['wide-opus-r1','wide-opus-r2']:
    for path in sorted(S.glob(prefix+'*.log')):
        add('verification-attempts/'+path.name,path)
    for path in sorted(S.glob(prefix+'*status.json')):
        add('verification-attempts/'+path.name,path)
add('pack-script.py',Path(__file__))
files['scope.json']=(json.dumps(dict(kind='verification',identity=identity,strict_configurations=36,project_checks=9,
    contract='Current mixed-lane correction and exact p2 boundary tests, explicit dispatch policy and historical wide-prime report replay. All9/36checks bind the identical measured 8b78 runtime and compiler inputs. No new scientific timing claim.'),indent=2)+'\n').encode()
files['sha256.json']=(json.dumps({k:hashlib.sha256(v).hexdigest()for k,v in sorted(files.items())},indent=2)+'\n').encode()
assert not a.output.exists()
with lzma.LZMAFile(a.output,'wb',filters=[dict(id=lzma.FILTER_LZMA2,preset=3,dict_size=64*1024**2)]) as compressed,tarfile.open(fileobj=compressed,mode='w|')as archive:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo('wide-prime-verification/'+name);info.size=len(data);info.mode=0o644;info.mtime=0
        archive.addfile(info,io.BytesIO(data))
print(a.output,hashlib.file_digest(a.output.open('rb'),'sha256').hexdigest(),a.output.stat().st_size)
