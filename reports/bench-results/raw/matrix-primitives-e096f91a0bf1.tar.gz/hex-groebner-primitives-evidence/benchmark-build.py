from pathlib import Path
import os,json,subprocess,tempfile,shutil,hashlib,time
root=Path('/tmp/hex-groebner-matrix-kernels-dev');production=Path('/tmp/hex-groebner-primitives-kernel-production');out=production/'bench-binaries'
while not(production/'manifest.json').exists():time.sleep(1)
out.mkdir(parents=True,exist_ok=False)
manifest=json.loads((production/'manifest.json').read_text());records=dict(source_fingerprint=manifest['source_fingerprint'],source_snapshot=manifest['source_snapshot'],build_policy='fresh detached source snapshot; only pinned dependency package cache shared',command=['lake','build','hexgroebner_bench'])
with tempfile.TemporaryDirectory(prefix='groebner-state-bench-')as tmp:
 checkout=Path(tmp)/'source';subprocess.run(['git','worktree','add','--detach',str(checkout),manifest['source_snapshot']],cwd=root,check=True,capture_output=True)
 try:
  (checkout/'.lake').mkdir();(checkout/'.lake/packages').symlink_to((root/'.lake/packages').resolve(),target_is_directory=True)
  with (out/'build.log').open('w')as f:p=subprocess.run(records['command'],cwd=checkout,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,LEAN_CC='/tmp/issue-10987-relocatable-wrapper/issue-10987-lean-cc'))
  records['returncode']=p.returncode;assert p.returncode==0
  shutil.copy2(checkout/'.lake/build/bin/hexgroebner_bench',out/'frame');records['binary_sha256']=hashlib.sha256((out/'frame').read_bytes()).hexdigest()
 finally:subprocess.run(['git','worktree','remove','--force',str(checkout)],cwd=root,check=True,capture_output=True)
(out/'builds.json').write_text(json.dumps(records,indent=2)+'\n');shutil.copy2(production/'manifest.json',out/'manifest.json');shutil.copy2(__file__,out/'build.py');print(records,flush=True)
