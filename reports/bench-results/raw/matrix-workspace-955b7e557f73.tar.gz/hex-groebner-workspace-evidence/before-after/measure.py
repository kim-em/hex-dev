from pathlib import Path
import os,json,subprocess,hashlib,sys
root=Path('/tmp/hex-groebner-matrix-proof-dev');sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
base=Path('/tmp/hex-groebner-workspace-production');old=Path('/tmp/hex-groebner-validation-production');out=base/'before-after';out.mkdir(exist_ok=False)
bases={'A':old,'B':base};builds={a:json.loads((p/'bench-binaries/builds.json').read_text())for a,p in bases.items()};binaries={a:p/'bench-binaries/frame'for a,p in bases.items()}
for a,b in binaries.items():assert hashlib.sha256(b.read_bytes()).hexdigest()==builds[a]['binary_sha256']
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[];all_points={a:[]for a in 'AB'}
try:
 for block,order in enumerate(['AB','BA']):
  for arm in order:
   prefix=f'block{block}-{arm}';command=[str(binaries[arm]),'run','Hex.Groebner.Bench.matrixSparse','--outer-trials','1','--export-file',str(out/(prefix+'.json'))]
   with(out/(prefix+'.log')).open('w')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
   runs.append(dict(block=block,arm=arm,command=command,returncode=r.returncode));assert r.returncode in[0,2]
   value=json.loads((out/(prefix+'.json')).read_text())['results'][0];points=value['points'];assert len(points)==5 and all(p['status']=='ok'for p in points);all_points[arm]+=points;print(prefix,value['verdict'],flush=True)
 for n in[64,128,256,512,1024]:
  hashes={p['result_hash']for points in all_points.values()for p in points if p['param']==n};assert len(hashes)==1,(n,hashes)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),builds=builds,scope='First native-workspace before/after campaign. A source14564559e1b2 uses native validation and Lean workspace zeroing; B uses native validation and bounded native workspace allocation/zeroing. Same five-size unit-coefficient sparse family and complete output consumption; source-specific fresh detached ELFs. Adjacent AB/BA whole sweeps, one trial per sweep, twenty samples, all retained with RSS/floors/failures. Preparation excluded; validation/allocation/elimination/full result consumption included. Complete hashes compared across both sources. One requested algorithm thread, automatic CPU lease, no host-activity filtering, no unchanged repeat. Separate from each source\'s reference/bulk comparison campaigns. F4 route remains unchanged; candidate/certificate/independent verification/kernel timings excluded.',runs=runs),indent=2)+'\n');lease.close()
(out/'measure.py').write_bytes(Path(__file__).read_bytes())
