from pathlib import Path
import os,json,subprocess,hashlib,sys
root=Path('/tmp/hex-groebner-matrix-proof-dev');sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
base=Path('/tmp/hex-groebner-workspace-production');out=base/'kernel-paired';out.mkdir(exist_ok=False)
build=json.loads((base/'bench-binaries/builds.json').read_text());binary=base/'bench-binaries/frame';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256'];cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[];points_by_name={}
try:
 for comparison,reference in [('reference','matrixSparseReference'),('bulk','matrixSparseBulk')]:
  all_points={a:[]for a in 'AB'}
  for block,order in enumerate(['AB','BA']):
   for arm in order:
    name=reference if arm=='A'else'matrixSparse';prefix=f'{comparison}-block{block}-{arm}';command=[str(binary),'run','Hex.Groebner.Bench.'+name,'--outer-trials','1','--export-file',str(out/(prefix+'.json'))]
    with(out/(prefix+'.log')).open('w')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
    runs.append(dict(comparison=comparison,block=block,arm=arm,command=command,returncode=r.returncode));assert r.returncode in[0,2]
    value=json.loads((out/(prefix+'.json')).read_text())['results'][0];points=value['points'];assert len(points)==5 and all(p['status']=='ok'for p in points);all_points[arm]+=points;points_by_name.setdefault(name,[]).extend(points);print(prefix,value['verdict'],flush=True)
  for n in[64,128,256,512,1024]:
   hashes={p['result_hash']for points in all_points.values()for p in points if p['param']==n};assert len(hashes)==1,(comparison,n,hashes)
 for n in[64,128,256,512,1024]:
  hashes={p['result_hash']for points in points_by_name.values()for p in points if p['param']==n};assert len(hashes)==1,(n,hashes)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),source_fingerprint=build['source_fingerprint'],binary_sha256=build['binary_sha256'],scope='Sparse distinct known-pivot family at prime65537; n/2 two-entry reducers and eight targets with one new target pivot. Complete decoded rows, target flags, multipliers, sugars and every resource counter structurally hashed. Build-time guards require successful complete equality at every timed size and native bulk admission. First campaign for native validation plus native zeroed workspaces; two separate comparisons, each with adjacent AB/BA whole five-size sweeps and one trial per sweep, forty completed points total. A is ordinary reference or existing native bulk route; B is continuation. All functions in the same fresh detached ELF; preparation excluded, validation/allocation/elimination/full result consumption included. Retain all samples, RSS, signal-floor flags, failures and host context. No pooling with dense-family or other source records and no unchanged repeat. Candidate/certificate/independent certification/kernel proof timings are not measured.',runs=runs),indent=2)+'\n');lease.close()
(out/'measure.py').write_bytes(Path(__file__).read_bytes());(out/'builds.json').write_bytes((base/'bench-binaries/builds.json').read_bytes())
