from pathlib import Path
import json,tarfile,hashlib,subprocess,shutil
root=Path('/tmp/hex-groebner-sparse-targets-dev');base=Path('/tmp/hex-groebner-combined-production');manifest=json.loads((base/'manifest.json').read_text());dest=root/'reports/bench-results/raw';catalog=[]
for directory in sorted(base.iterdir()):
 if not directory.is_dir() or not (directory/'metadata.json').exists():continue
 m=json.loads((directory/'metadata.json').read_text());assert m['source_fingerprint']==manifest['source_fingerprint'];shutil.copy2(__file__,directory/Path(__file__).name);shutil.copy2(base/'pooled-analysis.json',directory/'pooled-analysis.json')
 listings={'root-sources':m['source_manifest']}
 if m.get('baseline_manifest'):listings['baseline-sources']=m['baseline_manifest']['source_manifest']
 for folder,listing in listings.items():
  (directory/(folder+'.manifest')).write_text(listing)
  for line in listing.splitlines():
   header,name=line.split('\t',1);oid=header.split()[1];p=directory/folder/name;p.parent.mkdir(parents=True,exist_ok=True);content=subprocess.check_output(['git','cat-file','blob',oid],cwd=root);assert hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()==oid;p.write_bytes(content)
 if m.get('msolve_mode'):
  ms=Path('/tmp/hex-groebner-msolve');assert hashlib.sha256((ms/'src/neogb/.libs/libneogb.so.4.0.0').read_bytes()).hexdigest()==m['msolve_engine_sha256']
  for name in ['config.log','config.h','config.status','Makefile','src/neogb/Makefile']:shutil.copy2(ms/name,directory/('msolve-'+name.replace('/','-')))
  for name in ['issue-10987-msolve-native-build.log','issue-10987-msolve-native-configure-with-deps.log','issue-10987-msolve-native-compiler-probe.log','issue-10987-build-msolve-native.sh']:shutil.copy2(Path('/tmp')/name,directory/name)
  shutil.copy2('/tmp/hex-groebner-mersenne-dispatch-production/msolve-source-3672113ee2c6.tar',directory/'msolve-source-3672113ee2c6.tar')
 target=dest/('combined-'+directory.name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as archive:archive.add(directory,arcname=directory.name)
 row={'archive':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()};catalog.append(row);print(json.dumps(row),flush=True)
stage=base/'validation';stage.mkdir(exist_ok=False)
for name in ['manifest.json','source.manifest','build.log','groebner_freeze.py','pooled-analysis.json']:shutil.copy2(base/name,stage/name)
shutil.copytree(base/'root-sources',stage/'root-sources')
for name in ['all-conformance','all-oracles','san','gcc-san','dag','phase','manifest','headers','lines','bench-verify','baseline-hash-negative','tool-tests','freeze']:
 p=Path('/tmp/issue-10987-combined-'+name+'.log');assert p.exists(),p;shutil.copy2(p,stage/p.name)
for name in ['conformance/HexGroebner/PairRowsConformance.lean','conformance/HexGroebner/F4Conformance.lean','conformance/HexGroebner/TraceConformance.lean','conformance-fixtures/HexGroebner/f4.jsonl']:
 p=stage/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
shutil.copy2(__file__,stage/Path(__file__).name)
(stage/'scope.json').write_text(json.dumps({'source_fingerprint':manifest['source_fingerprint'],'scope':'Fresh 188-job build, separate frozen baseline manifest, six retained campaigns (one permitted unchanged repeat each), all 1956 conformance/theory targets, both 567-case CLI corpora, independent 175/567/1288 oracles, four Clang and four GCC sanitizer variants, 32 benchmark verification checks and project audits. Before/after allows only algorithm-statistic differences while requiring all metadata and complete bases to agree. Altered baseline hash is rejected before any measured process. Candidate generation is unchecked; certificate generation, independent final certification and kernel checking are excluded from timings. Separate current comparator campaigns are not pooled with the earlier standalone-driver snapshot.'},indent=2)+'\n')
target=dest/('combined-validation-'+manifest['source_fingerprint']+'.tar.gz')
with tarfile.open(target,'w:gz') as archive:archive.add(stage,arcname=stage.name)
catalog.append({'archive':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()});Path('/tmp/issue-10987-combined-archive-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n');print(json.dumps(catalog[-1]))
