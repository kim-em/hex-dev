/* Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
   Released under Apache 2.0 license as described in the file LICENSE.
   Authors: Kim Morrison */
#if defined(__linux__) && !defined(_GNU_SOURCE)
#define _GNU_SOURCE
#endif
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "matrix_avx512.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#if HEX_GROEBNER_AVX512
#if defined(__unix__) || defined(__APPLE__)
#include <sys/mman.h>
#include <unistd.h>
#endif
static uint32_t get_value(const uint8_t *p,unsigned w,size_t i) {
    uint32_t value=0;for(unsigned k=0;k<w;++k) value|=(uint32_t)p[w*i+k]<<(8*k);return value;
}
static void put_value(uint8_t *p,unsigned w,size_t i,uint32_t value) {
    for(unsigned k=0;k<w;++k) p[w*i+k]=(uint8_t)(value>>(8*k));
}
typedef struct {uint8_t *allocation,*data;size_t bytes,page;} buffer;
static buffer allocate(size_t bytes,unsigned at_end) {
#if defined(__unix__) || defined(__APPLE__)
    size_t page=(size_t)sysconf(_SC_PAGESIZE);assert(bytes<=page);
    uint8_t *base=mmap(NULL,3*page,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(base!=MAP_FAILED);
    assert(mprotect(base+page,page,PROT_READ|PROT_WRITE)==0);
    return (buffer){base,at_end?base+2*page-bytes:base+page,bytes,page};
#else
    (void)at_end;uint8_t *base=malloc(bytes);assert(base);return (buffer){base,base,bytes,0};
#endif
}
static void protect(buffer b,int readonly) {
#if defined(__unix__) || defined(__APPLE__)
    assert(mprotect(b.allocation+b.page,b.page,readonly?PROT_READ:PROT_READ|PROT_WRITE)==0);
#else
    (void)b;(void)readonly;
#endif
}
static void release(buffer b) {
#if defined(__unix__) || defined(__APPLE__)
    assert(munmap(b.allocation,3*b.page)==0);
#else
    free(b.allocation);
#endif
}
HEX_AVX512_TARGET
static void check(uint32_t p,uint32_t factor,unsigned stride,unsigned padding,unsigned at_end,unsigned prefix) {
    unsigned width=p<=256?1:p<=65536?2:4;
    size_t count=prefix+16,columns=4+15*stride+1+padding;
    buffer dense=allocate(columns*width,at_end),cs=allocate(count*4,at_end),vs=allocate(count*width,at_end);
    uint8_t expected[512],before[512];assert(columns*width<=sizeof(expected));
    for(size_t i=0;i<columns;++i) put_value(dense.data,width,i,i%3==0?0:i%3==1?p-1:(uint32_t)((i*UINT64_C(374761393))%p));
    if(prefix) {put_value(cs.data,4,0,0);put_value(vs.data,width,0,1);}
    for(unsigned i=0;i<16;++i) {
        put_value(cs.data,4,prefix+i,4+i*stride);
        put_value(vs.data,width,prefix+i,i%3==0?1:i%3==1?p-1:(uint32_t)((i*UINT64_C(2654435761))%(p-1))+1);
    }
    memcpy(expected,dense.data,dense.bytes);memcpy(before,dense.data,dense.bytes);
    unsigned accepted=stride==1 || padding+1>=4/width;
    if(accepted) for(unsigned i=0;i<16;++i) {
        uint32_t j=get_value(cs.data,4,prefix+i),a=get_value(expected,width,j),b=get_value(vs.data,width,prefix+i);
        put_value(expected,width,j,(uint32_t)((a+(uint64_t)p-(uint64_t)factor*b%p)%p));
    }
    uint32_t multiplier=width<4?factor:(uint32_t)(((uint64_t)factor<<32)%p);
    uint32_t reduction=width<4?(uint32_t)(UINT64_C(4294967296)/p):hex_mont32_inverse(p);
    protect(cs,1);protect(vs,1);
    unsigned result=p==INT32_MAX?hex_scan16_m31(dense.data,cs.data,vs.data,prefix,columns,p,multiplier,reduction,width):
        hex_scan16(dense.data,cs.data,vs.data,prefix,columns,p,multiplier,reduction,width);
    assert(result==(accepted?16u:0u));assert(memcmp(expected,dense.data,dense.bytes)==0);
    for(unsigned bad=0;bad<16;++bad) {
        protect(vs,0);uint32_t saved=get_value(vs.data,width,prefix+bad);put_value(vs.data,width,prefix+bad,p);protect(vs,1);
        memcpy(before,dense.data,dense.bytes);
        assert(hex_scan16(dense.data,cs.data,vs.data,prefix,columns,p,multiplier,reduction,width)==0);
        assert(memcmp(before,dense.data,dense.bytes)==0);
        protect(vs,0);put_value(vs.data,width,prefix+bad,saved);protect(vs,1);
        size_t j=get_value(cs.data,4,prefix+bad);saved=get_value(dense.data,width,j);put_value(dense.data,width,j,p);
        memcpy(before,dense.data,dense.bytes);
        assert(hex_scan16(dense.data,cs.data,vs.data,prefix,columns,p,multiplier,reduction,width)==0);
        assert(memcmp(before,dense.data,dense.bytes)==0);put_value(dense.data,width,j,saved);
    }
    protect(cs,0);put_value(cs.data,4,prefix+15,(uint32_t)columns);protect(cs,1);memcpy(before,dense.data,dense.bytes);
    assert(hex_scan16(dense.data,cs.data,vs.data,prefix,columns,p,multiplier,reduction,width)==0);
    assert(memcmp(before,dense.data,dense.bytes)==0);
    release(dense);release(cs);release(vs);
}
#endif
int main(void) {
#if HEX_GROEBNER_AVX512
    if(hex_avx512_available()) {
        uint32_t fields[]={3,251,257,32003,65521,65535,65537,1000000007,2147483629,2147483647};
        for(unsigned field=0;field<sizeof(fields)/sizeof(fields[0]);++field) {
            uint32_t p=fields[field],factors[]={0,1,p-1,1234567%p};
            for(unsigned f=0;f<4;++f) for(unsigned stride=1;stride<=3;stride+=2)
                for(unsigned padding=0;padding<4;++padding) for(unsigned end=0;end<2;++end)
                    for(unsigned prefix=0;prefix<2;++prefix) check(p,factors[f],stride,padding,end,prefix);
        }
        puts("exact AVX-512 updates: all widths, boundary fields, guard pages, readonly inputs and malformed packets passed");return 0;
    }
    const char *required=getenv("HEX_GROEBNER_REQUIRE_AVX512");
    if(required && strcmp(required,"1")==0) {fputs("AVX-512 required but unavailable\n",stderr);return 1;}
#endif
    puts("AVX-512 unavailable or disabled; existing fallbacks selected");return 0;
}
