import Lake
open Lake DSL
package InitRepro
lean_exe plain where
  root := `Plain
lean_exe jsonRuntime where
  root := `JsonRuntime

open System
target minimalInitO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "minimal_init.c")
  buildO (pkg.dir / defaultBuildDir / "minimal_init.o") source
    #["-I", (← getLeanIncludeDir).toString] #["-O2", "-fPIC"]
lean_exe jsonRuntimeOnly where
  root := `JsonRuntimeOnly
  moreLinkObjs := #[minimalInitO]
  moreLinkArgs := #["-Wl,--wrap=lean_initialize"]

lean_exe jsonMinimal where
  root := `JsonMinimal
  moreLinkArgs := #["-linitialize_minimal"]
