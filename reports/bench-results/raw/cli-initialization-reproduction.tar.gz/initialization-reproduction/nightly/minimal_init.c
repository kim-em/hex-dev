/* Diagnostic only: initialization counterfactual, not a supported production workaround. */
void lean_initialize_runtime_module(void);
void __wrap_lean_initialize(void) { lean_initialize_runtime_module(); }
