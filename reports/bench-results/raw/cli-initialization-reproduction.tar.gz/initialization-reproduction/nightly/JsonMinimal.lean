import Lean.Data.Json.Parser
import Lean.Data.Json.FromToJson.Basic

def main : IO Unit := do
  let value ← IO.ofExcept (Lean.Json.parse "0")
  IO.println value.compress
