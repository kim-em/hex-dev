from pathlib import Path
import subprocess,json,sys,os
sys.path.insert(0,'/tmp/hex-groebner-compare-monomials-dev')
from scripts.bench.cpu_lease import cpu_lease
root=Path(__file__).resolve().parent;out=root/'memory-supplement';out.mkdir(exist_ok=False);cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});rows=[]
try:
 for trial in range(3):
  for name in ['plain','jsonRuntime','jsonRuntimeOnly']:
   prefix=f'{trial}-{name}';command=['/run/current-system/sw/bin/time','-f','%M','-o',str(out/(prefix+'.rss')),str(root/'.lake/build/bin'/name)]
   with (out/(prefix+'.stdout')).open('wb') as stdout,(out/(prefix+'.stderr')).open('wb') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr)
   rows.append({'trial':trial,'name':name,'returncode':r.returncode,'peak_rss_kib':int((out/(prefix+'.rss')).read_text()),'command':command});assert r.returncode==0 and (out/(prefix+'.stdout')).read_bytes()==b'0\n'
finally:
 meta={'cpu':cpu,'scope':'Memory-only supplement via GNU time after exec, so its own small process forks the measured program. No timing claim or unchanged timing repeat. The original wait4 ru_maxrss figures carry the large Python parent high-water floor and must not be interpreted as program memory.','time_version':subprocess.check_output(['/run/current-system/sw/bin/time','--version'],text=True),'records':rows};(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
print(rows)
