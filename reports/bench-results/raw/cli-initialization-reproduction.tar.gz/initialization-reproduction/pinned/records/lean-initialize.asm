
.lake/build/bin/jsonRuntime:     file format elf64-x86-64


Disassembly of section .text:

0000000000b325c0 <lean_initialize>:
  b325c0:	80 3d 1a 96 fe 03 00 	cmpb   $0x0,0x3fe961a(%rip)        # 4b1bbe1 <_ZN4leanL13g_initializedE>
  b325c7:	74 01                	je     b325ca <lean_initialize+0xa>
  b325c9:	c3                   	ret
  b325ca:	50                   	push   %rax
  b325cb:	c6 05 0f 96 fe 03 01 	movb   $0x1,0x3fe960f(%rip)        # 4b1bbe1 <_ZN4leanL13g_initializedE>
  b325d2:	bf 01 00 00 00       	mov    $0x1,%edi
  b325d7:	e8 24 f4 d2 03       	call   4861a00 <_ZN4lean15save_stack_infoEb>
  b325dc:	e8 6f 03 00 00       	call   b32950 <_ZN4lean22initialize_util_moduleEv>
  b325e1:	bf 01 00 00 00       	mov    $0x1,%edi
  b325e6:	e8 d5 30 ca 03       	call   47d56c0 <initialize_Init>
  b325eb:	48 89 c7             	mov    %rax,%rdi
  b325ee:	e8 cd 00 00 00       	call   b326c0 <_ZN4lean17consume_io_resultEP11lean_object>
  b325f3:	bf 01 00 00 00       	mov    $0x1,%edi
  b325f8:	e8 a3 d7 b5 03       	call   468fda0 <initialize_Std>
  b325fd:	48 89 c7             	mov    %rax,%rdi
  b32600:	e8 bb 00 00 00       	call   b326c0 <_ZN4lean17consume_io_resultEP11lean_object>
  b32605:	bf 01 00 00 00       	mov    $0x1,%edi
  b3260a:	e8 11 4c 06 01       	call   1b97220 <initialize_Lean>
  b3260f:	48 89 c7             	mov    %rax,%rdi
  b32612:	e8 a9 00 00 00       	call   b326c0 <_ZN4lean17consume_io_resultEP11lean_object>
  b32617:	e8 f4 a9 00 00       	call   b3d010 <_ZN4lean24initialize_kernel_moduleEv>
  b3261c:	e8 2f 03 06 00       	call   b92950 <_ZN4lean21init_default_print_fnEv>
  b32621:	e8 aa 1d 06 00       	call   b943d0 <_ZN4lean30initialize_library_core_moduleEv>
  b32626:	e8 e5 1d 06 00       	call   b94410 <_ZN4lean25initialize_library_moduleEv>
  b3262b:	58                   	pop    %rax
  b3262c:	e9 f7 f5 06 00       	jmp    ba1c28 <_ZN4lean31initialize_constructions_moduleEv>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
