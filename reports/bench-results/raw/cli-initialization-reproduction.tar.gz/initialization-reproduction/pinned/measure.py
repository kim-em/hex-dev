from pathlib import Path
import sys,os,json,hashlib,subprocess,time,resource,select,ctypes
sys.path.insert(0,'/tmp/hex-groebner-compare-monomials-dev')
from scripts.bench.cpu_lease import cpu_lease
root=Path(__file__).resolve().parent;out=root/'records';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();binaries={a:root/'.lake/build/bin'/n for a,n in [('A','plain'),('B','jsonRuntime'),('C','jsonRuntimeOnly')]}
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});m={'host':os.uname().nodename,'cpu':cpu,'toolchain':(root/'lean-toolchain').read_text().strip(),'compiler':subprocess.check_output(['cc','--version'],text=True),'schedule':'24 trial-major triplets ABC/CBA alternating; B/C adjacent in alternate orders; retain every completed sample','contract':'A plain IO prints0; B parses/printsJSON0 with emitted full Lean initialization; C identical JSON source with diagnostic link-time substitution of runtime-only initialization, not a supported production workaround. Whole-process duration, no candidate computation.','binary_sha256':{a:sha(p) for a,p in binaries.items()},'binary_bytes':{a:p.stat().st_size for a,p in binaries.items()},'load_start':os.getloadavg(),'samples':[]}
libc=ctypes.CDLL(None,use_errno=True);libc.pidfd_open.argtypes=[ctypes.c_int,ctypes.c_uint];libc.pidfd_open.restype=ctypes.c_int
try:
 for trial in range(24):
  for arm in ('ABC' if trial%2==0 else 'CBA'):
   prefix=f't{trial}-{arm}';start=time.monotonic_ns()
   with (out/(prefix+'.stdout')).open('wb') as stdout,(out/(prefix+'.stderr')).open('wb') as stderr:
    proc=subprocess.Popen([str(binaries[arm])],stdout=stdout,stderr=stderr);fd=libc.pidfd_open(proc.pid,0)
    if fd<0:raise OSError(ctypes.get_errno(),'pidfd_open')
    try:
     ready,_,_=select.select([fd],[],[],30)
     if not ready:proc.kill()
     _,status,usage=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status)
    finally:os.close(fd)
   elapsed=time.monotonic_ns()-start;record={'trial':trial,'arm':arm,'wall_nanos':elapsed,'peak_rss_kib':usage.ru_maxrss,'returncode':proc.returncode,'stdout_sha256':sha(out/(prefix+'.stdout'))};m['samples'].append(record)
   assert proc.returncode==0 and (out/(prefix+'.stdout')).read_bytes()==b'0\n',record
finally:
 m['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(m,indent=2)+'\n');lease.close()
import math,statistics
summary={}
for arm in binaries:
 r=[x for x in m['samples'] if x['arm']==arm];v=[x['wall_nanos']/1e6 for x in r];summary[arm]={'count':len(v),'milliseconds':{'geomean':math.prod(v)**(1/len(v)),'median':statistics.median(v),'min':min(v),'max':max(v)},'peak_rss_kib':max(x['peak_rss_kib'] for x in r)}
pairs=[]
for trial in range(24):
 d={x['arm']:x for x in m['samples'] if x['trial']==trial};pairs.append(d['B']['wall_nanos']/d['C']['wall_nanos'])
summary['B_over_C']={'geomean':math.prod(pairs)**(1/len(pairs)),'median':statistics.median(pairs),'min':min(pairs),'max':max(pairs)}
(out/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
