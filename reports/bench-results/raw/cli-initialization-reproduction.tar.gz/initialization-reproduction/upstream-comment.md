A concrete downstream example from the finite-field F4 work in kim-em/hex-dev#10987: using only runtime JSON parsing/conversion pulls full Lean initialization into an executable that never elaborates Lean source.

`JsonRuntime.lean`:
```lean
import Lean.Data.Json.Parser
import Lean.Data.Json.FromToJson.Basic

def main : IO Unit := do
  let value ← IO.ofExcept (Lean.Json.parse "0")
  IO.println value.compress
```

A minimal `lakefile.lean`:
```lean
import Lake
open Lake DSL
package InitRepro
lean_exe jsonRuntime where
  root := `JsonRuntime
lean_exe jsonMinimal where
  root := `JsonMinimal
  moreLinkArgs := #["-linitialize_minimal"]
```
`JsonMinimal.lean` is byte-for-byte identical to `JsonRuntime.lean`. Build with `lake build jsonRuntime jsonMinimal` and run both: each prints `0`.

On the shared Linux EPYC 9455 host, 24 adjacent full/minimal pairs, alternating AB/BA on one automatically selected CPU per toolchain, retaining every completed sample:

| Toolchain | Full process geometric mean | Minimal process geometric mean | Paired full/minimal geometric mean |
| --- | ---: | ---: | ---: |
| 4.35.0-rc3, `470d5ce1400764999581fd26d5d72b00d990b0f4` | 20.771 ms | 2.521 ms | 8.241 |
| nightly-2026-10-30, `f0fc2fc18852fa60ff43f0daa33020d825c92e72` | 20.850 ms | 2.427 ms | 8.591 |

No quiet-host filtering or unchanged timing repeat is used. These are host-specific whole-process observations, including launch/output; they do not measure F4 arithmetic. The pinned full executable is about 114 MiB versus 12 MiB with the shipped minimal library. A separate memory-only GNU-time observation for the pinned full JSON executable reports about 63,000 KiB; the original Python wait4 RSS observations inherit a parent-memory floor and are deliberately not used as program-memory estimates.

The source path is concrete: `Lean/Compiler/LCNF/EmitC.lean`'s `emitInitFn` chooses `lean_initialize` when `usesModuleFrom env Lean` holds, and the ordinary implementation initializes the entire `Lean` aggregate. Narrowing the JSON umbrella to Parser + FromToJson.Basic does not avoid this decision.

The shipped `libinitialize_minimal.a` provides a useful workaround for this never-elaborating program, following the same restriction documented for leanchecker in `src/initialize/CMakeLists.txt`. This does **not** justify skipping full initialization for general Lean clients or removing effectful initializers. It would help downstream computational tools to have a documented Lake executable option for this restricted mode, or runtime JSON helpers available without the broad Lean-package initialization requirement. We will retain full initialization as a fallback and continue to remeasure the unchanged reproduction as the initialization/linking design evolves.
