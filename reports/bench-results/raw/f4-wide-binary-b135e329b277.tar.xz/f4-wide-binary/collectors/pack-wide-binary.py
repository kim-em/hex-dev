from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();assert identity['source_fingerprint']=='b135e329b277'
native=json.loads((s/'wide-binary-native-status.json').read_text());full=json.loads((s/'wide-binary-full-status.json').read_text())
assert len(native)==2 and len(full)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in native+full)
payload={}
def add(n,p):
 assert n not in payload,n
 payload[n]=p.read_bytes()
def tree(label,base,shallow=False):
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if p.is_file() and 'binaries'not in rel.parts and '.lake'not in rel.parts and (not shallow or len(rel.parts)==1 or rel.parts[0]in ['root-sources','compiler-inputs']):add(label+'/'+str(rel),p)
tree('baseline',s/'pivot-timeout-production',True);tree('candidate',s/'wide-binary-production')
for cc in ['clang','gcc']:
 add('native-'+cc+'.log',s/('wide-binary-'+cc+'.log'));tree('probes/'+cc,s/('wide-binary-'+cc))
add('native-status.json',s/'wide-binary-native-status.json');add('full-status.json',s/'wide-binary-full-status.json')
for n in ['build','oracles','driver','bench','dag','phase4','manifest','headers','lines']:add('full/'+n+'.log',s/('wide-binary-full-'+n+'.log'))
for n in ['measure-wide-binary-f2.py','measure-wide-binary-prime.py','measure-wide-binary-hard-cyclic9.py','wide-binary-native-checks.py','wide-binary-full-checks.py','pack-wide-binary.py']:add('collectors/'+n,s/n)
for n in ['wide-binary-freeze.log','wide-binary-kernel-build.log','wide-binary-models-first.log','wide-binary-models-updated.log','wide-binary-models-guards.log','wide-binary-c-build.log','wide-binary-c-build-final.log','wide-binary-rebase.log','wide-binary-native-runner.log','wide-binary-full-runner.log']:add('diagnostics/'+n,s/n)
text=tree_listing(CHECKS,identity['source_commit']);payload['checks.manifest']=text.encode()
for line in text.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode()
out=s/('f4-wide-binary-'+identity['source_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-wide-binary/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
