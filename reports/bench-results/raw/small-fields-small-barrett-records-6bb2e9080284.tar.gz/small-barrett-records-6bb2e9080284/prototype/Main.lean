import HexGroebner
import SmallF4
import Lean.Data.Json

open Hex.Groebner Lean

def parseTerm (j : Json) : Except String RawTerm := do
  let values ← j.getArr?
  if values.size != 2 then throw "term needs [exponents,coefficient]"
  let powers ← values[0]!.getArr? >>= fun a => a.mapM Json.getNat?
  let c ← values[1]!.getNat?
  if c ≥ 2^64 then throw "coefficient exceeds UInt64"
  return ⟨powers, c.toUInt64⟩

def parseInput (j : Json) : Except String (Context × Array RawPolynomial) := do
  let modulus ← j.getObjValAs? Nat "p"
  if h : Hex.Nat.isPrimeTrial modulus = true then
    if bound : modulus < 2^31 then
      let field : PrimeField := ⟨modulus.toUInt64, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using Hex.Nat.isPrimeTrial_isPrime h, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using bound⟩
      let variables ← j.getObjValAs? Nat "variables"
      let order ← j.getObjValAs? String "order"
      let order ← match order with
        | "grevlex" => pure TermOrder.grevlex
        | "grlex" => pure TermOrder.grlex
        | "lex" => pure TermOrder.lex
        | _ => throw "unknown order"
      let generators ← j.getObjVal? "generators" >>= Json.getArr? >>= fun a =>
        a.mapM fun p => p.getArr? >>= fun a => a.mapM parseTerm
      return (⟨field, variables, order⟩, generators)
    else throw "modulus out of bounds"
  else throw "not prime"

def emitPolynomial (p : RawPolynomial) : Json := .arr (p.map fun t =>
  .arr #[toJson t.exponents, toJson t.coefficient.toNat])

def main (args : List String) : IO Unit := do
  let small := args.contains "--small"
  let args := args.filter (· != "--small")
  let (filename, batchInterreduce, nativeMonomials, batchSize) ← match args with
    | [s] => pure (s, true, true, 1024)
    | [s, "--separate"] => pure (s, false, true, 1024)
    | [s, "--arrays"] => pure (s, true, false, 1024)
    | [s, "--batch64"] => pure (s, true, true, 64)
    | [s, "--batch256"] => pure (s, true, true, 256)
    | [s, "--batch1024"] => pure (s, true, true, 1024)
    | _ => throw (IO.userError "f4_compare input.json")
  let json ← IO.ofExcept (Json.parse (← IO.FS.readFile filename))
  let (context, generators) ← IO.ofExcept (parseInput json)
  let limits : Limits := {
    batchInterreduce, nativeMonomials, batchSize
    work := 100000000000
    packedBytes := 16 * 1024 * 1024 * 1024
    matrixEntries := 1000000000
    pairs := 100000000
    monomials := 10000000 }
  let start ← IO.monoNanosNow
  let forced : Candidate × Statistics ← if small then
    match Small.computeWith context limits generators with
    | .candidate c statistics => pure (⟨c.context,c.polynomials,c.randomState,c.batchSize,
        c.nativeRows,c.nativeMonomials,c.gebauerMoller,c.batchInterreduce⟩,statistics)
    | .internal e _ => throw (IO.userError s!"internal {reprStr e}")
    | .invalid e _ => throw (IO.userError s!"invalid {reprStr e}")
    | .exhausted r _ => throw (IO.userError s!"exhausted {reprStr r}")
    | .representation e _ => throw (IO.userError s!"representation {reprStr e}")
  else
    match computeWith context limits generators with
    | .candidate candidate statistics => pure (candidate,statistics)
    | .internal e _ => throw (IO.userError s!"internal {reprStr e}")
    | .invalid e _ => throw (IO.userError s!"invalid {reprStr e}")
    | .exhausted r _ => throw (IO.userError s!"exhausted {reprStr r}")
    | .representation e _ => throw (IO.userError s!"representation {reprStr e}")
  let stop ← IO.monoNanosNow
  let (candidate, statistics) := forced
  let output := Json.mkObj [
    ("basis", .arr (candidate.polynomials.map emitPolynomial)),
    ("candidate_nanos", toJson (stop-start)), ("small", toJson small),
    ("work", toJson statistics.work), ("pairs", toJson statistics.pairs),
    ("rounds", toJson statistics.rounds), ("matrix_calls", toJson statistics.matrixCalls),
    ("matrix_entries", toJson statistics.matrixEntries),
    ("allocated_bytes", toJson statistics.allocatedBytes),
    ("batch_cap", toJson candidate.batchSize),
    ("largest_batch", toJson statistics.largestBatch),
    ("peak_matrix_rows", toJson statistics.peakMatrixRows),
    ("peak_matrix_entries", toJson statistics.peakMatrixEntries),
    ("native_rows", toJson candidate.nativeRows),
    ("native_monomials", toJson candidate.nativeMonomials),
    ("gebauer_moller", toJson candidate.gebauerMoller),
    ("batch_interreduce", toJson candidate.batchInterreduce)]
  IO.println output.compress
