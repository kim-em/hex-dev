import SmallF4
import SmallScanConformance
import HexGroebner.F4Fixtures
open Hex.Groebner

def f4Checks : Bool := Id.run do
  for field in Fixtures.fields do
    for order in [TermOrder.lex,.grlex,.grevlex] do
      for c in F4Fixtures.cases field do
        let context : Context := ⟨field,c.variables,order⟩
        let .candidate expected stats := computeWith context {} c.generators | return false
        let .candidate actual usage := Small.computeWith context {} c.generators | return false
        if actual.polynomials != expected.polynomials || usage != stats then return false
  return true
#guard f4Checks

def main : IO Unit := do
  if f4Checks && SmallScanConformance.runtimeChecks && SmallScanConformance.runtimeWideChecks then
    IO.println "small-field SIMD primitives and all 567 bases/counters match portable/production references"
  else throw (IO.userError "small-field SIMD mismatch")
