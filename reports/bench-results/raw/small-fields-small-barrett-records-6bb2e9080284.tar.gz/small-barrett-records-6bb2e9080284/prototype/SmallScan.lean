module
public import HexGroebner.NativeScan
public import SmallNative
@[expose] public section
namespace Hex.Groebner.Small
@[extern "lean_hex_small_scan_transition"]
def transition (modulus : UInt64) (slots : @& ByteArray) (pivots : @& Array Native.Scan.Pivot)
    (initial : Native.Scan.State) (quantum workLimit traceLimit : @& Nat) (provenance : Bool) : Native.Scan.Result :=
  Native.Scan.portable modulus slots pivots initial quantum workLimit traceLimit provenance
end Hex.Groebner.Small
