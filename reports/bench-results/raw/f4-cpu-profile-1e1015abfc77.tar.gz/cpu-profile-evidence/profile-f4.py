from pathlib import Path
import json,os,subprocess,hashlib,sys,time
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-review');state=Path('/home/kim/tmp/issue-10987');binary=state/'review-production/binaries/compute';manifest=json.loads((state/'review-production/manifest.json').read_text());cases={'eco11-31':4,'cyclic7-31':8,'reimer6-31':16};args=['--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000']
if '--worker' in sys.argv:
 case=sys.argv[2];out=Path(sys.argv[3]);records=[]
 for i in range(cases[case]):
  cmd=[str(binary),*args,str(state/'admission-counts/medium'/f'{case}.json')];p=subprocess.run(cmd,capture_output=True,text=True);(out/f'{i}.stdout').write_text(p.stdout);(out/f'{i}.stderr').write_text(p.stderr);records.append(dict(iteration=i,command=cmd,returncode=p.returncode));(out/'processes.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0;value=json.loads(p.stdout);assert value['kind']=='unchecked_candidate'
 exit()
sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
out=state/'cpu-profile';out.mkdir(exist_ok=False);cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});runs=[];start=time.time();before=hashlib.sha256(binary.read_bytes()).hexdigest();assert before==manifest['binary_sha256']['compute'];load=os.getloadavg()
try:
 for case in cases:
  folder=out/case;folder.mkdir();command=['perf','record','-e','cycles:u','-F','997','--call-graph','dwarf,8192','--output',str(folder/'perf.data'),'--','python3',str(Path(__file__).resolve()),'--worker',case,str(folder)]
  with(folder/'record.log').open('w')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
  runs.append(dict(case=case,command=command,returncode=r.returncode));assert r.returncode==0
  for label,options in [('all',['--sort','comm,symbol']),('compute',['--comms','compute','--sort','symbol'])]:
   report=['perf','report','--stdio','--no-children','--percent-limit','0.5','-i',str(folder/'perf.data'),*options]
   with(folder/(label+'.txt')).open('w')as f:p=subprocess.run(report,stdout=f,stderr=subprocess.STDOUT)
   assert p.returncode==0
  print(case,'profile complete',flush=True)
finally:
 after=hashlib.sha256(binary.read_bytes()).hexdigest();(out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,algorithm_threads=1,host=os.uname().nodename,kernel=os.uname().release,load_start=load,load_end=os.getloadavg(),start_epoch=start,end_epoch=time.time(),binary_sha256_before=before,binary_sha256_after=after,source_fingerprint=manifest['source_fingerprint'],source_snapshot=manifest['source_snapshot'],perf_version=subprocess.check_output(['perf','--version'],text=True).strip(),runs=runs,scope='CPU-cycle profiles explaining modest full-system gains despite large primitive-kernel gains. Fixed Eco11/Cyclic7/Reimer6 inputs at2147483647, grevlex/default degree scheduling,4/8/16 complete process invocations respectively. All profiled outputs/statuses retained; no filtering/no unchanged rerun. Automatically leased CPU, one algorithm thread, shared-host activity recorded. Sample weights diagnostic only: candidateNanos in profiled outputs is not scientific timing evidence. No certification/kernel-checking/leadership claim.'),indent=2)+'\n');lease.close();assert before==after
(out/'profile-f4.py').write_bytes(Path(__file__).read_bytes())
