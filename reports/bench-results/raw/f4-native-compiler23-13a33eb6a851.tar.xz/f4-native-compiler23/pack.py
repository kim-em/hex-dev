from pathlib import Path
import hashlib,io,json,lzma,sys,tarfile
s=Path('/home/kim/tmp/issue-10987');payload={}
def add(name,path):assert name not in payload;payload[name]=path.read_bytes()
for label in ['avx512-default','native-compiler23']:
 base=s/(label+'-production')
 for path in sorted(base.rglob('*')):
  if path.is_file() and 'binaries' not in path.relative_to(base).parts:add(label+'/'+str(path.relative_to(base)),path)
a=json.loads((s/'avx512-default-production/manifest.json').read_text());b=json.loads((s/'native-compiler23-production/manifest.json').read_text());assert a['source_manifest']==b['source_manifest'] and a['native_options']==b['native_options']=={'hexGroebnerAVX512':False};assert a['compilers']['lean']==b['compilers']['lean']
for name in ['f4','f4-repeat','msolve']:
 base=s/'native-compiler23-production'/name;meta=json.loads((base/'metadata.json').read_text());analysis=json.loads((base/'analysis.json').read_text());assert len(meta['samples'])==analysis['samples']==56 and analysis['complete_bases_equal']==28 and analysis['timeouts']==analysis['failed_processes']==0
 assert meta['binary_sha256']==meta['binary_sha256_after']
 if name!='msolve':
  index={(row['case'],row['block'],row['arm']):row for row in meta['samples']}
  for case,block,arm in index:
   if arm!='A':continue
   outputs=[json.loads((base/f'{case}-b{block}-{x}.stdout').read_text()) for x in ['A','B']]
   for output in outputs:output.pop('candidateNanos')
   assert outputs[0]==outputs[1]
 else:assert analysis['ratio_direction']=='Hex/msolve process'
status=json.loads((s/'native-compiler23-production/kernel-status.json').read_text());assert len(status['samples'])==72 and all(row['exit_code'] in [0,2]for row in status['samples'])
for row in status['samples']:
 if not row['label'].startswith('matched/') or row['arm']!='A':continue
 prefix=row['label'][:-1];points=[json.loads((s/'native-compiler23-production/kernels'/(prefix+x)/'result.json').read_text())['results'][0]['points'][0]for x in ['A','B']];assert all(v['status']=='ok'for v in points) and points[0]['result_hash']==points[1]['result_hash']
add('pack.py',Path(__file__));digests={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())};payload['sha256.json']=(json.dumps(digests,indent=2)+'\n').encode();out=s/'f4-native-compiler23-13a33eb6a851.tar.xz'
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-native-compiler23/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(digests),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
