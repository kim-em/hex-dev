from pathlib import Path
import os,subprocess
s=Path('/home/kim/tmp/issue-10987');base=s/'native-compiler23-production'
command=[str(s/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(s/'final-products-production/medium-inputs/suite.json'),'--hex-scheduling','degree','--hex',str(base/'binaries/compute'),'--msolve',str(s/'msolve-current/.libs/msolve'),'--msolve-source',str(s/'msolve-current'),'--msolve-mode','2','--output',str(base/'msolve')]
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(s/'oracles/bin')+':'+os.environ['PATH'])
r=subprocess.run(command,env=env);(base/'measure-msolve.py').write_bytes(Path(__file__).read_bytes());raise SystemExit(r.returncode)
