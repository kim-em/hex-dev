from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-delayed');base=state/'matrix-counts-production';manifest=json.loads((base/'manifest.json').read_text());name='f4-matrix-counts-'+manifest['source_fingerprint'];payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
native=json.loads((state/'matrix-counts-native-status.json').read_text());full=json.loads((state/'matrix-counts-full-status.json').read_text());assert len(native)==2 and len(full)==9 and all(x['exit_code']==0 for x in native+full)
assert 'Build completed successfully' in (state/'matrix-counts-failure-build.log').read_text()
for p in sorted(base.rglob('*')):
 if p.is_file() and p.relative_to(base).parts[0]!='binaries':add('measurement/'+str(p.relative_to(base)),p.read_bytes())
for directory in ['matrix-counts-clang','matrix-counts-gcc','matrix-stage-probe']:
 for p in sorted((state/directory).rglob('*')):
  if p.is_file() and '.lake' not in p.relative_to(state/directory).parts:add('validation/'+directory+'/'+str(p.relative_to(state/directory)),p.read_bytes())
for pattern in ['matrix-counts-*.py','matrix-counts-*.json','matrix-counts-*.log']:
 for p in sorted(state.glob(pattern)):
  if p.is_file():add('reproduction/'+p.name,p.read_bytes())
for rel in ['issue-10987-lean-cc','issue-10987-lean-cc-flags.json']:
 add('reproduction/'+rel,(state/rel).read_bytes())
base_commit='958daf17b8f31fd371d781d1073aae17b508548c';current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();add('source.patch',subprocess.check_output(['git','diff','--binary',base_commit,current,'--','.',':!reports'],cwd=root));add('source-base.txt',(base_commit+'\n').encode())
import sys
sys.path.insert(0,str(root));from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing,fingerprint
listing=tree_listing(FAMILY,current);assert listing==manifest['source_manifest'];add('source-identity.json',(json.dumps(dict(commit=current,full_native_check_commit=native[0]['source_commit'],full_project_check_commit=full[0]['source_commit'],frozen_source_snapshot=manifest['source_snapshot'],runtime_source_fingerprint=fingerprint(listing),runtime_source_unchanged=True,scope='Untimed counter/stage diagnostics, source-pinned driver identity and conformance. The focused failure-prefix test is an additive conformance-only change after the full check commit; it builds successfully. No timing comparison is claimed.'),indent=2)+'\n').encode());add('archive.py',Path(__file__).read_bytes());add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest() for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/'matrix-counts-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
