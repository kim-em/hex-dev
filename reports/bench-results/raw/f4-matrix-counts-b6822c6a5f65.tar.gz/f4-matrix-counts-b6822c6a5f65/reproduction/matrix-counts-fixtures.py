from pathlib import Path
import json,os,subprocess
state=Path('/home/kim/tmp/issue-10987');root=Path.cwd();out=state/'matrix-counts-f4.jsonl';assert not out.exists()
with (state/'matrix-counts-fixtures.log').open('w') as log:r=subprocess.run([str(root/'.lake/build/bin/hexgroebner_emit_f4')],env=dict(os.environ,HEX_FIXTURE_OUTPUT=str(out)),stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,r.returncode
fixture=root/'conformance-fixtures/HexGroebner/f4.jsonl';old=[json.loads(x)for x in fixture.read_text().splitlines()];new=[json.loads(x)for x in out.read_text().splitlines()];assert len(old)==len(new)==1134
keys=['matrixTargets','matrixReductions','matrixZeroRows','serialMatrixTargets','serialMatrixReductions','serialMatrixZeroRows']
for a,b in zip(old,new):
 stripped=json.loads(json.dumps(b))
 for key in keys:assert isinstance(stripped['value'].pop(key),int)
 assert stripped==a,a['case']
fixture.write_bytes(out.read_bytes());(state/'matrix-counts-fixture-audit.json').write_text(json.dumps(dict(records=len(new),unchanged_existing_fields=True,new_fields=keys,checked_traced_counts=True),indent=2)+'\n');print('1134 fixture profiles: all existing fields unchanged; native/scalar/traced matrix counts agree',flush=True)
