from pathlib import Path
import hashlib,importlib.util,json,os,resource,subprocess,time
state=Path('/home/kim/tmp/issue-10987');base=state/'matrix-counts-production'
while not (base/'manifest.json').is_file():time.sleep(5)
manifest=json.loads((base/'manifest.json').read_text());assert manifest['source_fingerprint']=='b6822c6a5f65';binary=base/'binaries/compute';assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['binary_sha256']['compute']
out=base/'diagnostics';out.mkdir(exist_ok=False);suite=state/'final-products-production/medium-inputs/suite.json';plan=json.loads(suite.read_text());helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('leased_cpu',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[]
def bounds():
 resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,64*1024**2))
try:
 for case in plan['cases']:
  name=case['name'];input_path=suite.parent/(name+'.json');command=[str(binary),'--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000','--scheduling','degree',str(input_path)]
  with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=60,preexec_fn=bounds,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  record=dict(case=name,family=case['family'],p=case['p'],command=command,exit_code=r.returncode,input_sha256=hashlib.sha256(input_path.read_bytes()).hexdigest());runs.append(record);assert r.returncode==0
  value=json.loads((out/(name+'.stdout')).read_text());old=json.loads((state/'combined-performance-production/before-after-selected'/(name+'-b0-B.stdout')).read_text());value.pop('candidateNanos');old.pop('candidateNanos');stats=value['statistics'];counts={key:stats.pop(key)for key in ['matrixTargets','matrixReductions','matrixZeroRows']};assert value==old,name
  assert 0<=counts['matrixZeroRows']<=counts['matrixTargets']<=stats['matrixRows'];record.update(existing_fields_equal=True,counters=dict(stats,**counts),zero_target_ratio=counts['matrixZeroRows']/counts['matrixTargets'] if counts['matrixTargets'] else None)
  print(name,counts,flush=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(source_manifest=manifest,cpu=cpu,host=os.uname().nodename,threads='Serial algorithm, runtime auxiliary threads, one CPU affinity',load_start=load,load_end=os.getloadavg(),suite_sha256=hashlib.sha256(suite.read_bytes()).hexdigest(),runs=runs,scope='Untimed one-pass deterministic counter diagnostics on the existing medium development suite. Every complete basis and all pre-existing metadata/counters are compared to the retained fd0313 source outputs. The candidateNanos values remain in raw stdout but no timing or speedup claim uses these executions. Aggregate counts include initial and final interreduction matrix calls, so the zero/target fraction is not a block-sampling probability or a performance prediction.'),indent=2)+'\n');lease.close()
(out/'collect.py').write_bytes(Path(__file__).read_bytes());assert len(runs)==14
