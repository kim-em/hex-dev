import Lake
open Lake DSL
package GroebnerStageCounts
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-delayed"
lean_exe stage_counts where
  root := `Main
