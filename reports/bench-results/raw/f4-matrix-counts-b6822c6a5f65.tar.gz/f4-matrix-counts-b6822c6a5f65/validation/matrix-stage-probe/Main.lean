import HexGroebner.Driver.Input

open Hex.Groebner Lean

private def phaseName : F4.Phase → String
  | .input => "input"
  | .pairs => "pairs"
  | .interreduce => "interreduce"
  | .complete => "complete"

def main (args : List String) : IO UInt32 := do
  let [filename] := args | throw (IO.userError "one input filename required")
  let raw ← IO.FS.readFile filename
  let .ok (context,generators) := Json.parse raw >>= Driver.parseInput |
    throw (IO.userError "invalid input")
  let limits : Limits := {
    work := 100000000000, packedBytes := 17179869184, pairs := 100000000
    monomials := 10000000, matrixEntries := 1000000000 }
  let mut checkpoint : F4.Checkpoint := {}
  let mut workspace : Workspace := ⟨{ arity := context.variables },{}⟩
  for step in [:limits.rounds+4] do
    if checkpoint.phase == .complete then break
    let phase := checkpoint.phase
    let before := workspace.statistics
    let (result,next) := (F4.step context limits generators checkpoint).run workspace
    workspace := next
    let .ok updated := result | throw (IO.userError "F4 step failed")
    checkpoint := updated
    let s := workspace.statistics
    IO.println (Json.mkObj [
      ("kind",toJson "stage"),("step",toJson step),("phase",toJson (phaseName phase)),
      ("matrixCalls",toJson (s.matrixCalls-before.matrixCalls)),
      ("matrixRows",toJson (s.matrixRows-before.matrixRows)),
      ("matrixTargets",toJson (s.matrixTargets-before.matrixTargets)),
      ("matrixReductions",toJson (s.matrixReductions-before.matrixReductions)),
      ("matrixZeroRows",toJson (s.matrixZeroRows-before.matrixZeroRows)),
      ("basisRows",toJson checkpoint.basis.size)]).compress
  if checkpoint.phase != .complete then throw (IO.userError "stage fuel exhausted")
  let polynomials := checkpoint.basis.map fun row => row.polynomial.toRaw context.field workspace.table
  IO.println (Json.mkObj [("kind",toJson "stage_diagnostics_complete"),
    ("p",toJson context.field.modulus.toNat),("variables",toJson context.variables),
    ("statistics",Driver.statistics workspace.statistics),
    ("basis",Json.arr (polynomials.map Driver.polynomial))]).compress
  return 0
