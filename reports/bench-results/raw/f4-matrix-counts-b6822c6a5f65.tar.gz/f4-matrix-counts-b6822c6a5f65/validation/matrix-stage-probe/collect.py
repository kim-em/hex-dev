from pathlib import Path
import hashlib,json,os,subprocess
state=Path('/home/kim/tmp/issue-10987');project=Path(__file__).resolve().parent;base=state/'matrix-counts-production';out=base/'stages';suite=state/'final-products-production/medium-inputs/suite.json';plan=json.loads(suite.read_text());binary=project/'.lake/build/bin/stage_counts';records=[]
keys=['matrixTargets','matrixReductions','matrixZeroRows','matrixRows','matrixCalls']
try:
 for case in plan['cases']:
  name=case['name'];stdout=out/(name+'.jsonl');stderr=out/(name+'.stderr');command=[str(binary),str(suite.parent/(name+'.json'))]
  reused=stdout.exists()
  if not reused:
   with stdout.open('wb') as output,stderr.open('wb') as error:r=subprocess.run(command,stdout=output,stderr=error,timeout=60)
   code=r.returncode
  else:code=0
  record=dict(case=name,p=case['p'],family=case['family'],command=command,exit_code=code,reused_completed_eco_run=reused);records.append(record);assert code==0
  rows=[json.loads(line)for line in stdout.read_text().splitlines()];footer=rows[-1];assert footer['kind']=='stage_diagnostics_complete';assert all(row['kind']=='stage'for row in rows[:-1])
  whole=json.loads((base/'diagnostics'/(name+'.stdout')).read_text());assert footer['basis']==whole['basis'];assert footer['p']==whole['p'] and footer['variables']==whole['variables']
  for key in keys:assert sum(row[key]for row in rows[:-1])==footer['statistics'][key]==whole['statistics'][key]
  record['phases']={phase:{key:sum(row[key]for row in rows[:-1]if row['phase']==phase)for key in keys}for phase in ['input','pairs','interreduce']};record['complete_basis_equal']=True
  print(name,record['phases']['pairs'],flush=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(scope='Untimed per-stage F4.step diagnostics. First Eco11-31 completion is retained and reused; other commands have a60-second timeout. No timing claims. Complete bases and five cumulative matrix counters agree with the separately frozen current driver. Final decode work is absent from this step runner, so other counters are not equated.',source_commit='ef129f7da3',runtime_source_fingerprint='b6822c6a5f65',driver_manifest=json.loads((base/'manifest.json').read_text()),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source_sha256=hashlib.sha256((project/'Main.lean').read_bytes()).hexdigest(),runs=records),indent=2)+'\n')
assert len(records)==14
