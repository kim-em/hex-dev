from pathlib import Path
import hashlib,json,re,tarfile,sys
root=Path(sys.argv[1]);report=root/'reports/bench-results/hexgroebner-mersenne.md';rows=[]
for name,digest in re.findall(r'\]\(raw/([^\)]+)\).*?`([0-9a-f]{64})`',report.read_text()):
 p=root/'reports/bench-results/raw'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
 record={'archive':name,'sha256':digest,'source_blobs':0,'baseline_blobs':0}
 with tarfile.open(p,'r:gz') as t:
  names=set(t.getnames());metadata=[n for n in names if len(Path(n).parts)==2 and n.endswith('/metadata.json')]
  for n in metadata:
   m=json.load(t.extractfile(n));prefix=n.rsplit('/',1)[0]
   for key,dirname,countkey in [('source_manifest','root-sources','source_blobs'),('baseline_source_manifest','baseline-sources','baseline_blobs')]:
    listing=m.get(key)
    if not listing and key=='baseline_source_manifest':
     for candidate in [prefix+'/baseline-manifest.json',prefix+'/kernel-baseline-manifest.json']:
      if candidate in names:listing=json.load(t.extractfile(candidate)).get('source_manifest');break
    for line in (listing or '').splitlines():
     _,oid,rest=line.split(' ',2);_,path=rest.split('\t');member=prefix+'/'+dirname+'/'+path
     if member not in names:
      assert key=='baseline_source_manifest';continue
     data=t.extractfile(member).read();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert actual==oid,(name,path,actual,oid);record[countkey]+=1
 rows.append(record)
out={'archives':rows,'total_source_blobs':sum(r['source_blobs'] for r in rows),'total_baseline_blobs':sum(r['baseline_blobs'] for r in rows),'scope':'Each verified member matches its Git blob ID. Some earlier records rely on separately archived baseline sources; final dispatch archives include both complete source families.'};Path('archive-provenance.json').write_text(json.dumps(out,indent=2)+'\n');print(len(rows),'archives;',out['total_source_blobs'],'candidate blobs;',out['total_baseline_blobs'],'baseline blobs')
