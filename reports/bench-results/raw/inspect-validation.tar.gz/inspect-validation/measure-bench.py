import hashlib,json,os,pathlib,subprocess,sys,time
sys.path.insert(0,'/tmp/hex-groebner-compare-monomials-dev')
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import fingerprint,index_listing
root=pathlib.Path('/tmp/hex-groebner-compare-monomials-dev');dev=pathlib.Path('/tmp/hex-groebner-inspect-production')
listing=index_listing(FAMILY);fp=fingerprint(listing);out=dev/('inspect-production-bench-'+fp);out.mkdir(exist_ok=False)
binaries={'A':dev/'binaries/hexgroebner-bench-inspect-baseline','B':dev/'binaries/hexgroebner-bench-inspect'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
meta=dict(source_fingerprint=fp,source_manifest=listing,baseline_commit='b08b41295e77b53fa0318285b50ed8b5d07b0939',baseline_source_fingerprint=json.loads((dev/'binaries/baseline-manifest.json').read_text())['source_fingerprint'],binary_sha256={a:sha(p) for a,p in binaries.items()},cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),schedule='per case, adjacent AB then BA; declared five fixed repetitions',contract='A is frozen multiplied-row F4 with owned flat source deduplication, fingerprint f3d5acec8365. B uses unchanged F4, representation, arithmetic and sugar scheduling with bounded packed monomial order/divisibility comparisons. Complete reduced bases and all non-timing counters must agree. Candidate time includes canonicalization/F4/final interreduction; process time additionally includes startup/parse/output. Certification and kernel checking excluded.',toolchain=(root/'lean-toolchain').read_text().strip(),compiler=subprocess.check_output(['cc','--version'],text=True),script=pathlib.Path(__file__).read_text(),runs=[])
try:
 for block,order in enumerate(['AB','BA']):
  for case in ['cyclic4','cyclic5','cyclic6','katsura3','reimer5','cyclic6Small']:
   for arm in order:
    prefix=f'{case}-b{block}-{arm}';command=[str(binaries[arm]),'run','Hex.Groebner.Bench.'+case,'--export-file',str(out/(prefix+'.json'))]
    print(prefix,flush=True);start=time.monotonic_ns()
    with (out/(prefix+'.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    meta['runs'].append(dict(case=case,block=block,arm=arm,command=command,returncode=result.returncode,wall_nanos=time.monotonic_ns()-start))
finally:
 meta['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
