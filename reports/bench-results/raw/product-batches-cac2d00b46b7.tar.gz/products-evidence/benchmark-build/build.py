from pathlib import Path
import os,json,subprocess,time,shutil,hashlib
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products');state=Path('/home/kim/tmp/issue-10987')
for label,base in [('candidate',state/'products-production')]:
 while not(base/'manifest.json').is_file():time.sleep(10)
 manifest=json.loads((base/'manifest.json').read_text());out=base/'bench-binaries';out.mkdir(exist_ok=False);checkout=out/'source';subprocess.run(['git','worktree','add','--detach',str(checkout),manifest['source_snapshot']],cwd=root,check=True,capture_output=True);(checkout/'.lake').mkdir();(checkout/'.lake/packages').symlink_to((root/'.lake/packages').resolve(),target_is_directory=True)
 env=dict(os.environ,LEAN_CC=str(state/'issue-10987-lean-cc'),PATH='/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin:'+os.environ['PATH'],TMPDIR=str(state))
 with(out/'build.log').open('w')as f:r=subprocess.run(['lake','build','hexgroebner_bench'],cwd=checkout,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0;shutil.copy2(checkout/'.lake/build/bin/hexgroebner_bench',out/'frame');records=dict(label=label,source_fingerprint=manifest['source_fingerprint'],source_snapshot=manifest['source_snapshot'],binary_sha256=hashlib.sha256((out/'frame').read_bytes()).hexdigest(),build_command=['lake','build','hexgroebner_bench'],build_policy='Fresh source snapshot; only pinned dependency packages shared');(out/'builds.json').write_text(json.dumps(records,indent=2)+'\n');shutil.copy2(base/'manifest.json',out/'manifest.json');shutil.copy2(__file__,out/'build.py');print(label,records,flush=True)
