from pathlib import Path
import json,os,subprocess,hashlib,time,sys
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products');state=Path('/home/kim/tmp/issue-10987');base=state/'products-production';build=json.loads((base/'bench-binaries/builds.json').read_text());binary=base/'bench-binaries/frame';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256']
sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
out=base/'kernel-paired';out.mkdir(exist_ok=False);cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[];points={a:[] for a in 'AB'}
try:
 for block,order in enumerate(['AB','BA']):
  for arm in order:
   name='monomialProductsReference' if arm=='A' else 'monomialProducts';prefix=f'block{block}-{arm}';command=[str(binary),'run','Hex.Groebner.Bench.'+name,'--outer-trials','1','--export-file',str(out/(prefix+'.json'))]
   with(out/(prefix+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
   runs.append(dict(block=block,arm=arm,command=command,returncode=r.returncode));assert r.returncode in [0,2];v=json.loads((out/(prefix+'.json')).read_text())['results'][0];assert len(v['points'])==5 and all(x['status']=='ok' for x in v['points']);points[arm]+=v['points'];print(prefix,v['verdict'],flush=True)
 for n in [256,512,1024,2048,4096]:assert len({p['result_hash'] for ps in points.values() for p in ps if p['param']==n})==1
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),build=build,runs=runs,scope='First matched whole-sweep AB/BA comparison in the same fresh executable. A uses scalar per-term native lookup; B uses bounded batch lookup. At fixed arity three and ordinary hashes, all products already exist. Prepared monomial tables excluded; complete output support and final workspace, table count and work are consumed. Automatic CPU lease, all completed samples/RSS/floor/host context retained. No filtering or unchanged repeat. Not full F4, certification, verification or kernel-checking timing.'),indent=2)+'\n');lease.close()
(out/'measure.py').write_bytes(Path(__file__).read_bytes())
