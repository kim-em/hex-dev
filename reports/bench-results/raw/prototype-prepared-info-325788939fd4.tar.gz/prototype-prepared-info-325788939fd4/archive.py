from pathlib import Path
import json,tarfile,hashlib,shutil,subprocess
repo=Path('/tmp/hex-groebner-evidence-review');dest=repo/'reports/bench-results/raw';catalog=[]
for variant in ['append-packed','prepared-info']:
 base=Path('/tmp/hex-groebner-'+variant+'-production');m=json.loads((base/'manifest.json').read_text());fp=m['source_fingerprint'];name='prototype-'+variant+'-'+fp;stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
 for p in base.iterdir():
  if p.name in ['binaries','bench-binaries']:continue
  if p.is_dir():shutil.copytree(p,stage/p.name)
  else:shutil.copy2(p,stage/p.name)
 baseline=Path('/tmp/hex-groebner-scheduling-strengthened-production');bm=json.loads((baseline/'manifest.json').read_text());(stage/'baseline-manifest.json').write_text(json.dumps(bm,indent=2)+'\n')
 for folder,manifest in [('root-sources',m),('baseline-sources',bm)]:
  (stage/(folder+'.manifest')).write_text(manifest['source_manifest'])
  for line in manifest['source_manifest'].splitlines():
   h,n=line.split('\t',1);oid=h.split()[1];data=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;p=stage/folder/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 src=Path('/tmp/hex-groebner-'+variant+'-dev')
 for name2 in ['conformance/HexGroebner/NativeChecks.lean','conformance/HexGroebner/AppendConformance.lean' if variant=='append-packed' else 'conformance/HexGroebner/PreparationConformance.lean','scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh']:
  p=stage/name2;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src/name2,p)
 for p in Path('/tmp').glob('issue-10987-'+variant+'-*.log'):shutil.copy2(p,stage/p.name)
 scope=dict(source_fingerprint=fp,scope='Research variant, not selected. One small 64-process campaign, one medium 56-process campaign and one 120-point registered fixed campaign; no unchanged repeat. All complete bases and non-timing algorithm statistics agree with the baseline. Four Clang and four GCC ASan/UBSan variants exercise the new native calls in real F4 and compare with portable models. No full independent oracle/conformance profile claimed. A fresh 188-job freeze retains exact source blobs and binary hashes; candidate-only and process boundaries stay separate. Every completed sample and outlier is retained, no overall gain or compiler limitation established.')
 if variant=='append-packed':scope['initial_failure']='The initial owned-capacity helper doubled capacity on every shared append even when its old capacity was sufficient. MonomialConformance failed with INTERNAL PANIC: out of memory. The corrected helper preserves sufficient capacity when copying shared arrays, and all same tests and four Clang/four GCC sanitizer variants pass. The original failure and corrected build logs are retained; only corrected source 6b380360b565 was measured.'
 else:scope['proof']='prepareInfo_data proves that projecting prepared bytes returns the exact original portable preparation; its axiom audit reports propext and Quot.sound. Scalar metadata is decoded from that same byte payload. The C implementation is independently differential-tested, not justified by this pure-model theorem.'
 (stage/'scope.json').write_text(json.dumps(scope,indent=2)+'\n');shutil.copy2(__file__,stage/'archive.py');target=dest/(name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
 a=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),fingerprint=fp);catalog.append(a);print(a,flush=True)
Path('/tmp/issue-10987-native-variants-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
