/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

import HexGroebner.Native

namespace Hex.Groebner.PreparationConformance
open Native.Monomial

private def bytes (size seed : Nat) : ByteArray := Id.run do
  let mut out := ByteArray.emptyWithCapacity size
  for i in [:size] do out := out.push (UInt8.ofNat (seed+17*i))
  return out

private def equal : Option Preparation → Option Preparation → Bool
  | none,none => true
  | some a,some b => a.data == b.data && a.degree == b.degree &&
      a.mask == b.mask && a.hash == b.hash && a.largest == b.largest
  | _,_ => false

private def check (op width : UInt8) (arity count left right : UInt64)
    (source workspace : ByteArray) : Bool :=
  let beforeS := source.data.toList
  let beforeW := workspace.data.toList
  let expected := prepareInfoPortable op width arity count left right source workspace
  let actual := prepareInfo op width arity count left right source workspace
  equal actual expected && source.data.toList == beforeS && workspace.data.toList == beforeW

/-- The exact original preparation and scalar metadata agree at all widths,
arity bounds, overflow/inexact quotient, malformed spans and aliased buffers. -/
def runtimeChecks (seed : Nat) : Bool := Id.run do
  for w in [1,2,4] do
    for n in [1,2,7,65,4096] do
      let source := bytes (3*n*w) seed
      let workspace := bytes (4*n+28) (seed+11)
      for op in [0,1,2] do
        for (a,b) in [(0,0),(0,1),(1,0),(1,2)] do
          if !check op w.toUInt8 n.toUInt64 3 a b source workspace then return false
        if !check op w.toUInt8 n.toUInt64 3 3 0 source workspace then return false
        if !check op w.toUInt8 n.toUInt64 3 0 3 source workspace then return false
        if !check op w.toUInt8 n.toUInt64 3 0 1 (source.push 0) workspace then return false
        if !check op w.toUInt8 n.toUInt64 3 0 1 source (workspace.push 0) then return false
  for w in [0,3,5,255] do
    if !check 0 w.toUInt8 1 1 0 0 (bytes w seed) (bytes 32 seed) then return false
  for n in [0,4097,2^64-1] do
    if !check 0 1 n.toUInt64 1 0 0 {} {} then return false
  if !check 3 1 1 1 0 0 (bytes 1 seed) (bytes 32 seed) then return false
  -- Arity seven makes the 56-byte prepared workspace also a valid two-row u32 arena.
  let alias := bytes 56 seed
  for op in [0,1,2] do
    if !check op 4 7 2 0 1 alias alias then return false
  let mut source := bytes 8 0
  source := Native.write source 4 0 4294967295
  source := Native.write source 4 4 1
  for op in [0,1,2] do
    if !check op 4 1 2 0 1 source (bytes 32 seed) then return false
  return true

#guard runtimeChecks 0
#guard runtimeChecks 97

/-- info: 'Hex.Groebner.Native.Monomial.prepareInfo_data' depends on axioms: [propext, Quot.sound] -/
#guard_msgs in
#print axioms prepareInfo_data

end Hex.Groebner.PreparationConformance
