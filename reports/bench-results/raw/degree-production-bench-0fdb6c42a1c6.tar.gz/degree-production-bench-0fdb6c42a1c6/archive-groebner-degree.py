from pathlib import Path
import json,subprocess,shutil,tarfile,hashlib
p=Path('/tmp/hex-groebner-degree-production');dest=Path('/tmp/hex-groebner-evidence-review/reports/bench-results/raw')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for directory in sorted(p.glob('degree-production-*0fdb6c42a1c6')):
 meta=json.loads((directory/'metadata.json').read_text())
 for name in ['Main.lean','ReferenceElimination.lean','ReferenceF4.lean','ReferenceSymbolic.lean','lakefile.lean','lake-manifest.json','lean-toolchain','measure-production.py','measure-bench.py','analyze-diagnostic.py']:
  shutil.copy2(p/name,directory/name)
 shutil.copy2(p/'binaries/manifest.json',directory/'binary-manifest.json');shutil.copy2(p/'binaries/baseline-manifest.json',directory/'baseline-manifest.json');shutil.copy2(__file__,directory/Path(__file__).name)
 for listing,folder in [(meta['source_manifest'],'root-sources'),(json.loads((p/'binaries/baseline-manifest.json').read_text())['source_manifest'],'baseline-sources')]:
  for line in listing.splitlines():
   _,oid,rest=line.split(' ',2);_,name=rest.split('\t');f=directory/folder/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd='/tmp/hex-groebner-degree-dev'))
 for name in ['diagnostic-analysis.json','fixed-analysis.json']:
  shutil.copy2(p/name,directory/name)
 target=dest/(directory.name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(directory,arcname=directory.name)
 print(target.name,sha(target),flush=True)
