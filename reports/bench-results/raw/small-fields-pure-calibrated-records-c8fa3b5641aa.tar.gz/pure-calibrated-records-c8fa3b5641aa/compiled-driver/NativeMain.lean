import KernelBench
@[extern "hex_test_counts"] opaque counts : IO (UInt64 × UInt64)
@[extern "hex_test_vector_counts"] opaque vectors : IO (UInt64 × UInt64)
@[extern "hex_test_avx2"] opaque avx2 : IO Bool
def main (args : List String) : IO UInt32 := do
  if args == ["--check-paths"] then
    let output := Hex.Groebner.Bench.cauchy16Strided (Hex.Groebner.Bench.prepare16Strided 64)
    if !output.1 then throw (IO.userError "strided elimination failed")
    let (scan,gather) ← counts
    let (contiguous,strided) ← vectors
    let available ← avx2
    if scan == 0 then throw (IO.userError "native override was not called")
    if available && strided == 0 then throw (IO.userError "strided SIMD was not called")
    IO.println s!"scan={scan}, gather={gather}, contiguous={contiguous}, strided={strided}, SIMD={available}, rows={output.2.size}"
    return 0
  LeanBench.Cli.dispatch args
