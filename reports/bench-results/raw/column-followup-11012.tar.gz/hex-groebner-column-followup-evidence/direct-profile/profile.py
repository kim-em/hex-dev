from pathlib import Path
import os,json,subprocess,sys,hashlib
root=Path('/tmp/hex-groebner-evidence-review');sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
out=Path('/tmp/hex-groebner-column-direct-profile');out.mkdir(exist_ok=False)
variants={'A':Path('/tmp/hex-groebner-whole-matrix-reviewed-production'),'B':Path('/tmp/hex-groebner-column-revised-production')};cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});records=[];start=os.getloadavg()
for a,p in variants.items():(out/(a+'-manifest.json')).write_bytes((p/'manifest.json').read_bytes())
try:
 for case in ['noon4-31','quadratic5-2147483647']:
  values=[]
  for block,order in enumerate(['AB','BA']):
   for arm in order:
    prefix=f'{case}-{block}-{arm}';binary=variants[arm]/'binaries/compute';input=Path('/tmp/hex-groebner-packed-targets-reviewed-production/before-after-small/inputs')/(case+'.json')
    command=['perf','stat','-x',',','-e','cycles:u,instructions:u,task-clock,context-switches','-o',str(out/(prefix+'.perf.txt')),'--',str(binary),'--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000',str(input)]
    with (out/(prefix+'.stdout')).open('w')as stdout,(out/(prefix+'.stderr')).open('w')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
    records.append(dict(case=case,block=block,arm=arm,command=command,returncode=r.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),input_sha256=hashlib.sha256(input.read_bytes()).hexdigest()));assert r.returncode==0
    v=json.loads((out/(prefix+'.stdout')).read_text());values.append((v['basis'],{k:v for k,v in v['statistics'].items()if k not in ['work','allocatedBytes']}));print(prefix,'passed',flush=True)
  assert all(v==values[0]for v in values)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=start,load_end=os.getloadavg(),scope='Explanatory whole-process user-cycle and instruction profile of baseline hash maps and revised direct maps on two direct-only small inputs. One leased CPU, adjacent AB/BA, eight complete processes; full bases and non-resource counters compared. All counter records, outputs, failures and host activity retained. Profile wall durations are not timing estimates and replace none of the historical measurements. These tiny whole-process counters do not isolate the direct path or establish the cause of earlier outliers.',runs=records),indent=2)+'\n');lease.close()
(out/'profile.py').write_bytes(Path(__file__).read_bytes())
