/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

import HexGroebner.Native

namespace Hex.Groebner.AppendConformance
open Native.Monomial

private def bytes (size seed : Nat) : ByteArray := Id.run do
  let mut out := ByteArray.emptyWithCapacity size
  for i in [:size] do out := out.push (UInt8.ofNat (seed+17*i))
  return out

private def equal (a b : AppendResult) : Bool :=
  a.exponents == b.exponents && a.metadata == b.metadata && a.accepted == b.accepted

private def check (width : UInt8) (arity degree mask hash : UInt64)
    (prepared exponents metadata : ByteArray) : Bool :=
  let savedP := prepared.data.toList
  let savedE := exponents.data.toList
  let savedM := metadata.data.toList
  let expected := appendPreparedPortable width arity degree mask hash prepared exponents metadata
  let actual := appendPrepared width arity degree mask hash prepared exponents metadata
  equal actual expected && prepared.data.toList == savedP &&
    exponents.data.toList == savedE && metadata.data.toList == savedM

/-- Exercise all widths and arity boundaries, retained shared inputs, direct
arena aliases, malformed spans, coordinate overflow and arbitrary metadata. -/
def runtimeChecks (seed : Nat) : Bool := Id.run do
  for w in [1,2,4] do
    for n in [1,2,6,7,65,4096] do
      let mut prepared := bytes (n*4+28) seed
      for i in [:n] do
        prepared := Native.write prepared 4 (i*4) ((seed+11*i+1) % 2^(8*w))
      for count in [0,1,3] do
        let exponents := bytes (count*n*w) (seed+3)
        let metadata := bytes (count*24) (seed+5)
        if !check w.toUInt8 n.toUInt64 (2^64-1) 0x0123456789abcdef
            0xfedcba9876543210 prepared exponents metadata then return false
        if !check w.toUInt8 n.toUInt64 1 2 3 (prepared.extract 0 (prepared.size-1)) exponents metadata then
          return false
        if !check w.toUInt8 n.toUInt64 1 2 3 prepared (exponents.push 0) metadata then return false
        if !check w.toUInt8 n.toUInt64 1 2 3 prepared exponents (metadata.push 0) then return false
        if w < 4 then
          let bad := Native.write prepared 4 ((n-1)*4) (2^(8*w))
          if !check w.toUInt8 n.toUInt64 1 2 3 bad exponents metadata then return false
          if (appendPrepared w.toUInt8 n.toUInt64 1 2 3 bad exponents metadata).accepted then return false
  for w in [0,3,5,255] do
    if !check w.toUInt8 1 1 2 3 (bytes 32 seed) {} {} then return false
  for n in [0,4097,2^64-1] do
    if !check 1 n.toUInt64 1 2 3 {} {} {} then return false
  -- Exact same arena object occupies both owned arguments (stride 24).
  let arenas := bytes 24 seed
  let prepared := bytes 52 0
  if !check 4 6 1 2 3 prepared arenas arenas then return false
  -- Borrowed prepared bytes alias the exponent arena (arity 1, count 8).
  let prepared := bytes 32 seed
  if !check 4 1 1 2 3 prepared prepared (bytes 192 seed) then return false
  -- Borrowed prepared bytes alias the metadata arena (arity 5, count 2).
  let prepared := bytes 48 seed
  if !check 4 5 1 2 3 prepared (bytes 40 seed) prepared then return false
  return true

#guard runtimeChecks 0
#guard runtimeChecks 97

end Hex.Groebner.AppendConformance
