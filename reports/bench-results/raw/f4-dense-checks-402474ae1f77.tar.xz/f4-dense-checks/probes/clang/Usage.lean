import HexGroebner.Driver.Run
@[extern "hex_test_dense_counts"] opaque denseCounts : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_dense_admitted"] opaque denseAdmitted : IO UInt64
@[extern "hex_test_whole_counts"] opaque wholeCounts : IO (UInt64 × UInt64)
def main (args : List String) : IO UInt32 := do
  let status ← Hex.Groebner.Driver.run args
  let (prepares,scans,updates) ← denseCounts
  let admitted ← denseAdmitted
  let (accepted,declined) ← wholeCounts
  (← IO.getStderr).putStrLn (Lean.Json.mkObj [
    ("prepares",Lean.toJson prepares),("admitted",Lean.toJson admitted),
    ("scans",Lean.toJson scans),("updates",Lean.toJson updates),
    ("bulkAccepted",Lean.toJson accepted),("bulkDeclined",Lean.toJson declined)]).compress
  return status
