import HexGroebner.PairRowsConformance
@[extern "hex_test_support_count"] opaque queues : IO UInt64
@[extern "hex_test_support_clears"] opaque clears : IO UInt64
@[extern "hex_test_support_copies"] opaque copies : IO UInt64
@[extern "owner_pending_copies"] opaque pendingCopies : IO UInt64

def main : IO Unit := do
  let value := (← IO.getEnv "HEX_GROEBNER_TEST_SEED").getD "0"
  let some seed := value.toNat? | throw (IO.userError "invalid seed")
  for route in [:3] do
    let q ← queues
    let c ← clears
    let b ← copies
    let p ← pendingCopies
    let valid := Hex.Groebner.PairRowsConformance.systemChecks seed route
    IO.println s!"{route},{valid},{(← queues)-q},{(← clears)-c},{(← copies)-b},{(← pendingCopies)-p}"
    if !valid then throw (IO.userError "public-route result mismatch")
