import Lake
open Lake DSL System
package GroebnerOwnerControl
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration"

def probeO (pkg : Package) (name : String) (flags : Array String) : FetchM (Job FilePath) := do
  let source ← inputTextFile (pkg.dir / "probe.c")
  let scan ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/matrix_scan.c")
  let simd ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/matrix_simd.h")
  let wide ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/matrix_avx512.h")
  let body ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/matrix_scan_impl.h")
  let row ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/row_update.c")
  let trie ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/trie_lookup.h")
  let hit ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/monomial_hit.c")
  let runtimeHeader ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/matrix_runtime.h")
  let whole ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/matrix_eliminate.c")
  let continuation ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration/HexGroebner/ffi/matrix_state.c")
  let inputs := ((source.zipWith (fun s _ => s) scan).zipWith (fun s _ => s) simd).zipWith (fun s _ => s) body
  let inputs := inputs.zipWith (fun s _ => s) wide
  let inputs := (inputs.zipWith (fun s _ => s) row).zipWith (fun s _ => s) trie
  let inputs := inputs.zipWith (fun s _ => s) hit
  let inputs := (inputs.zipWith (fun s _ => s) whole).zipWith (fun s _ => s) continuation
  let inputs := inputs.zipWith (fun s _ => s) runtimeHeader
  buildO (pkg.dir / defaultBuildDir / (name ++ ".o")) inputs
    #["-isystem", (← getLeanIncludeDir).toString] flags
    (compiler := FilePath.mk "/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang")
    (extraDepTrace := do addPureTrace "/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang" "compiler"; pure BuildTrace.nil)

target probeNative pkg : FilePath := probeO pkg "Native" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_ENABLE_AVX512", "-fsanitize=address,undefined", "-fno-sanitize-recover=undefined", "-fno-omit-frame-pointer"]
lean_exe owner where
  root := `Owner
  moreLinkObjs := #[probeNative]
  moreLinkArgs := #["-Wl,--wrap=lean_array_push", "-Wl,--wrap=lean_hex_groebner_queue_support", "-Wl,--wrap=lean_hex_groebner_clear_support", "-Wl,--wrap=lean_hex_groebner_subtract_row", "-Wl,--wrap=lean_hex_monomial_products_attempt", "-Wl,--wrap=lean_hex_matrix_validate", "-Wl,--wrap=lean_hex_matrix_zeros", "-Wl,--wrap=lean_hex_matrix_advance", "-Wl,--wrap=lean_hex_groebner_remap_index", "-Wl,--wrap=lean_hex_groebner_append_zeros", "-Wl,--wrap=lean_hex_groebner_remap_columns", "-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather", "-Wl,--wrap=lean_hex_prepare_dense", "-Wl,--wrap=lean_hex_dense_transition", "-Wl,--wrap=lean_hex_groebner_equal_bytes", "-Wl,--wrap=lean_hex_groebner_equal_products", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_groebner_combine_owned", "-Wl,--wrap=lean_hex_groebner_search_monomial", "-Wl,--wrap=lean_hex_groebner_compare_monomials", "-Wl,--wrap=lean_hex_groebner_lookup_trie", "-Wl,--wrap=lean_hex_groebner_validate_trie", "/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/resource-root/lib/linux/libclang_rt.asan-x86_64.so"]

