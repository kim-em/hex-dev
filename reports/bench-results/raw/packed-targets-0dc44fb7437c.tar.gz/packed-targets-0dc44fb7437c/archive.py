from pathlib import Path
import json,tarfile,hashlib,shutil,subprocess
repo=Path('/tmp/hex-groebner-packed-targets-dev');dest=repo/'reports/bench-results/raw';catalog=[]
for variant in ['packed-targets']:
 base=Path('/tmp/hex-groebner-'+variant+'-production');m=json.loads((base/'manifest.json').read_text());fp=m['source_fingerprint'];name=variant+'-'+fp;stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
 for p in base.iterdir():
  if p.name in ['binaries','bench-binaries']:continue
  if p.is_dir():shutil.copytree(p,stage/p.name)
  else:shutil.copy2(p,stage/p.name)
 bm=json.loads(Path('/tmp/hex-groebner-scheduling-strengthened-production/manifest.json').read_text());(stage/'baseline-manifest.json').write_text(json.dumps(bm,indent=2)+'\n')
 for folder,manifest in [('root-sources',m),('baseline-sources',bm)]:
  (stage/(folder+'.manifest')).write_text(manifest['source_manifest'])
  for line in manifest['source_manifest'].splitlines():
   h,n=line.split('\t',1);oid=h.split()[1];data=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;p=stage/folder/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 scope=dict(source_fingerprint=fp,scope='Compact typed hash index and bounded native owned monomial construction on degree-scheduled F4. Separate source fingerprints are not pooled. Each source has one 64-process small and one 56-process medium first campaign, all complete bases equal, no failures/timeouts, no unchanged repeat. Candidate and process timing boundaries stay separate. Baseline source and all completed samples/outputs are retained. No compiler limitation or fastest-open-source claim.')
 if variant=='packed-targets':
  for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(repo/folder,stage/folder)
  for n in ['scripts/ci/check_groebner_rows.sh','scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_driver.py']:
   p=stage/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,p)
  for pat in ['issue-10987-packed-targets-*.log']:
   for p in Path('/tmp').glob(pat):shutil.copy2(p,stage/p.name)
  scope['validation']='Pre-review combined snapshot: 2161 conformance/theory/driver/bench jobs, independent full oracles, four Clang/four GCC sanitizer variants and all32 benchmark checks pass. The dependency audit fails because the native carrier is missing from the checker allowlist; its error is retained. Direct exclusive aliased insertion tests and corrected registration belong to later source, not this snapshot. Existing F4 counters exercise unique-table reuse but do not replace that later direct boundary coverage. Both small and medium observations have one first campaign and no unchanged repeat; fixed has120 points and equal complete structural output hashes.' 
 else:scope['validation']='Initial current-degree port before additional native harness registration. Its core library builds and CLI full-basis comparisons pass. Full final validation belongs to separate source78e8924c19cb, not this initial snapshot.'
 (stage/'scope.json').write_text(json.dumps(scope,indent=2)+'\n');shutil.copy2(__file__,stage/'archive.py');shutil.copy2('/tmp/analyze-groebner-target-columns.py',stage/'analyze.py');target=dest/(name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
 a=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),fingerprint=fp);catalog.append(a);print(a,flush=True)
Path('/tmp/issue-10987-packed-targets-prereview-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
