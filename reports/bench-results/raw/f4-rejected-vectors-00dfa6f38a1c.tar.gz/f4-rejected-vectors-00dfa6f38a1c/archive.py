from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile,sys
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');name='f4-rejected-vectors-00dfa6f38a1c';payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
sys.path.insert(0,str(root));from scripts.bench.groebner_performance_audit import campaign
analyses={}
for label in ['avx512-production','geometry-inline-production']:
 base=state/label
 for directory in sorted(base.glob('before-after*')):analyses[label+'/'+directory.name]=campaign(directory)
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if p.is_file() and rel.parts[0]!='binaries':add(label+'/'+str(rel),p.read_bytes())
for directory in ['avx512-clang','avx512-gcc','avx512-profile']:
 for p in sorted((state/directory).rglob('*')):
  if p.is_file() and '.lake' not in p.relative_to(state/directory).parts:add(directory+'/'+str(p.relative_to(state/directory)),p.read_bytes())
for pattern in ['avx512-*.py','avx512-*.json','avx512-*.log','avx512-probe.c','add-avx512*.py','geometry-inline-*.py','geometry-inline-*.json','geometry-inline-*.log']:
 for p in sorted(state.glob(pattern)):
  if p.is_file():add('reproduction/'+p.name,p.read_bytes())
for rel in ['issue-10987-lean-cc','issue-10987-lean-cc-flags.json','analyze-equivalence-candidates.py']:
 add('reproduction/'+rel,(state/rel).read_bytes())
base='81e3490e71d17939bfc9e7ab790bb7078dd05ca2'
for label,commit in [('avx512','d5c8b1c973fd61abf924ba514c03ed001fab8507'),('geometry-inline','7c1d872f40')]:
 add(label+'.patch',subprocess.check_output(['git','diff','--binary',base,commit,'--','.',':!reports'],cwd=root))
add('source-base.txt',(base+'\n').encode());add('independent-analysis.json',(json.dumps(analyses,indent=2)+'\n').encode());add('archive.py',Path(__file__).read_bytes());add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest() for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=state/(name+'.tar.gz')
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/'rejected-vectors-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
