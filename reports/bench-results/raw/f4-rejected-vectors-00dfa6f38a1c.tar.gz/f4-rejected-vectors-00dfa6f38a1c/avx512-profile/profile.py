from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
state=Path('/home/kim/tmp/issue-10987');base=state/'avx512-production';out=state/'avx512-profile';out.mkdir(exist_ok=False)
while not(state/'avx512-measure-repeat-status.json').is_file():time.sleep(5)
helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('frozen_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[]
try:
 for label,directory in [('baseline','performance-final-production'),('new','avx512-production')]:
  program=[str(state/directory/'binaries/compute'),'--scheduling','degree','--work','100000000000',str(state/'final-products-production/medium-inputs/eco11-31.json')]
  command=['perf','record','-e','cycles:u','-F','1999','--call-graph','dwarf,16384','-o',str(out/(label+'.data')),'--',*program]
  with(out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  runs.append(dict(label=label,command=command,exit_code=r.returncode,manifest=json.loads((state/directory/'manifest.json').read_text())));assert r.returncode==0
  for options,suffix in [(['--no-children','--percent-limit','0.5'],'report'),(['--header-only'],'header')]:
   with(out/(label+'.'+suffix)).open('w') as f:subprocess.run(['perf','report','--stdio',*options,'-i',str(out/(label+'.data'))],stdout=f,stderr=subprocess.STDOUT,check=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads='Serial algorithm, runtime auxiliary threads. Single-CPU affinity inherited.',host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),runs=runs,helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),scope='Diagnostic user-cycle profiles after an inconclusive wider-vector campaign. Startup/input/output included. Cost attribution only, not matched timing or acceptance evidence.'),indent=2)+'\n');lease.close()
(out/'profile.py').write_bytes(Path(__file__).read_bytes())
