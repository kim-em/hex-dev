from pathlib import Path
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-avx512')
p=root/'HexGroebner/ffi/matrix_simd.h';s=p.read_text();point='static inline uint32_t hex_mont32_inverse(uint32_t p) {';new='''/* AVX-512 requires the OS to preserve opmask and all ZMM register state,
   in addition to the XMM/YMM state checked by the AVX2 route. */
static inline int hex_avx512_available(void) {
    static atomic_uint cached=0;
    unsigned known=atomic_load_explicit(&cached,memory_order_relaxed);
    if(known) return known==2;
    unsigned a,b,c,d,lo,hi;
    int available=0;
    const unsigned xsave=(1u<<26)|(1u<<27)|(1u<<28);
    if(__get_cpuid(1,&a,&b,&c,&d) && (c&xsave)==xsave) {
        __asm__ volatile("xgetbv" : "=a"(lo),"=d"(hi) : "c"(0));
        (void)hi;
        if((lo&0xe6)==0xe6 && __get_cpuid_count(7,0,&a,&b,&c,&d) &&
                (b&(1u<<5)) && (b&(1u<<16))) available=1;
    }
    atomic_store_explicit(&cached,available?2:1,memory_order_relaxed);
    return available;
}

''';s=s.replace(point,new+point);point='\n#else\n#define HEX_GROEBNER_AVX2 0';new='''
/* Sixteen width-four updates. Every column, ordering and coefficient check
   precedes any store; rejection leaves the accumulator unchanged, allowing
   the eight-lane/scalar route to retain the precise malformed-input prefix. */
__attribute__((target("avx512f,avx2"),always_inline))
static inline unsigned hex_scan16_mode(uint8_t *dense,const uint8_t *columns,const uint8_t *coefficients,
        size_t entry,uint64_t column_count,uint32_t p,uint32_t multiplier,uint32_t reduction,unsigned mersenne) {
    __m512i j=_mm512_loadu_si512((const void *)(columns+entry*4));
    __m512i b=_mm512_loadu_si512((const void *)(coefficients+entry*4));
    uint32_t first,last;
    memcpy(&first,columns+entry*4,4);memcpy(&last,columns+(entry+15)*4,4);
    if(first>INT32_MAX || last>INT32_MAX || (uint64_t)last>=column_count) return 0;
    if(entry) {uint32_t previous;memcpy(&previous,columns+(entry-1)*4,4);if(previous>=first) return 0;}
    __m512i before=_mm512_permutexvar_epi32(_mm512_setr_epi32(0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14),j);
    if(_mm512_mask_cmp_epi32_mask(0xfffe,j,before,_MM_CMPINT_LE)) return 0;
    __m512i pv=_mm512_set1_epi32((int32_t)p),zero=_mm512_setzero_si512();
    if(_mm512_cmp_epi32_mask(b,zero,_MM_CMPINT_LE) ||
            _mm512_cmp_epi32_mask(b,pv,_MM_CMPINT_GE)) return 0;
    int contiguous=last-first==15;
    __m512i a=contiguous?_mm512_loadu_si512((const void *)(dense+(size_t)first*4)):
        _mm512_i32gather_epi32(j,(const void *)dense,4);
    if(_mm512_cmp_epi32_mask(a,zero,_MM_CMPINT_LT) ||
            _mm512_cmp_epi32_mask(a,pv,_MM_CMPINT_GE)) return 0;
    __m512i product;
    if(mersenne) {
        HEX_GROEBNER_MERSENNE_USED();
        uint32_t canonical=(multiplier>>1)+(multiplier&1)*UINT32_C(1073741824);
        __m512i f=_mm512_set1_epi64(canonical),p64=_mm512_set1_epi64(INT32_MAX);
        __m512i even=_mm512_mul_epu32(b,f),odd=_mm512_mul_epu32(_mm512_srli_epi64(b,32),f);
        even=_mm512_add_epi64(_mm512_and_si512(even,p64),_mm512_srli_epi64(even,31));
        odd=_mm512_add_epi64(_mm512_and_si512(odd,p64),_mm512_srli_epi64(odd,31));
        even=_mm512_mask_sub_epi64(even,_mm512_cmp_epu64_mask(even,p64,_MM_CMPINT_GE),even,p64);
        odd=_mm512_mask_sub_epi64(odd,_mm512_cmp_epu64_mask(odd,p64,_MM_CMPINT_GE),odd,p64);
        product=_mm512_or_si512(even,_mm512_slli_epi64(odd,32));
    } else {
        __m512i f=_mm512_set1_epi32((int32_t)multiplier),inv=_mm512_set1_epi32((int32_t)reduction);
        __m512i p64=_mm512_set1_epi64(p);
        __m512i even=_mm512_mul_epu32(b,f),odd=_mm512_mul_epu32(_mm512_srli_epi64(b,32),f);
        __m512i me=_mm512_mullo_epi32(even,inv),mo=_mm512_mullo_epi32(odd,inv);
        even=_mm512_srli_epi64(_mm512_add_epi64(even,_mm512_mul_epu32(me,p64)),32);
        odd=_mm512_srli_epi64(_mm512_add_epi64(odd,_mm512_mul_epu32(mo,p64)),32);
        even=_mm512_mask_sub_epi64(even,_mm512_cmp_epu64_mask(even,p64,_MM_CMPINT_GE),even,p64);
        odd=_mm512_mask_sub_epi64(odd,_mm512_cmp_epu64_mask(odd,p64,_MM_CMPINT_GE),odd,p64);
        product=_mm512_or_si512(even,_mm512_slli_epi64(odd,32));
    }
    __m512i difference=_mm512_sub_epi32(a,product);
    difference=_mm512_mask_add_epi32(difference,_mm512_cmp_epi32_mask(difference,zero,_MM_CMPINT_LT),difference,pv);
    if(contiguous) _mm512_storeu_si512((void *)(dense+(size_t)first*4),difference);
    else _mm512_i32scatter_epi32((void *)dense,j,difference,4);
    return 16;
}
__attribute__((target("avx512f,avx2"),always_inline))
static inline unsigned hex_scan16(uint8_t *dense,const uint8_t *columns,const uint8_t *coefficients,
        size_t entry,uint64_t column_count,uint32_t p,uint32_t multiplier,uint32_t reduction) {
    return hex_scan16_mode(dense,columns,coefficients,entry,column_count,p,multiplier,reduction,0);
}
__attribute__((target("avx512f,avx2"),always_inline))
static inline unsigned hex_scan16_m31(uint8_t *dense,const uint8_t *columns,const uint8_t *coefficients,
        size_t entry,uint64_t column_count,uint32_t p,uint32_t multiplier,uint32_t reduction) {
    if(p!=INT32_MAX) return 0;
    return hex_scan16_mode(dense,columns,coefficients,entry,column_count,p,multiplier,reduction,1);
}
''';assert point in s;s=s.replace(point,new+point);p.write_text(s)
p=root/'HexGroebner/ffi/matrix_scan_impl.h';s=p.read_text();point='''                    for(uint64_t k=0;k<updates;++k) {
                        if(updates-k>=8''';new='''                    for(uint64_t k=0;k<updates;++k) {
#if HEX_SCAN_VECTOR >= 2
                        if(updates-k>=16 && HEX_SCAN_UPDATE16(data,cs,vs,(size_t)entry,columns,
                                (uint32_t)p,multiplier,reduction)) {
                            entry+=16;k+=15;continue;
                        }
#endif
                        if(updates-k>=8''';assert point in s;s=s.replace(point,new);p.write_text(s)
p=root/'HexGroebner/ffi/matrix_scan.c';s=p.read_text();point='\nLEAN_EXPORT lean_obj_res lean_hex_scan_transition';new='''
#if HEX_GROEBNER_AVX2
#define HEX_SCAN_UPDATE16 hex_scan16
#define HEX_SCAN_NAME hex_scan_avx512
#define HEX_SCAN_ATTRIBUTE __attribute__((target("avx512f,avx2")))
#define HEX_SCAN_VECTOR 2
#define HEX_SCAN_WIDTH 4
#include "matrix_scan_impl.h"
#undef HEX_SCAN_NAME
#undef HEX_SCAN_ATTRIBUTE
#undef HEX_SCAN_VECTOR
#undef HEX_SCAN_WIDTH
#undef HEX_SCAN_UPDATE16
#undef HEX_SCAN_UPDATE
#define HEX_SCAN_UPDATE hex_scan8_m31
#define HEX_SCAN_UPDATE16 hex_scan16_m31
#define HEX_SCAN_NAME hex_scan_avx512_m31
#define HEX_SCAN_ATTRIBUTE __attribute__((target("avx512f,avx2")))
#define HEX_SCAN_VECTOR 2
#define HEX_SCAN_WIDTH 4
#include "matrix_scan_impl.h"
#undef HEX_SCAN_NAME
#undef HEX_SCAN_ATTRIBUTE
#undef HEX_SCAN_VECTOR
#undef HEX_SCAN_WIDTH
#undef HEX_SCAN_UPDATE16
#undef HEX_SCAN_UPDATE
#define HEX_SCAN_UPDATE hex_scan8
#endif
''';assert point in s;s=s.replace(point,'\n'+new+point);point='''    if(p>65536 && (p&1) && hex_avx2_available()) {
''';new='''    if(p>65536 && (p&1) && hex_avx2_available()) {
        if(hex_avx512_available()) {
            if(p==INT32_MAX) return hex_scan_avx512_m31(p,slots,pivots,initial,quantum,work,trace,provenance);
            return hex_scan_avx512(p,slots,pivots,initial,quantum,work,trace,provenance);
        }
''';assert point in s;s=s.replace(point,new);p.write_text(s)
