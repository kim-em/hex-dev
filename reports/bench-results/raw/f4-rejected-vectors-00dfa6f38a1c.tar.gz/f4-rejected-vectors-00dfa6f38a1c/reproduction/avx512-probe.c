#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-avx512/HexGroebner/ffi/matrix_simd.h"
static uint64_t state=10987;
static uint32_t random32(void) {state^=state<<13;state^=state>>7;state^=state<<17;return (uint32_t)state;}
#if HEX_GROEBNER_AVX2
__attribute__((target("avx512f,avx2")))
static void check(void) {
 uint32_t primes[]={65537,65539,998244353,2147483629,2147483647};
 for(unsigned pi=0;pi<5;++pi) for(unsigned t=0;t<1000;++t) {
  uint32_t p=primes[pi],factor=random32()%p,multiplier=(uint32_t)(((uint64_t)factor<<32)%p),inverse=hex_mont32_inverse(p);
  uint32_t cs[33],vs[33],dense[512],copy[512],expected[512];unsigned stride=t%3==0?1:7,entry=t%2;
  for(unsigned k=0;k<512;++k) dense[k]=k%3==0?0:k%3==1?p-1:random32()%p;
  memcpy(copy,dense,sizeof(dense));memcpy(expected,dense,sizeof(dense));
  for(unsigned k=0;k<33;++k){cs[k]=k*stride;vs[k]=k%3==0?1:k%3==1?p-1:random32()%(p-1)+1;}
  for(unsigned k=entry;k<entry+16;++k)expected[cs[k]]=(uint32_t)((dense[cs[k]]+(uint64_t)p-(uint64_t)factor*vs[k]%p)%p);
  assert(hex_scan16((uint8_t*)dense,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==16);
  assert(memcmp(dense,expected,sizeof(dense))==0);
  if(p==INT32_MAX){assert(hex_scan16_m31((uint8_t*)copy,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==16);assert(memcmp(copy,expected,sizeof(copy))==0);}
  for(unsigned k=entry;k<entry+16;++k){
   uint32_t saved=vs[k];vs[k]=k%2?0:p;memcpy(copy,dense,sizeof(dense));assert(hex_scan16((uint8_t*)dense,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==0);assert(memcmp(copy,dense,sizeof(copy))==0);vs[k]=saved;
   saved=cs[k];cs[k]=k%2?UINT32_MAX:512;assert(hex_scan16((uint8_t*)dense,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==0);assert(memcmp(copy,dense,sizeof(copy))==0);cs[k]=saved;
   saved=dense[cs[k]];dense[cs[k]]=p;memcpy(copy,dense,sizeof(dense));assert(hex_scan16((uint8_t*)dense,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==0);assert(memcmp(copy,dense,sizeof(copy))==0);dense[cs[k]]=saved;
  }
 }
}
#endif
int main(void) {
#if HEX_GROEBNER_AVX2
 if(hex_avx512_available()){check();puts("AVX512 probe passed");return 0;}
#endif
 puts("AVX512 unavailable");return 2;
}
