from pathlib import Path
p=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-avx512/HexGroebner/ffi/matrix_scan_selftest.c');s=p.read_text();point='/* Exhaust all odd one-byte moduli';new='''__attribute__((target("avx512f,avx2")))
static void check16(uint32_t p,uint32_t factor,unsigned stride,unsigned entry) {
    uint32_t cs[33],vs[33],dense[512],copy[512],expected[512];
    uint32_t multiplier=(uint32_t)(((uint64_t)factor<<32)%p),inverse=hex_mont32_inverse(p);
    for(unsigned k=0;k<512;++k) dense[k]=k%3==0?0:k%3==1?p-1:random32()%p;
    memcpy(copy,dense,sizeof(dense));memcpy(expected,dense,sizeof(dense));
    for(unsigned k=0;k<33;++k) {cs[k]=k*stride;vs[k]=k%3==0?1:k%3==1?p-1:random32()%(p-1)+1;}
    for(unsigned k=entry;k<entry+16;++k)
        expected[cs[k]]=(uint32_t)((dense[cs[k]]+(uint64_t)p-(uint64_t)factor*vs[k]%p)%p);
    assert(hex_scan16((uint8_t*)dense,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==16);
    assert(memcmp(dense,expected,sizeof(dense))==0);
    if(p==INT32_MAX) {
        assert(hex_scan16_m31((uint8_t*)copy,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==16);
        assert(memcmp(copy,expected,sizeof(copy))==0);
    }
    for(unsigned k=entry;k<entry+16;++k) {
        uint32_t saved=vs[k];
        for(unsigned bad=0;bad<2;++bad) {
            vs[k]=bad?p:0;memcpy(copy,dense,sizeof(dense));
            assert(hex_scan16((uint8_t*)dense,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==0);
            assert(memcmp(copy,dense,sizeof(copy))==0);
        }
        vs[k]=saved;saved=cs[k];
        uint32_t invalid[]={512,UINT32_MAX,UINT32_C(2147483648),k?cs[k-1]:cs[k+1]};
        for(unsigned bad=0;bad<4;++bad) {
            cs[k]=invalid[bad];memcpy(copy,dense,sizeof(dense));
            assert(hex_scan16((uint8_t*)dense,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==0);
            assert(memcmp(copy,dense,sizeof(copy))==0);
        }
        cs[k]=saved;saved=dense[cs[k]];dense[cs[k]]=p;memcpy(copy,dense,sizeof(dense));
        assert(hex_scan16((uint8_t*)dense,(uint8_t*)cs,(uint8_t*)vs,entry,512,p,multiplier,inverse)==0);
        assert(memcmp(copy,dense,sizeof(copy))==0);dense[cs[k]]=saved;
    }
}

''';assert point in s;s=s.replace(point,new+point);point='static unsigned width(uint32_t p)';new='''__attribute__((target("avx512f,avx2")))
static void check16_guard(uint32_t p,unsigned stride,unsigned at_end) {
    struct guarded_buffer d=guarded(128*4,at_end),c=guarded(16*4,at_end),v=guarded(16*4,at_end);
    uint32_t columns[16],coefficients[16],dense[128],expected[128];
    uint32_t factor=p-1,f=(uint32_t)(((uint64_t)factor<<32)%p),inverse=hex_mont32_inverse(p);
    for(unsigned i=0;i<128;++i) dense[i]=i%3?p-1:0;
    for(unsigned i=0;i<16;++i) {columns[i]=127-(15-i)*stride;coefficients[i]=i%2?p-1:1;}
    memcpy(expected,dense,sizeof(dense));
    for(unsigned i=0;i<16;++i)
        expected[columns[i]]=(uint32_t)((expected[columns[i]]+(uint64_t)p-(uint64_t)factor*coefficients[i]%p)%p);
    memcpy(d.data,dense,sizeof(dense));memcpy(c.data,columns,sizeof(columns));memcpy(v.data,coefficients,sizeof(coefficients));
    assert(hex_scan16(d.data,c.data,v.data,0,128,p,f,inverse)==16);
    assert(memcmp(d.data,expected,sizeof(expected))==0);
    columns[15]=128;memcpy(c.data,columns,sizeof(columns));
    assert(hex_scan16(d.data,c.data,v.data,0,128,p,f,inverse)==0);
    assert(memcmp(d.data,expected,sizeof(expected))==0);
    columns[15]=127;columns[12]=UINT32_MAX;memcpy(c.data,columns,sizeof(columns));
    assert(hex_scan16(d.data,c.data,v.data,0,128,p,f,inverse)==0);
    assert(memcmp(d.data,expected,sizeof(expected))==0);
    columns[12]=127-3*stride;coefficients[15]=p;
    memcpy(c.data,columns,sizeof(columns));memcpy(v.data,coefficients,sizeof(coefficients));
    assert(hex_scan16(d.data,c.data,v.data,0,128,p,f,inverse)==0);
    assert(memcmp(d.data,expected,sizeof(expected))==0);
    release(d);release(c);release(v);
}
''';assert point in s;s=s.replace(point,new+point);point='''        for(unsigned k=0;k<10000;++k) {''';new='''        if(hex_avx512_available()) {
            for(unsigned i=0;i<sizeof(fields)/sizeof(fields[0]);++i) {
                uint32_t p=fields[i];
                for(unsigned k=0;k<1000;++k) check16(p,random32()%p,k%3?7:1,k%3?1:0);
                for(unsigned stride=1;stride<=8;++stride) for(unsigned entry=0;entry<=16;++entry) {
                    check16(p,0,stride,entry);check16(p,1,stride,entry);check16(p,p-1,stride,entry);
                }
            }
#if defined(__unix__) || defined(__APPLE__)
            for(unsigned stride=1;stride<=8;++stride) for(unsigned end=0;end<2;++end) {
                check16_guard(65537,stride,end);check16_guard(INT32_MAX,stride,end);
            }
#endif
            puts("exact AVX-512 Montgomery/Mersenne updates and guard pages: passed");
        }
        for(unsigned k=0;k<10000;++k) {''';assert point in s;s=s.replace(point,new);p.write_text(s)
