from pathlib import Path
import json,subprocess,time
state=Path('/home/kim/tmp/issue-10987');base=state/'avx512-production'
while not(base/'manifest.json').is_file():time.sleep(5)
command=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'final-products-production/medium-inputs/suite.json'),'--hex',str(base/'binaries/compute'),'--hex-scheduling','degree','--baseline',str(state/'performance-final-production/binaries/compute'),'--baseline-manifest',str(state/'performance-final-production/manifest.json'),'--baseline-scheduling','degree','--output',str(base/'before-after-repeat')]
start=time.monotonic()
with (state/'avx512-before-after-repeat.log').open('w') as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
(state/'avx512-measure-repeat-status.json').write_text(json.dumps(dict(command=command,exit_code=r.returncode,seconds=time.monotonic()-start),indent=2)+'\n');assert r.returncode==0
subprocess.run(['python3',str(state/'analyze-equivalence-candidates.py'),str(base/'before-after-repeat')],check=True)
