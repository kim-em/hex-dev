from pathlib import Path
import hashlib,io,json,lzma,tarfile
state=Path('/home/kim/tmp/issue-10987');base=state/'sampled-reviewed-production';payload={}
for path in sorted(base.rglob('*')):
 rel=path.relative_to(base)
 if path.is_file() and 'binaries' not in rel.parts:
  payload['sampled-reviewed/'+str(rel)]=path.read_bytes()
for name in ['measure-sampled-reviewed.py','sampled-reviewed-kernel-measure.py']:
 payload['reproduction/'+name]=(state/name).read_bytes()
payload['reproduction/pack-sampled-reviewed-science.py']=Path(__file__).read_bytes()
manifest={k:hashlib.sha256(v).hexdigest()for k,v in sorted(payload.items())};payload['sha256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=Path('reports/bench-results/raw/f4-sampling-58952f05cd8c.tar.xz')
with lzma.open(out,'wb',preset=9)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-sampling-reviewed/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
