from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
s=Path('/home/kim/tmp/issue-10987');old=s/'monomial-batches-pr-fixed-verified-clang';out=s/'monomial-batch-usage-audit';out.mkdir(exist_ok=False)
sys.path.insert(0,str(Path.cwd()));from scripts.bench.groebner_checks import source_identity
identity=source_identity();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in old.iterdir():
 if p.is_file():shutil.copy2(p,out/p.name)
(out/'.lake').mkdir();(out/'.lake/packages').symlink_to(old/'.lake/packages',target_is_directory=True)
subprocess.run(['cp','-a','--reflink=auto',str(old/'.lake/build'),str(out/'.lake/build')],check=True)
p=out/'probe.c';t=p.read_text();needle=' return hex_test_products_attempt(table,support,monomial,start,count,max_count,max_bytes,max_work,native);';assert t.count(needle)==1
replacement=''' uint64_t fallback_terms=0;
 if(lean_is_scalar(start) && lean_is_scalar(count)) {
  uint64_t first=lean_unbox(start),n=lean_sarray_size(support)/4;
  if(first<n) {fallback_terms=lean_unbox(count);if(fallback_terms>n-first)fallback_terms=n-first;}
 }
 lean_object *result=hex_test_products_attempt(table,support,monomial,start,count,max_count,max_bytes,max_work,native);
 if(native && lean_obj_tag(result)==1) products_fallback_terms+=fallback_terms;
 return result;'''
t=t.replace('__typeof__(hex_test_products_attempt) __wrap_lean_hex_monomial_products_attempt;','static uint64_t products_fallback_terms=0;\n__typeof__(hex_test_products_attempt) __wrap_lean_hex_monomial_products_attempt;',1).replace(needle,replacement,1)
t+='\nLEAN_EXPORT lean_obj_res hex_audit_fallback_terms(lean_obj_arg world) {\n (void)world;return lean_io_result_mk_ok(lean_box_uint64(products_fallback_terms));\n}\n';p.write_text(t)
(out/'Usage.lean').write_text('''import HexGroebner.Driver.Run
@[extern "hex_test_batch_counts"] opaque batchCounts : IO (UInt64 × UInt64)
@[extern "hex_test_batch_deferrals"] opaque batchDeferrals : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_batch_insertions"] opaque batchInsertions : IO UInt64
@[extern "hex_audit_fallback_terms"] opaque fallbackTerms : IO UInt64
def main (args : List String) : IO UInt32 := do
  let status ← Hex.Groebner.Driver.run args
  let (hits,terms) ← batchCounts
  let (deferred,waste,errors) ← batchDeferrals
  let fallback ← fallbackTerms
  let inserted ← batchInsertions
  (← IO.getStderr).putStrLn (Lean.Json.mkObj [
    ("batchInsertions",Lean.toJson inserted),("batchHits",Lean.toJson hits),("hitTerms",Lean.toJson terms),
    ("deferredBatches",Lean.toJson deferred),("deferredTerms",Lean.toJson fallback),
    ("deferredWork",Lean.toJson waste),("boundErrors",Lean.toJson errors)]).compress
  return status
''')
source_hashes={p.name:sha(p)for p in out.iterdir()if p.is_file()};(out/'source-hashes.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1',LEAN_ABORT_ON_NONLINEAR='1',TMPDIR=str(s))
with(out/'build.log').open('w')as log:r=subprocess.run(['lake','build','usage'],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
exe=out/'.lake/build/bin/usage';binary_hash=sha(exe);records=[]
template=json.loads((old/'usage-results/mq10-f2-false.command.json').read_text());prefix=template[:template.index(str(old/'.lake/build/bin/usage'))]
for suite,label in [(s/'binary-dense-suite','f2'),(s/'final-products-production/medium-inputs','prime')]:
 for case in json.loads((suite/'suite.json').read_text())['cases']:
  inp=suite/(case['name']+'.json');name=case['name'];assert source_identity()==identity
  command=prefix+[str(exe),'--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000','--scheduling','degree','--dense-pivots','false',str(inp)]
  r=subprocess.run(command,env=env,capture_output=True)
  (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
  actual=json.loads(r.stdout);expected=json.loads((s/'monomial-batches-review-production'/('f2-false'if label=='f2'else'prime-control')/(name+'-b0-B.stdout')).read_text())
  actual.pop('candidateNanos');expected.pop('candidateNanos');assert r.returncode==0 and actual==expected
  counters=json.loads(r.stderr.decode().splitlines()[-1]);assert int(counters['boundErrors'])==0
  records.append(dict(case=name,suite=label,command=command,exit_code=r.returncode,input_sha256=sha(inp),basis_and_counters_equal=True,counters=counters,**identity))
  (out/'status.json').write_text(json.dumps(dict(binary_sha256=binary_hash,binary_sha256_after=sha(exe),sources_sha256=source_hashes,records=records,scope='Untimed diagnostic under sanitized Native probe with AVX512 enabled for oddfields. Not timing evidence. Fullbases+alllogicalcounters compared with frozen ddde8c89c095 outputs. Acceptance, inserted monomial, deferred slice/term/work counters are per process; no timing claim.'),indent=2)+'\n')
  print(name,counters,flush=True)
assert source_identity()==identity and sha(exe)==binary_hash
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
