from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();assert identity['source_fingerprint']=='ddde8c89c095';payload={}
def add(n,p):
 assert n not in payload,n
 payload[n]=p.read_bytes()
def tree(label,base,all_files):
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if p.is_file() and 'binaries'not in rel.parts and (all_files or rel.parts[0]in ['root-sources','compiler-inputs']or len(rel.parts)==1 and p.name in ['manifest.json','source.manifest','build.log','groebner_freeze.py']):add(label+'/'+str(rel),p)
# The source-bound timing capsules retain baseline and process observations.
tree('batch',s/'monomial-batches-review-production',False)
text=tree_listing(CHECKS,identity['source_commit']);payload['checks.manifest']=text.encode()
for line in text.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for cc in ['clang','gcc']:
 add('native-'+cc+'.log',s/f'monomial-batches-pr-fixed-verified-{cc}.log')
 base=s/f'monomial-batches-pr-fixed-verified-{cc}'
 for p in sorted(base.rglob('*')):
  if p.is_file()and'.lake'not in p.relative_to(base).parts:add('probes/'+cc+'/'+str(p.relative_to(base)),p)
for label,name in [('native-status.json','monomial-batches-pr-fixed-verified-native-status.json'),('full-status.json','monomial-batches-pr-fixed-full-status.json')]:
 rows=json.loads((s/name).read_text());assert len(rows)==(2 if label.startswith('native')else 9)and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in rows);add(label,s/name)
 if label.startswith('full'):
  for row in rows:add('full/'+row['name']+'.log',Path(row['log']))
for name in ['monomial-batches-pr-fixed-native-checks.py','monomial-batches-pr-fixed-full-checks.py','pack-monomial-batches-pr-guards.py','measure-monomial-batches-reference-kernels.py']:
 add('collectors/'+name,s/name)
add('reference/kernel-status.json',s/'monomial-batches-review-production/reference-kernel-status.json')
for p in sorted((s/'monomial-batches-review-production/reference-kernels').rglob('*')):
 if p.is_file():add('reference/kernels/'+str(p.relative_to(s/'monomial-batches-review-production/reference-kernels')),p)
for name in ['monomial-batches-pr-verified-clang.log','monomial-batches-pr-verified-native-status.json','monomial-batches-pr-full-status.json','monomial-batches-pr-full-oracles.log']:
 add('superseded-failures/'+name,s/name)
for p in sorted((s/'monomial-batch-usage-audit').rglob('*')):
 if p.is_file()and'.lake'not in p.relative_to(s/'monomial-batch-usage-audit').parts:add('usage/'+str(p.relative_to(s/'monomial-batch-usage-audit')),p)
add('collectors/audit-monomial-batch-usage.py',s/'audit-monomial-batch-usage.py')
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode()
payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode()
out=s/('f4-monomial-batch-checks-'+identity['checks_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-monomial-batches/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
