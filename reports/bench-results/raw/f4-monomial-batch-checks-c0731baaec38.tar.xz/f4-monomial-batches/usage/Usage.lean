import HexGroebner.Driver.Run
@[extern "hex_test_batch_counts"] opaque batchCounts : IO (UInt64 × UInt64)
@[extern "hex_test_batch_deferrals"] opaque batchDeferrals : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_batch_insertions"] opaque batchInsertions : IO UInt64
@[extern "hex_audit_fallback_terms"] opaque fallbackTerms : IO UInt64
def main (args : List String) : IO UInt32 := do
  let status ← Hex.Groebner.Driver.run args
  let (hits,terms) ← batchCounts
  let (deferred,waste,errors) ← batchDeferrals
  let fallback ← fallbackTerms
  let inserted ← batchInsertions
  (← IO.getStderr).putStrLn (Lean.Json.mkObj [
    ("batchInsertions",Lean.toJson inserted),("batchHits",Lean.toJson hits),("hitTerms",Lean.toJson terms),
    ("deferredBatches",Lean.toJson deferred),("deferredTerms",Lean.toJson fallback),
    ("deferredWork",Lean.toJson waste),("boundErrors",Lean.toJson errors)]).compress
  return status
