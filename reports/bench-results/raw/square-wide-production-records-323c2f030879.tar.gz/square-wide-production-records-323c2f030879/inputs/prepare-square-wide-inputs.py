from pathlib import Path
import copy,json,shutil
base=Path('/tmp/hex-groebner-square-delayed-production');p=Path('/tmp/hex-groebner-square-delayed-wide-production');p.mkdir(exist_ok=False);inputs=p/'inputs';inputs.mkdir();original=json.load(open('/tmp/hex-groebner-compare/diagnostic-suite.json'));plan=copy.deepcopy(original);plan['cases']=[]
for case in original['cases']:
 if case['p']!=2147483647:continue
 for prime in [65537,2147483629]:
  c=copy.deepcopy(case);old=c['p'];c['p']=prime;c['name']=case['name'].removesuffix('-31')+'-'+str(prime)
  c['generators']=[[[exponents,(coefficient if coefficient<=old//2 else coefficient-old)%prime] for exponents,coefficient in polynomial] for polynomial in c['generators']]
  plan['cases'].append(c);(inputs/(c['name']+'.json')).write_text(json.dumps(c)+'\n')
plan['protocol']['field_scope']='Companion wide-field experiment: same integer-lifted systems at 65537 and 2147483629; no pooling with the original 32003/Mersenne suite.'
(inputs/'diagnostic-suite.json').write_text(json.dumps(plan,indent=2)+'\n');shutil.copy2(__file__,inputs/Path(__file__).name)
(p/'binaries').mkdir()
for file in (base/'binaries').iterdir():
 if file.is_file():shutil.copy2(file,p/'binaries'/file.name)
s=(base/'measure-production.py').read_text().replace("ROOT=pathlib.Path('/tmp/hex-groebner-compare')",f"ROOT=pathlib.Path('{inputs}')").replace("DEV=pathlib.Path('/tmp/hex-groebner-square-delayed-production')",f"DEV=pathlib.Path('{p}')").replace("OUT=DEV/f'square-delayed-production-records-{fp}'", "OUT=DEV/f'square-wide-production-records-{fp}'");(p/'measure-production.py').write_text(s)
for name in ['analyze-diagnostic.py','analyze-fields.py']:shutil.copy2(base/name,p/name)
