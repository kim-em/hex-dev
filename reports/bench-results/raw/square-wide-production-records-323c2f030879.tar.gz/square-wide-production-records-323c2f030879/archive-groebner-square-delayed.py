from pathlib import Path
import shutil,subprocess,json,hashlib,tarfile
p=Path('/tmp/hex-groebner-square-delayed-production');wide=Path('/tmp/hex-groebner-square-delayed-wide-production');root=Path('/tmp/hex-groebner-square-delayed-dev');dest=Path('/tmp/hex-groebner-evidence-review/reports/bench-results/raw');records=list(p.glob('square-delayed-*-323c2f030879'))+list(wide.glob('square-wide-production-records-323c2f030879'))
validation=p/'square-delayed-validation';validation.mkdir(exist_ok=False)
for log in Path('/tmp').glob('issue-10987-square-delayed-*.log'):shutil.copy2(log,validation/log.name)
for file in ['conformance-fixtures/HexGroebner/f4.jsonl','conformance/HexGroebner/DelayedConformance.lean','conformance/HexGroebner/NativeChecks.lean','scripts/ci/check_groebner_matrix.py','scripts/libgraph.py']:
 f=validation/file;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/file,f)
shutil.copy2(p/'fresh-f4.jsonl',validation/'fresh-f4.jsonl');shutil.copy2('/tmp/prepare-square-wide-inputs.py',validation/'prepare-wide-inputs.py');records.append(validation)
listing=json.load(open(p/'binaries/manifest.json'))['source_manifest'];baseline=json.load(open(p/'binaries/baseline-manifest.json'))['source_manifest']
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for directory in sorted(records):
 for name in ['Main.lean','ReferenceElimination.lean','ReferenceF4.lean','ReferenceSymbolic.lean','lakefile.lean','lake-manifest.json','lean-toolchain','measure-production.py','measure-bench.py','measure-kernels.py','analyze-diagnostic.py','analyze-fields.py','analyze-kernels.py']:
  shutil.copy2(p/name,directory/name)
 for name in ['diagnostic-analysis.json','field-analysis.json','fixed-analysis.json']:
  if (p/name).exists():shutil.copy2(p/name,directory/name)
 for name in ['manifest.json','baseline-manifest.json']:shutil.copy2(p/'binaries'/name,directory/('binary-'+name))
 shutil.copy2(__file__,directory/Path(__file__).name)
 if directory.parent==wide:
  shutil.copytree(wide/'inputs',directory/'inputs');shutil.copy2(wide/'measure-production.py',directory/'measure-wide-production.py');shutil.copy2(wide/'diagnostic-analysis.json',directory/'wide-diagnostic-analysis.json');shutil.copy2(wide/'field-analysis.json',directory/'wide-field-analysis.json')
 for data,folder in [(listing,'root-sources'),(baseline,'baseline-sources')]:
  for line in data.splitlines():
   _,oid,rest=line.split(' ',2);_,name=rest.split('\t');f=directory/folder/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd=root))
 (directory/'source.manifest').write_text(listing);(directory/'baseline-source.manifest').write_text(baseline)
 target=dest/(directory.name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(directory,arcname=directory.name)
 print(target.name,sha(target),flush=True)
