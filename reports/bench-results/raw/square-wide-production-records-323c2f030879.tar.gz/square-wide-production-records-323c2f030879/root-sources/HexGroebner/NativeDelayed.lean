/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

public import HexGroebner.NativeScan
public import HexGroebner.NativeGather

@[expose] public section

namespace Hex.Groebner.Native.Delayed
open Scan

/-! Exact delayed reduction with little-endian 64-bit accumulators in `[0,p²)`.
Sparse pivots retain canonical residues. Subtract `factor*b`, adding `p²` on
underflow; the result remains in `[0,p²)`, since `factor*b < p² < 2^62`.
Reduction modulo p occurs at column tests and output. Calls preserve the existing
4096-transition bound, copy-on-write behavior and failure prefixes. -/

/-- Subtract one product in the bounded accumulator representation. -/
def subtract (square a product : Nat) : Nat :=
  if a ≥ product then a-product else a+square-product

/-- One correction preserves the accumulator bound. -/
theorem subtract_lt {square a product : Nat} (ha : a < square) (hb : product < square) :
    subtract square a product < square := by
  unfold subtract
  split <;> omega

/-- The represented integer changes by subtraction, with at most one modulus. -/
theorem subtract_balance (square a product : Nat) (hb : product < square) :
    subtract square a product + product = a + (if a ≥ product then 0 else square) := by
  unfold subtract
  split <;> omega

def scanPortable (modulus : UInt64) (slots : @& ByteArray) (pivots : @& Array Pivot)
    (initial : State) (quantum workLimit traceLimit : Nat) (provenance : Bool) : Result := Id.run do
  let p := modulus.toNat
  let w := Native.width p
  let square := p*p
  let columns := initial.dense.size / 8
  let mut out : Result := { state := initial }
  if p < 2 || p ≥ 2147483648 || quantum > 4096 || initial.dense.size % 8 != 0 ||
      columns > 4294967295 || slots.size != columns*4 || initial.column > columns ||
      (columns != 0 && initial.last ≥ columns) || initial.leading > columns ||
      initial.pending > pivots.size || pivots.size > 4294967295 ||
      initial.chargedUntil > columns || initial.entry > 4294967295 ||
      (initial.pending == 0 && initial.entry != 0) ||
      (initial.pending != 0 && initial.column ≥ columns) ||
      (columns == 0 && initial.last != 0) || initial.factor.toNat ≥ p then
    return { out with status := 4 }
  for _ in [:quantum] do
    let s := out.state
    if s.pending != 0 then
      let pivot := pivots[s.pending-1]!
      let some size := rowSize w pivot | return { out with status := 4 }
      if s.entry > size then return { out with status := 4 }
      if s.entry == size then
        if Native.read s.dense 8 (8*s.column) % p != 0 then return { out with status := 4 }
        out := { out with reductions := out.reductions+1 }
        if provenance then
          if out.traceNodes ≥ traceLimit then return { out with status := 3 }
          out := { out with events := out.events.push (s.pending - 1, s.factor), traceNodes := out.traceNodes+1 }
        out := { out with state := { s with dense := Native.write s.dense 8 (8*s.column) 0, pending := 0, entry := 0, column := s.column+1 } }
      else
        let j := Native.read pivot.columns 4 (4*s.entry)
        let b := Native.read pivot.coefficients w (w*s.entry)
        if j ≥ columns || b == 0 || b ≥ p || (s.entry > 0 &&
            Native.read pivot.columns 4 (4*(s.entry-1)) ≥ j) then
          return { out with status := 4 }
        let a := Native.read s.dense 8 (8*j)
        if a ≥ square then return { out with status := 4 }
        let product := s.factor.toNat * b
        let value := subtract square a product
        out := { out with state := { s with dense := Native.write s.dense 8 (8*j) value, entry := s.entry+1 } }
    else
      if s.column ≥ columns || s.column > s.last then return { out with status := 1 }
      if s.column ≥ s.chargedUntil then
        let stop := min (s.column+64) (s.last+1)
        let charge := stop-s.column
        if out.work+charge > workLimit then return { out with status := 2 }
        out := { out with work := out.work+charge, state := { out.state with chargedUntil := stop } }
      let s := out.state
      let a := Native.read s.dense 8 (8*s.column) % p
      let slot := Native.read slots 4 (4*s.column)
      if a == 0 || slot == 0 then
        let dense := if a == 0 then Native.write s.dense 8 (8*s.column) 0 else s.dense
        out := { out with state := { s with dense, column := s.column+1, leading := if a != 0 && s.leading == 0 then s.column+1 else s.leading } }
      else
        if slot > pivots.size then return { out with status := 4 }
        let pivot := pivots[slot-1]!
        let some size := rowSize w pivot | return { out with status := 4 }
        if Native.read pivot.columns 4 0 != s.column || Native.read pivot.coefficients w 0 != 1 then
          return { out with status := 4 }
        let last := Native.read pivot.columns 4 (4*(size-1))
        if last ≥ columns then return { out with status := 4 }
        out := { out with state := { s with last := max s.last last, sugar := max s.sugar pivot.sugar } }
        if out.work+size > workLimit then return { out with status := 2 }
        out := { out with work := out.work+size, state := { out.state with
          pending := slot, entry := 0, factor := a.toUInt64 } }
  return out

@[extern "lean_hex_delayed_scan_transition"]
def transition (modulus : UInt64) (slots : @& ByteArray) (pivots : @& Array Pivot)
    (initial : State) (quantum workLimit traceLimit : @& Nat) (provenance : Bool) : Result :=
  scanPortable modulus slots pivots initial quantum workLimit traceLimit provenance

def gatherPortable (modulus : UInt64) (initial : Gather.State) (stop quantum entriesLimit bytesLimit workLimit : Nat)
    (factor : UInt64) : Gather.Result := Id.run do
  let p := modulus.toNat
  let w := Native.width p
  let size := initial.dense.size/8
  let count := initial.columns.size/4
  let mut out : Gather.Result := { state := initial }
  if p < 2 || p ≥ 2147483648 || factor == 0 || factor.toNat ≥ p || quantum > 4096 ||
      initial.dense.size%8 != 0 || size > 4294967295 || initial.cursor > stop || stop > size ||
      initial.columns.size%4 != 0 || initial.coefficients.size != count*w then
    return { out with status := 5 }
  for _ in [:quantum] do
    let s := out.state
    if s.cursor ≥ stop then return { out with status := 1 }
    let a := Native.read s.dense 8 (s.cursor*8) % p
    if a != 0 then
      if s.columns.size > 0 && Native.read s.columns 4 (s.columns.size-4) ≥ s.cursor then
        return { out with status := 6 }
      if out.entries ≥ entriesLimit then return { out with status := 2 }
      out := { out with entries := out.entries+1 }
      if out.bytes+4+w > bytesLimit then return { out with status := 3 }
      out := { out with bytes := out.bytes+4+w }
      if s.columns.size+4 ≥ USize.size || s.coefficients.size+w ≥ USize.size then
        return { out with status := 5 }
      if factor != 1 then
        if out.work ≥ workLimit then return { out with status := 4 }
        out := { out with work := out.work+1 }
      let value := a*factor.toNat%p
      out := { out with state := ⟨Native.write s.dense 8 (s.cursor*8) 0,
        Gather.push 4 s.columns s.cursor,Gather.push w s.coefficients value,s.cursor+1⟩ }
    else out := { out with state := { s with dense := Native.write s.dense 8 (s.cursor*8) 0, cursor := s.cursor+1 } }
  return out

@[extern "lean_hex_delayed_gather"]
def gather (modulus : UInt64) (initial : Gather.State)
    (stop quantum entriesLimit bytesLimit workLimit : @& Nat) (factor : UInt64) : Gather.Result :=
  gatherPortable modulus initial stop quantum entriesLimit bytesLimit workLimit factor

end Hex.Groebner.Native.Delayed
