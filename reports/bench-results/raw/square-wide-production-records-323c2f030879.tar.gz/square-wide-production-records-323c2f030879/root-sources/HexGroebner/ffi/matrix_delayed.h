/* Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
   Released under Apache 2.0 license as described in the file LICENSE.
   Authors: Kim Morrison */
/* Included after the ordinary matrix helpers. Dense slots use exact u64 sums;
   sparse coefficient widths remain 1/2/4 bytes. No alignment is assumed. */
static inline uint64_t delayed_read(const uint8_t *p) {
    return rd(p,4) | (rd(p+4,4)<<32);
}
static inline void delayed_write(uint8_t *p,uint64_t v) {
    wr(p,4,v);wr(p+4,4,v>>32);
}
static inline uint64_t delayed_reduce(uint64_t value,uint64_t p,uint64_t reciprocal) {
    if(value<p) return value;
#if defined(__SIZEOF_INT128__) && !defined(HEX_GROEBNER_NO_UINT128)
    uint64_t q=(uint64_t)(((__uint128_t)value*reciprocal)>>64);
    value-=q*p;
    if(value>=p) value-=p;
    return value;
#else
    (void)reciprocal;
    return value%p;
#endif
}
static inline int delayed_update(uint8_t *data,const uint8_t *cs,const uint8_t *vs,
        unsigned w,uint64_t columns,uint64_t entry,uint64_t p,uint64_t factor,uint64_t reciprocal) {
    uint64_t j=rd(cs+(size_t)entry*4,4),b=rd(vs+(size_t)entry*w,w);
    if(j>=columns || !b || b>=p || (entry && rd(cs+(size_t)(entry-1)*4,4)>=j)) return 0;
    uint64_t a=delayed_read(data+(size_t)j*8);
    (void)reciprocal;
    uint64_t square=p*p,product=factor*b;
    if(a>=square) return 0;
    delayed_write(data+(size_t)j*8,a>=product?a-product:a+square-product);
    return 1;
}

#include "matrix_delayed_simd.h"
#define HEX_DELAYED_NAME delayed_scan_scalar
#define HEX_DELAYED_ATTRIBUTE
#define HEX_DELAYED_WIDTH 0
#define HEX_DELAYED_VECTOR 0
#include "matrix_delayed_scan_impl.h"
#undef HEX_DELAYED_NAME
#undef HEX_DELAYED_ATTRIBUTE
#undef HEX_DELAYED_WIDTH
#undef HEX_DELAYED_VECTOR
#if HEX_GROEBNER_AVX2
#define HEX_DELAYED_NAME delayed_scan_avx2
#define HEX_DELAYED_ATTRIBUTE __attribute__((target("avx2")))
#define HEX_DELAYED_WIDTH 4
#define HEX_DELAYED_VECTOR 1
#include "matrix_delayed_scan_impl.h"
#undef HEX_DELAYED_NAME
#undef HEX_DELAYED_ATTRIBUTE
#undef HEX_DELAYED_WIDTH
#undef HEX_DELAYED_VECTOR
#endif
LEAN_EXPORT lean_obj_res lean_hex_delayed_scan_transition(uint64_t p,
        b_lean_obj_arg slots,b_lean_obj_arg pivots,lean_obj_arg initial,
        b_lean_obj_arg quantum,b_lean_obj_arg work,b_lean_obj_arg trace,uint8_t provenance) {
#if HEX_GROEBNER_AVX2
    if(p>65536 && p<UINT64_C(2147483648) && hex_avx2_available())
        return delayed_scan_avx2(p,slots,pivots,initial,quantum,work,trace,provenance);
#endif
    return delayed_scan_scalar(p,slots,pivots,initial,quantum,work,trace,provenance);
}

LEAN_EXPORT lean_obj_res lean_hex_delayed_gather(uint64_t p,lean_obj_arg initial,
        b_lean_obj_arg stop_arg,b_lean_obj_arg quantum_arg,b_lean_obj_arg entries_arg,
        b_lean_obj_arg bytes_arg,b_lean_obj_arg work_arg,uint64_t factor) {
    unsigned w=p<=256?1:p<=65536?2:4;
    lean_object *dense=lean_ctor_get(initial,0),*cols=lean_ctor_get(initial,1),*coeff=lean_ctor_get(initial,2);
    size_t db=lean_sarray_size(dense),cb=lean_sarray_size(cols),vb=lean_sarray_size(coeff);
    uint64_t size=db/8,stop=bounded_nat(stop_arg,UINT64_C(4294967296));
    uint64_t cursor=bounded_nat(lean_ctor_get(initial,3),UINT64_C(4294967296));
    uint64_t quantum=bounded_nat(quantum_arg,4097);
    if(p<2 || p>=UINT64_C(2147483648) || !factor || factor>=p || quantum>4096 || db%8 ||
       size>UINT32_MAX || cursor>stop || stop>size || cb%4 || vb!=(cb/4)*w)
        return gather_result(initial,0,0,0,5);
    uint64_t entries_limit=bounded_nat(entries_arg,4096),bytes_limit=bounded_nat(bytes_arg,32768);
    uint64_t work_limit=bounded_nat(work_arg,4096);
    lean_inc(dense);lean_inc(cols);lean_inc(coeff);lean_dec(initial);
    dense=lean_sarray_ensure_exclusive(dense);
    /* Output aliases retain their original data until append_scalar copies. */
    uint8_t *data=lean_sarray_cptr(dense);
    uint64_t entries=0,bytes=0,work=0;uint8_t status=0;
    uint64_t reciprocal=0;
#if defined(__SIZEOF_INT128__) && !defined(HEX_GROEBNER_NO_UINT128)
    reciprocal=UINT64_MAX/p;if(UINT64_MAX%p==p-1) ++reciprocal;
#endif
    for(uint64_t tick=0;tick<quantum;++tick) {
        if(cursor>=stop) {status=1;break;}
        uint64_t a=delayed_reduce(delayed_read(data+(size_t)cursor*8),p,reciprocal);
        if(a) {
            size_t cn=lean_sarray_size(cols),vn=lean_sarray_size(coeff);
            if(cn && rd(lean_sarray_cptr(cols)+cn-4,4)>=cursor) {status=6;break;}
            if(entries>=entries_limit) {status=2;break;}++entries;
            if(bytes+4+w>bytes_limit) {status=3;break;}bytes+=4+w;
            if(cn>SIZE_MAX-4 || vn>SIZE_MAX-w) {status=5;break;}
            if(factor!=1) {if(work>=work_limit) {status=4;break;}++work;}
            uint64_t value=a;
            if(factor!=1) value=delayed_reduce(a*factor,p,reciprocal);
            cols=append_scalar(cols,4,cursor);coeff=append_scalar(coeff,w,value);
            delayed_write(data+(size_t)cursor*8,0);
        } else delayed_write(data+(size_t)cursor*8,0);
        ++cursor;
    }
    lean_object *state=lean_alloc_ctor(0,4,0);
    lean_ctor_set(state,0,dense);lean_ctor_set(state,1,cols);lean_ctor_set(state,2,coeff);
    lean_ctor_set(state,3,lean_uint64_to_nat(cursor));
    return gather_result(state,entries,bytes,work,status);
}
