import HexGroebner.NativeChecks
import HexGroebner.SparseBinaryConformance
import HexGroebner.EliminationConformance
@[extern "hex_test_binary_groups"] opaque binaryGroups : IO UInt64
@[extern "hex_test_sparse_counts"] opaque sparseCounts : IO (UInt64 × UInt64 × UInt64 × UInt64 × UInt64)

def main : IO UInt32 := do
  let sparseBefore ← sparseCounts
  let seed ← Hex.Groebner.NativeChecks.readSeed
  match Hex.Groebner.SparseBinaryConformance.checkSelection seed true with
  | .error message => throw (IO.userError message)
  | .ok () => pure ()
  let before ← binaryGroups
  let some expected := Hex.Groebner.EliminationConformance.binaryGroupBoundary seed true |
    throw (IO.userError "packed-only boundary mismatch")
  if (← binaryGroups) != before+expected.toUInt64 then
    throw (IO.userError "packed-only table count mismatch")
  if (← sparseCounts).1 != sparseBefore.1 then
    throw (IO.userError "packed-only control selected sparse")
  IO.println "PASS packed-only physical/payload boundaries, budgets and ownership"
  return 0
