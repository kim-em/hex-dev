import HexGroebner.NativeChecks
import HexGroebner.SparseBinaryConformance
@[extern "hex_test_sparse_counts"] opaque sparseCounts : IO (UInt64 × UInt64 × UInt64 × UInt64 × UInt64)
@[extern "hex_test_sparse_offsets"] opaque sparseOffsets (enabled : Bool) : IO Unit

def main : IO UInt32 := do
  let before ← sparseCounts
  let seed ← Hex.Groebner.NativeChecks.readSeed
  for offsets in [false,true] do
    sparseOffsets offsets
    match Hex.Groebner.SparseBinaryConformance.checkRuntime (seed+(if offsets then 7 else 0)) true with
    | .error message => throw (IO.userError message)
    | .ok () => pure ()
  sparseOffsets false
  if !Hex.Groebner.SparseBinaryConformance.shapeChecks ||
      !Hex.Groebner.SparseBinaryConformance.cardinalityChecks ||
      !Hex.Groebner.SparseBinaryConformance.malformedChecks then
    throw (IO.userError "forced sparse F2 shape/cardinality/malformed mismatch")
  let after ← sparseCounts
  if after.1 ≤ before.1 || after.2.1 ≤ before.2.1 || after.2.2.1 ≤ before.2.2.1 ||
      after.2.2.2.1 ≤ before.2.2.2.1 then throw (IO.userError "forced sparse F2 hooks unused")
  IO.println s!"PASS forced sparse F2 small/large/budget/malformed/offset/ownership: {after}"
  return 0
