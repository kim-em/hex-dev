from pathlib import Path
import argparse,hashlib,importlib.util,json,os,subprocess,sys,time
s=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sparse-binary');parser=argparse.ArgumentParser();parser.add_argument('compiler',choices=['clang','gcc']);parser.add_argument('output',type=Path);args=parser.parse_args();os.chdir(root);sys.path.insert(0,str(root));from scripts.bench.groebner_checks import source_identity
identity=source_identity();compiler={'clang':'/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang','gcc':'/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/gcc'}[args.compiler];assert not args.output.exists();os.environ.update(CC=compiler,HEX_GROEBNER_SANITIZE='1',HEX_GROEBNER_NATIVE_LOG_DIR=str(args.output),LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR='/dev/shm/issue-10987-build')
spec=importlib.util.spec_from_file_location('packed_selector_matrix_generator',root/'scripts/ci/check_groebner_matrix.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class Prepared(Exception):pass
original=subprocess.run
def prepare(command,*a,**kw):
 if isinstance(command,list)and command[:2]==['lake','build']:raise Prepared()
 return original(command,*a,**kw)
subprocess.run=prepare
try:
 try:module.run()
 except Prepared:pass
finally:subprocess.run=original
out=args.output;config=(out/'lakefile.lean').read_text();config=config.replace('"-DLEAN_EXPORTING",','"-DLEAN_EXPORTING", "-DHEX_GROEBNER_KEEP_PACKED_BINARY",');assert '-DHEX_GROEBNER_KEEP_PACKED_BINARY'in config;(out/'lakefile.lean').write_text(config)
main='''import HexGroebner.NativeChecks
import HexGroebner.SparseBinaryConformance
import HexGroebner.EliminationConformance
@[extern "hex_test_binary_groups"] opaque binaryGroups : IO UInt64
@[extern "hex_test_sparse_counts"] opaque sparseCounts : IO (UInt64 × UInt64 × UInt64 × UInt64 × UInt64)

def main : IO UInt32 := do
  let sparseBefore ← sparseCounts
  let seed ← Hex.Groebner.NativeChecks.readSeed
  match Hex.Groebner.SparseBinaryConformance.checkSelection seed true with
  | .error message => throw (IO.userError message)
  | .ok () => pure ()
  let before ← binaryGroups
  let some expected := Hex.Groebner.EliminationConformance.binaryGroupBoundary seed true |
    throw (IO.userError "packed-only boundary mismatch")
  if (← binaryGroups) != before+expected.toUInt64 then
    throw (IO.userError "packed-only table count mismatch")
  if (← sparseCounts).1 != sparseBefore.1 then
    throw (IO.userError "packed-only control selected sparse")
  IO.println "PASS packed-only physical/payload boundaries, budgets and ownership"
  return 0
'''
for variant in module.VARIANTS:(out/('Matrix'+variant+'.lean')).write_text(main)
# Use the generator's actual module names rather than assuming a prefix.
for path in out.glob('*.lean'):
 if path.name!='lakefile.lean'and 'def main'in path.read_text():path.write_text(main)
start=time.monotonic();results=[];build=original(['lake','build',*['check'+v for v in module.VARIANTS]],cwd=out);assert source_identity()==identity
status={'compiler':compiler,'keep_packed':True,'sanitize':['address','undefined'],'build_exit_code':build.returncode,'results':results,**identity};(out/'packed-status.json').write_text(json.dumps(status,indent=2)+'\n');assert build.returncode==0
loader='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2';lib='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib';preload=os.pathsep.join(module.sanitizer_libraries(compiler));env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1',LEAN_ABORT_ON_NONLINEAR='1');env.pop('LD_PRELOAD',None)
for variant in module.VARIANTS:
 command=[loader,'--library-path',lib,'--preload',preload,str(out/'.lake/build/bin'/('check'+variant))];r=original(command,env=env);results.append({'variant':variant,'exit_code':r.returncode});status['seconds']=time.monotonic()-start;(out/'packed-status.json').write_text(json.dumps(status,indent=2)+'\n');assert r.returncode==0
assert source_identity()==identity;print('PASS all six packed-only variants',args.compiler)
