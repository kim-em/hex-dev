from pathlib import Path
import json,os,subprocess,sys,time
state=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(Path.cwd()))
from scripts.bench.groebner_checks import source_identity
identity=source_identity()
for kind in ['forced','packed']:
 for name,compiler in [('clang','/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang'),('gcc','/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/gcc')]:
  assert source_identity()==identity
  project=state/f'sparse-audited-{kind}-{name}'
  env=dict(os.environ,LEAN_CC=str(state/'issue-10987-lean-cc'),CC=compiler,HEX_GROEBNER_SANITIZE='1',HEX_GROEBNER_REQUIRE_AVX2='1',HEX_GROEBNER_REQUIRE_AVX512='1',HEX_GROEBNER_MATRIX_PROFILE=kind,HEX_GROEBNER_TEST_LOADER='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2',HEX_GROEBNER_TEST_LIBRARY_PATH='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib',HEX_GROEBNER_NATIVE_LOG_DIR=str(project),TMPDIR='/dev/shm/issue-10987-build')
  with (state/f'sparse-audited-{kind}-{name}.log').open('w')as log:
   r=subprocess.run(['python3','scripts/ci/check_groebner_matrix.py'],env=env,stdout=log,stderr=subprocess.STDOUT)
  assert source_identity()==identity
  status=json.loads((project/'profile-status.json').read_text())
  assert status['profile']==kind and status['sanitize'] is True
  status.update(identity);status['sanitize']=['address','undefined']
  status['force_sparse' if kind=='forced' else 'keep_packed']=True
  (project/(kind+'-status.json')).write_text(json.dumps(status,indent=2)+'\n')
  print(kind,name,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
