import ScanTest

def main : IO Unit := do
  if runtimeChecks then IO.println "native scan: widths, chunking, counters, aliases, malformed inputs match portable"
  else throw (IO.userError "native scan mismatch")
