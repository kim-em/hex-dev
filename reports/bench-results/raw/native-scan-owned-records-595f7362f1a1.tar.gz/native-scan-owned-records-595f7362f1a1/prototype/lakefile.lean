import Lake
open Lake DSL System
package GroebnerScanDev
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
target scanO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "scan.c")
  let file := pkg.dir / defaultBuildDir / "scan.o"
  buildFileAfterDep file source fun input => do
    createParentDirs file
    proc { cmd := "cc", args := #["-O3","-Wall","-Wextra","-fPIC","-c",input.toString,"-o",file.toString,
      "-I",(← getLeanIncludeDir).toString] }

lean_lib ScanNative where
  roots := #[`ScanNative]
  globs := #[.one `ScanNative, .one `NativeScan]
  moreLinkObjs := #[scanO]
  precompileModules := true

lean_lib ScanDev where
  roots := #[`ScanTest, `EliminationPrototype, `SymbolicPrototype, `F4Prototype, `EngineTest, `F4Test]

lean_exe scan_compare where
  root := `Main

target scanSanitizedO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "scan.c")
  let file := pkg.dir / defaultBuildDir / "scan-sanitized.o"
  buildFileAfterDep file source fun input => do
    createParentDirs file
    proc { cmd := "cc", args := #["-O1","-g","-fsanitize=address,undefined","-fno-omit-frame-pointer",
      "-DHEX_GROEBNER_NO_UINT128","-Dlean_hex_scan_transition=__wrap_lean_hex_scan_transition","-fPIC","-c",input.toString,"-o",file.toString,
      "-I",(← getLeanIncludeDir).toString] }

lean_exe scan_checks where
  root := `Check
  moreLinkObjs := #[scanSanitizedO]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition","/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/resource-root/lib/linux/libclang_rt.asan-x86_64.so"]
