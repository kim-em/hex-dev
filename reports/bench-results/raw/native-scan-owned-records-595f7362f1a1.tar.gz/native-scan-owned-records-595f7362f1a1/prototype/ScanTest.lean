import NativeScan

open Hex.Groebner.Native
open Hex.Groebner.Native.Scan

def packed (width : Nat) (values : Array Nat) : ByteArray :=
  values.foldl (fun bytes value =>
    (List.range width).foldl (fun b i => b.push (UInt8.ofNat (value / 256^i))) bytes) ByteArray.empty

def row (columns coefficients : Array Nat) (sugar : Nat) : Pivot :=
  ⟨packed 4 columns, packed 1 coefficients, sugar⟩

def pivots : Array Pivot := #[row #[0,1,5] #[1,2,3] 9, row #[2,4] #[1,6] 11]
def slots : ByteArray := packed 4 #[1,0,2,0,0,0]
def initial : State := { dense := packed 1 #[3,4,2,0,0,0], column := 0, last := 2, chargedUntil := 0 }

def run (quantum : Nat) (provenance : Bool) (native : Bool := false) : Option Result := Id.run do
  let mut state := initial
  let mut events : Array (Nat × UInt64) := #[]
  let mut work := 0
  let mut reductions := 0
  let mut traces := 0
  for _ in [:100] do
    let result := (if native then transition else portable) 7 slots pivots state quantum (1000-work) (100-traces) provenance
    state := result.state
    events := events ++ result.events
    work := work+result.work
    reductions := reductions+result.reductions
    traces := traces+result.traceNodes
    if result.status == 1 then return some { state, events, work, reductions, traceNodes := traces, status := 1 }
    if result.status != 0 then return none
  return none

def equal (a b : Result) : Bool :=
  a.state.dense.data == b.state.dense.data && a.state.column == b.state.column &&
  a.state.last == b.state.last && a.state.chargedUntil == b.state.chargedUntil &&
  a.state.leading == b.state.leading && a.state.pending == b.state.pending &&
  a.state.entry == b.state.entry && a.state.sugar == b.state.sugar &&
  a.state.factor == b.state.factor && a.events == b.events && a.work == b.work &&
  a.reductions == b.reductions && a.traceNodes == b.traceNodes && a.status == b.status

#guard match run 4096 true with
  | some result => result.state.dense.data == #[0,5,0,0,2,5] &&
    result.state.leading == 2 && result.state.sugar == 11 && result.work == 11 &&
    result.events == #[(0,3),(1,2)] && result.reductions == 2
  | none => false

#guard (List.range 16).all fun k =>
  match run (k+1) true, run 4096 true with
  | some a,some b => equal a b
  | _,_ => false

#guard (portable 7 slots pivots initial 4097 1000 100 true).status == 4
#guard (portable 7 slots pivots initial 4096 0 100 true).status == 2
#guard (portable 7 slots pivots initial 4096 1000 0 true).status == 3
#guard match run 1 false with
  | some result => result.events.isEmpty && result.traceNodes == 0 && result.reductions == 2
  | none => false

#guard (List.range 32).all fun k =>
  match run (k+1) true true, run 4096 true false with
  | some a,some b => equal a b
  | _,_ => false

#guard (List.range 20).all fun q => (List.range 25).all fun work =>
  (List.range 4).all fun traces =>
    equal (transition 7 slots pivots initial q work traces true)
      (portable 7 slots pivots initial q work traces true)

private def fuzz : Bool := Id.run do
  for p in [2,3,251,256,257,65521,65536,65537,2147483647] do
    let w := Hex.Groebner.Native.width p
    for seed in [:12] do
      let mut rows : Array Pivot := #[]
      let mut indices := Array.replicate 31 0
      for (first,i) in (#[0,2,5,7]).zipIdx do
        let support := (Array.range (31-first)).map (·+first)
        let values := support.map fun j => if j == first then 1 else
          ((seed+1)*12345+(i+1)*69069+j*17)%(p-1)+1
        rows := rows.push ⟨packed 4 support,packed w values,2^90+(i+1)*17⟩
        indices := indices.set! first (i+1)
      let slots := packed 4 indices
      let input : State := { dense := packed w ((Array.range 31).map fun i =>
        ((seed+1)*69069+(i+1)*12345)%p),column := 0,last := 30,chargedUntil := 0 }
      for q in [0,1,2,7,31,64,4096] do
        for work in [0,1,31,32,64,127,4096,2^90] do
          for trace in [0,1,3,4,2^90] do
            for provenance in [false,true] do
              if !equal (transition p.toUInt64 slots rows input q work trace provenance)
                  (portable p.toUInt64 slots rows input q work trace provenance) then return false
  return true

#guard fuzz

private def aliases : Bool := Id.run do
  let p := 65537
  let w := 4
  let slots := packed 4 #[1,0,2,0,0,0]
  let rows : Array Pivot := #[⟨packed 4 #[0,2,5],packed w #[1,p-1,p-2],11⟩,
    ⟨packed 4 #[2,3],packed w #[1,p-3],2^90⟩]
  let input : State := { dense := slots,column := 0,last := 5,chargedUntil := 0 }
  if !equal (transition p.toUInt64 slots rows input 4096 1000 100 true)
      (portable p.toUInt64 slots rows input 4096 1000 100 true) then return false
  let dense := packed w (Array.replicate 9 1)
  let rows : Array Pivot := #[⟨packed 4 (Array.range 9),dense,5⟩]
  let slots := packed 4 #[1,0,0,0,0,0,0,0,0]
  let input : State := { dense,column := 0,last := 8,chargedUntil := 0 }
  return equal (transition p.toUInt64 slots rows input 4096 1000 100 true)
    (portable p.toUInt64 slots rows input 4096 1000 100 true)

#guard aliases

private def malformed : Bool := Id.run do
  let mut cases : Array (UInt64 × ByteArray × Array Pivot × State) := #[]
  cases := cases.push (1,slots,pivots,initial)
  cases := cases.push (2147483648,slots,pivots,initial)
  cases := cases.push (7,slots.extract 0 5,pivots,initial)
  cases := cases.push (7,slots,pivots,{ initial with column := 7 })
  cases := cases.push (7,slots,pivots,{ initial with column := 2^90 })
  cases := cases.push (7,slots,pivots,{ initial with last := 6 })
  cases := cases.push (7,slots,pivots,{ initial with pending := 3 })
  cases := cases.push (7,slots,pivots,{ initial with pending := 1,entry := 4 })
  cases := cases.push (7,slots,pivots,{ initial with factor := 7 })
  cases := cases.push (7,slots,pivots,{ initial with dense := packed 1 #[7,0,0,0,0,0] })
  cases := cases.push (7,packed 4 #[3,0,0,0,0,0],pivots,initial)
  for bad in [row #[0,0,5] #[1,2,3] 0,row #[0,6] #[1,2] 0,
      row #[0,1] #[2,3] 0,row #[0,1] #[1,7] 0,
      row #[0,1] #[1,0] 0,⟨packed 1 #[0,1],packed 1 #[1],0⟩] do
    cases := cases.push (7,slots,#[bad],initial)
  for (p,s,r,input) in cases do
    for quantum in [0,1,2,3,8,4096,4097,2^90] do
      if !equal (transition p s r input quantum 1000 100 true)
          (portable p s r input quantum 1000 100 true) then return false
  return true

#guard malformed

def runtimeChecks : Bool := fuzz && aliases && malformed &&
  (List.range 20).all fun q => (List.range 25).all fun work =>
  (List.range 4).all fun traces =>
    equal (transition 7 slots pivots initial q work traces true)
      (portable 7 slots pivots initial q work traces true)
