from pathlib import Path
import os,subprocess,json,sys,time
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');prefix=state/'eight-gap-full';results=[];sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import source_identity
identity=source_identity()
results=[{'name': 'build', 'exit_code': 0, 'seconds': None, 'log': '/home/kim/tmp/issue-10987/eight-gap-full-build.log', 'recovery': 'Exit success retained in full-checks.log; ENOSPC truncated status file while recording failed driver. Duration unavailable.', 'source_commit': '0f421fa535cc8c8dd4f71f3d584e6377a8ded1d6', 'source_fingerprint': 'bf49419e9294', 'source_manifest_sha256': 'bf49419e9294eb3879193d166126ae1c181e88ed932407f20ff5a0eb19394564', 'checks_fingerprint': 'e09606958716', 'checks_manifest_sha256': 'e09606958716517e065725863872f7da77f62242f02ecd6b1954b6e9cb4c4925'}, {'name': 'oracles', 'exit_code': 0, 'seconds': None, 'log': '/home/kim/tmp/issue-10987/eight-gap-full-oracles.log', 'recovery': 'Exit success retained in full-checks.log; ENOSPC truncated status file while recording failed driver. Duration unavailable.', 'source_commit': '0f421fa535cc8c8dd4f71f3d584e6377a8ded1d6', 'source_fingerprint': 'bf49419e9294', 'source_manifest_sha256': 'bf49419e9294eb3879193d166126ae1c181e88ed932407f20ff5a0eb19394564', 'checks_fingerprint': 'e09606958716', 'checks_manifest_sha256': 'e09606958716517e065725863872f7da77f62242f02ecd6b1954b6e9cb4c4925'}]
def run(name,command,env=None):
 assert source_identity()==identity
 log=Path(str(prefix)+'-'+name+'.log');start=time.monotonic()
 with log.open('w')as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,env=env)
 assert source_identity()==identity
 results.append(dict(name=name,command=command,exit_code=r.returncode,seconds=time.monotonic()-start,log=str(log),**identity));Path(str(prefix)+'-status.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('driver',['python3','scripts/ci/check_groebner_driver.py'])
run('bench',['bash','scripts/ci/check_bench_verify_budget.sh','HexGroebner=hexgroebner_bench'],dict(os.environ,HEX_LIBRARY_FILTER='HexGroebner'))
for name,script in [('dag','scripts/check_dag.py'),('phase4','scripts/check_phase4.py'),('manifest','scripts/release/check_released_manifest.py'),('headers','scripts/check_copyright_headers.py'),('lines','scripts/check_file_line_counts.py')]:run(name,[str(state/'oracles/bin/python'),script])
