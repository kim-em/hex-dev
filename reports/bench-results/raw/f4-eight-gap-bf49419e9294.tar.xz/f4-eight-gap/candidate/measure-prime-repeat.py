from pathlib import Path
import os,subprocess,json
state=Path('/home/kim/tmp/issue-10987');base=state/'eight-gap-production';old=state/'projection-bench-production'
command=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'final-products-production/medium-inputs/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/compute'),'--baseline',str(old/'binaries/compute'),'--baseline-manifest',str(old/'manifest.json'),'--output',str(base/'prime-control-repeat')]
assert command[command.index('--baseline')+1]==str(old/'binaries/compute')
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
result=subprocess.run(command,env=env);(base/'measure-prime-repeat.py').write_bytes(Path(__file__).read_bytes());raise SystemExit(result.returncode)
