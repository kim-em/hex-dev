from pathlib import Path
import json,subprocess,hashlib,shutil,tarfile
root=Path('/tmp/hex-groebner-cli-dev');p=Path('/tmp/hex-groebner-cli-production');dest=root/'reports/bench-results/raw';manifest=json.load(open(p/'manifest.json'));rows=[]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
planroot=Path('/tmp/hex-groebner-compare');plan=json.load(open(planroot/'diagnostic-suite.json'))
for directory in sorted(p.glob('cli-*-records-e0b1cbd73ebf')):
 for name in ['measure.py','manifest.json','full-init-validation-correction.json','hexgroebner_compute.rsp','hexgroebner_compute_full.rsp']:shutil.copy2(p/name,directory/name)
 shutil.copy2(__file__,directory/Path(__file__).name)
 shutil.copy2(planroot/'diagnostic-suite.json',directory/'diagnostic-suite.json')
 for case in plan['cases']:
  for ext in ['.json','.ms']:shutil.copy2(planroot/(case['name']+ext),directory/(case['name']+ext))
 for line in manifest['source_manifest'].splitlines():
  _,oid,rest=line.split(' ',2);_,name=rest.split('\t');f=directory/'root-sources'/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd=root))
 (directory/'source.manifest').write_text(manifest['source_manifest'])
 meta=json.load(open(directory/'metadata.json'))
 if meta['msolve_mode']:
  ms=Path('/tmp/hex-groebner-msolve');assert sha(ms/'src/neogb/.libs/libneogb.so.4.0.0')==meta['msolve_engine_sha256']
  shutil.copy2('/tmp/hex-groebner-mersenne-dispatch-production/msolve-source-3672113ee2c6.tar',directory/'msolve-source-3672113ee2c6.tar')
  for file in ['Makefile','src/neogb/Makefile']:
   text=(ms/file).read_text();(directory/('msolve-'+file.replace('/','-')+'-flags.txt')).write_text('\n'.join(l for l in text.splitlines() if l.startswith(('CC =','CFLAGS =','CPPFLAGS =','LDFLAGS =','LIBS =')))+'\n')
  (directory/'msolve-linkage.txt').write_text(subprocess.check_output(['ldd',str(ms/'.libs/msolve')],text=True)+subprocess.check_output(['ldd',str(ms/'src/neogb/.libs/libneogb.so.4.0.0')],text=True))
 target=dest/(directory.name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(directory,arcname=directory.name)
 rows.append((target.name,sha(target)))
validation=p/'cli-validation';validation.mkdir(exist_ok=False)
for log in Path('/tmp').glob('issue-10987-cli-*.log'):shutil.copy2(log,validation/log.name)
for file in ['scripts/ci/check_groebner_driver.py','bench/HexGroebner/Driver/Input.lean','bench/HexGroebner/Driver/Run.lean']:
 f=validation/file;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/file,f)
shutil.copy2(p/'full-init-validation-correction.json',validation/'full-init-validation-correction.json')
target=dest/'cli-validation-e0b1cbd73ebf.tar.gz'
with tarfile.open(target,'w:gz') as t:t.add(validation,arcname=validation.name)
rows.append((target.name,sha(target)))
repro=p/'initialization-reproduction';repro.mkdir(exist_ok=False)
for variant,folder in [('pinned','/tmp/hex-groebner-init-repro'),('nightly','/tmp/hex-groebner-init-repro-nightly')]:
 src=Path(folder);dst=repro/variant;dst.mkdir()
 for name in ['Plain.lean','JsonRuntime.lean','JsonRuntimeOnly.lean','JsonMinimal.lean','lakefile.lean','lake-manifest.json','lean-toolchain','measure.py','measure-minimal.py','memory.py','minimal_init.c','records','minimal-records','memory-supplement']:
  f=src/name
  if not f.exists():continue
  if f.is_dir():shutil.copytree(f,dst/name)
  else:shutil.copy2(f,dst/name)
 bins={f.name:{'sha256':sha(f),'bytes':f.stat().st_size} for f in (src/'.lake/build/bin').iterdir() if f.is_file() and f.suffix==''}
 (dst/'binary-hashes.json').write_text(json.dumps(bins,indent=2)+'\n')
 for f in (src/'.lake/build/bin').glob('*.rsp'):shutil.copy2(f,dst/f.name)
for pattern in ['issue-10987-init-repro*.log']:
 for f in Path('/tmp').glob(pattern):shutil.copy2(f,repro/f.name)
shutil.copy2('/tmp/issue-10987-upstream-init-comment.md',repro/'upstream-comment.md')
(repro/'scope.json').write_text(json.dumps({'upstream':'https://github.com/leanprover/lean4/issues/16082#issuecomment-6558865563','warning':'Original wait4 peak_rss_kib observations in records and minimal-records inherit a large Python parent floor and are invalid estimates of child program memory. They are retained unchanged. Only memory-supplement GNU-time RSS and the three final CLI campaigns GNU-time RSS are valid child memory observations. JsonRuntimeOnly is an unsupported diagnostic initializer interception, never the production implementation. Production uses the SDK initialize_minimal archive only for a program that never elaborates Lean source. Toolchains are separate and not pooled.','sdk_archive_sha256':manifest['minimal_initialization_archive_sha256']},indent=2)+'\n')
target=dest/'cli-initialization-reproduction.tar.gz'
with tarfile.open(target,'w:gz') as t:t.add(repro,arcname=repro.name)
rows.append((target.name,sha(target)))
Path('/tmp/issue-10987-cli-archive-hashes.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
