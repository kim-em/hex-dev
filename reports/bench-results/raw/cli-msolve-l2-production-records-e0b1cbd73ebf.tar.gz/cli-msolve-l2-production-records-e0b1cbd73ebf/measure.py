from pathlib import Path
import os,sys,json,hashlib,subprocess,time,resource,select,signal,ctypes,math,statistics
sys.path.insert(0,'/tmp/hex-groebner-cli-dev')
from scripts.bench.cpu_lease import cpu_lease
from scripts.oracle.groebner_singular import polynomial,canonical
p=Path(__file__).resolve().parent;manifest=json.load(open(p/'manifest.json'));root=Path('/tmp/hex-groebner-compare');plan=json.load(open(root/'diagnostic-suite.json'));mode=int(sys.argv[1]) if len(sys.argv)>1 else None
name=f'cli-msolve-l{mode}-production-records-' if mode else 'cli-production-records-';out=p/(name+manifest['source_fingerprint']);out.mkdir(exist_ok=False)
sha=lambda f:hashlib.file_digest(f.open('rb'),'sha256').hexdigest();cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
cliargs=['--work','100000000000','--packed-bytes',str(16*1024**3),'--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000']
binaries={'A':p/'binaries'/('compute' if mode else 'compute-reference'),'B':Path('/tmp/hex-groebner-msolve/msolve') if mode else p/'binaries/compute'}
m={**manifest,'cpu':cpu,'threads':1,'host':os.uname().nodename,'load_start':os.getloadavg(),'suite_sha256':sha(root/'diagnostic-suite.json'),'schedule':'two fixed blocks, adjacent AB then BA per input; retain all completed samples','contract':'Full unchecked reduced candidates; no certificate generation, independent final certification or kernel replay in timing. GNU time wrapper is identical on both arms and supplies post-exec peak RSS; wall time includes wrapper/launch/startup/parse/full output. A/B are ordinary/minimal SDK initialization of identical driver code unless msolve mode is present, then A is the dedicated driver and B is msolve full reduced grevlex output. One algorithm thread; resource caps match. No quiet-host filtering.','baseline_source_fingerprint':manifest['source_fingerprint'],'script':Path(__file__).read_text(),'samples':[],'msolve_mode':mode,'binary_sha256':{a:sha(f) for a,f in binaries.items()},'time_version':subprocess.check_output(['/run/current-system/sw/bin/time','--version'],text=True)}
if mode:
 ms=Path('/tmp/hex-groebner-msolve');m.update(msolve_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ms,text=True).strip(),msolve_engine_sha256=sha(ms/'src/neogb/.libs/libneogb.so.4.0.0'),msolve_cli_sha256=sha(ms/'.libs/msolve'),msolve_compiler='Clang23.1.3 -std=gnu23 -O3 -march=native; GMP6.3.0 MPFR4.2.2 FLINT3.6.0; source and linkage retained')
libc=ctypes.CDLL(None,use_errno=True);libc.pidfd_open.argtypes=[ctypes.c_int,ctypes.c_uint];libc.pidfd_open.restype=ctypes.c_int

def limits():
 os.setsid();resource.setrlimit(resource.RLIMIT_AS,(plan['protocol']['address_space_bytes'],)*2);resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,)*2)

try:
 for block,order in enumerate(['AB','BA']):
  for case in plan['cases']:
   bases={};results={}
   for arm in order:
    prefix=f"{case['name']}-b{block}-{arm}";rss=out/(prefix+'.rss');basisfile=out/(prefix+'.basis')
    program=[str(binaries[arm]),'-g','2','-t','1','-l',str(mode),'-v','2','-f',str(root/(case['name']+'.ms')),'-o',str(basisfile)] if mode and arm=='B' else [str(binaries[arm]),*cliargs,str(root/(case['name']+'.json'))]
    command=['/run/current-system/sw/bin/time','-f','%M','-o',str(rss),*program];start=time.monotonic_ns();timeout=False
    with (out/(prefix+'.stdout')).open('wb') as stdout,(out/(prefix+'.stderr')).open('wb') as stderr:
     proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env,preexec_fn=limits);fd=libc.pidfd_open(proc.pid,0)
     if fd<0:raise OSError(ctypes.get_errno(),'pidfd_open')
     try:
      ready,_,_=select.select([fd],[],[],plan['protocol']['timeout_seconds'])
      if not ready:timeout=True;os.killpg(proc.pid,signal.SIGKILL)
      _,status,usage=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status)
     finally:os.close(fd)
    elapsed=time.monotonic_ns()-start;record={'case':case['name'],'family':case['family'],'p':case['p'],'block':block,'arm':arm,'command':command,'wall_nanos':elapsed,'status':'timeout' if timeout else 'ok' if proc.returncode==0 else 'failed','returncode':proc.returncode,'peak_rss_kib':int(rss.read_text().splitlines()[-1]) if rss.exists() and rss.read_text().splitlines()[-1].isdigit() else None}
    if proc.returncode==0:
     if mode and arm=='B':
      data=''.join(line for line in basisfile.read_text().splitlines() if not line.startswith('#')).strip();assert data.startswith('[') and data.endswith(']:');bases[arm]=sorted(polynomial(s,case['variables'],case['p']) for s in data[1:-2].split(','))
     else:
      payload=json.loads((out/(prefix+'.stdout')).read_text());assert payload['kind']=='unchecked_candidate';bases[arm]=canonical(payload['basis']);results[arm]={k:v for k,v in payload.items() if k not in ['basis','candidateNanos']};record['statistics']={**payload['statistics'],'candidate_nanos':payload['candidateNanos']}
    m['samples'].append(record);print(prefix,record['status'],round(elapsed/1e6,2),flush=True)
   assert len(bases)==2 and bases['A']==bases['B'],case['name']
   if not mode:assert results['A']==results['B'],case['name']
   for sample in m['samples'][-2:]:sample['complete_basis_equal']=True
finally:
 m['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(m,indent=2)+'\n');lease.close()
ratios=[];families={}
for case in plan['cases']:
 for block in [0,1]:
  a,b=[next(s for s in m['samples'] if s['case']==case['name'] and s['block']==block and s['arm']==arm) for arm in ['A','B']];r=a['wall_nanos']/b['wall_nanos'] if mode else b['wall_nanos']/a['wall_nanos'];ratios.append(r);families.setdefault(case['family'],[]).append(r)
g=lambda v:math.exp(sum(map(math.log,v))/len(v));summary={'cpu':cpu,'samples':len(m['samples']),'complete_bases_equal':len(m['samples'])//2,'ratio_direction':'Hex/msolve process' if mode else 'minimal/full process','geomean':g(ratios),'median':statistics.median(ratios),'minimum':min(ratios),'maximum':max(ratios),'per_family':{k:g(v) for k,v in families.items()},'family_balanced_geomean':g([g(v) for v in families.values()]),'peak_rss_kib':{arm:max(s['peak_rss_kib'] for s in m['samples'] if s['arm']==arm) for arm in ['A','B']}};(out/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
