import json,math,pathlib,statistics
base=pathlib.Path('/tmp/hex-groebner-small-production');g=lambda v:math.exp(sum(map(math.log,v))/len(v));stats=lambda v:dict(geomean=g(v),median=statistics.median(v),minimum=min(v),maximum=max(v))
p=next(base.glob('small-production-records-*'));d=json.loads((p/'metadata.json').read_text());ratios=[];wall=[];cases={};fields={}
for c in json.loads((p/'diagnostic-suite.json').read_text())['cases']:
 r=[]
 for block in (0,1):
  v={x['arm']:x for x in d['samples'] if x['case']==c['name'] and x['block']==block};a,b=v['A'],v['B'];assert a['status']==b['status']=='ok'
  x=b['statistics']['candidate_nanos']/a['statistics']['candidate_nanos'];r.append(x);ratios.append(x);fields.setdefault(str(c['p']),[]).append(x);wall.append(b['wall_nanos']/a['wall_nanos'])
  for k in a['statistics']:
   if k!='candidate_nanos':assert a['statistics'][k]==b['statistics'][k],(c,k)
  assert json.loads((p/f"{c['name']}-b{block}-A.stdout").read_text())['basis']==json.loads((p/f"{c['name']}-b{block}-B.stdout").read_text())['basis']
 cases[c['name']]=r
out=dict(cpu=d['cpu'],samples=len(d['samples']),candidate=stats(ratios),wall=stats(wall),fields={p:stats(v) for p,v in fields.items()},per_case=cases,all_bases_counters_equal=True);(p/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print('full system',out)
p=next(base.glob('small-production-kernels-*'));d=json.loads((p/'metadata.json').read_text());ratios={};count=0;inconclusive=[];budget=[]
for case in ('cauchy8','cauchy16','cauchy16Trace','cyclic6Small'):
 r={}
 for block in (0,1):
  a,b=[json.loads((p/f'{case}-b{block}-{arm}.json').read_text())['results'][0] for arm in ('A','B')]
  for arm,v in zip(('A','B'),(a,b)):
   if v.get('verdict')=='inconclusive':inconclusive.append(f'{case}-b{block}-{arm}')
   if v.get('budget_truncated'):budget.append(f'{case}-b{block}-{arm}')
  assert len(a['points'])==len(b['points'])
  for x,y in zip(a['points'],b['points']):
   assert x['status']==y['status']=='ok' and x['result_hash']==y['result_hash']
   n=x.get('param','fixed');assert n==y.get('param','fixed')
   count+=2;r.setdefault(str(n),[]).append((y['total_nanos']/y['inner_repeats'])/(x['total_nanos']/x['inner_repeats']))
 ratios[case]={n:dict(**stats(v),ratios=v) for n,v in r.items()}
out=dict(cpu=d['cpu'],points=count,complete_hashes_match=True,per_case=ratios,inconclusive_exports=inconclusive,budget_truncated_exports=budget);(p/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print('kernels CPU',d['cpu'],'points',count,'inconclusive',inconclusive,'truncated',budget)
for case,r in ratios.items():print(case,{n:{k:round(v[k],4) for k in ('geomean','median','minimum','maximum')} for n,v in r.items()})
