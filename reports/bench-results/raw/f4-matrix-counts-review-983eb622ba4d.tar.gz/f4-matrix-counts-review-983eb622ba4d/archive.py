from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile,sys
state=Path('/home/kim/tmp/issue-10987');root=Path.cwd();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();checks=json.loads((state/'matrix-counts-review-full-status.json').read_text());assert len(checks)==9 and all(c['exit_code']==0 for c in checks);build=checks[0];assert build['source_commit']==commit
payload={}
def add(key,p):
 assert key not in payload
 payload[key]=p.read_bytes()
record=dict(source_commit=commit,command=' '.join(build['command']),exit_code=build['exit_code'],log='build.log',scope='Build includes work-prefix guard and four traced trace-node exhaustion guards. Full project checks follow. Existing native variants use the byte-identical driver runtime.')
payload['record.json']=(json.dumps(record,indent=2)+'\n').encode();add('build.log',Path(build['log']))
for key,name in [('full-status.json','matrix-counts-review-full-status.json'),('fixture-audit.json','matrix-counts-review-emit.json'),('fixture-emission.log','matrix-counts-review-emit.log'),('binary-identity.json','matrix-counts-review-binary-identity.json'),('capsule-tests.json','matrix-counts-capsule-tests.json')]:add(key,state/name)
for c in checks:add('checks/'+c['name']+'.log',Path(c['log']))
for key,p in [('freeze/manifest.json',state/'matrix-counts-review-production/manifest.json'),('freeze/build.log',state/'matrix-counts-review-production/build.log'),('archive.py',Path(__file__))]:add(key,p)
payload['review-fixes.patch']=subprocess.check_output(['git','diff','--binary','beab7bab18e3cab9bfab5c70ef242451cef31ce7',commit,'--','.',':!reports'])
payload['sha256.json']=(json.dumps({k:hashlib.sha256(v).hexdigest()for k,v in payload.items()},sort_keys=True,indent=2)+'\n').encode();name='f4-matrix-counts-review-'+commit[:12];out=root/'reports/bench-results/raw'/(name+'.tar.gz')
with out.open('xb')as f,gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as z,tarfile.open(fileobj=z,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
sys.path.insert(0,str(root));from scripts.bench.groebner_capsule import Capsule
capsule=Capsule(out);assert capsule.count==len(payload)
result=dict(path=str(out),sha256=capsule.sha256,payloads=capsule.count,bytes=out.stat().st_size);(state/'matrix-counts-review-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
