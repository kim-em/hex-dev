from pathlib import Path
import hashlib,json,os,re,subprocess,time
state=Path('/home/kim/tmp/issue-10987');out=state/'gamba-provenance-audit';out.mkdir(exist_ok=False)
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
records=json.loads((state/'gamba-binaries.json').read_text());hex=state/'equivalence-final-production/binaries/compute';info=[]
for record in [dict(isa='hex',binary=str(hex),loader='/lib64/ld-linux-x86-64.so.2',library_path=None),*records]:
 label=record['isa'];binary=record['binary'];readelf=subprocess.check_output(['readelf','-l',binary],text=True);dynamic=subprocess.check_output(['readelf','-d',binary],text=True);(out/(label+'-program-headers.txt')).write_text(readelf);(out/(label+'-dynamic.txt')).write_text(dynamic)
 loader=Path(record['loader']).resolve();command=[str(loader),*(['--library-path',record['library_path']]if record['library_path']else[]),'--list',binary];listing_command=command;result=subprocess.run(command,text=True,capture_output=True);assert result.returncode==0;(out/(label+'-loader-list.txt')).write_text(result.stdout+result.stderr)
 paths={Path(p).resolve()for p in re.findall(r'(/[^\s()]+)',result.stdout)if Path(p).is_file()};paths.add(loader)
 if label=='hex':
  command=[binary,'--scheduling','degree','--work','100000000000',str(state/'final-products-production/medium-inputs/eco11-15.json')]
 else:command=[str(loader),'--library-path',record['library_path'],binary,'-d','grevlex','-s','10987','-t','1','-v','2','-i',str(state/'final-products-production/medium-inputs/eco11-15.ms'),'-o',str(out/(label+'-eco11.basis'))]
 readings=[];environment=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 with(out/(label+'-eco11.stdout')).open('wb')as stdout,(out/(label+'-eco11.stderr')).open('wb')as stderr:
  process=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=environment)
  while process.poll()is None:
   try:
    text=Path(f'/proc/{process.pid}/stat').read_text();fields=text[text.rfind(')')+2:].split();status=Path(f'/proc/{process.pid}/status').read_text();maps=Path(f'/proc/{process.pid}/maps').read_text();paths|={Path(p).resolve()for p in re.findall(r'(/[^\s]+)',maps)if Path(p).is_file()and not p.endswith('(deleted)')};readings.append(dict(nice=int(fields[16]),priority=int(fields[15]),threads=int(re.search(r'^Threads:\s*(\d+)',status,re.M)[1])))
   except FileNotFoundError:pass
   time.sleep(.005)
  code=process.wait();assert code==0
 info.append(dict(arm=label,binary=binary,binary_sha256=sha(binary),loader=str(loader),loader_sha256=sha(loader),loader_list_command=listing_command,loaded_files={str(p):sha(p)for p in sorted(paths)},operational_command=command,exit_code=code,process_samples=readings,nice_values=sorted({x['nice']for x in readings}),thread_counts=sorted({x['threads']for x in readings})))
(out/'audit.json').write_text(json.dumps(dict(scope='Untimed operational provenance audit after the campaigns; sampled process nice/priority/thread counts, loader lists and mapped file hashes. These are not historical scheduler observations for the measured runs and not a startup baseline or timing sample.',arms=info,script=Path(__file__).read_text()),indent=2)+'\n');print([(r['arm'],r['nice_values'],r['thread_counts'])for r in info],flush=True)
