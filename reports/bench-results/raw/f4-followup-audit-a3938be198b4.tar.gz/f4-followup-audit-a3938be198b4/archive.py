from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');name='f4-followup-audit-a3938be198b4';payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
for directory in ['gamba-provenance-audit','workspace-wide-clang','workspace-wide-gcc']:
 for p in sorted((state/directory).rglob('*')):
  if p.is_file()and'.lake'not in p.relative_to(state/directory).parts:add(directory+'/'+str(p.relative_to(state/directory)),p.read_bytes())
for relative in ['workspace-wide-native-status.json','workspace-wide-native-checks.py','workspace-wide-clang.log','workspace-wide-gcc.log','workspace-zero-wide-tests-build.log','gamba-audit-provenance.py','gamba-avx2-help.txt','gamba-avx512-help.txt','gamba-measure.py','workspace-zero-dag-tests.log']:
 add('reproduction/'+relative,(state/relative).read_bytes())
for isa in ['avx2','avx512']:
 add(f'gamba-medium-{isa}/analysis.json',(state/f'gamba-medium-{isa}/analysis.json').read_bytes())
original=json.loads((state/'workspace-zero-production/manifest.json').read_text());add('shipping.patch',subprocess.check_output(['git','diff','--binary',original['source_snapshot'],'--','.',':!reports'],cwd=root));add('shipping-base.json',(json.dumps(dict(source_snapshot=original['source_snapshot'],source_tree=original['source_tree'],source_fingerprint=original['source_fingerprint'],scope='Post-freeze test/documentation changes; measured runtime source family remains identical'),indent=2)+'\n').encode());add('archive.py',Path(__file__).read_bytes());add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest()for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/'followup-audit-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
