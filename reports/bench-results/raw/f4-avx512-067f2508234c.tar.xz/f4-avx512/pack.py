from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root));payload={}
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();native=json.loads((s/'avx512-final-native-status.json').read_text());full=json.loads((s/'avx512-final-full-status.json').read_text())
assert len(native)==2 and len(full)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in native+full)
def add(name,path):assert name not in payload;payload[name]=path.read_bytes()
for label in ['avx512-baseline','avx512-prototype']:
 base=s/(label+'-production')
 for p in sorted(base.rglob('*')):
  if p.is_file()and 'binaries'not in p.relative_to(base).parts:add(label+'/'+str(p.relative_to(base)),p)
for kind in ['native','full']:
 add(kind+'-status.json',s/f'avx512-final-{kind}-status.json');add(kind+'-checks.py',s/f'avx512-final-{kind}-checks.py')
for family,prefix in [(FAMILY,'runtime'),(CHECKS,'checks')]:
 text=tree_listing(family,'HEAD');payload[prefix+'.manifest']=text.encode()
 for line in text.splitlines():
  _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload[prefix+'-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for row in full:add(row['name']+'.log',Path(row['log']))
for cc in ['clang','gcc']:
 add(cc+'.log',s/f'avx512-final-{cc}.log')
 for p in sorted((s/f'avx512-final-{cc}').rglob('*')):
  if p.is_file()and'.lake'not in p.relative_to(s/f'avx512-final-{cc}').parts:add('probes/'+cc+'/'+str(p.relative_to(s/f'avx512-final-{cc}')),p)
for name in ['avx512-prototype-native-status.json','avx512-prototype-clang.log']:
 add('diagnostics/initial-harness/'+name,s/name)
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();add('pack.py',Path(__file__))
digests={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())};payload['sha256.json']=(json.dumps(digests,indent=2)+'\n').encode();out=s/('f4-avx512-'+identity['source_fingerprint']+'.tar.xz')
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-avx512/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(digests),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
