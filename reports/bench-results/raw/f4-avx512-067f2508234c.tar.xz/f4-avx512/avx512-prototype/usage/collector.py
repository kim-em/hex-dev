from pathlib import Path
import hashlib,json,os,subprocess
s=Path('/home/kim/tmp/issue-10987');project=s/'avx512-usage-project';base=s/'avx512-prototype-production';out=base/'usage';out.mkdir(exist_ok=False)
loader='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2';libs='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib';asan='/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/lib/clang/23/lib/linux/libclang_rt.asan-x86_64.so'
cc='/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang';asan=subprocess.check_output([cc,'-print-file-name=libclang_rt.asan-x86_64.so'],text=True).strip();binary=project/'.lake/build/bin/usage';digest=hashlib.sha256(binary.read_bytes()).hexdigest();records=[]
m=json.loads((base/'f4/metadata.json').read_text());env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1',LEAN_ABORT_ON_NONLINEAR='1');env.pop('LD_PRELOAD',None)
for case in sorted({sample['case']for sample in m['samples']}):
 inp=base/'f4/inputs'/(case+'.json');command=[loader,'--library-path',libs,'--preload',asan,str(binary),'--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000','--scheduling','degree',str(inp)]
 with(out/(case+'.stdout')).open('w')as stdout,(out/(case+'.stderr')).open('w')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=env)
 assert r.returncode==0;actual=json.loads((out/(case+'.stdout')).read_text());expected=json.loads((base/'f4'/(case+'-b0-B.stdout')).read_text());actual.pop('candidateNanos');expected.pop('candidateNanos');assert actual==expected
 counters=json.loads((out/(case+'.stderr')).read_text());records.append(dict(case=case,p=actual['p'],command=command,exit_code=r.returncode,binary_sha256=digest,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),counters=counters));(out/'metadata.json').write_text(json.dumps(records,indent=2)+'\n');print(case,counters['avx512Packets'],flush=True)
assert hashlib.sha256(binary.read_bytes()).hexdigest()==digest
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
for name in ['Usage.lean','probe.c','lakefile.lean','lake-manifest.json','lean-toolchain']:(out/name).write_bytes((project/name).read_bytes())
