from pathlib import Path
import json,subprocess,shutil,os,sys,hashlib,time
root=Path('/tmp/hex-groebner-evidence-review');base=Path('/tmp/hex-groebner-column-revised-production');out=Path('/tmp/hex-groebner-column-revised-kernels');out.mkdir(exist_ok=False);folder=base/'bench-binaries'
while not (folder/'builds.json').exists():time.sleep(1)
build=json.loads((folder/'builds.json').read_text())['B'];assert build['returncode']==0;binary=folder/'B';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256'];shutil.copy2(folder/'builds.json',out/'builds.json');shutil.copy2(base/'manifest.json',out/'source-manifest.json')
sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});records=[];load_start=os.getloadavg()
try:
 for kernel in ['columnDirect','columnIndex']:
  command=[str(binary),'run','Hex.Groebner.Bench.'+kernel,'--outer-trials','5','--export-file',str(out/(kernel+'.json'))]
  with (out/(kernel+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  records.append(dict(kernel=kernel,command=command,returncode=r.returncode));assert r.returncode in [0,2]
  value=json.loads((out/(kernel+'.json')).read_text())['results'][0];points=value['points'];assert len(points)==45 and all(v['status']=='ok' for v in points)
  for n in [1024,1536,2048,3072,4096,8192,16384,32768,65536]:assert len({v['result_hash'] for v in points if v['param']==n})==1
  print(kernel,'45completepoints',value['verdict'],flush=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,source_fingerprint=build['source_fingerprint'],binary_sha256=build['binary_sha256'],load_start=load_start,load_end=os.getloadavg(),scope='Registered four-second inner batch, explicit five-trial, nine-size fixed lean-bench trial-major schedule. Sizes include non-powers of two and extend from1024to65536, varying hash load and exceeding the old256KiB table. Preparation excluded; allocation, initialization, complete table construction, bounded translation, output validation and full map/support hashing included. These measure whole map pipelines; indexed and direct maps hash different payload lengths, so their time ratio is not an isolated build-cost comparison. All completed points, flags, failures, host activity and raw data retained. No activity filtering or unchanged rerun. Fresh detached benchmark builds share only pinned package cache. Separate source/configuration from earlier9449/8267five-size observations; no pooling.',runs=records),indent=2)+'\n');lease.close()
shutil.copy2(__file__,out/'measure.py')
