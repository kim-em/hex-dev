from pathlib import Path
import json,subprocess,hashlib,tarfile,shutil,time
repo=Path('/tmp/hex-groebner-evidence-review');base=Path('/tmp/hex-groebner-column-revised-production');repeat=Path('/tmp/hex-groebner-column-revised-kernels-repeat/metadata.json')
while not repeat.exists():time.sleep(2)
repeat_data=json.loads(repeat.read_text());assert len(repeat_data['runs'])==2 and all(v['returncode'] in [0,2] for v in repeat_data['runs'])
checks=json.loads(Path('/tmp/issue-10987-column-revised-full-status.json').read_text());assert len(checks)==9 and all(v['exit_code']==0 for v in checks);m=json.loads((base/'manifest.json').read_text());name='column-revised-'+m['source_fingerprint'];stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
for p in base.iterdir():
 if p.name=='binaries':continue
 if p.name=='bench-binaries':
  d=stage/p.name;d.mkdir()
  for q in p.iterdir():
   if q.is_file() and q.name not in ['A','B']:shutil.copy2(q,d/q.name)
 elif p.is_dir():shutil.copytree(p,stage/p.name)
 else:shutil.copy2(p,stage/p.name)
identities={'measured':m,'baseline':json.loads(Path('/tmp/hex-groebner-whole-matrix-reviewed-production/manifest.json').read_text()),'initial':json.loads(Path('/tmp/hex-groebner-column-index-production/manifest.json').read_text())};counts={}
for label,manifest in identities.items():
 (stage/(label+'-manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n');counts[label]=0
 for line in manifest['source_manifest'].splitlines():
  mode,n=line.split('\t',1);oid=mode.split()[1];b=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;p=stage/(label+'-sources')/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);counts[label]+=1
validation=[]
for line in subprocess.check_output(['git','ls-files','--stage'],cwd=repo,text=True).splitlines():
 mode,n=line.split('\t',1)
 if not (n.startswith('conformance/HexGroebner/') or n.startswith('conformance-fixtures/HexGroebner/') or n in ['scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh','scripts/ci/check_groebner_driver.py','scripts/ci/run_oracles.sh']):continue
 oid=mode.split()[1];data=(repo/n).read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
 p=stage/'validation-sources'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);validation.append(line)
(stage/'validation-sources.manifest').write_text('\n'.join(validation)+'\n')
for pattern in ['issue-10987-column-revised-*.log','issue-10987-column-revised-*.json','issue-10987-pr11012-review-*.log','issue-10987-pr11012-implementation-failed.log','issue-10987-column-small-routes.log','issue-10987-column-revision-profile.log']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,stage/p.name)
for n in ['measure-groebner-column-revised.py','measure-groebner-column-revised-msolve.py','build-groebner-column-revised-benches.py','measure-groebner-column-revised-kernels.py','measure-groebner-column-revised-kernels-repeat.py','profile-groebner-column-small-routes.py','profile-groebner-column-revision.py','run-issue-10987-full-checks.py']:
 shutil.copy2(Path('/tmp')/n,stage/n)
for label,path in [('kernel-first','/tmp/hex-groebner-column-revised-kernels'),('kernel-repeat','/tmp/hex-groebner-column-revised-kernels-repeat'),('small-initial-source-routes','/tmp/hex-groebner-column-small-routes')]:shutil.copytree(path,stage/label)
profile=Path('/tmp/hex-groebner-column-revision-profile');d=stage/'source-revision-profile';d.mkdir();external=[]
for p in profile.iterdir():
 if not p.is_file():continue
 if p.name.endswith('.perf.data'):
  external.append(dict(local_path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size))
 else:shutil.copy2(p,d/p.name)
(stage/'local-profile-recordings.json').write_text(json.dumps(external,indent=2)+'\n')
for compiler,path in [('clang','/tmp/hex-groebner-column-revised-clang-sanitizers'),('gcc','/tmp/hex-groebner-column-revised-gcc-corrected-sanitizers')]:
 d=stage/('native-'+compiler);d.mkdir();native=Path(path)
 for p in native.iterdir():
  if p.is_file():shutil.copy2(p,d/p.name)
 for p in (native/'.lake').rglob('*.rsp'):
  q=d/'response-files'/p.relative_to(native/'.lake');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
shutil.copytree('/tmp/issue-10987-relocatable-wrapper',stage/'compiler-wrapper')
license_archive=repo/'reports/bench-results/raw/target-columns-input-provenance-licensed.tar.gz'
if license_archive.exists():
 with tarfile.open(license_archive) as t:
  for v in t.getmembers():
   if v.isfile() and Path(v.name).name=='LICENSE.md':(stage/'public-input-LICENSE.md').write_bytes(t.extractfile(v).read());break
scope='Charge both target-sort lookups per comparison in the packed-column implementation. Exact geometry-selected direct/index layouts, full-key equality, bounded 64 probes and charged fallback, borrowed/output aliases, portable models and bounded zero initialization remain. Source67e9835420ef has separate fresh driver and benchmark builds, first and sole unchanged repeat for small/medium/fixed observations, 240 CLI processes/120 complete equal bases and identical non-resource counters,240 equal fixed structural hashes. Work and allocation changes remain per input; no samples are filtered or pooled with the initial9449source. Separate first matched msolve modes2/42 sweeps retain56processes/28equal full bases each,zero failures/timeouts. The observed external gap differs from earlier source; a direct paired eight-process old/revised CPU profile onCyclic7/Eco11 has equal bases/non-resource counters,zero lost samples and estimated user-cycle ratios1.0427/0.9836. It does not explain the twofold change between separate external sweeps. Full raw timing outputs remain; raw explanatory perf recordings stay at the hashed shared-host paths,flat profiles and allocator/ELF context are archived. Kernel registrations use4s batches and nine fixed sizes including non-powers of two through65536. First and sole unchanged repeat each retain90complete rows,all flags and fit decisions; many first rows are below the signal floor,so no complete scaling proof is claimed. Earlier kernel configurations and sources remain separate. Small route attribution explicitly binds initial9449source; absolute revised candidate ranges and work-budget increases are reported. Nine full local checks pass,including the committed phase gate,34benchmark smoke checks,independent matrix/basis/division oracles and both1134-output CLI checks. FourClang/fourGCC ASanUBSan variants pass. Mimalloc allocations are not all tracked by ASan and leak detection is disabled; explicit C ownership checks assert refcount/exclusivity,original bytes,distinct output storage and success/failure with/without observers. Tests include shared prefixes,marked-linear aliases,exclusive growth,zero reuse,and exact exhaustion before initialization,during insertion and before fallback.64colliders charge2272work/1024bytes;65charge2530/2048before hash fallback. All1134emitted records match previous fields except work counters before regeneration. Initial unstaged freeze,CI missing-cost-comment failure,and GCC harness indentation failure are retained separately and corrected. Exact runtime and validation Git blobs,compiler helper,build logs,response files,inputs,outputs,RSS,activity and sample variability remain. Manual shared EPYC9455,one requested algorithm thread,leased CPUs,no activity filters. Candidate production excludes certificate generation,independent certification and kernel checking. Development evidence,not held-out acceptance; no uniform speedup,leadership or language/runtime impossibility claim.'
(stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=m['source_fingerprint'],physical_source_files=counts,validation_source_files=len(validation),scope=scope),indent=2)+'\n');shutil.copy2(__file__,stage/'archive.py');target=repo/'reports/bench-results/raw'/(name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
c=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source_fingerprint=m['source_fingerprint'],physical_source_files=counts,validation_source_files=len(validation),size=target.stat().st_size);Path('/tmp/issue-10987-column-revised-catalog.json').write_text(json.dumps(c,indent=2)+'\n');print(c)
