from pathlib import Path
import subprocess,sys
root=Path('/tmp/hex-groebner-evidence-review');base=Path('/tmp/hex-groebner-column-revised-production')
for mode in ['2','42']:
 command=['python3','scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite','/tmp/hex-groebner-medium-suite/suite.json','--output',str(base/('msolve-l'+mode)),'--hex',str(base/'binaries/compute'),'--msolve','/tmp/hex-groebner-msolve/.libs/msolve','--msolve-source','/tmp/hex-groebner-msolve','--msolve-mode',mode]
 with Path('/tmp/issue-10987-column-revised-msolve-l'+mode+'.log').open('w') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print(mode,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
