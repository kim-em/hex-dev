from pathlib import Path
import json,subprocess,shutil,tempfile,concurrent.futures,hashlib,os
repo=Path('/tmp/hex-groebner-evidence-review');production=Path('/tmp/hex-groebner-column-revised-production');output=production/'bench-binaries';output.mkdir(exist_ok=False);sources={'A':Path('/tmp/hex-groebner-whole-matrix-reviewed-production'),'B':production};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records={}
with tempfile.TemporaryDirectory(prefix='groebner-column-revised-benches-') as temp:
 checkouts={}
 try:
  for arm,source in sources.items():
   manifest=json.loads((source/'manifest.json').read_text());checkout=Path(temp)/arm
   subprocess.run(['git','worktree','add','--detach',str(checkout),manifest['source_snapshot']],cwd=repo,capture_output=True,check=True)
   (checkout/'.lake').mkdir();(checkout/'.lake/packages').symlink_to((repo/'.lake/packages').resolve(),target_is_directory=True);checkouts[arm]=checkout
   shutil.copy2(source/'manifest.json',output/(arm+'-manifest.json'));records[arm]=dict(source_fingerprint=manifest['source_fingerprint'],source_snapshot=manifest['source_snapshot'],build_policy='fresh detached worktree; only pinned dependency packages shared',command=['lake','build','hexgroebner_bench'])
  def build(arm):
   with (output/(arm+'-build.log')).open('w') as stream:r=subprocess.run(records[arm]['command'],cwd=checkouts[arm],stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,LEAN_CC='/tmp/issue-10987-lean-cc'))
   records[arm]['returncode']=r.returncode
   if r.returncode:raise RuntimeError('benchmark build '+arm+' failed')
   source=checkouts[arm]/'.lake/build/bin/hexgroebner_bench';shutil.copy2(source,output/arm);records[arm]['binary_sha256']=sha(output/arm)
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
   futures=[executor.submit(build,arm) for arm in sources]
   for future in futures:future.result()
 finally:
  for checkout in checkouts.values():subprocess.run(['git','worktree','remove','--force',str(checkout)],cwd=repo,capture_output=True,check=True)
  (output/'builds.json').write_text(json.dumps(records,indent=2)+'\n')
for name in ['issue-10987-lean-cc','issue-10987-lean-cc-flags.json']:shutil.copy2(Path('/tmp')/name,output/name)
shutil.copy2(__file__,output/'build-benches.py');print(records)
