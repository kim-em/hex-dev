
/tmp/hex-groebner-inspect-production/binaries/compare-inspect:     file format elf64-x86-64


Disassembly of section .text:

0000000000c799b0 <lean_hex_groebner_inspect_monomials>:
  c799b0:	55                   	push   %rbp
  c799b1:	41 57                	push   %r15
  c799b3:	41 56                	push   %r14
  c799b5:	41 55                	push   %r13
  c799b7:	41 54                	push   %r12
  c799b9:	53                   	push   %rbx
  c799ba:	50                   	push   %rax
  c799bb:	41 0f b6 41 07       	movzbl 0x7(%r9),%eax
  c799c0:	c1 e0 18             	shl    $0x18,%eax
  c799c3:	3d 00 00 00 f8       	cmp    $0xf8000000,%eax
  c799c8:	0f 85 a8 02 00 00    	jne    c79c76 <lean_hex_groebner_inspect_monomials+0x2c6>
  c799ce:	b0 03                	mov    $0x3,%al
  c799d0:	40 80 ff 02          	cmp    $0x2,%dil
  c799d4:	0f 87 6c 02 00 00    	ja     c79c46 <lean_hex_groebner_inspect_monomials+0x296>
  c799da:	44 8d 56 fd          	lea    -0x3(%rsi),%r10d
  c799de:	41 80 fa fe          	cmp    $0xfe,%r10b
  c799e2:	41 0f 92 c2          	setb   %r10b
  c799e6:	40 80 fe 04          	cmp    $0x4,%sil
  c799ea:	41 0f 95 c3          	setne  %r11b
  c799ee:	45 20 d3             	and    %r10b,%r11b
  c799f1:	48 81 fa 01 10 00 00 	cmp    $0x1001,%rdx
  c799f8:	41 0f 93 c2          	setae  %r10b
  c799fc:	45 08 da             	or     %r11b,%r10b
  c799ff:	4d 89 c3             	mov    %r8,%r11
  c79a02:	49 09 cb             	or     %rcx,%r11
  c79a05:	49 c1 eb 20          	shr    $0x20,%r11
  c79a09:	41 0f 95 c3          	setne  %r11b
  c79a0d:	45 08 d3             	or     %r10b,%r11b
  c79a10:	0f 85 30 02 00 00    	jne    c79c46 <lean_hex_groebner_inspect_monomials+0x296>
  c79a16:	48 85 d2             	test   %rdx,%rdx
  c79a19:	0f 84 25 02 00 00    	je     c79c44 <lean_hex_groebner_inspect_monomials+0x294>
  c79a1f:	49 8b 41 08          	mov    0x8(%r9),%rax
  c79a23:	49 89 f6             	mov    %rsi,%r14
  c79a26:	40 0f b6 de          	movzbl %sil,%ebx
  c79a2a:	49 89 d2             	mov    %rdx,%r10
  c79a2d:	48 89 d6             	mov    %rdx,%rsi
  c79a30:	48 0f af f3          	imul   %rbx,%rsi
  c79a34:	48 89 c2             	mov    %rax,%rdx
  c79a37:	48 09 f2             	or     %rsi,%rdx
  c79a3a:	48 c1 ea 20          	shr    $0x20,%rdx
  c79a3e:	74 15                	je     c79a55 <lean_hex_groebner_inspect_monomials+0xa5>
  c79a40:	31 d2                	xor    %edx,%edx
  c79a42:	48 f7 f6             	div    %rsi
  c79a45:	49 89 c3             	mov    %rax,%r11
  c79a48:	48 85 d2             	test   %rdx,%rdx
  c79a4b:	b0 03                	mov    $0x3,%al
  c79a4d:	0f 85 f3 01 00 00    	jne    c79c46 <lean_hex_groebner_inspect_monomials+0x296>
  c79a53:	eb 12                	jmp    c79a67 <lean_hex_groebner_inspect_monomials+0xb7>
  c79a55:	31 d2                	xor    %edx,%edx
  c79a57:	f7 f6                	div    %esi
  c79a59:	41 89 c3             	mov    %eax,%r11d
  c79a5c:	48 85 d2             	test   %rdx,%rdx
  c79a5f:	b0 03                	mov    $0x3,%al
  c79a61:	0f 85 df 01 00 00    	jne    c79c46 <lean_hex_groebner_inspect_monomials+0x296>
  c79a67:	4c 39 d9             	cmp    %r11,%rcx
  c79a6a:	0f 93 c2             	setae  %dl
  c79a6d:	4d 39 d8             	cmp    %r11,%r8
  c79a70:	41 0f 93 c3          	setae  %r11b
  c79a74:	41 08 d3             	or     %dl,%r11b
  c79a77:	0f 85 c9 01 00 00    	jne    c79c46 <lean_hex_groebner_inspect_monomials+0x296>
  c79a7d:	49 83 c1 18          	add    $0x18,%r9
  c79a81:	89 fa                	mov    %edi,%edx
  c79a83:	48 89 cf             	mov    %rcx,%rdi
  c79a86:	48 0f af fe          	imul   %rsi,%rdi
  c79a8a:	49 0f af f0          	imul   %r8,%rsi
  c79a8e:	45 89 f3             	mov    %r14d,%r11d
  c79a91:	41 80 f3 01          	xor    $0x1,%r11b
  c79a95:	41 08 d3             	or     %dl,%r11b
  c79a98:	75 26                	jne    c79ac0 <lean_hex_groebner_inspect_monomials+0x110>
  c79a9a:	4c 01 cf             	add    %r9,%rdi
  c79a9d:	4c 01 ce             	add    %r9,%rsi
  c79aa0:	4c 89 d2             	mov    %r10,%rdx
  c79aa3:	e8 e8 8d dd 03       	call   4a52890 <memcmp@plt>
  c79aa8:	85 c0                	test   %eax,%eax
  c79aaa:	0f 94 c1             	sete   %cl
  c79aad:	b2 02                	mov    $0x2,%dl
  c79aaf:	28 ca                	sub    %cl,%dl
  c79ab1:	31 c9                	xor    %ecx,%ecx
  c79ab3:	85 c0                	test   %eax,%eax
  c79ab5:	0f b6 c2             	movzbl %dl,%eax
  c79ab8:	0f 48 c1             	cmovs  %ecx,%eax
  c79abb:	e9 86 01 00 00       	jmp    c79c46 <lean_hex_groebner_inspect_monomials+0x296>
  c79ac0:	89 d0                	mov    %edx,%eax
  c79ac2:	41 80 fe 01          	cmp    $0x1,%r14b
  c79ac6:	75 20                	jne    c79ae8 <lean_hex_groebner_inspect_monomials+0x138>
  c79ac8:	3c 02                	cmp    $0x2,%al
  c79aca:	75 49                	jne    c79b15 <lean_hex_groebner_inspect_monomials+0x165>
  c79acc:	41 0f b6 04 39       	movzbl (%r9,%rdi,1),%eax
  c79ad1:	41 3a 04 31          	cmp    (%r9,%rsi,1),%al
  c79ad5:	0f 87 b8 00 00 00    	ja     c79b93 <lean_hex_groebner_inspect_monomials+0x1e3>
  c79adb:	49 01 d9             	add    %rbx,%r9
  c79ade:	49 ff ca             	dec    %r10
  c79ae1:	75 e9                	jne    c79acc <lean_hex_groebner_inspect_monomials+0x11c>
  c79ae3:	e9 5c 01 00 00       	jmp    c79c44 <lean_hex_groebner_inspect_monomials+0x294>
  c79ae8:	41 80 fe 04          	cmp    $0x4,%r14b
  c79aec:	0f 85 84 00 00 00    	jne    c79b76 <lean_hex_groebner_inspect_monomials+0x1c6>
  c79af2:	3c 02                	cmp    $0x2,%al
  c79af4:	0f 85 a0 00 00 00    	jne    c79b9a <lean_hex_groebner_inspect_monomials+0x1ea>
  c79afa:	41 8b 04 39          	mov    (%r9,%rdi,1),%eax
  c79afe:	41 3b 04 31          	cmp    (%r9,%rsi,1),%eax
  c79b02:	0f 87 8b 00 00 00    	ja     c79b93 <lean_hex_groebner_inspect_monomials+0x1e3>
  c79b08:	49 01 d9             	add    %rbx,%r9
  c79b0b:	49 ff ca             	dec    %r10
  c79b0e:	75 ea                	jne    c79afa <lean_hex_groebner_inspect_monomials+0x14a>
  c79b10:	e9 2f 01 00 00       	jmp    c79c44 <lean_hex_groebner_inspect_monomials+0x294>
  c79b15:	3c 01                	cmp    $0x1,%al
  c79b17:	75 3e                	jne    c79b57 <lean_hex_groebner_inspect_monomials+0x1a7>
  c79b19:	49 ff c0             	inc    %r8
  c79b1c:	4d 0f af c2          	imul   %r10,%r8
  c79b20:	49 ff c8             	dec    %r8
  c79b23:	4c 0f af c3          	imul   %rbx,%r8
  c79b27:	48 ff c1             	inc    %rcx
  c79b2a:	49 0f af ca          	imul   %r10,%rcx
  c79b2e:	48 ff c9             	dec    %rcx
  c79b31:	48 0f af cb          	imul   %rbx,%rcx
  c79b35:	48 f7 db             	neg    %rbx
  c79b38:	41 0f b6 04 09       	movzbl (%r9,%rcx,1),%eax
  c79b3d:	43 0f b6 14 01       	movzbl (%r9,%r8,1),%edx
  c79b42:	38 d0                	cmp    %dl,%al
  c79b44:	0f 85 1f 01 00 00    	jne    c79c69 <lean_hex_groebner_inspect_monomials+0x2b9>
  c79b4a:	49 01 d9             	add    %rbx,%r9
  c79b4d:	49 ff ca             	dec    %r10
  c79b50:	75 e6                	jne    c79b38 <lean_hex_groebner_inspect_monomials+0x188>
  c79b52:	e9 ed 00 00 00       	jmp    c79c44 <lean_hex_groebner_inspect_monomials+0x294>
  c79b57:	41 0f b6 04 39       	movzbl (%r9,%rdi,1),%eax
  c79b5c:	41 0f b6 0c 31       	movzbl (%r9,%rsi,1),%ecx
  c79b61:	38 c8                	cmp    %cl,%al
  c79b63:	0f 85 04 01 00 00    	jne    c79c6d <lean_hex_groebner_inspect_monomials+0x2bd>
  c79b69:	49 01 d9             	add    %rbx,%r9
  c79b6c:	49 ff ca             	dec    %r10
  c79b6f:	75 e6                	jne    c79b57 <lean_hex_groebner_inspect_monomials+0x1a7>
  c79b71:	e9 ce 00 00 00       	jmp    c79c44 <lean_hex_groebner_inspect_monomials+0x294>
  c79b76:	3c 02                	cmp    $0x2,%al
  c79b78:	75 77                	jne    c79bf1 <lean_hex_groebner_inspect_monomials+0x241>
  c79b7a:	41 0f b7 04 39       	movzwl (%r9,%rdi,1),%eax
  c79b7f:	66 41 3b 04 31       	cmp    (%r9,%rsi,1),%ax
  c79b84:	77 0d                	ja     c79b93 <lean_hex_groebner_inspect_monomials+0x1e3>
  c79b86:	49 01 d9             	add    %rbx,%r9
  c79b89:	49 ff ca             	dec    %r10
  c79b8c:	75 ec                	jne    c79b7a <lean_hex_groebner_inspect_monomials+0x1ca>
  c79b8e:	e9 b1 00 00 00       	jmp    c79c44 <lean_hex_groebner_inspect_monomials+0x294>
  c79b93:	31 c0                	xor    %eax,%eax
  c79b95:	e9 ac 00 00 00       	jmp    c79c46 <lean_hex_groebner_inspect_monomials+0x296>
  c79b9a:	3c 01                	cmp    $0x1,%al
  c79b9c:	75 39                	jne    c79bd7 <lean_hex_groebner_inspect_monomials+0x227>
  c79b9e:	49 ff c0             	inc    %r8
  c79ba1:	4d 0f af c2          	imul   %r10,%r8
  c79ba5:	49 ff c8             	dec    %r8
  c79ba8:	4c 0f af c3          	imul   %rbx,%r8
  c79bac:	48 ff c1             	inc    %rcx
  c79baf:	49 0f af ca          	imul   %r10,%rcx
  c79bb3:	48 ff c9             	dec    %rcx
  c79bb6:	48 0f af cb          	imul   %rbx,%rcx
  c79bba:	48 f7 db             	neg    %rbx
  c79bbd:	41 8b 04 09          	mov    (%r9,%rcx,1),%eax
  c79bc1:	43 8b 14 01          	mov    (%r9,%r8,1),%edx
  c79bc5:	39 d0                	cmp    %edx,%eax
  c79bc7:	0f 85 9c 00 00 00    	jne    c79c69 <lean_hex_groebner_inspect_monomials+0x2b9>
  c79bcd:	49 01 d9             	add    %rbx,%r9
  c79bd0:	49 ff ca             	dec    %r10
  c79bd3:	75 e8                	jne    c79bbd <lean_hex_groebner_inspect_monomials+0x20d>
  c79bd5:	eb 6d                	jmp    c79c44 <lean_hex_groebner_inspect_monomials+0x294>
  c79bd7:	41 8b 04 39          	mov    (%r9,%rdi,1),%eax
  c79bdb:	41 8b 0c 31          	mov    (%r9,%rsi,1),%ecx
  c79bdf:	39 c8                	cmp    %ecx,%eax
  c79be1:	0f 85 86 00 00 00    	jne    c79c6d <lean_hex_groebner_inspect_monomials+0x2bd>
  c79be7:	49 01 d9             	add    %rbx,%r9
  c79bea:	49 ff ca             	dec    %r10
  c79bed:	75 e8                	jne    c79bd7 <lean_hex_groebner_inspect_monomials+0x227>
  c79bef:	eb 53                	jmp    c79c44 <lean_hex_groebner_inspect_monomials+0x294>
  c79bf1:	3c 01                	cmp    $0x1,%al
  c79bf3:	75 38                	jne    c79c2d <lean_hex_groebner_inspect_monomials+0x27d>
  c79bf5:	49 ff c0             	inc    %r8
  c79bf8:	4d 0f af c2          	imul   %r10,%r8
  c79bfc:	49 ff c8             	dec    %r8
  c79bff:	4c 0f af c3          	imul   %rbx,%r8
  c79c03:	48 ff c1             	inc    %rcx
  c79c06:	49 0f af ca          	imul   %r10,%rcx
  c79c0a:	48 ff c9             	dec    %rcx
  c79c0d:	48 0f af cb          	imul   %rbx,%rcx
  c79c11:	48 f7 db             	neg    %rbx
  c79c14:	41 0f b7 04 09       	movzwl (%r9,%rcx,1),%eax
  c79c19:	43 0f b7 14 01       	movzwl (%r9,%r8,1),%edx
  c79c1e:	66 39 d0             	cmp    %dx,%ax
  c79c21:	75 46                	jne    c79c69 <lean_hex_groebner_inspect_monomials+0x2b9>
  c79c23:	49 01 d9             	add    %rbx,%r9
  c79c26:	49 ff ca             	dec    %r10
  c79c29:	75 e9                	jne    c79c14 <lean_hex_groebner_inspect_monomials+0x264>
  c79c2b:	eb 17                	jmp    c79c44 <lean_hex_groebner_inspect_monomials+0x294>
  c79c2d:	41 0f b7 04 39       	movzwl (%r9,%rdi,1),%eax
  c79c32:	41 0f b7 0c 31       	movzwl (%r9,%rsi,1),%ecx
  c79c37:	66 39 c8             	cmp    %cx,%ax
  c79c3a:	75 31                	jne    c79c6d <lean_hex_groebner_inspect_monomials+0x2bd>
  c79c3c:	49 01 d9             	add    %rbx,%r9
  c79c3f:	49 ff ca             	dec    %r10
  c79c42:	75 e9                	jne    c79c2d <lean_hex_groebner_inspect_monomials+0x27d>
  c79c44:	b0 01                	mov    $0x1,%al
  c79c46:	48 83 c4 08          	add    $0x8,%rsp
  c79c4a:	5b                   	pop    %rbx
  c79c4b:	41 5c                	pop    %r12
  c79c4d:	41 5d                	pop    %r13
  c79c4f:	41 5e                	pop    %r14
  c79c51:	41 5f                	pop    %r15
  c79c53:	5d                   	pop    %rbp
  c79c54:	31 c9                	xor    %ecx,%ecx
  c79c56:	31 ff                	xor    %edi,%edi
  c79c58:	31 d2                	xor    %edx,%edx
  c79c5a:	31 f6                	xor    %esi,%esi
  c79c5c:	45 31 c0             	xor    %r8d,%r8d
  c79c5f:	45 31 c9             	xor    %r9d,%r9d
  c79c62:	45 31 d2             	xor    %r10d,%r10d
  c79c65:	45 31 db             	xor    %r11d,%r11d
  c79c68:	c3                   	ret
  c79c69:	39 c2                	cmp    %eax,%edx
  c79c6b:	eb 02                	jmp    c79c6f <lean_hex_groebner_inspect_monomials+0x2bf>
  c79c6d:	39 c8                	cmp    %ecx,%eax
  c79c6f:	0f 93 c0             	setae  %al
  c79c72:	00 c0                	add    %al,%al
  c79c74:	eb d0                	jmp    c79c46 <lean_hex_groebner_inspect_monomials+0x296>
  c79c76:	48 8d 05 81 24 64 ff 	lea    -0x9bdb7f(%rip),%rax        # 2bc0fe <_ZZN10__cxxabiv112_GLOBAL__N_19__globalsEvE10eh_globals+0x2bc01e>
  c79c7d:	4c 8d 15 31 44 64 ff 	lea    -0x9bbbcf(%rip),%r10        # 2be0b5 <_ZZN10__cxxabiv112_GLOBAL__N_19__globalsEvE10eh_globals+0x2bdfd5>
  c79c84:	89 fb                	mov    %edi,%ebx
  c79c86:	48 89 c7             	mov    %rax,%rdi
  c79c89:	49 89 f6             	mov    %rsi,%r14
  c79c8c:	be ef 02 00 00       	mov    $0x2ef,%esi
  c79c91:	49 89 d7             	mov    %rdx,%r15
  c79c94:	4c 89 d2             	mov    %r10,%rdx
  c79c97:	4d 89 cd             	mov    %r9,%r13
  c79c9a:	4c 89 c5             	mov    %r8,%rbp
  c79c9d:	49 89 cc             	mov    %rcx,%r12
  c79ca0:	e8 0b 02 d1 03       	call   4989eb0 <lean_notify_assert>
  c79ca5:	4c 89 f6             	mov    %r14,%rsi
  c79ca8:	89 df                	mov    %ebx,%edi
  c79caa:	4c 89 e1             	mov    %r12,%rcx
  c79cad:	49 89 e8             	mov    %rbp,%r8
  c79cb0:	4d 89 e9             	mov    %r13,%r9
  c79cb3:	4c 89 fa             	mov    %r15,%rdx
  c79cb6:	41 0f b6 45 07       	movzbl 0x7(%r13),%eax
  c79cbb:	c1 e0 18             	shl    $0x18,%eax
  c79cbe:	3d 00 00 00 f8       	cmp    $0xf8000000,%eax
  c79cc3:	0f 84 05 fd ff ff    	je     c799ce <lean_hex_groebner_inspect_monomials+0x1e>
  c79cc9:	48 8d 3d 2e 24 64 ff 	lea    -0x9bdbd2(%rip),%rdi        # 2bc0fe <_ZZN10__cxxabiv112_GLOBAL__N_19__globalsEvE10eh_globals+0x2bc01e>
  c79cd0:	48 8d 15 de 43 64 ff 	lea    -0x9bbc22(%rip),%rdx        # 2be0b5 <_ZZN10__cxxabiv112_GLOBAL__N_19__globalsEvE10eh_globals+0x2bdfd5>
  c79cd7:	be ef 02 00 00       	mov    $0x2ef,%esi
  c79cdc:	e8 cf 01 d1 03       	call   4989eb0 <lean_notify_assert>
  c79ce1:	4c 89 f6             	mov    %r14,%rsi
  c79ce4:	89 df                	mov    %ebx,%edi
  c79ce6:	4c 89 e1             	mov    %r12,%rcx
  c79ce9:	49 89 e8             	mov    %rbp,%r8
  c79cec:	4d 89 e9             	mov    %r13,%r9
  c79cef:	4c 89 fa             	mov    %r15,%rdx
  c79cf2:	e9 d7 fc ff ff       	jmp    c799ce <lean_hex_groebner_inspect_monomials+0x1e>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
