from pathlib import Path
import shutil,subprocess,json,hashlib,tarfile
root=Path('/tmp/hex-groebner-compare-monomials-dev');p=Path('/tmp/hex-groebner-inspect-span-production');dest=root/'reports/bench-results/raw';records=list(p.glob('inspect-span-production-*7ad863391bb7*'))
validation=p/'inspect-span-validation';validation.mkdir(exist_ok=False)
for log in Path('/tmp').glob('issue-10987-monomial-inspection-*.log'):shutil.copy2(log,validation/log.name)
for file in ['conformance/HexGroebner/InspectConformance.lean','conformance/HexGroebner/NativeChecks.lean','scripts/ci/check_groebner_matrix.py']:
 f=validation/file;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/file,f)
records.append(validation);listing=json.load(open(p/'binaries/manifest.json'))['source_manifest'];baseline=json.load(open(p/'binaries/baseline-manifest.json'))['source_manifest'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for directory in sorted(records):
 for name in ['Main.lean','ReferenceElimination.lean','ReferenceF4.lean','ReferenceSymbolic.lean','lakefile.lean','lake-manifest.json','lean-toolchain','measure-production.py','measure-bench.py','analyze-diagnostic.py','analyze-fields.py','diagnostic-analysis.json','field-analysis.json','fixed-analysis.json']:shutil.copy2(p/name,directory/name)
 for name in ['manifest.json','baseline-manifest.json']:shutil.copy2(p/'binaries'/name,directory/('binary-'+name))
 shutil.copy2(__file__,directory/Path(__file__).name)
 for extra in ['measure-production-repeat.py','measure-bench-repeat.py','initial-inspect.asm','span-inspect.asm']:
  shutil.copy2(p/extra,directory/extra)
 for data,folder in [(listing,'root-sources'),(baseline,'baseline-sources')]:
  for line in data.splitlines():
   _,oid,rest=line.split(' ',2);_,name=rest.split('\t');f=directory/folder/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd=root))
 (directory/'source.manifest').write_text(listing);(directory/'baseline-source.manifest').write_text(baseline)
 target=dest/(directory.name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(directory,arcname=directory.name)
 print(target.name,sha(target),flush=True)
