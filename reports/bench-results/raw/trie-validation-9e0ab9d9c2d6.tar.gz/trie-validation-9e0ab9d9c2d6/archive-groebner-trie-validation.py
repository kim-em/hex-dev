from pathlib import Path
import json,subprocess,sys,hashlib,tarfile,shutil
root=Path('/tmp/hex-groebner-trie-dev');sys.path.insert(0,str(root))
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import index_listing,fingerprint
listing=index_listing(FAMILY);fp=fingerprint(listing);stage=Path('/tmp/hex-groebner-archive-staging')/('trie-validation-'+fp);stage.mkdir(exist_ok=False)
(stage/'source.manifest').write_text(listing)
for line in listing.splitlines():
 header,name=line.split('\t',1);oid=header.split()[1];p=stage/'root-sources'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd=root))
logs=['trie-cli-build','trie-cli-oracles','trie-cli-all-conformance','trie-cli-bench-verify','trie-cli-dag','trie-cli-phase','trie-cli-manifest','trie-cli-san','trie-cli-gcc-san','avx512-oracles']
for name in logs:
 p=Path('/tmp/issue-10987-'+name+'.log');shutil.copy2(p,stage/p.name)
for name in ['conformance/HexGroebner/TrieConformance.lean','conformance/HexGroebner/NativeChecks.lean','scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh','conformance-fixtures/HexGroebner/f4.jsonl']:
 p=stage/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
old=json.loads(Path('/tmp/hex-groebner-trie-compare-production/binaries/manifest.json').read_text());ids={line.split('\t',1)[1]:line.split()[1] for line in old['source_manifest'].splitlines()}
match={}
for name in ['HexGroebner/Reducer.lean','HexGroebner/NativeTrie.lean','HexGroebner/ffi/trie_lookup.h','HexGroebner/ffi/row_update.c']:
 content=(root/name).read_bytes();oid=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest();assert oid==ids[name],name;match[name]=oid
(stage/'scope.json').write_text(json.dumps({'source_fingerprint':fp,'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'measured_trie_source_fingerprint':old['source_fingerprint'],'measured_kernel_sources_unchanged':match,'scope':'Later integration with the standalone CLI. All 1956 relevant conformance/theory targets, both corpus drivers, independent 175/567/1288 oracle cases and four Clang plus four GCC sanitizer variants pass. Maximal read-only trie guard-page checks run in each compiler harness. Only charged work counters change in the 567 fixtures. AVX-512 oracle log is separate validation of its unchanged prototype, not a selected implementation or a performance observation.','driver_sha256':{name:hashlib.sha256((root/'.lake/build/bin'/name).read_bytes()).hexdigest() for name in ['hexgroebner_compute','hexgroebner_compute_full']}},indent=2)+'\n')
shutil.copy2(__file__,stage/Path(__file__).name)
target=Path('/tmp/hex-groebner-evidence-review/reports/bench-results/raw')/(stage.name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=stage.name)
record={'archive':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'source_fingerprint':fp};Path('/tmp/issue-10987-trie-validation-archive.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
