import os,subprocess,json,time
from pathlib import Path
root=Path('/home/kim/tmp/issue-10987');results=[]
for name,compiler in [('clang','/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang'),('gcc','/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/gcc')]:
 env=dict(os.environ,LEAN_CC=str(root/'issue-10987-lean-cc'),CC=compiler,HEX_GROEBNER_SANITIZE='1',HEX_GROEBNER_REQUIRE_AVX2='1',HEX_GROEBNER_TEST_LOADER='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2',HEX_GROEBNER_TEST_LIBRARY_PATH='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib',HEX_GROEBNER_NATIVE_LOG_DIR=str(root/f'scan-cache-{name}'),TMPDIR=str(root))
 start=time.monotonic()
 with (root/f'scan-cache-{name}.log').open('w') as log:
  p=subprocess.run(['bash','scripts/ci/check_groebner_rows.sh'],env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(compiler=compiler,name=name,exit_code=p.returncode,seconds=time.monotonic()-start));(root/'scan-cache-native-status.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
