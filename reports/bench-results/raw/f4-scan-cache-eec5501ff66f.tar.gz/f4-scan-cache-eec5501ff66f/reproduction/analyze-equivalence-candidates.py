from pathlib import Path
import json,math,sys
for directory in map(Path,sys.argv[1:]):
 rows=[]
 for path in sorted(directory.glob('*-A.stdout')):
  other=path.with_name(path.name.replace('-A.stdout','-B.stdout'));a=json.loads(path.read_text());b=json.loads(other.read_text());av=a.pop('candidateNanos');bv=b.pop('candidateNanos');assert a==b,path
  rows.append(dict(input=path.name,reference_candidate_nanos=av,candidate_nanos=bv,ratio=bv/av))
 assert len(rows)==28,len(rows)
 result=dict(scope='Complete JSON objects equal except internal candidateNanos, including every output and statistics field',pairs=len(rows),candidate_geomean=math.exp(sum(math.log(x['ratio']) for x in rows)/len(rows)),minimum=min(x['ratio'] for x in rows),maximum=max(x['ratio'] for x in rows),rows=rows)
 (directory/'candidate-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(directory,result['candidate_geomean'],flush=True)
