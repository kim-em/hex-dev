from pathlib import Path
import os,subprocess,json,sys,time
root=Path.cwd();prefix=Path(sys.argv[1]);results=[]
def run(name,command,env=None):
 log=Path(str(prefix)+'-'+name+'.log');start=time.monotonic()
 with log.open('w')as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,env=env)
 results.append(dict(name=name,command=command,exit_code=r.returncode,seconds=time.monotonic()-start,log=str(log)));Path(str(prefix)+'-status.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
modules=['HexGroebner.'+p.stem for p in sorted((root/'conformance/HexGroebner').glob('*.lean'))if not p.stem.startswith('Emit')and p.stem!='EliminationChecks']
run('build',['lake','build','HexGroebner','HexGroebnerTheory',*modules,'hexgroebner_compute','hexgroebner_compute_full','hexgroebner_emit_f4','hexgroebner_emit_division','hexgroebner_emit_fixtures','hexgroebner_bench'])
run('oracles',['bash','scripts/ci/run_oracles.sh'],dict(os.environ,HEX_LIBRARY_FILTER='HexGroebner',PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:/home/kim/tmp/issue-10987/oracles/bin:'+os.environ['PATH']))
run('driver',['python3','scripts/ci/check_groebner_driver.py'])
run('bench',['bash','scripts/ci/check_bench_verify_budget.sh','HexGroebner=hexgroebner_bench'],dict(os.environ,HEX_LIBRARY_FILTER='HexGroebner'))
for name,script in [('dag','scripts/check_dag.py'),('phase4','scripts/check_phase4.py'),('manifest','scripts/release/check_released_manifest.py'),('headers','scripts/check_copyright_headers.py'),('lines','scripts/check_file_line_counts.py')]:run(name,['/home/kim/tmp/issue-10987/oracles/bin/python',script])
