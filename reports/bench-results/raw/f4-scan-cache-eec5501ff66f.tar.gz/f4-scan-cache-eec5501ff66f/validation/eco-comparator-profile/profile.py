from pathlib import Path
import hashlib,importlib.util,json,os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'equivalence-final-production';out=state/'eco-comparator-profile';out.mkdir(exist_ok=False)
helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('frozen_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[]
record=next(x for x in json.loads((state/'gamba-binaries.json').read_text())if x['isa']=='avx512');environment=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
try:
 for label,case in [('hex','eco11-15'),('gamba','eco11-15'),('hex','eco11-31')]:
  name=label+'-'+case
  if label=='hex':program=[str(base/'binaries/compute'),'--scheduling','degree','--work','100000000000',str(state/('final-products-production/medium-inputs/'+case+'.json'))]
  else:program=[record['loader'],'--library-path',record['library_path'],record['binary'],'-d','grevlex','-s','10987','-t','1','-v','2','-i',str(state/('final-products-production/medium-inputs/'+case+'.ms')),'-o',str(out/(name+'.basis'))]
  command=['perf','record','-e','cycles:u','-F','1999','--call-graph','dwarf,16384','-o',str(out/(name+'.data')),'--',*program]
  with(out/(name+'.stdout')).open('wb')as stdout,(out/(name+'.stderr')).open('wb')as stderr:p=subprocess.run(command,stdout=stdout,stderr=stderr,env=environment)
  runs.append(dict(label=label,case=case,command=command,exit_code=p.returncode));assert p.returncode==0
  for options,suffix in [(['--no-children','--percent-limit','0.5'],'report'),(['--header-only'],'header')]:
   with(out/(name+'.'+suffix)).open('w')as f:subprocess.run(['perf','report','--stdio',*options,'-i',str(out/(name+'.data'))],stdout=f,stderr=subprocess.STDOUT,check=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads='Hex serial algorithm with runtime auxiliary threads; GamBa -t1. Single CPU affinity inherited.',host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),runs=runs,hex_manifest=json.loads((base/'manifest.json').read_text()),vendor=record,helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),scope='Diagnostic user-cycle profiles to explain the approximately8-10x Eco11 process gap on already measured inputs. Startup, input and full output are present in profiles. These are cost attribution, not matched timing samples or acceptance evidence. Raw profiles, outputs, failures and load context retained.'),indent=2)+'\n');lease.close()
(out/'profile.py').write_bytes(Path(__file__).read_bytes())
