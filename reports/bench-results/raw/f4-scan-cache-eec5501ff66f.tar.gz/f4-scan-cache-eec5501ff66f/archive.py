from pathlib import Path
import gzip,hashlib,io,json,subprocess,sys,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');label=sys.argv[1];assert label in ['scan-cache','driver-output'];base=state/(label+'-production');m=json.loads((base/'manifest.json').read_text());name='f4-'+label+'-'+m['source_fingerprint'];payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
for p in sorted(base.rglob('*')):
 rel=p.relative_to(base)
 if rel.parts[0]=='binaries'or rel.parts[:2]==('bench-binaries','source')or rel.parts==('bench-binaries','frame'):continue
 if p.is_file():add('measurement/'+str(rel),p.read_bytes())
for p in sorted(state.glob(label+'*')):
 if p.is_file()and p.suffix in ['.py','.json','.log']:add('reproduction/'+p.name,p.read_bytes())
for relative in ['issue-10987-lean-cc','issue-10987-lean-cc-flags.json','full-checks.py','analyze-equivalence-candidates.py']:
 add('reproduction/'+relative,(state/relative).read_bytes())
if label=='scan-cache':
 for directory in ['scan-cache-clang','scan-cache-gcc','eco-comparator-profile']:
  for p in sorted((state/directory).rglob('*')):
   if p.is_file()and'.lake'not in p.relative_to(state/directory).parts:add('validation/'+directory+'/'+str(p.relative_to(state/directory)),p.read_bytes())
base_commit='921d4d7a2466c12995f2f87faf78eae7dbd593b4';add('source.patch',subprocess.check_output(['git','diff','--binary',base_commit,m['source_snapshot'],'--','.',':!reports'],cwd=root));add('source-base.txt',(base_commit+'\n').encode());add('archive.py',Path(__file__).read_bytes());add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest()for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/(name+'-audit.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
