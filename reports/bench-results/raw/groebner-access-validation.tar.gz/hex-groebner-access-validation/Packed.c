// Lean compiler output
// Module: HexGroebner.Packed
// Imports: public import Init public meta import Init public import HexModArith.Field public import HexArith.Barrett.Context
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* l_System_Platform_numBits;
lean_object* lean_nat_pow(lean_object*, lean_object*);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_uint64_dec_le(uint64_t, uint64_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
extern lean_object* l_ByteArray_empty;
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_usize_add(size_t, size_t);
uint64_t lean_uint64_of_nat(lean_object*);
uint8_t lean_uint64_to_uint8(uint64_t);
lean_object* lean_byte_array_push(lean_object*, uint8_t);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
lean_object* lean_byte_array_size(lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_byte_array_uget(lean_object*, size_t);
lean_object* lean_usize_to_nat(size_t);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_byte_array_data(lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_Repr_addAppParen(lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* l_Array_range(lean_object*);
uint64_t lp_Hex_BarrettCtx_mk___redArg(uint64_t);
uint64_t lean_byte_array_hash(lean_object*);
uint64_t lean_uint64_mix_hash(uint64_t, uint64_t);
lean_object* lean_byte_array_set(lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u8_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u8_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u8_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u8_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u16_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u16_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u16_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u16_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u32_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u32_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u32_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u32_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqWidth_beq(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqWidth_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqWidth___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqWidth_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqWidth___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqWidth___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqWidth = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqWidth___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprWidth_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 22, .m_capacity = 22, .m_length = 21, .m_data = "Hex.Groebner.Width.u8"};
static const lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprWidth_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__1_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprWidth_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "Hex.Groebner.Width.u16"};
static const lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprWidth_repr___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__3_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprWidth_repr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 23, .m_capacity = 23, .m_length = 22, .m_data = "Hex.Groebner.Width.u32"};
static const lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprWidth_repr___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__5_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr(uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprWidth___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprWidth_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprWidth___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprWidth___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprWidth = (const lean_object*)&lp_Hex_Hex_Groebner_instReprWidth___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instInhabitedWidth_default;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instInhabitedWidth;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_bytes(uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_bytes___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqPrimeField_decEq(uint64_t, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqPrimeField_decEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqPrimeField(uint64_t, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqPrimeField___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_PrimeField_ofZMod64___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_PrimeField_ofZMod64___redArg___boxed(lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_PrimeField_ofZMod64(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_PrimeField_ofZMod64___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_PrimeField_width(uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_PrimeField_width___boxed(lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_PrimeField_barrett(uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_PrimeField_barrett___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Packed_read___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Packed_read(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Packed_readFast(uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_readFast___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg(uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter___redArg(lean_object*, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter(lean_object*, lean_object*, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_push(uint8_t, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_push___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_set(uint8_t, lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_set___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Groebner_instInhabitedSparseRow_default___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instInhabitedSparseRow_default___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedSparseRow;
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_instHashableSparseRow_hash(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instHashableSparseRow_hash___boxed(lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instHashableSparseRow___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instHashableSparseRow_hash___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instHashableSparseRow___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instHashableSparseRow___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instHashableSparseRow = (const lean_object*)&lp_Hex_Hex_Groebner_instHashableSparseRow___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_size(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_size___boxed(lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___closed__0_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___closed__1 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0(uint8_t, lean_object*, uint64_t, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__0;
static lean_once_cell_t lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__1;
static lean_once_cell_t lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__2;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_ofEntries(uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_ofEntries___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0(uint64_t, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_entries(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_entries___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorIdx(uint8_t v_x_1_){
_start:
{
switch(v_x_1_)
{
case 0:
{
lean_object* v___x_2_; 
v___x_2_ = lean_unsigned_to_nat(0u);
return v___x_2_;
}
case 1:
{
lean_object* v___x_3_; 
v___x_3_ = lean_unsigned_to_nat(1u);
return v___x_3_;
}
default: 
{
lean_object* v___x_4_; 
v___x_4_ = lean_unsigned_to_nat(2u);
return v___x_4_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorIdx___boxed(lean_object* v_x_5_){
_start:
{
uint8_t v_x_boxed_6_; lean_object* v_res_7_; 
v_x_boxed_6_ = lean_unbox(v_x_5_);
v_res_7_ = lp_Hex_Hex_Groebner_Width_ctorIdx(v_x_boxed_6_);
return v_res_7_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorElim___redArg(lean_object* v_k_8_){
_start:
{
lean_inc(v_k_8_);
return v_k_8_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorElim___redArg___boxed(lean_object* v_k_9_){
_start:
{
lean_object* v_res_10_; 
v_res_10_ = lp_Hex_Hex_Groebner_Width_ctorElim___redArg(v_k_9_);
lean_dec(v_k_9_);
return v_res_10_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorElim(lean_object* v_motive_11_, lean_object* v_ctorIdx_12_, uint8_t v_t_13_, lean_object* v_h_14_, lean_object* v_k_15_){
_start:
{
lean_inc(v_k_15_);
return v_k_15_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_ctorElim___boxed(lean_object* v_motive_16_, lean_object* v_ctorIdx_17_, lean_object* v_t_18_, lean_object* v_h_19_, lean_object* v_k_20_){
_start:
{
uint8_t v_t_boxed_21_; lean_object* v_res_22_; 
v_t_boxed_21_ = lean_unbox(v_t_18_);
v_res_22_ = lp_Hex_Hex_Groebner_Width_ctorElim(v_motive_16_, v_ctorIdx_17_, v_t_boxed_21_, v_h_19_, v_k_20_);
lean_dec(v_k_20_);
lean_dec(v_ctorIdx_17_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u8_elim___redArg(lean_object* v_u8_23_){
_start:
{
lean_inc(v_u8_23_);
return v_u8_23_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u8_elim___redArg___boxed(lean_object* v_u8_24_){
_start:
{
lean_object* v_res_25_; 
v_res_25_ = lp_Hex_Hex_Groebner_Width_u8_elim___redArg(v_u8_24_);
lean_dec(v_u8_24_);
return v_res_25_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u8_elim(lean_object* v_motive_26_, uint8_t v_t_27_, lean_object* v_h_28_, lean_object* v_u8_29_){
_start:
{
lean_inc(v_u8_29_);
return v_u8_29_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u8_elim___boxed(lean_object* v_motive_30_, lean_object* v_t_31_, lean_object* v_h_32_, lean_object* v_u8_33_){
_start:
{
uint8_t v_t_boxed_34_; lean_object* v_res_35_; 
v_t_boxed_34_ = lean_unbox(v_t_31_);
v_res_35_ = lp_Hex_Hex_Groebner_Width_u8_elim(v_motive_30_, v_t_boxed_34_, v_h_32_, v_u8_33_);
lean_dec(v_u8_33_);
return v_res_35_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u16_elim___redArg(lean_object* v_u16_36_){
_start:
{
lean_inc(v_u16_36_);
return v_u16_36_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u16_elim___redArg___boxed(lean_object* v_u16_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_Hex_Hex_Groebner_Width_u16_elim___redArg(v_u16_37_);
lean_dec(v_u16_37_);
return v_res_38_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u16_elim(lean_object* v_motive_39_, uint8_t v_t_40_, lean_object* v_h_41_, lean_object* v_u16_42_){
_start:
{
lean_inc(v_u16_42_);
return v_u16_42_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u16_elim___boxed(lean_object* v_motive_43_, lean_object* v_t_44_, lean_object* v_h_45_, lean_object* v_u16_46_){
_start:
{
uint8_t v_t_boxed_47_; lean_object* v_res_48_; 
v_t_boxed_47_ = lean_unbox(v_t_44_);
v_res_48_ = lp_Hex_Hex_Groebner_Width_u16_elim(v_motive_43_, v_t_boxed_47_, v_h_45_, v_u16_46_);
lean_dec(v_u16_46_);
return v_res_48_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u32_elim___redArg(lean_object* v_u32_49_){
_start:
{
lean_inc(v_u32_49_);
return v_u32_49_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u32_elim___redArg___boxed(lean_object* v_u32_50_){
_start:
{
lean_object* v_res_51_; 
v_res_51_ = lp_Hex_Hex_Groebner_Width_u32_elim___redArg(v_u32_50_);
lean_dec(v_u32_50_);
return v_res_51_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u32_elim(lean_object* v_motive_52_, uint8_t v_t_53_, lean_object* v_h_54_, lean_object* v_u32_55_){
_start:
{
lean_inc(v_u32_55_);
return v_u32_55_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_u32_elim___boxed(lean_object* v_motive_56_, lean_object* v_t_57_, lean_object* v_h_58_, lean_object* v_u32_59_){
_start:
{
uint8_t v_t_boxed_60_; lean_object* v_res_61_; 
v_t_boxed_60_ = lean_unbox(v_t_57_);
v_res_61_ = lp_Hex_Hex_Groebner_Width_u32_elim(v_motive_56_, v_t_boxed_60_, v_h_58_, v_u32_59_);
lean_dec(v_u32_59_);
return v_res_61_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqWidth_beq(uint8_t v_x_62_, uint8_t v_y_63_){
_start:
{
lean_object* v___x_64_; lean_object* v___x_65_; uint8_t v___x_66_; 
v___x_64_ = lp_Hex_Hex_Groebner_Width_ctorIdx(v_x_62_);
v___x_65_ = lp_Hex_Hex_Groebner_Width_ctorIdx(v_y_63_);
v___x_66_ = lean_nat_dec_eq(v___x_64_, v___x_65_);
lean_dec(v___x_65_);
lean_dec(v___x_64_);
return v___x_66_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqWidth_beq___boxed(lean_object* v_x_67_, lean_object* v_y_68_){
_start:
{
uint8_t v_x_21__boxed_69_; uint8_t v_y_22__boxed_70_; uint8_t v_res_71_; lean_object* v_r_72_; 
v_x_21__boxed_69_ = lean_unbox(v_x_67_);
v_y_22__boxed_70_ = lean_unbox(v_y_68_);
v_res_71_ = lp_Hex_Hex_Groebner_instBEqWidth_beq(v_x_21__boxed_69_, v_y_22__boxed_70_);
v_r_72_ = lean_box(v_res_71_);
return v_r_72_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6(void){
_start:
{
lean_object* v___x_84_; lean_object* v___x_85_; 
v___x_84_ = lean_unsigned_to_nat(2u);
v___x_85_ = lean_nat_to_int(v___x_84_);
return v___x_85_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7(void){
_start:
{
lean_object* v___x_86_; lean_object* v___x_87_; 
v___x_86_ = lean_unsigned_to_nat(1u);
v___x_87_ = lean_nat_to_int(v___x_86_);
return v___x_87_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr(uint8_t v_x_88_, lean_object* v_prec_89_){
_start:
{
lean_object* v___y_91_; lean_object* v___y_98_; lean_object* v___y_105_; 
switch(v_x_88_)
{
case 0:
{
lean_object* v___x_111_; uint8_t v___x_112_; 
v___x_111_ = lean_unsigned_to_nat(1024u);
v___x_112_ = lean_nat_dec_le(v___x_111_, v_prec_89_);
if (v___x_112_ == 0)
{
lean_object* v___x_113_; 
v___x_113_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6, &lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6);
v___y_91_ = v___x_113_;
goto v___jp_90_;
}
else
{
lean_object* v___x_114_; 
v___x_114_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7, &lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7);
v___y_91_ = v___x_114_;
goto v___jp_90_;
}
}
case 1:
{
lean_object* v___x_115_; uint8_t v___x_116_; 
v___x_115_ = lean_unsigned_to_nat(1024u);
v___x_116_ = lean_nat_dec_le(v___x_115_, v_prec_89_);
if (v___x_116_ == 0)
{
lean_object* v___x_117_; 
v___x_117_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6, &lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6);
v___y_98_ = v___x_117_;
goto v___jp_97_;
}
else
{
lean_object* v___x_118_; 
v___x_118_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7, &lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7);
v___y_98_ = v___x_118_;
goto v___jp_97_;
}
}
default: 
{
lean_object* v___x_119_; uint8_t v___x_120_; 
v___x_119_ = lean_unsigned_to_nat(1024u);
v___x_120_ = lean_nat_dec_le(v___x_119_, v_prec_89_);
if (v___x_120_ == 0)
{
lean_object* v___x_121_; 
v___x_121_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6, &lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprWidth_repr___closed__6);
v___y_105_ = v___x_121_;
goto v___jp_104_;
}
else
{
lean_object* v___x_122_; 
v___x_122_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7, &lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprWidth_repr___closed__7);
v___y_105_ = v___x_122_;
goto v___jp_104_;
}
}
}
v___jp_90_:
{
lean_object* v___x_92_; lean_object* v___x_93_; uint8_t v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; 
v___x_92_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprWidth_repr___closed__1));
lean_inc(v___y_91_);
v___x_93_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_93_, 0, v___y_91_);
lean_ctor_set(v___x_93_, 1, v___x_92_);
v___x_94_ = 0;
v___x_95_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_95_, 0, v___x_93_);
lean_ctor_set_uint8(v___x_95_, sizeof(void*)*1, v___x_94_);
v___x_96_ = l_Repr_addAppParen(v___x_95_, v_prec_89_);
return v___x_96_;
}
v___jp_97_:
{
lean_object* v___x_99_; lean_object* v___x_100_; uint8_t v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; 
v___x_99_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprWidth_repr___closed__3));
lean_inc(v___y_98_);
v___x_100_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_100_, 0, v___y_98_);
lean_ctor_set(v___x_100_, 1, v___x_99_);
v___x_101_ = 0;
v___x_102_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_102_, 0, v___x_100_);
lean_ctor_set_uint8(v___x_102_, sizeof(void*)*1, v___x_101_);
v___x_103_ = l_Repr_addAppParen(v___x_102_, v_prec_89_);
return v___x_103_;
}
v___jp_104_:
{
lean_object* v___x_106_; lean_object* v___x_107_; uint8_t v___x_108_; lean_object* v___x_109_; lean_object* v___x_110_; 
v___x_106_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprWidth_repr___closed__5));
lean_inc(v___y_105_);
v___x_107_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_107_, 0, v___y_105_);
lean_ctor_set(v___x_107_, 1, v___x_106_);
v___x_108_ = 0;
v___x_109_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_109_, 0, v___x_107_);
lean_ctor_set_uint8(v___x_109_, sizeof(void*)*1, v___x_108_);
v___x_110_ = l_Repr_addAppParen(v___x_109_, v_prec_89_);
return v___x_110_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprWidth_repr___boxed(lean_object* v_x_123_, lean_object* v_prec_124_){
_start:
{
uint8_t v_x_171__boxed_125_; lean_object* v_res_126_; 
v_x_171__boxed_125_ = lean_unbox(v_x_123_);
v_res_126_ = lp_Hex_Hex_Groebner_instReprWidth_repr(v_x_171__boxed_125_, v_prec_124_);
lean_dec(v_prec_124_);
return v_res_126_;
}
}
static uint8_t _init_lp_Hex_Hex_Groebner_instInhabitedWidth_default(void){
_start:
{
uint8_t v___x_129_; 
v___x_129_ = 0;
return v___x_129_;
}
}
static uint8_t _init_lp_Hex_Hex_Groebner_instInhabitedWidth(void){
_start:
{
uint8_t v___x_130_; 
v___x_130_ = 0;
return v___x_130_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_bytes(uint8_t v_x_131_){
_start:
{
switch(v_x_131_)
{
case 0:
{
lean_object* v___x_132_; 
v___x_132_ = lean_unsigned_to_nat(1u);
return v___x_132_;
}
case 1:
{
lean_object* v___x_133_; 
v___x_133_ = lean_unsigned_to_nat(2u);
return v___x_133_;
}
default: 
{
lean_object* v___x_134_; 
v___x_134_ = lean_unsigned_to_nat(4u);
return v___x_134_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Width_bytes___boxed(lean_object* v_x_135_){
_start:
{
uint8_t v_x_34__boxed_136_; lean_object* v_res_137_; 
v_x_34__boxed_136_ = lean_unbox(v_x_135_);
v_res_137_ = lp_Hex_Hex_Groebner_Width_bytes(v_x_34__boxed_136_);
return v_res_137_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqPrimeField_decEq(uint64_t v_x_138_, uint64_t v_x_139_){
_start:
{
uint8_t v___x_140_; 
v___x_140_ = lean_uint64_dec_eq(v_x_138_, v_x_139_);
return v___x_140_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqPrimeField_decEq___boxed(lean_object* v_x_141_, lean_object* v_x_142_){
_start:
{
uint64_t v_x_44__boxed_143_; uint64_t v_x_45__boxed_144_; uint8_t v_res_145_; lean_object* v_r_146_; 
v_x_44__boxed_143_ = lean_unbox_uint64(v_x_141_);
lean_dec_ref(v_x_141_);
v_x_45__boxed_144_ = lean_unbox_uint64(v_x_142_);
lean_dec_ref(v_x_142_);
v_res_145_ = lp_Hex_Hex_Groebner_instDecidableEqPrimeField_decEq(v_x_44__boxed_143_, v_x_45__boxed_144_);
v_r_146_ = lean_box(v_res_145_);
return v_r_146_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqPrimeField(uint64_t v_x_147_, uint64_t v_x_148_){
_start:
{
uint8_t v___x_149_; 
v___x_149_ = lean_uint64_dec_eq(v_x_147_, v_x_148_);
return v___x_149_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqPrimeField___boxed(lean_object* v_x_150_, lean_object* v_x_151_){
_start:
{
uint64_t v_x_6__boxed_152_; uint64_t v_x_7__boxed_153_; uint8_t v_res_154_; lean_object* v_r_155_; 
v_x_6__boxed_152_ = lean_unbox_uint64(v_x_150_);
lean_dec_ref(v_x_150_);
v_x_7__boxed_153_ = lean_unbox_uint64(v_x_151_);
lean_dec_ref(v_x_151_);
v_res_154_ = lp_Hex_Hex_Groebner_instDecidableEqPrimeField(v_x_6__boxed_152_, v_x_7__boxed_153_);
v_r_155_ = lean_box(v_res_154_);
return v_r_155_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_PrimeField_ofZMod64___redArg(lean_object* v_p_156_){
_start:
{
uint64_t v___x_157_; 
v___x_157_ = lean_uint64_of_nat(v_p_156_);
return v___x_157_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_PrimeField_ofZMod64___redArg___boxed(lean_object* v_p_158_){
_start:
{
uint64_t v_res_159_; lean_object* v_r_160_; 
v_res_159_ = lp_Hex_Hex_Groebner_PrimeField_ofZMod64___redArg(v_p_158_);
lean_dec(v_p_158_);
v_r_160_ = lean_box_uint64(v_res_159_);
return v_r_160_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_PrimeField_ofZMod64(lean_object* v_p_161_, lean_object* v_inst_162_, lean_object* v_inst_163_){
_start:
{
uint64_t v___x_164_; 
v___x_164_ = lean_uint64_of_nat(v_p_161_);
return v___x_164_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_PrimeField_ofZMod64___boxed(lean_object* v_p_165_, lean_object* v_inst_166_, lean_object* v_inst_167_){
_start:
{
uint64_t v_res_168_; lean_object* v_r_169_; 
v_res_168_ = lp_Hex_Hex_Groebner_PrimeField_ofZMod64(v_p_165_, v_inst_166_, v_inst_167_);
lean_dec(v_p_165_);
v_r_169_ = lean_box_uint64(v_res_168_);
return v_r_169_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_PrimeField_width(uint64_t v_field_170_){
_start:
{
uint64_t v___x_171_; uint8_t v___x_172_; 
v___x_171_ = 256ULL;
v___x_172_ = lean_uint64_dec_le(v_field_170_, v___x_171_);
if (v___x_172_ == 0)
{
uint64_t v___x_173_; uint8_t v___x_174_; 
v___x_173_ = 65536ULL;
v___x_174_ = lean_uint64_dec_le(v_field_170_, v___x_173_);
if (v___x_174_ == 0)
{
uint8_t v___x_175_; 
v___x_175_ = 2;
return v___x_175_;
}
else
{
uint8_t v___x_176_; 
v___x_176_ = 1;
return v___x_176_;
}
}
else
{
uint8_t v___x_177_; 
v___x_177_ = 0;
return v___x_177_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_PrimeField_width___boxed(lean_object* v_field_178_){
_start:
{
uint64_t v_field_boxed_179_; uint8_t v_res_180_; lean_object* v_r_181_; 
v_field_boxed_179_ = lean_unbox_uint64(v_field_178_);
lean_dec_ref(v_field_178_);
v_res_180_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_boxed_179_);
v_r_181_ = lean_box(v_res_180_);
return v_r_181_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_PrimeField_barrett(uint64_t v_field_182_){
_start:
{
uint64_t v___x_183_; 
v___x_183_ = lp_Hex_BarrettCtx_mk___redArg(v_field_182_);
return v___x_183_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_PrimeField_barrett___boxed(lean_object* v_field_184_){
_start:
{
uint64_t v_field_boxed_185_; uint64_t v_res_186_; lean_object* v_r_187_; 
v_field_boxed_185_ = lean_unbox_uint64(v_field_184_);
lean_dec_ref(v_field_184_);
v_res_186_ = lp_Hex_Hex_Groebner_PrimeField_barrett(v_field_boxed_185_);
v_r_187_ = lean_box_uint64(v_res_186_);
return v_r_187_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Packed_read___lam__0(lean_object* v_xs_188_, lean_object* v_i_189_){
_start:
{
lean_object* v___x_190_; uint8_t v___x_191_; 
v___x_190_ = lean_byte_array_size(v_xs_188_);
v___x_191_ = lean_nat_dec_lt(v_i_189_, v___x_190_);
return v___x_191_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read___lam__0___boxed(lean_object* v_xs_192_, lean_object* v_i_193_){
_start:
{
uint8_t v_res_194_; lean_object* v_r_195_; 
v_res_194_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_xs_192_, v_i_193_);
lean_dec(v_i_193_);
lean_dec_ref(v_xs_192_);
v_r_195_ = lean_box(v_res_194_);
return v_r_195_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Packed_read(uint8_t v_width_196_, lean_object* v_data_197_, lean_object* v_index_198_){
_start:
{
uint64_t v___y_200_; uint8_t v___y_201_; uint64_t v___y_207_; uint8_t v___y_208_; uint8_t v___x_213_; uint64_t v___y_215_; lean_object* v___y_216_; uint8_t v___y_217_; uint64_t v___y_230_; lean_object* v___y_231_; uint8_t v___y_232_; lean_object* v___y_245_; uint8_t v___y_246_; lean_object* v___y_263_; 
v___x_213_ = 0;
switch(v_width_196_)
{
case 0:
{
lean_object* v___x_270_; 
v___x_270_ = lean_unsigned_to_nat(1u);
v___y_263_ = v___x_270_;
goto v___jp_262_;
}
case 1:
{
lean_object* v___x_271_; 
v___x_271_ = lean_unsigned_to_nat(2u);
v___y_263_ = v___x_271_;
goto v___jp_262_;
}
default: 
{
lean_object* v___x_272_; 
v___x_272_ = lean_unsigned_to_nat(4u);
v___y_263_ = v___x_272_;
goto v___jp_262_;
}
}
v___jp_199_:
{
uint64_t v___x_202_; uint64_t v___x_203_; uint64_t v___x_204_; uint64_t v___x_205_; 
v___x_202_ = lean_uint8_to_uint64(v___y_201_);
v___x_203_ = 24ULL;
v___x_204_ = lean_uint64_shift_left(v___x_202_, v___x_203_);
v___x_205_ = lean_uint64_lor(v___y_200_, v___x_204_);
return v___x_205_;
}
v___jp_206_:
{
uint64_t v___x_209_; uint64_t v___x_210_; uint64_t v___x_211_; uint64_t v___x_212_; 
v___x_209_ = lean_uint8_to_uint64(v___y_208_);
v___x_210_ = 8ULL;
v___x_211_ = lean_uint64_shift_left(v___x_209_, v___x_210_);
v___x_212_ = lean_uint64_lor(v___y_207_, v___x_211_);
return v___x_212_;
}
v___jp_214_:
{
uint64_t v___x_218_; uint64_t v___x_219_; uint64_t v___x_220_; uint64_t v___x_221_; lean_object* v___x_222_; lean_object* v___x_223_; uint8_t v___x_224_; 
v___x_218_ = lean_uint8_to_uint64(v___y_217_);
v___x_219_ = 16ULL;
v___x_220_ = lean_uint64_shift_left(v___x_218_, v___x_219_);
v___x_221_ = lean_uint64_lor(v___y_215_, v___x_220_);
v___x_222_ = lean_unsigned_to_nat(3u);
v___x_223_ = lean_nat_add(v___y_216_, v___x_222_);
lean_dec(v___y_216_);
v___x_224_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_197_, v___x_223_);
if (v___x_224_ == 0)
{
lean_object* v___x_225_; lean_object* v___x_226_; uint8_t v___x_227_; 
lean_dec(v___x_223_);
v___x_225_ = lean_box(v___x_213_);
v___x_226_ = l_outOfBounds___redArg(v___x_225_);
lean_dec(v___x_225_);
v___x_227_ = lean_unbox(v___x_226_);
lean_dec(v___x_226_);
v___y_200_ = v___x_221_;
v___y_201_ = v___x_227_;
goto v___jp_199_;
}
else
{
uint8_t v___x_228_; 
v___x_228_ = lean_byte_array_fget(v_data_197_, v___x_223_);
lean_dec(v___x_223_);
v___y_200_ = v___x_221_;
v___y_201_ = v___x_228_;
goto v___jp_199_;
}
}
v___jp_229_:
{
uint64_t v___x_233_; uint64_t v___x_234_; uint64_t v___x_235_; uint64_t v___x_236_; lean_object* v___x_237_; lean_object* v___x_238_; uint8_t v___x_239_; 
v___x_233_ = lean_uint8_to_uint64(v___y_232_);
v___x_234_ = 8ULL;
v___x_235_ = lean_uint64_shift_left(v___x_233_, v___x_234_);
v___x_236_ = lean_uint64_lor(v___y_230_, v___x_235_);
v___x_237_ = lean_unsigned_to_nat(2u);
v___x_238_ = lean_nat_add(v___y_231_, v___x_237_);
v___x_239_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_197_, v___x_238_);
if (v___x_239_ == 0)
{
lean_object* v___x_240_; lean_object* v___x_241_; uint8_t v___x_242_; 
lean_dec(v___x_238_);
v___x_240_ = lean_box(v___x_213_);
v___x_241_ = l_outOfBounds___redArg(v___x_240_);
lean_dec(v___x_240_);
v___x_242_ = lean_unbox(v___x_241_);
lean_dec(v___x_241_);
v___y_215_ = v___x_236_;
v___y_216_ = v___y_231_;
v___y_217_ = v___x_242_;
goto v___jp_214_;
}
else
{
uint8_t v___x_243_; 
v___x_243_ = lean_byte_array_fget(v_data_197_, v___x_238_);
lean_dec(v___x_238_);
v___y_215_ = v___x_236_;
v___y_216_ = v___y_231_;
v___y_217_ = v___x_243_;
goto v___jp_214_;
}
}
v___jp_244_:
{
uint64_t v_a_247_; 
v_a_247_ = lean_uint8_to_uint64(v___y_246_);
switch(v_width_196_)
{
case 0:
{
lean_dec(v___y_245_);
return v_a_247_;
}
case 1:
{
lean_object* v___x_248_; lean_object* v___x_249_; uint8_t v___x_250_; 
v___x_248_ = lean_unsigned_to_nat(1u);
v___x_249_ = lean_nat_add(v___y_245_, v___x_248_);
lean_dec(v___y_245_);
v___x_250_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_197_, v___x_249_);
if (v___x_250_ == 0)
{
lean_object* v___x_251_; lean_object* v___x_252_; uint8_t v___x_253_; 
lean_dec(v___x_249_);
v___x_251_ = lean_box(v___x_213_);
v___x_252_ = l_outOfBounds___redArg(v___x_251_);
lean_dec(v___x_251_);
v___x_253_ = lean_unbox(v___x_252_);
lean_dec(v___x_252_);
v___y_207_ = v_a_247_;
v___y_208_ = v___x_253_;
goto v___jp_206_;
}
else
{
uint8_t v___x_254_; 
v___x_254_ = lean_byte_array_fget(v_data_197_, v___x_249_);
lean_dec(v___x_249_);
v___y_207_ = v_a_247_;
v___y_208_ = v___x_254_;
goto v___jp_206_;
}
}
default: 
{
lean_object* v___x_255_; lean_object* v___x_256_; uint8_t v___x_257_; 
v___x_255_ = lean_unsigned_to_nat(1u);
v___x_256_ = lean_nat_add(v___y_245_, v___x_255_);
v___x_257_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_197_, v___x_256_);
if (v___x_257_ == 0)
{
lean_object* v___x_258_; lean_object* v___x_259_; uint8_t v___x_260_; 
lean_dec(v___x_256_);
v___x_258_ = lean_box(v___x_213_);
v___x_259_ = l_outOfBounds___redArg(v___x_258_);
lean_dec(v___x_258_);
v___x_260_ = lean_unbox(v___x_259_);
lean_dec(v___x_259_);
v___y_230_ = v_a_247_;
v___y_231_ = v___y_245_;
v___y_232_ = v___x_260_;
goto v___jp_229_;
}
else
{
uint8_t v___x_261_; 
v___x_261_ = lean_byte_array_fget(v_data_197_, v___x_256_);
lean_dec(v___x_256_);
v___y_230_ = v_a_247_;
v___y_231_ = v___y_245_;
v___y_232_ = v___x_261_;
goto v___jp_229_;
}
}
}
}
v___jp_262_:
{
lean_object* v_offset_264_; uint8_t v___x_265_; 
v_offset_264_ = lean_nat_mul(v_index_198_, v___y_263_);
v___x_265_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_197_, v_offset_264_);
if (v___x_265_ == 0)
{
lean_object* v___x_266_; lean_object* v___x_267_; uint8_t v___x_268_; 
v___x_266_ = lean_box(v___x_213_);
v___x_267_ = l_outOfBounds___redArg(v___x_266_);
lean_dec(v___x_266_);
v___x_268_ = lean_unbox(v___x_267_);
lean_dec(v___x_267_);
v___y_245_ = v_offset_264_;
v___y_246_ = v___x_268_;
goto v___jp_244_;
}
else
{
uint8_t v___x_269_; 
v___x_269_ = lean_byte_array_fget(v_data_197_, v_offset_264_);
v___y_245_ = v_offset_264_;
v___y_246_ = v___x_269_;
goto v___jp_244_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read___boxed(lean_object* v_width_273_, lean_object* v_data_274_, lean_object* v_index_275_){
_start:
{
uint8_t v_width_boxed_276_; uint64_t v_res_277_; lean_object* v_r_278_; 
v_width_boxed_276_ = lean_unbox(v_width_273_);
v_res_277_ = lp_Hex_Hex_Groebner_Packed_read(v_width_boxed_276_, v_data_274_, v_index_275_);
lean_dec(v_index_275_);
lean_dec_ref(v_data_274_);
v_r_278_ = lean_box_uint64(v_res_277_);
return v_r_278_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Packed_readFast(uint8_t v_width_279_, lean_object* v_data_280_, lean_object* v_index_281_){
_start:
{
uint64_t v___y_283_; uint8_t v___y_284_; uint64_t v___y_290_; uint8_t v___y_291_; uint8_t v___x_296_; lean_object* v___y_298_; uint64_t v___y_299_; uint8_t v___y_300_; lean_object* v___y_313_; uint64_t v___y_314_; uint8_t v___y_315_; lean_object* v___y_328_; uint8_t v___y_329_; lean_object* v___y_346_; uint8_t v___y_347_; lean_object* v___y_385_; 
v___x_296_ = 0;
switch(v_width_279_)
{
case 0:
{
lean_object* v___x_393_; 
v___x_393_ = lean_unsigned_to_nat(1u);
v___y_385_ = v___x_393_;
goto v___jp_384_;
}
case 1:
{
lean_object* v___x_394_; 
v___x_394_ = lean_unsigned_to_nat(2u);
v___y_385_ = v___x_394_;
goto v___jp_384_;
}
default: 
{
lean_object* v___x_395_; 
v___x_395_ = lean_unsigned_to_nat(4u);
v___y_385_ = v___x_395_;
goto v___jp_384_;
}
}
v___jp_282_:
{
uint64_t v___x_285_; uint64_t v___x_286_; uint64_t v___x_287_; uint64_t v___x_288_; 
v___x_285_ = lean_uint8_to_uint64(v___y_284_);
v___x_286_ = 24ULL;
v___x_287_ = lean_uint64_shift_left(v___x_285_, v___x_286_);
v___x_288_ = lean_uint64_lor(v___y_283_, v___x_287_);
return v___x_288_;
}
v___jp_289_:
{
uint64_t v___x_292_; uint64_t v___x_293_; uint64_t v___x_294_; uint64_t v___x_295_; 
v___x_292_ = lean_uint8_to_uint64(v___y_291_);
v___x_293_ = 8ULL;
v___x_294_ = lean_uint64_shift_left(v___x_292_, v___x_293_);
v___x_295_ = lean_uint64_lor(v___y_290_, v___x_294_);
return v___x_295_;
}
v___jp_297_:
{
uint64_t v___x_301_; uint64_t v___x_302_; uint64_t v___x_303_; uint64_t v___x_304_; lean_object* v___x_305_; lean_object* v___x_306_; uint8_t v___x_307_; 
v___x_301_ = lean_uint8_to_uint64(v___y_300_);
v___x_302_ = 16ULL;
v___x_303_ = lean_uint64_shift_left(v___x_301_, v___x_302_);
v___x_304_ = lean_uint64_lor(v___y_299_, v___x_303_);
v___x_305_ = lean_unsigned_to_nat(3u);
v___x_306_ = lean_nat_add(v___y_298_, v___x_305_);
lean_dec(v___y_298_);
v___x_307_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_280_, v___x_306_);
if (v___x_307_ == 0)
{
lean_object* v___x_308_; lean_object* v___x_309_; uint8_t v___x_310_; 
lean_dec(v___x_306_);
v___x_308_ = lean_box(v___x_296_);
v___x_309_ = l_outOfBounds___redArg(v___x_308_);
lean_dec(v___x_308_);
v___x_310_ = lean_unbox(v___x_309_);
lean_dec(v___x_309_);
v___y_283_ = v___x_304_;
v___y_284_ = v___x_310_;
goto v___jp_282_;
}
else
{
uint8_t v___x_311_; 
v___x_311_ = lean_byte_array_fget(v_data_280_, v___x_306_);
lean_dec(v___x_306_);
v___y_283_ = v___x_304_;
v___y_284_ = v___x_311_;
goto v___jp_282_;
}
}
v___jp_312_:
{
uint64_t v___x_316_; uint64_t v___x_317_; uint64_t v___x_318_; uint64_t v___x_319_; lean_object* v___x_320_; lean_object* v___x_321_; uint8_t v___x_322_; 
v___x_316_ = lean_uint8_to_uint64(v___y_315_);
v___x_317_ = 8ULL;
v___x_318_ = lean_uint64_shift_left(v___x_316_, v___x_317_);
v___x_319_ = lean_uint64_lor(v___y_314_, v___x_318_);
v___x_320_ = lean_unsigned_to_nat(2u);
v___x_321_ = lean_nat_add(v___y_313_, v___x_320_);
v___x_322_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_280_, v___x_321_);
if (v___x_322_ == 0)
{
lean_object* v___x_323_; lean_object* v___x_324_; uint8_t v___x_325_; 
lean_dec(v___x_321_);
v___x_323_ = lean_box(v___x_296_);
v___x_324_ = l_outOfBounds___redArg(v___x_323_);
lean_dec(v___x_323_);
v___x_325_ = lean_unbox(v___x_324_);
lean_dec(v___x_324_);
v___y_298_ = v___y_313_;
v___y_299_ = v___x_319_;
v___y_300_ = v___x_325_;
goto v___jp_297_;
}
else
{
uint8_t v___x_326_; 
v___x_326_ = lean_byte_array_fget(v_data_280_, v___x_321_);
lean_dec(v___x_321_);
v___y_298_ = v___y_313_;
v___y_299_ = v___x_319_;
v___y_300_ = v___x_326_;
goto v___jp_297_;
}
}
v___jp_327_:
{
uint64_t v_a_330_; 
v_a_330_ = lean_uint8_to_uint64(v___y_329_);
switch(v_width_279_)
{
case 0:
{
lean_dec(v___y_328_);
return v_a_330_;
}
case 1:
{
lean_object* v___x_331_; lean_object* v___x_332_; uint8_t v___x_333_; 
v___x_331_ = lean_unsigned_to_nat(1u);
v___x_332_ = lean_nat_add(v___y_328_, v___x_331_);
lean_dec(v___y_328_);
v___x_333_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_280_, v___x_332_);
if (v___x_333_ == 0)
{
lean_object* v___x_334_; lean_object* v___x_335_; uint8_t v___x_336_; 
lean_dec(v___x_332_);
v___x_334_ = lean_box(v___x_296_);
v___x_335_ = l_outOfBounds___redArg(v___x_334_);
lean_dec(v___x_334_);
v___x_336_ = lean_unbox(v___x_335_);
lean_dec(v___x_335_);
v___y_290_ = v_a_330_;
v___y_291_ = v___x_336_;
goto v___jp_289_;
}
else
{
uint8_t v___x_337_; 
v___x_337_ = lean_byte_array_fget(v_data_280_, v___x_332_);
lean_dec(v___x_332_);
v___y_290_ = v_a_330_;
v___y_291_ = v___x_337_;
goto v___jp_289_;
}
}
default: 
{
lean_object* v___x_338_; lean_object* v___x_339_; uint8_t v___x_340_; 
v___x_338_ = lean_unsigned_to_nat(1u);
v___x_339_ = lean_nat_add(v___y_328_, v___x_338_);
v___x_340_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_280_, v___x_339_);
if (v___x_340_ == 0)
{
lean_object* v___x_341_; lean_object* v___x_342_; uint8_t v___x_343_; 
lean_dec(v___x_339_);
v___x_341_ = lean_box(v___x_296_);
v___x_342_ = l_outOfBounds___redArg(v___x_341_);
lean_dec(v___x_341_);
v___x_343_ = lean_unbox(v___x_342_);
lean_dec(v___x_342_);
v___y_313_ = v___y_328_;
v___y_314_ = v_a_330_;
v___y_315_ = v___x_343_;
goto v___jp_312_;
}
else
{
uint8_t v___x_344_; 
v___x_344_ = lean_byte_array_fget(v_data_280_, v___x_339_);
lean_dec(v___x_339_);
v___y_313_ = v___y_328_;
v___y_314_ = v_a_330_;
v___y_315_ = v___x_344_;
goto v___jp_312_;
}
}
}
}
v___jp_345_:
{
if (v___y_347_ == 0)
{
uint8_t v___x_348_; 
v___x_348_ = lp_Hex_Hex_Groebner_Packed_read___lam__0(v_data_280_, v___y_346_);
if (v___x_348_ == 0)
{
lean_object* v___x_349_; lean_object* v___x_350_; uint8_t v___x_351_; 
v___x_349_ = lean_box(v___x_296_);
v___x_350_ = l_outOfBounds___redArg(v___x_349_);
lean_dec(v___x_349_);
v___x_351_ = lean_unbox(v___x_350_);
lean_dec(v___x_350_);
v___y_328_ = v___y_346_;
v___y_329_ = v___x_351_;
goto v___jp_327_;
}
else
{
uint8_t v___x_352_; 
v___x_352_ = lean_byte_array_fget(v_data_280_, v___y_346_);
v___y_328_ = v___y_346_;
v___y_329_ = v___x_352_;
goto v___jp_327_;
}
}
else
{
size_t v_pos_353_; uint8_t v___x_354_; uint64_t v_a_355_; 
v_pos_353_ = lean_usize_of_nat(v___y_346_);
lean_dec(v___y_346_);
v___x_354_ = lean_byte_array_uget(v_data_280_, v_pos_353_);
v_a_355_ = lean_uint8_to_uint64(v___x_354_);
switch(v_width_279_)
{
case 0:
{
return v_a_355_;
}
case 1:
{
size_t v___x_356_; size_t v___x_357_; uint8_t v___x_358_; uint64_t v___x_359_; uint64_t v___x_360_; uint64_t v___x_361_; uint64_t v___x_362_; 
v___x_356_ = ((size_t)1ULL);
v___x_357_ = lean_usize_add(v_pos_353_, v___x_356_);
v___x_358_ = lean_byte_array_uget(v_data_280_, v___x_357_);
v___x_359_ = lean_uint8_to_uint64(v___x_358_);
v___x_360_ = 8ULL;
v___x_361_ = lean_uint64_shift_left(v___x_359_, v___x_360_);
v___x_362_ = lean_uint64_lor(v_a_355_, v___x_361_);
return v___x_362_;
}
default: 
{
size_t v___x_363_; size_t v___x_364_; uint8_t v___x_365_; uint64_t v___x_366_; uint64_t v___x_367_; uint64_t v___x_368_; uint64_t v___x_369_; size_t v___x_370_; size_t v___x_371_; uint8_t v___x_372_; uint64_t v___x_373_; uint64_t v___x_374_; uint64_t v___x_375_; uint64_t v___x_376_; size_t v___x_377_; size_t v___x_378_; uint8_t v___x_379_; uint64_t v___x_380_; uint64_t v___x_381_; uint64_t v___x_382_; uint64_t v___x_383_; 
v___x_363_ = ((size_t)1ULL);
v___x_364_ = lean_usize_add(v_pos_353_, v___x_363_);
v___x_365_ = lean_byte_array_uget(v_data_280_, v___x_364_);
v___x_366_ = lean_uint8_to_uint64(v___x_365_);
v___x_367_ = 8ULL;
v___x_368_ = lean_uint64_shift_left(v___x_366_, v___x_367_);
v___x_369_ = lean_uint64_lor(v_a_355_, v___x_368_);
v___x_370_ = ((size_t)2ULL);
v___x_371_ = lean_usize_add(v_pos_353_, v___x_370_);
v___x_372_ = lean_byte_array_uget(v_data_280_, v___x_371_);
v___x_373_ = lean_uint8_to_uint64(v___x_372_);
v___x_374_ = 16ULL;
v___x_375_ = lean_uint64_shift_left(v___x_373_, v___x_374_);
v___x_376_ = lean_uint64_lor(v___x_369_, v___x_375_);
v___x_377_ = ((size_t)3ULL);
v___x_378_ = lean_usize_add(v_pos_353_, v___x_377_);
v___x_379_ = lean_byte_array_uget(v_data_280_, v___x_378_);
v___x_380_ = lean_uint8_to_uint64(v___x_379_);
v___x_381_ = 24ULL;
v___x_382_ = lean_uint64_shift_left(v___x_380_, v___x_381_);
v___x_383_ = lean_uint64_lor(v___x_376_, v___x_382_);
return v___x_383_;
}
}
}
}
v___jp_384_:
{
lean_object* v_offset_386_; lean_object* v___x_387_; lean_object* v___x_388_; uint8_t v___x_389_; 
v_offset_386_ = lean_nat_mul(v_index_281_, v___y_385_);
v___x_387_ = lean_nat_add(v_offset_386_, v___y_385_);
v___x_388_ = lean_byte_array_size(v_data_280_);
v___x_389_ = lean_nat_dec_le(v___x_387_, v___x_388_);
if (v___x_389_ == 0)
{
lean_dec(v___x_387_);
v___y_346_ = v_offset_386_;
v___y_347_ = v___x_389_;
goto v___jp_345_;
}
else
{
size_t v___x_390_; lean_object* v___x_391_; uint8_t v___x_392_; 
v___x_390_ = lean_usize_of_nat(v___x_387_);
v___x_391_ = lean_usize_to_nat(v___x_390_);
v___x_392_ = lean_nat_dec_eq(v___x_391_, v___x_387_);
lean_dec(v___x_387_);
lean_dec(v___x_391_);
v___y_346_ = v_offset_386_;
v___y_347_ = v___x_392_;
goto v___jp_345_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_readFast___boxed(lean_object* v_width_396_, lean_object* v_data_397_, lean_object* v_index_398_){
_start:
{
uint8_t v_width_boxed_399_; uint64_t v_res_400_; lean_object* v_r_401_; 
v_width_boxed_399_ = lean_unbox(v_width_396_);
v_res_400_ = lp_Hex_Hex_Groebner_Packed_readFast(v_width_boxed_399_, v_data_397_, v_index_398_);
lean_dec(v_index_398_);
lean_dec_ref(v_data_397_);
v_r_401_ = lean_box_uint64(v_res_400_);
return v_r_401_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg(uint8_t v_x_402_, lean_object* v_h__1_403_, lean_object* v_h__2_404_, lean_object* v_h__3_405_){
_start:
{
switch(v_x_402_)
{
case 0:
{
lean_object* v___x_406_; lean_object* v___x_407_; 
lean_dec(v_h__3_405_);
lean_dec(v_h__2_404_);
v___x_406_ = lean_box(0);
v___x_407_ = lean_apply_1(v_h__1_403_, v___x_406_);
return v___x_407_;
}
case 1:
{
lean_object* v___x_408_; lean_object* v___x_409_; 
lean_dec(v_h__3_405_);
lean_dec(v_h__1_403_);
v___x_408_ = lean_box(0);
v___x_409_ = lean_apply_1(v_h__2_404_, v___x_408_);
return v___x_409_;
}
default: 
{
lean_object* v___x_410_; lean_object* v___x_411_; 
lean_dec(v_h__2_404_);
lean_dec(v_h__1_403_);
v___x_410_ = lean_box(0);
v___x_411_ = lean_apply_1(v_h__3_405_, v___x_410_);
return v___x_411_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg___boxed(lean_object* v_x_412_, lean_object* v_h__1_413_, lean_object* v_h__2_414_, lean_object* v_h__3_415_){
_start:
{
uint8_t v_x_33__boxed_416_; lean_object* v_res_417_; 
v_x_33__boxed_416_ = lean_unbox(v_x_412_);
v_res_417_ = lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg(v_x_33__boxed_416_, v_h__1_413_, v_h__2_414_, v_h__3_415_);
return v_res_417_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter(lean_object* v_motive_418_, uint8_t v_x_419_, lean_object* v_h__1_420_, lean_object* v_h__2_421_, lean_object* v_h__3_422_){
_start:
{
switch(v_x_419_)
{
case 0:
{
lean_object* v___x_423_; lean_object* v___x_424_; 
lean_dec(v_h__3_422_);
lean_dec(v_h__2_421_);
v___x_423_ = lean_box(0);
v___x_424_ = lean_apply_1(v_h__1_420_, v___x_423_);
return v___x_424_;
}
case 1:
{
lean_object* v___x_425_; lean_object* v___x_426_; 
lean_dec(v_h__3_422_);
lean_dec(v_h__1_420_);
v___x_425_ = lean_box(0);
v___x_426_ = lean_apply_1(v_h__2_421_, v___x_425_);
return v___x_426_;
}
default: 
{
lean_object* v___x_427_; lean_object* v___x_428_; 
lean_dec(v_h__2_421_);
lean_dec(v_h__1_420_);
v___x_427_ = lean_box(0);
v___x_428_ = lean_apply_1(v_h__3_422_, v___x_427_);
return v___x_428_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter___boxed(lean_object* v_motive_429_, lean_object* v_x_430_, lean_object* v_h__1_431_, lean_object* v_h__2_432_, lean_object* v_h__3_433_){
_start:
{
uint8_t v_x_48__boxed_434_; lean_object* v_res_435_; 
v_x_48__boxed_434_ = lean_unbox(v_x_430_);
v_res_435_ = lp_Hex___private_HexGroebner_Packed_0__Hex_Groebner_Width_bytes_match__1_splitter(v_motive_429_, v_x_48__boxed_434_, v_h__1_431_, v_h__2_432_, v_h__3_433_);
return v_res_435_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter___redArg(lean_object* v_x_436_, size_t v_x_437_, lean_object* v_h__1_438_){
_start:
{
lean_object* v_data_439_; lean_object* v___x_440_; lean_object* v___x_441_; 
v_data_439_ = lean_byte_array_data(v_x_436_);
v___x_440_ = lean_box_usize(v_x_437_);
v___x_441_ = lean_apply_3(v_h__1_438_, v_data_439_, v___x_440_, lean_box(0));
return v___x_441_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter___redArg___boxed(lean_object* v_x_442_, lean_object* v_x_443_, lean_object* v_h__1_444_){
_start:
{
size_t v_x_19__boxed_445_; lean_object* v_res_446_; 
v_x_19__boxed_445_ = lean_unbox_usize(v_x_443_);
lean_dec(v_x_443_);
v_res_446_ = lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter___redArg(v_x_442_, v_x_19__boxed_445_, v_h__1_444_);
return v_res_446_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter(lean_object* v_motive_447_, lean_object* v_x_448_, size_t v_x_449_, lean_object* v_x_450_, lean_object* v_h__1_451_){
_start:
{
lean_object* v_data_452_; lean_object* v___x_453_; lean_object* v___x_454_; 
v_data_452_ = lean_byte_array_data(v_x_448_);
v___x_453_ = lean_box_usize(v_x_449_);
v___x_454_ = lean_apply_3(v_h__1_451_, v_data_452_, v___x_453_, lean_box(0));
return v___x_454_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter___boxed(lean_object* v_motive_455_, lean_object* v_x_456_, lean_object* v_x_457_, lean_object* v_x_458_, lean_object* v_h__1_459_){
_start:
{
size_t v_x_31__boxed_460_; lean_object* v_res_461_; 
v_x_31__boxed_460_ = lean_unbox_usize(v_x_457_);
lean_dec(v_x_457_);
v_res_461_ = lp_Hex___private_HexGroebner_Packed_0__ByteArray_uget_match__1_splitter(v_motive_455_, v_x_456_, v_x_31__boxed_460_, v_x_458_, v_h__1_459_);
return v_res_461_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_push(uint8_t v_width_462_, lean_object* v_data_463_, uint64_t v_value_464_){
_start:
{
uint8_t v___x_465_; lean_object* v_data_466_; 
v___x_465_ = lean_uint64_to_uint8(v_value_464_);
v_data_466_ = lean_byte_array_push(v_data_463_, v___x_465_);
switch(v_width_462_)
{
case 0:
{
return v_data_466_;
}
case 1:
{
uint64_t v___x_467_; uint64_t v___x_468_; uint8_t v___x_469_; lean_object* v___x_470_; 
v___x_467_ = 8ULL;
v___x_468_ = lean_uint64_shift_right(v_value_464_, v___x_467_);
v___x_469_ = lean_uint64_to_uint8(v___x_468_);
v___x_470_ = lean_byte_array_push(v_data_466_, v___x_469_);
return v___x_470_;
}
default: 
{
uint64_t v___x_471_; uint64_t v___x_472_; uint8_t v___x_473_; lean_object* v___x_474_; uint64_t v___x_475_; uint64_t v___x_476_; uint8_t v___x_477_; lean_object* v___x_478_; uint64_t v___x_479_; uint64_t v___x_480_; uint8_t v___x_481_; lean_object* v___x_482_; 
v___x_471_ = 8ULL;
v___x_472_ = lean_uint64_shift_right(v_value_464_, v___x_471_);
v___x_473_ = lean_uint64_to_uint8(v___x_472_);
v___x_474_ = lean_byte_array_push(v_data_466_, v___x_473_);
v___x_475_ = 16ULL;
v___x_476_ = lean_uint64_shift_right(v_value_464_, v___x_475_);
v___x_477_ = lean_uint64_to_uint8(v___x_476_);
v___x_478_ = lean_byte_array_push(v___x_474_, v___x_477_);
v___x_479_ = 24ULL;
v___x_480_ = lean_uint64_shift_right(v_value_464_, v___x_479_);
v___x_481_ = lean_uint64_to_uint8(v___x_480_);
v___x_482_ = lean_byte_array_push(v___x_478_, v___x_481_);
return v___x_482_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_push___boxed(lean_object* v_width_483_, lean_object* v_data_484_, lean_object* v_value_485_){
_start:
{
uint8_t v_width_boxed_486_; uint64_t v_value_boxed_487_; lean_object* v_res_488_; 
v_width_boxed_486_ = lean_unbox(v_width_483_);
v_value_boxed_487_ = lean_unbox_uint64(v_value_485_);
lean_dec_ref(v_value_485_);
v_res_488_ = lp_Hex_Hex_Groebner_Packed_push(v_width_boxed_486_, v_data_484_, v_value_boxed_487_);
return v_res_488_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_set(uint8_t v_width_489_, lean_object* v_data_490_, lean_object* v_index_491_, uint64_t v_value_492_){
_start:
{
lean_object* v___y_494_; 
switch(v_width_489_)
{
case 0:
{
lean_object* v___x_522_; 
v___x_522_ = lean_unsigned_to_nat(1u);
v___y_494_ = v___x_522_;
goto v___jp_493_;
}
case 1:
{
lean_object* v___x_523_; 
v___x_523_ = lean_unsigned_to_nat(2u);
v___y_494_ = v___x_523_;
goto v___jp_493_;
}
default: 
{
lean_object* v___x_524_; 
v___x_524_ = lean_unsigned_to_nat(4u);
v___y_494_ = v___x_524_;
goto v___jp_493_;
}
}
v___jp_493_:
{
lean_object* v_offset_495_; uint8_t v___x_496_; lean_object* v_data_497_; 
v_offset_495_ = lean_nat_mul(v_index_491_, v___y_494_);
v___x_496_ = lean_uint64_to_uint8(v_value_492_);
v_data_497_ = lean_byte_array_set(v_data_490_, v_offset_495_, v___x_496_);
switch(v_width_489_)
{
case 0:
{
lean_dec(v_offset_495_);
return v_data_497_;
}
case 1:
{
lean_object* v___x_498_; lean_object* v___x_499_; uint64_t v___x_500_; uint64_t v___x_501_; uint8_t v___x_502_; lean_object* v___x_503_; 
v___x_498_ = lean_unsigned_to_nat(1u);
v___x_499_ = lean_nat_add(v_offset_495_, v___x_498_);
lean_dec(v_offset_495_);
v___x_500_ = 8ULL;
v___x_501_ = lean_uint64_shift_right(v_value_492_, v___x_500_);
v___x_502_ = lean_uint64_to_uint8(v___x_501_);
v___x_503_ = lean_byte_array_set(v_data_497_, v___x_499_, v___x_502_);
lean_dec(v___x_499_);
return v___x_503_;
}
default: 
{
lean_object* v___x_504_; lean_object* v___x_505_; uint64_t v___x_506_; uint64_t v___x_507_; uint8_t v___x_508_; lean_object* v___x_509_; lean_object* v___x_510_; lean_object* v___x_511_; uint64_t v___x_512_; uint64_t v___x_513_; uint8_t v___x_514_; lean_object* v___x_515_; lean_object* v___x_516_; lean_object* v___x_517_; uint64_t v___x_518_; uint64_t v___x_519_; uint8_t v___x_520_; lean_object* v___x_521_; 
v___x_504_ = lean_unsigned_to_nat(1u);
v___x_505_ = lean_nat_add(v_offset_495_, v___x_504_);
v___x_506_ = 8ULL;
v___x_507_ = lean_uint64_shift_right(v_value_492_, v___x_506_);
v___x_508_ = lean_uint64_to_uint8(v___x_507_);
v___x_509_ = lean_byte_array_set(v_data_497_, v___x_505_, v___x_508_);
lean_dec(v___x_505_);
v___x_510_ = lean_unsigned_to_nat(2u);
v___x_511_ = lean_nat_add(v_offset_495_, v___x_510_);
v___x_512_ = 16ULL;
v___x_513_ = lean_uint64_shift_right(v_value_492_, v___x_512_);
v___x_514_ = lean_uint64_to_uint8(v___x_513_);
v___x_515_ = lean_byte_array_set(v___x_509_, v___x_511_, v___x_514_);
lean_dec(v___x_511_);
v___x_516_ = lean_unsigned_to_nat(3u);
v___x_517_ = lean_nat_add(v_offset_495_, v___x_516_);
lean_dec(v_offset_495_);
v___x_518_ = 24ULL;
v___x_519_ = lean_uint64_shift_right(v_value_492_, v___x_518_);
v___x_520_ = lean_uint64_to_uint8(v___x_519_);
v___x_521_ = lean_byte_array_set(v___x_515_, v___x_517_, v___x_520_);
lean_dec(v___x_517_);
return v___x_521_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_set___boxed(lean_object* v_width_525_, lean_object* v_data_526_, lean_object* v_index_527_, lean_object* v_value_528_){
_start:
{
uint8_t v_width_boxed_529_; uint64_t v_value_boxed_530_; lean_object* v_res_531_; 
v_width_boxed_529_ = lean_unbox(v_width_525_);
v_value_boxed_530_ = lean_unbox_uint64(v_value_528_);
lean_dec_ref(v_value_528_);
v_res_531_ = lp_Hex_Hex_Groebner_Packed_set(v_width_boxed_529_, v_data_526_, v_index_527_, v_value_boxed_530_);
lean_dec(v_index_527_);
return v_res_531_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedSparseRow_default___closed__0(void){
_start:
{
lean_object* v___x_532_; lean_object* v___x_533_; 
v___x_532_ = l_ByteArray_empty;
v___x_533_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_533_, 0, v___x_532_);
lean_ctor_set(v___x_533_, 1, v___x_532_);
return v___x_533_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedSparseRow_default(void){
_start:
{
lean_object* v___x_534_; 
v___x_534_ = lean_obj_once(&lp_Hex_Hex_Groebner_instInhabitedSparseRow_default___closed__0, &lp_Hex_Hex_Groebner_instInhabitedSparseRow_default___closed__0_once, _init_lp_Hex_Hex_Groebner_instInhabitedSparseRow_default___closed__0);
return v___x_534_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedSparseRow(void){
_start:
{
lean_object* v___x_535_; 
v___x_535_ = lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
return v___x_535_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_instHashableSparseRow_hash(lean_object* v_x_536_){
_start:
{
lean_object* v_columns_537_; lean_object* v_coefficients_538_; uint64_t v___x_539_; uint64_t v___x_540_; uint64_t v___x_541_; uint64_t v___x_542_; uint64_t v___x_543_; 
v_columns_537_ = lean_ctor_get(v_x_536_, 0);
v_coefficients_538_ = lean_ctor_get(v_x_536_, 1);
v___x_539_ = 0ULL;
v___x_540_ = lean_byte_array_hash(v_columns_537_);
v___x_541_ = lean_uint64_mix_hash(v___x_539_, v___x_540_);
v___x_542_ = lean_byte_array_hash(v_coefficients_538_);
v___x_543_ = lean_uint64_mix_hash(v___x_541_, v___x_542_);
return v___x_543_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instHashableSparseRow_hash___boxed(lean_object* v_x_544_){
_start:
{
uint64_t v_res_545_; lean_object* v_r_546_; 
v_res_545_ = lp_Hex_Hex_Groebner_instHashableSparseRow_hash(v_x_544_);
lean_dec_ref(v_x_544_);
v_r_546_ = lean_box_uint64(v_res_545_);
return v_r_546_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_size(lean_object* v_row_549_){
_start:
{
lean_object* v_columns_550_; lean_object* v___x_551_; lean_object* v___x_552_; lean_object* v___x_553_; 
v_columns_550_ = lean_ctor_get(v_row_549_, 0);
v___x_551_ = lean_byte_array_size(v_columns_550_);
v___x_552_ = lean_unsigned_to_nat(2u);
v___x_553_ = lean_nat_shiftr(v___x_551_, v___x_552_);
return v___x_553_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_size___boxed(lean_object* v_row_554_){
_start:
{
lean_object* v_res_555_; 
v_res_555_ = lp_Hex_Hex_Groebner_SparseRow_size(v_row_554_);
lean_dec_ref(v_row_554_);
return v_res_555_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0(uint8_t v___x_560_, lean_object* v_columnCount_561_, uint64_t v_field_562_, lean_object* v_as_563_, size_t v_sz_564_, size_t v_i_565_, lean_object* v_b_566_){
_start:
{
uint8_t v___x_567_; 
v___x_567_ = lean_usize_dec_lt(v_i_565_, v_sz_564_);
if (v___x_567_ == 0)
{
return v_b_566_;
}
else
{
lean_object* v_a_568_; lean_object* v_snd_569_; lean_object* v___x_571_; uint8_t v_isShared_572_; uint8_t v_isSharedCheck_654_; 
v_a_568_ = lean_array_uget(v_as_563_, v_i_565_);
v_snd_569_ = lean_ctor_get(v_b_566_, 1);
v_isSharedCheck_654_ = !lean_is_exclusive(v_b_566_);
if (v_isSharedCheck_654_ == 0)
{
lean_object* v_unused_655_; 
v_unused_655_ = lean_ctor_get(v_b_566_, 0);
lean_dec(v_unused_655_);
v___x_571_ = v_b_566_;
v_isShared_572_ = v_isSharedCheck_654_;
goto v_resetjp_570_;
}
else
{
lean_inc(v_snd_569_);
lean_dec(v_b_566_);
v___x_571_ = lean_box(0);
v_isShared_572_ = v_isSharedCheck_654_;
goto v_resetjp_570_;
}
v_resetjp_570_:
{
lean_object* v_fst_573_; lean_object* v_snd_574_; lean_object* v___x_576_; uint8_t v_isShared_577_; uint8_t v_isSharedCheck_653_; 
v_fst_573_ = lean_ctor_get(v_a_568_, 0);
v_snd_574_ = lean_ctor_get(v_a_568_, 1);
v_isSharedCheck_653_ = !lean_is_exclusive(v_a_568_);
if (v_isSharedCheck_653_ == 0)
{
v___x_576_ = v_a_568_;
v_isShared_577_ = v_isSharedCheck_653_;
goto v_resetjp_575_;
}
else
{
lean_inc(v_snd_574_);
lean_inc(v_fst_573_);
lean_dec(v_a_568_);
v___x_576_ = lean_box(0);
v_isShared_577_ = v_isSharedCheck_653_;
goto v_resetjp_575_;
}
v_resetjp_575_:
{
lean_object* v_fst_578_; lean_object* v_snd_579_; lean_object* v___x_581_; uint8_t v_isShared_582_; uint8_t v_isSharedCheck_652_; 
v_fst_578_ = lean_ctor_get(v_snd_569_, 0);
v_snd_579_ = lean_ctor_get(v_snd_569_, 1);
v_isSharedCheck_652_ = !lean_is_exclusive(v_snd_569_);
if (v_isSharedCheck_652_ == 0)
{
v___x_581_ = v_snd_569_;
v_isShared_582_ = v_isSharedCheck_652_;
goto v_resetjp_580_;
}
else
{
lean_inc(v_snd_579_);
lean_inc(v_fst_578_);
lean_dec(v_snd_569_);
v___x_581_ = lean_box(0);
v_isShared_582_ = v_isSharedCheck_652_;
goto v_resetjp_580_;
}
v_resetjp_580_:
{
uint8_t v___x_591_; 
v___x_591_ = lean_nat_dec_le(v_columnCount_561_, v_fst_573_);
if (v___x_591_ == 0)
{
uint64_t v___x_592_; uint64_t v___x_593_; uint8_t v___x_594_; 
v___x_592_ = 0ULL;
v___x_593_ = lean_unbox_uint64(v_snd_574_);
v___x_594_ = lean_uint64_dec_eq(v___x_593_, v___x_592_);
if (v___x_594_ == 0)
{
uint64_t v___x_595_; uint8_t v___x_596_; 
v___x_595_ = lean_unbox_uint64(v_snd_574_);
v___x_596_ = lean_uint64_dec_le(v_field_562_, v___x_595_);
if (v___x_596_ == 0)
{
lean_object* v___x_597_; lean_object* v___y_599_; lean_object* v___y_600_; 
lean_del_object(v___x_581_);
lean_del_object(v___x_571_);
v___x_597_ = lean_box(0);
if (lean_obj_tag(v_snd_579_) == 1)
{
lean_object* v_val_647_; uint8_t v___x_648_; 
v_val_647_ = lean_ctor_get(v_snd_579_, 0);
v___x_648_ = lean_nat_dec_le(v_fst_573_, v_val_647_);
if (v___x_648_ == 0)
{
lean_dec_ref_known(v_snd_579_, 1);
goto v___jp_610_;
}
else
{
lean_object* v___x_649_; lean_object* v___x_650_; lean_object* v___x_651_; 
lean_del_object(v___x_576_);
lean_dec(v_snd_574_);
lean_dec(v_fst_573_);
v___x_649_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___closed__1));
v___x_650_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_650_, 0, v_fst_578_);
lean_ctor_set(v___x_650_, 1, v_snd_579_);
v___x_651_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_651_, 0, v___x_649_);
lean_ctor_set(v___x_651_, 1, v___x_650_);
return v___x_651_;
}
}
else
{
lean_dec(v_snd_579_);
goto v___jp_610_;
}
v___jp_598_:
{
lean_object* v___x_601_; lean_object* v___x_602_; lean_object* v___x_604_; 
v___x_601_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_601_, 0, v___y_599_);
lean_ctor_set(v___x_601_, 1, v___y_600_);
v___x_602_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_602_, 0, v_fst_573_);
if (v_isShared_577_ == 0)
{
lean_ctor_set(v___x_576_, 1, v___x_602_);
lean_ctor_set(v___x_576_, 0, v___x_601_);
v___x_604_ = v___x_576_;
goto v_reusejp_603_;
}
else
{
lean_object* v_reuseFailAlloc_609_; 
v_reuseFailAlloc_609_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_609_, 0, v___x_601_);
lean_ctor_set(v_reuseFailAlloc_609_, 1, v___x_602_);
v___x_604_ = v_reuseFailAlloc_609_;
goto v_reusejp_603_;
}
v_reusejp_603_:
{
lean_object* v___x_605_; size_t v___x_606_; size_t v___x_607_; 
v___x_605_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_605_, 0, v___x_597_);
lean_ctor_set(v___x_605_, 1, v___x_604_);
v___x_606_ = ((size_t)1ULL);
v___x_607_ = lean_usize_add(v_i_565_, v___x_606_);
v_i_565_ = v___x_607_;
v_b_566_ = v___x_605_;
goto _start;
}
}
v___jp_610_:
{
lean_object* v_columns_611_; lean_object* v_coefficients_612_; uint64_t v___x_613_; uint8_t v___x_614_; lean_object* v_data_615_; uint64_t v___x_616_; uint64_t v___x_617_; uint8_t v___x_618_; lean_object* v___x_619_; uint64_t v___x_620_; uint64_t v___x_621_; uint8_t v___x_622_; lean_object* v___x_623_; uint64_t v___x_624_; uint64_t v___x_625_; uint8_t v___x_626_; lean_object* v___x_627_; uint64_t v___x_628_; uint8_t v___x_629_; lean_object* v_data_630_; 
v_columns_611_ = lean_ctor_get(v_fst_578_, 0);
lean_inc_ref(v_columns_611_);
v_coefficients_612_ = lean_ctor_get(v_fst_578_, 1);
lean_inc_ref(v_coefficients_612_);
lean_dec(v_fst_578_);
v___x_613_ = lean_uint64_of_nat(v_fst_573_);
v___x_614_ = lean_uint64_to_uint8(v___x_613_);
v_data_615_ = lean_byte_array_push(v_columns_611_, v___x_614_);
v___x_616_ = 8ULL;
v___x_617_ = lean_uint64_shift_right(v___x_613_, v___x_616_);
v___x_618_ = lean_uint64_to_uint8(v___x_617_);
v___x_619_ = lean_byte_array_push(v_data_615_, v___x_618_);
v___x_620_ = 16ULL;
v___x_621_ = lean_uint64_shift_right(v___x_613_, v___x_620_);
v___x_622_ = lean_uint64_to_uint8(v___x_621_);
v___x_623_ = lean_byte_array_push(v___x_619_, v___x_622_);
v___x_624_ = 24ULL;
v___x_625_ = lean_uint64_shift_right(v___x_613_, v___x_624_);
v___x_626_ = lean_uint64_to_uint8(v___x_625_);
v___x_627_ = lean_byte_array_push(v___x_623_, v___x_626_);
v___x_628_ = lean_unbox_uint64(v_snd_574_);
v___x_629_ = lean_uint64_to_uint8(v___x_628_);
v_data_630_ = lean_byte_array_push(v_coefficients_612_, v___x_629_);
switch(v___x_560_)
{
case 0:
{
lean_dec(v_snd_574_);
v___y_599_ = v___x_627_;
v___y_600_ = v_data_630_;
goto v___jp_598_;
}
case 1:
{
uint64_t v___x_631_; uint64_t v___x_632_; uint8_t v___x_633_; lean_object* v___x_634_; 
v___x_631_ = lean_unbox_uint64(v_snd_574_);
lean_dec(v_snd_574_);
v___x_632_ = lean_uint64_shift_right(v___x_631_, v___x_616_);
v___x_633_ = lean_uint64_to_uint8(v___x_632_);
v___x_634_ = lean_byte_array_push(v_data_630_, v___x_633_);
v___y_599_ = v___x_627_;
v___y_600_ = v___x_634_;
goto v___jp_598_;
}
default: 
{
uint64_t v___x_635_; uint64_t v___x_636_; uint8_t v___x_637_; lean_object* v___x_638_; uint64_t v___x_639_; uint64_t v___x_640_; uint8_t v___x_641_; lean_object* v___x_642_; uint64_t v___x_643_; uint64_t v___x_644_; uint8_t v___x_645_; lean_object* v___x_646_; 
v___x_635_ = lean_unbox_uint64(v_snd_574_);
v___x_636_ = lean_uint64_shift_right(v___x_635_, v___x_616_);
v___x_637_ = lean_uint64_to_uint8(v___x_636_);
v___x_638_ = lean_byte_array_push(v_data_630_, v___x_637_);
v___x_639_ = lean_unbox_uint64(v_snd_574_);
v___x_640_ = lean_uint64_shift_right(v___x_639_, v___x_620_);
v___x_641_ = lean_uint64_to_uint8(v___x_640_);
v___x_642_ = lean_byte_array_push(v___x_638_, v___x_641_);
v___x_643_ = lean_unbox_uint64(v_snd_574_);
lean_dec(v_snd_574_);
v___x_644_ = lean_uint64_shift_right(v___x_643_, v___x_624_);
v___x_645_ = lean_uint64_to_uint8(v___x_644_);
v___x_646_ = lean_byte_array_push(v___x_642_, v___x_645_);
v___y_599_ = v___x_627_;
v___y_600_ = v___x_646_;
goto v___jp_598_;
}
}
}
}
else
{
lean_del_object(v___x_576_);
lean_dec(v_snd_574_);
lean_dec(v_fst_573_);
goto v___jp_583_;
}
}
else
{
lean_del_object(v___x_576_);
lean_dec(v_snd_574_);
lean_dec(v_fst_573_);
goto v___jp_583_;
}
}
else
{
lean_del_object(v___x_576_);
lean_dec(v_snd_574_);
lean_dec(v_fst_573_);
goto v___jp_583_;
}
v___jp_583_:
{
lean_object* v___x_584_; lean_object* v___x_586_; 
v___x_584_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___closed__0));
if (v_isShared_582_ == 0)
{
v___x_586_ = v___x_581_;
goto v_reusejp_585_;
}
else
{
lean_object* v_reuseFailAlloc_590_; 
v_reuseFailAlloc_590_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_590_, 0, v_fst_578_);
lean_ctor_set(v_reuseFailAlloc_590_, 1, v_snd_579_);
v___x_586_ = v_reuseFailAlloc_590_;
goto v_reusejp_585_;
}
v_reusejp_585_:
{
lean_object* v___x_588_; 
if (v_isShared_572_ == 0)
{
lean_ctor_set(v___x_571_, 1, v___x_586_);
lean_ctor_set(v___x_571_, 0, v___x_584_);
v___x_588_ = v___x_571_;
goto v_reusejp_587_;
}
else
{
lean_object* v_reuseFailAlloc_589_; 
v_reuseFailAlloc_589_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_589_, 0, v___x_584_);
lean_ctor_set(v_reuseFailAlloc_589_, 1, v___x_586_);
v___x_588_ = v_reuseFailAlloc_589_;
goto v_reusejp_587_;
}
v_reusejp_587_:
{
return v___x_588_;
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0___boxed(lean_object* v___x_656_, lean_object* v_columnCount_657_, lean_object* v_field_658_, lean_object* v_as_659_, lean_object* v_sz_660_, lean_object* v_i_661_, lean_object* v_b_662_){
_start:
{
uint8_t v___x_1221__boxed_663_; uint64_t v_field_boxed_664_; size_t v_sz_boxed_665_; size_t v_i_boxed_666_; lean_object* v_res_667_; 
v___x_1221__boxed_663_ = lean_unbox(v___x_656_);
v_field_boxed_664_ = lean_unbox_uint64(v_field_658_);
lean_dec_ref(v_field_658_);
v_sz_boxed_665_ = lean_unbox_usize(v_sz_660_);
lean_dec(v_sz_660_);
v_i_boxed_666_ = lean_unbox_usize(v_i_661_);
lean_dec(v_i_661_);
v_res_667_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0(v___x_1221__boxed_663_, v_columnCount_657_, v_field_boxed_664_, v_as_659_, v_sz_boxed_665_, v_i_boxed_666_, v_b_662_);
lean_dec_ref(v_as_659_);
lean_dec(v_columnCount_657_);
return v_res_667_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__0(void){
_start:
{
lean_object* v___x_668_; lean_object* v___x_669_; lean_object* v___x_670_; 
v___x_668_ = l_System_Platform_numBits;
v___x_669_ = lean_unsigned_to_nat(2u);
v___x_670_ = lean_nat_pow(v___x_669_, v___x_668_);
return v___x_670_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__1(void){
_start:
{
lean_object* v_previous_671_; lean_object* v_row_672_; lean_object* v___x_673_; 
v_previous_671_ = lean_box(0);
v_row_672_ = lean_obj_once(&lp_Hex_Hex_Groebner_instInhabitedSparseRow_default___closed__0, &lp_Hex_Hex_Groebner_instInhabitedSparseRow_default___closed__0_once, _init_lp_Hex_Hex_Groebner_instInhabitedSparseRow_default___closed__0);
v___x_673_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_673_, 0, v_row_672_);
lean_ctor_set(v___x_673_, 1, v_previous_671_);
return v___x_673_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__2(void){
_start:
{
lean_object* v___x_674_; lean_object* v_previous_675_; lean_object* v___x_676_; 
v___x_674_ = lean_obj_once(&lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__1, &lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__1_once, _init_lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__1);
v_previous_675_ = lean_box(0);
v___x_676_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_676_, 0, v_previous_675_);
lean_ctor_set(v___x_676_, 1, v___x_674_);
return v___x_676_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_ofEntries(uint64_t v_field_677_, lean_object* v_columnCount_678_, lean_object* v_entries_679_){
_start:
{
lean_object* v___x_680_; uint8_t v___x_681_; 
v___x_680_ = lean_unsigned_to_nat(4294967295u);
v___x_681_ = lean_nat_dec_lt(v___x_680_, v_columnCount_678_);
if (v___x_681_ == 0)
{
lean_object* v___x_682_; lean_object* v___x_683_; lean_object* v___x_684_; lean_object* v___x_685_; uint8_t v___x_686_; lean_object* v___y_688_; 
v___x_682_ = lean_unsigned_to_nat(2u);
v___x_683_ = lean_obj_once(&lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__0, &lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__0_once, _init_lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__0);
v___x_684_ = lean_array_get_size(v_entries_679_);
v___x_685_ = lean_unsigned_to_nat(4u);
v___x_686_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_677_);
switch(v___x_686_)
{
case 0:
{
lean_object* v___x_702_; 
v___x_702_ = lean_unsigned_to_nat(1u);
v___y_688_ = v___x_702_;
goto v___jp_687_;
}
case 1:
{
v___y_688_ = v___x_682_;
goto v___jp_687_;
}
default: 
{
v___y_688_ = v___x_685_;
goto v___jp_687_;
}
}
v___jp_687_:
{
lean_object* v___x_689_; lean_object* v___x_690_; uint8_t v___x_691_; 
v___x_689_ = lean_nat_add(v___x_685_, v___y_688_);
v___x_690_ = lean_nat_mul(v___x_684_, v___x_689_);
lean_dec(v___x_689_);
v___x_691_ = lean_nat_dec_le(v___x_683_, v___x_690_);
lean_dec(v___x_690_);
if (v___x_691_ == 0)
{
lean_object* v___x_692_; size_t v_sz_693_; size_t v___x_694_; lean_object* v___x_695_; lean_object* v_fst_696_; 
v___x_692_ = lean_obj_once(&lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__2, &lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__2_once, _init_lp_Hex_Hex_Groebner_SparseRow_ofEntries___closed__2);
v_sz_693_ = lean_array_size(v_entries_679_);
v___x_694_ = ((size_t)0ULL);
v___x_695_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_SparseRow_ofEntries_spec__0(v___x_686_, v_columnCount_678_, v_field_677_, v_entries_679_, v_sz_693_, v___x_694_, v___x_692_);
v_fst_696_ = lean_ctor_get(v___x_695_, 0);
lean_inc(v_fst_696_);
if (lean_obj_tag(v_fst_696_) == 0)
{
lean_object* v_snd_697_; lean_object* v_fst_698_; lean_object* v___x_699_; 
v_snd_697_ = lean_ctor_get(v___x_695_, 1);
lean_inc(v_snd_697_);
lean_dec_ref(v___x_695_);
v_fst_698_ = lean_ctor_get(v_snd_697_, 0);
lean_inc(v_fst_698_);
lean_dec(v_snd_697_);
v___x_699_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_699_, 0, v_fst_698_);
return v___x_699_;
}
else
{
lean_object* v_val_700_; 
lean_dec_ref(v___x_695_);
v_val_700_ = lean_ctor_get(v_fst_696_, 0);
lean_inc(v_val_700_);
lean_dec_ref_known(v_fst_696_, 1);
return v_val_700_;
}
}
else
{
lean_object* v___x_701_; 
v___x_701_ = lean_box(0);
return v___x_701_;
}
}
}
else
{
lean_object* v___x_703_; 
v___x_703_ = lean_box(0);
return v___x_703_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_ofEntries___boxed(lean_object* v_field_704_, lean_object* v_columnCount_705_, lean_object* v_entries_706_){
_start:
{
uint64_t v_field_boxed_707_; lean_object* v_res_708_; 
v_field_boxed_707_ = lean_unbox_uint64(v_field_704_);
lean_dec_ref(v_field_704_);
v_res_708_ = lp_Hex_Hex_Groebner_SparseRow_ofEntries(v_field_boxed_707_, v_columnCount_705_, v_entries_706_);
lean_dec_ref(v_entries_706_);
lean_dec(v_columnCount_705_);
return v_res_708_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(lean_object* v_xs_709_, lean_object* v_i_710_){
_start:
{
lean_object* v___x_711_; uint8_t v___x_712_; 
v___x_711_ = lean_byte_array_size(v_xs_709_);
v___x_712_ = lean_nat_dec_lt(v_i_710_, v___x_711_);
return v___x_712_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0___boxed(lean_object* v_xs_713_, lean_object* v_i_714_){
_start:
{
uint8_t v_res_715_; lean_object* v_r_716_; 
v_res_715_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v_xs_713_, v_i_714_);
lean_dec(v_i_714_);
lean_dec_ref(v_xs_713_);
v_r_716_ = lean_box(v_res_715_);
return v_r_716_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0(uint64_t v_field_717_, lean_object* v_row_718_, size_t v_sz_719_, size_t v_i_720_, lean_object* v_bs_721_){
_start:
{
uint8_t v___x_722_; 
v___x_722_ = lean_usize_dec_lt(v_i_720_, v_sz_719_);
if (v___x_722_ == 0)
{
return v_bs_721_;
}
else
{
lean_object* v_columns_723_; lean_object* v_coefficients_724_; lean_object* v_v_725_; lean_object* v___x_726_; lean_object* v_bs_x27_727_; lean_object* v___y_729_; uint64_t v___y_735_; lean_object* v___y_736_; uint8_t v___y_737_; uint8_t v___y_745_; uint64_t v___y_746_; lean_object* v___y_747_; lean_object* v___y_748_; lean_object* v___y_749_; uint8_t v___y_750_; uint8_t v___y_763_; uint64_t v___y_764_; lean_object* v___y_765_; lean_object* v___y_766_; lean_object* v___y_767_; uint8_t v___y_768_; uint64_t v___y_781_; lean_object* v___y_782_; uint8_t v___y_783_; uint8_t v___y_791_; uint8_t v___y_792_; lean_object* v___y_793_; lean_object* v___y_794_; lean_object* v___y_795_; uint8_t v___y_796_; uint8_t v___y_815_; uint8_t v___y_816_; lean_object* v___y_817_; lean_object* v___y_818_; lean_object* v___y_819_; uint8_t v___y_820_; uint8_t v___y_864_; uint8_t v___y_865_; lean_object* v___y_866_; lean_object* v___y_867_; lean_object* v___y_868_; uint64_t v___y_877_; uint64_t v___y_885_; uint8_t v___y_886_; uint8_t v___x_891_; lean_object* v___x_892_; lean_object* v_offset_893_; uint64_t v___y_895_; uint8_t v___y_896_; uint64_t v___y_909_; uint8_t v___y_910_; uint8_t v___y_923_; uint8_t v___y_933_; lean_object* v___x_963_; lean_object* v___x_964_; uint8_t v___x_965_; 
v_columns_723_ = lean_ctor_get(v_row_718_, 0);
v_coefficients_724_ = lean_ctor_get(v_row_718_, 1);
v_v_725_ = lean_array_uget(v_bs_721_, v_i_720_);
v___x_726_ = lean_unsigned_to_nat(0u);
v_bs_x27_727_ = lean_array_uset(v_bs_721_, v_i_720_, v___x_726_);
v___x_891_ = 0;
v___x_892_ = lean_unsigned_to_nat(4u);
v_offset_893_ = lean_nat_mul(v_v_725_, v___x_892_);
v___x_963_ = lean_nat_add(v_offset_893_, v___x_892_);
v___x_964_ = lean_byte_array_size(v_columns_723_);
v___x_965_ = lean_nat_dec_le(v___x_963_, v___x_964_);
if (v___x_965_ == 0)
{
lean_dec(v___x_963_);
v___y_933_ = v___x_965_;
goto v___jp_932_;
}
else
{
size_t v___x_966_; lean_object* v___x_967_; uint8_t v___x_968_; 
v___x_966_ = lean_usize_of_nat(v___x_963_);
v___x_967_ = lean_usize_to_nat(v___x_966_);
v___x_968_ = lean_nat_dec_eq(v___x_967_, v___x_963_);
lean_dec(v___x_963_);
lean_dec(v___x_967_);
v___y_933_ = v___x_968_;
goto v___jp_932_;
}
v___jp_728_:
{
size_t v___x_730_; size_t v___x_731_; lean_object* v___x_732_; 
v___x_730_ = ((size_t)1ULL);
v___x_731_ = lean_usize_add(v_i_720_, v___x_730_);
v___x_732_ = lean_array_uset(v_bs_x27_727_, v_i_720_, v___y_729_);
v_i_720_ = v___x_731_;
v_bs_721_ = v___x_732_;
goto _start;
}
v___jp_734_:
{
uint64_t v___x_738_; uint64_t v___x_739_; uint64_t v___x_740_; uint64_t v___x_741_; lean_object* v___x_742_; lean_object* v___x_743_; 
v___x_738_ = lean_uint8_to_uint64(v___y_737_);
v___x_739_ = 24ULL;
v___x_740_ = lean_uint64_shift_left(v___x_738_, v___x_739_);
v___x_741_ = lean_uint64_lor(v___y_735_, v___x_740_);
v___x_742_ = lean_box_uint64(v___x_741_);
v___x_743_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_743_, 0, v___y_736_);
lean_ctor_set(v___x_743_, 1, v___x_742_);
v___y_729_ = v___x_743_;
goto v___jp_728_;
}
v___jp_744_:
{
uint64_t v___x_751_; uint64_t v___x_752_; uint64_t v___x_753_; uint64_t v___x_754_; lean_object* v___x_755_; lean_object* v___x_756_; uint8_t v___x_757_; 
v___x_751_ = lean_uint8_to_uint64(v___y_750_);
v___x_752_ = 16ULL;
v___x_753_ = lean_uint64_shift_left(v___x_751_, v___x_752_);
v___x_754_ = lean_uint64_lor(v___y_746_, v___x_753_);
v___x_755_ = lean_unsigned_to_nat(3u);
v___x_756_ = lean_nat_add(v___y_747_, v___x_755_);
lean_dec(v___y_747_);
v___x_757_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v___y_748_, v___x_756_);
if (v___x_757_ == 0)
{
lean_object* v___x_758_; lean_object* v___x_759_; uint8_t v___x_760_; 
lean_dec(v___x_756_);
v___x_758_ = lean_box(v___y_745_);
v___x_759_ = l_outOfBounds___redArg(v___x_758_);
lean_dec(v___x_758_);
v___x_760_ = lean_unbox(v___x_759_);
lean_dec(v___x_759_);
v___y_735_ = v___x_754_;
v___y_736_ = v___y_749_;
v___y_737_ = v___x_760_;
goto v___jp_734_;
}
else
{
uint8_t v___x_761_; 
v___x_761_ = lean_byte_array_fget(v___y_748_, v___x_756_);
lean_dec(v___x_756_);
v___y_735_ = v___x_754_;
v___y_736_ = v___y_749_;
v___y_737_ = v___x_761_;
goto v___jp_734_;
}
}
v___jp_762_:
{
uint64_t v___x_769_; uint64_t v___x_770_; uint64_t v___x_771_; uint64_t v___x_772_; lean_object* v___x_773_; lean_object* v___x_774_; uint8_t v___x_775_; 
v___x_769_ = lean_uint8_to_uint64(v___y_768_);
v___x_770_ = 8ULL;
v___x_771_ = lean_uint64_shift_left(v___x_769_, v___x_770_);
v___x_772_ = lean_uint64_lor(v___y_764_, v___x_771_);
v___x_773_ = lean_unsigned_to_nat(2u);
v___x_774_ = lean_nat_add(v___y_765_, v___x_773_);
v___x_775_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v___y_766_, v___x_774_);
if (v___x_775_ == 0)
{
lean_object* v___x_776_; lean_object* v___x_777_; uint8_t v___x_778_; 
lean_dec(v___x_774_);
v___x_776_ = lean_box(v___y_763_);
v___x_777_ = l_outOfBounds___redArg(v___x_776_);
lean_dec(v___x_776_);
v___x_778_ = lean_unbox(v___x_777_);
lean_dec(v___x_777_);
v___y_745_ = v___y_763_;
v___y_746_ = v___x_772_;
v___y_747_ = v___y_765_;
v___y_748_ = v___y_766_;
v___y_749_ = v___y_767_;
v___y_750_ = v___x_778_;
goto v___jp_744_;
}
else
{
uint8_t v___x_779_; 
v___x_779_ = lean_byte_array_fget(v___y_766_, v___x_774_);
lean_dec(v___x_774_);
v___y_745_ = v___y_763_;
v___y_746_ = v___x_772_;
v___y_747_ = v___y_765_;
v___y_748_ = v___y_766_;
v___y_749_ = v___y_767_;
v___y_750_ = v___x_779_;
goto v___jp_744_;
}
}
v___jp_780_:
{
uint64_t v___x_784_; uint64_t v___x_785_; uint64_t v___x_786_; uint64_t v___x_787_; lean_object* v___x_788_; lean_object* v___x_789_; 
v___x_784_ = lean_uint8_to_uint64(v___y_783_);
v___x_785_ = 8ULL;
v___x_786_ = lean_uint64_shift_left(v___x_784_, v___x_785_);
v___x_787_ = lean_uint64_lor(v___y_781_, v___x_786_);
v___x_788_ = lean_box_uint64(v___x_787_);
v___x_789_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_789_, 0, v___y_782_);
lean_ctor_set(v___x_789_, 1, v___x_788_);
v___y_729_ = v___x_789_;
goto v___jp_728_;
}
v___jp_790_:
{
uint64_t v_a_797_; 
v_a_797_ = lean_uint8_to_uint64(v___y_796_);
switch(v___y_792_)
{
case 0:
{
lean_object* v___x_798_; lean_object* v___x_799_; 
lean_dec(v___y_793_);
v___x_798_ = lean_box_uint64(v_a_797_);
v___x_799_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_799_, 0, v___y_795_);
lean_ctor_set(v___x_799_, 1, v___x_798_);
v___y_729_ = v___x_799_;
goto v___jp_728_;
}
case 1:
{
lean_object* v___x_800_; lean_object* v___x_801_; uint8_t v___x_802_; 
v___x_800_ = lean_unsigned_to_nat(1u);
v___x_801_ = lean_nat_add(v___y_793_, v___x_800_);
lean_dec(v___y_793_);
v___x_802_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v___y_794_, v___x_801_);
if (v___x_802_ == 0)
{
lean_object* v___x_803_; lean_object* v___x_804_; uint8_t v___x_805_; 
lean_dec(v___x_801_);
v___x_803_ = lean_box(v___y_791_);
v___x_804_ = l_outOfBounds___redArg(v___x_803_);
lean_dec(v___x_803_);
v___x_805_ = lean_unbox(v___x_804_);
lean_dec(v___x_804_);
v___y_781_ = v_a_797_;
v___y_782_ = v___y_795_;
v___y_783_ = v___x_805_;
goto v___jp_780_;
}
else
{
uint8_t v___x_806_; 
v___x_806_ = lean_byte_array_fget(v___y_794_, v___x_801_);
lean_dec(v___x_801_);
v___y_781_ = v_a_797_;
v___y_782_ = v___y_795_;
v___y_783_ = v___x_806_;
goto v___jp_780_;
}
}
default: 
{
lean_object* v___x_807_; lean_object* v___x_808_; uint8_t v___x_809_; 
v___x_807_ = lean_unsigned_to_nat(1u);
v___x_808_ = lean_nat_add(v___y_793_, v___x_807_);
v___x_809_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v___y_794_, v___x_808_);
if (v___x_809_ == 0)
{
lean_object* v___x_810_; lean_object* v___x_811_; uint8_t v___x_812_; 
lean_dec(v___x_808_);
v___x_810_ = lean_box(v___y_791_);
v___x_811_ = l_outOfBounds___redArg(v___x_810_);
lean_dec(v___x_810_);
v___x_812_ = lean_unbox(v___x_811_);
lean_dec(v___x_811_);
v___y_763_ = v___y_791_;
v___y_764_ = v_a_797_;
v___y_765_ = v___y_793_;
v___y_766_ = v___y_794_;
v___y_767_ = v___y_795_;
v___y_768_ = v___x_812_;
goto v___jp_762_;
}
else
{
uint8_t v___x_813_; 
v___x_813_ = lean_byte_array_fget(v___y_794_, v___x_808_);
lean_dec(v___x_808_);
v___y_763_ = v___y_791_;
v___y_764_ = v_a_797_;
v___y_765_ = v___y_793_;
v___y_766_ = v___y_794_;
v___y_767_ = v___y_795_;
v___y_768_ = v___x_813_;
goto v___jp_762_;
}
}
}
}
v___jp_814_:
{
if (v___y_820_ == 0)
{
uint8_t v___x_821_; 
v___x_821_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v___y_818_, v___y_817_);
if (v___x_821_ == 0)
{
lean_object* v___x_822_; lean_object* v___x_823_; uint8_t v___x_824_; 
v___x_822_ = lean_box(v___y_815_);
v___x_823_ = l_outOfBounds___redArg(v___x_822_);
lean_dec(v___x_822_);
v___x_824_ = lean_unbox(v___x_823_);
lean_dec(v___x_823_);
v___y_791_ = v___y_815_;
v___y_792_ = v___y_816_;
v___y_793_ = v___y_817_;
v___y_794_ = v___y_818_;
v___y_795_ = v___y_819_;
v___y_796_ = v___x_824_;
goto v___jp_790_;
}
else
{
uint8_t v___x_825_; 
v___x_825_ = lean_byte_array_fget(v___y_818_, v___y_817_);
v___y_791_ = v___y_815_;
v___y_792_ = v___y_816_;
v___y_793_ = v___y_817_;
v___y_794_ = v___y_818_;
v___y_795_ = v___y_819_;
v___y_796_ = v___x_825_;
goto v___jp_790_;
}
}
else
{
size_t v_pos_826_; uint8_t v___x_827_; uint64_t v_a_828_; 
v_pos_826_ = lean_usize_of_nat(v___y_817_);
lean_dec(v___y_817_);
v___x_827_ = lean_byte_array_uget(v___y_818_, v_pos_826_);
v_a_828_ = lean_uint8_to_uint64(v___x_827_);
switch(v___y_816_)
{
case 0:
{
lean_object* v___x_829_; lean_object* v___x_830_; 
v___x_829_ = lean_box_uint64(v_a_828_);
v___x_830_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_830_, 0, v___y_819_);
lean_ctor_set(v___x_830_, 1, v___x_829_);
v___y_729_ = v___x_830_;
goto v___jp_728_;
}
case 1:
{
size_t v___x_831_; size_t v___x_832_; uint8_t v___x_833_; uint64_t v___x_834_; uint64_t v___x_835_; uint64_t v___x_836_; uint64_t v___x_837_; lean_object* v___x_838_; lean_object* v___x_839_; 
v___x_831_ = ((size_t)1ULL);
v___x_832_ = lean_usize_add(v_pos_826_, v___x_831_);
v___x_833_ = lean_byte_array_uget(v___y_818_, v___x_832_);
v___x_834_ = lean_uint8_to_uint64(v___x_833_);
v___x_835_ = 8ULL;
v___x_836_ = lean_uint64_shift_left(v___x_834_, v___x_835_);
v___x_837_ = lean_uint64_lor(v_a_828_, v___x_836_);
v___x_838_ = lean_box_uint64(v___x_837_);
v___x_839_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_839_, 0, v___y_819_);
lean_ctor_set(v___x_839_, 1, v___x_838_);
v___y_729_ = v___x_839_;
goto v___jp_728_;
}
default: 
{
size_t v___x_840_; size_t v___x_841_; uint8_t v___x_842_; uint64_t v___x_843_; uint64_t v___x_844_; uint64_t v___x_845_; uint64_t v___x_846_; size_t v___x_847_; size_t v___x_848_; uint8_t v___x_849_; uint64_t v___x_850_; uint64_t v___x_851_; uint64_t v___x_852_; uint64_t v___x_853_; size_t v___x_854_; size_t v___x_855_; uint8_t v___x_856_; uint64_t v___x_857_; uint64_t v___x_858_; uint64_t v___x_859_; uint64_t v___x_860_; lean_object* v___x_861_; lean_object* v___x_862_; 
v___x_840_ = ((size_t)1ULL);
v___x_841_ = lean_usize_add(v_pos_826_, v___x_840_);
v___x_842_ = lean_byte_array_uget(v___y_818_, v___x_841_);
v___x_843_ = lean_uint8_to_uint64(v___x_842_);
v___x_844_ = 8ULL;
v___x_845_ = lean_uint64_shift_left(v___x_843_, v___x_844_);
v___x_846_ = lean_uint64_lor(v_a_828_, v___x_845_);
v___x_847_ = ((size_t)2ULL);
v___x_848_ = lean_usize_add(v_pos_826_, v___x_847_);
v___x_849_ = lean_byte_array_uget(v___y_818_, v___x_848_);
v___x_850_ = lean_uint8_to_uint64(v___x_849_);
v___x_851_ = 16ULL;
v___x_852_ = lean_uint64_shift_left(v___x_850_, v___x_851_);
v___x_853_ = lean_uint64_lor(v___x_846_, v___x_852_);
v___x_854_ = ((size_t)3ULL);
v___x_855_ = lean_usize_add(v_pos_826_, v___x_854_);
v___x_856_ = lean_byte_array_uget(v___y_818_, v___x_855_);
v___x_857_ = lean_uint8_to_uint64(v___x_856_);
v___x_858_ = 24ULL;
v___x_859_ = lean_uint64_shift_left(v___x_857_, v___x_858_);
v___x_860_ = lean_uint64_lor(v___x_853_, v___x_859_);
v___x_861_ = lean_box_uint64(v___x_860_);
v___x_862_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_862_, 0, v___y_819_);
lean_ctor_set(v___x_862_, 1, v___x_861_);
v___y_729_ = v___x_862_;
goto v___jp_728_;
}
}
}
}
v___jp_863_:
{
lean_object* v_offset_869_; lean_object* v___x_870_; lean_object* v___x_871_; uint8_t v___x_872_; 
v_offset_869_ = lean_nat_mul(v_v_725_, v___y_868_);
lean_dec(v_v_725_);
v___x_870_ = lean_nat_add(v_offset_869_, v___y_868_);
v___x_871_ = lean_byte_array_size(v___y_866_);
v___x_872_ = lean_nat_dec_le(v___x_870_, v___x_871_);
if (v___x_872_ == 0)
{
lean_dec(v___x_870_);
v___y_815_ = v___y_864_;
v___y_816_ = v___y_865_;
v___y_817_ = v_offset_869_;
v___y_818_ = v___y_866_;
v___y_819_ = v___y_867_;
v___y_820_ = v___x_872_;
goto v___jp_814_;
}
else
{
size_t v___x_873_; lean_object* v___x_874_; uint8_t v___x_875_; 
v___x_873_ = lean_usize_of_nat(v___x_870_);
v___x_874_ = lean_usize_to_nat(v___x_873_);
v___x_875_ = lean_nat_dec_eq(v___x_874_, v___x_870_);
lean_dec(v___x_870_);
lean_dec(v___x_874_);
v___y_815_ = v___y_864_;
v___y_816_ = v___y_865_;
v___y_817_ = v_offset_869_;
v___y_818_ = v___y_866_;
v___y_819_ = v___y_867_;
v___y_820_ = v___x_875_;
goto v___jp_814_;
}
}
v___jp_876_:
{
lean_object* v___x_878_; uint8_t v___x_879_; uint8_t v___x_880_; 
v___x_878_ = lean_uint64_to_nat(v___y_877_);
v___x_879_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_717_);
v___x_880_ = 0;
switch(v___x_879_)
{
case 0:
{
lean_object* v___x_881_; 
v___x_881_ = lean_unsigned_to_nat(1u);
v___y_864_ = v___x_880_;
v___y_865_ = v___x_879_;
v___y_866_ = v_coefficients_724_;
v___y_867_ = v___x_878_;
v___y_868_ = v___x_881_;
goto v___jp_863_;
}
case 1:
{
lean_object* v___x_882_; 
v___x_882_ = lean_unsigned_to_nat(2u);
v___y_864_ = v___x_880_;
v___y_865_ = v___x_879_;
v___y_866_ = v_coefficients_724_;
v___y_867_ = v___x_878_;
v___y_868_ = v___x_882_;
goto v___jp_863_;
}
default: 
{
lean_object* v___x_883_; 
v___x_883_ = lean_unsigned_to_nat(4u);
v___y_864_ = v___x_880_;
v___y_865_ = v___x_879_;
v___y_866_ = v_coefficients_724_;
v___y_867_ = v___x_878_;
v___y_868_ = v___x_883_;
goto v___jp_863_;
}
}
}
v___jp_884_:
{
uint64_t v___x_887_; uint64_t v___x_888_; uint64_t v___x_889_; uint64_t v___x_890_; 
v___x_887_ = lean_uint8_to_uint64(v___y_886_);
v___x_888_ = 24ULL;
v___x_889_ = lean_uint64_shift_left(v___x_887_, v___x_888_);
v___x_890_ = lean_uint64_lor(v___y_885_, v___x_889_);
v___y_877_ = v___x_890_;
goto v___jp_876_;
}
v___jp_894_:
{
uint64_t v___x_897_; uint64_t v___x_898_; uint64_t v___x_899_; uint64_t v___x_900_; lean_object* v___x_901_; lean_object* v___x_902_; uint8_t v___x_903_; 
v___x_897_ = lean_uint8_to_uint64(v___y_896_);
v___x_898_ = 16ULL;
v___x_899_ = lean_uint64_shift_left(v___x_897_, v___x_898_);
v___x_900_ = lean_uint64_lor(v___y_895_, v___x_899_);
v___x_901_ = lean_unsigned_to_nat(3u);
v___x_902_ = lean_nat_add(v_offset_893_, v___x_901_);
lean_dec(v_offset_893_);
v___x_903_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v_columns_723_, v___x_902_);
if (v___x_903_ == 0)
{
lean_object* v___x_904_; lean_object* v___x_905_; uint8_t v___x_906_; 
lean_dec(v___x_902_);
v___x_904_ = lean_box(v___x_891_);
v___x_905_ = l_outOfBounds___redArg(v___x_904_);
lean_dec(v___x_904_);
v___x_906_ = lean_unbox(v___x_905_);
lean_dec(v___x_905_);
v___y_885_ = v___x_900_;
v___y_886_ = v___x_906_;
goto v___jp_884_;
}
else
{
uint8_t v___x_907_; 
v___x_907_ = lean_byte_array_fget(v_columns_723_, v___x_902_);
lean_dec(v___x_902_);
v___y_885_ = v___x_900_;
v___y_886_ = v___x_907_;
goto v___jp_884_;
}
}
v___jp_908_:
{
uint64_t v___x_911_; uint64_t v___x_912_; uint64_t v___x_913_; uint64_t v___x_914_; lean_object* v___x_915_; lean_object* v___x_916_; uint8_t v___x_917_; 
v___x_911_ = lean_uint8_to_uint64(v___y_910_);
v___x_912_ = 8ULL;
v___x_913_ = lean_uint64_shift_left(v___x_911_, v___x_912_);
v___x_914_ = lean_uint64_lor(v___y_909_, v___x_913_);
v___x_915_ = lean_unsigned_to_nat(2u);
v___x_916_ = lean_nat_add(v_offset_893_, v___x_915_);
v___x_917_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v_columns_723_, v___x_916_);
if (v___x_917_ == 0)
{
lean_object* v___x_918_; lean_object* v___x_919_; uint8_t v___x_920_; 
lean_dec(v___x_916_);
v___x_918_ = lean_box(v___x_891_);
v___x_919_ = l_outOfBounds___redArg(v___x_918_);
lean_dec(v___x_918_);
v___x_920_ = lean_unbox(v___x_919_);
lean_dec(v___x_919_);
v___y_895_ = v___x_914_;
v___y_896_ = v___x_920_;
goto v___jp_894_;
}
else
{
uint8_t v___x_921_; 
v___x_921_ = lean_byte_array_fget(v_columns_723_, v___x_916_);
lean_dec(v___x_916_);
v___y_895_ = v___x_914_;
v___y_896_ = v___x_921_;
goto v___jp_894_;
}
}
v___jp_922_:
{
uint64_t v_a_924_; lean_object* v___x_925_; lean_object* v___x_926_; uint8_t v___x_927_; 
v_a_924_ = lean_uint8_to_uint64(v___y_923_);
v___x_925_ = lean_unsigned_to_nat(1u);
v___x_926_ = lean_nat_add(v_offset_893_, v___x_925_);
v___x_927_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v_columns_723_, v___x_926_);
if (v___x_927_ == 0)
{
lean_object* v___x_928_; lean_object* v___x_929_; uint8_t v___x_930_; 
lean_dec(v___x_926_);
v___x_928_ = lean_box(v___x_891_);
v___x_929_ = l_outOfBounds___redArg(v___x_928_);
lean_dec(v___x_928_);
v___x_930_ = lean_unbox(v___x_929_);
lean_dec(v___x_929_);
v___y_909_ = v_a_924_;
v___y_910_ = v___x_930_;
goto v___jp_908_;
}
else
{
uint8_t v___x_931_; 
v___x_931_ = lean_byte_array_fget(v_columns_723_, v___x_926_);
lean_dec(v___x_926_);
v___y_909_ = v_a_924_;
v___y_910_ = v___x_931_;
goto v___jp_908_;
}
}
v___jp_932_:
{
if (v___y_933_ == 0)
{
uint8_t v___x_934_; 
v___x_934_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___lam__0(v_columns_723_, v_offset_893_);
if (v___x_934_ == 0)
{
lean_object* v___x_935_; lean_object* v___x_936_; uint8_t v___x_937_; 
v___x_935_ = lean_box(v___x_891_);
v___x_936_ = l_outOfBounds___redArg(v___x_935_);
lean_dec(v___x_935_);
v___x_937_ = lean_unbox(v___x_936_);
lean_dec(v___x_936_);
v___y_923_ = v___x_937_;
goto v___jp_922_;
}
else
{
uint8_t v___x_938_; 
v___x_938_ = lean_byte_array_fget(v_columns_723_, v_offset_893_);
v___y_923_ = v___x_938_;
goto v___jp_922_;
}
}
else
{
size_t v_pos_939_; uint8_t v___x_940_; uint64_t v_a_941_; size_t v___x_942_; size_t v___x_943_; uint8_t v___x_944_; uint64_t v___x_945_; uint64_t v___x_946_; uint64_t v___x_947_; uint64_t v___x_948_; size_t v___x_949_; size_t v___x_950_; uint8_t v___x_951_; uint64_t v___x_952_; uint64_t v___x_953_; uint64_t v___x_954_; uint64_t v___x_955_; size_t v___x_956_; size_t v___x_957_; uint8_t v___x_958_; uint64_t v___x_959_; uint64_t v___x_960_; uint64_t v___x_961_; uint64_t v___x_962_; 
v_pos_939_ = lean_usize_of_nat(v_offset_893_);
lean_dec(v_offset_893_);
v___x_940_ = lean_byte_array_uget(v_columns_723_, v_pos_939_);
v_a_941_ = lean_uint8_to_uint64(v___x_940_);
v___x_942_ = ((size_t)1ULL);
v___x_943_ = lean_usize_add(v_pos_939_, v___x_942_);
v___x_944_ = lean_byte_array_uget(v_columns_723_, v___x_943_);
v___x_945_ = lean_uint8_to_uint64(v___x_944_);
v___x_946_ = 8ULL;
v___x_947_ = lean_uint64_shift_left(v___x_945_, v___x_946_);
v___x_948_ = lean_uint64_lor(v_a_941_, v___x_947_);
v___x_949_ = ((size_t)2ULL);
v___x_950_ = lean_usize_add(v_pos_939_, v___x_949_);
v___x_951_ = lean_byte_array_uget(v_columns_723_, v___x_950_);
v___x_952_ = lean_uint8_to_uint64(v___x_951_);
v___x_953_ = 16ULL;
v___x_954_ = lean_uint64_shift_left(v___x_952_, v___x_953_);
v___x_955_ = lean_uint64_lor(v___x_948_, v___x_954_);
v___x_956_ = ((size_t)3ULL);
v___x_957_ = lean_usize_add(v_pos_939_, v___x_956_);
v___x_958_ = lean_byte_array_uget(v_columns_723_, v___x_957_);
v___x_959_ = lean_uint8_to_uint64(v___x_958_);
v___x_960_ = 24ULL;
v___x_961_ = lean_uint64_shift_left(v___x_959_, v___x_960_);
v___x_962_ = lean_uint64_lor(v___x_955_, v___x_961_);
v___y_877_ = v___x_962_;
goto v___jp_876_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0___boxed(lean_object* v_field_969_, lean_object* v_row_970_, lean_object* v_sz_971_, lean_object* v_i_972_, lean_object* v_bs_973_){
_start:
{
uint64_t v_field_boxed_974_; size_t v_sz_boxed_975_; size_t v_i_boxed_976_; lean_object* v_res_977_; 
v_field_boxed_974_ = lean_unbox_uint64(v_field_969_);
lean_dec_ref(v_field_969_);
v_sz_boxed_975_ = lean_unbox_usize(v_sz_971_);
lean_dec(v_sz_971_);
v_i_boxed_976_ = lean_unbox_usize(v_i_972_);
lean_dec(v_i_972_);
v_res_977_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0(v_field_boxed_974_, v_row_970_, v_sz_boxed_975_, v_i_boxed_976_, v_bs_973_);
lean_dec_ref(v_row_970_);
return v_res_977_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_entries(uint64_t v_field_978_, lean_object* v_row_979_){
_start:
{
lean_object* v___x_980_; lean_object* v___x_981_; size_t v_sz_982_; size_t v___x_983_; lean_object* v___x_984_; 
v___x_980_ = lp_Hex_Hex_Groebner_SparseRow_size(v_row_979_);
v___x_981_ = l_Array_range(v___x_980_);
v_sz_982_ = lean_array_size(v___x_981_);
v___x_983_ = ((size_t)0ULL);
v___x_984_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_SparseRow_entries_spec__0(v_field_978_, v_row_979_, v_sz_982_, v___x_983_, v___x_981_);
return v___x_984_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_SparseRow_entries___boxed(lean_object* v_field_985_, lean_object* v_row_986_){
_start:
{
uint64_t v_field_boxed_987_; lean_object* v_res_988_; 
v_field_boxed_987_ = lean_unbox_uint64(v_field_985_);
lean_dec_ref(v_field_985_);
v_res_988_ = lp_Hex_Hex_Groebner_SparseRow_entries(v_field_boxed_987_, v_row_986_);
lean_dec_ref(v_row_986_);
return v_res_988_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexModArith_Field(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexArith_Barrett_Context(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_Packed(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexModArith_Field(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexArith_Barrett_Context(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_Groebner_instInhabitedWidth_default = _init_lp_Hex_Hex_Groebner_instInhabitedWidth_default();
lp_Hex_Hex_Groebner_instInhabitedWidth = _init_lp_Hex_Hex_Groebner_instInhabitedWidth();
lp_Hex_Hex_Groebner_instInhabitedSparseRow_default = _init_lp_Hex_Hex_Groebner_instInhabitedSparseRow_default();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedSparseRow_default);
lp_Hex_Hex_Groebner_instInhabitedSparseRow = _init_lp_Hex_Hex_Groebner_instInhabitedSparseRow();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedSparseRow);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_Packed(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexModArith_Field(uint8_t builtin);
lean_object* initialize_Hex_HexArith_Barrett_Context(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_Packed(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexModArith_Field(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexArith_Barrett_Context(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Packed(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_Packed(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_Packed(builtin);
}
#ifdef __cplusplus
}
#endif
