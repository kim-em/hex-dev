// Lean compiler output
// Module: HexGroebner.Reducer
// Imports: public import Init public meta import Init public import HexGroebner.Polynomial
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern lean_object* lp_Hex_Hex_Groebner_instInhabitedPolynomial_default;
extern lean_object* l_ByteArray_empty;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* lean_array_fset(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
lean_object* lean_byte_array_size(lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_array_get(lean_object*, lean_object*, lean_object*);
lean_object* lean_uint64_to_nat(uint64_t);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_byte_array_uget(lean_object*, size_t);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_nat_mul(lean_object*, lean_object*);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_usize_to_nat(size_t);
lean_object* lp_Hex_Hex_Groebner_Computation_allocate(lean_object*, lean_object*, lean_object*);
uint8_t lean_uint64_to_uint8(uint64_t);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_byte_array_push(lean_object*, uint8_t);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_array_pop(lean_object*);
uint8_t lean_uint64_dec_le(uint64_t, uint64_t);
uint64_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(lean_object*, lean_object*);
uint64_t lean_uint64_land(uint64_t, uint64_t);
static lean_once_cell_t lp_Hex_Hex_Groebner_instInhabitedBasisElement_default___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instInhabitedBasisElement_default___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedBasisElement_default;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedBasisElement;
static lean_once_cell_t lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedDivisorNode;
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 2}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__0_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 3}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__1 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Groebner_ReducerIndex_build___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_ReducerIndex_build___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_build(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_build___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0___redArg(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__1_value)}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 246}, .m_size = 1, .m_capacity = 1, .m_data = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___closed__0 = (const lean_object*)&lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___closed__0_value;
static const lean_ctor_object lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___closed__0_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___closed__1 = (const lean_object*)&lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_find(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_find___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0___redArg(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex_Hex_Groebner_ReducerIndex_divisors___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_Groebner_ReducerIndex_divisors___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_ReducerIndex_divisors___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_ReducerIndex_divisors___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___closed__0_value),((lean_object*)&lp_Hex_Hex_Groebner_ReducerIndex_divisors___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_ReducerIndex_divisors___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_ReducerIndex_divisors___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_divisors(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_divisors___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedBasisElement_default___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; lean_object* v___x_3_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lp_Hex_Hex_Groebner_instInhabitedPolynomial_default;
v___x_3_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3_, 0, v___x_2_);
lean_ctor_set(v___x_3_, 1, v___x_1_);
return v___x_3_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedBasisElement_default(void){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_obj_once(&lp_Hex_Hex_Groebner_instInhabitedBasisElement_default___closed__0, &lp_Hex_Hex_Groebner_instInhabitedBasisElement_default___closed__0_once, _init_lp_Hex_Hex_Groebner_instInhabitedBasisElement_default___closed__0);
return v___x_4_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedBasisElement(void){
_start:
{
lean_object* v___x_5_; 
v___x_5_ = lp_Hex_Hex_Groebner_instInhabitedBasisElement_default;
return v___x_5_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default___closed__0(void){
_start:
{
lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___x_9_; 
v___x_6_ = lean_unsigned_to_nat(0u);
v___x_7_ = lean_box(0);
v___x_8_ = l_ByteArray_empty;
v___x_9_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_9_, 0, v___x_8_);
lean_ctor_set(v___x_9_, 1, v___x_7_);
lean_ctor_set(v___x_9_, 2, v___x_6_);
return v___x_9_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default(void){
_start:
{
lean_object* v___x_10_; 
v___x_10_ = lean_obj_once(&lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default___closed__0, &lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default___closed__0_once, _init_lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default___closed__0);
return v___x_10_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedDivisorNode(void){
_start:
{
lean_object* v___x_11_; 
v___x_11_ = lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default;
return v___x_11_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(lean_object* v_xs_12_, lean_object* v_i_13_){
_start:
{
lean_object* v___x_14_; uint8_t v___x_15_; 
v___x_14_ = lean_byte_array_size(v_xs_12_);
v___x_15_ = lean_nat_dec_lt(v_i_13_, v___x_14_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0___boxed(lean_object* v_xs_16_, lean_object* v_i_17_){
_start:
{
uint8_t v_res_18_; lean_object* v_r_19_; 
v_res_18_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_xs_16_, v_i_17_);
lean_dec(v_i_17_);
lean_dec_ref(v_xs_16_);
v_r_19_ = lean_box(v_res_18_);
return v_r_19_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg(uint64_t v___y_20_, lean_object* v___x_21_, lean_object* v_range_22_, lean_object* v_b_23_, lean_object* v_i_24_, lean_object* v___y_25_){
_start:
{
uint64_t v___y_27_; uint64_t v___y_33_; uint8_t v___y_34_; lean_object* v_stop_39_; lean_object* v_step_40_; uint8_t v___x_41_; 
v_stop_39_ = lean_ctor_get(v_range_22_, 1);
v_step_40_ = lean_ctor_get(v_range_22_, 2);
v___x_41_ = lean_nat_dec_lt(v_i_24_, v_stop_39_);
if (v___x_41_ == 0)
{
lean_object* v___x_42_; lean_object* v___x_43_; 
lean_dec(v_i_24_);
v___x_42_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_42_, 0, v_b_23_);
v___x_43_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_43_, 0, v___x_42_);
lean_ctor_set(v___x_43_, 1, v___y_25_);
return v___x_43_;
}
else
{
uint8_t v___y_45_; lean_object* v___y_46_; uint64_t v___y_47_; uint8_t v___y_48_; lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___y_63_; uint8_t v___y_64_; uint64_t v___y_65_; uint8_t v___y_66_; uint8_t v___y_78_; lean_object* v___y_79_; uint8_t v___y_80_; uint8_t v___y_89_; lean_object* v___y_90_; uint8_t v___y_91_; lean_object* v___x_121_; uint64_t v___y_123_; uint64_t v___y_138_; uint8_t v___y_139_; uint8_t v___x_144_; lean_object* v___x_145_; lean_object* v_offset_146_; uint64_t v___y_148_; uint8_t v___y_149_; uint64_t v___y_162_; uint8_t v___y_163_; uint8_t v___y_175_; uint8_t v___y_184_; lean_object* v___x_214_; lean_object* v___x_215_; uint8_t v___x_216_; 
v___x_60_ = lean_unsigned_to_nat(1u);
v___x_61_ = lean_unsigned_to_nat(2u);
v___x_121_ = lean_nat_mul(v___x_61_, v_i_24_);
v___x_144_ = 0;
v___x_145_ = lean_unsigned_to_nat(4u);
v_offset_146_ = lean_nat_mul(v___x_121_, v___x_145_);
v___x_214_ = lean_nat_add(v_offset_146_, v___x_145_);
v___x_215_ = lean_byte_array_size(v___x_21_);
v___x_216_ = lean_nat_dec_le(v___x_214_, v___x_215_);
if (v___x_216_ == 0)
{
lean_dec(v___x_214_);
v___y_184_ = v___x_216_;
goto v___jp_183_;
}
else
{
size_t v___x_217_; lean_object* v___x_218_; uint8_t v___x_219_; 
v___x_217_ = lean_usize_of_nat(v___x_214_);
v___x_218_ = lean_usize_to_nat(v___x_217_);
v___x_219_ = lean_nat_dec_eq(v___x_218_, v___x_214_);
lean_dec(v___x_214_);
lean_dec(v___x_218_);
v___y_184_ = v___x_219_;
goto v___jp_183_;
}
v___jp_44_:
{
uint64_t v___x_49_; uint64_t v___x_50_; uint64_t v___x_51_; uint64_t v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; uint8_t v___x_55_; 
v___x_49_ = lean_uint8_to_uint64(v___y_48_);
v___x_50_ = 16ULL;
v___x_51_ = lean_uint64_shift_left(v___x_49_, v___x_50_);
v___x_52_ = lean_uint64_lor(v___y_47_, v___x_51_);
v___x_53_ = lean_unsigned_to_nat(3u);
v___x_54_ = lean_nat_add(v___y_46_, v___x_53_);
lean_dec(v___y_46_);
v___x_55_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_21_, v___x_54_);
if (v___x_55_ == 0)
{
lean_object* v___x_56_; lean_object* v___x_57_; uint8_t v___x_58_; 
lean_dec(v___x_54_);
v___x_56_ = lean_box(v___y_45_);
v___x_57_ = l_outOfBounds___redArg(v___x_56_);
lean_dec(v___x_56_);
v___x_58_ = lean_unbox(v___x_57_);
lean_dec(v___x_57_);
v___y_33_ = v___x_52_;
v___y_34_ = v___x_58_;
goto v___jp_32_;
}
else
{
uint8_t v___x_59_; 
v___x_59_ = lean_byte_array_fget(v___x_21_, v___x_54_);
lean_dec(v___x_54_);
v___y_33_ = v___x_52_;
v___y_34_ = v___x_59_;
goto v___jp_32_;
}
}
v___jp_62_:
{
uint64_t v___x_67_; uint64_t v___x_68_; uint64_t v___x_69_; uint64_t v___x_70_; lean_object* v___x_71_; uint8_t v___x_72_; 
v___x_67_ = lean_uint8_to_uint64(v___y_66_);
v___x_68_ = 8ULL;
v___x_69_ = lean_uint64_shift_left(v___x_67_, v___x_68_);
v___x_70_ = lean_uint64_lor(v___y_65_, v___x_69_);
v___x_71_ = lean_nat_add(v___y_63_, v___x_61_);
v___x_72_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_21_, v___x_71_);
if (v___x_72_ == 0)
{
lean_object* v___x_73_; lean_object* v___x_74_; uint8_t v___x_75_; 
lean_dec(v___x_71_);
v___x_73_ = lean_box(v___y_64_);
v___x_74_ = l_outOfBounds___redArg(v___x_73_);
lean_dec(v___x_73_);
v___x_75_ = lean_unbox(v___x_74_);
lean_dec(v___x_74_);
v___y_45_ = v___y_64_;
v___y_46_ = v___y_63_;
v___y_47_ = v___x_70_;
v___y_48_ = v___x_75_;
goto v___jp_44_;
}
else
{
uint8_t v___x_76_; 
v___x_76_ = lean_byte_array_fget(v___x_21_, v___x_71_);
lean_dec(v___x_71_);
v___y_45_ = v___y_64_;
v___y_46_ = v___y_63_;
v___y_47_ = v___x_70_;
v___y_48_ = v___x_76_;
goto v___jp_44_;
}
}
v___jp_77_:
{
uint64_t v_a_81_; lean_object* v___x_82_; uint8_t v___x_83_; 
v_a_81_ = lean_uint8_to_uint64(v___y_80_);
v___x_82_ = lean_nat_add(v___y_79_, v___x_60_);
v___x_83_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_21_, v___x_82_);
if (v___x_83_ == 0)
{
lean_object* v___x_84_; lean_object* v___x_85_; uint8_t v___x_86_; 
lean_dec(v___x_82_);
v___x_84_ = lean_box(v___y_78_);
v___x_85_ = l_outOfBounds___redArg(v___x_84_);
lean_dec(v___x_84_);
v___x_86_ = lean_unbox(v___x_85_);
lean_dec(v___x_85_);
v___y_63_ = v___y_79_;
v___y_64_ = v___y_78_;
v___y_65_ = v_a_81_;
v___y_66_ = v___x_86_;
goto v___jp_62_;
}
else
{
uint8_t v___x_87_; 
v___x_87_ = lean_byte_array_fget(v___x_21_, v___x_82_);
lean_dec(v___x_82_);
v___y_63_ = v___y_79_;
v___y_64_ = v___y_78_;
v___y_65_ = v_a_81_;
v___y_66_ = v___x_87_;
goto v___jp_62_;
}
}
v___jp_88_:
{
if (v___y_91_ == 0)
{
uint8_t v___x_92_; 
v___x_92_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_21_, v___y_90_);
if (v___x_92_ == 0)
{
lean_object* v___x_93_; lean_object* v___x_94_; uint8_t v___x_95_; 
v___x_93_ = lean_box(v___y_89_);
v___x_94_ = l_outOfBounds___redArg(v___x_93_);
lean_dec(v___x_93_);
v___x_95_ = lean_unbox(v___x_94_);
lean_dec(v___x_94_);
v___y_78_ = v___y_89_;
v___y_79_ = v___y_90_;
v___y_80_ = v___x_95_;
goto v___jp_77_;
}
else
{
uint8_t v___x_96_; 
v___x_96_ = lean_byte_array_fget(v___x_21_, v___y_90_);
v___y_78_ = v___y_89_;
v___y_79_ = v___y_90_;
v___y_80_ = v___x_96_;
goto v___jp_77_;
}
}
else
{
size_t v_pos_97_; uint8_t v___x_98_; uint64_t v_a_99_; size_t v___x_100_; size_t v___x_101_; uint8_t v___x_102_; uint64_t v___x_103_; uint64_t v___x_104_; uint64_t v___x_105_; uint64_t v___x_106_; size_t v___x_107_; size_t v___x_108_; uint8_t v___x_109_; uint64_t v___x_110_; uint64_t v___x_111_; uint64_t v___x_112_; uint64_t v___x_113_; size_t v___x_114_; size_t v___x_115_; uint8_t v___x_116_; uint64_t v___x_117_; uint64_t v___x_118_; uint64_t v___x_119_; uint64_t v___x_120_; 
v_pos_97_ = lean_usize_of_nat(v___y_90_);
lean_dec(v___y_90_);
v___x_98_ = lean_byte_array_uget(v___x_21_, v_pos_97_);
v_a_99_ = lean_uint8_to_uint64(v___x_98_);
v___x_100_ = ((size_t)1ULL);
v___x_101_ = lean_usize_add(v_pos_97_, v___x_100_);
v___x_102_ = lean_byte_array_uget(v___x_21_, v___x_101_);
v___x_103_ = lean_uint8_to_uint64(v___x_102_);
v___x_104_ = 8ULL;
v___x_105_ = lean_uint64_shift_left(v___x_103_, v___x_104_);
v___x_106_ = lean_uint64_lor(v_a_99_, v___x_105_);
v___x_107_ = ((size_t)2ULL);
v___x_108_ = lean_usize_add(v_pos_97_, v___x_107_);
v___x_109_ = lean_byte_array_uget(v___x_21_, v___x_108_);
v___x_110_ = lean_uint8_to_uint64(v___x_109_);
v___x_111_ = 16ULL;
v___x_112_ = lean_uint64_shift_left(v___x_110_, v___x_111_);
v___x_113_ = lean_uint64_lor(v___x_106_, v___x_112_);
v___x_114_ = ((size_t)3ULL);
v___x_115_ = lean_usize_add(v_pos_97_, v___x_114_);
v___x_116_ = lean_byte_array_uget(v___x_21_, v___x_115_);
v___x_117_ = lean_uint8_to_uint64(v___x_116_);
v___x_118_ = 24ULL;
v___x_119_ = lean_uint64_shift_left(v___x_117_, v___x_118_);
v___x_120_ = lean_uint64_lor(v___x_113_, v___x_119_);
v___y_27_ = v___x_120_;
goto v___jp_26_;
}
}
v___jp_122_:
{
uint8_t v___x_124_; 
v___x_124_ = lean_uint64_dec_eq(v___y_123_, v___y_20_);
if (v___x_124_ == 0)
{
lean_object* v___x_125_; 
lean_dec(v___x_121_);
v___x_125_ = lean_nat_add(v_i_24_, v_step_40_);
lean_dec(v_i_24_);
v_i_24_ = v___x_125_;
goto _start;
}
else
{
lean_object* v___x_127_; uint8_t v___x_128_; lean_object* v___x_129_; lean_object* v_offset_130_; lean_object* v___x_131_; lean_object* v___x_132_; uint8_t v___x_133_; 
lean_dec(v_i_24_);
lean_dec(v_b_23_);
v___x_127_ = lean_nat_add(v___x_121_, v___x_60_);
lean_dec(v___x_121_);
v___x_128_ = 0;
v___x_129_ = lean_unsigned_to_nat(4u);
v_offset_130_ = lean_nat_mul(v___x_127_, v___x_129_);
lean_dec(v___x_127_);
v___x_131_ = lean_nat_add(v_offset_130_, v___x_129_);
v___x_132_ = lean_byte_array_size(v___x_21_);
v___x_133_ = lean_nat_dec_le(v___x_131_, v___x_132_);
if (v___x_133_ == 0)
{
lean_dec(v___x_131_);
v___y_89_ = v___x_128_;
v___y_90_ = v_offset_130_;
v___y_91_ = v___x_133_;
goto v___jp_88_;
}
else
{
size_t v___x_134_; lean_object* v___x_135_; uint8_t v___x_136_; 
v___x_134_ = lean_usize_of_nat(v___x_131_);
v___x_135_ = lean_usize_to_nat(v___x_134_);
v___x_136_ = lean_nat_dec_eq(v___x_135_, v___x_131_);
lean_dec(v___x_131_);
lean_dec(v___x_135_);
v___y_89_ = v___x_128_;
v___y_90_ = v_offset_130_;
v___y_91_ = v___x_136_;
goto v___jp_88_;
}
}
}
v___jp_137_:
{
uint64_t v___x_140_; uint64_t v___x_141_; uint64_t v___x_142_; uint64_t v___x_143_; 
v___x_140_ = lean_uint8_to_uint64(v___y_139_);
v___x_141_ = 24ULL;
v___x_142_ = lean_uint64_shift_left(v___x_140_, v___x_141_);
v___x_143_ = lean_uint64_lor(v___y_138_, v___x_142_);
v___y_123_ = v___x_143_;
goto v___jp_122_;
}
v___jp_147_:
{
uint64_t v___x_150_; uint64_t v___x_151_; uint64_t v___x_152_; uint64_t v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; uint8_t v___x_156_; 
v___x_150_ = lean_uint8_to_uint64(v___y_149_);
v___x_151_ = 16ULL;
v___x_152_ = lean_uint64_shift_left(v___x_150_, v___x_151_);
v___x_153_ = lean_uint64_lor(v___y_148_, v___x_152_);
v___x_154_ = lean_unsigned_to_nat(3u);
v___x_155_ = lean_nat_add(v_offset_146_, v___x_154_);
lean_dec(v_offset_146_);
v___x_156_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_21_, v___x_155_);
if (v___x_156_ == 0)
{
lean_object* v___x_157_; lean_object* v___x_158_; uint8_t v___x_159_; 
lean_dec(v___x_155_);
v___x_157_ = lean_box(v___x_144_);
v___x_158_ = l_outOfBounds___redArg(v___x_157_);
lean_dec(v___x_157_);
v___x_159_ = lean_unbox(v___x_158_);
lean_dec(v___x_158_);
v___y_138_ = v___x_153_;
v___y_139_ = v___x_159_;
goto v___jp_137_;
}
else
{
uint8_t v___x_160_; 
v___x_160_ = lean_byte_array_fget(v___x_21_, v___x_155_);
lean_dec(v___x_155_);
v___y_138_ = v___x_153_;
v___y_139_ = v___x_160_;
goto v___jp_137_;
}
}
v___jp_161_:
{
uint64_t v___x_164_; uint64_t v___x_165_; uint64_t v___x_166_; uint64_t v___x_167_; lean_object* v___x_168_; uint8_t v___x_169_; 
v___x_164_ = lean_uint8_to_uint64(v___y_163_);
v___x_165_ = 8ULL;
v___x_166_ = lean_uint64_shift_left(v___x_164_, v___x_165_);
v___x_167_ = lean_uint64_lor(v___y_162_, v___x_166_);
v___x_168_ = lean_nat_add(v_offset_146_, v___x_61_);
v___x_169_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_21_, v___x_168_);
if (v___x_169_ == 0)
{
lean_object* v___x_170_; lean_object* v___x_171_; uint8_t v___x_172_; 
lean_dec(v___x_168_);
v___x_170_ = lean_box(v___x_144_);
v___x_171_ = l_outOfBounds___redArg(v___x_170_);
lean_dec(v___x_170_);
v___x_172_ = lean_unbox(v___x_171_);
lean_dec(v___x_171_);
v___y_148_ = v___x_167_;
v___y_149_ = v___x_172_;
goto v___jp_147_;
}
else
{
uint8_t v___x_173_; 
v___x_173_ = lean_byte_array_fget(v___x_21_, v___x_168_);
lean_dec(v___x_168_);
v___y_148_ = v___x_167_;
v___y_149_ = v___x_173_;
goto v___jp_147_;
}
}
v___jp_174_:
{
uint64_t v_a_176_; lean_object* v___x_177_; uint8_t v___x_178_; 
v_a_176_ = lean_uint8_to_uint64(v___y_175_);
v___x_177_ = lean_nat_add(v_offset_146_, v___x_60_);
v___x_178_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_21_, v___x_177_);
if (v___x_178_ == 0)
{
lean_object* v___x_179_; lean_object* v___x_180_; uint8_t v___x_181_; 
lean_dec(v___x_177_);
v___x_179_ = lean_box(v___x_144_);
v___x_180_ = l_outOfBounds___redArg(v___x_179_);
lean_dec(v___x_179_);
v___x_181_ = lean_unbox(v___x_180_);
lean_dec(v___x_180_);
v___y_162_ = v_a_176_;
v___y_163_ = v___x_181_;
goto v___jp_161_;
}
else
{
uint8_t v___x_182_; 
v___x_182_ = lean_byte_array_fget(v___x_21_, v___x_177_);
lean_dec(v___x_177_);
v___y_162_ = v_a_176_;
v___y_163_ = v___x_182_;
goto v___jp_161_;
}
}
v___jp_183_:
{
if (v___y_184_ == 0)
{
uint8_t v___x_185_; 
v___x_185_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_21_, v_offset_146_);
if (v___x_185_ == 0)
{
lean_object* v___x_186_; lean_object* v___x_187_; uint8_t v___x_188_; 
v___x_186_ = lean_box(v___x_144_);
v___x_187_ = l_outOfBounds___redArg(v___x_186_);
lean_dec(v___x_186_);
v___x_188_ = lean_unbox(v___x_187_);
lean_dec(v___x_187_);
v___y_175_ = v___x_188_;
goto v___jp_174_;
}
else
{
uint8_t v___x_189_; 
v___x_189_ = lean_byte_array_fget(v___x_21_, v_offset_146_);
v___y_175_ = v___x_189_;
goto v___jp_174_;
}
}
else
{
size_t v_pos_190_; uint8_t v___x_191_; uint64_t v_a_192_; size_t v___x_193_; size_t v___x_194_; uint8_t v___x_195_; uint64_t v___x_196_; uint64_t v___x_197_; uint64_t v___x_198_; uint64_t v___x_199_; size_t v___x_200_; size_t v___x_201_; uint8_t v___x_202_; uint64_t v___x_203_; uint64_t v___x_204_; uint64_t v___x_205_; uint64_t v___x_206_; size_t v___x_207_; size_t v___x_208_; uint8_t v___x_209_; uint64_t v___x_210_; uint64_t v___x_211_; uint64_t v___x_212_; uint64_t v___x_213_; 
v_pos_190_ = lean_usize_of_nat(v_offset_146_);
lean_dec(v_offset_146_);
v___x_191_ = lean_byte_array_uget(v___x_21_, v_pos_190_);
v_a_192_ = lean_uint8_to_uint64(v___x_191_);
v___x_193_ = ((size_t)1ULL);
v___x_194_ = lean_usize_add(v_pos_190_, v___x_193_);
v___x_195_ = lean_byte_array_uget(v___x_21_, v___x_194_);
v___x_196_ = lean_uint8_to_uint64(v___x_195_);
v___x_197_ = 8ULL;
v___x_198_ = lean_uint64_shift_left(v___x_196_, v___x_197_);
v___x_199_ = lean_uint64_lor(v_a_192_, v___x_198_);
v___x_200_ = ((size_t)2ULL);
v___x_201_ = lean_usize_add(v_pos_190_, v___x_200_);
v___x_202_ = lean_byte_array_uget(v___x_21_, v___x_201_);
v___x_203_ = lean_uint8_to_uint64(v___x_202_);
v___x_204_ = 16ULL;
v___x_205_ = lean_uint64_shift_left(v___x_203_, v___x_204_);
v___x_206_ = lean_uint64_lor(v___x_199_, v___x_205_);
v___x_207_ = ((size_t)3ULL);
v___x_208_ = lean_usize_add(v_pos_190_, v___x_207_);
v___x_209_ = lean_byte_array_uget(v___x_21_, v___x_208_);
v___x_210_ = lean_uint8_to_uint64(v___x_209_);
v___x_211_ = 24ULL;
v___x_212_ = lean_uint64_shift_left(v___x_210_, v___x_211_);
v___x_213_ = lean_uint64_lor(v___x_206_, v___x_212_);
v___y_123_ = v___x_213_;
goto v___jp_122_;
}
}
}
v___jp_26_:
{
lean_object* v___x_28_; lean_object* v___x_29_; lean_object* v___x_30_; lean_object* v___x_31_; 
v___x_28_ = lean_uint64_to_nat(v___y_27_);
v___x_29_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_29_, 0, v___x_28_);
v___x_30_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_30_, 0, v___x_29_);
v___x_31_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_31_, 0, v___x_30_);
lean_ctor_set(v___x_31_, 1, v___y_25_);
return v___x_31_;
}
v___jp_32_:
{
uint64_t v___x_35_; uint64_t v___x_36_; uint64_t v___x_37_; uint64_t v___x_38_; 
v___x_35_ = lean_uint8_to_uint64(v___y_34_);
v___x_36_ = 24ULL;
v___x_37_ = lean_uint64_shift_left(v___x_35_, v___x_36_);
v___x_38_ = lean_uint64_lor(v___y_33_, v___x_37_);
v___y_27_ = v___x_38_;
goto v___jp_26_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___boxed(lean_object* v___y_220_, lean_object* v___x_221_, lean_object* v_range_222_, lean_object* v_b_223_, lean_object* v_i_224_, lean_object* v___y_225_){
_start:
{
uint64_t v___y_17100__boxed_226_; lean_object* v_res_227_; 
v___y_17100__boxed_226_ = lean_unbox_uint64(v___y_220_);
lean_dec_ref(v___y_220_);
v_res_227_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg(v___y_17100__boxed_226_, v___x_221_, v_range_222_, v_b_223_, v_i_224_, v___y_225_);
lean_dec_ref(v_range_222_);
lean_dec_ref(v___x_221_);
return v_res_227_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg(lean_object* v_limits_232_, lean_object* v_table_233_, lean_object* v___y_234_, lean_object* v_range_235_, lean_object* v_b_236_, lean_object* v_i_237_, lean_object* v___y_238_){
_start:
{
lean_object* v_a_240_; lean_object* v_snd_241_; lean_object* v_stop_244_; lean_object* v_step_245_; lean_object* v_a_247_; lean_object* v_snd_248_; uint8_t v___x_251_; 
v_stop_244_ = lean_ctor_get(v_range_235_, 1);
v_step_245_ = lean_ctor_get(v_range_235_, 2);
v___x_251_ = lean_nat_dec_lt(v_i_237_, v_stop_244_);
if (v___x_251_ == 0)
{
lean_object* v___x_252_; lean_object* v___x_253_; 
lean_dec(v_i_237_);
v___x_252_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_252_, 0, v_b_236_);
v___x_253_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_253_, 0, v___x_252_);
lean_ctor_set(v___x_253_, 1, v___y_238_);
return v___x_253_;
}
else
{
lean_object* v_fst_254_; lean_object* v_snd_255_; lean_object* v___x_257_; uint8_t v_isShared_258_; uint8_t v_isSharedCheck_507_; 
v_fst_254_ = lean_ctor_get(v_b_236_, 0);
v_snd_255_ = lean_ctor_get(v_b_236_, 1);
v_isSharedCheck_507_ = !lean_is_exclusive(v_b_236_);
if (v_isSharedCheck_507_ == 0)
{
v___x_257_ = v_b_236_;
v_isShared_258_ = v_isSharedCheck_507_;
goto v_resetjp_256_;
}
else
{
lean_inc(v_snd_255_);
lean_inc(v_fst_254_);
lean_dec(v_b_236_);
v___x_257_ = lean_box(0);
v_isShared_258_ = v_isSharedCheck_507_;
goto v_resetjp_256_;
}
v_resetjp_256_:
{
lean_object* v_arity_259_; uint8_t v_width_260_; lean_object* v_exponents_261_; lean_object* v___x_262_; lean_object* v___x_263_; lean_object* v_node_264_; lean_object* v_child_265_; lean_object* v___x_266_; lean_object* v___y_268_; lean_object* v___y_269_; lean_object* v___y_270_; uint64_t v___y_278_; uint64_t v___y_395_; uint8_t v___y_396_; uint64_t v___y_402_; uint8_t v___y_403_; lean_object* v___x_408_; lean_object* v___x_409_; uint8_t v___x_410_; uint64_t v___y_412_; lean_object* v___y_413_; uint8_t v___y_414_; uint64_t v___y_427_; lean_object* v___y_428_; uint8_t v___y_429_; lean_object* v___y_442_; uint8_t v___y_443_; lean_object* v___y_458_; uint8_t v___y_459_; lean_object* v___y_497_; 
v_arity_259_ = lean_ctor_get(v_table_233_, 0);
v_width_260_ = lean_ctor_get_uint8(v_table_233_, sizeof(void*)*8);
v_exponents_261_ = lean_ctor_get(v_table_233_, 1);
v___x_262_ = lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default;
v___x_263_ = lean_unsigned_to_nat(1u);
v_node_264_ = lean_unsigned_to_nat(0u);
v_child_265_ = lean_box(0);
v___x_266_ = l_ByteArray_empty;
v___x_408_ = lean_nat_mul(v___y_234_, v_arity_259_);
v___x_409_ = lean_nat_add(v___x_408_, v_i_237_);
lean_dec(v___x_408_);
v___x_410_ = 0;
switch(v_width_260_)
{
case 0:
{
v___y_497_ = v___x_263_;
goto v___jp_496_;
}
case 1:
{
lean_object* v___x_505_; 
v___x_505_ = lean_unsigned_to_nat(2u);
v___y_497_ = v___x_505_;
goto v___jp_496_;
}
default: 
{
lean_object* v___x_506_; 
v___x_506_ = lean_unsigned_to_nat(4u);
v___y_497_ = v___x_506_;
goto v___jp_496_;
}
}
v___jp_267_:
{
lean_object* v___x_271_; lean_object* v___x_272_; lean_object* v___x_273_; lean_object* v___x_275_; 
v___x_271_ = lean_nat_add(v_i_237_, v___x_263_);
v___x_272_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_272_, 0, v___x_266_);
lean_ctor_set(v___x_272_, 1, v_child_265_);
lean_ctor_set(v___x_272_, 2, v___x_271_);
v___x_273_ = lean_array_push(v___y_270_, v___x_272_);
if (v_isShared_258_ == 0)
{
lean_ctor_set(v___x_257_, 1, v___y_269_);
lean_ctor_set(v___x_257_, 0, v___x_273_);
v___x_275_ = v___x_257_;
goto v_reusejp_274_;
}
else
{
lean_object* v_reuseFailAlloc_276_; 
v_reuseFailAlloc_276_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_276_, 0, v___x_273_);
lean_ctor_set(v_reuseFailAlloc_276_, 1, v___y_269_);
v___x_275_ = v_reuseFailAlloc_276_;
goto v_reusejp_274_;
}
v_reusejp_274_:
{
v_a_247_ = v___x_275_;
v_snd_248_ = v___y_268_;
goto v___jp_246_;
}
}
v___jp_277_:
{
lean_object* v___x_279_; lean_object* v_statistics_280_; lean_object* v_edges_281_; lean_object* v___x_283_; uint8_t v_isShared_284_; uint8_t v_isSharedCheck_391_; 
v___x_279_ = lean_array_get(v___x_262_, v_fst_254_, v_snd_255_);
v_statistics_280_ = lean_ctor_get(v___y_238_, 1);
lean_inc_ref(v_statistics_280_);
v_edges_281_ = lean_ctor_get(v___x_279_, 0);
v_isSharedCheck_391_ = !lean_is_exclusive(v___x_279_);
if (v_isSharedCheck_391_ == 0)
{
lean_object* v_unused_392_; lean_object* v_unused_393_; 
v_unused_392_ = lean_ctor_get(v___x_279_, 2);
lean_dec(v_unused_392_);
v_unused_393_ = lean_ctor_get(v___x_279_, 1);
lean_dec(v_unused_393_);
v___x_283_ = v___x_279_;
v_isShared_284_ = v_isSharedCheck_391_;
goto v_resetjp_282_;
}
else
{
lean_inc(v_edges_281_);
lean_dec(v___x_279_);
v___x_283_ = lean_box(0);
v_isShared_284_ = v_isSharedCheck_391_;
goto v_resetjp_282_;
}
v_resetjp_282_:
{
lean_object* v_table_285_; lean_object* v_work_286_; lean_object* v_allocatedBytes_287_; lean_object* v_pairs_288_; lean_object* v_rounds_289_; lean_object* v_matrixEntries_290_; lean_object* v_matrixRows_291_; lean_object* v_matrixCalls_292_; lean_object* v_peakMatrixRows_293_; lean_object* v_peakMatrixEntries_294_; lean_object* v_largestBatch_295_; lean_object* v_productPairs_296_; lean_object* v_chainPairs_297_; lean_object* v_gmPairs_298_; lean_object* v___x_300_; uint8_t v_isShared_301_; uint8_t v_isSharedCheck_390_; 
v_table_285_ = lean_ctor_get(v___y_238_, 0);
v_work_286_ = lean_ctor_get(v_statistics_280_, 0);
v_allocatedBytes_287_ = lean_ctor_get(v_statistics_280_, 1);
v_pairs_288_ = lean_ctor_get(v_statistics_280_, 2);
v_rounds_289_ = lean_ctor_get(v_statistics_280_, 3);
v_matrixEntries_290_ = lean_ctor_get(v_statistics_280_, 4);
v_matrixRows_291_ = lean_ctor_get(v_statistics_280_, 5);
v_matrixCalls_292_ = lean_ctor_get(v_statistics_280_, 6);
v_peakMatrixRows_293_ = lean_ctor_get(v_statistics_280_, 7);
v_peakMatrixEntries_294_ = lean_ctor_get(v_statistics_280_, 8);
v_largestBatch_295_ = lean_ctor_get(v_statistics_280_, 9);
v_productPairs_296_ = lean_ctor_get(v_statistics_280_, 10);
v_chainPairs_297_ = lean_ctor_get(v_statistics_280_, 11);
v_gmPairs_298_ = lean_ctor_get(v_statistics_280_, 12);
v_isSharedCheck_390_ = !lean_is_exclusive(v_statistics_280_);
if (v_isSharedCheck_390_ == 0)
{
v___x_300_ = v_statistics_280_;
v_isShared_301_ = v_isSharedCheck_390_;
goto v_resetjp_299_;
}
else
{
lean_inc(v_gmPairs_298_);
lean_inc(v_chainPairs_297_);
lean_inc(v_productPairs_296_);
lean_inc(v_largestBatch_295_);
lean_inc(v_peakMatrixEntries_294_);
lean_inc(v_peakMatrixRows_293_);
lean_inc(v_matrixCalls_292_);
lean_inc(v_matrixRows_291_);
lean_inc(v_matrixEntries_290_);
lean_inc(v_rounds_289_);
lean_inc(v_pairs_288_);
lean_inc(v_allocatedBytes_287_);
lean_inc(v_work_286_);
lean_dec(v_statistics_280_);
v___x_300_ = lean_box(0);
v_isShared_301_ = v_isSharedCheck_390_;
goto v_resetjp_299_;
}
v_resetjp_299_:
{
lean_object* v_work_302_; lean_object* v___x_303_; lean_object* v___x_304_; lean_object* v___x_305_; lean_object* v___x_306_; lean_object* v_work_307_; uint8_t v___x_308_; 
v_work_302_ = lean_ctor_get(v_limits_232_, 0);
v___x_303_ = lean_byte_array_size(v_edges_281_);
v___x_304_ = lean_unsigned_to_nat(3u);
v___x_305_ = lean_nat_shiftr(v___x_303_, v___x_304_);
v___x_306_ = lean_nat_add(v___x_305_, v___x_263_);
v_work_307_ = lean_nat_add(v_work_286_, v___x_306_);
lean_dec(v___x_306_);
lean_dec(v_work_286_);
v___x_308_ = lean_nat_dec_lt(v_work_302_, v_work_307_);
if (v___x_308_ == 0)
{
lean_object* v___x_310_; uint8_t v_isShared_311_; uint8_t v_isSharedCheck_386_; 
lean_inc_ref(v_table_285_);
v_isSharedCheck_386_ = !lean_is_exclusive(v___y_238_);
if (v_isSharedCheck_386_ == 0)
{
lean_object* v_unused_387_; lean_object* v_unused_388_; 
v_unused_387_ = lean_ctor_get(v___y_238_, 1);
lean_dec(v_unused_387_);
v_unused_388_ = lean_ctor_get(v___y_238_, 0);
lean_dec(v_unused_388_);
v___x_310_ = v___y_238_;
v_isShared_311_ = v_isSharedCheck_386_;
goto v_resetjp_309_;
}
else
{
lean_dec(v___y_238_);
v___x_310_ = lean_box(0);
v_isShared_311_ = v_isSharedCheck_386_;
goto v_resetjp_309_;
}
v_resetjp_309_:
{
lean_object* v___x_313_; 
if (v_isShared_301_ == 0)
{
lean_ctor_set(v___x_300_, 0, v_work_307_);
v___x_313_ = v___x_300_;
goto v_reusejp_312_;
}
else
{
lean_object* v_reuseFailAlloc_385_; 
v_reuseFailAlloc_385_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_385_, 0, v_work_307_);
lean_ctor_set(v_reuseFailAlloc_385_, 1, v_allocatedBytes_287_);
lean_ctor_set(v_reuseFailAlloc_385_, 2, v_pairs_288_);
lean_ctor_set(v_reuseFailAlloc_385_, 3, v_rounds_289_);
lean_ctor_set(v_reuseFailAlloc_385_, 4, v_matrixEntries_290_);
lean_ctor_set(v_reuseFailAlloc_385_, 5, v_matrixRows_291_);
lean_ctor_set(v_reuseFailAlloc_385_, 6, v_matrixCalls_292_);
lean_ctor_set(v_reuseFailAlloc_385_, 7, v_peakMatrixRows_293_);
lean_ctor_set(v_reuseFailAlloc_385_, 8, v_peakMatrixEntries_294_);
lean_ctor_set(v_reuseFailAlloc_385_, 9, v_largestBatch_295_);
lean_ctor_set(v_reuseFailAlloc_385_, 10, v_productPairs_296_);
lean_ctor_set(v_reuseFailAlloc_385_, 11, v_chainPairs_297_);
lean_ctor_set(v_reuseFailAlloc_385_, 12, v_gmPairs_298_);
v___x_313_ = v_reuseFailAlloc_385_;
goto v_reusejp_312_;
}
v_reusejp_312_:
{
lean_object* v___x_315_; 
if (v_isShared_311_ == 0)
{
lean_ctor_set(v___x_310_, 1, v___x_313_);
v___x_315_ = v___x_310_;
goto v_reusejp_314_;
}
else
{
lean_object* v_reuseFailAlloc_384_; 
v_reuseFailAlloc_384_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_384_, 0, v_table_285_);
lean_ctor_set(v_reuseFailAlloc_384_, 1, v___x_313_);
v___x_315_ = v_reuseFailAlloc_384_;
goto v_reusejp_314_;
}
v_reusejp_314_:
{
lean_object* v___x_317_; 
if (v_isShared_284_ == 0)
{
lean_ctor_set(v___x_283_, 2, v___x_263_);
lean_ctor_set(v___x_283_, 1, v___x_305_);
lean_ctor_set(v___x_283_, 0, v_node_264_);
v___x_317_ = v___x_283_;
goto v_reusejp_316_;
}
else
{
lean_object* v_reuseFailAlloc_383_; 
v_reuseFailAlloc_383_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_383_, 0, v_node_264_);
lean_ctor_set(v_reuseFailAlloc_383_, 1, v___x_305_);
lean_ctor_set(v_reuseFailAlloc_383_, 2, v___x_263_);
v___x_317_ = v_reuseFailAlloc_383_;
goto v_reusejp_316_;
}
v_reusejp_316_:
{
lean_object* v___x_318_; lean_object* v_fst_319_; lean_object* v_a_320_; 
v___x_318_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg(v___y_278_, v_edges_281_, v___x_317_, v_child_265_, v_node_264_, v___x_315_);
lean_dec_ref(v___x_317_);
v_fst_319_ = lean_ctor_get(v___x_318_, 0);
lean_inc(v_fst_319_);
v_a_320_ = lean_ctor_get(v_fst_319_, 0);
lean_inc(v_a_320_);
lean_dec(v_fst_319_);
if (lean_obj_tag(v_a_320_) == 0)
{
lean_object* v_snd_321_; lean_object* v___x_322_; lean_object* v___x_323_; lean_object* v_fst_324_; 
v_snd_321_ = lean_ctor_get(v___x_318_, 1);
lean_inc(v_snd_321_);
lean_dec_ref(v___x_318_);
v___x_322_ = lean_unsigned_to_nat(8u);
v___x_323_ = lp_Hex_Hex_Groebner_Computation_allocate(v_limits_232_, v___x_322_, v_snd_321_);
v_fst_324_ = lean_ctor_get(v___x_323_, 0);
lean_inc(v_fst_324_);
if (lean_obj_tag(v_fst_324_) == 0)
{
lean_object* v_snd_325_; lean_object* v_a_326_; 
lean_dec_ref(v_edges_281_);
lean_del_object(v___x_257_);
lean_dec(v_snd_255_);
lean_dec(v_fst_254_);
lean_dec(v_i_237_);
v_snd_325_ = lean_ctor_get(v___x_323_, 1);
lean_inc(v_snd_325_);
lean_dec_ref(v___x_323_);
v_a_326_ = lean_ctor_get(v_fst_324_, 0);
lean_inc(v_a_326_);
lean_dec_ref_known(v_fst_324_, 1);
v_a_240_ = v_a_326_;
v_snd_241_ = v_snd_325_;
goto v___jp_239_;
}
else
{
lean_object* v_snd_327_; lean_object* v___x_328_; lean_object* v___x_329_; uint8_t v___x_330_; 
lean_dec_ref_known(v_fst_324_, 1);
v_snd_327_ = lean_ctor_get(v___x_323_, 1);
lean_inc(v_snd_327_);
lean_dec_ref(v___x_323_);
v___x_328_ = lean_array_get_size(v_fst_254_);
v___x_329_ = lean_unsigned_to_nat(4294967295u);
v___x_330_ = lean_nat_dec_lt(v___x_329_, v___x_328_);
if (v___x_330_ == 0)
{
uint8_t v___x_331_; uint8_t v___x_332_; 
v___x_331_ = lean_uint64_to_uint8(v___y_278_);
v___x_332_ = lean_nat_dec_lt(v_snd_255_, v___x_328_);
if (v___x_332_ == 0)
{
lean_dec_ref(v_edges_281_);
lean_dec(v_snd_255_);
v___y_268_ = v_snd_327_;
v___y_269_ = v___x_328_;
v___y_270_ = v_fst_254_;
goto v___jp_267_;
}
else
{
uint64_t v___x_333_; uint64_t v___x_334_; uint64_t v___x_335_; uint8_t v___x_336_; lean_object* v_v_337_; lean_object* v_reducer_338_; lean_object* v_depth_339_; lean_object* v___x_341_; uint8_t v_isShared_342_; uint8_t v_isSharedCheck_370_; 
v___x_333_ = 8ULL;
v___x_334_ = lean_uint64_shift_right(v___y_278_, v___x_333_);
v___x_335_ = lean_uint64_of_nat(v___x_328_);
v___x_336_ = lean_uint64_to_uint8(v___x_335_);
v_v_337_ = lean_array_fget(v_fst_254_, v_snd_255_);
v_reducer_338_ = lean_ctor_get(v_v_337_, 1);
v_depth_339_ = lean_ctor_get(v_v_337_, 2);
v_isSharedCheck_370_ = !lean_is_exclusive(v_v_337_);
if (v_isSharedCheck_370_ == 0)
{
lean_object* v_unused_371_; 
v_unused_371_ = lean_ctor_get(v_v_337_, 0);
lean_dec(v_unused_371_);
v___x_341_ = v_v_337_;
v_isShared_342_ = v_isSharedCheck_370_;
goto v_resetjp_340_;
}
else
{
lean_inc(v_depth_339_);
lean_inc(v_reducer_338_);
lean_dec(v_v_337_);
v___x_341_ = lean_box(0);
v_isShared_342_ = v_isSharedCheck_370_;
goto v_resetjp_340_;
}
v_resetjp_340_:
{
uint64_t v___x_343_; uint64_t v___x_344_; uint64_t v___x_345_; uint64_t v___x_346_; uint64_t v___x_347_; uint64_t v___x_348_; lean_object* v_data_349_; uint8_t v___x_350_; lean_object* v___x_351_; uint8_t v___x_352_; lean_object* v___x_353_; uint8_t v___x_354_; lean_object* v___x_355_; lean_object* v_data_356_; uint8_t v___x_357_; lean_object* v___x_358_; uint8_t v___x_359_; lean_object* v___x_360_; uint64_t v___x_361_; uint8_t v___x_362_; lean_object* v___x_363_; lean_object* v___x_364_; lean_object* v_xs_x27_365_; lean_object* v___x_367_; 
v___x_343_ = 16ULL;
v___x_344_ = lean_uint64_shift_right(v___y_278_, v___x_343_);
v___x_345_ = lean_uint64_shift_right(v___x_335_, v___x_333_);
v___x_346_ = lean_uint64_shift_right(v___x_335_, v___x_343_);
v___x_347_ = 24ULL;
v___x_348_ = lean_uint64_shift_right(v___y_278_, v___x_347_);
v_data_349_ = lean_byte_array_push(v_edges_281_, v___x_331_);
v___x_350_ = lean_uint64_to_uint8(v___x_334_);
v___x_351_ = lean_byte_array_push(v_data_349_, v___x_350_);
v___x_352_ = lean_uint64_to_uint8(v___x_344_);
v___x_353_ = lean_byte_array_push(v___x_351_, v___x_352_);
v___x_354_ = lean_uint64_to_uint8(v___x_348_);
v___x_355_ = lean_byte_array_push(v___x_353_, v___x_354_);
v_data_356_ = lean_byte_array_push(v___x_355_, v___x_336_);
v___x_357_ = lean_uint64_to_uint8(v___x_345_);
v___x_358_ = lean_byte_array_push(v_data_356_, v___x_357_);
v___x_359_ = lean_uint64_to_uint8(v___x_346_);
v___x_360_ = lean_byte_array_push(v___x_358_, v___x_359_);
v___x_361_ = lean_uint64_shift_right(v___x_335_, v___x_347_);
v___x_362_ = lean_uint64_to_uint8(v___x_361_);
v___x_363_ = lean_byte_array_push(v___x_360_, v___x_362_);
v___x_364_ = lean_box(0);
v_xs_x27_365_ = lean_array_fset(v_fst_254_, v_snd_255_, v___x_364_);
if (v_isShared_342_ == 0)
{
lean_ctor_set(v___x_341_, 0, v___x_363_);
v___x_367_ = v___x_341_;
goto v_reusejp_366_;
}
else
{
lean_object* v_reuseFailAlloc_369_; 
v_reuseFailAlloc_369_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_369_, 0, v___x_363_);
lean_ctor_set(v_reuseFailAlloc_369_, 1, v_reducer_338_);
lean_ctor_set(v_reuseFailAlloc_369_, 2, v_depth_339_);
v___x_367_ = v_reuseFailAlloc_369_;
goto v_reusejp_366_;
}
v_reusejp_366_:
{
lean_object* v___x_368_; 
v___x_368_ = lean_array_fset(v_xs_x27_365_, v_snd_255_, v___x_367_);
lean_dec(v_snd_255_);
v___y_268_ = v_snd_327_;
v___y_269_ = v___x_328_;
v___y_270_ = v___x_368_;
goto v___jp_267_;
}
}
}
}
else
{
lean_object* v___x_372_; 
lean_dec_ref(v_edges_281_);
lean_del_object(v___x_257_);
lean_dec(v_snd_255_);
lean_dec(v_fst_254_);
lean_dec(v_i_237_);
v___x_372_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__0));
v_a_240_ = v___x_372_;
v_snd_241_ = v_snd_327_;
goto v___jp_239_;
}
}
}
else
{
lean_object* v_snd_373_; lean_object* v___x_375_; uint8_t v_isShared_376_; uint8_t v_isSharedCheck_381_; 
lean_dec_ref(v_edges_281_);
lean_del_object(v___x_257_);
lean_dec(v_snd_255_);
v_snd_373_ = lean_ctor_get(v___x_318_, 1);
v_isSharedCheck_381_ = !lean_is_exclusive(v___x_318_);
if (v_isSharedCheck_381_ == 0)
{
lean_object* v_unused_382_; 
v_unused_382_ = lean_ctor_get(v___x_318_, 0);
lean_dec(v_unused_382_);
v___x_375_ = v___x_318_;
v_isShared_376_ = v_isSharedCheck_381_;
goto v_resetjp_374_;
}
else
{
lean_inc(v_snd_373_);
lean_dec(v___x_318_);
v___x_375_ = lean_box(0);
v_isShared_376_ = v_isSharedCheck_381_;
goto v_resetjp_374_;
}
v_resetjp_374_:
{
lean_object* v_val_377_; lean_object* v___x_379_; 
v_val_377_ = lean_ctor_get(v_a_320_, 0);
lean_inc(v_val_377_);
lean_dec_ref_known(v_a_320_, 1);
if (v_isShared_376_ == 0)
{
lean_ctor_set(v___x_375_, 1, v_val_377_);
lean_ctor_set(v___x_375_, 0, v_fst_254_);
v___x_379_ = v___x_375_;
goto v_reusejp_378_;
}
else
{
lean_object* v_reuseFailAlloc_380_; 
v_reuseFailAlloc_380_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_380_, 0, v_fst_254_);
lean_ctor_set(v_reuseFailAlloc_380_, 1, v_val_377_);
v___x_379_ = v_reuseFailAlloc_380_;
goto v_reusejp_378_;
}
v_reusejp_378_:
{
v_a_247_ = v___x_379_;
v_snd_248_ = v_snd_373_;
goto v___jp_246_;
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_389_; 
lean_dec(v_work_307_);
lean_dec(v___x_305_);
lean_del_object(v___x_300_);
lean_dec(v_gmPairs_298_);
lean_dec(v_chainPairs_297_);
lean_dec(v_productPairs_296_);
lean_dec(v_largestBatch_295_);
lean_dec(v_peakMatrixEntries_294_);
lean_dec(v_peakMatrixRows_293_);
lean_dec(v_matrixCalls_292_);
lean_dec(v_matrixRows_291_);
lean_dec(v_matrixEntries_290_);
lean_dec(v_rounds_289_);
lean_dec(v_pairs_288_);
lean_dec(v_allocatedBytes_287_);
lean_del_object(v___x_283_);
lean_dec_ref(v_edges_281_);
lean_del_object(v___x_257_);
lean_dec(v_snd_255_);
lean_dec(v_fst_254_);
lean_dec(v_i_237_);
v___x_389_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__1));
v_a_240_ = v___x_389_;
v_snd_241_ = v___y_238_;
goto v___jp_239_;
}
}
}
}
v___jp_394_:
{
uint64_t v___x_397_; uint64_t v___x_398_; uint64_t v___x_399_; uint64_t v___x_400_; 
v___x_397_ = lean_uint8_to_uint64(v___y_396_);
v___x_398_ = 8ULL;
v___x_399_ = lean_uint64_shift_left(v___x_397_, v___x_398_);
v___x_400_ = lean_uint64_lor(v___y_395_, v___x_399_);
v___y_278_ = v___x_400_;
goto v___jp_277_;
}
v___jp_401_:
{
uint64_t v___x_404_; uint64_t v___x_405_; uint64_t v___x_406_; uint64_t v___x_407_; 
v___x_404_ = lean_uint8_to_uint64(v___y_403_);
v___x_405_ = 24ULL;
v___x_406_ = lean_uint64_shift_left(v___x_404_, v___x_405_);
v___x_407_ = lean_uint64_lor(v___y_402_, v___x_406_);
v___y_278_ = v___x_407_;
goto v___jp_277_;
}
v___jp_411_:
{
uint64_t v___x_415_; uint64_t v___x_416_; uint64_t v___x_417_; uint64_t v___x_418_; lean_object* v___x_419_; lean_object* v___x_420_; uint8_t v___x_421_; 
v___x_415_ = lean_uint8_to_uint64(v___y_414_);
v___x_416_ = 16ULL;
v___x_417_ = lean_uint64_shift_left(v___x_415_, v___x_416_);
v___x_418_ = lean_uint64_lor(v___y_412_, v___x_417_);
v___x_419_ = lean_unsigned_to_nat(3u);
v___x_420_ = lean_nat_add(v___y_413_, v___x_419_);
lean_dec(v___y_413_);
v___x_421_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_261_, v___x_420_);
if (v___x_421_ == 0)
{
lean_object* v___x_422_; lean_object* v___x_423_; uint8_t v___x_424_; 
lean_dec(v___x_420_);
v___x_422_ = lean_box(v___x_410_);
v___x_423_ = l_outOfBounds___redArg(v___x_422_);
lean_dec(v___x_422_);
v___x_424_ = lean_unbox(v___x_423_);
lean_dec(v___x_423_);
v___y_402_ = v___x_418_;
v___y_403_ = v___x_424_;
goto v___jp_401_;
}
else
{
uint8_t v___x_425_; 
v___x_425_ = lean_byte_array_fget(v_exponents_261_, v___x_420_);
lean_dec(v___x_420_);
v___y_402_ = v___x_418_;
v___y_403_ = v___x_425_;
goto v___jp_401_;
}
}
v___jp_426_:
{
uint64_t v___x_430_; uint64_t v___x_431_; uint64_t v___x_432_; uint64_t v___x_433_; lean_object* v___x_434_; lean_object* v___x_435_; uint8_t v___x_436_; 
v___x_430_ = lean_uint8_to_uint64(v___y_429_);
v___x_431_ = 8ULL;
v___x_432_ = lean_uint64_shift_left(v___x_430_, v___x_431_);
v___x_433_ = lean_uint64_lor(v___y_427_, v___x_432_);
v___x_434_ = lean_unsigned_to_nat(2u);
v___x_435_ = lean_nat_add(v___y_428_, v___x_434_);
v___x_436_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_261_, v___x_435_);
if (v___x_436_ == 0)
{
lean_object* v___x_437_; lean_object* v___x_438_; uint8_t v___x_439_; 
lean_dec(v___x_435_);
v___x_437_ = lean_box(v___x_410_);
v___x_438_ = l_outOfBounds___redArg(v___x_437_);
lean_dec(v___x_437_);
v___x_439_ = lean_unbox(v___x_438_);
lean_dec(v___x_438_);
v___y_412_ = v___x_433_;
v___y_413_ = v___y_428_;
v___y_414_ = v___x_439_;
goto v___jp_411_;
}
else
{
uint8_t v___x_440_; 
v___x_440_ = lean_byte_array_fget(v_exponents_261_, v___x_435_);
lean_dec(v___x_435_);
v___y_412_ = v___x_433_;
v___y_413_ = v___y_428_;
v___y_414_ = v___x_440_;
goto v___jp_411_;
}
}
v___jp_441_:
{
uint64_t v_a_444_; 
v_a_444_ = lean_uint8_to_uint64(v___y_443_);
switch(v_width_260_)
{
case 0:
{
lean_dec(v___y_442_);
v___y_278_ = v_a_444_;
goto v___jp_277_;
}
case 1:
{
lean_object* v___x_445_; uint8_t v___x_446_; 
v___x_445_ = lean_nat_add(v___y_442_, v___x_263_);
lean_dec(v___y_442_);
v___x_446_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_261_, v___x_445_);
if (v___x_446_ == 0)
{
lean_object* v___x_447_; lean_object* v___x_448_; uint8_t v___x_449_; 
lean_dec(v___x_445_);
v___x_447_ = lean_box(v___x_410_);
v___x_448_ = l_outOfBounds___redArg(v___x_447_);
lean_dec(v___x_447_);
v___x_449_ = lean_unbox(v___x_448_);
lean_dec(v___x_448_);
v___y_395_ = v_a_444_;
v___y_396_ = v___x_449_;
goto v___jp_394_;
}
else
{
uint8_t v___x_450_; 
v___x_450_ = lean_byte_array_fget(v_exponents_261_, v___x_445_);
lean_dec(v___x_445_);
v___y_395_ = v_a_444_;
v___y_396_ = v___x_450_;
goto v___jp_394_;
}
}
default: 
{
lean_object* v___x_451_; uint8_t v___x_452_; 
v___x_451_ = lean_nat_add(v___y_442_, v___x_263_);
v___x_452_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_261_, v___x_451_);
if (v___x_452_ == 0)
{
lean_object* v___x_453_; lean_object* v___x_454_; uint8_t v___x_455_; 
lean_dec(v___x_451_);
v___x_453_ = lean_box(v___x_410_);
v___x_454_ = l_outOfBounds___redArg(v___x_453_);
lean_dec(v___x_453_);
v___x_455_ = lean_unbox(v___x_454_);
lean_dec(v___x_454_);
v___y_427_ = v_a_444_;
v___y_428_ = v___y_442_;
v___y_429_ = v___x_455_;
goto v___jp_426_;
}
else
{
uint8_t v___x_456_; 
v___x_456_ = lean_byte_array_fget(v_exponents_261_, v___x_451_);
lean_dec(v___x_451_);
v___y_427_ = v_a_444_;
v___y_428_ = v___y_442_;
v___y_429_ = v___x_456_;
goto v___jp_426_;
}
}
}
}
v___jp_457_:
{
if (v___y_459_ == 0)
{
uint8_t v___x_460_; 
v___x_460_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_261_, v___y_458_);
if (v___x_460_ == 0)
{
lean_object* v___x_461_; lean_object* v___x_462_; uint8_t v___x_463_; 
v___x_461_ = lean_box(v___x_410_);
v___x_462_ = l_outOfBounds___redArg(v___x_461_);
lean_dec(v___x_461_);
v___x_463_ = lean_unbox(v___x_462_);
lean_dec(v___x_462_);
v___y_442_ = v___y_458_;
v___y_443_ = v___x_463_;
goto v___jp_441_;
}
else
{
uint8_t v___x_464_; 
v___x_464_ = lean_byte_array_fget(v_exponents_261_, v___y_458_);
v___y_442_ = v___y_458_;
v___y_443_ = v___x_464_;
goto v___jp_441_;
}
}
else
{
size_t v_pos_465_; uint8_t v___x_466_; uint64_t v_a_467_; 
v_pos_465_ = lean_usize_of_nat(v___y_458_);
lean_dec(v___y_458_);
v___x_466_ = lean_byte_array_uget(v_exponents_261_, v_pos_465_);
v_a_467_ = lean_uint8_to_uint64(v___x_466_);
switch(v_width_260_)
{
case 0:
{
v___y_278_ = v_a_467_;
goto v___jp_277_;
}
case 1:
{
size_t v___x_468_; size_t v___x_469_; uint8_t v___x_470_; uint64_t v___x_471_; uint64_t v___x_472_; uint64_t v___x_473_; uint64_t v___x_474_; 
v___x_468_ = ((size_t)1ULL);
v___x_469_ = lean_usize_add(v_pos_465_, v___x_468_);
v___x_470_ = lean_byte_array_uget(v_exponents_261_, v___x_469_);
v___x_471_ = lean_uint8_to_uint64(v___x_470_);
v___x_472_ = 8ULL;
v___x_473_ = lean_uint64_shift_left(v___x_471_, v___x_472_);
v___x_474_ = lean_uint64_lor(v_a_467_, v___x_473_);
v___y_278_ = v___x_474_;
goto v___jp_277_;
}
default: 
{
size_t v___x_475_; size_t v___x_476_; uint8_t v___x_477_; uint64_t v___x_478_; uint64_t v___x_479_; uint64_t v___x_480_; uint64_t v___x_481_; size_t v___x_482_; size_t v___x_483_; uint8_t v___x_484_; uint64_t v___x_485_; uint64_t v___x_486_; uint64_t v___x_487_; uint64_t v___x_488_; size_t v___x_489_; size_t v___x_490_; uint8_t v___x_491_; uint64_t v___x_492_; uint64_t v___x_493_; uint64_t v___x_494_; uint64_t v___x_495_; 
v___x_475_ = ((size_t)1ULL);
v___x_476_ = lean_usize_add(v_pos_465_, v___x_475_);
v___x_477_ = lean_byte_array_uget(v_exponents_261_, v___x_476_);
v___x_478_ = lean_uint8_to_uint64(v___x_477_);
v___x_479_ = 8ULL;
v___x_480_ = lean_uint64_shift_left(v___x_478_, v___x_479_);
v___x_481_ = lean_uint64_lor(v_a_467_, v___x_480_);
v___x_482_ = ((size_t)2ULL);
v___x_483_ = lean_usize_add(v_pos_465_, v___x_482_);
v___x_484_ = lean_byte_array_uget(v_exponents_261_, v___x_483_);
v___x_485_ = lean_uint8_to_uint64(v___x_484_);
v___x_486_ = 16ULL;
v___x_487_ = lean_uint64_shift_left(v___x_485_, v___x_486_);
v___x_488_ = lean_uint64_lor(v___x_481_, v___x_487_);
v___x_489_ = ((size_t)3ULL);
v___x_490_ = lean_usize_add(v_pos_465_, v___x_489_);
v___x_491_ = lean_byte_array_uget(v_exponents_261_, v___x_490_);
v___x_492_ = lean_uint8_to_uint64(v___x_491_);
v___x_493_ = 24ULL;
v___x_494_ = lean_uint64_shift_left(v___x_492_, v___x_493_);
v___x_495_ = lean_uint64_lor(v___x_488_, v___x_494_);
v___y_278_ = v___x_495_;
goto v___jp_277_;
}
}
}
}
v___jp_496_:
{
lean_object* v_offset_498_; lean_object* v___x_499_; lean_object* v___x_500_; uint8_t v___x_501_; 
v_offset_498_ = lean_nat_mul(v___x_409_, v___y_497_);
lean_dec(v___x_409_);
v___x_499_ = lean_nat_add(v_offset_498_, v___y_497_);
v___x_500_ = lean_byte_array_size(v_exponents_261_);
v___x_501_ = lean_nat_dec_le(v___x_499_, v___x_500_);
if (v___x_501_ == 0)
{
lean_dec(v___x_499_);
v___y_458_ = v_offset_498_;
v___y_459_ = v___x_501_;
goto v___jp_457_;
}
else
{
size_t v___x_502_; lean_object* v___x_503_; uint8_t v___x_504_; 
v___x_502_ = lean_usize_of_nat(v___x_499_);
v___x_503_ = lean_usize_to_nat(v___x_502_);
v___x_504_ = lean_nat_dec_eq(v___x_503_, v___x_499_);
lean_dec(v___x_499_);
lean_dec(v___x_503_);
v___y_458_ = v_offset_498_;
v___y_459_ = v___x_504_;
goto v___jp_457_;
}
}
}
}
v___jp_239_:
{
lean_object* v___x_242_; lean_object* v___x_243_; 
v___x_242_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_242_, 0, v_a_240_);
v___x_243_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_243_, 0, v___x_242_);
lean_ctor_set(v___x_243_, 1, v_snd_241_);
return v___x_243_;
}
v___jp_246_:
{
lean_object* v___x_249_; 
v___x_249_ = lean_nat_add(v_i_237_, v_step_245_);
lean_dec(v_i_237_);
v_b_236_ = v_a_247_;
v_i_237_ = v___x_249_;
v___y_238_ = v_snd_248_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___boxed(lean_object* v_limits_508_, lean_object* v_table_509_, lean_object* v___y_510_, lean_object* v_range_511_, lean_object* v_b_512_, lean_object* v_i_513_, lean_object* v___y_514_){
_start:
{
lean_object* v_res_515_; 
v_res_515_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg(v_limits_508_, v_table_509_, v___y_510_, v_range_511_, v_b_512_, v_i_513_, v___y_514_);
lean_dec_ref(v_range_511_);
lean_dec(v___y_510_);
lean_dec_ref(v_table_509_);
lean_dec_ref(v_limits_508_);
return v_res_515_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2___redArg(lean_object* v_basis_516_, lean_object* v_context_517_, lean_object* v_limits_518_, lean_object* v_table_519_, lean_object* v_range_520_, lean_object* v_b_521_, lean_object* v_i_522_, lean_object* v___y_523_){
_start:
{
lean_object* v_a_525_; lean_object* v_snd_526_; lean_object* v_stop_529_; lean_object* v_step_530_; lean_object* v_a_532_; lean_object* v_snd_533_; lean_object* v___y_537_; lean_object* v___y_538_; lean_object* v___y_539_; uint8_t v___x_557_; 
v_stop_529_ = lean_ctor_get(v_range_520_, 1);
v_step_530_ = lean_ctor_get(v_range_520_, 2);
v___x_557_ = lean_nat_dec_lt(v_i_522_, v_stop_529_);
if (v___x_557_ == 0)
{
lean_object* v___x_558_; lean_object* v___x_559_; 
lean_dec(v_i_522_);
v___x_558_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_558_, 0, v_b_521_);
v___x_559_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_559_, 0, v___x_558_);
lean_ctor_set(v___x_559_, 1, v___y_523_);
return v___x_559_;
}
else
{
lean_object* v___x_560_; lean_object* v___x_561_; lean_object* v_polynomial_562_; lean_object* v_support_563_; lean_object* v___x_565_; uint8_t v_isShared_566_; uint8_t v_isSharedCheck_705_; 
v___x_560_ = lp_Hex_Hex_Groebner_instInhabitedBasisElement_default;
v___x_561_ = lean_array_get_borrowed(v___x_560_, v_basis_516_, v_i_522_);
v_polynomial_562_ = lean_ctor_get(v___x_561_, 0);
lean_inc_ref(v_polynomial_562_);
v_support_563_ = lean_ctor_get(v_polynomial_562_, 0);
v_isSharedCheck_705_ = !lean_is_exclusive(v_polynomial_562_);
if (v_isSharedCheck_705_ == 0)
{
lean_object* v_unused_706_; 
v_unused_706_ = lean_ctor_get(v_polynomial_562_, 1);
lean_dec(v_unused_706_);
v___x_565_ = v_polynomial_562_;
v_isShared_566_ = v_isSharedCheck_705_;
goto v_resetjp_564_;
}
else
{
lean_inc(v_support_563_);
lean_dec(v_polynomial_562_);
v___x_565_ = lean_box(0);
v_isShared_566_ = v_isSharedCheck_705_;
goto v_resetjp_564_;
}
v_resetjp_564_:
{
lean_object* v_node_567_; lean_object* v___x_568_; lean_object* v___x_569_; lean_object* v___x_570_; uint8_t v___x_571_; 
v_node_567_ = lean_unsigned_to_nat(0u);
v___x_568_ = lean_byte_array_size(v_support_563_);
v___x_569_ = lean_unsigned_to_nat(2u);
v___x_570_ = lean_nat_shiftr(v___x_568_, v___x_569_);
v___x_571_ = lean_nat_dec_eq(v___x_570_, v_node_567_);
if (v___x_571_ == 0)
{
lean_object* v___x_572_; lean_object* v___x_573_; lean_object* v___y_575_; uint64_t v___y_634_; uint8_t v___y_635_; lean_object* v___x_664_; uint8_t v___x_665_; 
v___x_572_ = lean_unsigned_to_nat(1u);
v___x_573_ = lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default;
v___x_664_ = lean_unsigned_to_nat(4u);
v___x_665_ = lean_nat_dec_le(v___x_664_, v___x_568_);
if (v___x_665_ == 0)
{
if (v___x_665_ == 0)
{
uint8_t v___x_666_; uint64_t v___y_668_; uint8_t v___y_669_; uint64_t v___y_681_; uint8_t v___y_682_; uint8_t v___y_693_; uint8_t v___x_700_; 
v___x_666_ = 0;
v___x_700_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_563_, v_node_567_);
if (v___x_700_ == 0)
{
lean_object* v___x_701_; lean_object* v___x_702_; uint8_t v___x_703_; 
v___x_701_ = lean_box(v___x_666_);
v___x_702_ = l_outOfBounds___redArg(v___x_701_);
lean_dec(v___x_701_);
v___x_703_ = lean_unbox(v___x_702_);
lean_dec(v___x_702_);
v___y_693_ = v___x_703_;
goto v___jp_692_;
}
else
{
uint8_t v___x_704_; 
v___x_704_ = lean_byte_array_fget(v_support_563_, v_node_567_);
v___y_693_ = v___x_704_;
goto v___jp_692_;
}
v___jp_667_:
{
uint64_t v___x_670_; uint64_t v___x_671_; uint64_t v___x_672_; uint64_t v___x_673_; lean_object* v___x_674_; uint8_t v___x_675_; 
v___x_670_ = lean_uint8_to_uint64(v___y_669_);
v___x_671_ = 16ULL;
v___x_672_ = lean_uint64_shift_left(v___x_670_, v___x_671_);
v___x_673_ = lean_uint64_lor(v___y_668_, v___x_672_);
v___x_674_ = lean_unsigned_to_nat(3u);
v___x_675_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_563_, v___x_674_);
if (v___x_675_ == 0)
{
lean_object* v___x_676_; lean_object* v___x_677_; uint8_t v___x_678_; 
lean_dec_ref(v_support_563_);
v___x_676_ = lean_box(v___x_666_);
v___x_677_ = l_outOfBounds___redArg(v___x_676_);
lean_dec(v___x_676_);
v___x_678_ = lean_unbox(v___x_677_);
lean_dec(v___x_677_);
v___y_634_ = v___x_673_;
v___y_635_ = v___x_678_;
goto v___jp_633_;
}
else
{
uint8_t v___x_679_; 
v___x_679_ = lean_byte_array_fget(v_support_563_, v___x_674_);
lean_dec_ref(v_support_563_);
v___y_634_ = v___x_673_;
v___y_635_ = v___x_679_;
goto v___jp_633_;
}
}
v___jp_680_:
{
uint64_t v___x_683_; uint64_t v___x_684_; uint64_t v___x_685_; uint64_t v___x_686_; uint8_t v___x_687_; 
v___x_683_ = lean_uint8_to_uint64(v___y_682_);
v___x_684_ = 8ULL;
v___x_685_ = lean_uint64_shift_left(v___x_683_, v___x_684_);
v___x_686_ = lean_uint64_lor(v___y_681_, v___x_685_);
v___x_687_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_563_, v___x_569_);
if (v___x_687_ == 0)
{
lean_object* v___x_688_; lean_object* v___x_689_; uint8_t v___x_690_; 
v___x_688_ = lean_box(v___x_666_);
v___x_689_ = l_outOfBounds___redArg(v___x_688_);
lean_dec(v___x_688_);
v___x_690_ = lean_unbox(v___x_689_);
lean_dec(v___x_689_);
v___y_668_ = v___x_686_;
v___y_669_ = v___x_690_;
goto v___jp_667_;
}
else
{
uint8_t v___x_691_; 
v___x_691_ = lean_byte_array_fget(v_support_563_, v___x_569_);
v___y_668_ = v___x_686_;
v___y_669_ = v___x_691_;
goto v___jp_667_;
}
}
v___jp_692_:
{
uint64_t v_a_694_; uint8_t v___x_695_; 
v_a_694_ = lean_uint8_to_uint64(v___y_693_);
v___x_695_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_563_, v___x_572_);
if (v___x_695_ == 0)
{
lean_object* v___x_696_; lean_object* v___x_697_; uint8_t v___x_698_; 
v___x_696_ = lean_box(v___x_666_);
v___x_697_ = l_outOfBounds___redArg(v___x_696_);
lean_dec(v___x_696_);
v___x_698_ = lean_unbox(v___x_697_);
lean_dec(v___x_697_);
v___y_681_ = v_a_694_;
v___y_682_ = v___x_698_;
goto v___jp_680_;
}
else
{
uint8_t v___x_699_; 
v___x_699_ = lean_byte_array_fget(v_support_563_, v___x_572_);
v___y_681_ = v_a_694_;
v___y_682_ = v___x_699_;
goto v___jp_680_;
}
}
}
else
{
goto v___jp_641_;
}
}
else
{
goto v___jp_641_;
}
v___jp_574_:
{
lean_object* v_variables_576_; lean_object* v___x_577_; lean_object* v___x_579_; 
v_variables_576_ = lean_ctor_get(v_context_517_, 0);
lean_inc(v_variables_576_);
v___x_577_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_577_, 0, v_node_567_);
lean_ctor_set(v___x_577_, 1, v_variables_576_);
lean_ctor_set(v___x_577_, 2, v___x_572_);
if (v_isShared_566_ == 0)
{
lean_ctor_set(v___x_565_, 1, v_node_567_);
lean_ctor_set(v___x_565_, 0, v_b_521_);
v___x_579_ = v___x_565_;
goto v_reusejp_578_;
}
else
{
lean_object* v_reuseFailAlloc_632_; 
v_reuseFailAlloc_632_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_632_, 0, v_b_521_);
lean_ctor_set(v_reuseFailAlloc_632_, 1, v_node_567_);
v___x_579_ = v_reuseFailAlloc_632_;
goto v_reusejp_578_;
}
v_reusejp_578_:
{
lean_object* v___x_580_; lean_object* v_fst_581_; 
v___x_580_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg(v_limits_518_, v_table_519_, v___y_575_, v___x_577_, v___x_579_, v_node_567_, v___y_523_);
lean_dec_ref_known(v___x_577_, 3);
lean_dec(v___y_575_);
v_fst_581_ = lean_ctor_get(v___x_580_, 0);
lean_inc(v_fst_581_);
if (lean_obj_tag(v_fst_581_) == 0)
{
lean_object* v_snd_582_; lean_object* v_a_583_; 
lean_dec(v___x_570_);
lean_dec(v_i_522_);
v_snd_582_ = lean_ctor_get(v___x_580_, 1);
lean_inc(v_snd_582_);
lean_dec_ref(v___x_580_);
v_a_583_ = lean_ctor_get(v_fst_581_, 0);
lean_inc(v_a_583_);
lean_dec_ref_known(v_fst_581_, 1);
v_a_525_ = v_a_583_;
v_snd_526_ = v_snd_582_;
goto v___jp_524_;
}
else
{
lean_object* v_snd_584_; lean_object* v_statistics_585_; lean_object* v_a_586_; lean_object* v_table_587_; lean_object* v_work_588_; lean_object* v_allocatedBytes_589_; lean_object* v_pairs_590_; lean_object* v_rounds_591_; lean_object* v_matrixEntries_592_; lean_object* v_matrixRows_593_; lean_object* v_matrixCalls_594_; lean_object* v_peakMatrixRows_595_; lean_object* v_peakMatrixEntries_596_; lean_object* v_largestBatch_597_; lean_object* v_productPairs_598_; lean_object* v_chainPairs_599_; lean_object* v_gmPairs_600_; lean_object* v___x_602_; uint8_t v_isShared_603_; uint8_t v_isSharedCheck_631_; 
v_snd_584_ = lean_ctor_get(v___x_580_, 1);
lean_inc(v_snd_584_);
lean_dec_ref(v___x_580_);
v_statistics_585_ = lean_ctor_get(v_snd_584_, 1);
lean_inc_ref(v_statistics_585_);
v_a_586_ = lean_ctor_get(v_fst_581_, 0);
lean_inc(v_a_586_);
lean_dec_ref_known(v_fst_581_, 1);
v_table_587_ = lean_ctor_get(v_snd_584_, 0);
v_work_588_ = lean_ctor_get(v_statistics_585_, 0);
v_allocatedBytes_589_ = lean_ctor_get(v_statistics_585_, 1);
v_pairs_590_ = lean_ctor_get(v_statistics_585_, 2);
v_rounds_591_ = lean_ctor_get(v_statistics_585_, 3);
v_matrixEntries_592_ = lean_ctor_get(v_statistics_585_, 4);
v_matrixRows_593_ = lean_ctor_get(v_statistics_585_, 5);
v_matrixCalls_594_ = lean_ctor_get(v_statistics_585_, 6);
v_peakMatrixRows_595_ = lean_ctor_get(v_statistics_585_, 7);
v_peakMatrixEntries_596_ = lean_ctor_get(v_statistics_585_, 8);
v_largestBatch_597_ = lean_ctor_get(v_statistics_585_, 9);
v_productPairs_598_ = lean_ctor_get(v_statistics_585_, 10);
v_chainPairs_599_ = lean_ctor_get(v_statistics_585_, 11);
v_gmPairs_600_ = lean_ctor_get(v_statistics_585_, 12);
v_isSharedCheck_631_ = !lean_is_exclusive(v_statistics_585_);
if (v_isSharedCheck_631_ == 0)
{
v___x_602_ = v_statistics_585_;
v_isShared_603_ = v_isSharedCheck_631_;
goto v_resetjp_601_;
}
else
{
lean_inc(v_gmPairs_600_);
lean_inc(v_chainPairs_599_);
lean_inc(v_productPairs_598_);
lean_inc(v_largestBatch_597_);
lean_inc(v_peakMatrixEntries_596_);
lean_inc(v_peakMatrixRows_595_);
lean_inc(v_matrixCalls_594_);
lean_inc(v_matrixRows_593_);
lean_inc(v_matrixEntries_592_);
lean_inc(v_rounds_591_);
lean_inc(v_pairs_590_);
lean_inc(v_allocatedBytes_589_);
lean_inc(v_work_588_);
lean_dec(v_statistics_585_);
v___x_602_ = lean_box(0);
v_isShared_603_ = v_isSharedCheck_631_;
goto v_resetjp_601_;
}
v_resetjp_601_:
{
lean_object* v_work_604_; lean_object* v_work_605_; uint8_t v___x_606_; 
v_work_604_ = lean_ctor_get(v_limits_518_, 0);
v_work_605_ = lean_nat_add(v_work_588_, v___x_572_);
lean_dec(v_work_588_);
v___x_606_ = lean_nat_dec_lt(v_work_604_, v_work_605_);
if (v___x_606_ == 0)
{
lean_object* v___x_608_; uint8_t v_isShared_609_; uint8_t v_isSharedCheck_627_; 
lean_inc_ref(v_table_587_);
v_isSharedCheck_627_ = !lean_is_exclusive(v_snd_584_);
if (v_isSharedCheck_627_ == 0)
{
lean_object* v_unused_628_; lean_object* v_unused_629_; 
v_unused_628_ = lean_ctor_get(v_snd_584_, 1);
lean_dec(v_unused_628_);
v_unused_629_ = lean_ctor_get(v_snd_584_, 0);
lean_dec(v_unused_629_);
v___x_608_ = v_snd_584_;
v_isShared_609_ = v_isSharedCheck_627_;
goto v_resetjp_607_;
}
else
{
lean_dec(v_snd_584_);
v___x_608_ = lean_box(0);
v_isShared_609_ = v_isSharedCheck_627_;
goto v_resetjp_607_;
}
v_resetjp_607_:
{
lean_object* v_fst_610_; lean_object* v_snd_611_; lean_object* v___x_612_; lean_object* v_reducer_613_; lean_object* v___x_615_; 
v_fst_610_ = lean_ctor_get(v_a_586_, 0);
lean_inc(v_fst_610_);
v_snd_611_ = lean_ctor_get(v_a_586_, 1);
lean_inc(v_snd_611_);
lean_dec(v_a_586_);
v___x_612_ = lean_array_get_borrowed(v___x_573_, v_fst_610_, v_snd_611_);
v_reducer_613_ = lean_ctor_get(v___x_612_, 1);
if (v_isShared_603_ == 0)
{
lean_ctor_set(v___x_602_, 0, v_work_605_);
v___x_615_ = v___x_602_;
goto v_reusejp_614_;
}
else
{
lean_object* v_reuseFailAlloc_626_; 
v_reuseFailAlloc_626_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_626_, 0, v_work_605_);
lean_ctor_set(v_reuseFailAlloc_626_, 1, v_allocatedBytes_589_);
lean_ctor_set(v_reuseFailAlloc_626_, 2, v_pairs_590_);
lean_ctor_set(v_reuseFailAlloc_626_, 3, v_rounds_591_);
lean_ctor_set(v_reuseFailAlloc_626_, 4, v_matrixEntries_592_);
lean_ctor_set(v_reuseFailAlloc_626_, 5, v_matrixRows_593_);
lean_ctor_set(v_reuseFailAlloc_626_, 6, v_matrixCalls_594_);
lean_ctor_set(v_reuseFailAlloc_626_, 7, v_peakMatrixRows_595_);
lean_ctor_set(v_reuseFailAlloc_626_, 8, v_peakMatrixEntries_596_);
lean_ctor_set(v_reuseFailAlloc_626_, 9, v_largestBatch_597_);
lean_ctor_set(v_reuseFailAlloc_626_, 10, v_productPairs_598_);
lean_ctor_set(v_reuseFailAlloc_626_, 11, v_chainPairs_599_);
lean_ctor_set(v_reuseFailAlloc_626_, 12, v_gmPairs_600_);
v___x_615_ = v_reuseFailAlloc_626_;
goto v_reusejp_614_;
}
v_reusejp_614_:
{
lean_object* v___x_617_; 
if (v_isShared_609_ == 0)
{
lean_ctor_set(v___x_608_, 1, v___x_615_);
v___x_617_ = v___x_608_;
goto v_reusejp_616_;
}
else
{
lean_object* v_reuseFailAlloc_625_; 
v_reuseFailAlloc_625_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_625_, 0, v_table_587_);
lean_ctor_set(v_reuseFailAlloc_625_, 1, v___x_615_);
v___x_617_ = v_reuseFailAlloc_625_;
goto v_reusejp_616_;
}
v_reusejp_616_:
{
if (lean_obj_tag(v_reducer_613_) == 0)
{
lean_dec(v___x_570_);
v___y_537_ = v_snd_611_;
v___y_538_ = v_fst_610_;
v___y_539_ = v___x_617_;
goto v___jp_536_;
}
else
{
if (v___x_571_ == 0)
{
lean_object* v_val_618_; lean_object* v___x_619_; lean_object* v_polynomial_620_; lean_object* v_support_621_; lean_object* v___x_622_; lean_object* v___x_623_; uint8_t v___x_624_; 
v_val_618_ = lean_ctor_get(v_reducer_613_, 0);
v___x_619_ = lean_array_get_borrowed(v___x_560_, v_basis_516_, v_val_618_);
v_polynomial_620_ = lean_ctor_get(v___x_619_, 0);
v_support_621_ = lean_ctor_get(v_polynomial_620_, 0);
v___x_622_ = lean_byte_array_size(v_support_621_);
v___x_623_ = lean_nat_shiftr(v___x_622_, v___x_569_);
v___x_624_ = lean_nat_dec_lt(v___x_570_, v___x_623_);
lean_dec(v___x_623_);
lean_dec(v___x_570_);
if (v___x_624_ == 0)
{
lean_dec(v_snd_611_);
v_a_532_ = v_fst_610_;
v_snd_533_ = v___x_617_;
goto v___jp_531_;
}
else
{
v___y_537_ = v_snd_611_;
v___y_538_ = v_fst_610_;
v___y_539_ = v___x_617_;
goto v___jp_536_;
}
}
else
{
lean_dec(v___x_570_);
v___y_537_ = v_snd_611_;
v___y_538_ = v_fst_610_;
v___y_539_ = v___x_617_;
goto v___jp_536_;
}
}
}
}
}
}
else
{
lean_object* v___x_630_; 
lean_dec(v_work_605_);
lean_del_object(v___x_602_);
lean_dec(v_gmPairs_600_);
lean_dec(v_chainPairs_599_);
lean_dec(v_productPairs_598_);
lean_dec(v_largestBatch_597_);
lean_dec(v_peakMatrixEntries_596_);
lean_dec(v_peakMatrixRows_595_);
lean_dec(v_matrixCalls_594_);
lean_dec(v_matrixRows_593_);
lean_dec(v_matrixEntries_592_);
lean_dec(v_rounds_591_);
lean_dec(v_pairs_590_);
lean_dec(v_allocatedBytes_589_);
lean_dec(v_a_586_);
lean_dec(v___x_570_);
lean_dec(v_i_522_);
v___x_630_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__1));
v_a_525_ = v___x_630_;
v_snd_526_ = v_snd_584_;
goto v___jp_524_;
}
}
}
}
}
v___jp_633_:
{
uint64_t v___x_636_; uint64_t v___x_637_; uint64_t v___x_638_; uint64_t v___x_639_; lean_object* v___x_640_; 
v___x_636_ = lean_uint8_to_uint64(v___y_635_);
v___x_637_ = 24ULL;
v___x_638_ = lean_uint64_shift_left(v___x_636_, v___x_637_);
v___x_639_ = lean_uint64_lor(v___y_634_, v___x_638_);
v___x_640_ = lean_uint64_to_nat(v___x_639_);
v___y_575_ = v___x_640_;
goto v___jp_574_;
}
v___jp_641_:
{
size_t v_pos_642_; uint8_t v___x_643_; uint64_t v_a_644_; size_t v___x_645_; uint8_t v___x_646_; uint64_t v___x_647_; uint64_t v___x_648_; uint64_t v___x_649_; uint64_t v___x_650_; size_t v___x_651_; uint8_t v___x_652_; uint64_t v___x_653_; uint64_t v___x_654_; uint64_t v___x_655_; uint64_t v___x_656_; size_t v___x_657_; uint8_t v___x_658_; uint64_t v___x_659_; uint64_t v___x_660_; uint64_t v___x_661_; uint64_t v___x_662_; lean_object* v___x_663_; 
v_pos_642_ = ((size_t)0ULL);
v___x_643_ = lean_byte_array_uget(v_support_563_, v_pos_642_);
v_a_644_ = lean_uint8_to_uint64(v___x_643_);
v___x_645_ = ((size_t)1ULL);
v___x_646_ = lean_byte_array_uget(v_support_563_, v___x_645_);
v___x_647_ = lean_uint8_to_uint64(v___x_646_);
v___x_648_ = 8ULL;
v___x_649_ = lean_uint64_shift_left(v___x_647_, v___x_648_);
v___x_650_ = lean_uint64_lor(v_a_644_, v___x_649_);
v___x_651_ = ((size_t)2ULL);
v___x_652_ = lean_byte_array_uget(v_support_563_, v___x_651_);
v___x_653_ = lean_uint8_to_uint64(v___x_652_);
v___x_654_ = 16ULL;
v___x_655_ = lean_uint64_shift_left(v___x_653_, v___x_654_);
v___x_656_ = lean_uint64_lor(v___x_650_, v___x_655_);
v___x_657_ = ((size_t)3ULL);
v___x_658_ = lean_byte_array_uget(v_support_563_, v___x_657_);
lean_dec_ref(v_support_563_);
v___x_659_ = lean_uint8_to_uint64(v___x_658_);
v___x_660_ = 24ULL;
v___x_661_ = lean_uint64_shift_left(v___x_659_, v___x_660_);
v___x_662_ = lean_uint64_lor(v___x_656_, v___x_661_);
v___x_663_ = lean_uint64_to_nat(v___x_662_);
v___y_575_ = v___x_663_;
goto v___jp_574_;
}
}
else
{
lean_dec(v___x_570_);
lean_del_object(v___x_565_);
lean_dec_ref(v_support_563_);
v_a_532_ = v_b_521_;
v_snd_533_ = v___y_523_;
goto v___jp_531_;
}
}
}
v___jp_524_:
{
lean_object* v___x_527_; lean_object* v___x_528_; 
v___x_527_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_527_, 0, v_a_525_);
v___x_528_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_528_, 0, v___x_527_);
lean_ctor_set(v___x_528_, 1, v_snd_526_);
return v___x_528_;
}
v___jp_531_:
{
lean_object* v___x_534_; 
v___x_534_ = lean_nat_add(v_i_522_, v_step_530_);
lean_dec(v_i_522_);
v_b_521_ = v_a_532_;
v_i_522_ = v___x_534_;
v___y_523_ = v_snd_533_;
goto _start;
}
v___jp_536_:
{
lean_object* v___x_540_; uint8_t v___x_541_; 
v___x_540_ = lean_array_get_size(v___y_538_);
v___x_541_ = lean_nat_dec_lt(v___y_537_, v___x_540_);
if (v___x_541_ == 0)
{
lean_dec(v___y_537_);
v_a_532_ = v___y_538_;
v_snd_533_ = v___y_539_;
goto v___jp_531_;
}
else
{
lean_object* v_v_542_; lean_object* v_edges_543_; lean_object* v_depth_544_; lean_object* v___x_546_; uint8_t v_isShared_547_; uint8_t v_isSharedCheck_555_; 
v_v_542_ = lean_array_fget(v___y_538_, v___y_537_);
v_edges_543_ = lean_ctor_get(v_v_542_, 0);
v_depth_544_ = lean_ctor_get(v_v_542_, 2);
v_isSharedCheck_555_ = !lean_is_exclusive(v_v_542_);
if (v_isSharedCheck_555_ == 0)
{
lean_object* v_unused_556_; 
v_unused_556_ = lean_ctor_get(v_v_542_, 1);
lean_dec(v_unused_556_);
v___x_546_ = v_v_542_;
v_isShared_547_ = v_isSharedCheck_555_;
goto v_resetjp_545_;
}
else
{
lean_inc(v_depth_544_);
lean_inc(v_edges_543_);
lean_dec(v_v_542_);
v___x_546_ = lean_box(0);
v_isShared_547_ = v_isSharedCheck_555_;
goto v_resetjp_545_;
}
v_resetjp_545_:
{
lean_object* v___x_548_; lean_object* v_xs_x27_549_; lean_object* v___x_550_; lean_object* v___x_552_; 
v___x_548_ = lean_box(0);
v_xs_x27_549_ = lean_array_fset(v___y_538_, v___y_537_, v___x_548_);
lean_inc(v_i_522_);
v___x_550_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_550_, 0, v_i_522_);
if (v_isShared_547_ == 0)
{
lean_ctor_set(v___x_546_, 1, v___x_550_);
v___x_552_ = v___x_546_;
goto v_reusejp_551_;
}
else
{
lean_object* v_reuseFailAlloc_554_; 
v_reuseFailAlloc_554_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_554_, 0, v_edges_543_);
lean_ctor_set(v_reuseFailAlloc_554_, 1, v___x_550_);
lean_ctor_set(v_reuseFailAlloc_554_, 2, v_depth_544_);
v___x_552_ = v_reuseFailAlloc_554_;
goto v_reusejp_551_;
}
v_reusejp_551_:
{
lean_object* v___x_553_; 
v___x_553_ = lean_array_fset(v_xs_x27_549_, v___y_537_, v___x_552_);
lean_dec(v___y_537_);
v_a_532_ = v___x_553_;
v_snd_533_ = v___y_539_;
goto v___jp_531_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2___redArg___boxed(lean_object* v_basis_707_, lean_object* v_context_708_, lean_object* v_limits_709_, lean_object* v_table_710_, lean_object* v_range_711_, lean_object* v_b_712_, lean_object* v_i_713_, lean_object* v___y_714_){
_start:
{
lean_object* v_res_715_; 
v_res_715_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2___redArg(v_basis_707_, v_context_708_, v_limits_709_, v_table_710_, v_range_711_, v_b_712_, v_i_713_, v___y_714_);
lean_dec_ref(v_range_711_);
lean_dec_ref(v_table_710_);
lean_dec_ref(v_limits_709_);
lean_dec_ref(v_context_708_);
lean_dec_ref(v_basis_707_);
return v_res_715_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2___redArg(lean_object* v_basis_716_, lean_object* v_limits_717_, lean_object* v_table_718_, lean_object* v_context_719_, lean_object* v_range_720_, lean_object* v_b_721_, lean_object* v_i_722_, lean_object* v___y_723_){
_start:
{
lean_object* v_a_725_; lean_object* v_snd_726_; lean_object* v_stop_729_; lean_object* v_step_730_; lean_object* v_a_732_; lean_object* v_snd_733_; lean_object* v___y_737_; lean_object* v___y_738_; lean_object* v___y_739_; uint8_t v___x_757_; 
v_stop_729_ = lean_ctor_get(v_range_720_, 1);
v_step_730_ = lean_ctor_get(v_range_720_, 2);
v___x_757_ = lean_nat_dec_lt(v_i_722_, v_stop_729_);
if (v___x_757_ == 0)
{
lean_object* v___x_758_; lean_object* v___x_759_; 
lean_dec(v_i_722_);
v___x_758_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_758_, 0, v_b_721_);
v___x_759_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_759_, 0, v___x_758_);
lean_ctor_set(v___x_759_, 1, v___y_723_);
return v___x_759_;
}
else
{
lean_object* v___x_760_; lean_object* v___x_761_; lean_object* v_polynomial_762_; lean_object* v_support_763_; lean_object* v___x_765_; uint8_t v_isShared_766_; uint8_t v_isSharedCheck_905_; 
v___x_760_ = lp_Hex_Hex_Groebner_instInhabitedBasisElement_default;
v___x_761_ = lean_array_get_borrowed(v___x_760_, v_basis_716_, v_i_722_);
v_polynomial_762_ = lean_ctor_get(v___x_761_, 0);
lean_inc_ref(v_polynomial_762_);
v_support_763_ = lean_ctor_get(v_polynomial_762_, 0);
v_isSharedCheck_905_ = !lean_is_exclusive(v_polynomial_762_);
if (v_isSharedCheck_905_ == 0)
{
lean_object* v_unused_906_; 
v_unused_906_ = lean_ctor_get(v_polynomial_762_, 1);
lean_dec(v_unused_906_);
v___x_765_ = v_polynomial_762_;
v_isShared_766_ = v_isSharedCheck_905_;
goto v_resetjp_764_;
}
else
{
lean_inc(v_support_763_);
lean_dec(v_polynomial_762_);
v___x_765_ = lean_box(0);
v_isShared_766_ = v_isSharedCheck_905_;
goto v_resetjp_764_;
}
v_resetjp_764_:
{
lean_object* v_node_767_; lean_object* v___x_768_; lean_object* v___x_769_; lean_object* v___x_770_; uint8_t v___x_771_; 
v_node_767_ = lean_unsigned_to_nat(0u);
v___x_768_ = lean_byte_array_size(v_support_763_);
v___x_769_ = lean_unsigned_to_nat(2u);
v___x_770_ = lean_nat_shiftr(v___x_768_, v___x_769_);
v___x_771_ = lean_nat_dec_eq(v___x_770_, v_node_767_);
if (v___x_771_ == 0)
{
lean_object* v___x_772_; lean_object* v___x_773_; lean_object* v___y_775_; uint64_t v___y_834_; uint8_t v___y_835_; lean_object* v___x_864_; uint8_t v___x_865_; 
v___x_772_ = lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default;
v___x_773_ = lean_unsigned_to_nat(1u);
v___x_864_ = lean_unsigned_to_nat(4u);
v___x_865_ = lean_nat_dec_le(v___x_864_, v___x_768_);
if (v___x_865_ == 0)
{
if (v___x_865_ == 0)
{
uint8_t v___x_866_; uint64_t v___y_868_; uint8_t v___y_869_; uint64_t v___y_881_; uint8_t v___y_882_; uint8_t v___y_893_; uint8_t v___x_900_; 
v___x_866_ = 0;
v___x_900_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_763_, v_node_767_);
if (v___x_900_ == 0)
{
lean_object* v___x_901_; lean_object* v___x_902_; uint8_t v___x_903_; 
v___x_901_ = lean_box(v___x_866_);
v___x_902_ = l_outOfBounds___redArg(v___x_901_);
lean_dec(v___x_901_);
v___x_903_ = lean_unbox(v___x_902_);
lean_dec(v___x_902_);
v___y_893_ = v___x_903_;
goto v___jp_892_;
}
else
{
uint8_t v___x_904_; 
v___x_904_ = lean_byte_array_fget(v_support_763_, v_node_767_);
v___y_893_ = v___x_904_;
goto v___jp_892_;
}
v___jp_867_:
{
uint64_t v___x_870_; uint64_t v___x_871_; uint64_t v___x_872_; uint64_t v___x_873_; lean_object* v___x_874_; uint8_t v___x_875_; 
v___x_870_ = lean_uint8_to_uint64(v___y_869_);
v___x_871_ = 16ULL;
v___x_872_ = lean_uint64_shift_left(v___x_870_, v___x_871_);
v___x_873_ = lean_uint64_lor(v___y_868_, v___x_872_);
v___x_874_ = lean_unsigned_to_nat(3u);
v___x_875_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_763_, v___x_874_);
if (v___x_875_ == 0)
{
lean_object* v___x_876_; lean_object* v___x_877_; uint8_t v___x_878_; 
lean_dec_ref(v_support_763_);
v___x_876_ = lean_box(v___x_866_);
v___x_877_ = l_outOfBounds___redArg(v___x_876_);
lean_dec(v___x_876_);
v___x_878_ = lean_unbox(v___x_877_);
lean_dec(v___x_877_);
v___y_834_ = v___x_873_;
v___y_835_ = v___x_878_;
goto v___jp_833_;
}
else
{
uint8_t v___x_879_; 
v___x_879_ = lean_byte_array_fget(v_support_763_, v___x_874_);
lean_dec_ref(v_support_763_);
v___y_834_ = v___x_873_;
v___y_835_ = v___x_879_;
goto v___jp_833_;
}
}
v___jp_880_:
{
uint64_t v___x_883_; uint64_t v___x_884_; uint64_t v___x_885_; uint64_t v___x_886_; uint8_t v___x_887_; 
v___x_883_ = lean_uint8_to_uint64(v___y_882_);
v___x_884_ = 8ULL;
v___x_885_ = lean_uint64_shift_left(v___x_883_, v___x_884_);
v___x_886_ = lean_uint64_lor(v___y_881_, v___x_885_);
v___x_887_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_763_, v___x_769_);
if (v___x_887_ == 0)
{
lean_object* v___x_888_; lean_object* v___x_889_; uint8_t v___x_890_; 
v___x_888_ = lean_box(v___x_866_);
v___x_889_ = l_outOfBounds___redArg(v___x_888_);
lean_dec(v___x_888_);
v___x_890_ = lean_unbox(v___x_889_);
lean_dec(v___x_889_);
v___y_868_ = v___x_886_;
v___y_869_ = v___x_890_;
goto v___jp_867_;
}
else
{
uint8_t v___x_891_; 
v___x_891_ = lean_byte_array_fget(v_support_763_, v___x_769_);
v___y_868_ = v___x_886_;
v___y_869_ = v___x_891_;
goto v___jp_867_;
}
}
v___jp_892_:
{
uint64_t v_a_894_; uint8_t v___x_895_; 
v_a_894_ = lean_uint8_to_uint64(v___y_893_);
v___x_895_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_763_, v___x_773_);
if (v___x_895_ == 0)
{
lean_object* v___x_896_; lean_object* v___x_897_; uint8_t v___x_898_; 
v___x_896_ = lean_box(v___x_866_);
v___x_897_ = l_outOfBounds___redArg(v___x_896_);
lean_dec(v___x_896_);
v___x_898_ = lean_unbox(v___x_897_);
lean_dec(v___x_897_);
v___y_881_ = v_a_894_;
v___y_882_ = v___x_898_;
goto v___jp_880_;
}
else
{
uint8_t v___x_899_; 
v___x_899_ = lean_byte_array_fget(v_support_763_, v___x_773_);
v___y_881_ = v_a_894_;
v___y_882_ = v___x_899_;
goto v___jp_880_;
}
}
}
else
{
goto v___jp_841_;
}
}
else
{
goto v___jp_841_;
}
v___jp_774_:
{
lean_object* v_variables_776_; lean_object* v___x_777_; lean_object* v___x_779_; 
v_variables_776_ = lean_ctor_get(v_context_719_, 0);
lean_inc(v_variables_776_);
v___x_777_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_777_, 0, v_node_767_);
lean_ctor_set(v___x_777_, 1, v_variables_776_);
lean_ctor_set(v___x_777_, 2, v___x_773_);
if (v_isShared_766_ == 0)
{
lean_ctor_set(v___x_765_, 1, v_node_767_);
lean_ctor_set(v___x_765_, 0, v_b_721_);
v___x_779_ = v___x_765_;
goto v_reusejp_778_;
}
else
{
lean_object* v_reuseFailAlloc_832_; 
v_reuseFailAlloc_832_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_832_, 0, v_b_721_);
lean_ctor_set(v_reuseFailAlloc_832_, 1, v_node_767_);
v___x_779_ = v_reuseFailAlloc_832_;
goto v_reusejp_778_;
}
v_reusejp_778_:
{
lean_object* v___x_780_; lean_object* v_fst_781_; 
v___x_780_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg(v_limits_717_, v_table_718_, v___y_775_, v___x_777_, v___x_779_, v_node_767_, v___y_723_);
lean_dec_ref_known(v___x_777_, 3);
lean_dec(v___y_775_);
v_fst_781_ = lean_ctor_get(v___x_780_, 0);
lean_inc(v_fst_781_);
if (lean_obj_tag(v_fst_781_) == 0)
{
lean_object* v_snd_782_; lean_object* v_a_783_; 
lean_dec(v___x_770_);
lean_dec(v_i_722_);
v_snd_782_ = lean_ctor_get(v___x_780_, 1);
lean_inc(v_snd_782_);
lean_dec_ref(v___x_780_);
v_a_783_ = lean_ctor_get(v_fst_781_, 0);
lean_inc(v_a_783_);
lean_dec_ref_known(v_fst_781_, 1);
v_a_725_ = v_a_783_;
v_snd_726_ = v_snd_782_;
goto v___jp_724_;
}
else
{
lean_object* v_snd_784_; lean_object* v_statistics_785_; lean_object* v_a_786_; lean_object* v_table_787_; lean_object* v_work_788_; lean_object* v_allocatedBytes_789_; lean_object* v_pairs_790_; lean_object* v_rounds_791_; lean_object* v_matrixEntries_792_; lean_object* v_matrixRows_793_; lean_object* v_matrixCalls_794_; lean_object* v_peakMatrixRows_795_; lean_object* v_peakMatrixEntries_796_; lean_object* v_largestBatch_797_; lean_object* v_productPairs_798_; lean_object* v_chainPairs_799_; lean_object* v_gmPairs_800_; lean_object* v___x_802_; uint8_t v_isShared_803_; uint8_t v_isSharedCheck_831_; 
v_snd_784_ = lean_ctor_get(v___x_780_, 1);
lean_inc(v_snd_784_);
lean_dec_ref(v___x_780_);
v_statistics_785_ = lean_ctor_get(v_snd_784_, 1);
lean_inc_ref(v_statistics_785_);
v_a_786_ = lean_ctor_get(v_fst_781_, 0);
lean_inc(v_a_786_);
lean_dec_ref_known(v_fst_781_, 1);
v_table_787_ = lean_ctor_get(v_snd_784_, 0);
v_work_788_ = lean_ctor_get(v_statistics_785_, 0);
v_allocatedBytes_789_ = lean_ctor_get(v_statistics_785_, 1);
v_pairs_790_ = lean_ctor_get(v_statistics_785_, 2);
v_rounds_791_ = lean_ctor_get(v_statistics_785_, 3);
v_matrixEntries_792_ = lean_ctor_get(v_statistics_785_, 4);
v_matrixRows_793_ = lean_ctor_get(v_statistics_785_, 5);
v_matrixCalls_794_ = lean_ctor_get(v_statistics_785_, 6);
v_peakMatrixRows_795_ = lean_ctor_get(v_statistics_785_, 7);
v_peakMatrixEntries_796_ = lean_ctor_get(v_statistics_785_, 8);
v_largestBatch_797_ = lean_ctor_get(v_statistics_785_, 9);
v_productPairs_798_ = lean_ctor_get(v_statistics_785_, 10);
v_chainPairs_799_ = lean_ctor_get(v_statistics_785_, 11);
v_gmPairs_800_ = lean_ctor_get(v_statistics_785_, 12);
v_isSharedCheck_831_ = !lean_is_exclusive(v_statistics_785_);
if (v_isSharedCheck_831_ == 0)
{
v___x_802_ = v_statistics_785_;
v_isShared_803_ = v_isSharedCheck_831_;
goto v_resetjp_801_;
}
else
{
lean_inc(v_gmPairs_800_);
lean_inc(v_chainPairs_799_);
lean_inc(v_productPairs_798_);
lean_inc(v_largestBatch_797_);
lean_inc(v_peakMatrixEntries_796_);
lean_inc(v_peakMatrixRows_795_);
lean_inc(v_matrixCalls_794_);
lean_inc(v_matrixRows_793_);
lean_inc(v_matrixEntries_792_);
lean_inc(v_rounds_791_);
lean_inc(v_pairs_790_);
lean_inc(v_allocatedBytes_789_);
lean_inc(v_work_788_);
lean_dec(v_statistics_785_);
v___x_802_ = lean_box(0);
v_isShared_803_ = v_isSharedCheck_831_;
goto v_resetjp_801_;
}
v_resetjp_801_:
{
lean_object* v_work_804_; lean_object* v_work_805_; uint8_t v___x_806_; 
v_work_804_ = lean_ctor_get(v_limits_717_, 0);
v_work_805_ = lean_nat_add(v_work_788_, v___x_773_);
lean_dec(v_work_788_);
v___x_806_ = lean_nat_dec_lt(v_work_804_, v_work_805_);
if (v___x_806_ == 0)
{
lean_object* v___x_808_; uint8_t v_isShared_809_; uint8_t v_isSharedCheck_827_; 
lean_inc_ref(v_table_787_);
v_isSharedCheck_827_ = !lean_is_exclusive(v_snd_784_);
if (v_isSharedCheck_827_ == 0)
{
lean_object* v_unused_828_; lean_object* v_unused_829_; 
v_unused_828_ = lean_ctor_get(v_snd_784_, 1);
lean_dec(v_unused_828_);
v_unused_829_ = lean_ctor_get(v_snd_784_, 0);
lean_dec(v_unused_829_);
v___x_808_ = v_snd_784_;
v_isShared_809_ = v_isSharedCheck_827_;
goto v_resetjp_807_;
}
else
{
lean_dec(v_snd_784_);
v___x_808_ = lean_box(0);
v_isShared_809_ = v_isSharedCheck_827_;
goto v_resetjp_807_;
}
v_resetjp_807_:
{
lean_object* v_fst_810_; lean_object* v_snd_811_; lean_object* v___x_812_; lean_object* v_reducer_813_; lean_object* v___x_815_; 
v_fst_810_ = lean_ctor_get(v_a_786_, 0);
lean_inc(v_fst_810_);
v_snd_811_ = lean_ctor_get(v_a_786_, 1);
lean_inc(v_snd_811_);
lean_dec(v_a_786_);
v___x_812_ = lean_array_get_borrowed(v___x_772_, v_fst_810_, v_snd_811_);
v_reducer_813_ = lean_ctor_get(v___x_812_, 1);
if (v_isShared_803_ == 0)
{
lean_ctor_set(v___x_802_, 0, v_work_805_);
v___x_815_ = v___x_802_;
goto v_reusejp_814_;
}
else
{
lean_object* v_reuseFailAlloc_826_; 
v_reuseFailAlloc_826_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_826_, 0, v_work_805_);
lean_ctor_set(v_reuseFailAlloc_826_, 1, v_allocatedBytes_789_);
lean_ctor_set(v_reuseFailAlloc_826_, 2, v_pairs_790_);
lean_ctor_set(v_reuseFailAlloc_826_, 3, v_rounds_791_);
lean_ctor_set(v_reuseFailAlloc_826_, 4, v_matrixEntries_792_);
lean_ctor_set(v_reuseFailAlloc_826_, 5, v_matrixRows_793_);
lean_ctor_set(v_reuseFailAlloc_826_, 6, v_matrixCalls_794_);
lean_ctor_set(v_reuseFailAlloc_826_, 7, v_peakMatrixRows_795_);
lean_ctor_set(v_reuseFailAlloc_826_, 8, v_peakMatrixEntries_796_);
lean_ctor_set(v_reuseFailAlloc_826_, 9, v_largestBatch_797_);
lean_ctor_set(v_reuseFailAlloc_826_, 10, v_productPairs_798_);
lean_ctor_set(v_reuseFailAlloc_826_, 11, v_chainPairs_799_);
lean_ctor_set(v_reuseFailAlloc_826_, 12, v_gmPairs_800_);
v___x_815_ = v_reuseFailAlloc_826_;
goto v_reusejp_814_;
}
v_reusejp_814_:
{
lean_object* v___x_817_; 
if (v_isShared_809_ == 0)
{
lean_ctor_set(v___x_808_, 1, v___x_815_);
v___x_817_ = v___x_808_;
goto v_reusejp_816_;
}
else
{
lean_object* v_reuseFailAlloc_825_; 
v_reuseFailAlloc_825_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_825_, 0, v_table_787_);
lean_ctor_set(v_reuseFailAlloc_825_, 1, v___x_815_);
v___x_817_ = v_reuseFailAlloc_825_;
goto v_reusejp_816_;
}
v_reusejp_816_:
{
if (lean_obj_tag(v_reducer_813_) == 0)
{
lean_dec(v___x_770_);
v___y_737_ = v_fst_810_;
v___y_738_ = v___x_817_;
v___y_739_ = v_snd_811_;
goto v___jp_736_;
}
else
{
if (v___x_771_ == 0)
{
lean_object* v_val_818_; lean_object* v___x_819_; lean_object* v_polynomial_820_; lean_object* v_support_821_; lean_object* v___x_822_; lean_object* v___x_823_; uint8_t v___x_824_; 
v_val_818_ = lean_ctor_get(v_reducer_813_, 0);
v___x_819_ = lean_array_get_borrowed(v___x_760_, v_basis_716_, v_val_818_);
v_polynomial_820_ = lean_ctor_get(v___x_819_, 0);
v_support_821_ = lean_ctor_get(v_polynomial_820_, 0);
v___x_822_ = lean_byte_array_size(v_support_821_);
v___x_823_ = lean_nat_shiftr(v___x_822_, v___x_769_);
v___x_824_ = lean_nat_dec_lt(v___x_770_, v___x_823_);
lean_dec(v___x_823_);
lean_dec(v___x_770_);
if (v___x_824_ == 0)
{
lean_dec(v_snd_811_);
v_a_732_ = v_fst_810_;
v_snd_733_ = v___x_817_;
goto v___jp_731_;
}
else
{
v___y_737_ = v_fst_810_;
v___y_738_ = v___x_817_;
v___y_739_ = v_snd_811_;
goto v___jp_736_;
}
}
else
{
lean_dec(v___x_770_);
v___y_737_ = v_fst_810_;
v___y_738_ = v___x_817_;
v___y_739_ = v_snd_811_;
goto v___jp_736_;
}
}
}
}
}
}
else
{
lean_object* v___x_830_; 
lean_dec(v_work_805_);
lean_del_object(v___x_802_);
lean_dec(v_gmPairs_800_);
lean_dec(v_chainPairs_799_);
lean_dec(v_productPairs_798_);
lean_dec(v_largestBatch_797_);
lean_dec(v_peakMatrixEntries_796_);
lean_dec(v_peakMatrixRows_795_);
lean_dec(v_matrixCalls_794_);
lean_dec(v_matrixRows_793_);
lean_dec(v_matrixEntries_792_);
lean_dec(v_rounds_791_);
lean_dec(v_pairs_790_);
lean_dec(v_allocatedBytes_789_);
lean_dec(v_a_786_);
lean_dec(v___x_770_);
lean_dec(v_i_722_);
v___x_830_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__1));
v_a_725_ = v___x_830_;
v_snd_726_ = v_snd_784_;
goto v___jp_724_;
}
}
}
}
}
v___jp_833_:
{
uint64_t v___x_836_; uint64_t v___x_837_; uint64_t v___x_838_; uint64_t v___x_839_; lean_object* v___x_840_; 
v___x_836_ = lean_uint8_to_uint64(v___y_835_);
v___x_837_ = 24ULL;
v___x_838_ = lean_uint64_shift_left(v___x_836_, v___x_837_);
v___x_839_ = lean_uint64_lor(v___y_834_, v___x_838_);
v___x_840_ = lean_uint64_to_nat(v___x_839_);
v___y_775_ = v___x_840_;
goto v___jp_774_;
}
v___jp_841_:
{
size_t v_pos_842_; uint8_t v___x_843_; uint64_t v_a_844_; size_t v___x_845_; uint8_t v___x_846_; uint64_t v___x_847_; uint64_t v___x_848_; uint64_t v___x_849_; uint64_t v___x_850_; size_t v___x_851_; uint8_t v___x_852_; uint64_t v___x_853_; uint64_t v___x_854_; uint64_t v___x_855_; uint64_t v___x_856_; size_t v___x_857_; uint8_t v___x_858_; uint64_t v___x_859_; uint64_t v___x_860_; uint64_t v___x_861_; uint64_t v___x_862_; lean_object* v___x_863_; 
v_pos_842_ = ((size_t)0ULL);
v___x_843_ = lean_byte_array_uget(v_support_763_, v_pos_842_);
v_a_844_ = lean_uint8_to_uint64(v___x_843_);
v___x_845_ = ((size_t)1ULL);
v___x_846_ = lean_byte_array_uget(v_support_763_, v___x_845_);
v___x_847_ = lean_uint8_to_uint64(v___x_846_);
v___x_848_ = 8ULL;
v___x_849_ = lean_uint64_shift_left(v___x_847_, v___x_848_);
v___x_850_ = lean_uint64_lor(v_a_844_, v___x_849_);
v___x_851_ = ((size_t)2ULL);
v___x_852_ = lean_byte_array_uget(v_support_763_, v___x_851_);
v___x_853_ = lean_uint8_to_uint64(v___x_852_);
v___x_854_ = 16ULL;
v___x_855_ = lean_uint64_shift_left(v___x_853_, v___x_854_);
v___x_856_ = lean_uint64_lor(v___x_850_, v___x_855_);
v___x_857_ = ((size_t)3ULL);
v___x_858_ = lean_byte_array_uget(v_support_763_, v___x_857_);
lean_dec_ref(v_support_763_);
v___x_859_ = lean_uint8_to_uint64(v___x_858_);
v___x_860_ = 24ULL;
v___x_861_ = lean_uint64_shift_left(v___x_859_, v___x_860_);
v___x_862_ = lean_uint64_lor(v___x_856_, v___x_861_);
v___x_863_ = lean_uint64_to_nat(v___x_862_);
v___y_775_ = v___x_863_;
goto v___jp_774_;
}
}
else
{
lean_dec(v___x_770_);
lean_del_object(v___x_765_);
lean_dec_ref(v_support_763_);
v_a_732_ = v_b_721_;
v_snd_733_ = v___y_723_;
goto v___jp_731_;
}
}
}
v___jp_724_:
{
lean_object* v___x_727_; lean_object* v___x_728_; 
v___x_727_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_727_, 0, v_a_725_);
v___x_728_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_728_, 0, v___x_727_);
lean_ctor_set(v___x_728_, 1, v_snd_726_);
return v___x_728_;
}
v___jp_731_:
{
lean_object* v___x_734_; lean_object* v___x_735_; 
v___x_734_ = lean_nat_add(v_i_722_, v_step_730_);
lean_dec(v_i_722_);
v___x_735_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2___redArg(v_basis_716_, v_context_719_, v_limits_717_, v_table_718_, v_range_720_, v_a_732_, v___x_734_, v_snd_733_);
return v___x_735_;
}
v___jp_736_:
{
lean_object* v___x_740_; uint8_t v___x_741_; 
v___x_740_ = lean_array_get_size(v___y_737_);
v___x_741_ = lean_nat_dec_lt(v___y_739_, v___x_740_);
if (v___x_741_ == 0)
{
lean_dec(v___y_739_);
v_a_732_ = v___y_737_;
v_snd_733_ = v___y_738_;
goto v___jp_731_;
}
else
{
lean_object* v_v_742_; lean_object* v_edges_743_; lean_object* v_depth_744_; lean_object* v___x_746_; uint8_t v_isShared_747_; uint8_t v_isSharedCheck_755_; 
v_v_742_ = lean_array_fget(v___y_737_, v___y_739_);
v_edges_743_ = lean_ctor_get(v_v_742_, 0);
v_depth_744_ = lean_ctor_get(v_v_742_, 2);
v_isSharedCheck_755_ = !lean_is_exclusive(v_v_742_);
if (v_isSharedCheck_755_ == 0)
{
lean_object* v_unused_756_; 
v_unused_756_ = lean_ctor_get(v_v_742_, 1);
lean_dec(v_unused_756_);
v___x_746_ = v_v_742_;
v_isShared_747_ = v_isSharedCheck_755_;
goto v_resetjp_745_;
}
else
{
lean_inc(v_depth_744_);
lean_inc(v_edges_743_);
lean_dec(v_v_742_);
v___x_746_ = lean_box(0);
v_isShared_747_ = v_isSharedCheck_755_;
goto v_resetjp_745_;
}
v_resetjp_745_:
{
lean_object* v___x_748_; lean_object* v_xs_x27_749_; lean_object* v___x_750_; lean_object* v___x_752_; 
v___x_748_ = lean_box(0);
v_xs_x27_749_ = lean_array_fset(v___y_737_, v___y_739_, v___x_748_);
lean_inc(v_i_722_);
v___x_750_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_750_, 0, v_i_722_);
if (v_isShared_747_ == 0)
{
lean_ctor_set(v___x_746_, 1, v___x_750_);
v___x_752_ = v___x_746_;
goto v_reusejp_751_;
}
else
{
lean_object* v_reuseFailAlloc_754_; 
v_reuseFailAlloc_754_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_754_, 0, v_edges_743_);
lean_ctor_set(v_reuseFailAlloc_754_, 1, v___x_750_);
lean_ctor_set(v_reuseFailAlloc_754_, 2, v_depth_744_);
v___x_752_ = v_reuseFailAlloc_754_;
goto v_reusejp_751_;
}
v_reusejp_751_:
{
lean_object* v___x_753_; 
v___x_753_ = lean_array_fset(v_xs_x27_749_, v___y_739_, v___x_752_);
lean_dec(v___y_739_);
v_a_732_ = v___x_753_;
v_snd_733_ = v___y_738_;
goto v___jp_731_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2___redArg___boxed(lean_object* v_basis_907_, lean_object* v_limits_908_, lean_object* v_table_909_, lean_object* v_context_910_, lean_object* v_range_911_, lean_object* v_b_912_, lean_object* v_i_913_, lean_object* v___y_914_){
_start:
{
lean_object* v_res_915_; 
v_res_915_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2___redArg(v_basis_907_, v_limits_908_, v_table_909_, v_context_910_, v_range_911_, v_b_912_, v_i_913_, v___y_914_);
lean_dec_ref(v_range_911_);
lean_dec_ref(v_context_910_);
lean_dec_ref(v_table_909_);
lean_dec_ref(v_limits_908_);
lean_dec_ref(v_basis_907_);
return v_res_915_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_ReducerIndex_build___closed__0(void){
_start:
{
lean_object* v___x_916_; lean_object* v___x_917_; lean_object* v___x_918_; lean_object* v_nodes_919_; 
v___x_916_ = lean_obj_once(&lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default___closed__0, &lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default___closed__0_once, _init_lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default___closed__0);
v___x_917_ = lean_unsigned_to_nat(1u);
v___x_918_ = lean_mk_empty_array_with_capacity(v___x_917_);
v_nodes_919_ = lean_array_push(v___x_918_, v___x_916_);
return v_nodes_919_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_build(lean_object* v_context_920_, lean_object* v_limits_921_, lean_object* v_basis_922_, lean_object* v_a_923_){
_start:
{
lean_object* v_table_924_; lean_object* v_node_925_; lean_object* v___x_926_; lean_object* v_nodes_927_; lean_object* v___x_928_; lean_object* v___x_929_; lean_object* v___x_930_; lean_object* v_fst_931_; 
v_table_924_ = lean_ctor_get(v_a_923_, 0);
lean_inc_ref(v_table_924_);
v_node_925_ = lean_unsigned_to_nat(0u);
v___x_926_ = lean_unsigned_to_nat(1u);
v_nodes_927_ = lean_obj_once(&lp_Hex_Hex_Groebner_ReducerIndex_build___closed__0, &lp_Hex_Hex_Groebner_ReducerIndex_build___closed__0_once, _init_lp_Hex_Hex_Groebner_ReducerIndex_build___closed__0);
v___x_928_ = lean_array_get_size(v_basis_922_);
v___x_929_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_929_, 0, v_node_925_);
lean_ctor_set(v___x_929_, 1, v___x_928_);
lean_ctor_set(v___x_929_, 2, v___x_926_);
v___x_930_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2___redArg(v_basis_922_, v_limits_921_, v_table_924_, v_context_920_, v___x_929_, v_nodes_927_, v_node_925_, v_a_923_);
lean_dec_ref_known(v___x_929_, 3);
lean_dec_ref(v_table_924_);
v_fst_931_ = lean_ctor_get(v___x_930_, 0);
lean_inc(v_fst_931_);
if (lean_obj_tag(v_fst_931_) == 0)
{
lean_object* v_snd_932_; lean_object* v___x_934_; uint8_t v_isShared_935_; uint8_t v_isSharedCheck_947_; 
v_snd_932_ = lean_ctor_get(v___x_930_, 1);
v_isSharedCheck_947_ = !lean_is_exclusive(v___x_930_);
if (v_isSharedCheck_947_ == 0)
{
lean_object* v_unused_948_; 
v_unused_948_ = lean_ctor_get(v___x_930_, 0);
lean_dec(v_unused_948_);
v___x_934_ = v___x_930_;
v_isShared_935_ = v_isSharedCheck_947_;
goto v_resetjp_933_;
}
else
{
lean_inc(v_snd_932_);
lean_dec(v___x_930_);
v___x_934_ = lean_box(0);
v_isShared_935_ = v_isSharedCheck_947_;
goto v_resetjp_933_;
}
v_resetjp_933_:
{
lean_object* v_a_936_; lean_object* v___x_938_; uint8_t v_isShared_939_; uint8_t v_isSharedCheck_946_; 
v_a_936_ = lean_ctor_get(v_fst_931_, 0);
v_isSharedCheck_946_ = !lean_is_exclusive(v_fst_931_);
if (v_isSharedCheck_946_ == 0)
{
v___x_938_ = v_fst_931_;
v_isShared_939_ = v_isSharedCheck_946_;
goto v_resetjp_937_;
}
else
{
lean_inc(v_a_936_);
lean_dec(v_fst_931_);
v___x_938_ = lean_box(0);
v_isShared_939_ = v_isSharedCheck_946_;
goto v_resetjp_937_;
}
v_resetjp_937_:
{
lean_object* v___x_941_; 
if (v_isShared_939_ == 0)
{
v___x_941_ = v___x_938_;
goto v_reusejp_940_;
}
else
{
lean_object* v_reuseFailAlloc_945_; 
v_reuseFailAlloc_945_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_945_, 0, v_a_936_);
v___x_941_ = v_reuseFailAlloc_945_;
goto v_reusejp_940_;
}
v_reusejp_940_:
{
lean_object* v___x_943_; 
if (v_isShared_935_ == 0)
{
lean_ctor_set(v___x_934_, 0, v___x_941_);
v___x_943_ = v___x_934_;
goto v_reusejp_942_;
}
else
{
lean_object* v_reuseFailAlloc_944_; 
v_reuseFailAlloc_944_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_944_, 0, v___x_941_);
lean_ctor_set(v_reuseFailAlloc_944_, 1, v_snd_932_);
v___x_943_ = v_reuseFailAlloc_944_;
goto v_reusejp_942_;
}
v_reusejp_942_:
{
return v___x_943_;
}
}
}
}
}
else
{
lean_object* v_snd_949_; lean_object* v___x_951_; uint8_t v_isShared_952_; uint8_t v_isSharedCheck_964_; 
v_snd_949_ = lean_ctor_get(v___x_930_, 1);
v_isSharedCheck_964_ = !lean_is_exclusive(v___x_930_);
if (v_isSharedCheck_964_ == 0)
{
lean_object* v_unused_965_; 
v_unused_965_ = lean_ctor_get(v___x_930_, 0);
lean_dec(v_unused_965_);
v___x_951_ = v___x_930_;
v_isShared_952_ = v_isSharedCheck_964_;
goto v_resetjp_950_;
}
else
{
lean_inc(v_snd_949_);
lean_dec(v___x_930_);
v___x_951_ = lean_box(0);
v_isShared_952_ = v_isSharedCheck_964_;
goto v_resetjp_950_;
}
v_resetjp_950_:
{
lean_object* v_a_953_; lean_object* v___x_955_; uint8_t v_isShared_956_; uint8_t v_isSharedCheck_963_; 
v_a_953_ = lean_ctor_get(v_fst_931_, 0);
v_isSharedCheck_963_ = !lean_is_exclusive(v_fst_931_);
if (v_isSharedCheck_963_ == 0)
{
v___x_955_ = v_fst_931_;
v_isShared_956_ = v_isSharedCheck_963_;
goto v_resetjp_954_;
}
else
{
lean_inc(v_a_953_);
lean_dec(v_fst_931_);
v___x_955_ = lean_box(0);
v_isShared_956_ = v_isSharedCheck_963_;
goto v_resetjp_954_;
}
v_resetjp_954_:
{
lean_object* v___x_958_; 
if (v_isShared_956_ == 0)
{
v___x_958_ = v___x_955_;
goto v_reusejp_957_;
}
else
{
lean_object* v_reuseFailAlloc_962_; 
v_reuseFailAlloc_962_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_962_, 0, v_a_953_);
v___x_958_ = v_reuseFailAlloc_962_;
goto v_reusejp_957_;
}
v_reusejp_957_:
{
lean_object* v___x_960_; 
if (v_isShared_952_ == 0)
{
lean_ctor_set(v___x_951_, 0, v___x_958_);
v___x_960_ = v___x_951_;
goto v_reusejp_959_;
}
else
{
lean_object* v_reuseFailAlloc_961_; 
v_reuseFailAlloc_961_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_961_, 0, v___x_958_);
lean_ctor_set(v_reuseFailAlloc_961_, 1, v_snd_949_);
v___x_960_ = v_reuseFailAlloc_961_;
goto v_reusejp_959_;
}
v_reusejp_959_:
{
return v___x_960_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_build___boxed(lean_object* v_context_966_, lean_object* v_limits_967_, lean_object* v_basis_968_, lean_object* v_a_969_){
_start:
{
lean_object* v_res_970_; 
v_res_970_ = lp_Hex_Hex_Groebner_ReducerIndex_build(v_context_966_, v_limits_967_, v_basis_968_, v_a_969_);
lean_dec_ref(v_basis_968_);
lean_dec_ref(v_limits_967_);
lean_dec_ref(v_context_966_);
return v_res_970_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0(uint64_t v___y_971_, lean_object* v___x_972_, lean_object* v_range_973_, lean_object* v_b_974_, lean_object* v_i_975_, lean_object* v_hs_976_, lean_object* v_hl_977_, lean_object* v___y_978_){
_start:
{
lean_object* v___x_979_; 
v___x_979_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg(v___y_971_, v___x_972_, v_range_973_, v_b_974_, v_i_975_, v___y_978_);
return v___x_979_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___boxed(lean_object* v___y_980_, lean_object* v___x_981_, lean_object* v_range_982_, lean_object* v_b_983_, lean_object* v_i_984_, lean_object* v_hs_985_, lean_object* v_hl_986_, lean_object* v___y_987_){
_start:
{
uint64_t v___y_18657__boxed_988_; lean_object* v_res_989_; 
v___y_18657__boxed_988_ = lean_unbox_uint64(v___y_980_);
lean_dec_ref(v___y_980_);
v_res_989_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0(v___y_18657__boxed_988_, v___x_981_, v_range_982_, v_b_983_, v_i_984_, v_hs_985_, v_hl_986_, v___y_987_);
lean_dec_ref(v_range_982_);
lean_dec_ref(v___x_981_);
return v_res_989_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1(lean_object* v_limits_990_, lean_object* v_table_991_, lean_object* v___y_992_, lean_object* v_range_993_, lean_object* v_b_994_, lean_object* v_i_995_, lean_object* v_hs_996_, lean_object* v_hl_997_, lean_object* v___y_998_){
_start:
{
lean_object* v___x_999_; 
v___x_999_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg(v_limits_990_, v_table_991_, v___y_992_, v_range_993_, v_b_994_, v_i_995_, v___y_998_);
return v___x_999_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___boxed(lean_object* v_limits_1000_, lean_object* v_table_1001_, lean_object* v___y_1002_, lean_object* v_range_1003_, lean_object* v_b_1004_, lean_object* v_i_1005_, lean_object* v_hs_1006_, lean_object* v_hl_1007_, lean_object* v___y_1008_){
_start:
{
lean_object* v_res_1009_; 
v_res_1009_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1(v_limits_1000_, v_table_1001_, v___y_1002_, v_range_1003_, v_b_1004_, v_i_1005_, v_hs_1006_, v_hl_1007_, v___y_1008_);
lean_dec_ref(v_range_1003_);
lean_dec(v___y_1002_);
lean_dec_ref(v_table_1001_);
lean_dec_ref(v_limits_1000_);
return v_res_1009_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2(lean_object* v_basis_1010_, lean_object* v_limits_1011_, lean_object* v_table_1012_, lean_object* v_context_1013_, lean_object* v_range_1014_, lean_object* v_b_1015_, lean_object* v_i_1016_, lean_object* v_hs_1017_, lean_object* v_hl_1018_, lean_object* v___y_1019_){
_start:
{
lean_object* v___x_1020_; 
v___x_1020_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2___redArg(v_basis_1010_, v_limits_1011_, v_table_1012_, v_context_1013_, v_range_1014_, v_b_1015_, v_i_1016_, v___y_1019_);
return v___x_1020_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2___boxed(lean_object* v_basis_1021_, lean_object* v_limits_1022_, lean_object* v_table_1023_, lean_object* v_context_1024_, lean_object* v_range_1025_, lean_object* v_b_1026_, lean_object* v_i_1027_, lean_object* v_hs_1028_, lean_object* v_hl_1029_, lean_object* v___y_1030_){
_start:
{
lean_object* v_res_1031_; 
v_res_1031_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2(v_basis_1021_, v_limits_1022_, v_table_1023_, v_context_1024_, v_range_1025_, v_b_1026_, v_i_1027_, v_hs_1028_, v_hl_1029_, v___y_1030_);
lean_dec_ref(v_range_1025_);
lean_dec_ref(v_context_1024_);
lean_dec_ref(v_table_1023_);
lean_dec_ref(v_limits_1022_);
lean_dec_ref(v_basis_1021_);
return v_res_1031_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2(lean_object* v_basis_1032_, lean_object* v_context_1033_, lean_object* v_limits_1034_, lean_object* v_table_1035_, lean_object* v_range_1036_, lean_object* v_b_1037_, lean_object* v_i_1038_, lean_object* v_hs_1039_, lean_object* v_hl_1040_, lean_object* v___y_1041_){
_start:
{
lean_object* v___x_1042_; 
v___x_1042_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2___redArg(v_basis_1032_, v_context_1033_, v_limits_1034_, v_table_1035_, v_range_1036_, v_b_1037_, v_i_1038_, v___y_1041_);
return v___x_1042_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2___boxed(lean_object* v_basis_1043_, lean_object* v_context_1044_, lean_object* v_limits_1045_, lean_object* v_table_1046_, lean_object* v_range_1047_, lean_object* v_b_1048_, lean_object* v_i_1049_, lean_object* v_hs_1050_, lean_object* v_hl_1051_, lean_object* v___y_1052_){
_start:
{
lean_object* v_res_1053_; 
v_res_1053_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__2_spec__2(v_basis_1043_, v_context_1044_, v_limits_1045_, v_table_1046_, v_range_1047_, v_b_1048_, v_i_1049_, v_hs_1050_, v_hl_1051_, v___y_1052_);
lean_dec_ref(v_range_1047_);
lean_dec_ref(v_table_1046_);
lean_dec_ref(v_limits_1045_);
lean_dec_ref(v_context_1044_);
lean_dec_ref(v_basis_1043_);
return v_res_1053_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0___redArg(uint64_t v___y_1054_, lean_object* v___x_1055_, lean_object* v_range_1056_, lean_object* v_b_1057_, lean_object* v_i_1058_){
_start:
{
lean_object* v_stop_1059_; lean_object* v_step_1060_; lean_object* v_a_1062_; uint64_t v___y_1066_; uint64_t v___y_1070_; uint8_t v___y_1071_; uint8_t v___x_1076_; 
v_stop_1059_ = lean_ctor_get(v_range_1056_, 1);
v_step_1060_ = lean_ctor_get(v_range_1056_, 2);
v___x_1076_ = lean_nat_dec_lt(v_i_1058_, v_stop_1059_);
if (v___x_1076_ == 0)
{
lean_dec(v_i_1058_);
return v_b_1057_;
}
else
{
lean_object* v___y_1078_; uint64_t v___y_1079_; uint8_t v___y_1080_; uint8_t v___y_1081_; lean_object* v___x_1093_; lean_object* v___x_1094_; lean_object* v___y_1096_; uint64_t v___y_1097_; uint8_t v___y_1098_; uint8_t v___y_1099_; lean_object* v___y_1111_; uint8_t v___y_1112_; uint8_t v___y_1113_; lean_object* v___y_1122_; uint8_t v___y_1123_; uint8_t v___y_1124_; lean_object* v___x_1154_; uint64_t v___y_1156_; uint64_t v___y_1169_; uint8_t v___y_1170_; uint8_t v___x_1175_; lean_object* v___x_1176_; lean_object* v_offset_1177_; uint64_t v___y_1179_; uint8_t v___y_1180_; uint64_t v___y_1193_; uint8_t v___y_1194_; uint8_t v___y_1206_; uint8_t v___y_1215_; lean_object* v___x_1245_; lean_object* v___x_1246_; uint8_t v___x_1247_; 
v___x_1093_ = lean_unsigned_to_nat(1u);
v___x_1094_ = lean_unsigned_to_nat(2u);
v___x_1154_ = lean_nat_mul(v___x_1094_, v_i_1058_);
v___x_1175_ = 0;
v___x_1176_ = lean_unsigned_to_nat(4u);
v_offset_1177_ = lean_nat_mul(v___x_1154_, v___x_1176_);
v___x_1245_ = lean_nat_add(v_offset_1177_, v___x_1176_);
v___x_1246_ = lean_byte_array_size(v___x_1055_);
v___x_1247_ = lean_nat_dec_le(v___x_1245_, v___x_1246_);
if (v___x_1247_ == 0)
{
lean_dec(v___x_1245_);
v___y_1215_ = v___x_1247_;
goto v___jp_1214_;
}
else
{
size_t v___x_1248_; lean_object* v___x_1249_; uint8_t v___x_1250_; 
v___x_1248_ = lean_usize_of_nat(v___x_1245_);
v___x_1249_ = lean_usize_to_nat(v___x_1248_);
v___x_1250_ = lean_nat_dec_eq(v___x_1249_, v___x_1245_);
lean_dec(v___x_1245_);
lean_dec(v___x_1249_);
v___y_1215_ = v___x_1250_;
goto v___jp_1214_;
}
v___jp_1077_:
{
uint64_t v___x_1082_; uint64_t v___x_1083_; uint64_t v___x_1084_; uint64_t v___x_1085_; lean_object* v___x_1086_; lean_object* v___x_1087_; uint8_t v___x_1088_; 
v___x_1082_ = lean_uint8_to_uint64(v___y_1081_);
v___x_1083_ = 16ULL;
v___x_1084_ = lean_uint64_shift_left(v___x_1082_, v___x_1083_);
v___x_1085_ = lean_uint64_lor(v___y_1079_, v___x_1084_);
v___x_1086_ = lean_unsigned_to_nat(3u);
v___x_1087_ = lean_nat_add(v___y_1078_, v___x_1086_);
lean_dec(v___y_1078_);
v___x_1088_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1055_, v___x_1087_);
if (v___x_1088_ == 0)
{
lean_object* v___x_1089_; lean_object* v___x_1090_; uint8_t v___x_1091_; 
lean_dec(v___x_1087_);
v___x_1089_ = lean_box(v___y_1080_);
v___x_1090_ = l_outOfBounds___redArg(v___x_1089_);
lean_dec(v___x_1089_);
v___x_1091_ = lean_unbox(v___x_1090_);
lean_dec(v___x_1090_);
v___y_1070_ = v___x_1085_;
v___y_1071_ = v___x_1091_;
goto v___jp_1069_;
}
else
{
uint8_t v___x_1092_; 
v___x_1092_ = lean_byte_array_fget(v___x_1055_, v___x_1087_);
lean_dec(v___x_1087_);
v___y_1070_ = v___x_1085_;
v___y_1071_ = v___x_1092_;
goto v___jp_1069_;
}
}
v___jp_1095_:
{
uint64_t v___x_1100_; uint64_t v___x_1101_; uint64_t v___x_1102_; uint64_t v___x_1103_; lean_object* v___x_1104_; uint8_t v___x_1105_; 
v___x_1100_ = lean_uint8_to_uint64(v___y_1099_);
v___x_1101_ = 8ULL;
v___x_1102_ = lean_uint64_shift_left(v___x_1100_, v___x_1101_);
v___x_1103_ = lean_uint64_lor(v___y_1097_, v___x_1102_);
v___x_1104_ = lean_nat_add(v___y_1096_, v___x_1094_);
v___x_1105_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1055_, v___x_1104_);
if (v___x_1105_ == 0)
{
lean_object* v___x_1106_; lean_object* v___x_1107_; uint8_t v___x_1108_; 
lean_dec(v___x_1104_);
v___x_1106_ = lean_box(v___y_1098_);
v___x_1107_ = l_outOfBounds___redArg(v___x_1106_);
lean_dec(v___x_1106_);
v___x_1108_ = lean_unbox(v___x_1107_);
lean_dec(v___x_1107_);
v___y_1078_ = v___y_1096_;
v___y_1079_ = v___x_1103_;
v___y_1080_ = v___y_1098_;
v___y_1081_ = v___x_1108_;
goto v___jp_1077_;
}
else
{
uint8_t v___x_1109_; 
v___x_1109_ = lean_byte_array_fget(v___x_1055_, v___x_1104_);
lean_dec(v___x_1104_);
v___y_1078_ = v___y_1096_;
v___y_1079_ = v___x_1103_;
v___y_1080_ = v___y_1098_;
v___y_1081_ = v___x_1109_;
goto v___jp_1077_;
}
}
v___jp_1110_:
{
uint64_t v_a_1114_; lean_object* v___x_1115_; uint8_t v___x_1116_; 
v_a_1114_ = lean_uint8_to_uint64(v___y_1113_);
v___x_1115_ = lean_nat_add(v___y_1111_, v___x_1093_);
v___x_1116_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1055_, v___x_1115_);
if (v___x_1116_ == 0)
{
lean_object* v___x_1117_; lean_object* v___x_1118_; uint8_t v___x_1119_; 
lean_dec(v___x_1115_);
v___x_1117_ = lean_box(v___y_1112_);
v___x_1118_ = l_outOfBounds___redArg(v___x_1117_);
lean_dec(v___x_1117_);
v___x_1119_ = lean_unbox(v___x_1118_);
lean_dec(v___x_1118_);
v___y_1096_ = v___y_1111_;
v___y_1097_ = v_a_1114_;
v___y_1098_ = v___y_1112_;
v___y_1099_ = v___x_1119_;
goto v___jp_1095_;
}
else
{
uint8_t v___x_1120_; 
v___x_1120_ = lean_byte_array_fget(v___x_1055_, v___x_1115_);
lean_dec(v___x_1115_);
v___y_1096_ = v___y_1111_;
v___y_1097_ = v_a_1114_;
v___y_1098_ = v___y_1112_;
v___y_1099_ = v___x_1120_;
goto v___jp_1095_;
}
}
v___jp_1121_:
{
if (v___y_1124_ == 0)
{
uint8_t v___x_1125_; 
v___x_1125_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1055_, v___y_1122_);
if (v___x_1125_ == 0)
{
lean_object* v___x_1126_; lean_object* v___x_1127_; uint8_t v___x_1128_; 
v___x_1126_ = lean_box(v___y_1123_);
v___x_1127_ = l_outOfBounds___redArg(v___x_1126_);
lean_dec(v___x_1126_);
v___x_1128_ = lean_unbox(v___x_1127_);
lean_dec(v___x_1127_);
v___y_1111_ = v___y_1122_;
v___y_1112_ = v___y_1123_;
v___y_1113_ = v___x_1128_;
goto v___jp_1110_;
}
else
{
uint8_t v___x_1129_; 
v___x_1129_ = lean_byte_array_fget(v___x_1055_, v___y_1122_);
v___y_1111_ = v___y_1122_;
v___y_1112_ = v___y_1123_;
v___y_1113_ = v___x_1129_;
goto v___jp_1110_;
}
}
else
{
size_t v_pos_1130_; uint8_t v___x_1131_; uint64_t v_a_1132_; size_t v___x_1133_; size_t v___x_1134_; uint8_t v___x_1135_; uint64_t v___x_1136_; uint64_t v___x_1137_; uint64_t v___x_1138_; uint64_t v___x_1139_; size_t v___x_1140_; size_t v___x_1141_; uint8_t v___x_1142_; uint64_t v___x_1143_; uint64_t v___x_1144_; uint64_t v___x_1145_; uint64_t v___x_1146_; size_t v___x_1147_; size_t v___x_1148_; uint8_t v___x_1149_; uint64_t v___x_1150_; uint64_t v___x_1151_; uint64_t v___x_1152_; uint64_t v___x_1153_; 
v_pos_1130_ = lean_usize_of_nat(v___y_1122_);
lean_dec(v___y_1122_);
v___x_1131_ = lean_byte_array_uget(v___x_1055_, v_pos_1130_);
v_a_1132_ = lean_uint8_to_uint64(v___x_1131_);
v___x_1133_ = ((size_t)1ULL);
v___x_1134_ = lean_usize_add(v_pos_1130_, v___x_1133_);
v___x_1135_ = lean_byte_array_uget(v___x_1055_, v___x_1134_);
v___x_1136_ = lean_uint8_to_uint64(v___x_1135_);
v___x_1137_ = 8ULL;
v___x_1138_ = lean_uint64_shift_left(v___x_1136_, v___x_1137_);
v___x_1139_ = lean_uint64_lor(v_a_1132_, v___x_1138_);
v___x_1140_ = ((size_t)2ULL);
v___x_1141_ = lean_usize_add(v_pos_1130_, v___x_1140_);
v___x_1142_ = lean_byte_array_uget(v___x_1055_, v___x_1141_);
v___x_1143_ = lean_uint8_to_uint64(v___x_1142_);
v___x_1144_ = 16ULL;
v___x_1145_ = lean_uint64_shift_left(v___x_1143_, v___x_1144_);
v___x_1146_ = lean_uint64_lor(v___x_1139_, v___x_1145_);
v___x_1147_ = ((size_t)3ULL);
v___x_1148_ = lean_usize_add(v_pos_1130_, v___x_1147_);
v___x_1149_ = lean_byte_array_uget(v___x_1055_, v___x_1148_);
v___x_1150_ = lean_uint8_to_uint64(v___x_1149_);
v___x_1151_ = 24ULL;
v___x_1152_ = lean_uint64_shift_left(v___x_1150_, v___x_1151_);
v___x_1153_ = lean_uint64_lor(v___x_1146_, v___x_1152_);
v___y_1066_ = v___x_1153_;
goto v___jp_1065_;
}
}
v___jp_1155_:
{
uint8_t v___x_1157_; 
v___x_1157_ = lean_uint64_dec_le(v___y_1156_, v___y_1054_);
if (v___x_1157_ == 0)
{
lean_dec(v___x_1154_);
v_a_1062_ = v_b_1057_;
goto v___jp_1061_;
}
else
{
lean_object* v___x_1158_; uint8_t v___x_1159_; lean_object* v___x_1160_; lean_object* v_offset_1161_; lean_object* v___x_1162_; lean_object* v___x_1163_; uint8_t v___x_1164_; 
v___x_1158_ = lean_nat_add(v___x_1154_, v___x_1093_);
lean_dec(v___x_1154_);
v___x_1159_ = 0;
v___x_1160_ = lean_unsigned_to_nat(4u);
v_offset_1161_ = lean_nat_mul(v___x_1158_, v___x_1160_);
lean_dec(v___x_1158_);
v___x_1162_ = lean_nat_add(v_offset_1161_, v___x_1160_);
v___x_1163_ = lean_byte_array_size(v___x_1055_);
v___x_1164_ = lean_nat_dec_le(v___x_1162_, v___x_1163_);
if (v___x_1164_ == 0)
{
lean_dec(v___x_1162_);
v___y_1122_ = v_offset_1161_;
v___y_1123_ = v___x_1159_;
v___y_1124_ = v___x_1164_;
goto v___jp_1121_;
}
else
{
size_t v___x_1165_; lean_object* v___x_1166_; uint8_t v___x_1167_; 
v___x_1165_ = lean_usize_of_nat(v___x_1162_);
v___x_1166_ = lean_usize_to_nat(v___x_1165_);
v___x_1167_ = lean_nat_dec_eq(v___x_1166_, v___x_1162_);
lean_dec(v___x_1162_);
lean_dec(v___x_1166_);
v___y_1122_ = v_offset_1161_;
v___y_1123_ = v___x_1159_;
v___y_1124_ = v___x_1167_;
goto v___jp_1121_;
}
}
}
v___jp_1168_:
{
uint64_t v___x_1171_; uint64_t v___x_1172_; uint64_t v___x_1173_; uint64_t v___x_1174_; 
v___x_1171_ = lean_uint8_to_uint64(v___y_1170_);
v___x_1172_ = 24ULL;
v___x_1173_ = lean_uint64_shift_left(v___x_1171_, v___x_1172_);
v___x_1174_ = lean_uint64_lor(v___y_1169_, v___x_1173_);
v___y_1156_ = v___x_1174_;
goto v___jp_1155_;
}
v___jp_1178_:
{
uint64_t v___x_1181_; uint64_t v___x_1182_; uint64_t v___x_1183_; uint64_t v___x_1184_; lean_object* v___x_1185_; lean_object* v___x_1186_; uint8_t v___x_1187_; 
v___x_1181_ = lean_uint8_to_uint64(v___y_1180_);
v___x_1182_ = 16ULL;
v___x_1183_ = lean_uint64_shift_left(v___x_1181_, v___x_1182_);
v___x_1184_ = lean_uint64_lor(v___y_1179_, v___x_1183_);
v___x_1185_ = lean_unsigned_to_nat(3u);
v___x_1186_ = lean_nat_add(v_offset_1177_, v___x_1185_);
lean_dec(v_offset_1177_);
v___x_1187_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1055_, v___x_1186_);
if (v___x_1187_ == 0)
{
lean_object* v___x_1188_; lean_object* v___x_1189_; uint8_t v___x_1190_; 
lean_dec(v___x_1186_);
v___x_1188_ = lean_box(v___x_1175_);
v___x_1189_ = l_outOfBounds___redArg(v___x_1188_);
lean_dec(v___x_1188_);
v___x_1190_ = lean_unbox(v___x_1189_);
lean_dec(v___x_1189_);
v___y_1169_ = v___x_1184_;
v___y_1170_ = v___x_1190_;
goto v___jp_1168_;
}
else
{
uint8_t v___x_1191_; 
v___x_1191_ = lean_byte_array_fget(v___x_1055_, v___x_1186_);
lean_dec(v___x_1186_);
v___y_1169_ = v___x_1184_;
v___y_1170_ = v___x_1191_;
goto v___jp_1168_;
}
}
v___jp_1192_:
{
uint64_t v___x_1195_; uint64_t v___x_1196_; uint64_t v___x_1197_; uint64_t v___x_1198_; lean_object* v___x_1199_; uint8_t v___x_1200_; 
v___x_1195_ = lean_uint8_to_uint64(v___y_1194_);
v___x_1196_ = 8ULL;
v___x_1197_ = lean_uint64_shift_left(v___x_1195_, v___x_1196_);
v___x_1198_ = lean_uint64_lor(v___y_1193_, v___x_1197_);
v___x_1199_ = lean_nat_add(v_offset_1177_, v___x_1094_);
v___x_1200_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1055_, v___x_1199_);
if (v___x_1200_ == 0)
{
lean_object* v___x_1201_; lean_object* v___x_1202_; uint8_t v___x_1203_; 
lean_dec(v___x_1199_);
v___x_1201_ = lean_box(v___x_1175_);
v___x_1202_ = l_outOfBounds___redArg(v___x_1201_);
lean_dec(v___x_1201_);
v___x_1203_ = lean_unbox(v___x_1202_);
lean_dec(v___x_1202_);
v___y_1179_ = v___x_1198_;
v___y_1180_ = v___x_1203_;
goto v___jp_1178_;
}
else
{
uint8_t v___x_1204_; 
v___x_1204_ = lean_byte_array_fget(v___x_1055_, v___x_1199_);
lean_dec(v___x_1199_);
v___y_1179_ = v___x_1198_;
v___y_1180_ = v___x_1204_;
goto v___jp_1178_;
}
}
v___jp_1205_:
{
uint64_t v_a_1207_; lean_object* v___x_1208_; uint8_t v___x_1209_; 
v_a_1207_ = lean_uint8_to_uint64(v___y_1206_);
v___x_1208_ = lean_nat_add(v_offset_1177_, v___x_1093_);
v___x_1209_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1055_, v___x_1208_);
if (v___x_1209_ == 0)
{
lean_object* v___x_1210_; lean_object* v___x_1211_; uint8_t v___x_1212_; 
lean_dec(v___x_1208_);
v___x_1210_ = lean_box(v___x_1175_);
v___x_1211_ = l_outOfBounds___redArg(v___x_1210_);
lean_dec(v___x_1210_);
v___x_1212_ = lean_unbox(v___x_1211_);
lean_dec(v___x_1211_);
v___y_1193_ = v_a_1207_;
v___y_1194_ = v___x_1212_;
goto v___jp_1192_;
}
else
{
uint8_t v___x_1213_; 
v___x_1213_ = lean_byte_array_fget(v___x_1055_, v___x_1208_);
lean_dec(v___x_1208_);
v___y_1193_ = v_a_1207_;
v___y_1194_ = v___x_1213_;
goto v___jp_1192_;
}
}
v___jp_1214_:
{
if (v___y_1215_ == 0)
{
uint8_t v___x_1216_; 
v___x_1216_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1055_, v_offset_1177_);
if (v___x_1216_ == 0)
{
lean_object* v___x_1217_; lean_object* v___x_1218_; uint8_t v___x_1219_; 
v___x_1217_ = lean_box(v___x_1175_);
v___x_1218_ = l_outOfBounds___redArg(v___x_1217_);
lean_dec(v___x_1217_);
v___x_1219_ = lean_unbox(v___x_1218_);
lean_dec(v___x_1218_);
v___y_1206_ = v___x_1219_;
goto v___jp_1205_;
}
else
{
uint8_t v___x_1220_; 
v___x_1220_ = lean_byte_array_fget(v___x_1055_, v_offset_1177_);
v___y_1206_ = v___x_1220_;
goto v___jp_1205_;
}
}
else
{
size_t v_pos_1221_; uint8_t v___x_1222_; uint64_t v_a_1223_; size_t v___x_1224_; size_t v___x_1225_; uint8_t v___x_1226_; uint64_t v___x_1227_; uint64_t v___x_1228_; uint64_t v___x_1229_; uint64_t v___x_1230_; size_t v___x_1231_; size_t v___x_1232_; uint8_t v___x_1233_; uint64_t v___x_1234_; uint64_t v___x_1235_; uint64_t v___x_1236_; uint64_t v___x_1237_; size_t v___x_1238_; size_t v___x_1239_; uint8_t v___x_1240_; uint64_t v___x_1241_; uint64_t v___x_1242_; uint64_t v___x_1243_; uint64_t v___x_1244_; 
v_pos_1221_ = lean_usize_of_nat(v_offset_1177_);
lean_dec(v_offset_1177_);
v___x_1222_ = lean_byte_array_uget(v___x_1055_, v_pos_1221_);
v_a_1223_ = lean_uint8_to_uint64(v___x_1222_);
v___x_1224_ = ((size_t)1ULL);
v___x_1225_ = lean_usize_add(v_pos_1221_, v___x_1224_);
v___x_1226_ = lean_byte_array_uget(v___x_1055_, v___x_1225_);
v___x_1227_ = lean_uint8_to_uint64(v___x_1226_);
v___x_1228_ = 8ULL;
v___x_1229_ = lean_uint64_shift_left(v___x_1227_, v___x_1228_);
v___x_1230_ = lean_uint64_lor(v_a_1223_, v___x_1229_);
v___x_1231_ = ((size_t)2ULL);
v___x_1232_ = lean_usize_add(v_pos_1221_, v___x_1231_);
v___x_1233_ = lean_byte_array_uget(v___x_1055_, v___x_1232_);
v___x_1234_ = lean_uint8_to_uint64(v___x_1233_);
v___x_1235_ = 16ULL;
v___x_1236_ = lean_uint64_shift_left(v___x_1234_, v___x_1235_);
v___x_1237_ = lean_uint64_lor(v___x_1230_, v___x_1236_);
v___x_1238_ = ((size_t)3ULL);
v___x_1239_ = lean_usize_add(v_pos_1221_, v___x_1238_);
v___x_1240_ = lean_byte_array_uget(v___x_1055_, v___x_1239_);
v___x_1241_ = lean_uint8_to_uint64(v___x_1240_);
v___x_1242_ = 24ULL;
v___x_1243_ = lean_uint64_shift_left(v___x_1241_, v___x_1242_);
v___x_1244_ = lean_uint64_lor(v___x_1237_, v___x_1243_);
v___y_1156_ = v___x_1244_;
goto v___jp_1155_;
}
}
}
v___jp_1061_:
{
lean_object* v___x_1063_; 
v___x_1063_ = lean_nat_add(v_i_1058_, v_step_1060_);
lean_dec(v_i_1058_);
v_b_1057_ = v_a_1062_;
v_i_1058_ = v___x_1063_;
goto _start;
}
v___jp_1065_:
{
lean_object* v___x_1067_; lean_object* v___x_1068_; 
v___x_1067_ = lean_uint64_to_nat(v___y_1066_);
v___x_1068_ = lean_array_push(v_b_1057_, v___x_1067_);
v_a_1062_ = v___x_1068_;
goto v___jp_1061_;
}
v___jp_1069_:
{
uint64_t v___x_1072_; uint64_t v___x_1073_; uint64_t v___x_1074_; uint64_t v___x_1075_; 
v___x_1072_ = lean_uint8_to_uint64(v___y_1071_);
v___x_1073_ = 24ULL;
v___x_1074_ = lean_uint64_shift_left(v___x_1072_, v___x_1073_);
v___x_1075_ = lean_uint64_lor(v___y_1070_, v___x_1074_);
v___y_1066_ = v___x_1075_;
goto v___jp_1065_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0___redArg___boxed(lean_object* v___y_1251_, lean_object* v___x_1252_, lean_object* v_range_1253_, lean_object* v_b_1254_, lean_object* v_i_1255_){
_start:
{
uint64_t v___y_5347__boxed_1256_; lean_object* v_res_1257_; 
v___y_5347__boxed_1256_ = lean_unbox_uint64(v___y_1251_);
lean_dec_ref(v___y_1251_);
v_res_1257_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0___redArg(v___y_5347__boxed_1256_, v___x_1252_, v_range_1253_, v_b_1254_, v_i_1255_);
lean_dec_ref(v_range_1253_);
lean_dec_ref(v___x_1252_);
return v_res_1257_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg(lean_object* v_maxWork_1260_, lean_object* v___x_1261_, lean_object* v_context_1262_, lean_object* v_table_1263_, lean_object* v_monomial_1264_, lean_object* v_basis_1265_, lean_object* v_range_1266_, lean_object* v_b_1267_, lean_object* v_i_1268_){
_start:
{
lean_object* v_stop_1269_; lean_object* v_step_1270_; lean_object* v_a_1272_; uint8_t v___x_1275_; 
v_stop_1269_ = lean_ctor_get(v_range_1266_, 1);
v_step_1270_ = lean_ctor_get(v_range_1266_, 2);
v___x_1275_ = lean_nat_dec_lt(v_i_1268_, v_stop_1269_);
if (v___x_1275_ == 0)
{
lean_dec(v_i_1268_);
return v_b_1267_;
}
else
{
lean_object* v_snd_1276_; lean_object* v___x_1278_; uint8_t v_isShared_1279_; uint8_t v_isSharedCheck_1715_; 
v_snd_1276_ = lean_ctor_get(v_b_1267_, 1);
v_isSharedCheck_1715_ = !lean_is_exclusive(v_b_1267_);
if (v_isSharedCheck_1715_ == 0)
{
lean_object* v_unused_1716_; 
v_unused_1716_ = lean_ctor_get(v_b_1267_, 0);
lean_dec(v_unused_1716_);
v___x_1278_ = v_b_1267_;
v_isShared_1279_ = v_isSharedCheck_1715_;
goto v_resetjp_1277_;
}
else
{
lean_inc(v_snd_1276_);
lean_dec(v_b_1267_);
v___x_1278_ = lean_box(0);
v_isShared_1279_ = v_isSharedCheck_1715_;
goto v_resetjp_1277_;
}
v_resetjp_1277_:
{
lean_object* v_snd_1280_; lean_object* v_fst_1281_; lean_object* v___x_1283_; uint8_t v_isShared_1284_; uint8_t v_isSharedCheck_1714_; 
v_snd_1280_ = lean_ctor_get(v_snd_1276_, 1);
v_fst_1281_ = lean_ctor_get(v_snd_1276_, 0);
v_isSharedCheck_1714_ = !lean_is_exclusive(v_snd_1276_);
if (v_isSharedCheck_1714_ == 0)
{
v___x_1283_ = v_snd_1276_;
v_isShared_1284_ = v_isSharedCheck_1714_;
goto v_resetjp_1282_;
}
else
{
lean_inc(v_snd_1280_);
lean_inc(v_fst_1281_);
lean_dec(v_snd_1276_);
v___x_1283_ = lean_box(0);
v_isShared_1284_ = v_isSharedCheck_1714_;
goto v_resetjp_1282_;
}
v_resetjp_1282_:
{
lean_object* v_fst_1285_; lean_object* v_snd_1286_; lean_object* v___x_1288_; uint8_t v_isShared_1289_; uint8_t v_isSharedCheck_1713_; 
v_fst_1285_ = lean_ctor_get(v_snd_1280_, 0);
v_snd_1286_ = lean_ctor_get(v_snd_1280_, 1);
v_isSharedCheck_1713_ = !lean_is_exclusive(v_snd_1280_);
if (v_isSharedCheck_1713_ == 0)
{
v___x_1288_ = v_snd_1280_;
v_isShared_1289_ = v_isSharedCheck_1713_;
goto v_resetjp_1287_;
}
else
{
lean_inc(v_snd_1286_);
lean_inc(v_fst_1285_);
lean_dec(v_snd_1280_);
v___x_1288_ = lean_box(0);
v_isShared_1289_ = v_isSharedCheck_1713_;
goto v_resetjp_1287_;
}
v_resetjp_1287_:
{
lean_object* v___x_1290_; lean_object* v___x_1291_; lean_object* v___x_1292_; uint8_t v___x_1293_; 
v___x_1290_ = lean_box(0);
v___x_1291_ = lean_unsigned_to_nat(0u);
v___x_1292_ = lean_array_get_size(v_fst_1285_);
v___x_1293_ = lean_nat_dec_eq(v___x_1292_, v___x_1291_);
if (v___x_1293_ == 0)
{
lean_object* v___x_1294_; lean_object* v___x_1295_; lean_object* v___x_1296_; lean_object* v___x_1297_; lean_object* v___x_1298_; uint8_t v___x_1313_; 
v___x_1294_ = lean_unsigned_to_nat(1u);
v___x_1295_ = lean_nat_sub(v___x_1292_, v___x_1294_);
v___x_1296_ = lean_array_get(v___x_1291_, v_fst_1285_, v___x_1295_);
lean_dec(v___x_1295_);
v___x_1297_ = lean_array_pop(v_fst_1285_);
v___x_1298_ = lean_nat_add(v_fst_1281_, v___x_1294_);
v___x_1313_ = lean_nat_dec_lt(v_maxWork_1260_, v___x_1298_);
if (v___x_1313_ == 0)
{
lean_object* v___x_1314_; lean_object* v___x_1315_; uint64_t v___y_1317_; uint64_t v___y_1344_; uint8_t v___y_1345_; uint64_t v___y_1351_; uint8_t v___y_1352_; lean_object* v_reducer_1357_; lean_object* v_depth_1358_; lean_object* v___y_1364_; lean_object* v___y_1365_; lean_object* v___y_1366_; lean_object* v___y_1367_; lean_object* v___y_1373_; lean_object* v___y_1374_; lean_object* v___y_1375_; lean_object* v___y_1376_; lean_object* v___y_1400_; uint64_t v___y_1401_; lean_object* v___y_1402_; lean_object* v___y_1403_; uint8_t v___y_1404_; lean_object* v_variables_1410_; uint8_t v___x_1411_; 
lean_dec(v_fst_1281_);
v___x_1314_ = lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default;
v___x_1315_ = lean_array_get(v___x_1314_, v___x_1261_, v___x_1296_);
lean_dec(v___x_1296_);
v_reducer_1357_ = lean_ctor_get(v___x_1315_, 1);
v_depth_1358_ = lean_ctor_get(v___x_1315_, 2);
v_variables_1410_ = lean_ctor_get(v_context_1262_, 0);
v___x_1411_ = lean_nat_dec_eq(v_depth_1358_, v_variables_1410_);
if (v___x_1411_ == 0)
{
lean_object* v_arity_1412_; uint8_t v_width_1413_; lean_object* v_exponents_1414_; lean_object* v___x_1415_; lean_object* v___x_1416_; uint8_t v___x_1417_; uint64_t v___y_1419_; lean_object* v___y_1420_; uint8_t v___y_1421_; uint64_t v___y_1434_; lean_object* v___y_1435_; uint8_t v___y_1436_; lean_object* v___y_1449_; uint8_t v___y_1450_; lean_object* v___y_1465_; uint8_t v___y_1466_; lean_object* v___y_1504_; 
lean_del_object(v___x_1288_);
lean_del_object(v___x_1283_);
lean_del_object(v___x_1278_);
v_arity_1412_ = lean_ctor_get(v_table_1263_, 0);
v_width_1413_ = lean_ctor_get_uint8(v_table_1263_, sizeof(void*)*8);
v_exponents_1414_ = lean_ctor_get(v_table_1263_, 1);
v___x_1415_ = lean_nat_mul(v_monomial_1264_, v_arity_1412_);
v___x_1416_ = lean_nat_add(v___x_1415_, v_depth_1358_);
lean_dec(v___x_1415_);
v___x_1417_ = 0;
switch(v_width_1413_)
{
case 0:
{
v___y_1504_ = v___x_1294_;
goto v___jp_1503_;
}
case 1:
{
lean_object* v___x_1512_; 
v___x_1512_ = lean_unsigned_to_nat(2u);
v___y_1504_ = v___x_1512_;
goto v___jp_1503_;
}
default: 
{
lean_object* v___x_1513_; 
v___x_1513_ = lean_unsigned_to_nat(4u);
v___y_1504_ = v___x_1513_;
goto v___jp_1503_;
}
}
v___jp_1418_:
{
uint64_t v___x_1422_; uint64_t v___x_1423_; uint64_t v___x_1424_; uint64_t v___x_1425_; lean_object* v___x_1426_; lean_object* v___x_1427_; uint8_t v___x_1428_; 
v___x_1422_ = lean_uint8_to_uint64(v___y_1421_);
v___x_1423_ = 16ULL;
v___x_1424_ = lean_uint64_shift_left(v___x_1422_, v___x_1423_);
v___x_1425_ = lean_uint64_lor(v___y_1419_, v___x_1424_);
v___x_1426_ = lean_unsigned_to_nat(3u);
v___x_1427_ = lean_nat_add(v___y_1420_, v___x_1426_);
lean_dec(v___y_1420_);
v___x_1428_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_1414_, v___x_1427_);
if (v___x_1428_ == 0)
{
lean_object* v___x_1429_; lean_object* v___x_1430_; uint8_t v___x_1431_; 
lean_dec(v___x_1427_);
v___x_1429_ = lean_box(v___x_1417_);
v___x_1430_ = l_outOfBounds___redArg(v___x_1429_);
lean_dec(v___x_1429_);
v___x_1431_ = lean_unbox(v___x_1430_);
lean_dec(v___x_1430_);
v___y_1344_ = v___x_1425_;
v___y_1345_ = v___x_1431_;
goto v___jp_1343_;
}
else
{
uint8_t v___x_1432_; 
v___x_1432_ = lean_byte_array_fget(v_exponents_1414_, v___x_1427_);
lean_dec(v___x_1427_);
v___y_1344_ = v___x_1425_;
v___y_1345_ = v___x_1432_;
goto v___jp_1343_;
}
}
v___jp_1433_:
{
uint64_t v___x_1437_; uint64_t v___x_1438_; uint64_t v___x_1439_; uint64_t v___x_1440_; lean_object* v___x_1441_; lean_object* v___x_1442_; uint8_t v___x_1443_; 
v___x_1437_ = lean_uint8_to_uint64(v___y_1436_);
v___x_1438_ = 8ULL;
v___x_1439_ = lean_uint64_shift_left(v___x_1437_, v___x_1438_);
v___x_1440_ = lean_uint64_lor(v___y_1434_, v___x_1439_);
v___x_1441_ = lean_unsigned_to_nat(2u);
v___x_1442_ = lean_nat_add(v___y_1435_, v___x_1441_);
v___x_1443_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_1414_, v___x_1442_);
if (v___x_1443_ == 0)
{
lean_object* v___x_1444_; lean_object* v___x_1445_; uint8_t v___x_1446_; 
lean_dec(v___x_1442_);
v___x_1444_ = lean_box(v___x_1417_);
v___x_1445_ = l_outOfBounds___redArg(v___x_1444_);
lean_dec(v___x_1444_);
v___x_1446_ = lean_unbox(v___x_1445_);
lean_dec(v___x_1445_);
v___y_1419_ = v___x_1440_;
v___y_1420_ = v___y_1435_;
v___y_1421_ = v___x_1446_;
goto v___jp_1418_;
}
else
{
uint8_t v___x_1447_; 
v___x_1447_ = lean_byte_array_fget(v_exponents_1414_, v___x_1442_);
lean_dec(v___x_1442_);
v___y_1419_ = v___x_1440_;
v___y_1420_ = v___y_1435_;
v___y_1421_ = v___x_1447_;
goto v___jp_1418_;
}
}
v___jp_1448_:
{
uint64_t v_a_1451_; 
v_a_1451_ = lean_uint8_to_uint64(v___y_1450_);
switch(v_width_1413_)
{
case 0:
{
lean_dec(v___y_1449_);
v___y_1317_ = v_a_1451_;
goto v___jp_1316_;
}
case 1:
{
lean_object* v___x_1452_; uint8_t v___x_1453_; 
v___x_1452_ = lean_nat_add(v___y_1449_, v___x_1294_);
lean_dec(v___y_1449_);
v___x_1453_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_1414_, v___x_1452_);
if (v___x_1453_ == 0)
{
lean_object* v___x_1454_; lean_object* v___x_1455_; uint8_t v___x_1456_; 
lean_dec(v___x_1452_);
v___x_1454_ = lean_box(v___x_1417_);
v___x_1455_ = l_outOfBounds___redArg(v___x_1454_);
lean_dec(v___x_1454_);
v___x_1456_ = lean_unbox(v___x_1455_);
lean_dec(v___x_1455_);
v___y_1351_ = v_a_1451_;
v___y_1352_ = v___x_1456_;
goto v___jp_1350_;
}
else
{
uint8_t v___x_1457_; 
v___x_1457_ = lean_byte_array_fget(v_exponents_1414_, v___x_1452_);
lean_dec(v___x_1452_);
v___y_1351_ = v_a_1451_;
v___y_1352_ = v___x_1457_;
goto v___jp_1350_;
}
}
default: 
{
lean_object* v___x_1458_; uint8_t v___x_1459_; 
v___x_1458_ = lean_nat_add(v___y_1449_, v___x_1294_);
v___x_1459_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_1414_, v___x_1458_);
if (v___x_1459_ == 0)
{
lean_object* v___x_1460_; lean_object* v___x_1461_; uint8_t v___x_1462_; 
lean_dec(v___x_1458_);
v___x_1460_ = lean_box(v___x_1417_);
v___x_1461_ = l_outOfBounds___redArg(v___x_1460_);
lean_dec(v___x_1460_);
v___x_1462_ = lean_unbox(v___x_1461_);
lean_dec(v___x_1461_);
v___y_1434_ = v_a_1451_;
v___y_1435_ = v___y_1449_;
v___y_1436_ = v___x_1462_;
goto v___jp_1433_;
}
else
{
uint8_t v___x_1463_; 
v___x_1463_ = lean_byte_array_fget(v_exponents_1414_, v___x_1458_);
lean_dec(v___x_1458_);
v___y_1434_ = v_a_1451_;
v___y_1435_ = v___y_1449_;
v___y_1436_ = v___x_1463_;
goto v___jp_1433_;
}
}
}
}
v___jp_1464_:
{
if (v___y_1466_ == 0)
{
uint8_t v___x_1467_; 
v___x_1467_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_1414_, v___y_1465_);
if (v___x_1467_ == 0)
{
lean_object* v___x_1468_; lean_object* v___x_1469_; uint8_t v___x_1470_; 
v___x_1468_ = lean_box(v___x_1417_);
v___x_1469_ = l_outOfBounds___redArg(v___x_1468_);
lean_dec(v___x_1468_);
v___x_1470_ = lean_unbox(v___x_1469_);
lean_dec(v___x_1469_);
v___y_1449_ = v___y_1465_;
v___y_1450_ = v___x_1470_;
goto v___jp_1448_;
}
else
{
uint8_t v___x_1471_; 
v___x_1471_ = lean_byte_array_fget(v_exponents_1414_, v___y_1465_);
v___y_1449_ = v___y_1465_;
v___y_1450_ = v___x_1471_;
goto v___jp_1448_;
}
}
else
{
size_t v_pos_1472_; uint8_t v___x_1473_; uint64_t v_a_1474_; 
v_pos_1472_ = lean_usize_of_nat(v___y_1465_);
lean_dec(v___y_1465_);
v___x_1473_ = lean_byte_array_uget(v_exponents_1414_, v_pos_1472_);
v_a_1474_ = lean_uint8_to_uint64(v___x_1473_);
switch(v_width_1413_)
{
case 0:
{
v___y_1317_ = v_a_1474_;
goto v___jp_1316_;
}
case 1:
{
size_t v___x_1475_; size_t v___x_1476_; uint8_t v___x_1477_; uint64_t v___x_1478_; uint64_t v___x_1479_; uint64_t v___x_1480_; uint64_t v___x_1481_; 
v___x_1475_ = ((size_t)1ULL);
v___x_1476_ = lean_usize_add(v_pos_1472_, v___x_1475_);
v___x_1477_ = lean_byte_array_uget(v_exponents_1414_, v___x_1476_);
v___x_1478_ = lean_uint8_to_uint64(v___x_1477_);
v___x_1479_ = 8ULL;
v___x_1480_ = lean_uint64_shift_left(v___x_1478_, v___x_1479_);
v___x_1481_ = lean_uint64_lor(v_a_1474_, v___x_1480_);
v___y_1317_ = v___x_1481_;
goto v___jp_1316_;
}
default: 
{
size_t v___x_1482_; size_t v___x_1483_; uint8_t v___x_1484_; uint64_t v___x_1485_; uint64_t v___x_1486_; uint64_t v___x_1487_; uint64_t v___x_1488_; size_t v___x_1489_; size_t v___x_1490_; uint8_t v___x_1491_; uint64_t v___x_1492_; uint64_t v___x_1493_; uint64_t v___x_1494_; uint64_t v___x_1495_; size_t v___x_1496_; size_t v___x_1497_; uint8_t v___x_1498_; uint64_t v___x_1499_; uint64_t v___x_1500_; uint64_t v___x_1501_; uint64_t v___x_1502_; 
v___x_1482_ = ((size_t)1ULL);
v___x_1483_ = lean_usize_add(v_pos_1472_, v___x_1482_);
v___x_1484_ = lean_byte_array_uget(v_exponents_1414_, v___x_1483_);
v___x_1485_ = lean_uint8_to_uint64(v___x_1484_);
v___x_1486_ = 8ULL;
v___x_1487_ = lean_uint64_shift_left(v___x_1485_, v___x_1486_);
v___x_1488_ = lean_uint64_lor(v_a_1474_, v___x_1487_);
v___x_1489_ = ((size_t)2ULL);
v___x_1490_ = lean_usize_add(v_pos_1472_, v___x_1489_);
v___x_1491_ = lean_byte_array_uget(v_exponents_1414_, v___x_1490_);
v___x_1492_ = lean_uint8_to_uint64(v___x_1491_);
v___x_1493_ = 16ULL;
v___x_1494_ = lean_uint64_shift_left(v___x_1492_, v___x_1493_);
v___x_1495_ = lean_uint64_lor(v___x_1488_, v___x_1494_);
v___x_1496_ = ((size_t)3ULL);
v___x_1497_ = lean_usize_add(v_pos_1472_, v___x_1496_);
v___x_1498_ = lean_byte_array_uget(v_exponents_1414_, v___x_1497_);
v___x_1499_ = lean_uint8_to_uint64(v___x_1498_);
v___x_1500_ = 24ULL;
v___x_1501_ = lean_uint64_shift_left(v___x_1499_, v___x_1500_);
v___x_1502_ = lean_uint64_lor(v___x_1495_, v___x_1501_);
v___y_1317_ = v___x_1502_;
goto v___jp_1316_;
}
}
}
}
v___jp_1503_:
{
lean_object* v_offset_1505_; lean_object* v___x_1506_; lean_object* v___x_1507_; uint8_t v___x_1508_; 
v_offset_1505_ = lean_nat_mul(v___x_1416_, v___y_1504_);
lean_dec(v___x_1416_);
v___x_1506_ = lean_nat_add(v_offset_1505_, v___y_1504_);
v___x_1507_ = lean_byte_array_size(v_exponents_1414_);
v___x_1508_ = lean_nat_dec_le(v___x_1506_, v___x_1507_);
if (v___x_1508_ == 0)
{
lean_dec(v___x_1506_);
v___y_1465_ = v_offset_1505_;
v___y_1466_ = v___x_1508_;
goto v___jp_1464_;
}
else
{
size_t v___x_1509_; lean_object* v___x_1510_; uint8_t v___x_1511_; 
v___x_1509_ = lean_usize_of_nat(v___x_1506_);
v___x_1510_ = lean_usize_to_nat(v___x_1509_);
v___x_1511_ = lean_nat_dec_eq(v___x_1510_, v___x_1506_);
lean_dec(v___x_1506_);
lean_dec(v___x_1510_);
v___y_1465_ = v_offset_1505_;
v___y_1466_ = v___x_1511_;
goto v___jp_1464_;
}
}
}
else
{
lean_inc(v_reducer_1357_);
lean_dec(v___x_1315_);
if (lean_obj_tag(v_reducer_1357_) == 1)
{
lean_object* v_val_1514_; lean_object* v___x_1515_; lean_object* v___x_1516_; lean_object* v_polynomial_1517_; lean_object* v___x_1519_; uint8_t v_isShared_1520_; uint8_t v_isSharedCheck_1693_; 
v_val_1514_ = lean_ctor_get(v_reducer_1357_, 0);
v___x_1515_ = lp_Hex_Hex_Groebner_instInhabitedBasisElement_default;
v___x_1516_ = lean_array_get(v___x_1515_, v_basis_1265_, v_val_1514_);
v_polynomial_1517_ = lean_ctor_get(v___x_1516_, 0);
v_isSharedCheck_1693_ = !lean_is_exclusive(v___x_1516_);
if (v_isSharedCheck_1693_ == 0)
{
lean_object* v_unused_1694_; 
v_unused_1694_ = lean_ctor_get(v___x_1516_, 1);
lean_dec(v_unused_1694_);
v___x_1519_ = v___x_1516_;
v_isShared_1520_ = v_isSharedCheck_1693_;
goto v_resetjp_1518_;
}
else
{
lean_inc(v_polynomial_1517_);
lean_dec(v___x_1516_);
v___x_1519_ = lean_box(0);
v_isShared_1520_ = v_isSharedCheck_1693_;
goto v_resetjp_1518_;
}
v_resetjp_1518_:
{
lean_object* v_support_1521_; lean_object* v___x_1523_; uint8_t v_isShared_1524_; uint8_t v_isSharedCheck_1691_; 
v_support_1521_ = lean_ctor_get(v_polynomial_1517_, 0);
v_isSharedCheck_1691_ = !lean_is_exclusive(v_polynomial_1517_);
if (v_isSharedCheck_1691_ == 0)
{
lean_object* v_unused_1692_; 
v_unused_1692_ = lean_ctor_get(v_polynomial_1517_, 1);
lean_dec(v_unused_1692_);
v___x_1523_ = v_polynomial_1517_;
v_isShared_1524_ = v_isSharedCheck_1691_;
goto v_resetjp_1522_;
}
else
{
lean_inc(v_support_1521_);
lean_dec(v_polynomial_1517_);
v___x_1523_ = lean_box(0);
v_isShared_1524_ = v_isSharedCheck_1691_;
goto v_resetjp_1522_;
}
v_resetjp_1522_:
{
lean_object* v___y_1526_; lean_object* v___y_1527_; lean_object* v___y_1528_; lean_object* v___y_1529_; uint8_t v___y_1530_; uint64_t v___y_1531_; uint8_t v___y_1532_; lean_object* v___y_1543_; lean_object* v___y_1544_; lean_object* v___y_1545_; lean_object* v___y_1546_; lean_object* v___y_1547_; uint8_t v___y_1548_; uint64_t v___y_1549_; uint8_t v___y_1550_; lean_object* v___y_1561_; lean_object* v___y_1562_; lean_object* v___y_1563_; lean_object* v___y_1564_; uint8_t v___y_1565_; lean_object* v___y_1566_; uint8_t v___y_1567_; lean_object* v___y_1575_; uint64_t v___y_1618_; uint8_t v___y_1619_; lean_object* v___x_1648_; lean_object* v___x_1649_; uint8_t v___x_1650_; 
v___x_1648_ = lean_unsigned_to_nat(4u);
v___x_1649_ = lean_byte_array_size(v_support_1521_);
v___x_1650_ = lean_nat_dec_le(v___x_1648_, v___x_1649_);
if (v___x_1650_ == 0)
{
if (v___x_1650_ == 0)
{
uint8_t v___x_1651_; uint64_t v___y_1653_; uint8_t v___y_1654_; uint64_t v___y_1666_; uint8_t v___y_1667_; uint8_t v___y_1679_; uint8_t v___x_1686_; 
v___x_1651_ = 0;
v___x_1686_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_1521_, v___x_1291_);
if (v___x_1686_ == 0)
{
lean_object* v___x_1687_; lean_object* v___x_1688_; uint8_t v___x_1689_; 
v___x_1687_ = lean_box(v___x_1651_);
v___x_1688_ = l_outOfBounds___redArg(v___x_1687_);
lean_dec(v___x_1687_);
v___x_1689_ = lean_unbox(v___x_1688_);
lean_dec(v___x_1688_);
v___y_1679_ = v___x_1689_;
goto v___jp_1678_;
}
else
{
uint8_t v___x_1690_; 
v___x_1690_ = lean_byte_array_fget(v_support_1521_, v___x_1291_);
v___y_1679_ = v___x_1690_;
goto v___jp_1678_;
}
v___jp_1652_:
{
uint64_t v___x_1655_; uint64_t v___x_1656_; uint64_t v___x_1657_; uint64_t v___x_1658_; lean_object* v___x_1659_; uint8_t v___x_1660_; 
v___x_1655_ = lean_uint8_to_uint64(v___y_1654_);
v___x_1656_ = 16ULL;
v___x_1657_ = lean_uint64_shift_left(v___x_1655_, v___x_1656_);
v___x_1658_ = lean_uint64_lor(v___y_1653_, v___x_1657_);
v___x_1659_ = lean_unsigned_to_nat(3u);
v___x_1660_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_1521_, v___x_1659_);
if (v___x_1660_ == 0)
{
lean_object* v___x_1661_; lean_object* v___x_1662_; uint8_t v___x_1663_; 
v___x_1661_ = lean_box(v___x_1651_);
v___x_1662_ = l_outOfBounds___redArg(v___x_1661_);
lean_dec(v___x_1661_);
v___x_1663_ = lean_unbox(v___x_1662_);
lean_dec(v___x_1662_);
v___y_1618_ = v___x_1658_;
v___y_1619_ = v___x_1663_;
goto v___jp_1617_;
}
else
{
uint8_t v___x_1664_; 
v___x_1664_ = lean_byte_array_fget(v_support_1521_, v___x_1659_);
v___y_1618_ = v___x_1658_;
v___y_1619_ = v___x_1664_;
goto v___jp_1617_;
}
}
v___jp_1665_:
{
uint64_t v___x_1668_; uint64_t v___x_1669_; uint64_t v___x_1670_; uint64_t v___x_1671_; lean_object* v___x_1672_; uint8_t v___x_1673_; 
v___x_1668_ = lean_uint8_to_uint64(v___y_1667_);
v___x_1669_ = 8ULL;
v___x_1670_ = lean_uint64_shift_left(v___x_1668_, v___x_1669_);
v___x_1671_ = lean_uint64_lor(v___y_1666_, v___x_1670_);
v___x_1672_ = lean_unsigned_to_nat(2u);
v___x_1673_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_1521_, v___x_1672_);
if (v___x_1673_ == 0)
{
lean_object* v___x_1674_; lean_object* v___x_1675_; uint8_t v___x_1676_; 
v___x_1674_ = lean_box(v___x_1651_);
v___x_1675_ = l_outOfBounds___redArg(v___x_1674_);
lean_dec(v___x_1674_);
v___x_1676_ = lean_unbox(v___x_1675_);
lean_dec(v___x_1675_);
v___y_1653_ = v___x_1671_;
v___y_1654_ = v___x_1676_;
goto v___jp_1652_;
}
else
{
uint8_t v___x_1677_; 
v___x_1677_ = lean_byte_array_fget(v_support_1521_, v___x_1672_);
v___y_1653_ = v___x_1671_;
v___y_1654_ = v___x_1677_;
goto v___jp_1652_;
}
}
v___jp_1678_:
{
uint64_t v_a_1680_; uint8_t v___x_1681_; 
v_a_1680_ = lean_uint8_to_uint64(v___y_1679_);
v___x_1681_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_1521_, v___x_1294_);
if (v___x_1681_ == 0)
{
lean_object* v___x_1682_; lean_object* v___x_1683_; uint8_t v___x_1684_; 
v___x_1682_ = lean_box(v___x_1651_);
v___x_1683_ = l_outOfBounds___redArg(v___x_1682_);
lean_dec(v___x_1682_);
v___x_1684_ = lean_unbox(v___x_1683_);
lean_dec(v___x_1683_);
v___y_1666_ = v_a_1680_;
v___y_1667_ = v___x_1684_;
goto v___jp_1665_;
}
else
{
uint8_t v___x_1685_; 
v___x_1685_ = lean_byte_array_fget(v_support_1521_, v___x_1294_);
v___y_1666_ = v_a_1680_;
v___y_1667_ = v___x_1685_;
goto v___jp_1665_;
}
}
}
else
{
goto v___jp_1625_;
}
}
else
{
goto v___jp_1625_;
}
v___jp_1525_:
{
uint64_t v___x_1533_; uint64_t v___x_1534_; uint64_t v___x_1535_; uint64_t v___x_1536_; uint8_t v___x_1537_; 
v___x_1533_ = lean_uint8_to_uint64(v___y_1532_);
v___x_1534_ = 16ULL;
v___x_1535_ = lean_uint64_shift_left(v___x_1533_, v___x_1534_);
v___x_1536_ = lean_uint64_lor(v___y_1531_, v___x_1535_);
v___x_1537_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___y_1527_, v___y_1526_);
if (v___x_1537_ == 0)
{
lean_object* v___x_1538_; lean_object* v___x_1539_; uint8_t v___x_1540_; 
v___x_1538_ = lean_box(v___y_1530_);
v___x_1539_ = l_outOfBounds___redArg(v___x_1538_);
lean_dec(v___x_1538_);
v___x_1540_ = lean_unbox(v___x_1539_);
lean_dec(v___x_1539_);
v___y_1400_ = v___y_1526_;
v___y_1401_ = v___x_1536_;
v___y_1402_ = v___y_1528_;
v___y_1403_ = v___y_1529_;
v___y_1404_ = v___x_1540_;
goto v___jp_1399_;
}
else
{
uint8_t v___x_1541_; 
v___x_1541_ = lean_byte_array_fget(v___y_1527_, v___y_1526_);
v___y_1400_ = v___y_1526_;
v___y_1401_ = v___x_1536_;
v___y_1402_ = v___y_1528_;
v___y_1403_ = v___y_1529_;
v___y_1404_ = v___x_1541_;
goto v___jp_1399_;
}
}
v___jp_1542_:
{
uint64_t v___x_1551_; uint64_t v___x_1552_; uint64_t v___x_1553_; uint64_t v___x_1554_; uint8_t v___x_1555_; 
v___x_1551_ = lean_uint8_to_uint64(v___y_1550_);
v___x_1552_ = 8ULL;
v___x_1553_ = lean_uint64_shift_left(v___x_1551_, v___x_1552_);
v___x_1554_ = lean_uint64_lor(v___y_1549_, v___x_1553_);
v___x_1555_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___y_1544_, v___y_1547_);
if (v___x_1555_ == 0)
{
lean_object* v___x_1556_; lean_object* v___x_1557_; uint8_t v___x_1558_; 
v___x_1556_ = lean_box(v___y_1548_);
v___x_1557_ = l_outOfBounds___redArg(v___x_1556_);
lean_dec(v___x_1556_);
v___x_1558_ = lean_unbox(v___x_1557_);
lean_dec(v___x_1557_);
v___y_1526_ = v___y_1543_;
v___y_1527_ = v___y_1544_;
v___y_1528_ = v___y_1545_;
v___y_1529_ = v___y_1546_;
v___y_1530_ = v___y_1548_;
v___y_1531_ = v___x_1554_;
v___y_1532_ = v___x_1558_;
goto v___jp_1525_;
}
else
{
uint8_t v___x_1559_; 
v___x_1559_ = lean_byte_array_fget(v___y_1544_, v___y_1547_);
v___y_1526_ = v___y_1543_;
v___y_1527_ = v___y_1544_;
v___y_1528_ = v___y_1545_;
v___y_1529_ = v___y_1546_;
v___y_1530_ = v___y_1548_;
v___y_1531_ = v___x_1554_;
v___y_1532_ = v___x_1559_;
goto v___jp_1525_;
}
}
v___jp_1560_:
{
uint64_t v_a_1568_; uint8_t v___x_1569_; 
v_a_1568_ = lean_uint8_to_uint64(v___y_1567_);
v___x_1569_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___y_1562_, v___x_1294_);
if (v___x_1569_ == 0)
{
lean_object* v___x_1570_; lean_object* v___x_1571_; uint8_t v___x_1572_; 
v___x_1570_ = lean_box(v___y_1565_);
v___x_1571_ = l_outOfBounds___redArg(v___x_1570_);
lean_dec(v___x_1570_);
v___x_1572_ = lean_unbox(v___x_1571_);
lean_dec(v___x_1571_);
v___y_1543_ = v___y_1561_;
v___y_1544_ = v___y_1562_;
v___y_1545_ = v___y_1563_;
v___y_1546_ = v___y_1564_;
v___y_1547_ = v___y_1566_;
v___y_1548_ = v___y_1565_;
v___y_1549_ = v_a_1568_;
v___y_1550_ = v___x_1572_;
goto v___jp_1542_;
}
else
{
uint8_t v___x_1573_; 
v___x_1573_ = lean_byte_array_fget(v___y_1562_, v___x_1294_);
v___y_1543_ = v___y_1561_;
v___y_1544_ = v___y_1562_;
v___y_1545_ = v___y_1563_;
v___y_1546_ = v___y_1564_;
v___y_1547_ = v___y_1566_;
v___y_1548_ = v___y_1565_;
v___y_1549_ = v_a_1568_;
v___y_1550_ = v___x_1573_;
goto v___jp_1542_;
}
}
v___jp_1574_:
{
lean_object* v_metadata_1576_; lean_object* v___x_1577_; lean_object* v___x_1578_; uint64_t v___x_1579_; lean_object* v___x_1580_; lean_object* v___x_1581_; uint64_t v___x_1582_; lean_object* v___x_1583_; uint8_t v___x_1584_; 
v_metadata_1576_ = lean_ctor_get(v_table_1263_, 2);
v___x_1577_ = lean_unsigned_to_nat(3u);
v___x_1578_ = lean_nat_mul(v___x_1577_, v___y_1575_);
lean_dec(v___y_1575_);
v___x_1579_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1576_, v___x_1578_);
v___x_1580_ = lean_uint64_to_nat(v___x_1579_);
v___x_1581_ = lean_nat_mul(v___x_1577_, v_monomial_1264_);
v___x_1582_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1576_, v___x_1581_);
v___x_1583_ = lean_uint64_to_nat(v___x_1582_);
v___x_1584_ = lean_nat_dec_le(v___x_1580_, v___x_1583_);
lean_dec(v___x_1583_);
if (v___x_1584_ == 0)
{
lean_dec(v___x_1581_);
lean_dec(v___x_1580_);
lean_dec(v___x_1578_);
lean_del_object(v___x_1523_);
lean_dec_ref(v_support_1521_);
lean_del_object(v___x_1519_);
lean_dec_ref_known(v_reducer_1357_, 1);
lean_del_object(v___x_1288_);
lean_del_object(v___x_1283_);
lean_del_object(v___x_1278_);
goto v___jp_1309_;
}
else
{
lean_object* v___x_1585_; uint64_t v___x_1586_; lean_object* v___x_1587_; uint64_t v___x_1588_; uint64_t v___x_1589_; uint8_t v___x_1590_; 
v___x_1585_ = lean_nat_add(v___x_1578_, v___x_1294_);
lean_dec(v___x_1578_);
v___x_1586_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1576_, v___x_1585_);
lean_dec(v___x_1585_);
v___x_1587_ = lean_nat_add(v___x_1581_, v___x_1294_);
lean_dec(v___x_1581_);
v___x_1588_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1576_, v___x_1587_);
lean_dec(v___x_1587_);
v___x_1589_ = lean_uint64_land(v___x_1586_, v___x_1588_);
v___x_1590_ = lean_uint64_dec_eq(v___x_1589_, v___x_1586_);
if (v___x_1590_ == 0)
{
lean_dec(v___x_1580_);
lean_del_object(v___x_1523_);
lean_dec_ref(v_support_1521_);
lean_del_object(v___x_1519_);
lean_dec_ref_known(v_reducer_1357_, 1);
lean_del_object(v___x_1288_);
lean_del_object(v___x_1283_);
lean_del_object(v___x_1278_);
goto v___jp_1309_;
}
else
{
if (lean_obj_tag(v_snd_1286_) == 1)
{
lean_object* v_val_1591_; lean_object* v___x_1592_; lean_object* v_polynomial_1593_; lean_object* v_support_1594_; lean_object* v___x_1595_; lean_object* v___x_1596_; lean_object* v___x_1597_; lean_object* v___x_1598_; lean_object* v___x_1599_; uint8_t v___x_1600_; 
lean_del_object(v___x_1523_);
lean_del_object(v___x_1519_);
v_val_1591_ = lean_ctor_get(v_snd_1286_, 0);
v___x_1592_ = lean_array_get_borrowed(v___x_1515_, v_basis_1265_, v_val_1591_);
v_polynomial_1593_ = lean_ctor_get(v___x_1592_, 0);
v_support_1594_ = lean_ctor_get(v_polynomial_1593_, 0);
v___x_1595_ = lean_byte_array_size(v_support_1521_);
lean_dec_ref(v_support_1521_);
v___x_1596_ = lean_unsigned_to_nat(2u);
v___x_1597_ = lean_nat_shiftr(v___x_1595_, v___x_1596_);
v___x_1598_ = lean_byte_array_size(v_support_1594_);
v___x_1599_ = lean_nat_shiftr(v___x_1598_, v___x_1596_);
v___x_1600_ = lean_nat_dec_lt(v___x_1597_, v___x_1599_);
if (v___x_1600_ == 0)
{
uint8_t v___x_1601_; 
v___x_1601_ = lean_nat_dec_eq(v___x_1597_, v___x_1599_);
lean_dec(v___x_1599_);
lean_dec(v___x_1597_);
if (v___x_1601_ == 0)
{
lean_dec(v___x_1580_);
lean_dec_ref_known(v_reducer_1357_, 1);
goto v___jp_1299_;
}
else
{
lean_object* v___x_1602_; uint8_t v___x_1603_; 
v___x_1602_ = lean_unsigned_to_nat(4u);
v___x_1603_ = lean_nat_dec_le(v___x_1602_, v___x_1598_);
if (v___x_1603_ == 0)
{
if (v___x_1603_ == 0)
{
uint8_t v___x_1604_; uint8_t v___x_1605_; 
v___x_1604_ = 0;
v___x_1605_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_support_1594_, v___x_1291_);
if (v___x_1605_ == 0)
{
lean_object* v___x_1606_; lean_object* v___x_1607_; uint8_t v___x_1608_; 
v___x_1606_ = lean_box(v___x_1604_);
v___x_1607_ = l_outOfBounds___redArg(v___x_1606_);
lean_dec(v___x_1606_);
v___x_1608_ = lean_unbox(v___x_1607_);
lean_dec(v___x_1607_);
v___y_1561_ = v___x_1577_;
v___y_1562_ = v_support_1594_;
v___y_1563_ = v___x_1580_;
v___y_1564_ = v_metadata_1576_;
v___y_1565_ = v___x_1604_;
v___y_1566_ = v___x_1596_;
v___y_1567_ = v___x_1608_;
goto v___jp_1560_;
}
else
{
uint8_t v___x_1609_; 
v___x_1609_ = lean_byte_array_fget(v_support_1594_, v___x_1291_);
v___y_1561_ = v___x_1577_;
v___y_1562_ = v_support_1594_;
v___y_1563_ = v___x_1580_;
v___y_1564_ = v_metadata_1576_;
v___y_1565_ = v___x_1604_;
v___y_1566_ = v___x_1596_;
v___y_1567_ = v___x_1609_;
goto v___jp_1560_;
}
}
else
{
v___y_1373_ = v___x_1577_;
v___y_1374_ = v_support_1594_;
v___y_1375_ = v___x_1580_;
v___y_1376_ = v_metadata_1576_;
goto v___jp_1372_;
}
}
else
{
v___y_1373_ = v___x_1577_;
v___y_1374_ = v_support_1594_;
v___y_1375_ = v___x_1580_;
v___y_1376_ = v_metadata_1576_;
goto v___jp_1372_;
}
}
}
else
{
lean_dec(v___x_1599_);
lean_dec(v___x_1597_);
lean_dec_ref_known(v_snd_1286_, 1);
lean_dec(v___x_1580_);
lean_del_object(v___x_1288_);
lean_del_object(v___x_1283_);
lean_del_object(v___x_1278_);
goto v___jp_1359_;
}
}
else
{
lean_object* v___x_1611_; 
lean_dec(v___x_1580_);
lean_dec_ref(v_support_1521_);
lean_del_object(v___x_1288_);
lean_dec(v_snd_1286_);
lean_del_object(v___x_1283_);
lean_del_object(v___x_1278_);
if (v_isShared_1524_ == 0)
{
lean_ctor_set(v___x_1523_, 1, v_reducer_1357_);
lean_ctor_set(v___x_1523_, 0, v___x_1297_);
v___x_1611_ = v___x_1523_;
goto v_reusejp_1610_;
}
else
{
lean_object* v_reuseFailAlloc_1616_; 
v_reuseFailAlloc_1616_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1616_, 0, v___x_1297_);
lean_ctor_set(v_reuseFailAlloc_1616_, 1, v_reducer_1357_);
v___x_1611_ = v_reuseFailAlloc_1616_;
goto v_reusejp_1610_;
}
v_reusejp_1610_:
{
lean_object* v___x_1613_; 
if (v_isShared_1520_ == 0)
{
lean_ctor_set(v___x_1519_, 1, v___x_1611_);
lean_ctor_set(v___x_1519_, 0, v___x_1298_);
v___x_1613_ = v___x_1519_;
goto v_reusejp_1612_;
}
else
{
lean_object* v_reuseFailAlloc_1615_; 
v_reuseFailAlloc_1615_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1615_, 0, v___x_1298_);
lean_ctor_set(v_reuseFailAlloc_1615_, 1, v___x_1611_);
v___x_1613_ = v_reuseFailAlloc_1615_;
goto v_reusejp_1612_;
}
v_reusejp_1612_:
{
lean_object* v___x_1614_; 
v___x_1614_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1614_, 0, v___x_1290_);
lean_ctor_set(v___x_1614_, 1, v___x_1613_);
v_a_1272_ = v___x_1614_;
goto v___jp_1271_;
}
}
}
}
}
}
v___jp_1617_:
{
uint64_t v___x_1620_; uint64_t v___x_1621_; uint64_t v___x_1622_; uint64_t v___x_1623_; lean_object* v___x_1624_; 
v___x_1620_ = lean_uint8_to_uint64(v___y_1619_);
v___x_1621_ = 24ULL;
v___x_1622_ = lean_uint64_shift_left(v___x_1620_, v___x_1621_);
v___x_1623_ = lean_uint64_lor(v___y_1618_, v___x_1622_);
v___x_1624_ = lean_uint64_to_nat(v___x_1623_);
v___y_1575_ = v___x_1624_;
goto v___jp_1574_;
}
v___jp_1625_:
{
size_t v_pos_1626_; uint8_t v___x_1627_; uint64_t v_a_1628_; size_t v___x_1629_; uint8_t v___x_1630_; uint64_t v___x_1631_; uint64_t v___x_1632_; uint64_t v___x_1633_; uint64_t v___x_1634_; size_t v___x_1635_; uint8_t v___x_1636_; uint64_t v___x_1637_; uint64_t v___x_1638_; uint64_t v___x_1639_; uint64_t v___x_1640_; size_t v___x_1641_; uint8_t v___x_1642_; uint64_t v___x_1643_; uint64_t v___x_1644_; uint64_t v___x_1645_; uint64_t v___x_1646_; lean_object* v___x_1647_; 
v_pos_1626_ = ((size_t)0ULL);
v___x_1627_ = lean_byte_array_uget(v_support_1521_, v_pos_1626_);
v_a_1628_ = lean_uint8_to_uint64(v___x_1627_);
v___x_1629_ = ((size_t)1ULL);
v___x_1630_ = lean_byte_array_uget(v_support_1521_, v___x_1629_);
v___x_1631_ = lean_uint8_to_uint64(v___x_1630_);
v___x_1632_ = 8ULL;
v___x_1633_ = lean_uint64_shift_left(v___x_1631_, v___x_1632_);
v___x_1634_ = lean_uint64_lor(v_a_1628_, v___x_1633_);
v___x_1635_ = ((size_t)2ULL);
v___x_1636_ = lean_byte_array_uget(v_support_1521_, v___x_1635_);
v___x_1637_ = lean_uint8_to_uint64(v___x_1636_);
v___x_1638_ = 16ULL;
v___x_1639_ = lean_uint64_shift_left(v___x_1637_, v___x_1638_);
v___x_1640_ = lean_uint64_lor(v___x_1634_, v___x_1639_);
v___x_1641_ = ((size_t)3ULL);
v___x_1642_ = lean_byte_array_uget(v_support_1521_, v___x_1641_);
v___x_1643_ = lean_uint8_to_uint64(v___x_1642_);
v___x_1644_ = 24ULL;
v___x_1645_ = lean_uint64_shift_left(v___x_1643_, v___x_1644_);
v___x_1646_ = lean_uint64_lor(v___x_1640_, v___x_1645_);
v___x_1647_ = lean_uint64_to_nat(v___x_1646_);
v___y_1575_ = v___x_1647_;
goto v___jp_1574_;
}
}
}
}
else
{
lean_object* v___x_1695_; lean_object* v___x_1696_; lean_object* v___x_1697_; 
lean_dec(v_reducer_1357_);
lean_del_object(v___x_1288_);
lean_del_object(v___x_1283_);
lean_del_object(v___x_1278_);
v___x_1695_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1695_, 0, v___x_1297_);
lean_ctor_set(v___x_1695_, 1, v_snd_1286_);
v___x_1696_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1696_, 0, v___x_1298_);
lean_ctor_set(v___x_1696_, 1, v___x_1695_);
v___x_1697_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1697_, 0, v___x_1290_);
lean_ctor_set(v___x_1697_, 1, v___x_1696_);
v_a_1272_ = v___x_1697_;
goto v___jp_1271_;
}
}
v___jp_1316_:
{
lean_object* v_edges_1318_; lean_object* v___x_1320_; uint8_t v_isShared_1321_; uint8_t v_isSharedCheck_1340_; 
v_edges_1318_ = lean_ctor_get(v___x_1315_, 0);
v_isSharedCheck_1340_ = !lean_is_exclusive(v___x_1315_);
if (v_isSharedCheck_1340_ == 0)
{
lean_object* v_unused_1341_; lean_object* v_unused_1342_; 
v_unused_1341_ = lean_ctor_get(v___x_1315_, 2);
lean_dec(v_unused_1341_);
v_unused_1342_ = lean_ctor_get(v___x_1315_, 1);
lean_dec(v_unused_1342_);
v___x_1320_ = v___x_1315_;
v_isShared_1321_ = v_isSharedCheck_1340_;
goto v_resetjp_1319_;
}
else
{
lean_inc(v_edges_1318_);
lean_dec(v___x_1315_);
v___x_1320_ = lean_box(0);
v_isShared_1321_ = v_isSharedCheck_1340_;
goto v_resetjp_1319_;
}
v_resetjp_1319_:
{
lean_object* v___x_1322_; lean_object* v___x_1323_; lean_object* v___x_1324_; lean_object* v___x_1325_; uint8_t v___x_1326_; 
v___x_1322_ = lean_byte_array_size(v_edges_1318_);
v___x_1323_ = lean_unsigned_to_nat(3u);
v___x_1324_ = lean_nat_shiftr(v___x_1322_, v___x_1323_);
v___x_1325_ = lean_nat_add(v___x_1298_, v___x_1324_);
v___x_1326_ = lean_nat_dec_lt(v_maxWork_1260_, v___x_1325_);
if (v___x_1326_ == 0)
{
lean_object* v___x_1328_; 
lean_dec(v___x_1298_);
if (v_isShared_1321_ == 0)
{
lean_ctor_set(v___x_1320_, 2, v___x_1294_);
lean_ctor_set(v___x_1320_, 1, v___x_1324_);
lean_ctor_set(v___x_1320_, 0, v___x_1291_);
v___x_1328_ = v___x_1320_;
goto v_reusejp_1327_;
}
else
{
lean_object* v_reuseFailAlloc_1333_; 
v_reuseFailAlloc_1333_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_1333_, 0, v___x_1291_);
lean_ctor_set(v_reuseFailAlloc_1333_, 1, v___x_1324_);
lean_ctor_set(v_reuseFailAlloc_1333_, 2, v___x_1294_);
v___x_1328_ = v_reuseFailAlloc_1333_;
goto v_reusejp_1327_;
}
v_reusejp_1327_:
{
lean_object* v___x_1329_; lean_object* v___x_1330_; lean_object* v___x_1331_; lean_object* v___x_1332_; 
v___x_1329_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0___redArg(v___y_1317_, v_edges_1318_, v___x_1328_, v___x_1297_, v___x_1291_);
lean_dec_ref(v___x_1328_);
lean_dec_ref(v_edges_1318_);
v___x_1330_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1330_, 0, v___x_1329_);
lean_ctor_set(v___x_1330_, 1, v_snd_1286_);
v___x_1331_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1331_, 0, v___x_1325_);
lean_ctor_set(v___x_1331_, 1, v___x_1330_);
v___x_1332_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1332_, 0, v___x_1290_);
lean_ctor_set(v___x_1332_, 1, v___x_1331_);
v_a_1272_ = v___x_1332_;
goto v___jp_1271_;
}
}
else
{
lean_object* v___x_1334_; lean_object* v___x_1335_; lean_object* v___x_1336_; lean_object* v___x_1337_; lean_object* v___x_1338_; lean_object* v___x_1339_; 
lean_dec(v___x_1325_);
lean_dec(v___x_1324_);
lean_del_object(v___x_1320_);
lean_dec_ref(v_edges_1318_);
lean_dec(v_i_1268_);
v___x_1334_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg___closed__0));
lean_inc(v___x_1298_);
v___x_1335_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1335_, 0, v___x_1334_);
lean_ctor_set(v___x_1335_, 1, v___x_1298_);
v___x_1336_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1336_, 0, v___x_1335_);
v___x_1337_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1337_, 0, v___x_1297_);
lean_ctor_set(v___x_1337_, 1, v_snd_1286_);
v___x_1338_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1338_, 0, v___x_1298_);
lean_ctor_set(v___x_1338_, 1, v___x_1337_);
v___x_1339_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1339_, 0, v___x_1336_);
lean_ctor_set(v___x_1339_, 1, v___x_1338_);
return v___x_1339_;
}
}
}
v___jp_1343_:
{
uint64_t v___x_1346_; uint64_t v___x_1347_; uint64_t v___x_1348_; uint64_t v___x_1349_; 
v___x_1346_ = lean_uint8_to_uint64(v___y_1345_);
v___x_1347_ = 24ULL;
v___x_1348_ = lean_uint64_shift_left(v___x_1346_, v___x_1347_);
v___x_1349_ = lean_uint64_lor(v___y_1344_, v___x_1348_);
v___y_1317_ = v___x_1349_;
goto v___jp_1316_;
}
v___jp_1350_:
{
uint64_t v___x_1353_; uint64_t v___x_1354_; uint64_t v___x_1355_; uint64_t v___x_1356_; 
v___x_1353_ = lean_uint8_to_uint64(v___y_1352_);
v___x_1354_ = 8ULL;
v___x_1355_ = lean_uint64_shift_left(v___x_1353_, v___x_1354_);
v___x_1356_ = lean_uint64_lor(v___y_1351_, v___x_1355_);
v___y_1317_ = v___x_1356_;
goto v___jp_1316_;
}
v___jp_1359_:
{
lean_object* v___x_1360_; lean_object* v___x_1361_; lean_object* v___x_1362_; 
v___x_1360_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1360_, 0, v___x_1297_);
lean_ctor_set(v___x_1360_, 1, v_reducer_1357_);
v___x_1361_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1361_, 0, v___x_1298_);
lean_ctor_set(v___x_1361_, 1, v___x_1360_);
v___x_1362_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1362_, 0, v___x_1290_);
lean_ctor_set(v___x_1362_, 1, v___x_1361_);
v_a_1272_ = v___x_1362_;
goto v___jp_1271_;
}
v___jp_1363_:
{
lean_object* v___x_1368_; uint64_t v___x_1369_; lean_object* v___x_1370_; uint8_t v___x_1371_; 
v___x_1368_ = lean_nat_mul(v___y_1364_, v___y_1367_);
lean_dec(v___y_1367_);
v___x_1369_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v___y_1366_, v___x_1368_);
lean_dec(v___x_1368_);
v___x_1370_ = lean_uint64_to_nat(v___x_1369_);
v___x_1371_ = lean_nat_dec_lt(v___x_1370_, v___y_1365_);
lean_dec(v___y_1365_);
lean_dec(v___x_1370_);
if (v___x_1371_ == 0)
{
lean_dec(v_reducer_1357_);
goto v___jp_1299_;
}
else
{
lean_del_object(v___x_1288_);
lean_dec(v_snd_1286_);
lean_del_object(v___x_1283_);
lean_del_object(v___x_1278_);
goto v___jp_1359_;
}
}
v___jp_1372_:
{
size_t v_pos_1377_; uint8_t v___x_1378_; uint64_t v_a_1379_; size_t v___x_1380_; uint8_t v___x_1381_; uint64_t v___x_1382_; uint64_t v___x_1383_; uint64_t v___x_1384_; uint64_t v___x_1385_; size_t v___x_1386_; uint8_t v___x_1387_; uint64_t v___x_1388_; uint64_t v___x_1389_; uint64_t v___x_1390_; uint64_t v___x_1391_; size_t v___x_1392_; uint8_t v___x_1393_; uint64_t v___x_1394_; uint64_t v___x_1395_; uint64_t v___x_1396_; uint64_t v___x_1397_; lean_object* v___x_1398_; 
v_pos_1377_ = ((size_t)0ULL);
v___x_1378_ = lean_byte_array_uget(v___y_1374_, v_pos_1377_);
v_a_1379_ = lean_uint8_to_uint64(v___x_1378_);
v___x_1380_ = ((size_t)1ULL);
v___x_1381_ = lean_byte_array_uget(v___y_1374_, v___x_1380_);
v___x_1382_ = lean_uint8_to_uint64(v___x_1381_);
v___x_1383_ = 8ULL;
v___x_1384_ = lean_uint64_shift_left(v___x_1382_, v___x_1383_);
v___x_1385_ = lean_uint64_lor(v_a_1379_, v___x_1384_);
v___x_1386_ = ((size_t)2ULL);
v___x_1387_ = lean_byte_array_uget(v___y_1374_, v___x_1386_);
v___x_1388_ = lean_uint8_to_uint64(v___x_1387_);
v___x_1389_ = 16ULL;
v___x_1390_ = lean_uint64_shift_left(v___x_1388_, v___x_1389_);
v___x_1391_ = lean_uint64_lor(v___x_1385_, v___x_1390_);
v___x_1392_ = ((size_t)3ULL);
v___x_1393_ = lean_byte_array_uget(v___y_1374_, v___x_1392_);
v___x_1394_ = lean_uint8_to_uint64(v___x_1393_);
v___x_1395_ = 24ULL;
v___x_1396_ = lean_uint64_shift_left(v___x_1394_, v___x_1395_);
v___x_1397_ = lean_uint64_lor(v___x_1391_, v___x_1396_);
v___x_1398_ = lean_uint64_to_nat(v___x_1397_);
v___y_1364_ = v___y_1373_;
v___y_1365_ = v___y_1375_;
v___y_1366_ = v___y_1376_;
v___y_1367_ = v___x_1398_;
goto v___jp_1363_;
}
v___jp_1399_:
{
uint64_t v___x_1405_; uint64_t v___x_1406_; uint64_t v___x_1407_; uint64_t v___x_1408_; lean_object* v___x_1409_; 
v___x_1405_ = lean_uint8_to_uint64(v___y_1404_);
v___x_1406_ = 24ULL;
v___x_1407_ = lean_uint64_shift_left(v___x_1405_, v___x_1406_);
v___x_1408_ = lean_uint64_lor(v___y_1401_, v___x_1407_);
v___x_1409_ = lean_uint64_to_nat(v___x_1408_);
v___y_1364_ = v___y_1400_;
v___y_1365_ = v___y_1402_;
v___y_1366_ = v___y_1403_;
v___y_1367_ = v___x_1409_;
goto v___jp_1363_;
}
}
else
{
lean_object* v___x_1698_; lean_object* v___x_1699_; lean_object* v___x_1700_; lean_object* v___x_1701_; lean_object* v___x_1702_; lean_object* v___x_1703_; 
lean_dec(v___x_1298_);
lean_dec(v___x_1296_);
lean_del_object(v___x_1288_);
lean_del_object(v___x_1283_);
lean_del_object(v___x_1278_);
lean_dec(v_i_1268_);
v___x_1698_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg___closed__0));
lean_inc(v_fst_1281_);
v___x_1699_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1699_, 0, v___x_1698_);
lean_ctor_set(v___x_1699_, 1, v_fst_1281_);
v___x_1700_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1700_, 0, v___x_1699_);
v___x_1701_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1701_, 0, v___x_1297_);
lean_ctor_set(v___x_1701_, 1, v_snd_1286_);
v___x_1702_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1702_, 0, v_fst_1281_);
lean_ctor_set(v___x_1702_, 1, v___x_1701_);
v___x_1703_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1703_, 0, v___x_1700_);
lean_ctor_set(v___x_1703_, 1, v___x_1702_);
return v___x_1703_;
}
v___jp_1299_:
{
lean_object* v___x_1301_; 
if (v_isShared_1289_ == 0)
{
lean_ctor_set(v___x_1288_, 0, v___x_1297_);
v___x_1301_ = v___x_1288_;
goto v_reusejp_1300_;
}
else
{
lean_object* v_reuseFailAlloc_1308_; 
v_reuseFailAlloc_1308_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1308_, 0, v___x_1297_);
lean_ctor_set(v_reuseFailAlloc_1308_, 1, v_snd_1286_);
v___x_1301_ = v_reuseFailAlloc_1308_;
goto v_reusejp_1300_;
}
v_reusejp_1300_:
{
lean_object* v___x_1303_; 
if (v_isShared_1284_ == 0)
{
lean_ctor_set(v___x_1283_, 1, v___x_1301_);
lean_ctor_set(v___x_1283_, 0, v___x_1298_);
v___x_1303_ = v___x_1283_;
goto v_reusejp_1302_;
}
else
{
lean_object* v_reuseFailAlloc_1307_; 
v_reuseFailAlloc_1307_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1307_, 0, v___x_1298_);
lean_ctor_set(v_reuseFailAlloc_1307_, 1, v___x_1301_);
v___x_1303_ = v_reuseFailAlloc_1307_;
goto v_reusejp_1302_;
}
v_reusejp_1302_:
{
lean_object* v___x_1305_; 
if (v_isShared_1279_ == 0)
{
lean_ctor_set(v___x_1278_, 1, v___x_1303_);
lean_ctor_set(v___x_1278_, 0, v___x_1290_);
v___x_1305_ = v___x_1278_;
goto v_reusejp_1304_;
}
else
{
lean_object* v_reuseFailAlloc_1306_; 
v_reuseFailAlloc_1306_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1306_, 0, v___x_1290_);
lean_ctor_set(v_reuseFailAlloc_1306_, 1, v___x_1303_);
v___x_1305_ = v_reuseFailAlloc_1306_;
goto v_reusejp_1304_;
}
v_reusejp_1304_:
{
v_a_1272_ = v___x_1305_;
goto v___jp_1271_;
}
}
}
}
v___jp_1309_:
{
lean_object* v___x_1310_; lean_object* v___x_1311_; lean_object* v___x_1312_; 
v___x_1310_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1310_, 0, v___x_1297_);
lean_ctor_set(v___x_1310_, 1, v_snd_1286_);
v___x_1311_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1311_, 0, v___x_1298_);
lean_ctor_set(v___x_1311_, 1, v___x_1310_);
v___x_1312_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1312_, 0, v___x_1290_);
lean_ctor_set(v___x_1312_, 1, v___x_1311_);
v_a_1272_ = v___x_1312_;
goto v___jp_1271_;
}
}
else
{
lean_object* v___x_1705_; 
lean_dec(v_i_1268_);
if (v_isShared_1289_ == 0)
{
v___x_1705_ = v___x_1288_;
goto v_reusejp_1704_;
}
else
{
lean_object* v_reuseFailAlloc_1712_; 
v_reuseFailAlloc_1712_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1712_, 0, v_fst_1285_);
lean_ctor_set(v_reuseFailAlloc_1712_, 1, v_snd_1286_);
v___x_1705_ = v_reuseFailAlloc_1712_;
goto v_reusejp_1704_;
}
v_reusejp_1704_:
{
lean_object* v___x_1707_; 
if (v_isShared_1284_ == 0)
{
lean_ctor_set(v___x_1283_, 1, v___x_1705_);
v___x_1707_ = v___x_1283_;
goto v_reusejp_1706_;
}
else
{
lean_object* v_reuseFailAlloc_1711_; 
v_reuseFailAlloc_1711_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1711_, 0, v_fst_1281_);
lean_ctor_set(v_reuseFailAlloc_1711_, 1, v___x_1705_);
v___x_1707_ = v_reuseFailAlloc_1711_;
goto v_reusejp_1706_;
}
v_reusejp_1706_:
{
lean_object* v___x_1709_; 
if (v_isShared_1279_ == 0)
{
lean_ctor_set(v___x_1278_, 1, v___x_1707_);
lean_ctor_set(v___x_1278_, 0, v___x_1290_);
v___x_1709_ = v___x_1278_;
goto v_reusejp_1708_;
}
else
{
lean_object* v_reuseFailAlloc_1710_; 
v_reuseFailAlloc_1710_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1710_, 0, v___x_1290_);
lean_ctor_set(v_reuseFailAlloc_1710_, 1, v___x_1707_);
v___x_1709_ = v_reuseFailAlloc_1710_;
goto v_reusejp_1708_;
}
v_reusejp_1708_:
{
return v___x_1709_;
}
}
}
}
}
}
}
}
v___jp_1271_:
{
lean_object* v___x_1273_; 
v___x_1273_ = lean_nat_add(v_i_1268_, v_step_1270_);
lean_dec(v_i_1268_);
v_b_1267_ = v_a_1272_;
v_i_1268_ = v___x_1273_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg___boxed(lean_object* v_maxWork_1717_, lean_object* v___x_1718_, lean_object* v_context_1719_, lean_object* v_table_1720_, lean_object* v_monomial_1721_, lean_object* v_basis_1722_, lean_object* v_range_1723_, lean_object* v_b_1724_, lean_object* v_i_1725_){
_start:
{
lean_object* v_res_1726_; 
v_res_1726_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg(v_maxWork_1717_, v___x_1718_, v_context_1719_, v_table_1720_, v_monomial_1721_, v_basis_1722_, v_range_1723_, v_b_1724_, v_i_1725_);
lean_dec_ref(v_range_1723_);
lean_dec_ref(v_basis_1722_);
lean_dec(v_monomial_1721_);
lean_dec_ref(v_table_1720_);
lean_dec_ref(v_context_1719_);
lean_dec_ref(v___x_1718_);
lean_dec(v_maxWork_1717_);
return v_res_1726_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin(lean_object* v_context_1734_, lean_object* v_index_1735_, lean_object* v_basis_1736_, lean_object* v_table_1737_, lean_object* v_monomial_1738_, lean_object* v_initialWork_1739_, lean_object* v_maxWork_1740_){
_start:
{
lean_object* v___x_1741_; lean_object* v___x_1742_; lean_object* v_result_1743_; lean_object* v___x_1744_; lean_object* v___x_1745_; lean_object* v___x_1746_; lean_object* v___x_1747_; lean_object* v___x_1748_; lean_object* v___x_1749_; lean_object* v_fst_1750_; 
v___x_1741_ = lean_unsigned_to_nat(0u);
v___x_1742_ = lean_unsigned_to_nat(1u);
v_result_1743_ = lean_box(0);
v___x_1744_ = lean_array_get_size(v_index_1735_);
v___x_1745_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1745_, 0, v___x_1741_);
lean_ctor_set(v___x_1745_, 1, v___x_1744_);
lean_ctor_set(v___x_1745_, 2, v___x_1742_);
v___x_1746_ = ((lean_object*)(lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___closed__1));
v___x_1747_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1747_, 0, v_initialWork_1739_);
lean_ctor_set(v___x_1747_, 1, v___x_1746_);
v___x_1748_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1748_, 0, v_result_1743_);
lean_ctor_set(v___x_1748_, 1, v___x_1747_);
v___x_1749_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg(v_maxWork_1740_, v_index_1735_, v_context_1734_, v_table_1737_, v_monomial_1738_, v_basis_1736_, v___x_1745_, v___x_1748_, v___x_1741_);
lean_dec_ref_known(v___x_1745_, 3);
v_fst_1750_ = lean_ctor_get(v___x_1749_, 0);
lean_inc(v_fst_1750_);
if (lean_obj_tag(v_fst_1750_) == 0)
{
lean_object* v_snd_1751_; lean_object* v_snd_1752_; lean_object* v_fst_1753_; lean_object* v_snd_1754_; lean_object* v___x_1756_; uint8_t v_isShared_1757_; uint8_t v_isSharedCheck_1762_; 
v_snd_1751_ = lean_ctor_get(v___x_1749_, 1);
lean_inc(v_snd_1751_);
lean_dec_ref(v___x_1749_);
v_snd_1752_ = lean_ctor_get(v_snd_1751_, 1);
lean_inc(v_snd_1752_);
v_fst_1753_ = lean_ctor_get(v_snd_1751_, 0);
lean_inc(v_fst_1753_);
lean_dec(v_snd_1751_);
v_snd_1754_ = lean_ctor_get(v_snd_1752_, 1);
v_isSharedCheck_1762_ = !lean_is_exclusive(v_snd_1752_);
if (v_isSharedCheck_1762_ == 0)
{
lean_object* v_unused_1763_; 
v_unused_1763_ = lean_ctor_get(v_snd_1752_, 0);
lean_dec(v_unused_1763_);
v___x_1756_ = v_snd_1752_;
v_isShared_1757_ = v_isSharedCheck_1762_;
goto v_resetjp_1755_;
}
else
{
lean_inc(v_snd_1754_);
lean_dec(v_snd_1752_);
v___x_1756_ = lean_box(0);
v_isShared_1757_ = v_isSharedCheck_1762_;
goto v_resetjp_1755_;
}
v_resetjp_1755_:
{
lean_object* v___x_1758_; lean_object* v___x_1760_; 
v___x_1758_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1758_, 0, v_snd_1754_);
if (v_isShared_1757_ == 0)
{
lean_ctor_set(v___x_1756_, 1, v_fst_1753_);
lean_ctor_set(v___x_1756_, 0, v___x_1758_);
v___x_1760_ = v___x_1756_;
goto v_reusejp_1759_;
}
else
{
lean_object* v_reuseFailAlloc_1761_; 
v_reuseFailAlloc_1761_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1761_, 0, v___x_1758_);
lean_ctor_set(v_reuseFailAlloc_1761_, 1, v_fst_1753_);
v___x_1760_ = v_reuseFailAlloc_1761_;
goto v_reusejp_1759_;
}
v_reusejp_1759_:
{
return v___x_1760_;
}
}
}
else
{
lean_object* v_val_1764_; 
lean_dec_ref(v___x_1749_);
v_val_1764_ = lean_ctor_get(v_fst_1750_, 0);
lean_inc(v_val_1764_);
lean_dec_ref_known(v_fst_1750_, 1);
return v_val_1764_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin___boxed(lean_object* v_context_1765_, lean_object* v_index_1766_, lean_object* v_basis_1767_, lean_object* v_table_1768_, lean_object* v_monomial_1769_, lean_object* v_initialWork_1770_, lean_object* v_maxWork_1771_){
_start:
{
lean_object* v_res_1772_; 
v_res_1772_ = lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin(v_context_1765_, v_index_1766_, v_basis_1767_, v_table_1768_, v_monomial_1769_, v_initialWork_1770_, v_maxWork_1771_);
lean_dec(v_maxWork_1771_);
lean_dec(v_monomial_1769_);
lean_dec_ref(v_table_1768_);
lean_dec_ref(v_basis_1767_);
lean_dec_ref(v_index_1766_);
lean_dec_ref(v_context_1765_);
return v_res_1772_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0(uint64_t v___y_1773_, lean_object* v___x_1774_, lean_object* v_range_1775_, lean_object* v_b_1776_, lean_object* v_i_1777_, lean_object* v_hs_1778_, lean_object* v_hl_1779_){
_start:
{
lean_object* v___x_1780_; 
v___x_1780_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0___redArg(v___y_1773_, v___x_1774_, v_range_1775_, v_b_1776_, v_i_1777_);
return v___x_1780_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0___boxed(lean_object* v___y_1781_, lean_object* v___x_1782_, lean_object* v_range_1783_, lean_object* v_b_1784_, lean_object* v_i_1785_, lean_object* v_hs_1786_, lean_object* v_hl_1787_){
_start:
{
uint64_t v___y_6618__boxed_1788_; lean_object* v_res_1789_; 
v___y_6618__boxed_1788_ = lean_unbox_uint64(v___y_1781_);
lean_dec_ref(v___y_1781_);
v_res_1789_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__0(v___y_6618__boxed_1788_, v___x_1782_, v_range_1783_, v_b_1784_, v_i_1785_, v_hs_1786_, v_hl_1787_);
lean_dec_ref(v_range_1783_);
lean_dec_ref(v___x_1782_);
return v_res_1789_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1(lean_object* v_maxWork_1790_, lean_object* v___x_1791_, lean_object* v_context_1792_, lean_object* v_table_1793_, lean_object* v_monomial_1794_, lean_object* v_basis_1795_, lean_object* v_range_1796_, lean_object* v_b_1797_, lean_object* v_i_1798_, lean_object* v_hs_1799_, lean_object* v_hl_1800_){
_start:
{
lean_object* v___x_1801_; 
v___x_1801_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___redArg(v_maxWork_1790_, v___x_1791_, v_context_1792_, v_table_1793_, v_monomial_1794_, v_basis_1795_, v_range_1796_, v_b_1797_, v_i_1798_);
return v___x_1801_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1___boxed(lean_object* v_maxWork_1802_, lean_object* v___x_1803_, lean_object* v_context_1804_, lean_object* v_table_1805_, lean_object* v_monomial_1806_, lean_object* v_basis_1807_, lean_object* v_range_1808_, lean_object* v_b_1809_, lean_object* v_i_1810_, lean_object* v_hs_1811_, lean_object* v_hl_1812_){
_start:
{
lean_object* v_res_1813_; 
v_res_1813_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin_spec__1(v_maxWork_1802_, v___x_1803_, v_context_1804_, v_table_1805_, v_monomial_1806_, v_basis_1807_, v_range_1808_, v_b_1809_, v_i_1810_, v_hs_1811_, v_hl_1812_);
lean_dec_ref(v_range_1808_);
lean_dec_ref(v_basis_1807_);
lean_dec(v_monomial_1806_);
lean_dec_ref(v_table_1805_);
lean_dec_ref(v_context_1804_);
lean_dec_ref(v___x_1803_);
lean_dec(v_maxWork_1802_);
return v_res_1813_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_find(lean_object* v_context_1814_, lean_object* v_limits_1815_, lean_object* v_index_1816_, lean_object* v_basis_1817_, lean_object* v_monomial_1818_, lean_object* v_a_1819_){
_start:
{
lean_object* v_statistics_1820_; lean_object* v_table_1821_; lean_object* v___x_1823_; uint8_t v_isShared_1824_; uint8_t v_isSharedCheck_1859_; 
v_statistics_1820_ = lean_ctor_get(v_a_1819_, 1);
v_table_1821_ = lean_ctor_get(v_a_1819_, 0);
v_isSharedCheck_1859_ = !lean_is_exclusive(v_a_1819_);
if (v_isSharedCheck_1859_ == 0)
{
v___x_1823_ = v_a_1819_;
v_isShared_1824_ = v_isSharedCheck_1859_;
goto v_resetjp_1822_;
}
else
{
lean_inc(v_statistics_1820_);
lean_inc(v_table_1821_);
lean_dec(v_a_1819_);
v___x_1823_ = lean_box(0);
v_isShared_1824_ = v_isSharedCheck_1859_;
goto v_resetjp_1822_;
}
v_resetjp_1822_:
{
lean_object* v_work_1825_; lean_object* v_allocatedBytes_1826_; lean_object* v_pairs_1827_; lean_object* v_rounds_1828_; lean_object* v_matrixEntries_1829_; lean_object* v_matrixRows_1830_; lean_object* v_matrixCalls_1831_; lean_object* v_peakMatrixRows_1832_; lean_object* v_peakMatrixEntries_1833_; lean_object* v_largestBatch_1834_; lean_object* v_productPairs_1835_; lean_object* v_chainPairs_1836_; lean_object* v_gmPairs_1837_; lean_object* v___x_1839_; uint8_t v_isShared_1840_; uint8_t v_isSharedCheck_1858_; 
v_work_1825_ = lean_ctor_get(v_statistics_1820_, 0);
v_allocatedBytes_1826_ = lean_ctor_get(v_statistics_1820_, 1);
v_pairs_1827_ = lean_ctor_get(v_statistics_1820_, 2);
v_rounds_1828_ = lean_ctor_get(v_statistics_1820_, 3);
v_matrixEntries_1829_ = lean_ctor_get(v_statistics_1820_, 4);
v_matrixRows_1830_ = lean_ctor_get(v_statistics_1820_, 5);
v_matrixCalls_1831_ = lean_ctor_get(v_statistics_1820_, 6);
v_peakMatrixRows_1832_ = lean_ctor_get(v_statistics_1820_, 7);
v_peakMatrixEntries_1833_ = lean_ctor_get(v_statistics_1820_, 8);
v_largestBatch_1834_ = lean_ctor_get(v_statistics_1820_, 9);
v_productPairs_1835_ = lean_ctor_get(v_statistics_1820_, 10);
v_chainPairs_1836_ = lean_ctor_get(v_statistics_1820_, 11);
v_gmPairs_1837_ = lean_ctor_get(v_statistics_1820_, 12);
v_isSharedCheck_1858_ = !lean_is_exclusive(v_statistics_1820_);
if (v_isSharedCheck_1858_ == 0)
{
v___x_1839_ = v_statistics_1820_;
v_isShared_1840_ = v_isSharedCheck_1858_;
goto v_resetjp_1838_;
}
else
{
lean_inc(v_gmPairs_1837_);
lean_inc(v_chainPairs_1836_);
lean_inc(v_productPairs_1835_);
lean_inc(v_largestBatch_1834_);
lean_inc(v_peakMatrixEntries_1833_);
lean_inc(v_peakMatrixRows_1832_);
lean_inc(v_matrixCalls_1831_);
lean_inc(v_matrixRows_1830_);
lean_inc(v_matrixEntries_1829_);
lean_inc(v_rounds_1828_);
lean_inc(v_pairs_1827_);
lean_inc(v_allocatedBytes_1826_);
lean_inc(v_work_1825_);
lean_dec(v_statistics_1820_);
v___x_1839_ = lean_box(0);
v_isShared_1840_ = v_isSharedCheck_1858_;
goto v_resetjp_1838_;
}
v_resetjp_1838_:
{
lean_object* v_work_1841_; lean_object* v___x_1842_; lean_object* v_fst_1843_; lean_object* v_snd_1844_; lean_object* v___x_1846_; uint8_t v_isShared_1847_; uint8_t v_isSharedCheck_1857_; 
v_work_1841_ = lean_ctor_get(v_limits_1815_, 0);
v___x_1842_ = lp_Hex___private_HexGroebner_Reducer_0__Hex_Groebner_ReducerIndex_findWithin(v_context_1814_, v_index_1816_, v_basis_1817_, v_table_1821_, v_monomial_1818_, v_work_1825_, v_work_1841_);
v_fst_1843_ = lean_ctor_get(v___x_1842_, 0);
v_snd_1844_ = lean_ctor_get(v___x_1842_, 1);
v_isSharedCheck_1857_ = !lean_is_exclusive(v___x_1842_);
if (v_isSharedCheck_1857_ == 0)
{
v___x_1846_ = v___x_1842_;
v_isShared_1847_ = v_isSharedCheck_1857_;
goto v_resetjp_1845_;
}
else
{
lean_inc(v_snd_1844_);
lean_inc(v_fst_1843_);
lean_dec(v___x_1842_);
v___x_1846_ = lean_box(0);
v_isShared_1847_ = v_isSharedCheck_1857_;
goto v_resetjp_1845_;
}
v_resetjp_1845_:
{
lean_object* v___x_1849_; 
if (v_isShared_1840_ == 0)
{
lean_ctor_set(v___x_1839_, 0, v_snd_1844_);
v___x_1849_ = v___x_1839_;
goto v_reusejp_1848_;
}
else
{
lean_object* v_reuseFailAlloc_1856_; 
v_reuseFailAlloc_1856_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_1856_, 0, v_snd_1844_);
lean_ctor_set(v_reuseFailAlloc_1856_, 1, v_allocatedBytes_1826_);
lean_ctor_set(v_reuseFailAlloc_1856_, 2, v_pairs_1827_);
lean_ctor_set(v_reuseFailAlloc_1856_, 3, v_rounds_1828_);
lean_ctor_set(v_reuseFailAlloc_1856_, 4, v_matrixEntries_1829_);
lean_ctor_set(v_reuseFailAlloc_1856_, 5, v_matrixRows_1830_);
lean_ctor_set(v_reuseFailAlloc_1856_, 6, v_matrixCalls_1831_);
lean_ctor_set(v_reuseFailAlloc_1856_, 7, v_peakMatrixRows_1832_);
lean_ctor_set(v_reuseFailAlloc_1856_, 8, v_peakMatrixEntries_1833_);
lean_ctor_set(v_reuseFailAlloc_1856_, 9, v_largestBatch_1834_);
lean_ctor_set(v_reuseFailAlloc_1856_, 10, v_productPairs_1835_);
lean_ctor_set(v_reuseFailAlloc_1856_, 11, v_chainPairs_1836_);
lean_ctor_set(v_reuseFailAlloc_1856_, 12, v_gmPairs_1837_);
v___x_1849_ = v_reuseFailAlloc_1856_;
goto v_reusejp_1848_;
}
v_reusejp_1848_:
{
lean_object* v___x_1851_; 
if (v_isShared_1824_ == 0)
{
lean_ctor_set(v___x_1823_, 1, v___x_1849_);
v___x_1851_ = v___x_1823_;
goto v_reusejp_1850_;
}
else
{
lean_object* v_reuseFailAlloc_1855_; 
v_reuseFailAlloc_1855_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1855_, 0, v_table_1821_);
lean_ctor_set(v_reuseFailAlloc_1855_, 1, v___x_1849_);
v___x_1851_ = v_reuseFailAlloc_1855_;
goto v_reusejp_1850_;
}
v_reusejp_1850_:
{
lean_object* v___x_1853_; 
if (v_isShared_1847_ == 0)
{
lean_ctor_set(v___x_1846_, 1, v___x_1851_);
v___x_1853_ = v___x_1846_;
goto v_reusejp_1852_;
}
else
{
lean_object* v_reuseFailAlloc_1854_; 
v_reuseFailAlloc_1854_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1854_, 0, v_fst_1843_);
lean_ctor_set(v_reuseFailAlloc_1854_, 1, v___x_1851_);
v___x_1853_ = v_reuseFailAlloc_1854_;
goto v_reusejp_1852_;
}
v_reusejp_1852_:
{
return v___x_1853_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_find___boxed(lean_object* v_context_1860_, lean_object* v_limits_1861_, lean_object* v_index_1862_, lean_object* v_basis_1863_, lean_object* v_monomial_1864_, lean_object* v_a_1865_){
_start:
{
lean_object* v_res_1866_; 
v_res_1866_ = lp_Hex_Hex_Groebner_ReducerIndex_find(v_context_1860_, v_limits_1861_, v_index_1862_, v_basis_1863_, v_monomial_1864_, v_a_1865_);
lean_dec(v_monomial_1864_);
lean_dec_ref(v_basis_1863_);
lean_dec_ref(v_index_1862_);
lean_dec_ref(v_limits_1861_);
lean_dec_ref(v_context_1860_);
return v_res_1866_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0___redArg(uint64_t v___y_1867_, lean_object* v___x_1868_, lean_object* v_range_1869_, lean_object* v_b_1870_, lean_object* v_i_1871_, lean_object* v___y_1872_){
_start:
{
lean_object* v_stop_1873_; lean_object* v_step_1874_; lean_object* v_a_1876_; lean_object* v_snd_1877_; uint64_t v___y_1881_; uint64_t v___y_1885_; uint8_t v___y_1886_; uint8_t v___x_1891_; 
v_stop_1873_ = lean_ctor_get(v_range_1869_, 1);
v_step_1874_ = lean_ctor_get(v_range_1869_, 2);
v___x_1891_ = lean_nat_dec_lt(v_i_1871_, v_stop_1873_);
if (v___x_1891_ == 0)
{
lean_object* v___x_1892_; lean_object* v___x_1893_; 
lean_dec(v_i_1871_);
v___x_1892_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1892_, 0, v_b_1870_);
v___x_1893_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1893_, 0, v___x_1892_);
lean_ctor_set(v___x_1893_, 1, v___y_1872_);
return v___x_1893_;
}
else
{
uint64_t v___y_1895_; uint8_t v___y_1896_; lean_object* v___y_1897_; uint8_t v___y_1898_; lean_object* v___x_1910_; lean_object* v___x_1911_; uint8_t v___y_1913_; uint64_t v___y_1914_; lean_object* v___y_1915_; uint8_t v___y_1916_; uint8_t v___y_1928_; lean_object* v___y_1929_; uint8_t v___y_1930_; uint8_t v___y_1939_; lean_object* v___y_1940_; uint8_t v___y_1941_; lean_object* v___x_1971_; uint64_t v___y_1973_; uint64_t v___y_1986_; uint8_t v___y_1987_; uint8_t v___x_1992_; lean_object* v___x_1993_; lean_object* v_offset_1994_; uint64_t v___y_1996_; uint8_t v___y_1997_; uint64_t v___y_2010_; uint8_t v___y_2011_; uint8_t v___y_2023_; uint8_t v___y_2032_; lean_object* v___x_2062_; lean_object* v___x_2063_; uint8_t v___x_2064_; 
v___x_1910_ = lean_unsigned_to_nat(1u);
v___x_1911_ = lean_unsigned_to_nat(2u);
v___x_1971_ = lean_nat_mul(v___x_1911_, v_i_1871_);
v___x_1992_ = 0;
v___x_1993_ = lean_unsigned_to_nat(4u);
v_offset_1994_ = lean_nat_mul(v___x_1971_, v___x_1993_);
v___x_2062_ = lean_nat_add(v_offset_1994_, v___x_1993_);
v___x_2063_ = lean_byte_array_size(v___x_1868_);
v___x_2064_ = lean_nat_dec_le(v___x_2062_, v___x_2063_);
if (v___x_2064_ == 0)
{
lean_dec(v___x_2062_);
v___y_2032_ = v___x_2064_;
goto v___jp_2031_;
}
else
{
size_t v___x_2065_; lean_object* v___x_2066_; uint8_t v___x_2067_; 
v___x_2065_ = lean_usize_of_nat(v___x_2062_);
v___x_2066_ = lean_usize_to_nat(v___x_2065_);
v___x_2067_ = lean_nat_dec_eq(v___x_2066_, v___x_2062_);
lean_dec(v___x_2062_);
lean_dec(v___x_2066_);
v___y_2032_ = v___x_2067_;
goto v___jp_2031_;
}
v___jp_1894_:
{
uint64_t v___x_1899_; uint64_t v___x_1900_; uint64_t v___x_1901_; uint64_t v___x_1902_; lean_object* v___x_1903_; lean_object* v___x_1904_; uint8_t v___x_1905_; 
v___x_1899_ = lean_uint8_to_uint64(v___y_1898_);
v___x_1900_ = 16ULL;
v___x_1901_ = lean_uint64_shift_left(v___x_1899_, v___x_1900_);
v___x_1902_ = lean_uint64_lor(v___y_1895_, v___x_1901_);
v___x_1903_ = lean_unsigned_to_nat(3u);
v___x_1904_ = lean_nat_add(v___y_1897_, v___x_1903_);
lean_dec(v___y_1897_);
v___x_1905_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1868_, v___x_1904_);
if (v___x_1905_ == 0)
{
lean_object* v___x_1906_; lean_object* v___x_1907_; uint8_t v___x_1908_; 
lean_dec(v___x_1904_);
v___x_1906_ = lean_box(v___y_1896_);
v___x_1907_ = l_outOfBounds___redArg(v___x_1906_);
lean_dec(v___x_1906_);
v___x_1908_ = lean_unbox(v___x_1907_);
lean_dec(v___x_1907_);
v___y_1885_ = v___x_1902_;
v___y_1886_ = v___x_1908_;
goto v___jp_1884_;
}
else
{
uint8_t v___x_1909_; 
v___x_1909_ = lean_byte_array_fget(v___x_1868_, v___x_1904_);
lean_dec(v___x_1904_);
v___y_1885_ = v___x_1902_;
v___y_1886_ = v___x_1909_;
goto v___jp_1884_;
}
}
v___jp_1912_:
{
uint64_t v___x_1917_; uint64_t v___x_1918_; uint64_t v___x_1919_; uint64_t v___x_1920_; lean_object* v___x_1921_; uint8_t v___x_1922_; 
v___x_1917_ = lean_uint8_to_uint64(v___y_1916_);
v___x_1918_ = 8ULL;
v___x_1919_ = lean_uint64_shift_left(v___x_1917_, v___x_1918_);
v___x_1920_ = lean_uint64_lor(v___y_1914_, v___x_1919_);
v___x_1921_ = lean_nat_add(v___y_1915_, v___x_1911_);
v___x_1922_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1868_, v___x_1921_);
if (v___x_1922_ == 0)
{
lean_object* v___x_1923_; lean_object* v___x_1924_; uint8_t v___x_1925_; 
lean_dec(v___x_1921_);
v___x_1923_ = lean_box(v___y_1913_);
v___x_1924_ = l_outOfBounds___redArg(v___x_1923_);
lean_dec(v___x_1923_);
v___x_1925_ = lean_unbox(v___x_1924_);
lean_dec(v___x_1924_);
v___y_1895_ = v___x_1920_;
v___y_1896_ = v___y_1913_;
v___y_1897_ = v___y_1915_;
v___y_1898_ = v___x_1925_;
goto v___jp_1894_;
}
else
{
uint8_t v___x_1926_; 
v___x_1926_ = lean_byte_array_fget(v___x_1868_, v___x_1921_);
lean_dec(v___x_1921_);
v___y_1895_ = v___x_1920_;
v___y_1896_ = v___y_1913_;
v___y_1897_ = v___y_1915_;
v___y_1898_ = v___x_1926_;
goto v___jp_1894_;
}
}
v___jp_1927_:
{
uint64_t v_a_1931_; lean_object* v___x_1932_; uint8_t v___x_1933_; 
v_a_1931_ = lean_uint8_to_uint64(v___y_1930_);
v___x_1932_ = lean_nat_add(v___y_1929_, v___x_1910_);
v___x_1933_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1868_, v___x_1932_);
if (v___x_1933_ == 0)
{
lean_object* v___x_1934_; lean_object* v___x_1935_; uint8_t v___x_1936_; 
lean_dec(v___x_1932_);
v___x_1934_ = lean_box(v___y_1928_);
v___x_1935_ = l_outOfBounds___redArg(v___x_1934_);
lean_dec(v___x_1934_);
v___x_1936_ = lean_unbox(v___x_1935_);
lean_dec(v___x_1935_);
v___y_1913_ = v___y_1928_;
v___y_1914_ = v_a_1931_;
v___y_1915_ = v___y_1929_;
v___y_1916_ = v___x_1936_;
goto v___jp_1912_;
}
else
{
uint8_t v___x_1937_; 
v___x_1937_ = lean_byte_array_fget(v___x_1868_, v___x_1932_);
lean_dec(v___x_1932_);
v___y_1913_ = v___y_1928_;
v___y_1914_ = v_a_1931_;
v___y_1915_ = v___y_1929_;
v___y_1916_ = v___x_1937_;
goto v___jp_1912_;
}
}
v___jp_1938_:
{
if (v___y_1941_ == 0)
{
uint8_t v___x_1942_; 
v___x_1942_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1868_, v___y_1940_);
if (v___x_1942_ == 0)
{
lean_object* v___x_1943_; lean_object* v___x_1944_; uint8_t v___x_1945_; 
v___x_1943_ = lean_box(v___y_1939_);
v___x_1944_ = l_outOfBounds___redArg(v___x_1943_);
lean_dec(v___x_1943_);
v___x_1945_ = lean_unbox(v___x_1944_);
lean_dec(v___x_1944_);
v___y_1928_ = v___y_1939_;
v___y_1929_ = v___y_1940_;
v___y_1930_ = v___x_1945_;
goto v___jp_1927_;
}
else
{
uint8_t v___x_1946_; 
v___x_1946_ = lean_byte_array_fget(v___x_1868_, v___y_1940_);
v___y_1928_ = v___y_1939_;
v___y_1929_ = v___y_1940_;
v___y_1930_ = v___x_1946_;
goto v___jp_1927_;
}
}
else
{
size_t v_pos_1947_; uint8_t v___x_1948_; uint64_t v_a_1949_; size_t v___x_1950_; size_t v___x_1951_; uint8_t v___x_1952_; uint64_t v___x_1953_; uint64_t v___x_1954_; uint64_t v___x_1955_; uint64_t v___x_1956_; size_t v___x_1957_; size_t v___x_1958_; uint8_t v___x_1959_; uint64_t v___x_1960_; uint64_t v___x_1961_; uint64_t v___x_1962_; uint64_t v___x_1963_; size_t v___x_1964_; size_t v___x_1965_; uint8_t v___x_1966_; uint64_t v___x_1967_; uint64_t v___x_1968_; uint64_t v___x_1969_; uint64_t v___x_1970_; 
v_pos_1947_ = lean_usize_of_nat(v___y_1940_);
lean_dec(v___y_1940_);
v___x_1948_ = lean_byte_array_uget(v___x_1868_, v_pos_1947_);
v_a_1949_ = lean_uint8_to_uint64(v___x_1948_);
v___x_1950_ = ((size_t)1ULL);
v___x_1951_ = lean_usize_add(v_pos_1947_, v___x_1950_);
v___x_1952_ = lean_byte_array_uget(v___x_1868_, v___x_1951_);
v___x_1953_ = lean_uint8_to_uint64(v___x_1952_);
v___x_1954_ = 8ULL;
v___x_1955_ = lean_uint64_shift_left(v___x_1953_, v___x_1954_);
v___x_1956_ = lean_uint64_lor(v_a_1949_, v___x_1955_);
v___x_1957_ = ((size_t)2ULL);
v___x_1958_ = lean_usize_add(v_pos_1947_, v___x_1957_);
v___x_1959_ = lean_byte_array_uget(v___x_1868_, v___x_1958_);
v___x_1960_ = lean_uint8_to_uint64(v___x_1959_);
v___x_1961_ = 16ULL;
v___x_1962_ = lean_uint64_shift_left(v___x_1960_, v___x_1961_);
v___x_1963_ = lean_uint64_lor(v___x_1956_, v___x_1962_);
v___x_1964_ = ((size_t)3ULL);
v___x_1965_ = lean_usize_add(v_pos_1947_, v___x_1964_);
v___x_1966_ = lean_byte_array_uget(v___x_1868_, v___x_1965_);
v___x_1967_ = lean_uint8_to_uint64(v___x_1966_);
v___x_1968_ = 24ULL;
v___x_1969_ = lean_uint64_shift_left(v___x_1967_, v___x_1968_);
v___x_1970_ = lean_uint64_lor(v___x_1963_, v___x_1969_);
v___y_1881_ = v___x_1970_;
goto v___jp_1880_;
}
}
v___jp_1972_:
{
uint8_t v___x_1974_; 
v___x_1974_ = lean_uint64_dec_le(v___y_1973_, v___y_1867_);
if (v___x_1974_ == 0)
{
lean_dec(v___x_1971_);
v_a_1876_ = v_b_1870_;
v_snd_1877_ = v___y_1872_;
goto v___jp_1875_;
}
else
{
lean_object* v___x_1975_; uint8_t v___x_1976_; lean_object* v___x_1977_; lean_object* v_offset_1978_; lean_object* v___x_1979_; lean_object* v___x_1980_; uint8_t v___x_1981_; 
v___x_1975_ = lean_nat_add(v___x_1971_, v___x_1910_);
lean_dec(v___x_1971_);
v___x_1976_ = 0;
v___x_1977_ = lean_unsigned_to_nat(4u);
v_offset_1978_ = lean_nat_mul(v___x_1975_, v___x_1977_);
lean_dec(v___x_1975_);
v___x_1979_ = lean_nat_add(v_offset_1978_, v___x_1977_);
v___x_1980_ = lean_byte_array_size(v___x_1868_);
v___x_1981_ = lean_nat_dec_le(v___x_1979_, v___x_1980_);
if (v___x_1981_ == 0)
{
lean_dec(v___x_1979_);
v___y_1939_ = v___x_1976_;
v___y_1940_ = v_offset_1978_;
v___y_1941_ = v___x_1981_;
goto v___jp_1938_;
}
else
{
size_t v___x_1982_; lean_object* v___x_1983_; uint8_t v___x_1984_; 
v___x_1982_ = lean_usize_of_nat(v___x_1979_);
v___x_1983_ = lean_usize_to_nat(v___x_1982_);
v___x_1984_ = lean_nat_dec_eq(v___x_1983_, v___x_1979_);
lean_dec(v___x_1979_);
lean_dec(v___x_1983_);
v___y_1939_ = v___x_1976_;
v___y_1940_ = v_offset_1978_;
v___y_1941_ = v___x_1984_;
goto v___jp_1938_;
}
}
}
v___jp_1985_:
{
uint64_t v___x_1988_; uint64_t v___x_1989_; uint64_t v___x_1990_; uint64_t v___x_1991_; 
v___x_1988_ = lean_uint8_to_uint64(v___y_1987_);
v___x_1989_ = 24ULL;
v___x_1990_ = lean_uint64_shift_left(v___x_1988_, v___x_1989_);
v___x_1991_ = lean_uint64_lor(v___y_1986_, v___x_1990_);
v___y_1973_ = v___x_1991_;
goto v___jp_1972_;
}
v___jp_1995_:
{
uint64_t v___x_1998_; uint64_t v___x_1999_; uint64_t v___x_2000_; uint64_t v___x_2001_; lean_object* v___x_2002_; lean_object* v___x_2003_; uint8_t v___x_2004_; 
v___x_1998_ = lean_uint8_to_uint64(v___y_1997_);
v___x_1999_ = 16ULL;
v___x_2000_ = lean_uint64_shift_left(v___x_1998_, v___x_1999_);
v___x_2001_ = lean_uint64_lor(v___y_1996_, v___x_2000_);
v___x_2002_ = lean_unsigned_to_nat(3u);
v___x_2003_ = lean_nat_add(v_offset_1994_, v___x_2002_);
lean_dec(v_offset_1994_);
v___x_2004_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1868_, v___x_2003_);
if (v___x_2004_ == 0)
{
lean_object* v___x_2005_; lean_object* v___x_2006_; uint8_t v___x_2007_; 
lean_dec(v___x_2003_);
v___x_2005_ = lean_box(v___x_1992_);
v___x_2006_ = l_outOfBounds___redArg(v___x_2005_);
lean_dec(v___x_2005_);
v___x_2007_ = lean_unbox(v___x_2006_);
lean_dec(v___x_2006_);
v___y_1986_ = v___x_2001_;
v___y_1987_ = v___x_2007_;
goto v___jp_1985_;
}
else
{
uint8_t v___x_2008_; 
v___x_2008_ = lean_byte_array_fget(v___x_1868_, v___x_2003_);
lean_dec(v___x_2003_);
v___y_1986_ = v___x_2001_;
v___y_1987_ = v___x_2008_;
goto v___jp_1985_;
}
}
v___jp_2009_:
{
uint64_t v___x_2012_; uint64_t v___x_2013_; uint64_t v___x_2014_; uint64_t v___x_2015_; lean_object* v___x_2016_; uint8_t v___x_2017_; 
v___x_2012_ = lean_uint8_to_uint64(v___y_2011_);
v___x_2013_ = 8ULL;
v___x_2014_ = lean_uint64_shift_left(v___x_2012_, v___x_2013_);
v___x_2015_ = lean_uint64_lor(v___y_2010_, v___x_2014_);
v___x_2016_ = lean_nat_add(v_offset_1994_, v___x_1911_);
v___x_2017_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1868_, v___x_2016_);
if (v___x_2017_ == 0)
{
lean_object* v___x_2018_; lean_object* v___x_2019_; uint8_t v___x_2020_; 
lean_dec(v___x_2016_);
v___x_2018_ = lean_box(v___x_1992_);
v___x_2019_ = l_outOfBounds___redArg(v___x_2018_);
lean_dec(v___x_2018_);
v___x_2020_ = lean_unbox(v___x_2019_);
lean_dec(v___x_2019_);
v___y_1996_ = v___x_2015_;
v___y_1997_ = v___x_2020_;
goto v___jp_1995_;
}
else
{
uint8_t v___x_2021_; 
v___x_2021_ = lean_byte_array_fget(v___x_1868_, v___x_2016_);
lean_dec(v___x_2016_);
v___y_1996_ = v___x_2015_;
v___y_1997_ = v___x_2021_;
goto v___jp_1995_;
}
}
v___jp_2022_:
{
uint64_t v_a_2024_; lean_object* v___x_2025_; uint8_t v___x_2026_; 
v_a_2024_ = lean_uint8_to_uint64(v___y_2023_);
v___x_2025_ = lean_nat_add(v_offset_1994_, v___x_1910_);
v___x_2026_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1868_, v___x_2025_);
if (v___x_2026_ == 0)
{
lean_object* v___x_2027_; lean_object* v___x_2028_; uint8_t v___x_2029_; 
lean_dec(v___x_2025_);
v___x_2027_ = lean_box(v___x_1992_);
v___x_2028_ = l_outOfBounds___redArg(v___x_2027_);
lean_dec(v___x_2027_);
v___x_2029_ = lean_unbox(v___x_2028_);
lean_dec(v___x_2028_);
v___y_2010_ = v_a_2024_;
v___y_2011_ = v___x_2029_;
goto v___jp_2009_;
}
else
{
uint8_t v___x_2030_; 
v___x_2030_ = lean_byte_array_fget(v___x_1868_, v___x_2025_);
lean_dec(v___x_2025_);
v___y_2010_ = v_a_2024_;
v___y_2011_ = v___x_2030_;
goto v___jp_2009_;
}
}
v___jp_2031_:
{
if (v___y_2032_ == 0)
{
uint8_t v___x_2033_; 
v___x_2033_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v___x_1868_, v_offset_1994_);
if (v___x_2033_ == 0)
{
lean_object* v___x_2034_; lean_object* v___x_2035_; uint8_t v___x_2036_; 
v___x_2034_ = lean_box(v___x_1992_);
v___x_2035_ = l_outOfBounds___redArg(v___x_2034_);
lean_dec(v___x_2034_);
v___x_2036_ = lean_unbox(v___x_2035_);
lean_dec(v___x_2035_);
v___y_2023_ = v___x_2036_;
goto v___jp_2022_;
}
else
{
uint8_t v___x_2037_; 
v___x_2037_ = lean_byte_array_fget(v___x_1868_, v_offset_1994_);
v___y_2023_ = v___x_2037_;
goto v___jp_2022_;
}
}
else
{
size_t v_pos_2038_; uint8_t v___x_2039_; uint64_t v_a_2040_; size_t v___x_2041_; size_t v___x_2042_; uint8_t v___x_2043_; uint64_t v___x_2044_; uint64_t v___x_2045_; uint64_t v___x_2046_; uint64_t v___x_2047_; size_t v___x_2048_; size_t v___x_2049_; uint8_t v___x_2050_; uint64_t v___x_2051_; uint64_t v___x_2052_; uint64_t v___x_2053_; uint64_t v___x_2054_; size_t v___x_2055_; size_t v___x_2056_; uint8_t v___x_2057_; uint64_t v___x_2058_; uint64_t v___x_2059_; uint64_t v___x_2060_; uint64_t v___x_2061_; 
v_pos_2038_ = lean_usize_of_nat(v_offset_1994_);
lean_dec(v_offset_1994_);
v___x_2039_ = lean_byte_array_uget(v___x_1868_, v_pos_2038_);
v_a_2040_ = lean_uint8_to_uint64(v___x_2039_);
v___x_2041_ = ((size_t)1ULL);
v___x_2042_ = lean_usize_add(v_pos_2038_, v___x_2041_);
v___x_2043_ = lean_byte_array_uget(v___x_1868_, v___x_2042_);
v___x_2044_ = lean_uint8_to_uint64(v___x_2043_);
v___x_2045_ = 8ULL;
v___x_2046_ = lean_uint64_shift_left(v___x_2044_, v___x_2045_);
v___x_2047_ = lean_uint64_lor(v_a_2040_, v___x_2046_);
v___x_2048_ = ((size_t)2ULL);
v___x_2049_ = lean_usize_add(v_pos_2038_, v___x_2048_);
v___x_2050_ = lean_byte_array_uget(v___x_1868_, v___x_2049_);
v___x_2051_ = lean_uint8_to_uint64(v___x_2050_);
v___x_2052_ = 16ULL;
v___x_2053_ = lean_uint64_shift_left(v___x_2051_, v___x_2052_);
v___x_2054_ = lean_uint64_lor(v___x_2047_, v___x_2053_);
v___x_2055_ = ((size_t)3ULL);
v___x_2056_ = lean_usize_add(v_pos_2038_, v___x_2055_);
v___x_2057_ = lean_byte_array_uget(v___x_1868_, v___x_2056_);
v___x_2058_ = lean_uint8_to_uint64(v___x_2057_);
v___x_2059_ = 24ULL;
v___x_2060_ = lean_uint64_shift_left(v___x_2058_, v___x_2059_);
v___x_2061_ = lean_uint64_lor(v___x_2054_, v___x_2060_);
v___y_1973_ = v___x_2061_;
goto v___jp_1972_;
}
}
}
v___jp_1875_:
{
lean_object* v___x_1878_; 
v___x_1878_ = lean_nat_add(v_i_1871_, v_step_1874_);
lean_dec(v_i_1871_);
v_b_1870_ = v_a_1876_;
v_i_1871_ = v___x_1878_;
v___y_1872_ = v_snd_1877_;
goto _start;
}
v___jp_1880_:
{
lean_object* v___x_1882_; lean_object* v___x_1883_; 
v___x_1882_ = lean_uint64_to_nat(v___y_1881_);
v___x_1883_ = lean_array_push(v_b_1870_, v___x_1882_);
v_a_1876_ = v___x_1883_;
v_snd_1877_ = v___y_1872_;
goto v___jp_1875_;
}
v___jp_1884_:
{
uint64_t v___x_1887_; uint64_t v___x_1888_; uint64_t v___x_1889_; uint64_t v___x_1890_; 
v___x_1887_ = lean_uint8_to_uint64(v___y_1886_);
v___x_1888_ = 24ULL;
v___x_1889_ = lean_uint64_shift_left(v___x_1887_, v___x_1888_);
v___x_1890_ = lean_uint64_lor(v___y_1885_, v___x_1889_);
v___y_1881_ = v___x_1890_;
goto v___jp_1880_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0___redArg___boxed(lean_object* v___y_2068_, lean_object* v___x_2069_, lean_object* v_range_2070_, lean_object* v_b_2071_, lean_object* v_i_2072_, lean_object* v___y_2073_){
_start:
{
uint64_t v___y_10867__boxed_2074_; lean_object* v_res_2075_; 
v___y_10867__boxed_2074_ = lean_unbox_uint64(v___y_2068_);
lean_dec_ref(v___y_2068_);
v_res_2075_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0___redArg(v___y_10867__boxed_2074_, v___x_2069_, v_range_2070_, v_b_2071_, v_i_2072_, v___y_2073_);
lean_dec_ref(v_range_2070_);
lean_dec_ref(v___x_2069_);
return v_res_2075_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1___redArg(lean_object* v_limits_2076_, lean_object* v___x_2077_, lean_object* v_context_2078_, lean_object* v_table_2079_, lean_object* v_monomial_2080_, lean_object* v_range_2081_, lean_object* v_b_2082_, lean_object* v_i_2083_, lean_object* v___y_2084_){
_start:
{
lean_object* v_a_2086_; lean_object* v_snd_2087_; lean_object* v_stop_2090_; lean_object* v_step_2091_; lean_object* v_a_2093_; lean_object* v_snd_2094_; uint8_t v___x_2097_; 
v_stop_2090_ = lean_ctor_get(v_range_2081_, 1);
v_step_2091_ = lean_ctor_get(v_range_2081_, 2);
v___x_2097_ = lean_nat_dec_lt(v_i_2083_, v_stop_2090_);
if (v___x_2097_ == 0)
{
lean_object* v___x_2098_; lean_object* v___x_2099_; 
lean_dec(v_i_2083_);
v___x_2098_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2098_, 0, v_b_2082_);
v___x_2099_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2099_, 0, v___x_2098_);
lean_ctor_set(v___x_2099_, 1, v___y_2084_);
return v___x_2099_;
}
else
{
lean_object* v_fst_2100_; lean_object* v_snd_2101_; lean_object* v___x_2103_; uint8_t v_isShared_2104_; uint8_t v_isSharedCheck_2313_; 
v_fst_2100_ = lean_ctor_get(v_b_2082_, 0);
v_snd_2101_ = lean_ctor_get(v_b_2082_, 1);
v_isSharedCheck_2313_ = !lean_is_exclusive(v_b_2082_);
if (v_isSharedCheck_2313_ == 0)
{
v___x_2103_ = v_b_2082_;
v_isShared_2104_ = v_isSharedCheck_2313_;
goto v_resetjp_2102_;
}
else
{
lean_inc(v_snd_2101_);
lean_inc(v_fst_2100_);
lean_dec(v_b_2082_);
v___x_2103_ = lean_box(0);
v_isShared_2104_ = v_isSharedCheck_2313_;
goto v_resetjp_2102_;
}
v_resetjp_2102_:
{
lean_object* v___x_2105_; lean_object* v___x_2106_; uint8_t v___x_2107_; 
v___x_2105_ = lean_unsigned_to_nat(0u);
v___x_2106_ = lean_array_get_size(v_fst_2100_);
v___x_2107_ = lean_nat_dec_eq(v___x_2106_, v___x_2105_);
if (v___x_2107_ == 0)
{
lean_object* v_statistics_2108_; lean_object* v_table_2109_; lean_object* v_work_2110_; lean_object* v_allocatedBytes_2111_; lean_object* v_pairs_2112_; lean_object* v_rounds_2113_; lean_object* v_matrixEntries_2114_; lean_object* v_matrixRows_2115_; lean_object* v_matrixCalls_2116_; lean_object* v_peakMatrixRows_2117_; lean_object* v_peakMatrixEntries_2118_; lean_object* v_largestBatch_2119_; lean_object* v_productPairs_2120_; lean_object* v_chainPairs_2121_; lean_object* v_gmPairs_2122_; lean_object* v___x_2124_; uint8_t v_isShared_2125_; uint8_t v_isSharedCheck_2307_; 
v_statistics_2108_ = lean_ctor_get(v___y_2084_, 1);
lean_inc_ref(v_statistics_2108_);
v_table_2109_ = lean_ctor_get(v___y_2084_, 0);
v_work_2110_ = lean_ctor_get(v_statistics_2108_, 0);
v_allocatedBytes_2111_ = lean_ctor_get(v_statistics_2108_, 1);
v_pairs_2112_ = lean_ctor_get(v_statistics_2108_, 2);
v_rounds_2113_ = lean_ctor_get(v_statistics_2108_, 3);
v_matrixEntries_2114_ = lean_ctor_get(v_statistics_2108_, 4);
v_matrixRows_2115_ = lean_ctor_get(v_statistics_2108_, 5);
v_matrixCalls_2116_ = lean_ctor_get(v_statistics_2108_, 6);
v_peakMatrixRows_2117_ = lean_ctor_get(v_statistics_2108_, 7);
v_peakMatrixEntries_2118_ = lean_ctor_get(v_statistics_2108_, 8);
v_largestBatch_2119_ = lean_ctor_get(v_statistics_2108_, 9);
v_productPairs_2120_ = lean_ctor_get(v_statistics_2108_, 10);
v_chainPairs_2121_ = lean_ctor_get(v_statistics_2108_, 11);
v_gmPairs_2122_ = lean_ctor_get(v_statistics_2108_, 12);
v_isSharedCheck_2307_ = !lean_is_exclusive(v_statistics_2108_);
if (v_isSharedCheck_2307_ == 0)
{
v___x_2124_ = v_statistics_2108_;
v_isShared_2125_ = v_isSharedCheck_2307_;
goto v_resetjp_2123_;
}
else
{
lean_inc(v_gmPairs_2122_);
lean_inc(v_chainPairs_2121_);
lean_inc(v_productPairs_2120_);
lean_inc(v_largestBatch_2119_);
lean_inc(v_peakMatrixEntries_2118_);
lean_inc(v_peakMatrixRows_2117_);
lean_inc(v_matrixCalls_2116_);
lean_inc(v_matrixRows_2115_);
lean_inc(v_matrixEntries_2114_);
lean_inc(v_rounds_2113_);
lean_inc(v_pairs_2112_);
lean_inc(v_allocatedBytes_2111_);
lean_inc(v_work_2110_);
lean_dec(v_statistics_2108_);
v___x_2124_ = lean_box(0);
v_isShared_2125_ = v_isSharedCheck_2307_;
goto v_resetjp_2123_;
}
v_resetjp_2123_:
{
lean_object* v_work_2126_; lean_object* v___x_2127_; lean_object* v_work_2128_; uint8_t v___x_2129_; 
v_work_2126_ = lean_ctor_get(v_limits_2076_, 0);
v___x_2127_ = lean_unsigned_to_nat(1u);
v_work_2128_ = lean_nat_add(v_work_2110_, v___x_2127_);
lean_dec(v_work_2110_);
v___x_2129_ = lean_nat_dec_lt(v_work_2126_, v_work_2128_);
if (v___x_2129_ == 0)
{
lean_object* v___x_2131_; uint8_t v_isShared_2132_; uint8_t v_isSharedCheck_2303_; 
lean_inc_ref(v_table_2109_);
v_isSharedCheck_2303_ = !lean_is_exclusive(v___y_2084_);
if (v_isSharedCheck_2303_ == 0)
{
lean_object* v_unused_2304_; lean_object* v_unused_2305_; 
v_unused_2304_ = lean_ctor_get(v___y_2084_, 1);
lean_dec(v_unused_2304_);
v_unused_2305_ = lean_ctor_get(v___y_2084_, 0);
lean_dec(v_unused_2305_);
v___x_2131_ = v___y_2084_;
v_isShared_2132_ = v_isSharedCheck_2303_;
goto v_resetjp_2130_;
}
else
{
lean_dec(v___y_2084_);
v___x_2131_ = lean_box(0);
v_isShared_2132_ = v_isSharedCheck_2303_;
goto v_resetjp_2130_;
}
v_resetjp_2130_:
{
lean_object* v___x_2133_; lean_object* v___x_2134_; lean_object* v___x_2135_; lean_object* v___x_2136_; lean_object* v_reducer_2137_; lean_object* v_depth_2138_; lean_object* v_variables_2139_; lean_object* v___x_2140_; lean_object* v___x_2142_; 
v___x_2133_ = lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default;
v___x_2134_ = lean_nat_sub(v___x_2106_, v___x_2127_);
v___x_2135_ = lean_array_get_borrowed(v___x_2105_, v_fst_2100_, v___x_2134_);
lean_dec(v___x_2134_);
v___x_2136_ = lean_array_get(v___x_2133_, v___x_2077_, v___x_2135_);
v_reducer_2137_ = lean_ctor_get(v___x_2136_, 1);
v_depth_2138_ = lean_ctor_get(v___x_2136_, 2);
v_variables_2139_ = lean_ctor_get(v_context_2078_, 0);
v___x_2140_ = lean_array_pop(v_fst_2100_);
lean_inc(v_gmPairs_2122_);
lean_inc(v_chainPairs_2121_);
lean_inc(v_productPairs_2120_);
lean_inc(v_largestBatch_2119_);
lean_inc(v_peakMatrixEntries_2118_);
lean_inc(v_peakMatrixRows_2117_);
lean_inc(v_matrixCalls_2116_);
lean_inc(v_matrixRows_2115_);
lean_inc(v_matrixEntries_2114_);
lean_inc(v_rounds_2113_);
lean_inc(v_pairs_2112_);
lean_inc(v_allocatedBytes_2111_);
lean_inc(v_work_2128_);
if (v_isShared_2125_ == 0)
{
lean_ctor_set(v___x_2124_, 0, v_work_2128_);
v___x_2142_ = v___x_2124_;
goto v_reusejp_2141_;
}
else
{
lean_object* v_reuseFailAlloc_2302_; 
v_reuseFailAlloc_2302_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_2302_, 0, v_work_2128_);
lean_ctor_set(v_reuseFailAlloc_2302_, 1, v_allocatedBytes_2111_);
lean_ctor_set(v_reuseFailAlloc_2302_, 2, v_pairs_2112_);
lean_ctor_set(v_reuseFailAlloc_2302_, 3, v_rounds_2113_);
lean_ctor_set(v_reuseFailAlloc_2302_, 4, v_matrixEntries_2114_);
lean_ctor_set(v_reuseFailAlloc_2302_, 5, v_matrixRows_2115_);
lean_ctor_set(v_reuseFailAlloc_2302_, 6, v_matrixCalls_2116_);
lean_ctor_set(v_reuseFailAlloc_2302_, 7, v_peakMatrixRows_2117_);
lean_ctor_set(v_reuseFailAlloc_2302_, 8, v_peakMatrixEntries_2118_);
lean_ctor_set(v_reuseFailAlloc_2302_, 9, v_largestBatch_2119_);
lean_ctor_set(v_reuseFailAlloc_2302_, 10, v_productPairs_2120_);
lean_ctor_set(v_reuseFailAlloc_2302_, 11, v_chainPairs_2121_);
lean_ctor_set(v_reuseFailAlloc_2302_, 12, v_gmPairs_2122_);
v___x_2142_ = v_reuseFailAlloc_2302_;
goto v_reusejp_2141_;
}
v_reusejp_2141_:
{
lean_object* v___x_2144_; 
lean_inc_ref(v_table_2109_);
if (v_isShared_2132_ == 0)
{
lean_ctor_set(v___x_2131_, 1, v___x_2142_);
v___x_2144_ = v___x_2131_;
goto v_reusejp_2143_;
}
else
{
lean_object* v_reuseFailAlloc_2301_; 
v_reuseFailAlloc_2301_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2301_, 0, v_table_2109_);
lean_ctor_set(v_reuseFailAlloc_2301_, 1, v___x_2142_);
v___x_2144_ = v_reuseFailAlloc_2301_;
goto v_reusejp_2143_;
}
v_reusejp_2143_:
{
uint64_t v___y_2146_; uint64_t v___y_2177_; uint8_t v___y_2178_; uint64_t v___y_2184_; uint8_t v___y_2185_; uint8_t v___x_2190_; 
v___x_2190_ = lean_nat_dec_eq(v_depth_2138_, v_variables_2139_);
if (v___x_2190_ == 0)
{
lean_object* v_arity_2191_; uint8_t v_width_2192_; lean_object* v_exponents_2193_; lean_object* v___x_2194_; lean_object* v___x_2195_; uint8_t v___x_2196_; uint64_t v___y_2198_; lean_object* v___y_2199_; uint8_t v___y_2200_; uint64_t v___y_2213_; lean_object* v___y_2214_; uint8_t v___y_2215_; lean_object* v___y_2228_; uint8_t v___y_2229_; lean_object* v___y_2244_; uint8_t v___y_2245_; lean_object* v___y_2283_; 
lean_del_object(v___x_2103_);
v_arity_2191_ = lean_ctor_get(v_table_2079_, 0);
v_width_2192_ = lean_ctor_get_uint8(v_table_2079_, sizeof(void*)*8);
v_exponents_2193_ = lean_ctor_get(v_table_2079_, 1);
v___x_2194_ = lean_nat_mul(v_monomial_2080_, v_arity_2191_);
v___x_2195_ = lean_nat_add(v___x_2194_, v_depth_2138_);
lean_dec(v___x_2194_);
v___x_2196_ = 0;
switch(v_width_2192_)
{
case 0:
{
v___y_2283_ = v___x_2127_;
goto v___jp_2282_;
}
case 1:
{
lean_object* v___x_2291_; 
v___x_2291_ = lean_unsigned_to_nat(2u);
v___y_2283_ = v___x_2291_;
goto v___jp_2282_;
}
default: 
{
lean_object* v___x_2292_; 
v___x_2292_ = lean_unsigned_to_nat(4u);
v___y_2283_ = v___x_2292_;
goto v___jp_2282_;
}
}
v___jp_2197_:
{
uint64_t v___x_2201_; uint64_t v___x_2202_; uint64_t v___x_2203_; uint64_t v___x_2204_; lean_object* v___x_2205_; lean_object* v___x_2206_; uint8_t v___x_2207_; 
v___x_2201_ = lean_uint8_to_uint64(v___y_2200_);
v___x_2202_ = 16ULL;
v___x_2203_ = lean_uint64_shift_left(v___x_2201_, v___x_2202_);
v___x_2204_ = lean_uint64_lor(v___y_2198_, v___x_2203_);
v___x_2205_ = lean_unsigned_to_nat(3u);
v___x_2206_ = lean_nat_add(v___y_2199_, v___x_2205_);
lean_dec(v___y_2199_);
v___x_2207_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_2193_, v___x_2206_);
if (v___x_2207_ == 0)
{
lean_object* v___x_2208_; lean_object* v___x_2209_; uint8_t v___x_2210_; 
lean_dec(v___x_2206_);
v___x_2208_ = lean_box(v___x_2196_);
v___x_2209_ = l_outOfBounds___redArg(v___x_2208_);
lean_dec(v___x_2208_);
v___x_2210_ = lean_unbox(v___x_2209_);
lean_dec(v___x_2209_);
v___y_2177_ = v___x_2204_;
v___y_2178_ = v___x_2210_;
goto v___jp_2176_;
}
else
{
uint8_t v___x_2211_; 
v___x_2211_ = lean_byte_array_fget(v_exponents_2193_, v___x_2206_);
lean_dec(v___x_2206_);
v___y_2177_ = v___x_2204_;
v___y_2178_ = v___x_2211_;
goto v___jp_2176_;
}
}
v___jp_2212_:
{
uint64_t v___x_2216_; uint64_t v___x_2217_; uint64_t v___x_2218_; uint64_t v___x_2219_; lean_object* v___x_2220_; lean_object* v___x_2221_; uint8_t v___x_2222_; 
v___x_2216_ = lean_uint8_to_uint64(v___y_2215_);
v___x_2217_ = 8ULL;
v___x_2218_ = lean_uint64_shift_left(v___x_2216_, v___x_2217_);
v___x_2219_ = lean_uint64_lor(v___y_2213_, v___x_2218_);
v___x_2220_ = lean_unsigned_to_nat(2u);
v___x_2221_ = lean_nat_add(v___y_2214_, v___x_2220_);
v___x_2222_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_2193_, v___x_2221_);
if (v___x_2222_ == 0)
{
lean_object* v___x_2223_; lean_object* v___x_2224_; uint8_t v___x_2225_; 
lean_dec(v___x_2221_);
v___x_2223_ = lean_box(v___x_2196_);
v___x_2224_ = l_outOfBounds___redArg(v___x_2223_);
lean_dec(v___x_2223_);
v___x_2225_ = lean_unbox(v___x_2224_);
lean_dec(v___x_2224_);
v___y_2198_ = v___x_2219_;
v___y_2199_ = v___y_2214_;
v___y_2200_ = v___x_2225_;
goto v___jp_2197_;
}
else
{
uint8_t v___x_2226_; 
v___x_2226_ = lean_byte_array_fget(v_exponents_2193_, v___x_2221_);
lean_dec(v___x_2221_);
v___y_2198_ = v___x_2219_;
v___y_2199_ = v___y_2214_;
v___y_2200_ = v___x_2226_;
goto v___jp_2197_;
}
}
v___jp_2227_:
{
uint64_t v_a_2230_; 
v_a_2230_ = lean_uint8_to_uint64(v___y_2229_);
switch(v_width_2192_)
{
case 0:
{
lean_dec(v___y_2228_);
v___y_2146_ = v_a_2230_;
goto v___jp_2145_;
}
case 1:
{
lean_object* v___x_2231_; uint8_t v___x_2232_; 
v___x_2231_ = lean_nat_add(v___y_2228_, v___x_2127_);
lean_dec(v___y_2228_);
v___x_2232_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_2193_, v___x_2231_);
if (v___x_2232_ == 0)
{
lean_object* v___x_2233_; lean_object* v___x_2234_; uint8_t v___x_2235_; 
lean_dec(v___x_2231_);
v___x_2233_ = lean_box(v___x_2196_);
v___x_2234_ = l_outOfBounds___redArg(v___x_2233_);
lean_dec(v___x_2233_);
v___x_2235_ = lean_unbox(v___x_2234_);
lean_dec(v___x_2234_);
v___y_2184_ = v_a_2230_;
v___y_2185_ = v___x_2235_;
goto v___jp_2183_;
}
else
{
uint8_t v___x_2236_; 
v___x_2236_ = lean_byte_array_fget(v_exponents_2193_, v___x_2231_);
lean_dec(v___x_2231_);
v___y_2184_ = v_a_2230_;
v___y_2185_ = v___x_2236_;
goto v___jp_2183_;
}
}
default: 
{
lean_object* v___x_2237_; uint8_t v___x_2238_; 
v___x_2237_ = lean_nat_add(v___y_2228_, v___x_2127_);
v___x_2238_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_2193_, v___x_2237_);
if (v___x_2238_ == 0)
{
lean_object* v___x_2239_; lean_object* v___x_2240_; uint8_t v___x_2241_; 
lean_dec(v___x_2237_);
v___x_2239_ = lean_box(v___x_2196_);
v___x_2240_ = l_outOfBounds___redArg(v___x_2239_);
lean_dec(v___x_2239_);
v___x_2241_ = lean_unbox(v___x_2240_);
lean_dec(v___x_2240_);
v___y_2213_ = v_a_2230_;
v___y_2214_ = v___y_2228_;
v___y_2215_ = v___x_2241_;
goto v___jp_2212_;
}
else
{
uint8_t v___x_2242_; 
v___x_2242_ = lean_byte_array_fget(v_exponents_2193_, v___x_2237_);
lean_dec(v___x_2237_);
v___y_2213_ = v_a_2230_;
v___y_2214_ = v___y_2228_;
v___y_2215_ = v___x_2242_;
goto v___jp_2212_;
}
}
}
}
v___jp_2243_:
{
if (v___y_2245_ == 0)
{
uint8_t v___x_2246_; 
v___x_2246_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__0___redArg___lam__0(v_exponents_2193_, v___y_2244_);
if (v___x_2246_ == 0)
{
lean_object* v___x_2247_; lean_object* v___x_2248_; uint8_t v___x_2249_; 
v___x_2247_ = lean_box(v___x_2196_);
v___x_2248_ = l_outOfBounds___redArg(v___x_2247_);
lean_dec(v___x_2247_);
v___x_2249_ = lean_unbox(v___x_2248_);
lean_dec(v___x_2248_);
v___y_2228_ = v___y_2244_;
v___y_2229_ = v___x_2249_;
goto v___jp_2227_;
}
else
{
uint8_t v___x_2250_; 
v___x_2250_ = lean_byte_array_fget(v_exponents_2193_, v___y_2244_);
v___y_2228_ = v___y_2244_;
v___y_2229_ = v___x_2250_;
goto v___jp_2227_;
}
}
else
{
size_t v_pos_2251_; uint8_t v___x_2252_; uint64_t v_a_2253_; 
v_pos_2251_ = lean_usize_of_nat(v___y_2244_);
lean_dec(v___y_2244_);
v___x_2252_ = lean_byte_array_uget(v_exponents_2193_, v_pos_2251_);
v_a_2253_ = lean_uint8_to_uint64(v___x_2252_);
switch(v_width_2192_)
{
case 0:
{
v___y_2146_ = v_a_2253_;
goto v___jp_2145_;
}
case 1:
{
size_t v___x_2254_; size_t v___x_2255_; uint8_t v___x_2256_; uint64_t v___x_2257_; uint64_t v___x_2258_; uint64_t v___x_2259_; uint64_t v___x_2260_; 
v___x_2254_ = ((size_t)1ULL);
v___x_2255_ = lean_usize_add(v_pos_2251_, v___x_2254_);
v___x_2256_ = lean_byte_array_uget(v_exponents_2193_, v___x_2255_);
v___x_2257_ = lean_uint8_to_uint64(v___x_2256_);
v___x_2258_ = 8ULL;
v___x_2259_ = lean_uint64_shift_left(v___x_2257_, v___x_2258_);
v___x_2260_ = lean_uint64_lor(v_a_2253_, v___x_2259_);
v___y_2146_ = v___x_2260_;
goto v___jp_2145_;
}
default: 
{
size_t v___x_2261_; size_t v___x_2262_; uint8_t v___x_2263_; uint64_t v___x_2264_; uint64_t v___x_2265_; uint64_t v___x_2266_; uint64_t v___x_2267_; size_t v___x_2268_; size_t v___x_2269_; uint8_t v___x_2270_; uint64_t v___x_2271_; uint64_t v___x_2272_; uint64_t v___x_2273_; uint64_t v___x_2274_; size_t v___x_2275_; size_t v___x_2276_; uint8_t v___x_2277_; uint64_t v___x_2278_; uint64_t v___x_2279_; uint64_t v___x_2280_; uint64_t v___x_2281_; 
v___x_2261_ = ((size_t)1ULL);
v___x_2262_ = lean_usize_add(v_pos_2251_, v___x_2261_);
v___x_2263_ = lean_byte_array_uget(v_exponents_2193_, v___x_2262_);
v___x_2264_ = lean_uint8_to_uint64(v___x_2263_);
v___x_2265_ = 8ULL;
v___x_2266_ = lean_uint64_shift_left(v___x_2264_, v___x_2265_);
v___x_2267_ = lean_uint64_lor(v_a_2253_, v___x_2266_);
v___x_2268_ = ((size_t)2ULL);
v___x_2269_ = lean_usize_add(v_pos_2251_, v___x_2268_);
v___x_2270_ = lean_byte_array_uget(v_exponents_2193_, v___x_2269_);
v___x_2271_ = lean_uint8_to_uint64(v___x_2270_);
v___x_2272_ = 16ULL;
v___x_2273_ = lean_uint64_shift_left(v___x_2271_, v___x_2272_);
v___x_2274_ = lean_uint64_lor(v___x_2267_, v___x_2273_);
v___x_2275_ = ((size_t)3ULL);
v___x_2276_ = lean_usize_add(v_pos_2251_, v___x_2275_);
v___x_2277_ = lean_byte_array_uget(v_exponents_2193_, v___x_2276_);
v___x_2278_ = lean_uint8_to_uint64(v___x_2277_);
v___x_2279_ = 24ULL;
v___x_2280_ = lean_uint64_shift_left(v___x_2278_, v___x_2279_);
v___x_2281_ = lean_uint64_lor(v___x_2274_, v___x_2280_);
v___y_2146_ = v___x_2281_;
goto v___jp_2145_;
}
}
}
}
v___jp_2282_:
{
lean_object* v_offset_2284_; lean_object* v___x_2285_; lean_object* v___x_2286_; uint8_t v___x_2287_; 
v_offset_2284_ = lean_nat_mul(v___x_2195_, v___y_2283_);
lean_dec(v___x_2195_);
v___x_2285_ = lean_nat_add(v_offset_2284_, v___y_2283_);
v___x_2286_ = lean_byte_array_size(v_exponents_2193_);
v___x_2287_ = lean_nat_dec_le(v___x_2285_, v___x_2286_);
if (v___x_2287_ == 0)
{
lean_dec(v___x_2285_);
v___y_2244_ = v_offset_2284_;
v___y_2245_ = v___x_2287_;
goto v___jp_2243_;
}
else
{
size_t v___x_2288_; lean_object* v___x_2289_; uint8_t v___x_2290_; 
v___x_2288_ = lean_usize_of_nat(v___x_2285_);
v___x_2289_ = lean_usize_to_nat(v___x_2288_);
v___x_2290_ = lean_nat_dec_eq(v___x_2289_, v___x_2285_);
lean_dec(v___x_2285_);
lean_dec(v___x_2289_);
v___y_2244_ = v_offset_2284_;
v___y_2245_ = v___x_2290_;
goto v___jp_2243_;
}
}
}
else
{
lean_inc(v_reducer_2137_);
lean_dec(v___x_2136_);
lean_dec(v_work_2128_);
lean_dec(v_gmPairs_2122_);
lean_dec(v_chainPairs_2121_);
lean_dec(v_productPairs_2120_);
lean_dec(v_largestBatch_2119_);
lean_dec(v_peakMatrixEntries_2118_);
lean_dec(v_peakMatrixRows_2117_);
lean_dec(v_matrixCalls_2116_);
lean_dec(v_matrixRows_2115_);
lean_dec(v_matrixEntries_2114_);
lean_dec(v_rounds_2113_);
lean_dec(v_pairs_2112_);
lean_dec(v_allocatedBytes_2111_);
lean_dec_ref(v_table_2109_);
if (lean_obj_tag(v_reducer_2137_) == 1)
{
lean_object* v_val_2293_; lean_object* v___x_2294_; lean_object* v___x_2296_; 
v_val_2293_ = lean_ctor_get(v_reducer_2137_, 0);
lean_inc(v_val_2293_);
lean_dec_ref_known(v_reducer_2137_, 1);
v___x_2294_ = lean_array_push(v_snd_2101_, v_val_2293_);
if (v_isShared_2104_ == 0)
{
lean_ctor_set(v___x_2103_, 1, v___x_2294_);
lean_ctor_set(v___x_2103_, 0, v___x_2140_);
v___x_2296_ = v___x_2103_;
goto v_reusejp_2295_;
}
else
{
lean_object* v_reuseFailAlloc_2297_; 
v_reuseFailAlloc_2297_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2297_, 0, v___x_2140_);
lean_ctor_set(v_reuseFailAlloc_2297_, 1, v___x_2294_);
v___x_2296_ = v_reuseFailAlloc_2297_;
goto v_reusejp_2295_;
}
v_reusejp_2295_:
{
v_a_2093_ = v___x_2296_;
v_snd_2094_ = v___x_2144_;
goto v___jp_2092_;
}
}
else
{
lean_object* v___x_2299_; 
lean_dec(v_reducer_2137_);
if (v_isShared_2104_ == 0)
{
lean_ctor_set(v___x_2103_, 0, v___x_2140_);
v___x_2299_ = v___x_2103_;
goto v_reusejp_2298_;
}
else
{
lean_object* v_reuseFailAlloc_2300_; 
v_reuseFailAlloc_2300_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2300_, 0, v___x_2140_);
lean_ctor_set(v_reuseFailAlloc_2300_, 1, v_snd_2101_);
v___x_2299_ = v_reuseFailAlloc_2300_;
goto v_reusejp_2298_;
}
v_reusejp_2298_:
{
v_a_2093_ = v___x_2299_;
v_snd_2094_ = v___x_2144_;
goto v___jp_2092_;
}
}
}
v___jp_2145_:
{
lean_object* v_edges_2147_; lean_object* v___x_2149_; uint8_t v_isShared_2150_; uint8_t v_isSharedCheck_2173_; 
v_edges_2147_ = lean_ctor_get(v___x_2136_, 0);
v_isSharedCheck_2173_ = !lean_is_exclusive(v___x_2136_);
if (v_isSharedCheck_2173_ == 0)
{
lean_object* v_unused_2174_; lean_object* v_unused_2175_; 
v_unused_2174_ = lean_ctor_get(v___x_2136_, 2);
lean_dec(v_unused_2174_);
v_unused_2175_ = lean_ctor_get(v___x_2136_, 1);
lean_dec(v_unused_2175_);
v___x_2149_ = v___x_2136_;
v_isShared_2150_ = v_isSharedCheck_2173_;
goto v_resetjp_2148_;
}
else
{
lean_inc(v_edges_2147_);
lean_dec(v___x_2136_);
v___x_2149_ = lean_box(0);
v_isShared_2150_ = v_isSharedCheck_2173_;
goto v_resetjp_2148_;
}
v_resetjp_2148_:
{
lean_object* v___x_2151_; lean_object* v___x_2152_; lean_object* v___x_2153_; lean_object* v_work_2154_; uint8_t v___x_2155_; 
v___x_2151_ = lean_byte_array_size(v_edges_2147_);
v___x_2152_ = lean_unsigned_to_nat(3u);
v___x_2153_ = lean_nat_shiftr(v___x_2151_, v___x_2152_);
v_work_2154_ = lean_nat_add(v_work_2128_, v___x_2153_);
lean_dec(v_work_2128_);
v___x_2155_ = lean_nat_dec_lt(v_work_2126_, v_work_2154_);
if (v___x_2155_ == 0)
{
lean_object* v___x_2156_; lean_object* v___x_2157_; lean_object* v___x_2159_; 
lean_dec_ref(v___x_2144_);
v___x_2156_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v___x_2156_, 0, v_work_2154_);
lean_ctor_set(v___x_2156_, 1, v_allocatedBytes_2111_);
lean_ctor_set(v___x_2156_, 2, v_pairs_2112_);
lean_ctor_set(v___x_2156_, 3, v_rounds_2113_);
lean_ctor_set(v___x_2156_, 4, v_matrixEntries_2114_);
lean_ctor_set(v___x_2156_, 5, v_matrixRows_2115_);
lean_ctor_set(v___x_2156_, 6, v_matrixCalls_2116_);
lean_ctor_set(v___x_2156_, 7, v_peakMatrixRows_2117_);
lean_ctor_set(v___x_2156_, 8, v_peakMatrixEntries_2118_);
lean_ctor_set(v___x_2156_, 9, v_largestBatch_2119_);
lean_ctor_set(v___x_2156_, 10, v_productPairs_2120_);
lean_ctor_set(v___x_2156_, 11, v_chainPairs_2121_);
lean_ctor_set(v___x_2156_, 12, v_gmPairs_2122_);
v___x_2157_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2157_, 0, v_table_2109_);
lean_ctor_set(v___x_2157_, 1, v___x_2156_);
if (v_isShared_2150_ == 0)
{
lean_ctor_set(v___x_2149_, 2, v___x_2127_);
lean_ctor_set(v___x_2149_, 1, v___x_2153_);
lean_ctor_set(v___x_2149_, 0, v___x_2105_);
v___x_2159_ = v___x_2149_;
goto v_reusejp_2158_;
}
else
{
lean_object* v_reuseFailAlloc_2171_; 
v_reuseFailAlloc_2171_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v_reuseFailAlloc_2171_, 0, v___x_2105_);
lean_ctor_set(v_reuseFailAlloc_2171_, 1, v___x_2153_);
lean_ctor_set(v_reuseFailAlloc_2171_, 2, v___x_2127_);
v___x_2159_ = v_reuseFailAlloc_2171_;
goto v_reusejp_2158_;
}
v_reusejp_2158_:
{
lean_object* v___x_2160_; lean_object* v_fst_2161_; lean_object* v_snd_2162_; lean_object* v___x_2164_; uint8_t v_isShared_2165_; uint8_t v_isSharedCheck_2170_; 
v___x_2160_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0___redArg(v___y_2146_, v_edges_2147_, v___x_2159_, v___x_2140_, v___x_2105_, v___x_2157_);
lean_dec_ref(v___x_2159_);
lean_dec_ref(v_edges_2147_);
v_fst_2161_ = lean_ctor_get(v___x_2160_, 0);
v_snd_2162_ = lean_ctor_get(v___x_2160_, 1);
v_isSharedCheck_2170_ = !lean_is_exclusive(v___x_2160_);
if (v_isSharedCheck_2170_ == 0)
{
v___x_2164_ = v___x_2160_;
v_isShared_2165_ = v_isSharedCheck_2170_;
goto v_resetjp_2163_;
}
else
{
lean_inc(v_snd_2162_);
lean_inc(v_fst_2161_);
lean_dec(v___x_2160_);
v___x_2164_ = lean_box(0);
v_isShared_2165_ = v_isSharedCheck_2170_;
goto v_resetjp_2163_;
}
v_resetjp_2163_:
{
lean_object* v_a_2166_; lean_object* v___x_2168_; 
v_a_2166_ = lean_ctor_get(v_fst_2161_, 0);
lean_inc(v_a_2166_);
lean_dec(v_fst_2161_);
if (v_isShared_2165_ == 0)
{
lean_ctor_set(v___x_2164_, 1, v_snd_2101_);
lean_ctor_set(v___x_2164_, 0, v_a_2166_);
v___x_2168_ = v___x_2164_;
goto v_reusejp_2167_;
}
else
{
lean_object* v_reuseFailAlloc_2169_; 
v_reuseFailAlloc_2169_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2169_, 0, v_a_2166_);
lean_ctor_set(v_reuseFailAlloc_2169_, 1, v_snd_2101_);
v___x_2168_ = v_reuseFailAlloc_2169_;
goto v_reusejp_2167_;
}
v_reusejp_2167_:
{
v_a_2093_ = v___x_2168_;
v_snd_2094_ = v_snd_2162_;
goto v___jp_2092_;
}
}
}
}
else
{
lean_object* v___x_2172_; 
lean_dec(v_work_2154_);
lean_dec(v___x_2153_);
lean_del_object(v___x_2149_);
lean_dec_ref(v_edges_2147_);
lean_dec_ref(v___x_2140_);
lean_dec(v_gmPairs_2122_);
lean_dec(v_chainPairs_2121_);
lean_dec(v_productPairs_2120_);
lean_dec(v_largestBatch_2119_);
lean_dec(v_peakMatrixEntries_2118_);
lean_dec(v_peakMatrixRows_2117_);
lean_dec(v_matrixCalls_2116_);
lean_dec(v_matrixRows_2115_);
lean_dec(v_matrixEntries_2114_);
lean_dec(v_rounds_2113_);
lean_dec(v_pairs_2112_);
lean_dec(v_allocatedBytes_2111_);
lean_dec_ref(v_table_2109_);
lean_dec(v_snd_2101_);
lean_dec(v_i_2083_);
v___x_2172_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__1));
v_a_2086_ = v___x_2172_;
v_snd_2087_ = v___x_2144_;
goto v___jp_2085_;
}
}
}
v___jp_2176_:
{
uint64_t v___x_2179_; uint64_t v___x_2180_; uint64_t v___x_2181_; uint64_t v___x_2182_; 
v___x_2179_ = lean_uint8_to_uint64(v___y_2178_);
v___x_2180_ = 24ULL;
v___x_2181_ = lean_uint64_shift_left(v___x_2179_, v___x_2180_);
v___x_2182_ = lean_uint64_lor(v___y_2177_, v___x_2181_);
v___y_2146_ = v___x_2182_;
goto v___jp_2145_;
}
v___jp_2183_:
{
uint64_t v___x_2186_; uint64_t v___x_2187_; uint64_t v___x_2188_; uint64_t v___x_2189_; 
v___x_2186_ = lean_uint8_to_uint64(v___y_2185_);
v___x_2187_ = 8ULL;
v___x_2188_ = lean_uint64_shift_left(v___x_2186_, v___x_2187_);
v___x_2189_ = lean_uint64_lor(v___y_2184_, v___x_2188_);
v___y_2146_ = v___x_2189_;
goto v___jp_2145_;
}
}
}
}
}
else
{
lean_object* v___x_2306_; 
lean_dec(v_work_2128_);
lean_del_object(v___x_2124_);
lean_dec(v_gmPairs_2122_);
lean_dec(v_chainPairs_2121_);
lean_dec(v_productPairs_2120_);
lean_dec(v_largestBatch_2119_);
lean_dec(v_peakMatrixEntries_2118_);
lean_dec(v_peakMatrixRows_2117_);
lean_dec(v_matrixCalls_2116_);
lean_dec(v_matrixRows_2115_);
lean_dec(v_matrixEntries_2114_);
lean_dec(v_rounds_2113_);
lean_dec(v_pairs_2112_);
lean_dec(v_allocatedBytes_2111_);
lean_del_object(v___x_2103_);
lean_dec(v_snd_2101_);
lean_dec(v_fst_2100_);
lean_dec(v_i_2083_);
v___x_2306_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_build_spec__1___redArg___closed__1));
v_a_2086_ = v___x_2306_;
v_snd_2087_ = v___y_2084_;
goto v___jp_2085_;
}
}
}
else
{
lean_object* v___x_2309_; 
lean_dec(v_i_2083_);
if (v_isShared_2104_ == 0)
{
v___x_2309_ = v___x_2103_;
goto v_reusejp_2308_;
}
else
{
lean_object* v_reuseFailAlloc_2312_; 
v_reuseFailAlloc_2312_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2312_, 0, v_fst_2100_);
lean_ctor_set(v_reuseFailAlloc_2312_, 1, v_snd_2101_);
v___x_2309_ = v_reuseFailAlloc_2312_;
goto v_reusejp_2308_;
}
v_reusejp_2308_:
{
lean_object* v___x_2310_; lean_object* v___x_2311_; 
v___x_2310_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2310_, 0, v___x_2309_);
v___x_2311_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2311_, 0, v___x_2310_);
lean_ctor_set(v___x_2311_, 1, v___y_2084_);
return v___x_2311_;
}
}
}
}
v___jp_2085_:
{
lean_object* v___x_2088_; lean_object* v___x_2089_; 
lean_inc_ref(v_a_2086_);
v___x_2088_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2088_, 0, v_a_2086_);
v___x_2089_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2089_, 0, v___x_2088_);
lean_ctor_set(v___x_2089_, 1, v_snd_2087_);
return v___x_2089_;
}
v___jp_2092_:
{
lean_object* v___x_2095_; 
v___x_2095_ = lean_nat_add(v_i_2083_, v_step_2091_);
lean_dec(v_i_2083_);
v_b_2082_ = v_a_2093_;
v_i_2083_ = v___x_2095_;
v___y_2084_ = v_snd_2094_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1___redArg___boxed(lean_object* v_limits_2314_, lean_object* v___x_2315_, lean_object* v_context_2316_, lean_object* v_table_2317_, lean_object* v_monomial_2318_, lean_object* v_range_2319_, lean_object* v_b_2320_, lean_object* v_i_2321_, lean_object* v___y_2322_){
_start:
{
lean_object* v_res_2323_; 
v_res_2323_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1___redArg(v_limits_2314_, v___x_2315_, v_context_2316_, v_table_2317_, v_monomial_2318_, v_range_2319_, v_b_2320_, v_i_2321_, v___y_2322_);
lean_dec_ref(v_range_2319_);
lean_dec(v_monomial_2318_);
lean_dec_ref(v_table_2317_);
lean_dec_ref(v_context_2316_);
lean_dec_ref(v___x_2315_);
lean_dec_ref(v_limits_2314_);
return v_res_2323_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_divisors(lean_object* v_context_2329_, lean_object* v_limits_2330_, lean_object* v_index_2331_, lean_object* v_monomial_2332_, lean_object* v_a_2333_){
_start:
{
lean_object* v_table_2334_; lean_object* v___x_2335_; lean_object* v___x_2336_; lean_object* v___x_2337_; lean_object* v___x_2338_; lean_object* v___x_2339_; lean_object* v___x_2340_; lean_object* v_fst_2341_; 
v_table_2334_ = lean_ctor_get(v_a_2333_, 0);
lean_inc_ref(v_table_2334_);
v___x_2335_ = lean_unsigned_to_nat(0u);
v___x_2336_ = lean_unsigned_to_nat(1u);
v___x_2337_ = lean_array_get_size(v_index_2331_);
v___x_2338_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2338_, 0, v___x_2335_);
lean_ctor_set(v___x_2338_, 1, v___x_2337_);
lean_ctor_set(v___x_2338_, 2, v___x_2336_);
v___x_2339_ = ((lean_object*)(lp_Hex_Hex_Groebner_ReducerIndex_divisors___closed__1));
v___x_2340_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1___redArg(v_limits_2330_, v_index_2331_, v_context_2329_, v_table_2334_, v_monomial_2332_, v___x_2338_, v___x_2339_, v___x_2335_, v_a_2333_);
lean_dec_ref_known(v___x_2338_, 3);
lean_dec_ref(v_table_2334_);
v_fst_2341_ = lean_ctor_get(v___x_2340_, 0);
lean_inc(v_fst_2341_);
if (lean_obj_tag(v_fst_2341_) == 0)
{
lean_object* v_snd_2342_; lean_object* v___x_2344_; uint8_t v_isShared_2345_; uint8_t v_isSharedCheck_2357_; 
v_snd_2342_ = lean_ctor_get(v___x_2340_, 1);
v_isSharedCheck_2357_ = !lean_is_exclusive(v___x_2340_);
if (v_isSharedCheck_2357_ == 0)
{
lean_object* v_unused_2358_; 
v_unused_2358_ = lean_ctor_get(v___x_2340_, 0);
lean_dec(v_unused_2358_);
v___x_2344_ = v___x_2340_;
v_isShared_2345_ = v_isSharedCheck_2357_;
goto v_resetjp_2343_;
}
else
{
lean_inc(v_snd_2342_);
lean_dec(v___x_2340_);
v___x_2344_ = lean_box(0);
v_isShared_2345_ = v_isSharedCheck_2357_;
goto v_resetjp_2343_;
}
v_resetjp_2343_:
{
lean_object* v_a_2346_; lean_object* v___x_2348_; uint8_t v_isShared_2349_; uint8_t v_isSharedCheck_2356_; 
v_a_2346_ = lean_ctor_get(v_fst_2341_, 0);
v_isSharedCheck_2356_ = !lean_is_exclusive(v_fst_2341_);
if (v_isSharedCheck_2356_ == 0)
{
v___x_2348_ = v_fst_2341_;
v_isShared_2349_ = v_isSharedCheck_2356_;
goto v_resetjp_2347_;
}
else
{
lean_inc(v_a_2346_);
lean_dec(v_fst_2341_);
v___x_2348_ = lean_box(0);
v_isShared_2349_ = v_isSharedCheck_2356_;
goto v_resetjp_2347_;
}
v_resetjp_2347_:
{
lean_object* v___x_2351_; 
if (v_isShared_2349_ == 0)
{
v___x_2351_ = v___x_2348_;
goto v_reusejp_2350_;
}
else
{
lean_object* v_reuseFailAlloc_2355_; 
v_reuseFailAlloc_2355_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2355_, 0, v_a_2346_);
v___x_2351_ = v_reuseFailAlloc_2355_;
goto v_reusejp_2350_;
}
v_reusejp_2350_:
{
lean_object* v___x_2353_; 
if (v_isShared_2345_ == 0)
{
lean_ctor_set(v___x_2344_, 0, v___x_2351_);
v___x_2353_ = v___x_2344_;
goto v_reusejp_2352_;
}
else
{
lean_object* v_reuseFailAlloc_2354_; 
v_reuseFailAlloc_2354_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2354_, 0, v___x_2351_);
lean_ctor_set(v_reuseFailAlloc_2354_, 1, v_snd_2342_);
v___x_2353_ = v_reuseFailAlloc_2354_;
goto v_reusejp_2352_;
}
v_reusejp_2352_:
{
return v___x_2353_;
}
}
}
}
}
else
{
lean_object* v_a_2359_; lean_object* v___x_2361_; uint8_t v_isShared_2362_; uint8_t v_isSharedCheck_2376_; 
v_a_2359_ = lean_ctor_get(v_fst_2341_, 0);
v_isSharedCheck_2376_ = !lean_is_exclusive(v_fst_2341_);
if (v_isSharedCheck_2376_ == 0)
{
v___x_2361_ = v_fst_2341_;
v_isShared_2362_ = v_isSharedCheck_2376_;
goto v_resetjp_2360_;
}
else
{
lean_inc(v_a_2359_);
lean_dec(v_fst_2341_);
v___x_2361_ = lean_box(0);
v_isShared_2362_ = v_isSharedCheck_2376_;
goto v_resetjp_2360_;
}
v_resetjp_2360_:
{
lean_object* v_snd_2363_; lean_object* v_snd_2364_; lean_object* v___x_2366_; uint8_t v_isShared_2367_; uint8_t v_isSharedCheck_2374_; 
v_snd_2363_ = lean_ctor_get(v___x_2340_, 1);
lean_inc(v_snd_2363_);
lean_dec_ref(v___x_2340_);
v_snd_2364_ = lean_ctor_get(v_a_2359_, 1);
v_isSharedCheck_2374_ = !lean_is_exclusive(v_a_2359_);
if (v_isSharedCheck_2374_ == 0)
{
lean_object* v_unused_2375_; 
v_unused_2375_ = lean_ctor_get(v_a_2359_, 0);
lean_dec(v_unused_2375_);
v___x_2366_ = v_a_2359_;
v_isShared_2367_ = v_isSharedCheck_2374_;
goto v_resetjp_2365_;
}
else
{
lean_inc(v_snd_2364_);
lean_dec(v_a_2359_);
v___x_2366_ = lean_box(0);
v_isShared_2367_ = v_isSharedCheck_2374_;
goto v_resetjp_2365_;
}
v_resetjp_2365_:
{
lean_object* v___x_2369_; 
if (v_isShared_2362_ == 0)
{
lean_ctor_set(v___x_2361_, 0, v_snd_2364_);
v___x_2369_ = v___x_2361_;
goto v_reusejp_2368_;
}
else
{
lean_object* v_reuseFailAlloc_2373_; 
v_reuseFailAlloc_2373_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2373_, 0, v_snd_2364_);
v___x_2369_ = v_reuseFailAlloc_2373_;
goto v_reusejp_2368_;
}
v_reusejp_2368_:
{
lean_object* v___x_2371_; 
if (v_isShared_2367_ == 0)
{
lean_ctor_set(v___x_2366_, 1, v_snd_2363_);
lean_ctor_set(v___x_2366_, 0, v___x_2369_);
v___x_2371_ = v___x_2366_;
goto v_reusejp_2370_;
}
else
{
lean_object* v_reuseFailAlloc_2372_; 
v_reuseFailAlloc_2372_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2372_, 0, v___x_2369_);
lean_ctor_set(v_reuseFailAlloc_2372_, 1, v_snd_2363_);
v___x_2371_ = v_reuseFailAlloc_2372_;
goto v_reusejp_2370_;
}
v_reusejp_2370_:
{
return v___x_2371_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ReducerIndex_divisors___boxed(lean_object* v_context_2377_, lean_object* v_limits_2378_, lean_object* v_index_2379_, lean_object* v_monomial_2380_, lean_object* v_a_2381_){
_start:
{
lean_object* v_res_2382_; 
v_res_2382_ = lp_Hex_Hex_Groebner_ReducerIndex_divisors(v_context_2377_, v_limits_2378_, v_index_2379_, v_monomial_2380_, v_a_2381_);
lean_dec(v_monomial_2380_);
lean_dec_ref(v_index_2379_);
lean_dec_ref(v_limits_2378_);
lean_dec_ref(v_context_2377_);
return v_res_2382_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0(uint64_t v___y_2383_, lean_object* v___x_2384_, lean_object* v_range_2385_, lean_object* v_b_2386_, lean_object* v_i_2387_, lean_object* v_hs_2388_, lean_object* v_hl_2389_, lean_object* v___y_2390_){
_start:
{
lean_object* v___x_2391_; 
v___x_2391_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0___redArg(v___y_2383_, v___x_2384_, v_range_2385_, v_b_2386_, v_i_2387_, v___y_2390_);
return v___x_2391_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0___boxed(lean_object* v___y_2392_, lean_object* v___x_2393_, lean_object* v_range_2394_, lean_object* v_b_2395_, lean_object* v_i_2396_, lean_object* v_hs_2397_, lean_object* v_hl_2398_, lean_object* v___y_2399_){
_start:
{
uint64_t v___y_11745__boxed_2400_; lean_object* v_res_2401_; 
v___y_11745__boxed_2400_ = lean_unbox_uint64(v___y_2392_);
lean_dec_ref(v___y_2392_);
v_res_2401_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__0(v___y_11745__boxed_2400_, v___x_2393_, v_range_2394_, v_b_2395_, v_i_2396_, v_hs_2397_, v_hl_2398_, v___y_2399_);
lean_dec_ref(v_range_2394_);
lean_dec_ref(v___x_2393_);
return v_res_2401_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1(lean_object* v_limits_2402_, lean_object* v___x_2403_, lean_object* v_context_2404_, lean_object* v_table_2405_, lean_object* v_monomial_2406_, lean_object* v_range_2407_, lean_object* v_b_2408_, lean_object* v_i_2409_, lean_object* v_hs_2410_, lean_object* v_hl_2411_, lean_object* v___y_2412_){
_start:
{
lean_object* v___x_2413_; 
v___x_2413_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1___redArg(v_limits_2402_, v___x_2403_, v_context_2404_, v_table_2405_, v_monomial_2406_, v_range_2407_, v_b_2408_, v_i_2409_, v___y_2412_);
return v___x_2413_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1___boxed(lean_object* v_limits_2414_, lean_object* v___x_2415_, lean_object* v_context_2416_, lean_object* v_table_2417_, lean_object* v_monomial_2418_, lean_object* v_range_2419_, lean_object* v_b_2420_, lean_object* v_i_2421_, lean_object* v_hs_2422_, lean_object* v_hl_2423_, lean_object* v___y_2424_){
_start:
{
lean_object* v_res_2425_; 
v_res_2425_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_ReducerIndex_divisors_spec__1(v_limits_2414_, v___x_2415_, v_context_2416_, v_table_2417_, v_monomial_2418_, v_range_2419_, v_b_2420_, v_i_2421_, v_hs_2422_, v_hl_2423_, v___y_2424_);
lean_dec_ref(v_range_2419_);
lean_dec(v_monomial_2418_);
lean_dec_ref(v_table_2417_);
lean_dec_ref(v_context_2416_);
lean_dec_ref(v___x_2415_);
lean_dec_ref(v_limits_2414_);
return v_res_2425_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Polynomial(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_Reducer(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Polynomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_Groebner_instInhabitedBasisElement_default = _init_lp_Hex_Hex_Groebner_instInhabitedBasisElement_default();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedBasisElement_default);
lp_Hex_Hex_Groebner_instInhabitedBasisElement = _init_lp_Hex_Hex_Groebner_instInhabitedBasisElement();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedBasisElement);
lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default = _init_lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedDivisorNode_default);
lp_Hex_Hex_Groebner_instInhabitedDivisorNode = _init_lp_Hex_Hex_Groebner_instInhabitedDivisorNode();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedDivisorNode);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_Reducer(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Polynomial(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_Reducer(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Polynomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Reducer(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_Reducer(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_Reducer(builtin);
}
#ifdef __cplusplus
}
#endif
