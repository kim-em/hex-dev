### Description

In a `module`, a small literal `for` loop cannot be discharged by ordinary kernel reduction through `decide +kernel` after importing `Init.Data.Range.Basic`. Changing that import to `import all Init.Data.Range.Basic` makes exactly the same proof pass.

Could the logical body and loop helper behind `Std.Legacy.Range.forIn'` be exposed for this use? If the opacity is intentional, guidance for portable kernel-reducible loop models would also help.

### Reproducer

`RangePublic.lean`:

```lean
module

import Init.Data.Range.Basic

public theorem loop_example : (Id.run do
    let mut total := 0
    for i in [:2] do total := total+i
    return total) = 1 := by decide +kernel
```

`lake build RangePublic` fails with `Tactic decide failed to reduce`; the residual expression contains the range loop. The control file differs in only one line:

```lean
import all Init.Data.Range.Basic
```

With that import, `lake build RangePrivate` succeeds. No Mathlib or Batteries is needed. Minimal `lakefile.lean`:

```lean
import Lake
open Lake DSL
package rangeReplay
lean_lib RangePublic
lean_lib RangePrivate
```

### Versions and checks

The public-import case fails and the `import all` control passes on each tested toolchain:

- `leanprover/lean4:v4.35.0-rc3` (our project pin).
- `leanprover/lean4:v4.36.0-rc2`.
- `leanprover/lean4-nightly:nightly-2026-10-30`, the newest published nightly listed by the release API when checked.

The current default-branch source also declares the range operation `@[inline]` without `@[expose]`. I checked for related issues using `Std.Legacy.Range`, `Range expose`, and `forIn decide`; #10546 concerns a different module/kernel mismatch involving signed integers.

### Impact

This surfaced while adding kernel-replay examples for pure Lean models of bounded finite-field matrix operations in kim-em/hex-dev#10987. The implementation currently keeps the `import all` workaround in a test-only module and continues native-operation work independently. We are not asserting a runtime performance penalty from this reproducer; the observed cost is that the ordinary public-import replay does not build.
