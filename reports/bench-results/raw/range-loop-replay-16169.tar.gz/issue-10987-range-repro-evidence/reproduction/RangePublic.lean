module

import Init.Data.Range.Basic

public theorem loop_example : (Id.run do
    let mut total := 0
    for i in [:2] do total := total+i
    return total) = 1 := by decide +kernel
