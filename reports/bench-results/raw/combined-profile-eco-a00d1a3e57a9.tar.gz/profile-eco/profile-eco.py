from pathlib import Path
import os,sys,json,subprocess,hashlib
sys.path.insert(0,'/tmp/hex-groebner-sparse-targets-dev')
from scripts.bench.cpu_lease import cpu_lease
p=Path(__file__).resolve().parent;out=p/'profile-eco';out.mkdir(exist_ok=False);cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});binary=p/'binaries/compute';inputs=Path('/tmp/hex-groebner-compare/eco10-31.json')
args=[str(binary),'--work','100000000000','--packed-bytes',str(16*1024**3),'--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000',str(inputs)]
batch=out/'batch.py';batch.write_text('import subprocess\ncommand='+repr(args)+'\nfor i in range(8):\n with open('+repr(str(out))+'+"/run-"+str(i)+".stdout","wb") as f:\n  subprocess.run(command,stdout=f,check=True)\n')
command=['perf','record','-F','1999','-g','--call-graph','dwarf,4096','-o',str(out/'eco.perf'),'--','python3',str(batch)]
try:
 with (out/'record.log').open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 if r.returncode==0:
  with (out/'symbols.txt').open('w') as report:subprocess.run(['perf','report','--stdio','--no-children','--sort','symbol','-i',str(out/'eco.perf')],stdout=report,stderr=subprocess.STDOUT,check=True)
 (out/'metadata.json').write_text(json.dumps({'source_fingerprint':'a00d1a3e57a9','cpu':cpu,'host':os.uname().nodename,'load':os.getloadavg(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(inputs.read_bytes()).hexdigest(),'command':command,'returncode':r.returncode,'reason':'Explain the remaining Eco gap in the combined native-comparator sweeps after sparse target ordering and packed reducer lookup. Eight exploratory profile invocations, full process including parsing/output; no timing or performance-comparison claim.','script':Path(__file__).read_text()},indent=2)+'\n')
finally:lease.close()
