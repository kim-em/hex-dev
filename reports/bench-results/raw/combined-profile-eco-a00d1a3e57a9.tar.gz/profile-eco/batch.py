import subprocess
command=['/tmp/hex-groebner-combined-production/binaries/compute', '--work', '100000000000', '--packed-bytes', '17179869184', '--pairs', '100000000', '--monomials', '10000000', '--matrix-entries', '1000000000', '/tmp/hex-groebner-compare/eco10-31.json']
for i in range(8):
 with open('/tmp/hex-groebner-combined-production/profile-eco'+"/run-"+str(i)+".stdout","wb") as f:
  subprocess.run(command,stdout=f,check=True)
