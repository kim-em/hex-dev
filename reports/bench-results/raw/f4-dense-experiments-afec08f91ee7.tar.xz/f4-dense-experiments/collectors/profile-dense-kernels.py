from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
state=Path('/home/kim/tmp/issue-10987');base=state/'dense-reviewed-production';out=state/'dense-kernel-cycle-profile';out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('cpu_lease',base/'root-sources/scripts/bench/cpu_lease.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
manifest=json.loads((base/'manifest.json').read_text());binary=base/'binaries/bench';records=[];cpu,lease=module.cpu_lease()
try:
 for block in [0,1]:
  for arm in (['sparse','dense']if block==0 else['dense','sparse']):
   label=f'b{block}-{arm}';name='sparsePivot'if arm=='sparse'else'densePivot';data=out/(label+'.data')
   command=['perf','record','-o',str(data),'-e','cycles:u','-F','997','--call-graph','dwarf,8192','--',str(binary),'_child','--bench','Hex.Groebner.Bench.'+name,'--param','4096','--target-nanos','1000000000']
   start=time.time_ns();load=os.getloadavg()
   with (out/(label+'.stdout')).open('wb')as stdout,(out/(label+'.stderr')).open('wb')as stderr:
    result=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=lambda:os.sched_setaffinity(0,{cpu}))
   with (out/(label+'.report')).open('wb')as report:
    subprocess.run(['perf','report','--stdio','-i',str(data),'--no-children','--percent-limit','0.3'],stdout=report,stderr=subprocess.STDOUT,check=True)
   records.append(dict(label=label,command=command,exit_code=result.returncode,cpu=cpu,started_ns=start,finished_ns=time.time_ns(),load_start=load,load_end=os.getloadavg()))
   (out/'metadata.json').write_text(json.dumps(dict(manifest=manifest,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),perf_version=subprocess.check_output(['perf','--version'],text=True).strip(),records=records,scope='Diagnostic cycle profiles of the already measured kernel to explain near-equal timings. Not a fresh timing campaign or filtered sample selection.'),indent=2)+'\n')
   print(label,result.returncode,flush=True)
   if result.returncode:raise SystemExit(result.returncode)
finally:lease.close()
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
