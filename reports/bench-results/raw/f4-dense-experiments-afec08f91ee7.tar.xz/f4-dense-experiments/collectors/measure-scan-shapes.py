from pathlib import Path
import subprocess,os
state=Path('/home/kim/tmp/issue-10987');base=state/'scan-shapes-production';baseline=state/'sampled-io-production'
common=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'final-products-production/medium-inputs/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--baseline-manifest',str(baseline/'manifest.json')]
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
for name,binary,extra in [('deterministic','compute',[]),('sampled','sample',['--sampled','--baseline-sampled','--seed','10987'])]:
 command=common+extra+['--hex',str(base/'binaries'/binary),'--baseline',str(baseline/'binaries'/binary),'--output',str(base/name)]
 with (base/(name+'-runner.log')).open('w')as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
(base/'measure.py').write_bytes(Path(__file__).read_bytes())
