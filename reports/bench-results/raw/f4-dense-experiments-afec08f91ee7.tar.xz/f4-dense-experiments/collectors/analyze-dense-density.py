from pathlib import Path
import hashlib,json,math,statistics
base=Path('/home/kim/tmp/issue-10987/dense-density-production');metadata=json.loads((base/'kernel-status.json').read_text());samples=metadata['samples']
assert len(samples)==78 and all(s['exit_code']in [0,2]for s in samples)
assert all(a['finished_ns']<=b['started_ns']for a,b in zip(samples,samples[1:]))
expected=[f'complexity/{shape}/{arm}'for shape in ['half','three-quarters','full']for arm in ['dense','sparse']]
expected += [f'matched/{shape}/b{block}-{n}-{arm}'for block in [0,1]for shape in ['half','three-quarters','full']for n in [128,256,512,1024,2048,4096]for arm in (['sparse','dense']if block==0 else['dense','sparse'])]
assert [s['label']for s in samples]==expected
assert metadata['binary_sha256']==metadata['binary_sha256_after']==hashlib.sha256((base/'binaries/bench').read_bytes()).hexdigest()
result={}
for shape in ['half','three-quarters','full']:
 rows=[];ratios=[];flags=0
 for n in [128,256,512,1024,2048,4096]:
  pair=[]
  for block in [0,1]:
   a,b=[json.loads((base/f'kernels/matched/{shape}/b{block}-{n}-{arm}/result.json').read_text())['results'][0]['points'][0]for arm in ['sparse','dense']]
   assert a['status']==b['status']=='ok' and a['result_hash']==b['result_hash']and a['param']==b['param']==n
   for p in [a,b]:assert math.isclose(p['per_call_nanos'],p['total_nanos']/p['inner_repeats'],rel_tol=1e-8)
   flags+=a['below_signal_floor']+b['below_signal_floor'];pair.append(b['per_call_nanos']/a['per_call_nanos']);ratios.append(pair[-1])
  rows.append(dict(n=n,ratios=pair,geomean=math.exp(statistics.mean(map(math.log,pair)))))
 result[shape]=dict(geomean=math.exp(statistics.mean(map(math.log,ratios))),below_signal_floor=flags,rows=rows)
for shape in result:
 result[shape]['curves']={}
 for arm in ['dense','sparse']:
  record=json.loads((base/f'kernels/complexity/{shape}/{arm}/result.json').read_text())['results'][0]
  assert [(p['trial_index'],p['param'])for p in record['points']]==[(t,n)for t in range(3)for n in [128,256,512,1024,2048,4096]]and all(p['status']=='ok'for p in record['points'])
  result[shape]['curves'][arm]=dict(verdict=record['verdict'],slope=record['slope'],below_signal_floor=sum(p['below_signal_floor']for p in record['points']),medians={str(n):statistics.median(p['per_call_nanos']for p in record['points']if p['param']==n)for n in [128,256,512,1024,2048,4096]})
summary=dict(cpu=samples[0]['cpu'],processes=78,matched_pairs=36,inconclusive_processes=sum(s['exit_code']==2 for s in samples),results=result,scope='64 pending updates per call; full final output consumed once; setup excluded. Includes all completed signal-floor samples without rerun. No full-system claim.')
(base/'kernel-analysis.json').write_text(json.dumps(summary,indent=2)+'\n');(base/'analyze-kernels.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({shape:dict(geomean=r['geomean'],flags=r['below_signal_floor'],rows=r['rows'])for shape,r in result.items()},indent=2))
