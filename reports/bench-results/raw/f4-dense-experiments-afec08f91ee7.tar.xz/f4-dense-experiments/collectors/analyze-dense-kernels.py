from pathlib import Path
import hashlib,json,math,statistics
base=Path('/home/kim/tmp/issue-10987/dense-reviewed-production')
metadata=json.loads((base/'kernel-status.json').read_text())
assert metadata['binary_sha256']==metadata['binary_sha256_after']==hashlib.sha256((base/'binaries/bench').read_bytes()).hexdigest()
samples=metadata['samples'];assert len(samples)==27 and all(s['exit_code']==0 for s in samples)
assert all(a['finished_ns']<=b['started_ns']for a,b in zip(samples,samples[1:]))
expected=['complexity/'+v for v in ['dense','sparse','portable']]
expected +=[f'matched/b{b}-{n}-{a}'for b in [0,1]for n in [128,256,512,1024,2048,4096]for a in (['sparse','dense']if b==0 else['dense','sparse'])]
assert [s['label']for s in samples]==expected
rows=[];ratios=[]
for n in [128,256,512,1024,2048,4096]:
 pair=[]
 for block in [0,1]:
  a,b=[json.loads((base/f'kernels/matched/b{block}-{n}-{arm}/result.json').read_text())['results'][0]['points'][0] for arm in ['sparse','dense']]
  assert a['status']==b['status']=='ok'and a['result_hash']==b['result_hash']and a['param']==b['param']==n
  for point in [a,b]:assert math.isclose(point['per_call_nanos'],point['total_nanos']/point['inner_repeats'],rel_tol=1e-8)
  pair.append(b['per_call_nanos']/a['per_call_nanos'])
  ratios.append(pair[-1])
 rows.append(dict(n=n,ratios=pair,geomean=math.exp(statistics.mean(map(math.log,pair)))))
curves={}
for arm in ['dense','sparse','portable']:
 result=json.loads((base/f'kernels/complexity/{arm}/result.json').read_text())['results'][0]
 assert [(p['trial_index'],p['param'])for p in result['points']]==[(t,n)for t in range(3)for n in [128,256,512,1024,2048,4096]]
 assert all(p['status']=='ok'for p in result['points'])
 curves[arm]=dict(verdict=result['verdict'],slope=result['slope'],below_signal_floor=sum(p['below_signal_floor']for p in result['points']),medians={str(n):statistics.median(p['per_call_nanos']for p in result['points']if p['param']==n)for n in [128,256,512,1024,2048,4096]})
result=dict(cpu=samples[0]['cpu'],processes=len(samples),matched_pairs=12,matched_dense_over_sparse_geomean=math.exp(statistics.mean(map(math.log,ratios))),rows=rows,curves=curves,scope='Pending half-full M31 row updates; preparation excluded; full outputs and counters consumed. No full-system timing claim.')
(base/'kernel-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
(base/'analyze-kernels.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(result,indent=2))
