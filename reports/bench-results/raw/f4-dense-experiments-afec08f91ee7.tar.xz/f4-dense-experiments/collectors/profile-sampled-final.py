from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time
state=Path('/home/kim/tmp/issue-10987');base=state/'sampled-io-production';manifest=json.loads((base/'manifest.json').read_text());out=state/'sampled-final-cycle-profile'
args=['--scheduling','degree','--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000']
input=state/'final-products-production/medium-inputs/eco11-31.json'
if '--worker' in sys.argv:
 arm=sys.argv[2];folder=Path(sys.argv[3]);records=[];binary=base/'binaries'/arm
 for i in range(4):
  command=[str(binary),*args,*(['--seed','10987','--block-rows','32','--zero-tests','3']if arm=='sample' else []),str(input)]
  r=subprocess.run(command,capture_output=True);(folder/f'{i}.stdout').write_bytes(r.stdout);(folder/f'{i}.stderr').write_bytes(r.stderr)
  records.append(dict(iteration=i,command=command,exit_code=r.returncode));(folder/'processes.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0
 raise SystemExit(0)
helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('frozen_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
out.mkdir(exist_ok=False);cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[];start=time.time()
hashes={arm:hashlib.sha256((base/'binaries'/arm).read_bytes()).hexdigest()for arm in ['compute','sample']};assert all(hashes[arm]==manifest['binary_sha256'][arm]for arm in hashes)
try:
 for arm in ['compute','sample']:
  folder=out/arm;folder.mkdir();command=['perf','record','-e','cycles:u','-F','997','--call-graph','dwarf,8192','--output',str(folder/'perf.data'),'--','python3',str(Path(__file__).resolve()),'--worker',arm,str(folder)]
  with (folder/'record.log').open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  runs.append(dict(arm=arm,command=command,exit_code=r.returncode));assert r.returncode==0
  for label,options in [('all',['--sort','comm,symbol']),('engine',['--comms',arm,'--sort','symbol'])]:
   with (folder/(label+'.txt')).open('w')as log:r=subprocess.run(['perf','report','--stdio','--no-children','--percent-limit','0.5','-i',str(folder/'perf.data'),*options],stdout=log,stderr=subprocess.STDOUT)
   assert r.returncode==0
  print(arm,'profile complete',flush=True)
finally:
 after={arm:hashlib.sha256((base/'binaries'/arm).read_bytes()).hexdigest()for arm in hashes}
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,algorithm_threads=1,host=os.uname().nodename,kernel=os.uname().release,load_start=load,load_end=os.getloadavg(),start_epoch=start,end_epoch=time.time(),binary_sha256_before=hashes,binary_sha256_after=after,manifest=manifest,input_sha256=hashlib.sha256(input.read_bytes()).hexdigest(),perf_version=subprocess.check_output(['perf','--version'],text=True).strip(),runs=runs,scope='Diagnostic cycle profiles explaining why the opt-in sampler has no overall win after removing quadratic pivot metadata copying. Four complete Eco11 M31 invocations per arm, fixed degree scheduling, seed10987/block32/zero3. All outputs and failures retained. No scientific timing, speedup or acceptance claim uses profiled candidateNanos or sample weights. No filtering or unchanged repeat.'),indent=2)+'\n');lease.close();assert hashes==after
(out/'profile.py').write_bytes(Path(__file__).read_bytes())
values=[json.loads((out/arm/f'{i}.stdout').read_text())for arm in ['compute','sample']for i in range(4)]
assert all(v['basis']==values[0]['basis']for v in values)
print('all eight profiled complete bases agree')
