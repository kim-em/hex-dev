/* Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
   Released under Apache 2.0 license as described in the file LICENSE.
   Authors: Kim Morrison */
#include <lean/lean.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "simd.h"

static inline uint64_t rd(const uint8_t *p, unsigned w) {
    uint64_t v=p[0];
    if(w>1) v|=(uint64_t)p[1]<<8;
    if(w>2) v|=(uint64_t)p[2]<<16 | (uint64_t)p[3]<<24;
    return v;
}
static inline void wr(uint8_t *p,unsigned w,uint64_t v) {
    p[0]=(uint8_t)v;
    if(w>1) p[1]=(uint8_t)(v>>8);
    if(w>2) {p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);}
}
static uint64_t bounded_nat(b_lean_obj_arg n,uint64_t cap) {
    lean_object *limit=lean_uint64_to_nat(cap);
    uint64_t value=lean_nat_dec_le(n,limit)?lean_uint64_of_nat(n):cap;
    lean_dec(limit);
    return value;
}
static inline int geometry(b_lean_obj_arg pivot,unsigned w,uint64_t *size) {
    size_t cb=lean_sarray_size(lean_ctor_get(pivot,0));
    size_t vb=lean_sarray_size(lean_ctor_get(pivot,1));
    *size=cb/4;
    return cb%4==0 && *size!=0 && *size<=UINT32_MAX && vb==*size*w;
}
static lean_obj_res result(lean_obj_arg state,lean_obj_arg events,
        uint64_t work,uint64_t reductions,uint64_t traces,uint8_t status) {
    lean_object *out=lean_alloc_ctor(0,5,1);
    lean_ctor_set(out,0,state);lean_ctor_set(out,1,events);
    lean_ctor_set(out,2,lean_uint64_to_nat(work));
    lean_ctor_set(out,3,lean_uint64_to_nat(reductions));
    lean_ctor_set(out,4,lean_uint64_to_nat(traces));
    lean_ctor_set_uint8(out,5*sizeof(void*),status);
    return out;
}

LEAN_EXPORT lean_obj_res lean_hex_scan_transition(uint64_t p,
        b_lean_obj_arg slots,b_lean_obj_arg pivots,lean_obj_arg initial,
        b_lean_obj_arg quantum_arg,b_lean_obj_arg work_arg,b_lean_obj_arg trace_arg,
        uint8_t provenance) {
    unsigned w=p<=256?1:p<=65536?2:4;
    lean_object *dense=lean_ctor_get(initial,0);
    size_t db=lean_sarray_size(dense), count=lean_array_size(pivots);
    uint64_t columns=db/w;
    uint64_t quantum=bounded_nat(quantum_arg,4097);
    uint64_t col=bounded_nat(lean_ctor_get(initial,1),UINT64_C(4294967296));
    uint64_t last=bounded_nat(lean_ctor_get(initial,2),UINT64_C(4294967296));
    uint64_t charged=bounded_nat(lean_ctor_get(initial,3),UINT64_C(4294967296));
    uint64_t leading=bounded_nat(lean_ctor_get(initial,4),UINT64_C(4294967296));
    uint64_t pending=bounded_nat(lean_ctor_get(initial,5),UINT64_C(4294967296));
    uint64_t entry=bounded_nat(lean_ctor_get(initial,6),UINT64_C(4294967296));
    uint64_t factor=lean_ctor_get_uint64(initial,8*sizeof(void*));
    if(p<2 || p>=UINT64_C(2147483648) || quantum>4096 || db%w ||
       columns>UINT32_MAX || columns>SIZE_MAX/4 || lean_sarray_size(slots)!=columns*4 ||
       col>columns || (columns && last>=columns) || leading>columns ||
       pending>count || count>UINT32_MAX || charged>columns || entry>UINT32_MAX ||
       (!pending && entry) || (pending && col>=columns) || (!columns && last) || factor>=p)
        return result(initial,lean_alloc_array(0,0),0,0,0,4);
    uint64_t work_limit=bounded_nat(work_arg,UINT64_C(1)<<45);
    uint64_t trace_limit=bounded_nat(trace_arg,4096);
    lean_object *events=lean_alloc_array(0,provenance?(size_t)(quantum<trace_limit?quantum:trace_limit):0);
    lean_object *sugar=lean_ctor_get(initial,7);
    lean_inc(dense);lean_inc(sugar);
    lean_object *alias=NULL;
    if(dense==slots) {alias=dense;lean_inc(alias);}
    lean_dec(initial);
    dense=lean_sarray_ensure_exclusive(dense);
    uint8_t *data=lean_sarray_cptr(dense);
    const uint8_t *slot_bytes=lean_sarray_cptr(slots);
    uint64_t work=0,reductions=0,traces=0;
    uint8_t status=0;
#if defined(__SIZEOF_INT128__) && !defined(HEX_GROEBNER_NO_UINT128)
    uint64_t reciprocal;
    if(w<4) reciprocal=UINT64_C(4294967296)/p;
    else {reciprocal=UINT64_MAX/p;if(UINT64_MAX%p==p-1) ++reciprocal;}
#endif
#if HEX_GROEBNER_AVX2
    int simd=w==4 && (p&1) && hex_avx2_available();
    uint32_t negative_inverse=simd?hex_mont32_inverse((uint32_t)p):0;
#endif
    for(uint64_t tick=0;tick<quantum;++tick) {
        if(pending) {
            lean_object *pivot=lean_array_cptr(pivots)[pending-1];
            uint64_t size;
            if(!geometry(pivot,w,&size) || entry>size) {status=4;break;}
            if(entry==size) {
                ++reductions;
                if(provenance) {
                    if(traces>=trace_limit) {status=3;break;}
                    lean_object *event=lean_alloc_ctor(0,2,0);
                    lean_ctor_set(event,0,lean_uint64_to_nat(pending-1));
                    lean_ctor_set(event,1,lean_box_uint64(factor));
                    events=lean_array_push(events,event);++traces;
                }
                pending=0;entry=0;++col;
            } else {
                const uint8_t *cs=lean_sarray_cptr(lean_ctor_get(pivot,0));
                const uint8_t *vs=lean_sarray_cptr(lean_ctor_get(pivot,1));
                uint64_t updates=size-entry;
                if(updates>quantum-tick) updates=quantum-tick;
#if HEX_GROEBNER_AVX2
                uint32_t factor_mont=simd && updates>=8?(uint32_t)((factor<<32)%p):0;
#endif
                for(uint64_t k=0;k<updates;++k) {
#if HEX_GROEBNER_AVX2
                if(simd && updates-k>=8 && hex_scan8(data,cs,vs,(size_t)entry,columns,
                        (uint32_t)p,factor_mont,negative_inverse)) {
                    entry+=8;k+=7;continue;
                }
#endif
                uint64_t j=rd(cs+(size_t)entry*4,4),b=rd(vs+(size_t)entry*w,w);
                if(j>=columns || !b || b>=p || (entry && rd(cs+(size_t)(entry-1)*4,4)>=j)) {status=4;break;}
                uint64_t a=rd(data+(size_t)j*w,w);
                if(a>=p) {status=4;break;}
                uint64_t product=factor*b;
#if defined(__SIZEOF_INT128__) && !defined(HEX_GROEBNER_NO_UINT128)
                uint64_t q=w<4?(product*reciprocal)>>32:(uint64_t)(((__uint128_t)product*reciprocal)>>64);
                product-=q*p;if(product>=p) product-=p;
#else
                product%=p;
#endif
                uint64_t difference=a-product;
                difference+=p&(UINT64_C(0)-(difference>>63));
                wr(data+(size_t)j*w,w,difference);++entry;
                }
                if(status==4) break;
                tick+=updates-1;
            }
        } else {
            if(col>=columns || col>last) {status=1;break;}
            if(col>=charged) {
                uint64_t stop=col+64<last+1?col+64:last+1;
                uint64_t charge=stop-col;
                if(work+charge>work_limit) {status=2;break;}
                work+=charge;charged=stop;
            }
            uint64_t a=rd(data+(size_t)col*w,w);
            if(a>=p) {status=4;break;}
            uint64_t slot=rd(slot_bytes+(size_t)col*4,4);
            if(!a || !slot) {if(a && !leading) leading=col+1;++col;}
            else {
                if(slot>count) {status=4;break;}
                lean_object *pivot=lean_array_cptr(pivots)[slot-1];
                uint64_t size;
                if(!geometry(pivot,w,&size)) {status=4;break;}
                const uint8_t *cs=lean_sarray_cptr(lean_ctor_get(pivot,0));
                const uint8_t *vs=lean_sarray_cptr(lean_ctor_get(pivot,1));
                if(rd(cs,4)!=col || rd(vs,w)!=1) {status=4;break;}
                uint64_t end=rd(cs+(size_t)(size-1)*4,4);
                if(end>=columns) {status=4;break;}
                if(end>last) last=end;
                lean_object *label=lean_ctor_get(pivot,2);
                if(lean_nat_dec_lt(sugar,label)) {lean_inc(label);lean_dec(sugar);sugar=label;}
                if(work+size>work_limit) {status=2;break;}
                work+=size;pending=slot;entry=0;factor=a;
            }
        }
    }
    if(alias) lean_dec(alias);
    lean_object *state=lean_alloc_ctor(0,8,8);
    lean_ctor_set(state,0,dense);lean_ctor_set(state,1,lean_uint64_to_nat(col));
    lean_ctor_set(state,2,lean_uint64_to_nat(last));lean_ctor_set(state,3,lean_uint64_to_nat(charged));
    lean_ctor_set(state,4,lean_uint64_to_nat(leading));lean_ctor_set(state,5,lean_uint64_to_nat(pending));
    lean_ctor_set(state,6,lean_uint64_to_nat(entry));lean_ctor_set(state,7,sugar);
    lean_ctor_set_uint64(state,8*sizeof(void*),factor);
    return result(state,events,work,reductions,traces,status);
}

static lean_object *append_scalar(lean_obj_arg bytes,unsigned w,uint64_t value) {
    size_t used=lean_sarray_size(bytes),cap=lean_sarray_capacity(bytes);
    if(!lean_is_exclusive(bytes) || cap-used<w) {
        size_t wanted=used+w;
        size_t grown=cap>SIZE_MAX/2?wanted:cap*2;
        if(grown<wanted) grown=wanted;
        lean_object *copy=lean_alloc_sarray(1,used,grown);
        memcpy(lean_sarray_cptr(copy),lean_sarray_cptr(bytes),used);
        lean_dec(bytes);bytes=copy;
    }
    wr(lean_sarray_cptr(bytes)+used,w,value);
    lean_sarray_set_size(bytes,used+w);
    return bytes;
}

static lean_obj_res gather_result(lean_obj_arg state,uint64_t entries,
        uint64_t bytes,uint64_t work,uint8_t status) {
    lean_object *out=lean_alloc_ctor(0,4,1);
    lean_ctor_set(out,0,state);lean_ctor_set(out,1,lean_uint64_to_nat(entries));
    lean_ctor_set(out,2,lean_uint64_to_nat(bytes));lean_ctor_set(out,3,lean_uint64_to_nat(work));
    lean_ctor_set_uint8(out,4*sizeof(void*),status);
    return out;
}

LEAN_EXPORT lean_obj_res lean_hex_gather(uint64_t p,lean_obj_arg initial,
        b_lean_obj_arg stop_arg,b_lean_obj_arg quantum_arg,b_lean_obj_arg entries_arg,
        b_lean_obj_arg bytes_arg,b_lean_obj_arg work_arg,uint64_t factor) {
    unsigned w=p<=256?1:p<=65536?2:4;
    lean_object *dense=lean_ctor_get(initial,0),*cols=lean_ctor_get(initial,1),*coeff=lean_ctor_get(initial,2);
    size_t db=lean_sarray_size(dense),cb=lean_sarray_size(cols),vb=lean_sarray_size(coeff);
    uint64_t size=db/w,stop=bounded_nat(stop_arg,UINT64_C(4294967296));
    uint64_t cursor=bounded_nat(lean_ctor_get(initial,3),UINT64_C(4294967296));
    uint64_t quantum=bounded_nat(quantum_arg,4097);
    if(p<2 || p>=UINT64_C(2147483648) || !factor || factor>=p || quantum>4096 || db%w ||
       size>UINT32_MAX || cursor>stop || stop>size || cb%4 || vb!=(cb/4)*w)
        return gather_result(initial,0,0,0,5);
    uint64_t entries_limit=bounded_nat(entries_arg,4096),bytes_limit=bounded_nat(bytes_arg,32768);
    uint64_t work_limit=bounded_nat(work_arg,4096);
    lean_inc(dense);lean_inc(cols);lean_inc(coeff);lean_dec(initial);
    dense=lean_sarray_ensure_exclusive(dense);
    /* Output aliases retain their original data until append_scalar copies. */
    uint8_t *data=lean_sarray_cptr(dense);
    uint64_t entries=0,bytes=0,work=0;uint8_t status=0;
#if defined(__SIZEOF_INT128__) && !defined(HEX_GROEBNER_NO_UINT128)
    uint64_t reciprocal;
    if(w<4) reciprocal=UINT64_C(4294967296)/p;
    else {reciprocal=UINT64_MAX/p;if(UINT64_MAX%p==p-1) ++reciprocal;}
#endif
    for(uint64_t tick=0;tick<quantum;++tick) {
        if(cursor>=stop) {status=1;break;}
        uint64_t a=rd(data+(size_t)cursor*w,w);
        if(a>=p) {status=6;break;}
        if(a) {
            size_t cn=lean_sarray_size(cols),vn=lean_sarray_size(coeff);
            if(cn && rd(lean_sarray_cptr(cols)+cn-4,4)>=cursor) {status=6;break;}
            if(entries>=entries_limit) {status=2;break;}++entries;
            if(bytes+4+w>bytes_limit) {status=3;break;}bytes+=4+w;
            if(cn>SIZE_MAX-4 || vn>SIZE_MAX-w) {status=5;break;}
            if(factor!=1) {if(work>=work_limit) {status=4;break;}++work;}
            uint64_t value=a;
            if(factor!=1) {
            value*=factor;
#if defined(__SIZEOF_INT128__) && !defined(HEX_GROEBNER_NO_UINT128)
            uint64_t q=w<4?(value*reciprocal)>>32:(uint64_t)(((__uint128_t)value*reciprocal)>>64);
            value-=q*p;if(value>=p) value-=p;
#else
            value%=p;
#endif
            }
            cols=append_scalar(cols,4,cursor);coeff=append_scalar(coeff,w,value);
            wr(data+(size_t)cursor*w,w,0);
        }
        ++cursor;
    }
    lean_object *state=lean_alloc_ctor(0,4,0);
    lean_ctor_set(state,0,dense);lean_ctor_set(state,1,cols);lean_ctor_set(state,2,coeff);
    lean_ctor_set(state,3,lean_uint64_to_nat(cursor));
    return gather_result(state,entries,bytes,work,status);
}
