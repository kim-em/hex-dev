import ScanTest
import GatherTest

def main : IO Unit := do
  if runtimeChecks && runtimeWideChecks && gatherRuntimeChecks && gatherMalformedChecks then IO.println "native scan and gather: widths, chunking, counters, aliases, malformed inputs match portable"
  else throw (IO.userError "native scan mismatch")
