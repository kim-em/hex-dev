from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();assert identity['source_fingerprint']=='a2a159e27d63'
frozen=json.loads((s/'wide-public-doc-production/manifest.json').read_text());old=json.loads((s/'wide-rebased-verified-production/manifest.json').read_text());assert frozen['binary_sha256']==old['binary_sha256']
payload={}
def add(n,p):
 assert n not in payload,n
 payload[n]=p.read_bytes()
for p in sorted((s/'wide-public-doc-production').rglob('*')):
 rel=p.relative_to(s/'wide-public-doc-production')
 if p.is_file()and'binaries'not in rel.parts:add('documentation/'+str(rel),p)
for name in ['wide-public-doc-build.log','wide-public-doc-freeze.log','pack-public-doc-audit.py']:add('collectors/'+name,s/name)
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();payload['checks.manifest']=tree_listing(CHECKS,identity['source_commit']).encode();payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode()
out=s/('f4-public-doc-audit-'+identity['source_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-public-doc-audit/'+n);entry.size=len(b);entry.mode=0o644;tar.addfile(entry,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
