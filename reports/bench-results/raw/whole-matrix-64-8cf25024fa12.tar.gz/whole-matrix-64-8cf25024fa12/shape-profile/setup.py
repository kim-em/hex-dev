from pathlib import Path
import json,subprocess,shutil
root=Path('/tmp/hex-groebner-whole-matrix-dev');out=Path('/tmp/hex-groebner-whole-matrix64-shape-profile');out.mkdir(exist_ok=False)
m=json.loads((root/'lake-manifest.json').read_text());m['name']='GroebnerShapeProfile';m['packagesDir']=str(root/'.lake/packages')
for p in m['packages']:p['inherited']=True
m['packages'].append(dict(type='path',name='Hex',dir=str(root),inherited=False,configFile='lakefile.lean',manifestFile='lake-manifest.json',scope=''))
(out/'lake-manifest.json').write_text(json.dumps(m,indent=2)+'\n');shutil.copy2(root/'lean-toolchain',out/'lean-toolchain')
(out/'Profile.lean').write_text('import HexGroebner.Driver.Run\ndef main (args : List String) : IO UInt32 := Hex.Groebner.Driver.run args\n')
(out/'probe.c').write_text('''#include <lean/lean.h>
#include <stdio.h>
#include <stdlib.h>
extern lean_obj_res __real_lean_hex_groebner_eliminate_matrix(uint64_t,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,uint8_t);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_eliminate_matrix(uint64_t p,b_lean_obj_arg limits,b_lean_obj_arg columns,b_lean_obj_arg reducers,b_lean_obj_arg targets,b_lean_obj_arg sugars,uint8_t independent) {
 size_t nr=lean_array_size(reducers),nt=lean_array_size(targets);uint64_t entries=0,cols=lean_is_scalar(columns)?lean_unbox(columns):UINT64_MAX;
 for(size_t i=0;i<nr+nt;++i) {lean_object *row=lean_array_cptr(i<nr?reducers:targets)[i<nr?i:i-nr];entries+=lean_sarray_size(lean_ctor_get(row,0))/4;}
 uint64_t width=p<=256?1:p<=65536?2:4;
 uint64_t bound=(nr+nt)*65+2*entries+cols*(width+4)+nt*(entries+(nt+3)*cols+64)+cols;
 lean_object *result=__real_lean_hex_groebner_eliminate_matrix(p,limits,columns,reducers,targets,sugars,independent);
 const char *path=getenv("HEX_GROEBNER_MATRIX_PROFILE");if(path) {FILE *file=fopen(path,"a");if(file) {
 fprintf(file,"{\\"columns\\":%llu,\\"reducers\\":%zu,\\"targets\\":%zu,\\"entries\\":%llu,\\"bound\\":%llu,\\"accepted\\":%s,\\"independent\\":%u}\\n",(unsigned long long)cols,nr,nt,(unsigned long long)entries,(unsigned long long)bound,lean_is_scalar(result)?"false":"true",independent);fclose(file);}}
 return result;
}
''')
(out/'lakefile.lean').write_text('''import Lake
open Lake DSL System
package GroebnerShapeProfile
require Hex from ROOT

target probeO pkg : FilePath := do
 let source ← inputTextFile (pkg.dir / "probe.c")
 buildO (pkg.dir / defaultBuildDir / "probe.o") source
   #["-isystem", (← getLeanIncludeDir).toString]
   #["-O3", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING"]
   (compiler := "cc") (extraDepTrace := getLeanTrace)
lean_exe profile where
 root := `Profile
 moreLinkObjs := #[probeO]
 moreLinkArgs := #["-Wl,--wrap=lean_hex_groebner_eliminate_matrix"]
'''.replace('ROOT',json.dumps(str(root))))
with (out/'build.log').open('w') as log:r=subprocess.run(['lake','build','profile'],cwd=out,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
print(out)
