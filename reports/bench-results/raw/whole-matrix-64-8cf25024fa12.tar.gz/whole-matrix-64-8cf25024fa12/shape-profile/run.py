from pathlib import Path
import os,json,subprocess,sys,hashlib
root=Path('/tmp/hex-groebner-whole-matrix-dev');sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
out=Path(__file__).resolve().parent;production=Path('/tmp/hex-groebner-whole-matrix64-production');binary=out/'.lake/build/bin/profile';cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
meta=dict(scope='Explanatory native whole-matrix shape/eligibility profile of source8cf25024fa12. Instrumented full-init driver calls the same Driver.run; complete bases and counters except candidate timing must match frozen production results. All wrapper calls are retained. No timing estimates are collected from these instrumented runs. Temporary-project --ld-path selects a working linker after two retained failed build attempts due to an obsolete SDK wrapper; production source/toolchain wrappers are unchanged.',cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),runs=[])
try:
 for case in ['cyclic7-31','eco11-31','reimer6-31','minrank_d_2_p_2_q_4_r_2-31']:
  inputfile=Path('/tmp/hex-groebner-medium-suite')/(case+'.json');calls=out/(case+'.calls.jsonl');assert not calls.exists()
  command=[str(binary),'--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000',str(inputfile)]
  with (out/(case+'.stdout')).open('w') as stdout,(out/(case+'.stderr')).open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,HEX_GROEBNER_MATRIX_PROFILE=str(calls),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  assert r.returncode==0
  actual=json.loads((out/(case+'.stdout')).read_text());previous=json.loads((production/'before-after-medium'/(case+'-b0-B.stdout')).read_text());assert actual['basis']==previous['basis']
  assert {k:v for k,v in actual['statistics'].items() if k!='candidate_nanos'}=={k:v for k,v in previous['statistics'].items() if k!='candidate_nanos'}
  records=[json.loads(line) for line in calls.read_text().splitlines()];assert records
  summary=dict(case=case,command=command,returncode=r.returncode,calls=len(records),accepted=sum(x['accepted'] for x in records),over_columns=sum(x['columns']>4096 for x in records),over_reducers=sum(x['reducers']>1024 for x in records),over_targets=sum(x['targets']>64 for x in records),over_bound=sum(x['bound']>2**20 for x in records),maximum_columns=max(x['columns'] for x in records),maximum_targets=max(x['targets'] for x in records),maximum_bound=max(x['bound'] for x in records))
  meta['runs'].append(summary);print(summary,flush=True)
finally:
 meta['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
