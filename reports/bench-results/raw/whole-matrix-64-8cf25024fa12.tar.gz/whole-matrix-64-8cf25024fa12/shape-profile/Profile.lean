import HexGroebner.Driver.Run
def main (args : List String) : IO UInt32 := Hex.Groebner.Driver.run args
