import Lake
open Lake DSL System
package GroebnerShapeProfile
require Hex from "/tmp/hex-groebner-whole-matrix-dev"

target probeO pkg : FilePath := do
 let source ← inputTextFile (pkg.dir / "probe.c")
 buildO (pkg.dir / defaultBuildDir / "probe.o") source
   #["-isystem", (← getLeanIncludeDir).toString]
   #["-O3", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING"]
   (compiler := "cc") (extraDepTrace := getLeanTrace)
lean_exe profile where
 root := `Profile
 moreLinkObjs := #[probeO]
 moreLinkArgs := #["--ld-path=/run/current-system/sw/bin/ld.lld", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix"]
