from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/tmp/hex-groebner-whole-matrix-dev');sys.path.insert(0,str(root))
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import fingerprint,index_listing
base=Path(__file__).resolve().parent;manifest=json.loads((base/'manifest.json').read_text());listing=index_listing(FAMILY);assert listing==manifest['source_manifest'];fp=fingerprint(listing)
suffix='-repeat' if '--repeat' in sys.argv else '';out=base/('whole-matrix64-bench-'+fp+suffix);out.mkdir(exist_ok=False)
binaries={arm:base/'bench-binaries'/arm for arm in ['A','B']};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
meta=dict(source_fingerprint=fp,source_manifest=listing,baseline_manifest=json.loads((base/'bench-binaries/A-manifest.json').read_text()),binary_sha256={a:sha(p) for a,p in binaries.items()},cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),schedule='Per case adjacent AB then BA; fixed five declared lean-bench repetitions, all points retained. Both arms use identical GNU time child-RSS wrappers.',contract='A current packed-targets source9bac12f60779; its minimal/full compute hashes equal measured8d139a1e1c57. B bounded untraced whole matrix source'+fp+',64-bit ABI, at most4096columns/1024reducers/64targets/2^20work, known distinct reducer pivots. Exact reference rows/counters and portable continuation for unsupported shapes; candidate F4 plus interreduction, excludes certificate production, final certification and kernel replay. Kernel point times are analyzed separately from wrapper/process observations.',toolchain=(root/'lean-toolchain').read_text().strip(),script=Path(__file__).read_text(),runs=[])
try:
 for block,order in enumerate(['AB','BA']):
  for case in ['cyclic4','cyclic5','cyclic6','katsura3','reimer5','cyclic6Small']:
   for arm in order:
    prefix=f'{case}-b{block}-{arm}';rss=out/(prefix+'.rss');command=['/run/current-system/sw/bin/time','-f','%M','-o',str(rss),str(binaries[arm]),'run','Hex.Groebner.Bench.'+case,'--export-file',str(out/(prefix+'.json'))]
    print(prefix,flush=True);start=time.monotonic_ns()
    with (out/(prefix+'.log')).open('w') as stream:r=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=env)
    meta['runs'].append(dict(case=case,block=block,arm=arm,command=command,returncode=r.returncode,wall_nanos=time.monotonic_ns()-start,peak_rss_kib=int(rss.read_text().splitlines()[-1])))
    if r.returncode:raise SystemExit(r.returncode)
finally:
 meta['load_end']=os.getloadavg();meta['source_unchanged']=index_listing(FAMILY)==listing;meta['binary_sha256_after']={a:sha(p) for a,p in binaries.items()};(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
assert meta['source_unchanged'] and meta['binary_sha256_after']==meta['binary_sha256']
subprocess.run(['python3',str(base/'analyze-fixed.py')],check=True)
