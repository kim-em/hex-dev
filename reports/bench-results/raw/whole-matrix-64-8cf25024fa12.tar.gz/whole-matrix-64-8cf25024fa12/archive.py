from pathlib import Path
import json,subprocess,hashlib,tarfile,shutil
repo=Path('/tmp/hex-groebner-whole-matrix-dev');catalog=[]
variants=[('capped','/tmp/hex-groebner-whole-matrix-production','/tmp/hex-groebner-packed-targets-layout-production','8-target bounded native matrix prototype. Full2175-job validation, independent oracles, both CLI checks,8sanitizer variants,32bench checks and project audits pass after monomial guard port. Small/medium first and sole unchanged repeat produce120complete basis/counter pairs; no fixed sweep or external comparators. No accepted large-Nat limits, exact quantum-border or exclusive shared-array tests are claimed. Native implementation is not selected in this snapshot; the later64-target implementation is separate.', ['issue-10987-whole-matrix-guarded-*.log','issue-10987-whole-matrix-clang-sanitizers*.log','issue-10987-whole-matrix-gcc-sanitizers.log','issue-10987-whole-matrix-boundaries-*.log','issue-10987-whole-matrix-guard-port-build.log','issue-10987-whole-matrix-measure*.log']),('64','/tmp/hex-groebner-whole-matrix64-production','/tmp/hex-groebner-packed-targets-layout-production','64-target bounded native matrix prototype before ABI documentation and additional limit/alias tests. Full2175-job validation, independent oracles, both CLI checks,8sanitizer variants,32bench checks and project audits pass. Small/medium first and sole unchanged repeats produce120complete basis/counter pairs, fixed sweep120points with all complete structural hashes equal, and separate matched current-msolve l2/l42 sweeps each56processes and28complete basis pairs. All observations/outliers/failures retained; no timing filter. One medium-repeat setup mistakenly names the baseline manifest as its binary; SHA validation rejects it before any measured process. Empty setup and error are retained; corrected command supplies its sole measured repeat. The explanatory80-call/4input shape profile is separate from timings; bases/counters agree,37native matrices accepted. An obsolete localSDK linker wrapper caused retained profile build failures; only that temporary project uses workingLLVM23.1.3 linker via--ld-path. Production measured builds used the originalSDK23.1.0 linker arrangement. No verified performance leadership, held-out acceptance, certificate timing or compiler-impossibility claim.', ['issue-10987-whole-matrix64-build.log','issue-10987-whole-matrix64-check.log','issue-10987-whole-matrix64-full*.log','issue-10987-whole-matrix64-*sanitizers.log','issue-10987-whole-matrix64-measure*.log','issue-10987-whole-matrix64-fixed.log','issue-10987-whole-matrix64-msolve*.log'])]
for label,base,baseline,scope,patterns in variants:
 base=Path(base);m=json.loads((base/'manifest.json').read_text());bm=json.loads((Path(baseline)/'manifest.json').read_text());name='whole-matrix-'+label+'-'+m['source_fingerprint'];stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
 for p in base.iterdir():
  if p.name=='binaries':continue
  if p.name=='bench-binaries':
   dest=stage/p.name;dest.mkdir()
   for q in p.iterdir():
    if q.is_file() and q.name not in ['A','B']:shutil.copy2(q,dest/q.name)
  elif p.is_dir():shutil.copytree(p,stage/p.name)
  else:shutil.copy2(p,stage/p.name)
 (stage/'baseline-manifest.json').write_text(json.dumps(bm,indent=2)+'\n')
 for folder,manifest in [('root-sources',m),('baseline-sources',bm)]:
  (stage/(folder+'.manifest')).write_text(manifest['source_manifest'])
  for line in manifest['source_manifest'].splitlines():
   h,n=line.split('\t',1);oid=h.split()[1];data=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;p=stage/folder/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 # Preserve the historical validation sources, not today's expanded tests.
 files=subprocess.check_output(['git','ls-tree','-r','--name-only',m['source_snapshot'],'--','conformance/HexGroebner','conformance-fixtures/HexGroebner','scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh','scripts/ci/check_groebner_driver.py','scripts/libgraph.py'],cwd=repo,text=True).splitlines()
 for n in files:
  data=subprocess.check_output(['git','show',m['source_snapshot']+':'+n],cwd=repo);p=stage/'validation-snapshot'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 for pattern in patterns:
  for p in Path('/tmp').glob(pattern):shutil.copy2(p,stage/p.name)
 if label=='64':
  source=Path('/tmp/hex-groebner-whole-matrix64-shape-profile');dest=stage/'shape-profile';dest.mkdir()
  for p in source.iterdir():
   if p.is_file():shutil.copy2(p,dest/p.name)
  shutil.copy2('/tmp/profile-groebner-whole-shapes.py',dest/'setup.py')
  shutil.copy2('/tmp/measure-groebner-whole64.py',stage/'measure-cli.py')
 # Reuse the previously committed public-input provenance and license.
 licensed=repo/'reports/bench-results/raw/target-columns-input-provenance-licensed.tar.gz'
 if licensed.exists():
  with tarfile.open(licensed,'r:gz') as tar:
   for member in tar.getmembers():
    if member.isfile() and Path(member.name).name=='LICENSE.md':
     p=stage/'public-input-LICENSE.md';p.write_bytes(tar.extractfile(member).read());break
 (stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=m['source_fingerprint'],scope=scope),indent=2)+'\n');shutil.copy2(__file__,stage/'archive.py');target=repo/'reports/bench-results/raw'/(name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as tar:tar.add(stage,arcname=name)
 catalog.append(dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source_fingerprint=m['source_fingerprint']));print(catalog[-1],flush=True)
Path('/tmp/issue-10987-whole-matrix-history-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
