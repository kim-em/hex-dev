import Lake
import Lean.Compiler.FFI
open Lake DSL
package GroebnerLinkerCheck
lean_exe check where
 root := `Main

#eval IO.println ("INTERNAL_C=" ++ (Lean.toJson (Lean.Compiler.FFI.getInternalCFlags "/home/kim/.elan/toolchains/leanprover--lean4---v4.35.0-rc3")).compress)
#eval IO.println ("INTERNAL_LINK=" ++ (Lean.toJson (Lean.Compiler.FFI.getInternalLinkerFlags "/home/kim/.elan/toolchains/leanprover--lean4---v4.35.0-rc3")).compress)
