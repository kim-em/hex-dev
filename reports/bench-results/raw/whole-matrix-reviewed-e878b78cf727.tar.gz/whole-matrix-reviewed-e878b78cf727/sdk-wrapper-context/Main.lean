def main : IO Unit := IO.println "local SDK linker override passed"
