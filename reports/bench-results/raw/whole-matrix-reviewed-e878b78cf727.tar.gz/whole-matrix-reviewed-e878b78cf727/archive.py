from pathlib import Path
import json,subprocess,hashlib,tarfile,shutil
repo=Path('/tmp/hex-groebner-whole-matrix-dev');base=Path('/tmp/hex-groebner-whole-matrix-reviewed-production');m=json.loads((base/'manifest.json').read_text());bm=json.loads(Path('/tmp/hex-groebner-packed-targets-sdk-check-production/manifest.json').read_text());checks=json.loads(Path('/tmp/issue-10987-whole-matrix-reviewed-full-status.json').read_text());assert len(checks)==9 and all(c['exit_code']==0 for c in checks)
name='whole-matrix-reviewed-'+m['source_fingerprint'];stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
for p in base.iterdir():
 if p.name=='binaries':continue
 if p.name=='bench-binaries':
  dest=stage/p.name;dest.mkdir()
  for q in p.iterdir():
   if q.is_file() and q.name not in ['A','B']:shutil.copy2(q,dest/q.name)
 elif p.is_dir():shutil.copytree(p,stage/p.name)
 else:shutil.copy2(p,stage/p.name)
(stage/'baseline-manifest.json').write_text(json.dumps(bm,indent=2)+'\n')
for folder,manifest in [('root-sources',m),('baseline-sources',bm)]:
 (stage/(folder+'.manifest')).write_text(manifest['source_manifest'])
 for line in manifest['source_manifest'].splitlines():
  h,n=line.split('\t',1);oid=h.split()[1];data=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;p=stage/folder/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(repo/folder,stage/'validation-sources'/folder)
for n in ['scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh','scripts/ci/check_groebner_driver.py','scripts/libgraph.py']:
 p=stage/'validation-sources'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,p)
for p in Path('/tmp').glob('issue-10987-whole-matrix-reviewed-*.log'):shutil.copy2(p,stage/p.name)
for n in ['issue-10987-whole-matrix-reviewed-full-status.json','issue-10987-lean-cc','issue-10987-lean-cc-flags.json','run-issue-10987-full-checks.py','measure-groebner-whole-reviewed.py']:
 shutil.copy2(Path('/tmp')/n,stage/n)
context=stage/'sdk-wrapper-context';context.mkdir()
for p in Path('/tmp').glob('issue-10987-local-linker*.log'):shutil.copy2(p,context/p.name)
for n in ['Main.lean','lakefile.lean','lake-manifest.json','lean-toolchain']:shutil.copy2(Path('/tmp/hex-groebner-linker-check')/n,context/n)
shutil.copy2('/tmp/issue-10987-packed-targets-sdk-check-freeze.log',context/'baseline-freeze.log')
licensed=repo/'reports/bench-results/raw/target-columns-input-provenance-licensed.tar.gz'
if licensed.exists():
 with tarfile.open(licensed,'r:gz') as tar:
  for member in tar.getmembers():
   if member.isfile() and Path(member.name).name=='LICENSE.md':(stage/'public-input-LICENSE.md').write_bytes(tar.extractfile(member).read());break
scope='Reviewed bounded native whole-matrix implementation, prime fields2<=p<2^31,64-bit ABI,4096columns/1024knownreducers/64targets and2^20work quantum. Exact successful reference rows/sugars/counters, borrowed inputs and portable continuation outside C. Limits above scalar Nat range saturate above all accepted totals; large sugars decline. ABI/layout/range/ownership/fallback and conservative work derivation documented. Native speculative failure is bounded, reference-terminal in F4 and happens at most once per computation/resumption. Expanded tests cover every work/packedBytes/outputEntries boundary,exact2^20 and2^20+1bounds,2^63-1/2^63 limits/sugars, shared reducer/target arrays and both independent/joint modes.2175-job full build,175matrix/567uniqueSymPy-Singularbasis/1288division oracles,1134schedulingprofiles per CLI,32bench checks and all audits pass. Four Clang/four GCC ASan/UBSan variants pass, each with3602accepted/274deferred F4whole-matrix attempts and115exclusive monomial reuses/24workspace-aliased inserts. An initial compiled coverage check failed because the small F4 cases all accepted; the final seed-dependent work-budget sweep exercises both outcomes. Failed build/test logs are retained. These final validation sources are under validation-sources; production source_manifest excludes conformance files. Small/medium retainfirst and sole unchanged repeats:240processes/120complete basis and counter pairs,0failures/timeouts. Fixed240points retain first and sole unchanged repeat; all full structural hashes agree, including regressions and extreme outliers. No further unchanged repeat, no host-activity filter, no uniform speedup claim. Separate msolve l2/l42 first sweeps each56processes/28complete basis pairs, allagree. Candidate production/interreduction and process times are separate; certificate generation, independent final certification and kernel replay are excluded. Development corpus, not held-out SPEC acceptance. An obsolete SDK linker wrapper caused retained local build failures. A task-local LEAN_CC wrapper restores SDK compile/link flags and directly invokes existing SDK Clang23.1.0/LLD23.1.0. This changes baseline9bac binary hashes; baseline and candidate are both freshly rebuilt through the same wrapper. Fixed benchmark executables use fresh detached snapshots, sharing only pinned dependency packages. Wrapper, exact flags, manifests and logs retained. Older607b/8cf and their original linker arrangement remain separate, never pooled. No fastest-open-source or compiler/runtime impossibility claim.'
(stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=m['source_fingerprint'],baseline_source_fingerprint=bm['source_fingerprint'],scope=scope),indent=2)+'\n');shutil.copy2(__file__,stage/'archive.py');target=repo/'reports/bench-results/raw'/(name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as tar:tar.add(stage,arcname=name)
a=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source_fingerprint=m['source_fingerprint']);Path('/tmp/issue-10987-whole-matrix-reviewed-catalog.json').write_text(json.dumps(a,indent=2)+'\n');print(a)
