from pathlib import Path
import gzip,hashlib,io,json,subprocess,sys,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-equivalence');base_commit='1420b84ce3aa2e48781f11244dc51a5b504c090b'
mode=sys.argv[1];final=state/'equivalence-shaped-production'
if mode=='early':
 bases=[state/'equivalence-production'];name='f4-continuation-9ddab5fe4bf1';extras=['equivalence-measurements.py','equivalence-measurements-status.json','analyze-equivalence-candidates.py']
else:
 fp=json.loads((final/'manifest.json').read_text())['source_fingerprint'];bases=[state/'equivalence-reviewed-production',final];name='f4-continuation-dispatch-'+fp
 extras=['equivalence-reviewed-measurements.py','equivalence-reviewed-measurements-status.json','equivalence-shaped-measurements.py','equivalence-shaped-measurements-status.json','build-equivalence-reviewed-bench.py','build-equivalence-shaped-bench.py','measure-equivalence-wide.py','measure-equivalence-wide-selected.py','profile-equivalence-selected.py','analyze-equivalence-candidates.py','equivalence-reviewed-full-status.json','equivalence-shaped-full-status.json','equivalence-review-native-status.json','equivalence-shaped-native-status.json','full-checks.py','equivalence-shaped-native-checks.py','equivalence-reviewed-dag-tests.log']
payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
for base in bases:
 for path in sorted(base.rglob('*')):
  relative=path.relative_to(base);parts=relative.parts
  if parts[0]=='binaries' or parts[:2]==('bench-binaries','source') or parts==('bench-binaries','frame'):continue
  if path.is_file():add(base.name+'/'+str(relative),path.read_bytes())
 manifest=json.loads((base/'manifest.json').read_text())
 patch=subprocess.check_output(['git','diff','--binary',base_commit,manifest['source_snapshot'],'--','.',':!reports'],cwd=root)
 add(base.name+'/source.patch',patch)
 add(base.name+'/source-base.json',(json.dumps(dict(base_commit=base_commit,source_snapshot=manifest['source_snapshot'],source_tree=manifest['source_tree'],source_fingerprint=manifest['source_fingerprint'],reproduction='Apply source.patch to base_commit; reports are excluded. Complete measured FAMILY source blobs are also retained under root-sources.'),indent=2)+'\n').encode())
for relative in extras+['build-current-msolve.sh','msolve-current-provenance.json','msolve-current-help.txt','msolve-current-autoreconf.log','msolve-current-libtoolize.log','msolve-current-configure.log','msolve-current-build.log','msolve-config-failed-gmp.log','issue-10987-lean-cc','issue-10987-lean-cc-flags.json']:
 p=state/relative
 if p.is_file():add('reproduction/'+relative,p.read_bytes())
if mode!='early':
 for pattern in ['equivalence-reviewed-full-*.log','equivalence-shaped-full-*.log','equivalence-review-clang.log','equivalence-review-gcc.log','equivalence-shaped-clang.log','equivalence-shaped-gcc.log']:
  for p in sorted(state.glob(pattern)):add('verification/'+p.name,p.read_bytes())
 for directory in ['equivalence-review-clang','equivalence-review-gcc','equivalence-shaped-clang','equivalence-shaped-gcc']:
  for p in sorted((state/directory).rglob('*')):
   if p.is_file():add('verification/'+directory+'/'+str(p.relative_to(state/directory)),p.read_bytes())
source=state/'msolve-current'
for relative in ['config.log','config.status','config.h','Makefile','src/neogb/Makefile','libtool']:
 add('msolve-generated/'+relative,(source/relative).read_bytes())
add('msolve-source.tar',subprocess.check_output(['git','archive','HEAD'],cwd=source))
add('archive.py',Path(__file__).read_bytes())
digests={key:hashlib.sha256(data).hexdigest()for key,data in payload.items()};add('sha256.json',(json.dumps(digests,indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size)
(state/(name+'-audit.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
