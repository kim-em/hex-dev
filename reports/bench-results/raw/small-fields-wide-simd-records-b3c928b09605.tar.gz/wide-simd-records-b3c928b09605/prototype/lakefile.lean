import Lake
open Lake DSL System
package GroebnerWideDev
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
target wideO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "wide_scan.c")
  let body ← inputTextFile (pkg.dir / "wide_scan_impl.h")
  let simd ← inputTextFile (pkg.dir / "wide_simd.h")
  let common ← inputTextFile (pkg.dir / "matrix_simd.h")
  buildO (pkg.dir / defaultBuildDir / "wide.o") (((source.zipWith (fun s _ => s) body).zipWith (fun s _ => s) simd).zipWith (fun s _ => s) common)
    #["-I", (← getLeanIncludeDir).toString]
    #["-O3", "-Wall", "-Wextra", "-fPIC"]
lean_lib WideNative where
  roots := #[`WideNative]
  globs := #[.one `WideNative,.one `WideNativeScan,.one `WideNativeGather]
  moreLinkObjs := #[wideO]
  precompileModules := true
lean_lib WideDev where
  roots := #[`WideElimination,`WideSymbolic,`WideF4]
lean_exe wide_compare where
  root := `Main
lean_exe wide_checks where
  root := `WideTest
