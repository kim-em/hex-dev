#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
static uint64_t matrix_read(const uint8_t *p,unsigned w) {
 uint64_t x=p[0];if(w>1)x|=(uint64_t)p[1]<<8;
 if(w>2)x|=(uint64_t)p[2]<<16|(uint64_t)p[3]<<24;
 return x;
}
static inline uint32_t sparse_column(const uint8_t *p) {
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    uint32_t value;memcpy(&value,p,sizeof(value));return value;
#else
    return (uint32_t)matrix_read(p,4);
#endif
}

int main(void) {
 uint32_t state=1;uint8_t bytes[16];uint64_t checks=0;
 for(unsigned trial=0;trial<4096;++trial) {
  state=UINT32_C(1664525)*state+UINT32_C(1013904223);
  uint32_t values[]={0,1,255,256,65535,65536,1048575,UINT32_C(2147483648),UINT32_MAX,state};
  for(unsigned v=0;v<sizeof(values)/sizeof(values[0]);++v)for(unsigned offset=0;offset<8;++offset) {
   memset(bytes,0xa5,sizeof(bytes));uint32_t expected=values[v];
   for(unsigned j=0;j<4;++j)bytes[offset+j]=(uint8_t)(expected>>(j*8));
   assert(matrix_read(bytes+offset,4)==expected);
   assert(sparse_column(bytes+offset)==expected);++checks;
  }
 }
 printf("PASS %llu aligned/unaligned little-endian index boundaries\n",(unsigned long long)checks);return 0;
}
