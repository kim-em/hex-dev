from pathlib import Path
import subprocess,os,json,hashlib
s=Path('/home/kim/tmp/issue-10987');rows=[]
for name,cc in [('clang','/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang'),('gcc','/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/gcc')]:
 for mode in ['native','portable']:
  binary=s/f'sparse-index-endian-clean-{name}-{mode}';command=[cc,'-O3','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-sanitize-recover=undefined',*(['-U__BYTE_ORDER__']if mode=='portable'else[]),str(s/'sparse-index-endian-selftest.c'),'-o',str(binary)]
  build=subprocess.run(command,capture_output=True,text=True);row=dict(compiler=cc,mode=mode,command=command,build_exit=build.returncode,build_stdout=build.stdout,build_stderr=build.stderr,selftest_sha256=hashlib.file_digest((s/'sparse-index-endian-selftest.c').open('rb'),'sha256').hexdigest());rows.append(row)
  if not build.returncode:
   run=subprocess.run([str(binary)],capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'));row.update(exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr,binary_sha256=hashlib.file_digest(binary.open('rb'),'sha256').hexdigest())
  (s/'sparse-index-endian-clean-status.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,mode,row.get('exit_code',row['build_exit']),row.get('stdout',''),flush=True)
  if build.returncode or row.get('exit_code'):raise SystemExit(1)
