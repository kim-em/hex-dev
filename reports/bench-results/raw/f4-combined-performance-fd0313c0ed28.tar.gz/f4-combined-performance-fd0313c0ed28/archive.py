from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');base=state/'combined-performance-production';name='f4-combined-performance-fd0313c0ed28';payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
checks=json.loads((state/'combined-performance-full-status.json').read_text());assert len(checks)==9 and all(x['exit_code']==0 for x in checks)
for p in sorted(base.rglob('*')):
 if p.is_file()and p.relative_to(base).parts[0]!='binaries':add('measurement/'+str(p.relative_to(base)),p.read_bytes())
for pattern in ['combined-performance*.py','combined-performance*.json','combined-performance*.log','combined-gamba*.py','combined-gamba*.json','combined-gamba*.log','combined-selected*.py','combined-selected*.json','combined-selected*.log']:
 for p in sorted(state.glob(pattern)):
  if p.is_file():add('reproduction/'+p.name,p.read_bytes())
for directory in ['combined-performance-clang','combined-performance-gcc']:
 for p in sorted((state/directory).rglob('*')):
  if p.is_file()and'.lake'not in p.relative_to(state/directory).parts:add('validation/'+directory+'/'+str(p.relative_to(state/directory)),p.read_bytes())
for relative in ['issue-10987-lean-cc','issue-10987-lean-cc-flags.json','full-checks.py','analyze-equivalence-candidates.py','msolve-current-provenance.json','build-current-msolve.sh','gamba-binaries.json','gamba-current-release.json','gamba-avx2-help.txt','gamba-avx512-help.txt']:
 add('reproduction/'+relative,(state/relative).read_bytes())
m=json.loads((base/'manifest.json').read_text());base_commit='7832dd536a7035b6f3cbcc8c0657d6597eebdaca';add('source.patch',subprocess.check_output(['git','diff','--binary',base_commit,m['source_snapshot'],'--','.',':!reports'],cwd=root));add('source-base.txt',(base_commit+'\n').encode())
import sys
sys.path.insert(0,str(root));from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing,fingerprint
current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();listing=tree_listing(FAMILY,current);assert listing==m['source_manifest'];add('source-audit.json',(json.dumps(dict(commit=current,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),frozen_source_snapshot=m['source_snapshot'],frozen_source_tree=m['source_tree'],source_fingerprint=fingerprint(listing),manifest_match=True,rebase='Combined tree is unchanged after rebasing onto merged PR11018. Complete model/kernel/conformance tests precede that tree-preserving rebase.'),indent=2)+'\n').encode())
add('archive.py',Path(__file__).read_bytes());add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest()for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
assert out.stat().st_size<100*1024**2,'split the completed capsule before pushing; retain this payload'
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/(name+'-audit.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
