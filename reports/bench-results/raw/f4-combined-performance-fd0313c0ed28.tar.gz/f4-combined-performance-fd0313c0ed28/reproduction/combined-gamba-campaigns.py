from pathlib import Path
import json,subprocess,time
state=Path('/home/kim/tmp/issue-10987');base=state/'combined-performance-production'
while not(base/'manifest.json').is_file():time.sleep(5)
runs=[]
for isa in ['avx512','avx2']:
 with(state/('combined-gamba-'+isa+'.log')).open('w')as log:p=subprocess.run([str(state/'oracles/bin/python'),str(state/'combined-gamba-measure.py'),isa],stdout=log,stderr=subprocess.STDOUT)
 runs.append(dict(isa=isa,exit_code=p.returncode));(state/'combined-gamba-status.json').write_text(json.dumps(runs,indent=2)+'\n');print(isa,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
