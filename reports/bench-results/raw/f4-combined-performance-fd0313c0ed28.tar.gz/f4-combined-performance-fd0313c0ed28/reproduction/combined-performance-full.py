from pathlib import Path
import json,os,subprocess,time
state=Path('/home/kim/tmp/issue-10987')
while True:
 p=state/'combined-performance-native-status.json'
 if p.exists():
  results=json.loads(p.read_text())
  if any(x['exit_code'] for x in results):raise SystemExit('native failure')
  if len(results)==2:break
 time.sleep(5)
env=dict(os.environ,LEAN_CC=str(state/'issue-10987-lean-cc'),TMPDIR=str(state))
raise SystemExit(subprocess.call(['python3',str(state/'full-checks.py'),str(state/'combined-performance-full')],env=env))
