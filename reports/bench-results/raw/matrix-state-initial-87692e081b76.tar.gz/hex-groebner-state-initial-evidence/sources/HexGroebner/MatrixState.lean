/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

public import HexGroebner.Matrix
public import HexGroebner.NativeScan
public import HexGroebner.NativeGather

public section

namespace Hex.Groebner.MatrixState

inductive Phase where
  | check | validate | workspace | input | scan | gather | order | done
  deriving BEq, Inhabited

/-- Private matrix continuation. The input identity travels with its workspace;
no continuation can be resumed against a different field, matrix or allowance.
Only untraced elimination is modeled here.

The 64-bit ABI has 19 object fields in declaration order after scalar fields
are removed: limits, columns, reducers, targets, sugars, validation, input,
dense, slots, pivots, nativePivots, remainders, rank, scan, gather, leading,
sugar, stats and result. Scalar storage is modulus/inverse (two UInt64), then
independent/phase (two UInt8). Native continuation owns the state and may copy
shared buffers; input matrices and saved snapshots remain immutable. -/
structure State where
  private mk ::
  field : PrimeField
  limits : MatrixLimits
  columns : Nat
  reducers : Array SparseRow
  targets : Array SparseRow
  sugars : Array Nat
  independent : Bool
  phase : Phase := .check
  validation : Nat := 0
  input : Nat := 0
  dense : ByteArray := {}
  slots : ByteArray := {}
  pivots : Array Pivot := #[]
  nativePivots : Array Native.Scan.Pivot := #[]
  remainders : Array RemainderRow := #[]
  rank : Nat := 0
  scan : Native.Scan.State := { dense := {},column := 0,last := 0,chargedUntil := 0 }
  gather : Native.Gather.State := ⟨{},{},{},0⟩
  leading : Nat := 0
  sugar : Nat := 0
  inverse : UInt64 := 1
  stats : MatrixStats := {}
  result : Option (Except MatrixError (Echelon × Array RemainderRow)) := none

def start (field : PrimeField) (limits : MatrixLimits) (columns : Nat)
    (reducers targets : Array SparseRow) (sugars : Array Nat) (independent : Bool) : State :=
  { field,limits,columns,reducers,targets,sugars,independent }

private abbrev Work := ExceptT MatrixError (StateM State)

private def liftWork (action : Matrix.Work α) : Work α := ExceptT.mk fun s =>
  let (result,stats) := action.run s.stats
  (result,{ s with stats })

private def work (n : Nat) : Work Unit := do
  liftWork (Matrix.work (← get).limits n)

private def completeRow : Work Unit :=
  modify fun s => { s with
    input := s.input+1
    phase := .input
    stats.processedRows := s.stats.processedRows+1 }

private def isTarget (s : State) : Bool := s.input >= s.reducers.size

private def install (row : SparseRow) (column : Nat) (inverse : UInt64) (sugar : Nat) : Work Unit := do
  let s ← get
  if s.independent && isTarget s then
    set { s with remainders := s.remainders.push ⟨row,none,sugar⟩ }
  else
    set { s with
      slots := Packed.set .u32 s.slots column (s.pivots.size+1).toUInt64
      pivots := s.pivots.push ⟨row,isTarget s,none,inverse,sugar⟩
      nativePivots := s.nativePivots.push ⟨row.columns,row.coefficients,sugar⟩
      rank := s.rank + if isTarget s then 0 else 1 }
  completeRow

private def zeroRow : Work Unit := do
  modify fun s => { s with
    remainders := if s.independent && isTarget s then
      s.remainders.push ⟨{},none,s.sugar⟩ else s.remainders
    stats.zeroRows := s.stats.zeroRows+1 }
  completeRow

private def step (native : Bool) : Work Unit := do
  let s ← get
  match s.phase with
  | .check =>
    if s.columns > 4294967295 || s.reducers.size+s.targets.size > 4294967295 then
      throw .dimensions
    if s.columns > s.limits.columns then throw (.exhausted .columns)
    if s.reducers.size+s.targets.size > s.limits.rows then throw (.exhausted .rows)
    if !s.sugars.isEmpty && s.sugars.size != s.reducers.size+s.targets.size then throw .dimensions
    set { s with phase := .validate }
  | .validate =>
    if s.validation >= s.reducers.size+s.targets.size then
      set { s with phase := .workspace }
    else
      let row := if s.validation < s.reducers.size then s.reducers[s.validation]!
        else s.targets[s.validation-s.reducers.size]!
      liftWork (Matrix.validate s.field s.limits s.columns s.validation row)
      modify fun s => { s with validation := s.validation+1 }
  | .workspace =>
    let bytes := s.columns*(s.field.width.bytes+4)
    if bytes >= USize.size then throw .dimensions
    liftWork (Matrix.packedBytes s.limits bytes)
    work bytes
    modify fun s => { s with
      dense := Matrix.zeros (s.columns*s.field.width.bytes)
      slots := Matrix.zeros (s.columns*4), phase := .input }
  | .input =>
    if s.input >= s.reducers.size+s.targets.size then
      set { s with phase := .order }
    else
      work 1
      let row := if isTarget s then s.targets[s.input-s.reducers.size]! else s.reducers[s.input]!
      let sugar := s.sugars[s.input]?.getD 0
      modify fun s => { s with sugar }
      if row.size == 0 then zeroRow else
        let first := (Packed.read .u32 row.columns 0).toNat
        if !isTarget s && Packed.read .u32 s.slots first == 0 then
          let inverse ← liftWork (Matrix.inverse s.field s.field.barrett s.limits
            (Packed.read s.field.width row.coefficients 0))
          let output ← liftWork (Matrix.scaleSparse s.field s.field.barrett s.limits row inverse)
          install output first inverse sugar
        else
          work row.size
          let mut dense := s.dense
          for i in [:row.size] do
            dense := Packed.set s.field.width dense (Packed.read .u32 row.columns i).toNat
              (Packed.read s.field.width row.coefficients i)
          modify fun s => { s with
            dense := {}
            phase := .scan
            scan := {
              dense := dense
              column := first
              last := (Packed.read .u32 row.columns (row.size-1)).toNat
              chargedUntil := first
              sugar := sugar } }
  | .scan =>
    let output := if native then
      Native.Scan.transition s.field.modulus s.slots s.nativePivots s.scan 4096
        (s.limits.work-s.stats.work) 0 false
      else Native.Scan.portable s.field.modulus s.slots s.nativePivots s.scan 4096
        (s.limits.work-s.stats.work) 0 false
    work output.work
    modify fun s => { s with
      scan := output.state
      stats.reductions := s.stats.reductions+output.reductions }
    if output.status == 2 then throw (.exhausted .work)
    if output.status != 0 && output.status != 1 then throw .rowUpdate
    if output.status == 1 then
      let state := output.state
      modify fun s => { s with sugar := state.sugar }
      if state.leading == 0 then
        modify fun s => { s with dense := state.dense,scan := { s.scan with dense := {} } }
        zeroRow
      else
        let column := state.leading-1
        let inverse ← if s.independent && isTarget s then pure 1 else
          liftWork (Matrix.inverse s.field s.field.barrett s.limits
            (Packed.read s.field.width state.dense column))
        work (state.last+1-column)
        modify fun s => { s with
          phase := .gather
          leading := column
          inverse := inverse
          scan := { s.scan with dense := {} }
          gather := ⟨state.dense,{},{},column⟩ }
  | .gather =>
    let output := if native then
      Native.Gather.gather s.field.modulus s.gather (s.scan.last+1) 4096
        (s.limits.outputEntries-s.stats.outputEntries) (s.limits.packedBytes-s.stats.packedBytes)
        (s.limits.work-s.stats.work) s.inverse
      else Native.Gather.portable s.field.modulus s.gather (s.scan.last+1) 4096
        (s.limits.outputEntries-s.stats.outputEntries) (s.limits.packedBytes-s.stats.packedBytes)
        (s.limits.work-s.stats.work) s.inverse
    liftWork (Matrix.charge .outputEntries output.entries s.limits.outputEntries
      (·.outputEntries) fun stats n => { stats with outputEntries := n })
    liftWork (Matrix.packedBytes s.limits output.bytes)
    work output.work
    modify fun s => { s with gather := output.state }
    if output.status == 2 then throw (.exhausted .outputEntries)
    if output.status == 3 then throw (.exhausted .packedBytes)
    if output.status == 4 then throw (.exhausted .work)
    if output.status == 5 then throw .dimensions
    if output.status != 0 && output.status != 1 then throw .rowUpdate
    if output.status == 1 then
      let state := output.state
      modify fun s => { s with dense := state.dense,gather := ⟨{},{},{},0⟩ }
      install ⟨state.columns,state.coefficients⟩ s.leading s.inverse s.sugar
  | .order =>
    let mut ordered := #[]
    if !s.independent then
      work s.columns
      for column in [:s.columns] do
        let slot := (Packed.read .u32 s.slots column).toNat
        if slot != 0 then ordered := ordered.push s.pivots[slot-1]!
    modify fun s => { s with
      phase := .done
      result := some (.ok (⟨ordered,s.rank,#[]⟩,s.remainders)) }
  | .done => pure ()

private def advancePhase (state : State) (native : Bool) : State := Id.run do
  if state.phase == .done then return state
  let (result,state) := (step native).run state
  match result with
  | .ok _ => return state
  | .error e => return { state with phase := .done,result := some (.error e) }

/-- One phase using bounded native scan/gather. The exported bridge handles
non-hot phases and scalar values outside the frame's native fast path. -/
@[export lean_hex_matrix_step]
def next (state : State) : State := advancePhase state true

/-- Advance a bounded number of atomic phases. The shape-dependent cap budgets
workspace initialization, pending sparse-row charges and array growth
conservatively: at most max(1, 2^20/(8*columns+2*rows+4224)) phases per call. -/
def advancePortable (state : State) (steps : Nat) : State := Id.run do
  let count := min steps (max 1 (1048576 / (8*state.columns+2*(state.reducers.size+state.targets.size)+4224)))
  let mut state := state
  for _ in [:count] do
    if state.phase == .done then break
    state := advancePhase state false
  return state

/-- A native call uses the 64-bit ABI and admits at most 65536 columns and input rows. Other shapes take no transition
here, allowing the caller to run the portable continuation outside native code.
The state is owned and steps is borrowed Nat. C mirrors every intermediate
cursor, pending update, sugar label, charged prefix and terminal outcome.
Large counter values use the bounded Lean phase within the admitted geometry;
large allowances saturate above all totals reachable in one fast native call. -/
@[extern "lean_hex_matrix_advance"]
private def advanceSmall (state : State) (steps : @& Nat) : State :=
  if USize.size != 2^64 || state.columns > 65536 ||
      state.reducers.size+state.targets.size > 65536 then state
  else advancePortable state steps

/-- Bounded native continuation with the same scalar definition. -/
def advance (state : State) (steps : Nat) : State :=
  if USize.size != 2^64 || state.columns > 65536 ||
      state.reducers.size+state.targets.size > 65536 then
    advancePortable state steps else advanceSmall state steps

@[simp] theorem advance_spec (state : State) (steps : Nat) :
    advance state steps = advancePortable state steps := by
  unfold advance advanceSmall
  split <;> simp_all

/-- Run the untraced portable continuation with finite transition fuel. This is
an experimental reference model; it is not selected by the public F4 route. -/
def finishWith (quantum : Nat) (state : State) (native := false) : Except MatrixError (Echelon × Array RemainderRow) × MatrixStats := Id.run do
  let fuel := 2*state.limits.work+4*(state.reducers.size+state.targets.size)+8
  let mut state := state
  for _ in [:fuel] do
    if state.phase == .done then break
    state := if native then advance state (max 1 quantum)
      else advancePortable state (max 1 quantum)
  return (state.result.getD (.error .rowUpdate),state.stats)

/-- Run the reference continuation in batches of 64 phases. -/
def finish (state : State) := finishWith 64 state

end Hex.Groebner.MatrixState
