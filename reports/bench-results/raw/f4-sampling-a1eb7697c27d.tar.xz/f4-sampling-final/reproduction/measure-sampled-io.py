from pathlib import Path
import os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'sampled-io-production'
s=(state/'sampled-kernel-measure.py').read_text().replace("state/'sampled-install-production'","state/'sampled-io-production'");(state/'sampled-io-kernel-measure.py').write_text(s)
with (base/'kernel-runner.log').open('w')as log:
 subprocess.run(['python3',str(state/'sampled-io-kernel-measure.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
common=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'final-products-production/medium-inputs/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree']
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
for name,args in [('deterministic',['--sampled','--seed','10987','--hex',str(base/'binaries/sample'),'--baseline',str(base/'binaries/compute'),'--baseline-manifest',str(base/'manifest.json')]),('refactor',['--hex',str(base/'binaries/compute'),'--baseline',str(state/'sampled-reviewed-production/binaries/compute'),'--baseline-manifest',str(state/'sampled-reviewed-production/manifest.json')])]:
 with (base/(name+'-runner.log')).open('w')as log:
  subprocess.run(common+args+['--output',str(base/name)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
