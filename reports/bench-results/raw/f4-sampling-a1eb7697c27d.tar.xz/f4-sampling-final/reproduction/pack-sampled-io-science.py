from pathlib import Path
import hashlib,io,json,lzma,tarfile
state=Path('/home/kim/tmp/issue-10987');base=state/'sampled-io-production';payload={}
for path in sorted(base.rglob('*')):
 rel=path.relative_to(base)
 if path.is_file() and 'binaries' not in rel.parts:
  payload['sampled-final/'+str(rel)]=path.read_bytes()
for name in ['measure-sampled-io.py','sampled-io-kernel-measure.py']:
 payload['reproduction/'+name]=(state/name).read_bytes()
payload['reproduction/pack-sampled-io-science.py']=Path(__file__).read_bytes()
manifest={k:hashlib.sha256(v).hexdigest()for k,v in sorted(payload.items())};payload['sha256.json']=(json.dumps(manifest,indent=2)+'\n').encode();fp=json.loads((base/'manifest.json').read_text())['source_fingerprint']
out=Path('reports/bench-results/raw')/f'f4-sampling-{fp}.tar.xz'
with lzma.open(out,'wb',preset=9)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-sampling-final/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
