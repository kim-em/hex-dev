from pathlib import Path
import json,tarfile,hashlib,shutil,subprocess
repo=Path('/tmp/hex-groebner-packed-targets-dev');base=Path('/tmp/hex-groebner-packed-targets-layout-production');m=json.loads((base/'manifest.json').read_text());fp=m['source_fingerprint'];name='packed-targets-guards-'+fp;stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
checks=json.loads(Path('/tmp/issue-10987-pr11010-layout-full-status.json').read_text());assert len(checks)==9 and all(c['exit_code']==0 for c in checks)
for p in base.iterdir():
 if p.name=='binaries':continue
 if p.is_dir():shutil.copytree(p,stage/p.name)
 else:shutil.copy2(p,stage/p.name)
bm=json.loads(Path('/tmp/hex-groebner-packed-targets-reviewed-production/manifest.json').read_text());(stage/'baseline-manifest.json').write_text(json.dumps(bm,indent=2)+'\n')
for folder,manifest in [('root-sources',m),('baseline-sources',bm)]:
 (stage/(folder+'.manifest')).write_text(manifest['source_manifest'])
 for line in manifest['source_manifest'].splitlines():
  h,n=line.split('\t',1);oid=h.split()[1];data=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;p=stage/folder/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(repo/folder,stage/folder)
for n in ['scripts/libgraph.py','scripts/check_dag.py','scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh','scripts/ci/check_groebner_driver.py']:
 p=stage/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,p)
for p in Path('/tmp').glob('issue-10987-pr11010-layout-*.log'):shutil.copy2(p,stage/p.name)
shutil.copy2('/tmp/issue-10987-pr11010-layout-full-status.json',stage/'checks.json');shutil.copy2('/tmp/run-issue-10987-full-checks.py',stage/'run-checks.py')
fault=Path('/tmp/issue-10987-pr11010-linear-resize-mutant');assert json.loads((fault/'result.json').read_text())['rejected'];shutil.copytree(fault,stage/'linear-resize-fault',ignore=shutil.ignore_patterns('project'))
(stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=fp,scope='Constructor-layout guards and exclusive ByteArray resize correction on top of23688dd217ce. Preserve marked-linear arrays through exclusive growth, with LEAN_ABORT_ON_NONLINEAR=1 in every instrumented runtime. Direct unique-table alias coverage includes exponents, metadata, index heads and links; instrumentation requires all four accepted classes. Four Clang and four GCC ASan/UBSan variants pass, each115exclusive reuses and24aliased insertions. Replacing only the resize helper with its old nonlinear-only version in a separate native object builds but exits1 with the expected marked-linear panic.2170-job full local build, all independent oracles, both CLI checks,32bench checks and all project audits pass. Fresh272-job frozen source. One initial small64-process/32-pair campaign and one medium56-process/28-pair campaign compare this revised source with23688dd217ce. Complete bases and all counters except candidate time agree; every sample retained. No unchanged timing repeat, no established speed change; earlier performance sources are separate and not pooled. Certificate generation, independent certification and kernel replay are outside candidate timing. Linux only: Windows/macOS native execution not verified, existing upstream CI has one ubuntu job. No fastest-open-source or compiler-impossibility claim.'),indent=2)+'\n')
shutil.copy2('/tmp/analyze-groebner-target-columns.py',stage/'analyze.py');shutil.copy2(__file__,stage/'archive.py');target=repo/'reports/bench-results/raw'/(name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
a=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),fingerprint=fp);Path('/tmp/issue-10987-packed-targets-guards-catalog.json').write_text(json.dumps(a,indent=2)+'\n');print(a)
