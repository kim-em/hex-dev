#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import sys

from libgraph import (
    EXTERNAL_IMPORT_ROOTS,
    PROOF_IMPORT_ROOTS,
    KNOWN_EXCEPTIONS,
    check_lakefile_alignment,
    library_owner_for_path,
    load_lakefile_libs,
    load_libraries,
    may_import,
    reachable_dependencies,
    topological_order,
)


IMPORT_RE = re.compile(
    r"^\s*(?:(?:public|private)\s+)?(?:meta\s+)?import\s+(.+?)\s*$"
)
LEAN_EXE_ROOT_RE = re.compile(r"^\s*root\s*:=\s*`([A-Za-z0-9_.]+)\s*$")
LEAN_GLOB_MODULE_RE = re.compile(r"`([A-Z][A-Za-z0-9_.]+)")
LEAN_LIB_RE = re.compile(r"^lean_lib\s+([A-Za-z0-9_]+)\b")
QUALIFIED_IMPORT_RE = re.compile(
    r"^\s*(?:(?:public|private)\s+)?(?:meta\s+)?import\s+(?:all\s+)?([A-Za-z0-9_.]+)\s*$"
)
IMPORT_ALL_RE = re.compile(
    r"^\s*(?:(?:public|private|meta)\s+)*import\s+all\s+([A-Za-z0-9_.]+)\s*$"
)

# Private constructors and definition bodies form an ordinary/public-import API
# boundary. `import all` is a deliberate trusted-internals escape hatch, so
# every owning exception must be an exact reviewed path rather than a suffix or
# directory convention. The ECM diagnostic observes private preparation costs.
SEALED_IMPORT_ALL_ALLOWLIST: dict[str, frozenset[Path]] = {
    "HexIntFactor.EcmStage2": frozenset({
        Path("bench/HexPrimality/EcmDiagnostics/EcmPreparation.lean")}),
    # Ordinary-kernel replay of the actual validated native context needs the
    # opaque preparation body. This fixture does not construct unchecked domains.
    "HexSturm.Basic": frozenset({
        Path("experiments/KernelReplay/NativeAssemblyStaged.lean"),
        Path("experiments/KernelReplay/FrameDataProbe.lean"),
        Path("experiments/KernelReplay/FrameJoint.lean"),
        Path("experiments/KernelReplay/FrameOwners.lean"),
        Path("experiments/KernelReplay/FrameOperand.lean"),
        Path("experiments/KernelReplay/FrameFrontier.lean")}),
    # The model equation supports consumers without exposing the implementation.
    "HexRealClosureTheory.NumberFieldTower": frozenset(),
    "HexInterval.Executable": frozenset(),
    "HexInterval.Runtime": frozenset(),
    "HexInterval.RuntimeController": frozenset(),
    "HexInterval.Search": frozenset(),
    "HexIntervalTheory.Driver": frozenset(),
    "HexIntervalTheory.Controller": frozenset(),
    "HexIntervalTheory.Proof": frozenset(),
    "HexIntervalTheory.RuntimeProof": frozenset(),
    "HexIntervalTheory.RuntimeTerminal": frozenset(),
}

UMBRELLA_BUILD_TARGETS = {
    "HexPosDefTheoryTests",
    "HexPosDefTheoryProofProbe",
    "HexOrderedFnTests",
    "HexRealClosureTests",
    "HexRealClosureConformanceSupport",
    "HexRealClosureTheoryTests",
    "HexLLLBenchSupport",
    "HexGF2BenchSupport",
    "HexRankBenchSupport",
    "HexSignDetBenchSupport",
    "HexSturmBenchSupport",
    "HexBerlekampKernelProbe",
    "HexPrimalityKernelProbe",
    "HexPrimalityElabProbe",
    "HexPrimalityElabProbeScientific",
    "HexPrimalityConstructionProbe",
    "HexPrimalityTheoryProofProbe",
    "HexECPPTheoryProofProbe",
    "HexECPPTheoryPariIO",
    "HexIntFactorPariIO",
    "HexECPPTheoryTests",
    "HexIntFactorKernelProbe",
    "HexIntFactorTests",
    "HexIntFactorMixedFrozen",
    "HexIntFactorTheoryTests",
    "HexIntFactorTheoryProofProbe",
    "HexIntFactorFieldConformance",
    "HexMvGcdKernelProbe",
    "HexMvGcdBenchSupport",
    "HexRationalFnBenchSupport",
    "HexRationalFnKernelProbe",
    "HexMvPolyBenchSupport",
    "HexModularBenchSupport",
    "HexMvPolyTheoryProofProbe",
    "HexBerlekampZassenhausTheoryProofProbe",
    "HexBerlekampTheoryProofProbe",
    "HexIntervalExperiment",
    "HexGenericRankTests",
    "HexGenericRankTheoryProofProbe",
    "HexDeterminantalIdealTheoryProofProbe",
    "HexRankTests",
    "HexRealAlgebraicTheoryTests",
    "HexSturmTheoryTests",
    "HexRankTheoryProofProbe",
    "HexCharPolyTheoryProofProbe",
    "HexCharPolyTheoryMeasurements",
    "HexBareissTheoryProofProbe",
    "HexPolyDetTheoryProofProbe",
    "HexPolyDetTheoryDiagnostics",
    "HexKroneckerTests",
    "HexIntervalTheoryExperiment",
    "HexIntervalPntFks2Local",
    "HexIntervalPntFks2ConformanceLocal",
    "HexIntervalReplayProbe",
    "HexIntervalTheoryReplayProbe",
    "HexRealRootsTheoryReplayProbe",
    "HexRCFBenchSupport",
    "HexRCFProofProbe",
    "HexRCFProofProbeMeasurements",
    "HexRCFCellRequestedStress",
    "HexRCFAlgebraicCellsStress",
    "HexRealFormulaProofProbe",
    "HexRCFRealFormula",
    "HexRCFRealCoefficients",
    "HexQuerySemantics",
    "HexConformance",
    "HexFactorizationModules",
    "HexMvFactorizationTests",
    "HexReleaseTests",
    "HexSparsePolyTests",
    "HexTruncatedSeriesTests",
    "HexSmithTests",
    "HexStructuralTacticTests",
    "HexStructuralTacticProofProbe",
    "HexLatticeEnumTests",
    "HexDeterminantalIdealTests",
    "HexPermGroupTests",
    "HexGraphIsoTests",
    "HexGraphIsoCfiDiagnostics",
    "HexCharPolyTests",
    "HexReleaseExamples",
}


# SPEC-assigned optional public modules build with their owning library while
# staying outside its ordinary umbrella. Only these exact modules are allowed.
OPTIONAL_BUILD_MODULES = {
    "HexIntFactor": {"HexIntFactor.Pari", "HexIntFactor.Export",
        "HexIntFactor.Mixed.Replay", "HexIntFactor.Mixed.Import",
        "HexIntFactor.Mixed.Pari", "HexIntFactor.Mixed.Export"},
}


def parse_imports(path: Path) -> list[str]:
    imports: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        match = QUALIFIED_IMPORT_RE.match(line.split("--", 1)[0].rstrip())
        if match:
            imports.append(match.group(1))
    return imports


def lean_build_roots(lakefile: Path) -> set[str]:
    """Explicit executable roots and library entry modules, including opt-ins."""
    roots: set[str] = set()
    in_roots = False
    for line in lakefile.read_text(encoding="utf-8").splitlines():
        match = LEAN_EXE_ROOT_RE.match(line)
        if match:
            roots.add(match.group(1))
        if line.strip().startswith("roots := #["):
            in_roots = True
        if in_roots:
            roots.update(LEAN_GLOB_MODULE_RE.findall(line))
            if "]" in line:
                in_roots = False
    return roots


def lean_glob_modules(lakefile: Path, targets: set[str]) -> set[str]:
    r"""Explicit module names in selected build-only Lake targets.

    A production library glob is not an alternative to reachability from its
    public umbrella. Only the named verification/bench support targets may own
    modules that are intentionally absent from a shipped umbrella.
    """
    modules: set[str] = set()
    current_target: str | None = None
    in_globs = False
    for line in lakefile.read_text(encoding="utf-8").splitlines():
        target_match = LEAN_LIB_RE.match(line)
        if target_match:
            current_target = target_match.group(1)
            in_globs = False
        elif line and not line[0].isspace():
            current_target = None
            in_globs = False
        if current_target not in targets:
            continue
        if "globs := #[" in line:
            in_globs = True
        if in_globs:
            modules.update(LEAN_GLOB_MODULE_RE.findall(line))
            if "]" in line:
                in_globs = False
    return modules


def module_name_for(rel_path: Path) -> str:
    """`HexFoo/Bar/Baz.lean` → `HexFoo.Bar.Baz`."""
    return ".".join(rel_path.with_suffix("").parts)


def import_closure_in_library(
    root: Path, entry_module: str, owner: str
) -> set[str]:
    """Modules belonging to `owner` reachable from `entry_module`.

    Walks `import` lines, but only crawls into modules whose name starts
    with `owner.`; that's enough for the umbrella-completeness check,
    which only compares against files under `owner/`.
    """
    seen: set[str] = set()
    stack: list[str] = [entry_module]
    while stack:
        module = stack.pop()
        if module in seen:
            continue
        rel = Path(*module.split(".")).with_suffix(".lean")
        path = root / rel
        if not path.exists():
            continue
        seen.add(module)
        for imported in parse_imports(path):
            if imported == owner or imported.startswith(owner + "."):
                stack.append(imported)
    return seen


def check_umbrella_completeness(
    root: Path, libraries, build_roots: set[str]
) -> list[str]:
    """Every regular module under `Foo/` must be reachable from either
    `Foo.lean` (umbrella) or an explicit Lake executable/glob root.

    A module reachable only from a separate build root is still absent from
    the library's shared object `libHex_Foo.dylib`, but that's fine —
    its symbols ship with the executable and downstream libraries don't
    expect to call into bench / emit-fixture code.
    """
    errors: list[str] = []
    for owner in libraries:
        directory = root / owner
        if not directory.is_dir():
            continue
        umbrella_path = root / f"{owner}.lean"
        if not umbrella_path.exists():
            continue
        reachable = import_closure_in_library(root, owner, owner)
        for build_root in build_roots:
            reachable |= import_closure_in_library(root, build_root, owner)
        for lean_file in sorted(directory.rglob("*.lean")):
            module = module_name_for(lean_file.relative_to(root))
            if module in build_roots:
                continue
            if module in reachable:
                continue
            errors.append(
                f"{owner}.lean does not (transitively) import {module}; "
                "add it to the umbrella, or declare it as an explicit Lake build root"
            )
    return errors


def project_lean_files(root: Path) -> list[Path]:
    files = []
    for path in root.rglob("*.lean"):
        if ".lake" in path.parts:
            continue
        files.append(path.relative_to(root))
    return sorted(files)


def check_adapter_imports(root: Path, files: list[Path], libraries) -> list[str]:
    """Keep development-only modules out of library source and published umbrellas.

    Check full module paths even for imports within the same library prefix.
    Manuals and conformance may exercise adapters; library code may not depend
    on sources omitted by release publishing.
    """
    modules = {
        module_name_for(path.relative_to("adapters"))
        for path in files if path.parts[0] == "adapters"
    }
    errors = []
    for rel_path in files:
        owner = rel_path.parts[0].removesuffix(".lean")
        if owner not in libraries or owner == "HexManual":
            continue
        for line_no, line in enumerate((root / rel_path).read_text().splitlines(), start=1):
            match = IMPORT_RE.match(line.split("--", 1)[0])
            if not match:
                continue
            for module in match.group(1).split():
                if module in modules:
                    errors.append(f"{rel_path}:{line_no} imports development adapter {module} "
                                  "from library source")
    return errors


def check_sealed_import_all(root: Path, files: list[Path]) -> list[str]:
    """Reject trusted-internals imports outside exact reviewed owning paths.

    This scan deliberately covers every project Lean file, including roots such
    as ``conformance/`` and ``bench/`` which have no library DAG owner.
    """
    errors = []
    for rel_path in files:
        path = root / rel_path
        for line_no, line in enumerate(
            path.read_text(encoding="utf-8").splitlines(), start=1
        ):
            import_all = IMPORT_ALL_RE.match(line.split("--", 1)[0].rstrip())
            if not import_all:
                continue
            module = import_all.group(1)
            allowed = SEALED_IMPORT_ALL_ALLOWLIST.get(module)
            if allowed is not None and rel_path not in allowed:
                errors.append(
                    f"{rel_path}:{line_no} uses `import all {module}` outside its "
                    "exact trusted-internals allowlist"
                )
    return errors


def import_roots(line: str) -> list[str]:
    match = IMPORT_RE.match(line.split("--", 1)[0].rstrip())
    if not match:
        return []
    roots = []
    for token in match.group(1).replace(",", " ").split():
        token = token.strip()
        if token:
            roots.append(token.split(".", 1)[0])
    return roots


def main() -> int:
    root = Path(__file__).resolve().parent.parent
    errors: list[str] = []

    try:
        libraries = load_libraries(root / "libraries.yml")
        lakefile_libs = load_lakefile_libs(root)
        topological_order(libraries)
        reachable = reachable_dependencies(libraries)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1

    errors.extend(check_lakefile_alignment(libraries, lakefile_libs))

    # Root-file existence per PLAN/Conventions.md §"Library status":
    #   active local entry  ⟺  <Name>.lean exists at repo root
    #   planned/draft entry  ⟹  <Name>.lean must not exist
    # External libraries are consumed via a git `require`; their sources
    # (root file included) live in the released repo, not locally, so they
    # are exempt from the local root-file existence check.
    active_names = [
        name for name, info in libraries.items()
        if info.is_active and not info.is_external
    ]
    nonactive_names = [name for name, info in libraries.items() if not info.is_active]
    for name in active_names + sorted(KNOWN_EXCEPTIONS):
        if not (root / f"{name}.lean").exists():
            errors.append(f"missing root file {name}.lean")
    for name in nonactive_names:
        if (root / f"{name}.lean").exists():
            info = libraries[name]
            errors.append(
                f"{name}.lean exists at repo root but {name} has status: {info.status}; "
                f"non-active libraries must not have a root file"
            )

    lakefile = root / "lakefile.lean"
    build_roots = lean_build_roots(lakefile) | lean_glob_modules(
        lakefile, UMBRELLA_BUILD_TARGETS
    )
    for target, modules in OPTIONAL_BUILD_MODULES.items():
        build_roots |= lean_glob_modules(lakefile, {target}) & modules
    errors.extend(check_umbrella_completeness(root, libraries, build_roots))

    lean_files = project_lean_files(root)
    errors.extend(check_sealed_import_all(root, lean_files))
    errors.extend(check_adapter_imports(root, lean_files, libraries))

    for rel_path in lean_files:
        owner = library_owner_for_path(rel_path, libraries)
        if owner is None:
            continue
        path = root / rel_path
        for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            for imported_root in import_roots(line):
                if imported_root == owner:
                    continue
                if imported_root in PROOF_IMPORT_ROOTS:
                    if owner != "HexManual" and not libraries[owner].mathlib:
                        errors.append(
                            f"{rel_path}:{line_no} imports {imported_root} but {owner} is not a mathlib bridge"
                        )
                    continue
                if imported_root == "Verso":
                    if owner != "HexManual":
                        errors.append(f"{rel_path}:{line_no} imports Verso outside HexManual")
                    continue
                if imported_root in libraries:
                    if (
                        owner in libraries
                        and owner != "HexManual"
                        and not may_import(
                            owner, imported_root, libraries, reachable,
                            adapter=rel_path.parts[0] == "adapters",
                        )
                    ):
                        errors.append(
                            f"{rel_path}:{line_no} imports {imported_root} without a dependency path from {owner}"
                        )
                    continue
                if imported_root in EXTERNAL_IMPORT_ROOTS:
                    continue

    if errors:
        for error in errors:
            print(error, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
