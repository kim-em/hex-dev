#include <lean/lean.h>
#include <stdint.h>
static uint64_t pushes=0,shared=0,elements=0;
lean_obj_res __real_lean_array_push(lean_obj_arg,lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lean_array_push(lean_obj_arg a,lean_obj_arg value) {
 if(!lean_is_scalar(value) && lean_obj_tag(value)==0 && lean_ctor_num_objs(value)==3 &&
    !lean_is_scalar(lean_ctor_get(value,0)) && !lean_is_scalar(lean_ctor_get(value,1)) &&
    lean_is_sarray(lean_ctor_get(value,0)) && lean_is_sarray(lean_ctor_get(value,1))) {
  ++pushes;if(!lean_is_exclusive(a)) {++shared;elements+=lean_array_size(a);}
 }
 return __real_lean_array_push(a,value);
}
LEAN_EXPORT lean_obj_res sampling_owners(lean_obj_arg world) {
 (void)world;lean_object *inner=lean_alloc_ctor(0,2,0),*outer=lean_alloc_ctor(0,2,0);
 lean_ctor_set(inner,0,lean_box_uint64(shared));lean_ctor_set(inner,1,lean_box_uint64(elements));
 lean_ctor_set(outer,0,lean_box_uint64(pushes));lean_ctor_set(outer,1,inner);
 return lean_io_result_mk_ok(outer);
}
