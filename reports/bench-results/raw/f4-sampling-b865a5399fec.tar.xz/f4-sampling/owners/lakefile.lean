import Lake
open Lake DSL System
package SamplingOwners
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampling-owned"
target ownerO pkg : FilePath := do
 let source ← inputTextFile (pkg.dir / "probe.c")
 buildO (pkg.dir / ".lake/build/probe.o") source #[] #["-O2","-fPIC","-I",(← getLeanIncludeDir).toString]
lean_exe probe where
 root := `Main
 moreLinkObjs := #[ownerO]
 moreLinkArgs := #["-Wl,--wrap=lean_array_push"]
