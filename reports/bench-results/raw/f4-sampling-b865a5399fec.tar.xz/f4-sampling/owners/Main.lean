import HexGroebner.Bench.Sampling
@[extern "sampling_owners"] opaque owners : IO (UInt64 × UInt64 × UInt64)
def main (args : List String) : IO Unit := do
 let [raw] := args | throw (IO.userError "one size required")
 let some n := raw.toNat? | throw (IO.userError "invalid size")
 let result := Hex.Groebner.Bench.samplingKnown (Hex.Groebner.Bench.prepareSampling n)
 IO.println s!"success={result.1},digest={hash result}"
 IO.println (← owners)
