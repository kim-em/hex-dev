from pathlib import Path
import lzma,hashlib,io,json,subprocess,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path.cwd();payload={}
def add(name,data):
 assert name not in payload,name
 payload[name]=data
def tree(source,prefix,excluded=()):
 for path in sorted(source.rglob('*')):
  rel=path.relative_to(source)
  if path.is_file() and not any(x in rel.parts for x in ['binaries','.lake','__pycache__']) and str(rel) not in excluded:
   add(prefix+'/'+str(rel),path.read_bytes())
for label in ['sampled','sampled-owned','sampled-frame','sampled-install','sampled-abi']:
 tree(state/(label+'-production'),label)
tree(state/'sampling-f4-initial','initial')
initial=json.loads((state/'sampling-f4-initial/metadata.json').read_text())
for line in initial['source_manifest'].splitlines():
 _,oid,rest=line.split(' ',2);_,name=rest.split('\t')
 add('initial/root-sources/'+name,subprocess.check_output(['git','cat-file','blob',oid]))
tree(state/'sampling-array-owners','owners')
tree(state/'sampled-profile','profile',excluded=('baseline.data','sampled.data'))
add('profile/raw-perf-hashes.json',(json.dumps({name:hashlib.sha256((state/'sampled-profile'/name).read_bytes()).hexdigest() for name in ['baseline.data','sampled.data']},indent=2)+'\n').encode())
for name in ['sampled-abi-rebase-identity.json','sampled-rebase-identity.json','sampled-abi-kernel-measure.py','sampled-kernel-measure.py']:
 add('reproduction/'+name,(state/name).read_bytes())
add('CONTENTS.txt',b'All completed sampled-F4 development timing campaigns, including negative and inconclusive runs, and the initial untimed diagnostic. Frozen binaries are identified by SHA-256 and exact source snapshots but are not included. Profile reports and original perf-data hashes are included; the two binary perf traces are retained in the original workspace. Ownership diagnostics retain source, generated-project build logs and all before/after outputs. Project verification is a separate capsule.\n')
add('reproduction/pack-sampling-science.py',Path(__file__).read_bytes())
manifest={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())}
add('sha256.json',(json.dumps(manifest,indent=2)+'\n').encode())
out=root/'reports/bench-results/raw/f4-sampling-b865a5399fec.tar.xz'
with out.open('wb')as f,lzma.LZMAFile(f,mode='wb',preset=9)as gz,tarfile.open(fileobj=gz,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-sampling/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
