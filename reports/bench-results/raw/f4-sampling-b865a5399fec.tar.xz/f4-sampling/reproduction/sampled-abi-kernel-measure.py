from pathlib import Path
import hashlib,importlib.util,json,os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'sampled-abi-production';out=base/'kernels';out.mkdir(exist_ok=False);helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('frozen_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();manifest=json.loads((base/'manifest.json').read_text());binary=base/'binaries/bench';before=hashlib.sha256(binary.read_bytes()).hexdigest();assert before==manifest['binary_sha256']['bench'];command=[str(binary),'run','Hex.Groebner.Bench.samplingKnown','--outer-trials','3','--export-file',str(out/'result.json')]
try:
 with(out/'stdout').open('wb')as stdout,(out/'stderr').open('wb')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
finally:
 (out/'metadata.json').write_text(json.dumps(dict(command=command,exit_code=r.returncode,cpu=cpu,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),manifest=manifest,binary_sha256=before,binary_sha256_after=hashlib.sha256(binary.read_bytes()).hexdigest(),scope='Ordinary lean-bench fixed trial-major complexity schedule,3outertrials,declared128..8192inputs. Full output hashing included. No filtering or rerun.'),indent=2)+'\n');lease.close()
(out/'measure.py').write_bytes(Path(__file__).read_bytes());print('kernel exit',r.returncode)
