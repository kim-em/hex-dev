from pathlib import Path
import hashlib,importlib.util,json,os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'sampled-production';out=state/'sampled-profile';out.mkdir(exist_ok=False)
helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('frozen_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);cpu,lease=module.cpu_lease();load=os.getloadavg();os.sched_setaffinity(0,{cpu});runs=[]
try:
 for label,directory,binary,extra in [('baseline','matrix-counts-production','compute',[]),('sampled','sampled-production','sample',['--seed','10987'])]:
  program=[str(state/directory/'binaries'/binary),*extra,'--scheduling','degree','--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000',str(state/'final-products-production/medium-inputs/eco11-31.json')]
  command=['perf','record','-e','cycles:u','-F','1999','--call-graph','dwarf,16384','-o',str(out/(label+'.data')),'--',*program]
  with(out/(label+'.stdout')).open('wb')as stdout,(out/(label+'.stderr')).open('wb')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  runs.append(dict(label=label,command=command,exit_code=r.returncode,manifest=json.loads((state/directory/'manifest.json').read_text())));assert r.returncode==0
  for options,suffix in [(['--no-children','--percent-limit','0.5'],'report'),(['--header-only'],'header')]:
   with(out/(label+'.'+suffix)).open('w')as f:subprocess.run(['perf','report','--stdio',*options,'-i',str(out/(label+'.data'))],stdout=f,stderr=subprocess.STDOUT,check=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),runs=runs,helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),scope='Diagnostic profiles explain the unexpected matched sampling slowdown. Includes startup/parse/output. Cost attribution only; no timing or language-barrier claim.'),indent=2)+'\n');lease.close()
(out/'profile.py').write_bytes(Path(__file__).read_bytes())
