// Lean compiler output
// Module: HexGroebner.PackedWord
// Imports: public import Init public meta import Init public import HexGroebner.Packed
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_byte_array_size(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
lean_object* lean_byte_array_data(lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_byte_array_uget(lean_object*, size_t);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_usize_to_nat(size_t);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Packed_read64___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read64___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Packed_read64(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read64___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Packed_read64Fast(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read64Fast___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter___redArg(lean_object*, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter(lean_object*, lean_object*, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg(uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Packed_read64___lam__0(lean_object* v_xs_1_, lean_object* v_i_2_){
_start:
{
lean_object* v___x_3_; uint8_t v___x_4_; 
v___x_3_ = lean_byte_array_size(v_xs_1_);
v___x_4_ = lean_nat_dec_lt(v_i_2_, v___x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read64___lam__0___boxed(lean_object* v_xs_5_, lean_object* v_i_6_){
_start:
{
uint8_t v_res_7_; lean_object* v_r_8_; 
v_res_7_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_xs_5_, v_i_6_);
lean_dec(v_i_6_);
lean_dec_ref(v_xs_5_);
v_r_8_ = lean_box(v_res_7_);
return v_r_8_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Packed_read64(lean_object* v_bytes_9_, lean_object* v_offset_10_){
_start:
{
uint64_t v___y_12_; uint64_t v___y_13_; uint64_t v___y_14_; uint8_t v___y_15_; uint8_t v___x_22_; uint64_t v___y_24_; uint64_t v___y_25_; uint64_t v___y_26_; uint64_t v___y_27_; uint8_t v___y_28_; uint64_t v___y_40_; uint64_t v___y_41_; uint64_t v___y_42_; uint64_t v___y_43_; uint64_t v___y_44_; uint8_t v___y_45_; uint64_t v___y_57_; uint64_t v___y_58_; uint64_t v___y_59_; uint64_t v___y_60_; uint8_t v___y_61_; uint64_t v___y_71_; uint64_t v___y_72_; uint64_t v___y_73_; uint8_t v___y_74_; uint64_t v___y_87_; uint64_t v___y_88_; uint8_t v___y_89_; uint64_t v___y_102_; uint8_t v___y_103_; uint8_t v___y_116_; uint8_t v___x_125_; 
v___x_22_ = 0;
v___x_125_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_9_, v_offset_10_);
if (v___x_125_ == 0)
{
lean_object* v___x_126_; lean_object* v___x_127_; uint8_t v___x_128_; 
v___x_126_ = lean_box(v___x_22_);
v___x_127_ = l_outOfBounds___redArg(v___x_126_);
lean_dec(v___x_126_);
v___x_128_ = lean_unbox(v___x_127_);
lean_dec(v___x_127_);
v___y_116_ = v___x_128_;
goto v___jp_115_;
}
else
{
uint8_t v___x_129_; 
v___x_129_ = lean_byte_array_fget(v_bytes_9_, v_offset_10_);
v___y_116_ = v___x_129_;
goto v___jp_115_;
}
v___jp_11_:
{
uint64_t v___x_16_; uint64_t v___x_17_; uint64_t v_high_18_; uint64_t v___x_19_; uint64_t v___x_20_; uint64_t v___x_21_; 
v___x_16_ = lean_uint8_to_uint64(v___y_15_);
v___x_17_ = lean_uint64_shift_left(v___x_16_, v___y_13_);
v_high_18_ = lean_uint64_lor(v___y_14_, v___x_17_);
v___x_19_ = 32ULL;
v___x_20_ = lean_uint64_shift_left(v_high_18_, v___x_19_);
v___x_21_ = lean_uint64_lor(v___y_12_, v___x_20_);
return v___x_21_;
}
v___jp_23_:
{
uint64_t v___x_29_; uint64_t v___x_30_; uint64_t v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; uint8_t v___x_34_; 
v___x_29_ = lean_uint8_to_uint64(v___y_28_);
v___x_30_ = lean_uint64_shift_left(v___x_29_, v___y_27_);
v___x_31_ = lean_uint64_lor(v___y_26_, v___x_30_);
v___x_32_ = lean_unsigned_to_nat(7u);
v___x_33_ = lean_nat_add(v_offset_10_, v___x_32_);
v___x_34_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_9_, v___x_33_);
if (v___x_34_ == 0)
{
lean_object* v___x_35_; lean_object* v___x_36_; uint8_t v___x_37_; 
lean_dec(v___x_33_);
v___x_35_ = lean_box(v___x_22_);
v___x_36_ = l_outOfBounds___redArg(v___x_35_);
lean_dec(v___x_35_);
v___x_37_ = lean_unbox(v___x_36_);
lean_dec(v___x_36_);
v___y_12_ = v___y_25_;
v___y_13_ = v___y_24_;
v___y_14_ = v___x_31_;
v___y_15_ = v___x_37_;
goto v___jp_11_;
}
else
{
uint8_t v___x_38_; 
v___x_38_ = lean_byte_array_fget(v_bytes_9_, v___x_33_);
lean_dec(v___x_33_);
v___y_12_ = v___y_25_;
v___y_13_ = v___y_24_;
v___y_14_ = v___x_31_;
v___y_15_ = v___x_38_;
goto v___jp_11_;
}
}
v___jp_39_:
{
uint64_t v___x_46_; uint64_t v___x_47_; uint64_t v___x_48_; lean_object* v___x_49_; lean_object* v___x_50_; uint8_t v___x_51_; 
v___x_46_ = lean_uint8_to_uint64(v___y_45_);
v___x_47_ = lean_uint64_shift_left(v___x_46_, v___y_43_);
v___x_48_ = lean_uint64_lor(v___y_44_, v___x_47_);
v___x_49_ = lean_unsigned_to_nat(6u);
v___x_50_ = lean_nat_add(v_offset_10_, v___x_49_);
v___x_51_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_9_, v___x_50_);
if (v___x_51_ == 0)
{
lean_object* v___x_52_; lean_object* v___x_53_; uint8_t v___x_54_; 
lean_dec(v___x_50_);
v___x_52_ = lean_box(v___x_22_);
v___x_53_ = l_outOfBounds___redArg(v___x_52_);
lean_dec(v___x_52_);
v___x_54_ = lean_unbox(v___x_53_);
lean_dec(v___x_53_);
v___y_24_ = v___y_41_;
v___y_25_ = v___y_40_;
v___y_26_ = v___x_48_;
v___y_27_ = v___y_42_;
v___y_28_ = v___x_54_;
goto v___jp_23_;
}
else
{
uint8_t v___x_55_; 
v___x_55_ = lean_byte_array_fget(v_bytes_9_, v___x_50_);
lean_dec(v___x_50_);
v___y_24_ = v___y_41_;
v___y_25_ = v___y_40_;
v___y_26_ = v___x_48_;
v___y_27_ = v___y_42_;
v___y_28_ = v___x_55_;
goto v___jp_23_;
}
}
v___jp_56_:
{
uint64_t v___x_62_; lean_object* v___x_63_; lean_object* v___x_64_; uint8_t v___x_65_; 
v___x_62_ = lean_uint8_to_uint64(v___y_61_);
v___x_63_ = lean_unsigned_to_nat(5u);
v___x_64_ = lean_nat_add(v_offset_10_, v___x_63_);
v___x_65_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_9_, v___x_64_);
if (v___x_65_ == 0)
{
lean_object* v___x_66_; lean_object* v___x_67_; uint8_t v___x_68_; 
lean_dec(v___x_64_);
v___x_66_ = lean_box(v___x_22_);
v___x_67_ = l_outOfBounds___redArg(v___x_66_);
lean_dec(v___x_66_);
v___x_68_ = lean_unbox(v___x_67_);
lean_dec(v___x_67_);
v___y_40_ = v___y_58_;
v___y_41_ = v___y_57_;
v___y_42_ = v___y_60_;
v___y_43_ = v___y_59_;
v___y_44_ = v___x_62_;
v___y_45_ = v___x_68_;
goto v___jp_39_;
}
else
{
uint8_t v___x_69_; 
v___x_69_ = lean_byte_array_fget(v_bytes_9_, v___x_64_);
lean_dec(v___x_64_);
v___y_40_ = v___y_58_;
v___y_41_ = v___y_57_;
v___y_42_ = v___y_60_;
v___y_43_ = v___y_59_;
v___y_44_ = v___x_62_;
v___y_45_ = v___x_69_;
goto v___jp_39_;
}
}
v___jp_70_:
{
uint64_t v___x_75_; uint64_t v___x_76_; uint64_t v___x_77_; uint64_t v_low_78_; lean_object* v___x_79_; lean_object* v___x_80_; uint8_t v___x_81_; 
v___x_75_ = lean_uint8_to_uint64(v___y_74_);
v___x_76_ = 24ULL;
v___x_77_ = lean_uint64_shift_left(v___x_75_, v___x_76_);
v_low_78_ = lean_uint64_lor(v___y_73_, v___x_77_);
v___x_79_ = lean_unsigned_to_nat(4u);
v___x_80_ = lean_nat_add(v_offset_10_, v___x_79_);
v___x_81_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_9_, v___x_80_);
if (v___x_81_ == 0)
{
lean_object* v___x_82_; lean_object* v___x_83_; uint8_t v___x_84_; 
lean_dec(v___x_80_);
v___x_82_ = lean_box(v___x_22_);
v___x_83_ = l_outOfBounds___redArg(v___x_82_);
lean_dec(v___x_82_);
v___x_84_ = lean_unbox(v___x_83_);
lean_dec(v___x_83_);
v___y_57_ = v___x_76_;
v___y_58_ = v_low_78_;
v___y_59_ = v___y_72_;
v___y_60_ = v___y_71_;
v___y_61_ = v___x_84_;
goto v___jp_56_;
}
else
{
uint8_t v___x_85_; 
v___x_85_ = lean_byte_array_fget(v_bytes_9_, v___x_80_);
lean_dec(v___x_80_);
v___y_57_ = v___x_76_;
v___y_58_ = v_low_78_;
v___y_59_ = v___y_72_;
v___y_60_ = v___y_71_;
v___y_61_ = v___x_85_;
goto v___jp_56_;
}
}
v___jp_86_:
{
uint64_t v___x_90_; uint64_t v___x_91_; uint64_t v___x_92_; uint64_t v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; uint8_t v___x_96_; 
v___x_90_ = lean_uint8_to_uint64(v___y_89_);
v___x_91_ = 16ULL;
v___x_92_ = lean_uint64_shift_left(v___x_90_, v___x_91_);
v___x_93_ = lean_uint64_lor(v___y_88_, v___x_92_);
v___x_94_ = lean_unsigned_to_nat(3u);
v___x_95_ = lean_nat_add(v_offset_10_, v___x_94_);
v___x_96_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_9_, v___x_95_);
if (v___x_96_ == 0)
{
lean_object* v___x_97_; lean_object* v___x_98_; uint8_t v___x_99_; 
lean_dec(v___x_95_);
v___x_97_ = lean_box(v___x_22_);
v___x_98_ = l_outOfBounds___redArg(v___x_97_);
lean_dec(v___x_97_);
v___x_99_ = lean_unbox(v___x_98_);
lean_dec(v___x_98_);
v___y_71_ = v___x_91_;
v___y_72_ = v___y_87_;
v___y_73_ = v___x_93_;
v___y_74_ = v___x_99_;
goto v___jp_70_;
}
else
{
uint8_t v___x_100_; 
v___x_100_ = lean_byte_array_fget(v_bytes_9_, v___x_95_);
lean_dec(v___x_95_);
v___y_71_ = v___x_91_;
v___y_72_ = v___y_87_;
v___y_73_ = v___x_93_;
v___y_74_ = v___x_100_;
goto v___jp_70_;
}
}
v___jp_101_:
{
uint64_t v___x_104_; uint64_t v___x_105_; uint64_t v___x_106_; uint64_t v___x_107_; lean_object* v___x_108_; lean_object* v___x_109_; uint8_t v___x_110_; 
v___x_104_ = lean_uint8_to_uint64(v___y_103_);
v___x_105_ = 8ULL;
v___x_106_ = lean_uint64_shift_left(v___x_104_, v___x_105_);
v___x_107_ = lean_uint64_lor(v___y_102_, v___x_106_);
v___x_108_ = lean_unsigned_to_nat(2u);
v___x_109_ = lean_nat_add(v_offset_10_, v___x_108_);
v___x_110_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_9_, v___x_109_);
if (v___x_110_ == 0)
{
lean_object* v___x_111_; lean_object* v___x_112_; uint8_t v___x_113_; 
lean_dec(v___x_109_);
v___x_111_ = lean_box(v___x_22_);
v___x_112_ = l_outOfBounds___redArg(v___x_111_);
lean_dec(v___x_111_);
v___x_113_ = lean_unbox(v___x_112_);
lean_dec(v___x_112_);
v___y_87_ = v___x_105_;
v___y_88_ = v___x_107_;
v___y_89_ = v___x_113_;
goto v___jp_86_;
}
else
{
uint8_t v___x_114_; 
v___x_114_ = lean_byte_array_fget(v_bytes_9_, v___x_109_);
lean_dec(v___x_109_);
v___y_87_ = v___x_105_;
v___y_88_ = v___x_107_;
v___y_89_ = v___x_114_;
goto v___jp_86_;
}
}
v___jp_115_:
{
uint64_t v___x_117_; lean_object* v___x_118_; lean_object* v___x_119_; uint8_t v___x_120_; 
v___x_117_ = lean_uint8_to_uint64(v___y_116_);
v___x_118_ = lean_unsigned_to_nat(1u);
v___x_119_ = lean_nat_add(v_offset_10_, v___x_118_);
v___x_120_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_9_, v___x_119_);
if (v___x_120_ == 0)
{
lean_object* v___x_121_; lean_object* v___x_122_; uint8_t v___x_123_; 
lean_dec(v___x_119_);
v___x_121_ = lean_box(v___x_22_);
v___x_122_ = l_outOfBounds___redArg(v___x_121_);
lean_dec(v___x_121_);
v___x_123_ = lean_unbox(v___x_122_);
lean_dec(v___x_122_);
v___y_102_ = v___x_117_;
v___y_103_ = v___x_123_;
goto v___jp_101_;
}
else
{
uint8_t v___x_124_; 
v___x_124_ = lean_byte_array_fget(v_bytes_9_, v___x_119_);
lean_dec(v___x_119_);
v___y_102_ = v___x_117_;
v___y_103_ = v___x_124_;
goto v___jp_101_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read64___boxed(lean_object* v_bytes_130_, lean_object* v_offset_131_){
_start:
{
uint64_t v_res_132_; lean_object* v_r_133_; 
v_res_132_ = lp_Hex_Hex_Groebner_Packed_read64(v_bytes_130_, v_offset_131_);
lean_dec(v_offset_131_);
lean_dec_ref(v_bytes_130_);
v_r_133_ = lean_box_uint64(v_res_132_);
return v_r_133_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Packed_read64Fast(lean_object* v_bytes_134_, lean_object* v_offset_135_){
_start:
{
uint64_t v___y_137_; uint64_t v___y_138_; uint64_t v___y_139_; uint8_t v___y_140_; uint8_t v___x_147_; uint64_t v___y_149_; uint64_t v___y_150_; uint64_t v___y_151_; uint64_t v___y_152_; uint8_t v___y_153_; uint64_t v___y_165_; uint64_t v___y_166_; uint64_t v___y_167_; uint64_t v___y_168_; uint64_t v___y_169_; uint8_t v___y_170_; uint64_t v___y_182_; uint64_t v___y_183_; uint64_t v___y_184_; uint64_t v___y_185_; uint8_t v___y_186_; uint64_t v___y_196_; uint64_t v___y_197_; uint64_t v___y_198_; uint8_t v___y_199_; uint64_t v___y_212_; uint64_t v___y_213_; uint8_t v___y_214_; uint64_t v___y_227_; uint8_t v___y_228_; uint8_t v___y_241_; uint8_t v___y_251_; lean_object* v___x_306_; lean_object* v___x_307_; lean_object* v___x_308_; uint8_t v___x_309_; 
v___x_147_ = 0;
v___x_306_ = lean_unsigned_to_nat(8u);
v___x_307_ = lean_nat_add(v_offset_135_, v___x_306_);
v___x_308_ = lean_byte_array_size(v_bytes_134_);
v___x_309_ = lean_nat_dec_le(v___x_307_, v___x_308_);
if (v___x_309_ == 0)
{
lean_dec(v___x_307_);
v___y_251_ = v___x_309_;
goto v___jp_250_;
}
else
{
size_t v___x_310_; lean_object* v___x_311_; uint8_t v___x_312_; 
v___x_310_ = lean_usize_of_nat(v___x_307_);
v___x_311_ = lean_usize_to_nat(v___x_310_);
v___x_312_ = lean_nat_dec_eq(v___x_311_, v___x_307_);
lean_dec(v___x_307_);
lean_dec(v___x_311_);
v___y_251_ = v___x_312_;
goto v___jp_250_;
}
v___jp_136_:
{
uint64_t v___x_141_; uint64_t v___x_142_; uint64_t v_high_143_; uint64_t v___x_144_; uint64_t v___x_145_; uint64_t v___x_146_; 
v___x_141_ = lean_uint8_to_uint64(v___y_140_);
v___x_142_ = lean_uint64_shift_left(v___x_141_, v___y_139_);
v_high_143_ = lean_uint64_lor(v___y_138_, v___x_142_);
v___x_144_ = 32ULL;
v___x_145_ = lean_uint64_shift_left(v_high_143_, v___x_144_);
v___x_146_ = lean_uint64_lor(v___y_137_, v___x_145_);
return v___x_146_;
}
v___jp_148_:
{
uint64_t v___x_154_; uint64_t v___x_155_; uint64_t v___x_156_; lean_object* v___x_157_; lean_object* v___x_158_; uint8_t v___x_159_; 
v___x_154_ = lean_uint8_to_uint64(v___y_153_);
v___x_155_ = lean_uint64_shift_left(v___x_154_, v___y_151_);
v___x_156_ = lean_uint64_lor(v___y_150_, v___x_155_);
v___x_157_ = lean_unsigned_to_nat(7u);
v___x_158_ = lean_nat_add(v_offset_135_, v___x_157_);
v___x_159_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_134_, v___x_158_);
if (v___x_159_ == 0)
{
lean_object* v___x_160_; lean_object* v___x_161_; uint8_t v___x_162_; 
lean_dec(v___x_158_);
v___x_160_ = lean_box(v___x_147_);
v___x_161_ = l_outOfBounds___redArg(v___x_160_);
lean_dec(v___x_160_);
v___x_162_ = lean_unbox(v___x_161_);
lean_dec(v___x_161_);
v___y_137_ = v___y_149_;
v___y_138_ = v___x_156_;
v___y_139_ = v___y_152_;
v___y_140_ = v___x_162_;
goto v___jp_136_;
}
else
{
uint8_t v___x_163_; 
v___x_163_ = lean_byte_array_fget(v_bytes_134_, v___x_158_);
lean_dec(v___x_158_);
v___y_137_ = v___y_149_;
v___y_138_ = v___x_156_;
v___y_139_ = v___y_152_;
v___y_140_ = v___x_163_;
goto v___jp_136_;
}
}
v___jp_164_:
{
uint64_t v___x_171_; uint64_t v___x_172_; uint64_t v___x_173_; lean_object* v___x_174_; lean_object* v___x_175_; uint8_t v___x_176_; 
v___x_171_ = lean_uint8_to_uint64(v___y_170_);
v___x_172_ = lean_uint64_shift_left(v___x_171_, v___y_169_);
v___x_173_ = lean_uint64_lor(v___y_166_, v___x_172_);
v___x_174_ = lean_unsigned_to_nat(6u);
v___x_175_ = lean_nat_add(v_offset_135_, v___x_174_);
v___x_176_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_134_, v___x_175_);
if (v___x_176_ == 0)
{
lean_object* v___x_177_; lean_object* v___x_178_; uint8_t v___x_179_; 
lean_dec(v___x_175_);
v___x_177_ = lean_box(v___x_147_);
v___x_178_ = l_outOfBounds___redArg(v___x_177_);
lean_dec(v___x_177_);
v___x_179_ = lean_unbox(v___x_178_);
lean_dec(v___x_178_);
v___y_149_ = v___y_165_;
v___y_150_ = v___x_173_;
v___y_151_ = v___y_167_;
v___y_152_ = v___y_168_;
v___y_153_ = v___x_179_;
goto v___jp_148_;
}
else
{
uint8_t v___x_180_; 
v___x_180_ = lean_byte_array_fget(v_bytes_134_, v___x_175_);
lean_dec(v___x_175_);
v___y_149_ = v___y_165_;
v___y_150_ = v___x_173_;
v___y_151_ = v___y_167_;
v___y_152_ = v___y_168_;
v___y_153_ = v___x_180_;
goto v___jp_148_;
}
}
v___jp_181_:
{
uint64_t v___x_187_; lean_object* v___x_188_; lean_object* v___x_189_; uint8_t v___x_190_; 
v___x_187_ = lean_uint8_to_uint64(v___y_186_);
v___x_188_ = lean_unsigned_to_nat(5u);
v___x_189_ = lean_nat_add(v_offset_135_, v___x_188_);
v___x_190_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_134_, v___x_189_);
if (v___x_190_ == 0)
{
lean_object* v___x_191_; lean_object* v___x_192_; uint8_t v___x_193_; 
lean_dec(v___x_189_);
v___x_191_ = lean_box(v___x_147_);
v___x_192_ = l_outOfBounds___redArg(v___x_191_);
lean_dec(v___x_191_);
v___x_193_ = lean_unbox(v___x_192_);
lean_dec(v___x_192_);
v___y_165_ = v___y_182_;
v___y_166_ = v___x_187_;
v___y_167_ = v___y_183_;
v___y_168_ = v___y_185_;
v___y_169_ = v___y_184_;
v___y_170_ = v___x_193_;
goto v___jp_164_;
}
else
{
uint8_t v___x_194_; 
v___x_194_ = lean_byte_array_fget(v_bytes_134_, v___x_189_);
lean_dec(v___x_189_);
v___y_165_ = v___y_182_;
v___y_166_ = v___x_187_;
v___y_167_ = v___y_183_;
v___y_168_ = v___y_185_;
v___y_169_ = v___y_184_;
v___y_170_ = v___x_194_;
goto v___jp_164_;
}
}
v___jp_195_:
{
uint64_t v___x_200_; uint64_t v___x_201_; uint64_t v___x_202_; uint64_t v_low_203_; lean_object* v___x_204_; lean_object* v___x_205_; uint8_t v___x_206_; 
v___x_200_ = lean_uint8_to_uint64(v___y_199_);
v___x_201_ = 24ULL;
v___x_202_ = lean_uint64_shift_left(v___x_200_, v___x_201_);
v_low_203_ = lean_uint64_lor(v___y_196_, v___x_202_);
v___x_204_ = lean_unsigned_to_nat(4u);
v___x_205_ = lean_nat_add(v_offset_135_, v___x_204_);
v___x_206_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_134_, v___x_205_);
if (v___x_206_ == 0)
{
lean_object* v___x_207_; lean_object* v___x_208_; uint8_t v___x_209_; 
lean_dec(v___x_205_);
v___x_207_ = lean_box(v___x_147_);
v___x_208_ = l_outOfBounds___redArg(v___x_207_);
lean_dec(v___x_207_);
v___x_209_ = lean_unbox(v___x_208_);
lean_dec(v___x_208_);
v___y_182_ = v_low_203_;
v___y_183_ = v___y_197_;
v___y_184_ = v___y_198_;
v___y_185_ = v___x_201_;
v___y_186_ = v___x_209_;
goto v___jp_181_;
}
else
{
uint8_t v___x_210_; 
v___x_210_ = lean_byte_array_fget(v_bytes_134_, v___x_205_);
lean_dec(v___x_205_);
v___y_182_ = v_low_203_;
v___y_183_ = v___y_197_;
v___y_184_ = v___y_198_;
v___y_185_ = v___x_201_;
v___y_186_ = v___x_210_;
goto v___jp_181_;
}
}
v___jp_211_:
{
uint64_t v___x_215_; uint64_t v___x_216_; uint64_t v___x_217_; uint64_t v___x_218_; lean_object* v___x_219_; lean_object* v___x_220_; uint8_t v___x_221_; 
v___x_215_ = lean_uint8_to_uint64(v___y_214_);
v___x_216_ = 16ULL;
v___x_217_ = lean_uint64_shift_left(v___x_215_, v___x_216_);
v___x_218_ = lean_uint64_lor(v___y_212_, v___x_217_);
v___x_219_ = lean_unsigned_to_nat(3u);
v___x_220_ = lean_nat_add(v_offset_135_, v___x_219_);
v___x_221_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_134_, v___x_220_);
if (v___x_221_ == 0)
{
lean_object* v___x_222_; lean_object* v___x_223_; uint8_t v___x_224_; 
lean_dec(v___x_220_);
v___x_222_ = lean_box(v___x_147_);
v___x_223_ = l_outOfBounds___redArg(v___x_222_);
lean_dec(v___x_222_);
v___x_224_ = lean_unbox(v___x_223_);
lean_dec(v___x_223_);
v___y_196_ = v___x_218_;
v___y_197_ = v___x_216_;
v___y_198_ = v___y_213_;
v___y_199_ = v___x_224_;
goto v___jp_195_;
}
else
{
uint8_t v___x_225_; 
v___x_225_ = lean_byte_array_fget(v_bytes_134_, v___x_220_);
lean_dec(v___x_220_);
v___y_196_ = v___x_218_;
v___y_197_ = v___x_216_;
v___y_198_ = v___y_213_;
v___y_199_ = v___x_225_;
goto v___jp_195_;
}
}
v___jp_226_:
{
uint64_t v___x_229_; uint64_t v___x_230_; uint64_t v___x_231_; uint64_t v___x_232_; lean_object* v___x_233_; lean_object* v___x_234_; uint8_t v___x_235_; 
v___x_229_ = lean_uint8_to_uint64(v___y_228_);
v___x_230_ = 8ULL;
v___x_231_ = lean_uint64_shift_left(v___x_229_, v___x_230_);
v___x_232_ = lean_uint64_lor(v___y_227_, v___x_231_);
v___x_233_ = lean_unsigned_to_nat(2u);
v___x_234_ = lean_nat_add(v_offset_135_, v___x_233_);
v___x_235_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_134_, v___x_234_);
if (v___x_235_ == 0)
{
lean_object* v___x_236_; lean_object* v___x_237_; uint8_t v___x_238_; 
lean_dec(v___x_234_);
v___x_236_ = lean_box(v___x_147_);
v___x_237_ = l_outOfBounds___redArg(v___x_236_);
lean_dec(v___x_236_);
v___x_238_ = lean_unbox(v___x_237_);
lean_dec(v___x_237_);
v___y_212_ = v___x_232_;
v___y_213_ = v___x_230_;
v___y_214_ = v___x_238_;
goto v___jp_211_;
}
else
{
uint8_t v___x_239_; 
v___x_239_ = lean_byte_array_fget(v_bytes_134_, v___x_234_);
lean_dec(v___x_234_);
v___y_212_ = v___x_232_;
v___y_213_ = v___x_230_;
v___y_214_ = v___x_239_;
goto v___jp_211_;
}
}
v___jp_240_:
{
uint64_t v___x_242_; lean_object* v___x_243_; lean_object* v___x_244_; uint8_t v___x_245_; 
v___x_242_ = lean_uint8_to_uint64(v___y_241_);
v___x_243_ = lean_unsigned_to_nat(1u);
v___x_244_ = lean_nat_add(v_offset_135_, v___x_243_);
v___x_245_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_134_, v___x_244_);
if (v___x_245_ == 0)
{
lean_object* v___x_246_; lean_object* v___x_247_; uint8_t v___x_248_; 
lean_dec(v___x_244_);
v___x_246_ = lean_box(v___x_147_);
v___x_247_ = l_outOfBounds___redArg(v___x_246_);
lean_dec(v___x_246_);
v___x_248_ = lean_unbox(v___x_247_);
lean_dec(v___x_247_);
v___y_227_ = v___x_242_;
v___y_228_ = v___x_248_;
goto v___jp_226_;
}
else
{
uint8_t v___x_249_; 
v___x_249_ = lean_byte_array_fget(v_bytes_134_, v___x_244_);
lean_dec(v___x_244_);
v___y_227_ = v___x_242_;
v___y_228_ = v___x_249_;
goto v___jp_226_;
}
}
v___jp_250_:
{
if (v___y_251_ == 0)
{
uint8_t v___x_252_; 
v___x_252_ = lp_Hex_Hex_Groebner_Packed_read64___lam__0(v_bytes_134_, v_offset_135_);
if (v___x_252_ == 0)
{
lean_object* v___x_253_; lean_object* v___x_254_; uint8_t v___x_255_; 
v___x_253_ = lean_box(v___x_147_);
v___x_254_ = l_outOfBounds___redArg(v___x_253_);
lean_dec(v___x_253_);
v___x_255_ = lean_unbox(v___x_254_);
lean_dec(v___x_254_);
v___y_241_ = v___x_255_;
goto v___jp_240_;
}
else
{
uint8_t v___x_256_; 
v___x_256_ = lean_byte_array_fget(v_bytes_134_, v_offset_135_);
v___y_241_ = v___x_256_;
goto v___jp_240_;
}
}
else
{
size_t v_pos_257_; uint8_t v___x_258_; uint64_t v___x_259_; size_t v___x_260_; size_t v___x_261_; uint8_t v___x_262_; uint64_t v___x_263_; uint64_t v___x_264_; uint64_t v___x_265_; uint64_t v___x_266_; size_t v___x_267_; size_t v___x_268_; uint8_t v___x_269_; uint64_t v___x_270_; uint64_t v___x_271_; uint64_t v___x_272_; uint64_t v___x_273_; size_t v___x_274_; size_t v___x_275_; uint8_t v___x_276_; uint64_t v___x_277_; uint64_t v___x_278_; uint64_t v___x_279_; uint64_t v_low_280_; size_t v___x_281_; size_t v___x_282_; uint8_t v___x_283_; uint64_t v___x_284_; size_t v___x_285_; size_t v___x_286_; uint8_t v___x_287_; uint64_t v___x_288_; uint64_t v___x_289_; uint64_t v___x_290_; size_t v___x_291_; size_t v___x_292_; uint8_t v___x_293_; uint64_t v___x_294_; uint64_t v___x_295_; uint64_t v___x_296_; size_t v___x_297_; size_t v___x_298_; uint8_t v___x_299_; uint64_t v___x_300_; uint64_t v___x_301_; uint64_t v_high_302_; uint64_t v___x_303_; uint64_t v___x_304_; uint64_t v___x_305_; 
v_pos_257_ = lean_usize_of_nat(v_offset_135_);
v___x_258_ = lean_byte_array_uget(v_bytes_134_, v_pos_257_);
v___x_259_ = lean_uint8_to_uint64(v___x_258_);
v___x_260_ = ((size_t)1ULL);
v___x_261_ = lean_usize_add(v_pos_257_, v___x_260_);
v___x_262_ = lean_byte_array_uget(v_bytes_134_, v___x_261_);
v___x_263_ = lean_uint8_to_uint64(v___x_262_);
v___x_264_ = 8ULL;
v___x_265_ = lean_uint64_shift_left(v___x_263_, v___x_264_);
v___x_266_ = lean_uint64_lor(v___x_259_, v___x_265_);
v___x_267_ = ((size_t)2ULL);
v___x_268_ = lean_usize_add(v_pos_257_, v___x_267_);
v___x_269_ = lean_byte_array_uget(v_bytes_134_, v___x_268_);
v___x_270_ = lean_uint8_to_uint64(v___x_269_);
v___x_271_ = 16ULL;
v___x_272_ = lean_uint64_shift_left(v___x_270_, v___x_271_);
v___x_273_ = lean_uint64_lor(v___x_266_, v___x_272_);
v___x_274_ = ((size_t)3ULL);
v___x_275_ = lean_usize_add(v_pos_257_, v___x_274_);
v___x_276_ = lean_byte_array_uget(v_bytes_134_, v___x_275_);
v___x_277_ = lean_uint8_to_uint64(v___x_276_);
v___x_278_ = 24ULL;
v___x_279_ = lean_uint64_shift_left(v___x_277_, v___x_278_);
v_low_280_ = lean_uint64_lor(v___x_273_, v___x_279_);
v___x_281_ = ((size_t)4ULL);
v___x_282_ = lean_usize_add(v_pos_257_, v___x_281_);
v___x_283_ = lean_byte_array_uget(v_bytes_134_, v___x_282_);
v___x_284_ = lean_uint8_to_uint64(v___x_283_);
v___x_285_ = ((size_t)5ULL);
v___x_286_ = lean_usize_add(v_pos_257_, v___x_285_);
v___x_287_ = lean_byte_array_uget(v_bytes_134_, v___x_286_);
v___x_288_ = lean_uint8_to_uint64(v___x_287_);
v___x_289_ = lean_uint64_shift_left(v___x_288_, v___x_264_);
v___x_290_ = lean_uint64_lor(v___x_284_, v___x_289_);
v___x_291_ = ((size_t)6ULL);
v___x_292_ = lean_usize_add(v_pos_257_, v___x_291_);
v___x_293_ = lean_byte_array_uget(v_bytes_134_, v___x_292_);
v___x_294_ = lean_uint8_to_uint64(v___x_293_);
v___x_295_ = lean_uint64_shift_left(v___x_294_, v___x_271_);
v___x_296_ = lean_uint64_lor(v___x_290_, v___x_295_);
v___x_297_ = ((size_t)7ULL);
v___x_298_ = lean_usize_add(v_pos_257_, v___x_297_);
v___x_299_ = lean_byte_array_uget(v_bytes_134_, v___x_298_);
v___x_300_ = lean_uint8_to_uint64(v___x_299_);
v___x_301_ = lean_uint64_shift_left(v___x_300_, v___x_278_);
v_high_302_ = lean_uint64_lor(v___x_296_, v___x_301_);
v___x_303_ = 32ULL;
v___x_304_ = lean_uint64_shift_left(v_high_302_, v___x_303_);
v___x_305_ = lean_uint64_lor(v_low_280_, v___x_304_);
return v___x_305_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Packed_read64Fast___boxed(lean_object* v_bytes_313_, lean_object* v_offset_314_){
_start:
{
uint64_t v_res_315_; lean_object* v_r_316_; 
v_res_315_ = lp_Hex_Hex_Groebner_Packed_read64Fast(v_bytes_313_, v_offset_314_);
lean_dec(v_offset_314_);
lean_dec_ref(v_bytes_313_);
v_r_316_ = lean_box_uint64(v_res_315_);
return v_r_316_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter___redArg(lean_object* v_x_317_, size_t v_x_318_, lean_object* v_h__1_319_){
_start:
{
lean_object* v_data_320_; lean_object* v___x_321_; lean_object* v___x_322_; 
v_data_320_ = lean_byte_array_data(v_x_317_);
v___x_321_ = lean_box_usize(v_x_318_);
v___x_322_ = lean_apply_3(v_h__1_319_, v_data_320_, v___x_321_, lean_box(0));
return v___x_322_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter___redArg___boxed(lean_object* v_x_323_, lean_object* v_x_324_, lean_object* v_h__1_325_){
_start:
{
size_t v_x_19__boxed_326_; lean_object* v_res_327_; 
v_x_19__boxed_326_ = lean_unbox_usize(v_x_324_);
lean_dec(v_x_324_);
v_res_327_ = lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter___redArg(v_x_323_, v_x_19__boxed_326_, v_h__1_325_);
return v_res_327_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter(lean_object* v_motive_328_, lean_object* v_x_329_, size_t v_x_330_, lean_object* v_x_331_, lean_object* v_h__1_332_){
_start:
{
lean_object* v_data_333_; lean_object* v___x_334_; lean_object* v___x_335_; 
v_data_333_ = lean_byte_array_data(v_x_329_);
v___x_334_ = lean_box_usize(v_x_330_);
v___x_335_ = lean_apply_3(v_h__1_332_, v_data_333_, v___x_334_, lean_box(0));
return v___x_335_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter___boxed(lean_object* v_motive_336_, lean_object* v_x_337_, lean_object* v_x_338_, lean_object* v_x_339_, lean_object* v_h__1_340_){
_start:
{
size_t v_x_31__boxed_341_; lean_object* v_res_342_; 
v_x_31__boxed_341_ = lean_unbox_usize(v_x_338_);
lean_dec(v_x_338_);
v_res_342_ = lp_Hex___private_HexGroebner_PackedWord_0__ByteArray_uget_match__1_splitter(v_motive_336_, v_x_337_, v_x_31__boxed_341_, v_x_339_, v_h__1_340_);
return v_res_342_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg(uint8_t v_x_343_, lean_object* v_h__1_344_, lean_object* v_h__2_345_, lean_object* v_h__3_346_){
_start:
{
switch(v_x_343_)
{
case 0:
{
lean_object* v___x_347_; lean_object* v___x_348_; 
lean_dec(v_h__3_346_);
lean_dec(v_h__2_345_);
v___x_347_ = lean_box(0);
v___x_348_ = lean_apply_1(v_h__1_344_, v___x_347_);
return v___x_348_;
}
case 1:
{
lean_object* v___x_349_; lean_object* v___x_350_; 
lean_dec(v_h__3_346_);
lean_dec(v_h__1_344_);
v___x_349_ = lean_box(0);
v___x_350_ = lean_apply_1(v_h__2_345_, v___x_349_);
return v___x_350_;
}
default: 
{
lean_object* v___x_351_; lean_object* v___x_352_; 
lean_dec(v_h__2_345_);
lean_dec(v_h__1_344_);
v___x_351_ = lean_box(0);
v___x_352_ = lean_apply_1(v_h__3_346_, v___x_351_);
return v___x_352_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg___boxed(lean_object* v_x_353_, lean_object* v_h__1_354_, lean_object* v_h__2_355_, lean_object* v_h__3_356_){
_start:
{
uint8_t v_x_33__boxed_357_; lean_object* v_res_358_; 
v_x_33__boxed_357_ = lean_unbox(v_x_353_);
v_res_358_ = lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter___redArg(v_x_33__boxed_357_, v_h__1_354_, v_h__2_355_, v_h__3_356_);
return v_res_358_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter(lean_object* v_motive_359_, uint8_t v_x_360_, lean_object* v_h__1_361_, lean_object* v_h__2_362_, lean_object* v_h__3_363_){
_start:
{
switch(v_x_360_)
{
case 0:
{
lean_object* v___x_364_; lean_object* v___x_365_; 
lean_dec(v_h__3_363_);
lean_dec(v_h__2_362_);
v___x_364_ = lean_box(0);
v___x_365_ = lean_apply_1(v_h__1_361_, v___x_364_);
return v___x_365_;
}
case 1:
{
lean_object* v___x_366_; lean_object* v___x_367_; 
lean_dec(v_h__3_363_);
lean_dec(v_h__1_361_);
v___x_366_ = lean_box(0);
v___x_367_ = lean_apply_1(v_h__2_362_, v___x_366_);
return v___x_367_;
}
default: 
{
lean_object* v___x_368_; lean_object* v___x_369_; 
lean_dec(v_h__2_362_);
lean_dec(v_h__1_361_);
v___x_368_ = lean_box(0);
v___x_369_ = lean_apply_1(v_h__3_363_, v___x_368_);
return v___x_369_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter___boxed(lean_object* v_motive_370_, lean_object* v_x_371_, lean_object* v_h__1_372_, lean_object* v_h__2_373_, lean_object* v_h__3_374_){
_start:
{
uint8_t v_x_48__boxed_375_; lean_object* v_res_376_; 
v_x_48__boxed_375_ = lean_unbox(v_x_371_);
v_res_376_ = lp_Hex___private_HexGroebner_PackedWord_0__Hex_Groebner_Width_bytes_match__1_splitter(v_motive_370_, v_x_48__boxed_375_, v_h__1_372_, v_h__2_373_, v_h__3_374_);
return v_res_376_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Packed(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_PackedWord(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Packed(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_PackedWord(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Packed(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_PackedWord(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Packed(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_PackedWord(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_PackedWord(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_PackedWord(builtin);
}
#ifdef __cplusplus
}
#endif
