import Lake
open Lake DSL System
package GroebnerMatrixChecks
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"

def probeO (pkg : Package) (name : String) (flags : Array String) : FetchM (Job FilePath) := do
  let source ← inputTextFile (pkg.dir / "probe.c")
  let scan ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987/HexGroebner/ffi/matrix_scan.c")
  let simd ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987/HexGroebner/ffi/matrix_simd.h")
  let body ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987/HexGroebner/ffi/matrix_scan_impl.h")
  let inputs := ((source.zipWith (fun s _ => s) scan).zipWith (fun s _ => s) simd).zipWith (fun s _ => s) body
  buildO (pkg.dir / defaultBuildDir / (name ++ ".o")) inputs
    #["-isystem", (← getLeanIncludeDir).toString] flags
    (compiler := FilePath.mk "clang")
    (extraDepTrace := do addPureTrace "clang" "compiler"; pure BuildTrace.nil)

target probeNative pkg : FilePath := probeO pkg "Native" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING"]
lean_exe checkNative where
  root := `CheckNative
  moreLinkObjs := #[probeNative]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]

target probeScalar pkg : FilePath := probeO pkg "Scalar" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_NO_AVX2"]
lean_exe checkScalar where
  root := `CheckScalar
  moreLinkObjs := #[probeScalar]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]

target probeRemainder pkg : FilePath := probeO pkg "Remainder" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_NO_UINT128"]
lean_exe checkRemainder where
  root := `CheckRemainder
  moreLinkObjs := #[probeRemainder]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]

target probeScalarRemainder pkg : FilePath := probeO pkg "ScalarRemainder" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_NO_AVX2", "-DHEX_GROEBNER_NO_UINT128"]
lean_exe checkScalarRemainder where
  root := `CheckScalarRemainder
  moreLinkObjs := #[probeScalarRemainder]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]
