import HexGroebner.NativeChecks
@[extern "hex_test_counts"] opaque counts : IO (UInt64 × UInt64)
@[extern "hex_test_vector_counts"] opaque vectorCounts : IO (UInt64 × UInt64)
@[extern "hex_test_avx2"] opaque avx2 : IO Bool
def main : IO Unit := do
  Hex.Groebner.NativeChecks.run
  let (scan,gather) ← counts
  if scan == 0 || gather == 0 then throw (IO.userError "test override was not called")
  let available ← avx2
  let (contiguous,gathered) ← vectorCounts
  IO.println s!"native call counts: scan={scan}, gather={gather}; AVX2={available}, contiguous={contiguous}, strided={gathered}"
  if true && available && (contiguous == 0 || gathered == 0) then
    throw (IO.userError "an AVX2 path was not exercised")
  if true && (← IO.getEnv "HEX_GROEBNER_REQUIRE_AVX2") == some "1" && !available then
    throw (IO.userError "AVX2 coverage required but unavailable")
