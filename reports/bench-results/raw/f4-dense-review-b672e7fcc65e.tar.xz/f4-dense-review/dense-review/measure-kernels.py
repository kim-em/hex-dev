from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
state=Path('/home/kim/tmp/issue-10987');base=state/'dense-review-production'
helper=base/'root-sources/scripts/bench/cpu_lease.py'
spec=importlib.util.spec_from_file_location('cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
manifest=json.loads((base/'manifest.json').read_text());binary=base/'binaries/bench'
cpu,lease=module.cpu_lease();digest=hashlib.sha256(binary.read_bytes()).hexdigest();assert digest==manifest['binary_sha256']['bench']
status_path=base/'kernel-status.json'
samples=json.loads(status_path.read_text())['samples'] if status_path.exists() else []
completed={s['label']for s in samples}
def run(label,name,extra):
 if label in completed:return
 out=base/'kernels'/label;out.mkdir(parents=True,exist_ok=False)
 command=[str(binary),'run','Hex.Groebner.Bench.'+name,*extra,'--export-file',str(out/'result.json')]
 started=time.time_ns();load=os.getloadavg()
 with (out/'stdout').open('wb')as stdout,(out/'stderr').open('wb')as stderr:
  result=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=lambda:os.sched_setaffinity(0,{cpu}),env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
 sample=dict(label=label,command=command,exit_code=result.returncode,started_ns=started,finished_ns=time.time_ns(),cpu=cpu,load_start=load,load_end=os.getloadavg())
 samples.append(sample);(out/'metadata.json').write_text(json.dumps(sample,indent=2)+'\n')
 (base/'kernel-status.json').write_text(json.dumps(dict(manifest=manifest,binary_sha256=digest,binary_sha256_after=hashlib.sha256(binary.read_bytes()).hexdigest(),host=os.uname().nodename,threads=1,samples=samples),indent=2)+'\n')
 print(label,result.returncode,flush=True)
 if result.returncode not in [0,2]:raise SystemExit(result.returncode)
shapes=[('selected','denseSelected','sparseSelected')]
try:
 for shape,dense,sparse in shapes:
  for arm,name in [('dense',dense),('sparse',sparse)]:
   run('complexity/'+shape+'/'+arm,name,['--outer-trials','3'])
 for block in [0,1]:
  for shape,dense,sparse in shapes:
   for n in [128,256,512,1024,2048,4096]:
    for arm in (['sparse','dense']if block==0 else['dense','sparse']):
     name=sparse if arm=='sparse'else dense
     run(f'matched/{shape}/b{block}-{n}-{arm}',name,['--outer-trials','1','--param-schedule','doubling','--param-floor',str(n),'--param-ceiling',str(n)])
finally:lease.close()
(base/'measure-kernels.py').write_bytes(Path(__file__).read_bytes())
