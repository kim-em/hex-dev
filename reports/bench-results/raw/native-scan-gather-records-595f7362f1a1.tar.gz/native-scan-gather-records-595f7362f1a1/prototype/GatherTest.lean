import NativeGather
import ScanTest

open Hex.Groebner.Native

private def gatherEqual (a b : Gather.Result) : Bool :=
  a.state.dense.data == b.state.dense.data && a.state.columns.data == b.state.columns.data &&
  a.state.coefficients.data == b.state.coefficients.data && a.state.cursor == b.state.cursor &&
  a.entries == b.entries && a.bytes == b.bytes && a.work == b.work && a.status == b.status

private def checked : Bool := Id.run do
  for p in [2,3,251,256,257,65521,65536,65537,2147483647] do
    let w := width p
    for seed in [:8] do
      let dense := packed w ((Array.range 31).map fun i =>
        if (i+seed)%3 == 0 then 0 else ((i+1)*69069+(seed+1)*12345)%p)
      let state : Gather.State := ⟨dense,{}, {},0⟩
      for factor in [1,p-1,p/2] do
        for quantum in [0,1,3,31,32,4096,4097] do
          for entries in [0,1,30,31,2^90] do
            for bytes in [0,4+w,30*(4+w),31*(4+w),2^90] do
              for work in [0,1,30,31,2^90] do
                if !gatherEqual (Gather.gather p.toUInt64 state 31 quantum entries bytes work factor.toUInt64)
                    (Gather.portable p.toUInt64 state 31 quantum entries bytes work factor.toUInt64) then return false
  return true

#guard checked

private def aliases : Bool := Id.run do
  let dense := packed 4 #[0,2,0,7,0,11,0]
  for state in [(⟨dense,dense,packed 4 (Array.replicate 7 1),0⟩ : Gather.State),
      ⟨dense,{}, {},0⟩,⟨dense,packed 4 #[0],packed 4 #[1],1⟩,
      ⟨dense,dense,dense,0⟩] do
    if !gatherEqual (Gather.gather 65537 state 7 4096 100 1000 100 3)
        (Gather.portable 65537 state 7 4096 100 1000 100 3) then return false
  let dense := packed 4 ((Array.replicate 31 1).set! 30 0)
  for state in [(⟨dense,dense,dense,1⟩ : Gather.State),
      ⟨dense,packed 4 (Array.replicate 31 0),dense,1⟩] do
    if !gatherEqual (Gather.gather 65537 state 31 4096 100 1000 100 3)
        (Gather.portable 65537 state 31 4096 100 1000 100 3) then return false
  return true

#guard aliases

def gatherRuntimeChecks : Bool := checked && aliases
