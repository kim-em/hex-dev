import ScanTest
import GatherTest

def main : IO Unit := do
  if runtimeChecks && gatherRuntimeChecks then IO.println "native scan and gather: widths, chunking, counters, aliases, malformed inputs match portable"
  else throw (IO.userError "native scan mismatch")
