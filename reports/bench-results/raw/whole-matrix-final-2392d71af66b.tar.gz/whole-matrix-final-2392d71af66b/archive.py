from pathlib import Path
import json,hashlib,subprocess,shutil,tarfile
repo=Path('/tmp/hex-groebner-whole-matrix-pr');base=Path('/tmp/hex-groebner-whole-final-production');manifest=json.loads((base/'manifest.json').read_text());checks=json.loads(Path('/tmp/issue-10987-pr11011-final-full-status.json').read_text());assert len(checks)==9 and all(x['exit_code']==0 for x in checks)
name='whole-matrix-final-'+manifest['source_fingerprint'];stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
for n in ['manifest.json','build.log']:
 p=base/n
 if p.exists():shutil.copy2(p,stage/n)
count=0
for line in manifest['source_manifest'].splitlines():
 mode,n=line.split('\t',1);oid=mode.split()[1];data=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
 p=stage/'root-sources'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);count+=1
for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(repo/folder,stage/'validation-sources'/folder)
for p in Path('/tmp').glob('issue-10987-pr11011-final-*'):
 if p.is_file():shutil.copy2(p,stage/p.name)
for n in ['issue-10987-pr11011-review-docs-build.log','issue-10987-pr11011-run-spec-build.log','run-issue-10987-full-checks.py','profile-groebner-baseline-builds.py']:
 shutil.copy2(Path('/tmp')/n,stage/n)
for name2 in ['clang','gcc']:
 shutil.copytree(Path('/tmp/hex-groebner-whole-final-'+name2+'-sanitizers'),stage/('native-'+name2))
shutil.copytree('/tmp/issue-10987-relocatable-wrapper',stage/'compiler-wrapper')
shutil.copytree('/tmp/hex-groebner-baseline-build-profile',stage/'baseline-build-profile')
old=json.loads(Path('/tmp/hex-groebner-whole-matrix-reviewed-production/manifest.json').read_text());assert manifest['binary_sha256']==old['binary_sha256']
(stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=manifest['source_fingerprint'],physical_source_files=count,measured_source_fingerprint=old['source_fingerprint'],byte_identical_drivers=True,scope='Supplement preserving final reference-equivalence proof, ABI docs, 64/65-target and1024/1025-reducer boundary checks, fresh full checks and8native sanitizer variants. Historical archives unchanged. Both compute binaries are byte-identical to the separately measured e878b78cf727 drivers; no additional timing sweep. Relocatable compiler wrapper/flags archived together, SDK path overridable through HEX_GROEBNER_LEAN_SDK. Separate original/restored-wrapper baseline-only profile compares identical source9bac, leased CPU69,1999Hz user cycles,DWARF,one requested algorithm thread,AB/BA,8processes onCyclic7-31/Eco11-31. All complete bases/counters equal,zero lost samples,raw perf data,allocator/ELF context retained. Profile durations are explanatory only, excluded from timing estimates; do not infer a causal linker penalty or explain unrelated external sweeps.'),indent=2)+'\n')
shutil.copy2(__file__,stage/'archive.py');target=repo/'reports/bench-results/raw'/(name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as tar:tar.add(stage,arcname=name)
a=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source_fingerprint=manifest['source_fingerprint'],physical_source_files=count,size=target.stat().st_size);Path('/tmp/issue-10987-whole-matrix-final-catalog.json').write_text(json.dumps(a,indent=2)+'\n');print(a)
