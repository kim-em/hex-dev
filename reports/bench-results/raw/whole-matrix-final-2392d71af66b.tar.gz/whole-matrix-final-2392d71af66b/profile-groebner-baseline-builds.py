from pathlib import Path
import os,json,subprocess,sys,hashlib
root=Path('/tmp/hex-groebner-whole-matrix-pr');sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
out=Path('/tmp/hex-groebner-baseline-build-profile');out.mkdir(exist_ok=False)
variants={'A':Path('/tmp/hex-groebner-packed-targets-final-production'),'B':Path('/tmp/hex-groebner-packed-targets-sdk-check-production')};cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});records=[]
manifest={a:json.loads((p/'manifest.json').read_text()) for a,p in variants.items()};assert manifest['A']['source_manifest']==manifest['B']['source_manifest']
for arm,base in variants.items():
 (out/(arm+'-manifest.json')).write_text(json.dumps(manifest[arm],indent=2)+'\n')
 for name,args in [('dynamic',['readelf','-d']),('program',['readelf','-l']),('size',['size'])]:
  with (out/(arm+'-'+name+'.txt')).open('w') as f:subprocess.run([*args,str(base/'binaries/compute')],stdout=f,stderr=subprocess.STDOUT,check=True)
try:
 for case in ['cyclic7-31','eco11-31']:
  outputs=[]
  for block,order in enumerate(['AB','BA']):
   for arm in order:
    prefix=f'{case}-{block}-{arm}';binary=variants[arm]/'binaries/compute';data=out/(prefix+'.perf.data');command=['perf','record','-e','cycles:u','-F','1999','--call-graph','dwarf','-o',str(data),'--',str(binary),'--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000','/tmp/hex-groebner-medium-suite/'+case+'.json']
    with (out/(prefix+'.stdout')).open('w') as stdout,(out/(prefix+'.stderr')).open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,MIMALLOC_SHOW_STATS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
    record=dict(case=case,block=block,arm=arm,command=command,returncode=r.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest());records.append(record);assert r.returncode==0
    value=json.loads((out/(prefix+'.stdout')).read_text());outputs.append((value['basis'],{k:v for k,v in value['statistics'].items() if k!='candidate_nanos'}))
    with (out/(prefix+'.flat.txt')).open('w') as f:subprocess.run(['perf','report','--stdio','--no-children','--sort','symbol','-i',str(data),'--percent-limit','0.5'],stdout=f,stderr=subprocess.STDOUT,check=True)
    print(prefix,'passed',flush=True)
  assert all(value==outputs[0] for value in outputs)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(scope='Explanatory profile of identical source9bac12f60779 built under originalSDK wrapper(A203fed...) and restored task-localSDK wrapper(B70a1c...). One requested algorithm thread, singleleasedCPU, adjacentAB/BA acrossCyclic7-31/Eco11-31. All complete bases/counters must agree; raw samples, allocator statistics and perfdata retained. Profiled processes are not used as timing estimates or unchanged timing reruns. Dynamic-link and section context is recorded; differences are not assumed causal.',cpu=cpu,threads=1,host=os.uname().nodename,runs=records),indent=2)+'\n');lease.close()
