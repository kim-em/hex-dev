from pathlib import Path
import shutil,json,hashlib,tarfile
stage=Path('/tmp/hex-groebner-archive-staging/whole-matrix-final-2392d71af66b');repo=Path('/tmp/hex-groebner-whole-matrix-pr');target=repo/'reports/bench-results/raw/whole-matrix-final-2392d71af66b.tar.gz';shutil.copy2(target,'/tmp/issue-10987-whole-final-original-full.tar.gz');records=[]
for compiler in ['clang','gcc']:
 root=stage/('native-'+compiler)/'.lake';local=Path('/tmp/hex-groebner-whole-final-'+compiler+'-sanitizers/.lake')
 for p in root.rglob('*'):
  if not p.is_file():continue
  name=p.relative_to(root)
  records.append(dict(kind='regenerable native build output',local_path=str(local/name),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size))
  if p.suffix=='.rsp':
   dest=stage/('native-'+compiler)/'response-files'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 shutil.rmtree(root)
for p in (stage/'baseline-build-profile').glob('*.perf.data'):
 records.append(dict(kind='raw explanatory profile, retained on shared host',local_path=str(Path('/tmp/hex-groebner-baseline-build-profile')/p.name),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size));p.unlink()
(stage/'local-artifact-inventory.json').write_text(json.dumps(records,indent=2)+'\n')
scope=json.loads((stage/'scope.json').read_text());scope['scope']='Supplement for validated source 2392d71af66b: erased reference-equivalence proof, ABI documentation, 64/65-target and 1024/1025-reducer checks, nine fresh full-check steps and eight native sanitizer variants. Both compute binaries are byte-identical to separately measured e878b78cf727. No additional timing sweep. Compiler wrapper and flags are colocated; HEX_GROEBNER_LEAN_SDK overrides the SDK path. Baseline-only explanatory profile compares identical source 9bac with original and restored wrapper builds, CPU 69, 1999 Hz user cycles, DWARF, one requested algorithm thread and eight adjacent AB/BA processes on Cyclic7-31/Eco11-31. Complete bases/counters agree; zero lost samples. Flat profiles, allocator statistics, ELF context, response files and artifact hashes are archived. Regenerable native build outputs and raw perf recordings remain at the shared-host paths in local-artifact-inventory.json. Historical three measurement archives are unchanged. Profiled durations are excluded from timing estimates and do not establish a causal linker penalty or explain the unrelated external-sweep shift.';(stage/'scope.json').write_text(json.dumps(scope,indent=2)+'\n')
p=stage/'baseline-build-profile/metadata.json';meta=json.loads(p.read_text());meta['scope']='Explanatory profile of identical source 9bac12f60779 built under original SDK wrapper (A,203fed...) and restored task-local SDK wrapper (B,70a1c...). One requested algorithm thread, single leased CPU, adjacent AB/BA across Cyclic7-31 and Eco11-31. All complete bases/counters agree. Allocator statistics and flat profiles are archived; raw perf recordings remain on the shared host, with hashes in local-artifact-inventory.json. Profiled durations are not timing estimates or unchanged timing reruns. ELF and section differences are recorded and are not assumed causal.';p.write_text(json.dumps(meta,indent=2)+'\n')
shutil.copy2(__file__,stage/'trim-archive.py')
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=stage.name)
sha=hashlib.sha256(target.read_bytes()).hexdigest();catalog=Path('/tmp/issue-10987-whole-matrix-final-catalog.json');c=json.loads(catalog.read_text());old=c['sha256'];c['sha256']=sha;c['size']=target.stat().st_size;catalog.write_text(json.dumps(c,indent=2)+'\n');p=repo/'reports/bench-results/hexgroebner-whole-matrix.md';p.write_text(p.read_text().replace(old,sha));print(c)
