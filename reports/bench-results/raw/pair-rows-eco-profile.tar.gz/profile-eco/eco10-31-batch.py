import subprocess,json,pathlib
exe='/tmp/hex-groebner-pair-rows-owned-production/binaries/compare-pair-rows-owned'
inp='/tmp/hex-groebner-compare/eco10-31.json'
root=pathlib.Path('/tmp/hex-groebner-pair-rows-owned-production/profile-eco')
for i in range(8):
 with (root/('eco10-31'+'-'+str(i)+'.stdout')).open('w') as out,(root/('eco10-31'+'-'+str(i)+'.stderr')).open('w') as err:
  subprocess.run([exe,inp],stdout=out,stderr=err,check=True)
