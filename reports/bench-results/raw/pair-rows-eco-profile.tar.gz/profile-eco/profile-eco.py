from pathlib import Path
import sys,os,json,subprocess,hashlib
sys.path.insert(0,'/tmp/hex-groebner-pair-rows-review')
from scripts.bench.cpu_lease import cpu_lease
p=Path('/tmp/hex-groebner-pair-rows-owned-production/profile-eco');p.mkdir(exist_ok=False)
exe=Path('/tmp/hex-groebner-pair-rows-owned-production/binaries/compare-pair-rows-owned')
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});runs=[]
try:
 for case in ['eco10-15','eco10-31']:
  inp=Path('/tmp/hex-groebner-compare')/(case+'.json')
  batch=p/(case+'-batch.py');batch.write_text("import subprocess,json,pathlib\nexe="+repr(str(exe))+"\ninp="+repr(str(inp))+"\nroot=pathlib.Path("+repr(str(p))+\
   ")\nfor i in range(8):\n with (root/("+repr(case)+"+'-'+str(i)+'.stdout')).open('w') as out,(root/("+repr(case)+"+'-'+str(i)+'.stderr')).open('w') as err:\n  subprocess.run([exe,inp],stdout=out,stderr=err,check=True)\n")
  command=['perf','record','-F','1999','-g','--call-graph','dwarf,4096','-o',str(p/(case+'.perf')),'--','python3',str(batch)]
  with (p/(case+'.stdout')).open('w') as out,(p/(case+'.stderr')).open('w') as err:r=subprocess.run(command,stdout=out,stderr=err)
  runs.append(dict(case=case,command=command,returncode=r.returncode,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest()))
  if r.returncode==0:
   with (p/(case+'-report.txt')).open('w') as out:subprocess.run(['perf','report','--stdio','--no-children','--sort','symbol','-i',str(p/(case+'.perf'))],stdout=out,stderr=subprocess.STDOUT,check=True)
finally:
 (p/'metadata.json').write_text(json.dumps(dict(cpu=cpu,runs=runs,source_fingerprint='70aacca874da',binary_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),load=os.getloadavg(),reason='Explain the matched msolve gap on Eco10, a large diagnostic case. Eight full process invocations per field under perf; includes startup/parse/output; no matched timing claim or null-control requirement.',script=Path(__file__).read_text()),indent=2)+'\n');lease.close()
