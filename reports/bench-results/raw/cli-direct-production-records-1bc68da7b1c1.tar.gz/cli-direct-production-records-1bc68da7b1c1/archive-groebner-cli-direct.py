from pathlib import Path
import json,subprocess,hashlib,shutil,tarfile
root=Path('/tmp/hex-groebner-cli-dev');p=Path('/tmp/hex-groebner-cli-direct-production');dest=root/'reports/bench-results/raw';manifest=json.load(open(p/'manifest.json'));rows=[]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for directory in sorted(p.glob('*records-1bc68da7b1c1')):
 for name in ['manifest.json']:shutil.copy2(p/name,directory/name)
 shutil.copy2(__file__,directory/Path(__file__).name)
 for line in manifest['source_manifest'].splitlines():
  _,oid,rest=line.split(' ',2);_,name=rest.split('\t');f=directory/'root-sources'/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd=root))
 (directory/'source.manifest').write_text(manifest['source_manifest'])
 meta=json.load(open(directory/'metadata.json'))
 if meta['msolve_mode']:
  ms=Path('/tmp/hex-groebner-msolve');assert sha(ms/'src/neogb/.libs/libneogb.so.4.0.0')==meta['msolve_engine_sha256']
  shutil.copy2('/tmp/hex-groebner-mersenne-dispatch-production/msolve-source-3672113ee2c6.tar',directory/'msolve-source-3672113ee2c6.tar')
  shutil.copy2('/tmp/issue-10987-cli-reviewed-msolve-fetch.log',directory/'msolve-fetch.log')
  (directory/'msolve-linkage.txt').write_text(subprocess.check_output(['ldd',str(ms/'.libs/msolve')],text=True)+subprocess.check_output(['ldd',str(ms/'src/neogb/.libs/libneogb.so.4.0.0')],text=True))
 target=dest/(directory.name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(directory,arcname=directory.name)
 rows.append((target.name,sha(target)))
validation=p/'cli-direct-validation';validation.mkdir(exist_ok=False)
for pattern in ['issue-10987-cli-direct*.log','issue-10987-cli-init-*.log','issue-10987-cli-target-build-tests.log','issue-10987-cli-serial-boundary-conformance.log','issue-10987-cli-stale-source-negative.log']:
 for log in Path('/tmp').glob(pattern):shutil.copy2(log,validation/log.name)
for file in ['scripts/ci/check_groebner_driver.py','scripts/ci/check_groebner_initialization.py','scripts/bench/groebner_cli_measure.py']:
 f=validation/file;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/file,f)
target=dest/'cli-direct-validation-1bc68da7b1c1.tar.gz'
with tarfile.open(target,'w:gz') as t:t.add(validation,arcname=validation.name)
rows.append((target.name,sha(target)))
Path('/tmp/issue-10987-cli-direct-archive-hashes.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
