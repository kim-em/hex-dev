import hashlib,json,os,pathlib,subprocess,sys,time
sys.path.insert(0,'/tmp/hex-groebner-intern-review')
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import fingerprint,index_listing
root=pathlib.Path('/tmp/hex-groebner-intern-review');dev=pathlib.Path('/tmp/hex-groebner-intern-final-production')
listing=index_listing(FAMILY);fp=fingerprint(listing);out=dev/('intern-final-production-bench-'+fp+'-repeat');out.mkdir(exist_ok=False)
binaries={'A':pathlib.Path('/tmp/hex-groebner-pair-rows-owned-production/binaries/hexgroebner-bench-pair-rows-owned'),'B':dev/'binaries/hexgroebner-bench-intern-final'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
meta=dict(source_fingerprint=fp,source_manifest=listing,baseline_commit='6841f20b1f',baseline_source_fingerprint='70aacca874da',binary_sha256={a:sha(p) for a,p in binaries.items()},cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),schedule='per case, adjacent AB then BA; declared five fixed repetitions',contract='two frozen production executables; A owned-set multiplied-row engine 70aacca874da, B compact typed monomial index with bounded native attempts with exact native validation, lookup and insertion, exclusive table reuse, unchanged deferred state and Lean fallback outside the native call and reference fallback; same fixed six F4 systems and complete structural hashing, only cyclic6Small uses two-byte coefficients; preparation, certification and kernel checking excluded',toolchain=(root/'lean-toolchain').read_text().strip(),compiler=subprocess.check_output(['cc','--version'],text=True),script=pathlib.Path(__file__).read_text(),runs=[])
try:
 for block,order in enumerate(['AB','BA']):
  for case in ['cyclic4','cyclic5','cyclic6','katsura3','reimer5','cyclic6Small']:
   for arm in order:
    prefix=f'{case}-b{block}-{arm}';command=[str(binaries[arm]),'run','Hex.Groebner.Bench.'+case,'--export-file',str(out/(prefix+'.json'))]
    print(prefix,flush=True);start=time.monotonic_ns()
    with (out/(prefix+'.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    meta['runs'].append(dict(case=case,block=block,arm=arm,command=command,returncode=result.returncode,wall_nanos=time.monotonic_ns()-start))
finally:
 meta['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
