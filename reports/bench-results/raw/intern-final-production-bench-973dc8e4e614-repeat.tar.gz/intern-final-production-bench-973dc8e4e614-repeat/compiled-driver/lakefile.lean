import Lake
open Lake DSL
package GroebnerNativeProduction
require Hex from "/tmp/hex-groebner-intern-review"
lean_lib Reference where
  roots := #[`ReferenceElimination, `ReferenceSymbolic, `ReferenceF4]
lean_exe production_compare where
  root := `Main

open System

target sanitizedO pkg : FilePath := do
  let directory := FilePath.mk "/tmp/hex-groebner-intern-review/HexGroebner/ffi"
  let source ← inputTextFile (directory / "matrix_scan.c")
  let header ← inputTextFile (directory / "matrix_simd.h")
  let body ← inputTextFile (directory / "matrix_scan_impl.h")
  buildO (pkg.dir / defaultBuildDir / "sanitized.o")
    ((source.zipWith (fun s _ => s) header).zipWith (fun s _ => s) body)
    #["-I", (← getLeanIncludeDir).toString]
    #["-O1", "-g", "-fsanitize=address,undefined", "-fno-omit-frame-pointer", "-fPIC",
      "-Dlean_hex_scan_transition=__wrap_lean_hex_scan_transition",
      "-Dlean_hex_gather=__wrap_lean_hex_gather"]

lean_exe production_checks where
  root := `Check
  moreLinkObjs := #[sanitizedO]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather",
    "/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/resource-root/lib/linux/libclang_rt.asan-x86_64.so"]
