from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
s=Path('/home/kim/tmp/issue-10987');base=s/'matrix-replay-frozen-v2';out=Path('/dev/shm/issue-10987-delayed-replay-v2');out.mkdir(exist_ok=False)
manifest=json.loads((base/'manifest.json').read_text());selected=json.loads((base/'selected-matrix.json').read_text());frame=Path('/dev/shm/issue-10987-klyz-matrix-shapes/frames')/('frame-%06d.bin'%selected['id']);binary=base/'replay';sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();assert sha(binary)==manifest['binary_sha256']
helper=s/'lazy-hardened-production/root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('replay_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});rows=[];start=os.getloadavg()
try:
 for block in [0,1]:
  for arm in (['A','B']if block==0 else['B','A']):
   mode='reference'if arm=='A'else'delayed';name=f'b{block}-{arm}';command=[str(binary),mode,str(frame)]
   with(out/(name+'.stdout')).open('w')as stdout,(out/(name+'.stderr')).open('w')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
   row=dict(block=block,arm=arm,command=command,exit_code=r.returncode)
   if r.returncode==0:
    row['result']=json.loads((out/(name+'.stdout')).read_text());assert row['result']['completeOutputAndCountersEqual']and row['result']['work']==selected['work']
   rows.append(row);print(name,r.returncode,row.get('result',{}).get('candidateNanos'),flush=True)
   (out/'samples.json').write_text(json.dumps(rows,indent=2)+'\n')
   if r.returncode:raise SystemExit(r.returncode)
finally:
 assert sha(binary)==manifest['binary_sha256']
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=start,load_end=os.getloadavg(),manifest=manifest,input=selected,input_sha256=sha(frame),binary_sha256=sha(binary),helper_sha256=sha(helper),samples=rows,scope='Four initial adjacent AB/BA kernel observations on one in-sample captured matrix. CandidateNanos comes from C CLOCK_MONOTONIC_RAW around only the provider. Input decode and independent complete-reference replay happen outside timing. Every completed sample is retained; no repeat or whole-system/leadership claim.'),indent=2)+'\n');lease.close()
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
