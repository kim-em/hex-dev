from pathlib import Path
import hashlib,json,shutil
s=Path('/home/kim/tmp/issue-10987');old=s/'hard-frame-probe';out=s/'klyz-shape-probe';assert not out.exists();shutil.copytree(old,out,ignore=shutil.ignore_patterns('.lake','usage-results'))
(out/'.lake').mkdir();cache=Path('/dev/shm/issue-10987-klyz-shape-build');cache.mkdir();(out/'.lake/build').symlink_to(cache)
shutil.copytree(old/'.lake/build',cache,dirs_exist_ok=True,symlinks=True)
p=out/'probe.c';text=p.read_text();needle='static uint64_t continuation_phases[8]';pos=text.index(needle)
helper=r'''
static uint64_t profile_frames=0,profile_max_entries=0;
static void profile_u64(FILE *f,uint64_t n) {
 uint8_t b[8];for(unsigned i=0;i<8;++i)b[i]=(uint8_t)(n>>(8*i));
 if(fwrite(b,1,8,f)!=8)abort();
}
static void profile_matrix(uint64_t p,uint64_t columns,b_lean_obj_arg reducers,
 b_lean_obj_arg targets,b_lean_obj_arg sugars,b_lean_obj_arg stats,uint8_t independent) {
 const char *log=getenv("HEX_F4_MATRIX_SHAPES"),*directory=getenv("HEX_F4_MATRIX_DUMPS");
 if(!log || p!=32003)return;
 uint64_t nr=lean_array_size(reducers),nt=lean_array_size(targets),entries=0;
 for(uint64_t i=0;i<nr+nt;++i) {
  lean_object *r=lean_array_cptr(i<nr?reducers:targets)[i<nr?i:i-nr];
  entries+=lean_sarray_size(lean_ctor_get(r,0))/4;
 }
 lean_object *work=lean_ctor_get(stats,0);if(!lean_is_scalar(work))abort();
 uint64_t id=profile_frames++;int dump=directory&&entries>profile_max_entries;
 FILE *stream=fopen(log,"a");if(!stream)abort();
 fprintf(stream,"{\"id\":%llu,\"p\":%llu,\"columns\":%llu,\"reducers\":%llu,\"targets\":%llu,\"entries\":%llu,\"work\":%llu,\"independent\":%u,\"dump\":%s}\n",
  (unsigned long long)id,(unsigned long long)p,(unsigned long long)columns,
  (unsigned long long)nr,(unsigned long long)nt,(unsigned long long)entries,
  (unsigned long long)lean_unbox(work),(unsigned)independent,dump?"true":"false");
 if(fclose(stream))abort();
 if(!dump)return;profile_max_entries=entries;
 char path[512];int count=snprintf(path,sizeof(path),"%s/frame-%06llu.bin",directory,(unsigned long long)id);
 if(count<0||(size_t)count>=sizeof(path))abort();stream=fopen(path,"wb");if(!stream)abort();
 if(fwrite("HXF4MAT1",1,8,stream)!=8)abort();
 uint64_t ns=lean_array_size(sugars),header[]={p,columns,nr,nt,ns,independent,entries};
 for(unsigned i=0;i<7;++i)profile_u64(stream,header[i]);
 for(uint64_t i=0;i<ns;++i){lean_object *n=lean_array_cptr(sugars)[i];if(!lean_is_scalar(n))abort();profile_u64(stream,lean_unbox(n));}
 for(uint64_t i=0;i<nr+nt;++i) {
  lean_object *r=lean_array_cptr(i<nr?reducers:targets)[i<nr?i:i-nr];
  lean_object *cs=lean_ctor_get(r,0),*vs=lean_ctor_get(r,1);
  size_t cb=lean_sarray_size(cs),vb=lean_sarray_size(vs);profile_u64(stream,cb);profile_u64(stream,vb);
  if(fwrite(lean_sarray_cptr(cs),1,cb,stream)!=cb||fwrite(lean_sarray_cptr(vs),1,vb,stream)!=vb)abort();
 }
 if(fclose(stream))abort();
}
'''
text=text[:pos]+helper+'\n'+text[pos:]
needle='if(!lean_is_scalar(answer) && lean_obj_tag(answer)==1) { ++continuation_successes;';assert needle in text;text=text.replace(needle,'if(!lean_is_scalar(answer) && lean_obj_tag(answer)==1) { profile_matrix(c.p,c.columns,c.v[2],c.v[3],c.v[4],c.v[17],c.independent); ++continuation_successes;',1)
needle='lean_object *result=hex_test_whole(p,limits,columns,reducers,targets,sugars,independent);';assert needle in text
text=text.replace(needle,needle+'\n if(!lean_is_scalar(result)&&lean_is_scalar(columns)) {lean_object *r=lean_ctor_get(result,0);profile_matrix(p,lean_unbox(columns),reducers,targets,sugars,lean_ctor_get(r,1),independent);}',1)
p.write_text(text)
(out/'prepare-profile.py').write_bytes(Path(__file__).read_bytes())
print(out,hashlib.sha256(p.read_bytes()).hexdigest())
