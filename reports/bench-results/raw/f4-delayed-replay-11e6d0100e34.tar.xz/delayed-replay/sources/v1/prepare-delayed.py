from pathlib import Path
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-bulk-scan')
s=(root/'HexGroebner/ffi/matrix_eliminate.c').read_text()
s=s.replace('#include "matrix_runtime.h"','#include "matrix_runtime.h"\n#define lean_hex_groebner_eliminate_matrix hex_replay_delayed\n#define lean_hex_matrix_validate hex_replay_delayed_validate\n#define lean_hex_matrix_zeros hex_replay_delayed_zeros')
s=s.replace('#define MATRIX_QUANTUM UINT64_C(1048576)','#define MATRIX_QUANTUM (UINT64_C(1)<<34)')
needle='typedef struct {\n    uint64_t limits[7]';assert needle in s;s=s.replace(needle,'''typedef struct {
    const uint8_t *columns,*coefficients;
    uint64_t size,end,sugar;
} delayed_pivot;
_Static_assert(sizeof(delayed_pivot)==40,"delayed pivot layout");

typedef struct {
    uint64_t limits[7]''',1)
s=s.replace('uint8_t cache,binary,project;','uint8_t cache,binary,project,delayed;').replace('lean_object *dense,*slots,*pivots,','lean_object *delayed_meta;\n    lean_object *dense,*slots,*pivots,',1)
needle='static int matrix_charge(';idx=s.index(needle);s=s[:idx]+'''static uint64_t delayed_read(matrix_context *c,uint64_t col) {
    uint64_t n;memcpy(&n,lean_sarray_cptr(c->dense)+(size_t)col*8,8);return n;
}
static void delayed_write(matrix_context *c,uint64_t col,uint64_t n) {
    memcpy(lean_sarray_cptr(c->dense)+(size_t)col*8,&n,8);
}
'''+s[idx:]
s=s.replace('static void matrix_cleanup(matrix_context *c) {','static void matrix_cleanup(matrix_context *c) {\n    if(c->delayed_meta) lean_dec(c->delayed_meta);',1)
needle='    if(c->binary) {\n        if(id>=c->capacity)';assert needle in s
s=s.replace(needle,'''    if(c->delayed) {
        if(id>=c->capacity) {lean_dec(row);return 0;}
        lean_object *cs=lean_ctor_get(row,0),*vs=lean_ctor_get(row,1);
        uint64_t n=lean_sarray_size(cs)/4;
        if(!n || n>c->columns) {lean_dec(row);return 0;}
        delayed_pivot pivot={lean_sarray_cptr(cs),lean_sarray_cptr(vs),n,
            matrix_read(lean_sarray_cptr(cs)+(size_t)(n-1)*4,4),sugar};
        memcpy(lean_sarray_cptr(c->delayed_meta)+id*sizeof(pivot),&pivot,sizeof(pivot));
    }
'''+needle,1).replace('if(!c->binary) {\n        lean_object *native=', 'if(!c->binary && !c->delayed) {\n        lean_object *native=',1)
needle='static int matrix_scan(matrix_context *c,';idx=s.index(needle)
s=s[:idx]+'''/* Each head is visited once. Thus each cell receives at most columns
   additions <=(p-1)^2, within the explicitly checked UInt64 bound. */
static int delayed_scan(matrix_context *c,uint64_t first,uint64_t *last,
        uint64_t *leading,uint64_t *sugar) {
    uint64_t charged=first;
    for(uint64_t col=first;col<c->columns && col<=*last;++col) {
        if(col>=charged) {
            uint64_t stop=col+64<*last+1?col+64:*last+1;
            if(!matrix_work(c,stop-col)) return 0;
            charged=stop;
        }
        uint64_t a=delayed_read(c,col)%c->p;
        delayed_write(c,col,a);
        if(!a) continue;
        uint64_t slot=matrix_read(lean_sarray_cptr(c->slots)+(size_t)col*4,4);
        if(!slot) {if(!*leading) *leading=col+1;continue;}
        delayed_pivot pivot;
        memcpy(&pivot,lean_sarray_cptr(c->delayed_meta)+(size_t)(slot-1)*sizeof(pivot),sizeof(pivot));
        if(pivot.end>*last) *last=pivot.end;
        if(pivot.sugar>*sugar) *sugar=pivot.sugar;
        if(!matrix_work(c,pivot.size)) return 0;
        uint64_t factor=c->p-a;
        for(uint64_t j=1;j<pivot.size;++j) {
            uint64_t k=matrix_read(pivot.columns+(size_t)j*4,4);
            uint64_t b=matrix_read(pivot.coefficients+(size_t)j*c->width,c->width);
            delayed_write(c,k,delayed_read(c,k)+factor*b);
        }
        delayed_write(c,col,0);
        ++c->stats[6];
    }
    return 1;
}
static lean_object *delayed_gather(matrix_context *c,uint64_t first,uint64_t last,
        uint64_t inverse) {
    if(!matrix_work(c,last+1-first)) return NULL;
    uint64_t n=0;
    for(uint64_t col=first;col<=last;++col) if(delayed_read(c,col)%c->p) ++n;
    if(!matrix_charge(&c->stats[2],n,c->limits[3]) ||
       !matrix_bytes(c,n*(4+c->width)) || (inverse!=1 && !matrix_work(c,n))) return NULL;
    lean_object *cs=lean_alloc_sarray(1,(size_t)n*4,(size_t)n*4);
    lean_object *vs=lean_alloc_sarray(1,(size_t)n*c->width,(size_t)n*c->width);
    uint64_t i=0;
    for(uint64_t col=first;col<=last;++col) {
        uint64_t a=delayed_read(c,col)%c->p;
        delayed_write(c,col,0);
        if(a) {
            matrix_write(lean_sarray_cptr(cs)+(size_t)i*4,4,col);
            matrix_write(lean_sarray_cptr(vs)+(size_t)i*c->width,c->width,(a*inverse)%c->p);
            ++i;
        }
    }
    return matrix_row(cs,vs);
}

'''+s[idx:]
s=s.replace('''    if(c->binary) return matrix_scan_binary(c,first,last,leading,sugar);''','''    if(c->delayed) return delayed_scan(c,first,last,leading,sugar);
    if(c->binary) return matrix_scan_binary(c,first,last,leading,sugar);''',1)
s=s.replace('''    if(c->binary) return matrix_gather_binary(c,column,last);''','''    if(c->delayed) return delayed_gather(c,column,last,inverse);
    if(c->binary) return matrix_gather_binary(c,column,last);''',1)
s=s.replace('''if(sizeof(void*)!=8 || p<2 || p>=UINT64_C(2147483648) ||''','''if(sizeof(void*)!=8 || p<3 || p>65536 ||''',1)
s=s.replace('''    c.binary=p==2 && lean_ctor_get_uint8(limits,7*sizeof(void*)+1);''','''    c.binary=0;c.delayed=1;''',1)
s=s.replace('''if(c.columns>(c.binary?131072:4096) || nr>(c.binary?131072:1024) || nt>(c.binary?4096:64)) goto defer;''','''if(c.columns>131072 || nr>131072 || nt>4096) goto defer;
    if(c.columns && (p-1)*(p-1)>(UINT64_MAX-(p-1))/c.columns) goto defer;''',1)
s=s.replace('''    if(c.binary) c.scratch=(c.capacity+1)*c.words*8+16*c.capacity;''','''    if(c.delayed) c.scratch=(8-c.width)*c.columns+sizeof(delayed_pivot)*c.capacity;
    if(c.binary) c.scratch=(c.capacity+1)*c.words*8+16*c.capacity;''',1)
s=s.replace('''    if(bound>c.quantum) goto defer;''','''    if(bound>(UINT64_C(1)<<38)) goto defer;''',1)
s=s.replace('''    c.dense=matrix_zeros(c.binary?0:(size_t)c.columns*c.width);''','''    if(c.delayed) c.delayed_meta=matrix_zeros((size_t)c.capacity*sizeof(delayed_pivot));
    c.dense=matrix_zeros(c.binary?0:(size_t)c.columns*(c.delayed?8:c.width));''',1)
s=s.replace('''            for(size_t j=0;!c.project && j<n;++j) {''','''            /* Every nonempty target starts from zero, including after rows
               whose nonzero integers cancelled to zero residues. */
            if(c.delayed) memset(lean_sarray_cptr(c.dense),0,(size_t)c.columns*8);
            for(size_t j=0;!c.project && j<n;++j) {''',1)
s=s.replace('''                else matrix_write(lean_sarray_cptr(c.dense)+(size_t)col*c.width,c.width,
                    matrix_read(lean_sarray_cptr(vs)+j*c.width,c.width));''','''                else if(c.delayed) delayed_write(&c,col,matrix_read(lean_sarray_cptr(vs)+j*c.width,c.width));
                else matrix_write(lean_sarray_cptr(c.dense)+(size_t)col*c.width,c.width,
                    matrix_read(lean_sarray_cptr(vs)+j*c.width,c.width));''',1)
s=s.replace('''matrix_read(lean_sarray_cptr(c.dense)+(size_t)col*c.width,c.width),&inverse)''','''(c.delayed?delayed_read(&c,col)%c.p:
                        matrix_read(lean_sarray_cptr(c.dense)+(size_t)col*c.width,c.width)),&inverse)''',1)
Path('delayed.c').write_text(s)
