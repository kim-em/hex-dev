import HexGroebner.Elimination
import HexGroebnerStateNative
import Lean

namespace Replay
open Hex.Groebner
structure Input where
  field : PrimeField
  columns : Nat
  reducers : Array SparseRow
  targets : Array SparseRow
  sugars : Array Nat
  independent : Bool
  entries : Nat
structure Cursor where
  bytes : ByteArray
  offset : Nat := 8
abbrev Decode := StateT Cursor (Except String)

def natural : Decode Nat := do
  let s ← get
  if s.offset+8 > s.bytes.size then throw "truncated integer"
  let mut value := 0
  for i in [:8] do value := value+s.bytes[s.offset+i]!.toNat*2^(8*i)
  set { s with offset := s.offset+8 }
  return value

def chunk (n : Nat) : Decode ByteArray := do
  let s ← get
  if s.offset+n > s.bytes.size then throw "truncated row"
  let bytes := s.bytes.extract s.offset (s.offset+n)
  set { s with offset := s.offset+n }
  return bytes

def fieldOf (modulus : Nat) : Except String PrimeField := do
  if bound : modulus < 2^31 then
    if h : Hex.Nat.isPrimeTrial modulus = true then
      return ⟨modulus.toUInt64, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using
          Hex.Nat.isPrimeTrial_isPrime h, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using bound⟩
    else throw "nonprime modulus"
  else throw "unsupported modulus"

def decode : Decode Input := do
  let p ← natural
  let field ← match fieldOf p with
    | .ok f => pure f
    | .error e => throw e
  let columns ← natural
  let nr ← natural
  let nt ← natural
  let ns ← natural
  let independent ← natural
  let entries ← natural
  if columns > 131072 || nr > 131072 || nt > 4096 ||
      (ns != 0 && ns != nr+nt) || independent > 1 then throw "unsupported shape"
  let mut sugars := Array.emptyWithCapacity ns
  for _ in [:ns] do sugars := sugars.push (← natural)
  let mut rows := Array.emptyWithCapacity (nr+nt)
  let mut count := 0
  for _ in [:nr+nt] do
    let cb ← natural
    let vb ← natural
    if cb%4 != 0 || cb/4 > columns || vb != cb/4*field.width.bytes then
      throw "malformed packed row"
    let cols ← chunk cb
    let vals ← chunk vb
    rows := rows.push (⟨cols,vals⟩ : SparseRow)
    count := count+cb/4
  let state ← get
  if state.offset != state.bytes.size || count != entries then throw "matrix length mismatch"
  return ⟨field,columns,rows.extract 0 nr,rows.extract nr (nr+nt),sugars,
    independent == 1,entries⟩

def read (path : System.FilePath) : IO Input := do
  let bytes ← IO.FS.readBinFile path
  if String.fromUTF8! (bytes.extract 0 8) != "HXF4MAT1" then throw (IO.userError "matrix format mismatch")
  match decode.run { bytes := bytes } with
  | .error e => throw (IO.userError e)
  | .ok (input,_) => return input

def limits : MatrixLimits := {
  columns := 200000, rows := 200000,
  inputEntries := 2^50, outputEntries := 2^50,
  packedBytes := 2^50, work := 2^50, traceNodes := 2^50 }

@[export hex_replay_control]
def control (field : PrimeField) (limits : MatrixLimits) (columns : Nat)
    (reducers targets : Array SparseRow) (sugars : Array Nat) (independent : Bool) :
    Option Elimination.Result :=
  some (Elimination.run field limits columns reducers targets false sugars true independent)

def candidateShape (field : PrimeField) (limits : MatrixLimits) (columns : Nat)
    (reducers targets : Array SparseRow) (sugars : Array Nat) : Bool := Id.run do
  let p := field.modulus.toNat
  let rows := reducers.size+targets.size
  if USize.size != 2^64 || p < 3 || p > 65536 || columns > 131072 ||
      reducers.size > 131072 || targets.size > 4096 || columns > limits.columns ||
      rows > limits.rows || (!sugars.isEmpty && sugars.size != rows) ||
      !(sugars.all (· < USize.size/2)) then return false
  let workspace := columns*(field.width.bytes+4)
  if limits.work < 2*rows+workspace || limits.packedBytes < workspace then return false
  let mut entries := 0
  for group in [reducers,targets] do
    for row in group do
      if row.columns.size%4 != 0 || row.coefficients.size != row.size*field.width.bytes then return false
      entries := entries+row.size
  if entries > 2^33 then return false
  let bound := rows*65+2*entries+workspace+
    targets.size*(entries+(targets.size+3)*columns+64)+columns
  if bound > 2^38 then return false
  let mut seen := Array.replicate columns false
  for row in reducers do
    if row.size != 0 then
      let col := (Packed.read .u32 row.columns 0).toNat
      if col >= columns || seen[col]! then return false
      seen := seen.set! col true
  return true

def candidatePortable (field : PrimeField) (limits : MatrixLimits) (columns : Nat)
    (reducers targets : Array SparseRow) (sugars : Array Nat) (independent : Bool) :
    Option Elimination.Result :=
  if !(candidateShape field limits columns reducers targets sugars) then none else
    let r := Elimination.reference field limits columns reducers targets sugars independent
    let capacity := min (reducers.size+targets.size) columns
    let scratch := (8-field.width.bytes)*columns+40*capacity
    if r.result.isOk && r.stats.work ≤ 2^34 && r.stats.packedBytes+scratch ≤ limits.packedBytes
      then some r else none

@[extern "hex_replay_timed"]
def timed (choice : UInt8) (field : PrimeField) (limits : @& MatrixLimits) (columns : @& Nat)
    (reducers targets : @& Array SparseRow) (sugars : @& Array Nat) (independent : Bool) :
    IO (Option Elimination.Result × UInt64) := do
  let start ← IO.monoNanosNow
  let result := if choice == 0 then control field limits columns reducers targets sugars independent
    else candidatePortable field limits columns reducers targets sugars independent
  let stop ← IO.monoNanosNow
  return (result,(stop-start).toUInt64)

def same (a b : Elimination.Result) : Bool := Id.run do
  if a.stats != b.stats then return false
  match a.result,b.result with
  | .error a,.error b => return a == b
  | .ok (a,ar),.ok (b,br) =>
    if a.reducerRank != b.reducerRank || a.trace != b.trace ||
        a.rows.size != b.rows.size || ar.size != br.size then return false
    for i in [:a.rows.size] do
      let x := a.rows[i]!
      let y := b.rows[i]!
      if x.row.columns != y.row.columns || x.row.coefficients != y.row.coefficients ||
          x.fromTarget != y.fromTarget || x.derivation != y.derivation ||
          x.multiplier != y.multiplier || x.sugar != y.sugar then return false
    for i in [:ar.size] do
      let x := ar[i]!
      let y := br[i]!
      if x.row.columns != y.row.columns || x.row.coefficients != y.row.coefficients ||
          x.derivation != y.derivation || x.sugar != y.sugar then return false
    return true
  | _,_ => return false
end Replay
