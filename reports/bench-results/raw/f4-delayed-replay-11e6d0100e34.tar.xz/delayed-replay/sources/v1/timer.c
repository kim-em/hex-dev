#define _POSIX_C_SOURCE 200809L
#include <lean/lean.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
extern lean_obj_res hex_replay_control(uint64_t,lean_obj_arg,lean_obj_arg,
    lean_obj_arg,lean_obj_arg,lean_obj_arg,uint8_t);
extern lean_obj_res hex_replay_delayed(uint64_t,b_lean_obj_arg,b_lean_obj_arg,
    b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,uint8_t);
static uint64_t now_ns(void) {
    struct timespec t;if(clock_gettime(CLOCK_MONOTONIC_RAW,&t))abort();
    return (uint64_t)t.tv_sec*UINT64_C(1000000000)+(uint64_t)t.tv_nsec;
}
LEAN_EXPORT lean_obj_res hex_replay_timed(uint8_t choice,uint64_t p,
    b_lean_obj_arg limits,b_lean_obj_arg columns,b_lean_obj_arg reducers,
    b_lean_obj_arg targets,b_lean_obj_arg sugars,uint8_t independent) {
    lean_object *out;
    uint64_t begin=now_ns();
    if(!choice) {
        /* The exported Lean reference consumes these five object arguments. */
        lean_inc(limits);lean_inc(columns);lean_inc(reducers);lean_inc(targets);lean_inc(sugars);
        out=hex_replay_control(p,limits,columns,reducers,targets,sugars,independent);
    } else out=hex_replay_delayed(p,limits,columns,reducers,targets,sugars,independent);
    uint64_t elapsed=now_ns()-begin;
    lean_object *pair=lean_alloc_ctor(0,2,0);
    lean_ctor_set(pair,0,out);lean_ctor_set(pair,1,lean_box_uint64(elapsed));
    return lean_io_result_mk_ok(pair);
}
