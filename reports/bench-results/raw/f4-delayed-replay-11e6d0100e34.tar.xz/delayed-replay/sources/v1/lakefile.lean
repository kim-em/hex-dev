import Lake
open Lake DSL System
package F4Replay
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-bulk-scan"
lean_lib Replay

def objectO (pkg : Package) (name : String) : FetchM (Job FilePath) := do
  let source ← inputTextFile (pkg.dir / (name ++ ".c"))
  let header ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-bulk-scan/HexGroebner/ffi/matrix_runtime.h")
  let inputs := source.zipWith (fun s _ => s) header
  buildO (pkg.dir / defaultBuildDir / (name ++ ".o")) inputs
    #["-isystem", (← getLeanIncludeDir).toString,
      "-I/home/kim/worktrees/hex-dev/hex-dev-issue-10987-bulk-scan/HexGroebner/ffi"]
    #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING"]
    (compiler := FilePath.mk "/nix/store/2msw5nclhpsm80z65dqmjiv8kkras989-clang-wrapper-21.1.8/bin/clang")

target delayedO pkg : FilePath := objectO pkg "delayed"
target timerO pkg : FilePath := objectO pkg "timer"
lean_exe replay where
  root := `Main
  moreLinkObjs := #[delayedO,timerO]
