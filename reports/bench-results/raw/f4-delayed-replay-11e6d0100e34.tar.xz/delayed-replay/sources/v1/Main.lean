import Replay
open Hex.Groebner Lean

def main (args : List String) : IO UInt32 := do
  let [mode,path] := args | throw (IO.userError "replay reference|delayed matrix.bin")
  if mode != "reference" && mode != "delayed" then throw (IO.userError "unknown provider")
  let input ← Replay.read path
  let choice := if mode == "reference" then (0:UInt8) else 1
  let (actual,nanos) ← Replay.timed choice input.field Replay.limits input.columns
    input.reducers input.targets input.sugars input.independent
  let some result := actual | throw (IO.userError "provider declined")
  -- Independent full packed-output comparison is outside the timed call.
  let expected := Elimination.reference input.field Replay.limits input.columns
    input.reducers input.targets input.sugars input.independent
  let equal := Replay.same result expected
  let rowCount := match result.result with | .ok (e,_) => e.rows.size | .error _ => 0
  IO.println (Json.mkObj [
    ("kind",toJson "unchecked_matrix_candidate"),("provider",toJson mode),
    ("p",toJson input.field.modulus.toNat),("columns",toJson input.columns),
    ("reducers",toJson input.reducers.size),("targets",toJson input.targets.size),
    ("rows",toJson rowCount),("completeOutputAndCountersEqual",toJson equal),
    ("success",toJson result.result.isOk),("work",toJson result.stats.work),
    ("candidateNanos",toJson nanos.toNat),
    ("inputEntries",toJson result.stats.inputEntries),
    ("outputEntries",toJson result.stats.outputEntries)]).compress
  return if result.result.isOk && equal then 0 else 1
