from pathlib import Path
import struct,random,subprocess,json
s=Path('/home/kim/tmp/issue-10987');out=Path('/dev/shm/issue-10987-delayed-simd-random-v2');out.mkdir(exist_ok=False);rng=random.Random(10987);rows=[]
def u(x):return struct.pack('<Q',x)
for case in range(100):
 p=[3,251,257,65521][case%4];w=1 if p<256 else 2;cols=rng.choice([1,2,5,17,63,64,65,127,256]);nr=rng.randrange(min(cols,24)+1);nt=rng.randrange(1,18)
 heads=sorted(rng.sample(range(cols),nr));reducers=[]
 for h in heads:
  tail=sorted(rng.sample(range(h+1,cols),rng.randrange(min(cols-h-1,40)+1)))
  reducers.append([(h,1)]+[(x,rng.randrange(1,p))for x in tail])
 targets=[]
 for t in range(nt):
  if t and t%5==0:targets.append(list(targets[-1]));continue
  support=sorted(rng.sample(range(cols),rng.randrange(min(cols,64)+1)))
  targets.append([(x,rng.randrange(1,p))for x in support])
 independent=case%2;ns=nr+nt if case%3 else 0;allrows=reducers+targets
 b=b'HXF4MAT1'+b''.join(u(x)for x in[p,cols,nr,nt,ns,independent,sum(map(len,allrows))])+b''.join(u(rng.randrange(10000))for _ in range(ns))
 for row in allrows:
  cb=b''.join(struct.pack('<I',x)for x,a in row);vb=b''.join(a.to_bytes(w,'little')for x,a in row);b+=u(len(cb))+u(len(vb))+cb+vb
 path=out/f'{case:03d}.bin';path.write_bytes(b)
 r=subprocess.run([str(s/'matrix-replay/.lake/build/bin/replay'),'delayed',str(path)],capture_output=True,text=True)
 (out/f'{case:03d}.stdout').write_text(r.stdout);(out/f'{case:03d}.stderr').write_text(r.stderr)
 result=json.loads(r.stdout)if r.returncode==0 else None;rows.append(dict(case=case,exit=r.returncode,result=result))
 (out/'status.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert r.returncode==0,(case,r.stderr)
print('PASS',len(rows),'seeded complete output/counter comparisons')
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
