from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');name='f4-performance-audit-ec583f66a7';payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
native=json.loads((state/'performance-pr19-final-native-status.json').read_text());checks=json.loads((state/'performance-pr19-static-status.json').read_text());assert len(native)==2 and len(checks)==6 and all(x['exit_code']==0 for x in native+checks)
for directory in ['performance-pr19-final-clang','performance-pr19-final-gcc','performance-pr19-clang']:
 for p in sorted((state/directory).rglob('*')):
  if p.is_file() and '.lake' not in p.relative_to(state/directory).parts:add('validation/'+directory+'/'+str(p.relative_to(state/directory)),p.read_bytes())
for pattern in ['performance-pr19*.py','performance-pr19*.json','performance-pr19*.log','performance-report-audit-negative.*']:
 for p in sorted(state.glob(pattern)):
  if p.is_file():add('reproduction/'+p.name,p.read_bytes())
base='81e3490e71d17939bfc9e7ab790bb7078dd05ca2';current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();add('source.patch',subprocess.check_output(['git','diff','--binary',base,current,'--','.',':!reports'],cwd=root));add('source-base.txt',(base+'\n').encode())
import sys
sys.path.insert(0,str(root));from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing,fingerprint
listing=tree_listing(FAMILY,current);manifest=json.loads((state/'performance-final-production/manifest.json').read_text());assert listing==manifest['source_manifest'];add('runtime-source-audit.json',(json.dumps(dict(commit=current,runtime_source_fingerprint=fingerprint(listing),runtime_manifest_identical=True,fresh_build_manifest_commit=manifest['commit'],binary_sha256=manifest['binary_sha256'],changes_since_build=subprocess.check_output(['git','diff','--name-only',manifest['commit'],current],cwd=root,text=True).splitlines(),scope='Runtime source family exactly matches the fresh CLI identity build. Expanded test/harness/analysis/documentation changes are recorded separately; the full nine-stage project run at 65884c900e reuses Lake artifacts.'),indent=2)+'\n').encode())
add('archive.py',Path(__file__).read_bytes());add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest() for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/'performance-pr19-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
