from pathlib import Path
import importlib.util,json,tempfile
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');state=Path('/home/kim/tmp/issue-10987');source=state/'combined-performance-production/before-after-selected'
spec=importlib.util.spec_from_file_location('audit',root/'scripts/bench/groebner_performance_audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
results=[]
for kind in ['statistics','scheduling','duplicate','output']:
 with tempfile.TemporaryDirectory(dir=state,prefix='report-negative-') as directory:
  target=Path(directory)
  for p in source.iterdir():
   if p.is_file(): (target/p.name).symlink_to(p)
  metadata=json.loads((source/'metadata.json').read_text())
  if kind=='statistics':metadata['samples'][0]['statistics']['rounds']+=1
  if kind=='scheduling':metadata['samples'][0]['scheduling']='sugar'
  if kind=='duplicate':metadata['samples'][1]['arm']='A'
  if kind=='output':
   path=target/'cyclic7-15-b0-B.stdout';value=json.loads(path.read_text());value['statistics']['rounds']+=1;path.unlink();path.write_text(json.dumps(value))
  (target/'metadata.json').unlink();(target/'metadata.json').write_text(json.dumps(metadata))
  try:audit.campaign(target)
  except ValueError as error:results.append(dict(mutation=kind,rejected=True,message=str(error)))
  else:raise RuntimeError('missed mutation '+kind)
(state/'performance-report-audit-negative.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
