import HexGroebner.Packed

open Hex.Groebner

namespace MetadataTest

def reference (bytes : @& ByteArray) (index : Nat) : UInt64 :=
  Packed.read .u32 bytes index ||| (Packed.read .u32 bytes (index+1) <<< 32)

def checked (bytes : @& ByteArray) (index : Nat) : UInt64 :=
  let offset := index*4
  if h : offset+8 ≤ bytes.size then
    let low := (bytes[offset]'(by omega)).toUInt64 |||
      ((bytes[offset+1]'(by omega)).toUInt64 <<< 8) |||
      ((bytes[offset+2]'(by omega)).toUInt64 <<< 16) |||
      ((bytes[offset+3]'(by omega)).toUInt64 <<< 24)
    let high := (bytes[offset+4]'(by omega)).toUInt64 |||
      ((bytes[offset+5]'(by omega)).toUInt64 <<< 8) |||
      ((bytes[offset+6]'(by omega)).toUInt64 <<< 16) |||
      ((bytes[offset+7]'(by omega)).toUInt64 <<< 24)
    low ||| (high <<< 32)
  else reference bytes index

theorem checked_eq (bytes : ByteArray) (index : Nat) :
    checked bytes index = reference bytes index := by
  unfold checked
  dsimp only
  split
  · rename_i h
    have h0 : index*4 < bytes.size := by omega
    have h1 : index*4+1 < bytes.size := by omega
    have h2 : index*4+2 < bytes.size := by omega
    have h3 : index*4+3 < bytes.size := by omega
    have h4 : index*4+4 < bytes.size := by omega
    have h5 : index*4+5 < bytes.size := by omega
    have h6 : index*4+6 < bytes.size := by omega
    have h7 : index*4+7 < bytes.size := by omega
    simp [reference,Packed.read,Width.bytes,Nat.add_mul,Nat.add_assoc,h0,h1,h2,h3,h4,h5,h6,h7]
  · rfl

example : checked ⟨#[255,255,255,255,255,255,255,255]⟩ 0 = 18446744073709551615 := by decide +kernel

#print axioms checked_eq
end MetadataTest
