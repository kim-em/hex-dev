import CheckedWord

open Hex.Groebner
namespace MetadataTest

theorem offset_eq (base step : Nat) (h : base+step < USize.size) :
    (USize.ofNat base + USize.ofNat step).toNat = base+step := by
  rw [USize.toNat_add,
    USize.toNat_ofNat_of_lt' (by omega : base < USize.size),
    USize.toNat_ofNat_of_lt' (by omega : step < USize.size)]
  exact Nat.mod_eq_of_lt h

def wordU (bytes : @& ByteArray) (index : Nat) : UInt64 :=
  let offset := index*4
  if h : offset+8 ≤ bytes.size ∧ offset+8 ≤ USize.size then
    let pos := USize.ofNat offset
    have boundAt (i : Nat) (hi : i < 8) : (pos+USize.ofNat i).toNat < bytes.size := by
      dsimp only [pos]
      rw [offset_eq _ _ (by omega)]
      omega
    let low := (bytes.uget (pos+USize.ofNat 0) (boundAt 0 (by decide))).toUInt64 |||
      ((bytes.uget (pos+USize.ofNat 1) (boundAt 1 (by decide))).toUInt64 <<< 8) |||
      ((bytes.uget (pos+USize.ofNat 2) (boundAt 2 (by decide))).toUInt64 <<< 16) |||
      ((bytes.uget (pos+USize.ofNat 3) (boundAt 3 (by decide))).toUInt64 <<< 24)
    let high := (bytes.uget (pos+USize.ofNat 4) (boundAt 4 (by decide))).toUInt64 |||
      ((bytes.uget (pos+USize.ofNat 5) (boundAt 5 (by decide))).toUInt64 <<< 8) |||
      ((bytes.uget (pos+USize.ofNat 6) (boundAt 6 (by decide))).toUInt64 <<< 16) |||
      ((bytes.uget (pos+USize.ofNat 7) (boundAt 7 (by decide))).toUInt64 <<< 24)
    low ||| (high <<< 32)
  else reference bytes index

theorem wordU_eq (bytes : ByteArray) (index : Nat) :
    wordU bytes index = reference bytes index := by
  cases bytes with
  | mk data =>
    unfold wordU
    dsimp only
    split
    · rename_i h
      have h0 : index*4 < data.size := by simpa [ByteArray.size] using (show index*4 < (ByteArray.mk data).size by omega)
      have h1 : index*4+1 < data.size := by simpa [ByteArray.size] using (show index*4+1 < (ByteArray.mk data).size by omega)
      have h2 : index*4+2 < data.size := by simpa [ByteArray.size] using (show index*4+2 < (ByteArray.mk data).size by omega)
      have h3 : index*4+3 < data.size := by simpa [ByteArray.size] using (show index*4+3 < (ByteArray.mk data).size by omega)
      have h4 : index*4+4 < data.size := by simpa [ByteArray.size] using (show index*4+4 < (ByteArray.mk data).size by omega)
      have h5 : index*4+5 < data.size := by simpa [ByteArray.size] using (show index*4+5 < (ByteArray.mk data).size by omega)
      have h6 : index*4+6 < data.size := by simpa [ByteArray.size] using (show index*4+6 < (ByteArray.mk data).size by omega)
      have h7 : index*4+7 < data.size := by simpa [ByteArray.size] using (show index*4+7 < (ByteArray.mk data).size by omega)
      have j0 := offset_eq (index*4) 0 (by omega)
      have j1 := offset_eq (index*4) 1 (by omega)
      have j2 := offset_eq (index*4) 2 (by omega)
      have j3 := offset_eq (index*4) 3 (by omega)
      have j4 := offset_eq (index*4) 4 (by omega)
      have j5 := offset_eq (index*4) 5 (by omega)
      have j6 := offset_eq (index*4) 6 (by omega)
      have j7 := offset_eq (index*4) 7 (by omega)
      have mod_eq (i : Nat) (hi : i < 8) :
          (index*4+i) % (2^System.Platform.numBits) = index*4+i := by
        exact Nat.mod_eq_of_lt (show index*4+i < USize.size by omega)
      simp only [reference,Packed.read,Width.bytes,ByteArray.uget,Array.ugetElem_eq_getElem,
        ByteArray.size,ByteArray.getElem_eq_getElem_data,Nat.add_mul,Nat.one_mul,
        Nat.add_assoc,Nat.add_zero,Nat.reduceAdd,j0,j1,j2,j3,j4,j5,j6,j7,h0,h1,h2,h3,h4,h5,h6,h7,
        getElem!_pos]
    · rfl

example : wordU ⟨#[255,255,255,255,255,255,255,255]⟩ 0 = 18446744073709551615 := by
  rw [wordU_eq]
  decide +kernel

#print axioms wordU_eq
end MetadataTest
