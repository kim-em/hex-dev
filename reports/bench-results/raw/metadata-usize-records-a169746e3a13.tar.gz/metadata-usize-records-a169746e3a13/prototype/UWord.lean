import CheckedWord

open Hex.Groebner
namespace MetadataTest

theorem offset_eq (base step : Nat) (h : base+step < USize.size) :
    (USize.ofNat base + USize.ofNat step).toNat = base+step := by
  rw [USize.toNat_add,
    USize.toNat_ofNat_of_lt' (by omega : base < USize.size),
    USize.toNat_ofNat_of_lt' (by omega : step < USize.size)]
  exact Nat.mod_eq_of_lt h

def wordU (bytes : @& ByteArray) (index : Nat) : UInt64 :=
  let offset := index*4
  if h : offset+8 ≤ bytes.size ∧ offset+8 ≤ USize.size then
    let pos := USize.ofNat offset
    have boundAt (i : Nat) (hi : i < 8) : (pos+USize.ofNat i).toNat < bytes.size := by
      dsimp only [pos]
      rw [offset_eq _ _ (by omega)]
      omega
    let low := (bytes.uget (pos+USize.ofNat 0) (boundAt 0 (by decide))).toUInt64 |||
      ((bytes.uget (pos+USize.ofNat 1) (boundAt 1 (by decide))).toUInt64 <<< 8) |||
      ((bytes.uget (pos+USize.ofNat 2) (boundAt 2 (by decide))).toUInt64 <<< 16) |||
      ((bytes.uget (pos+USize.ofNat 3) (boundAt 3 (by decide))).toUInt64 <<< 24)
    let high := (bytes.uget (pos+USize.ofNat 4) (boundAt 4 (by decide))).toUInt64 |||
      ((bytes.uget (pos+USize.ofNat 5) (boundAt 5 (by decide))).toUInt64 <<< 8) |||
      ((bytes.uget (pos+USize.ofNat 6) (boundAt 6 (by decide))).toUInt64 <<< 16) |||
      ((bytes.uget (pos+USize.ofNat 7) (boundAt 7 (by decide))).toUInt64 <<< 24)
    low ||| (high <<< 32)
  else reference bytes index

theorem wordU_eq (bytes : ByteArray) (index : Nat) :
    wordU bytes index = reference bytes index := by
  cases bytes with
  | mk data =>
    unfold wordU
    dsimp only
    split
    · rename_i h
      simp only [ByteArray.size] at h
      have index_eq (i : Nat) (hi : i < 8) :
          (USize.ofNat (index*4)+USize.ofNat i).toNat = index*4+i :=
        offset_eq _ _ (by omega)
      simp (disch := (simp only [ByteArray.size] <;> omega)) only [reference,Packed.read,Width.bytes,ByteArray.uget,
        Array.ugetElem_eq_getElem,ByteArray.size,ByteArray.getElem_eq_getElem_data,
        Nat.add_mul,Nat.one_mul,Nat.add_assoc,Nat.add_zero,Nat.reduceAdd,
        index_eq 0 (by decide),index_eq 1 (by decide),index_eq 2 (by decide),index_eq 3 (by decide),
        index_eq 4 (by decide),index_eq 5 (by decide),index_eq 6 (by decide),index_eq 7 (by decide),
        getElem!_pos]
    · rfl

example : wordU ⟨#[255,255,255,255,255,255,255,255]⟩ 0 = 18446744073709551615 := by
  rw [wordU_eq]
  decide +kernel

#print axioms wordU_eq
end MetadataTest
