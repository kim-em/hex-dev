#if defined(__linux__) && !defined(_GNU_SOURCE)
#define _GNU_SOURCE
#endif
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "matrix_simd.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#if HEX_GROEBNER_AVX2
#include <sys/mman.h>
#include <unistd.h>
static uint64_t rng=UINT64_C(0x6390743202398481);
static uint32_t random32(void) {rng^=rng<<13;rng^=rng>>7;rng^=rng<<17;return (uint32_t)rng;}
static unsigned width(uint32_t p) {return p<=256?1:p<=65536?2:4;}
static uint32_t read_value(const uint8_t *b,unsigned w,unsigned i) {uint32_t v=0;memcpy(&v,b+(size_t)i*w,w);return v;}
static void write_value(uint8_t *b,unsigned w,unsigned i,uint32_t v) {memcpy(b+(size_t)i*w,&v,w);}
struct guarded {uint8_t *mapping,*data;size_t page;};
static struct guarded guarded(size_t bytes,unsigned end) {
 long length=sysconf(_SC_PAGESIZE);assert(length>0 && bytes<=(size_t)length);size_t page=(size_t)length;
 uint8_t *mapping=mmap(NULL,3*page,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(mapping!=MAP_FAILED);
 assert(mprotect(mapping+page,page,PROT_READ|PROT_WRITE)==0);
 return (struct guarded){mapping,end?mapping+2*page-bytes:mapping+page,page};
}
static void release(struct guarded b) {assert(munmap(b.mapping,3*b.page)==0);}
__attribute__((target("avx2")))
static void check(uint32_t p,uint32_t factor,unsigned stride,unsigned padding,unsigned end) {
 unsigned w=width(p);struct guarded d=guarded(128*w,end),c=guarded(16*4,end),v=guarded(16*w,end);
 uint8_t expected[128*4],before[128*4];uint32_t columns[16],coefficients[16];
 for(unsigned i=0;i<128;++i) write_value(d.data,w,i,i%3==0?0:i%3==1?p-1:random32()%p);
 for(unsigned i=0;i<16;++i) {columns[i]=127-padding-(15-i)*stride;coefficients[i]=i%3==0?1:i%3==1?p-1:random32()%(p-1)+1;write_value(v.data,w,i,coefficients[i]);}
 memcpy(c.data,columns,sizeof(columns));memcpy(expected,d.data,128*w);
 uint32_t inverse=hex_mont32_inverse(p),f=(uint32_t)(((uint64_t)factor<<32)%p);
 assert((uint32_t)(inverse*p)==UINT32_MAX);
 for(unsigned entry=0;entry<16;entry+=8) {
  memcpy(before,d.data,128*w);
  unsigned n=hex_scan8(d.data,c.data,v.data,entry,128,p,f,inverse,w);
  unsigned should= (stride==1 || w==4 || 128-columns[entry+7]>=4/w)?8:0;
  assert(n==should);
  if(n) for(unsigned i=entry;i<entry+8;++i) {
   uint32_t a=read_value(expected,w,columns[i]);uint64_t product=(uint64_t)factor*coefficients[i]%p;
   write_value(expected,w,columns[i],(uint32_t)((a+(uint64_t)p-product)%p));
  } else assert(memcmp(before,d.data,128*w)==0);
  assert(memcmp(expected,d.data,128*w)==0);
 }
 for(unsigned bad=0;bad<8;++bad) {
  uint32_t saved=coefficients[bad];write_value(v.data,w,bad,p);memcpy(before,d.data,128*w);
  assert(hex_scan8(d.data,c.data,v.data,0,128,p,f,inverse,w)==0);assert(memcmp(before,d.data,128*w)==0);write_value(v.data,w,bad,saved);
  saved=read_value(d.data,w,columns[bad]);write_value(d.data,w,columns[bad],p);memcpy(before,d.data,128*w);
  assert(hex_scan8(d.data,c.data,v.data,0,128,p,f,inverse,w)==0);assert(memcmp(before,d.data,128*w)==0);write_value(d.data,w,columns[bad],saved);
 }
 columns[15]=128;memcpy(c.data,columns,sizeof(columns));memcpy(before,d.data,128*w);
 assert(hex_scan8(d.data,c.data,v.data,8,128,p,f,inverse,w)==0);assert(memcmp(before,d.data,128*w)==0);
 release(d);release(c);release(v);
}
#endif
int main(void) {
#if HEX_GROEBNER_AVX2
 if(hex_avx2_available()) {
  uint32_t fields[]={3,5,127,251,257,32003,65521,65537,1000000007,2147483647};
  for(unsigned i=0;i<sizeof(fields)/sizeof(fields[0]);++i) {
   uint32_t p=fields[i];
   for(unsigned stride=1;stride<=8;++stride) for(unsigned pad=0;pad<=4;++pad) for(unsigned end=0;end<2;++end) {
    check(p,0,stride,pad,end);check(p,1,stride,pad,end);check(p,p-1,stride,pad,end);check(p,random32()%p,stride,pad,end);
   }
  }
  puts("all widths, scalar arithmetic oracle, contiguous/strided guard-page boundaries and malformed-prefix preservation passed");return 0;
 }
#endif
 return 1;
}
