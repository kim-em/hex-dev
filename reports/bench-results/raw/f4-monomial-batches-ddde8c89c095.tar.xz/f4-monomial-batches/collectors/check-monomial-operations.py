from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
s=Path('/home/kim/tmp/issue-10987');old=s/'products-deferral-audit';out=s/'monomial-operation-audit';out.mkdir(exist_ok=False)
sys.path.insert(0,str(Path.cwd()));from scripts.bench.groebner_checks import source_identity
identity=source_identity();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in old.iterdir():
 if p.is_file()and p.suffix in ['.lean','.json','.c']or p.name=='lean-toolchain':
  if p.name not in ['status.json','source-hashes.json']:shutil.copy2(p,out/p.name)
(out/'.lake').mkdir();(out/'.lake/packages').symlink_to(old/'.lake/packages',target_is_directory=True)
subprocess.run(['cp','-a','--reflink=auto',str(old/'.lake/build'),str(out/'.lake/build')],check=True)
p=out/'probe.c';t=p.read_text();needle=' return hex_test_combine_owned(table,operation,a,b,max_count,max_bytes,max_work,native);';assert t.count(needle)==1
block='''static uint64_t operation_counts[3][5]={{0}};
'''
t=t.replace('__typeof__(hex_test_combine_owned) __wrap_lean_hex_groebner_combine_owned;',block+'__typeof__(hex_test_combine_owned) __wrap_lean_hex_groebner_combine_owned;',1)
t=t.replace(needle,''' uint64_t old_count=0,old_work=0;
 if(operation<3) {
  ++operation_counts[operation][0];
  if(lean_is_scalar(lean_ctor_get(table,3)))old_count=lean_unbox(lean_ctor_get(table,3));
  if(lean_is_scalar(lean_ctor_get(table,7)))old_work=lean_unbox(lean_ctor_get(table,7));
 }
 lean_object *result=hex_test_combine_owned(table,operation,a,b,max_count,max_bytes,max_work,native);
 if(operation<3) {
  if(lean_obj_tag(result)==0) {
   ++operation_counts[operation][1];
   lean_object *updated=lean_ctor_get(lean_ctor_get(result,0),1);
   if(lean_is_scalar(lean_ctor_get(updated,3)))operation_counts[operation][2]+=lean_unbox(lean_ctor_get(updated,3))-old_count;
   if(lean_is_scalar(lean_ctor_get(updated,7)))operation_counts[operation][3]+=lean_unbox(lean_ctor_get(updated,7))-old_work;
  } else ++operation_counts[operation][4];
 }
 return result;''',1)
t+='''\nLEAN_EXPORT lean_obj_res hex_audit_operations(lean_obj_arg world) {
 (void)world;lean_object *out=lean_mk_empty_array_with_capacity(lean_box(3));
 for(unsigned op=0;op<3;++op) {
  lean_object *row=lean_mk_empty_array_with_capacity(lean_box(5));
  for(unsigned i=0;i<5;++i)row=lean_array_push(row,lean_box_uint64(operation_counts[op][i]));
  out=lean_array_push(out,row);
 }
 return lean_io_result_mk_ok(out);
}\n''';p.write_text(t)
p=out/'Usage.lean';t=p.read_text().replace('def main (args', '@[extern "hex_audit_operations"] opaque operations : IO (Array (Array UInt64))\ndef main (args',1).replace('  let fallback ← fallbackTerms','  let fallback ← fallbackTerms\n  let counts ← operations',1).replace('("batchHits",Lean.toJson hits)','("operations",Lean.toJson counts),("batchHits",Lean.toJson hits)',1);p.write_text(t)
source_hashes={p.name:sha(p)for p in out.iterdir()if p.is_file()};(out/'source-hashes.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1',LEAN_ABORT_ON_NONLINEAR='1',TMPDIR=str(s))
with(out/'build.log').open('w')as log:r=subprocess.run(['lake','build','usage'],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
exe=out/'.lake/build/bin/usage';binary_hash=sha(exe);records=[]
for original in json.loads((old/'status.json').read_text())['records']:
 name=original['case'];command=[str(exe)if x==str(old/'.lake/build/bin/usage')else x for x in original['command']];assert str(exe)in command and source_identity()==identity
 r=subprocess.run(command,env=env,capture_output=True);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 actual=json.loads(r.stdout);expected=json.loads((old/(name+'.stdout')).read_text());actual.pop('candidateNanos');expected.pop('candidateNanos');assert r.returncode==0 and actual==expected
 counters=json.loads(r.stderr.decode().splitlines()[-1]);ops=[[int(x)for x in row]for row in counters.pop('operations')];counters={k:int(v)for k,v in counters.items()}
 assert counters==original['counters']and all(row[0]==row[1]+row[4]for row in ops)
 records.append(dict(case=name,suite=original['suite'],command=command,exit_code=r.returncode,basis_and_counters_equal=True,counters=counters,operations=ops,operation_columns=['calls','accepted','inserted','charged_work','deferred'],**identity))
 (out/'status.json').write_text(json.dumps(dict(binary_sha256=binary_hash,binary_sha256_after=sha(exe),sources_sha256=source_hashes,records=records,scope='Untimed sanitizedNative counters, opcode orderLCM/product/quotient; allcompletebasesandlogicalcounters comparedwithretainedproducts-deferral audit. No timing claim.'),indent=2)+'\n')
 print(name,ops,flush=True)
assert source_identity()==identity and sha(exe)==binary_hash
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
