import os,subprocess,json,time,sys
from pathlib import Path
state=Path('/home/kim/tmp/issue-10987');results=[];sys.path.insert(0,str(Path.cwd()))
from scripts.bench.groebner_checks import source_identity
identity=source_identity()
for name,compiler in [('clang','/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang'),('gcc','/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/gcc')]:
 assert source_identity()==identity
 env=dict(os.environ,LEAN_CC=str(state/'issue-10987-lean-cc'),CC=compiler,HEX_GROEBNER_SANITIZE='1',HEX_GROEBNER_REQUIRE_AVX2='1',HEX_GROEBNER_TEST_LOADER='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2',HEX_GROEBNER_TEST_LIBRARY_PATH='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib',HEX_GROEBNER_NATIVE_LOG_DIR=str(state/f'trie-format-{name}'),TMPDIR=str(state))
 start=time.monotonic()
 with (state/f'trie-format-{name}.log').open('w')as log:r=subprocess.run(['bash','scripts/ci/check_groebner_rows.sh'],env=env,stdout=log,stderr=subprocess.STDOUT)
 assert source_identity()==identity
 results.append(dict(compiler=compiler,name=name,exit_code=r.returncode,seconds=time.monotonic()-start,variants=['Native','Scalar','Remainder','ScalarRemainder'],sanitize=['address','undefined'],test_log_dir=env['HEX_GROEBNER_NATIVE_LOG_DIR'],**identity));(state/'trie-format-native-status.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
