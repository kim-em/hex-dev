/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

import HexGroebner

namespace Hex.Groebner.TrieConformance
open Computation

private def field : PrimeField := ⟨7,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
private def limits : Limits := { work := 1000000000,packedBytes := 1000000000 }

private def equal (a b : Except ComputeError (Option Nat)) : Bool :=
  match a,b with
  | .ok a,.ok b => a == b
  | .error a,.error b => a == b
  | _,_ => false

/-- Compare every lookup and its exhausted prefix against the original node
traversal, and compare native calls directly with the packed portable model. -/
def runtimeChecks (seed : Nat) : Bool := Id.run do
  for n in [0,1,3,7,65,513,2047,4097] do
    for base in [1,257,65537] do
      let context : Context := ⟨field,n,.grevlex⟩
      let trial : Computation Bool := do
        let mut basis : Array BasisElement := #[]
        for k in [:4] do
          let exponents := (Array.range n).map fun i => base+(k+i)%3
          let p ← Polynomial.normalize context limits k #[⟨exponents,1⟩]
          basis := basis.push ⟨p,0⟩
        let index ← ReducerIndex.build context limits basis
        if n ≤ 2047 && index.packed.isNone then return false
        if n > 4096 && index.packed.isSome then return false
        for k in [:5] do
          let values := (Array.range n).map fun i => (base+(k+2*i+seed)%4).toUInt64
          let monomial ← intern limits values
          let state ← get
          let (plain,plainWork) := ReducerIndex.findPortable context index basis state.table monomial
            state.statistics.work limits.work false
          let (pruned,prunedWork) := ReducerIndex.findPortable context index basis state.table monomial
            state.statistics.work limits.work
          if !equal plain pruned || prunedWork > plainWork then return false
          for allowance in [0,1,2,5,17,1000,4096,100000,2^90] do
            let budget := { limits with work := state.statistics.work+allowance }
            let (expected,work) := ReducerIndex.findPortable context index basis state.table monomial
              state.statistics.work budget.work
            let (actual,next) := (index.find context budget basis monomial).run state
            if !equal actual expected || next.statistics.work != work then return false
            if let some view := index.packed then
              let a := Native.Trie.lookup view state.table.width.bytes.toUInt8 state.table.count.toUInt64
                monomial.toUInt64 state.table.exponents state.table.metadata (min allowance 32768).toUInt64
              let b := Native.Trie.lookupPortable view state.table.width.bytes.toUInt8 state.table.count.toUInt64
                monomial.toUInt64 state.table.exponents state.table.metadata (min allowance 32768).toUInt64
              if a.status == 3 || a.reducer != b.reducer || a.work != b.work || a.status != b.status then return false
        return true
      match trial.run ⟨{arity := n},{}⟩ with
      | (.ok true,_) => pure ()
      | _ => return false
  return true

/-- A 2048-node chain exercises the previous format boundary and 4095 units. -/
def boundaryChecks : Bool := Id.run do
  let context : Context := ⟨field,2047,.grevlex⟩
  let trial : Computation Bool := do
    let p ← Polynomial.normalize context limits 0 #[⟨Array.replicate 2047 65537,1⟩]
    let basis := #[BasisElement.mk p 0]
    let index ← ReducerIndex.build context limits basis
    let some view := index.packed | return false
    if index.nodes.size != 2048 then return false
    if Native.Trie.valid view.arity view.nodes view.edges view.maxLeading !=
        Native.Trie.validPortable view.arity view.nodes view.edges view.maxLeading then return false
    let state ← get
    let monomial := p.monomial 0
    for allowance in [0,1,2,3,4093,4094,4095,4096,2^90] do
      let a := Native.Trie.lookup view 4 state.table.count.toUInt64 monomial.toUInt64
        state.table.exponents state.table.metadata (min allowance 32768).toUInt64
      let b := Native.Trie.lookupPortable view 4 state.table.count.toUInt64 monomial.toUInt64
        state.table.exponents state.table.metadata (min allowance 32768).toUInt64
      if a.status == 3 || a.reducer != b.reducer || a.work != b.work || a.status != b.status then return false
      if allowance ≥ 4095 && (a.status != 1 || a.work != 4095 || a.reducer != some 0) then return false
    for viewData in [view.nodes.extract 0 (view.nodes.size-1),
        Native.write view.nodes 4 0 1,Native.write view.nodes 4 4 1,
        Native.write view.nodes 4 8 2,Native.write view.nodes 4 12 1,
        Native.write view.nodes 4 (24*(index.nodes.size-1)+16) 0,
        Native.write view.nodes 4 (24*(index.nodes.size-1)+20) (view.maxLeading.toNat+1),
        Native.write view.nodes 4 28 0,Native.write view.nodes 4 40 0,
        Native.write view.nodes 4 40 2,Native.write view.nodes 4 16 2] do
      if (Native.Trie.View.check view.arity viewData view.edges view.maxLeading).isSome then return false
      if Native.Trie.valid view.arity viewData view.edges view.maxLeading !=
          Native.Trie.validPortable view.arity viewData view.edges view.maxLeading then return false
    for links in [view.edges.extract 0 (view.edges.size-8),
        view.edges.extract 0 (view.edges.size-1),
        Native.write view.edges 4 4 0,Native.write view.edges 4 4 2048,
        Native.write view.edges 4 12 1] do
      if (Native.Trie.View.check view.arity view.nodes links view.maxLeading).isSome then return false
      if Native.Trie.valid view.arity view.nodes links view.maxLeading !=
          Native.Trie.validPortable view.arity view.nodes links view.maxLeading then return false
    for arity in [0,1,2047,4097,2^90] do
      for maximum in [0,1,4294967295,4294967296,18446744073709551615] do
        if Native.Trie.valid arity view.nodes view.edges maximum !=
            Native.Trie.validPortable arity view.nodes view.edges maximum then return false
    for arena in [state.table.exponents.extract 0 (state.table.exponents.size-1),{}] do
      let a := Native.Trie.lookup view 4 state.table.count.toUInt64 monomial.toUInt64
        arena state.table.metadata 4096
      let b := Native.Trie.lookupPortable view 4 state.table.count.toUInt64 monomial.toUInt64
        arena state.table.metadata 4096
      if a.status != 3 || a.reducer != b.reducer || a.work != b.work || a.status != b.status then return false
    return true
  match trial.run ⟨{arity := 2047},{}⟩ with
  | (.ok true,_) => return true
  | _ => return false

/-- Large views run natively within the format-wide quantum. Every parent
allowance has the exact portable prefix without discarded traversal work. -/
def largeChecks : Bool := Id.run do
  let context : Context := ⟨field,1,.grevlex⟩
  let trial : Computation Bool := do
    let mut basis : Array BasisElement := #[]
    for k in [:2100] do
      let p ← Polynomial.normalize context limits k #[⟨#[k],1⟩]
      basis := basis.push ⟨p,0⟩
    let index ← ReducerIndex.build context limits basis
    let some view := index.packed | return false
    if index.nodes.size != 2101 then return false
    if Native.Trie.valid view.arity view.nodes view.edges view.maxLeading !=
        Native.Trie.validPortable view.arity view.nodes view.edges view.maxLeading then return false
    let state ← get
    for query in [0,2000,2099] do
      let monomial := basis[query]!.polynomial.monomial 0
      for allowance in [0,1,2099,2100,2101,2102,4095,4096,4200,4201,32767,32768,100000,2^90] do
        let raw := Native.Trie.lookup view state.table.width.bytes.toUInt8 state.table.count.toUInt64 monomial.toUInt64
          state.table.exponents state.table.metadata (min allowance 32768).toUInt64
        let model := Native.Trie.lookupPortable view state.table.width.bytes.toUInt8 state.table.count.toUInt64 monomial.toUInt64
          state.table.exponents state.table.metadata (min allowance 32768).toUInt64
        if raw.reducer != model.reducer || raw.work != model.work || raw.status != model.status then return false
        if raw.status == 3 then return false
        let budget := { limits with work := state.statistics.work+allowance }
        let (expected, work) := ReducerIndex.findPortable context index basis state.table monomial
          state.statistics.work budget.work
        let (actual, next) := (index.find context budget basis monomial).run state
        if !equal actual expected || next.statistics.work != work then return false
        if allowance ≥ 100000 && !equal actual (.ok (some query)) then return false
    return true
  match trial.run ⟨{arity := 1},{}⟩ with
  | (.ok true,_) => return true
  | _ => return false

/-- Malformed cached bounds agree in C and Lean: understated/overstated
minima, unknown descendants, empty cached branches and unkeyed terminal nodes. -/
def cacheChecks (seed : Nat) : Bool := Id.run do
  let pack (words : Array Nat) := words.foldl (fun bytes n => Packed.push .u32 bytes n.toUInt64) {}
  let priority := 2+seed%3
  let nodes := pack #[0,0,1,0,priority,0, 1,1,0,1,priority,0]
  let edges := pack #[0,1]
  if !Native.Trie.valid 1 nodes edges 0 || !Native.Trie.validPortable 1 nodes edges 0 then return false
  for bytes in [Native.write nodes 4 16 (priority-1), Native.write nodes 4 16 (priority+1),
      Native.write nodes 4 40 0, Native.write nodes 4 36 0] do
    let a := Native.Trie.valid 1 bytes edges 0
    let b := Native.Trie.validPortable 1 bytes edges 0
    if a || a != b then return false
  let empty := pack #[0,0,1,0,0,0, 1,1,0,0,0,0]
  for arity in [1,2] do
    if !Native.Trie.valid arity empty edges 0 || !Native.Trie.validPortable arity empty edges 0 then return false
    for bytes in [Native.write empty 4 40 1, Native.write empty 4 16 1] do
      let a := Native.Trie.valid arity bytes edges 0
      let b := Native.Trie.validPortable arity bytes edges 0
      if a || a != b then return false
  return true

/-- Independent preference cases force a later visited leaf to win by sparsity
or degree, and distinguish LIFO ties from basis-index order. -/
def policyChecks : Bool := Id.run do
  let context : Context := ⟨field,2,.lex⟩
  let cases : Array (Array RawPolynomial × Nat) := #[
    (#[#[⟨#[0,1],1⟩], #[⟨#[1,1],1⟩,⟨#[0,0],1⟩],
      #[⟨#[2,0],1⟩,⟨#[0,1],1⟩,⟨#[0,0],1⟩]], 0),
    (#[#[⟨#[2,1],1⟩], #[⟨#[1,0],1⟩], #[⟨#[0,2],1⟩]], 0),
    (#[#[⟨#[2,0],1⟩,⟨#[0,0],1⟩], #[⟨#[0,2],1⟩,⟨#[0,0],1⟩]], 1)]
  for (raw, expected) in cases do
    let trial : Computation Bool := do
      let mut basis : Array BasisElement := #[]
      for i in [:raw.size] do
        basis := basis.push ⟨← Polynomial.normalize context limits i raw[i]!,0⟩
      let index ← ReducerIndex.build context limits basis
      let some view := index.packed | return false
      for query in #[#[3,3], #[1,3], #[3,0], #[0,0]] do
        let monomial ← intern limits query
        let state ← get
        let actual := Native.Trie.lookup view state.table.width.bytes.toUInt8
          state.table.count.toUInt64 monomial.toUInt64 state.table.exponents state.table.metadata 4096
        let (reference, _) := ReducerIndex.findPortable context index basis state.table
          monomial state.statistics.work (state.statistics.work+4096)
        let (plain, plainWork) := ReducerIndex.findPortable context index basis state.table
          monomial state.statistics.work (state.statistics.work+100000) false
        let (pruned, prunedWork) := ReducerIndex.findPortable context index basis state.table
          monomial state.statistics.work (state.statistics.work+100000)
        if !equal plain pruned || prunedWork > plainWork then return false
        if actual.status != 1 || !equal (.ok actual.reducer) reference then return false
        if query == #[3,3] && actual.reducer != some expected then return false
        for allowance in [:32] do
          let budget := { limits with work := state.statistics.work+allowance }
          let (reference, work) := ReducerIndex.findPortable context index basis state.table
            monomial state.statistics.work budget.work
          let (value, next) := (index.find context budget basis monomial).run state
          if !equal value reference || next.statistics.work != work then return false
      return true
    match trial.run ⟨{ arity := 2 },{}⟩ with
    | (.ok true,_) => pure ()
    | _ => return false
  return true

#guard cacheChecks 0

#guard largeChecks

#guard policyChecks

-- An importing caller cannot forge a packed snapshot or replace its trie nodes.
#check_failure ReducerIndex.mk
#check_failure fun (index : ReducerIndex) => ({ index with nodes := #[] } : ReducerIndex)

#guard boundaryChecks

#guard runtimeChecks 0

end Hex.Groebner.TrieConformance
