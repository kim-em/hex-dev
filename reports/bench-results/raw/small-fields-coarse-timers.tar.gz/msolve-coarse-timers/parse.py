"""Reproduce coarse internal-counter bounds from the two retained comparator archives.
Pass the directory containing the extracted msolve-l{2,42}-records-* directories.
"""
from pathlib import Path
import json,re,sys
base=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
rows=[]
for route in [2,42]:
 p=base/f'msolve-l{route}-records-8142939751e3'
 for case in ['eco10-15','eco10-31','reimer5-15','reimer5-31']:
  for block in [0,1]:
   stem=f'{case}-b{block}';h=json.loads((p/(stem+'-A.stdout')).read_text())['candidate_nanos']/1e9
   matches=re.findall(r'^overall\(elapsed\)\s+([0-9.]+) sec', (p/(stem+'-B.stderr')).read_text(),re.M);assert len(matches)==1
   t=float(matches[0]);lo=max(0,t-.005);hi=t+.005
   rows.append(dict(experiment=p.name,case=case,block=block,hex_candidate_seconds=h,msolve_display_seconds=t,display_quantum_seconds=.01,msolve_rounding_interval=[lo,hi],hex_over_display_point=h/t if t>=.05 else None,ratio_lower_bound=h/hi,ratio_upper_bound=h/lo if t>=.05 else None,contract='Hex candidate includes canonicalization, F4, interreduction and interchange decoding; msolve F4 statistics time includes its internal computation/reduction, with different input/output conversion boundaries. Coarse internal observations, not matched process ratios.'))
print(json.dumps(rows,indent=2))
