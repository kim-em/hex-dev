from pathlib import Path
import argparse,hashlib,importlib.util,json,os,shutil,subprocess,time
p=argparse.ArgumentParser();p.add_argument('frozen',type=Path);p.add_argument('output',type=Path);args=p.parse_args();base=args.frozen;out=args.output;out.mkdir(exist_ok=False)
manifest=json.loads((base/'manifest.json').read_text());binary=base/'binaries/bench';sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();assert sha(binary)==manifest['binary_sha256']['bench']
helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('delayed_lease',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);cpu,lease=m.cpu_lease();samples=[];clock=shutil.which('time');before={str(p):sha(p)for p in [binary,helper,Path(__file__)]}
shutil.copy2(Path(__file__),out/'collector.py');shutil.copy2(helper,out/'cpu_lease.py');shutil.copy2(base/'manifest.json',out/'frozen-manifest.json')
meta=dict(manifest=manifest,cpu=cpu,threads=1,host=os.uname().nodename,source_bindings=before,samples=samples,contract='Deterministic known-head sparse matrix elimination, complete packed row contents, origin/multiplier/sugar and all eight logical counters hashed. Same binary, off/on option, p251/p32003/M31, with delayed reduction enabled for all three coefficient widths in B. lean-bench trial-major schedule; all completed runs retained; no leadership claim.')
def save():
 meta['source_bindings_after']={p:sha(Path(p))for p in before};(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(label,arm,shape,extra):
 directory=out/label;directory.mkdir(parents=True);function='bulk'+('Delayed'if arm=='B'else'')+shape
 command=[clock,'-f','%M','-o',str(directory/'rss'),str(binary),'run','Hex.Groebner.Bench.'+function,*extra,'--target-inner-nanos','8000000000','--max-seconds-per-call','60','--export-file',str(directory/'result.json')]
 start=time.time_ns();load=os.getloadavg()
 with(directory/'stdout').open('wb')as stdout,(directory/'stderr').open('wb')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=lambda:os.sched_setaffinity(0,{cpu}),env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
 row=dict(label=label,arm=arm,shape=shape,command=command,exit_code=r.returncode,started_ns=start,finished_ns=time.time_ns(),load_start=load,load_end=os.getloadavg());samples.append(row);save();print(label,r.returncode,flush=True);assert r.returncode in [0,2]
 data=json.loads((directory/'result.json').read_text())['results'][0];assert all(point['status']=='ok'and not point['below_signal_floor']for point in data['points'])
try:
 for shape in ['Byte','Short','Word']:
  for arm in ['A','B']:run(f'complexity/{shape}/{arm}',arm,shape,['--outer-trials','3'])
 for block in [0,1]:
  for shape in ['Byte','Short','Word']:
   for n in [128,256,512]:
    for arm in (['A','B']if block==0 else['B','A']):run(f'matched/{shape}/b{block}-{n}-{arm}',arm,shape,['--outer-trials','1','--param-schedule','doubling','--param-floor',str(n),'--param-ceiling',str(n)])
 for shape in ['Byte','Short','Word']:
  for n in [128,256,512]:
   points=[json.loads((out/f'matched/{shape}/b{b}-{n}-{a}/result.json').read_text())['results'][0]['points'][0]for b in [0,1]for a in ['A','B']];assert len({p['result_hash']for p in points})==1
finally:
 save();lease.close()
print('COMPLETE',len(samples),'benchmark processes; all complete output digests equal')
