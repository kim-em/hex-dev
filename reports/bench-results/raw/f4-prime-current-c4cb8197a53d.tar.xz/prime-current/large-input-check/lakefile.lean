import Lake
open Lake DSL
package LargeKernelChecks
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-prime-fixed-sweep"
lean_exe check where
  root := `Main
