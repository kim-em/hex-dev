import HexGroebner.Bench.Bulk
open Hex.Groebner.Bench

def main (args : List String) : IO UInt32 := do
  for arg in args do
    let some n := arg.toNat? | throw (IO.userError "column count required")
    if n < 1024 || n > 4096 then throw (IO.userError "unsupported validation size")
    let a := bulkByte (prepareBulkByte n)
    let b := bulkDelayedByte (prepareBulkByte n)
    if !a.1 || a != b then throw (IO.userError s!"byte failure {n}")
    let a := bulkShort (prepareBulkShort n)
    let b := bulkDelayedShort (prepareBulkShort n)
    if !a.1 || a != b then throw (IO.userError s!"short failure {n}")
    let a := bulkWord (prepareBulkWord n)
    let b := bulkDelayedWord (prepareBulkWord n)
    if !a.1 || a != b then throw (IO.userError s!"word failure {n}")
    IO.println s!"PASS {n}: all three widths successful; complete rows and counters equal"
  return 0
