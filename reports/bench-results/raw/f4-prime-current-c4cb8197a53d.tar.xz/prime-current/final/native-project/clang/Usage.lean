import HexGroebner.Driver.Run
@[extern "hex_test_dense_counts"] opaque denseCounts : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_dense_admitted"] opaque denseAdmitted : IO UInt64
@[extern "hex_test_whole_counts"] opaque wholeCounts : IO (UInt64 × UInt64)
@[extern "hex_test_delayed_refused"] opaque delayedRefusedWork : IO UInt64
@[extern "hex_test_avx512_count"] opaque avx512Count : IO UInt64
def main (args : List String) : IO UInt32 := do
  let status ← Hex.Groebner.Driver.run args
  let (prepares,scans,updates) ← denseCounts
  let packets ← avx512Count
  let admitted ← denseAdmitted
  let (accepted,declined) ← wholeCounts
  let refusedWork ← delayedRefusedWork
  (← IO.getStderr).putStrLn (Lean.Json.mkObj [
    ("avx512Packets",Lean.toJson packets),("prepares",Lean.toJson prepares),("admitted",Lean.toJson admitted),
    ("scans",Lean.toJson scans),("updates",Lean.toJson updates),
    ("delayedRefusedWork",Lean.toJson refusedWork),
    ("bulkAccepted",Lean.toJson accepted),("bulkDeclined",Lean.toJson declined)]).compress
  return status
