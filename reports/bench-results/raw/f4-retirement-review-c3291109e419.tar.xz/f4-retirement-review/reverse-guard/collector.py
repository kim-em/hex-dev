import hashlib,json,os,subprocess,time
from pathlib import Path
s=Path('/home/kim/tmp/issue-10987');r=Path.cwd();out=s/'retirement-reverse-guard-audit';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
guard=r/'conformance/HexGroebner/F4Conformance.lean';pair=r/'HexGroebner/Pairs.lean'
guard.write_bytes(Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-active-list/conformance/HexGroebner/F4Conformance.lean').read_bytes())
expected=s/'retirement-reverse-production/root-sources/HexGroebner/Pairs.lean'
# The archived reverse source and this checkout must be identical before compilation.
if not expected.exists():
 import tarfile
 with tarfile.open('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-active-list/reports/bench-results/raw/f4-active-list-checks-0a4bc08b663d.tar.xz')as tar:
  archived=tar.extractfile('f4-active-list-checks/mutations/reverse/root-sources/HexGroebner/Pairs.lean').read()
else:archived=expected.read_bytes()
assert pair.read_bytes()==archived
record=dict(command=['lake','build','HexGroebner.F4Conformance'],pair_sha256_before=sha(pair),guard_sha256_before=sha(guard),head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
started=time.monotonic()
with(out/'build.log').open('w')as log:run=subprocess.run(record['command'],env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR=str(s)),stdout=log,stderr=subprocess.STDOUT)
record.update(exit_code=run.returncode,seconds=time.monotonic()-started,pair_sha256_after=sha(pair),guard_sha256_after=sha(guard))
(out/'Pairs.lean').write_bytes(pair.read_bytes());(out/'F4Conformance.lean').write_bytes(guard.read_bytes());(out/'metadata.json').write_text(json.dumps(record,indent=2)+'\n')
assert run.returncode!=0 and 'retirementPairs\ndid not evaluate' in(out/'build.log').read_text()
assert record['pair_sha256_before']==record['pair_sha256_after']and record['guard_sha256_before']==record['guard_sha256_after']
print('reversed source guard rejected',flush=True)
