from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();assert identity['source_fingerprint']=='8861aaf91c08'
native=json.loads((s/'wide-rebased-native-status.json').read_text());full=json.loads((s/'wide-rebased-full-status.json').read_text())
assert len(native)==2 and len(full)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in native+full)
frozen=json.loads((s/'wide-rebased-verified-production/manifest.json').read_text());measured=json.loads((s/'lazy-hardened-production/manifest.json').read_text())
assert frozen['binary_sha256']==measured['binary_sha256']
payload={}
def add(n,p):
 assert n not in payload,n
 payload[n]=p.read_bytes()
def tree(label,base):
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if p.is_file()and'binaries'not in rel.parts and'.lake'not in rel.parts:add(label+'/'+str(rel),p)
tree('audit',s/'wide-rebased-verified-production')
for cc in ['clang','gcc']:
 add('native-'+cc+'.log',s/('wide-rebased-'+cc+'.log'));tree('probes/'+cc,s/('wide-rebased-'+cc))
add('native-status.json',s/'wide-rebased-native-status.json');add('full-status.json',s/'wide-rebased-full-status.json')
for n in ['build','oracles','driver','bench','dag','phase4','manifest','headers','lines']:add('full/'+n+'.log',s/('wide-rebased-full-'+n+'.log'))
for n in ['wide-rebased-native-checks.py','wide-rebased-full-checks.py','pack-wide-rebased-audit.py']:add('collectors/'+n,s/n)
for n in ['wide-pr-final-rebase.log','wide-pr-main-refresh.log','wide-rebased-freeze.log','wide-rebased-verified-freeze.log']:add('diagnostics/'+n,s/n)
checks=tree_listing(CHECKS,identity['source_commit']);payload['checks.manifest']=checks.encode()
for line in checks.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode()
out=s/('f4-lazy-config-audit-'+identity['source_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-lazy-config-audit/'+n);entry.size=len(b);entry.mode=0o644;tar.addfile(entry,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
