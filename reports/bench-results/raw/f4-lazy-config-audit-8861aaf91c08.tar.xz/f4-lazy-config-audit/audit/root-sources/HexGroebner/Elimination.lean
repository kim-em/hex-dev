/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

-- The dispatcher owns the provenance/scalar calls into the carrier implementation.
import all HexGroebner.EliminationKernel
public import HexGroebner.EliminationKernel
import HexGroebner.MatrixState

public section

namespace Hex.Groebner

namespace Elimination

/-- Select bounded bulk elimination for untraced native calls. Declined frames
continue in owned bounded phases within the native scheduler's shape limits,
with the reference result and exact counters. Larger frames retain the reference's
bounded native scan/gather kernels. -/
def run (field : PrimeField) (limits : MatrixLimits) (columns : Nat)
    (reducers targets : Array SparseRow) (provenance : Bool) (sugars : Array Nat)
    (native independent : Bool) : Result :=
  if native && !provenance then
    match attempt field limits columns reducers targets sugars independent with
    | some result => result
    | none =>
      if columns ≤ 65536 ∧ reducers.size+targets.size ≤ 65536 then
        let output := MatrixState.finishWith 64
          (MatrixState.start field limits columns reducers targets sugars independent)
        ⟨output.1,output.2⟩
      else reference field limits columns reducers targets sugars independent
  else
    let (result,stats) :=
      (eliminate field limits columns reducers targets provenance sugars native independent).run {}
    ⟨result,stats⟩


end Elimination

/-- Deterministic finite-prime-field Macaulay elimination, with sparse reducers,
packed dense accumulation, monic output, stable columns and optional provenance.
`native := false` retains scalar Lean updates; the default uses bounded native
chunks with identical rows, provenance and counters. Untraced native 64-bit calls first
try a complete frame bounded by 4096 columns, 1024 reducers, 64 targets and
`2^20` work. Explicit `binaryPivots` over F2 permits 16384 columns, 16384
reducers and 1024 targets, bounded by `2^32` logical work and `2^28` physical
visits. Private bitmap and metadata bytes additionally fit the packed-byte allowance.
Declined frames with at most 65536 columns and total input rows
continue in bounded native phases. Larger frames retain the reference route
with bounded native scan/gather kernels.
Cancellation is observed between calls. Input rows must be canonical
and use the field's coefficient width. Limits cover
validation and nested arithmetic as well as elimination. Successful rows span
the input row space; they are echelon, not reduced echelon. The polynomial layer
is responsible for supplying columns in the chosen lawful monomial order. -/
def eliminateWith (field : PrimeField) (limits : MatrixLimits)
    (columns : Nat) (reducers targets : Array SparseRow) (provenance : Bool := false)
    (sugars : Array Nat := #[]) (native : Bool := true) : MatrixResult :=
  let output := Elimination.run field limits columns reducers targets provenance sugars native false
  ⟨output.result.map Prod.fst, output.stats⟩

/-- Reduce each target by the same reducer echelon space, preserving its scalar
and input position. Targets never reduce each other. Validation, sparse reducer
installation, bounded native updates and allowances are shared with elimination.
Untraced native 64-bit calls use the same optional matrix frames and field-specific
caps as `eliminateWith`; other untraced native calls within the continuation
shape limits use bounded phases. Larger frames and provenance calls retain
the reference scan/gather chunks.
`native := false` uses scalar Lean row updates. Explicit dense-pivot preparation
retains its bounded provider and shared preparation charges, including traced
and reference calls; only the untraced continuation reuses the caches.
This is a linear triangular solve; polynomial normal-form claims additionally
require the symbolic closure and a Gröbner basis. -/
def reduceRowsWith (field : PrimeField) (limits : MatrixLimits)
    (columns : Nat) (reducers targets : Array SparseRow) (provenance : Bool := false)
    (sugars : Array Nat := #[]) (native : Bool := true) : RemainderResult :=
  let output := Elimination.run field limits columns reducers targets provenance sugars native true
  ⟨output.result.map (fun (e, rows) => ⟨rows, e.trace⟩), output.stats⟩

end Hex.Groebner
