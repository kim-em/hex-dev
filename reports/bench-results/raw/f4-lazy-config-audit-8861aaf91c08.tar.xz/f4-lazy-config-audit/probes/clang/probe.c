#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames/HexGroebner/ffi/matrix_runtime.h"
#define lean_hex_groebner_subtract_row hex_test_unused_subtract
#define lean_hex_groebner_remap_columns hex_test_remap
#define lean_hex_groebner_remap_index hex_test_remap_index
#define lean_hex_groebner_clear_support hex_test_clear_support
#define lean_hex_groebner_queue_support hex_test_queue_support
#define lean_hex_groebner_append_zeros hex_test_append_zeros
#define lean_hex_groebner_prepare_monomial hex_test_unused_prepare
#define lean_hex_groebner_equal_monomial hex_test_unused_monomial_equal
#define lean_hex_groebner_search_monomial hex_test_search_monomial
#define lean_hex_groebner_equal_bytes hex_test_equal_bytes
#define lean_hex_groebner_equal_products hex_test_equal_products
#define lean_hex_groebner_compare_monomials hex_test_compare
#define lean_hex_groebner_validate_trie hex_test_validate
#define lean_hex_groebner_lookup_trie hex_test_trie
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames/HexGroebner/ffi/row_update.c"
#undef lean_hex_groebner_compare_monomials
#undef lean_hex_groebner_validate_trie
#undef lean_hex_groebner_lookup_trie
#undef lean_hex_groebner_subtract_row
#undef lean_hex_groebner_remap_columns
#undef lean_hex_groebner_remap_index
#undef lean_hex_groebner_clear_support
#undef lean_hex_groebner_queue_support
#undef lean_hex_groebner_append_zeros
#undef lean_hex_groebner_prepare_monomial
#undef lean_hex_groebner_equal_monomial
#undef lean_hex_groebner_search_monomial
#undef lean_hex_groebner_equal_bytes
#undef lean_hex_groebner_equal_products
static uint64_t pivot_pushes=0,pivot_shared=0,pivot_shared_entries=0;
lean_obj_res __real_lean_array_push(lean_obj_arg,lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lean_array_push(lean_obj_arg a,lean_obj_arg value) {
 if(!lean_is_scalar(value) && lean_obj_tag(value)==0 && lean_ctor_num_objs(value)==3 &&
    !lean_is_scalar(lean_ctor_get(value,0)) && !lean_is_scalar(lean_ctor_get(value,1)) &&
    lean_is_sarray(lean_ctor_get(value,0)) && lean_is_sarray(lean_ctor_get(value,1))) {
  ++pivot_pushes;if(!lean_is_exclusive(a)) {++pivot_shared; pivot_shared_entries+=lean_array_size(a);}
 }
 return __real_lean_array_push(a,value);
}
LEAN_EXPORT lean_obj_res hex_test_reset_pivot_owners(lean_obj_arg world) {
 (void)world;pivot_pushes=pivot_shared=pivot_shared_entries=0;
 return lean_io_result_mk_ok(lean_box(0));
}
LEAN_EXPORT lean_obj_res hex_test_pivot_owners(lean_obj_arg world) {
 (void)world;lean_object *inner=lean_alloc_ctor(0,2,0),*outer=lean_alloc_ctor(0,2,0);
 lean_ctor_set(inner,0,lean_box_uint64(pivot_shared));lean_ctor_set(inner,1,lean_box_uint64(pivot_shared_entries));
 lean_ctor_set(outer,0,lean_box_uint64(pivot_pushes));lean_ctor_set(outer,1,inner);
 return lean_io_result_mk_ok(outer);
}
LEAN_EXPORT lean_obj_res hex_test_copy_bytes(b_lean_obj_arg input,lean_obj_arg world) {
 (void)world;size_t n=lean_sarray_size(input);
 lean_object *copy=lean_alloc_sarray(1,n,n);
 for(size_t i=0;i<n;++i) lean_sarray_cptr(copy)[i]=lean_sarray_cptr(input)[i];
 return lean_io_result_mk_ok(copy);
}
static uint64_t subtract_calls=0;
__typeof__(hex_test_unused_subtract) __wrap_lean_hex_groebner_subtract_row;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_subtract_row(
 uint64_t modulus,lean_obj_arg dense,b_lean_obj_arg columns,b_lean_obj_arg coefficients,
 b_lean_obj_arg start,b_lean_obj_arg count,uint64_t factor) {
 ++subtract_calls;return hex_test_unused_subtract(modulus,dense,columns,coefficients,start,count,factor);
}
LEAN_EXPORT lean_obj_res hex_test_subtract_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(subtract_calls));
}
static uint64_t remap_calls=0;
__typeof__(hex_test_remap) __wrap_lean_hex_groebner_remap_columns;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_remap_columns(
 b_lean_obj_arg positions,b_lean_obj_arg support,b_lean_obj_arg start,
 b_lean_obj_arg count,lean_obj_arg output) {
 ++remap_calls;return hex_test_remap(positions,support,start,count,output);
}
static uint64_t support_calls=0,support_copies=0,clear_calls=0;
__typeof__(hex_test_queue_support) __wrap_lean_hex_groebner_queue_support;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_queue_support(uint64_t count,
 b_lean_obj_arg ids,b_lean_obj_arg start,b_lean_obj_arg terms,
 lean_obj_arg bits,lean_obj_arg pending) {
 ++support_calls;if(!lean_is_exclusive(bits))++support_copies;return hex_test_queue_support(count,ids,start,terms,bits,pending);
}
__typeof__(hex_test_clear_support) __wrap_lean_hex_groebner_clear_support;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_clear_support(lean_obj_arg bits,
 b_lean_obj_arg queue,b_lean_obj_arg start,b_lean_obj_arg terms) {
 ++clear_calls;if(!lean_is_exclusive(bits))++support_copies;
 return hex_test_clear_support(bits,queue,start,terms);
}
LEAN_EXPORT lean_obj_res hex_test_support_copies(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(support_copies));
}
LEAN_EXPORT lean_obj_res hex_test_support_clears(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(clear_calls));
}
LEAN_EXPORT lean_obj_res hex_test_support_aliases(lean_obj_arg world) {
 (void)world;int ok=1;
 for(unsigned linear=0;linear<2;++linear) for(unsigned alias=0;alias<2;++alias)
 for(unsigned shared=0;shared<2;++shared) for(unsigned fail=0;fail<2;++fail) {
  if(linear && shared) continue;
  lean_object *ids=lean_alloc_sarray(1,8,8);
  write_le(lean_sarray_cptr(ids),4,33);write_le(lean_sarray_cptr(ids)+4,4,fail?64:0);
  lean_object *bits=alias?ids:lean_alloc_sarray(1,8,8);
  if(!alias)memset(lean_sarray_cptr(bits),0,8);
  uint8_t ids_saved[8],bits_saved[8],expected[8];
  memcpy(ids_saved,lean_sarray_cptr(ids),8);memcpy(bits_saved,lean_sarray_cptr(bits),8);
  memcpy(expected,bits_saved,8);expected[4]|=2;expected[0]|=1;
  lean_object *keeper=bits,*pending=lean_alloc_array(0,4);
  if(linear)lean_sarray_mark_linear_core(bits);
  if(shared)lean_inc(keeper);
  lean_object *result=hex_test_queue_support(64,ids,lean_box(0),lean_box(2),bits,pending);
  ok=ok && lean_obj_tag(result)==(fail?0:1);
  if(!fail && lean_obj_tag(result)==1) {
   lean_object *pair=lean_ctor_get(result,0),*actual=lean_ctor_get(pair,0),*queued=lean_ctor_get(pair,1);
   ok=ok && lean_is_exclusive(actual) && lean_sarray_size(actual)==8;
   ok=ok && memcmp(lean_sarray_cptr(actual),expected,8)==0;
   ok=ok && lean_array_size(queued)==(alias?1:2) && lean_unbox(lean_array_get_core(queued,0))==33;
   if(!alias && lean_array_size(queued)==2)ok=ok && lean_unbox(lean_array_get_core(queued,1))==0;
   if(linear)ok=ok && lean_sarray_is_marked_linear(actual);
  }
  if(shared) {
   ok=ok && memcmp(lean_sarray_cptr(keeper),bits_saved,8)==0;lean_dec(keeper);
  }
  if(!alias) {
   ok=ok && memcmp(lean_sarray_cptr(ids),ids_saved,8)==0;lean_dec(ids);
  }
  lean_dec(result);
 }
 return lean_io_result_mk_ok(lean_box(ok));
}
LEAN_EXPORT lean_obj_res hex_test_support_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(support_calls));
}
static uint64_t index_calls=0,zero_calls=0;
__typeof__(hex_test_remap_index) __wrap_lean_hex_groebner_remap_index;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_remap_index(
 b_lean_obj_arg slots,b_lean_obj_arg support,b_lean_obj_arg start,
 b_lean_obj_arg count,b_lean_obj_arg probes,lean_obj_arg output) {
 ++index_calls;return hex_test_remap_index(slots,support,start,count,probes,output);
}
__typeof__(hex_test_append_zeros) __wrap_lean_hex_groebner_append_zeros;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_append_zeros(lean_obj_arg output,b_lean_obj_arg count) {
 ++zero_calls;if(lean_sarray_size(output) && !lean_is_exclusive(output))++support_copies;
 return hex_test_append_zeros(output,count);
}
LEAN_EXPORT lean_obj_res hex_test_index_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(index_calls));
}
LEAN_EXPORT lean_obj_res hex_test_zero_append_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(zero_calls));
}
LEAN_EXPORT lean_obj_res hex_test_remap_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(remap_calls));
}
LEAN_EXPORT lean_obj_res hex_test_remap_aliases(lean_obj_arg world) {
 (void)world;int ok=1;
 for(unsigned linear=0;linear<2;++linear) for(unsigned mode=0;mode<4;++mode)
 for(unsigned test=0;test<4;++test) {
  int fail=test==1 || test==2,observe=test>=2;
  /* A marked output may be a borrowed alias, but cannot have another owner. */
  if(linear && observe) continue;
  lean_object *positions=lean_alloc_sarray(1,12,12),*support=lean_alloc_sarray(1,12,12);
  for(unsigned i=0;i<3;++i) {
   write_le(lean_sarray_cptr(positions)+4*i,4,i+1);
   write_le(lean_sarray_cptr(support)+4*i,4,fail && i==2?777:i);
  }
  uint8_t position_snapshot[12],support_snapshot[12],output_snapshot[12];
  memcpy(position_snapshot,lean_sarray_cptr(positions),12);
  memcpy(support_snapshot,lean_sarray_cptr(support),12);
  lean_object *out=mode==0?support:positions;size_t old=12;
  if(mode>=2) {out=lean_alloc_sarray(1,4,mode==2?4:32);write_le(lean_sarray_cptr(out),4,37);old=4;}
  memcpy(output_snapshot,lean_sarray_cptr(out),old);lean_object *keeper=out;
  if(linear) lean_sarray_mark_linear_core(out);
  if(observe) lean_inc(keeper);
  lean_object *result=hex_test_remap(positions,support,lean_box(0),lean_box(3),out);
  ok=ok && lean_obj_tag(result)==(fail?0:1);
  if(!fail && lean_obj_tag(result)==1) {
   lean_object *bytes=lean_ctor_get(result,0);
   ok=ok && lean_is_exclusive(bytes) && lean_sarray_size(bytes)==old+12;
   if(linear) ok=ok && lean_sarray_is_marked_linear(bytes);
   if(lean_sarray_size(bytes)==old+12) {
    ok=ok && memcmp(lean_sarray_cptr(bytes),output_snapshot,old)==0;
    for(unsigned i=0;i<3;++i) ok=ok && read_le(lean_sarray_cptr(bytes)+old+4*i,4)==i;
   }
   if(observe) ok=ok && lean_sarray_cptr(bytes)!=lean_sarray_cptr(keeper);
  }
  if(observe) {
   ok=ok && lean_is_exclusive(keeper) && lean_sarray_size(keeper)==old;
   ok=ok && memcmp(lean_sarray_cptr(keeper),output_snapshot,old)==0;lean_dec(keeper);
  }
  if(mode!=1) ok=ok && lean_is_exclusive(positions) &&
    memcmp(lean_sarray_cptr(positions),position_snapshot,12)==0;
  if(mode!=0) ok=ok && lean_is_exclusive(support) &&
    memcmp(lean_sarray_cptr(support),support_snapshot,12)==0;
  lean_dec(result);if(mode!=1) lean_dec(positions);if(mode!=0) lean_dec(support);
 }
 return lean_io_result_mk_ok(lean_box(ok));
}
LEAN_EXPORT lean_obj_res hex_test_index_aliases(lean_obj_arg world) {
 (void)world;int ok=1;
 for(unsigned linear=0;linear<2;++linear) for(unsigned mode=0;mode<4;++mode)
 for(unsigned test=0;test<4;++test) {
  int fail=test==1 || test==2,observe=test>=2;
  /* A marked output may be a borrowed alias, but cannot have another owner. */
  if(linear && observe) continue;
  lean_object *slots=lean_alloc_sarray(1,128,128),*support=lean_alloc_sarray(1,12,12);
  memset(lean_sarray_cptr(slots),0,128);
  for(unsigned i=0;i<3;++i) {
   size_t bucket=(size_t)(column_hash(i)&15);
   while(read_le(lean_sarray_cptr(slots)+bucket*8+4,4)) bucket=(bucket+1)&15;
   write_le(lean_sarray_cptr(slots)+bucket*8,4,i);
   write_le(lean_sarray_cptr(slots)+bucket*8+4,4,i+1);
   write_le(lean_sarray_cptr(support)+4*i,4,fail && i==2?777:i);
  }
  uint8_t slot_snapshot[128],support_snapshot[12],output_snapshot[128];
  memcpy(slot_snapshot,lean_sarray_cptr(slots),128);memcpy(support_snapshot,lean_sarray_cptr(support),12);
  lean_object *out=mode==0?support:slots;size_t old=lean_sarray_size(out);
  if(mode>=2) {out=lean_alloc_sarray(1,4,mode==2?4:32);write_le(lean_sarray_cptr(out),4,37);old=4;}
  memcpy(output_snapshot,lean_sarray_cptr(out),old);lean_object *keeper=out;
  if(linear) lean_sarray_mark_linear_core(out);
  if(observe) lean_inc(keeper);
  lean_object *result=hex_test_remap_index(slots,support,lean_box(0),lean_box(3),lean_box(64),out);
  ok=ok && (lean_obj_tag(result)==(fail?0:1));
  if(!fail && lean_obj_tag(result)==1) {
   lean_object *bytes=lean_ctor_get(result,0);
   ok=ok && lean_is_exclusive(bytes) && lean_sarray_size(bytes)==old+12;
   if(linear) ok=ok && lean_sarray_is_marked_linear(bytes);
   if(lean_sarray_size(bytes)==old+12) {
    ok=ok && memcmp(lean_sarray_cptr(bytes),output_snapshot,old)==0;
    for(unsigned i=0;i<3;++i) ok=ok && read_le(lean_sarray_cptr(bytes)+old+4*i,4)==i;
   }
   if(observe) ok=ok && lean_sarray_cptr(bytes)!=lean_sarray_cptr(keeper);
  }
  if(observe) {
   ok=ok && lean_is_exclusive(keeper) && lean_sarray_size(keeper)==old;
   ok=ok && memcmp(lean_sarray_cptr(keeper),output_snapshot,old)==0;lean_dec(keeper);
  }
  if(mode!=1) ok=ok && lean_is_exclusive(slots) && memcmp(lean_sarray_cptr(slots),slot_snapshot,128)==0;
  if(mode!=0) ok=ok && lean_is_exclusive(support) && memcmp(lean_sarray_cptr(support),support_snapshot,12)==0;
  lean_dec(result);if(mode!=1) lean_dec(slots);if(mode!=0) lean_dec(support);
 }
 for(unsigned capacity=4;capacity<=32;capacity*=8) for(unsigned shared=0;shared<2;++shared) {
  lean_object *bytes=lean_alloc_sarray(1,4,capacity);memset(lean_sarray_cptr(bytes),37,4);
  lean_object *keeper=bytes;
  if(shared) lean_inc(keeper);else lean_sarray_mark_linear_core(bytes);
  lean_object *result=hex_test_append_zeros(bytes,lean_box(12));ok=ok && lean_obj_tag(result)==1;
  if(lean_obj_tag(result)==1) {
   bytes=lean_ctor_get(result,0);ok=ok && lean_is_exclusive(bytes) && lean_sarray_size(bytes)==16;
   if(!shared) ok=ok && lean_sarray_is_marked_linear(bytes);
   if(shared) ok=ok && lean_sarray_cptr(bytes)!=lean_sarray_cptr(keeper);
   for(unsigned i=0;i<16;++i) ok=ok && lean_sarray_cptr(bytes)[i]==(i<4?37:0);
  }
  if(shared) {
   ok=ok && lean_is_exclusive(keeper) && lean_sarray_size(keeper)==4;
   for(unsigned i=0;i<4;++i) ok=ok && lean_sarray_cptr(keeper)[i]==37;
   lean_dec(keeper);
  }
  lean_dec(result);
 }
 return lean_io_result_mk_ok(lean_box(ok));
}
static uint64_t batch_hits=0,batch_terms=0,batch_deferrals=0,batch_waste=0,batch_bound_errors=0;
static uint64_t batch_insertions=0;
static const uint8_t *product_snapshot=NULL;
static size_t product_snapshot_size=0;
static void check_product_borrow(b_lean_obj_arg support) {
 if(product_snapshot) {
  assert(lean_sarray_size(support)==product_snapshot_size);
  assert(memcmp(lean_sarray_cptr(support),product_snapshot,product_snapshot_size)==0);
 }
}
#define HEX_GROEBNER_PRODUCTS_BORROWED(support) check_product_borrow(support)
#define HEX_GROEBNER_PRODUCTS_INSERTED(n) (batch_insertions+=(n))
#define HEX_GROEBNER_PRODUCTS_DEFERRED(w) (++batch_deferrals,batch_waste+=(w),batch_bound_errors+=((w)>4096))
#define HEX_GROEBNER_PRODUCTS_FOUND(n) (++batch_hits,batch_terms+=(n))
static uint64_t fused_success=0,fused_insert=0,fused_unique=0,fused_deferred=0,unique_alias=0,unique_alias_mask=0;
#define HEX_GROEBNER_DEFERRED() (++fused_deferred)
#define HEX_GROEBNER_UNIQUE_ALIAS(mask) (++unique_alias,unique_alias_mask|=(mask))
#define HEX_GROEBNER_TABLE_UNIQUE() (++fused_unique)
#define HEX_GROEBNER_INSERT_FOUND() (++fused_insert)
#define HEX_GROEBNER_HIT_FOUND() (++fused_success)
#define HEX_GROEBNER_HIT_HELPERS
#define lean_hex_monomial_products_attempt hex_test_products_attempt
#define lean_hex_groebner_combine_owned hex_test_combine_owned
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames/HexGroebner/ffi/monomial_hit.c"
#undef lean_hex_groebner_combine_owned
#undef lean_hex_monomial_products_attempt
/* Build an RC=1 table directly: no Lean variable can retain a snapshot and
   accidentally turn the tested operation into the shared-table branch. */
LEAN_EXPORT lean_obj_res hex_test_product_aliases(lean_obj_arg world) {
 (void)world;int ok=1;
 for(unsigned mode=0;mode<11;++mode) for(unsigned linear=0;linear<2;++linear)
 for(unsigned spare=0;spare<2;++spare) for(unsigned observe=0;observe<3;++observe) {
  /* Multiple owning fields deliberately share arenas only when unmarked. */
  if(linear && (mode>=6 || observe==2)) continue;
  unsigned count=mode==7 || mode==10?8:3;
  size_t sizes[5]={count*4,count*24,32,128,count*4};lean_object *arenas[5];
  for(unsigned i=0;i<5;++i) {
   arenas[i]=lean_alloc_sarray(1,sizes[i],sizes[i]+(spare?128:0));
   memset(lean_sarray_cptr(arenas[i]),0,sizes[i]);
  }
  for(unsigned i=0;i<count;++i) {
   write_le(lean_sarray_cptr(arenas[0])+4*i,4,i);
   uint8_t *m=lean_sarray_cptr(arenas[1])+24*i;
   hit_write64(m,i);hit_write64(m+8,i?1:0);hit_write64(m+16,0);
   write_le(lean_sarray_cptr(arenas[4])+4*i,4,i);
  }
  write_le(lean_sarray_cptr(arenas[3]),4,count);
  write_le(lean_sarray_cptr(arenas[3])+4,4,1);
  write_le(lean_sarray_cptr(arenas[2]),4,1);
  /* Intra-table aliases: exponents/links have identical complete contents;
     each workspace alias is also a valid pre-existing scratch buffer. */
  if(mode==6) {lean_dec(arenas[4]);arenas[4]=arenas[0];lean_inc(arenas[4]);}
  if(mode>=7) {
   unsigned source=mode==7?0:mode==8?1:mode==9?3:4;
   lean_dec(arenas[2]);arenas[2]=arenas[source];lean_inc(arenas[2]);sizes[2]=sizes[source];
  }
  unsigned support_arena=mode?mode<=5?mode-1:0:5;
  lean_object *support;
  size_t start=0;
  if(support_arena==5) {support=lean_alloc_sarray(1,4,4);write_le(lean_sarray_cptr(support),4,1);}
  else {
   support=arenas[support_arena];
   start=support_arena==0 || support_arena==3 || support_arena==4?1:support_arena==1?6:0;
  }
  uint8_t snapshots[5][256],support_copy[256];
  for(unsigned i=0;i<5;++i) memcpy(snapshots[i],lean_sarray_cptr(arenas[i]),sizes[i]);
  size_t support_size=lean_sarray_size(support);memcpy(support_copy,lean_sarray_cptr(support),support_size);
  if(linear) for(unsigned i=0;i<5;++i) lean_sarray_mark_linear_core(arenas[i]);
  if(observe==1 && mode) lean_inc(support);
  if(observe==2) for(unsigned i=0;i<5;++i) lean_inc(arenas[i]);
  lean_object *index=lean_alloc_ctor(0,2,0);
  lean_ctor_set(index,0,arenas[3]);lean_ctor_set(index,1,arenas[4]);
  lean_object *table=lean_alloc_ctor(0,8,1);
  lean_ctor_set(table,0,lean_box(1));lean_ctor_set(table,1,arenas[0]);lean_ctor_set(table,2,arenas[1]);
  lean_ctor_set(table,3,lean_box(count));lean_ctor_set(table,4,arenas[2]);lean_ctor_set(table,5,index);
  lean_ctor_set(table,6,lean_box(0));lean_ctor_set(table,7,lean_box(0));
  lean_ctor_set_uint8(table,8*sizeof(void*),2);
  assert(lean_is_exclusive(table));
  uint8_t prepared[32];
  assert(prepare_monomial(1,4,1,count,1,count-1,snapshots[0],count*4,prepared,32));
  uint64_t visited=0;product_snapshot=support_copy;product_snapshot_size=support_size;
  lean_object *result=products_hits(table,support,lean_box(count-1),lean_box(start),lean_box(1),
    lean_box(100),lean_box(10000),lean_box(10000),1,&visited);
  product_snapshot=NULL;
  ok=ok && result!=NULL;
  assert(result!=NULL);
  lean_object *updated=lean_ctor_get(result,1),*ids=lean_ctor_get(lean_ctor_get(result,0),0);
  ok=ok && updated==table && lean_is_exclusive(updated) && lean_obj_tag(lean_ctor_get(result,0))==1;
  ok=ok && lean_unbox(lean_ctor_get(updated,0))==1 && lean_unbox(lean_ctor_get(updated,3))==count+1;
  ok=ok && lean_unbox(lean_ctor_get(updated,6))==0 && lean_unbox(lean_ctor_get(updated,7))==2*count+5;
  ok=ok && lean_ctor_get_uint8(updated,8*sizeof(void*))==2 && visited==2*count+5;
  ok=ok && lean_sarray_size(ids)==4 && read_le(lean_sarray_cptr(ids),4)==count;
  lean_object *new_index=lean_ctor_get(updated,5);
  lean_object *out[5]={lean_ctor_get(updated,1),lean_ctor_get(updated,2),lean_ctor_get(updated,4),
    lean_ctor_get(new_index,0),lean_ctor_get(new_index,1)};
  uint8_t expected_exponents[40],expected_metadata[240],expected_heads[128],expected_links[40];
  memcpy(expected_exponents,snapshots[0],count*4);write_le(expected_exponents+count*4,4,count);
  memcpy(expected_metadata,snapshots[1],count*24);memcpy(expected_metadata+count*24,prepared+4,16);
  hit_write64(expected_metadata+count*24+16,0);
  memcpy(expected_heads,snapshots[3],128);write_le(expected_heads,4,count+1);
  memcpy(expected_links,snapshots[4],count*4);write_le(expected_links+count*4,4,count);
  const uint8_t *expected[5]={expected_exponents,expected_metadata,prepared,expected_heads,expected_links};
  size_t output_sizes[5]={(count+1)*4,(count+1)*24,32,128,(count+1)*4};
  for(unsigned i=0;i<5;++i) {
   ok=ok && lean_is_exclusive(out[i]) && lean_sarray_size(out[i])==output_sizes[i];
   if(lean_sarray_size(out[i])==output_sizes[i]) ok=ok && memcmp(lean_sarray_cptr(out[i]),expected[i],output_sizes[i])==0;
   if(linear) ok=ok && lean_sarray_is_marked_linear(out[i]);
   if(!mode && !observe && spare && (i==0 || i==1 || i==4)) ok=ok && out[i]==arenas[i];
  }
  if(!mode) {ok=ok && memcmp(lean_sarray_cptr(support),support_copy,support_size)==0;lean_dec(support);}
  if(observe==1 && mode) {
   ok=ok && memcmp(lean_sarray_cptr(support),support_copy,support_size)==0;
   if(linear) ok=ok && lean_sarray_is_marked_linear(support);
   lean_dec(support);
  }
  if(observe==2) for(unsigned i=0;i<5;++i) {
   ok=ok && lean_sarray_size(arenas[i])==sizes[i] && memcmp(lean_sarray_cptr(arenas[i]),snapshots[i],sizes[i])==0;
   lean_dec(arenas[i]);
  }
  lean_dec(result);
 }
 return lean_io_result_mk_ok(lean_box(ok));
}
static lean_object *test_product_table(void) {
 lean_object *es=lean_alloc_sarray(1,32,32),*meta=lean_alloc_sarray(1,192,192);
 lean_object *workspace=lean_alloc_sarray(1,32,32),*heads=lean_alloc_sarray(1,256,256),*links=lean_alloc_sarray(1,32,32);
 memset(lean_sarray_cptr(heads),0,256);memset(lean_sarray_cptr(workspace),0,32);
 for(unsigned i=0;i<8;++i) write_le(lean_sarray_cptr(es)+4*i,4,i);
 for(unsigned i=0;i<8;++i) {
  uint8_t prepared[32];assert(prepare_monomial(0,4,1,8,i,i,lean_sarray_cptr(es),32,prepared,32));
  memcpy(lean_sarray_cptr(meta)+24*i,prepared+4,24);
  uint64_t hash=read_le(prepared+20,4)|(read_le(prepared+24,4)<<32);
  size_t slot=(size_t)(hit_mix(hash)&63);
  uint64_t previous=read_le(lean_sarray_cptr(heads)+slot*4,4);
  write_le(lean_sarray_cptr(links)+i*4,4,previous);write_le(lean_sarray_cptr(heads)+slot*4,4,i+1);
 }
 lean_object *index=lean_alloc_ctor(0,2,0);lean_ctor_set(index,0,heads);lean_ctor_set(index,1,links);
 lean_object *table=lean_alloc_ctor(0,8,1);
 lean_ctor_set(table,0,lean_box(1));lean_ctor_set(table,1,es);lean_ctor_set(table,2,meta);
 lean_ctor_set(table,3,lean_box(8));lean_ctor_set(table,4,workspace);lean_ctor_set(table,5,index);
 lean_ctor_set(table,6,lean_box(64));lean_ctor_set(table,7,lean_box(0));lean_ctor_set_uint8(table,8*sizeof(void*),2);
 return table;
}
static int test_product_tables_equal(b_lean_obj_arg a,b_lean_obj_arg b) {
 for(unsigned i=0;i<8;++i) {
  lean_object *x=lean_ctor_get(a,i),*y=lean_ctor_get(b,i);
  if(i==1 || i==2 || i==4) {if(!lean_sarray_eq(x,y))return 0;}
  else if(i==5) {
   if(!lean_sarray_eq(lean_ctor_get(x,0),lean_ctor_get(y,0)) ||
      !lean_sarray_eq(lean_ctor_get(x,1),lean_ctor_get(y,1)))return 0;
  } else if(!lean_nat_dec_eq(x,y))return 0;
 }
 return lean_ctor_get_uint8(a,8*sizeof(void*))==lean_ctor_get_uint8(b,8*sizeof(void*));
}
LEAN_EXPORT lean_obj_res hex_test_product_exclusive(lean_obj_arg world) {
 (void)world;int ok=1;
 for(unsigned insert=0;insert<2;++insert) {
  lean_object *table=test_product_table(),*expected=test_product_table();
  lean_object *support=lean_alloc_sarray(1,12,12);unsigned right=insert?7:0;
  for(unsigned i=0;i<3;++i) write_le(lean_sarray_cptr(support)+i*4,4,insert?(i==1?2:1):i);
  unsigned ids[3];
  /* Independent owned scalar operations supply complete table expectations;
     add each product's separate operand-validation charge before the call. */
  for(unsigned i=0;i<3;++i) {
   uint64_t work=lean_unbox(lean_ctor_get(expected,7))+1;
   lean_dec(lean_ctor_get(expected,7));lean_ctor_set(expected,7,lean_uint64_to_nat(work));
   lean_object *attempt=hit_compute(expected,1,lean_box(read_le(lean_sarray_cptr(support)+i*4,4)),
     lean_box(right),lean_box(100),lean_box(10000),lean_box(10000),lean_box(work));
   assert(lean_obj_tag(attempt)==0);lean_object *result=lean_ctor_get(attempt,0);
   ids[i]=lean_unbox(lean_ctor_get(lean_ctor_get(result,0),0));expected=lean_ctor_get(result,1);
   lean_inc(expected);lean_dec(attempt);assert(lean_is_exclusive(expected));
  }
  uint64_t visited=0;assert(lean_is_exclusive(table));
  lean_object *result=products_hits(table,support,lean_box(right),lean_box(0),lean_box(3),
    lean_box(100),lean_box(10000),lean_box(10000),1,&visited);
  assert(result!=NULL);lean_object *actual=lean_ctor_get(result,1);
  lean_object *output=lean_ctor_get(lean_ctor_get(result,0),0);
  ok=ok && actual==table && lean_is_exclusive(actual) && test_product_tables_equal(actual,expected);
  ok=ok && lean_sarray_size(output)==12 && lean_unbox(lean_ctor_get(actual,3))==(insert?10:8);
  for(unsigned i=0;i<3;++i) ok=ok && read_le(lean_sarray_cptr(output)+i*4,4)==ids[i];
  if(insert) {
   lean_object *index=lean_ctor_get(actual,5),*heads=lean_ctor_get(index,0);
   unsigned changed=0;
   for(unsigned slot=0;slot<64;++slot) if(read_le(lean_sarray_cptr(heads)+4*slot,4)>8)++changed;
   ok=ok && changed==2;
  }
  lean_dec(result);lean_dec(expected);lean_dec(support);
 }
 return lean_io_result_mk_ok(lean_box(ok));
}
LEAN_EXPORT lean_obj_res hex_test_owned_runtime(lean_obj_arg world) {
 (void)world;int ok=1;
 for(size_t capacity=1;capacity<=8;capacity*=8) {
  lean_object *bytes=lean_alloc_sarray(1,1,capacity);lean_sarray_cptr(bytes)[0]=37;
  lean_sarray_mark_linear_core(bytes);bytes=hit_extend(bytes,2);
  ok=ok && lean_sarray_is_marked_linear(bytes) && lean_sarray_size(bytes)==2 &&
      lean_sarray_cptr(bytes)[0]==37;lean_dec(bytes);
 }
 lean_object *fake=lean_alloc_ctor(0,7,0);
 for(unsigned i=0;i<7;++i) lean_ctor_set(fake,i,lean_box(0));
 lean_object *result=hex_test_combine_owned(fake,0,lean_box(0),lean_box(0),
   lean_box(100),lean_box(10000),lean_box(10000),1);
 ok=ok && lean_obj_tag(result)==1 && lean_ctor_get(result,0)==fake;
 lean_dec(result);
 fake=lean_alloc_ctor(0,8,1);
 for(unsigned i=0;i<8;++i) lean_ctor_set(fake,i,lean_box(0));
 lean_object *index=lean_alloc_ctor(0,1,0);lean_ctor_set(index,0,lean_box(0));
 lean_ctor_set(fake,5,index);lean_ctor_set_uint8(fake,8*sizeof(void*),0);
 result=hex_test_combine_owned(fake,0,lean_box(0),lean_box(0),lean_box(100),
   lean_box(10000),lean_box(10000),1);
 ok=ok && lean_obj_tag(result)==1 && lean_ctor_get(result,0)==fake;lean_dec(result);
 return lean_io_result_mk_ok(lean_box(ok));
}
static uint64_t mersenne_vectors=0,zero_scans=0,packets16=0;
static uint32_t widths16=0;
#define HEX_GROEBNER_AVX512_USED(w,c) (++packets16,widths16|=1u<<(2*((w)==1?0:(w)==2?1:2)+!(c)))
#define HEX_GROEBNER_ZERO_SCAN_USED() (++zero_scans)
#define HEX_GROEBNER_MERSENNE_USED() (++mersenne_vectors)
#define hex_scan8 hex_test_scan8_base
#define hex_scan8_m31 hex_test_scan8_m31_base
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames/HexGroebner/ffi/matrix_simd.h"
#undef hex_scan8
#undef hex_scan8_m31
static uint64_t vector_contiguous=0,vector_gather=0;
static uint32_t vector_widths=0;
#if HEX_GROEBNER_AVX2
static __typeof__(hex_test_scan8_base) hex_test_scan8_counted;
__attribute__((target("avx2"),always_inline))
static inline unsigned hex_test_scan8_counted(uint8_t *dense,const uint8_t *columns,
 const uint8_t *coefficients,size_t entry,uint64_t column_count,uint32_t p,
 uint32_t multiplier,uint32_t reduction,unsigned width) {
 unsigned n=hex_test_scan8_base(dense,columns,coefficients,entry,column_count,p,multiplier,reduction,width);
 if(n) {uint32_t first,last;memcpy(&first,columns+entry*4,4);memcpy(&last,columns+(entry+7)*4,4);
  if(last-first==7) ++vector_contiguous;else ++vector_gather;
  unsigned group=width==1?0:width==2?1:2;
  vector_widths|=1u<<(2*group+(last-first!=7));}
 return n;
}
__attribute__((target("avx2"),always_inline))
static inline unsigned hex_test_scan8_m31_counted(uint8_t *dense,const uint8_t *columns,
 const uint8_t *coefficients,size_t entry,uint64_t column_count,uint32_t p,
 uint32_t multiplier,uint32_t reduction,unsigned width) {
 unsigned n=hex_test_scan8_m31_base(dense,columns,coefficients,entry,column_count,p,multiplier,reduction,width);
 if(n) {uint32_t first,last;memcpy(&first,columns+entry*4,4);memcpy(&last,columns+(entry+7)*4,4);
  if(last-first==7) ++vector_contiguous;else ++vector_gather;
  unsigned group=3;
  vector_widths|=1u<<(2*group+(last-first!=7));}
 return n;
}
#define hex_scan8 hex_test_scan8_counted
#define hex_scan8_m31 hex_test_scan8_m31_counted
#endif
static uint64_t dense_prepares=0,dense_scans=0,dense_updates=0,dense_admitted=0;
#define HEX_GROEBNER_DENSE_USED() (++dense_updates)
#define lean_hex_prepare_dense hex_test_prepare_dense
#define lean_hex_dense_transition hex_test_dense_transition
#define lean_hex_scan_transition hex_test_scan
#define lean_hex_gather hex_test_gather
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames/HexGroebner/ffi/matrix_scan.c"
#undef lean_hex_scan_transition
#undef lean_hex_gather
#undef lean_hex_prepare_dense
#undef lean_hex_dense_transition
__typeof__(hex_test_prepare_dense) __wrap_lean_hex_prepare_dense;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_prepare_dense(uint64_t p,b_lean_obj_arg columns,
 b_lean_obj_arg source,b_lean_obj_arg work,b_lean_obj_arg bytes) {
 ++dense_prepares;
 lean_object *result=hex_test_prepare_dense(p,columns,source,work,bytes);
 if(lean_sarray_size(lean_ctor_get(lean_ctor_get(result,0),1))) ++dense_admitted;
 return result;
}
__typeof__(hex_test_dense_transition) __wrap_lean_hex_dense_transition;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_dense_transition(uint64_t p,b_lean_obj_arg columns,
 b_lean_obj_arg slots,b_lean_obj_arg pivots,lean_obj_arg initial,b_lean_obj_arg quantum,
 b_lean_obj_arg work,b_lean_obj_arg trace,uint8_t provenance) {
 ++dense_scans;return hex_test_dense_transition(p,columns,slots,pivots,initial,quantum,work,trace,provenance);
}
LEAN_EXPORT lean_obj_res hex_test_dense_admitted(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(dense_admitted));
}
LEAN_EXPORT lean_obj_res hex_test_dense_counts(lean_obj_arg world) {
 (void)world;lean_object *tail=lean_alloc_ctor(0,2,0),*out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(tail,0,lean_box_uint64(dense_scans));lean_ctor_set(tail,1,lean_box_uint64(dense_updates));
 lean_ctor_set(out,0,lean_box_uint64(dense_prepares));lean_ctor_set(out,1,tail);
 return lean_io_result_mk_ok(out);
}

static uint64_t whole_accepted=0,whole_deferred=0,whole_joint=0,whole_independent=0;
static uint64_t binary_frames=0,binary_scans=0,binary_bytes=0;
static uint64_t binary_groups=0,binary_installed=0,binary_initialized=0;
#define HEX_GROEBNER_BINARY_ROW_INSTALLED(packed) (++binary_installed,binary_initialized+=(packed))
#define HEX_GROEBNER_BINARY_GROUPS(n) (binary_groups+=(n))
static uint64_t binary_tables=0;
#define HEX_GROEBNER_BINARY_TABLE_USED() (++binary_tables)
static uint64_t binary_projects=0;
#define HEX_GROEBNER_BINARY_PROJECT_USED() (++binary_projects)
static uint64_t binary_sparse=0,binary_words=0,binary_high_words=0;
#define HEX_GROEBNER_BINARY_SCAN_USED() (++binary_scans)
#define HEX_GROEBNER_BINARY_PIVOTS_USED(n) (++binary_frames,binary_bytes+=lean_sarray_size(c.binary_rows)+lean_sarray_size(c.binary_meta)+(c.project_rows?lean_sarray_size(c.project_rows):0)+(c.project_meta?lean_sarray_size(c.project_meta):0)+(c.project_table?lean_sarray_size(c.project_table):0))
#define HEX_GROEBNER_BINARY_SPARSE_USED() (++binary_sparse)
#define HEX_GROEBNER_BINARY_WORD_USED(id) (++binary_words,(id)>=1024?++binary_high_words:0)
#define HEX_GROEBNER_MATRIX_ACCEPTED() (++whole_accepted,independent?++whole_independent:++whole_joint)
#define HEX_GROEBNER_MATRIX_DEFERRED() (++whole_deferred)
#define HEX_GROEBNER_BINARY_POISON 1
#define lean_hex_groebner_eliminate_matrix hex_test_whole
static uint64_t continuation_phases[8]={0},continuation_successes=0;
/* cont_counts can leave its scalar cache partial for arbitrary Nat counters.
   Inspect that cache only while fast is true; the isolated F4 window uses it. */
static uint64_t continuation_reduced=0,continuation_zero=0,continuation_inverses=0;
#define HEX_GROEBNER_CONT_INVERSE() (++continuation_inverses)
#define HEX_GROEBNER_CONT_SUCCESS(initial,phase,result,reductions,zero_rows) do {  if((initial)!=7 && (phase)==7 && !lean_is_scalar(result) && lean_obj_tag(result)==1) {   lean_object *answer=lean_ctor_get(result,0);   if(!lean_is_scalar(answer) && lean_obj_tag(answer)==1) { ++continuation_successes; continuation_reduced+=fast && (reductions)>0; continuation_zero+=fast && (zero_rows)>0; }  } } while(0)
static uint64_t cont_exhausted[8][7]={{0}},cont_invalid_masks[6]={0};
static uint64_t cont_validation_work[2]={0};
#define HEX_GROEBNER_CONT_VALIDATE_WORK(s,w) (cont_validation_work[s]|=UINT64_C(1)<<(w))
static uint64_t cont_declined_mask=0,cont_edge_mask=0,cont_allocated_mask=0;
#define HEX_GROEBNER_CONT_EXHAUSTED(p,r,w) (cont_exhausted[p][r]|=UINT64_C(1)<<(w))
#define HEX_GROEBNER_CONT_INVALID(t,w) (cont_invalid_masks[t]|=UINT64_C(1)<<(w))
#define HEX_GROEBNER_CONT_DECLINE(w) (cont_declined_mask|=UINT64_C(1)<<(w))
#define HEX_GROEBNER_CONT_EDGE(w) (cont_edge_mask|=UINT64_C(1)<<(w))
#define HEX_GROEBNER_CONT_ALLOCATE(w) (cont_allocated_mask|=UINT64_C(1)<<(w))

static uint64_t cont_count=0,cont_factor=0,cont_ticks=0,cont_max_ticks=0,cont_max_units=0,cont_violations=0;
#define HEX_GROEBNER_CONT_BEGIN(c,r,n,o) do {cont_count=(n);cont_factor=8*(c)+((o)==65536?3:2)*(r)+(o);cont_ticks=0;} while(0)
#define HEX_GROEBNER_CONT_TICK() (++cont_ticks)
#define HEX_GROEBNER_CONT_END() do {  uint64_t units=cont_ticks*cont_factor;  if(cont_ticks>cont_count || units>1048576) ++cont_violations;  if(cont_ticks>cont_max_ticks) cont_max_ticks=cont_ticks;  if(units>cont_max_units) cont_max_units=units; } while(0)

#define HEX_GROEBNER_CONT_PHASE(p) (++continuation_phases[p])
#define lean_hex_matrix_advance hex_test_matrix_advance
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames/HexGroebner/ffi/matrix_state.c"
#undef lean_hex_matrix_advance
static uint64_t continuation_calls=0;
__typeof__(hex_test_matrix_advance) __wrap_lean_hex_matrix_advance;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_advance(lean_obj_arg state,b_lean_obj_arg steps) {
 ++continuation_calls;return hex_test_matrix_advance(state,steps);
}
LEAN_EXPORT lean_obj_res hex_test_continuation_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(continuation_calls));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_successes(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(continuation_successes));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_arithmetic(lean_obj_arg world) {
 (void)world;
 lean_object *tail=lean_alloc_ctor(0,2,0);
 lean_ctor_set(tail,0,lean_box_uint64(continuation_zero));
 lean_ctor_set(tail,1,lean_box_uint64(continuation_inverses));
 lean_object *out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(continuation_reduced));lean_ctor_set(out,1,tail);
 return lean_io_result_mk_ok(out);
}
LEAN_EXPORT lean_obj_res hex_test_continuation_reset_bounds(lean_obj_arg world) {
 (void)world;cont_max_ticks=cont_max_units=cont_violations=0;
 return lean_io_result_mk_ok(lean_box(0));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_outcomes(lean_obj_arg world) {
 const uint64_t widths=(UINT64_C(1)<<1)|(UINT64_C(1)<<2)|(UINT64_C(1)<<4);
 int ok=cont_validation_work[0]==widths && cont_validation_work[1]==widths && cont_declined_mask==widths && cont_edge_mask==widths && cont_allocated_mask==widths;
 for(unsigned t=2;t<=4;++t) ok=ok && cont_invalid_masks[t]==widths;
 ok=ok && cont_exhausted[1][2]==widths && cont_exhausted[1][4]==widths && cont_exhausted[1][5]==widths;
 ok=ok && cont_exhausted[2][4]==widths && cont_exhausted[2][5]==widths;
 (void)world;return lean_io_result_mk_ok(lean_box(ok));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_workspaces(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(continuation_phases[2]));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_validations(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(continuation_phases[1]));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_phases(lean_obj_arg world) {
 (void)world;lean_object *tail=lean_alloc_ctor(0,2,0),*pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(tail,0,lean_box_uint64(continuation_phases[4]));
 lean_ctor_set(tail,1,lean_box_uint64(continuation_phases[5]));
 lean_ctor_set(pair,0,lean_box_uint64(continuation_phases[3]));lean_ctor_set(pair,1,tail);
 return lean_io_result_mk_ok(pair);
}

LEAN_EXPORT lean_obj_res hex_test_continuation_bounds(lean_obj_arg world) {
 (void)world;lean_object *tail=lean_alloc_ctor(0,2,0),*pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(tail,0,lean_box_uint64(cont_max_units));
 lean_ctor_set(tail,1,lean_box_uint64(cont_violations));
 lean_ctor_set(pair,0,lean_box_uint64(cont_max_ticks));lean_ctor_set(pair,1,tail);
 return lean_io_result_mk_ok(pair);
}

#define lean_hex_matrix_validate hex_test_matrix_validate
#define lean_hex_matrix_zeros hex_test_matrix_zeros
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames/HexGroebner/ffi/matrix_eliminate.c"
#undef lean_hex_matrix_validate
#undef lean_hex_matrix_zeros
#undef lean_hex_groebner_eliminate_matrix
static uint64_t primitive_validations=0,primitive_zeros=0;
static uint64_t primitive_validate_admitted=0,primitive_validate_declined=0;
static uint64_t primitive_zero_admitted=0,primitive_zero_declined=0;
__typeof__(hex_test_matrix_validate) __wrap_lean_hex_matrix_validate;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_validate(uint64_t p,b_lean_obj_arg limits,
 b_lean_obj_arg columns,b_lean_obj_arg index,b_lean_obj_arg row,b_lean_obj_arg stats) {
 lean_object *saved_limits[7],*saved_stats[8],*saved_row[2];
 for(unsigned i=0;i<7;++i)saved_limits[i]=lean_ctor_get(limits,i);
 for(unsigned i=0;i<8;++i)saved_stats[i]=lean_ctor_get(stats,i);
 for(unsigned i=0;i<2;++i)saved_row[i]=lean_ctor_get(row,i);
 size_t a=lean_sarray_size(saved_row[0]),b=lean_sarray_size(saved_row[1]);
 uint8_t *snapshot=NULL;
 if(a<=1048576 && b<=1048576) {
  snapshot=malloc(a+b+1);assert(snapshot);
  memcpy(snapshot,lean_sarray_cptr(saved_row[0]),a);
  memcpy(snapshot+a,lean_sarray_cptr(saved_row[1]),b);
 }
 ++primitive_validations;lean_object *result=hex_test_matrix_validate(p,limits,columns,index,row,stats);
 for(unsigned i=0;i<7;++i)assert(saved_limits[i]==lean_ctor_get(limits,i));
 for(unsigned i=0;i<8;++i)assert(saved_stats[i]==lean_ctor_get(stats,i));
 for(unsigned i=0;i<2;++i)assert(saved_row[i]==lean_ctor_get(row,i));
 if(snapshot) {
  assert(a==lean_sarray_size(saved_row[0]) && b==lean_sarray_size(saved_row[1]));
  assert(memcmp(snapshot,lean_sarray_cptr(saved_row[0]),a)==0);
  assert(memcmp(snapshot+a,lean_sarray_cptr(saved_row[1]),b)==0);free(snapshot);
 }
 if(lean_is_scalar(result))++primitive_validate_declined;else {
  ++primitive_validate_admitted;assert(lean_is_exclusive(result));
  lean_object *pair=lean_ctor_get(result,0);assert(lean_is_exclusive(pair));
  assert(lean_is_exclusive(lean_ctor_get(pair,0)));
  assert(lean_is_exclusive(lean_ctor_get(pair,1)));
 }
 return result;
}
__typeof__(hex_test_matrix_zeros) __wrap_lean_hex_matrix_zeros;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_zeros(b_lean_obj_arg size) {
 ++primitive_zeros;lean_object *result=hex_test_matrix_zeros(size);
 if(lean_is_scalar(result))++primitive_zero_declined;else {
  ++primitive_zero_admitted;assert(lean_is_exclusive(result));
  assert(lean_is_exclusive(lean_ctor_get(result,0)));
 }
 return result;
}
LEAN_EXPORT lean_obj_res hex_test_binary_counts(lean_obj_arg world) {
 (void)world;lean_object *tail=lean_alloc_ctor(0,2,0),*out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(tail,0,lean_box_uint64(binary_scans));lean_ctor_set(tail,1,lean_box_uint64(binary_bytes));
 lean_ctor_set(out,0,lean_box_uint64(binary_frames));lean_ctor_set(out,1,tail);
 return lean_io_result_mk_ok(out);
}
LEAN_EXPORT lean_obj_res hex_test_binary_installed(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(binary_installed));
 lean_ctor_set(out,1,lean_box_uint64(binary_initialized));return lean_io_result_mk_ok(out);
}
LEAN_EXPORT lean_obj_res hex_test_binary_groups(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(binary_groups));
}
LEAN_EXPORT lean_obj_res hex_test_binary_tables(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(binary_tables));
}
LEAN_EXPORT lean_obj_res hex_test_binary_projects(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(binary_projects));
}
LEAN_EXPORT lean_obj_res hex_test_binary_paths(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0),*tail=lean_alloc_ctor(0,2,0);
 lean_ctor_set(tail,0,lean_box_uint64(binary_words));lean_ctor_set(tail,1,lean_box_uint64(binary_high_words));
 lean_ctor_set(out,0,lean_box_uint64(binary_sparse));lean_ctor_set(out,1,tail);
 return lean_io_result_mk_ok(out);
}
LEAN_EXPORT lean_obj_res hex_test_matrix_primitives(lean_obj_arg world) {
 (void)world;lean_object *pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(pair,0,lean_box_uint64(primitive_validations));
 lean_ctor_set(pair,1,lean_box_uint64(primitive_zeros));return lean_io_result_mk_ok(pair);
}
LEAN_EXPORT lean_obj_res hex_test_primitive_admissions(lean_obj_arg world) {
 (void)world;lean_object *outer=lean_alloc_ctor(0,2,0),*a=lean_alloc_ctor(0,2,0),*b=lean_alloc_ctor(0,2,0);
 lean_ctor_set(a,0,lean_box_uint64(primitive_validate_admitted));
 lean_ctor_set(a,1,lean_box_uint64(primitive_validate_declined));
 lean_ctor_set(b,0,lean_box_uint64(primitive_zero_admitted));
 lean_ctor_set(b,1,lean_box_uint64(primitive_zero_declined));
 lean_ctor_set(outer,0,a);lean_ctor_set(outer,1,b);return lean_io_result_mk_ok(outer);
}
static uint64_t scan_calls=0,gather_calls=0,byte_calls=0,product_calls=0;
__typeof__(hex_test_products_attempt) __wrap_lean_hex_monomial_products_attempt;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_monomial_products_attempt(lean_obj_arg table,
 b_lean_obj_arg support,lean_obj_arg monomial,lean_obj_arg start,lean_obj_arg count,
 lean_obj_arg max_count,lean_obj_arg max_bytes,lean_obj_arg max_work,uint8_t native) {
 return hex_test_products_attempt(table,support,monomial,start,count,max_count,max_bytes,max_work,native);
}
LEAN_EXPORT lean_obj_res hex_test_batch_insertions(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(batch_insertions));
}
LEAN_EXPORT lean_obj_res hex_test_batch_counts(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(batch_hits));
 lean_ctor_set(out,1,lean_box_uint64(batch_terms));return lean_io_result_mk_ok(out);
}

LEAN_EXPORT lean_obj_res hex_test_batch_deferrals(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0),*tail=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(batch_deferrals));
 lean_ctor_set(tail,0,lean_box_uint64(batch_waste));
 lean_ctor_set(tail,1,lean_box_uint64(batch_bound_errors));
 lean_ctor_set(out,1,tail);return lean_io_result_mk_ok(out);
}
static uint64_t search_calls=0;
__typeof__(hex_test_combine_owned) __wrap_lean_hex_groebner_combine_owned;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_combine_owned(lean_obj_arg table,uint8_t operation,
 lean_obj_arg a,lean_obj_arg b,lean_obj_arg max_count,lean_obj_arg max_bytes,
 lean_obj_arg max_work,uint8_t native) {
 return hex_test_combine_owned(table,operation,a,b,max_count,max_bytes,max_work,native);
}
LEAN_EXPORT lean_obj_res hex_test_deferred_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(fused_deferred));
}
LEAN_EXPORT lean_obj_res hex_test_alias_mask(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(unique_alias_mask));
}
LEAN_EXPORT lean_obj_res hex_test_alias_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(unique_alias));
}
LEAN_EXPORT lean_obj_res hex_test_unique_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(fused_unique));
}
LEAN_EXPORT lean_obj_res hex_test_insert_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(fused_insert));
}
LEAN_EXPORT lean_obj_res hex_test_accept_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(fused_success));
}
__typeof__(hex_test_search_monomial) __wrap_lean_hex_groebner_search_monomial;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_search_monomial(uint8_t width,
 uint64_t arity,uint64_t count,uint64_t hash,uint64_t link,uint64_t quantum,
 b_lean_obj_arg exponents,b_lean_obj_arg metadata,b_lean_obj_arg links,
 b_lean_obj_arg candidate,b_lean_obj_arg allowance) {
 ++search_calls;
 return hex_test_search_monomial(width,arity,count,hash,link,quantum,exponents,metadata,links,candidate,allowance);
}
LEAN_EXPORT lean_obj_res hex_test_search_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(search_calls));
}
__typeof__(hex_test_whole) __wrap_lean_hex_groebner_eliminate_matrix;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_eliminate_matrix(uint64_t p,
 b_lean_obj_arg limits,b_lean_obj_arg columns,b_lean_obj_arg reducers,
 b_lean_obj_arg targets,b_lean_obj_arg sugars,uint8_t independent) {
 lean_object *result=hex_test_whole(p,limits,columns,reducers,targets,sugars,independent);
 const char *path=getenv("HEX_GROEBNER_FRAME_LOG");
 if(path && p==2 && lean_ctor_get_uint8(limits,7*sizeof(void*)+1) && lean_is_scalar(columns)) {
  uint64_t nc=lean_unbox(columns),nr=lean_array_size(reducers),nt=lean_array_size(targets),entries=0;
  for(uint64_t i=0;i<nr+nt;++i) {
   lean_object *row=lean_array_cptr(i<nr?reducers:targets)[i<nr?i:i-nr];
   entries+=lean_sarray_size(lean_ctor_get(row,0))/4;
  }
  uint64_t words=(nc+63)/64,rows=nr+nt;
  uint64_t logical=rows*65+2*entries+nc*5+nt*(entries+(nt+3)*nc+64)+nc;
  uint64_t physical=rows*words+3*entries+4*nt*nc+6*nc+nt*(rows*words+64);
  uint64_t scratch=((rows<nc?rows:nc)+1)*words*8;
  /* A loose upper bound includes all inputs, normalized reducers, maximal
     target output, headers and both workspaces. Below it, bytes cannot refuse. */
  uint64_t byte_upper=scratch+20*entries+128*rows+25*nt*nc+10*nc;
  lean_object *cap=lean_ctor_get(limits,4);
  uint64_t allowance=lean_is_scalar(cap)?lean_unbox(cap):UINT64_MAX/2;
  int accepted=!lean_is_scalar(result);
  const char *reason=accepted?"accepted":nc>131072||nr>131072||nt>4096?"shape":
    logical>(UINT64_C(1)<<38)?"logical":physical>(UINT64_C(1)<<34)?"physical":
    byte_upper<=allowance?"other_without_byte_refusal":"other_possible_byte_refusal";
  FILE *stream=fopen(path,"a");
  if(!stream) abort();
  fprintf(stream,"%llu,%llu,%llu,%llu,%s,%llu,%llu\n",
   (unsigned long long)nc,(unsigned long long)nr,(unsigned long long)nt,
   (unsigned long long)entries,reason,(unsigned long long)byte_upper,(unsigned long long)allowance);
  if(fclose(stream)) abort();
 }
 return result;
}
LEAN_EXPORT lean_obj_res hex_test_whole_modes(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(whole_joint));
 lean_ctor_set(out,1,lean_box_uint64(whole_independent));return lean_io_result_mk_ok(out);
}
LEAN_EXPORT lean_obj_res hex_test_whole_counts(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(whole_accepted));
 lean_ctor_set(out,1,lean_box_uint64(whole_deferred));return lean_io_result_mk_ok(out);
}
static uint64_t comparison_calls=0,comparison_declines=0;
__typeof__(hex_test_compare) __wrap_lean_hex_groebner_compare_monomials;
LEAN_EXPORT uint8_t __wrap_lean_hex_groebner_compare_monomials(uint8_t operation,uint8_t width,
 uint64_t arity,uint64_t left,uint64_t right,b_lean_obj_arg arena) {
 ++comparison_calls;
 uint8_t result=hex_test_compare(operation,width,arity,left,right,arena);
 if(result==3) ++comparison_declines;
 return result;
}
LEAN_EXPORT lean_obj_res hex_test_comparison_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(comparison_calls));
}
LEAN_EXPORT lean_obj_res hex_test_comparison_declines(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(comparison_declines));
}
static uint64_t trie_calls=0,trie_declines=0;
__typeof__(hex_test_validate) __wrap_lean_hex_groebner_validate_trie;
LEAN_EXPORT uint8_t __wrap_lean_hex_groebner_validate_trie(b_lean_obj_arg arity,
 b_lean_obj_arg nodes,b_lean_obj_arg edges,uint64_t max_leading) {
 return hex_test_validate(arity,nodes,edges,max_leading);
}

__typeof__(hex_test_trie) __wrap_lean_hex_groebner_lookup_trie;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_lookup_trie(b_lean_obj_arg view,uint8_t width,
 uint64_t count,uint64_t query,b_lean_obj_arg arena,b_lean_obj_arg metadata,uint64_t remaining) {
 ++trie_calls;
 lean_object *result=hex_test_trie(view,width,count,query,arena,metadata,remaining);
 if(lean_ctor_get_uint8(result,2*sizeof(void*))==3) ++trie_declines;
 return result;
}
LEAN_EXPORT lean_obj_res hex_test_trie_counts(lean_obj_arg world) {
 (void)world;lean_object *pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(pair,0,lean_box_uint64(trie_calls));
 lean_ctor_set(pair,1,lean_box_uint64(trie_declines));
 return lean_io_result_mk_ok(pair);
}

__typeof__(hex_test_equal_products) __wrap_lean_hex_groebner_equal_products;
LEAN_EXPORT uint8_t __wrap_lean_hex_groebner_equal_products(uint8_t width,
 uint64_t arity,uint64_t count,uint64_t multiplier,uint64_t start,uint64_t terms,
 b_lean_obj_arg arena,b_lean_obj_arg base,b_lean_obj_arg result) {
 ++product_calls;return hex_test_equal_products(width,arity,count,multiplier,start,terms,arena,base,result);
}
LEAN_EXPORT lean_obj_res hex_test_product_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(product_calls));
}
__typeof__(hex_test_equal_bytes) __wrap_lean_hex_groebner_equal_bytes;
LEAN_EXPORT uint8_t __wrap_lean_hex_groebner_equal_bytes(b_lean_obj_arg left,
 b_lean_obj_arg right,b_lean_obj_arg start,b_lean_obj_arg count) {
 ++byte_calls;return hex_test_equal_bytes(left,right,start,count);
}
__typeof__(hex_test_scan) __wrap_lean_hex_scan_transition;
__typeof__(hex_test_gather) __wrap_lean_hex_gather;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_scan_transition(uint64_t p,
 b_lean_obj_arg slots,b_lean_obj_arg pivots,lean_obj_arg initial,
 b_lean_obj_arg quantum,b_lean_obj_arg work,b_lean_obj_arg trace,uint8_t provenance) {
 ++scan_calls;return hex_test_scan(p,slots,pivots,initial,quantum,work,trace,provenance);
}
LEAN_EXPORT lean_obj_res __wrap_lean_hex_gather(uint64_t p,lean_obj_arg initial,
 b_lean_obj_arg stop,b_lean_obj_arg quantum,b_lean_obj_arg entries,
 b_lean_obj_arg bytes,b_lean_obj_arg work,uint64_t factor) {
 ++gather_calls;return hex_test_gather(p,initial,stop,quantum,entries,bytes,work,factor);
}
LEAN_EXPORT lean_obj_res hex_test_zero_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(zero_scans));
}
LEAN_EXPORT lean_obj_res hex_test_avx512_widths(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint32(widths16));
}
LEAN_EXPORT lean_obj_res hex_test_avx512_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(packets16));
}
LEAN_EXPORT lean_obj_res hex_test_avx512_available(lean_obj_arg world) {
 (void)world;
#if HEX_GROEBNER_AVX512
 return lean_io_result_mk_ok(lean_box(hex_avx512_available()));
#else
 return lean_io_result_mk_ok(lean_box(0));
#endif
}
LEAN_EXPORT lean_obj_res hex_test_mersenne_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(mersenne_vectors));
}
LEAN_EXPORT lean_obj_res hex_test_byte_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(byte_calls));
}
LEAN_EXPORT lean_obj_res hex_test_counts(lean_obj_arg world) {
 (void)world;lean_object *pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(pair,0,lean_box_uint64(scan_calls));
 lean_ctor_set(pair,1,lean_box_uint64(gather_calls));
 return lean_io_result_mk_ok(pair);
}
LEAN_EXPORT lean_obj_res hex_test_vector_counts(lean_obj_arg world) {
 (void)world;lean_object *pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(pair,0,lean_box_uint64(vector_contiguous));
 lean_ctor_set(pair,1,lean_box_uint64(vector_gather));
 return lean_io_result_mk_ok(pair);
}
LEAN_EXPORT lean_obj_res hex_test_widths(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint32(vector_widths));
}
LEAN_EXPORT lean_obj_res hex_test_avx2(lean_obj_arg world) {
 (void)world;
#if HEX_GROEBNER_AVX2
 return lean_io_result_mk_ok(lean_box(hex_avx2_available()));
#else
 return lean_io_result_mk_ok(lean_box(0));
#endif
}
