from pathlib import Path
import os,subprocess,json
state=Path('/home/kim/tmp/issue-10987');base=state/'binary-words-production'
command=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'binary-dense-suite/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/compute'),'--baseline',str(state/'binary-pivots-production/binaries/compute'),'--baseline-manifest',str(state/'binary-pivots-production/manifest.json'),'--hex-dense-pivots','false','--baseline-dense-pivots','false','--hex-binary-pivots','true','--baseline-binary-pivots','true','--output',str(base/'f2-false-repeat')]
assert json.loads((state/'binary-pivots-production/manifest.json').read_text())['source_fingerprint']=='86ad4e3f842f'
assert command[command.index('--baseline')+1]==str(state/'binary-pivots-production/binaries/compute')
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
result=subprocess.run(command,env=env);(base/'measure-f2-repeat.py').write_bytes(Path(__file__).read_bytes());raise SystemExit(result.returncode)
