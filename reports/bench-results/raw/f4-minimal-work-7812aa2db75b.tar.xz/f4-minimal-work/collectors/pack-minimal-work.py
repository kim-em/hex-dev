from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();assert identity['source_fingerprint']=='7812aa2db75b'
native=json.loads((s/'minimal-work-verified-native-status.json').read_text());full=json.loads((s/'minimal-work-full-status.json').read_text())
assert len(native)==2 and len(full)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in native+full)
payload={}
def add(n,p):
 assert n not in payload,n
 payload[n]=p.read_bytes()
def tree(label,base,shallow=False):
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if p.is_file() and 'binaries'not in rel.parts and '.lake'not in rel.parts and (not shallow or len(rel.parts)==1 or rel.parts[0]in ['root-sources','compiler-inputs']):add(label+'/'+str(rel),p)
tree('baseline',s/'product-pointers-production',True);tree('candidate',s/'minimal-work-production')
for cc in ['clang','gcc']:
 add('native-'+cc+'.log',s/('minimal-work-verified-'+cc+'.log'));tree('probes/'+cc,s/('minimal-work-verified-'+cc))
add('native-status.json',s/'minimal-work-verified-native-status.json');add('full-status.json',s/'minimal-work-full-status.json')
for n in ['build','oracles','driver','bench','dag','phase4','manifest','headers','lines']:add('full/'+n+'.log',s/('minimal-work-full-'+n+'.log'))
for n in ['measure-minimal-work-f2.py','measure-minimal-work-prime.py','measure-minimal-work-f2-repeat.py','measure-minimal-work-prime-repeat.py','minimal-work-native-checks.py','minimal-work-full-checks.py','pack-minimal-work.py']:add('collectors/'+n,s/n)
for n in ['minimal-work-freeze.log','minimal-work-freeze-corrected.log','minimal-work-native-checks.log','minimal-work-model-build.log','minimal-work-prefix-build.log','minimal-work-native-model.log']:add('diagnostics/'+n,s/n)
text=tree_listing(CHECKS,identity['source_commit']);payload['checks.manifest']=text.encode()
for line in text.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode()
out=s/('f4-minimal-work-'+identity['source_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-minimal-work/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
