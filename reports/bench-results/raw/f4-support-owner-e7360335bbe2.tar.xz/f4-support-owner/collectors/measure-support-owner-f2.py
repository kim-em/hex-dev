from pathlib import Path
import os,subprocess,json
state=Path('/home/kim/tmp/issue-10987');base=state/'support-owner-production'
command=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'binary-dense-suite/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/compute'),'--baseline',str(state/'binary-pr30-review-production/binaries/compute'),'--baseline-manifest',str(state/'binary-pr30-review-production/manifest.json'),'--hex-dense-pivots','false','--baseline-dense-pivots','false','--hex-binary-pivots','true','--baseline-binary-pivots','true','--output',str(base/'f2-false')]
assert command[command.index('--baseline')+1]==str(state/'binary-pr30-review-production/binaries/compute')
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
result=subprocess.run(command,env=env);(base/'measure-f2.py').write_bytes(Path(__file__).read_bytes());raise SystemExit(result.returncode)
