from pathlib import Path
import json,subprocess,hashlib
s=Path('/home/kim/tmp/issue-10987');out=s/'support-owner-controls';rows=json.loads((out/'status.json').read_text());assert len(rows)==1 and rows[0]['label']=='positive'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=out/'negative';root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-owner-negative');data=[]
for line in(d/'stdout').read_text().splitlines():
 route,valid,q,c,b,p=line.split(',');assert valid=='true' and int(q)>0 and int(c)>0;data.append(dict(route=int(route),queues=int(q),clears=int(c),bitmap_and_zero_fill_copies=int(b),pending_copies=int(p)))
assert [r['route']for r in data]==[0,1,2] and data[0]['bitmap_and_zero_fill_copies']>0 and data[2]['bitmap_and_zero_fill_copies']>0
assert all(r['pending_copies']==0 for r in data) and (d/'stderr').read_text()==''
assert subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()==['HexGroebner/F4.lean','HexGroebner/Producer/Compute.lean','HexGroebner/Sampled.lean']
record=dict(label='negative',root=str(root),sanitizer_environment=rows[0]['sanitizer_environment'],command=[x.replace(str(out/'positive'),str(d))for x in rows[0]['command']],binary_sha256=sha(d/'.lake/build/bin/owner'),probe_sha256=sha(d/'probe.c'),owner_lean_sha256=sha(d/'Owner.lean'),rows=data,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_diff=subprocess.check_output(['git','diff','--binary','HEAD','--','HexGroebner/'],cwd=root,text=True))
rows.append(record);(out/'status.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows)
(out/'scope.txt').write_text('Non-timed ClangASan/UBSan positive/negative ownership diagnostic. Current1b731source versus only F4/Sampled/Producer.Compute restored to9ade64. Deterministic and producer controls showthreecopiesbefore andzeroafter; sampled smallcasewasalreadyzero. All pendingqueuecopycounterszero. Firstpositiveattempt usedleakchecking unlikeapprovedharness andreporteda320byteLean/runtime-loaderstaticleak; stderrpreserved. Matchedrunsuseexistingharness ASAN_OPTIONS=detect_leaks=0,UBSAN_OPTIONS=halt_on_error=1,LEAN_ABORT_ON_NONLINEAR=1. Theinitialallroutes-copy expectationwasfalseforthesampledcase; assertionlogandactualsuccessfulCSVretained; finalizationvalidatesobservedrouteswithoutre-executing completedbinaries.\n')
