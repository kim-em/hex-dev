from pathlib import Path
import json,subprocess,os,hashlib,re
s=Path('/home/kim/tmp/issue-10987');positive=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration');negative=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-owner-negative');template=s/'support-owner-verified-clang';out=s/'support-owner-controls';out.mkdir(exist_ok=True);results=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR=str(s),HEX_GROEBNER_TEST_SEED='0',ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1',LEAN_ABORT_ON_NONLINEAR='1')
for label,root in [('positive',positive),('negative',negative)]:
 d=out/label;d.mkdir(exist_ok=True);m=json.loads((template/'lake-manifest.json').read_text());m['name']='GroebnerOwnerControl';m['packagesDir']=str(root/'.lake/packages')
 for p in m['packages']:
  if p['name']=='Hex':p['dir']=str(root)
 (d/'lake-manifest.json').write_text(json.dumps(m,indent=2)+'\n');(d/'lean-toolchain').write_bytes((root/'lean-toolchain').read_bytes())
 lake=(template/'lakefile.lean').read_text().split('target probeAVX2 pkg')[0].replace('package GroebnerMatrixChecks','package GroebnerOwnerControl').replace(str(positive),str(root)).replace('lean_exe checkNative where\n  root := `CheckNative','lean_exe owner where\n  root := `Owner')
 (d/'lakefile.lean').write_text(lake)
 probe=(template/'probe.c').read_text().replace(str(positive),str(root)).replace('static uint64_t support_calls=0,support_copies=0,clear_calls=0;','static uint64_t support_calls=0,support_copies=0,clear_calls=0,pending_copies=0;').replace(' ++support_calls;if(!lean_is_exclusive(bits))',' ++support_calls;if(lean_array_size(pending) && !lean_is_exclusive(pending))++pending_copies;\n if(!lean_is_exclusive(bits))')
 probe+='\nLEAN_EXPORT lean_obj_res owner_pending_copies(lean_obj_arg world) {(void)world;return lean_io_result_mk_ok(lean_box_uint64(pending_copies));}\n'
 (d/'probe.c').write_text(probe)
 (d/'Owner.lean').write_text('''import HexGroebner.PairRowsConformance
@[extern "hex_test_support_count"] opaque queues : IO UInt64
@[extern "hex_test_support_clears"] opaque clears : IO UInt64
@[extern "hex_test_support_copies"] opaque copies : IO UInt64
@[extern "owner_pending_copies"] opaque pendingCopies : IO UInt64

def main : IO Unit := do
  let value := (← IO.getEnv "HEX_GROEBNER_TEST_SEED").getD "0"
  let some seed := value.toNat? | throw (IO.userError "invalid seed")
  for route in [:3] do
    let q ← queues
    let c ← clears
    let b ← copies
    let p ← pendingCopies
    let valid := Hex.Groebner.PairRowsConformance.systemChecks seed route
    IO.println s!"{route},{valid},{(← queues)-q},{(← clears)-c},{(← copies)-b},{(← pendingCopies)-p}"
    if !valid then throw (IO.userError "public-route result mismatch")
''')
 with(d/'build.log').open('w')as f:subprocess.run(['lake','build','owner'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 binary=d/'.lake/build/bin/owner';command=['/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2','--library-path','/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib','--preload','/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/resource-root/lib/linux/libclang_rt.asan-x86_64.so',str(binary)]
 with(d/'stdout').open('w')as stdout,(d/'stderr').open('w')as stderr:r=subprocess.run(command,cwd=d,env=env,stdout=stdout,stderr=stderr)
 assert r.returncode==0;rows=[]
 for line in(d/'stdout').read_text().splitlines():
  route,valid,q,c,b,p=line.split(',');assert valid=='true' and int(q)>0 and int(c)>0;rows.append(dict(route=int(route),queues=int(q),clears=int(c),bitmap_and_zero_fill_copies=int(b),pending_copies=int(p)))
 assert [r['route']for r in rows]==[0,1,2]
 assert all(r['bitmap_and_zero_fill_copies']==0 and r['pending_copies']==0 for r in rows)if label=='positive'else all(r['bitmap_and_zero_fill_copies']>0 for r in rows)
 record=dict(label=label,root=str(root),sanitizer_environment={k:env[k]for k in ['ASAN_OPTIONS','UBSAN_OPTIONS','LEAN_ABORT_ON_NONLINEAR']},command=command,binary_sha256=sha(binary),probe_sha256=sha(d/'probe.c'),owner_lean_sha256=sha(d/'Owner.lean'),rows=rows,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_diff=subprocess.check_output(['git','diff','--binary','HEAD','--','HexGroebner/'],cwd=root,text=True));results.append(record);(out/'status.json').write_text(json.dumps(results,indent=2)+'\n');print(label,rows,flush=True)
