from pathlib import Path
import json,hashlib,tarfile,lzma,io
s=Path('/home/kim/tmp/issue-10987');base=s/'support-owner-controls';payload={}
def add(name,p):assert name not in payload;payload[name]=p.read_bytes()
for p in sorted(base.rglob('*')):
 rel=p.relative_to(base)
 if p.is_file() and '.lake'not in rel.parts:add('controls/'+str(rel),p)
for label,root in [('positive',Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-integration')),('negative',Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-support-owner-negative'))]:
 for path in ['HexGroebner/F4.lean','HexGroebner/Sampled.lean','HexGroebner/Producer/Compute.lean','HexGroebner/Runtime.lean','HexGroebner/Symbolic.lean','HexGroebner/ffi/row_update.c','conformance/HexGroebner/PairRowsConformance.lean']:add('sources/'+label+'/'+path,root/path)
for name in ['check-support-owner-control.py','check-support-owner-control-runtime-matched.py','finish-support-owner-control.py','support-owner-controls.log','support-owner-controls-runtime-matched.log','support-owner-control-finalization.log']:add('collectors/'+name,s/name)
payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode();out=s/'f4-support-owner-controls-e7360335bbe2.tar.xz';assert not out.exists()
with lzma.open(out,'wb',preset=6)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for n,b in sorted(payload.items()):
  item=tarfile.TarInfo('f4-support-owner-controls/'+n);item.size=len(b);item.mode=0o644;tar.addfile(item,io.BytesIO(b))
print(out,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
