from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root));from scripts.bench.groebner_checks import source_identity
identity=source_identity();rows=json.loads((s/'active-list-rebased-full-status.json').read_text());assert len(rows)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in rows);payload={}
def add(n,p):assert n not in payload;payload[n]=p.read_bytes()
base=s/'active-list-rebased-production'
for p in sorted(base.rglob('*')):
 if p.is_file()and'binaries'not in p.relative_to(base).parts:add('current/'+str(p.relative_to(base)),p)
for row in rows:add('full/'+row['name']+'.log',Path(row['log']))
for name,path in [('full-status.json',s/'active-list-rebased-full-status.json'),('full-collector.py',s/'active-list-rebased-full-checks.py'),('header-deps-status.json',s/'header-deps-status.json'),('header-collector.py',s/'check-header-deps.py'),('pack.py',Path(__file__))]:add(name,path)
for label in ['initial','changed','restored']:add('header/'+label+'.log',s/f'header-deps-{label}.log')
objects={'monomial_hit.o':hashlib.sha256((root/'.lake/build/HexGroebner/ffi/monomial_hit.o').read_bytes()).hexdigest()};assert all(r['object_sha256']==objects['monomial_hit.o']for r in json.loads((s/'header-deps-status.json').read_text()))
payload['object-control.json']=(json.dumps(objects,indent=2)+'\n').encode();payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode();out=root/'reports/bench-results/raw'/('f4-retirement-rebased-'+identity['source_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-retirement-rebased/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
