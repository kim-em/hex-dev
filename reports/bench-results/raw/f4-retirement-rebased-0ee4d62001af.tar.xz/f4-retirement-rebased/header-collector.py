from pathlib import Path
import hashlib,json,os,subprocess
w=Path.cwd();s=Path('/home/kim/tmp/issue-10987');header=w/'HexGroebner/ffi/trie_lookup.h';original=header.read_bytes();obj=w/'.lake/build/HexGroebner/ffi/monomial_hit.o';rows=[];env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR=str(s))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 for label,data in [('initial',original),('changed',original+b'\n/* dependency rebuild probe */\n'),('restored',original)]:
  before=obj.stat().st_mtime_ns;header.write_bytes(data)
  with(s/f'header-deps-{label}.log').open('w')as out:r=subprocess.run(['lake','build','hexgroebnerMonomialO'],env=env,stdout=out,stderr=subprocess.STDOUT)
  assert r.returncode==0,label
  after=obj.stat().st_mtime_ns
  if label!='initial':assert after!=before,label
  rows.append(dict(label=label,exit_code=r.returncode,mtime_before=before,mtime_after=after,object_sha256=sha(obj),header_sha256=sha(header)))
 assert len({r['object_sha256']for r in rows})==1
 baseline=s.parent.parent/'worktrees/hex-dev/hex-dev-issue-10987-sdk-native/.lake/build/HexGroebner/ffi/monomial_hit.o'
 baseline=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sdk-native/.lake/build/HexGroebner/ffi/monomial_hit.o')
 assert sha(baseline)==sha(obj)
 (s/'header-deps-status.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS: header edit/restoration rebuild object; all hashes equal old default',flush=True)
finally:header.write_bytes(original)
