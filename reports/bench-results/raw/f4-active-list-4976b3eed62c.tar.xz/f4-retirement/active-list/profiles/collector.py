from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
s=Path('/home/kim/tmp/issue-10987');base=s/'active-list-production';old=s/'avx512-default-production';out=base/'profiles';out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('cpu_lease',base/'root-sources/scripts/bench/cpu_lease.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
manifests={a:json.loads((p/'manifest.json').read_text())for a,p in [('A',old),('B',base)]};cpu,lease=module.cpu_lease();records=[]
try:
 for case in ['kat8-15','cyclic7-31']:
  for trial,arm in enumerate(['A','B','B','A']):
   label=f'{case}-{trial}-{arm}';data=out/(label+'.data');root=old if arm=='A'else base
   if case=='frame1024':
    binary=root/'binaries/bench';args=['run','Hex.Groebner.Bench.delayedMatrix','--outer-trials','1','--param-schedule','doubling','--param-floor','1024','--param-ceiling','1024','--export-file',str(out/(label+'.json'))]
   else:
    binary=root/'binaries/compute';inp=base/'f4/inputs'/(case+'.json');args=['--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000','--scheduling','degree',str(inp)]
   command=['perf','record','-o',str(data),'-e','cycles:u','-F','997','--call-graph','dwarf,8192','--',str(binary),*args];start=time.time_ns();load=os.getloadavg()
   with(out/(label+'.stdout')).open('wb')as stdout,(out/(label+'.stderr')).open('wb')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=lambda:os.sched_setaffinity(0,{cpu}),env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
   assert r.returncode in [0,2]if case=='frame1024'else r.returncode==0
   if case=='frame1024':
    point=json.loads((out/(label+'.json')).read_text())['results'][0]['points'][0];expected=json.loads((base/f'kernels/matched/dense/b0-1024-{arm}/result.json').read_text())['results'][0]['points'][0];assert point['result_hash']==expected['result_hash']
   else:
    actual=json.loads((out/(label+'.stdout')).read_text());expected=json.loads((base/f'f4/{case}-b0-{arm}.stdout').read_text());actual.pop('candidateNanos');expected.pop('candidateNanos');assert actual==expected
   with(out/(label+'.report')).open('wb')as report:subprocess.run(['perf','report','--stdio','-i',str(data),'--no-children','--percent-limit','0.3'],stdout=report,stderr=subprocess.STDOUT,check=True)
   records.append(dict(case=case,trial=trial,arm=arm,command=command,exit_code=r.returncode,started_ns=start,finished_ns=time.time_ns(),load_start=load,load_end=os.getloadavg(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
   (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,host=os.uname().nodename,manifest=manifests,records=records,scope='Fixed ABBA diagnostic cycle profiles; excluded from scientific timing ratios.'),indent=2)+'\n');print(label,r.returncode,flush=True)
finally:lease.close();(out/'collector.py').write_bytes(Path(__file__).read_bytes())
