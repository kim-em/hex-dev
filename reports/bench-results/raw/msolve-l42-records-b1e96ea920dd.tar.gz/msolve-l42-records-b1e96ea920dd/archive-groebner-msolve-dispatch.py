from pathlib import Path
import json,subprocess,hashlib,shutil,tarfile
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987');b=Path('/tmp/hex-groebner-mersenne-dispatch-production');ms=Path('/tmp/hex-groebner-msolve');raw=root/'reports/bench-results/raw';rows=[]
source=b/'msolve-source-3672113ee2c6.tar'
with source.open('wb') as f:subprocess.run(['git','archive','HEAD','src','Makefile.am','configure.ac','COPYING'],cwd=ms,stdout=f,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in sorted(b.glob('msolve-l*-records-*')):
 m=json.loads((p/'metadata.json').read_text());assert sha(ms/'.libs/msolve')==m['msolve_binary_sha256']
 correction={'scope':'The original metadata.msolve_build compiler label is stale. Raw metadata and samples remain unchanged. Both source compiler settings are Clang, not GCC; GNU runtime/startup objects account for the GCC comment in the executable.','msolve_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ms,text=True).strip(),'configure_options':subprocess.check_output(['./config.status','--config'],cwd=ms,text=True).strip(),'compiler':subprocess.check_output(['clang','--version'],text=True),'engine_library_sha256':sha(ms/'src/neogb/.libs/libneogb.so.4.0.0'),'engine_library_comment':subprocess.check_output(['readelf','-p','.comment','src/neogb/.libs/libneogb.so.4.0.0'],cwd=ms,text=True),'source_archive_sha256':sha(source)}
 (p/'protocol-correction.json').write_text(json.dumps(correction,indent=2)+'\n')
 for file in ['Makefile','src/neogb/Makefile']:
  text=(ms/file).read_text();(p/('msolve-'+file.replace('/','-')+'-flags.txt')).write_text('\n'.join(l for l in text.splitlines() if l.startswith(('CC =','CFLAGS =','CPPFLAGS =','LDFLAGS =','LIBS =')))+'\n')
 shutil.copy2(source,p/source.name);shutil.copy2(ms/'COPYING',p/'msolve-COPYING');shutil.copy2('/tmp/issue-10987-msolve-current-fetch.log',p/'upstream-fetch.log')
 for file in ['measure-msolve.py','verify-msolve.py','coverage-source-equivalence.json']:shutil.copy2(b/file,p/file)
 shutil.copy2(__file__,p/Path(__file__).name)
 for file in ['/tmp/hex-groebner-msolve-build.log','/tmp/issue-10987-mersenne-dispatch-msolve-analysis.log']:
  if Path(file).exists():shutil.copy2(file,p/Path(file).name)
 plan=json.loads(Path('/tmp/hex-groebner-compare/diagnostic-suite.json').read_text());shutil.copy2('/tmp/hex-groebner-compare/diagnostic-suite.json',p/'diagnostic-suite.json')
 for case in plan['cases']:
  for ext in ['.json','.ms']:shutil.copy2(Path('/tmp/hex-groebner-compare')/(case['name']+ext),p/(case['name']+ext))
 for line in (p/'source.manifest').read_text().splitlines():
  _,oid,rest=line.split(' ',2);_,name=rest.split('\t');f=p/'root-sources'/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd=root))
 out=raw/(p.name+'.tar.gz');assert not out.exists()
 with tarfile.open(out,'w:gz') as t:t.add(p,arcname=p.name)
 rows.append((out.name,sha(out)));print(*rows[-1],flush=True)
(b/'msolve-archive-hashes.json').write_text(json.dumps(rows,indent=2)+'\n')
