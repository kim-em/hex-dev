from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path.cwd();kind='products';s=Path('/home/kim/tmp/issue-10987');d=s/(kind+'-digest-checks');d.mkdir(exist_ok=False);(d/'.lake').mkdir();(d/'.lake/build').symlink_to('/dev/shm/issue-10987-product-digests-build');Path('/dev/shm/issue-10987-product-digests-build').mkdir()
m=json.loads((s/'projection-bench-checks/lake-manifest.json').read_text());m['name']='DigestChecks';m['packagesDir']=str(root/'.lake/packages')
for p in m['packages']:
 if p['name']=='Hex':p['dir']=str(root)
(d/'lake-manifest.json').write_text(json.dumps(m,indent=2)+'\n');(d/'lean-toolchain').write_bytes((root/'lean-toolchain').read_bytes())
(d/'lakefile.lean').write_text('import Lake\nopen Lake DSL\npackage DigestChecks\nrequire Hex from '+json.dumps(str(root))+'\nlean_exe check where\n  root := `Check\n')
sizes=[0,1,63,64,65,256,512,1024,2048,4096]
program='import HexGroebner.Bench.Products\nopen Hex.Groebner.Bench\n\ndef main : IO Unit := do\n'
for prep,function,reference in [('prepareProducts','monomialProducts','monomialProductsReference'),('prepareProducts22','productWide','productWideReference'),('prepareProductMisses','productMisses','productMissesReference')]:
 program+=f'  for n in {sizes} do\n    let input := {prep} n\n    let actual := {function} input\n    if !actual.1 || actual != {reference} input then\n      throw (IO.userError s!"invalid {function} at {{n}}")\n    IO.println s!"{function},{{n}},{{hash actual}}"\n'
(d/'Check.lean').write_text(program)
env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR='/dev/shm/issue-10987-build',PATH='/nix/store/2msw5nclhpsm80z65dqmjiv8kkras989-clang-wrapper-21.1.8/bin:'+os.environ['PATH'])
with(d/'build.log').open('w')as f:r=subprocess.run(['lake','build','check'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
exe=d/'.lake/build/bin/check'
with(d/'run.stdout').open('w')as out,(d/'run.stderr').open('w')as err:r=subprocess.run([str(exe)],cwd=d,env=env,stdout=out,stderr=err)
assert r.returncode==0
values={row.rsplit(',',1)[0]:int(row.rsplit(',',1)[1])for row in(d/'run.stdout').read_text().splitlines()};assert len(values)==30
(d/'status.json').write_text(json.dumps(dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binary_sha256=hashlib.file_digest(exe.open('rb'),'sha256').hexdigest(),exit_code=r.returncode,kind=kind,sizes=sizes,digests=values),indent=2)+'\n');print(kind,'all complete digests independently validated',flush=True)
