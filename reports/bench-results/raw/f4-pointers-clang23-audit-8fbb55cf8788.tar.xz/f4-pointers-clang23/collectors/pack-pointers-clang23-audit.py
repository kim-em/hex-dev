from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();assert identity['source_fingerprint']=='8fbb55cf8788'
native=json.loads((s/'product-pointers-verified-native-status.json').read_text());full=json.loads((s/'pointers-clang23-configured-full-status.json').read_text());native_id={k:native[0][k]for k in identity}
assert all(identity[k]==v for k,v in native_id.items()if k!='source_commit')
assert len(native)==2 and len(full)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in native_id.items())for r in native)and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in full)
payload={}
def add(n,p):
 assert n not in payload,n
 payload[n]=p.read_bytes()
def tree(label,base,shallow=False):
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if p.is_file()and not any(x in rel.parts for x in ['binaries','.lake'])and(not shallow or len(rel.parts)==1 or rel.parts[0]in ['root-sources','compiler-inputs']):add(label+'/'+str(rel),p)
tree('baseline',s/'product-pointers-production',True);tree('candidate',s/'pointers-clang23-production')
for cc in ['clang','gcc']:
 add('native-'+cc+'.log',s/('product-pointers-verified-'+cc+'.log'));tree('probes/'+cc,s/('product-pointers-verified-'+cc))
add('native-status.json',s/'product-pointers-verified-native-status.json');add('full-status.json',s/'pointers-clang23-configured-full-status.json');add('configuration.json',s/'pointers-clang23-configured-full-configuration.json')
for n in ['build','oracles','driver','bench','dag','phase4','manifest','headers','lines']:add('full/'+n+'.log',s/('pointers-clang23-configured-full-'+n+'.log'))
for prefix in ['pointers-clang23-full','pointers-clang23-configured-full']:
 for p in sorted(s.glob(prefix+'*.json')):add('diagnostics/'+p.name,p)
 for p in sorted(s.glob(prefix+'*.log')):
  if p.name not in ['pointers-clang23-configured-full-'+n+'.log'for n in ['build','oracles','driver','bench','dag','phase4','manifest','headers','lines']]:add('diagnostics/'+p.name,p)
for p in [s/'issue-10987-clang23-generic-cc',s/'issue-10987-lean-cc',s/'clang23-generic-lake/lake',s/'clang23-generic-default-cc/cc']:add('profile-inputs/'+p.parent.name+'/'+p.name,p)
for n in ['pointers-clang23-target.stderr','pointers-clang23-target.stdout','pointers-clang23-freeze.log']:add('diagnostics/'+n,s/n)
for pattern in ['measure-pointers-clang23-*.py','pointers-clang23*full-checks.py','pack-pointers-clang23-audit.py']:
 for p in sorted(s.glob(pattern)):add('collectors/'+p.name,p)
add('driver-identity.json',s/'pointers-clang23-driver-identity.json')
text=tree_listing(CHECKS,identity['source_commit']);payload['checks.manifest']=text.encode()
for line in text.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for name,value in [('identity',identity),('native-identity',native_id)]:payload[name+'.json']=(json.dumps(value,indent=2)+'\n').encode()
payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode();out=s/'f4-pointers-clang23-audit-8fbb55cf8788.tar.xz';assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-pointers-clang23/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
