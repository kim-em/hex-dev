from pathlib import Path
import hashlib,json,subprocess,sys
sys.path.insert(0,str(Path.cwd()));from scripts.bench.groebner_capsule import Capsule
from scripts.oracle.groebner_sympy import check
s=Path('/home/kim/tmp/issue-10987');out=s/'retirement-review-audit';out.mkdir(exist_ok=False);guards=Capsule(Path('reports/bench-results/raw/f4-active-list-checks-0a4bc08b663d.tar.xz'));inp=guards.json('mutations/always-check/minimal-f2-input.json');path=out/'input.json';path.write_text(json.dumps(inp,indent=2)+'\n');good_manifest=json.loads((s/'active-list-rebased-production/manifest.json').read_text());bad=guards.json('mutations/always-check/status.json');records=[];outputs=[]
for label,binary,expected in [('good',s/'active-list-rebased-production/binaries/compute',good_manifest['binary_sha256']['compute']),('bad',Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-retirement-mutant/.lake/build/bin/hexgroebner_compute'),bad['binary_sha256'])]:
 before=hashlib.sha256(binary.read_bytes()).hexdigest();assert before==expected
 command=[str(binary),'--work','1000000000',str(path)];r=subprocess.run(command,capture_output=True);assert r.returncode==0;after=hashlib.sha256(binary.read_bytes()).hexdigest();assert before==after;(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);outputs.append(json.loads(r.stdout));records.append(dict(label=label,command=command,exit_code=r.returncode,binary_sha256_before=before,binary_sha256_after=after,input_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
expected=check({**inp,'basis':outputs[0]['basis']});assert outputs[1]['basis']!=expected
try:check({**inp,'basis':outputs[1]['basis']})
except ValueError as e:(out/'independent-rejection.txt').write_text(str(e)+'\n')
else:raise AssertionError('invalid candidate accepted')
(out/'metadata.json').write_text(json.dumps(dict(records=records,good_manifest=good_manifest,bad_identity=bad),indent=2)+'\n');print('PASS: minimized F2 counterexample bound to both executables; independently rejected bad basis',flush=True)
