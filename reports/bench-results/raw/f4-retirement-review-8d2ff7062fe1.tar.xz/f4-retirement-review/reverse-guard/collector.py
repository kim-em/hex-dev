import hashlib,json,os,subprocess,time
from pathlib import Path
s=Path('/home/kim/tmp/issue-10987');r=Path.cwd();out=s/'retirement-reverse-final-audit';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
guard=r/'conformance/HexGroebner/F4Conformance.lean';pair=r/'HexGroebner/Pairs.lean'
guard.write_bytes(Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-active-list/conformance/HexGroebner/F4Conformance.lean').read_bytes())
expected=s/'retirement-reverse-production/root-sources/HexGroebner/Pairs.lean'
# The archived reverse source and this checkout must be identical before compilation.
if not expected.exists():
 import tarfile
 with tarfile.open('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-active-list/reports/bench-results/raw/f4-active-list-checks-0a4bc08b663d.tar.xz')as tar:
  archived=tar.extractfile('f4-active-list-checks/mutations/reverse/root-sources/HexGroebner/Pairs.lean').read()
else:archived=expected.read_bytes()
assert pair.read_bytes()==archived
record=dict(command=['lake','build','HexGroebner.F4Conformance'],pair_sha256_before=sha(pair),guard_sha256_before=sha(guard),head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
import sys
sys.path.insert(0,str(r))
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import index_listing
from scripts.bench.groebner_checks import CHECKS
def snapshot(family):
 lines=[]
 for line in index_listing(family).splitlines():
  mode,oid,rest=line.split(' ',2);_,path=rest.split('\t');data=(r/path).read_bytes()
  actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  if family==FAMILY:assert actual==oid,path
  lines.append(f'{mode} {actual} 0\t{path}\n')
 return ''.join(lines)
runtime=snapshot(FAMILY);checks=snapshot(CHECKS)
(out/'runtime.manifest').write_text(runtime);(out/'checks.manifest').write_text(checks)
record['runtime_manifest_sha256_before']=hashlib.sha256(runtime.encode()).hexdigest()
record['checks_manifest_sha256_before']=hashlib.sha256(checks.encode()).hexdigest()
started=time.monotonic()
with(out/'build.log').open('w')as log:run=subprocess.run(record['command'],env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR=str(s)),stdout=log,stderr=subprocess.STDOUT)
record.update(exit_code=run.returncode,seconds=time.monotonic()-started,pair_sha256_after=sha(pair),guard_sha256_after=sha(guard))
record['runtime_manifest_sha256_after']=hashlib.sha256(snapshot(FAMILY).encode()).hexdigest()
record['checks_manifest_sha256_after']=hashlib.sha256(snapshot(CHECKS).encode()).hexdigest()
assert index_listing(FAMILY)==runtime
(out/'Pairs.lean').write_bytes(pair.read_bytes());(out/'F4Conformance.lean').write_bytes(guard.read_bytes());(out/'metadata.json').write_text(json.dumps(record,indent=2)+'\n')
assert run.returncode!=0 and all(name+'\ndid not evaluate' in(out/'build.log').read_text()for name in ['retirementPairs','retirementChain'])
assert record['pair_sha256_before']==record['pair_sha256_after']and record['guard_sha256_before']==record['guard_sha256_after']
print('reversed source guard rejected',flush=True)
