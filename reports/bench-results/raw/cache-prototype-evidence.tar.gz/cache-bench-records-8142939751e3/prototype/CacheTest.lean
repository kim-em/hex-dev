import CacheF4
import HexGroebner.F4Fixtures
open Hex.Groebner

def checks : Bool := Id.run do
  for field in Fixtures.fields do
    for order in [TermOrder.lex,.grlex,.grevlex] do
      for c in F4Fixtures.cases field do
        let context : Context := ⟨field,c.variables,order⟩
        let .candidate expected stats := computeWith context {} c.generators | return false
        let .candidate actual usage := Cached.computeWith context {} c.generators | return false
        if actual.polynomials != expected.polynomials then return false
        if {usage with work:=stats.work,allocatedBytes:=stats.allocatedBytes} != stats then return false
  return true
#guard checks

def main : IO Unit := do
  if checks then IO.println "cached reducers: all 567 canonical bases and non-resource counters match"
  else throw (IO.userError "cached reducer mismatch")
