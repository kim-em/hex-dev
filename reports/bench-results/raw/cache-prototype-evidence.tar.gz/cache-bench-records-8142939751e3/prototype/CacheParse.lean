import HexGroebner
import CacheF4
import Lean.Data.Json

open Hex.Groebner Lean
namespace Hex.Groebner.CacheBench

def parseTerm (j : Json) : Except String RawTerm := do
  let values ← j.getArr?
  if values.size != 2 then throw "term needs [exponents,coefficient]"
  let powers ← values[0]!.getArr? >>= fun a => a.mapM Json.getNat?
  let c ← values[1]!.getNat?
  if c ≥ 2^64 then throw "coefficient exceeds UInt64"
  return ⟨powers, c.toUInt64⟩

def parseInput (j : Json) : Except String (Context × Array RawPolynomial) := do
  let modulus ← j.getObjValAs? Nat "p"
  if h : Hex.Nat.isPrimeTrial modulus = true then
    if bound : modulus < 2^31 then
      let field : PrimeField := ⟨modulus.toUInt64, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using Hex.Nat.isPrimeTrial_isPrime h, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using bound⟩
      let variables ← j.getObjValAs? Nat "variables"
      let order ← j.getObjValAs? String "order"
      let order ← match order with
        | "grevlex" => pure TermOrder.grevlex
        | "grlex" => pure TermOrder.grlex
        | "lex" => pure TermOrder.lex
        | _ => throw "unknown order"
      let generators ← j.getObjVal? "generators" >>= Json.getArr? >>= fun a =>
        a.mapM fun p => p.getArr? >>= fun a => a.mapM parseTerm
      return (⟨field, variables, order⟩, generators)
    else throw "modulus out of bounds"
  else throw "not prime"


end Hex.Groebner.CacheBench
