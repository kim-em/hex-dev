import Lake
open Lake DSL
package GroebnerReducerCache
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
lean_lib CacheDev where
  roots := #[`CacheSymbolic,`CacheF4,`CacheParse,`CacheBench]
lean_exe cache_compare where
  root := `Main
lean_exe cache_checks where
  root := `CacheTest
lean_exe cache_boundaries where
  root := `CacheBoundary

lean_exe cache_bench where
  root := `CacheBenchMain
