import CacheParse
import LeanBench
namespace Hex.Groebner.CacheBench
private instance : Nonempty Context := ⟨⟨⟨7,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩,0,.grevlex⟩⟩
private def load (name : String) : IO (Context × Array RawPolynomial) := do
  let json ← IO.ofExcept (Lean.Json.parse (← IO.FS.readFile ("/tmp/hex-groebner-compare/"++name++".json")))
  IO.ofExcept (parseInput json)
private def run (cached : Bool) (input : Context × Array RawPolynomial) : IO (Array RawPolynomial) := do
  let (context,generators) := input
  let limits : Limits := {work:=100000000000,packedBytes:=16*1024*1024*1024,matrixEntries:=1000000000,pairs:=100000000,monomials:=10000000}
  if cached then
    match Cached.computeWith context limits generators with
    | .candidate c _ => return c.polynomials
    | _ => throw (IO.userError "cached computation incomplete")
  else
    match computeWith context limits generators with
    | .candidate c _ => return c.polynomials
    | _ => throw (IO.userError "reference computation incomplete")

initialize cyclic6p15Input : IO.Ref (Context × Array RawPolynomial) ← IO.mkRef (← load "cyclic6-15")
def referencecyclic6p15 (_ : Unit) : IO (Array RawPolynomial) := do run false (← cyclic6p15Input.get)
setup_fixed_benchmark referencecyclic6p15 where {repeats:=5}
def cachedcyclic6p15 (_ : Unit) : IO (Array RawPolynomial) := do run true (← cyclic6p15Input.get)
setup_fixed_benchmark cachedcyclic6p15 where {repeats:=5}

initialize cyclic6p31Input : IO.Ref (Context × Array RawPolynomial) ← IO.mkRef (← load "cyclic6-31")
def referencecyclic6p31 (_ : Unit) : IO (Array RawPolynomial) := do run false (← cyclic6p31Input.get)
setup_fixed_benchmark referencecyclic6p31 where {repeats:=5}
def cachedcyclic6p31 (_ : Unit) : IO (Array RawPolynomial) := do run true (← cyclic6p31Input.get)
setup_fixed_benchmark cachedcyclic6p31 where {repeats:=5}

initialize kat6p15Input : IO.Ref (Context × Array RawPolynomial) ← IO.mkRef (← load "kat6-15")
def referencekat6p15 (_ : Unit) : IO (Array RawPolynomial) := do run false (← kat6p15Input.get)
setup_fixed_benchmark referencekat6p15 where {repeats:=5}
def cachedkat6p15 (_ : Unit) : IO (Array RawPolynomial) := do run true (← kat6p15Input.get)
setup_fixed_benchmark cachedkat6p15 where {repeats:=5}

initialize kat6p31Input : IO.Ref (Context × Array RawPolynomial) ← IO.mkRef (← load "kat6-31")
def referencekat6p31 (_ : Unit) : IO (Array RawPolynomial) := do run false (← kat6p31Input.get)
setup_fixed_benchmark referencekat6p31 where {repeats:=5}
def cachedkat6p31 (_ : Unit) : IO (Array RawPolynomial) := do run true (← kat6p31Input.get)
setup_fixed_benchmark cachedkat6p31 where {repeats:=5}

initialize eco10p15Input : IO.Ref (Context × Array RawPolynomial) ← IO.mkRef (← load "eco10-15")
def referenceeco10p15 (_ : Unit) : IO (Array RawPolynomial) := do run false (← eco10p15Input.get)
setup_fixed_benchmark referenceeco10p15 where {repeats:=5}
def cachedeco10p15 (_ : Unit) : IO (Array RawPolynomial) := do run true (← eco10p15Input.get)
setup_fixed_benchmark cachedeco10p15 where {repeats:=5}

initialize eco10p31Input : IO.Ref (Context × Array RawPolynomial) ← IO.mkRef (← load "eco10-31")
def referenceeco10p31 (_ : Unit) : IO (Array RawPolynomial) := do run false (← eco10p31Input.get)
setup_fixed_benchmark referenceeco10p31 where {repeats:=5}
def cachedeco10p31 (_ : Unit) : IO (Array RawPolynomial) := do run true (← eco10p31Input.get)
setup_fixed_benchmark cachedeco10p31 where {repeats:=5}

initialize reimer5p15Input : IO.Ref (Context × Array RawPolynomial) ← IO.mkRef (← load "reimer5-15")
def referencereimer5p15 (_ : Unit) : IO (Array RawPolynomial) := do run false (← reimer5p15Input.get)
setup_fixed_benchmark referencereimer5p15 where {repeats:=5}
def cachedreimer5p15 (_ : Unit) : IO (Array RawPolynomial) := do run true (← reimer5p15Input.get)
setup_fixed_benchmark cachedreimer5p15 where {repeats:=5}

initialize reimer5p31Input : IO.Ref (Context × Array RawPolynomial) ← IO.mkRef (← load "reimer5-31")
def referencereimer5p31 (_ : Unit) : IO (Array RawPolynomial) := do run false (← reimer5p31Input.get)
setup_fixed_benchmark referencereimer5p31 where {repeats:=5}
def cachedreimer5p31 (_ : Unit) : IO (Array RawPolynomial) := do run true (← reimer5p31Input.get)
setup_fixed_benchmark cachedreimer5p31 where {repeats:=5}

end Hex.Groebner.CacheBench
