from pathlib import Path
import json,math,statistics
p=next(Path('/tmp/hex-groebner-reducer-cache').glob('cache-bench-records-*'));m=json.loads((p/'metadata.json').read_text());g=lambda v:math.exp(sum(map(math.log,v))/len(v));r={};count=0
for case in [family+'p'+str(width) for family in ['cyclic6','kat6','eco10','reimer5'] for width in [15,31]]:
 ratios=[]
 for block in (0,1):
  a,b=[json.loads((p/f'{case}-b{block}-{arm}.json').read_text())['results'][0] for arm in ('A','B')]
  assert a['hashes_agree'] and b['hashes_agree'] and a['observed_hash']==b['observed_hash']
  assert len(a['points'])==len(b['points'])==5
  for x,y in zip(a['points'],b['points']):
   assert x['status']==y['status']=='ok' and x['result_hash']==y['result_hash'];count+=2;ratios.append((y['total_nanos']/y['inner_repeats'])/(x['total_nanos']/x['inner_repeats']))
 r[case]=dict(geomean=g(ratios),median=statistics.median(ratios),minimum=min(ratios),maximum=max(ratios),ratios=ratios)
o=dict(cpu=m['cpu'],points=count,all_hashes_match=True,per_case=r);(p/'analysis.json').write_text(json.dumps(o,indent=2)+'\n');print('CPU',m['cpu'],'points',count)
for c,v in r.items():print(c,{k:round(v[k],4) for k in ('geomean','median','minimum','maximum')})
