import hashlib,json,os,pathlib,resource,shutil,subprocess,sys,time
sys.path.insert(0,'/home/kim/worktrees/hex-dev/hex-dev-issue-10987')
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import fingerprint,index_listing
root=pathlib.Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987');dev=pathlib.Path('/tmp/hex-groebner-reducer-cache');listing=index_listing(FAMILY);fp=fingerprint(listing)
binary=dev/'binaries/cache-bench';shutil.copy2(dev/'.lake/build/bin/cache_bench',binary)
out=dev/('cache-bench-records-'+fp);out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
meta=dict(source_fingerprint=fp,source_manifest=listing,cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),binary_sha256=sha(binary),schedule='per case, adjacent AB then BA, declared five fixed repetitions',contract='same frozen binary; A production narrow SIMD engine, B explicit checkpoint multiplied-reducer cache; cyclic6,kat6,eco10,reimer5 grevlex at32003/2147483647; input IO-backed parse/prepare excluded; canonicalization, candidate through final interreduction and complete structural basis hashing included; certification/kernel checking excluded',script=pathlib.Path(__file__).read_text(),toolchain=(root/'lean-toolchain').read_text().strip(),compiler=subprocess.check_output(['cc','--version'],text=True),runs=[])
proto=out/'prototype';proto.mkdir()
for f in dev.iterdir():
 if f.suffix in ('.lean','.json') or f.name=='lean-toolchain':shutil.copy2(f,proto/f.name)
for name in ['cyclic6','kat6','eco10','reimer5']:
 for width in [15,31]:shutil.copy2('/tmp/hex-groebner-compare/'+name+'-'+str(width)+'.json',out/(name+'-'+str(width)+'.json'))
def limits():resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2)
try:
 for block,order in enumerate(('AB','BA')):
  for case in [family+'p'+str(width) for family in ['cyclic6','kat6','eco10','reimer5'] for width in [15,31]]:
   for arm in order:
    name=('reference' if arm=='A' else 'cached')+case;prefix=f'{case}-b{block}-{arm}';command=[str(binary),'run','Hex.Groebner.CacheBench.'+name,'--export-file',str(out/(prefix+'.json'))]
    print(prefix,flush=True);start=time.monotonic_ns()
    with (out/(prefix+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
    meta['runs'].append(dict(case=case,arm=arm,block=block,command=command,returncode=r.returncode,wall_nanos=time.monotonic_ns()-start))
finally:
 meta['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
