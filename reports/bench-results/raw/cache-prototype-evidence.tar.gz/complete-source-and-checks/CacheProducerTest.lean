import CachedProducerPipeline
import HexGroebner.F4Fixtures
open Hex.Groebner

def checks : Except String Unit := do
  for field in Fixtures.fields do
    for order in [TermOrder.lex,.grlex,.grevlex] do
      for c in F4Fixtures.cases field do
        let context : Context := ⟨field,c.variables,order⟩
        let .candidate expected _ := computeWith context {} c.generators | throw "candidate computation incomplete"
        let outcome := CachedProducer.basisWith context {} c.generators
        let actual ← match outcome with
          | .success value _ _ => pure value
          | .rejected _ => throw s!"certificate rejected, p={field.modulus.toNat}, order={reprStr order}, input={reprStr c.generators}"
          | .computeExhausted r _ => throw s!"compute exhausted {reprStr r}, p={field.modulus.toNat}, input={reprStr c.generators}"
          | .certificateExhausted r _ => throw s!"certificate exhausted {reprStr r}, p={field.modulus.toNat}, input={reprStr c.generators}"
          | .representation r _ => throw s!"representation {reprStr r}"
          | .invalid _ _ => throw "invalid"
          | .internal _ => throw "internal"
          | .address _ => throw "address"
        let canonical := expected.polynomials.map fun p =>
          p.foldl (fun f t => Hex.MvPoly.Kernel.addMod field.modulus.toNat f
            [(t.exponents.toList,t.coefficient.toNat)]) []
        if actual.polynomials != canonical then throw s!"basis mismatch p={field.modulus.toNat}, order={reprStr order}, actual={reprStr actual.polynomials}, expected={reprStr canonical}"
        if !checkBasis context actual.generators actual.polynomials actual.certificate then throw "independent certificate rejected"
  return ()
#guard checks.isOk

def main : IO Unit := do
  IO.ofExcept checks
  IO.println "cached certificate producer: all 567 bases match and complete certificates independently check"
