#include <stdlib.h>
#include <stdio.h>
#define lean_hex_groebner_subtract_row unused_subtract
#define lean_hex_groebner_prepare_monomial probe_prepare
#define lean_hex_groebner_equal_monomial unused_equal
#define lean_hex_groebner_equal_bytes unused_bytes
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987/HexGroebner/ffi/row_update.c"
#undef lean_hex_groebner_subtract_row
#undef lean_hex_groebner_prepare_monomial
#undef lean_hex_groebner_equal_monomial
#undef lean_hex_groebner_equal_bytes
struct entry {uint64_t key;unsigned operation,occupied;};
static struct entry *entries;
static size_t capacity,used;
static uint64_t calls[3],unique[3],coordinates[3],invalid;
static uint64_t mix(uint64_t x) {
 x^=x>>30;x*=UINT64_C(0xbf58476d1ce4e5b9);x^=x>>27;
 x*=UINT64_C(0x94d049bb133111eb);return x^(x>>31);
}
static size_t slot(uint64_t key,unsigned operation) {
 size_t at=(size_t)mix(key^mix(operation))&(capacity-1);
 while(entries[at].occupied && (entries[at].key!=key || entries[at].operation!=operation)) at=(at+1)&(capacity-1);
 return at;
}
static void grow(void) {
 struct entry *old=entries;size_t previous=capacity;
 capacity=capacity?capacity*2:65536;entries=calloc(capacity,sizeof(*entries));
 if(!entries) {fputs("probe allocation failed\n",stderr);exit(99);}
 for(size_t i=0;i<previous;++i) if(old[i].occupied) entries[slot(old[i].key,old[i].operation)]=old[i];
 free(old);
}
static void dump(void) {
 fprintf(stderr,"untimed monomial preparation reuse: invalid=%llu\n",(unsigned long long)invalid);
 for(unsigned op=0;op<3;++op) fprintf(stderr,"op=%u calls=%llu unique=%llu repeated=%llu coordinate_visits=%llu\n",op,(unsigned long long)calls[op],(unsigned long long)unique[op],(unsigned long long)(calls[op]-unique[op]),(unsigned long long)coordinates[op]);
}
__typeof__(probe_prepare) __wrap_lean_hex_groebner_prepare_monomial;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_prepare_monomial(uint8_t operation,uint8_t width,
 uint64_t arity,uint64_t count,uint64_t left,uint64_t right,b_lean_obj_arg source,lean_obj_arg workspace) {
 if(!capacity) {grow();atexit(dump);}
 if(operation>2 || left>UINT32_MAX || right>UINT32_MAX) ++invalid;
 else {
  ++calls[operation];coordinates[operation]+=arity;
  uint64_t a=left,b=right;
  if(operation<2 && a>b) {uint64_t temp=a;a=b;b=temp;}
  uint64_t key=a<<32|b;
  if(used*10>=capacity*7) grow();
  size_t at=slot(key,operation);
  if(!entries[at].occupied) {entries[at]=(struct entry){key,operation,1};++used;++unique[operation];}
 }
 return probe_prepare(operation,width,arity,count,left,right,source,workspace);
}
