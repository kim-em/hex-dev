import Lake
open Lake DSL System
package GroebnerMonomialProbe
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
lean_lib Reference where
  roots := #[`ReferenceElimination, `ReferenceSymbolic, `ReferenceF4]
target probeO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "probe.c")
  let body ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987/HexGroebner/ffi/row_update.c")
  buildO (pkg.dir / defaultBuildDir / "probe.o") (source.zipWith (fun s _ => s) body)
    #["-isystem", (← getLeanIncludeDir).toString]
    #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING"]
lean_exe monomial_probe where
  root := `Main
  moreLinkObjs := #[probeO]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_groebner_prepare_monomial"]
