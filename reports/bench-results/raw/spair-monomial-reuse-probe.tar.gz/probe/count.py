from pathlib import Path
import json,os,sys,resource,subprocess,hashlib,re
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987');sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
base=Path('/tmp/hex-groebner-compare');dev=Path(__file__).resolve().parent;out=dev/'counts';out.mkdir(exist_ok=False);cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});binary=dev/'.lake/build/bin/monomial_probe';plan=json.loads((base/'diagnostic-suite.json').read_text());rows=[]
def limits():resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2)
try:
 for case in plan['cases']:
  name=case['name'];command=[str(binary),str(base/(name+'.json'))]
  with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=30,preexec_fn=limits)
  assert r.returncode==0
  a=json.loads((out/(name+'.stdout')).read_text());b=json.loads((Path('/tmp/hex-groebner-reducer-find-production/reducer-find-production-records-cfb2c79989e2')/(name+'-b0-B.stdout')).read_text());a.pop('candidate_nanos');b.pop('candidate_nanos');assert a==b
  text=(out/(name+'.stderr')).read_text();assert 'invalid=0' in text
  operations=[]
  for op,calls,unique,repeated,coordinates in re.findall(r'op=(\d+) calls=(\d+) unique=(\d+) repeated=(\d+) coordinate_visits=(\d+)',text):operations.append(dict(operation=int(op),calls=int(calls),unique=int(unique),repeated=int(repeated),coordinate_visits=int(coordinates),repeated_fraction=int(repeated)/int(calls) if int(calls) else 0))
  rows.append(dict(case=name,command=command,all_basis_and_non_time_counters_equal=True,operations=operations));print(name,[(x['operation'],x['calls'],round(x['repeated_fraction'],3)) for x in operations],flush=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),scope='Untimed instrumentation, one process/monomial arena per input, stable IDs; commutative LCM/product pairs normalized, quotient ordered; no timing or memory-performance claim. Exact preparation implementation unchanged.',rows=rows,script=Path(__file__).read_text()),indent=2)+'\n');lease.close()
