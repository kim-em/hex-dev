from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');name='f4-performance-review-8f56f7677ce6';payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
full=json.loads((state/'performance-reviewed-full-status.json').read_text());native=json.loads((state/'performance-reviewed-native-status.json').read_text())
assert len(full)==9 and len(native)==2 and all(x['exit_code']==0 for x in full+native)
assert all(x['source_fingerprint']=='8f56f7677ce6' for x in full+native)
for directory in ['performance-final-production','performance-reviewed-clang','performance-reviewed-gcc']:
 for p in sorted((state/directory).rglob('*')):
  rel=p.relative_to(state/directory)
  if p.is_file() and '.lake' not in rel.parts and 'binaries' not in rel.parts:add(directory+'/'+str(rel),p.read_bytes())
for p in sorted(state.glob('performance-reviewed-*')):
 if p.is_file():add('reproduction/'+p.name,p.read_bytes())
measured=json.loads((state/'combined-performance-production/manifest.json').read_text());final=json.loads((state/'performance-final-production/manifest.json').read_text());assert measured['binary_sha256']==final['binary_sha256']
add('post-measurement.patch',subprocess.check_output(['git','diff','--binary',measured['source_snapshot'],'HEAD','--','.',':!reports'],cwd=root));add('source-base.json',(json.dumps(dict(measured_source_snapshot=measured['source_snapshot'],final_source_commit=final['commit'],scope='Comment, test and documentation changes since the measurement snapshot; fresh final binaries are byte-identical to both measured executables.'),indent=2)+'\n').encode());add('archive.py',Path(__file__).read_bytes());add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest() for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out) as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/'performance-review-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
