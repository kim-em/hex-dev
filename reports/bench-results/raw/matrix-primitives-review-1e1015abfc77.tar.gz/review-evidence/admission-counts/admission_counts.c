#include <lean/lean.h>
#include <stdio.h>
#include <stdint.h>
static uint64_t va,vd,za,zd,ma,md;
extern lean_obj_res __real_lean_hex_matrix_validate(uint64_t,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_validate(uint64_t p,b_lean_obj_arg limits,b_lean_obj_arg cols,b_lean_obj_arg index,b_lean_obj_arg row,b_lean_obj_arg stats) {
 lean_object *r=__real_lean_hex_matrix_validate(p,limits,cols,index,row,stats);
 if(lean_is_scalar(r))++vd;else ++va;return r;
}
extern lean_obj_res __real_lean_hex_matrix_zeros(b_lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_zeros(b_lean_obj_arg n) {
 lean_object *r=__real_lean_hex_matrix_zeros(n);if(lean_is_scalar(r))++zd;else ++za;return r;
}
extern lean_obj_res __real_lean_hex_groebner_eliminate_matrix(uint64_t,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,uint8_t);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_eliminate_matrix(uint64_t p,b_lean_obj_arg limits,b_lean_obj_arg cols,b_lean_obj_arg rs,b_lean_obj_arg ts,b_lean_obj_arg sugars,uint8_t independent) {
 lean_object *r=__real_lean_hex_groebner_eliminate_matrix(p,limits,cols,rs,ts,sugars,independent);
 if(lean_is_scalar(r))++md;else ++ma;return r;
}
__attribute__((destructor)) static void counts(void) {
 fprintf(stderr,"HEX_MATRIX_ADMISSION {\"validation_admitted\":%llu,\"validation_declined\":%llu,\"zero_admitted\":%llu,\"zero_declined\":%llu,\"bulk_admitted\":%llu,\"bulk_declined\":%llu}\n",(unsigned long long)va,(unsigned long long)vd,(unsigned long long)za,(unsigned long long)zd,(unsigned long long)ma,(unsigned long long)md);
}
