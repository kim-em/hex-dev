from pathlib import Path
import json,subprocess,shutil,os,sys,hashlib
root=Path('/tmp/hex-groebner-column-index-dev');source=Path('/tmp/hex-groebner-column-index-kernel-sweep');out=Path('/tmp/hex-groebner-column-index-kernel-five');out.mkdir(exist_ok=False);binary=source/'benchmark';build=json.loads((source/'build.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256'];shutil.copy2(source/'build.json',out/'build.json');shutil.copy2(source/'source-manifest.json',out/'source-manifest.json')
sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});records=[]
try:
 for kernel in ['columnDirect','columnIndex']:
  command=[str(binary),'run','Hex.Groebner.Bench.'+kernel,'--outer-trials','5','--export-file',str(out/(kernel+'.json'))]
  with (out/(kernel+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  records.append(dict(kernel=kernel,command=command,returncode=r.returncode));assert r.returncode==0
  points=json.loads((out/(kernel+'.json')).read_text())['results'][0]['points'];assert len(points)==25 and all(v['status']=='ok' for v in points)
  print(kernel,'25points passed',flush=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,source_fingerprint=build['source_fingerprint'],binary_sha256=build['binary_sha256'],scope='Fixed five-size/five-trial lean-bench complexity sweep with explicit --outer-trials5,shared host,one leasedCPU,one requestedalgorithmthread,allcompletedpoints retained,noactivityfilter,no unchangedrerun. Same freshly detached benchmark binary as preceding setup attempt. Inputpreparationexcluded;allocation,initialization,construction,translation,independentvalidation andfullstructuralhashingincluded. The initial setup assumed a five-trial default, but lean-bench defaults to one; its five completed columnDirect points and assertionfailure remain separate in hex-groebner-column-index-kernel-sweep. These points are not pooled with this explicit five-trial observation.',runs=records),indent=2)+'\n');lease.close()
shutil.copy2(__file__,out/'measure.py')
