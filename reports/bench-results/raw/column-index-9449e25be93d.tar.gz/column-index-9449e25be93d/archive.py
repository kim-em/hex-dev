from pathlib import Path
import json,subprocess,hashlib,tarfile,shutil,time
repo=Path('/tmp/hex-groebner-evidence-review');base=Path('/tmp/hex-groebner-column-index-production');final=Path('/tmp/hex-groebner-column-index-integrated-production');status=Path('/tmp/issue-10987-pr11012-integrated-full-status.json')
while True:
 if status.exists():
  checks=json.loads(status.read_text())
  if any(v['exit_code']!=0 for v in checks):raise SystemExit('Integrated checks failed')
  if len(checks)==9:break
 time.sleep(2)
m=json.loads((base/'manifest.json').read_text());fm=json.loads((final/'manifest.json').read_text());assert fm['binary_sha256']==m['binary_sha256'];name='column-index-'+m['source_fingerprint'];stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
for p in base.iterdir():
 if p.name=='binaries':continue
 if p.name=='bench-binaries':
  d=stage/p.name;d.mkdir()
  for q in p.iterdir():
   if q.is_file() and q.name not in ['A','B']:shutil.copy2(q,d/q.name)
 elif p.is_dir():shutil.copytree(p,stage/p.name)
 else:shutil.copy2(p,stage/p.name)
identities={'measured':m,'baseline':json.loads(Path('/tmp/hex-groebner-whole-matrix-reviewed-production/manifest.json').read_text()),'final':fm,'kernels':json.loads(Path('/tmp/hex-groebner-column-index-bench-production/manifest.json').read_text())};counts={}
for label,manifest in identities.items():
 (stage/(label+'-manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n');counts[label]=0
 for line in manifest['source_manifest'].splitlines():
  mode,n=line.split('\t',1);oid=mode.split()[1];b=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;p=stage/(label+'-sources')/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);counts[label]+=1
for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(repo/folder,stage/'validation-sources'/folder)
for n in ['scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh','scripts/ci/check_groebner_driver.py','scripts/ci/run_oracles.sh']:
 p=stage/'validation-sources'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,p)
for pattern in ['issue-10987-column-index-*.log','issue-10987-column-index-*.json','issue-10987-pr11012-integrated-*']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file():shutil.copy2(p,stage/p.name)
for n in ['measure-groebner-column-index.py','measure-groebner-column-index-msolve.py','build-groebner-column-index-benches.py','measure-groebner-column-kernels.py','measure-groebner-column-kernels-five.py','measure-groebner-column-kernels-long.py','profile-groebner-column-index-routes.py','profile-groebner-column-small-initial.py','profile-groebner-column-small-second.py','profile-groebner-column-small.py','run-issue-10987-full-checks.py']:
 shutil.copy2(Path('/tmp')/n,stage/n)
for label,path in [('route-profile','/tmp/hex-groebner-column-index-route-profile'),('kernel-first','/tmp/hex-groebner-column-index-kernel-sweep'),('kernel-five','/tmp/hex-groebner-column-index-kernel-five'),('kernel-long','/tmp/hex-groebner-column-index-kernel-long')]:
 d=stage/label;d.mkdir()
 for p in Path(path).iterdir():
  if p.is_file() and p.name!='benchmark':shutil.copy2(p,d/p.name)
for suffix in ['', '-initial','-second']:
 shutil.copytree(Path('/tmp/hex-groebner-column-index-small-profile'+suffix),stage/('small-profile'+suffix))
for compiler in ['clang','gcc']:
 native=Path('/tmp/hex-groebner-column-index-complete-'+compiler+'-sanitizers');d=stage/('native-'+compiler);d.mkdir()
 for p in native.iterdir():
  if p.is_file():shutil.copy2(p,d/p.name)
 for p in (native/'.lake').rglob('*.rsp'):
  q=d/'response-files'/p.relative_to(native/'.lake');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
shutil.copytree('/tmp/issue-10987-relocatable-wrapper',stage/'compiler-wrapper')
# Retain the public structured input license already distributed with the sources.
license_archive=repo/'reports/bench-results/raw/target-columns-input-provenance-licensed.tar.gz'
if license_archive.exists():
 with tarfile.open(license_archive) as t:
  for v in t.getmembers():
   if v.isfile() and Path(v.name).name=='LICENSE.md':(stage/'public-input-LICENSE.md').write_bytes(t.extractfile(v).read());break
scope='Packed direct and exact open-addressed u32 column lookup for candidate and certificate row construction. Geometry alone selects layouts. Collision chains beyond 64 retain charged attempts and use the lawful hash map. Native direct/index remaps consume at most 4096 IDs, reserve once and commit logical size on success; zero appends consume at most 4096 bytes. Full-key equality, borrowed/output aliases, marked-linear growth and malformed slices agree with portable models. Conservative probe bounds, initialization, attempted insertions and packed payload are charged before work; limits can exhaust sooner than the original unit-cost hash route. All 240 CLI processes and 120 complete basis pairs agree; work/allocation counters differ and remain. Fixed sweeps retain 240 complete structural output hashes. Each small, medium and fixed observation retains its first campaign and sole unchanged repeat, every outlier and failure; no further unchanged rerun. Small aggregate regressions and extreme MinRank ratios remain, while medium and fixed Reimer improve. No uniform gain or leadership claim. Separate msolve modes 2 and 42 each retain 56 processes/28 equal full bases, with zero failures/timeouts and exact build/ISA identities; observed Hex/msolve means 2.2242/2.3915. Four-input route profile has exact uninstrumented basis/counter agreement and counts all layouts. MinRank explanatory profile retains two baseline processes that completed before reporting-key errors and a corrected four-process AB/BA; no durations are pooled into timing estimates and the prior wall spikes remain unexplained. Two registered linear kernels retain all 50 points in an explicit five-trial/five-size four-second-batch sweep, plus the initial five-point default-trial setup and 25-point below-floor five-trial setup; configurations remain separate and all signal/warmup flags remain. Final integrated build, independent matrix/basis/division oracles, both 1134-output CLI corpora,34 benchmark smoke checks and all project audits pass. Eight complete Clang/GCC ASan/UBSan variants include exact 64/65 collision fallback counters, independent hash-map comparisons, shared/exclusive/marked aliases and new-kernel call counters. A failed expanded harness marked a buffer after sharing it; corrected marking order passes, implementation unchanged. Final and benchmark compute binaries are byte-identical to measured drivers. Raw benchmark binaries and regenerable sanitizer build output are omitted; exact SHA256s, source blobs, response files, logs and compiler helper remain. Manual shared-host EPYC 9455, one requested algorithm thread and leased CPUs; no activity filters. All observations are development evidence, not held-out SPEC acceptance. Candidate production excludes certificate generation, independent final certification and kernel checking; no language/runtime impossibility is established.'
(stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=m['source_fingerprint'],final_source_fingerprint=fm['source_fingerprint'],physical_source_files=counts,byte_identical_compute_drivers=True,scope=scope),indent=2)+'\n');shutil.copy2(__file__,stage/'archive.py');target=repo/'reports/bench-results/raw'/(name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
c=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source_fingerprint=m['source_fingerprint'],final_source_fingerprint=fm['source_fingerprint'],physical_source_files=counts,size=target.stat().st_size);Path('/tmp/issue-10987-column-index-catalog.json').write_text(json.dumps(c,indent=2)+'\n');print(c)
