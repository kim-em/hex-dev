from pathlib import Path
import json,subprocess,shutil,tempfile,os,sys,hashlib,time
root=Path('/tmp/hex-groebner-column-index-dev');base=Path('/tmp/hex-groebner-column-index-bench-production');out=Path('/tmp/hex-groebner-column-index-kernel-sweep');out.mkdir(exist_ok=False)
while not (base/'manifest.json').exists():time.sleep(1)
m=json.loads((base/'manifest.json').read_text());build=dict(source_fingerprint=m['source_fingerprint'],source_snapshot=m['source_snapshot'],command=['lake','build','hexgroebner_bench'],policy='fresh detached snapshot; only pinned dependency packages shared')
with tempfile.TemporaryDirectory(prefix='groebner-column-kernels-') as temp:
 checkout=Path(temp)/'checkout';subprocess.run(['git','worktree','add','--detach',str(checkout),m['source_snapshot']],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True);(checkout/'.lake').mkdir();(checkout/'.lake/packages').symlink_to((root/'.lake/packages').resolve(),target_is_directory=True)
 try:
  with (out/'build.log').open('w') as f:r=subprocess.run(build['command'],cwd=checkout,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,LEAN_CC='/tmp/issue-10987-relocatable-wrapper/issue-10987-lean-cc'))
  build['returncode']=r.returncode;assert r.returncode==0;binary=out/'benchmark';shutil.copy2(checkout/'.lake/build/bin/hexgroebner_bench',binary);build['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
 finally:subprocess.run(['git','worktree','remove','--force',str(checkout)],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
(out/'build.json').write_text(json.dumps(build,indent=2)+'\n');shutil.copy2(base/'manifest.json',out/'source-manifest.json')
sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});records=[]
try:
 for kernel in ['columnDirect','columnIndex']:
  command=[str(binary),'run','Hex.Groebner.Bench.'+kernel,'--export-file',str(out/(kernel+'.json'))]
  with (out/(kernel+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  records.append(dict(kernel=kernel,command=command,returncode=r.returncode));assert r.returncode==0
  points=json.loads((out/(kernel+'.json')).read_text())['results'][0]['points'];assert len(points)==25 and all(v['status']=='ok' for v in points)
  print(kernel,'25points passed',flush=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,source_fingerprint=m['source_fingerprint'],binary_sha256=build.get('binary_sha256'),scope='Standalone scientific linear-model kernel sweep on shared host, fixed lean-bench trial-major five-size/five-repetition schedule, one leased CPU and one requested algorithm thread. Input preparation excluded; map allocation/initialization/construction, bounded row translation, independent complete output validation and full map/support structural hashing included. Dense direct layout and exact indexed sparse-ID layout have O(n) bounded-probe work. All completed samples retained, no activity filters and no unchanged rerun. Fresh detached benchmark build shares only pinned dependency packages. This is complexity/constant-factor evidence, not a before/after performance comparison or full-system leadership evidence.',runs=records),indent=2)+'\n');lease.close()
shutil.copy2(__file__,out/'measure.py')
