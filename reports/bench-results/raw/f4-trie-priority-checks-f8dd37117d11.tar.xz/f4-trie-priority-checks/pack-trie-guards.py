from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root));payload={}
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();runtime=tree_listing(FAMILY,'HEAD');checks=tree_listing(CHECKS,'HEAD')
assert runtime==json.loads((state/'trie-format-production/manifest.json').read_text())['source_manifest']
def add(name,path):
 assert name not in payload,name
 payload[name]=path.read_bytes()
for kind in ['native','full']:
 source=state/f'trie-reviewed-{kind}-status.json';records=json.loads(source.read_text())
 assert len(records)==(2 if kind=='native' else 9)
 assert all(row['exit_code']==0 and all(row[key]==value for key,value in identity.items())for row in records)
 add(kind+'-status.json',source)
 add(kind+'-checks.py',state/f'trie-reviewed-{kind}-checks.py')
payload['runtime.manifest']=runtime.encode();payload['checks.manifest']=checks.encode()
for listing,prefix in [(runtime,'runtime-sources/'),(checks,'checks-sources/')]:
 for line in listing.splitlines():
  _,oid,rest=line.split(' ',2);_,name=rest.split('\t')
  payload[prefix+name]=subprocess.check_output(['git','cat-file','blob',oid])
for row in json.loads((state/'trie-reviewed-full-status.json').read_text()):add(row['name']+'.log',Path(row['log']))
for compiler in ['clang','gcc']:
 add(compiler+'.log',state/f'trie-reviewed-{compiler}.log')
 for path in sorted((state/f'trie-reviewed-{compiler}').glob('*')):
  if path.is_file():add('probes/'+compiler+'/'+path.name,path)
add('report-generator.py',root/'scripts/bench/groebner_trie_report.py')
add('pack-trie-guards.py',Path(__file__))
payload['implementation.patch']=subprocess.check_output(['git','diff','cbc679874fc1466441253c2990a3402b85e97071..HEAD','--no-ext-diff'])
manifest={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())}
payload['sha256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=state/f'f4-trie-priority-checks-{identity["checks_fingerprint"]}.tar.xz'
with lzma.open(out,'wb',preset=6)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-trie-priority-checks/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
