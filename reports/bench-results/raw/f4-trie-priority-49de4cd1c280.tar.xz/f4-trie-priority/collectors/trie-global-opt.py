from pathlib import Path
p=Path('HexGroebner/NativeTrie.lean');s=p.read_text().replace('  let mut bestPriority := 0\n  for _ in [:n] do','  let mut bestPriority := 0\n  let lower := word view.nodes 4\n  for _ in [:n] do\n    if out.reducer.isSome && lower != 0 && bestPriority == lower then break')
p.write_text(s)
p=Path('HexGroebner/Reducer.lean');s=p.read_text().replace('  let mut bestPriority := 0\n  -- Each trie node','  let mut bestPriority := 0\n  let lower := if prune then index.packed.map (fun view => Native.Trie.word view.nodes 4) |>.getD 0 else 0\n  -- Each trie node').replace('  for _ in [:index.nodes.size] do\n    if pending.isEmpty then break\n    let node := pending.back!\n    pending := pending.pop\n    if work + 1 > maxWork', '  for _ in [:index.nodes.size] do\n    if result.isSome && lower != 0 && bestPriority == lower then break\n    if pending.isEmpty then break\n    let node := pending.back!\n    pending := pending.pop\n    if work + 1 > maxWork')
p.write_text(s)
p=Path('HexGroebner/ffi/trie_lookup.h');s=p.read_text().replace('    uint32_t best=0,best_priority=0;','    uint32_t best=0,best_priority=0;\n    uint32_t lower=(uint32_t)trie_read(nodes+16,4);').replace('    for(uint64_t visited=0;visited<n && sp;++visited) {','    for(uint64_t visited=0;visited<n && sp;++visited) {\n        if(best && lower && best_priority==lower) break;')
p.write_text(s)
