from pathlib import Path
import subprocess,os
state=Path('/home/kim/tmp/issue-10987');base=state/'trie-wide-production';prior=state/'sampled-io-production'
command=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'final-products-production/medium-inputs/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/compute'),'--baseline',str(prior/'binaries/compute'),'--baseline-manifest',str(prior/'manifest.json'),'--output',str(base/'before-after-repeat')]
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
with (base/'repeat-runner.log').open('w')as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
