from pathlib import Path
import hashlib,importlib.util,json,os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'trie-global-production'
helper=base/'root-sources/scripts/bench/cpu_lease.py'
spec=importlib.util.spec_from_file_location('frozen_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
manifest=json.loads((base/'manifest.json').read_text());binary=base/'binaries/bench'
for label,name in [('native','trieLookup'),('portable','trieLookupPortable')]:
 out=base/'kernels'/label;out.mkdir(parents=True,exist_ok=False)
 cpu,lease=module.cpu_lease();before=hashlib.sha256(binary.read_bytes()).hexdigest();assert before==manifest['binary_sha256']['bench'];load=os.getloadavg()
 command=[str(binary),'run','Hex.Groebner.Bench.'+name,'--outer-trials','3','--export-file',str(out/'result.json')]
 try:
  with (out/'stdout').open('wb')as stdout,(out/'stderr').open('wb')as stderr:
   r=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=lambda:os.sched_setaffinity(0,{cpu}),env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
 finally:lease.close()
 (out/'metadata.json').write_text(json.dumps(dict(command=command,exit_code=r.returncode,cpu=cpu,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),manifest=manifest,binary_sha256=before,binary_sha256_after=hashlib.sha256(binary.read_bytes()).hexdigest(),scope='Ordinary fixed trial-major lean-bench schedule, 3 outer trials, all declared 16..2048 inputs retained. Preparation excluded; selected monomial and charged work hashed. No filtering or rerun.'),indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
 print(label,'kernel complete',flush=True)
common=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'final-products-production/medium-inputs/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/compute')]
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
for name,prior in [('combined','sampled-io-production'),('early-stop','trie-wide-production')]:
 baseline=state/prior
 with (base/(name+'-runner.log')).open('w')as log:
  subprocess.run(common+['--baseline',str(baseline/'binaries/compute'),'--baseline-manifest',str(baseline/'manifest.json'),'--output',str(base/name)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
(base/'measure.py').write_bytes(Path(__file__).read_bytes())
