from pathlib import Path
import os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'trie-direct-production'
common=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'final-products-production/medium-inputs/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/compute')]
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
for name,prior in [('combined','sampled-io-production'),('control','trie-global-production')]:
 baseline=state/prior
 with (base/(name+'-runner.log')).open('w')as log:
  subprocess.run(common+['--baseline',str(baseline/'binaries/compute'),'--baseline-manifest',str(baseline/'manifest.json'),'--output',str(base/name)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
(base/'measure.py').write_bytes(Path(__file__).read_bytes())
