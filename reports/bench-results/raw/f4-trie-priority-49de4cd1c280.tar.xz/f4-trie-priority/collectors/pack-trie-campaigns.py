from pathlib import Path
import hashlib,io,json,lzma,tarfile
state=Path('/home/kim/tmp/issue-10987');payload={}
def add(name,path):
 assert name not in payload,name
 payload[name]=path.read_bytes()
for label in ['trie-bound','trie-wide','trie-global','trie-direct','trie-bounded','trie-selected']:
 root=state/(label+'-production')
 if not root.exists():continue
 for path in sorted(root.rglob('*')):
  if path.is_file() and 'binaries' not in path.relative_to(root).parts:
   add(label+'/'+path.relative_to(root).as_posix(),path)
 for suffix in ['native-checks.py','native-status.json','native-run.log','full-checks.py','full-status.json','full-run.log','freeze.log']:
  path=state/(label+'-'+suffix)
  if path.exists():add('verification/'+label+'/'+suffix,path)
 for compiler in ['clang','gcc']:
  log=state/f'{label}-{compiler}.log'
  if log.exists():add('verification/'+label+'/'+compiler+'.log',log)
 for path in sorted(state.glob(label+'-full-*.log')):add('verification/'+label+'/'+path.name,path)
for name in ['measure-trie-wide.py','measure-trie-wide-repeat.py','measure-trie-global.py','measure-trie-global-repeat.py','measure-trie-direct.py','measure-trie-direct-cli.py','measure-trie-bounded.py','trie-global-opt.py','trie-direct-opt.py','trie-global-fixture-audit.json']:
 path=state/name
 if path.exists():add('collectors/'+name,path)
add('collectors/pack-trie-campaigns.py',Path(__file__))
manifest={k:hashlib.sha256(v).hexdigest() for k,v in sorted(payload.items())}
payload['sha256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=state/'trie-priority-campaigns.tar.xz'
with lzma.open(out,'wb',preset=6)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-trie-priority/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
