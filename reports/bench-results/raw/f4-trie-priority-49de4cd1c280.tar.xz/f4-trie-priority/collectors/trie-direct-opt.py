from pathlib import Path
p=Path('HexGroebner/NativeTrie.lean');s=p.read_text().replace('    if out.reducer.isSome && lower != 0 && bestPriority == lower then break\n','').replace('            bestPriority := priority\n','            bestPriority := priority\n            if lower != 0 && priority == lower then return out\n');p.write_text(s)
p=Path('HexGroebner/Reducer.lean');s=p.read_text().replace('    if result.isSome && lower != 0 && bestPriority == lower then break\n','');needle='''            result := some candidate
            bestPriority := bound
    else
''';replacement='''            result := some candidate
            bestPriority := bound
          if lower != 0 && bestPriority == lower then return (.ok result, work)
    else
''';assert needle in s;s=s.replace(needle,replacement);p.write_text(s)
p=Path('HexGroebner/ffi/trie_lookup.h');s=p.read_text().replace('        if(best && lower && best_priority==lower) break;\n','').replace('                    best=key;best_priority=priority;','                    best=key;best_priority=priority;\n                    if(lower && priority==lower) return (struct trie_result){best,work,1};');p.write_text(s)
