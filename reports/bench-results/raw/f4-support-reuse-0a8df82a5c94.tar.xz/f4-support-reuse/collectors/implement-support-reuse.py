from pathlib import Path
p=Path('HexGroebner/Runtime.lean');s=p.read_text().replace('payload, including eight logical bytes per reducer-cache insertion and','payload, plus growth of the reusable symbolic support bitmap, including eight\nlogical bytes per reducer-cache insertion and');s=s.replace('  statistics : Statistics := {}\n\n/-- The shared', '''  statistics : Statistics := {}
  /-- Reused arena-ID membership bits; only payload growth is newly allocated. -/
  supportBits : ByteArray := {}
  /-- IDs whose bits must be cleared before the next symbolic preparation. -/
  supportQueue : Array Nat := #[]

/-- The shared''',1)
s=s.replace('⟨outcome.table, { statistics with work := outcome.table.work }⟩','{ state with table := outcome.table, statistics := { statistics with work := outcome.table.work } }').replace('⟨outcome.table, { statistics with work := failure.work }⟩','{ state with table := outcome.table, statistics := { statistics with work := failure.work } }').replace('⟨outcome.table,{ statistics with work := outcome.table.work }⟩','{ state with table := outcome.table, statistics := { statistics with work := outcome.table.work } }').replace('⟨outcome.table,{ statistics with work := failure.work }⟩','{ state with table := outcome.table, statistics := { statistics with work := failure.work } }');p.write_text(s)
p=Path('HexGroebner/Native.lean');s=p.read_text().replace('bitmap has exactly ceil(arena count/8) bytes.','bitmap has at least ceil(arena count/8) bytes.').replace('at\nmost4096','at\nmost 4096').replace('bits.size != (count+7)/8','bits.size < (count+7)/8');point='\nend Support\n';new='''
/-- Clear only a visited slice of u32 IDs. The bitmap is consumed and the
queue is borrowed. Invalid slices, IDs outside u32 or positions outside the
bitmap return none; at most4096 entries are visited. Other bits are preserved. -/
@[expose] def clearPortable (bits : ByteArray) (queue : @& Array Nat) (start terms : Nat) :
    Option ByteArray := Id.run do
  if terms > 4096 || start > queue.size || terms > queue.size-start then return none
  let mut bits := bits
  for i in [start:start+terms] do
    let id := queue[i]!
    if id ≥ 4294967296 || id/8 ≥ bits.size then return none
    let pos := id/8
    let mask : UInt8 := 1 <<< (id%8).toUInt8
    bits := bits.set! pos (bits[pos]! &&& ~~~mask)
  return some bits

/-- Bounded native clearing with complete prevalidation and copy-on-write for
shared bitmaps. The visited array is borrowed and no pointers are retained. -/
@[expose, extern "lean_hex_groebner_clear_support"]
def clear (bits : ByteArray) (queue : @& Array Nat) (start terms : @& Nat) : Option ByteArray :=
  clearPortable bits queue start terms
'''.replace('at most4096','at most 4096');assert point in s;s=s.replace(point,'\n'+new+point,1);p.write_text(s)
p=Path('HexGroebner/ffi/row_update.c');s=p.read_text().replace('(count+7)/8!=bit_bytes','(count+7)/8>bit_bytes');i=s.rfind('\n#endif');new='''
/* Clear a bounded visited-ID slice. Nat conversion is exact after the u32
   check, including boxed u32 values on 32-bit hosts. Validate before writes. */
LEAN_EXPORT lean_obj_res lean_hex_groebner_clear_support(lean_obj_arg bits,
        b_lean_obj_arg queue,b_lean_obj_arg start_arg,b_lean_obj_arg terms_arg) {
    size_t start,terms,n=lean_array_size(queue),bytes=lean_sarray_size(bits);
    lean_object *max_id,*result;
    if(!lean_is_scalar(start_arg) || !lean_is_scalar(terms_arg)) goto invalid_clear;
    start=lean_unbox(start_arg);terms=lean_unbox(terms_arg);
    if(terms>4096 || start>n || terms>n-start) goto invalid_clear;
    max_id=lean_unsigned_to_nat(UINT32_MAX);
    for(size_t i=0;i<terms;++i) {
        lean_object *id=lean_array_cptr(queue)[start+i];
        if(!lean_nat_dec_le(id,max_id) || lean_uint64_of_nat(id)/8>=bytes) {
            lean_dec(max_id);goto invalid_clear;
        }
    }
    lean_dec(max_id);
    if(terms) {
        bits=remap_reserve(bits,bytes,0);
        uint8_t *target=lean_sarray_cptr(bits);
        for(size_t i=0;i<terms;++i) {
            uint64_t id=lean_uint64_of_nat(lean_array_cptr(queue)[start+i]);
            target[id/8]&=(uint8_t)~(1u<<(id%8));
        }
    }
    result=lean_alloc_ctor(1,1,0);lean_ctor_set(result,0,bits);return result;
invalid_clear:
    lean_dec(bits);return lean_box(0);
}
''';s=s[:i]+'\n'+new+s[i:];p.write_text(s)
p=Path('HexGroebner/Symbolic.lean');s=p.read_text();a=s.index('/-- Queue each arena');b=s.index('/-- Close every selected term',a);new='''/-- Move scratch buffers out of the state before calling an owned operation.
Invalid internal geometry discards scratch only; charged state is preserved. -/
private def supportStep (operation : ByteArray → Array Nat → Option (ByteArray × Array Nat)) :
    Computation Unit := ExceptT.mk fun state =>
  let bits := state.supportBits
  let queue := state.supportQueue
  let state := { state with supportBits := {},supportQueue := #[] }
  match operation bits queue with
  | some (bits,queue) => (.ok (),{ state with supportBits := bits,supportQueue := queue })
  | none => (.error (.representation .index),state)

/-- Reset only the previous preparation's visited IDs. An exhausted attempt
retains both scratch buffers, so resumption reuses their paid-for payload. -/
private def resetSupport (limits : Limits) : Computation Unit := do
  let count := (← get).supportQueue.size
  spend limits count
  for chunk in [:(count+4095)/4096] do
    let start := chunk*4096
    let terms := min 4096 (count-start)
    supportStep fun bits queue => do
      let bits ← if limits.nativeMonomials then Native.Support.clear bits queue start terms
        else Native.Support.clearPortable bits queue start terms
      return (bits,queue)
  modify fun state => { state with supportQueue := #[] }

/-- Queue each arena identifier once, growing the reusable bitmap only when
necessary. Growth and clearing work count against the parent allowances. -/
private def queueSupport (limits : Limits) (p : Polynomial) : Computation Unit := do
  if p.size == 0 then return
  let count := (← get).table.count
  let size := (count+7)/8
  if size ≥ USize.size then throw (.representation .address)
  let oldSize := (← get).supportBits.size
  if oldSize < size then
    let extra := size-oldSize
    spend limits extra
    allocate limits extra
    for chunk in [:(extra+4095)/4096] do
      let amount := min 4096 (extra-chunk*4096)
      supportStep fun bits queue => do
        let bits ← if limits.nativeMonomials then Native.Columns.zeros bits amount
          else Native.Columns.zerosPortable bits amount
        return (bits,queue)
  for chunk in [:(p.size+4095)/4096] do
    let start := chunk*4096
    let terms := min 4096 (p.size-start)
    supportStep fun bits queue => if limits.nativeMonomials then
        Native.Support.queue count.toUInt64 p.support start terms bits queue
      else Native.Support.queuePortable count.toUInt64 p.support start terms bits queue

''';s=s[:a]+new+s[b:];s=s.replace('  let mut support : ByteArray := {}\n  let mut pending : Array Nat := #[]','  resetSupport limits',1)
s=s.replace('    let (next, queued) ← queueSupport limits p support pending\n    support := next\n    pending := queued','    queueSupport limits p').replace('      let (next, queued) ← queueSupport limits p support pending\n      support := next\n      pending := queued','      queueSupport limits p')
s=s.replace('    if cursor ≥ pending.size then break\n    let monomial := pending[cursor]!','    if cursor ≥ (← get).supportQueue.size then break\n    let monomial := (← get).supportQueue[cursor]!').replace('  if cursor < pending.size then','  if cursor < (← get).supportQueue.size then').replace('  let columns ← sort context limits pending','  let columns ← sort context limits (← get).supportQueue');p.write_text(s)
