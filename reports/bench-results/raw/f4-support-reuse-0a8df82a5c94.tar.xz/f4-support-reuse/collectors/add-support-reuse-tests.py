from pathlib import Path
p=Path('HexGroebner/Runtime.lean');s=p.read_text().replace('  if (support.size/4) == 0 then return','  if support.size%4 != 0 then throw (.representation .index)\n  if support.isEmpty then return');p.write_text(s)
p=Path('conformance/HexGroebner/ReducerCacheConformance.lean');s=p.read_text().replace('    let supportBytes := ((← get).table.count + 7) / 8\n','').replace('    -- A cache hit reuses polynomial payloads; each matrix owns its support bitmap.\n    if after.allocatedBytes != before.allocatedBytes + supportBytes then return false','    -- Cache hits also reuse the workspace bitmap without a new payload charge.\n    if after.allocatedBytes != before.allocatedBytes then return false');p.write_text(s)
p=Path('conformance/HexGroebner/SupportConformance.lean');s=p.read_text().replace('(8,packed #[0],zeroes 2)','(8,packed #[0],zeroes 0)').replace('bit33','bit 33');point='\n#guard queueChecks 0';new='''
/-- Clearing rejects malformed slices and IDs and preserves every other bit,
including duplicates, empty slices and a bitmap shared with an observer. -/
def clearChecks (seed : Nat) : Bool := Id.run do
  let bits : ByteArray := ⟨Array.replicate 9 255⟩
  let queue := #[0,7,8,31,32,63,63,64,seed%65]
  for start in [0,1,queue.size,queue.size+1,2^100] do
    for terms in [0,1,queue.size,4096,4097,2^100] do
      let expected := Native.Support.clearPortable bits queue start terms
      if Native.Support.clear bits queue start terms != expected then return false
      if bits != (⟨Array.replicate 9 255⟩ : ByteArray) then return false
  let some actual := Native.Support.clear bits #[0,7,8,31,32,63,63] 0 7 | return false
  if actual != (⟨#[126,254,255,127,254,255,255,127,255]⟩ : ByteArray) then return false
  for queue in [#[72],#[2^32],#[2^100]] do
    if (Native.Support.clear bits queue 0 1).isSome then return false
  let queue := (Array.range 4097).map fun i => (i+seed)%65
  let expected := Native.Support.clearPortable bits queue 0 4096
  if expected.isNone || Native.Support.clear bits queue 0 4096 != expected then return false
  return (Native.Support.clear bits queue 0 4097).isNone

#guard clearChecks 0
#guard clearChecks 17
''';assert point in s;s=s.replace(point,'\n'+new+point,1);p.write_text(s)
p=Path('conformance/HexGroebner/PairRowsConformance.lean');s=p.read_text().replace('degrees k down to0','degrees k down to 0');point='\nend Hex.Groebner.PairRowsConformance';assert point in s;new='''
/-- Production symbolic preprocessing crosses both chunk limits: a 40000-ID
arena needs5000 bitmap bytes, and each target contains4200 distinct IDs.
Separate-tail remainders reuse the bitmap: only the first call pays its growth.
The visited queue is cleared between calls, without changing the normal form. -/
def chunkChecks (seed : Nat) (native : Bool) : Bool := Id.run do
  let context : Context := ⟨field,1,.lex⟩
  let limits : Limits := { work := 1000000000, nativeRows := native,nativeMonomials := native }
  let action : Computation Bool := do
    for i in [:40000] do
      let _ ← intern limits #[i.toUInt64]
    let mut p : Polynomial := {}
    for i in [:4200] do
      p := { support := Packed.push .u32 p.support (4199-i+seed%17).toUInt64
        coefficients := p.coefficients.push 1 }
    let index ← ReducerIndex.build context limits #[]
    let before := (← get).statistics
    let first ← p.remainderWith context limits index #[]
    let middle := (← get).statistics
    let second ← p.remainderWith context limits index #[]
    let after := (← get).statistics
    if first.support != p.support || first.coefficients != p.coefficients ||
        second.support != p.support || second.coefficients != p.coefficients then return false
    if middle.allocatedBytes-before.allocatedBytes != after.allocatedBytes-middle.allocatedBytes+5000 then
      return false
    let scratch := (← get).support
    return scratch.bits.size == 5000 && scratch.queue.size == 4200
  match action.run { table := { arity := 1 } } with
  | (.ok value,_) => value
  | _ => false
'''.replace('needs5000','needs 5000').replace('contains4200','contains 4200');s=s.replace(point,'\n'+new+point,1);p.write_text(s)
p=Path('scripts/ci/check_groebner_matrix.py');s=p.read_text().replace('#define lean_hex_groebner_queue_support hex_test_queue_support','#define lean_hex_groebner_clear_support hex_test_clear_support\n#define lean_hex_groebner_queue_support hex_test_queue_support',1).replace('#undef lean_hex_groebner_queue_support','#undef lean_hex_groebner_clear_support\n#undef lean_hex_groebner_queue_support',1).replace('static uint64_t support_calls=0;','static uint64_t support_calls=0,support_copies=0,clear_calls=0;',1).replace(' ++support_calls;return hex_test_queue_support',' ++support_calls;if(!lean_is_exclusive(bits))++support_copies;return hex_test_queue_support',1)
point='LEAN_EXPORT lean_obj_res hex_test_support_aliases(lean_obj_arg world) {';new='''__typeof__(hex_test_clear_support) __wrap_lean_hex_groebner_clear_support;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_clear_support(lean_obj_arg bits,
 b_lean_obj_arg queue,b_lean_obj_arg start,b_lean_obj_arg terms) {
 ++clear_calls;if(!lean_is_exclusive(bits))++support_copies;
 return hex_test_clear_support(bits,queue,start,terms);
}
LEAN_EXPORT lean_obj_res hex_test_support_copies(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(support_copies));
}
LEAN_EXPORT lean_obj_res hex_test_support_clears(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(clear_calls));
}
''';assert point in s;s=s.replace(point,new+point,1).replace('"-Wl,--wrap=lean_hex_groebner_queue_support",','"-Wl,--wrap=lean_hex_groebner_queue_support", "-Wl,--wrap=lean_hex_groebner_clear_support",',1)
s=s.replace('@[extern "hex_test_support_aliases"] opaque supportAliases : IO Bool','@[extern "hex_test_support_aliases"] opaque supportAliases : IO Bool\n@[extern "hex_test_support_copies"] opaque supportCopies : IO UInt64\n@[extern "hex_test_support_clears"] opaque supportClears : IO UInt64',1)
a=s.index('  let symbolicSeed ← Hex.Groebner.NativeChecks.readSeed\n',s.index('private def checkBinary'));b=s.index('  let allocationBefore',a);symbolic=s[a:b];s=s[:a]+s[b:]
point='  IO.println s!"native support queue calls: {(← supportCount)-before}"';new='''  if !Hex.Groebner.SupportConformance.clearChecks seed then
    throw (IO.userError "native support clear/reference mismatch")
  let copiesBefore ← supportCopies
  let queuesBefore ← supportCount
  let clearsBefore ← supportClears
'''+symbolic+'''  for native in [true,false] do
    if !Hex.Groebner.PairRowsConformance.chunkChecks seed native then
      throw (IO.userError "production support chunks or separate-tail allocation mismatch")
  if (← supportCopies) != copiesBefore || (← supportCount) ≤ queuesBefore ||
      (← supportClears) ≤ clearsBefore then
    throw (IO.userError "production support loop copied scratch or native chunks were unused")
  IO.println s!"production support calls/clears/copies: {(← supportCount)-queuesBefore}/{(← supportClears)-clearsBefore}/{(← supportCopies)-copiesBefore}"
''';assert point in s;s=s.replace(point,new+point,1);p.write_text(s)
