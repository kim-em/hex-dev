from pathlib import Path
import os,sys,json,hashlib,subprocess
s=Path('/home/kim/tmp/issue-10987');base=s/'symbolic-bitmap-production';out=base/'profiles-mq10-corrected';out.mkdir(exist_ok=False);sys.path.insert(0,str(Path.cwd()))
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_checks import source_identity
identity=source_identity();cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();records=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifests={a:json.loads((s/p/'manifest.json').read_text())for a,p in [('A','binary-table-bounds-production'),('B','symbolic-bitmap-production')]};assert manifests['A']['compilers']==manifests['B']['compilers']
meta=json.loads((base/'f2-false/metadata.json').read_text());row=next(r for r in meta['samples']if r['arm']=='B'and r['block']==0 and r['case']=='mq10-f2');flags=row['command'][row['command'].index(str(base/'binaries/compute'))+1:];inp=Path(flags[-1]);(out/'input.json').write_bytes(inp.read_bytes());outputs=[]
try:
 for i,arm in enumerate(['A','B','B','A']):
  assert source_identity()==identity
  binary=s/('binary-table-bounds-production'if arm=='A'else'symbolic-bitmap-production')/'binaries/compute';assert sha(binary)==manifests[arm]['binary_sha256']['compute'];name=f'mq10-{i}-{arm}';command=['perf','record','-e','cycles:u','-F','1999','--call-graph','dwarf,16384','-o',str(out/(name+'.data')),'--',str(binary),*flags]
  with(out/(name+'.stdout')).open('w')as stdout,(out/(name+'.stderr')).open('w')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  record=dict(name=name,arm=arm,command=command,exit_code=r.returncode,binary_sha256=sha(binary),input_sha256=sha(inp));records.append(record);assert r.returncode==0
  for options,suffix in [(['--no-children','--percent-limit','0.5'],'report'),(['--header-only'],'header')]:
   with(out/(name+'.'+suffix)).open('w')as f:subprocess.run(['perf','report','--stdio',*options,'-i',str(out/(name+'.data'))],stdout=f,stderr=subprocess.STDOUT,check=True)
  record['trace_sha256']=sha(out/(name+'.data'));outputs.append(json.loads((out/(name+'.stdout')).read_text()))
 assert all(v['basis']==outputs[0]['basis']for v in outputs)
 for v in outputs:
  for k in ['work','allocatedBytes']:v['statistics'].pop(k)
 assert all(v['statistics']==outputs[0]['statistics']for v in outputs)
finally:
 assert source_identity()==identity
 (out/'metadata.json').write_text(json.dumps(dict(identity=identity,manifest=manifests,cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),records=records,scope='Four adjacent AB/BA diagnostic user-cycle profiles to explain the unexpected bitmap-only slowdown. Complete bases and structural statistics agree; work and allocation include explicit bitmap growth. No timing or acceptance claim; all raw traces, errors and sample counts retained.'),indent=2)+'\n');lease.close();(out/'collector.py').write_bytes(Path(__file__).read_bytes())
