import Lake
open Lake DSL
package GroebnerIndexedReads
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
lean_lib IndexedDev where
  roots := #[`IndexedWord,`IndexedMonomial,`IndexedRuntime,`IndexedPolynomial,`IndexedReducer,`IndexedPairs,`IndexedSymbolic,`IndexedF4]
lean_exe indexed_compare where
  root := `Main
lean_exe indexed_checks where
  root := `IndexedTest
