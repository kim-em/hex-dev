import IndexedF4
import HexGroebner.F4Fixtures
open Hex.Groebner

private def readerChecks : Bool := Id.run do
  for width in [Width.u8,.u16,.u32] do
    for size in [4:81] do
      for seed in [:8] do
        let bytes : ByteArray := ⟨(Array.range size).map fun i => UInt8.ofNat ((seed*7919+i*69069)%256)⟩
        for index in [:size/width.bytes] do
          if Packed.read width bytes index != (Native.read bytes width.bytes (index*width.bytes)).toUInt64 then return false
  return true
#guard readerChecks

private def checks : Bool := Id.run do
  for field in Fixtures.fields do
    for order in [TermOrder.lex,.grlex,.grevlex] do
      for c in F4Fixtures.cases field do
        let context : Context := ⟨field,c.variables,order⟩
        let .candidate expected stats := computeWith context {} c.generators | return false
        let .candidate actual usage := Indexed.computeWith context {} c.generators | return false
        if actual.polynomials != expected.polynomials || usage != stats then return false
  return true
#guard checks

def main : IO Unit := do
  if checks && readerChecks then IO.println "indexed word reads: independent decoder and all 567 bases/counters match"
  else throw (IO.userError "indexed word mismatch")
