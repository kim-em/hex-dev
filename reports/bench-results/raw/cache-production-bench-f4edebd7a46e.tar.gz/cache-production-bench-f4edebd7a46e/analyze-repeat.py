from pathlib import Path
import json,math,statistics
base=Path('/tmp/hex-groebner-cache-production');g=lambda v:math.exp(sum(map(math.log,v))/len(v));summary=lambda v:dict(geomean=g(v),median=statistics.median(v),minimum=min(v),maximum=max(v));all_ratios={};analyses={}
for suffix in ['','-repeat']:
 p=base/('cache-production-bench-f4edebd7a46e'+suffix);m=json.loads((p/'metadata.json').read_text());cases={};count=0
 for case in ['cyclic4','cyclic5','cyclic6','katsura3','reimer5','cyclic6Small']:
  v=[]
  for block in [0,1]:
   a,b=[json.loads((p/f'{case}-b{block}-{arm}.json').read_text())['results'][0] for arm in ['A','B']];assert a['hashes_agree'] and b['hashes_agree'] and a['observed_hash']==b['observed_hash'];assert len(a['points'])==len(b['points'])==5
   for x,y in zip(a['points'],b['points']):
    assert x['status']==y['status']=='ok' and x['result_hash']==y['result_hash'];count+=2;v.append((y['total_nanos']/y['inner_repeats'])/(x['total_nanos']/x['inner_repeats']))
  cases[case]=dict(**summary(v),ratios=v);all_ratios.setdefault(case,[]).extend(v)
 o=dict(cpu=m['cpu'],points=count,all_hashes_match=True,per_case=cases);analyses['repeat' if suffix else 'first']=o
 if suffix:(p/'analysis.json').write_text(json.dumps(o,indent=2)+'\n')
analyses['all_retained_points']=dict(points=240,all_hashes_match=True,per_case={c:summary(v) for c,v in all_ratios.items()});(p/'combined-analysis.json').write_text(json.dumps(analyses,indent=2)+'\n')
print('CPU first/repeat',analyses['first']['cpu'],analyses['repeat']['cpu'])
for case,v in analyses['all_retained_points']['per_case'].items():print(case,{k:round(x,4) for k,x in v.items()},'repeat',round(analyses['repeat']['per_case'][case]['geomean'],4))
