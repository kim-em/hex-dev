from pathlib import Path
import json,math,statistics
base=Path('/tmp/hex-groebner-cache-production');g=lambda v:math.exp(sum(map(math.log,v))/len(v));summary=lambda v:dict(geomean=g(v),median=statistics.median(v),minimum=min(v),maximum=max(v))
p=next(base.glob('cache-production-records-*'));m=json.loads((p/'metadata.json').read_text());ratios=[];wall=[];cases={}
for c in json.loads((p/'diagnostic-suite.json').read_text())['cases']:
 v=[];w=[];allocated=[]
 for block in [0,1]:
  a,b=[next(x for x in m['samples'] if x['case']==c['name'] and x['block']==block and x['arm']==arm) for arm in ['A','B']];assert a['status']==b['status']=='ok'
  for k in a['statistics']:
   if k not in ['candidate_nanos','work','allocated_bytes']:assert a['statistics'][k]==b['statistics'][k],(c,k)
  assert json.loads((p/f"{c['name']}-b{block}-A.stdout").read_text())['basis']==json.loads((p/f"{c['name']}-b{block}-B.stdout").read_text())['basis'];x=b['statistics']['candidate_nanos']/a['statistics']['candidate_nanos'];v.append(x);ratios.append(x);wall.append(b['wall_nanos']/a['wall_nanos']);w.append(b['statistics']['work']/a['statistics']['work']);allocated.append(b['statistics']['allocated_bytes']/a['statistics']['allocated_bytes'])
 cases[c['name']]=dict(candidate_ratios=v,work_ratios=w,allocation_ratios=allocated);print(c['name'],*[round(x,4) for x in v])
o=dict(cpu=m['cpu'],samples=len(m['samples']),candidate=summary(ratios),wall=summary(wall),per_case=cases,complete_bases_and_non_resource_counters_equal=True);(p/'analysis.json').write_text(json.dumps(o,indent=2)+'\n');print('full system',{k:v for k,v in o.items() if k!='per_case'})
p=next(base.glob('cache-production-bench-*'));m=json.loads((p/'metadata.json').read_text());cases={};count=0
for case in ['cyclic4','cyclic5','cyclic6','katsura3','reimer5','cyclic6Small']:
 v=[]
 for block in [0,1]:
  a,b=[json.loads((p/f'{case}-b{block}-{arm}.json').read_text())['results'][0] for arm in ['A','B']];assert a['hashes_agree'] and b['hashes_agree'] and a['observed_hash']==b['observed_hash'];assert len(a['points'])==len(b['points'])==5
  for x,y in zip(a['points'],b['points']):
   assert x['status']==y['status']=='ok' and x['result_hash']==y['result_hash'];count+=2;v.append((y['total_nanos']/y['inner_repeats'])/(x['total_nanos']/x['inner_repeats']))
 cases[case]=dict(**summary(v),ratios=v)
o=dict(cpu=m['cpu'],points=count,all_hashes_match=True,per_case=cases);(p/'analysis.json').write_text(json.dumps(o,indent=2)+'\n');print('bench CPU',m['cpu'],'points',count)
for c,v in cases.items():print(c,{k:round(v[k],4) for k in ['geomean','median','minimum','maximum']})
