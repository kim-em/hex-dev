from pathlib import Path
p=Path('HexGroebner/Native.lean');s=p.read_text();point='\nend Hex.Groebner.Native'
assert point in s
new='''
namespace Support

/-- Queue the previously unseen u32 arena IDs in one slice, preserving first
occurrence order. The bitmap has exactly ceil(arena count/8) bytes. Pending is
an arbitrary prefix; its contents do not seed the bitmap. A slice contains at
most4096 terms. Malformed geometry, out-of-range IDs or a larger slice return
none. Existing bitmap bits and pending entries are retained. -/
@[expose] def queuePortable (count : UInt64) (ids : @& ByteArray) (start terms : Nat)
    (bits : ByteArray) (pending : Array Nat) : Option (ByteArray × Array Nat) := Id.run do
  let count := count.toNat
  if count > 4294967296 || bits.size != (count+7)/8 || ids.size%4 != 0 ||
      terms > 4096 || start > ids.size/4 || terms > ids.size/4-start then return none
  let mut bits := bits
  let mut pending := pending
  for i in [start:start+terms] do
    let id := read ids 4 (4*i)
    if id ≥ count then return none
    let pos := id/8
    let mask : UInt8 := 1 <<< (id%8).toUInt8
    let value := bits[pos]!
    if value &&& mask == 0 then
      bits := bits.set! pos (value ||| mask)
      pending := pending.push id
  return some (bits,pending)

/-- Bounded native support queue. The ID slice is borrowed; bitmap and pending
are consumed, with copy-on-write for shared storage and borrowed aliases.
Validation precedes mutation. No pointer is retained and byte order is explicit. -/
@[expose, extern "lean_hex_groebner_queue_support"]
def queue (count : UInt64) (ids : @& ByteArray) (start terms : @& Nat)
    (bits : ByteArray) (pending : Array Nat) : Option (ByteArray × Array Nat) :=
  queuePortable count ids start terms bits pending

end Support
'''
s=s.replace(point,'\n'+new+point);p.write_text(s)
p=Path('HexGroebner/ffi/row_update.c');s=p.read_text();point='\n#endif';i=s.rfind(point);assert i>0
new='''
/* Native.Support.queuePortable. Validate the entire bounded slice before any
   writes; retain a borrowed alias while copy-on-write replaces the bitmap. */
LEAN_EXPORT lean_obj_res lean_hex_groebner_queue_support(uint64_t count,
        b_lean_obj_arg ids,b_lean_obj_arg start_arg,b_lean_obj_arg terms_arg,
        lean_obj_arg bits,lean_obj_arg pending) {
    size_t start,terms,bytes=lean_sarray_size(ids),bit_bytes=lean_sarray_size(bits);
    const uint8_t *source=lean_sarray_cptr(ids);
    lean_object *alias=NULL,*pair,*result;
    if(count>UINT64_C(4294967296) || (count+7)/8!=bit_bytes || bytes%4 ||
       !lean_is_scalar(start_arg) || !lean_is_scalar(terms_arg)) goto invalid_support;
    start=lean_unbox(start_arg);terms=lean_unbox(terms_arg);
    if(terms>4096 || start>bytes/4 || terms>bytes/4-start) goto invalid_support;
    for(size_t i=0;i<terms;++i)
        if(read_le(source+(start+i)*4,4)>=count) goto invalid_support;
    if(terms) {
        if(bits==ids) {alias=bits;lean_inc(alias);}
        bits=remap_reserve(bits,bit_bytes,alias!=NULL);
        uint8_t *target=lean_sarray_cptr(bits);
        for(size_t i=0;i<terms;++i) {
            uint64_t id=read_le(source+(start+i)*4,4);
            uint8_t mask=(uint8_t)(1u<<(id%8));
            if(!(target[id/8]&mask)) {
                target[id/8]|=mask;
                pending=lean_array_push(pending,lean_unsigned_to_nat((unsigned)id));
            }
        }
    }
    if(alias) lean_dec(alias);
    pair=lean_alloc_ctor(0,2,0);lean_ctor_set(pair,0,bits);lean_ctor_set(pair,1,pending);
    result=lean_alloc_ctor(1,1,0);lean_ctor_set(result,0,pair);return result;
invalid_support:
    lean_dec(bits);lean_dec(pending);return lean_box(0);
}
'''
s=s[:i]+'\n'+new+s[i:];p.write_text(s)
p=Path('HexGroebner/Symbolic.lean');s=p.read_text();start=s.index('  let mut pending := pending\n',s.index('private def queueSupport'));end=s.index('  return (bits,pending)',start)
s=s[:start]+'''  let mut pending := pending
  for chunk in [:(p.size+4095)/4096] do
    let start := chunk*4096
    let terms := min 4096 (p.size-start)
    let some (next,queued) := if limits.nativeMonomials then
        Native.Support.queue count.toUInt64 p.support start terms bits pending
      else Native.Support.queuePortable count.toUInt64 p.support start terms bits pending |
        throw (.representation .index)
    bits := next
    pending := queued
'''+s[end:];p.write_text(s)
