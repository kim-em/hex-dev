from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');base=s/'support-native-production';old=base;sys.path.insert(0,str(root))
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_checks import source_identity
identity=source_identity();manifests={a:json.loads((p/'manifest.json').read_text())for a,p in [('A',old),('B',base)]};binaries={a:p/'binaries/bench'for a,p in [('A',old),('B',base)]}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();digests={a:sha(p)for a,p in binaries.items()};assert all(digests[a]==m['binary_sha256']['bench']for a,m in manifests.items())
assert manifests['A']==manifests['B'] and digests['A']==digests['B']
out=base/'kernels-long';out.mkdir(exist_ok=False);cpu,lease=cpu_lease();samples=[]
def run(label,arm,function,extra):
 assert source_identity()==identity
 directory=out/label;directory.mkdir(parents=True)
 command=['/usr/bin/time','-f','%M','-o',str(directory/'rss'),str(binaries[arm]),'run','Hex.Groebner.Bench.'+('supportPortable'if arm=='A'else'supportNative'),*extra,'--target-inner-nanos','8000000000','--export-file',str(directory/'result.json')]
 if not Path(command[0]).exists():
  import shutil
  command[0]=shutil.which('time')
 start=time.time_ns();load=os.getloadavg()
 with(directory/'stdout').open('wb')as stdout,(directory/'stderr').open('wb')as stderr:
  r=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=lambda:os.sched_setaffinity(0,{cpu}),env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
 row=dict(label=label,arm=arm,function=function,command=command,exit_code=r.returncode,started_ns=start,finished_ns=time.time_ns(),cpu=cpu,load_start=load,load_end=os.getloadavg());samples.append(row)
 (base/'kernel-long-status.json').write_text(json.dumps(dict(manifest=manifests,binary_sha256=digests,binary_sha256_after={a:sha(p)for a,p in binaries.items()},samples=samples,host=os.uname().nodename,threads=1,identity=identity),indent=2)+'\n')
 assert source_identity()==identity and r.returncode in [0,2]
 value=json.loads((directory/'result.json').read_text())['results'][0];assert all(p['status']=='ok'for p in value['points']);print(label,r.returncode,flush=True)
shapes=['supportQueue'];sizes=[256,1024,4096,16384,65536]
try:
 for block in [0,1]:
  for function in shapes:
   for n in sizes:
    for arm in (['A','B']if block==0 else['B','A']):run(f'matched/{function}/b{block}-{n}-{arm}',arm,function,['--outer-trials','1','--param-schedule','doubling','--param-floor',str(n),'--param-ceiling',str(n)])
 for function in shapes:
  for n in sizes:
   points=[json.loads((out/f'matched/{function}/b{b}-{n}-{a}/result.json').read_text())['results'][0]['points'][0]for b in [0,1]for a in ['A','B']]
   assert len({p['result_hash']for p in points})==1
finally:
 lease.close();(base/'measure-support-kernels-long.py').write_bytes(Path(__file__).read_bytes())
