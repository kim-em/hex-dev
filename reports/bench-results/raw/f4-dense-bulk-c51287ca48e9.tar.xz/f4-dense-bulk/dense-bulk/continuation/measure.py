from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
state=Path('/home/kim/tmp/issue-10987');base=state/'dense-bulk-production';old=state/'trie-format-production'
spec=importlib.util.spec_from_file_location('cpu_lease',base/'root-sources/scripts/bench/cpu_lease.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
manifest={arm:json.loads((path/'manifest.json').read_text())for arm,path in [('A',old),('B',base)]};binaries={'A':old/'binaries/bench','B':base/'binaries/bench'}
digests={arm:hashlib.sha256(path.read_bytes()).hexdigest()for arm,path in binaries.items()};assert all(digests[arm]==m['binary_sha256']['bench']for arm,m in manifest.items())
cpu,lease=module.cpu_lease();samples=[];out=base/'continuation';out.mkdir(exist_ok=False)
try:
 for block in [0,1]:
  for function in ['matrixFrame','matrixSparse']:
   for n in [64,128,256,512,1024]:
    for arm in (['A','B']if block==0 else['B','A']):
     label=f'b{block}-{function}-{n}-{arm}';directory=out/label;directory.mkdir()
     command=[str(binaries[arm]),'run','Hex.Groebner.Bench.'+function,'--outer-trials','1','--param-schedule','doubling','--param-floor',str(n),'--param-ceiling',str(n),'--export-file',str(directory/'result.json')]
     start=time.time_ns();load=os.getloadavg()
     with(directory/'stdout').open('wb')as stdout,(directory/'stderr').open('wb')as stderr:
      result=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=lambda:os.sched_setaffinity(0,{cpu}),env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
     sample=dict(label=label,block=block,function=function,param=n,arm=arm,command=command,exit_code=result.returncode,started_ns=start,finished_ns=time.time_ns(),cpu=cpu,load_start=load,load_end=os.getloadavg());samples.append(sample)
     (directory/'metadata.json').write_text(json.dumps(sample,indent=2)+'\n')
     (out/'metadata.json').write_text(json.dumps(dict(manifest=manifest,binary_sha256=digests,binary_sha256_after={arm:hashlib.sha256(path.read_bytes()).hexdigest()for arm,path in binaries.items()},samples=samples,host=os.uname().nodename,threads=1,field=65537,dense_pivots=False),indent=2)+'\n')
     print(label,result.returncode,flush=True)
     if result.returncode not in [0,2]:raise SystemExit(result.returncode)
finally:
 lease.close();(out/'measure.py').write_bytes(Path(__file__).read_bytes())
