from pathlib import Path
import json,hashlib,subprocess,shutil,tarfile
repo=Path('/tmp/hex-groebner-column-map-native-dev');dest=Path('/tmp/hex-groebner-evidence-review/reports/bench-results');catalog=[]
for variant,prefix,status_prefix in [('column-map','issue-10987-column-map-','issue-10987-column-map-full-updated'),('column-map-native','issue-10987-column-map-native-','issue-10987-column-map-native-full')]:
 base=Path('/tmp/hex-groebner-'+variant+'-production');m=json.loads((base/'manifest.json').read_text());checks=json.loads(Path('/tmp/'+status_prefix+'-status.json').read_text());assert len(checks)==9 and all(v['exit_code']==0 for v in checks)
 name=variant+'-'+m['source_fingerprint'];stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
 for p in base.iterdir():
  if p.name=='binaries':continue
  if p.name=='bench-binaries':
   d=stage/p.name;d.mkdir()
   for q in p.iterdir():
    if q.is_file() and q.name not in ['A','B']:shutil.copy2(q,d/q.name)
  elif p.is_dir():shutil.copytree(p,stage/p.name)
  else:shutil.copy2(p,stage/p.name)
 bm=json.loads(Path('/tmp/hex-groebner-whole-matrix-reviewed-production/manifest.json').read_text());(stage/'baseline-manifest.json').write_text(json.dumps(bm,indent=2)+'\n')
 for folder,manifest in [('root-sources',m),('baseline-sources',bm)]:
  for line in manifest['source_manifest'].splitlines():
   mode,n=line.split('\t',1);oid=mode.split()[1];b=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;p=stage/folder/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 shutil.copytree(Path('/tmp/hex-groebner-'+variant+'-validation-snapshot'),stage/'validation-sources')
 for p in Path('/tmp').glob(prefix+'*'):
  if p.is_file() and p.suffix in ['.log','.json'] and (variant.endswith('native') or not any(x in p.name for x in ['native-','reserved-'])):shutil.copy2(p,stage/p.name)
 for n in ['issue-10987-lean-cc','issue-10987-lean-cc-flags.json','run-issue-10987-full-checks.py','measure-groebner-'+variant+'.py','build-groebner-'+variant+'-benches.py']:shutil.copy2(Path('/tmp')/n,stage/n)
 shutil.copytree('/tmp/issue-10987-relocatable-wrapper',stage/'relocatable-compiler-helper')
 if variant.endswith('native'):shutil.copy2('/tmp/issue-10987-column-map-native-opus-review.txt',stage/'independent-review.txt')
 scope='Historical packed dense column lookup prototype; do not adopt unchanged. Dense ID-prefix intervals use u32 positions plus one; sparse intervals or insufficient remaining work/payload allowance use the hash map. This budget-dependent route can be non-monotone and is superseded by geometry-only selection. Native variant adds <=4096-entry translation with four exported runtime byte pushes per entry and two lookup passes, superseded by one reserve and direct stores. Nine local check steps pass; native variant additionally passes eight Clang/GCC ASan/UBSan variants with 9269 F4 native remaps each and exclusive borrowed/output alias tests. Pure prototype has no dedicated new sanitizer campaign. All240 CLI processes/120 complete basis pairs and240 fixed structural output points agree; no measured failures/timeouts. Work and allocatedBytes differ from the whole-matrix baseline and are retained. Each observation has a first campaign and sole unchanged repeat; all samples, outliers, failures, host activity, CPU, RSS and source/build identities retained. No further unchanged repeat. Generated F4 fixture matches1134old records except work/referenceWork/serialWork, which are updated and checked independently. The earlier oracle fixture mismatch and initial unregistered or reserved-keyword test build failures are retained. Candidate production excludes certificate production, independent final certification and kernel replay; development evidence, not SPEC acceptance. Wrapper SDKClang23.1.0/LLD23.1.0 and native FFIClang23.1.3, no source/build pooling. These prototypes do not establish leadership or a language limitation.'
 (stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=m['source_fingerprint'],scope=scope),indent=2)+'\n');shutil.copy2(__file__,stage/'archive.py');target=dest/'raw'/(name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
 c=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source_fingerprint=m['source_fingerprint']);catalog.append(c);print(c,flush=True)
Path('/tmp/issue-10987-column-history-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
