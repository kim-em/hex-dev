from pathlib import Path
import hashlib,io,json,lzma,tarfile
s=Path('/home/kim/tmp/issue-10987');payload={}
for label in ['avx512-default','native-cc-option']:
 base=s/(label+'-production')
 for path in sorted(base.rglob('*')):
  if path.is_file() and 'binaries'not in path.relative_to(base).parts:payload[label+'/'+str(path.relative_to(base))]=path.read_bytes()
base=s/'native-cc-option-production'
for name in ['f4','f4-repeat']:
 meta=json.loads((base/name/'metadata.json').read_text());analysis=json.loads((base/name/'analysis.json').read_text());assert len(meta['samples'])==56 and analysis['complete_bases_equal']==28 and analysis['failed_processes']==analysis['timeouts']==0
 for case in {row['case']for row in meta['samples']}:
  for block in [0,1]:
   outputs=[json.loads((base/name/f'{case}-b{block}-{arm}.stdout').read_text())for arm in ['A','B']]
   for output in outputs:output.pop('candidateNanos')
   assert outputs[0]==outputs[1]
status=json.loads((base/'kernel-status.json').read_text());assert len(status['samples'])==72
for row in status['samples']:
 if not row['label'].startswith('matched/')or row['arm']!='A':continue
 points=[json.loads((base/'kernels'/(row['label'][:-1]+arm)/'result.json').read_text())['results'][0]['points'][0]for arm in ['A','B']];assert all(p['status']=='ok'for p in points)and points[0]['result_hash']==points[1]['result_hash']
payload['pack.py']=Path(__file__).read_bytes();digests={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())};payload['sha256.json']=(json.dumps(digests,indent=2)+'\n').encode();out=s/'f4-native-cc-option-4abe7f39fd7a.tar.xz'
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-native-cc-option/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(digests),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
