from pathlib import Path
import hashlib,json,os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'dense-state-production';old=state/'sampled-io-production'
common=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'final-products-production/medium-inputs/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/compute')]
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
for name,prior,candidate,baseline in [('enabled',base,'true','false'),('control',old,'false',None),('combined',old,'true',None)]:
 command=common+['--baseline',str(prior/'binaries/compute'),'--baseline-manifest',str(prior/'manifest.json'),'--hex-dense-pivots',candidate,'--output',str(base/name)]
 if baseline is not None:command+=['--baseline-dense-pivots',baseline]
 with (base/(name+'-runner.log')).open('w')as log:
  result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
(base/'measure.py').write_bytes(Path(__file__).read_bytes())
