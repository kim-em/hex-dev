/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/
import HexGroebner.Elimination
import HexGroebner.Fixtures

namespace Hex.Groebner.EliminationConformance

private def field : PrimeField :=
  ⟨7, Hex.Nat.isPrimeTrial_isPrime (by decide), by decide⟩

private def same (a b : Elimination.Result) : Bool := Id.run do
  if a.stats != b.stats then return false
  match a.result,b.result with
  | .error a,.error b => return a == b
  | .ok (a,ar),.ok (b,br) =>
    if a.reducerRank != b.reducerRank || a.trace != b.trace ||
        a.rows.size != b.rows.size || ar.size != br.size then return false
    for i in [:a.rows.size] do
      let x := a.rows[i]!
      let y := b.rows[i]!
      if x.row.columns != y.row.columns || x.row.coefficients != y.row.coefficients ||
          x.fromTarget != y.fromTarget || x.derivation != y.derivation ||
          x.multiplier != y.multiplier || x.sugar != y.sugar then return false
    for i in [:ar.size] do
      let x := ar[i]!
      let y := br[i]!
      if x.row.columns != y.row.columns || x.row.coefficients != y.row.coefficients ||
          x.derivation != y.derivation || x.sugar != y.sugar then return false
    return true
  | _,_ => return false

def basic : Bool := Id.run do
  let some r := SparseRow.ofEntries field 3 #[(0,2),(2,1)] | return false
  let some t := SparseRow.ofEntries field 3 #[(0,4),(1,1)] | return false
  for independent in [false,true] do
    let some expected := Elimination.attemptPortable field {} 3 #[r] #[t] #[2,3] independent
      | return false
    let some actual := Elimination.attempt field {} 3 #[r] #[t] #[2,3] independent
      | return false
    if !same actual expected then return false
    if !independent && actual.stats.work != 41 then return false
  return true

#guard basic

private def sameAttempt (a b : Option Elimination.Result) : Bool :=
  match a,b with
  | none,none => true
  | some a,some b => same a b
  | _,_ => false

private def sameRows (a b : Array SparseRow) : Bool :=
  a.size == b.size && (a.zip b).all fun (x,y) =>
    x.columns == y.columns && x.coefficients == y.coefficients

/-- Different nonces produce equal independent buffers, retaining a separate
copy against which borrowed-input preservation can be checked. -/
@[noinline] private def rows (field : PrimeField) (columns reducers targets seed : Nat) :
    Option (Array SparseRow × Array SparseRow × Array Nat) := Id.run do
  let salt := seed % 7
  let reducers := min reducers columns
  let mut all := #[]
  let mut sugars := #[]
  for i in [:reducers+targets] do
    let mut entries := #[]
    if (salt+i)%5 != 0 then
      for column in [:columns] do
        let keep := if i < reducers then
          column ≥ i && (column == i || (column+i+salt)%4 == 0)
        else (column+3*i+salt)%4 == 0
        if keep then
          entries := entries.push (column,
            ((salt+3*i+5*column)%(field.modulus.toNat-1)+1).toUInt64)
    let some row := SparseRow.ofEntries field columns entries | return none
    all := all.push row
    sugars := sugars.push ((i+salt)%11)
  return some (all.extract 0 reducers,all.extract reducers all.size,sugars)

private def check (field : PrimeField) (limits : MatrixLimits) (columns nr nt seed : Nat)
    (independent : Bool) : Bool := Id.run do
  let some (er,et,es) := rows field columns nr nt (seed+7) | return false
  let expected := Elimination.attemptPortable field limits columns er et es independent
  let some (ar,actualTargets,actualSugars) := rows field columns nr nt (seed+14) | return false
  let actual := Elimination.attempt field limits columns ar actualTargets actualSugars independent
  return sameAttempt actual expected && sameRows ar er && sameRows actualTargets et

private def denseChecks (field : PrimeField) : Bool := Id.run do
  let columns := 4096
  let coefficient := if field.modulus == 2 then 1 else 2
  let some reducer := SparseRow.ofEntries field columns
    ((Array.range columns).map fun i => (i,1)) | return false
  let some target := SparseRow.ofEntries field columns
    ((Array.range columns).map fun i => (i,coefficient)) | return false
  for reducers in [#[],#[reducer]] do
    for independent in [false,true] do
      let some expected := Elimination.attemptPortable field {} columns reducers #[target] #[] independent
        | return false
      let some actual := Elimination.attempt field {} columns reducers #[target] #[] independent
        | return false
      if !same actual expected then return false
  return true

/-- Unsupported dimensions, noncanonical rows, arbitrary Nat allowances and
all resource limits retain the reference's rejection or completed outcome. -/
def boundaryChecks : Bool := Id.run do
  let some r := SparseRow.ofEntries field 3 #[(0,2),(2,1)] | return false
  let some t := SparseRow.ofEntries field 3 #[(0,4),(1,1)] | return false
  let malformed : Array SparseRow := #[
    { r with columns := r.columns.push 0 },
    { r with coefficients := r.coefficients.push 0 },
    { r with coefficients := Packed.set field.width r.coefficients 0 0 },
    { r with columns := Packed.set .u32 r.columns 0 3 },
    { r with columns := Packed.set .u32 r.columns 1 0 }]
  for independent in [false,true] do
    for row in malformed do
      for (reducers,targets) in [(#[row],#[t]),(#[r],#[row])] do
        let expected := Elimination.attemptPortable field {} 3 reducers targets #[] independent
        let actual := Elimination.attempt field {} 3 reducers targets #[] independent
        if !sameAttempt actual expected then return false
    for columns in [0,2,3,4096,4097,2^90] do
      for reducers in [#[r],#[r,r]] do
        for sugars in [#[],#[2,3],#[2],#[2,USize.size/2-1],#[2,USize.size/2],#[2,2^90]] do
          let expected := Elimination.attemptPortable field {} columns reducers #[t] sugars independent
          let actual := Elimination.attempt field {} columns reducers #[t] sugars independent
          if !sameAttempt actual expected then return false
    for n in [0,1,2,3,4,5,16,32,64,1000000,USize.size/2-1,USize.size/2,2^90] do
      for limits in ([{ columns := n },{ rows := n },{ inputEntries := n },
          { outputEntries := n },{ packedBytes := n },{ work := n },{ traceNodes := n }] :
          List MatrixLimits) do
        let expected := Elimination.attemptPortable field limits 3 #[r] #[t] #[] independent
        let actual := Elimination.attempt field limits 3 #[r] #[t] #[] independent
        if !sameAttempt actual expected then return false
  return true

#guard boundaryChecks

@[noinline] private def thresholdRows (columns nr entries nonce : Nat) :
    Option (Array SparseRow × Array SparseRow) := Id.run do
  let mut reducers := #[]
  if nr != 0 then
    let some row := SparseRow.ofEntries field columns #[(0,(nonce%7+1).toUInt64)] | return none
    reducers := #[row]
  let count := entries-nr
  let mut targets := #[]
  for i in [:64] do
    let length := count/64 + if i < count%64 then 1 else 0
    let values := (Array.range length).map fun j => (j+nr,(nonce%7+1).toUInt64)
    let some row := SparseRow.ofEntries field columns values | return none
    targets := targets.push row
  return some (reducers,targets)

/-- Both sides of the hand-copied work-quantum threshold, with valid sparse
rows and independently allocated expected inputs. -/
def thresholdChecks : Bool := Id.run do
  if USize.size != 2^64 then return true
  for (columns,nr,entries,bound) in [(205,0,2425,2^20),(222,1,1318,2^20+1)] do
    let some (er,et) := thresholdRows columns nr entries 7 | return false
    let actualEntries := (er ++ et).foldl (fun n row => n + row.size) 0
    let actualBound := (nr+64)*65+2*actualEntries+columns*(field.width.bytes+4)+
      64*(actualEntries+(64+3)*columns+64)+columns
    if actualEntries != entries || actualBound != bound then return false
    if Elimination.fits field {} columns er et #[] != (bound == 2^20) then return false
    for independent in [false,true] do
      let expected := Elimination.attemptPortable field {} columns er et #[] independent
      let some (ar,actualTargets) := thresholdRows columns nr entries 14 | return false
      let actual := Elimination.attempt field {} columns ar actualTargets #[] independent
      if (bound == 2^20 && actual.isNone) || !sameAttempt actual expected ||
          !sameRows ar er || !sameRows actualTargets et then return false
  return true

#guard thresholdChecks

/-- The reducer and target arrays are the same borrowed object. Independent
reference buffers detect mutation, and the native call must accept. -/
def sharedChecks (seed : Nat) : Bool := Id.run do
  if USize.size != 2^64 then return true
  let nonce := seed + if seed%7 == 0 || seed%7 == 5 then 1 else 0
  for independent in [false,true] do
    let some (er,_,_) := rows field 3 1 0 (nonce+7) | return false
    let some expected := Elimination.attemptPortable field {} 3 er er #[] independent
      | return false
    let some (ar,_,_) := rows field 3 1 0 nonce | return false
    let some actual := Elimination.attempt field {} 3 ar ar #[] independent | return false
    if !same actual expected || !sameRows ar er then return false
  return true

#guard sharedChecks 0

/-- Check both sides of every separately copied matrix-size cap. -/
def sizeChecks (seed : Nat) : Bool := Id.run do
  for (columns,nr,nt) in [(3,0,64),(3,0,65),(1025,1024,1),(1025,1025,1)] do
    let some (er,et,es) := rows field columns nr nt (seed+7) | return false
    let some (ar,actualTargets,actualSugars) := rows field columns nr nt seed | return false
    let expected := Elimination.attemptPortable field {} columns er et es false
    let actual := Elimination.attempt field {} columns ar actualTargets actualSugars false
    if !sameAttempt actual expected || !sameRows ar er || !sameRows actualTargets et then return false
    if USize.size == 2^64 && ((nr == 1024 || nt == 64) && actual.isNone) then return false
    if (nr == 1025 || nt == 65) && actual.isSome then return false
  return true

#guard sizeChecks 0

@[noinline] private def binaryLargeRows (nonce : Nat) : Option (Array SparseRow × Array SparseRow) := do
  let field : PrimeField := ⟨2,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  let salt := nonce%7
  let reducers ← (Array.range 2048).mapM fun i =>
    SparseRow.ofEntries field 8192 #[(i,1),(4096+(17*i+salt)%4096,1)]
  let targets ← (Array.range 128).mapM fun i =>
    SparseRow.ofEntries field 8192 #[(i,1),(2048+i,1),(4096+(17*i+salt)%4096,1)]
  return (reducers,targets)

/-- Nonempty rows beyond all old caps, sparse wide updates, high leading
columns, and both sides of the physical bound with nonzero input entries. -/
def binaryLargeChecks (seed : Nat) : Bool := Id.run do
  if USize.size != 2^64 then return true
  let field : PrimeField := ⟨2,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  let limits : MatrixLimits := { binaryPivots := true }
  for independent in [false,true] do
    let some (er,et) := binaryLargeRows (seed+7) | return false
    let some (ar,actualTargets) := binaryLargeRows seed | return false
    let some expected := Elimination.attemptPortable field limits 8192 er et #[] independent | return false
    let some actual := Elimination.attempt field limits 8192 ar actualTargets #[] independent | return false
    if !same actual expected || !sameRows ar er || !sameRows actualTargets et then return false
  let some high := SparseRow.ofEntries field 8192 #[(7000,1),(8191,1)] | return false
  if (Elimination.attempt field limits 8192 #[high,high] #[] #[] false).isSome then return false
  if (Elimination.attempt field {} 8192 #[high] #[] #[] false).isSome ||
      (Elimination.attemptPortable field {} 8192 #[high] #[] #[] false).isSome then return false
  let other : PrimeField := ⟨3,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  if (Elimination.attempt other limits 8192 #[] #[] #[] false).isSome ||
      (Elimination.attemptPortable other limits 8192 #[] #[] #[] false).isSome then return false
  if !sameAttempt (Elimination.attempt field limits 0 #[] #[{}] #[] true)
      (Elimination.attemptPortable field limits 0 #[] #[{}] #[] true) then return false
  if Elimination.binaryBound 16384 16321 62 14976 != 2^28 ||
      Elimination.binaryBound 16384 16321 62 14977 != 2^28+3 then return false
  for entries in [14976,14977] do
    let some row := SparseRow.ofEntries field 16384 ((Array.range entries).map (·,(1:UInt64))) | return false
    let reducers := (Array.replicate 16321 ({} : SparseRow)).set! 0 row
    let targets := Array.replicate 62 ({} : SparseRow)
    let expected := Elimination.attemptPortable field limits 16384 reducers targets #[] false
    let actual := Elimination.attempt field limits 16384 reducers targets #[] false
    if expected.isSome != (entries == 14976) || !sameAttempt actual expected then return false
  return true

@[noinline] private def binaryWorkRows (nonce : Nat) : Option (Array SparseRow) :=
  let field : PrimeField := ⟨2,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  let tail := 1024+nonce%7
  (Array.range 1024).mapM fun i =>
    SparseRow.ofEntries field 2055 (#[ (i,(1:UInt64)) ] ++
      (Array.range 1024).map fun j => (tail+j,(1:UInt64)))

/-- Expanded shape caps and adjacent sides of the physical-work guard, plus
malformed rows and arbitrary natural-number limits in the packed F2 route. -/
def binaryBounds : Bool := Id.run do
  if USize.size != 2^64 then return true
  let field : PrimeField := ⟨2,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  let limits : MatrixLimits := { binaryPivots := true }
  let empty : SparseRow := {}
  let reducers := Array.replicate 16384 empty
  let targets := Array.replicate 61 empty
  if Elimination.binaryBound 16384 16384 61 0 > 2^28 ||
      Elimination.binaryBound 16384 16384 62 0 <= 2^28 then return false
  let some expected := Elimination.attemptPortable field limits 16384 reducers targets #[] false | return false
  let some actual := Elimination.attempt field limits 16384 reducers targets #[] false | return false
  if !same actual expected then return false
  for (columns,rs,ts) in [(16385,#[],#[]),(1,Array.replicate 16385 empty,#[]),
      (1,#[],Array.replicate 1025 empty),(16384,reducers,targets.push empty),
      (16384,reducers,Array.replicate 1024 empty)] do
    if (Elimination.attempt field limits columns rs ts #[] false).isSome ||
        (Elimination.attemptPortable field limits columns rs ts #[] false).isSome then return false
  let some row := SparseRow.ofEntries field 3 #[(0,1),(2,1)] | return false
  let malformed : Array SparseRow := #[
    { row with columns := row.columns.push 0 },
    { row with coefficients := row.coefficients.push 0 },
    { row with coefficients := Packed.set .u8 row.coefficients 0 0 },
    { row with coefficients := Packed.set .u8 row.coefficients 0 2 },
    { row with columns := Packed.set .u32 row.columns 1 3 },
    { row with columns := Packed.set .u32 row.columns 1 0 }]
  for bad in malformed do
    for (rs,ts) in [(#[bad],#[row]),(#[row],#[bad])] do
      if !sameAttempt (Elimination.attempt field limits 3 rs ts #[] false)
          (Elimination.attemptPortable field limits 3 rs ts #[] false) then return false
  for amount in [0,1,15,16,31,32,63,64,2^90] do
    for cap in ([{ limits with packedBytes := amount },{ limits with work := amount },
        { limits with inputEntries := amount },{ limits with outputEntries := amount }] : List MatrixLimits) do
      if !sameAttempt (Elimination.attempt field cap 3 #[row] #[row] #[] false)
          (Elimination.attemptPortable field cap 3 #[row] #[row] #[] false) then return false
  return true

/-- A successful F2 frame with actual charged work above the old quantum and
an aliased target reduced by a packed known pivot. Runs in compiled conformance. -/
def binaryWorkChecks (seed : Nat) : Bool := Id.run do
  if USize.size != 2^64 then return true
  if !binaryBounds then return false
  let field : PrimeField := ⟨2,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  let some er := binaryWorkRows (seed+7) | return false
  let some ar := binaryWorkRows seed | return false
  let limits : MatrixLimits := { binaryPivots := true }
  let some expected := Elimination.attemptPortable field limits 2055 er #[er[1023]!] #[] false | return false
  let some actual := Elimination.attempt field limits 2055 ar #[ar[1023]!] #[] false | return false
  return expected.stats.work > 2^20 && same actual expected && sameRows ar er

@[noinline] private def binaryRows (columns nonce : Nat) :
    Option (Array SparseRow × Array SparseRow) := do
  let field : PrimeField := ⟨2,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  let value : UInt64 := 1
  let salt := nonce%7
  let support := Array.range columns
  let r0 ← SparseRow.ofEntries field columns ((support.filter (fun i => (i+salt)%2 == 0)).map (·,value))
  let r1 ← SparseRow.ofEntries field columns ((support.filter (fun i => (i+salt)%2 == 1)).map (·,value))
  let both ← SparseRow.ofEntries field columns (support.map (·,value))
  let tail ← SparseRow.ofEntries field columns ((support.filter (fun i => (i+salt)%3 == 2)).map (·,value))
  return (#[r0,r1],#[both,tail,tail])

/-- Byte/word boundaries, zero rows, nonzero target installation, shared inputs,
independent targets and near-success parent budget refusals over ordinary F2. -/
def binaryChecks (seed : Nat) : Bool := Id.run do
  if USize.size != 2^64 then return true
  let field : PrimeField := ⟨2,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  for columns in [1,2,7,8,9,63,64,65,127,128,129,257,4096] do
    for independent in [false,true] do
      let some (er,et) := binaryRows columns (seed+7) | return false
      let some expected := Elimination.attemptPortable field { binaryPivots := true } columns er et #[1,2,3,4,5] independent
        | return false
      let some (ar,actualTargets) := binaryRows columns seed | return false
      let some actual := Elimination.attempt field { binaryPivots := true } columns ar actualTargets #[1,2,3,4,5] independent
        | return false
      if !same actual expected || !sameRows ar er || !sameRows actualTargets et then return false
      let scratch := Elimination.binaryBytes columns (er.size+et.size)
      let tight : MatrixLimits := { binaryPivots := true,packedBytes := expected.stats.packedBytes+scratch }
      if !(Elimination.attempt field tight columns ar actualTargets #[1,2,3,4,5] independent).isSome then return false
      for limits in ([{ binaryPivots := true,work := expected.stats.work-1 },
          { binaryPivots := true,packedBytes := expected.stats.packedBytes+scratch-1 },
          { binaryPivots := true,outputEntries := expected.stats.outputEntries-1 }] : List MatrixLimits) do
        if !sameAttempt (Elimination.attempt field limits columns ar actualTargets #[1,2,3,4,5] independent)
            (Elimination.attemptPortable field limits columns er et #[1,2,3,4,5] independent) then return false
  return true

#guard binaryChecks 0

/-- Complete F4 forwards the policy into real native pair matrices. Dynamic
input degrees prevent compile-time reuse of this ownership/counter window. -/
def binaryFresh (seed : Nat) : Bool := Id.run do
  let field : PrimeField := ⟨2,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  let context : Context := ⟨field,2,.grevlex⟩
  let generators : Array RawPolynomial := #[
    #[⟨#[2+seed%7,0],1⟩,⟨#[0,1],1⟩],#[⟨#[1,1],1⟩,⟨#[0,0],1⟩]]
  let .candidate actual stats := computeWith context { binaryPivots := true } generators | return false
  let .candidate expected reference := computeWith context
    { binaryPivots := true,nativeRows := false,nativeMonomials := false } generators | return false
  return actual.polynomials == expected.polynomials && stats == reference

def runtimeChecks (seed : Nat) : Bool := Id.run do
  for field in Fixtures.fields do
    for columns in [0,1,3,9,65,257] do
      for (nr,nt) in [(0,0),(3,0),(0,3),(3,1),(3,3),(3,8),(3,9),(3,32),(3,64)] do
        for independent in [false,true] do
          let some (er,et,es) := rows field columns nr nt (seed+7) | return false
          let expected := Elimination.attemptPortable field {} columns er et es independent
          let some (actualReducers,actualTargets,actualSugars) := rows field columns nr nt seed | return false
          let actual := Elimination.attempt field {} columns actualReducers actualTargets actualSugars independent
          if !sameAttempt actual expected || !sameRows actualReducers er || !sameRows actualTargets et then return false
    if !denseChecks field then return false
    let some (rs,ts,sugars) := rows field 9 3 3 seed | return false
    for independent in [false,true] do
      let expected := Elimination.reference field {} 9 rs ts sugars independent
      for work in [:expected.stats.work+1] do
        let limits : MatrixLimits := { work }
        if !check field limits 9 3 3 (seed+7*work) independent then return false
      for entries in [:expected.stats.outputEntries+1] do
        let limits : MatrixLimits := { outputEntries := entries }
        if !check field limits 9 3 3 (seed+7*entries) independent then return false
      for bytes in [:expected.stats.packedBytes+1] do
        let limits : MatrixLimits := { packedBytes := bytes }
        if !check field limits 9 3 3 (seed+7*bytes) independent then return false
  return true

end Hex.Groebner.EliminationConformance
