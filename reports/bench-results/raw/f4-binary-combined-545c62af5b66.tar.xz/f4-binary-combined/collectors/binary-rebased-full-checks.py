from pathlib import Path
import os,subprocess,json,sys,time
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');prefix=state/'binary-rebased-full';results=[];sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import source_identity
identity=source_identity()
def run(name,command,env=None):
 assert source_identity()==identity
 log=Path(str(prefix)+'-'+name+'.log');start=time.monotonic()
 with log.open('w')as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,env=env)
 assert source_identity()==identity
 results.append(dict(name=name,command=command,exit_code=r.returncode,seconds=time.monotonic()-start,log=str(log),**identity));Path(str(prefix)+'-status.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
modules=['HexGroebner.'+p.stem for p in sorted((root/'conformance/HexGroebner').glob('*.lean'))if not p.stem.startswith('Emit')and p.stem!='EliminationChecks']
run('build',['lake','build','HexGroebner','HexGroebnerTheory',*modules,'hexgroebner_compute','hexgroebner_compute_full','hexgroebner_sample','hexgroebner_sample_full','hexgroebner_sampling_checks','hexgroebner_emit_f4','hexgroebner_emit_division','hexgroebner_emit_fixtures','hexgroebner_bench','HexGroebner.EliminationDispatchProof'])
run('oracles',['bash','scripts/ci/run_oracles.sh'],dict(os.environ,HEX_LIBRARY_FILTER='HexGroebner',PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH']))
run('driver',['python3','scripts/ci/check_groebner_driver.py'])
run('bench',['bash','scripts/ci/check_bench_verify_budget.sh','HexGroebner=hexgroebner_bench'],dict(os.environ,HEX_LIBRARY_FILTER='HexGroebner'))
for name,script in [('dag','scripts/check_dag.py'),('phase4','scripts/check_phase4.py'),('manifest','scripts/release/check_released_manifest.py'),('headers','scripts/check_copyright_headers.py'),('lines','scripts/check_file_line_counts.py')]:run(name,[str(state/'oracles/bin/python'),script])
