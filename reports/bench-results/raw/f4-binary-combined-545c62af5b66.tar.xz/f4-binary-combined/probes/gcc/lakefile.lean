import Lake
open Lake DSL System
package GroebnerMatrixChecks
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit"

def probeO (pkg : Package) (name : String) (flags : Array String) : FetchM (Job FilePath) := do
  let source ← inputTextFile (pkg.dir / "probe.c")
  let scan ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/matrix_scan.c")
  let simd ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/matrix_simd.h")
  let wide ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/matrix_avx512.h")
  let body ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/matrix_scan_impl.h")
  let row ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/row_update.c")
  let trie ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/trie_lookup.h")
  let hit ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/monomial_hit.c")
  let runtimeHeader ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/matrix_runtime.h")
  let whole ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/matrix_eliminate.c")
  let continuation ← inputTextFile (FilePath.mk "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sampler-hybrid-audit/HexGroebner/ffi/matrix_state.c")
  let inputs := ((source.zipWith (fun s _ => s) scan).zipWith (fun s _ => s) simd).zipWith (fun s _ => s) body
  let inputs := inputs.zipWith (fun s _ => s) wide
  let inputs := (inputs.zipWith (fun s _ => s) row).zipWith (fun s _ => s) trie
  let inputs := inputs.zipWith (fun s _ => s) hit
  let inputs := (inputs.zipWith (fun s _ => s) whole).zipWith (fun s _ => s) continuation
  let inputs := inputs.zipWith (fun s _ => s) runtimeHeader
  buildO (pkg.dir / defaultBuildDir / (name ++ ".o")) inputs
    #["-isystem", (← getLeanIncludeDir).toString] flags
    (compiler := FilePath.mk "/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/gcc")
    (extraDepTrace := do addPureTrace "/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/gcc" "compiler"; pure BuildTrace.nil)

target probeNative pkg : FilePath := probeO pkg "Native" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_ENABLE_AVX512", "-fsanitize=address,undefined", "-fno-sanitize-recover=undefined", "-fno-omit-frame-pointer"]
lean_exe checkNative where
  root := `CheckNative
  moreLinkObjs := #[probeNative]
  moreLinkArgs := #["-Wl,--wrap=lean_array_push", "-Wl,--wrap=lean_hex_groebner_subtract_row", "-Wl,--wrap=lean_hex_monomial_products_attempt", "-Wl,--wrap=lean_hex_matrix_validate", "-Wl,--wrap=lean_hex_matrix_zeros", "-Wl,--wrap=lean_hex_matrix_advance", "-Wl,--wrap=lean_hex_groebner_remap_index", "-Wl,--wrap=lean_hex_groebner_append_zeros", "-Wl,--wrap=lean_hex_groebner_remap_columns", "-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather", "-Wl,--wrap=lean_hex_prepare_dense", "-Wl,--wrap=lean_hex_dense_transition", "-Wl,--wrap=lean_hex_groebner_equal_bytes", "-Wl,--wrap=lean_hex_groebner_equal_products", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_groebner_combine_owned", "-Wl,--wrap=lean_hex_groebner_search_monomial", "-Wl,--wrap=lean_hex_groebner_compare_monomials", "-Wl,--wrap=lean_hex_groebner_lookup_trie", "-Wl,--wrap=lean_hex_groebner_validate_trie", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libasan.so", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libubsan.so"]

target probeAVX2 pkg : FilePath := probeO pkg "AVX2" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_ENABLE_AVX512", "-fsanitize=address,undefined", "-fno-sanitize-recover=undefined", "-fno-omit-frame-pointer", "-DHEX_GROEBNER_NO_AVX512"]
lean_exe checkAVX2 where
  root := `CheckAVX2
  moreLinkObjs := #[probeAVX2]
  moreLinkArgs := #["-Wl,--wrap=lean_array_push", "-Wl,--wrap=lean_hex_groebner_subtract_row", "-Wl,--wrap=lean_hex_monomial_products_attempt", "-Wl,--wrap=lean_hex_matrix_validate", "-Wl,--wrap=lean_hex_matrix_zeros", "-Wl,--wrap=lean_hex_matrix_advance", "-Wl,--wrap=lean_hex_groebner_remap_index", "-Wl,--wrap=lean_hex_groebner_append_zeros", "-Wl,--wrap=lean_hex_groebner_remap_columns", "-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather", "-Wl,--wrap=lean_hex_prepare_dense", "-Wl,--wrap=lean_hex_dense_transition", "-Wl,--wrap=lean_hex_groebner_equal_bytes", "-Wl,--wrap=lean_hex_groebner_equal_products", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_groebner_combine_owned", "-Wl,--wrap=lean_hex_groebner_search_monomial", "-Wl,--wrap=lean_hex_groebner_compare_monomials", "-Wl,--wrap=lean_hex_groebner_lookup_trie", "-Wl,--wrap=lean_hex_groebner_validate_trie", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libasan.so", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libubsan.so"]

target probeAVX2Remainder pkg : FilePath := probeO pkg "AVX2Remainder" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_ENABLE_AVX512", "-fsanitize=address,undefined", "-fno-sanitize-recover=undefined", "-fno-omit-frame-pointer", "-DHEX_GROEBNER_NO_AVX512", "-DHEX_GROEBNER_NO_UINT128"]
lean_exe checkAVX2Remainder where
  root := `CheckAVX2Remainder
  moreLinkObjs := #[probeAVX2Remainder]
  moreLinkArgs := #["-Wl,--wrap=lean_array_push", "-Wl,--wrap=lean_hex_groebner_subtract_row", "-Wl,--wrap=lean_hex_monomial_products_attempt", "-Wl,--wrap=lean_hex_matrix_validate", "-Wl,--wrap=lean_hex_matrix_zeros", "-Wl,--wrap=lean_hex_matrix_advance", "-Wl,--wrap=lean_hex_groebner_remap_index", "-Wl,--wrap=lean_hex_groebner_append_zeros", "-Wl,--wrap=lean_hex_groebner_remap_columns", "-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather", "-Wl,--wrap=lean_hex_prepare_dense", "-Wl,--wrap=lean_hex_dense_transition", "-Wl,--wrap=lean_hex_groebner_equal_bytes", "-Wl,--wrap=lean_hex_groebner_equal_products", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_groebner_combine_owned", "-Wl,--wrap=lean_hex_groebner_search_monomial", "-Wl,--wrap=lean_hex_groebner_compare_monomials", "-Wl,--wrap=lean_hex_groebner_lookup_trie", "-Wl,--wrap=lean_hex_groebner_validate_trie", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libasan.so", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libubsan.so"]

target probeScalar pkg : FilePath := probeO pkg "Scalar" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_ENABLE_AVX512", "-fsanitize=address,undefined", "-fno-sanitize-recover=undefined", "-fno-omit-frame-pointer", "-DHEX_GROEBNER_NO_AVX2"]
lean_exe checkScalar where
  root := `CheckScalar
  moreLinkObjs := #[probeScalar]
  moreLinkArgs := #["-Wl,--wrap=lean_array_push", "-Wl,--wrap=lean_hex_groebner_subtract_row", "-Wl,--wrap=lean_hex_monomial_products_attempt", "-Wl,--wrap=lean_hex_matrix_validate", "-Wl,--wrap=lean_hex_matrix_zeros", "-Wl,--wrap=lean_hex_matrix_advance", "-Wl,--wrap=lean_hex_groebner_remap_index", "-Wl,--wrap=lean_hex_groebner_append_zeros", "-Wl,--wrap=lean_hex_groebner_remap_columns", "-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather", "-Wl,--wrap=lean_hex_prepare_dense", "-Wl,--wrap=lean_hex_dense_transition", "-Wl,--wrap=lean_hex_groebner_equal_bytes", "-Wl,--wrap=lean_hex_groebner_equal_products", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_groebner_combine_owned", "-Wl,--wrap=lean_hex_groebner_search_monomial", "-Wl,--wrap=lean_hex_groebner_compare_monomials", "-Wl,--wrap=lean_hex_groebner_lookup_trie", "-Wl,--wrap=lean_hex_groebner_validate_trie", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libasan.so", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libubsan.so"]

target probeRemainder pkg : FilePath := probeO pkg "Remainder" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_ENABLE_AVX512", "-fsanitize=address,undefined", "-fno-sanitize-recover=undefined", "-fno-omit-frame-pointer", "-DHEX_GROEBNER_NO_UINT128"]
lean_exe checkRemainder where
  root := `CheckRemainder
  moreLinkObjs := #[probeRemainder]
  moreLinkArgs := #["-Wl,--wrap=lean_array_push", "-Wl,--wrap=lean_hex_groebner_subtract_row", "-Wl,--wrap=lean_hex_monomial_products_attempt", "-Wl,--wrap=lean_hex_matrix_validate", "-Wl,--wrap=lean_hex_matrix_zeros", "-Wl,--wrap=lean_hex_matrix_advance", "-Wl,--wrap=lean_hex_groebner_remap_index", "-Wl,--wrap=lean_hex_groebner_append_zeros", "-Wl,--wrap=lean_hex_groebner_remap_columns", "-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather", "-Wl,--wrap=lean_hex_prepare_dense", "-Wl,--wrap=lean_hex_dense_transition", "-Wl,--wrap=lean_hex_groebner_equal_bytes", "-Wl,--wrap=lean_hex_groebner_equal_products", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_groebner_combine_owned", "-Wl,--wrap=lean_hex_groebner_search_monomial", "-Wl,--wrap=lean_hex_groebner_compare_monomials", "-Wl,--wrap=lean_hex_groebner_lookup_trie", "-Wl,--wrap=lean_hex_groebner_validate_trie", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libasan.so", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libubsan.so"]

target probeScalarRemainder pkg : FilePath := probeO pkg "ScalarRemainder" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_ENABLE_AVX512", "-fsanitize=address,undefined", "-fno-sanitize-recover=undefined", "-fno-omit-frame-pointer", "-DHEX_GROEBNER_NO_AVX2", "-DHEX_GROEBNER_NO_UINT128"]
lean_exe checkScalarRemainder where
  root := `CheckScalarRemainder
  moreLinkObjs := #[probeScalarRemainder]
  moreLinkArgs := #["-Wl,--wrap=lean_array_push", "-Wl,--wrap=lean_hex_groebner_subtract_row", "-Wl,--wrap=lean_hex_monomial_products_attempt", "-Wl,--wrap=lean_hex_matrix_validate", "-Wl,--wrap=lean_hex_matrix_zeros", "-Wl,--wrap=lean_hex_matrix_advance", "-Wl,--wrap=lean_hex_groebner_remap_index", "-Wl,--wrap=lean_hex_groebner_append_zeros", "-Wl,--wrap=lean_hex_groebner_remap_columns", "-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather", "-Wl,--wrap=lean_hex_prepare_dense", "-Wl,--wrap=lean_hex_dense_transition", "-Wl,--wrap=lean_hex_groebner_equal_bytes", "-Wl,--wrap=lean_hex_groebner_equal_products", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_groebner_combine_owned", "-Wl,--wrap=lean_hex_groebner_search_monomial", "-Wl,--wrap=lean_hex_groebner_compare_monomials", "-Wl,--wrap=lean_hex_groebner_lookup_trie", "-Wl,--wrap=lean_hex_groebner_validate_trie", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libasan.so", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libubsan.so"]

lean_exe usage where
  root := `Usage
  moreLinkObjs := #[probeNative]
  moreLinkArgs := #["-Wl,--wrap=lean_array_push", "-Wl,--wrap=lean_hex_groebner_subtract_row", "-Wl,--wrap=lean_hex_monomial_products_attempt", "-Wl,--wrap=lean_hex_matrix_validate", "-Wl,--wrap=lean_hex_matrix_zeros", "-Wl,--wrap=lean_hex_matrix_advance", "-Wl,--wrap=lean_hex_groebner_remap_index", "-Wl,--wrap=lean_hex_groebner_append_zeros", "-Wl,--wrap=lean_hex_groebner_remap_columns", "-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather", "-Wl,--wrap=lean_hex_prepare_dense", "-Wl,--wrap=lean_hex_dense_transition", "-Wl,--wrap=lean_hex_groebner_equal_bytes", "-Wl,--wrap=lean_hex_groebner_equal_products", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_groebner_combine_owned", "-Wl,--wrap=lean_hex_groebner_search_monomial", "-Wl,--wrap=lean_hex_groebner_compare_monomials", "-Wl,--wrap=lean_hex_groebner_lookup_trie", "-Wl,--wrap=lean_hex_groebner_validate_trie", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libasan.so", "/nix/store/j7qx4s4mr17j1wqgvqdzj33lmrnzb387-gcc-16.2.0-lib/lib/libubsan.so"]
