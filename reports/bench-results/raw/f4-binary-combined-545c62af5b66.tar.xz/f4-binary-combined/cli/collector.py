from pathlib import Path
import json,subprocess,hashlib,sys
s=Path('/home/kim/tmp/issue-10987');base=s/'binary-rebased-matched-production';out=s/'binary-rebased-cli';out.mkdir(exist_ok=False);rows=[]
for p in [2,32003]:
 inp=out/f'p{p}.json';inp.write_text(json.dumps(dict(p=p,variables=2,order='grevlex',generators=[[[[2,0],1],[[0,1],1]],[[[1,1],1],[[0,0],1]]]))+'\n')
 for driver in ['compute','compute-reference']:
  baseline=None
  for label,flags,wanted in [('default',[],False),('false',['--binary-pivots','false'],False),('true',['--binary-pivots','true'],True),('duplicate',['--binary-pivots','true','--binary-pivots','false'],False)]:
   cmd=[str(base/'binaries'/driver),*flags,str(inp)];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,(cmd,r.stderr);value=json.loads(r.stdout);assert value['binaryPivots']==wanted
   values=(value['basis'],value['statistics']);baseline=baseline or values;assert baseline==values
   prefix=f'{driver}-p{p}-{label}';(out/(prefix+'.stdout')).write_text(r.stdout);(out/(prefix+'.stderr')).write_text(r.stderr);rows.append(dict(command=cmd,exit_code=0,binary_sha256=hashlib.sha256((base/'binaries'/driver).read_bytes()).hexdigest(),basis_and_statistics_equal=True,requested_policy=wanted))
for driver in ['compute','compute-reference']:
 for flag in ['nope','-1']:
  cmd=[str(base/'binaries'/driver),'--binary-pivots',flag,str(out/'p2.json')];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==2
  prefix=f'{driver}-invalid-{flag}';(out/(prefix+'.stdout')).write_text(r.stdout);(out/(prefix+'.stderr')).write_text(r.stderr);rows.append(dict(command=cmd,exit_code=2,invalid_rejected=True))
(out/'status.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'collector.py').write_bytes(Path(__file__).read_bytes());print(len(rows),'CLI policy checks passed')
