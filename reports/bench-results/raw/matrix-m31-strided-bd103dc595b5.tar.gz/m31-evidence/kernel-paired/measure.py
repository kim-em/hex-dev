from pathlib import Path
import json,os,subprocess,hashlib,time,sys
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-m31');state=Path('/home/kim/tmp/issue-10987');bases={'A':state/'review-production','B':state/'m31-production'}
for b in bases.values():
 while not(b/'bench-binaries/builds.json').exists():time.sleep(10)
binaries={a:b/'bench-binaries/frame'for a,b in bases.items()};builds={a:json.loads((b/'bench-binaries/builds.json').read_text())for a,b in bases.items()}
for a,b in binaries.items():assert hashlib.sha256(b.read_bytes()).hexdigest()==builds[a]['binary_sha256']
sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
out=state/'m31-production/kernel-paired';out.mkdir(exist_ok=False);cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[]
try:
 for name in['cauchy31','cauchy31Strided']:
  points={a:[]for a in'AB'}
  for block,order in enumerate(['AB','BA']):
   for arm in order:
    prefix=f'{name}-block{block}-{arm}';command=[str(binaries[arm]),'run','Hex.Groebner.Bench.'+name,'--outer-trials','1','--export-file',str(out/(prefix+'.json'))]
    with(out/(prefix+'.log')).open('w')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
    runs.append(dict(name=name,block=block,arm=arm,command=command,returncode=r.returncode));assert r.returncode in[0,2];v=json.loads((out/(prefix+'.json')).read_text())['results'][0];assert len(v['points'])==4 and all(x['status']=='ok'for x in v['points']);points[arm]+=v['points'];print(prefix,v['verdict'],flush=True)
  for n in[64,128,256,512]:assert len({p['result_hash']for ps in points.values()for p in ps if p['param']==n})==1
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),builds=builds,runs=runs,scope='First matched AB/BA whole-sweep Cauchy31 contiguous and strided comparisons,4sizes64/128/256/512,32completedpoints. A folding only contiguous products; B folding both contiguous and strided products. Complete decoded output hashes agree. Prepared matrices excluded, validation/allocation/elimination/fulloutputconsumption timed. Automatically leased CPU, all samples/RSS/floors/hostcontext retained, no filtering/no unchanged rerun. Separate from fullF4 campaigns. Not certification/nativeverification/kernelchecking timings.'),indent=2)+'\n');lease.close()
(out/'measure.py').write_bytes(Path(__file__).read_bytes())
