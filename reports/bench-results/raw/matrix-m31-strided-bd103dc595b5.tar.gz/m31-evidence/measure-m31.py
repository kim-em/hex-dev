from pathlib import Path
import json,subprocess,os,time,math,statistics,hashlib
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-m31');state=Path('/home/kim/tmp/issue-10987');base=state/'m31-production'
while not(base/'manifest.json').is_file():time.sleep(10)
baseline=state/'review-production';assert (baseline/'manifest.json').is_file();results={}
for suite in['small','medium']:
 plan=state/'admission-counts'/suite
 # Recover the exact suite plan from the retained measurement capsule.
 import tarfile
 with tarfile.open(root/'reports/bench-results/raw/matrix-primitives-portable-16c437c35eac.tar.gz')as tar:
  member=next(x for x in tar.getmembers()if x.name.endswith('/before-after-'+suite+'/inputs/'+('diagnostic-suite.json'if suite=='small'else'suite.json')))
  folder=base/(suite+'-inputs');folder.mkdir(exist_ok=True)
  for item in tar.getmembers():
   if '/before-after-'+suite+'/inputs/' in item.name and item.isfile() and item.name.endswith(('.json','.ms')):
    (folder/Path(item.name).name).write_bytes(tar.extractfile(item).read())
  suite_file=folder/Path(member.name).name
 command=['python3','scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(suite_file),'--output',str(base/('before-after-'+suite)),'--hex',str(base/'binaries/compute'),'--baseline',str(baseline/'binaries/compute'),'--baseline-manifest',str(baseline/'manifest.json')]
 with(state/('m31-measure-'+suite+'.log')).open('w')as f:r=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(suite,r.returncode);metadata=json.loads((base/('before-after-'+suite)/'metadata.json').read_text());pairs={}
 for sample in metadata['samples']:
  assert sample['status']=='ok'and sample['complete_basis_equal'];pairs.setdefault((sample['case'],sample['block']),{})[sample['arm']]=sample
 rows=[]
 for (name,block),pair in pairs.items():
  a,b=pair['A'],pair['B'];assert {k:v for k,v in a['statistics'].items()if k!='candidate_nanos'}=={k:v for k,v in b['statistics'].items()if k!='candidate_nanos'}
  rows.append(dict(case=name,block=block,family=a['family'],p=a['p'],candidate_ratio=b['statistics']['candidate_nanos']/a['statistics']['candidate_nanos'],process_ratio=b['wall_nanos']/a['wall_nanos']))
 summary=lambda xs:dict(geomean=statistics.geometric_mean(xs),median=statistics.median(xs),minimum=min(xs),maximum=max(xs))
 results[suite]=dict(pairs=len(rows),all_complete_bases_and_counters_equal=True,candidate=summary([x['candidate_ratio']for x in rows]),process=summary([x['process_ratio']for x in rows]),by_prime={str(p):summary([x['candidate_ratio']for x in rows if x['p']==p])for p in sorted({x['p']for x in rows})},rows=rows)
 (base/'separate-suite-analysis.json').write_text(json.dumps(results,indent=2)+'\n');print(suite,{k:v for k,v in results[suite].items()if k!='rows'},flush=True)
