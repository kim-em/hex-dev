from pathlib import Path
import json,math,statistics
base=Path('/tmp/hex-groebner-hotloop-production');g=lambda v:math.exp(sum(map(math.log,v))/len(v));summary=lambda v:dict(geomean=g(v),median=statistics.median(v),minimum=min(v),maximum=max(v))
p=next(base.glob('hotloop-production-records-*'));m=json.loads((p/'metadata.json').read_text());ratios=[];wall=[];cases={}
for c in json.loads((p/'diagnostic-suite.json').read_text())['cases']:
 v=[];w=[];allocated=[]
 for block in [0,1]:
  a,b=[next(x for x in m['samples'] if x['case']==c['name'] and x['block']==block and x['arm']==arm) for arm in ['A','B']];assert a['status']==b['status']=='ok'
  for k in a['statistics']:
   if k not in ['candidate_nanos','work','allocated_bytes']:assert a['statistics'][k]==b['statistics'][k],(c,k)
  assert json.loads((p/f"{c['name']}-b{block}-A.stdout").read_text())['basis']==json.loads((p/f"{c['name']}-b{block}-B.stdout").read_text())['basis'];x=b['statistics']['candidate_nanos']/a['statistics']['candidate_nanos'];v.append(x);ratios.append(x);wall.append(b['wall_nanos']/a['wall_nanos']);w.append(b['statistics']['work']/a['statistics']['work']);allocated.append(b['statistics']['allocated_bytes']/a['statistics']['allocated_bytes'])
 cases[c['name']]=dict(candidate_ratios=v,work_ratios=w,allocation_ratios=allocated);print(c['name'],*[round(x,4) for x in v])
o=dict(cpu=m['cpu'],samples=len(m['samples']),candidate=summary(ratios),wall=summary(wall),per_case=cases,complete_bases_and_non_resource_counters_equal=True);(p/'analysis.json').write_text(json.dumps(o,indent=2)+'\n');print('full system',{k:v for k,v in o.items() if k!='per_case'})
