from pathlib import Path
import subprocess,json
base=Path(__file__).resolve().parent
for i in range(8):
 with (base/f'run-{i}.stdout').open('w') as o,(base/f'run-{i}.stderr').open('w') as e:
  r=subprocess.run(['/tmp/hex-groebner-scheduling-strengthened-production/binaries/compute','--scheduling','degree','--work','100000000000','--matrix-entries','1000000000','--packed-bytes','17179869184','/tmp/hex-groebner-medium-suite/cyclic7-31.json'],stdout=o,stderr=e)
 assert r.returncode==0
