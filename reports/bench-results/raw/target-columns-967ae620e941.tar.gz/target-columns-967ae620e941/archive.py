from pathlib import Path
import json,tarfile,hashlib,shutil,subprocess
repo=Path('/tmp/hex-groebner-target-columns-dev');dest=repo/'reports/bench-results/raw';catalog=[]
for variant in ['target-columns','target-columns-validated']:
 base=Path('/tmp/hex-groebner-'+variant+'-production');m=json.loads((base/'manifest.json').read_text());fp=m['source_fingerprint'];name=variant+'-'+fp;stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
 for p in base.iterdir():
  if p.name in ['binaries','bench-binaries']:continue
  if p.is_dir():shutil.copytree(p,stage/p.name)
  else:shutil.copy2(p,stage/p.name)
 baseline=Path('/tmp/hex-groebner-scheduling-strengthened-production');bm=json.loads((baseline/'manifest.json').read_text());(stage/'baseline-manifest.json').write_text(json.dumps(bm,indent=2)+'\n')
 for folder,manifest in [('root-sources',m),('baseline-sources',bm)]:
  (stage/(folder+'.manifest')).write_text(manifest['source_manifest'])
  for line in manifest['source_manifest'].splitlines():
   h,n=line.split('\t',1);oid=h.split()[1];data=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;p=stage/folder/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 scope=dict(source_fingerprint=fp,baseline_source_fingerprint=bm['source_fingerprint'],scope='Development comparison, not an acceptance or leadership claim. Complete reduced bases agree in every small and medium CLI pair and every fixed benchmark structural hash. Both candidate production and full process boundaries are retained separately. Each small, medium and fixed observation has one initial campaign and its single unchanged repeat, retaining all completed samples, outliers, failures and host context. The two variant source fingerprints are separate experiments and must not be pooled. The default total-degree scheduler is used for timing; both degree and sugar are covered by conformance. No certification/kernel cost is included in candidate timings. No comparator binaries are redistributed.')
 if variant.endswith('validated'):
  for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(repo/folder,stage/folder)
  for n in ['scripts/oracle/groebner_corpus.py','scripts/oracle/groebner_sympy.py','scripts/oracle/groebner_singular.py','scripts/ci/check_groebner_driver.py']:
   p=stage/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,p)
  for p in Path('/tmp').glob('issue-10987-target-columns-*.log'):shutil.copy2(p,stage/p.name)
  p=Path('/tmp/issue-10987-target-columns-reimer65537-counters.json');shutil.copy2(p,stage/p.name)
  scope['validation']='All 1958 conformance/theory targets, independent 175 matrix/567 unique basis/1288 division oracle checks with 1134 equal strategy profiles, CLI checks, four Clang and four GCC sanitizer variants, and 32 benchmark smoke cases pass. Missing symbolic columns return representation.index. Optional packed trie preparation can be skipped at tight work bounds: a fresh successful run is checked against the same mathematical basis and its allowance; every exhausted continuation still compares exact statistics and traced derivations between the original and opposite incoming scheduling option. The initial diagnostic failure and corrected validation logs are retained.'
 else:scope['validation']='Initial reverse-column prototype. Later source b9c671b4f9af changes a missing-column fallback and adjusts a budget-sensitive conformance assumption. This older campaign is retained separately and is not the final implementation validation.'
 (stage/'scope.json').write_text(json.dumps(scope,indent=2)+'\n');shutil.copy2('/tmp/analyze-groebner-target-columns.py',stage/'analyze.py');shutil.copy2(__file__,stage/'archive.py');target=dest/(name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
 a=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),fingerprint=fp);catalog.append(a);print(a,flush=True)
Path('/tmp/issue-10987-target-columns-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
