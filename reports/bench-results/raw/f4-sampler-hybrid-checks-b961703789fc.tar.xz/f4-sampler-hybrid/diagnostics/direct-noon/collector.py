from pathlib import Path
import os,sys,json,hashlib,subprocess
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');base=s/'sampler-hybrid-production';out=base/'profiles-direct-noon';out.mkdir(exist_ok=False);sys.path.insert(0,str(root))
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_checks import source_identity
identity=source_identity();manifest=json.loads((base/'manifest.json').read_text());cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();records=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
try:
 for case,inp in [('noon5-31',s/'final-products-production/medium-inputs/noon5-31.json')]:
  (out/(case+'.json')).write_bytes(inp.read_bytes());outputs=[]
  for index,arm in enumerate(['A','B','B','A']):
   assert source_identity()==identity
   binary=base/'binaries'/('compute'if arm=='A'else'sample');key=binary.name;assert sha(binary)==manifest['binary_sha256'][key]
   name=f'{case}-{index}-{arm}';extra=[]if arm=='A'else['--seed','10987','--block-rows','32','--zero-tests','1','--min-targets','128']
   command=['perf','record','-e','cycles:u','-F','1999','--call-graph','dwarf,16384','-o',str(out/(name+'.data')),'--',str(binary),*extra,'--scheduling','degree','--work','100000000000',str(inp)]
   with(out/(name+'.stdout')).open('wb')as stdout,(out/(name+'.stderr')).open('wb')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
   records.append(dict(name=name,command=command,exit_code=r.returncode,binary_sha256=sha(binary),input_sha256=sha(inp)));assert r.returncode==0
   for options,suffix in [(['--no-children','--percent-limit','0.5'],'report'),(['--header-only'],'header')]:
    with(out/(name+'.'+suffix)).open('w')as f:subprocess.run(['perf','report','--stdio',*options,'-i',str(out/(name+'.data'))],stdout=f,stderr=subprocess.STDOUT,check=True)
   outputs.append(json.loads((out/(name+'.stdout')).read_text()));records[-1]['trace_sha256']=sha(out/(name+'.data'))
  assert all(v['basis']==outputs[0]['basis']and v['statistics']==outputs[0]['statistics']for v in outputs)
  assert all(v.get('sampling',{}).get('calls',0)==0 for v in outputs)
  for arm in ['A','B']:
   values=[v for v in outputs if(v.get('algorithm')=='f4-sampled')==(arm=='B')]
   for v in values:v.pop('candidateNanos')
   assert values[0]==values[1]
finally:
 assert source_identity()==identity
 (out/'metadata.json').write_text(json.dumps(dict(identity=identity,manifest=manifest,cpu=cpu,host=os.uname().nodename,threads=1,load_start=load,load_end=os.getloadavg(),records=records,scope='Four diagnostic user-cycle profiles, adjacent deterministic/sampled then reverse, to investigate candidate-time differences when both policies run identical deterministic work. Low sample counts do not justify fine-grained attribution. Whole processes include startup, parsing and output. Cost attribution only, no timing or acceptance claim; complete bases and per-arm non-time metadata checked. All raw traces retained with hashes.'),indent=2)+'\n');lease.close();(out/'collector.py').write_bytes(Path(__file__).read_bytes())
