import Lake
open Lake DSL System
package GroebnerStridedBench
require Hex from "/tmp/hex-groebner-small-review"
def probeO (pkg : Package) (name : String) (flags : Array String) : FetchM (Job FilePath) := do
  let source ← inputTextFile (pkg.dir / "probe.c")
  let body ← inputTextFile (FilePath.mk "/tmp/hex-groebner-small-review/HexGroebner/ffi/matrix_scan_impl.h")
  let simd ← inputTextFile (FilePath.mk "/tmp/hex-groebner-small-review/HexGroebner/ffi/matrix_simd.h")
  let inputs := (source.zipWith (fun s _ => s) body).zipWith (fun s _ => s) simd
  buildO (pkg.dir / defaultBuildDir / (name ++ ".o")) inputs
    #["-isystem", (← getLeanIncludeDir).toString] flags
lean_lib KernelBench where
  roots := #[`KernelBench]
target probeNative pkg : FilePath := probeO pkg "Native" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING"]
lean_exe benchNative where
  root := `NativeMain
  moreLinkObjs := #[probeNative]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]
target probeScalar pkg : FilePath := probeO pkg "Scalar" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_NO_AVX2"]
lean_exe benchScalar where
  root := `ScalarMain
  moreLinkObjs := #[probeScalar]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]
