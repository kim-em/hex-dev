from pathlib import Path
import json,math,statistics
p=next(Path('/tmp/hex-groebner-strided-bench').glob('final-calibrated-records-*'));m=json.loads((p/'metadata.json').read_text());g=lambda v:math.exp(sum(map(math.log,v))/len(v));cases={};fits=[];count=0
for case in ['cauchy8','cauchy16','cauchy16Trace','cauchy16Strided']:
 r={}
 for block in [0,1]:
  data={arm:json.loads((p/f'{case}-b{block}-{arm}.json').read_text())['results'][0] for arm in ['A','B']}
  for arm,d in data.items():
   fits.append(dict(case=case,block=block,arm=arm,verdict=d['verdict'],beta=d.get('slope'),advisories=d.get('advisories'),spawn_floor_nanos=d['spawn_floor_nanos'],points=len(d['points']),verdict_points=sum(x.get('part_of_verdict',False) for x in d['points'])))
  a,b=data['A'],data['B'];assert len(a['points'])==len(b['points'])
  for x,y in zip(a['points'],b['points']):
   assert x['status']==y['status']=='ok' and x['param']==y['param'] and x['trial_index']==y['trial_index'] and x['result_hash']==y['result_hash'];count+=2;n=x['param'];a_ns=x['total_nanos']/x['inner_repeats'];b_ns=y['total_nanos']/y['inner_repeats'];updates=(n**3-n)/3
   row=r.setdefault(str(n),dict(ratios=[],scalar_ns_per_update=[],simd_ns_per_update=[]));row['ratios'].append(b_ns/a_ns);row['scalar_ns_per_update'].append(a_ns/updates);row['simd_ns_per_update'].append(b_ns/updates)
 for n,v in r.items():v.update(geomean=g(v['ratios']),median=statistics.median(v['ratios']),minimum=min(v['ratios']),maximum=max(v['ratios']))
 cases[case]=r
out=dict(source_fingerprint=m['source_fingerprint'],cpu=m['cpu'],completed_points=count,all_full_output_hashes_match=True,per_case=cases,fits=fits);(p/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print('source',m['source_fingerprint'],'CPU',m['cpu'],'points',count)
for case,r in cases.items():print(case,{n:round(v['geomean'],4) for n,v in r.items()})
for row in fits:print(row['case'],row['block'],row['arm'],row['verdict'],row['beta'],row['advisories'])
