/* Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
   Released under Apache 2.0 license as described in the file LICENSE.
   Authors: Kim Morrison */
#ifndef HEX_GROEBNER_DELAYED_SIMD_H
#define HEX_GROEBNER_DELAYED_SIMD_H
#include "matrix_simd.h"
#if HEX_GROEBNER_AVX2
/* Four exact u64 accumulators, with u16 sparse coefficients. Returning zero
   leaves all bytes unchanged so scalar code preserves malformed/overflow prefixes. */
__attribute__((target("avx2"),always_inline))
static inline unsigned hex_delayed4(uint8_t *data,const uint8_t *columns,
        const uint8_t *coefficients,size_t entry,uint64_t column_count,uint32_t p,uint32_t factor) {
    uint32_t ids[4],previous;
    memcpy(ids,columns+entry*4,16);
    if(p<=256 || p>65536 || factor>=p || ids[3]>=column_count || ids[3]>INT32_MAX ||
       ids[0]>=ids[1] || ids[1]>=ids[2] || ids[2]>=ids[3]) return 0;
    if(entry) {memcpy(&previous,columns+(entry-1)*4,4);if(previous>=ids[0]) return 0;}
    __m128i index=_mm_loadu_si128((const __m128i *)(const void *)(columns+entry*4));
    __m256i b=_mm256_cvtepu16_epi64(_mm_loadl_epi64((const __m128i *)(const void *)(coefficients+entry*2)));
    __m256i zero=_mm256_setzero_si256(),modulus=_mm256_set1_epi64x((long long)p);
    if((uint32_t)_mm256_movemask_epi8(_mm256_cmpgt_epi64(modulus,b))!=UINT32_MAX ||
       _mm256_movemask_epi8(_mm256_cmpeq_epi64(b,zero))) return 0;
    __m256i a=ids[3]-ids[0]==3?_mm256_loadu_si256((const __m256i *)(const void *)(data+(size_t)ids[0]*8)):
        _mm256_i32gather_epi64((const long long *)(const void *)data,index,8);
    __m256i product=_mm256_mul_epu32(_mm256_set1_epi64x((long long)factor),_mm256_sub_epi64(modulus,b));
    __m256i value=_mm256_add_epi64(a,product),sign=_mm256_set1_epi64x(INT64_MIN);
    if(_mm256_movemask_epi8(_mm256_cmpgt_epi64(_mm256_xor_si256(a,sign),_mm256_xor_si256(value,sign))))
        return 0;
    if(ids[3]-ids[0]==3) _mm256_storeu_si256((__m256i *)(void *)(data+(size_t)ids[0]*8),value);
    else {
        uint64_t values[4];_mm256_storeu_si256((__m256i *)(void *)values,value);
        for(unsigned i=0;i<4;++i) memcpy(data+(size_t)ids[i]*8,values+i,8);
    }
    return 4;
}
#endif
#endif
