from pathlib import Path
import json,math,statistics,sys
p=Path(sys.argv[1]);ratios={};count=0;inconclusive=[];budget=[]
for case in ('cauchy16','cauchy16Strided'):
 r={}
 for block in (0,1):
  a,b=[json.loads((p/f'{case}-b{block}-{arm}.json').read_text())['results'][0] for arm in ('A','B')]
  for arm,v in zip(('A','B'),(a,b)):
   if v.get('verdict')=='inconclusive':inconclusive.append(f'{case}-b{block}-{arm}')
   if v.get('budget_truncated'):budget.append(f'{case}-b{block}-{arm}')
  assert len(a['points'])==len(b['points'])
  for x,y in zip(a['points'],b['points']):
   assert x['status']==y['status']=='ok' and x['result_hash']==y['result_hash']
   n=x['param'];assert n==y['param'];count+=2;r.setdefault(str(n),[]).append((y['total_nanos']/y['inner_repeats'])/(x['total_nanos']/x['inner_repeats']))
 ratios[case]={n:dict(geomean=math.exp(sum(map(math.log,v))/len(v)),median=statistics.median(v),minimum=min(v),maximum=max(v),ratios=v) for n,v in r.items()}
out=dict(cpu=json.loads((p/'metadata.json').read_text())['cpu'],points=count,complete_hashes_match=True,per_case=ratios,inconclusive_exports=inconclusive,budget_truncated_exports=budget);(p/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['cpu'],count,inconclusive,budget)
for c,ns in ratios.items():print(c,{n:round(v['geomean'],4) for n,v in ns.items()})
