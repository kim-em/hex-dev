from pathlib import Path
import sys,os,json,subprocess,hashlib
sys.path.insert(0,'/home/kim/worktrees/hex-dev/hex-dev-issue-10987')
from scripts.bench.cpu_lease import cpu_lease
p=Path('/tmp/hex-groebner-delayed-simd-production/profile');p.mkdir(exist_ok=False)
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});runs=[]
try:
 for label,exe,fp in [('pair-rows','/tmp/hex-groebner-pair-rows-verified-production/binaries/hexgroebner-bench-pair-rows-verified','c9fcd659ff93'),('delayed-simd','/tmp/hex-groebner-delayed-simd-production/binaries/hexgroebner-bench-delayed-simd','89a5bdc1fd9b')]:
  cmd=['perf','record','-F','1999','-g','--call-graph','dwarf,8192','-o',str(p/(label+'.perf')),'--',exe,'run','Hex.Groebner.Bench.cyclic6Small','--repeats','1','--min-total-seconds','2','--export-file',str(p/(label+'.json'))]
  with (p/(label+'.stdout')).open('w') as out,(p/(label+'.stderr')).open('w') as err:r=subprocess.run(cmd,stdout=out,stderr=err)
  runs.append(dict(label=label,source_fingerprint=fp,command=cmd,returncode=r.returncode,binary_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest()))
  if r.returncode==0:
   with (p/(label+'-report.txt')).open('w') as out:subprocess.run(['perf','report','--stdio','--no-children','--sort','symbol','-i',str(p/(label+'.perf'))],stdout=out,stderr=subprocess.STDOUT,check=True)
finally:
 (p/'metadata.json').write_text(json.dumps(dict(cpu=cpu,runs=runs,reason='Explain delayed SIMD failure to improve full F4 despite fewer modular reductions; sampling with two-second inner calibration and one repetition to amortize process initialization; not matched timing evidence',load=os.getloadavg(),script=Path(__file__).read_text()),indent=2)+'\n');lease.close()
