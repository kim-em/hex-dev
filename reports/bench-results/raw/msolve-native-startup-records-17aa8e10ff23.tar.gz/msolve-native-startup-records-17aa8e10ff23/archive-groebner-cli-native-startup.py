from pathlib import Path
import json,subprocess,hashlib,shutil,tarfile
root=Path('/tmp/hex-groebner-cli-dev');p=Path('/tmp/hex-groebner-cli-effective-freeze');dest=root/'reports/bench-results/raw';manifest=json.load(open(p/'manifest.json'));rows=[]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for directory in sorted(p.glob('msolve-native-startup-records-17aa8e10ff23')):
 shutil.copy2(p/'manifest.json',directory/'manifest.json');shutil.copy2(__file__,directory/Path(__file__).name)
 for line in manifest['source_manifest'].splitlines():
  _,oid,rest=line.split(' ',2);_,name=rest.split('\t');f=directory/'root-sources'/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd=root))
 (directory/'source.manifest').write_text(manifest['source_manifest'])
 ms=Path('/tmp/hex-groebner-msolve');meta=json.load(open(directory/'metadata.json'));assert sha(ms/'src/neogb/.libs/libneogb.so.4.0.0')==meta['msolve_engine_sha256']
 for name in ['config.log','config.h','config.status','Makefile','src/neogb/Makefile']:
  shutil.copy2(ms/name,directory/('msolve-'+name.replace('/','-')))
 for name in ['issue-10987-msolve-native-build.log','issue-10987-msolve-native-configure-with-deps.log','issue-10987-msolve-native-compiler-probe.log','issue-10987-build-msolve-native.sh','issue-10987-msolve-effective-native-build.json']:
  shutil.copy2(Path('/tmp')/name,directory/name)
 shutil.copy2('/tmp/hex-groebner-mersenne-dispatch-production/msolve-source-3672113ee2c6.tar',directory/'msolve-source-3672113ee2c6.tar')
 (directory/'msolve-recorded-commands.txt').write_text(subprocess.check_output(['readelf','-p','.GCC.command.line',str(ms/'src/neogb/.libs/libneogb.so.4.0.0')],text=True))
 target=dest/(directory.name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(directory,arcname=directory.name)
 rows.append((target.name,sha(target)))

print(json.dumps(rows,indent=2))
