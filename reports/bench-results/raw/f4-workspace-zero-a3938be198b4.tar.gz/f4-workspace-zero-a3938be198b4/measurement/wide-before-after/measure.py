from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
state=Path('/home/kim/tmp/issue-10987');base=state/'workspace-zero-production'
while not(base/'bench-binaries/builds.json').is_file():time.sleep(5)
build=json.loads((base/'bench-binaries/builds.json').read_text());binary=base/'bench-binaries/frame';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256']
helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('frozen_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
old=state/'equivalence-shaped-production/bench-binaries';oldbuild=json.loads((old/'builds.json').read_text());assert hashlib.sha256((old/'frame').read_bytes()).hexdigest()==oldbuild['binary_sha256']
for mode in ['before-after','reference']:
 out=base/('wide-'+mode);out.mkdir(exist_ok=False);cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[];points={a:[]for a in 'AB'}
 try:
  for block,order in enumerate(['AB','BA']):
   for arm in order:
    executable=old/'frame'if mode=='before-after'and arm=='A'else binary
    name='matrixWideReference'if mode=='reference'and arm=='A'else 'matrixWide'
    prefix=f'block{block}-{arm}';command=[str(executable),'run','Hex.Groebner.Bench.'+name,'--outer-trials','1','--export-file',str(out/(prefix+'.json'))]
    with(out/(prefix+'.log')).open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
    runs.append(dict(block=block,arm=arm,command=command,exit_code=r.returncode));assert r.returncode in[0,2]
    result=json.loads((out/(prefix+'.json')).read_text())['results'][0];assert len(result['points'])==4 and all(x['status']=='ok'for x in result['points']);points[arm]+=result['points'];print(mode,prefix,result['verdict'],flush=True)
  for n in [65536,65537,131072,262144]:assert len({p['result_hash']for ps in points.values()for p in ps if p['param']==n})==1
 finally:
  (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),build=build,baseline_build=oldbuild if mode=='before-after'else build,cpu_helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),runs=runs,scope='First matched AB/BA whole sweeps. Before-after compares the unchanged current continuation against native zero-buffer initialization in otherwise identical complete frame computation. Reference compares the new continuation and reference in one executable. Prepared inputs excluded; all decoded rows/metadata and eight counters hashed. Every completed point, RSS, floor flag and failure retained. No host filtering, unchanged repeat or pooling of campaigns. Not full F4, certification, verification or kernel-checking timing.'),indent=2)+'\n');lease.close()
  (out/'measure.py').write_bytes(Path(__file__).read_bytes())
