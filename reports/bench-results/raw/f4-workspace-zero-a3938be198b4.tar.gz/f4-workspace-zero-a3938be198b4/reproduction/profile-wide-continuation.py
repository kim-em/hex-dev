from pathlib import Path
import hashlib,importlib.util,json,os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'equivalence-reviewed-production';out=state/'wide-continuation-profile';out.mkdir(exist_ok=False)
helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('frozen_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
manifest=json.loads((base/'bench-binaries/builds.json').read_text());binary=base/'bench-binaries/frame';assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['binary_sha256']
cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();records=[]
try:
 for label,name in [('reference','matrixWideReference'),('continuation','matrixWide')]:
  command=['perf','record','-e','cycles:u','-F','999','--call-graph','dwarf,8192','-o',str(out/(label+'.data')),'--',str(binary),'run','Hex.Groebner.Bench.'+name,'--outer-trials','1','--export-file',str(out/(label+'.json'))]
  with(out/(label+'.stdout')).open('w')as stdout,(out/(label+'.stderr')).open('w')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  records.append(dict(label=label,command=command,exit_code=r.returncode));assert r.returncode in [0,2]
  for option,suffix in [(['--no-children','--percent-limit','0.5'],'report'),(['--header-only'],'header')]:
   with(out/(label+'.'+suffix)).open('w')as f:subprocess.run(['perf','report','--stdio',*option,'-i',str(out/(label+'.data'))],stdout=f,stderr=subprocess.STDOUT,check=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),build=manifest,cpu_helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),runs=records,scope='Diagnostic profiles of the already measured approximately fourfold wide-continuation regression. Full registered four-width sweeps; prep and initialization are present in whole-process profiles. These instrumented exports are retained but are not used as timing comparisons or unchanged repeats. User-cycle sampling is inherited by child benchmark processes. No timing, coverage or leadership claim from these profiles.'),indent=2)+'\n');lease.close()
(out/'profile.py').write_bytes(Path(__file__).read_bytes())
