from pathlib import Path
import hashlib,io,json,lzma,sys,tarfile
root=Path.cwd();sys.path.insert(0,str(root));from scripts.bench.groebner_capsule import Capsule
s=Path('/home/kim/tmp/issue-10987')
for name in ['f4-active-pairs-1385ee01d770.tar.xz','f4-active-list-4976b3eed62c.tar.xz']:
 original=Capsule(s/name);payload=dict(original.payloads);payload.pop('sha256.json');assert hashlib.sha256((root/'reports/bench-results/raw'/name).read_bytes()).hexdigest()==original.sha256
 payload['sympy-LICENSE']=(s/'sympy-LICENSE').read_bytes();payload['upstream-reference.json']=(json.dumps({'source_url':'https://github.com/sympy/sympy/blob/master/sympy/polys/groebnertools.py','source_sha256':hashlib.sha256(payload['sympy-groebnertools.py']).hexdigest(),'license_url':'https://github.com/sympy/sympy/blob/master/LICENSE','original_capsule_sha256':original.sha256},indent=2)+'\n').encode();payload['license-pack.py']=Path(__file__).read_bytes();payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode()
 out=root/'reports/bench-results/raw'/name
 with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
  for n,b in sorted(payload.items()):
   e=tarfile.TarInfo('f4-retirement/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
 final=Capsule(out);assert all(final.read(n)==b for n,b in original.payloads.items()if n!='sha256.json');print(name,final.count,out.stat().st_size,final.sha256,flush=True)
