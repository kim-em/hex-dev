from pathlib import Path
import json,subprocess,time
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');out=state/'active-pairs-corpus';out.mkdir(exist_ok=True)
records=[json.loads(line)for line in(root/'conformance-fixtures/HexGroebner/f4.jsonl').read_text().splitlines()];rows=[]
for executable in ['hexgroebner_compute','hexgroebner_compute_full']:
 for i,r in enumerate(records):
  expected=r['value'];input_path=out/'input.json';input_path.write_text(json.dumps({k:expected[k]for k in ['p','variables','order','generators']})+'\n')
  for serial in [False,True]:
   command=[str(root/'.lake/build/bin'/executable),'--scheduling',expected['scheduling']]
   if serial:command+=['--batch-size','1']
   command+=[str(input_path)];p=subprocess.run(command,capture_output=True,timeout=30)
   assert p.returncode==0,(r['case'],p.stdout[-1000:],p.stderr[-500:])
   value=json.loads(p.stdout);assert value['kind']=='unchecked_candidate'and value['basis']==expected['basis'],r['case']
   rows.append({'executable':executable,'case':r['case'],'serial':serial,'basis_equal':True,'statistics':value['statistics']})
  if i%40==0:print(executable,i,len(records),flush=True)
(out/'status.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS',len(rows),'complete bases',flush=True)
