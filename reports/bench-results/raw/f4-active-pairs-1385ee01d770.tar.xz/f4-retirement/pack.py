from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();payload={}
def add(name,p):assert name not in payload;payload[name]=p.read_bytes()
for label,directory in [('baseline','avx512-default-production'),('active-pairs','active-pairs-production')]:
 base=s/directory
 for p in sorted(base.rglob('*')):
  if p.is_file()and'binaries'not in p.relative_to(base).parts:add(label+'/'+str(p.relative_to(base)),p)
text=tree_listing(CHECKS,'HEAD');payload['checks.manifest']=text.encode()
for line in text.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for n in ['active-pairs-build.log','active-pairs-drivers-build.log','active-pairs-f4-check.log','active-pairs-corpus.log','active-pairs-oracles.log','active-pairs-f4.jsonl','check-active-pairs-corpus.py','sympy-groebnertools.py']:
 add(n,s/n)
add('corpus-status.json',s/'active-pairs-corpus/status.json');add('pack.py',Path(__file__))
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();payload['scope.json']=b'{"selected":false,"production":false,"description":"Intermediate tree-based retirement prototype; no fastest-open-source claim; no more unchanged repeats"}\n'
payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode();out=s/('f4-active-pairs-'+identity['source_fingerprint']+'.tar.xz')
assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-active-pairs/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
