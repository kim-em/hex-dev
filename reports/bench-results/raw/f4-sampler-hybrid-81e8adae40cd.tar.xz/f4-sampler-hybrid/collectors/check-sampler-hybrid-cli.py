from pathlib import Path
import json,subprocess,hashlib
s=Path('/home/kim/tmp/issue-10987');base=s/'sampler-hybrid-production';out=base/'cli';out.mkdir(exist_ok=False);records=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for arm in ['sample','sample-reference']:
 binary=base/'binaries'/arm
 for index,(flags,code,minimum)in enumerate([([],0,0),(['--min-targets','0'],0,0),(['--min-targets',str(2**90)],0,2**90),(['--min-targets','128','--min-targets','0'],0,0),(['--min-targets','-1'],2,None),(['--min-targets','no'],2,None)]):
  inp=s/'final-products-production/medium-inputs/cyclic7-15.json';name=f'{arm}-{index}';command=[str(binary),'--seed','10987','--work','100000000000','--matrix-entries','1000000000',*flags,str(inp)]
  r=subprocess.run(command,capture_output=True);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);v=json.loads(r.stdout);assert r.returncode==code
  if minimum is not None:
   assert v['kind']=='unchecked_candidate'and v['minimumTargets']==minimum
   expected=json.loads((s/'monomial-batches-review-production/prime-control/cyclic7-15-b0-B.stdout').read_text());assert v['basis']==expected['basis']
   if minimum:assert v['sampling']['calls']==v['sampling']['randomWords']==0 and v['randomState']==10987
  else:assert v['kind']=='invalid_input'and'basis'not in v
  records.append(dict(name=name,command=command,exit_code=r.returncode,binary_sha256=sha(binary),input_sha256=sha(inp),minimum_targets=minimum))
(out/'status.json').write_text(json.dumps(records,indent=2)+'\n');(out/'collector.py').write_bytes(Path(__file__).read_bytes());print(len(records),'CLI boundary checks passed')
