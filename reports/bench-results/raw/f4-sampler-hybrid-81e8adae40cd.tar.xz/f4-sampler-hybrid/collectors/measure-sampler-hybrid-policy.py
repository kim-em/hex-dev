from pathlib import Path
import os,subprocess
s=Path('/home/kim/tmp/issue-10987');base=s/'sampler-hybrid-production'
command=[str(s/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(s/'final-products-production/medium-inputs/suite.json'),'--sampled','--baseline-sampled','--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/sample'),'--baseline',str(base/'binaries/sample'),'--baseline-manifest',str(base/'manifest.json'),'--seed','10987','--block-rows','32','--zero-tests','1','--min-targets','128','--baseline-min-targets','0','--output',str(base/'cutoff128-prime')]
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(s/'oracles/bin')+':'+os.environ['PATH'])
r=subprocess.run(command,env=env);(base/'measure-policy.py').write_bytes(Path(__file__).read_bytes());raise SystemExit(r.returncode)
