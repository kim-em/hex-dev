from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();assert identity['source_fingerprint']=='81e8adae40cd';payload={}
def add(n,p):
 assert n not in payload,n
 payload[n]=p.read_bytes()
def tree(label,base):
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if p.is_file()and'binaries'not in rel.parts and p.suffix!='.data':add(label+'/'+str(rel),p)
tree('baseline',s/'sampled-current-production');tree('hybrid',s/'sampler-hybrid-production')
text=tree_listing(CHECKS,identity['source_commit']);payload['checks.manifest']=text.encode()
for line in text.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for cc in ['clang','gcc']:
 add('native-'+cc+'.log',s/f'sampler-hybrid-verified-{cc}.log')
 base=s/f'sampler-hybrid-verified-{cc}'
 for p in sorted(base.rglob('*')):
  if p.is_file()and'.lake'not in p.relative_to(base).parts:add('probes/'+cc+'/'+str(p.relative_to(base)),p)
for label,name in [('native-status.json','sampler-hybrid-verified-native-status.json'),('full-status.json','sampler-hybrid-full-status.json')]:
 rows=json.loads((s/name).read_text());assert len(rows)==(2 if label.startswith('native')else 9)and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in rows);add(label,s/name)
 if label.startswith('full'):
  for row in rows:add('full/'+row['name']+'.log',Path(row['log']))
for pattern in ['*sampl*current*.py','*sampler-hybrid*.py']:
 for p in sorted(s.glob(pattern)):
  n='collectors/'+p.name
  if n not in payload:add(n,p)
for name in ['sampled-current-profile.log','sampled-current-profile-mq-resumed.log','sampler-hybrid-model.log','sampler-hybrid-checks.log']:
 add('logs/'+name,s/name)
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode()
payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode()
out=s/('f4-sampler-hybrid-'+identity['source_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-sampler-hybrid/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
