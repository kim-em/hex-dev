import Lake
open Lake DSL
package GroebnerMetadataDev
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
lean_lib MetadataDev where
  roots := #[`CheckedWord]
