from pathlib import Path
import subprocess,sys,json,hashlib
root=Path('/tmp/hex-groebner-matrix-kernels-dev');production=Path('/tmp/hex-groebner-primitives-portable-production');baseline_root=Path('/tmp/hex-groebner-primitives-baseline');baseline=baseline_root/'binaries/compute';baseline_manifest=baseline_root/'manifest.json';manifest=production/'manifest.json';candidate=production/'binaries/compute'
assert baseline.is_file() and baseline.name=='compute';assert hashlib.sha256(baseline.read_bytes()).hexdigest()==json.loads(baseline_manifest.read_text())['binary_sha256']['compute']
suffix='-repeat' if '--repeat' in sys.argv else ''
suites={'small':Path('/tmp/hex-groebner-packed-targets-reviewed-production/before-after-small/inputs/diagnostic-suite.json'),'medium':Path('/tmp/hex-groebner-medium-suite/suite.json')}
for kind,suite in suites.items():
 command=['python3','scripts/bench/groebner_cli_measure.py','--manifest',str(manifest),'--suite',str(suite),'--output',str(production/('before-after-'+kind+suffix)),'--hex',str(candidate),'--baseline',str(baseline),'--baseline-manifest',str(baseline_manifest)]
 log=Path('/tmp/issue-10987-primitives-portable-measure-'+kind+suffix+'.log')
 with log.open('w') as stream:r=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 print(kind,suffix,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
subprocess.run(['python3','/tmp/analyze-groebner-target-columns.py',str(production)],cwd=root,check=True)

analysis=json.loads((production/'pooled-analysis.json').read_text())
for suite in analysis.values():
 for row in suite['ratios']:
  a={k:v for k,v in row['baseline'].items() if k!='candidate_nanos'}
  b={k:v for k,v in row['candidate'].items() if k!='candidate_nanos'}
  assert a==b,(row['case'],a,b)
print('All algorithm/resource counters match across every complete basis pair',flush=True)
