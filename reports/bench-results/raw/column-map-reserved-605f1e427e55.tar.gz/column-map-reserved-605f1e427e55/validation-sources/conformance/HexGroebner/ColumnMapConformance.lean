/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

import HexGroebner.ColumnMap

namespace Hex.Groebner.ColumnMapConformance

private def copy (bytes : ByteArray) : ByteArray := Id.run do
  let mut out := ByteArray.emptyWithCapacity bytes.size
  for i in [:bytes.size] do out := out.push bytes[i]!
  return out

private def buffer (n : Nat) (value : Nat → UInt64) : ByteArray := Id.run do
  let mut out := ByteArray.emptyWithCapacity (4*n)
  for i in [:n] do out := Packed.push .u32 out (value i)
  return out

/-- Exact native/model agreement across full chunks, malformed geometry,
absent entries, large scalar arguments, and every borrowed/output alias. -/
def remapChecks (seed : Nat) : Bool := Id.run do
  for n in [0,7,5001] do
    let positions := buffer n (fun i => (i + 1 + seed%17).toUInt64)
    let support := buffer n (fun i => i.toUInt64)
    for start in [0,3,n,n+1,2^80] do
      for count in [0,1,7,4095,4096,4097,2^80] do
        for initialOutput in [ByteArray.empty,positions,support] do
          let expected := Native.Columns.remapPortable (copy positions) (copy support)
            start count (copy initialOutput)
          let actual := Native.Columns.remap positions support start count initialOutput
          if actual != expected then return false
    if n > 0 then
      for broken in [positions.push 1,Packed.set .u32 positions (n-1) 0] do
        let expected := Native.Columns.remapPortable (copy broken) (copy support) 0 (min n 4096) {}
        if Native.Columns.remap broken support 0 (min n 4096) {} != expected then return false
      let support := Packed.set .u32 support 0 n.toUInt64
      if (Native.Columns.remap positions support 0 1 {}).isSome then return false
  let permuted := buffer 13 (fun i => ((i*7+3)%13+1).toUInt64)
  let repeated := buffer 31 (fun i => (i%13).toUInt64)
  for initialOutput in [ByteArray.empty,permuted,repeated] do
    let expected := Native.Columns.remapPortable (copy permuted) (copy repeated) 0 31 (copy initialOutput)
    if Native.Columns.remap permuted repeated 0 31 initialOutput != expected then return false
  let positions := buffer 3 (fun i => (i+1).toUInt64)
  let support := (buffer 3 (fun i => i.toUInt64)).push 77
  if Native.Columns.remap positions support 0 3 {} !=
      Native.Columns.remapPortable positions support 0 3 {} then return false
  return true

/-- Exact layout, work and payload outcomes, including pre-existing table bytes.
Every successful map is independently compared against a hash-map oracle. -/
def checks (seed : Nat) : Bool := Id.run do
  let table := ({ arity := 1 } : MonomialTable).internOwned #[0] 1000 10000 10000
  for initialTable in [({ arity := 0 } : MonomialTable),table.table] do
    for columns in [#[],#[0],#[0,1,2],#[4,1,4,0],#[7],#[8],#[4294967295],
        #[2^80],(Array.range 257).map fun i => (i * 17 + seed) % 257] do
      let mut expected : Std.HashMap Nat Nat := {}
      for i in [:columns.size] do expected := expected.insert columns[i]! i
      let count := columns.foldl (fun count id => max count (id+1)) 0
      let dense := columns.size < 4294967296 && count <= columns.size*8 && count*4 < USize.size
      let requiredWork := 2*columns.size + if dense then count else 0
      let requiredBytes := initialTable.bytes + if dense then 4*count else 0
      for work in [0,1,2,3,10,100,1000,10000,requiredWork-1,requiredWork,requiredWork+1] do
        for bytes in [0,1,3,4,8,31,32,33,100,10000,requiredBytes-1,requiredBytes,requiredBytes+1] do
          if bytes < initialTable.bytes then continue
          let limits : Limits := { work, packedBytes := bytes }
          let workspace : Workspace := { table := initialTable }
          let (result,state) := (ColumnMap.build limits columns).run workspace
          let expectedWork := if work < columns.size then 0 else
            if work < requiredWork then columns.size else requiredWork
          if state.statistics.work != expectedWork then return false
          if state.statistics.allocatedBytes + state.table.bytes > bytes then return false
          if work < requiredWork then
            let .error (.exhausted .work) := result | return false
            if state.statistics.allocatedBytes != 0 then return false
          else if bytes < requiredBytes then
            let .error (.exhausted .packedBytes) := result | return false
            if state.statistics.allocatedBytes != 0 then return false
          else
            let .ok positions := result | return false
            if state.statistics.allocatedBytes != (if dense then 4*count else 0) then return false
            match positions with
            | .packed _ => if !dense then return false
            | .hashed _ => if dense then return false
            for id in [0,1,2,3,4,7,8,257,4294967295,2^80] ++ columns.toList do
              if positions.get? id != expected[id]? then return false
  let positions := ColumnMap.hashed (({} : Std.HashMap Nat Nat).insert 0 (2^32))
  if (positions.encode (buffer 1 (fun _ => 0)) true).isSome then return false
  return true

#guard checks 0
#guard remapChecks 0

end Hex.Groebner.ColumnMapConformance
