from pathlib import Path
import json,subprocess,hashlib,tarfile,shutil
repo=Path('/tmp/hex-groebner-column-map-native-dev');base=Path('/tmp/hex-groebner-column-map-reserved-production');dest=Path('/tmp/hex-groebner-evidence-review/reports/bench-results');m=json.loads((base/'manifest.json').read_text());checks=json.loads(Path('/tmp/issue-10987-column-map-reserved-full-status.json').read_text());assert len(checks)==9 and all(v['exit_code']==0 for v in checks);name='column-map-reserved-'+m['source_fingerprint'];stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
for p in base.iterdir():
 if p.name=='binaries':continue
 if p.name=='bench-binaries':
  d=stage/p.name;d.mkdir()
  for q in p.iterdir():
   if q.is_file() and q.name not in ['A','B']:shutil.copy2(q,d/q.name)
 elif p.is_dir():shutil.copytree(p,stage/p.name)
 else:shutil.copy2(p,stage/p.name)
for folder,manifest in [('root-sources',m),('baseline-sources',json.loads(Path('/tmp/hex-groebner-whole-matrix-reviewed-production/manifest.json').read_text()))]:
 (stage/(folder+'.manifest')).write_text(manifest['source_manifest'])
 for line in manifest['source_manifest'].splitlines():
  mode,n=line.split('\t',1);oid=mode.split()[1];b=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;p=stage/folder/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(repo/folder,stage/'validation-sources'/folder)
for n in ['scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh','scripts/ci/check_groebner_driver.py']:
 p=stage/'validation-sources'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,p)
for p in Path('/tmp').glob('issue-10987-column-map-reserved-*'):
 if p.is_file() and p.suffix in ['.log','.json']:shutil.copy2(p,stage/p.name)
for n in ['issue-10987-column-map-native-policy-build.log','issue-10987-column-map-native-reserve-build.log','run-issue-10987-full-checks.py','measure-groebner-column-map-reserved.py','build-groebner-column-map-reserved-benches.py']:shutil.copy2(Path('/tmp')/n,stage/n)
shutil.copytree('/tmp/issue-10987-relocatable-wrapper',stage/'compiler-wrapper');profile=Path('/tmp/hex-groebner-column-map-route-profile');d=stage/'route-profile';d.mkdir()
for p in profile.iterdir():
 if p.is_file():shutil.copy2(p,d/p.name)
for compiler in ['clang','gcc']:
 native=Path('/tmp/hex-groebner-column-map-reserved-'+compiler+'-sanitizers');d=stage/('native-'+compiler);d.mkdir()
 for p in native.iterdir():
  if p.is_file():shutil.copy2(p,d/p.name)
 for p in (native/'.lake').rglob('*.rsp'):
  q=d/'response-files'/p.relative_to(native/'.lake');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
(stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=m['source_fingerprint'],decision='Do not adopt as a general speedup: mixed CLI evidence and fixed Cyclic5/Reimer5 regressions. Continue investigating compact sparse lookup.',scope='Geometry-only dense ID-prefix column maps, one-reserve direct native stores in <=4096-entry chunks, scalar remap body selected by nativeRows=false. Packed initialization, payload and lookup work are charged exactly; route is independent of remaining allowance. Exact outcome/counter conformance includes table bytes, limit boundaries,duplicate/missing/large IDs,permuted maps,repeated supports,full chunks,malformed buffers and shared/exclusive/marked-linear output aliases. All nine local checks and eight Clang/GCC ASan/UBSan variants pass, each recording9269F4native translations. Both first campaigns and sole unchanged repeats retained forsmall/mediumCLI andfixed benchmarks:240CLIprocesses,120completebasis pairs and240fixed structuralhashes equal;zero failures/timeouts. Work/allocatedBytes differ from baseline; raw counters retained. No pooling across source/build variants,no activity filtering,no more unchanged repeats. Candidate production excludes certificate generation,independentcertification andkernelchecking. Explanatory CPU13routeprofile counts packed/hash layouts onfourcomplete larger systems with equal uninstrumentedbases/counters; instrumented durations excluded from timings. Same restored SDKClang23.1.0/LLD23.1.0 wrapper; nativeFFIClang23.1.3. Development evidence, notheld-outSPECacceptance; no leadership orlanguage-limitclaim.'),indent=2)+'\n');shutil.copy2(__file__,stage/'archive.py');target=dest/'raw'/(name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
c=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source_fingerprint=m['source_fingerprint']);Path('/tmp/issue-10987-column-reserved-catalog.json').write_text(json.dumps(c,indent=2)+'\n');print(c)
