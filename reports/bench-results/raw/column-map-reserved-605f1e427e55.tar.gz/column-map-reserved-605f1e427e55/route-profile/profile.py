from pathlib import Path
import json,subprocess,shutil,os,hashlib,sys
root=Path('/tmp/hex-groebner-column-map-native-dev');base=Path('/tmp/hex-groebner-column-map-reserved-production');out=Path('/tmp/hex-groebner-column-map-route-profile');out.mkdir(exist_ok=False);m=json.loads((base/'manifest.json').read_text());checkout=out/'checkout'
subprocess.run(['git','worktree','add','--detach',str(checkout),m['source_snapshot']],cwd=root,check=True,stdout=subprocess.DEVNULL);(checkout/'.lake').mkdir();(checkout/'.lake/packages').symlink_to((root/'.lake/packages').resolve(),target_is_directory=True)
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(checkout/'ColumnProfile.lean').write_text('import HexGroebner.Driver.Run\ndef main (args : List String) : IO UInt32 := Hex.Groebner.Driver.run args\n')
source=r'''#include <lean/lean.h>
#include <stdio.h>
#include <stdlib.h>
extern lean_obj_res __real_lp_Hex_Hex_Groebner_ColumnMap_build(lean_obj_arg,lean_obj_arg,lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lp_Hex_Hex_Groebner_ColumnMap_build(lean_obj_arg limits,lean_obj_arg columns,lean_obj_arg workspace) {
 size_t n=lean_array_size(columns);
 lean_object *result=__real_lp_Hex_Hex_Groebner_ColumnMap_build(limits,columns,workspace);
 lean_object *value=lean_ctor_get(result,0);const char *path=getenv("HEX_GROEBNER_COLUMN_PROFILE");
 if(path) {FILE *file=fopen(path,"a");if(file) {
  if(lean_obj_tag(value)==1) {
   lean_object *map=lean_ctor_get(value,0);int packed=lean_obj_tag(map)==0;
   size_t bytes=packed?lean_sarray_size(lean_ctor_get(map,0)):0;
   fprintf(file,"{\"columns\":%zu,\"packed\":%s,\"packed_bytes\":%zu}\n",n,packed?"true":"false",bytes);
  } else fprintf(file,"{\"columns\":%zu,\"error\":true}\n",n);
  fclose(file);
 }}
 return result;
}
''';(checkout/'column_profile.c').write_text(source);(out/'column_profile.c').write_text(source)
config='''
target columnProfileO pkg : FilePath := do
 let source ← inputTextFile (pkg.dir / "column_profile.c")
 buildO (pkg.dir / defaultBuildDir / "column-profile.o") source
   #["-isystem", (← getLeanIncludeDir).toString]
   #["-O3", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING"]
   (compiler := "cc") (extraDepTrace := getLeanTrace)
lean_exe column_profile where
 root := `ColumnProfile
 moreLinkObjs := #[columnProfileO]
 moreLinkArgs := #["-Wl,--wrap=lp_Hex_Hex_Groebner_ColumnMap_build"]
''';p=checkout/'lakefile.lean';p.write_text(p.read_text()+config);shutil.copy2(p,out/'profile-lakefile.lean')
env=dict(os.environ,LEAN_CC='/tmp/issue-10987-relocatable-wrapper/issue-10987-lean-cc')
with (out/'build.log').open('w') as f:r=subprocess.run(['lake','build','column_profile'],cwd=checkout,stdout=f,stderr=subprocess.STDOUT,env=env)
assert r.returncode==0
sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});records=[]
try:
 for case in ['cyclic7-31','eco11-31','reimer6-31','minrank_d_2_p_2_q_4_r_2-31']:
  args=['--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000','/tmp/hex-groebner-medium-suite/'+case+'.json'];outputs=[]
  for arm,binary in [('profile',checkout/'.lake/build/bin/column_profile'),('production',base/'binaries/compute')]:
   with (out/(case+'-'+arm+'.stdout')).open('w') as stdout,(out/(case+'-'+arm+'.stderr')).open('w') as stderr:r=subprocess.run([str(binary),*args],stdout=stdout,stderr=stderr,env=dict(os.environ,HEX_GROEBNER_COLUMN_PROFILE=str(out/(case+'.routes.jsonl')),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
   assert r.returncode==0;value=json.loads((out/(case+'-'+arm+'.stdout')).read_text());outputs.append((value['basis'],{k:v for k,v in value['statistics'].items() if k!='candidate_nanos'}))
  assert outputs[0]==outputs[1]
  routes=[json.loads(line) for line in (out/(case+'.routes.jsonl')).read_text().splitlines()];assert routes and all('error' not in row for row in routes);assert len(routes)==outputs[0][1]['matrixCalls']
  rec=dict(case=case,calls=len(routes),packed=sum(row['packed'] for row in routes),hashed=sum(not row['packed'] for row in routes),columns=sum(row['columns'] for row in routes),packed_columns=sum(row['columns'] for row in routes if row['packed']),packed_bytes=sum(row['packed_bytes'] for row in routes));records.append(rec);print(rec,flush=True)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(source_fingerprint=m['source_fingerprint'],cpu=cpu,threads=1,host=os.uname().nodename,scope='Explanatory route profile, one complete run per input with independent uninstrumented same-source comparison. All full bases and counters must agree; successful build-call counts must equal matrixCalls. Instrumented runs excluded from timing estimates; no filtering or unchanged timing rerun. Fresh detached profiling build, only pinned package cache shared; same relocatable SDK compiler helper. Wrapper snapshots the input column count before transferring ownership, and reads only the returned Except/ColumnMap tags and packed payload size.',profile_binary_sha256=hashlib.sha256((checkout/'.lake/build/bin/column_profile').read_bytes()).hexdigest(),records=records),indent=2)+'\n');lease.close()
shutil.copy2(__file__,out/'profile.py')
