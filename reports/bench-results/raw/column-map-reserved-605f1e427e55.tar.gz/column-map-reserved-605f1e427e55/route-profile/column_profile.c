#include <lean/lean.h>
#include <stdio.h>
#include <stdlib.h>
extern lean_obj_res __real_lp_Hex_Hex_Groebner_ColumnMap_build(lean_obj_arg,lean_obj_arg,lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lp_Hex_Hex_Groebner_ColumnMap_build(lean_obj_arg limits,lean_obj_arg columns,lean_obj_arg workspace) {
 size_t n=lean_array_size(columns);
 lean_object *result=__real_lp_Hex_Hex_Groebner_ColumnMap_build(limits,columns,workspace);
 lean_object *value=lean_ctor_get(result,0);const char *path=getenv("HEX_GROEBNER_COLUMN_PROFILE");
 if(path) {FILE *file=fopen(path,"a");if(file) {
  if(lean_obj_tag(value)==1) {
   lean_object *map=lean_ctor_get(value,0);int packed=lean_obj_tag(map)==0;
   size_t bytes=packed?lean_sarray_size(lean_ctor_get(map,0)):0;
   fprintf(file,"{\"columns\":%zu,\"packed\":%s,\"packed_bytes\":%zu}\n",n,packed?"true":"false",bytes);
  } else fprintf(file,"{\"columns\":%zu,\"error\":true}\n",n);
  fclose(file);
 }}
 return result;
}
