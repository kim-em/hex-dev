/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

public import HexGroebner.Runtime

public section

namespace Hex.Groebner

/-- A matrix column map. Dense identifier intervals use packed u32 positions
plus one; sparse intervals retain the hash map. Zero denotes absence. -/
inductive ColumnMap where
  | packed (positions : ByteArray)
  | hashed (positions : Std.HashMap Nat Nat)

namespace ColumnMap

@[inline] def get? (positions : @& ColumnMap) (id : Nat) : Option Nat :=
  match positions with
  | .hashed positions => positions[id]?
  | .packed positions =>
    if id >= positions.size / 4 then none else
    let value := (Packed.read .u32 positions id).toNat
    if value == 0 then none else some (value - 1)

@[inline] def getD (positions : @& ColumnMap) (id fallback : Nat) : Nat :=
  (positions.get? id).getD fallback

/-- Encode a polynomial support in the fixed matrix columns. Packed maps use
bounded native slices; the scalar model and hash-map route preserve the same
missing-ID behavior and ignore unused trailing support bytes. -/
def encode (positions : @& ColumnMap) (support : @& ByteArray) (native : Bool) :
    Option ByteArray := Id.run do
  let mut output := ByteArray.emptyWithCapacity support.size
  match positions with
  | .packed positions =>
    let count := support.size / 4
    for chunk in [:(count + 4095) / 4096] do
      let start := chunk * 4096
      let size := min 4096 (count - start)
      let result := if native then Native.Columns.remap positions support start size output
        else Native.Columns.remapPortable positions support start size output
      let some next := result | return none
      output := next
  | .hashed positions =>
    for i in [:support.size / 4] do
      let id := (Packed.read .u32 support i).toNat
      let some column := positions[id]? | return none
      if column >= 4294967296 then return none
      output := Packed.push .u32 output column.toUInt64
  return some output

/-- Build a column map with at most eight packed slots per column. Geometry
alone selects the layout; initialization and packed payload are charged before
allocation. Increasing an allowance cannot change the chosen layout or charges.
Repeated identifiers keep the final position, as for `HashMap.insert`. -/
def build (limits : Limits) (columns : Array Nat) : Computation ColumnMap := do
  Computation.spend limits columns.size
  let count := columns.foldl (fun count id => max count (id + 1)) 0
  if columns.size < 4294967296 && count <= columns.size * 8 && count * 4 < USize.size then
    Computation.spend limits (count + columns.size)
    Computation.allocate limits (count * 4)
    let mut positions := ByteArray.emptyWithCapacity (count * 4)
    for _ in [:count] do positions := Packed.push .u32 positions 0
    for i in [:columns.size] do
      positions := Packed.set .u32 positions columns[i]! (i + 1).toUInt64
    return .packed positions
  else
    Computation.spend limits columns.size
    let mut positions : Std.HashMap Nat Nat := {}
    for i in [:columns.size] do positions := positions.insert columns[i]! i
    return .hashed positions

end ColumnMap
end Hex.Groebner
