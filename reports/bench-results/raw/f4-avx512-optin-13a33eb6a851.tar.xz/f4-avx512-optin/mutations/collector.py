from pathlib import Path
import hashlib,json,resource,shutil,subprocess
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');out=state/'avx512-boundary-mutants';out.mkdir(exist_ok=False)
cc='/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang';header=(root/'HexGroebner/ffi/matrix_avx512.h').read_text();results=[]
mutants=[('column-bound',' || (uint64_t)last>=column_count',''),('gather-headroom','< 4/width','< (4/width-1)'),('previous-column','if(previous>=(uint32_t)first) return 0;','(void)previous;'),('zero-coefficient',' & _mm512_cmpgt_epi32_mask(b,_mm512_setzero_si512())',''),('high-bit-coefficient','_mm512_cmpgt_epi32_mask(b,_mm512_setzero_si512())','_mm512_cmpneq_epi32_mask(b,_mm512_setzero_si512())'),('mode-guard','    if(mersenne && (width!=4 || p!=INT32_MAX)) return 0;\n','')]
def no_core():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
for name,old,new in mutants:
 assert header.count(old)==1,name
 directory=out/name;directory.mkdir();(directory/'matrix_avx512.h').write_text(header.replace(old,new))
 for file in ['matrix_simd.h','matrix_avx512_selftest.c']:shutil.copy2(root/'HexGroebner/ffi'/file,directory/file)
 binary=directory/'test';command=[cc,'-O2','-std=c11','-Wall','-Wextra','-Werror',str(directory/'matrix_avx512_selftest.c'),'-o',str(binary)]
 with(directory/'compile.log').open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,name
 with(directory/'stdout').open('w')as stdout,(directory/'stderr').open('w')as stderr:r=subprocess.run([str(binary)],stdout=stdout,stderr=stderr,preexec_fn=no_core)
 assert r.returncode!=0,name
 results.append(dict(name=name,old=old,new=new,compile=command,exit_code=r.returncode,source_header_sha256=hashlib.sha256(header.encode()).hexdigest(),test_sha256=hashlib.sha256((directory/'matrix_avx512_selftest.c').read_bytes()).hexdigest()));(out/'status.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
shutil.copy2(__file__,out/'collector.py')
