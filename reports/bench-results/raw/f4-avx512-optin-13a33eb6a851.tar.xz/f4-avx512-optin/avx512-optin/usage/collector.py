from pathlib import Path
import hashlib,json,shutil
s=Path('/home/kim/tmp/issue-10987');base=s/'avx512-optin-production';out=base/'usage';out.mkdir(exist_ok=False);metadata=json.loads((base/'f4/metadata.json').read_text());records=[]
for cc in ['clang','gcc']:
 project=s/('avx512-optin-'+cc);target=out/cc;target.mkdir();binary=project/'.lake/build/bin/usage';digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 for case in sorted({sample['case']for sample in metadata['samples']}):
  prefix=project/'usage-results'/(case+'-false');actual=json.loads(prefix.with_suffix('.stdout').read_text());expected=json.loads((base/'f4'/(case+'-b0-B.stdout')).read_text());actual.pop('candidateNanos');expected.pop('candidateNanos');assert actual==expected
  counters=json.loads(prefix.with_suffix('.stderr').read_text());assert int(counters['avx512Packets'])>0
  for suffix in ['.stdout','.stderr','.command.json']:shutil.copy2(prefix.with_suffix(suffix),target/(case+suffix))
  records.append(dict(case=case,compiler=cc,exit_code=0,input_sha256=metadata['input_sha256'][case+'.json'],binary_sha256=digest,counters=counters))
 for name in ['Usage.lean','probe.c','lakefile.lean','lake-manifest.json','lean-toolchain']:shutil.copy2(project/name,target/name)
(out/'metadata.json').write_text(json.dumps(records,indent=2)+'\n');shutil.copy2(__file__,out/'collector.py');print('retained28instrumentedreplays;allnon-timeoutputsagree')
