from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
state=Path('/home/kim/tmp/issue-10987');base=state/'avx512-optin-production';old=state/'avx512-default-production'
spec=importlib.util.spec_from_file_location('cpu_lease',base/'root-sources/scripts/bench/cpu_lease.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
manifests={arm:json.loads((path/'manifest.json').read_text())for arm,path in [('A',old),('B',base)]};binaries={'A':old/'binaries/bench','B':base/'binaries/bench'}
digests={arm:hashlib.sha256(path.read_bytes()).hexdigest()for arm,path in binaries.items()};assert all(digests[a]==m['binary_sha256']['bench']for a,m in manifests.items())
cpu,lease=module.cpu_lease();samples=[];out=base/'kernels';out.mkdir(exist_ok=False)
def run(label,arm,function,extra):
 directory=out/label;directory.mkdir(parents=True)
 command=[str(binaries[arm]),'run','Hex.Groebner.Bench.'+function,*extra,'--target-inner-nanos','1000000000','--export-file',str(directory/'result.json')]
 start=time.time_ns();load=os.getloadavg()
 with(directory/'stdout').open('wb')as stdout,(directory/'stderr').open('wb')as stderr:
  result=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=lambda:os.sched_setaffinity(0,{cpu}),env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
 record=dict(label=label,arm=arm,function=function,command=command,exit_code=result.returncode,started_ns=start,finished_ns=time.time_ns(),cpu=cpu,load_start=load,load_end=os.getloadavg());samples.append(record)
 (directory/'metadata.json').write_text(json.dumps(record,indent=2)+'\n');(base/'kernel-status.json').write_text(json.dumps(dict(manifest=manifests,binary_sha256=digests,binary_sha256_after={a:hashlib.sha256(p.read_bytes()).hexdigest()for a,p in binaries.items()},samples=samples,host=os.uname().nodename,threads=1,fields=[32003,2147483647]),indent=2)+'\n');print(label,result.returncode,flush=True)
 if result.returncode not in [0,2]:raise SystemExit(result.returncode)
shapes=[('u16-dense','cauchy16',[64,128,256,512]),('u16-strided','cauchy16Strided',[64,128,256,512]),('m31-dense','cauchy31',[64,128,256,512]),('m31-strided','cauchy31Strided',[64,128,256,512])]
try:
 for shape,function,sizes in shapes:
  for arm in ['A','B']:run(f'complexity/{shape}/{arm}',arm,function,['--outer-trials','3'])
 for block in [0,1]:
  for shape,function,sizes in shapes:
   for n in sizes:
    for arm in (['A','B']if block==0 else['B','A']):run(f'matched/{shape}/b{block}-{n}-{arm}',arm,function,['--outer-trials','1','--param-schedule','doubling','--param-floor',str(n),'--param-ceiling',str(n)])
finally:lease.close();(base/'measure-kernels.py').write_bytes(Path(__file__).read_bytes())
