from pathlib import Path
import hashlib,json,os,subprocess,time
s=Path('/home/kim/tmp/issue-10987');project=s/'avx512-optin-clang';header=Path.cwd()/'HexGroebner/ffi/matrix_avx512.h';original=header.read_bytes();obj=project/'.lake/build/Native.o';records=[];env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR=str(s))
assert str(header) in (project/'lakefile.lean').read_text()
def run(label):
 before=obj.stat().st_mtime_ns
 with(s/f'avx512-cache-{label}.log').open('w')as out:r=subprocess.run(['lake','build','probeNative'],cwd=project,env=env,stdout=out,stderr=subprocess.STDOUT)
 assert r.returncode==0
 row=dict(label=label,mtime_before=before,mtime_after=obj.stat().st_mtime_ns,object_sha256=hashlib.sha256(obj.read_bytes()).hexdigest());records.append(row)
try:
 run('unchanged');assert records[-1]['mtime_before']==records[-1]['mtime_after']
 header.write_bytes(original+b'\n/* Header dependency regression probe. */\n');run('header-change');assert records[-1]['mtime_before']!=records[-1]['mtime_after']
finally:header.write_bytes(original)
run('restored');assert records[-1]['mtime_before']!=records[-1]['mtime_after'];assert records[-1]['object_sha256']==records[0]['object_sha256']
assert header.read_bytes()==original
(s/'avx512-cache-status.json').write_text(json.dumps(records,indent=2)+'\n');print('unchanged cached; header change and restore rebuilt; restored object hash identical')
