/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

public import HexGroebner.Runtime

public section

namespace Hex.Groebner

/-- Matrix column lookup by stable monomial ID. Compact spans use unboxed
32-bit slots with zero denoting absence; sparse spans retain exact hash lookup. -/
inductive ColumnMap where
  | dense (slots : ByteArray)
  | sparse (positions : Std.HashMap Nat Nat)

namespace ColumnMap

/-- Construct a column map, retaining the last position for duplicate IDs.
The dense route reserves all payload and initialization work before allocation.
It is used only for spans at most four times the number of columns and when
remaining parent allowances can pay its initialization. -/
def build (limits : Limits) (columns : Array Nat) : Computation ColumnMap := do
  Computation.spend limits (2 * columns.size)
  let capacity := columns.foldl (fun n id => max n (id+1)) 0
  let state ← get
  let dense := capacity > 0 && capacity ≤ 4 * columns.size &&
    columns.size < 4294967296 && 4 * capacity < USize.size &&
    state.statistics.work + capacity ≤ limits.work &&
    state.statistics.allocatedBytes + state.table.bytes + 4 * capacity ≤ limits.packedBytes
  if dense then
    Computation.spend limits capacity
    Computation.allocate limits (4 * capacity)
    let mut slots := ByteArray.emptyWithCapacity (4 * capacity)
    for _ in [:capacity] do slots := Packed.push .u32 slots 0
    for i in [:columns.size] do slots := Packed.set .u32 slots columns[i]! (i+1).toUInt64
    return .dense slots
  else
    let mut positions : Std.HashMap Nat Nat := {}
    for i in [:columns.size] do positions := positions.insert columns[i]! i
    return .sparse positions

/-- Exact lookup, with the same missing-ID behavior in both representations. -/
@[inline] def get? (positions : @& ColumnMap) (id : Nat) : Option Nat :=
  match positions with
  | .sparse positions => positions[id]?
  | .dense slots =>
    if id ≥ slots.size / 4 then none else
      let value := (Packed.read .u32 slots id).toNat
      if value == 0 then none else some (value-1)

/-- Translate a packed polynomial support, with bounded native calls for the
compact map and the original exact lookup for sparse spans. -/
def translate (positions : @& ColumnMap) (support : @& ByteArray) (native := true) : Option ByteArray := Id.run do
  let mut output := ByteArray.emptyWithCapacity support.size
  match positions with
  | .dense slots =>
    for block in [:((support.size/4+4095)/4096)] do
      let start := 4096*block
      let count := min 4096 (support.size/4-start)
      let some next := (if native then Native.Columns.append slots support start count output
        else Native.Columns.appendPortable slots support start count output) | return none
      output := next
  | .sparse _ =>
    for i in [:support.size/4] do
      let some column := positions.get? (Packed.read .u32 support i).toNat | return none
      output := Packed.push .u32 output column.toUInt64
  return some output

end ColumnMap
end Hex.Groebner
