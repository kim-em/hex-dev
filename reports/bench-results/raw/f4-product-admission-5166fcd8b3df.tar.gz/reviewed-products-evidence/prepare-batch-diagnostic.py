from pathlib import Path
p=Path('/home/kim/tmp/issue-10987/admission-counts.py');s=p.read_text().replace('hex-dev-issue-10987-review','hex-dev-issue-10987-products').replace("base=Path('/home/kim/tmp/issue-10987/review-production')","base=Path('/home/kim/tmp/issue-10987/adaptive-production')").replace("out=Path('/home/kim/tmp/issue-10987/admission-counts')","out=Path('/home/kim/tmp/issue-10987/adaptive-admission-counts')")
a=s.index("c=r'''")+6;b=s.index("'''",a);c=s[a:b];needle='static uint64_t va,vd,za,zd,ma,md;';insert=r'''
static uint64_t ba,bt,bd,bw,bpeak,berrors;
#define HEX_GROEBNER_NO_LEAN
#include "HexGroebner/ffi/row_update.c"
#undef HEX_GROEBNER_NO_LEAN
#define HEX_GROEBNER_HIT_HELPERS
#define HEX_GROEBNER_PRODUCTS_FOUND(n) (++ba,bt+=(n))
#define HEX_GROEBNER_PRODUCTS_DEFERRED(w) (++bd,bw+=(w),bpeak=bpeak>(w)?bpeak:(w),berrors+=((w)>4096))
#define lean_hex_groebner_combine_owned hex_diagnostic_combine_owned
#define lean_hex_monomial_products_attempt hex_diagnostic_products_attempt
#include "HexGroebner/ffi/monomial_hit.c"
#undef lean_hex_groebner_combine_owned
#undef lean_hex_monomial_products_attempt
LEAN_EXPORT lean_obj_res __wrap_lean_hex_monomial_products_attempt(lean_obj_arg table,
 b_lean_obj_arg support,lean_obj_arg monomial,lean_obj_arg start,lean_obj_arg count,
 lean_obj_arg max_count,lean_obj_arg max_bytes,lean_obj_arg max_work,uint8_t native) {
 return hex_diagnostic_products_attempt(table,support,monomial,start,count,max_count,max_bytes,max_work,native);
}
''';c=c.replace(needle,needle+insert);c=c[:c.index('__attribute__((destructor))')]+r'''__attribute__((destructor)) static void counts(void) {
 fprintf(stderr,"HEX_MATRIX_ADMISSION {\"validation_admitted\":%llu,\"validation_declined\":%llu,\"zero_admitted\":%llu,\"zero_declined\":%llu,\"bulk_admitted\":%llu,\"bulk_declined\":%llu,\"batch_admitted\":%llu,\"batch_terms\":%llu,\"batch_deferred\":%llu,\"discarded_visit_reservations\":%llu,\"peak_discarded\":%llu,\"bound_errors\":%llu}\n",(unsigned long long)va,(unsigned long long)vd,(unsigned long long)za,(unsigned long long)zd,(unsigned long long)ma,(unsigned long long)md,(unsigned long long)ba,(unsigned long long)bt,(unsigned long long)bd,(unsigned long long)bw,(unsigned long long)bpeak,(unsigned long long)berrors);
}
''';s=s[:a]+c+s[b:];s=s.replace('"-Wl,--wrap=lean_hex_groebner_eliminate_matrix"]','"-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_monomial_products_attempt"]');s=s.replace('Untimed admission diagnostic, one invocation','Untimed batch and matrix admission diagnostic, one invocation');s=s.replace("assert results['normal']==results['instrumented'],name;","assert results['normal']==results['instrumented'],name;assert counts['bound_errors']==0 and counts['peak_discarded']<=4096;");Path('/home/kim/tmp/issue-10987/batch-admission-counts.py').write_text(s)
