from pathlib import Path
import json,os,subprocess,hashlib,sys
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products');state=Path('/home/kim/tmp/issue-10987');base=state/'adaptive-production';build=json.loads((base/'bench-binaries/builds.json').read_text());binary=base/'bench-binaries/frame';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256'];sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
out=base/'kernel-paired';out.mkdir(exist_ok=False);cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[];analysis={}
try:
 for family,reference,batch,arity in [('hits','monomialProductsReference','monomialProducts',3),('misses','productMissesReference','productMisses',3),('wide','productWideReference','productWide',22)]:
  folder=out/family;folder.mkdir();points={a:[] for a in 'AB'};data={}
  for block,order in enumerate(['AB','BA']):
   for arm in order:
    name=reference if arm=='A' else batch;prefix=f'block{block}-{arm}';command=[str(binary),'run','Hex.Groebner.Bench.'+name,'--outer-trials','1','--export-file',str(folder/(prefix+'.json'))]
    with(folder/(prefix+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
    runs.append(dict(family=family,arity=arity,block=block,arm=arm,command=command,returncode=r.returncode));assert r.returncode in [0,2];v=json.loads((folder/(prefix+'.json')).read_text())['results'][0];assert len(v['points'])==5 and all(x['status']=='ok' for x in v['points']);points[arm]+=v['points'];data[block,arm]={x['param']:x for x in v['points']};print(family,prefix,v['verdict'],flush=True)
  rows=[]
  for n in [256,512,1024,2048,4096]:
   assert len({p['result_hash'] for ps in points.values() for p in ps if p['param']==n})==1
   rows.append(dict(n=n,ratios=[data[b,'B'][n]['per_call_nanos']/data[b,'A'][n]['per_call_nanos'] for b in [0,1]],all_hashes_equal=True))
  analysis[family]=rows;(out/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),build=build,runs=runs,scope='First matched whole-sweep AB/BA scalar-native versus batch-native comparisons in one fresh source88dc2e32d9ca executable. Arity3 existing hits; arity3 distinct last-term misses in every complete64term slice; arity22 existing hits with adaptive58term slices. Five sizes256..4096. Prepared tables excluded, output assembly and independent ID validation included. Complete output support/final workspace/count/work consumed for hits and wide; all changed arenas/metadata/index bytes also consumed for misses. Automatic CPU lease, every completed sample/RSS/floor/host context retained. Separate families, no filtering/no unchanged repeat. Not fullF4/certification/nativeverification/kernelcheck timings.'),indent=2)+'\n');lease.close()
(out/'measure.py').write_bytes(Path(__file__).read_bytes())
