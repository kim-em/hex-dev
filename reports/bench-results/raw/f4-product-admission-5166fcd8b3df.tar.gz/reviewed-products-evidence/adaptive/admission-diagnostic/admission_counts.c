#include <lean/lean.h>
#include <stdio.h>
#include <stdint.h>
static uint64_t va,vd,za,zd,ma,md;
static uint64_t ba,bt,bd,bw,bpeak,berrors;
#define HEX_GROEBNER_NO_LEAN
#include "HexGroebner/ffi/row_update.c"
#undef HEX_GROEBNER_NO_LEAN
#define HEX_GROEBNER_HIT_HELPERS
#define HEX_GROEBNER_PRODUCTS_FOUND(n) (++ba,bt+=(n))
#define HEX_GROEBNER_PRODUCTS_DEFERRED(w) (++bd,bw+=(w),bpeak=bpeak>(w)?bpeak:(w),berrors+=((w)>4096))
#define lean_hex_groebner_combine_owned hex_diagnostic_combine_owned
#define lean_hex_monomial_products_attempt hex_diagnostic_products_attempt
#include "HexGroebner/ffi/monomial_hit.c"
#undef lean_hex_groebner_combine_owned
#undef lean_hex_monomial_products_attempt
LEAN_EXPORT lean_obj_res __wrap_lean_hex_monomial_products_attempt(lean_obj_arg table,
 b_lean_obj_arg support,lean_obj_arg monomial,lean_obj_arg start,lean_obj_arg count,
 lean_obj_arg max_count,lean_obj_arg max_bytes,lean_obj_arg max_work,uint8_t native) {
 return hex_diagnostic_products_attempt(table,support,monomial,start,count,max_count,max_bytes,max_work,native);
}

extern lean_obj_res __real_lean_hex_matrix_validate(uint64_t,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_validate(uint64_t p,b_lean_obj_arg limits,b_lean_obj_arg cols,b_lean_obj_arg index,b_lean_obj_arg row,b_lean_obj_arg stats) {
 lean_object *r=__real_lean_hex_matrix_validate(p,limits,cols,index,row,stats);
 if(lean_is_scalar(r))++vd;else ++va;return r;
}
extern lean_obj_res __real_lean_hex_matrix_zeros(b_lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_zeros(b_lean_obj_arg n) {
 lean_object *r=__real_lean_hex_matrix_zeros(n);if(lean_is_scalar(r))++zd;else ++za;return r;
}
extern lean_obj_res __real_lean_hex_groebner_eliminate_matrix(uint64_t,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,uint8_t);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_eliminate_matrix(uint64_t p,b_lean_obj_arg limits,b_lean_obj_arg cols,b_lean_obj_arg rs,b_lean_obj_arg ts,b_lean_obj_arg sugars,uint8_t independent) {
 lean_object *r=__real_lean_hex_groebner_eliminate_matrix(p,limits,cols,rs,ts,sugars,independent);
 if(lean_is_scalar(r))++md;else ++ma;return r;
}
__attribute__((destructor)) static void counts(void) {
 fprintf(stderr,"HEX_MATRIX_ADMISSION {\"validation_admitted\":%llu,\"validation_declined\":%llu,\"zero_admitted\":%llu,\"zero_declined\":%llu,\"bulk_admitted\":%llu,\"bulk_declined\":%llu,\"batch_admitted\":%llu,\"batch_terms\":%llu,\"batch_deferred\":%llu,\"discarded_visit_reservations\":%llu,\"peak_discarded\":%llu,\"bound_errors\":%llu}\n",(unsigned long long)va,(unsigned long long)vd,(unsigned long long)za,(unsigned long long)zd,(unsigned long long)ma,(unsigned long long)md,(unsigned long long)ba,(unsigned long long)bt,(unsigned long long)bd,(unsigned long long)bw,(unsigned long long)bpeak,(unsigned long long)berrors);
}
