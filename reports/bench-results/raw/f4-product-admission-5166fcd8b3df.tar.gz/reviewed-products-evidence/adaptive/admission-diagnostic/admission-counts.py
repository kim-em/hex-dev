from pathlib import Path
import os,json,time,hashlib,subprocess,shutil,tarfile
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products');base=Path('/home/kim/tmp/issue-10987/adaptive-production');out=Path('/home/kim/tmp/issue-10987/adaptive-admission-counts')
while not(base/'manifest.json').is_file():time.sleep(10)
out.mkdir(exist_ok=True);m=json.loads((base/'manifest.json').read_text());checkout=out/'source'
if not checkout.exists():
 subprocess.run(['git','worktree','add','--detach',str(checkout),m['source_snapshot']],cwd=root,check=True,capture_output=True);(checkout/'.lake').mkdir();(checkout/'.lake/packages').symlink_to((root/'.lake/packages').resolve(),target_is_directory=True)
c=r'''#include <lean/lean.h>
#include <stdio.h>
#include <stdint.h>
static uint64_t va,vd,za,zd,ma,md;
static uint64_t ba,bt,bd,bw,bpeak,berrors;
#define HEX_GROEBNER_NO_LEAN
#include "HexGroebner/ffi/row_update.c"
#undef HEX_GROEBNER_NO_LEAN
#define HEX_GROEBNER_HIT_HELPERS
#define HEX_GROEBNER_PRODUCTS_FOUND(n) (++ba,bt+=(n))
#define HEX_GROEBNER_PRODUCTS_DEFERRED(w) (++bd,bw+=(w),bpeak=bpeak>(w)?bpeak:(w),berrors+=((w)>4096))
#define lean_hex_groebner_combine_owned hex_diagnostic_combine_owned
#define lean_hex_monomial_products_attempt hex_diagnostic_products_attempt
#include "HexGroebner/ffi/monomial_hit.c"
#undef lean_hex_groebner_combine_owned
#undef lean_hex_monomial_products_attempt
LEAN_EXPORT lean_obj_res __wrap_lean_hex_monomial_products_attempt(lean_obj_arg table,
 b_lean_obj_arg support,lean_obj_arg monomial,lean_obj_arg start,lean_obj_arg count,
 lean_obj_arg max_count,lean_obj_arg max_bytes,lean_obj_arg max_work,uint8_t native) {
 return hex_diagnostic_products_attempt(table,support,monomial,start,count,max_count,max_bytes,max_work,native);
}

extern lean_obj_res __real_lean_hex_matrix_validate(uint64_t,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_validate(uint64_t p,b_lean_obj_arg limits,b_lean_obj_arg cols,b_lean_obj_arg index,b_lean_obj_arg row,b_lean_obj_arg stats) {
 lean_object *r=__real_lean_hex_matrix_validate(p,limits,cols,index,row,stats);
 if(lean_is_scalar(r))++vd;else ++va;return r;
}
extern lean_obj_res __real_lean_hex_matrix_zeros(b_lean_obj_arg);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_zeros(b_lean_obj_arg n) {
 lean_object *r=__real_lean_hex_matrix_zeros(n);if(lean_is_scalar(r))++zd;else ++za;return r;
}
extern lean_obj_res __real_lean_hex_groebner_eliminate_matrix(uint64_t,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,b_lean_obj_arg,uint8_t);
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_eliminate_matrix(uint64_t p,b_lean_obj_arg limits,b_lean_obj_arg cols,b_lean_obj_arg rs,b_lean_obj_arg ts,b_lean_obj_arg sugars,uint8_t independent) {
 lean_object *r=__real_lean_hex_groebner_eliminate_matrix(p,limits,cols,rs,ts,sugars,independent);
 if(lean_is_scalar(r))++md;else ++ma;return r;
}
__attribute__((destructor)) static void counts(void) {
 fprintf(stderr,"HEX_MATRIX_ADMISSION {\"validation_admitted\":%llu,\"validation_declined\":%llu,\"zero_admitted\":%llu,\"zero_declined\":%llu,\"bulk_admitted\":%llu,\"bulk_declined\":%llu,\"batch_admitted\":%llu,\"batch_terms\":%llu,\"batch_deferred\":%llu,\"discarded_visit_reservations\":%llu,\"peak_discarded\":%llu,\"bound_errors\":%llu}\n",(unsigned long long)va,(unsigned long long)vd,(unsigned long long)za,(unsigned long long)zd,(unsigned long long)ma,(unsigned long long)md,(unsigned long long)ba,(unsigned long long)bt,(unsigned long long)bd,(unsigned long long)bw,(unsigned long long)bpeak,(unsigned long long)berrors);
}
'''
(checkout/'admission_counts.c').write_text(c);lake=subprocess.check_output(['git','show',m['source_snapshot']+':lakefile.lean'],cwd=root,text=True);decl='''target hexgroebnerAdmissionO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "admission_counts.c")
  buildO (pkg.dir / defaultBuildDir / "admission_counts.o") source
    #["-I", (← getLeanIncludeDir).toString] #["-O3", "-fPIC"]

''';lake=lake.replace('lean_exe hexgroebner_compute where',decl+'lean_exe hexgroebner_compute where',1).replace('moreLinkObjs := #[hexgroebnerInitialize]','moreLinkObjs := #[hexgroebnerInitialize,hexgroebnerAdmissionO]\n  moreLinkArgs := #["-Wl,--wrap=lean_hex_matrix_validate", "-Wl,--wrap=lean_hex_matrix_zeros", "-Wl,--wrap=lean_hex_groebner_eliminate_matrix", "-Wl,--wrap=lean_hex_monomial_products_attempt"]',1);(checkout/'lakefile.lean').write_text(lake);shutil.copy2(checkout/'admission_counts.c',out/'admission_counts.c');shutil.copy2(checkout/'lakefile.lean',out/'instrumented-lakefile.lean')
env=dict(os.environ,LEAN_CC='/home/kim/tmp/issue-10987/issue-10987-lean-cc',TMPDIR='/home/kim/tmp/issue-10987',PATH='/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin:'+os.environ['PATH'],OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
with(out/'build.log').open('w')as f:r=subprocess.run(['lake','build','hexgroebner_compute'],cwd=checkout,env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0;instrumented=checkout/'.lake/build/bin/hexgroebner_compute';normal=base/'binaries/compute';assert hashlib.sha256(normal.read_bytes()).hexdigest()==m['binary_sha256']['compute']
archive=root/'reports/bench-results/raw/matrix-primitives-portable-16c437c35eac.tar.gz';observations=[]
with tarfile.open(archive)as tar:
 for suite in ['small','medium']:
  name=next(n for n in tar.getnames()if n.endswith('/before-after-'+suite+'/metadata.json'));metadata=json.load(tar.extractfile(name));cases={}
  for sample in metadata['samples']:cases.setdefault(sample['case'],sample)
  folder=out/suite;folder.mkdir(exist_ok=True)
  for name,sample in cases.items():
   member=next(n for n in tar.getnames()if n.endswith('/before-after-'+suite+'/inputs/'+name+'.json'));data=tar.extractfile(member).read();input_file=folder/(name+'.json');input_file.write_bytes(data);arguments=sample['command'][6:-1]+[str(input_file)]
   results={};counts=None
   for arm,binary in [('normal',normal),('instrumented',instrumented)]:
    cmd=[str(binary),*arguments];p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,timeout=300);(folder/(name+'-'+arm+'.stdout')).write_text(p.stdout);(folder/(name+'-'+arm+'.stderr')).write_text(p.stderr);assert p.returncode==0,(name,arm,p.returncode,p.stderr)
    value=json.loads(p.stdout);assert value.get('kind')=='unchecked_candidate',(name,arm,value);value.pop('candidateNanos',None);results[arm]=value
    if arm=='instrumented':
     line=next(x for x in p.stderr.splitlines()if x.startswith('HEX_MATRIX_ADMISSION '));counts=json.loads(line.split(' ',1)[1])
   assert results['normal']==results['instrumented'],name;assert counts['bound_errors']==0 and counts['peak_discarded']<=4096;observations.append(dict(suite=suite,case=name,counts=counts,complete_basis_and_counters_equal=True));print(suite,name,counts,flush=True)
records=dict(source_fingerprint=m['source_fingerprint'],source_snapshot=m['source_snapshot'],source_commit=m['commit'],normal_binary_sha256=hashlib.sha256(normal.read_bytes()).hexdigest(),instrumented_binary_sha256=hashlib.sha256(instrumented.read_bytes()).hexdigest(),scope='Untimed batch and matrix admission diagnostic, one invocation per unique case of retained small/medium timing-suite inputs; normal versus link-wrapped driver, identical complete basis/metadata/resource counters after removing candidateNanos only. Per-process counts include both standalone primitives and bulk matrices. No timing or coverage-leadership claim. All commands/inputs/outputs retained.',observations=observations,totals={s:{k:sum(x['counts'][k]for x in observations if x['suite']==s)for k in observations[0]['counts']}for s in['small','medium']})
(out/'results.json').write_text(json.dumps(records,indent=2)+'\n');shutil.copy2(base/'manifest.json',out/'normal-manifest.json');shutil.copy2(__file__,out/'admission-counts.py');print(records['totals'],flush=True)
