#include <assert.h>
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products/HexGroebner/ffi/matrix_runtime.h"
#define lean_hex_groebner_subtract_row hex_test_unused_subtract
#define lean_hex_groebner_remap_columns hex_test_remap
#define lean_hex_groebner_remap_index hex_test_remap_index
#define lean_hex_groebner_append_zeros hex_test_append_zeros
#define lean_hex_groebner_prepare_monomial hex_test_unused_prepare
#define lean_hex_groebner_equal_monomial hex_test_unused_monomial_equal
#define lean_hex_groebner_search_monomial hex_test_search_monomial
#define lean_hex_groebner_equal_bytes hex_test_equal_bytes
#define lean_hex_groebner_equal_products hex_test_equal_products
#define lean_hex_groebner_compare_monomials hex_test_compare
#define lean_hex_groebner_validate_trie hex_test_validate
#define lean_hex_groebner_lookup_trie hex_test_trie
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products/HexGroebner/ffi/row_update.c"
#undef lean_hex_groebner_compare_monomials
#undef lean_hex_groebner_validate_trie
#undef lean_hex_groebner_lookup_trie
#undef lean_hex_groebner_subtract_row
#undef lean_hex_groebner_remap_columns
#undef lean_hex_groebner_remap_index
#undef lean_hex_groebner_append_zeros
#undef lean_hex_groebner_prepare_monomial
#undef lean_hex_groebner_equal_monomial
#undef lean_hex_groebner_search_monomial
#undef lean_hex_groebner_equal_bytes
#undef lean_hex_groebner_equal_products
static uint64_t remap_calls=0;
__typeof__(hex_test_remap) __wrap_lean_hex_groebner_remap_columns;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_remap_columns(
 b_lean_obj_arg positions,b_lean_obj_arg support,b_lean_obj_arg start,
 b_lean_obj_arg count,lean_obj_arg output) {
 ++remap_calls;return hex_test_remap(positions,support,start,count,output);
}
static uint64_t index_calls=0,zero_calls=0;
__typeof__(hex_test_remap_index) __wrap_lean_hex_groebner_remap_index;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_remap_index(
 b_lean_obj_arg slots,b_lean_obj_arg support,b_lean_obj_arg start,
 b_lean_obj_arg count,b_lean_obj_arg probes,lean_obj_arg output) {
 ++index_calls;return hex_test_remap_index(slots,support,start,count,probes,output);
}
__typeof__(hex_test_append_zeros) __wrap_lean_hex_groebner_append_zeros;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_append_zeros(lean_obj_arg output,b_lean_obj_arg count) {
 ++zero_calls;return hex_test_append_zeros(output,count);
}
LEAN_EXPORT lean_obj_res hex_test_index_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(index_calls));
}
LEAN_EXPORT lean_obj_res hex_test_zero_append_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(zero_calls));
}
LEAN_EXPORT lean_obj_res hex_test_remap_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(remap_calls));
}
LEAN_EXPORT lean_obj_res hex_test_remap_aliases(lean_obj_arg world) {
 (void)world;int ok=1;
 for(unsigned linear=0;linear<2;++linear) for(unsigned mode=0;mode<4;++mode)
 for(unsigned test=0;test<4;++test) {
  int fail=test==1 || test==2,observe=test>=2;
  /* A marked output may be a borrowed alias, but cannot have another owner. */
  if(linear && observe) continue;
  lean_object *positions=lean_alloc_sarray(1,12,12),*support=lean_alloc_sarray(1,12,12);
  for(unsigned i=0;i<3;++i) {
   write_le(lean_sarray_cptr(positions)+4*i,4,i+1);
   write_le(lean_sarray_cptr(support)+4*i,4,fail && i==2?777:i);
  }
  uint8_t position_snapshot[12],support_snapshot[12],output_snapshot[12];
  memcpy(position_snapshot,lean_sarray_cptr(positions),12);
  memcpy(support_snapshot,lean_sarray_cptr(support),12);
  lean_object *out=mode==0?support:positions;size_t old=12;
  if(mode>=2) {out=lean_alloc_sarray(1,4,mode==2?4:32);write_le(lean_sarray_cptr(out),4,37);old=4;}
  memcpy(output_snapshot,lean_sarray_cptr(out),old);lean_object *keeper=out;
  if(linear) lean_sarray_mark_linear_core(out);
  if(observe) lean_inc(keeper);
  lean_object *result=hex_test_remap(positions,support,lean_box(0),lean_box(3),out);
  ok=ok && lean_obj_tag(result)==(fail?0:1);
  if(!fail && lean_obj_tag(result)==1) {
   lean_object *bytes=lean_ctor_get(result,0);
   ok=ok && lean_is_exclusive(bytes) && lean_sarray_size(bytes)==old+12;
   if(linear) ok=ok && lean_sarray_is_marked_linear(bytes);
   if(lean_sarray_size(bytes)==old+12) {
    ok=ok && memcmp(lean_sarray_cptr(bytes),output_snapshot,old)==0;
    for(unsigned i=0;i<3;++i) ok=ok && read_le(lean_sarray_cptr(bytes)+old+4*i,4)==i;
   }
   if(observe) ok=ok && lean_sarray_cptr(bytes)!=lean_sarray_cptr(keeper);
  }
  if(observe) {
   ok=ok && lean_is_exclusive(keeper) && lean_sarray_size(keeper)==old;
   ok=ok && memcmp(lean_sarray_cptr(keeper),output_snapshot,old)==0;lean_dec(keeper);
  }
  if(mode!=1) ok=ok && lean_is_exclusive(positions) &&
    memcmp(lean_sarray_cptr(positions),position_snapshot,12)==0;
  if(mode!=0) ok=ok && lean_is_exclusive(support) &&
    memcmp(lean_sarray_cptr(support),support_snapshot,12)==0;
  lean_dec(result);if(mode!=1) lean_dec(positions);if(mode!=0) lean_dec(support);
 }
 return lean_io_result_mk_ok(lean_box(ok));
}
LEAN_EXPORT lean_obj_res hex_test_index_aliases(lean_obj_arg world) {
 (void)world;int ok=1;
 for(unsigned linear=0;linear<2;++linear) for(unsigned mode=0;mode<4;++mode)
 for(unsigned test=0;test<4;++test) {
  int fail=test==1 || test==2,observe=test>=2;
  /* A marked output may be a borrowed alias, but cannot have another owner. */
  if(linear && observe) continue;
  lean_object *slots=lean_alloc_sarray(1,128,128),*support=lean_alloc_sarray(1,12,12);
  memset(lean_sarray_cptr(slots),0,128);
  for(unsigned i=0;i<3;++i) {
   size_t bucket=(size_t)(column_hash(i)&15);
   while(read_le(lean_sarray_cptr(slots)+bucket*8+4,4)) bucket=(bucket+1)&15;
   write_le(lean_sarray_cptr(slots)+bucket*8,4,i);
   write_le(lean_sarray_cptr(slots)+bucket*8+4,4,i+1);
   write_le(lean_sarray_cptr(support)+4*i,4,fail && i==2?777:i);
  }
  uint8_t slot_snapshot[128],support_snapshot[12],output_snapshot[128];
  memcpy(slot_snapshot,lean_sarray_cptr(slots),128);memcpy(support_snapshot,lean_sarray_cptr(support),12);
  lean_object *out=mode==0?support:slots;size_t old=lean_sarray_size(out);
  if(mode>=2) {out=lean_alloc_sarray(1,4,mode==2?4:32);write_le(lean_sarray_cptr(out),4,37);old=4;}
  memcpy(output_snapshot,lean_sarray_cptr(out),old);lean_object *keeper=out;
  if(linear) lean_sarray_mark_linear_core(out);
  if(observe) lean_inc(keeper);
  lean_object *result=hex_test_remap_index(slots,support,lean_box(0),lean_box(3),lean_box(64),out);
  ok=ok && (lean_obj_tag(result)==(fail?0:1));
  if(!fail && lean_obj_tag(result)==1) {
   lean_object *bytes=lean_ctor_get(result,0);
   ok=ok && lean_is_exclusive(bytes) && lean_sarray_size(bytes)==old+12;
   if(linear) ok=ok && lean_sarray_is_marked_linear(bytes);
   if(lean_sarray_size(bytes)==old+12) {
    ok=ok && memcmp(lean_sarray_cptr(bytes),output_snapshot,old)==0;
    for(unsigned i=0;i<3;++i) ok=ok && read_le(lean_sarray_cptr(bytes)+old+4*i,4)==i;
   }
   if(observe) ok=ok && lean_sarray_cptr(bytes)!=lean_sarray_cptr(keeper);
  }
  if(observe) {
   ok=ok && lean_is_exclusive(keeper) && lean_sarray_size(keeper)==old;
   ok=ok && memcmp(lean_sarray_cptr(keeper),output_snapshot,old)==0;lean_dec(keeper);
  }
  if(mode!=1) ok=ok && lean_is_exclusive(slots) && memcmp(lean_sarray_cptr(slots),slot_snapshot,128)==0;
  if(mode!=0) ok=ok && lean_is_exclusive(support) && memcmp(lean_sarray_cptr(support),support_snapshot,12)==0;
  lean_dec(result);if(mode!=1) lean_dec(slots);if(mode!=0) lean_dec(support);
 }
 for(unsigned capacity=4;capacity<=32;capacity*=8) for(unsigned shared=0;shared<2;++shared) {
  lean_object *bytes=lean_alloc_sarray(1,4,capacity);memset(lean_sarray_cptr(bytes),37,4);
  lean_object *keeper=bytes;
  if(shared) lean_inc(keeper);else lean_sarray_mark_linear_core(bytes);
  lean_object *result=hex_test_append_zeros(bytes,lean_box(12));ok=ok && lean_obj_tag(result)==1;
  if(lean_obj_tag(result)==1) {
   bytes=lean_ctor_get(result,0);ok=ok && lean_is_exclusive(bytes) && lean_sarray_size(bytes)==16;
   if(!shared) ok=ok && lean_sarray_is_marked_linear(bytes);
   if(shared) ok=ok && lean_sarray_cptr(bytes)!=lean_sarray_cptr(keeper);
   for(unsigned i=0;i<16;++i) ok=ok && lean_sarray_cptr(bytes)[i]==(i<4?37:0);
  }
  if(shared) {
   ok=ok && lean_is_exclusive(keeper) && lean_sarray_size(keeper)==4;
   for(unsigned i=0;i<4;++i) ok=ok && lean_sarray_cptr(keeper)[i]==37;
   lean_dec(keeper);
  }
  lean_dec(result);
 }
 return lean_io_result_mk_ok(lean_box(ok));
}
static uint64_t batch_hits=0,batch_terms=0,batch_deferrals=0,batch_waste=0,batch_bound_errors=0;
#define HEX_GROEBNER_PRODUCTS_DEFERRED(w) (++batch_deferrals,batch_waste+=(w),batch_bound_errors+=((w)>4096))
#define HEX_GROEBNER_PRODUCTS_FOUND(n) (++batch_hits,batch_terms+=(n))
static uint64_t fused_success=0,fused_insert=0,fused_unique=0,fused_deferred=0,unique_alias=0,unique_alias_mask=0;
#define HEX_GROEBNER_DEFERRED() (++fused_deferred)
#define HEX_GROEBNER_UNIQUE_ALIAS(mask) (++unique_alias,unique_alias_mask|=(mask))
#define HEX_GROEBNER_TABLE_UNIQUE() (++fused_unique)
#define HEX_GROEBNER_INSERT_FOUND() (++fused_insert)
#define HEX_GROEBNER_HIT_FOUND() (++fused_success)
#define HEX_GROEBNER_HIT_HELPERS
#define lean_hex_monomial_products_attempt hex_test_products_attempt
#define lean_hex_groebner_combine_owned hex_test_combine_owned
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products/HexGroebner/ffi/monomial_hit.c"
#undef lean_hex_groebner_combine_owned
#undef lean_hex_monomial_products_attempt
LEAN_EXPORT lean_obj_res hex_test_owned_runtime(lean_obj_arg world) {
 (void)world;int ok=1;
 for(size_t capacity=1;capacity<=8;capacity*=8) {
  lean_object *bytes=lean_alloc_sarray(1,1,capacity);lean_sarray_cptr(bytes)[0]=37;
  lean_sarray_mark_linear_core(bytes);bytes=hit_extend(bytes,2);
  ok=ok && lean_sarray_is_marked_linear(bytes) && lean_sarray_size(bytes)==2 &&
      lean_sarray_cptr(bytes)[0]==37;lean_dec(bytes);
 }
 lean_object *fake=lean_alloc_ctor(0,7,0);
 for(unsigned i=0;i<7;++i) lean_ctor_set(fake,i,lean_box(0));
 lean_object *result=hex_test_combine_owned(fake,0,lean_box(0),lean_box(0),
   lean_box(100),lean_box(10000),lean_box(10000),1);
 ok=ok && lean_obj_tag(result)==1 && lean_ctor_get(result,0)==fake;
 lean_dec(result);
 fake=lean_alloc_ctor(0,8,1);
 for(unsigned i=0;i<8;++i) lean_ctor_set(fake,i,lean_box(0));
 lean_object *index=lean_alloc_ctor(0,1,0);lean_ctor_set(index,0,lean_box(0));
 lean_ctor_set(fake,5,index);lean_ctor_set_uint8(fake,8*sizeof(void*),0);
 result=hex_test_combine_owned(fake,0,lean_box(0),lean_box(0),lean_box(100),
   lean_box(10000),lean_box(10000),1);
 ok=ok && lean_obj_tag(result)==1 && lean_ctor_get(result,0)==fake;lean_dec(result);
 return lean_io_result_mk_ok(lean_box(ok));
}
static uint64_t mersenne_vectors=0,zero_scans=0;
#define HEX_GROEBNER_ZERO_SCAN_USED() (++zero_scans)
#define HEX_GROEBNER_MERSENNE_USED() (++mersenne_vectors)
#define hex_scan8 hex_test_scan8_base
#define hex_scan8_m31 hex_test_scan8_m31_base
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products/HexGroebner/ffi/matrix_simd.h"
#undef hex_scan8
#undef hex_scan8_m31
static uint64_t vector_contiguous=0,vector_gather=0;
static uint32_t vector_widths=0;
#if HEX_GROEBNER_AVX2
static __typeof__(hex_test_scan8_base) hex_test_scan8_counted;
__attribute__((target("avx2"),always_inline))
static inline unsigned hex_test_scan8_counted(uint8_t *dense,const uint8_t *columns,
 const uint8_t *coefficients,size_t entry,uint64_t column_count,uint32_t p,
 uint32_t multiplier,uint32_t reduction,unsigned width) {
 unsigned n=hex_test_scan8_base(dense,columns,coefficients,entry,column_count,p,multiplier,reduction,width);
 if(n) {uint32_t first,last;memcpy(&first,columns+entry*4,4);memcpy(&last,columns+(entry+7)*4,4);
  if(last-first==7) ++vector_contiguous;else ++vector_gather;
  unsigned group=width==1?0:width==2?1:2;
  vector_widths|=1u<<(2*group+(last-first!=7));}
 return n;
}
__attribute__((target("avx2"),always_inline))
static inline unsigned hex_test_scan8_m31_counted(uint8_t *dense,const uint8_t *columns,
 const uint8_t *coefficients,size_t entry,uint64_t column_count,uint32_t p,
 uint32_t multiplier,uint32_t reduction,unsigned width) {
 unsigned n=hex_test_scan8_m31_base(dense,columns,coefficients,entry,column_count,p,multiplier,reduction,width);
 if(n) {uint32_t first,last;memcpy(&first,columns+entry*4,4);memcpy(&last,columns+(entry+7)*4,4);
  if(last-first==7) ++vector_contiguous;else ++vector_gather;
  unsigned group=3;
  vector_widths|=1u<<(2*group+(last-first!=7));}
 return n;
}
#define hex_scan8 hex_test_scan8_counted
#define hex_scan8_m31 hex_test_scan8_m31_counted
#endif
#define lean_hex_scan_transition hex_test_scan
#define lean_hex_gather hex_test_gather
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products/HexGroebner/ffi/matrix_scan.c"
#undef lean_hex_scan_transition
#undef lean_hex_gather
static uint64_t whole_accepted=0,whole_deferred=0,whole_joint=0,whole_independent=0;
#define HEX_GROEBNER_MATRIX_ACCEPTED() (++whole_accepted,independent?++whole_independent:++whole_joint)
#define HEX_GROEBNER_MATRIX_DEFERRED() (++whole_deferred)
#define lean_hex_groebner_eliminate_matrix hex_test_whole
static uint64_t continuation_phases[8]={0};
static uint64_t cont_exhausted[8][7]={{0}},cont_invalid_masks[6]={0};
static uint64_t cont_validation_work[2]={0};
#define HEX_GROEBNER_CONT_VALIDATE_WORK(s,w) (cont_validation_work[s]|=UINT64_C(1)<<(w))
static uint64_t cont_declined_mask=0,cont_edge_mask=0,cont_allocated_mask=0;
#define HEX_GROEBNER_CONT_EXHAUSTED(p,r,w) (cont_exhausted[p][r]|=UINT64_C(1)<<(w))
#define HEX_GROEBNER_CONT_INVALID(t,w) (cont_invalid_masks[t]|=UINT64_C(1)<<(w))
#define HEX_GROEBNER_CONT_DECLINE(w) (cont_declined_mask|=UINT64_C(1)<<(w))
#define HEX_GROEBNER_CONT_EDGE(w) (cont_edge_mask|=UINT64_C(1)<<(w))
#define HEX_GROEBNER_CONT_ALLOCATE(w) (cont_allocated_mask|=UINT64_C(1)<<(w))

static uint64_t cont_count=0,cont_factor=0,cont_ticks=0,cont_max_ticks=0,cont_max_units=0,cont_violations=0;
#define HEX_GROEBNER_CONT_BEGIN(c,r,n) do {cont_count=(n);cont_factor=8*(c)+2*(r)+4224;cont_ticks=0;} while(0)
#define HEX_GROEBNER_CONT_TICK() (++cont_ticks)
#define HEX_GROEBNER_CONT_END() do {  uint64_t units=cont_ticks*cont_factor;  if(cont_ticks>cont_count || units>1048576) ++cont_violations;  if(cont_ticks>cont_max_ticks) cont_max_ticks=cont_ticks;  if(units>cont_max_units) cont_max_units=units; } while(0)

#define HEX_GROEBNER_CONT_PHASE(p) (++continuation_phases[p])
#define lean_hex_matrix_advance hex_test_matrix_advance
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products/HexGroebner/ffi/matrix_state.c"
#undef lean_hex_matrix_advance
static uint64_t continuation_calls=0;
__typeof__(hex_test_matrix_advance) __wrap_lean_hex_matrix_advance;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_advance(lean_obj_arg state,b_lean_obj_arg steps) {
 ++continuation_calls;return hex_test_matrix_advance(state,steps);
}
LEAN_EXPORT lean_obj_res hex_test_continuation_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(continuation_calls));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_outcomes(lean_obj_arg world) {
 const uint64_t widths=(UINT64_C(1)<<1)|(UINT64_C(1)<<2)|(UINT64_C(1)<<4);
 int ok=cont_validation_work[0]==widths && cont_validation_work[1]==widths && cont_declined_mask==widths && cont_edge_mask==widths && cont_allocated_mask==widths;
 for(unsigned t=2;t<=4;++t) ok=ok && cont_invalid_masks[t]==widths;
 ok=ok && cont_exhausted[1][2]==widths && cont_exhausted[1][4]==widths && cont_exhausted[1][5]==widths;
 ok=ok && cont_exhausted[2][4]==widths && cont_exhausted[2][5]==widths;
 (void)world;return lean_io_result_mk_ok(lean_box(ok));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_workspaces(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(continuation_phases[2]));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_validations(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(continuation_phases[1]));
}
LEAN_EXPORT lean_obj_res hex_test_continuation_phases(lean_obj_arg world) {
 (void)world;lean_object *tail=lean_alloc_ctor(0,2,0),*pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(tail,0,lean_box_uint64(continuation_phases[4]));
 lean_ctor_set(tail,1,lean_box_uint64(continuation_phases[5]));
 lean_ctor_set(pair,0,lean_box_uint64(continuation_phases[3]));lean_ctor_set(pair,1,tail);
 return lean_io_result_mk_ok(pair);
}

LEAN_EXPORT lean_obj_res hex_test_continuation_bounds(lean_obj_arg world) {
 (void)world;lean_object *tail=lean_alloc_ctor(0,2,0),*pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(tail,0,lean_box_uint64(cont_max_units));
 lean_ctor_set(tail,1,lean_box_uint64(cont_violations));
 lean_ctor_set(pair,0,lean_box_uint64(cont_max_ticks));lean_ctor_set(pair,1,tail);
 return lean_io_result_mk_ok(pair);
}

#define lean_hex_matrix_validate hex_test_matrix_validate
#define lean_hex_matrix_zeros hex_test_matrix_zeros
#include "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-products/HexGroebner/ffi/matrix_eliminate.c"
#undef lean_hex_matrix_validate
#undef lean_hex_matrix_zeros
#undef lean_hex_groebner_eliminate_matrix
static uint64_t primitive_validations=0,primitive_zeros=0;
static uint64_t primitive_validate_admitted=0,primitive_validate_declined=0;
static uint64_t primitive_zero_admitted=0,primitive_zero_declined=0;
__typeof__(hex_test_matrix_validate) __wrap_lean_hex_matrix_validate;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_validate(uint64_t p,b_lean_obj_arg limits,
 b_lean_obj_arg columns,b_lean_obj_arg index,b_lean_obj_arg row,b_lean_obj_arg stats) {
 lean_object *saved_limits[7],*saved_stats[8],*saved_row[2];
 for(unsigned i=0;i<7;++i)saved_limits[i]=lean_ctor_get(limits,i);
 for(unsigned i=0;i<8;++i)saved_stats[i]=lean_ctor_get(stats,i);
 for(unsigned i=0;i<2;++i)saved_row[i]=lean_ctor_get(row,i);
 size_t a=lean_sarray_size(saved_row[0]),b=lean_sarray_size(saved_row[1]);
 uint8_t *snapshot=NULL;
 if(a<=1048576 && b<=1048576) {
  snapshot=malloc(a+b+1);assert(snapshot);
  memcpy(snapshot,lean_sarray_cptr(saved_row[0]),a);
  memcpy(snapshot+a,lean_sarray_cptr(saved_row[1]),b);
 }
 ++primitive_validations;lean_object *result=hex_test_matrix_validate(p,limits,columns,index,row,stats);
 for(unsigned i=0;i<7;++i)assert(saved_limits[i]==lean_ctor_get(limits,i));
 for(unsigned i=0;i<8;++i)assert(saved_stats[i]==lean_ctor_get(stats,i));
 for(unsigned i=0;i<2;++i)assert(saved_row[i]==lean_ctor_get(row,i));
 if(snapshot) {
  assert(a==lean_sarray_size(saved_row[0]) && b==lean_sarray_size(saved_row[1]));
  assert(memcmp(snapshot,lean_sarray_cptr(saved_row[0]),a)==0);
  assert(memcmp(snapshot+a,lean_sarray_cptr(saved_row[1]),b)==0);free(snapshot);
 }
 if(lean_is_scalar(result))++primitive_validate_declined;else {
  ++primitive_validate_admitted;assert(lean_is_exclusive(result));
  lean_object *pair=lean_ctor_get(result,0);assert(lean_is_exclusive(pair));
  assert(lean_is_exclusive(lean_ctor_get(pair,0)));
  assert(lean_is_exclusive(lean_ctor_get(pair,1)));
 }
 return result;
}
__typeof__(hex_test_matrix_zeros) __wrap_lean_hex_matrix_zeros;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_matrix_zeros(b_lean_obj_arg size) {
 ++primitive_zeros;lean_object *result=hex_test_matrix_zeros(size);
 if(lean_is_scalar(result))++primitive_zero_declined;else {
  ++primitive_zero_admitted;assert(lean_is_exclusive(result));
  assert(lean_is_exclusive(lean_ctor_get(result,0)));
 }
 return result;
}
LEAN_EXPORT lean_obj_res hex_test_matrix_primitives(lean_obj_arg world) {
 (void)world;lean_object *pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(pair,0,lean_box_uint64(primitive_validations));
 lean_ctor_set(pair,1,lean_box_uint64(primitive_zeros));return lean_io_result_mk_ok(pair);
}
LEAN_EXPORT lean_obj_res hex_test_primitive_admissions(lean_obj_arg world) {
 (void)world;lean_object *outer=lean_alloc_ctor(0,2,0),*a=lean_alloc_ctor(0,2,0),*b=lean_alloc_ctor(0,2,0);
 lean_ctor_set(a,0,lean_box_uint64(primitive_validate_admitted));
 lean_ctor_set(a,1,lean_box_uint64(primitive_validate_declined));
 lean_ctor_set(b,0,lean_box_uint64(primitive_zero_admitted));
 lean_ctor_set(b,1,lean_box_uint64(primitive_zero_declined));
 lean_ctor_set(outer,0,a);lean_ctor_set(outer,1,b);return lean_io_result_mk_ok(outer);
}
static uint64_t scan_calls=0,gather_calls=0,byte_calls=0,product_calls=0;
__typeof__(hex_test_products_attempt) __wrap_lean_hex_monomial_products_attempt;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_monomial_products_attempt(lean_obj_arg table,
 b_lean_obj_arg support,lean_obj_arg monomial,lean_obj_arg start,lean_obj_arg count,
 lean_obj_arg max_count,lean_obj_arg max_bytes,lean_obj_arg max_work,uint8_t native) {
 return hex_test_products_attempt(table,support,monomial,start,count,max_count,max_bytes,max_work,native);
}
LEAN_EXPORT lean_obj_res hex_test_batch_counts(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(batch_hits));
 lean_ctor_set(out,1,lean_box_uint64(batch_terms));return lean_io_result_mk_ok(out);
}

LEAN_EXPORT lean_obj_res hex_test_batch_deferrals(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0),*tail=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(batch_deferrals));
 lean_ctor_set(tail,0,lean_box_uint64(batch_waste));
 lean_ctor_set(tail,1,lean_box_uint64(batch_bound_errors));
 lean_ctor_set(out,1,tail);return lean_io_result_mk_ok(out);
}
static uint64_t search_calls=0;
__typeof__(hex_test_combine_owned) __wrap_lean_hex_groebner_combine_owned;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_combine_owned(lean_obj_arg table,uint8_t operation,
 lean_obj_arg a,lean_obj_arg b,lean_obj_arg max_count,lean_obj_arg max_bytes,
 lean_obj_arg max_work,uint8_t native) {
 return hex_test_combine_owned(table,operation,a,b,max_count,max_bytes,max_work,native);
}
LEAN_EXPORT lean_obj_res hex_test_deferred_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(fused_deferred));
}
LEAN_EXPORT lean_obj_res hex_test_alias_mask(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(unique_alias_mask));
}
LEAN_EXPORT lean_obj_res hex_test_alias_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(unique_alias));
}
LEAN_EXPORT lean_obj_res hex_test_unique_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(fused_unique));
}
LEAN_EXPORT lean_obj_res hex_test_insert_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(fused_insert));
}
LEAN_EXPORT lean_obj_res hex_test_accept_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(fused_success));
}
__typeof__(hex_test_search_monomial) __wrap_lean_hex_groebner_search_monomial;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_search_monomial(uint8_t width,
 uint64_t arity,uint64_t count,uint64_t hash,uint64_t link,uint64_t quantum,
 b_lean_obj_arg exponents,b_lean_obj_arg metadata,b_lean_obj_arg links,
 b_lean_obj_arg candidate,b_lean_obj_arg allowance) {
 ++search_calls;
 return hex_test_search_monomial(width,arity,count,hash,link,quantum,exponents,metadata,links,candidate,allowance);
}
LEAN_EXPORT lean_obj_res hex_test_search_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(search_calls));
}
__typeof__(hex_test_whole) __wrap_lean_hex_groebner_eliminate_matrix;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_eliminate_matrix(uint64_t p,
 b_lean_obj_arg limits,b_lean_obj_arg columns,b_lean_obj_arg reducers,
 b_lean_obj_arg targets,b_lean_obj_arg sugars,uint8_t independent) {
 return hex_test_whole(p,limits,columns,reducers,targets,sugars,independent);
}
LEAN_EXPORT lean_obj_res hex_test_whole_modes(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(whole_joint));
 lean_ctor_set(out,1,lean_box_uint64(whole_independent));return lean_io_result_mk_ok(out);
}
LEAN_EXPORT lean_obj_res hex_test_whole_counts(lean_obj_arg world) {
 (void)world;lean_object *out=lean_alloc_ctor(0,2,0);
 lean_ctor_set(out,0,lean_box_uint64(whole_accepted));
 lean_ctor_set(out,1,lean_box_uint64(whole_deferred));return lean_io_result_mk_ok(out);
}
static uint64_t comparison_calls=0,comparison_declines=0;
__typeof__(hex_test_compare) __wrap_lean_hex_groebner_compare_monomials;
LEAN_EXPORT uint8_t __wrap_lean_hex_groebner_compare_monomials(uint8_t operation,uint8_t width,
 uint64_t arity,uint64_t left,uint64_t right,b_lean_obj_arg arena) {
 ++comparison_calls;
 uint8_t result=hex_test_compare(operation,width,arity,left,right,arena);
 if(result==3) ++comparison_declines;
 return result;
}
LEAN_EXPORT lean_obj_res hex_test_comparison_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(comparison_calls));
}
LEAN_EXPORT lean_obj_res hex_test_comparison_declines(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(comparison_declines));
}
static uint64_t trie_calls=0,trie_declines=0;
__typeof__(hex_test_validate) __wrap_lean_hex_groebner_validate_trie;
LEAN_EXPORT uint8_t __wrap_lean_hex_groebner_validate_trie(b_lean_obj_arg arity,
 b_lean_obj_arg nodes,b_lean_obj_arg edges,uint64_t max_leading) {
 return hex_test_validate(arity,nodes,edges,max_leading);
}

__typeof__(hex_test_trie) __wrap_lean_hex_groebner_lookup_trie;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_lookup_trie(b_lean_obj_arg view,uint8_t width,
 uint64_t count,uint64_t query,b_lean_obj_arg arena,b_lean_obj_arg metadata,uint64_t remaining) {
 ++trie_calls;
 lean_object *result=hex_test_trie(view,width,count,query,arena,metadata,remaining);
 if(lean_ctor_get_uint8(result,2*sizeof(void*))==3) ++trie_declines;
 return result;
}
LEAN_EXPORT lean_obj_res hex_test_trie_counts(lean_obj_arg world) {
 (void)world;lean_object *pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(pair,0,lean_box_uint64(trie_calls));
 lean_ctor_set(pair,1,lean_box_uint64(trie_declines));
 return lean_io_result_mk_ok(pair);
}

__typeof__(hex_test_equal_products) __wrap_lean_hex_groebner_equal_products;
LEAN_EXPORT uint8_t __wrap_lean_hex_groebner_equal_products(uint8_t width,
 uint64_t arity,uint64_t count,uint64_t multiplier,uint64_t start,uint64_t terms,
 b_lean_obj_arg arena,b_lean_obj_arg base,b_lean_obj_arg result) {
 ++product_calls;return hex_test_equal_products(width,arity,count,multiplier,start,terms,arena,base,result);
}
LEAN_EXPORT lean_obj_res hex_test_product_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(product_calls));
}
__typeof__(hex_test_equal_bytes) __wrap_lean_hex_groebner_equal_bytes;
LEAN_EXPORT uint8_t __wrap_lean_hex_groebner_equal_bytes(b_lean_obj_arg left,
 b_lean_obj_arg right,b_lean_obj_arg start,b_lean_obj_arg count) {
 ++byte_calls;return hex_test_equal_bytes(left,right,start,count);
}
__typeof__(hex_test_scan) __wrap_lean_hex_scan_transition;
__typeof__(hex_test_gather) __wrap_lean_hex_gather;
LEAN_EXPORT lean_obj_res __wrap_lean_hex_scan_transition(uint64_t p,
 b_lean_obj_arg slots,b_lean_obj_arg pivots,lean_obj_arg initial,
 b_lean_obj_arg quantum,b_lean_obj_arg work,b_lean_obj_arg trace,uint8_t provenance) {
 ++scan_calls;return hex_test_scan(p,slots,pivots,initial,quantum,work,trace,provenance);
}
LEAN_EXPORT lean_obj_res __wrap_lean_hex_gather(uint64_t p,lean_obj_arg initial,
 b_lean_obj_arg stop,b_lean_obj_arg quantum,b_lean_obj_arg entries,
 b_lean_obj_arg bytes,b_lean_obj_arg work,uint64_t factor) {
 ++gather_calls;return hex_test_gather(p,initial,stop,quantum,entries,bytes,work,factor);
}
LEAN_EXPORT lean_obj_res hex_test_zero_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(zero_scans));
}
LEAN_EXPORT lean_obj_res hex_test_mersenne_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(mersenne_vectors));
}
LEAN_EXPORT lean_obj_res hex_test_byte_count(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint64(byte_calls));
}
LEAN_EXPORT lean_obj_res hex_test_counts(lean_obj_arg world) {
 (void)world;lean_object *pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(pair,0,lean_box_uint64(scan_calls));
 lean_ctor_set(pair,1,lean_box_uint64(gather_calls));
 return lean_io_result_mk_ok(pair);
}
LEAN_EXPORT lean_obj_res hex_test_vector_counts(lean_obj_arg world) {
 (void)world;lean_object *pair=lean_alloc_ctor(0,2,0);
 lean_ctor_set(pair,0,lean_box_uint64(vector_contiguous));
 lean_ctor_set(pair,1,lean_box_uint64(vector_gather));
 return lean_io_result_mk_ok(pair);
}
LEAN_EXPORT lean_obj_res hex_test_widths(lean_obj_arg world) {
 (void)world;return lean_io_result_mk_ok(lean_box_uint32(vector_widths));
}
LEAN_EXPORT lean_obj_res hex_test_avx2(lean_obj_arg world) {
 (void)world;
#if HEX_GROEBNER_AVX2
 return lean_io_result_mk_ok(lean_box(hex_avx2_available()));
#else
 return lean_io_result_mk_ok(lean_box(0));
#endif
}
