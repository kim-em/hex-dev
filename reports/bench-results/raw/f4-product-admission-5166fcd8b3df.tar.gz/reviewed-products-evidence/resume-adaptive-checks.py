from pathlib import Path
import json,subprocess,shutil,time
prefix=Path('/home/kim/tmp/issue-10987/adaptive-full');status=Path(str(prefix)+'-status.json');shutil.copy2(status,str(prefix)+'-status-before-comment-fix.json');shutil.copy2(str(prefix)+'-phase4.log',str(prefix)+'-phase4-cost-comment.log');results=json.loads(status.read_text());assert len(results)==6 and results[-1]['name']=='phase4' and results[-1]['exit_code']==1;results=results[:-1]
for name,script in [('phase4','scripts/check_phase4.py'),('manifest','scripts/release/check_released_manifest.py'),('headers','scripts/check_copyright_headers.py'),('lines','scripts/check_file_line_counts.py')]:
 command=['/home/kim/tmp/issue-10987/oracles/bin/python',script];log=Path(str(prefix)+'-'+name+'.log');start=time.monotonic()
 with log.open('w') as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=command,exit_code=r.returncode,seconds=time.monotonic()-start,log=str(log)));status.write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
