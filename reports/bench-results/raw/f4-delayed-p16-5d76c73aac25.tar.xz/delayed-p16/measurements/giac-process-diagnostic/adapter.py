"""Candidate-only Giac adapter; retain its native output beside the CAS input."""
from pathlib import Path
import json,os,re,subprocess,sys,time
sys.path.insert(0,'/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames')
from scripts.oracle.groebner_singular import expression, polynomial
inp,out=map(Path,sys.argv[1:]);value=json.loads(inp.read_text())
p,n,order=value['p'],value['variables'],value['order']
engine='/nix/store/20q8fga4bjb7cjxcb23mqc5gx6ajv99a-giac-2.0.0-19/bin/icas'
ordering={'grevlex':'revlex','lex':'plex','grlex':'tdeg'}[order]
program='threads(1):;\nt:=time():;\nB:=gbasis(['+','.join(expression(f)for f in value['generators'])+'] mod '+str(p)+',['+','.join('x'+str(i)for i in range(n))+'],'+ordering+'):;\n[time()-t,threads(),B];\n'
out.with_suffix('.cas').write_text(program)
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
start=time.monotonic_ns()
with out.with_suffix('.raw.stdout').open('w')as stdout,out.with_suffix('.raw.stderr').open('w')as stderr:
 r=subprocess.run([engine,str(out.with_suffix('.cas'))],env=env,stdout=stdout,stderr=stderr)
elapsed=time.monotonic_ns()-start
if r.returncode:raise RuntimeError(('giac failed',r.returncode))
raw=out.with_suffix('.raw.stdout').read_text()
match=re.fullmatch(r'\s*(?:"Done",\s*)*\[([0-9.eE+-]+),1,\[(.*)\]\]\s*',raw,re.S)
if not match:raise ValueError('unrecognized Giac output: '+raw[:500])
# Giac prints expanded ordinary-ring polynomials with balanced integer lifts.
basis=[[[list(e),c]for e,c in polynomial(text,n,p)] for text in match[2].split(',')if text.strip()]
basis=[f for f in basis if f]
# Giac may return a reduced basis with non-unit leading coefficients. Include
# the explicit monic output conversion in adapter process time.
def key(term):
 e=term[0]
 return tuple(e) if order=='lex' else (sum(e),tuple(e) if order=='grlex' else tuple(-v for v in reversed(e)))
for f in basis:
 f.sort(key=key,reverse=True)
 inverse=pow(f[0][1],-1,p)
 for term in f:term[1]=term[1]*inverse%p
result=dict(engine='Giac',version='2.0.0-19',p=p,variables=n,order=order,basis=basis,
 kind='unchecked_candidate',threads=1,engineProcessNanos=elapsed,outputConversion='explicit monic scaling after Giac; included in adapter process time',engineTimeSeconds=float(match[1]),
 engineTimeContract='Giac time() difference; do not assume this is wall time',
 command=[engine,str(out.with_suffix('.cas'))])
out.write_text(json.dumps(result)+'\n');print(json.dumps(result))
