"""Matched first-size diagnostic; retain every run, including failures and JIT phases."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,math,os,resource,select,shutil,signal,subprocess,time
s=Path('/home/kim/tmp/issue-10987');frozen=s/'delayed-prime-packets-production';inputs=s/'fixed-corpus-v2-cli-validated'
p=argparse.ArgumentParser();p.add_argument('engine',choices=['julia','giac']);p.add_argument('output',type=Path);args=p.parse_args();out=args.output;out.mkdir(exist_ok=False)
manifest=json.loads((frozen/'manifest.json').read_text());suite=json.loads((inputs/'suite.json').read_text())
seen=set();cases=[]
for c in suite['cases']:
 key=c['family'],c['p']
 if c['split']=='primary'and key not in seen:seen.add(key);cases.append(c)
assert len(cases)==30 and len({c['family']for c in cases})==10
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
helper=frozen/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('lease',helper);lease_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(lease_module)
cpu,lease=lease_module.cpu_lease();os.sched_setaffinity(0,{cpu})
hex_binary=frozen/'binaries/compute';assert sha(hex_binary)==manifest['binary_sha256']['compute']
julia=Path('/nix/store/6jkbimngiixj3qvnpjb7ja7l0icrxkdj-julia-bin-1.13.3/bin/julia')
giac=Path('/nix/store/20q8fga4bjb7cjxcb23mqc5gx6ajv99a-giac-2.0.0-19/bin/icas');clock=Path(shutil.which('time'))
adapter=s/('groebnerjl-adapter.jl'if args.engine=='julia'else'giac-adapter.py')
bindings=[adapter,helper,hex_binary,julia if args.engine=='julia'else giac,clock,Path(__file__),s/'groebnerjl-project/Manifest.toml',s/'groebnerjl-project/Project.toml',Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames/scripts/oracle/groebner_singular.py'),Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-wide-binary-frames/scripts/oracle/common.py')]
before={str(p):sha(p)for p in bindings}
for name,path in [('adapter'+adapter.suffix,adapter),('collector.py',Path(__file__)),('cpu_lease.py',helper),('julia-Manifest.toml',s/'groebnerjl-project/Manifest.toml'),('julia-Project.toml',s/'groebnerjl-project/Project.toml')]:shutil.copy2(path,out/name)
limits=suite['protocol']['hex_limits'];hexargs=[part for k,v in limits.items()for part in ['--'+k,str(v)]]
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JULIA_NUM_THREADS='1',JULIA_DEPOT_PATH=str(s/'julia-depot'),JULIA_SSL_CA_ROOTS_PATH='/etc/ssl/certs/ca-certificates.crt')
meta=dict(engine=args.engine,selection='First listed primary case per family and field, fixed before timing; 30 cases, ten families, three prime fields. No held-out cases. Diagnostic only, not full acceptance.',manifest=manifest,cases=cases,cpu=cpu,threads=1,schedule='Adjacent AB then BA, two pairs per input; A=Hex, B=comparator',protocol=suite['protocol'],source_bindings=before,host=os.uname().nodename,load_start=os.getloadavg(),samples=[],contract='Complete monic reduced unchecked candidates in ordinary prime-field polynomial rings. No certificate generation or certification. Process times include adapter and launch costs; pidfd readiness avoids Python wait(timeout) polling granularity. Julia uses fixed unrelated warmup inputs; setup/warmup/candidate times are reported separately and residual JIT may remain in candidate time. Giac monic output scaling is explicit and included in adapter process time; its time() value has no asserted wall-clock interpretation. All completed runs retained; no repeats or leadership claim.')
def save():
 temp=out/'metadata.pending';temp.write_text(json.dumps(meta,indent=2)+'\n');temp.replace(out/'metadata.json')
def canonical(basis):return sorted(sorted((tuple(e),int(c))for e,c in f)for f in basis if f)
def bound():
 os.setsid();resource.setrlimit(resource.RLIMIT_AS,(8*1024**3,8*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(256*1024**2,256*1024**2))
active=None;save()
try:
 for block in [0,1]:
  for case in cases:
   name=case['name'];input_path=inputs/(name+'.json');value=json.loads(input_path.read_text())
   # Adapter files were independently checked against the fixed canonical inputs.
   target=out/(name+'.input.json')
   if not target.exists():shutil.copy2(input_path,target)
   results={};rows=[]
   for arm in (['A','B']if block==0 else['B','A']):
    prefix=out/(name+f'-b{block}-{arm}');rss=Path(str(prefix)+'.rss')
    if arm=='A':command=[str(hex_binary),*hexargs,'--scheduling','degree','--binary-pivots','true','--dense-pivots','false','--delayed-reduction','true',str(target)]
    elif args.engine=='julia':command=[str(julia),'--threads=1,0','--startup-file=no','--project='+str(s/'groebnerjl-project'),str(adapter),str(target)]
    else:command=[str(s/'oracles/bin/python'),str(adapter),str(target),str(prefix)+'.giac.json']
    row=dict(case=name,family=case['family'],p=case['p'],block=block,arm=arm,command=command,status='pending',complete_basis_equal=False)
    start=time.monotonic_ns()
    with Path(str(prefix)+'.stdout').open('w')as stdout,Path(str(prefix)+'.stderr').open('w')as stderr:
     active=subprocess.Popen([str(clock),'-f','%M','-o',str(rss),'--',*command],stdout=stdout,stderr=stderr,env=env,preexec_fn=bound)
     descriptor=os.pidfd_open(active.pid)
     try:
      if select.select([descriptor],[],[],300)[0]:
       code=active.wait();row['status']='ok'if code==0 else'failed'
      else:
       os.killpg(active.pid,signal.SIGKILL);code=active.wait();row['status']='timeout'
     finally:os.close(descriptor)
    row.update(returncode=code,wall_nanos=time.monotonic_ns()-start);active=None
    text=rss.read_text().strip().splitlines()if rss.exists()else[];row['peak_rss_kib']=int(text[-1])if text and text[-1].isdigit()else None
    if row['status']=='ok':
     try:
      data=json.loads(Path(str(prefix)+'.stdout').read_text())
      assert data['kind']=='unchecked_candidate'and(data['p'],data['variables'],data['order'])==(value['p'],value['variables'],value['order'])
      results[arm]=canonical(data['basis']);row['phases']={k:data[k]for k in ['candidateNanos','warmupNanos','setupNanos','engineTimeSeconds','engineProcessNanos']if k in data}
     except(Exception)as error:row.update(status='invalid_output',error=str(error))
    meta['samples'].append(row);rows.append(row);save();print(name,block,arm,row['status'],round(row['wall_nanos']/1e6,2),flush=True)
   equal=len(results)==2 and results['A']==results['B']
   for row in rows:row['complete_basis_equal']=equal
   save()
finally:
 if active is not None and active.poll()is None:os.killpg(active.pid,signal.SIGKILL);active.wait()
 meta.update(load_end=os.getloadavg(),source_bindings_after={str(p):sha(p)for p in bindings});meta['sources_unchanged']=meta['source_bindings_after']==before;save();lease.close()
ratios=[];families={};candidate=[]
for c in cases:
 for block in [0,1]:
  pair={r['arm']:r for r in meta['samples']if r['case']==c['name']and r['block']==block}
  if len(pair)==2 and all(r['status']=='ok'and r['complete_basis_equal']for r in pair.values()):
   ratio=pair['A']['wall_nanos']/pair['B']['wall_nanos'];ratios.append(ratio);families.setdefault(c['family'],[]).append(ratio)
   if all('candidateNanos'in r['phases']for r in pair.values()):candidate.append(pair['A']['phases']['candidateNanos']/pair['B']['phases']['candidateNanos'])
g=lambda v:math.exp(sum(map(math.log,v))/len(v))if v else None
summary=dict(samples=len(meta['samples']),expected_samples=120,equal_pairs=sum(r['complete_basis_equal']for r in meta['samples'])//2,failures=sum(r['status']!='ok'for r in meta['samples']),ratio_direction='Hex/comparator',jointly_solved_process_geomean=g(ratios),per_family={f:g(v)for f,v in families.items()},candidate_geomean=g(candidate),scope='Diagnostic only. Jointly solved ratios do not compensate for any coverage loss. Julia JIT/setup and Giac output normalization contracts remain explicit.')
(out/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
if len(meta['samples'])!=120 or summary['equal_pairs']!=60 or summary['failures']or not meta['sources_unchanged']:raise SystemExit(1)
