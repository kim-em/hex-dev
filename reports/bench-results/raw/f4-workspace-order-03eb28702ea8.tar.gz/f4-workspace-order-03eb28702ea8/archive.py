from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile,sys
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');mode=sys.argv[1]
base=state/({'zero':'workspace-zero-production','order':'workspace-order-production','hash':'symbolic-single-hash-production'}[mode]);m=json.loads((base/'manifest.json').read_text());name='f4-'+{'zero':'workspace-zero','order':'workspace-order','hash':'symbolic-hash'}[mode]+'-'+m['source_fingerprint'];payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
for p in sorted(base.rglob('*')):
 rel=p.relative_to(base)
 if rel.parts[0]=='binaries'or rel.parts[:2]==('bench-binaries','source')or rel.parts==('bench-binaries','frame'):continue
 if p.is_file():add('measurement/'+str(rel),p.read_bytes())
for relative in ['issue-10987-lean-cc','issue-10987-lean-cc-flags.json']:
 add('build/'+relative,(state/relative).read_bytes())
add('source.patch',subprocess.check_output(['git','diff','--binary','921d4d7a2466c12995f2f87faf78eae7dbd593b4',m['source_snapshot'],'--','.',':!reports'],cwd=root));add('source-base.txt',b'921d4d7a2466c12995f2f87faf78eae7dbd593b4\n')
if mode=='zero':
 for directory in ['wide-continuation-profile','workspace-zero-clang','workspace-zero-gcc']:
  for p in sorted((state/directory).rglob('*')):
   if p.is_file()and'.lake'not in p.relative_to(state/directory).parts:add('validation/'+directory+'/'+str(p.relative_to(state/directory)),p.read_bytes())
 for pattern in ['workspace-zero-full-*.log','workspace-zero-*.log','workspace-zero-native-status.json','workspace-zero-full-status.json','workspace-zero-measure-status.json','workspace-zero.patch']:
  for p in sorted(state.glob(pattern)):
   key='validation/'+p.name
   if key not in payload:add(key,p.read_bytes())
 for relative in ['full-checks.py','workspace-zero-native-checks.py','workspace-zero-system-measure.py','measure-workspace-zero-wide.py','profile-wide-continuation.py','build-workspace-zero-bench.py']:
  add('reproduction/'+relative,(state/relative).read_bytes())
else:
 for p in sorted(state.glob(('workspace-order'if mode=='order'else'symbolic-single-hash')+'*')):
  if p.is_file()and p.suffix in ['.py','.log','.patch','.json']:add('reproduction/'+p.name,p.read_bytes())
add('archive.py',Path(__file__).read_bytes());add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest()for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/(name+'-audit.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
