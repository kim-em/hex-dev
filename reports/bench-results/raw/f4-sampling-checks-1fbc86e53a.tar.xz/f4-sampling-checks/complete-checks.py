from pathlib import Path
import json,os,subprocess,time,sys
state=Path('/home/kim/tmp/issue-10987');root=Path.cwd();sys.path.insert(0,str(root))
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing,fingerprint
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();listing=tree_listing(FAMILY,commit)
p=state/'sampled-abi-full-status.json';prior=json.loads(p.read_text());(state/'sampled-abi-first-full-attempt.json').write_text(json.dumps(prior,indent=2)+'\n');results=[x for x in prior if x['exit_code']==0]
for name,script in [('phase4','scripts/check_phase4.py'),('manifest','scripts/release/check_released_manifest.py'),('headers','scripts/check_copyright_headers.py'),('lines','scripts/check_file_line_counts.py')]:
 log=state/f'sampled-abi-complete-{name}.log';command=[str(state/'oracles/bin/python'),script];start=time.monotonic()
 with log.open('w')as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=command,exit_code=r.returncode,seconds=time.monotonic()-start,log=str(log),source_commit=commit,source_fingerprint=fingerprint(listing)));p.write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
(state/'sampled-abi-final-source.manifest').write_text(listing)
