from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile
state=Path('/home/kim/tmp/issue-10987');payload={}
def add(name,path):
 assert name not in payload
 payload[name]=path.read_bytes()
for name,path in [('native-status.json','sampled-abi-native-status.json'),('full-status.json','sampled-abi-full-status.json'),('first-full-attempt.json','sampled-abi-first-full-attempt.json'),('first-phase4.log','sampled-abi-full-phase4.log'),('final-source.manifest','sampled-abi-final-source.manifest'),('comment-binary-identity.json','sampled-abi-comment-binary-identity.json'),('comment-build.log','sampled-abi-cost-comment-build.log'),('full-checks.py','sampled-abi-full-checks.py'),('complete-checks.py','sampled-abi-complete-project-checks.py'),('native-checks.py','sampled-abi-native-checks.py')]:add(name,state/path)
for row in json.loads((state/'sampled-abi-full-status.json').read_text()):
 assert row['exit_code']==0
 add(row['name']+'.log',Path(row['log']))
for compiler in ['clang','gcc']:add(compiler+'.log',state/f'sampled-abi-{compiler}.log')
add('Sampling.lean',Path('bench/HexGroebner/Bench/Sampling.lean'))
for name in ['scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh','scripts/ci/check_groebner_sampling.py','scripts/ci/run_oracles.sh','conformance/HexGroebner/SamplingConformance.lean','conformance/HexGroebner/SampledConformance.lean']:
 add('sources/'+name,Path(name))
payload['implementation.patch']=subprocess.check_output(['git','diff','origin/main...HEAD','--no-ext-diff'])
add('pack-sampling-guards.py',Path(__file__))
manifest={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())};payload['sha256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=Path('reports/bench-results/raw/f4-sampling-checks-1fbc86e53a.tar.xz')
with lzma.open(out,'wb',preset=6)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-sampling-checks/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
