import Lake
open Lake DSL System
package GroebnerScanDev
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
target scanO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "scan.c")
  let header ← inputTextFile (pkg.dir / "simd.h")
  let flags := #["-O3", "-Wall", "-Wextra", "-fPIC"]
  buildO (pkg.dir / defaultBuildDir / "scan.o")
    (source.zipWith (fun source _ => source) header)
    #["-I", (← getLeanIncludeDir).toString] flags

lean_lib ScanNative where
  roots := #[`ScanNative]
  globs := #[.one `ScanNative, .one `NativeScan, .one `NativeGather]
  moreLinkObjs := #[scanO]
  precompileModules := true

lean_lib ScanDev where
  roots := #[`ScanTest, `EliminationPrototype, `SymbolicPrototype, `F4Prototype, `EngineTest, `F4Test, `GatherTest]

lean_exe scan_compare where
  root := `Main

target scanSanitizedO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "scan.c")
  let header ← inputTextFile (pkg.dir / "simd.h")
  let flags := #["-O1", "-g", "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
    "-DHEX_GROEBNER_NO_UINT128", "-Dlean_hex_gather=__wrap_lean_hex_gather",
    "-Dlean_hex_scan_transition=__wrap_lean_hex_scan_transition", "-fPIC"]
  buildO (pkg.dir / defaultBuildDir / "scan-sanitized.o")
    (source.zipWith (fun source _ => source) header)
    #["-I", (← getLeanIncludeDir).toString] flags

lean_exe scan_checks where
  root := `Check
  moreLinkObjs := #[scanSanitizedO]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition","-Wl,--wrap=lean_hex_gather","/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/resource-root/lib/linux/libclang_rt.asan-x86_64.so"]

target scanNoSimdO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "scan.c")
  let header ← inputTextFile (pkg.dir / "simd.h")
  buildO (pkg.dir / defaultBuildDir / "scan-no-simd.o")
    (source.zipWith (fun source _ => source) header)
    #["-I", (← getLeanIncludeDir).toString]
    #["-O3", "-Wall", "-Wextra", "-fPIC", "-DHEX_GROEBNER_NO_AVX2",
      "-Dlean_hex_scan_transition=__wrap_lean_hex_scan_transition",
      "-Dlean_hex_gather=__wrap_lean_hex_gather"]

lean_exe scan_compare_no_simd where
  root := `NoSimdMain
  moreLinkObjs := #[scanNoSimdO]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]

target scanNoSimdSanitizedO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "scan.c")
  let header ← inputTextFile (pkg.dir / "simd.h")
  buildO (pkg.dir / defaultBuildDir / "scan-no-simd-sanitized.o")
    (source.zipWith (fun source _ => source) header)
    #["-I", (← getLeanIncludeDir).toString]
    #["-O1", "-g", "-fsanitize=address,undefined", "-fno-omit-frame-pointer", "-fPIC",
      "-DHEX_GROEBNER_NO_UINT128", "-DHEX_GROEBNER_NO_AVX2",
      "-Dlean_hex_scan_transition=__wrap_lean_hex_scan_transition",
      "-Dlean_hex_gather=__wrap_lean_hex_gather"]

lean_exe scan_checks_no_simd where
  root := `NoSimdCheck
  moreLinkObjs := #[scanNoSimdSanitizedO]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather",
    "/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/resource-root/lib/linux/libclang_rt.asan-x86_64.so"]
