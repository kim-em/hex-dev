import ScanTest
import GatherTest
import EngineTest
import F4Test

def main : IO Unit := do
  if engineRuntimeChecks && f4RuntimeChecks && runtimeChecks && runtimeWideChecks && gatherRuntimeChecks && gatherMalformedChecks then IO.println "native scan and gather: widths, chunking, counters, aliases, malformed inputs match portable"
  else throw (IO.userError "native scan mismatch")
