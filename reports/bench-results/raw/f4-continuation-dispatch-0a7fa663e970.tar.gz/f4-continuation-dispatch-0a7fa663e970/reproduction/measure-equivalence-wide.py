from pathlib import Path
import json,os,subprocess,hashlib,time,sys
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-equivalence');state=Path('/home/kim/tmp/issue-10987');base=state/'equivalence-reviewed-production'
while not(base/'bench-binaries/builds.json').is_file():time.sleep(5)
build=json.loads((base/'bench-binaries/builds.json').read_text());binary=base/'bench-binaries/frame';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256']
sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
out=base/'wide-paired';out.mkdir(exist_ok=False);cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[];points={a:[] for a in 'AB'}
try:
 for block,order in enumerate(['AB','BA']):
  for arm in order:
   name='matrixWideReference' if arm=='A' else 'matrixWide';prefix=f'block{block}-{arm}';command=[str(binary),'run','Hex.Groebner.Bench.'+name,'--outer-trials','1','--export-file',str(out/(prefix+'.json'))]
   with(out/(prefix+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
   runs.append(dict(block=block,arm=arm,command=command,returncode=r.returncode));assert r.returncode in [0,2];v=json.loads((out/(prefix+'.json')).read_text())['results'][0];assert len(v['points'])==4 and all(x['status']=='ok' for x in v['points']);points[arm]+=v['points'];print(prefix,v['verdict'],flush=True)
 for n in [65536,65537,131072,262144]:assert len({p['result_hash'] for ps in points.values() for p in ps if p['param']==n})==1
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),build=build,runs=runs,scope='First matched whole-sweep AB/BA comparison in one fresh executable. A uses Elimination.reference; B uses MatrixState.finishWith. Four widths straddle the native phase scheduler column cap. Eight fixed reducers and targets force a final-column pivot and full scanning. Prepared packed inputs excluded; complete decoded output and all eight matrix counters are consumed. Automatic CPU lease, one algorithm thread requested, all completed samples/RSS/floor/host context retained. No filtering or unchanged repeat. Not full F4, certification, verification or kernel checking timing.'),indent=2)+'\n');lease.close()
(out/'measure.py').write_bytes(Path(__file__).read_bytes())
