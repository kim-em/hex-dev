from pathlib import Path
import json,subprocess,time
while not (Path('/home/kim/tmp/issue-10987/equivalence-shaped-production/manifest.json')).is_file():time.sleep(5)
root=Path('/home/kim/tmp/issue-10987');production=root/'equivalence-shaped-production'
base=[str(root/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(production/'manifest.json'),'--suite',str(root/'final-products-production/medium-inputs/suite.json'),'--hex',str(production/'binaries/compute'),'--hex-scheduling','degree']
campaigns=[('before-after',['--baseline',str(root/'current-comparator-production/binaries/compute'),'--baseline-manifest',str(root/'current-comparator-production/manifest.json'),'--baseline-scheduling','degree'])]
for mode in [2,42]:campaigns.append(('msolve-l'+str(mode),['--msolve',str(root/'msolve-current/.libs/msolve'),'--msolve-source',str(root/'msolve-current'),'--msolve-mode',str(mode)]))
results=[]
for name,extra in campaigns:
 command=base+['--output',str(production/name)]+extra;start=time.monotonic()
 with (root/('equivalence-shaped-'+name+'.log')).open('w')as output:
  result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=command,exit_code=result.returncode,seconds=time.monotonic()-start));(root/'equivalence-shaped-measurements-status.json').write_text(json.dumps(results,indent=2)+'\n');print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
