set -euo pipefail
cd /home/kim/tmp/issue-10987/msolve-current
export NIX_ENFORCE_NO_NATIVE=0
export CC='/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang -std=gnu23'
export CFLAGS='-O3 -march=native -frecord-command-line'
export CPPFLAGS='-I/nix/store/58cds16cp7zyiywadnfih6x99vd7f9fq-gmp-with-cxx-6.3.0-dev/include -I/nix/store/qdff55w0yg76d6zx9wdpw76rk84vna2k-mpfr-4.2.2-dev/include -I/nix/store/gm627d8phjkix5g0jj7327phsr7prxp9-flint-3.6.0/include'
export LDFLAGS='-L/nix/store/7whfqxz5vs4kn8jiybvdj5k7ib6h4442-gmp-with-cxx-6.3.0/lib -L/nix/store/rnxpzpjpvj8yfqh3mjwry1fjbv2r14gh-mpfr-4.2.2/lib -L/nix/store/gm627d8phjkix5g0jj7327phsr7prxp9-flint-3.6.0/lib -Wl,-rpath,/nix/store/7whfqxz5vs4kn8jiybvdj5k7ib6h4442-gmp-with-cxx-6.3.0/lib -Wl,-rpath,/nix/store/rnxpzpjpvj8yfqh3mjwry1fjbv2r14gh-mpfr-4.2.2/lib -Wl,-rpath,/nix/store/gm627d8phjkix5g0jj7327phsr7prxp9-flint-3.6.0/lib'
libtoolize --copy --force > /home/kim/tmp/issue-10987/msolve-current-libtoolize.log 2>&1
autoreconf -i > /home/kim/tmp/issue-10987/msolve-current-autoreconf.log 2>&1
./configure --prefix=/home/kim/tmp/issue-10987/msolve-current-install > /home/kim/tmp/issue-10987/msolve-current-configure.log 2>&1
make -j4 V=1 > /home/kim/tmp/issue-10987/msolve-current-build.log 2>&1
