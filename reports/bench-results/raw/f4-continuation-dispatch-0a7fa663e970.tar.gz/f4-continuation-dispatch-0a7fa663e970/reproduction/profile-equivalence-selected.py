from pathlib import Path
import os,sys,json,hashlib,subprocess
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-equivalence');state=Path('/home/kim/tmp/issue-10987');base=state/'equivalence-reviewed-production';out=base/'profiles';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();records=[];env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
try:
 for field in ['15','31']:
  input=state/f'final-products-production/medium-inputs/cyclic7-{field}.json';(out/input.name).write_bytes(input.read_bytes())
  for arm in (['A','B'] if field=='15' else ['B','A']):
   binary=(state/'current-comparator-production' if arm=='A' else base)/'binaries/compute';name=f'cyclic7-{field}-{arm}'
   command=['perf','record','-e','cycles:u','-F','1999','--call-graph','dwarf,16384','-o',str(out/(name+'.data')),'--',str(binary),'--scheduling','degree','--work','100000000000',str(input)]
   with(out/(name+'.stdout')).open('wb')as stdout,(out/(name+'.stderr')).open('wb')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=env)
   records.append(dict(name=name,command=command,exit_code=r.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),input_sha256=hashlib.sha256(input.read_bytes()).hexdigest()))
   assert r.returncode==0
   with(out/(name+'.report')).open('w')as f:subprocess.run(['perf','report','--stdio','--no-children','--percent-limit','0.5','-i',str(out/(name+'.data'))],stdout=f,stderr=subprocess.STDOUT,check=True)
   with(out/(name+'.headers')).open('w')as f:subprocess.run(['perf','report','--header-only','--stdio','-i',str(out/(name+'.data'))],stdout=f,stderr=subprocess.STDOUT,check=True)
 for field in ['15','31']:
  values=[]
  for arm in ['A','B']:
   v=json.loads((out/f'cyclic7-{field}-{arm}.stdout').read_text());v.pop('candidateNanos');values.append(v)
  assert values[0]==values[1]
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,host=os.uname().nodename,threads=1,load_start=load,load_end=os.getloadavg(),runs=records,scope='Diagnostic user-cycle profiles to explain unchanged whole-system performance after matrix continuation selection. Four sequential processes; startup included. These are cost attribution, not timing comparisons or acceptance evidence. Full outputs and counters agree within each field. All raw samples and failures retained.'),indent=2)+'\n');lease.close()
(out/'profile.py').write_bytes(Path(__file__).read_bytes())
