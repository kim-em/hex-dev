import ctypes,hashlib,json,os,pathlib,resource,select,signal,subprocess,sys,time
sys.path.insert(0,'/tmp/hex-groebner-compare-monomials-dev')
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import fingerprint,index_listing
library=json.loads(pathlib.Path('/tmp/hex-groebner-text-production/binaries/manifest.json').read_text())
listing=library['source_manifest']
fp='text-'+library['driver_sha256'][:12]
ROOT=pathlib.Path('/tmp/hex-groebner-compare')
mode=int(sys.argv[1]);OUT=pathlib.Path('/tmp/hex-groebner-text-production')/f'msolve-l{mode}-records-{fp}'
libc=ctypes.CDLL(None,use_errno=True)
libc.pidfd_open.argtypes=[ctypes.c_int,ctypes.c_uint]
libc.pidfd_open.restype=ctypes.c_int
OUT.mkdir(exist_ok=False)
plan=json.loads((ROOT/'diagnostic-suite.json').read_text());protocol=plan['protocol']
hexbin=pathlib.Path('/tmp/hex-groebner-text-production/binaries/compare-text');msbin=pathlib.Path('/tmp/hex-groebner-msolve/msolve')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
meta=dict(protocol=protocol,suite_sha256=sha(ROOT/'diagnostic-suite.json'),cpu=cpu,affinity=sorted(os.sched_getaffinity(0)),host=os.uname().nodename,load_start=os.getloadavg(),hex_binary_sha256=sha(hexbin),hex_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),msolve_commit=subprocess.check_output(['git','-C','/tmp/hex-groebner-msolve','rev-parse','HEAD'],text=True).strip(),msolve_binary_sha256=sha(pathlib.Path('/tmp/hex-groebner-msolve/.libs/msolve')),msolve_build='Clang23.1.3 -std=gnu23 -O3 -march=native; GMP6.3.0 MPFR4.2.2 FLINT3.6.0; OpenMP enabled; engine identity and compiler settings retained',msolve_linear_algebra=mode,driver_sha256=sha(pathlib.Path('/tmp/hex-groebner-text-production/Main.lean')),timer_sha256=sha(pathlib.Path(__file__)),guarantees='Hex deterministic unchecked reduced candidate; msolve current upstream full reduced grevlex basis with l2 exact-default or l42 probabilistic elimination; one thread, neither certificate generation nor kernel checking included; whole-process time includes startup/parse/full output and is not isolated candidate time')
(OUT/'source.manifest').write_text(listing)
meta.update(hex_source_fingerprint=library['source_fingerprint'],hex_library_commit=library['library_commit'],source_note='Identical typed-comparison library source802ae51122d7; supported sparse text driver without Lean package imports; no runtime initialization interception.',hex_source_dirty=False,toolchain=pathlib.Path('/tmp/hex-groebner-compare-monomials-dev/lean-toolchain').read_text().strip(),script=pathlib.Path(__file__).read_text(),msolve_engine_sha256=sha(pathlib.Path('/tmp/hex-groebner-msolve/src/neogb/.libs/libneogb.so.4.0.0')))
(OUT/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')

def limits():
    os.setsid()
    resource.setrlimit(resource.RLIMIT_AS,(protocol['address_space_bytes'],)*2)
    resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,)*2)

def sample(case,block,arm):
    prefix=f"{case['name']}-b{block}-{arm}";path=OUT/(prefix+'.basis')
    if arm=='A':command=[str(hexbin),str(pathlib.Path('/tmp/hex-groebner-text-production/inputs')/(case['name']+'.txt'))]
    else:command=[str(msbin),'-g','2','-t','1','-l',str(mode),'-v','2','-f',str(ROOT/(case['name']+'.ms')),'-o',str(path)]
    start=time.monotonic_ns();load=os.getloadavg();timeout=False
    with (OUT/(prefix+'.stdout')).open('wb') as stdout,(OUT/(prefix+'.stderr')).open('wb') as stderr:
        proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env,preexec_fn=limits)
        fd=libc.pidfd_open(proc.pid,0)
        if fd < 0: raise OSError(ctypes.get_errno(), "pidfd_open")
        try:
            ready,_,_=select.select([fd],[],[],protocol['timeout_seconds'])
            if not ready:
                timeout=True;os.killpg(proc.pid,signal.SIGKILL)
            _,status,usage=os.wait4(proc.pid,0)
            proc.returncode=os.waitstatus_to_exitcode(status)
        finally:os.close(fd)
    elapsed=time.monotonic_ns()-start
    record=dict(case=case['name'],family=case['family'],p=case['p'],block=block,arm=arm,command=command,wall_nanos=elapsed,status='timeout' if timeout else 'ok' if proc.returncode==0 else 'failed',returncode=proc.returncode,peak_rss_kib=usage.ru_maxrss,user_seconds=usage.ru_utime,system_seconds=usage.ru_stime,load_start=load)
    if arm=='A' and proc.returncode==0:
        try:
            result=json.loads((OUT/(prefix+'.stdout')).read_text())
            record['statistics']={k:v for k,v in result.items() if k!='basis'}
        except Exception as e:record.update(status='malformed',error=str(e))
    with (OUT/'samples.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
    print(prefix,record['status'],elapsed/1e9,flush=True)

try:
    for case in plan['cases']:
        for block,order in enumerate(protocol['orders']):
            for arm in order:sample(case,block,arm)
finally:
    meta['load_end']=os.getloadavg();(OUT/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
