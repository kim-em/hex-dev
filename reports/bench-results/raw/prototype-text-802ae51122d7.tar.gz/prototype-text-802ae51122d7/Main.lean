import HexGroebner

open Hex.Groebner

abbrev Parser := StateT (List String) (Except String)

def token : Parser String := do
  let x::xs ← get | throw "unexpected end of input"
  set xs
  return x

def natural : Parser Nat := do
  let word ← token
  let some n := word.toNat? | throw "expected natural number"
  return n

def primeField (p : Nat) : Except String PrimeField :=
  if bound : p < 2^31 then
    if h : Hex.Nat.isPrimeTrial p = true then
      .ok ⟨p.toUInt64, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : p < 2^64)] using Hex.Nat.isPrimeTrial_isPrime h, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : p < 2^64)] using bound⟩
    else .error "modulus is not prime"
  else .error "modulus out of bounds"

def parse : Parser (Context × Array RawPolynomial) := do
  let p ← natural
  let field ← liftM (primeField p)
  let variables ← natural
  let order ← token
  let order ← match order with
    | "lex" => pure TermOrder.lex
    | "grlex" => pure TermOrder.grlex
    | "grevlex" => pure TermOrder.grevlex
    | _ => throw "unknown monomial order"
  let count ← natural
  let mut generators := #[]
  for _ in [:count] do
    let terms ← natural
    let mut polynomial := #[]
    for _ in [:terms] do
      let coefficient ← natural
      if coefficient ≥ 2^64 then throw "coefficient exceeds UInt64"
      let mut exponents := #[]
      for _ in [:variables] do exponents := exponents.push (← natural)
      polynomial := polynomial.push ⟨exponents,coefficient.toUInt64⟩
    generators := generators.push polynomial
  if !(← get).isEmpty then throw "trailing input"
  return (⟨field,variables,order⟩,generators)

def array (xs : Array String) : String := "["++String.intercalate "," xs.toList++"]"
def polynomial (p : RawPolynomial) : String := array (p.map fun t =>
  array #[array (t.exponents.map toString),toString t.coefficient.toNat])

def main (args : List String) : IO Unit := do
  let [filename] := args | throw (IO.userError "production_compare input.txt")
  let source ← IO.FS.readFile filename
  let words := ((source.splitOn "\n").flatMap (·.splitOn "\t")).flatMap (·.splitOn " ")
  let ((context,generators),_) ← IO.ofExcept (parse.run (words.filter (· != "")))
  let limits : Limits := {
    work := 100000000000
    packedBytes := 16 * 1024 * 1024 * 1024
    matrixEntries := 1000000000
    pairs := 100000000
    monomials := 10000000 }
  let start ← IO.monoNanosNow
  let (candidate,stats) ← match computeWith context limits generators with
    | .candidate c s => pure (c,s)
    | .invalid e _ => throw (IO.userError s!"invalid {reprStr e}")
    | .internal e _ => throw (IO.userError s!"internal {reprStr e}")
    | .exhausted r _ => throw (IO.userError s!"exhausted {reprStr r}")
    | .representation e _ => throw (IO.userError s!"representation {reprStr e}")
  let stop ← IO.monoNanosNow
  let fields : List (String × String) := [
    ("basis",array (candidate.polynomials.map polynomial)),
    ("candidate_nanos",toString (stop-start)),("reference","false"),
    ("work",toString stats.work),("allocated_bytes",toString stats.allocatedBytes),
    ("rounds",toString stats.rounds),("pairs",toString stats.pairs),
    ("matrix_calls",toString stats.matrixCalls),("matrix_entries",toString stats.matrixEntries),
    ("largest_batch",toString stats.largestBatch),
    ("peak_matrix_rows",toString stats.peakMatrixRows),("peak_matrix_entries",toString stats.peakMatrixEntries),
    ("batch_cap",toString candidate.batchSize),
    ("native_rows",toString candidate.nativeRows),("native_monomials",toString candidate.nativeMonomials),
    ("gebauer_moller",toString candidate.gebauerMoller),("batch_interreduce",toString candidate.batchInterreduce)]
  IO.println ("{"++String.intercalate "," (fields.map fun (name,value) => "\""++name++"\":"++value)++"}")
