from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();payload={}
records=[]
for kind in ['native','full']:
 rows=json.loads((state/f'native-cc-verified-{kind}-status.json').read_text())
 assert len(rows)==(2 if kind=='native'else 9)
 assert all(row['exit_code']==0 and all(row[k]==v for k,v in identity.items())for row in rows)
 records.extend(rows)
def add(name,path):
 assert name not in payload
 payload[name]=path.read_bytes()
for label in ['native-cc-default','native-cc-reviewed']:
 base=state/(label+'-production')
 for path in sorted(base.rglob('*')):
  if path.is_file()and'binaries'not in path.relative_to(base).parts:add(label+'/'+str(path.relative_to(base)),path)
for family,label in [(FAMILY,'runtime'),(CHECKS,'checks')]:
 text=tree_listing(family,'HEAD');payload[label+'.manifest']=text.encode()
 for line in text.splitlines():
  _,oid,rest=line.split(' ',2);_,path=rest.split('\t')
  payload[label+'-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for row in records:
 if 'log'in row:add('full/'+row['name']+'.log',Path(row['log']))
for kind in ['native','full']:
 add(kind+'-status.json',state/f'native-cc-verified-{kind}-status.json')
 add(kind+'-checks.py',state/f'native-cc-verified-{kind}-checks.py')
for cc in ['clang','gcc']:
 add(cc+'.log',state/f'native-cc-verified-{cc}.log')
 directory=state/f'native-cc-verified-{cc}'
 for path in sorted(directory.rglob('*')):
  if path.is_file()and'.lake'not in path.relative_to(directory).parts:add('probes/'+cc+'/'+str(path.relative_to(directory)),path)
for name in ['native-compiler-option-cache-status.json','native-cc-verification-bridge.json','check-native-compiler-option.py']:
 add(name,state/name)
for label in ['default','clang','cached','gcc','restored']:
 add('cache/'+label+'.log',state/f'native-compiler-option-{label}.log')
for name in ['sdk-native-build.log','native-cc-verified-freeze.log']:
 add('diagnostics/'+name,state/name)
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode()
add('pack.py',Path(__file__))
digests={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())}
payload['sha256.json']=(json.dumps(digests,indent=2)+'\n').encode()
out=state/('f4-native-cc-guards-'+identity['source_fingerprint']+'.tar.xz')
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-native-cc-guards/'+name);entry.size=len(data);entry.mode=0o644
  tar.addfile(entry,io.BytesIO(data))
print(out,len(digests),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
