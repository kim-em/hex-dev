from pathlib import Path
import hashlib,json,os,subprocess
s=Path('/home/kim/tmp/issue-10987');root=Path.cwd();directory=root/'.lake/build/HexGroebner/ffi';files=['row_update.o','monomial_hit.o','matrix_state.o','matrix_eliminate.o','matrix_scan.o'];targets=['hexgroebnerRowsO','hexgroebnerMonomialO','hexgroebnerStateO','hexgroebnerEliminationO','hexgroebnerScanO'];records=[];env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR=str(s));options=[('default',[], 'clang version 21.1.8'),('clang',['-KhexGroebnerCC=/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang'],'clang version 23.1.3'),('cached',['-KhexGroebnerCC=/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/bin/clang'],'clang version 23.1.3'),('gcc',['-KhexGroebnerCC=/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/gcc'],'16.2.0'),('restored',[], 'clang version 21.1.8')]
for label,flags,version in options:
 before={name:(directory/name).stat().st_mtime_ns for name in files}
 command=['lake','-R',*flags,'build',*targets]
 with(s/f'native-compiler-option-{label}.log').open('w')as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,label
 after={name:(directory/name).stat().st_mtime_ns for name in files};digests={name:hashlib.sha256((directory/name).read_bytes()).hexdigest()for name in files};comments={name:subprocess.check_output(['readelf','-p','.comment',str(directory/name)],text=True)for name in files};assert all(version in text for text in comments.values())
 if label=='cached':assert before==after
 elif label!='default':assert all(before[name]!=after[name]for name in files)
 if label=='restored':assert digests==records[0]['object_sha256']
 records.append(dict(label=label,command=command,exit_code=r.returncode,mtime_before=before,mtime_after=after,object_sha256=digests,compiler_comments=comments));(s/'native-compiler-option-cache-status.json').write_text(json.dumps(records,indent=2)+'\n');print(label,r.returncode,flush=True)
