/* Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
   Released under Apache 2.0 license as described in the file LICENSE.
   Authors: Kim Morrison */
#ifndef HEX_GROEBNER_DELAYED32_SIMD_H
#define HEX_GROEBNER_DELAYED32_SIMD_H
#include "matrix_simd.h"
#if HEX_GROEBNER_AVX2
/* Eight exact u32 accumulators. A block reduces every old accumulator
   before addition when any lane would overflow. The reciprocal is floor(2^32/p). For
   p<=65536, (p-1)^2+(p-1)<2^32, so the repaired addition cannot overflow. */
__attribute__((target("avx2"),always_inline))
static inline unsigned hex_delayed32_8(uint8_t *dense,const uint8_t *columns,
        const uint8_t *coefficients,size_t entry,uint64_t column_count,
        uint32_t p,uint32_t factor,uint32_t reciprocal) {
    if(p<=256 || p>65536 || factor>=p) return 0;
    __m256i ids=_mm256_loadu_si256((const __m256i *)(const void *)(columns+entry*4));
    int32_t first=_mm256_extract_epi32(ids,0),last=_mm256_extract_epi32(ids,7);
    if(first<0 || last<0 || (uint64_t)last>=column_count) return 0;
    if(entry) {uint32_t previous;memcpy(&previous,columns+(entry-1)*4,4);if(previous>=(uint32_t)first) return 0;}
    __m256i before=_mm256_permutevar8x32_epi32(ids,_mm256_setr_epi32(0,0,1,2,3,4,5,6));
    __m256i sorted=_mm256_or_si256(_mm256_cmpgt_epi32(ids,before),_mm256_setr_epi32(-1,0,0,0,0,0,0,0));
    __m256i b=_mm256_cvtepu16_epi32(_mm_loadu_si128((const __m128i *)(const void *)(coefficients+entry*2)));
    __m256i pv=_mm256_set1_epi32((int32_t)p),zero=_mm256_setzero_si256();
    __m256i valid=_mm256_and_si256(sorted,_mm256_and_si256(_mm256_cmpgt_epi32(b,zero),_mm256_cmpgt_epi32(pv,b)));
    if(_mm256_movemask_epi8(valid)!=-1) return 0;
    __m256i consecutive=_mm256_add_epi32(_mm256_set1_epi32(first),_mm256_setr_epi32(0,1,2,3,4,5,6,7));
    int contiguous=_mm256_movemask_epi8(_mm256_cmpeq_epi32(ids,consecutive))==-1;
    __m256i a=contiguous?_mm256_loadu_si256((const __m256i *)(const void *)(dense+(size_t)first*4)):
        _mm256_i32gather_epi32((const int *)(const void *)dense,ids,4);
    __m256i product=_mm256_mullo_epi32(_mm256_set1_epi32((int32_t)factor),_mm256_sub_epi32(pv,b));
    __m256i sum=_mm256_add_epi32(a,product),sign=_mm256_set1_epi32(INT32_MIN);
    __m256i overflow=_mm256_cmpgt_epi32(_mm256_xor_si256(a,sign),_mm256_xor_si256(sum,sign));
    if(_mm256_movemask_epi8(overflow)) {
        __m256i inv=_mm256_set1_epi32((int32_t)reciprocal);
        __m256i even=_mm256_srli_epi64(_mm256_mul_epu32(a,inv),32);
        __m256i odd=_mm256_srli_epi64(_mm256_mul_epu32(_mm256_srli_epi64(a,32),inv),32);
        __m256i q=_mm256_or_si256(even,_mm256_slli_epi64(odd,32));
        __m256i r=_mm256_sub_epi32(a,_mm256_mullo_epi32(q,pv));
        r=_mm256_sub_epi32(r,_mm256_and_si256(_mm256_cmpgt_epi32(r,_mm256_set1_epi32((int32_t)p-1)),pv));
        sum=_mm256_add_epi32(r,product);
    }
    if(contiguous) _mm256_storeu_si256((__m256i *)(void *)(dense+(size_t)first*4),sum);
    else {
        uint32_t indices[8],values[8];_mm256_storeu_si256((__m256i *)(void *)indices,ids);
        _mm256_storeu_si256((__m256i *)(void *)values,sum);
        for(unsigned i=0;i<8;++i) memcpy(dense+(size_t)indices[i]*4,values+i,4);
    }
    return 8;
}
#endif
#endif
