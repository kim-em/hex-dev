/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

public import HexGroebner.NativeScan
public import HexGroebner.NativeGather

@[expose] public section

namespace Hex.Groebner.Native.Delayed32
open Scan

/-! Exact delayed reduction with little-endian unsigned 32-bit accumulators.
Sparse pivots retain the field's minimal coefficient width. Adding `factor*(p-b)`
preserves subtraction modulo p. Reduce the old accumulator before an addition
that would overflow; reduce at column tests and output, and clear processed
slots. Every call retains the existing 4096-transition bound and failure prefix. -/

/-- Reduce all eight selected accumulators together when any addition would
 overflow. Invalid blocks leave scalar processing to preserve the first error. -/
def updateBlock (p factor columns start : Nat) (dense : ByteArray)
    (row : Pivot) : Option ByteArray := Id.run do
  let mut indices := #[]
  let mut products := #[]
  let mut values := #[]
  let mut reduce := false
  for k in [:8] do
    let entry := start+k
    let j := Native.read row.columns 4 (4*entry)
    let b := Native.read row.coefficients 2 (2*entry)
    if j ≥ columns || b == 0 || b ≥ p ||
        (entry > 0 && Native.read row.columns 4 (4*(entry-1)) ≥ j) then return none
    let a := Native.read dense 4 (4*j)
    let product := factor*(p-b)
    indices := indices.push j
    products := products.push product
    values := values.push a
    reduce := reduce || a+product ≥ 2^32
  let mut dense := dense
  for k in [:8] do
    let a := values[k]!
    dense := Native.write dense 4 (4*indices[k]!) ((if reduce then a%p else a)+products[k]!)
  return some dense

def scanPortable (modulus : UInt64) (slots : @& ByteArray) (pivots : @& Array Pivot)
    (initial : State) (quantum workLimit traceLimit : Nat) (provenance : Bool) : Result := Id.run do
  let p := modulus.toNat
  let w := Native.width p
  let capacity := 2^32
  let columns := initial.dense.size / 4
  let mut out : Result := { state := initial }
  if p < 2 || p > 65536 || quantum > 4096 || initial.dense.size % 4 != 0 ||
      columns > 4294967295 || slots.size != columns*4 || initial.column > columns ||
      (columns != 0 && initial.last ≥ columns) || initial.leading > columns ||
      initial.pending > pivots.size || pivots.size > 4294967295 ||
      initial.chargedUntil > columns || initial.entry > 4294967295 ||
      (initial.pending == 0 && initial.entry != 0) ||
      (initial.pending != 0 && initial.column ≥ columns) ||
      (columns == 0 && initial.last != 0) || initial.factor.toNat ≥ p then
    return { out with status := 4 }
  let mut skip := 0
  for tick in [:quantum] do
    if skip != 0 then
      skip := skip-1
      continue
    let s := out.state
    if s.pending != 0 then
      let pivot := pivots[s.pending-1]!
      let some size := rowSize w pivot | return { out with status := 4 }
      if s.entry > size then return { out with status := 4 }
      if s.entry == size then
        if Native.read s.dense 4 (4*s.column) % p != 0 then return { out with status := 4 }
        out := { out with reductions := out.reductions+1 }
        if provenance then
          if out.traceNodes ≥ traceLimit then return { out with status := 3 }
          out := { out with events := out.events.push (s.pending - 1, s.factor), traceNodes := out.traceNodes+1 }
        out := { out with state := { s with dense := Native.write s.dense 4 (4*s.column) 0, pending := 0, entry := 0, column := s.column+1 } }
      else
        if w == 2 && size-s.entry ≥ 8 && quantum-tick ≥ 8 then
          if let some dense := updateBlock p s.factor.toNat columns s.entry s.dense pivot then
            out := { out with state := { s with dense, entry := s.entry+8 } }
            skip := 7
            continue
        let j := Native.read pivot.columns 4 (4*s.entry)
        let b := Native.read pivot.coefficients w (w*s.entry)
        if j ≥ columns || b == 0 || b ≥ p || (s.entry > 0 &&
            Native.read pivot.columns 4 (4*(s.entry-1)) ≥ j) then
          return { out with status := 4 }
        let a := Native.read s.dense 4 (4*j)
        let product := s.factor.toNat * (p-b)
        let a := if a+product ≥ capacity then a%p else a
        out := { out with state := { s with dense := Native.write s.dense 4 (4*j) (a+product), entry := s.entry+1 } }
    else
      if s.column ≥ columns || s.column > s.last then return { out with status := 1 }
      if s.column ≥ s.chargedUntil then
        let stop := min (s.column+64) (s.last+1)
        let charge := stop-s.column
        if out.work+charge > workLimit then return { out with status := 2 }
        out := { out with work := out.work+charge, state := { out.state with chargedUntil := stop } }
      let s := out.state
      let a := Native.read s.dense 4 (4*s.column) % p
      let slot := Native.read slots 4 (4*s.column)
      if a == 0 || slot == 0 then
        let dense := if a == 0 then Native.write s.dense 4 (4*s.column) 0 else s.dense
        out := { out with state := { s with dense, column := s.column+1, leading := if a != 0 && s.leading == 0 then s.column+1 else s.leading } }
      else
        if slot > pivots.size then return { out with status := 4 }
        let pivot := pivots[slot-1]!
        let some size := rowSize w pivot | return { out with status := 4 }
        if Native.read pivot.columns 4 0 != s.column || Native.read pivot.coefficients w 0 != 1 then
          return { out with status := 4 }
        let last := Native.read pivot.columns 4 (4*(size-1))
        if last ≥ columns then return { out with status := 4 }
        out := { out with state := { s with last := max s.last last, sugar := max s.sugar pivot.sugar } }
        if out.work+size > workLimit then return { out with status := 2 }
        out := { out with work := out.work+size, state := { out.state with
          pending := slot, entry := 0, factor := a.toUInt64 } }
  return out

@[extern "lean_hex_delayed32_scan_transition"]
def transition (modulus : UInt64) (slots : @& ByteArray) (pivots : @& Array Pivot)
    (initial : State) (quantum workLimit traceLimit : @& Nat) (provenance : Bool) : Result :=
  scanPortable modulus slots pivots initial quantum workLimit traceLimit provenance

def gatherPortable (modulus : UInt64) (initial : Gather.State) (stop quantum entriesLimit bytesLimit workLimit : Nat)
    (factor : UInt64) : Gather.Result := Id.run do
  let p := modulus.toNat
  let w := Native.width p
  let size := initial.dense.size/4
  let count := initial.columns.size/4
  let mut out : Gather.Result := { state := initial }
  if p < 2 || p > 65536 || factor == 0 || factor.toNat ≥ p || quantum > 4096 ||
      initial.dense.size%4 != 0 || size > 4294967295 || initial.cursor > stop || stop > size ||
      initial.columns.size%4 != 0 || initial.coefficients.size != count*w then
    return { out with status := 5 }
  for _ in [:quantum] do
    let s := out.state
    if s.cursor ≥ stop then return { out with status := 1 }
    let a := Native.read s.dense 4 (s.cursor*4) % p
    if a != 0 then
      if s.columns.size > 0 && Native.read s.columns 4 (s.columns.size-4) ≥ s.cursor then
        return { out with status := 6 }
      if out.entries ≥ entriesLimit then return { out with status := 2 }
      out := { out with entries := out.entries+1 }
      if out.bytes+4+w > bytesLimit then return { out with status := 3 }
      out := { out with bytes := out.bytes+4+w }
      if s.columns.size+4 ≥ USize.size || s.coefficients.size+w ≥ USize.size then
        return { out with status := 5 }
      if factor != 1 then
        if out.work ≥ workLimit then return { out with status := 4 }
        out := { out with work := out.work+1 }
      let value := a*factor.toNat%p
      out := { out with state := ⟨Native.write s.dense 4 (s.cursor*4) 0,
        Gather.push 4 s.columns s.cursor,Gather.push w s.coefficients value,s.cursor+1⟩ }
    else out := { out with state := { s with dense := Native.write s.dense 4 (s.cursor*4) 0, cursor := s.cursor+1 } }
  return out

@[extern "lean_hex_delayed32_gather"]
def gather (modulus : UInt64) (initial : Gather.State)
    (stop quantum entriesLimit bytesLimit workLimit : @& Nat) (factor : UInt64) : Gather.Result :=
  gatherPortable modulus initial stop quantum entriesLimit bytesLimit workLimit factor

end Hex.Groebner.Native.Delayed32
