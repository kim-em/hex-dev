/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

public import HexMvPoly

public section

/-!
Downstream module-boundary checks for the kernel-reduction closure of
`Hex.MvPoly`.
-/

namespace Hex.MvPoly.KernelTests

open Hex
open scoped Hex

abbrev P := MvPoly 2 Int Mono.lex

@[expose] def x : P := X 0
@[expose] def y : P := X 1
@[expose] def p : P := C 1 + x + y

example : p + -p = 0 := by
  decide +kernel

example : (p == p) = true := by
  decide +kernel

example : coeff (Mono.unit 0) p = 1 := by
  decide +kernel

example :
    p * p =
      ofTerms
        [(Mono.zero, 1),
         (Mono.unit 0, 2),
         (Mono.unit 1, 2),
         (Mono.mul (Mono.unit 0) (Mono.unit 0), 1),
         (Mono.mul (Mono.unit 0) (Mono.unit 1), 2),
         (Mono.mul (Mono.unit 1) (Mono.unit 1), 1)] := by
  decide +kernel

example : p ^ 3 = p * p * p := by
  decide +kernel

example : Mono.powBySq (3 : Int) 13 = 1594323 := by
  decide +kernel

example :
    Mono.dvd (Mono.unit 0 : Mono 2)
      (Mono.succAt 0 (Mono.unit 0 : Mono 2)) = true := by
  decide +kernel

example :
    Mono.div (Mono.unit 0 : Mono 2)
        (Mono.succAt 0 (Mono.unit 0 : Mono 2)) =
      some (Mono.unit 0 : Mono 2) := by
  decide +kernel

example :
    Mono.lcm (Mono.unit 0 : Mono 2) (Mono.unit 1 : Mono 2) =
      Mono.mul (Mono.unit 0 : Mono 2) (Mono.unit 1 : Mono 2) := by
  decide +kernel

example :
    Mono.gcd (Mono.unit 0 : Mono 2) (Mono.unit 1 : Mono 2) = Mono.zero := by
  decide +kernel

example : Mono.lex #v[1, 5] #v[2, 0] = .lt := by
  decide +kernel

example : Mono.grlex #v[2, 0] #v[1, 2] = .lt := by
  decide +kernel

example : Mono.grevlex #v[1, 1] #v[2, 0] = .lt := by
  decide +kernel

example : Mono.grlex #v[2, 0, 1] #v[1, 2, 0] = .gt := by
  decide +kernel

example : Mono.grevlex #v[2, 0, 1] #v[1, 2, 0] = .lt := by
  decide +kernel

example :
    Mono.grevlex #v[1, 1] #v[2, 0] =
      Mono.grevlex
        (Mono.mul #v[1, 1] #v[3, 4])
        (Mono.mul #v[2, 0] #v[3, 4]) := by
  decide +kernel

abbrev GP := MvPoly 2 Int Mono.grlex

@[expose] def gx : GP := X 0
@[expose] def gy : GP := X 1

example : gx * gy + gy * gx = ofTerms
    [(Mono.mul (Mono.unit 0) (Mono.unit 1), 2)] := by
  decide +kernel

abbrev QP := MvPoly 2 Rat Mono.grevlex

@[expose] def qx : QP := X 0
@[expose] def qy : QP := X 1
@[expose] def q : QP := C (1 / 2) + qx + qy

example : q * (qx - qy) + q * (qy - qx) = 0 := by
  decide +kernel

example : eval (fun i => if i = 0 then 2 else 3) q = 11 / 2 := by
  decide +kernel

example :
    eval₂ (fun c : Int => 2 * c) (fun i => if i = 0 then 2 else 3) p = 12 := by
  decide +kernel

example :
    reorder Mono.grevlex p =
      (ofTerms
        [(Mono.zero, 1), (Mono.unit 0, 1), (Mono.unit 1, 1)] :
        MvPoly 2 Int Mono.grevlex) := by
  decide +kernel

example :
    rename Mono.lex (fun _ => (0 : Fin 1)) p =
      (C 1 + C 2 * X 0 : MvPoly 1 Int Mono.lex) := by
  decide +kernel

example :
    subst (targetCmp := Mono.lex)
        (fun i => if i = 0 then (X 0 : P) + C 1 else C 2) p =
      X 0 + C 4 := by
  decide +kernel

@[expose] def sparse : P :=
  ofTerms
    [(#v[4, 0], 2), (#v[1, 2], 3), (#v[0, 3], -1), (Mono.zero, 5)]

example :
    homogeneousComponent 3 sparse =
      ofTerms [(#v[1, 2], 3), (#v[0, 3], -1)] := by
  decide +kernel

example :
    evalHorner (fun i => if i = 0 then 2 else 3) sparse = 64 := by
  decide +kernel

example :
    evalHorner (fun i => if i = 0 then 2 else 3) sparse =
      eval (fun i => if i = 0 then 2 else 3) sparse := by
  decide +kernel

example :
    partialEval (fun i => if i = 0 then some 2 else none) sparse =
      ofTerms
        [(Mono.zero, 37), (#v[0, 2], 6), (#v[0, 3], -1)] := by
  decide +kernel

example :
    partialEval (fun i => if i = 0 then some 2 else none)
        (ofTerms [(#v[1, 0], 1), (Mono.zero, -2)] : P) =
      0 := by
  decide +kernel

@[expose] def outerGap : P :=
  ofTerms [(#v[4, 0], 2), (#v[2, 1], 3)]

example :
    evalHorner (fun i => if i = 0 then 2 else 3) outerGap = 68 := by
  decide +kernel

theorem splitFirst_roundtrip :
    ofUnivariate (cmp := Mono.grevlex) 0 Mono.lex
      (toUnivariate 0 Mono.lex q) = q := by
  decide +kernel

theorem splitLast_roundtrip :
    ofUnivariate (cmp := Mono.grevlex) 1 Mono.lex
      (toUnivariate 1 Mono.lex q) = q := by
  decide +kernel

@[expose] def gapCoeffs : DensePoly (MvPoly 1 Rat Mono.lex) :=
  DensePoly.ofList [C 2 + X 0, 0, C 3]

theorem gapCoeffs_roundtrip :
    toUnivariate 1 Mono.lex
        (ofUnivariate (cmp := Mono.grevlex) 1 Mono.lex gapCoeffs) =
      gapCoeffs := by
  decide +kernel

abbrev P3 := MvPoly 3 Int Mono.lex

@[expose] def middleSplit : P3 :=
  ofTerms [(#v[2, 3, 4], 5), (#v[0, 1, 2], -7), (Mono.zero, 11)]

theorem middleSplit_roundtrip :
    ofUnivariate (cmp := Mono.lex) 1 Mono.grevlex
      (toUnivariate 1 Mono.grevlex middleSplit) = middleSplit := by
  decide +kernel

theorem zero_roundtrip :
    ofUnivariate (cmp := Mono.grevlex) 1 Mono.lex
      (toUnivariate 1 Mono.lex (0 : QP)) = 0 := by
  decide +kernel

abbrev P0 := MvPoly 0 Int Mono.lex

example : (C 7 : P0) + C (-7) = 0 := by
  decide +kernel

example : evalHorner (fun i => nomatch i) (C 7 : P0) = 7 := by
  decide +kernel

abbrev P1 := MvPoly 1 Int Mono.lex

theorem oneVar_roundtrip :
    ofUnivariate (cmp := Mono.lex) 0 Mono.lex
      (toUnivariate 0 Mono.lex ((X 0 : P1) * X 0 + C 7)) =
        (X 0 : P1) * X 0 + C 7 := by
  decide +kernel

example : (X 0 : P1) * X 0 = monomial
    (Mono.succAt 0 (Mono.unit 0)) 1 := by
  decide +kernel

/-! # Canonical list-form replay -/

abbrev PL := Kernel.PolyList Int

@[expose] def listX : PL := [([1, 0], 1)]
@[expose] def listY : PL := [([0, 1], 1)]
@[expose] def listP : PL := Kernel.add (Kernel.one 2) (Kernel.add listX listY)

example : Kernel.isCanonical 2 listP = true := by
  decide +kernel

example : Kernel.beq (Kernel.add listP (Kernel.neg listP)) [] = true := by
  decide +kernel

example : Kernel.isZero (Kernel.add listP (Kernel.neg listP)) = true := by
  decide +kernel

example :
    Kernel.beq (Kernel.mul listP listP)
      [([2, 0], 1), ([1, 1], 2), ([1, 0], 2),
       ([0, 2], 1), ([0, 1], 2), ([0, 0], 1)] = true := by
  decide +kernel

example : Kernel.evalAt [2, 3] listP = 6 := by
  decide +kernel

abbrev QPL := Kernel.PolyList Rat

@[expose] def listQ : QPL :=
  [([1, 0], 1), ([0, 1], 1), ([0, 0], 1 / 2)]

example : Kernel.evalAt [2, 3] listQ = 11 / 2 := by
  decide +kernel

example : Kernel.isCanonical 2 listQ = true := by
  decide +kernel

example : Kernel.beq (Kernel.mul listQ listQ)
    [([2, 0], 1), ([1, 1], 2), ([1, 0], 1),
     ([0, 2], 1), ([0, 1], 1), ([0, 0], 1 / 4)] = true := by
  decide +kernel

example : Kernel.beq (Kernel.smul (1 / 3) listQ)
    [([1, 0], 1 / 3), ([0, 1], 1 / 3), ([0, 0], 1 / 6)] = true := by
  decide +kernel

example : Kernel.isZero (Kernel.sub listQ listQ) = true := by
  decide +kernel

example : Kernel.beq (Kernel.add listQ (Kernel.neg listQ)) [] = true := by
  decide +kernel

/-- Dot product over canonical polynomial lists. -/
@[expose] def listDot : List PL → List PL → PL
  | a :: as, b :: bs => Kernel.add (Kernel.mul a b) (listDot as bs)
  | _, _ => []

/-- The first `n` columns of a row-list matrix. -/
@[expose] def listColumns : Nat → List (List PL) → List (List PL)
  | 0, _ => []
  | n + 1, rows =>
      rows.map (fun row => row.getD 0 []) ::
        listColumns n (rows.map (fun row => row.drop 1))

/-- Matrix multiplication used only by the closed certificate replay below. -/
@[expose] def listMatMul (columns : Nat) (a b : List (List PL)) :
    List (List PL) :=
  let bs := listColumns columns b
  a.map fun row => bs.map (listDot row)

/-- Entrywise equality through the polynomial list equality checker. -/
@[expose] def listMatrixBeq : List (List PL) → List (List PL) → Bool
  | [], [] => true
  | a :: as, b :: bs =>
      (a.zip b).all (fun e => Kernel.beq e.1 e.2) &&
        Nat.beq a.length b.length && listMatrixBeq as bs
  | _, _ => false

@[expose] def listDiag4 (a : PL) : List (List PL) :=
  [[a, [], [], []], [[], a, [], []], [[], [], a, []], [[], [], [], a]]

/- The tridiagonal matrix has diagonal p = x + y + 1 and off-diagonal 1.
Its adjugate and determinant are independent coefficient literals, so replay
checks real cross-term cancellation rather than repeating an expression. -/
@[expose] def listTri4 : List (List PL) :=
  [[listP, [([0, 0], 1)], [], []],
   [[([0, 0], 1)], listP, [([0, 0], 1)], []],
   [[], [([0, 0], 1)], listP, [([0, 0], 1)]],
   [[], [], [([0, 0], 1)], listP]]

@[expose] def listAdj4 : List (List PL) :=
  let a : PL :=
    [([3, 0], 1), ([2, 1], 3), ([2, 0], 3), ([1, 2], 3), ([1, 1], 6),
     ([1, 0], 1), ([0, 3], 1), ([0, 2], 3), ([0, 1], 1), ([0, 0], -1)]
  let b : PL :=
    [([2, 0], -1), ([1, 1], -2), ([1, 0], -2), ([0, 2], -1), ([0, 1], -2)]
  let c : PL :=
    [([3, 0], 1), ([2, 1], 3), ([2, 0], 3), ([1, 2], 3), ([1, 1], 6),
     ([1, 0], 2), ([0, 3], 1), ([0, 2], 3), ([0, 1], 2)]
  let d : PL :=
    [([2, 0], -1), ([1, 1], -2), ([1, 0], -2),
     ([0, 2], -1), ([0, 1], -2), ([0, 0], -1)]
  let p : PL := [([1, 0], 1), ([0, 1], 1), ([0, 0], 1)]
  let m : PL := [([0, 0], -1)]
  [[a, b, p, m], [b, c, d, p], [p, d, c, b], [m, p, b, a]]

@[expose] def listDet4 : PL :=
  [([4, 0], 1), ([3, 1], 4), ([3, 0], 4), ([2, 2], 6), ([2, 1], 12),
   ([2, 0], 3), ([1, 3], 4), ([1, 2], 12), ([1, 1], 6), ([1, 0], -2),
   ([0, 4], 1), ([0, 3], 4), ([0, 2], 3), ([0, 1], -2), ([0, 0], -1)]

example : listAdj4.all (fun row => row.all (Kernel.isCanonical 2)) = true := by
  decide +kernel

example : listTri4.all (fun row => row.all (Kernel.isCanonical 2)) = true := by
  decide +kernel

example : Kernel.isCanonical 2 listDet4 = true := by
  decide +kernel

set_option trace.profiler true in
/-- A `4 × 4` tridiagonal adjugate identity. Its proof term evaluates only
`List`, `Nat`, and `Int` primitives on the certificate path. -/
theorem list_certificate_4x4 :
    listMatrixBeq (listMatMul 4 listTri4 listAdj4) (listDiag4 listDet4) = true := by
  decide +kernel

example : listMatrixBeq (listMatMul 4 listAdj4 listTri4) (listDiag4 listDet4) = true := by
  decide +kernel

-- A corrupted certificate must be rejected.
example : listMatrixBeq (listMatMul 4 listTri4 listAdj4)
    (listDiag4 (Kernel.add listDet4 (Kernel.one 2))) = false := by
  decide +kernel

example : Kernel.Canonical 2 listP := by
  exact Kernel.isCanonical_iff.mp (by decide +kernel)

example :
    Kernel.isZero (Kernel.add listP (Kernel.neg listP)) = true ↔
      Kernel.denote (cmp := Mono.lex)
        (n := 2)
        (Kernel.add listP (Kernel.neg listP)) = 0 :=
  Kernel.isZero_iff
    (Kernel.add_canonical
      ((Kernel.isCanonical_iff (n := 2) (p := listP)).mp (by decide +kernel))
      (Kernel.neg_canonical
        ((Kernel.isCanonical_iff (n := 2) (p := listP)).mp (by decide +kernel))))

example : Kernel.beq (Kernel.mul listP listP) (Kernel.mul listP listP) = true :=
  Kernel.beq_refl _

/-! # Axiom hygiene -/

/-- info: 'Hex.MvPoly.KernelTests.list_certificate_4x4' depends on axioms: [propext] -/
#guard_msgs in
#print axioms list_certificate_4x4

/-- info: 'Hex.MvPoly.KernelTests.splitFirst_roundtrip' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms splitFirst_roundtrip

/-- info: 'Hex.MvPoly.KernelTests.splitLast_roundtrip' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms splitLast_roundtrip

/-- info: 'Hex.MvPoly.KernelTests.gapCoeffs_roundtrip' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms gapCoeffs_roundtrip

/-- info: 'Hex.MvPoly.KernelTests.middleSplit_roundtrip' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms middleSplit_roundtrip

/-- info: 'Hex.MvPoly.KernelTests.zero_roundtrip' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms zero_roundtrip

/-- info: 'Hex.MvPoly.KernelTests.oneVar_roundtrip' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms oneVar_roundtrip

/-- info: 'Hex.Mono.instLexOrder' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms Hex.Mono.instLexOrder

/-- info: 'Hex.Mono.instGrlexOrder' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms Hex.Mono.instGrlexOrder

/-- info: 'Hex.Mono.instGrevlexOrder' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms Hex.Mono.instGrevlexOrder

/-- info: 'Hex.MvPoly.coeff_pow_succ' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms Hex.MvPoly.coeff_pow_succ

/-- info: 'Hex.MvPoly.pow_succ' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms Hex.MvPoly.pow_succ

/-- info: 'Hex.MvPoly.mul_assoc' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms Hex.MvPoly.mul_assoc

/-- info: 'Hex.MvPoly.mul_comm' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms Hex.MvPoly.mul_comm

/-- info: 'Hex.MvPoly.mul_add' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms Hex.MvPoly.mul_add

/-- info: 'Hex.MvPoly.partialEval_eq_subst' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs in
#print axioms Hex.MvPoly.partialEval_eq_subst

end Hex.MvPoly.KernelTests
