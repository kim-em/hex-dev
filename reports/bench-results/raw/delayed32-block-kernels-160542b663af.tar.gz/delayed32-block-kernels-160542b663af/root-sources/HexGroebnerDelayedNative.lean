/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/
module

/-! Native carrier for delayed matrix bindings. Their shared state types and C
providers come from the matrix carrier, which must be loaded before this one. -/
