/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

public import HexArith.ExtGcd
public import HexArith.Nat.ModArith
public import HexArith.UInt64.Wide

public section

/-!
Machine-word residues in `ZMod64`.

This module introduces the `UInt64`-backed residue type `Hex.ZMod64 p`
together with a project-local modulus-bounds typeclass, smart construction by
reduction mod `p`, the initial additive and multiplicative API, executable
exponentiation and inversion helpers, and the default extern-backed
multiplication contract.
-/
namespace Hex

namespace ZMod64

/-- `ZMod64 p` is only valid when `p` is positive and strictly below `2^31`.
This small-modulus invariant keeps every residue and the modulus in a `UInt64`,
makes the sum of two residues fit in a word without carry, and keeps the product
of two residues below `2^62`, so the modular multiply reduces a single word (no
`__uint128_t`) and future convolution kernels can accumulate several products
before one reduction (Barrett/lazy). Every current and anticipated application
(Berlekamp-Zassenhaus, LLL, matrix work) uses small primes, so no needed
generality is lost. -/
class Bounds (p : Nat) : Prop where
  /-- The modulus is positive. -/
  pPos : 0 < p
  /-- The modulus is strictly below `2^31`. -/
  pLtR : p < 2 ^ 31

/-- The modulus is strictly below the machine-word size `2^64`, so it and every
residue fit in a `UInt64`. Derived from the `p < 2^31` bound. -/
theorem Bounds.pLtWord (p : Nat) [Bounds p] : p < UInt64.word :=
  Nat.lt_trans (Bounds.pLtR (p := p)) (by decide)

/-- The canonical `Bounds 2`, for the whole project.

`Bounds` has no general instance: the two conditions are decidable for a
literal, but instance search cannot run `decide` on the goal, so every modulus
needs its own witness. `p = 2` is wanted almost everywhere (`GF(2)`, the
`FpPoly 2` pow-chain checkers, the Conway table), and it used to be re-declared
in each place: six public copies across five files, in `HexBerlekamp`,
`HexConway`, `HexGF2Theory` (three) and `HexGFqTheory`. Any module importing
several saw that many equal-priority candidates, and further copies in test and
guard modules were captured into emitted proof terms, producing errors naming
constants nobody had written.

Declaring it here, alongside the class, gives every consumer one candidate
reachable by the import they already have. A module needing some other modulus
should use `local instance`, or a `private theorem` plus
`attribute [local instance]` to keep the name unexported too. Never
`private instance`: that leaves the instance visible to search in importing
modules while making its name unreferenceable there. -/
instance boundsTwo : Bounds 2 := ⟨by decide, by decide⟩

end ZMod64

/-- Residues mod `p` stored in a single machine word, with a proof of reduction. -/
structure ZMod64 (p : Nat) [ZMod64.Bounds p] where
  /-- The backing machine word holding the standard representative. -/
  val : UInt64
  /-- Proof that the stored word is already reduced below the modulus. -/
  isLt : val.toNat < p

namespace ZMod64

variable {p : Nat} [Bounds p]

/-- View a residue as its reduced Nat representative. -/
@[expose]
def toNat (a : ZMod64 p) : Nat :=
  a.val.toNat

/-- View a residue as its underlying `UInt64` word. -/
@[expose]
def toUInt64 (a : ZMod64 p) : UInt64 :=
  a.val

/-- Equality of residues is equality of the stored words: the reduction
proof is irrelevant. -/
instance : DecidableEq (ZMod64 p) := fun a b =>
  if h : a.val = b.val then
    isTrue (by
      cases a
      cases b
      cases h
      rfl)
  else
    isFalse (by
      intro hab
      cases hab
      exact h rfl)

instance : CoeOut (ZMod64 p) UInt64 where
  coe := toUInt64

instance : CoeOut (ZMod64 p) Nat where
  coe := toNat

/-- Converting a residue to `UInt64` exposes exactly the stored word. -/
@[simp, grind =] theorem toUInt64_eq_val (a : ZMod64 p) : a.toUInt64 = a.val := rfl

/-- Converting a residue to `Nat` reads the stored word as its canonical representative. -/
@[simp, grind =] theorem toNat_eq_val (a : ZMod64 p) : a.toNat = a.val.toNat := rfl

/-- The Nat view of a residue is always the canonical representative below the modulus. -/
@[simp] theorem toNat_lt (a : ZMod64 p) : a.toNat < p := a.isLt

/-- Extensionality for residues via equality of their stored machine words. -/
@[ext] theorem ext {a b : ZMod64 p} (h : a.val = b.val) : a = b := by
  cases a
  cases b
  cases h
  rfl

/-- Extensionality for residues via their canonical Nat representatives. -/
@[grind .]
theorem ext_toNat {a b : ZMod64 p} (h : a.toNat = b.toNat) : a = b :=
  ext (UInt64.toNat_inj.mp h)

/-- Reduce a Nat representative modulo `p`. -/
@[expose]
def normalize (p n : Nat) : Nat :=
  n % p

/-- Normalization always returns a canonical representative below the modulus. -/
theorem normalize_lt (p n : Nat) [Bounds p] : normalize p n < p :=
  Nat.mod_lt _ (Bounds.pPos (p := p))

/-- Normalizing an already canonical representative leaves it unchanged. -/
@[simp, grind =] theorem normalize_of_lt {q n : Nat} (hn : n < q) : normalize q n = n := by
  rw [normalize, Nat.mod_eq_of_lt hn]

/-- Normalizing a residue's canonical representative leaves it unchanged. -/
@[simp, grind =] theorem normalize_toNat (a : ZMod64 p) : normalize p a.toNat = a.toNat :=
  normalize_of_lt a.toNat_lt

/--
Build a reduced residue by taking the Nat representative mod `p`.

The bound `p < 2^64` ensures the reduced representative is stored faithfully in
the backing `UInt64`.
-/
@[expose]
def ofNat (p n : Nat) [Bounds p] : ZMod64 p := by
  let reduced := normalize p n
  have hred : reduced < p := normalize_lt p n
  have hword : reduced < UInt64.word := Nat.lt_trans hred (Bounds.pLtWord p)
  have hsize : reduced < UInt64.size := by
    simpa [UInt64.word, UInt64.size] using hword
  refine ⟨UInt64.ofNatLT reduced hsize, ?_⟩
  change (UInt64.ofNatLT reduced hsize).toNat < p
  rw [UInt64.toNat_ofNatLT]
  exact hred

/-- The Nat representative of `ofNat p n` is `n` reduced modulo `p`. -/
@[simp, grind =] theorem toNat_ofNat (n : Nat) : (ofNat p n).toNat = n % p := by
  simp [toNat, ofNat, normalize]

/-- The stored word of `ofNat p n`, viewed as a Nat, is `n` reduced modulo `p`. -/
@[simp, grind =] theorem val_toNat_ofNat (n : Nat) : (ofNat p n).val.toNat = n % p := by
  simpa using toNat_ofNat (p := p) n

/-- Constructing a residue from its canonical representative is the identity. -/
@[simp, grind =] theorem ofNat_toNat (a : ZMod64 p) : ofNat p a.toNat = a := by
  apply ext
  apply UInt64.toNat_inj.mp
  rw [val_toNat_ofNat]
  exact Nat.mod_eq_of_lt a.toNat_lt

/-- Two residues are equal exactly when their canonical representatives agree. -/
@[grind ←]
theorem eq_iff_toNat_eq (a b : ZMod64 p) : a = b ↔ a.toNat = b.toNat :=
  ⟨fun h => h ▸ rfl, ext_toNat⟩

/-- A reduced representative constructs the same residue as the original representative. -/
@[simp, grind =] theorem ofNat_mod (n : Nat) : ofNat p (n % p) = ofNat p n := by
  rw [eq_iff_toNat_eq, toNat_ofNat, toNat_ofNat, Nat.mod_mod]

/-- Normalizing before constructing a residue does not change the residue. -/
@[simp, grind =] theorem ofNat_normalize (n : Nat) : ofNat p (normalize p n) = ofNat p n := by
  simp [normalize]

/-- Characterise when an arbitrary representative builds a given residue. -/
@[grind ←]
theorem ofNat_eq_iff_toNat_eq (n : Nat) (a : ZMod64 p) :
    ofNat p n = a ↔ n % p = a.toNat := by
  rw [eq_iff_toNat_eq, toNat_ofNat]

/-- Characterise when a residue is built from an arbitrary representative. -/
@[grind ←]
theorem eq_ofNat_iff_toNat_eq (a : ZMod64 p) (n : Nat) :
    a = ofNat p n ↔ a.toNat = n % p := by
  rw [eq_iff_toNat_eq, toNat_ofNat]

/-- Equality of residues built from arbitrary Nat representatives is equality modulo `p`. -/
@[grind ←]
theorem ofNat_eq_ofNat_iff_mod_eq (x y : Nat) :
    ofNat p x = ofNat p y ↔ x % p = y % p := by
  rw [eq_iff_toNat_eq, toNat_ofNat, toNat_ofNat]

/-- All canonical residues modulo `p`, listed in representative order. -/
@[expose]
def values (p : Nat) [Bounds p] : List (ZMod64 p) :=
  (List.range p).map fun n => ofNat p n

/-- The canonical list of residues modulo `p` has one entry for each representative. -/
@[simp, grind =] theorem values_length : (values p).length = p := by
  simp [values]

/-- Every residue appears in `values`. -/
theorem mem_values (a : ZMod64 p) : a ∈ values p := by
  unfold values
  apply List.mem_map.mpr
  refine ⟨a.toNat, List.mem_range.mpr a.toNat_lt, ?_⟩
  apply ext
  apply UInt64.toNat_inj.mp
  rw [val_toNat_ofNat]
  exact (Nat.mod_eq_of_lt a.toNat_lt).trans (by rfl)

/-- Membership in the canonical residue list is automatic for every residue. -/
@[simp, grind =] theorem mem_values_iff (a : ZMod64 p) : a ∈ values p ↔ True :=
  iff_true_intro (mem_values a)

/-- Reduced representatives below `p` construct the same residue exactly when
the representatives are equal. -/
theorem ofNat_eq_ofNat_iff_of_lt {x y : Nat} (hx : x < p) (hy : y < p) :
    ofNat p x = ofNat p y ↔ x = y := by
  constructor
  · intro h
    have hnat := congrArg ZMod64.toNat h
    rw [toNat_ofNat, toNat_ofNat, Nat.mod_eq_of_lt hx, Nat.mod_eq_of_lt hy] at hnat
    exact hnat
  · intro h
    subst y
    rfl

private theorem nodup_map_of_injective_on
    {α β : Type} {xs : List α} {f : α → β}
    (hxs : xs.Nodup)
    (hinj : ∀ a, a ∈ xs → ∀ b, b ∈ xs → f a = f b → a = b) :
    (xs.map f).Nodup := by
  induction xs with
  | nil =>
      simp
  | cons x xs ih =>
      simp only [List.map_cons]
      rw [List.nodup_cons] at hxs ⊢
      constructor
      · intro hx
        rcases List.mem_map.mp hx with ⟨y, hy, hxy⟩
        have hxy' : x = y := hinj x (by simp) y (by simp [hy]) hxy.symm
        exact hxs.1 (hxy' ▸ hy)
      · apply ih hxs.2
        intro a ha b hb hab
        exact hinj a (by simp [ha]) b (by simp [hb]) hab

/-- The canonical residue list has no duplicate entries. -/
@[grind .]
theorem values_nodup : (values p).Nodup := by
  unfold values
  apply nodup_map_of_injective_on (List.nodup_range : (List.range p).Nodup)
  intro x hx y hy hxy
  exact
    (ofNat_eq_ofNat_iff_of_lt
      (List.mem_range.mp hx) (List.mem_range.mp hy)).mp hxy

/-- The zero residue class. -/
@[expose]
protected def zero : ZMod64 p :=
  ofNat p 0

/-- The residue class of one. -/
@[expose]
protected def one : ZMod64 p :=
  ofNat p 1

/-- The modulus as a `UInt64` word when `p < 2^64`. -/
@[expose]
def modulusWord (p : Nat) (hp : p < UInt64.word) : UInt64 :=
  UInt64.ofNatLT p (by simpa [UInt64.word, UInt64.size] using hp)

/-- The correction word `2^64 - p` used when `p < 2^64`. -/
@[expose]
def complementWord (p : Nat) [Bounds p] (_hp : p < UInt64.word) : UInt64 :=
  UInt64.ofNatLT (UInt64.word - p) <| by
    have h : UInt64.word - p < UInt64.word :=
      Nat.sub_lt (by decide : 0 < 2 ^ 64) (Bounds.pPos (p := p))
    simpa [UInt64.word, UInt64.size] using h

/-- The modulus word, viewed as a `Nat`, is exactly `p`. -/
private theorem modulusWord_toNat : (modulusWord p (Bounds.pLtWord p)).toNat = p := by
  simp [modulusWord]

/-- The unreduced sum of two residues is faithful in a machine word: since
`a, b < p < 2^31`, we have `a.toNat + b.toNat < 2^32 ≤ 2^64`, so machine-word
addition never wraps. This is why `add` needs no carry branch. -/
private theorem toNat_val_add (a b : ZMod64 p) :
    (a.val + b.val).toNat = a.toNat + b.toNat := by
  have ha : a.toNat < p := a.isLt
  have hb : b.toNat < p := b.isLt
  have hp : p < 2 ^ 31 := Bounds.pLtR (p := p)
  have hbound : (2 : Nat) ^ 31 + 2 ^ 31 ≤ UInt64.word := by decide
  have hsum_lt : a.toNat + b.toNat < UInt64.word := by omega
  rw [UInt64.toNat_add]
  simpa [toNat_eq_val, UInt64.word] using
    (by rw [Nat.mod_eq_of_lt hsum_lt] :
      (a.toNat + b.toNat) % UInt64.word = a.toNat + b.toNat)

/-- The corrected word `a + (p - b)` used by `sub`'s borrow branch is faithful
and equals `a.toNat + (p - b.toNat)`: the inner `p - b` stays below `p` and the
outer sum below `2^32`, so neither subtraction nor addition wraps. -/
private theorem toNat_val_sub (a b : ZMod64 p) :
    (a.val + (modulusWord p (Bounds.pLtWord p) - b.val)).toNat
      = a.toNat + (p - b.toNat) := by
  have hmp := modulusWord_toNat (p := p)
  have hb : b.toNat < p := b.isLt
  have hble : b.val ≤ modulusWord p (Bounds.pLtWord p) :=
    UInt64.le_iff_toNat_le.mpr (by rw [hmp]; exact Nat.le_of_lt b.isLt)
  have hc : (modulusWord p (Bounds.pLtWord p) - b.val).toNat = p - b.toNat := by
    rw [UInt64.toNat_sub_of_le _ b.val hble, hmp]; rfl
  have ha : a.toNat < p := a.isLt
  have hp : p < 2 ^ 31 := Bounds.pLtR (p := p)
  have hbound : (2 : Nat) ^ 31 + 2 ^ 31 ≤ UInt64.word := by decide
  have hsum_lt : a.toNat + (p - b.toNat) < UInt64.word := by omega
  rw [UInt64.toNat_add, hc]
  simpa [toNat_eq_val, UInt64.word] using
    (by rw [Nat.mod_eq_of_lt hsum_lt] :
      (a.toNat + (p - b.toNat)) % UInt64.word = a.toNat + (p - b.toNat))

/-- Reduce branch of `reduceOnce`: subtracting the modulus word from a faithful
representative below `2 * p` lands back in canonical range `< p`. -/
theorem reduceOnce_reduce_lt (s : UInt64) (hs : s.toNat < 2 * p)
    (h : modulusWord p (Bounds.pLtWord p) ≤ s) :
    (s - modulusWord p (Bounds.pLtWord p)).toNat < p := by
  have hmp := modulusWord_toNat (p := p)
  rw [UInt64.toNat_sub_of_le s _ h]
  omega

/-- No-reduce branch of `reduceOnce`: a faithful representative already below the
modulus word is already canonical. -/
theorem reduceOnce_noReduce_lt (s : UInt64) (_hs : s.toNat < 2 * p)
    (h : ¬ modulusWord p (Bounds.pLtWord p) ≤ s) :
    s.toNat < p := by
  have hmp := modulusWord_toNat (p := p)
  have hnle : ¬ (modulusWord p (Bounds.pLtWord p)).toNat ≤ s.toNat :=
    fun hh => h (UInt64.le_iff_toNat_le.mpr hh)
  omega

/--
Canonicalise a machine word whose value is a faithful representative in
`[0, 2*p)` by one conditional subtraction of the modulus word.

Under the `p < 2^31` bound `add` produces such a representative with no
machine-word wraparound, so this single reduce branch replaces the former
three-way carry analysis and keeps the runtime division-free.
-/
@[expose]
def reduceOnce (s : UInt64) (hs : s.toNat < 2 * p) : ZMod64 p :=
  if h : modulusWord p (Bounds.pLtWord p) ≤ s then
    ⟨s - modulusWord p (Bounds.pLtWord p), reduceOnce_reduce_lt s hs h⟩
  else
    ⟨s, reduceOnce_noReduce_lt s hs h⟩

/-- The reduction step returns the modular reduction of the faithful
representative `s`. -/
private theorem toNat_reduceOnce (s : UInt64) (hs : s.toNat < 2 * p) :
    (reduceOnce s hs).toNat = s.toNat % p := by
  have hmp := modulusWord_toNat (p := p)
  unfold reduceOnce
  split
  · rename_i h
    show (s - modulusWord p (Bounds.pLtWord p)).toNat = s.toNat % p
    have hle : p ≤ s.toNat := by
      have := UInt64.le_iff_toNat_le.mp h; omega
    rw [UInt64.toNat_sub_of_le s _ h, hmp, Nat.mod_eq_sub_mod hle,
      Nat.mod_eq_of_lt (by omega)]
  · rename_i h
    show s.toNat = s.toNat % p
    exact (Nat.mod_eq_of_lt (reduceOnce_noReduce_lt s hs h)).symm

/--
Add two reduced residues: the residue of the sum of canonical representatives.

This is the kernel-reduction-friendly specification: reducing it unfolds to a
single `Nat` addition and mod, so `decide`-style proofs walk a straight-line
computation. Compiled code instead runs the branchy machine-word implementation
`addImpl`, registered by the `@[csimp]` theorem `add_eq_impl`.
-/
@[expose]
noncomputable def add (a b : ZMod64 p) : ZMod64 p :=
  ofNat p (a.toNat + b.toNat)

/--
Runtime implementation of {name}`Hex.ZMod64.add`: one faithful machine-word
addition followed by a single conditional subtraction of the modulus
({name}`reduceOnce`), with no carry branch and no division. Its correctness proof is
the `@[csimp]` theorem `add_eq_impl`. Under `p < 2^31` the sum
`a.val + b.val` never overflows the word.
-/
@[expose]
def addImpl (a b : ZMod64 p) : ZMod64 p :=
  reduceOnce (a.val + b.val) (by
    have h := toNat_val_add a b
    have ha : a.toNat < p := a.isLt
    have hb : b.toNat < p := b.isLt
    omega)

/--
Subtract two residues: the residue of `a.toNat + (p - b.toNat)`, the canonical
representative of the modular difference.

Like {name}`Hex.ZMod64.add`, this is the kernel-reduction-friendly
specification; compiled code runs `subImpl` through the `@[csimp]` theorem
`sub_eq_impl`.
-/
@[expose]
noncomputable def sub (a b : ZMod64 p) : ZMod64 p :=
  ofNat p (a.toNat + (p - b.toNat))

/-- No-borrow branch of {name}`sub`: when `b ≤ a` the machine-word difference is
already the canonical representative `< p`. -/
theorem sub_noBorrow_lt (a b : ZMod64 p) (h : b.val ≤ a.val) :
    (a.val - b.val).toNat < p := by
  rw [UInt64.toNat_sub_of_le a.val b.val h]
  have ha : a.val.toNat < p := a.isLt
  omega

/-- Borrow branch of {name}`sub`: when `a < b` the faithful word `a + (p - b)` has
representative `p - (b - a)`, which stays in canonical range `< p`. -/
theorem sub_borrow_lt (a b : ZMod64 p) (h : ¬ b.val ≤ a.val) :
    (a.val + (modulusWord p (Bounds.pLtWord p) - b.val)).toNat < p := by
  rw [toNat_val_sub]
  have hab : a.toNat < b.toNat :=
    Nat.lt_of_not_le (fun hh => h (UInt64.le_iff_toNat_le.mpr hh))
  have hbp : b.toNat < p := b.toNat_lt
  omega

/--
Runtime implementation of {name}`Hex.ZMod64.sub`: a single sign test picks the fast common path
`a - b` (already canonical when `b ≤ a`) or the corrected `a + (p - b)`, with no
division and no wraparound reasoning. Its correctness proof is the `@[csimp]`
theorem `sub_eq_impl`. Under `p < 2^31` neither branch overflows the word.
-/
@[expose]
def subImpl (a b : ZMod64 p) : ZMod64 p :=
  if h : b.val ≤ a.val then
    ⟨a.val - b.val, sub_noBorrow_lt a b h⟩
  else
    ⟨a.val + (modulusWord p (Bounds.pLtWord p) - b.val), sub_borrow_lt a b h⟩

/--
Multiply two reduced residues and reduce the product mod `p`.

The trusted runtime contract is the `lean_hex_zmod64_mul` extern, whose C body
must agree with this pure Lean fallback.
-/
@[expose, extern "lean_hex_zmod64_mul"]
def mul (a b : ZMod64 p) : ZMod64 p :=
  ofNat p (a.toNat * b.toNat)

/--
Raise a residue to a natural power using exponentiation by squaring.

The accumulator form keeps the executable path close to the intended downstream
runtime usage while preserving a simple semantic contract.
-/
@[expose, extern "lean_hex_zmod64_pow"]
def pow (a : ZMod64 p) (n : Nat) : ZMod64 p :=
  let rec go (base acc : ZMod64 p) (k : Nat) : ZMod64 p :=
    match k with
    | 0 => acc
    | m + 1 =>
        let acc' := if (m + 1) % 2 = 0 then acc else mul acc base
        go (mul base base) acc' ((m + 1) / 2)
  termination_by k
  decreasing_by
    simpa using Nat.div_lt_self (Nat.succ_pos m) (by decide : 1 < 2)
  go a ZMod64.one n

/--
Compute a modular inverse candidate via the integer extended-GCD helper from
`hex-arith`.

When `a` is coprime to `p`, this is the canonical inverse mod `p`; otherwise it
still exposes the executable Bezout-derived residue needed by later algebraic
layers. The trusted runtime contract is `lean_hex_zmod64_inv`, which runs the
same Euclidean remainder and cofactor recurrence directly in bounded word
arithmetic and returns the cofactor modulo `p`.
-/
@[expose, extern "lean_hex_zmod64_inv"]
def inv (a : ZMod64 p) : ZMod64 p :=
  let (_, s, _) := HexArith.Int.extGcd (Int.ofNat a.toNat) (Int.ofNat p)
  ofNat p (Int.toNat (s % Int.ofNat p))

/-- Addition agrees with addition of canonical representatives modulo `p`. -/
@[simp, grind =] theorem toNat_add (a b : ZMod64 p) :
    (add a b).toNat = (a.toNat + b.toNat) % p :=
  toNat_ofNat (a.toNat + b.toNat)

/-- The runtime {name}`addImpl` also computes the residue of the representative sum;
the reduction is delegated to {name}`reduceOnce` on the faithful word sum. -/
private theorem toNat_addImpl (a b : ZMod64 p) :
    (addImpl a b).toNat = (a.toNat + b.toNat) % p := by
  unfold addImpl
  rw [toNat_reduceOnce, toNat_val_add]

/-- The kernel-facing {name}`add` and the runtime {name}`addImpl` compute the same residue.
Registered `@[csimp]`, so compiled code runs the division-free machine-word
implementation while kernel reduction sees the one-line specification. -/
@[csimp] theorem add_eq_impl : @add = @addImpl := by
  funext p _ a b
  exact ext_toNat (by rw [toNat_add, toNat_addImpl])


/-- Subtraction agrees with modular subtraction of canonical representatives. -/
@[simp, grind =] theorem toNat_sub (a b : ZMod64 p) :
    (sub a b).toNat = (a.toNat + (p - b.toNat)) % p :=
  toNat_ofNat (a.toNat + (p - b.toNat))

/-- The runtime {name}`subImpl` also computes the canonical modular difference;
the reduction is delegated to {name}`reduceOnce` on the faithful word `a + (p - b)`. -/
private theorem toNat_subImpl (a b : ZMod64 p) :
    (subImpl a b).toNat = (a.toNat + (p - b.toNat)) % p := by
  unfold subImpl
  split
  · rename_i h
    show (a.val - b.val).toNat = (a.toNat + (p - b.toNat)) % p
    rw [UInt64.toNat_sub_of_le a.val b.val h, ← toNat_eq_val, ← toNat_eq_val]
    have hba : b.toNat ≤ a.toNat := UInt64.le_iff_toNat_le.mp h
    have ha : a.toNat < p := a.toNat_lt
    rw [show a.toNat + (p - b.toNat) = (a.toNat - b.toNat) + p by omega,
      Nat.add_mod_right, Nat.mod_eq_of_lt (by omega)]
  · rename_i h
    show (a.val + (modulusWord p (Bounds.pLtWord p) - b.val)).toNat =
      (a.toNat + (p - b.toNat)) % p
    rw [toNat_val_sub]
    have hab : a.toNat < b.toNat :=
      Nat.lt_of_not_le (fun hh => h (UInt64.le_iff_toNat_le.mpr hh))
    have hbp : b.toNat < p := b.toNat_lt
    rw [Nat.mod_eq_of_lt (by omega)]

/-- The kernel-facing {name}`sub` and the runtime {name}`subImpl` compute the same residue.
Registered `@[csimp]`, so compiled code runs the division-free machine-word
implementation while kernel reduction sees the one-line specification. -/
@[csimp] theorem sub_eq_impl : @sub = @subImpl := by
  funext p _ a b
  exact ext_toNat (by rw [toNat_sub, toNat_subImpl])


instance : Zero (ZMod64 p) where
  zero := ZMod64.zero

instance : One (ZMod64 p) where
  one := ZMod64.one

instance : Add (ZMod64 p) where
  add := ZMod64.add

instance : Sub (ZMod64 p) where
  sub := ZMod64.sub

instance : Mul (ZMod64 p) where
  mul := ZMod64.mul

instance : Pow (ZMod64 p) Nat where
  pow := ZMod64.pow

instance : Inv (ZMod64 p) where
  inv := ZMod64.inv

/-- Invert a unit, returning `none` if the Bezout candidate is not an inverse.
The multiplication check works for composite moduli as well as primes. -/
@[expose]
def inv? (a : ZMod64 p) : Option (ZMod64 p) :=
  let b := inv a
  if a * b = 1 then some b else none

/-- Every returned inverse multiplies its argument to one. -/
theorem inv?_eq_some {a b : ZMod64 p} (h : inv? a = some b) : a * b = 1 := by
  unfold inv? at h
  dsimp only at h
  split at h
  · cases h
    assumption
  · contradiction

/-- The canonical representative of the zero residue is `0`. -/
@[simp, grind =] theorem toNat_zero : (ZMod64.zero : ZMod64 p).toNat = 0 := by
  rw [ZMod64.zero, toNat_ofNat]
  exact Nat.zero_mod _

/-- The canonical representative of the one residue is `1 % p`. -/
@[simp, grind =] theorem toNat_one : (ZMod64.one : ZMod64 p).toNat = 1 % p := by
  rw [ZMod64.one, toNat_ofNat]

/-- Addition is the residue built from the sum of canonical representatives. -/
theorem add_eq_ofNat (a b : ZMod64 p) :
    add a b = ofNat p (a.toNat + b.toNat) :=
  rfl

/-- Operator-level form of {name}`add_eq_ofNat`. -/
theorem add_op_eq_ofNat (a b : ZMod64 p) :
    a + b = ofNat p (a.toNat + b.toNat) := by
  exact add_eq_ofNat a b

/-- Subtraction is the residue built from the modular difference of representatives. -/
theorem sub_eq_ofNat (a b : ZMod64 p) :
    sub a b = ofNat p (a.toNat + (p - b.toNat)) :=
  rfl

/-- Operator-level form of {name}`sub_eq_ofNat`. -/
theorem sub_op_eq_ofNat (a b : ZMod64 p) :
    a - b = ofNat p (a.toNat + (p - b.toNat)) := by
  exact sub_eq_ofNat a b

/-- Multiplication agrees with multiplication of canonical representatives modulo `p`. -/
@[simp, grind =] theorem toNat_mul (a b : ZMod64 p) :
    (mul a b).toNat = (a.toNat * b.toNat) % p := by
  rw [mul, toNat_ofNat]

/-- Multiplication is the residue built from the product of canonical representatives. -/
theorem mul_eq_ofNat (a b : ZMod64 p) :
    mul a b = ofNat p (a.toNat * b.toNat) := by
  rw [eq_iff_toNat_eq, toNat_mul, toNat_ofNat]

/-- Operator-level form of {name}`mul_eq_ofNat`. -/
theorem mul_op_eq_ofNat (a b : ZMod64 p) :
    a * b = ofNat p (a.toNat * b.toNat) := by
  exact mul_eq_ofNat a b

/--
Definition-level representative equation for the extended-GCD inverse candidate.

Most callers should prefer `inv_mul_eq_one_of_coprime`; this lemma exposes the
exact executable residue produced by {name}`inv`. It is intentionally not tagged as a
default simplification rule, since unfolding {name}`inv` exposes the extended-GCD
implementation body.
-/
theorem toNat_inv_def (a : ZMod64 p) :
    (inv a).toNat =
      (Int.toNat ((let (_, s, _) := HexArith.Int.extGcd (Int.ofNat a.toNat) (Int.ofNat p); s)
        % Int.ofNat p)) % p := by
  rw [inv, toNat_ofNat]

/-- Inversion is the residue built from the extended-GCD inverse representative. -/
theorem inv_eq_ofNat (a : ZMod64 p) :
    inv a =
      ofNat p
        (Int.toNat
          ((let (_, s, _) :=
              HexArith.Int.extGcd (Int.ofNat a.toNat) (Int.ofNat p); s)
            % Int.ofNat p)) := by
  rw [eq_iff_toNat_eq, toNat_inv_def, toNat_ofNat]

/-- Operator-level form of {name}`inv_eq_ofNat`. -/
theorem inv_op_eq_ofNat (a : ZMod64 p) :
    a⁻¹ =
      ofNat p
        (Int.toNat
          ((let (_, s, _) :=
              HexArith.Int.extGcd (Int.ofNat a.toNat) (Int.ofNat p); s)
            % Int.ofNat p)) := by
  exact inv_eq_ofNat a

/-- A Bézout cofactor for `gcd a p = 1` reduces to a modular inverse of `a`:
given `s * a + t * p = 1`, the centered representative `s % p` satisfies
`(s % p) * a ≡ 1 (mod p)`. This is the step turning the extended-GCD output
(`HexArith.Int.extGcd`, consumed by {name}`inv`) into the modular-inverse
correctness statement. -/
private theorem invBezout_mul_mod_eq_one {a p : Nat} (hp : 0 < p)
    {s t : Int} (hbez : s * Int.ofNat a + t * Int.ofNat p = 1) :
    (Int.toNat (s % Int.ofNat p) * a) % p = 1 % p := by
  have hpInt : (Int.ofNat p) ≠ 0 := Int.ofNat_ne_zero.mpr (Nat.ne_of_gt hp)
  have hs_nonneg : 0 ≤ s % Int.ofNat p := Int.emod_nonneg _ hpInt
  have hs_cast : Int.ofNat (Int.toNat (s % Int.ofNat p)) = s % Int.ofNat p :=
    Int.toNat_of_nonneg hs_nonneg
  have hs_congr :
      (Int.ofNat (Int.toNat (s % Int.ofNat p)) * Int.ofNat a -
          s * Int.ofNat a) % Int.ofNat p = 0 := by
    rw [hs_cast]
    have hdiv :
        Int.ofNat p ∣
          (s % Int.ofNat p * Int.ofNat a - s * Int.ofNat a) := by
      have hbase : Int.ofNat p ∣ s % Int.ofNat p - s :=
        Int.dvd_sub_self_of_emod_eq rfl
      rcases hbase with ⟨k, hk⟩
      refine ⟨k * Int.ofNat a, ?_⟩
      rw [← Int.sub_mul, hk, Int.mul_assoc]
    exact Int.emod_eq_zero_of_dvd hdiv
  have hbez_congr : (s * Int.ofNat a - 1) % Int.ofNat p = 0 := by
    have hdiv : Int.ofNat p ∣ s * Int.ofNat a - 1 := by
      refine ⟨-t, ?_⟩
      calc
        s * Int.ofNat a - 1 = -(t * Int.ofNat p) := by omega
        _ = Int.ofNat p * -t := by
          rw [Int.mul_comm]
          exact Int.neg_mul_eq_mul_neg (Int.ofNat p) t
    exact Int.emod_eq_zero_of_dvd hdiv
  apply Int.ofNat_inj.mp
  rw [Int.natCast_emod, Int.natCast_emod]
  have htarget :
      (Int.ofNat (Int.toNat (s % Int.ofNat p) * a) - 1) % Int.ofNat p = 0 := by
    have hdiv₁ : Int.ofNat p ∣
        Int.ofNat (Int.toNat (s % Int.ofNat p)) * Int.ofNat a -
          s * Int.ofNat a :=
      Int.dvd_of_emod_eq_zero hs_congr
    have hdiv₂ : Int.ofNat p ∣ s * Int.ofNat a - 1 :=
      Int.dvd_of_emod_eq_zero hbez_congr
    have hdiv : Int.ofNat p ∣ Int.ofNat (Int.toNat (s % Int.ofNat p) * a) - 1 := by
      rcases hdiv₁ with ⟨k₁, hk₁⟩
      rcases hdiv₂ with ⟨k₂, hk₂⟩
      refine ⟨k₁ + k₂, ?_⟩
      calc
        Int.ofNat (Int.toNat (s % Int.ofNat p) * a) - 1 =
            (Int.ofNat (Int.toNat (s % Int.ofNat p)) * Int.ofNat a -
                s * Int.ofNat a) +
              (s * Int.ofNat a - 1) := by
          rw [show Int.ofNat (Int.toNat (s % Int.ofNat p) * a) =
              Int.ofNat (Int.toNat (s % Int.ofNat p)) * Int.ofNat a by
            simp [Int.ofNat_eq_natCast]]
          omega
        _ = Int.ofNat p * k₁ + Int.ofNat p * k₂ := by
          rw [hk₁, hk₂]
        _ = Int.ofNat p * (k₁ + k₂) := by
          rw [Int.mul_add]
    exact Int.emod_eq_zero_of_dvd hdiv
  have hleft :
      (Int.ofNat (Int.toNat (s % Int.ofNat p) * a) % Int.ofNat p) =
        (1 : Int) % Int.ofNat p := by
    exact Int.emod_eq_emod_iff_emod_sub_eq_zero.mpr htarget
  simpa using hleft

/-- Even case of one square-and-multiply step: when `k` is even, replacing
`base ^ k` by `(base * base) ^ (k / 2)` under modular reduction leaves the
accumulator unchanged mod `p`. Used by `pow_go_toNat` to discharge the even
branch of the {name}`pow.go` recursion. -/
private theorem nat_mod_mul_pow_square_even (acc base k p : Nat) (heven : k % 2 = 0) :
    (acc * ((base * base) % p) ^ (k / 2)) % p = (acc * base ^ k) % p := by
  have hk : 2 * (k / 2) = k := by
    have h := Nat.mod_add_div k 2
    omega
  have hsquare : (base * base) ^ (k / 2) = base ^ (2 * (k / 2)) := by
    rw [Nat.mul_pow, ← Nat.pow_add]
    congr
    omega
  calc
    (acc * ((base * base) % p) ^ (k / 2)) % p =
        (acc * (base * base) ^ (k / 2)) % p := by
      rw [Nat.mul_mod]
      rw [show ((base * base) % p) ^ (k / 2) % p = (base * base) ^ (k / 2) % p by
        exact (Nat.pow_mod (base * base) (k / 2) p).symm]
      rw [← Nat.mul_mod]
    _ = (acc * base ^ (2 * (k / 2))) % p := by rw [hsquare]
    _ = (acc * base ^ k) % p := by rw [hk]

/-- Odd case of one square-and-multiply step: when `k` is odd, folding one
factor of `base` into the accumulator and replacing `base ^ k` by
`(base * base) ^ (k / 2)` under modular reduction reproduces `acc * base ^ k`
mod `p`. Used by `pow_go_toNat` for the odd branch of the {name}`pow.go` recursion. -/
private theorem nat_mod_mul_pow_square_odd (acc base k p : Nat) (hodd : k % 2 ≠ 0) :
    ((acc * base) % p * ((base * base) % p) ^ (k / 2)) % p =
      (acc * base ^ k) % p := by
  have hmod : k % 2 = 1 := by
    have h := Nat.mod_two_eq_zero_or_one k
    omega
  have hk : 1 + 2 * (k / 2) = k := by
    have h := Nat.mod_add_div k 2
    omega
  have hsquare : (base * base) ^ (k / 2) = base ^ (2 * (k / 2)) := by
    rw [Nat.mul_pow, ← Nat.pow_add]
    congr
    omega
  calc
    ((acc * base) % p * ((base * base) % p) ^ (k / 2)) % p =
        (acc * base * (base * base) ^ (k / 2)) % p := by
      rw [Nat.mul_mod, Nat.mod_mod]
      rw [show ((base * base) % p) ^ (k / 2) % p = (base * base) ^ (k / 2) % p by
        exact (Nat.pow_mod (base * base) (k / 2) p).symm]
      rw [← Nat.mul_mod]
    _ = (acc * (base * base ^ (2 * (k / 2)))) % p := by
      rw [hsquare]
      grind
    _ = (acc * base ^ (1 + 2 * (k / 2))) % p := by
      simp [Nat.pow_add]
    _ = (acc * base ^ k) % p := by rw [hk]

/-- Loop invariant of the {name}`pow.go` tail recursion: the canonical representative
of `pow.go base acc k` is `(acc.toNat * base.toNat ^ k) % p`, linking the
tail-recursive accumulator to `base ^ k` mod `p`. This is the workhorse behind
`toNat_pow`. -/
private theorem pow_go_toNat (base acc : ZMod64 p) (k : Nat) :
    (pow.go base acc k).toNat = (acc.toNat * base.toNat ^ k) % p := by
  revert base acc
  induction k using Nat.strongRecOn with
  | ind k ih =>
      intro base acc
      cases k with
      | zero =>
          simp [pow.go, Nat.mod_eq_of_lt acc.isLt]
      | succ m =>
          have hlt : (m + 1) / 2 < m + 1 :=
            Nat.div_lt_self (Nat.succ_pos m) (by decide : 1 < 2)
          simp [pow.go]
          by_cases heven : (m + 1) % 2 = 0
          · rw [ite_eq_left heven]
            have hrec := ih ((m + 1) / 2) hlt (mul base base) acc
            change (pow.go (mul base base) acc ((m + 1) / 2)).toNat =
              acc.toNat * base.toNat ^ (m + 1) % p
            rw [hrec, toNat_mul]
            exact nat_mod_mul_pow_square_even acc.toNat base.toNat (m + 1) p heven
          · rw [ite_eq_right heven]
            have hrec := ih ((m + 1) / 2) hlt (mul base base) (mul acc base)
            change (pow.go (mul base base) (mul acc base) ((m + 1) / 2)).toNat =
              acc.toNat * base.toNat ^ (m + 1) % p
            rw [hrec, toNat_mul, toNat_mul]
            exact nat_mod_mul_pow_square_odd acc.toNat base.toNat (m + 1) p heven

/-- Exponentiation agrees with natural-power reduction of the canonical representative. -/
@[simp, grind =] theorem toNat_pow (a : ZMod64 p) (n : Nat) :
    (pow a n).toNat = a.toNat ^ n % p := by
  rw [pow, pow_go_toNat, toNat_one, ← Nat.mod_mul_mod]
  simp

/-- Exponentiation is the residue built from the representative's natural power. -/
theorem pow_eq_ofNat (a : ZMod64 p) (n : Nat) :
    pow a n = ofNat p (a.toNat ^ n) := by
  rw [eq_iff_toNat_eq, toNat_pow, toNat_ofNat]

/-- Operator-level form of {name}`pow_eq_ofNat`. -/
theorem pow_op_eq_ofNat (a : ZMod64 p) (n : Nat) :
    a ^ n = ofNat p (a.toNat ^ n) := by
  exact pow_eq_ofNat a n

/--
The extended-GCD inverse candidate is a left inverse whenever the representative
is coprime to the modulus.
-/
@[grind =]
theorem inv_mul_eq_one (a : ZMod64 p) (hcop : Nat.Coprime a.toNat p) :
    (mul (inv a) a).toNat = 1 % p := by
  rw [toNat_mul, toNat_inv_def]
  generalize hgcd : HexArith.Int.extGcd (Int.ofNat a.toNat) (Int.ofNat p) = triple
  obtain ⟨g, s, t⟩ := triple
  have hbez :
      s * Int.ofNat a.toNat + t * Int.ofNat p = 1 := by
    have hspec := HexArith.Int.extGcd_bezout (Int.ofNat a.toNat) (Int.ofNat p)
    have hfst := HexArith.Int.extGcd_fst (Int.ofNat a.toNat) (Int.ofNat p)
    rw [hgcd] at hspec
    rw [hgcd] at hfst
    simp at hfst
    have hg : g = 1 := by
      rw [hfst]
      simpa [Int.gcd_eq_natAbs_gcd_natAbs, hcop]
    rw [hg] at hspec
    simp at hspec
    exact hspec
  simpa [Nat.mod_mod] using
    invBezout_mul_mod_eq_one (a := a.toNat) (p := p) (Bounds.pPos (p := p))
      (s := s) (t := t) hbez

/-- Coprime residues multiply by their computed inverse to the unit residue. -/
@[grind =]
theorem inv_mul_eq_one_of_coprime (a : ZMod64 p) (hcop : Nat.Coprime a.toNat p) :
    mul (inv a) a = ZMod64.one := by
  rw [eq_iff_toNat_eq, inv_mul_eq_one a hcop, toNat_one]

/-- Operator-level form of {name}`inv_mul_eq_one_of_coprime`. -/
@[grind =]
theorem inv_op_mul_eq_one_of_coprime (a : ZMod64 p) (hcop : Nat.Coprime a.toNat p) :
    a⁻¹ * a = 1 := by
  exact inv_mul_eq_one_of_coprime a hcop

/-- Addition produces a canonical representative below the modulus. -/
theorem add_lt_modulus (a b : ZMod64 p) : (add a b).toNat < p := by
  exact (add a b).isLt

/-- Subtraction produces a canonical representative below the modulus. -/
theorem sub_lt_modulus (a b : ZMod64 p) : (sub a b).toNat < p := by
  exact (sub a b).isLt

/-- Multiplication produces a canonical representative below the modulus. -/
theorem mul_lt_modulus (a b : ZMod64 p) : (mul a b).toNat < p := by
  exact (mul a b).isLt

/-- Exponentiation produces a canonical representative below the modulus. -/
theorem pow_lt_modulus (a : ZMod64 p) (n : Nat) : (pow a n).toNat < p := by
  exact (pow a n).isLt

/-- Inversion produces a canonical representative below the modulus. -/
theorem inv_lt_modulus (a : ZMod64 p) : (inv a).toNat < p := by
  exact (inv a).isLt

end ZMod64
end Hex
