from pathlib import Path
import json,math,statistics,sys
base=Path(sys.argv[1]);summarize=lambda xs:dict(geomean=math.exp(sum(map(math.log,xs))/len(xs)),median=statistics.median(xs),minimum=min(xs),maximum=max(xs),ratios=xs)
all_cases={};experiments=[]
for p in sorted(base.glob('*-production-bench-*')):
 m=json.loads((p/'metadata.json').read_text());out={};points=0
 for case in ['cyclic4','cyclic5','cyclic6','katsura3','reimer5','cyclic6Small']:
  ratios=[]
  for block in [0,1]:
   a,b=[json.loads((p/f'{case}-b{block}-{arm}.json').read_text())['results'][0]['points'] for arm in ['A','B']];assert len(a)==len(b)
   for x,y in zip(a,b):
    assert x['status']==y['status']=='ok' and x['result_hash']==y['result_hash'];points+=2;ratios.append((y['total_nanos']/y['inner_repeats'])/(x['total_nanos']/x['inner_repeats']))
  out[case]=summarize(ratios);all_cases.setdefault(case,[]).extend(ratios)
 x=dict(name=p.name,cpu=m['cpu'],source_fingerprint=m['source_fingerprint'],completed_points=points,all_full_output_hashes_equal=True,cases=out);(p/'analysis.json').write_text(json.dumps(x,indent=2)+'\n');experiments.append(x)
out=dict(experiments=experiments,pooled_cases={k:summarize(v) for k,v in all_cases.items()},completed_points=sum(e['completed_points'] for e in experiments));(base/'fixed-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for x in experiments:
 print(x['name'],'CPU',x['cpu'],x['completed_points'],'points')
 for c,v in x['cases'].items():print(c,*(round(v[k],4) for k in ['geomean','median','minimum','maximum']))
print('All completed',out['completed_points'])
for c,v in out['pooled_cases'].items():print('pooled',c,*(round(v[k],4) for k in ['geomean','median','minimum','maximum']))
