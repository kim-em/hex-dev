import hashlib,json,os,pathlib,subprocess,sys,time
sys.path.insert(0,'/tmp/hex-groebner-avx512-contiguous-dev')
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import fingerprint,index_listing
root=pathlib.Path('/tmp/hex-groebner-avx512-contiguous-dev');dev=pathlib.Path('/tmp/hex-groebner-contiguous512-checked-production')
listing=index_listing(FAMILY);fp=fingerprint(listing);out=dev/('contiguous512-bench-'+fp);out.mkdir(exist_ok=False)
binaries={'A':dev/'bench-binaries/A','B':dev/'bench-binaries/B'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
meta=dict(source_fingerprint=fp,source_manifest=listing,baseline_commit='47f5369d6ca8bbb5fed8e50580a5d4e5003a9190',baseline_source_fingerprint=json.loads((dev/'bench-binaries/baseline-manifest.json').read_text())['source_fingerprint'],binary_sha256={a:sha(p) for a,p in binaries.items()},cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),schedule='per case, adjacent AB then BA; declared five fixed repetitions',contract='A is the frozen packed-trie/sparse-first implementation a5989cb5e42e. B adds exact sixteen-entry AVX-512 row updates; strided M31 packets retain eight-entry AVX2 Mersenne dispatch. All sugar scheduling, reducer policy, full bases and algorithm counters remain unchanged. Full result hashes must agree. Candidate canonicalization, F4 and final interreduction are timed; certification and kernel checking are excluded',toolchain=(root/'lean-toolchain').read_text().strip(),compiler=subprocess.check_output(['cc','--version'],text=True),script=pathlib.Path(__file__).read_text(),runs=[])
try:
 for block,order in enumerate(['AB','BA']):
  for case in ['cyclic4','cyclic5','cyclic6','katsura3','reimer5','cyclic6Small']:
   for arm in order:
    prefix=f'{case}-b{block}-{arm}';command=[str(binaries[arm]),'run','Hex.Groebner.Bench.'+case,'--export-file',str(out/(prefix+'.json'))]
    print(prefix,flush=True);start=time.monotonic_ns()
    with (out/(prefix+'.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    meta['runs'].append(dict(case=case,block=block,arm=arm,command=command,returncode=result.returncode,wall_nanos=time.monotonic_ns()-start))
finally:
 meta['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
