from pathlib import Path
import json, shutil, subprocess, tarfile, hashlib
base=Path('/tmp/hex-groebner-contiguous512-checked-production');repo=Path('/tmp/hex-groebner-evidence-review')
manifest=json.loads((base/'manifest.json').read_text());fp=manifest['source_fingerprint'];name='prototype-contiguous512-'+fp
stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
for p in base.iterdir():
 if p.is_file(): shutil.copy2(p,stage/p.name)
 elif p.name not in ['binaries','bench-binaries']: shutil.copytree(p,stage/p.name)
for folder,m in [('root-sources',manifest),('baseline-sources',json.loads(Path('/tmp/hex-groebner-ranked-production/manifest.json').read_text()))]:
 (stage/(folder+'.manifest')).write_text(m['source_manifest'])
 for line in m['source_manifest'].splitlines():
  header,path=line.split('\t');oid=header.split()[1];content=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()==oid
  p=stage/folder/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content)
logs=['/tmp/issue-10987-contiguous512-san.log','/tmp/issue-10987-contiguous512-packets.log','/tmp/issue-10987-contiguous512-bench-build.log','/tmp/issue-10987-contiguous512-checked-freeze.log','/tmp/issue-10987-contiguous512-freeze.log']
for p in logs:shutil.copy2(p,stage/Path(p).name)
shutil.copy2('/tmp/hex-groebner-ranked-production/manifest.json',stage/'baseline-manifest.json');shutil.copy2(__file__,stage/'archive.py')
(stage/'scope.json').write_text(json.dumps(dict(source_fingerprint=fp,baseline='a5989cb5e42e',candidate_commit=manifest['commit'],scope='One 64-process CPU68 CLI campaign, 32 complete bases and all non-timing counters equal; one 120-point CPU12 registered fixed campaign. Every completed sample and outlier retained. No unchanged repeat. Six Clang ASan/UBSan variants and readonly packet guard tests pass. No full independent oracle/conformance profile claimed for this prototype. No scientific superiority established; not selected. No compiler limitation established.',failed_setup='A new test shape consisted of two separate contiguous eight-entry runs. Initial db4b16ff41 test expected rejection based on its stride label instead of actual remaining bytes, failing matrix_avx512_selftest.c:74 result==(accepted?16u:0u). The engine did not fail. The unmeasured freeze was interrupted and its build log retained. Commit 765c8dbf43 corrected the test using actual last-column capacity before the fresh successful freeze. All measured samples use the corrected snapshot.'),indent=2)+'\n')
target=repo/'reports/bench-results/raw'/(name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
print(json.dumps(dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source_fingerprint=fp),indent=2))
