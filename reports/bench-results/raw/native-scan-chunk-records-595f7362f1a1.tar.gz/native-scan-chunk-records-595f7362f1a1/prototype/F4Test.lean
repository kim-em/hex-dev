import F4Prototype
import HexGroebner.F4Fixtures

open Hex.Groebner

private def checked : Bool := Id.run do
  for field in Fixtures.fields do
    for order in [TermOrder.lex,.grlex,.grevlex] do
      for c in F4Fixtures.cases field do
        let context : Context := ⟨field,c.variables,order⟩
        let .candidate expected stats := computeWith context {} c.generators | return false
        let .candidate actual usage := ScanProto.computeWith context {} c.generators | return false
        if actual.polynomials != expected.polynomials || usage != stats then return false
  return true

#guard checked
