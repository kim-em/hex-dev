import Lake
open Lake DSL System
package GroebnerScanDev
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
target scanO pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "scan.c")
  let file := pkg.dir / defaultBuildDir / "scan.o"
  buildFileAfterDep file source fun input => do
    createParentDirs file
    proc { cmd := "cc", args := #["-O3","-Wall","-Wextra","-fPIC","-c",input.toString,"-o",file.toString,
      "-I",(← getLeanIncludeDir).toString] }

lean_lib ScanNative where
  roots := #[`ScanNative]
  globs := #[.one `ScanNative, .one `NativeScan]
  moreLinkObjs := #[scanO]
  precompileModules := true

lean_lib ScanDev where
  roots := #[`ScanTest, `EliminationPrototype, `SymbolicPrototype, `F4Prototype, `EngineTest, `F4Test]

lean_exe scan_compare where
  root := `Main
