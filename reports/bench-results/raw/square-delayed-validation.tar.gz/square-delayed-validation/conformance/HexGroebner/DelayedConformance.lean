/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

import HexGroebner.Elimination
import HexGroebner.F4
import HexGroebner.Fixtures
import HexGroebner.ScanConformance

namespace Hex.Groebner.DelayedConformance
open Native ScanConformance

private def canonical (p : Nat) (dense : ByteArray) : ByteArray :=
  packed (Native.width p) ((Array.range (dense.size/8)).map fun i => Native.read dense 8 (8*i)%p)

private def gatherEqual (a b : Gather.Result) : Bool :=
  a.state.dense == b.state.dense && a.state.columns == b.state.columns &&
    a.state.coefficients == b.state.coefficients && a.state.cursor == b.state.cursor &&
    a.entries == b.entries && a.bytes == b.bytes && a.work == b.work && a.status == b.status

/-- Compare every bounded native result and its charged failure prefix with the
portable wide transition, and compare its residue projection with the existing
immediate-reduction transition. Inputs include accumulators at the upper square boundary. -/
def runtimeChecks (seed : Nat) : Bool := Id.run do
  for p in [2,3,251,256,257,32003,65521,65536,65537,2147483647] do
    let w := Native.width p
    let pivots : Array Scan.Pivot := #[
      ⟨packed 4 #[0,2,4,6,8],packed w #[1,p-1,p-1,p-1,p-1],2^90⟩,
      ⟨packed 4 #[2,4,6,8],packed w #[1,p-1,p-1,p-1],2^90+1⟩]
    let slots := packed 4 #[1,0,2,0,0,0,0,0,0]
    for value in [seed%p,p-1,p*p-1,p*p-p] do
      let initial : Scan.State := { dense := packed 8 (#[value,seed%p,p+1,2*p,p-1,value,3*p,seed%p,p-1].map (· % (p*p))), column := 0,last := 8,chargedUntil := 0 }
      for quantum in [0,1,2,7,32,4096] do
        for work in [0,1,5,32,2^90] do
          for traces in [0,1,2^90] do
            for provenance in [false,true] do
              let actual := Native.Delayed.transition p.toUInt64 slots pivots initial quantum work traces provenance
              let expected := Native.Delayed.scanPortable p.toUInt64 slots pivots initial quantum work traces provenance
              if !ScanConformance.equal actual expected then return false
              let original := Native.Scan.portable p.toUInt64 slots pivots
                { initial with dense := canonical p initial.dense } quantum work traces provenance
              let projected := { actual with state := { actual.state with dense := canonical p actual.state.dense } }
              if !ScanConformance.equal projected original then return false
      let input : Gather.State := ⟨initial.dense, {},{},0⟩
      for factor in [1,p-1] do
        for quantum in [0,1,5,4096,4097] do
          for entries in [0,1,5] do
            for bytes in [0,4+w,1000] do
              for work in [0,1,5] do
                let actual := Native.Delayed.gather p.toUInt64 input 9 quantum entries bytes work factor.toUInt64
                let expected := Native.Delayed.gatherPortable p.toUInt64 input 9 quantum entries bytes work factor.toUInt64
                if !gatherEqual actual expected then return false
                let original := Native.Gather.portable p.toUInt64
                  { input with dense := canonical p input.dense } 9 quantum entries bytes work factor.toUInt64
                let projected := { actual with state := { actual.state with dense := canonical p actual.state.dense } }
                if !gatherEqual projected original then return false
  return true

#guard runtimeChecks 0

/-- Invalid geometry, oversized Nat fields and borrowed aliases preserve the
portable rejection prefix. Touched accumulator updates reject values outside the square bound. -/
def malformedChecks (seed : Nat) : Bool := Id.run do
  let p := 65537
  let slots := packed 4 #[1,0,0]
  let dense := packed 8 #[1,seed%p,2]
  let pivots : Array Scan.Pivot := #[⟨packed 4 #[0,2],packed 4 #[1,p-1],seed⟩]
  let initial : Scan.State := { dense,column := 0,last := 2,chargedUntil := 0 }
  let states := #[initial,{ initial with dense := dense.extract 0 7 },
    { initial with column := 2^90 },{ initial with last := 2^90 },
    { initial with chargedUntil := 2^90 },{ initial with leading := 2^90 },
    { initial with pending := 2^90 },{ initial with entry := 1 },
    { initial with pending := 1,entry := 2^90 },{ initial with factor := p.toUInt64 },
    { initial with pending := 1,entry := 2 }]
  for state in states do
    for modulus in [0,1,p,2147483648] do
      for quantum in [0,1,4096,4097,2^90] do
        if !ScanConformance.equal
            (Native.Delayed.transition modulus.toUInt64 slots pivots state quantum (2^90) (2^90) true)
            (Native.Delayed.scanPortable modulus.toUInt64 slots pivots state quantum (2^90) (2^90) true) then return false
  for rows in [#[Native.Scan.Pivot.mk (packed 4 #[0,2]) (packed 1 #[1]) 0],
      #[⟨packed 4 #[0,0],packed 4 #[1,1],0⟩],#[⟨packed 4 #[0,3],packed 4 #[1,1],0⟩],
      #[⟨packed 4 #[1,2],packed 4 #[1,1],0⟩]] do
    if !ScanConformance.equal
        (Native.Delayed.transition p.toUInt64 slots rows initial 4096 1000 100 true)
        (Native.Delayed.scanPortable p.toUInt64 slots rows initial 4096 1000 100 true) then return false
  for input in [(⟨dense,{},{},0⟩ : Gather.State),⟨dense,dense,dense,1⟩,
      ⟨dense.extract 0 7,{},{},0⟩,⟨dense,packed 1 #[0],{},0⟩,
      ⟨dense,packed 4 #[0],{},0⟩,⟨dense,{},{},2^90⟩] do
    for factor in [0,1,p-1,p] do
      for stop in [0,3,2^90] do
        if !gatherEqual
            (Native.Delayed.gather p.toUInt64 input stop 4096 100 1000 100 factor.toUInt64)
            (Native.Delayed.gatherPortable p.toUInt64 input stop 4096 100 1000 100 factor.toUInt64) then return false
  return true

#guard malformedChecks 0

/-- A pending reduction crosses native quanta and extends the active range to
5000 columns. Compare every resumed state, not only the completed matrix. -/
def longChecks (seed : Nat) : Bool := Id.run do
  let p := 2147483647
  let n := 5000
  let factor := 1+seed%5
  let slots := packed 4 ((Array.replicate n 0).set! 0 1)
  let pivots : Array Scan.Pivot := #[⟨packed 4 (Array.range n),
    packed 4 ((Array.replicate n (p-1)).set! 0 1),2^90⟩]
  for quantum in [17,4096] do
    let mut state : Scan.State := { dense := packed 8 ((Array.replicate n 0).set! 0 factor), column := 0,last := 0,chargedUntil := 0 }
    let mut done := false
    let mut events := #[]
    let mut work := 0
    for _ in [:2*n+4] do
      let actual := Native.Delayed.transition p.toUInt64 slots pivots state quantum 1000000 100 true
      let expected := Native.Delayed.scanPortable p.toUInt64 slots pivots state quantum 1000000 100 true
      if !ScanConformance.equal actual expected then return false
      state := actual.state
      events := events ++ actual.events
      work := work+actual.work
      if actual.status == 1 then
        done := true
        break
      if actual.status != 0 then return false
    if !done || state.leading != 2 || state.sugar != 2^90 || work != 2*n ||
        events != #[(0,factor.toUInt64)] || Native.read state.dense 8 0 != 0 ||
        Native.read state.dense 8 (8*(n-1)) % p != factor then return false
  return true

#guard longChecks 0

example : (Native.Delayed.scanPortable 7 (packed 4 #[1,0])
    #[⟨packed 4 #[0,1],packed 1 #[1,6],0⟩]
    { dense := packed 8 #[2,0],column := 0,last := 1,chargedUntil := 0 }
    4 100 1 true).work = 4 := by decide +kernel

private def rowEq (a b : SparseRow) : Bool := a.columns == b.columns && a.coefficients == b.coefficients

/-- Entire matrices and shared derivations agree with immediate reduction. The
only completed-run counter difference is the larger dense workspace. -/
def matrixChecks : Bool := Id.run do
  for field in Fixtures.fields do
    for c in Fixtures.cases field do
      let .ok reducers := Fixtures.sparse field c.columns c.reducers | return false
      let .ok targets := Fixtures.sparse field c.columns c.targets | return false
      for provenance in [false,true] do
        let a := eliminateWith field {} c.columns reducers targets provenance
        let b := eliminateWith field { delayedReduction := false } c.columns reducers targets provenance
        let .ok aBasis := a.result | return false
        let .ok bBasis := b.result | return false
        if aBasis.trace != bBasis.trace || aBasis.reducerRank != bBasis.reducerRank ||
            aBasis.rows.size != bBasis.rows.size then return false
        for (a,b) in aBasis.rows.zip bBasis.rows do
          if !rowEq a.row b.row || a.fromTarget != b.fromTarget || a.derivation != b.derivation ||
              a.multiplier != b.multiplier || a.sugar != b.sugar then return false
        let extra := (({} : MatrixLimits).denseBytes field-field.width.bytes)*c.columns
        if a.stats != { b.stats with work := b.stats.work+extra, packedBytes := b.stats.packedBytes+extra } then return false
  return true

#guard matrixChecks

/-- A full four-byte F4 call exercises the delayed providers inside the native
counter window. The input depends on IO's seed in the compiled runner. -/
def f4Checks (seed : Nat) : Bool := Id.run do
  let field : PrimeField := ⟨2147483647,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  let context : Context := ⟨field,5,.grevlex⟩
  let mut generators : Array RawPolynomial := #[]
  for degree in [1:5] do
    let mut polynomial := #[]
    for start in [:5] do
      let mut exponents := Array.replicate 5 0
      for step in [:degree] do exponents := exponents.modify ((start+step)%5) (·+1)
      polynomial := polynomial.push ⟨exponents,1⟩
    generators := generators.push polynomial
  generators := generators.push #[⟨Array.replicate 5 1,1⟩,
    ⟨Array.replicate 5 0,(2147483647-(seed%2147483646+1)).toUInt64⟩]
  match computeWith context {} generators with
  | .candidate value statistics => return !value.polynomials.isEmpty && statistics.matrixCalls > 1
  | _ => return false

end Hex.Groebner.DelayedConformance
