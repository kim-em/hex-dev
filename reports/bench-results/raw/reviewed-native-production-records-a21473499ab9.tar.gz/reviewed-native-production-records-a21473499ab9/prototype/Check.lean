import HexGroebner.ScanConformance
import HexGroebner.GatherConformance
import HexGroebner.MatrixNativeConformance
import HexGroebner.F4Conformance
open Hex.Groebner

def main : IO Unit := do
  if ScanConformance.runtimeChecks && ScanConformance.runtimeWideChecks &&
      GatherConformance.gatherRuntimeChecks && GatherConformance.gatherMalformedChecks &&
      MatrixNativeConformance.engineRuntimeChecks then
    IO.println "production native scan/gather: widths, aliases, malformed prefixes, matrices and resource boundaries match portable"
  else throw (IO.userError "native scan/gather mismatch")
