import Lake
open Lake DSL
package GroebnerNativeProduction
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987"
lean_lib Reference where
  roots := #[`ReferenceElimination, `ReferenceSymbolic, `ReferenceF4]
lean_exe production_compare where
  root := `Main
