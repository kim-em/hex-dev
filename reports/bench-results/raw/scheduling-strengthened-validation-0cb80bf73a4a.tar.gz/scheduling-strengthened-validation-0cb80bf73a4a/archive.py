from pathlib import Path
import shutil,tarfile,hashlib,json
root=Path('/tmp/hex-groebner-scheduling-dev');base=Path('/tmp/hex-groebner-scheduling-strengthened-production');stage=base/'validation';stage.mkdir(exist_ok=False)
for n in ['manifest.json','source.manifest','build.log','groebner_freeze.py']:shutil.copy2(base/n,stage/n)
shutil.copytree(base/'root-sources',stage/'root-sources')
for n in ['resume-sweeps','strengthened-tests','full-conformance','unique-oracles','oracle-tests','dag','phase4','manifest','headers','lines','report-lines','mutants']:
 p=Path('/tmp/issue-10987-pr11008-'+n+'.log')
 if p.exists():shutil.copy2(p,stage/p.name)
shutil.copy2('/tmp/issue-10987-pr11008-binary-identity.json',stage/'binary-identity.json');shutil.copytree('/tmp/issue-10987-pr11008-mutants',stage/'fault-tests');shutil.copy2('/tmp/issue-10987-pr11008-run-mutants.py',stage/'run-fault-tests.py')
for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(root/folder,stage/folder)
for n in ['scripts/oracle/groebner_corpus.py','scripts/oracle/groebner_sympy.py','scripts/oracle/groebner_singular.py','scripts/oracle/test_groebner_sympy.py','scripts/ci/check_groebner_driver.py']:
 p=stage/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/n,p)
for n in ['counter-analysis.json','pooled-analysis.json']:shutil.copy2(Path('/tmp/hex-groebner-scheduling-production')/n,stage/('original-'+n))
shutil.copy2(root/'reports/bench-results/raw/scheduling-counter-strata-bf00a2b578a8.json',stage/'counter-strata.json')
(stage/'scope.json').write_text(json.dumps(dict(source_fingerprint='0cb80bf73a4a',scope='Strengthened continuation and corpus validation. A fresh 188-job build yields byte-identical default/full-init executables to the timed bf00a2b578a8 source and prior 6ede9cb261a4 validation. All 1958 conformance/theory targets pass. Both producers compare resumed statistics at every work boundary on a system whose schedulers differ; the traced route also compares derivations, and each sweep requires a queued checkpoint and an attempted round. Each fault copy selects its relevant guard without changing the predicate; deleting either scheduling override fails that named guard. Both strategies cover batch caps. Every unflagged CLI degree profile is checked. Strict corpus validation remains active under Python -O, rejects invalid sugar headers and missing strategy metadata, checks all 1134 profile inputs/bases for equality, and sends the 567 unique problems to independent SymPy/Singular once. Initial four Clang/four GCC sanitizer evidence remains unchanged; native sources and frozen binaries are unchanged. No new timings, null controls or unchanged repeats. Timing strata retain all samples and identify equal counters without claiming equal traces or attributing latency causes.'),indent=2)+'\n')
shutil.copy2(__file__,stage/'archive.py');target=root/'reports/bench-results/raw/scheduling-strengthened-validation-0cb80bf73a4a.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname='scheduling-strengthened-validation-0cb80bf73a4a')
result=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest());Path('/tmp/issue-10987-pr11008-strengthened-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
