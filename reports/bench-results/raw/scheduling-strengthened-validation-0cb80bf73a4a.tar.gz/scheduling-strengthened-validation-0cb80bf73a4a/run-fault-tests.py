from pathlib import Path
import subprocess,re,json
root=Path('/tmp/hex-groebner-scheduling-mutants');out=Path('/tmp/issue-10987-pr11008-mutants');out.mkdir(exist_ok=False)
test=root/'conformance/HexGroebner/SchedulingResumeConformance.lean';original_test=test.read_text();results=[]
for name,file,guard,omit in [('candidate','HexGroebner/F4.lean','checkpoints','traced'),('producer','HexGroebner/Producer/Compute.lean','traced','checkpoints')]:
 p=root/file;original=p.read_text();line='  let limits := { limits with scheduling := initial.scheduling }\n';assert original.count(line)==1
 mutated=original.replace(line,'',1);p.write_text(mutated);test.write_text(original_test.replace('#guard '+omit,'-- #guard '+omit))
 (out/(name+'-original.lean')).write_text(original);(out/(name+'-mutant.lean')).write_text(mutated);(out/(name+'-test.lean')).write_text(test.read_text())
 try:
  with (out/(name+'.log')).open('w') as log:r=subprocess.run(['lake','build','+HexGroebner.SchedulingResumeConformance'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  text=(out/(name+'.log')).read_text();assert r.returncode!=0 and ('  '+guard+'\ndid not evaluate to `true`') in text,(name,text[-3000:])
  errors=[s for s in text.splitlines() if s.startswith('error:')];assert all('Expression' in s or s=='error: build failed' for s in errors),errors
  results.append(dict(mutant=name,exit=r.returncode,failed_guard=guard));print(results[-1],flush=True)
 finally:p.write_text(original);test.write_text(original_test)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
