from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
s=Path('/home/kim/tmp/issue-10987');stage='support-integration';root=Path.cwd();sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS
from scripts.bench.sweep_freshness import tree_listing
prefix='support-integration-verified';native=json.loads((s/(prefix+'-native-status.json')).read_text());identity={k:native[0][k]for k in ['source_commit','source_fingerprint','source_manifest_sha256','checks_fingerprint','checks_manifest_sha256']};assert len(native)==2 and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in native);payload={}
def add(n,p):
 assert n not in payload,n
 payload[n]=p.read_bytes()
def tree(label,base,shallow=False):
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if p.is_file()and'binaries'not in rel.parts and p.suffix!='.data' and (not shallow or len(rel.parts)==1 or rel.parts[0]in ['root-sources','compiler-inputs']):add(label+'/'+str(rel),p)
tree('baseline',s/'binary-pr30-review-production',True);tree('candidate',s/'support-integration-recovered-production')
manifest=json.loads((s/'support-integration-recovered-production/manifest.json').read_text());assert manifest['source_fingerprint']==identity['source_fingerprint']
for cc in ['clang','gcc']:
 add('native-'+cc+'.log',s/(prefix+'-'+cc+'.log'));base=s/(prefix+'-'+cc)
 for p in sorted(base.rglob('*')):
  if p.is_file()and'.lake'not in p.relative_to(base).parts:add('probes/'+cc+'/'+str(p.relative_to(base)),p)
add('native-status.json',s/(prefix+'-native-status.json'))
add('full-status.json',s/'support-integration-fixtures-full-status.json')
for name in ['build','oracles','driver','bench','dag','phase4','manifest','headers','lines']:
 add('full/'+name+'.log',s/('support-integration-fixtures-full-'+name+'.log'))
for name in ['support-native-disk-interruption.json','support-integration-full-build.log',
 'support-integration-freeze.log','support-integration-recovered-full-oracles.log',
 'support-integration-f4-emission.log','disk-recovery-build-output.json']:
 add('diagnostics/'+name,s/name)
text=tree_listing(CHECKS,identity['source_commit']);payload['checks.manifest']=text.encode()
for line in text.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for p in sorted(s.glob('*support-integration*.py')):add('collectors/'+p.name,p)
if stage=='projection':
 tree('usage-failed',s/'binary-projection-usage-results');tree('usage',s/'binary-projection-usage-results-corrected')
 for name in ['Usage.lean','probe.c','lakefile.lean','lake-manifest.json']:add('usage-probe/'+name,s/'binary-projection-usage'/name)
if stage=='table-bounds':
 for name in ['binary-table-bounds-tests-build.log','binary-table-bounds-debug.log','binary-table-bounds-gaps-fixed.log']:
  add('diagnostics/'+name,s/name)
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();payload['scope.txt']=f'Development experiment {stage}. All twelve sanitized native variants pass; all nine project gates pass on this snapshot. Retains the first matched F4 pass and exactly one unchanged repeat over both F2 and prime fields. Work and allocation differ only by the explicit support bitmap charge; all other structural statistics agree. All completed samples/outliers retained; no leadership claim.\n'.encode();payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode();out=s/('f4-'+stage+'-'+identity['source_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-'+stage+'/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
