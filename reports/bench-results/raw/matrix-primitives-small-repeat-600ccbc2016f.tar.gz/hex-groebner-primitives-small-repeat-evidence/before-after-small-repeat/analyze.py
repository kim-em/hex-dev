from pathlib import Path
import json,statistics
base=Path('/tmp/hex-groebner-primitives-kernel-production');out=base/'before-after-small-repeat';d=json.loads((out/'metadata.json').read_text());pairs={}
for s in d['samples']:
 assert s['status']=='ok' and s['complete_basis_equal'];pairs.setdefault((s['case'],s['block']),{})[s['arm']]=s
rows=[]
for (case,block),arms in pairs.items():
 assert set(arms)=={'A','B'};a,b=arms['A'],arms['B'];assert {k:v for k,v in a['statistics'].items()if k!='candidate_nanos'}=={k:v for k,v in b['statistics'].items()if k!='candidate_nanos'}
 rows.append(dict(case=case,block=block,family=a['family'],candidate=b['statistics']['candidate_nanos']/a['statistics']['candidate_nanos'],process=b['wall_nanos']/a['wall_nanos']))
def summary(v):return dict(geomean=statistics.geometric_mean(v),median=statistics.median(v),minimum=min(v),maximum=max(v))
families={f:{k:summary([r[k]for r in rows if r['family']==f])for k in['candidate','process']}for f in sorted({r['family']for r in rows})}
result=dict(scope='Single allowed diagnostic small-suite repeat after inconclusive near-neutral initial result. Source600ccbc2016f, compute ELF byte-identical to sourcee096f91a0bf1. Source and observations remain separate; no pooling and no further unchanged repeat.',pairs=len(rows),processes=len(d['samples']),all_complete_bases_and_counters_equal=True,candidate=summary([r['candidate']for r in rows]),process=summary([r['process']for r in rows]),family_balanced_process=statistics.geometric_mean(v['process']['geomean']for v in families.values()),families=families,ratios=rows)
(out/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');(out/'analyze.py').write_bytes(Path(__file__).read_bytes());print({k:v for k,v in result.items()if k not in ['families','ratios']})
