from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile,sys
state=Path('/home/kim/tmp/issue-10987');root=Path.cwd();payload={};sys.path.insert(0,str(root))
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing
listing=tree_listing(FAMILY,'HEAD');measured=json.loads((state/'sampled-reviewed-production/manifest.json').read_text());assert listing==measured['source_manifest']
def add(name,path):
 assert name not in payload
 payload[name]=path.read_bytes()
for name,path in [('native-status.json','sampled-reviewed-native-status.json'),('full-status.json','sampled-reviewed-full-status.json'),('full-checks.py','sampled-reviewed-full-checks.py'),('native-checks.py','sampled-reviewed-native-checks.py')]:add(name,state/path)
payload['final-source.manifest']=listing.encode()
for row in json.loads((state/'sampled-reviewed-full-status.json').read_text()):
 assert row['exit_code']==0
 add(row['name']+'.log',Path(row['log']))
for compiler in ['clang','gcc']:add(compiler+'.log',state/f'sampled-reviewed-{compiler}.log')
for name in ['scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh','scripts/ci/check_groebner_sampling.py','scripts/ci/run_oracles.sh','scripts/ci/test_oracle_build.py','scripts/bench/groebner_sampling_report.py','conformance/HexGroebner/SamplingConformance.lean','conformance/HexGroebner/SampledConformance.lean']:
 add('sources/'+name,Path(name))
payload['implementation.patch']=subprocess.check_output(['git','diff','origin/main...HEAD','--no-ext-diff'])
add('pack-sampled-reviewed-guards.py',Path(__file__))
manifest={k:hashlib.sha256(v).hexdigest()for k,v in sorted(payload.items())};payload['sha256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=Path('reports/bench-results/raw/f4-sampling-checks-ad855e8a2e.tar.xz')
with lzma.open(out,'wb',preset=6)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-sampling-reviewed-checks/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
