import KernelBench
open Hex.Groebner.Bench
def main : IO Unit := do
  for n in [32,64,96,125] do
    if !(cauchy8 (prepare8 n)).1 then throw (IO.userError s!"cauchy8 failed at {n}")
    IO.println s!"cauchy8 {n}: success"
  for n in [64,128,256,512] do
    if !(cauchy16 (prepare16 n)).1 then throw (IO.userError s!"cauchy16 failed at {n}")
    if !(cauchy16Trace (prepare16 n)).1 then throw (IO.userError s!"cauchy16Trace failed at {n}")
    if !(cauchy16Strided (prepare16Strided n)).1 then throw (IO.userError s!"cauchy16Strided failed at {n}")
    IO.println s!"cauchy16/trace/strided {n}: success"
