#define lean_hex_scan_transition __wrap_lean_hex_scan_transition
#define lean_hex_gather __wrap_lean_hex_gather
#include "/tmp/hex-groebner-small-review/HexGroebner/ffi/matrix_scan.c"
