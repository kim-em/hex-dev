import Lake
open Lake DSL System
package GroebnerStridedBench
require Hex from "/tmp/hex-groebner-small-review"
def probeO (pkg : Package) (name : String) (flags : Array String) : FetchM (Job FilePath) := do
  let source ← inputTextFile (pkg.dir / "probe.c")
  let body ← inputTextFile (FilePath.mk "/tmp/hex-groebner-small-review/HexGroebner/ffi/matrix_scan_impl.h")
  let simd ← inputTextFile (FilePath.mk "/tmp/hex-groebner-small-review/HexGroebner/ffi/matrix_simd.h")
  let inputs := (source.zipWith (fun s _ => s) body).zipWith (fun s _ => s) simd
  buildO (pkg.dir / defaultBuildDir / (name ++ ".o")) inputs
    #["-isystem", (← getLeanIncludeDir).toString] flags
lean_lib KernelBench where
  roots := #[`KernelBench]
target probeNative pkg : FilePath := probeO pkg "Native" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING"]
lean_exe benchNative where
  root := `NativeMain
  moreLinkObjs := #[probeNative]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]
target probeScalar pkg : FilePath := probeO pkg "Scalar" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_NO_AVX2"]
lean_exe benchScalar where
  root := `ScalarMain
  moreLinkObjs := #[probeScalar]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]

def plainO (pkg : Package) (name : String) (flags : Array String) : FetchM (Job FilePath) := do
  let source ← inputTextFile (pkg.dir / "plain.c")
  let body ← inputTextFile (FilePath.mk "/tmp/hex-groebner-small-review/HexGroebner/ffi/matrix_scan_impl.h")
  let simd ← inputTextFile (FilePath.mk "/tmp/hex-groebner-small-review/HexGroebner/ffi/matrix_simd.h")
  let scan ← inputTextFile (FilePath.mk "/tmp/hex-groebner-small-review/HexGroebner/ffi/matrix_scan.c")
  let inputs := ((source.zipWith (fun s _ => s) body).zipWith (fun s _ => s) simd).zipWith (fun s _ => s) scan
  buildO (pkg.dir / defaultBuildDir / (name ++ ".o")) inputs
    #["-isystem", (← getLeanIncludeDir).toString] flags
target plainNative pkg : FilePath := plainO pkg "PlainNative" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING"]
lean_exe benchPlainNative where
  root := `PlainNativeMain
  moreLinkObjs := #[plainNative]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]
target plainScalar pkg : FilePath := plainO pkg "PlainScalar" #["-O3", "-g", "-Wall", "-Wextra", "-Werror", "-fPIC", "-DLEAN_EXPORTING", "-DHEX_GROEBNER_NO_AVX2"]
lean_exe benchPlainScalar where
  root := `PlainScalarMain
  moreLinkObjs := #[plainScalar]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]

lean_exe ecoProbe where
  root := `EcoMain
  moreLinkObjs := #[probeNative]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]
lean_lib Reference where
  roots := #[`ReferenceElimination, `ReferenceSymbolic, `ReferenceF4]

lean_exe verifyNative where
  root := `VerifyNativeMain
  moreLinkObjs := #[plainNative]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]

lean_exe verifyScalar where
  root := `VerifyScalarMain
  moreLinkObjs := #[plainScalar]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_scan_transition", "-Wl,--wrap=lean_hex_gather"]
