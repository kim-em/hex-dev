from pathlib import Path
import json,tarfile,subprocess,hashlib,shutil
repo=Path('/tmp/hex-groebner-evidence-review');dest=repo/'reports/bench-results/raw';catalog=[]
variants=['sparse-targets']
for variant in variants:
 base=Path('/tmp/hex-groebner-'+variant+'-production');manifest=json.loads((base/'binaries/manifest.json').read_text());fp=manifest['source_fingerprint'];name=f'prototype-{variant}-{fp}';stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(parents=True,exist_ok=False)
 shutil.copy2(__file__,stage/'archive-prototypes.py');shutil.copy2(base/'binaries/manifest.json',stage/'manifest.json')
 baseline=base/'binaries/baseline-manifest.json'
 if baseline.exists():shutil.copy2(baseline,stage/'baseline-manifest.json')
 for script in base.iterdir():
  if script.is_file() and (script.suffix in ['.lean','.py','.json'] or script.name=='lean-toolchain'):shutil.copy2(script,stage/script.name)
 directories=[];samples=runs=0
 for directory in base.iterdir():
  if directory.is_dir() and (directory/'metadata.json').exists():
   meta=json.loads((directory/'metadata.json').read_text())
   # Include independently described auxiliary campaigns as well as source-indexed runs.
   if meta.get('source_fingerprint') not in [None,fp]:continue
   shutil.copytree(directory,stage/directory.name)
   directories.append(directory.name);samples+=len(meta.get('samples',[]));runs+=len(meta.get('runs',[]))
 listings={'root-sources':manifest.get('source_manifest')}
 if baseline.exists():listings['baseline-sources']=json.loads(baseline.read_text()).get('source_manifest')
 count=0
 for folder,listing in listings.items():
  if not listing:continue
  (stage/(folder+'.manifest')).write_text(listing)
  for line in listing.splitlines():
   header,path=line.split('\t',1);oid=header.split()[1];p=stage/folder/path;p.parent.mkdir(parents=True,exist_ok=True)
   content=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);p.write_bytes(content)
   assert hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()==oid;count+=1
 # Preserve the original two-process semantic failure as a distinct snapshot.
 failed=base/'sparse-targets-production-records-29215102b484'
 if failed.exists():
  shutil.copytree(failed,stage/failed.name)
  old=json.loads((base/'binaries/failed-29215102b484/manifest.json').read_text())
  (stage/'failed-manifest.json').write_text(json.dumps(old,indent=2)+'\n')
  for line in old['source_manifest'].splitlines():
   header,path=line.split('\t',1);oid=header.split()[1];p=stage/'failed-sources'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd=repo))
  shutil.copy2('/tmp/issue-10987-sparse-targets-production-measure.log',stage/'failed-campaign.log')
 corrections=['Original 29215102b484 prototype sorted independent final normal-form targets too, breaking row/remainder correspondence. Both completed processes and the complete-basis mismatch are retained separately. Corrected 668abb190c63 sorts only joint elimination and supplies all aggregate timing results. The failed snapshot is never pooled with it.']
 if variant=='avx512':corrections.append('Kernel protocol text later mentions eight-lane updates; the A/B definition at its start is authoritative: baseline AVX2 eight-entry versus sixteen-entry AVX-512. All completed finite-size points are retained; complexity verdicts remain inconclusive.')
 if variant in ['text','json-runtime','minimal-init']:corrections.append('The computational source index remains 802ae51122d7; external driver/prototype files and their hashes identify frontend changes. Text msolve runs used a libtool wrapper and Nix-stripped native tuning, so those comparator observations are biased in favor of Hex and superseded by standalone-driver native comparisons. Compiler labels inherited from older generic metadata are not authoritative; actual FFI compiler is Clang 23.1.3, SDK C compiler Clang 23.1.0.')
 (stage/'scope.json').write_text(json.dumps({'variant':variant,'source_fingerprint':fp,'complete_record_directories':directories,'samples':samples,'run_exports':runs,'source_blobs':count,'scope':'Research variant only, not a selected implementation. Independent snapshots must not be pooled. All completed samples and outliers are retained. No fastest-open-source claim. GNU-time wrapper memory reports apply only where explicitly recorded; wait4 parent-floor readings must not be interpreted as child memory.','protocol_corrections':corrections},indent=2)+'\n')
 target=dest/(name+'.tar.gz');assert not target.exists(),target
 with tarfile.open(target,'w:gz') as archive:archive.add(stage,arcname=name)
 row={'variant':variant,'source_fingerprint':fp,'archive':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'samples':samples,'run_exports':runs,'source_blobs':count};catalog.append(row);print(json.dumps(row),flush=True)
Path('/tmp/issue-10987-sparse-targets-archive-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
