from pathlib import Path
import sys,json,math,statistics
base=Path(sys.argv[1]);summary=lambda v:dict(geomean=math.exp(sum(map(math.log,v))/len(v)),median=statistics.median(v),minimum=min(v),maximum=max(v));experiments=[];allrows=[]
for p in sorted(base.glob('*-production-records-*')):
 if not p.name.endswith('668abb190c63'):continue
 m=json.loads((p/'metadata.json').read_text());groups={};rows=[]
 for r in m['samples']:groups.setdefault((r['case'],r['block']),{})[r['arm']]=r
 for (case,block),pair in groups.items():
  a,b=pair['A'],pair['B'];assert a['status']==b['status']=='ok' and a['complete_basis_equal'] and b['complete_basis_equal'];sa,sb=a['statistics'].copy(),b['statistics'].copy();an,bn=sa.pop('candidate_nanos'),sb.pop('candidate_nanos'); changes={k:[sa[k],sb[k]] for k in sa if sa[k]!=sb[k]}
  rows.append(dict(case=case,block=block,candidate_ratio=bn/an,process_ratio=b['wall_nanos']/a['wall_nanos'],a_candidate_nanos=an,b_candidate_nanos=bn,changed_counters=changes))
 x=dict(name=p.name,cpu=m['cpu'],source_fingerprint=m['source_fingerprint'],samples=len(m['samples']),all_full_bases_equal=True,candidate=summary([r['candidate_ratio'] for r in rows]),process=summary([r['process_ratio'] for r in rows]),pairs=rows);(p/'analysis.json').write_text(json.dumps(x,indent=2)+'\n');experiments.append(x);allrows.extend(rows)
out=dict(experiments=experiments,candidate=summary([r['candidate_ratio'] for r in allrows]),process=summary([r['process_ratio'] for r in allrows]),samples=sum(e['samples'] for e in experiments),pairs=allrows);(base/'diagnostic-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for x in experiments:print(x['name'],x['cpu'],x['candidate'],x['process'])
print('all',out['candidate'],out['process'])
