from pathlib import Path
import hashlib,json,random,subprocess,sys
w=Path.cwd();sys.path.insert(0,str(w));from scripts.oracle.groebner_sympy import check
s=Path('/home/kim/tmp/issue-10987');out=s/'active-list-random';out.mkdir(exist_ok=False);rng=random.Random(1098726);records=[];manifest=json.loads((s/'active-list-production/manifest.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for case in range(128):
 p=[2,3,7,101][case%4];n=2+(case//4)%2;order=['lex','grlex','grevlex'][(case//8)%3];homogeneous=(case//24)%2==0;positive=(case//48)%2==1;variables=n-1 if positive else n;generators=[]
 for j in range(2+case%2):
  terms=[]
  for _ in range(3+case%3):
   degree=2 if homogeneous else rng.randrange(4);powers=[0]*n
   for _ in range(degree):powers[rng.randrange(variables)]+=1
   terms.append([powers,rng.randrange(1,p)])
  generators.append(terms)
 inp={'p':p,'variables':n,'order':order,'generators':generators};path=out/f'{case}.json';path.write_text(json.dumps(inp)+'\n');expected=None
 for scheduling in ['degree','sugar']:
  for name in ['compute','compute-reference']:
   binary=s/'active-list-production/binaries'/name;before=sha(binary)
   command=[str(binary),'--work','1000000000','--scheduling',scheduling,str(path)]
   r=subprocess.run(command,capture_output=True,timeout=30);after=sha(binary)
   (out/f'{case}-{scheduling}-{name}.stdout').write_bytes(r.stdout);(out/f'{case}-{scheduling}-{name}.stderr').write_bytes(r.stderr)
   assert r.returncode==0,(case,scheduling,name,r.returncode,r.stdout[-500:])
   value=json.loads(r.stdout);assert value['kind']=='unchecked_candidate';assert before==after==manifest['binary_sha256'][name]
   if expected is None:expected=check({**inp,'basis':value['basis']})
   assert value['basis']==expected,(case,scheduling,name)
   records.append({'case':case,'scheduling':scheduling,'name':name,'exit_code':r.returncode,'input_sha256':sha(path),'binary_sha256':before,'basis_equal':True})
 (out/'status.json').write_text(json.dumps({'seed':1098726,'source_fingerprint':manifest['source_fingerprint'],'records':records},indent=2)+'\n')
 if case%16==0:print(case,len(records),flush=True)
print('PASS',len(records),'computations on128 fresh systems with independent SymPy bases',flush=True)
