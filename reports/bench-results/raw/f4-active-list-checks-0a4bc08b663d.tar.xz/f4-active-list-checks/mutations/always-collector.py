from pathlib import Path
import hashlib,json,subprocess,sys
w=Path.cwd();sys.path.insert(0,str(w));from scripts.bench.groebner_checks import source_identity
s=Path('/home/kim/tmp/issue-10987');out=s/'retirement-always-check';out.mkdir(exist_ok=False);binary=w/'.lake/build/bin/hexgroebner_compute';identity=source_identity();digest=hashlib.sha256(binary.read_bytes()).hexdigest();rows=[];detected=False
for case in range(128):
 inp=s/'active-list-random'/f'{case}.json';expected=json.loads((s/'active-list-random'/f'{case}-degree-compute.stdout').read_text());r=subprocess.run([str(binary),'--work','1000000000',str(inp)],capture_output=True,timeout=30);(out/f'{case}.stdout').write_bytes(r.stdout);(out/f'{case}.stderr').write_bytes(r.stderr);got=json.loads(r.stdout);equal=got.get('basis')==expected['basis'];rows.append({'case':case,'exit_code':r.returncode,'basis_equal':equal,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest()})
 if r.returncode==0 and got['kind']=='unchecked_candidate'and not equal:
  detected=True;(out/'counterexample.json').write_bytes(inp.read_bytes());(out/'expected.json').write_text(json.dumps(expected,indent=2)+'\n');break
assert source_identity()==identity and digest==hashlib.sha256(binary.read_bytes()).hexdigest()
(out/'status.json').write_text(json.dumps({'detected':detected,**identity,'binary_sha256':digest,'records':rows},indent=2)+'\n');assert detected,'corpus did not detect invalid retirement';print('DETECTED wrong basis',rows[-1],flush=True)
