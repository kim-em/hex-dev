from pathlib import Path
import copy,json,subprocess
s=Path('/home/kim/tmp/issue-10987');out=s/'retirement-always-check';value=json.loads((out/'counterexample.json').read_text());path=out/'minimize-input.json';records=[]
def fails(inp):
 path.write_text(json.dumps(inp)+'\n');values=[]
 for binary in [s/'active-list-production/binaries/compute',Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-retirement-mutant/.lake/build/bin/hexgroebner_compute')]:
  r=subprocess.run([str(binary),'--work','1000000000',str(path)],capture_output=True,timeout=30)
  if r.returncode:return False
  values.append(json.loads(r.stdout))
 answer=values[0]['basis']!=values[1]['basis'];records.append({'input':inp,'different':answer})
 return answer
for p in [2,3,7]:
 trial=copy.deepcopy(value);trial['p']=p
 for g in trial['generators']:
  for t in g:t[1]%=p
 if fails(trial):value=trial;break
changed=True
while changed:
 changed=False
 for i in range(len(value['generators'])):
  trial=copy.deepcopy(value);del trial['generators'][i]
  if fails(trial):value=trial;changed=True;break
 if changed:continue
 for i,g in enumerate(value['generators']):
  for j in range(len(g)):
   trial=copy.deepcopy(value);del trial['generators'][i][j]
   if fails(trial):value=trial;changed=True;break
  if changed:break
(out/'minimal-input.json').write_text(json.dumps(value,indent=2)+'\n');(out/'minimization.json').write_text(json.dumps(records,indent=2)+'\n');print(value)
for name,binary in [('good',s/'active-list-production/binaries/compute'),('bad',Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-retirement-mutant/.lake/build/bin/hexgroebner_compute'))]:
 r=subprocess.run([str(binary),str(out/'minimal-input.json')],capture_output=True);assert r.returncode==0;(out/('minimal-'+name+'.json')).write_bytes(r.stdout)
