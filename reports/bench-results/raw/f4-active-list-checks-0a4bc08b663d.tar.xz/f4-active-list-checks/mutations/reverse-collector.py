from pathlib import Path
import hashlib,json,subprocess
s=Path('/home/kim/tmp/issue-10987');out=s/'retirement-mutant-check';out.mkdir(exist_ok=False);binary=s/'retirement-mutant-production/binaries/compute';m=json.loads((s/'retirement-mutant-production/manifest.json').read_text());digest=hashlib.sha256(binary.read_bytes()).hexdigest();assert digest==m['binary_sha256']['compute'];rows=[];detected=False
for case in range(128):
 inp=s/'active-list-random'/f'{case}.json';expected=json.loads((s/'active-list-random'/f'{case}-degree-compute.stdout').read_text());r=subprocess.run([str(binary),'--work','1000000000',str(inp)],capture_output=True,timeout=30);(out/f'{case}.stdout').write_bytes(r.stdout);(out/f'{case}.stderr').write_bytes(r.stderr);got=json.loads(r.stdout);equal=r.returncode==0 and got.get('basis')==expected['basis'];rows.append({'case':case,'exit_code':r.returncode,'basis_equal':equal,'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest()})
 if not equal:
  detected=True;(out/'counterexample.json').write_bytes(inp.read_bytes());(out/'expected.json').write_text(json.dumps(expected,indent=2)+'\n');break
(out/'status.json').write_text(json.dumps({'detected':detected,'mutant_source_fingerprint':m['source_fingerprint'],'binary_sha256':digest,'records':rows},indent=2)+'\n');assert detected,'corpus did not detect reversed retirement';print('DETECTED',rows[-1],flush=True)
