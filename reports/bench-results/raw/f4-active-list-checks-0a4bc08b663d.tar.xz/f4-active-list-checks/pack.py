from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing
native=json.loads((s/'active-list-verified-native-status.json').read_text());full=json.loads((s/'active-list-verified-full-status.json').read_text());identity={k:v for k,v in native[0].items()if k.startswith(('source_','checks_'))};review=source_identity();payload={}
assert len(native)==2 and len(full)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in native+full)
def add(name,p):assert name not in payload;payload[name]=p.read_bytes()
def snapshots(family,commit,label):
 text=tree_listing(family,commit);payload[label+'.manifest']=text.encode()
 for line in text.splitlines():
  _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload[label+'-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for family,label in [(FAMILY,'runtime'),(CHECKS,'checks')]:snapshots(family,identity['source_commit'],label)
snapshots(CHECKS,review['source_commit'],'review-checks')
for label,base in [('reviewed',s/'active-list-reviewed-production'),('mutations/reverse',s/'retirement-mutant-production')]:
 for p in sorted(base.rglob('*')):
  if p.is_file()and'binaries'not in p.relative_to(base).parts:add(label+'/'+str(p.relative_to(base)),p)
for kind in ['native','full']:
 add(kind+'-status.json',s/f'active-list-verified-{kind}-status.json');add(kind+'-collector.py',s/f'active-list-verified-{kind}-checks.py')
for row in full:add('full/'+row['name']+'.log',Path(row['log']))
for cc in ['clang','gcc']:
 add('native-'+cc+'.log',s/f'active-list-verified-{cc}.log');base=s/f'active-list-verified-{cc}'
 for p in sorted(base.rglob('*')):
  if p.is_file()and'.lake'not in p.relative_to(base).parts:add('probes/'+cc+'/'+str(p.relative_to(base)),p)
for base,label in [(s/'active-list-random','random'),(s/'retirement-mutant-check','mutations/reverse-check'),(s/'retirement-mutant-directed','mutations/reverse-directed'),(s/'retirement-always-check','mutations/always-check')]:
 for p in sorted(base.rglob('*')):
  if p.is_file():add(label+'/'+str(p.relative_to(base)),p)
for name,path in [('review-f4.log',s/'active-list-final-f4-check.log'),('corpus-status.json',s/'active-list-corpus/status.json'),('oracles.log',s/'active-list-oracles.log'),('emission.jsonl',s/'active-list-f4.jsonl'),('random-collector.py',s/'check-active-list-random.py'),('corpus-collector.py',s/'check-active-list-corpus.py'),('msolve-engine.json',s/'native-cc-review-audit/msolve-engine.json'),('msolve-upstream.txt',s/'active-list-msolve-upstream.txt'),('mutations/reverse-guard-build.log',s/'retirement-mutant-guard-build.log'),('mutations/reverse-guard-source.lean',s/'retirement-mutant-guard-source.lean'),('mutations/reverse-Pairs.lean',s/'retirement-mutant-reverse-Pairs.lean'),('mutations/always-build.log',s/'retirement-mutant-always-build.log'),('mutations/always-collector.py',s/'check-retirement-always.py'),('mutations/reverse-collector.py',s/'check-retirement-mutant.py'),('mutations/minimize.py',s/'minimize-retirement-mutant.py'),('pack.py',Path(__file__))]:add(name,path)
mutant=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-retirement-mutant');add('mutations/always-Pairs.lean',mutant/'HexGroebner/Pairs.lean')
final=json.loads((s/'active-list-final-full-status.json').read_text());assert len(final)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in review.items())for r in final)
add('review-full-status.json',s/'active-list-final-full-status.json');add('review-full-collector.py',s/'active-list-final-full-checks.py')
for row in final:add('review-full/'+row['name']+'.log',Path(row['log']))
for name,d in [('identity',identity),('review-identity',review)]:payload[name+'.json']=(json.dumps(d,indent=2)+'\n').encode()
payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode();out=s/('f4-active-list-checks-'+review['checks_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-active-list-checks/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
