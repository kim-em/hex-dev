from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');base=state/'dense-active-production';sys.path.insert(0,str(root));payload={}
from scripts.bench.groebner_checks import CHECKS
from scripts.bench.sweep_freshness import tree_listing
manifest=json.loads((base/'manifest.json').read_text());records=json.loads((state/'dense-active-native-status.json').read_text());assert len(records)==2 and all(r['exit_code']==0 and r['source_fingerprint']==manifest['source_fingerprint']for r in records)
def add(name,path):assert name not in payload;payload[name]=path.read_bytes()
for path in sorted(base.rglob('*')):
 if path.is_file()and'binaries'not in path.relative_to(base).parts:add('dense-active/'+str(path.relative_to(base)),path)
add('native-status.json',state/'dense-active-native-status.json');add('native-checks.py',state/'dense-active-native-checks.py')
checks=tree_listing(CHECKS,records[0]['source_commit']);payload['checks.manifest']=checks.encode()
for line in checks.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for compiler in ['clang','gcc']:
 add(compiler+'.log',state/('dense-active-'+compiler+'.log'))
 for path in sorted((state/('dense-active-'+compiler)).glob('*')):
  if path.is_file():add('probes/'+compiler+'/'+path.name,path)
add('pack.py',Path(__file__))
digests={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())};payload['sha256.json']=(json.dumps(digests,indent=2)+'\n').encode()
out=state/('f4-dense-active-'+manifest['source_fingerprint']+'.tar.xz')
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-dense-active/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(digests),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
