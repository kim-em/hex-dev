from pathlib import Path
import os,subprocess,json
state=Path('/home/kim/tmp/issue-10987');base=state/'binary-pivots-production';old=state/'monomial-batches-review-production'
command=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'final-products-production/medium-inputs/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/compute'),'--baseline',str(old/'binaries/compute'),'--baseline-manifest',str(old/'manifest.json'),'--output',str(base/'prime-control')]
assert json.loads((state/'monomial-batches-review-production/manifest.json').read_text())['source_fingerprint']=='ddde8c89c095'
assert command[command.index('--baseline')+1]==str(state/'monomial-batches-review-production/binaries/compute')
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
result=subprocess.run(command,env=env);(base/'measure-prime.py').write_bytes(Path(__file__).read_bytes());raise SystemExit(result.returncode)
