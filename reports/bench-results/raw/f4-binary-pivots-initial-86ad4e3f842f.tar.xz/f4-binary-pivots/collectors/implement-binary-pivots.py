from pathlib import Path
p=Path('HexGroebner/ffi/matrix_eliminate.c');s=p.read_text()
s=s.replace('#define MATRIX_QUANTUM UINT64_C(1048576)','#define MATRIX_QUANTUM UINT64_C(1048576)\n#define BINARY_LOGICAL_QUANTUM (UINT64_C(1)<<32)\n#define BINARY_WORD_QUANTUM (UINT64_C(1)<<28)\n#ifndef HEX_GROEBNER_BINARY_SCAN_USED\n#define HEX_GROEBNER_BINARY_SCAN_USED() ((void)0)\n#endif\n#ifndef HEX_GROEBNER_BINARY_PIVOTS_USED\n#define HEX_GROEBNER_BINARY_PIVOTS_USED(bytes) ((void)(bytes))\n#endif')
s=s.replace('uint64_t limits[7],stats[8],p,columns;','uint64_t limits[7],stats[8],p,columns,quantum,scratch,words,capacity;').replace('    uint8_t cache;','    uint8_t cache,binary;').replace('lean_object *dense,*slots,*pivots,*native_pivots,*remainders;','lean_object *dense,*slots,*pivots,*native_pivots,*remainders,*binary_rows;')
s=s.replace('c->limits[5]<MATRIX_QUANTUM?c->limits[5]:MATRIX_QUANTUM','c->limits[5]<c->quantum?c->limits[5]:c->quantum')
s=s.replace('return matrix_charge(&c->stats[3],n,c->limits[4]);','return matrix_charge(&c->stats[3],n,c->limits[4]-c->scratch);')
s=s.replace('    if(c->dense) lean_dec(c->dense);','    if(c->binary_rows) lean_dec(c->binary_rows);\n    if(c->dense) lean_dec(c->dense);',1)
needle='    lean_object *native=lean_alloc_ctor(0,3,0);'
s=s.replace(needle,'''    if(c->binary) {
        if(id>=c->capacity) {lean_dec(row);return 0;}
        uint8_t *packed=lean_sarray_cptr(c->binary_rows)+(size_t)id*c->words*8;
        lean_object *ids=lean_ctor_get(row,0);
        for(size_t i=0;i<lean_sarray_size(ids)/4;++i) {
            uint64_t col=matrix_read(lean_sarray_cptr(ids)+4*i,4);
            packed[col>>3]|=(uint8_t)(1u<<(col&7));
        }
    }
'''+needle,1)
old=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-binary-bitframe-wide/HexGroebner/ffi/matrix_eliminate.c').read_text()
a=old.index('/* Characteristic-two frames');b=old.index('/* The accumulator moves',a);block=old[a:b]
block=block.replace('/* Characteristic-two frames use bits inside the already charged, owned\n   columns-byte accumulator. All source rows were validated before allocation;\n   installed rows have coefficients one. This representation never leaves the\n   private frame. Slots, sparse outputs, sugar and logical charges are unchanged.\n   No additional packed buffer is allocated. A decline discards the frame. */','''/* F2 rows and the accumulator live in a private bit matrix. The complete
   scratch payload is admitted against the parent's packed-byte peak. No bit
   buffer escapes the frame; logical charges retain the sparse reference model.
   memcpy word loads/stores avoid alignment and effective-type assumptions. */
static uint8_t *matrix_binary_dense(matrix_context *c) {
    return lean_sarray_cptr(c->binary_rows)+(size_t)c->capacity*c->words*8;
}
static void matrix_binary_xor(uint8_t *restrict data,const uint8_t *restrict row,
        uint64_t first,uint64_t last) {
    for(uint64_t i=first;i<=last;++i) {
        uint64_t a,b;
        memcpy(&a,data+(size_t)i*8,8);memcpy(&b,row+(size_t)i*8,8);
        a^=b;memcpy(data+(size_t)i*8,&a,8);
    }
}''')
block=block.replace('uint8_t *data=lean_sarray_cptr(c->dense);','uint8_t *data=matrix_binary_dense(c);')
a=block.index('        /* Group sorted source columns');b=block.index('++c->stats[6];',a)
block=block[:a]+'''        const uint8_t *packed=lean_sarray_cptr(c->binary_rows)+(size_t)(slot-1)*c->words*8;
        matrix_binary_xor(data,packed,col>>6,end>>6);
        '''+block[b:]
block=block.replace('memset(data,0,(size_t)((c->columns+7)/8));','memset(data,0,(size_t)c->words*8);')
needle='/* The accumulator moves';s=s.replace(needle,block+needle,1)
s=s.replace('    lean_object *state=lean_alloc_ctor(0,8,8);','    if(c->binary) return matrix_scan_binary(c,first,last,leading,sugar);\n    lean_object *state=lean_alloc_ctor(0,8,8);',1)
s=s.replace('    if(!matrix_work(c,last+1-column)) return NULL;','    if(c->binary) return matrix_gather_binary(c,column,last);\n    if(!matrix_work(c,last+1-column)) return NULL;',1)
s=s.replace('    c.p=p;c.width=p<=256?1:p<=65536?2:4;c.columns=lean_unbox(column_arg);','''    c.p=p;c.width=p<=256?1:p<=65536?2:4;c.columns=lean_unbox(column_arg);
    c.binary=p==2 && lean_ctor_get_uint8(limits,7*sizeof(void*)+1);
    c.quantum=c.binary?BINARY_LOGICAL_QUANTUM:MATRIX_QUANTUM;''',1)
s=s.replace('    if(c.columns>4096 || nr>1024 || nt>64) goto defer;','    if(c.columns>(c.binary?16384:4096) || nr>(c.binary?8192:1024) || nt>(c.binary?1024:64)) goto defer;',1)
s=s.replace('    if(c.columns>c.limits[0] || rows>c.limits[1]) goto defer;','''    if(c.columns>c.limits[0] || rows>c.limits[1]) goto defer;
    c.words=(c.columns+63)/64;c.capacity=rows;
    if(c.binary) c.scratch=(rows+1)*c.words*8;
    if(c.scratch>c.limits[4]) goto defer;''',1)
s=s.replace('n>MATRIX_QUANTUM/2 || entries>MATRIX_QUANTUM/2-n','n>c.quantum/2 || entries>c.quantum/2-n',1)
s=s.replace('    if(bound>MATRIX_QUANTUM) goto defer;\n    uint8_t seen[512]={0};','''    if(bound>c.quantum) goto defer;
    if(c.binary) {
        uint64_t physical=rows*c.words+3*entries+3*nt*c.columns+workspace+
            nt*(rows*c.words+64)+c.columns;
        if(physical>BINARY_WORD_QUANTUM) goto defer;
    }
    uint8_t seen[2048]={0};''',1)
s=s.replace('    c.dense=matrix_zeros((size_t)c.columns*c.width);','''    if(c.binary) {
        c.binary_rows=matrix_zeros((size_t)c.scratch);
        HEX_GROEBNER_BINARY_PIVOTS_USED(c.scratch);
    }
    c.dense=matrix_zeros(c.binary?0:(size_t)c.columns*c.width);''',1)
needle='''                matrix_write(lean_sarray_cptr(c.dense)+(size_t)col*c.width,c.width,
                    matrix_read(lean_sarray_cptr(vs)+j*c.width,c.width));'''
assert s.count(needle)==1
s=s.replace(needle,'''                if(c.binary) matrix_binary_dense(&c)[col>>3]|=(uint8_t)(1u<<(col&7));
                else matrix_write(lean_sarray_cptr(c.dense)+(size_t)col*c.width,c.width,
                    matrix_read(lean_sarray_cptr(vs)+j*c.width,c.width));''',1)
s=s.replace('if(!independent && !matrix_inverse(&c,','if(!independent && !c.binary && !matrix_inverse(&c,',1)
p.write_text(s)
