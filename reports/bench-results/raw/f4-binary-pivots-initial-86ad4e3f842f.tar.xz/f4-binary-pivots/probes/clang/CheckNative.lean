import HexGroebner.NativeChecks
import HexGroebner.SampledConformance
import HexGroebner.DenseConformance
import HexGroebner.DenseMatrixConformance
@[extern "hex_test_dense_counts"] opaque denseCounts : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_subtract_count"] opaque subtractCount : IO UInt64
@[extern "hex_test_copy_bytes"] opaque copyBytes (input : @& ByteArray) : IO ByteArray
@[extern "hex_test_reset_pivot_owners"] opaque resetPivotOwners : IO Unit
@[extern "hex_test_pivot_owners"] opaque pivotOwners : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_batch_deferrals"] opaque batchDeferrals : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_batch_counts"] opaque batchCounts : IO (UInt64 × UInt64)
@[extern "hex_test_batch_insertions"] opaque batchInsertions : IO UInt64
@[extern "hex_test_binary_counts"] opaque binaryCounts : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_matrix_primitives"] opaque matrixPrimitives : IO (UInt64 × UInt64)
@[extern "hex_test_primitive_admissions"] opaque primitiveAdmissions : IO ((UInt64 × UInt64) × (UInt64 × UInt64))
@[extern "hex_test_remap_count"] opaque remapCount : IO UInt64
@[extern "hex_test_continuation_count"] opaque continuationCount : IO UInt64
@[extern "hex_test_continuation_successes"] opaque continuationSuccesses : IO UInt64
@[extern "hex_test_continuation_arithmetic"] opaque continuationArithmetic : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_continuation_reset_bounds"] opaque resetContinuationBounds : IO Unit
@[extern "hex_test_continuation_validations"] opaque continuationValidations : IO UInt64
@[extern "hex_test_continuation_workspaces"] opaque continuationWorkspaces : IO UInt64
@[extern "hex_test_continuation_outcomes"] opaque continuationOutcomes : IO Bool
@[extern "hex_test_continuation_phases"] opaque continuationPhases : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_continuation_bounds"] opaque continuationBounds : IO (UInt64 × UInt64 × UInt64)
@[extern "hex_test_index_count"] opaque indexCount : IO UInt64
@[extern "hex_test_zero_append_count"] opaque zeroAppendCount : IO UInt64
@[extern "hex_test_remap_aliases"] opaque remapAliases : IO Bool
@[extern "hex_test_index_aliases"] opaque indexAliases : IO Bool
@[extern "hex_test_comparison_count"] opaque comparisonCount : IO UInt64
@[extern "hex_test_comparison_declines"] opaque comparisonDeclines : IO UInt64
@[extern "hex_test_trie_counts"] opaque trieCounts : IO (UInt64 × UInt64)
@[extern "hex_test_counts"] opaque counts : IO (UInt64 × UInt64)
@[extern "hex_test_whole_modes"] opaque wholeModes : IO (UInt64 × UInt64)
@[extern "hex_test_whole_counts"] opaque wholeCounts : IO (UInt64 × UInt64)
@[extern "hex_test_byte_count"] opaque byteCount : IO UInt64
@[extern "hex_test_search_count"] opaque searchCount : IO UInt64
@[extern "hex_test_accept_count"] opaque acceptedCount : IO UInt64
@[extern "hex_test_insert_count"] opaque insertCount : IO UInt64
@[extern "hex_test_unique_count"] opaque uniqueCount : IO UInt64
@[extern "hex_test_product_exclusive"] opaque productExclusive : IO Bool
@[extern "hex_test_product_aliases"] opaque productAliases : IO Bool
@[extern "hex_test_owned_runtime"] opaque ownedRuntime : IO Bool
@[extern "hex_test_deferred_count"] opaque deferredCount : IO UInt64
@[extern "hex_test_alias_mask"] opaque aliasMask : IO UInt64
@[extern "hex_test_alias_count"] opaque aliasCount : IO UInt64
@[extern "hex_test_product_count"] opaque productCount : IO UInt64
@[extern "hex_test_vector_counts"] opaque vectorCounts : IO (UInt64 × UInt64)
@[extern "hex_test_avx2"] opaque avx2 : IO Bool
@[extern "hex_test_widths"] opaque widths : IO UInt32
@[extern "hex_test_zero_count"] opaque zeroCount : IO UInt64
@[extern "hex_test_mersenne_count"] opaque mersenneCount : IO UInt64
@[extern "hex_test_avx512_count"] opaque avx512Count : IO UInt64
@[extern "hex_test_avx512_widths"] opaque avx512Widths : IO UInt32
@[extern "hex_test_avx512_available"] opaque avx512Available : IO Bool
def checkDenseOwnership (primitiveSeed : Nat) : IO Unit := do
  for independent in [false,true] do
    let checkpoint := Hex.Groebner.DenseMatrixConformance.snapshotState primitiveSeed independent
    let some cache := checkpoint.densePivots | throw (IO.userError "missing dense checkpoint")
    let some held := cache.rows[0]? | throw (IO.userError "empty dense checkpoint")
    let heldBytes ← copyBytes held.dense
    let heldSource ← copyBytes held.source.coefficients
    let scheduleSeed ← Hex.Groebner.NativeChecks.readSeed
    let completed := Hex.Groebner.MatrixState.finishState (1+scheduleSeed%64) checkpoint
    let alternate := Hex.Groebner.MatrixState.finishState (64-scheduleSeed%64) checkpoint
    if completed.phase != .done || alternate.phase != .done ||
        checkpoint.nativePivots.size != 1 || cache.rows.size != 1 ||
        completed.nativePivots.size != (if independent then 3 else 6) ||
        alternate.stats != completed.stats then
      throw (IO.userError "shared dense checkpoint did not complete")
    let afterBytes ← copyBytes held.dense
    let afterSource ← copyBytes held.source.coefficients
    if heldBytes != afterBytes || heldSource != afterSource then
      throw (IO.userError "shared nonempty dense cache was mutated")
  IO.println "shared dense checkpoints: 4 IO byte comparisons"
  let beforeTiny ← wholeCounts
  let tinyRow : Hex.Groebner.SparseRow :=
    ⟨Hex.Groebner.Packed.push .u32 {} 0,Hex.Groebner.Packed.push .u32 {} 1⟩
  let tinyField : Hex.Groebner.PrimeField :=
    ⟨2147483647,Hex.Nat.isPrimeTrial_isPrime (by decide),by decide⟩
  let tiny := Hex.Groebner.eliminateWith tinyField { densePivots := true }
    (2+primitiveSeed%127) #[tinyRow] #[tinyRow]
  if !tiny.result.isOk then throw (IO.userError "small cached-option matrix failed")
  let afterTiny ← wholeCounts
  if afterTiny.1 != beforeTiny.1+1 || afterTiny.2 != beforeTiny.2 then
    throw (IO.userError "small cached-option matrix lost its bulk frame")
  IO.println "small M31 cached-option bulk frame: accepted"
  let beforeDispatch ← wholeCounts
  if !Hex.Groebner.DenseMatrixConformance.dispatchChecks primitiveSeed false then
    throw (IO.userError "public dense-option dispatch counters differ")
  let afterDispatch ← wholeCounts
  if afterDispatch.1 != beforeDispatch.1+12 || afterDispatch.2 != beforeDispatch.2 then
    throw (IO.userError "dense-option public dispatch lost bulk frames")
  if !Hex.Groebner.DenseMatrixConformance.dispatchChecks primitiveSeed true then
    throw (IO.userError "dense-option public dispatch boundary counters differ")
  if !Hex.Groebner.DenseMatrixConformance.capChecks primitiveSeed then
    throw (IO.userError "dense-option bulk work cap differs from reference")
  IO.println "public M31 cached-option bulk frames: 12 accepted; exact boundary counters and work cap passed"

def checkMersenne : IO UInt64 := do
  let before512 ← avx512Count
  let beforeMersenne ← mersenneCount
  Hex.Groebner.NativeChecks.runMersenneF4
  let mersenne ← mersenneCount
  let after512 ← avx512Count
  let paths512 ← avx512Widths
  let available512 ← avx512Available
  IO.println s!"AVX-512 packets: {after512}; full F4={after512-before512}; available={available512}; width/layout bits={paths512}"
  if available512 && paths512 != 63 then
    throw (IO.userError "an AVX-512 width/layout path was not exercised")
  if available512 && after512 ≤ before512 then
    throw (IO.userError "full F4 did not exercise AVX-512 packets")
  if true && (← IO.getEnv "HEX_GROEBNER_REQUIRE_AVX512") == some "1" && !available512 then
    throw (IO.userError "AVX-512 coverage required but unavailable")
  if true && (← avx2) && mersenne ≤ beforeMersenne then
    throw (IO.userError "complete F4 did not exercise Mersenne vectors")
  return mersenne

private def checkBinary (seed : Nat) : IO Unit := do
  let before ← binaryCounts
  if !Hex.Groebner.EliminationConformance.binaryChecks seed ||
      !Hex.Groebner.EliminationConformance.binaryWorkChecks seed then
    throw (IO.userError "private packed F2 frame/reference mismatch")
  let after ← binaryCounts
  if after.1 ≤ before.1 || after.2.1 ≤ before.2.1 || after.2.2 ≤ before.2.2 then
    throw (IO.userError "private F2 pivots or word scan unused")
  IO.println s!"private F2 frames/scans/bytes: {after}"

private def checkOwnership : IO Unit := do
  if !(← indexAliases) then throw (IO.userError "exclusive index/zero ownership mismatch")
  if !(← remapAliases) then throw (IO.userError "exclusive borrowed column-map alias mismatch")
  if !(← productExclusive) then throw (IO.userError "exclusive multi-slot insertion/lookup mismatch")
  if !(← productAliases) then throw (IO.userError "exclusive product insertion/alias mismatch")
  if !(← ownedRuntime) then throw (IO.userError "native layout or linear resize mismatch")

def main : IO Unit := do
  checkOwnership
  IO.println "native constructor layout and marked-linear growth passed"
  let beforeOwned ← uniqueCount
  let beforeAlias ← aliasCount
  Hex.Groebner.NativeChecks.runOwned
  let afterOwned ← uniqueCount
  let afterAlias ← aliasCount
  if afterOwned ≤ beforeOwned || afterAlias ≤ beforeAlias || (← aliasMask) != 15 then
    throw (IO.userError "exclusive alias insertion was not exercised")
  IO.println s!"exclusive owned comparisons: reuses={afterOwned-beforeOwned}, aliased insertions={afterAlias-beforeAlias}"
  let primitiveSeed ← Hex.Groebner.NativeChecks.readSeed
  IO.println s!"primitive conformance seed: {primitiveSeed}"
  checkBinary primitiveSeed
  let beforeBatchInsertions ← batchInsertions
  if !Hex.Groebner.ProductBatchConformance.insertionChecks primitiveSeed then
    throw (IO.userError "monomial batch insertion/reference state mismatch")
  let afterBatchInsertions ← batchInsertions
  if afterBatchInsertions ≤ beforeBatchInsertions then
    throw (IO.userError "native monomial batch insertion unused")
  IO.println s!"native monomial batch insertions: {afterBatchInsertions-beforeBatchInsertions}; alias/refusal states passed"
  if !Hex.Groebner.DenseMatrixConformance.frameChecks primitiveSeed then
    throw (IO.userError "dense normalized/target frame boundaries differ")
  IO.println "dense normalized/target frames: exact parent refusal and density boundaries passed"
  let beforeDense ← denseCounts
  if !Hex.Groebner.DenseConformance.packetChecks primitiveSeed ||
      !Hex.Groebner.DenseMatrixConformance.admissionChecks primitiveSeed ||
      !Hex.Groebner.DenseMatrixConformance.mixedChecks primitiveSeed ||
      !Hex.Groebner.DenseMatrixConformance.checks primitiveSeed ||
      !Hex.Groebner.DenseConformance.largeChecks primitiveSeed ||
      !Hex.Groebner.DenseConformance.boundaryChecks primitiveSeed ||
      !Hex.Groebner.DenseConformance.scanChecks primitiveSeed then
    throw (IO.userError "dense pivot scan prefix mismatch")
  let mut denseColumns : ByteArray := {}
  let mut denseValues : ByteArray := {}
  for i in [:128] do
    denseColumns := Hex.Groebner.Packed.push .u32 denseColumns i.toUInt64
    denseValues := Hex.Groebner.Packed.push .u32 denseValues (i+1).toUInt64
  let denseSource : Hex.Groebner.Native.Scan.Pivot := ⟨denseColumns,denseValues,primitiveSeed⟩
  let prepared := Hex.Groebner.Native.Dense.prepare 2147483647 128 denseSource 100000 100000
  let sourceSnapshot ← copyBytes prepared.row.source.coefficients
  let cacheSnapshot ← copyBytes prepared.row.dense
  let denseInitial : Hex.Groebner.Native.Scan.State := {
    dense := prepared.row.dense
    column := 0
    last := 127
    chargedUntil := 128
    pending := 1
    factor := 1 }
  let denseSlots := Hex.Groebner.Native.write (Hex.Groebner.Native.Dense.zeros 512) 4 0 1
  let denseOutput := Hex.Groebner.Native.Dense.transition 2147483647 128 denseSlots
    #[prepared.row] denseInitial 128 100000 0 false
  if denseOutput.state.dense != Hex.Groebner.Native.Dense.zeros 512 ||
      prepared.row.source.coefficients != sourceSnapshot || prepared.row.dense != cacheSnapshot ||
      denseInitial.dense != cacheSnapshot then
    throw (IO.userError "dense pivot source/cache/continuation snapshot was mutated")
  checkDenseOwnership primitiveSeed
  let afterDense ← denseCounts
  if afterDense.1 ≤ beforeDense.1 || afterDense.2.1 ≤ beforeDense.2.1 ||
      afterDense.2.2 ≤ beforeDense.2.2 then
    throw (IO.userError "dense pivot native materialization/update was not exercised")
  IO.println s!"dense pivot calls: {afterDense}"
  let beforeDenseF4 ← denseCounts
  let beforeDenseF4Frames ← wholeCounts
  if !Hex.Groebner.DenseMatrixConformance.fullChecks primitiveSeed then
    throw (IO.userError "complete dense/sparse F4 basis differs")
  let afterDenseF4 ← denseCounts
  let afterDenseF4Frames ← wholeCounts
  if afterDenseF4Frames.2 ≤ beforeDenseF4Frames.2 then
    throw (IO.userError "complete F4 fixture did not reach the continuation")
  IO.println s!"dense full-F4 bulk declines: {afterDenseF4Frames.2-beforeDenseF4Frames.2}"
  if afterDenseF4.2.2 ≤ beforeDenseF4.2.2 then
    throw (IO.userError "complete F4 did not exercise dense pivot updates")
  IO.println s!"dense full-F4 updates: {afterDenseF4.2.2-beforeDenseF4.2.2}"


  let beforePortableScan ← counts
  let beforePortableWhole ← wholeCounts
  let beforePortableBytes ← byteCount
  let beforePortableRemap ← remapCount
  let beforePortableIndex ← indexCount
  let beforePortableZeros ← zeroAppendCount
  let beforePortableContinuation ← continuationCount
  let beforePortableBatchDeferrals ← batchDeferrals
  let beforePortableBatches ← batchCounts
  let beforePortableProducts ← productCount
  let beforePortable ← matrixPrimitives
  for offset in [:6] do
    let seed := primitiveSeed+offset
    if !Hex.Groebner.MatrixPrimitiveConformance.portable seed then
      throw (IO.userError s!"portable matrix route failed, seed={seed}")
    Hex.Groebner.NativeChecks.runPortableF4 seed
  if (← matrixPrimitives) != beforePortable || (← counts) != beforePortableScan ||
      (← wholeCounts) != beforePortableWhole || (← byteCount) != beforePortableBytes ||
      (← remapCount) != beforePortableRemap || (← indexCount) != beforePortableIndex ||
      (← zeroAppendCount) != beforePortableZeros ||
      (← continuationCount) != beforePortableContinuation ||
      (← productCount) != beforePortableProducts || (← batchCounts) != beforePortableBatches ||
      (← batchDeferrals) != beforePortableBatchDeferrals then
    throw (IO.userError "public portable F4 called a native row/bulk/column/byte provider")
  let beforeIntegrated ← primitiveAdmissions
  for offset in [:6] do
    if !Hex.Groebner.MatrixPrimitiveConformance.integrated (primitiveSeed+offset) then
      throw (IO.userError s!"traced native matrix integration failed, seed={primitiveSeed+offset}")
  let afterIntegrated ← primitiveAdmissions
  if afterIntegrated.1.1 ≤ beforeIntegrated.1.1 || afterIntegrated.2.1 ≤ beforeIntegrated.2.1 then
    throw (IO.userError "traced elimination did not admit both native primitives")
  IO.println s!"traced elimination primitive admissions: validation={afterIntegrated.1.1-beforeIntegrated.1.1}, zero={afterIntegrated.2.1-beforeIntegrated.2.1}"
  let beforeWide ← batchCounts
  let beforeWideDeferrals ← batchDeferrals
  Hex.Groebner.NativeChecks.runProductWide
  let afterWide ← batchCounts
  let wideBatches := afterWide.1-beforeWide.1
  if wideBatches == 0 || wideBatches ≥ 128 || afterWide.2-beforeWide.2 != 128 ||
      (← batchDeferrals) != beforeWideDeferrals then
    throw (IO.userError "adaptive 22-variable multiplication did not batch every term")
  IO.println s!"adaptive 22-variable accepted batches/terms: {wideBatches}/128; deferrals=0"
  let beforeMiss ← batchDeferrals
  Hex.Groebner.NativeChecks.runProductMiss
  let afterMiss ← batchDeferrals
  if afterMiss.1 ≤ beforeMiss.1 || afterMiss.2.1 ≤ beforeMiss.2.1 then
    throw (IO.userError "last-term miss did not exercise discarded-visit diagnostic")
  IO.println s!"last-term-miss deferred calls/reservations: {afterMiss.1-beforeMiss.1}/{afterMiss.2.1-beforeMiss.2.1}"
  let beforeWideZeros ← primitiveAdmissions
  Hex.Groebner.NativeChecks.runWideWorkspaces
  let afterWideZeros ← primitiveAdmissions
  if afterWideZeros.2.1-beforeWideZeros.2.1 != 6 ||
      afterWideZeros.2.2-beforeWideZeros.2.2 != 6 then
    throw (IO.userError s!"wide workspace zero-provider admission mismatch: before={beforeWideZeros.2}, after={afterWideZeros.2}")
  IO.println "wide workspace zeros: all widths, six admitted and six declined"
  Hex.Groebner.NativeChecks.run
  let batches ← batchCounts
  if batches.1 == 0 || batches.2 == 0 then throw (IO.userError "monomial product batch unused")
  IO.println s!"monomial product batches/terms: {batches}"
  let primitives ← matrixPrimitives
  IO.println s!"native matrix validation/zero-buffer primitives: {primitives}"
  let continuationCalls ← continuationCount
  if continuationCalls == 0 then throw (IO.userError "native continuation unused")
  if !(← continuationOutcomes) then
    throw (IO.userError "native validation/workspace outcomes missing at some coefficient width")
  IO.println "native validation/workspace outcomes: all widths, errors, exhaustion, admission edges and allocation"
  let workspaces ← continuationWorkspaces
  if workspaces == 0 then throw (IO.userError "native continuation workspace unused")
  IO.println s!"native continuation workspaces: {workspaces}"
  let validations ← continuationValidations
  if validations == 0 then throw (IO.userError "native continuation validation unused")
  IO.println s!"native continuation validations: {validations}"
  let phases ← continuationPhases
  if phases.1 == 0 || phases.2.1 == 0 || phases.2.2 == 0 then
    throw (IO.userError "native continuation fast phases unused")
  IO.println s!"native continuation calls: {continuationCalls}; fast input/scan/gather: {phases}"
  let bounds ← continuationBounds
  if bounds.1 == 0 || bounds.2.1 == 0 || bounds.2.1 > 1048576 || bounds.2.2 != 0 then
    throw (IO.userError "native continuation phase bound violated")
  IO.println s!"native continuation loop count/declared product/schedule errors: {bounds}"
  let modes ← wholeModes
  if modes.1 == 0 || modes.2 == 0 then throw (IO.userError "native joint/independent matrices not covered")
  IO.println s!"whole matrix joint/independent accepted: {modes}"
  let indexBefore ← indexCount
  let zeroAppendBefore ← zeroAppendCount
  if indexBefore == 0 || zeroAppendBefore == 0 then throw (IO.userError "packed index/zero native checks unused")
  let remapBefore ← remapCount
  if remapBefore == 0 then throw (IO.userError "native column remapping not exercised")
  let wholeBefore ← wholeCounts
  let primitiveCompared ← byteCount
  let primitiveProducts ← productCount
  let beforeZero ← zeroCount
  let comparedBefore ← comparisonCount
  let declinedBefore ← comparisonDeclines
  let trieBefore ← trieCounts
  let primitiveUnique ← uniqueCount
  let primitiveInserts ← insertCount
  let primitiveAccepted ← acceptedCount
  let primitiveDeferred ← deferredCount
  let beforeF4Deferrals ← batchDeferrals
  let beforeF4Batches ← batchCounts
  let beforeF4Primitives ← primitiveAdmissions
  resetContinuationBounds
  let beforeF4Continuation ← continuationCount
  let beforeF4Validations ← continuationValidations
  let beforeF4Workspaces ← continuationWorkspaces
  let beforeF4Phases ← continuationPhases
  Hex.Groebner.NativeChecks.runF4
  let beforeOversizedSuccess ← continuationSuccesses
  let beforeOversizedArithmetic ← continuationArithmetic
  let beforeOversizedWhole ← wholeCounts
  Hex.Groebner.NativeChecks.runOversizedF4
  let afterOversizedSuccess ← continuationSuccesses
  let afterOversizedArithmetic ← continuationArithmetic
  let afterOversizedWhole ← wholeCounts
  if afterOversizedSuccess ≤ beforeOversizedSuccess || afterOversizedWhole.2 ≤ beforeOversizedWhole.2 then
    throw (IO.userError "successful oversized F4 did not complete a deferred native continuation")
  if afterOversizedArithmetic.1 ≤ beforeOversizedArithmetic.1 ||
      afterOversizedArithmetic.2.1 ≤ beforeOversizedArithmetic.2.1 ||
      afterOversizedArithmetic.2.2 ≤ beforeOversizedArithmetic.2.2 then
    throw (IO.userError "oversized F4 did not exercise successful reductions, zero rows and non-unit inverses")
  IO.println s!"oversized F4 reduced/zero successes/non-unit inverses: {afterOversizedArithmetic.1-beforeOversizedArithmetic.1}/{afterOversizedArithmetic.2.1-beforeOversizedArithmetic.2.1}/{afterOversizedArithmetic.2.2-beforeOversizedArithmetic.2.2}"
  IO.println s!"oversized F4 successful continuations/bulk deferrals: {afterOversizedSuccess-beforeOversizedSuccess}/{afterOversizedWhole.2-beforeOversizedWhole.2}"
  let afterF4Deferrals ← batchDeferrals
  if afterF4Deferrals.2.2 != 0 then throw (IO.userError "batch visit cap exceeded")
  IO.println s!"F4 deferred batches/discarded visit reservations: {afterF4Deferrals.1-beforeF4Deferrals.1}/{afterF4Deferrals.2.1-beforeF4Deferrals.2.1}"
  let afterF4Batches ← batchCounts
  if afterF4Batches.1 ≤ beforeF4Batches.1 || afterF4Batches.2 ≤ beforeF4Batches.2 then
    throw (IO.userError "F4 did not exercise accepted monomial batches")
  IO.println s!"F4 monomial batches/terms: {afterF4Batches.1-beforeF4Batches.1}/{afterF4Batches.2-beforeF4Batches.2}"
  let afterF4Primitives ← primitiveAdmissions
  -- All F4-window matrices fit the continuation scheduler's geometry. Larger
  -- production frames legitimately retain the reference's native primitives.
  if afterF4Primitives != beforeF4Primitives then
    throw (IO.userError "bounded-shape F4 window used deselected standalone matrix primitives")
  IO.println s!"F4 primitive validation admitted/declined: {afterF4Primitives.1.1-beforeF4Primitives.1.1}/{afterF4Primitives.1.2-beforeF4Primitives.1.2}; zero admitted/declined: {afterF4Primitives.2.1-beforeF4Primitives.2.1}/{afterF4Primitives.2.2-beforeF4Primitives.2.2}"
  let afterF4Continuation ← continuationCount
  let afterF4Validations ← continuationValidations
  let afterF4Workspaces ← continuationWorkspaces
  let afterF4Phases ← continuationPhases
  if afterF4Continuation ≤ beforeF4Continuation || afterF4Validations ≤ beforeF4Validations ||
      afterF4Workspaces ≤ beforeF4Workspaces then
    throw (IO.userError "F4 did not exercise native continuation validation and workspace setup")
  if afterF4Phases.1 ≤ beforeF4Phases.1 || afterF4Phases.2.1 ≤ beforeF4Phases.2.1 ||
      afterF4Phases.2.2 ≤ beforeF4Phases.2.2 then
    throw (IO.userError "F4 did not exercise native continuation input, scan and gather")
  -- These counters check the configured phase-loop cap, not measured machine
  -- instructions, allocation volume or elapsed time inside each phase.
  let f4Bounds ← continuationBounds
  if f4Bounds.1 == 0 || f4Bounds.2.1 == 0 || f4Bounds.2.1 > 1048576 || f4Bounds.2.2 != 0 then
    throw (IO.userError "F4 native continuation configured loop cap violated")
  IO.println s!"F4 continuation calls/validation/workspace: {afterF4Continuation-beforeF4Continuation}/{afterF4Validations-beforeF4Validations}/{afterF4Workspaces-beforeF4Workspaces}; input/scan/gather: {afterF4Phases.1-beforeF4Phases.1}/{afterF4Phases.2.1-beforeF4Phases.2.1}/{afterF4Phases.2.2-beforeF4Phases.2.2}"
  let wholeAfter ← wholeCounts
  if wholeAfter.1 ≤ wholeBefore.1 || wholeAfter.2 ≤ wholeBefore.2 then throw (IO.userError "F4 did not exercise accepted/deferred whole matrices")
  IO.println s!"whole matrix accepted/deferred: {wholeAfter}; F4 accepted/deferred: {wholeAfter.1-wholeBefore.1}/{wholeAfter.2-wholeBefore.2}"
  let f4Unique ← uniqueCount
  if f4Unique ≤ primitiveUnique then throw (IO.userError "F4 did not exercise exclusive table reuse")
  let f4Inserts ← insertCount
  if f4Inserts ≤ primitiveInserts then throw (IO.userError "F4 did not exercise native monomial insertion")
  let f4Accepted ← acceptedCount
  if f4Accepted-f4Inserts ≤ primitiveAccepted-primitiveInserts then
    throw (IO.userError "F4 did not exercise non-inserting monomial lookup")
  let f4Searches ← searchCount
  let f4Deferred ← deferredCount
  let trieAfter ← trieCounts
  if trieAfter.1 ≤ trieBefore.1 || trieAfter.2 != trieBefore.2 then
    throw (IO.userError "F4 did not obtain valid native trie answers")
  IO.println s!"trie calls/declines: {trieAfter}; F4 calls: {trieAfter.1-trieBefore.1}"
  let afterZero ← zeroCount
  let comparedAfter ← comparisonCount
  let declinedAfter ← comparisonDeclines
  let accepted := (comparedAfter-comparedBefore)-(declinedAfter-declinedBefore)
  if accepted == 0 || declinedAfter != declinedBefore then
    throw (IO.userError "F4 did not obtain bounded native comparison answers")
  IO.println s!"native monomial calls: {comparedAfter}, declines: {declinedAfter}; F4 accepted: {accepted}, F4 declines: {declinedAfter-declinedBefore}"
  IO.println s!"packed interning: searches={f4Searches}, accepted={f4Accepted}, lookups={f4Accepted-f4Inserts}, insertions={f4Inserts}, unique={f4Unique}, deferrals={f4Deferred}, F4 deferrals={f4Deferred-primitiveDeferred}"
  let f4Compared ← byteCount
  let f4Products ← productCount
  if f4Products ≤ primitiveProducts then throw (IO.userError "F4 did not exercise arena product validation")
  if f4Compared ≤ primitiveCompared then throw (IO.userError "F4 did not exercise cache comparison")
  Hex.Groebner.NativeChecks.runCache
  let cacheCompared ← byteCount
  let cacheProducts ← productCount
  if cacheProducts ≤ f4Products then throw (IO.userError "cache checks did not exercise arena product validation")
  if cacheCompared ≤ f4Compared then throw (IO.userError "cache checks did not exercise byte binding")
  let mersenne ← checkMersenne
  let indexAfter ← indexCount
  let zeroAppendAfter ← zeroAppendCount
  if indexAfter ≤ indexBefore || zeroAppendAfter ≤ zeroAppendBefore then
    throw (IO.userError "F4/cache checks did not exercise packed index/zero kernels")
  IO.println s!"native index remaps: total={indexAfter}, F4/cache={indexAfter-indexBefore}; zero appends={zeroAppendAfter}"
  let remapAfter ← remapCount
  if remapAfter ≤ remapBefore then throw (IO.userError "F4/cache checks did not exercise native column remapping")
  IO.println s!"native column remaps: total={remapAfter}, F4/cache={remapAfter-remapBefore}"
  let (scan,gather) ← counts
  let compared ← byteCount
  if scan == 0 || gather == 0 || compared == 0 then throw (IO.userError "test override was not called")
  let available ← avx2
  let (contiguous,gathered) ← vectorCounts
  let covered ← widths
  IO.println s!"native call counts: scan={scan}, gather={gather}; AVX2={available}, contiguous={contiguous}, strided={gathered}, width paths={covered}, byte comparisons={compared}, product validations={cacheProducts}, Mersenne vectors={mersenne}, zero blocks={afterZero}, F4 zero blocks={afterZero-beforeZero}"
  if true && available && afterZero ≤ beforeZero then
    throw (IO.userError "complete F4 did not exercise zero blocks")
  if true && available && (contiguous == 0 || gathered == 0 || covered != 255) then
    throw (IO.userError "an AVX2 path was not exercised")
  if true && (← IO.getEnv "HEX_GROEBNER_REQUIRE_AVX2") == some "1" && !available then
    throw (IO.userError "AVX2 coverage required but unavailable")
  resetPivotOwners
  let ownerSeed ← Hex.Groebner.NativeChecks.readSeed
  let ownerRows := 256+ownerSeed%2
  if !Hex.Groebner.SamplingChecks.grow ownerRows then
    throw (IO.userError "fresh sampling pivot growth failed")
  let (pushes,shared,entries) ← pivotOwners
  if pushes != ownerRows.toUInt64 || entries != 0 then
    throw (IO.userError s!"sampling copied shared pivot metadata: {pushes}/{shared}/{entries}")
  IO.println s!"sampling pivot pushes={pushes}, shared={shared}, existing shared entries={entries}"
  resetPivotOwners
  if !Hex.Groebner.SamplingChecks.growTargets ownerRows then
    throw (IO.userError "fresh sampled target pivot growth failed")
  let (pushes,shared,entries) ← pivotOwners
  if pushes != ownerRows.toUInt64 || entries != 0 then
    throw (IO.userError s!"sampling copied shared target pivot metadata: {pushes}/{shared}/{entries}")
  IO.println s!"sampling target pivot pushes={pushes}, shared={shared}, existing shared entries={entries}"
  resetPivotOwners
  let freshSeed ← Hex.Groebner.NativeChecks.readSeed
  let some digest := Hex.Groebner.SampledConformance.fresh freshSeed |
    throw (IO.userError "fresh sampled F4 failed")
  IO.println s!"fresh sampled F4 digest={digest}"
  let (pushes,shared,entries) ← pivotOwners
  if pushes == 0 || entries != 0 then
    throw (IO.userError s!"sampled F4 copied shared pivot metadata: {pushes}/{shared}/{entries}")
  IO.println s!"sampled F4 pivot pushes={pushes}, shared={shared}, existing shared entries={entries}"
  for kind in [:4] do
    let some (ready,held) := Hex.Groebner.SamplingChecks.snapshot kind |
      throw (IO.userError s!"missing sampling snapshot {kind}")
    let before ← copyBytes held
    -- Read after the first observation: the pure transition depends on this IO
    -- value and cannot move ahead of the first byte copy. Stay below its cap.
    let snapshotSeed ← Hex.Groebner.NativeChecks.readSeed
    let completed := Hex.Groebner.Sampling.advance
      { work := 10000000,packedBytes := 10000000 } (63-snapshotSeed%2) ready
    if completed.failure.isSome || completed.phase != .done then
      throw (IO.userError s!"sampling snapshot {kind} did not complete")
    let after ← copyBytes held
    if before.data != after.data then
      throw (IO.userError s!"sampling snapshot {kind} was mutated")
  IO.println "sampling snapshots: 4 IO byte comparisons"
  let beforeSubtract ← subtractCount
  let (beforeScan,beforeGather) ← counts
  Hex.Groebner.SampledConformance.run
  let afterSubtract ← subtractCount
  let (afterScan,afterGather) ← counts
  if afterSubtract ≤ beforeSubtract || afterScan ≤ beforeScan || afterGather ≤ beforeGather then
    throw (IO.userError "sampled F4 did not exercise instrumented combination/scan/gather")
  IO.println s!"sampled native calls: subtract={afterSubtract-beforeSubtract}, scan={afterScan-beforeScan}, gather={afterGather-beforeGather}"
