using Nemo, Groebner

function read_system(path)
    lines = readlines(path)
    names = [strip(s) for s in split(lines[1], ',') if !isempty(strip(s))]
    p = parse(UInt, strip(lines[2], [',',' ','\t']))
    names == ["x$(i)" for i in 0:length(names)-1] || error("variable metadata")
    R, xs = polynomial_ring(Nemo.Native.GF(p), names, internal_ordering=:degrevlex)
    polynomials = elem_type(R)[]
    for text in split(join(lines[3:end], ""), ',')
        text = replace(strip(text), " "=>"")
        isempty(text) && continue
        f = zero(R)
        for term in eachmatch(r"[+-]?[^+-]+", text)
            word = term.match
            c = startswith(word, "-") ? -one(base_ring(R)) : one(base_ring(R))
            word = lstrip(word, ['+','-'])
            monomial = one(R)
            for factor in split(word, '*')
                if all(isdigit, factor)
                    c *= parse(BigInt, factor)
                else
                    m = match(r"^x(\d+)(?:\^(\d+))?$", factor)
                    isnothing(m) && error("invalid factor")
                    variable = parse(Int, m[1])+1
                    1 <= variable <= length(xs) || error("invalid variable")
                    exponent = isnothing(m[2]) ? 1 : parse(Int,m[2])
                    monomial *= xs[variable]^exponent
                end
            end
            f += c*monomial
        end
        push!(polynomials, f)
    end
    R, polynomials
end

function write_basis(path, R, basis)
    open(path,"w") do io
        println(io, join(string.(symbols(R)),","))
        println(io,characteristic(base_ring(R)))
        for f in basis
            println(io,string(f),",")
        end
    end
end

function compute(path,output,mode)
    start=time_ns()
    R,F = read_system(path)
    G=groebner(F,ordering=DegRevLex(),reduced=true,linalg=Symbol(mode),tasks=1,seed=42)
    elapsed=time_ns()-start
    write_basis(output,R,G)
    println("candidate_nanos=",elapsed)
    println("basis_size=",length(G))
end

length(ARGS) in [3,4] || error("input, output, linear-algebra mode, optional warm flag required")
ARGS[3] in ["deterministic","randomized","las_vegas"] || error("unknown mode")
if length(ARGS)==4
    ARGS[4]=="warm" || error("unknown warmup mode")
    println("phase=first_call")
    compute(ARGS[1],ARGS[2]*".first",ARGS[3])
    println("phase=second_call")
end
compute(ARGS[1],ARGS[2],ARGS[3])
