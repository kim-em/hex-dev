from pathlib import Path
import os,subprocess,csv,json,hashlib
s=Path('/home/kim/tmp/issue-10987');root=s/'binary-review-fixed-verified-clang';out=s/'binary-pr30-forced-refusals';out.mkdir(exist_ok=False);binary=root/'.lake/build/bin/checkNative';records=out/'frames.csv'
loader='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2';lib='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib';asan='/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/resource-root/lib/linux/libclang_rt.asan-x86_64.so';cmd=[loader,'--library-path',lib,'--preload',asan,str(binary)]
with (out/'stdout').open('w')as stdout,(out/'stderr').open('w')as stderr:r=subprocess.run(cmd,stdout=stdout,stderr=stderr,env=dict(os.environ,HEX_GROEBNER_FRAME_LOG=str(records),ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1'))
assert r.returncode==0
fields=['columns','reducers','targets','entries','reason','byteUpper','byteAllowance'];frames=list(csv.DictReader(records.read_text().splitlines(),fieldnames=fields));counts={}
for row in frames:counts[row['reason']]=counts.get(row['reason'],0)+1
assert set(counts)=={'accepted','shape','logical','physical','other_without_byte_refusal','other_possible_byte_refusal'},counts
assert any(row['reason']=='other_possible_byte_refusal' and int(row['byteAllowance'])<(min(int(row['columns']),int(row['reducers'])+int(row['targets']))+1)*((int(row['columns'])+63)//64)*8 for row in frames)
(out/'status.json').write_text(json.dumps(dict(command=cmd,exit_code=r.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),fields=fields,counts=counts,frames=len(frames)),indent=2)+'\n');(out/'collector.py').write_bytes(Path(__file__).read_bytes());print(counts)
