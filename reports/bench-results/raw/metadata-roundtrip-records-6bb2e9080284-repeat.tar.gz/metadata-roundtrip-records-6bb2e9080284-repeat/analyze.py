import json,math,pathlib,statistics
base=pathlib.Path('/tmp/hex-groebner-metadata-dev');g=lambda a:math.exp(sum(map(math.log,a))/len(a))
def summary(v):return dict(geomean=g(v),median=statistics.median(v),minimum=min(v),maximum=max(v))
allc=[];allw=[];analyses={}
for suffix in ('','-repeat'):
 p=base/('metadata-roundtrip-records-6bb2e9080284'+suffix);d=json.loads((p/'metadata.json').read_text());r={};cr=[];wr=[]
 for c in json.loads((p/'diagnostic-suite.json').read_text())['cases']:
  r[c['name']]=[]
  for block in (0,1):
   v={x['arm']:x for x in d['samples'] if x['case']==c['name'] and x['block']==block};a,b=v['A'],v['B'];assert a['status']==b['status']=='ok';x=b['statistics']['candidate_nanos']/a['statistics']['candidate_nanos'];r[c['name']].append(x);cr.append(x);wr.append(b['wall_nanos']/a['wall_nanos'])
   for k in a['statistics']:
    if k!='candidate_nanos':assert a['statistics'][k]==b['statistics'][k],(c,k)
   assert json.loads((p/f"{c['name']}-b{block}-A.stdout").read_text())['basis']==json.loads((p/f"{c['name']}-b{block}-B.stdout").read_text())['basis']
 o=dict(samples=len(d['samples']),cpu=d['cpu'],candidate=summary(cr),wall=summary(wr),per_case=r,complete_bases_and_counters_equal=True);analyses['first' if not suffix else 'repeat']=o;allc+=cr;allw+=wr
 if suffix:(p/'analysis.json').write_text(json.dumps(o,indent=2)+'\n')
analyses['all_retained_samples']=dict(samples=128,candidate=summary(allc),wall=summary(allw));print(json.dumps(analyses['all_retained_samples'],indent=2));print('first',analyses['first']['candidate'],analyses['first']['wall']);print('repeat',analyses['repeat']['candidate'],analyses['repeat']['wall']);(p/'combined-analysis.json').write_text(json.dumps(analyses,indent=2)+'\n')
analyses={};pooled={}
for suffix in ('','-repeat'):
 p=base/('metadata-roundtrip-bench-records-6bb2e9080284'+suffix);d=json.loads((p/'metadata.json').read_text());r={};count=0
 for case in ('cyclic4','cyclic5','cyclic6','reimer5'):
  ratios=[]
  for block in (0,1):
   a,b=[json.loads((p/f'{case}-b{block}-{arm}.json').read_text())['results'][0] for arm in ('A','B')];assert a['hashes_agree'] and b['hashes_agree'] and a['observed_hash']==b['observed_hash'];assert len(a['points'])==len(b['points'])==5
   for x,y in zip(a['points'],b['points']):
    assert x['status']==y['status']=='ok' and x['result_hash']==y['result_hash'];count+=2;ratios.append((y['total_nanos']/y['inner_repeats'])/(x['total_nanos']/x['inner_repeats']))
  r[case]=dict(**summary(ratios),ratios=ratios);pooled.setdefault(case,[]).extend(ratios)
 o=dict(cpu=d['cpu'],completed_points=count,all_hashes_match=True,per_case=r);analyses['first' if not suffix else 'repeat']=o
 if suffix:(p/'analysis.json').write_text(json.dumps(o,indent=2)+'\n')
analyses['all_retained_samples']=dict(completed_points=160,per_case={c:summary(v) for c,v in pooled.items()});(p/'combined-analysis.json').write_text(json.dumps(analyses,indent=2)+'\n');print('bench',json.dumps(analyses,indent=2))
