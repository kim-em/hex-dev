import HexGroebner.Bench.Projection

def main : IO Unit := do
  let raw := (← IO.getEnv "HEX_GROEBNER_TEST_SEED").getD "0"
  let some seed := raw.toNat? | throw (IO.userError "invalid seed")
  for size in [64,128,256,512] do
    let n := size+seed%2
    let input := Hex.Groebner.Bench.prepareProjection n
    let actual := Hex.Groebner.Bench.binaryProjection input
    let expected := Hex.Groebner.Bench.projectionSparse input
    if !actual.1 || actual != expected then throw (IO.userError s!"projection mismatch at {n}")
    IO.println s!"projection {n}: known rank, independent units, pivot flags/sugars and all eight counters passed"
