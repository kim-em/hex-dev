import Lake
open Lake DSL
package ProjectionChecks
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-projection-bench"
lean_exe check where
  root := `Check
