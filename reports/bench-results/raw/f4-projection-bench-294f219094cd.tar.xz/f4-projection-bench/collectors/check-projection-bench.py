from pathlib import Path
import json,subprocess,os,hashlib
s=Path('/home/kim/tmp/issue-10987');root=Path.cwd();d=s/'projection-bench-checks';d.mkdir(exist_ok=False)
m=json.loads((s/'support-owner-controls/positive/lake-manifest.json').read_text());m['name']='ProjectionChecks';m['packagesDir']=str(root/'.lake/packages')
for p in m['packages']:
 if p['name']=='Hex':p['dir']=str(root)
(d/'lake-manifest.json').write_text(json.dumps(m,indent=2)+'\n');(d/'lean-toolchain').write_bytes((root/'lean-toolchain').read_bytes())
(d/'lakefile.lean').write_text('import Lake\nopen Lake DSL\npackage ProjectionChecks\nrequire Hex from '+json.dumps(str(root))+'\nlean_exe check where\n  root := `Check\n')
(d/'Check.lean').write_text('''import HexGroebner.Bench.Projection

def main : IO Unit := do
  let raw := (← IO.getEnv "HEX_GROEBNER_TEST_SEED").getD "0"
  let some seed := raw.toNat? | throw (IO.userError "invalid seed")
  for size in [64,128,256,512] do
    let n := size+seed%2
    let input := Hex.Groebner.Bench.prepareProjection n
    let actual := Hex.Groebner.Bench.binaryProjection input
    let expected := Hex.Groebner.Bench.projectionSparse input
    if !actual.1 || actual != expected then throw (IO.userError s!"projection mismatch at {n}")
    IO.println s!"projection {n}: known rank, independent units, pivot flags/sugars and all eight counters passed"
''')
env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR=str(s),HEX_GROEBNER_TEST_SEED='0')
with(d/'build.log').open('w')as f:subprocess.run(['lake','build','check'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
for seed in [0,1]:
 env['HEX_GROEBNER_TEST_SEED']=str(seed)
 with(d/f'run-{seed}.stdout').open('w')as stdout,(d/f'run-{seed}.stderr').open('w')as stderr:r=subprocess.run([str(d/'.lake/build/bin/check')],cwd=d,env=env,stdout=stdout,stderr=stderr)
 assert r.returncode==0
print('Projection benchmark independent rank/target checks pass at64/65,128/129,256/257,512/513',flush=True)
(d/'status.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'binary_sha256':hashlib.sha256((d/'.lake/build/bin/check').read_bytes()).hexdigest(),'seeds':[0,1],'sizes':[64,65,128,129,256,257,512,513],'exit_codes':[0,0]},indent=2)+'\n')
