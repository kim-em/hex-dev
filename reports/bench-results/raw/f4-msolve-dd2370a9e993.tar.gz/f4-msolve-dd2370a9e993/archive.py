from pathlib import Path
import hashlib,tarfile,io,json,subprocess,gzip
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-equivalence');base=state/'current-comparator-production';source=state/'msolve-current';name='f4-msolve-dd2370a9e993';payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
for path in sorted(base.rglob('*')):
 if path.is_file() and not path.relative_to(base).parts[0]=='binaries':add('hex/'+str(path.relative_to(base)),path.read_bytes())
for path in ['build-current-msolve.sh','msolve-current-provenance.json','msolve-current-help.txt','msolve-current-autoreconf.log','msolve-current-libtoolize.log','msolve-current-configure.log','msolve-current-build.log','msolve-config-failed-gmp.log','current-comparator-freeze.log','current-msolve-l2.log','current-msolve-l42.log','issue-10987-lean-cc','issue-10987-lean-cc-flags.json']:
 p=state/path
 if p.is_file():add('build/'+path,p.read_bytes())
for path in ['config.log','config.status','config.h','Makefile','src/neogb/Makefile','libtool']:
 add('msolve-generated/'+path,(source/path).read_bytes())
add('msolve-source.tar',subprocess.check_output(['git','archive','HEAD'],cwd=source))
add('archive.py',Path(__file__).read_bytes())
checks={k:hashlib.sha256(v).hexdigest() for k,v in payload.items()}
add('sha256.json',(json.dumps(checks,indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size)
(state/'current-msolve-archive-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
