/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

public import Std.Data.HashMap

public section

namespace Hex.Groebner

/-- Two stable u32 indices in one word. This type alias introduces no runtime
wrapper. Equality compares the complete word; hashing mixes its correlated halves. -/
@[expose] def IndexPair := UInt64

namespace IndexPair

/-- Pack an ordered pair. Callers establish that both indices fit in 32 bits. -/
@[expose, inline] def pack (left right : Nat) : IndexPair :=
  left.toUInt64 <<< 32 ||| right.toUInt64

instance : BEq IndexPair := inferInstanceAs (BEq UInt64)
instance : DecidableEq IndexPair := inferInstanceAs (DecidableEq UInt64)
instance : LawfulBEq IndexPair := inferInstanceAs (LawfulBEq UInt64)

/-- Transparent word mixing, so kernel computation does not depend on the
opaque runtime `mixHash`. Hashes only select buckets; equality remains exact. -/
@[expose, inline] def hash (key : IndexPair) : UInt64 :=
  let word : UInt64 := key
  let x : UInt64 := (word ^^^ (word >>> 30)) * 13787848793156543929
  let x : UInt64 := (x ^^^ (x >>> 27)) * 10723151780598845931
  x ^^^ (x >>> 31)

instance : Hashable IndexPair := ⟨hash⟩

end IndexPair
end Hex.Groebner
