#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdatomic.h>
static uint64_t candidate_calls=0,control_calls=0,accepted=0,declined=0,discarded_work=0;
#define HEX_GROEBNER_MATRIX_ACCEPTED() (++accepted)
#define HEX_GROEBNER_MATRIX_DEFERRED() (++declined)
#define HEX_GROEBNER_DELAYED_DEFERRED(work) (discarded_work+=(work))
#define HEX_GROEBNER_FORCE_SPARSE_BINARY
#define HEX_GROEBNER_SPARSE_DEFERRED(work) (discarded_work+=(work))
#define lean_hex_groebner_eliminate_matrix hex_candidate_eliminate
#define lean_hex_matrix_validate hex_unused_validate
#define lean_hex_matrix_zeros hex_unused_zeros
#include "ffi/matrix_eliminate.c"
#undef lean_hex_groebner_eliminate_matrix
__typeof__(hex_candidate_eliminate) __real_lean_hex_groebner_eliminate_matrix;
static atomic_uint selected=0;
static void report_calls(void) {fprintf(stderr,"binaryScanCandidate=%llu control=%llu accepted=%llu declined=%llu discardedWork=%llu\n",(unsigned long long)candidate_calls,(unsigned long long)control_calls,(unsigned long long)accepted,(unsigned long long)declined,(unsigned long long)discarded_work);}
static int prefer_sparse(b_lean_obj_arg limits,b_lean_obj_arg column_arg,
        b_lean_obj_arg reducers,b_lean_obj_arg targets) {
 if(sizeof(void*)!=8 || !lean_is_scalar(column_arg)) return 0;
 uint64_t columns=lean_unbox(column_arg),nr=lean_array_size(reducers),nt=lean_array_size(targets);
 if(columns>131072 || nr>131072 || nt>4096) return 0;
 uint64_t minimum=2*(nr+nt)+5*columns;
 for(unsigned i=0;i<7;++i) {
  lean_object *arg=lean_ctor_get(limits,i);uint64_t limit=lean_is_scalar(arg)?lean_unbox(arg):UINT64_MAX/2;
  if((i==0 && columns>limit) || (i==1 && nr+nt>limit) ||
     (i==4 && 5*columns>limit) || (i==5 && minimum>limit)) return 0;
 }
 uint64_t entries=0,dense=0;
 for(size_t i=0;i<nr+nt;++i) {
  lean_object *row=lean_array_cptr(i<nr?reducers:targets)[i<nr?i:i-nr];
  lean_object *cs=lean_ctor_get(row,0);size_t bytes=lean_sarray_size(cs),n=bytes/4;
  if(bytes%4 || n>(UINT64_C(1)<<37) || entries>(UINT64_C(1)<<37)-n) return 0;
  entries+=n;
  if(i<nr && n) {
   uint64_t head=matrix_read(lean_sarray_cptr(cs),4),last=matrix_read(lean_sarray_cptr(cs)+(n-1)*4,4);
   if(head>=columns || last>=columns || last<head) return 0;
   if(n>last/64-head/64+1) ++dense;
  }
 }
 uint64_t rows=nr+nt,words=(columns+63)/64,capacity=rows<columns?rows:columns;
 uint64_t bytes=(capacity+1)*words*8+16*capacity;
 uint64_t cost=rows*(words+8)+3*entries+4*nt*columns+6*columns+nt*(rows*words+64);
 if(columns>=64 && nr>=4 && nt>=64) {
  bytes+=nt*(words*8+16)+16*words*8;
  cost+=nt*(columns+2*words+8)+((nr+3)/4)*(16*words+512)+8*nt*nr+5*columns;
  cost-=3*words*nt*(dense/4);
 }
 lean_object *allowance=lean_ctor_get(limits,4);
 uint64_t packed=lean_is_scalar(allowance)?lean_unbox(allowance):UINT64_MAX/2;
 return bytes>packed || cost>(UINT64_C(1)<<34);
}
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_eliminate_matrix(uint64_t p,
 b_lean_obj_arg limits,b_lean_obj_arg columns,b_lean_obj_arg reducers,
 b_lean_obj_arg targets,b_lean_obj_arg sugars,uint8_t independent) {
 unsigned mode=atomic_load_explicit(&selected,memory_order_relaxed);
 if(!mode) {const char *env=getenv("HEX_BINARY_SCAN_CANDIDATE");mode=env&&env[0]=='1'?2:1;atomic_store_explicit(&selected,mode,memory_order_relaxed);atexit(report_calls);}
 if(mode==2 && p==2 && lean_ctor_get_uint8(limits,7*sizeof(void*)+1) && prefer_sparse(limits,columns,reducers,targets)) {
   ++candidate_calls;return hex_candidate_eliminate(p,limits,columns,reducers,targets,sugars,independent);
 }
 ++control_calls;return __real_lean_hex_groebner_eliminate_matrix(p,limits,columns,reducers,targets,sugars,independent);
}
