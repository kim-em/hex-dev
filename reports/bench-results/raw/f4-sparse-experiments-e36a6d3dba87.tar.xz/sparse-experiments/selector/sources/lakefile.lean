import Lake
open Lake DSL System
package SparseBinarySelectorPrototype
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-sparse-binary"

target probe pkg : FilePath := do
  let source ← inputTextFile (pkg.dir / "probe.c")
  let inputs ← #["matrix_eliminate.c","matrix_delayed.h","matrix_simd.h","matrix_avx512.h","matrix_runtime.h"].foldlM (fun job name => do
    let header ← inputTextFile (pkg.dir / "ffi" / FilePath.mk name)
    pure (job.zipWith (fun s _ => s) header)) source
  buildO (pkg.buildDir / "probe.o") inputs #["-isystem", (← getLeanIncludeDir).toString]
    #["-O3","-g","-fPIC","-Wall","-Wextra","-Werror","-DLEAN_EXPORTING"]
    (compiler := FilePath.mk "/nix/store/2msw5nclhpsm80z65dqmjiv8kkras989-clang-wrapper-21.1.8/bin/clang")

lean_exe driver where
  root := `Main
  moreLinkObjs := #[probe]
  moreLinkArgs := #["-Wl,--wrap=lean_hex_groebner_eliminate_matrix"]
