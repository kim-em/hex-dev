"""Fixed first-size F4 comparison of one frozen binary with the option off/on."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,math,os,resource,select,shutil,signal,subprocess,time
s=Path('/home/kim/tmp/issue-10987');p=argparse.ArgumentParser();p.add_argument('frozen',type=Path);p.add_argument('output',type=Path);p.add_argument('--case');args=p.parse_args();base=args.frozen;out=args.output;out.mkdir(exist_ok=False)
inputs=s/'fixed-corpus-v2-cli-validated';suite=json.loads((inputs/'suite.json').read_text());manifest=json.loads((base/'manifest.json').read_text());seen=set();cases=[]
for c in suite['cases']:
 key=c['family'],c['p']
 if args.case:
  if c['name']==args.case:cases.append(c)
 elif c['split']=='primary'and key not in seen:seen.add(key);cases.append(c)
assert len(cases)==(1 if args.case else 30)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();binary=base/'binaries/compute';assert sha(binary)==manifest['binary_sha256']['compute']
helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('delayed_cpu_lease',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);cpu,lease=m.cpu_lease();os.sched_setaffinity(0,{cpu})
clock=Path(shutil.which('time'));bindings=[binary,helper,clock,Path(__file__),base/'manifest.json',*sorted((base/'experimental-sources').rglob('*'))];bindings=[p for p in bindings if p.is_file()];before={str(p):sha(p)for p in bindings}
for name,path in [('collector.py',Path(__file__)),('cpu_lease.py',helper),('frozen-manifest.json',base/'manifest.json'),('suite.json',inputs/'suite.json')]:shutil.copy2(path,out/name)
limits=suite['protocol']['hex_limits'];options=[part for k,v in limits.items()for part in ['--'+k,str(v)]];env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
meta=dict(manifest=manifest,cases=cases,cpu=cpu,threads=1,schedule='Adjacent AB then BA; same frozen private executable, A=original sparse continuation, B=select sparse F2 before work when packed payload or conservative table-group lower bound guarantees packed refusal; environment switch only; delayedReduction true and all other options identical',protocol=suite['protocol'],source_bindings=before,host=os.uname().nodename,load_start=os.getloadavg(),samples=[],selection='Focused Eco14 F2 diagnostic comparison after a complete fixed sweep and profile identified sparse continuation as the bottleneck. One predeclared input, no balanced-suite or leadership claim.',contract='Complete reduced unchecked F4 candidates in ordinary prime-field polynomial rings. Candidate production and whole-process time are separate; no certificate-generation, independent native certification or kernel-checking time. All completed samples and failures retained. No leadership claim.')
def save():
 t=out/'metadata.pending';t.write_text(json.dumps(meta,indent=2)+'\n');t.replace(out/'metadata.json')
def bound():
 os.setsid();resource.setrlimit(resource.RLIMIT_AS,(8*1024**3,8*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(256*1024**2,256*1024**2))
active=None;save()
try:
 for block in [0,1]:
  for case in cases:
   name=case['name'];target=out/(name+'.input.json');source=inputs/(name+'.json')
   if not target.exists():shutil.copy2(source,target)
   value=json.loads(target.read_text());results={};rows=[]
   for arm in (['A','B']if block==0 else['B','A']):
    prefix=out/(name+f'-b{block}-{arm}');rss=Path(str(prefix)+'.rss');flag='true'if arm=='B'else'false'
    child_env=dict(env,HEX_BINARY_SCAN_CANDIDATE='1' if arm=='B'else'0')
    command=[str(binary),*options,'--scheduling','degree','--binary-pivots','true','--dense-pivots','false','--delayed-reduction','true',str(target)]
    row=dict(case=name,family=case['family'],p=case['p'],block=block,arm=arm,command=command,status='pending',complete_output_and_counters_equal=False,input_sha256=sha(target));start=time.monotonic_ns()
    with Path(str(prefix)+'.stdout').open('w')as stdout,Path(str(prefix)+'.stderr').open('w')as stderr:
     active=subprocess.Popen([str(clock),'-f','%M','-o',str(rss),'--',*command],stdout=stdout,stderr=stderr,env=child_env,preexec_fn=bound);descriptor=os.pidfd_open(active.pid)
     try:
      if select.select([descriptor],[],[],300)[0]:code=active.wait();row['status']='ok'if code==0 else'failed'
      else:os.killpg(active.pid,signal.SIGKILL);code=active.wait();row['status']='timeout'
     finally:os.close(descriptor)
    row.update(returncode=code,wall_nanos=time.monotonic_ns()-start);active=None;text=rss.read_text().strip().splitlines()if rss.exists()else[];row['peak_rss_kib']=int(text[-1])if text and text[-1].isdigit()else None
    if row['status']=='ok':
     try:
      data=json.loads(Path(str(prefix)+'.stdout').read_text());assert data['kind']=='unchecked_candidate'and(data['p'],data['variables'],data['order'])==(value['p'],value['variables'],value['order']);assert data['delayedReduction']is True;import re;counts=re.search(r'binaryScanCandidate=(\d+) control=(\d+)',Path(str(prefix)+'.stderr').read_text());assert counts;row['frame_calls']={'candidate':int(counts[1]),'control':int(counts[2])};assert int(counts[1]if arm=='B'else counts[2])>0;frame_counts=re.search(r'accepted=(\d+) declined=(\d+) discardedWork=(\d+)',Path(str(prefix)+'.stderr').read_text());assert frame_counts;row['native_frames']={'accepted':int(frame_counts[1]),'declined':int(frame_counts[2]),'discarded_work':int(frame_counts[3])};row['candidate_nanos']=data['candidateNanos'];results[arm]={k:v for k,v in data.items()if k not in ['candidateNanos','delayedReduction']}
     except Exception as error:row.update(status='invalid_output',error=str(error))
    meta['samples'].append(row);rows.append(row);save();print(name,block,arm,row['status'],round(row['wall_nanos']/1e6,2),row.get('candidate_nanos'),flush=True)
   equal=len(results)==2 and results['A']==results['B']
   for row in rows:row['complete_output_and_counters_equal']=equal
   save()
finally:
 if active is not None and active.poll()is None:os.killpg(active.pid,signal.SIGKILL);active.wait()
 meta.update(load_end=os.getloadavg(),source_bindings_after={str(p):sha(p)for p in bindings});meta['sources_unchanged']=meta['source_bindings_after']==before;save();lease.close()
ratios=[]
for c in cases:
 for block in [0,1]:
  pair=[r for r in meta['samples']if r['case']==c['name']and r['block']==block]
  if len(pair)==2 and all(r['complete_output_and_counters_equal']for r in pair):
   a=next(r for r in pair if r['arm']=='A');b=next(r for r in pair if r['arm']=='B');ratios.append(dict(case=c['name'],family=c['family'],p=c['p'],block=block,process_ratio=b['wall_nanos']/a['wall_nanos'],candidate_ratio=b['candidate_nanos']/a['candidate_nanos']))
(out/'paired-ratios.json').write_text(json.dumps(ratios,indent=2)+'\n');print('COMPLETE',len(meta['samples']),'processes',len(ratios),'fully equal pairs',flush=True)
