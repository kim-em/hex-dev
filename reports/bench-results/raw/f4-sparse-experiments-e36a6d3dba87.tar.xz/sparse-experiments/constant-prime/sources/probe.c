#include <stdlib.h>
#include <stdatomic.h>
#include <stdio.h>
#define lean_hex_scan_transition hex_candidate_scan
#define lean_hex_dense_transition hex_unused_dense
#define lean_hex_gather hex_unused_gather
#define lean_hex_prepare_dense hex_unused_prepare
#include "ffi/matrix_scan.c"
#undef lean_hex_scan_transition
__typeof__(hex_candidate_scan) __real_lean_hex_scan_transition;
static atomic_uint selected=0;
static uint64_t candidate_calls=0,control_calls=0;
static void report_calls(void) {fprintf(stderr,"binaryScanCandidate=%llu control=%llu\n",(unsigned long long)candidate_calls,(unsigned long long)control_calls);}
LEAN_EXPORT lean_obj_res __wrap_lean_hex_scan_transition(uint64_t p,
 b_lean_obj_arg slots,b_lean_obj_arg pivots,lean_obj_arg initial,
 b_lean_obj_arg quantum,b_lean_obj_arg work,b_lean_obj_arg trace,uint8_t provenance) {
 unsigned mode=atomic_load_explicit(&selected,memory_order_relaxed);
 if(!mode) {const char *env=getenv("HEX_BINARY_SCAN_CANDIDATE");mode=env && env[0]=='1'?2:1;atomic_store_explicit(&selected,mode,memory_order_relaxed);atexit(report_calls);}
 if(mode==2 && p==2) {++candidate_calls;return hex_candidate_scan(p,slots,pivots,initial,quantum,work,trace,provenance);}
 ++control_calls;return __real_lean_hex_scan_transition(p,slots,pivots,initial,quantum,work,trace,provenance);
}
