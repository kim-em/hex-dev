#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdatomic.h>
static uint64_t candidate_calls=0,control_calls=0,accepted=0,declined=0,discarded_work=0;
#define HEX_GROEBNER_MATRIX_ACCEPTED() (++accepted)
#define HEX_GROEBNER_MATRIX_DEFERRED() (++declined)
#define HEX_GROEBNER_DELAYED_DEFERRED(work) (discarded_work+=(work))
#define lean_hex_groebner_eliminate_matrix hex_candidate_eliminate
#define lean_hex_matrix_validate hex_unused_validate
#define lean_hex_matrix_zeros hex_unused_zeros
#include "ffi/matrix_eliminate.c"
#undef lean_hex_groebner_eliminate_matrix
__typeof__(hex_candidate_eliminate) __real_lean_hex_groebner_eliminate_matrix;
static atomic_uint selected=0;
static void report_calls(void) {fprintf(stderr,"binaryScanCandidate=%llu control=%llu accepted=%llu declined=%llu discardedWork=%llu\n",(unsigned long long)candidate_calls,(unsigned long long)control_calls,(unsigned long long)accepted,(unsigned long long)declined,(unsigned long long)discarded_work);}
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_eliminate_matrix(uint64_t p,
 b_lean_obj_arg limits,b_lean_obj_arg columns,b_lean_obj_arg reducers,
 b_lean_obj_arg targets,b_lean_obj_arg sugars,uint8_t independent) {
 unsigned mode=atomic_load_explicit(&selected,memory_order_relaxed);
 if(!mode) {const char *env=getenv("HEX_BINARY_SCAN_CANDIDATE");mode=env&&env[0]=='1'?2:1;atomic_store_explicit(&selected,mode,memory_order_relaxed);atexit(report_calls);}
 if(mode==2 && p==2 && lean_ctor_get_uint8(limits,7*sizeof(void*)+1) && lean_is_scalar(columns) &&
    (lean_unbox(columns)>131072 || lean_array_size(reducers)>131072)) {
   ++candidate_calls;return hex_candidate_eliminate(p,limits,columns,reducers,targets,sugars,independent);
 }
 ++control_calls;return __real_lean_hex_groebner_eliminate_matrix(p,limits,columns,reducers,targets,sugars,independent);
}
