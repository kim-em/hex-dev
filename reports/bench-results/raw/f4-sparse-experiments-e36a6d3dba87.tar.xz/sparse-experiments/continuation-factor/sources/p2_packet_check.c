#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#include "ffi/matrix_simd.h"
#if HEX_GROEBNER_AVX2
__attribute__((target("avx2")))
static void check_packet(unsigned stride,unsigned gap,unsigned factor,int malformed) {
    uint32_t columns[8];uint8_t coefficients[8],dense[96],expected[96],before[96];
    for(unsigned k=0;k<96;++k)dense[k]=expected[k]=before[k]=(uint8_t)(k&1);
    for(unsigned k=0;k<8;++k) {columns[k]=gap+k*stride;coefficients[k]=1;expected[columns[k]]^=(uint8_t)factor;}
    if(malformed==1)coefficients[3]=0;
    if(malformed==2)coefficients[4]=2;
    if(malformed==3)columns[4]=columns[3];
    if(malformed==4)dense[columns[5]]=before[columns[5]]=2;
    unsigned count=hex_scan8(dense,(const uint8_t*)columns,coefficients,0,96,2,factor,UINT32_C(2147483648),1);
    assert(count==(malformed?0:8));assert(memcmp(dense,malformed?before:expected,96)==0);
}
__attribute__((target("avx2")))
static void check_guard(void) {
    size_t page=(size_t)sysconf(_SC_PAGESIZE);uint8_t *a=mmap(NULL,page*6,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(a!=MAP_FAILED);
    for(unsigned k=1;k<6;k+=2)assert(mprotect(a+page*k,page,PROT_NONE)==0);
    uint8_t *dense=a+page-8,*columns=a+page*3-32,*coefficients=a+page*5-8;
    for(unsigned k=0;k<8;++k) {dense[k]=(uint8_t)(k&1);uint32_t col=k;memcpy(columns+k*4,&col,4);coefficients[k]=1;}
    assert(hex_scan8(dense,columns,coefficients,0,8,2,1,UINT32_C(2147483648),1)==8);
    for(unsigned k=0;k<8;++k)assert(dense[k]==((k&1)^1));
    assert(munmap(a,page*6)==0);
}
#endif
int main(void) {
#if HEX_GROEBNER_AVX2
    if(!hex_avx2_available())return 77;
    for(unsigned factor=0;factor<2;++factor)for(unsigned stride=1;stride<9;++stride)for(unsigned gap=0;gap<16;++gap)for(int malformed=0;malformed<5;++malformed)check_packet(stride,gap,factor,malformed);
    check_guard();puts("PASS 1280 valid and malformed F2 packet cases plus exact guard-page loads");return 0;
#else
    return 77;
#endif
}
