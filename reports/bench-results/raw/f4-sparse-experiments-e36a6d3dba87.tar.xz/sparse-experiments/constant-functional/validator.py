from pathlib import Path
import argparse,hashlib,importlib.util,json,os,resource,select,shutil,signal,subprocess
s=Path('/home/kim/tmp/issue-10987');parser=argparse.ArgumentParser();parser.add_argument('project',type=Path);parser.add_argument('output',type=Path);args=parser.parse_args();p=args.project;out=args.output;out.mkdir(exist_ok=False);binary=p/'.lake/build/bin/driver';sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest();files=[binary,p/'Main.lean',p/'probe.c',p/'lakefile.lean',*sorted((p/'ffi').glob('*')),Path(__file__)];before={str(q):sha(q)for q in files};suite=json.loads((s/'fixed-corpus-v2-cli-validated/suite.json').read_text());options=[x for k,v in suite['protocol']['hex_limits'].items()for x in ['--'+k,str(v)]];source=s/'fixed-corpus-v2-cli-validated/eco14-2.json';shutil.copy2(source,out/'input.json');shutil.copy2(Path(__file__),out/'validator.py');command=[str(binary),*options,'--scheduling','degree','--binary-pivots','true','--dense-pivots','false','--delayed-reduction','true',str(out/'input.json')]
helper=s/'prime-review-final-production/root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('validation_cpu_lease',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);cpu,lease=m.cpu_lease();os.sched_setaffinity(0,{cpu});record={'scope':'Functional comparison only; no comparative timing claim. Private prototype; portable admission/payload alignment and comprehensive raw boundary tests remain prerequisites for production.','command':command,'cpu':cpu,'source_bindings':before}
def bounds():
 os.setsid();resource.setrlimit(resource.RLIMIT_AS,(8*1024**3,)*2);resource.setrlimit(resource.RLIMIT_FSIZE,(256*1024**2,)*2)
try:
 with(out/'run.stdout').open('w')as stdout,(out/'run.stderr').open('w')as stderr:
  child=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=dict(os.environ,HEX_BINARY_SCAN_CANDIDATE='1'),preexec_fn=bounds);fd=os.pidfd_open(child.pid)
  try:
   if not select.select([fd],[],[],300)[0]:os.killpg(child.pid,signal.SIGKILL)
   code=child.wait()
  finally:os.close(fd)
 record.update(exit_code=code,source_bindings_after={str(q):sha(q)for q in files});record['sources_unchanged']=record['source_bindings']==record['source_bindings_after'];(out/'status.json').write_text(json.dumps(record,indent=2)+'\n');assert code==0 and record['sources_unchanged']
 a=json.loads((out/'run.stdout').read_text());expected=Path('/dev/shm/issue-10987-wide-fixed-default1024-msolve-first/eco14-2-b0-A.stdout');b=json.loads(expected.read_text());given=json.loads((out/'input.json').read_text());assert a['kind']=='unchecked_candidate'and all(a[k]==given[k]for k in ['p','variables','order']);record.update(complete_basis_equal=a['basis']==b['basis'],all_statistics_equal=a['statistics']==b['statistics'],native_counters=(out/'run.stderr').read_text(),expected_stdout_sha256=sha(expected),actual_stdout_sha256=sha(out/'run.stdout'));(out/'status.json').write_text(json.dumps(record,indent=2)+'\n');assert record['complete_basis_equal']and record['all_statistics_equal'];print('PASS complete Eco14 basis, metadata and all statistics; immutable source bindings')
finally:lease.close()
