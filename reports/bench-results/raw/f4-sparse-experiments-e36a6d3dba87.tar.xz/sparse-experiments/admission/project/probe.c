#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdatomic.h>
#define HEX_GROEBNER_MATRIX_ACCEPTED() fprintf(stderr,"accepted work=%llu physical=%llu scratch=%llu quantum=%llu sparse=%u\n",(unsigned long long)c.stats[0],(unsigned long long)c.physical,(unsigned long long)c.scratch,(unsigned long long)c.quantum,(unsigned)c.sparse_binary)
#define HEX_GROEBNER_MATRIX_DEFERRED() fprintf(stderr,"declined work=%llu physical=%llu scratch=%llu quantum=%llu sparse=%u\n",(unsigned long long)c.stats[0],(unsigned long long)c.physical,(unsigned long long)c.scratch,(unsigned long long)c.quantum,(unsigned)c.sparse_binary)
#define lean_hex_groebner_eliminate_matrix hex_candidate_eliminate
#define lean_hex_matrix_validate hex_unused_validate
#define lean_hex_matrix_zeros hex_unused_zeros
#include "ffi/matrix_eliminate.c"
#undef lean_hex_groebner_eliminate_matrix
LEAN_EXPORT lean_obj_res __wrap_lean_hex_groebner_eliminate_matrix(uint64_t p,
 b_lean_obj_arg limits,b_lean_obj_arg columns,b_lean_obj_arg reducers,
 b_lean_obj_arg targets,b_lean_obj_arg sugars,uint8_t independent) {
 uint64_t entries=0;size_t nr=lean_array_size(reducers),nt=lean_array_size(targets);
 for(size_t i=0;i<nr+nt;++i) {lean_object *r=lean_array_cptr(i<nr?reducers:targets)[i<nr?i:i-nr];entries+=lean_sarray_size(lean_ctor_get(r,0))/4;}
 fprintf(stderr,"frame p=%llu columns=%llu reducers=%zu targets=%zu entries=%llu independent=%u\n",(unsigned long long)p,(unsigned long long)lean_unbox(columns),nr,nt,(unsigned long long)entries,(unsigned)independent);
 return hex_candidate_eliminate(p,limits,columns,reducers,targets,sugars,independent);
}
