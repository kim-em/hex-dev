"""Retain every completed private sparse-F2 comparison, including rejected routes."""
from pathlib import Path
import hashlib,io,json,lzma,tarfile
S=Path('/home/kim/tmp/issue-10987');files={}
def add(name,path):
    assert name not in files;files[name]=Path(path).read_bytes()
def directory(prefix,base):
    base=Path(base)
    for path in sorted(base.rglob('*')):
        if path.is_file():add(prefix+'/'+str(path.relative_to(base)),path)
for label,freeze in [('baseline-c4','prime-review-final-production'),('baseline-c935','sparse-binary-production-768')]:
    base=S/freeze
    for name in ['manifest.json','build.log','source.manifest','groebner_freeze.py']:
        if(base/name).is_file():add(label+'/'+name,base/name)
    directory(label+'/root-sources',base/'root-sources')
experiments=[
 ('continuation','binary-continuation-prototype-frozen-v2','/dev/shm/issue-10987-binary-continuation-prototype-eco14-executable'),
 ('continuation-factor','binary-continuation-factor-frozen-v1','/dev/shm/issue-10987-binary-continuation-factor-eco14'),
 ('wide-sparse','binary-sparse-frame-frozen-v1','/dev/shm/issue-10987-binary-sparse-frame-eco14'),
 ('bit-accumulator','binary-sparse-bits-frozen-v1','/dev/shm/issue-10987-binary-sparse-bits-eco14'),
 ('retry','sparse-binary-fallback-frozen-v1',S/'sparse-binary-fallback-first-eco14'),
 ('selector','sparse-binary-selector-frozen-v1',S/'sparse-binary-selector-first-eco14'),
 ('constant-prime','binary-constant-prime-frozen-v2',S/'binary-constant-prime-first-eco14')]
for label,freeze,raw in experiments:
    base=S/freeze;add(label+'/manifest.json',base/'manifest.json')
    directory(label+'/sources',base/'experimental-sources')
    if(base/'build.log').is_file():add(label+'/build.log',base/'build.log')
    metadata=json.loads((Path(raw)/'metadata.json').read_text())
    assert len(metadata['samples'])==4 and metadata['sources_unchanged']
    assert all(r['status']=='ok'and r['complete_output_and_counters_equal']for r in metadata['samples'])
    directory(label+'/measurements',raw)
directory('failed-launches','/dev/shm/issue-10987-binary-continuation-prototype-eco14')
directory('admission',S/'sparse-binary-admission-eco14')
for name in ['probe.c','Main.lean','lakefile.lean','lake-manifest.json','lean-toolchain']:
    add('admission/project/'+name,S/'sparse-binary-admission-profile-c935'/name)
directory('admission/project/ffi',S/'sparse-binary-admission-profile-c935/ffi')
directory('compiler-audit',S/'sparse-prototype-compiler-audit')
for label,raw in [('retry-functional','sparse-binary-fallback-functional-eco14'),
                  ('selector-functional','sparse-binary-selector-functional-eco14'),
                  ('constant-functional','binary-constant-prime-functional-eco14')]:directory(label,S/raw)
files['scope.json']=(json.dumps(dict(
    experiments=[x[0]for x in experiments],samples=28,pairs=14,
    scope='Private in-sample Eco14F2 diagnostics. Every completed sample, outlier, rejected route and the original permission-denied launches are retained. No balanced-suite or leadership claim. Retry-provider discardedWork counts only sparse retry work; separate admission telemetry records202062207packed discarded charged units.',
    selected='Upfront selector motivated the integrated implementation; production source and executable differ and require their own measurements.',
    unselected=['continuation','continuation-factor','bit-accumulator','constant-prime'],
    comparisons='All successful matched pairs have identical complete candidates, metadata and logical counters. Candidate production, process time, certification and kernel checking remain distinct.'),indent=2)+'\n').encode()
add('pack-script.py',Path(__file__))
files['sha256.json']=(json.dumps({k:hashlib.sha256(v).hexdigest()for k,v in sorted(files.items())},indent=2)+'\n').encode()
out=S/'f4-sparse-experiments-e36a6d3dba87.tar.xz';assert not out.exists()
with lzma.LZMAFile(out,'wb',filters=[dict(id=lzma.FILTER_LZMA2,preset=3,dict_size=64*1024**2)])as compressed,tarfile.open(fileobj=compressed,mode='w|')as archive:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo('sparse-experiments/'+name);info.size=len(data);info.mode=0o644;info.mtime=0
        archive.addfile(info,io.BytesIO(data))
print(out,hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),out.stat().st_size)
