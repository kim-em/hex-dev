module

public import Lake

public section

open System Lake DSL

package Hex where
  -- Parse docstrings as Verso markup. Suggestions remain opt-in because they
  -- attempt to elaborate ordinary code spans, including local expressions.
  leanOptions := #[⟨`doc.verso, true⟩, ⟨`doc.verso.suggestions, false⟩]

require verso from git
  "https://github.com/leanprover/verso.git" @ "v4.35.0-rc3"

-- Test-only native oracle. Released Hex libraries do not depend on it.
require NautyFFI from git
  "https://github.com/leanprover/nauty-ffi.git" @
    "ec8597014d0ae82490a616b855d59a35e6bfa21f"

require «lean-bench» from git
  "https://github.com/kim-em/lean-bench.git" @ "master"

-- Abstract Sturm–Tarski semantics for the development query adapters, and
-- Hasse's theorem for the ECPP companion.
require TauCeti from git
  "https://github.com/TauCetiProject/TauCeti.git" @
    "1c497c347f615b3087cb605f8cf743e591376105"

require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git" @
    "6b7abb3c7686292736be2955bd3eb9ebf63b456a"

private def clmulOTarget (pkg : Package) : FetchM (Job FilePath) := do
  let oFile := pkg.dir / defaultBuildDir / "HexGF2" / "ffi" / "clmul.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexGF2" / "ffi" / "clmul.c"
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (← getLeanIncludeDir).toString, "-fPIC", "-O3"]
    compileO oFile srcFile flags

private def zmod64MulOTarget (pkg : Package) : FetchM (Job FilePath) := do
  let oFile := pkg.dir / defaultBuildDir / "HexModArith" / "ffi" / "zmod64_mul.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexModArith" / "ffi" / "zmod64_mul.c"
  buildFileAfterDep oFile srcTarget fun srcFile => do
    -- `LEAN_EXPORTING` makes `LEAN_EXPORT` a dllexport on Windows, as Lake
    -- does for Lean's own C; a carrier DLL otherwise hides these symbols.
    let flags := #["-I", (← getLeanIncludeDir).toString, "-fPIC", "-O3",
      "-DLEAN_EXPORTING"]
    -- Mathlib's sandbox permits writes in the build directory, but not /tmp.
    -- Set TMPDIR for this compiler process only, including compiler wrappers.
    createParentDirs oFile
    proc {
      cmd := "cc"
      args := #["-c", "-o", oFile.toString, srcFile.toString] ++ flags
      env := #[("TMPDIR", some (← IO.FS.realPath (oFile.parent.getD ".")).toString)]
    }

extern_lib hexgf2ffi (pkg) := do
  let name := nameToStaticLib "hexgf2ffi"
  let oTarget ← clmulOTarget pkg
  buildStaticLib (pkg.staticLibDir / name) #[oTarget]

private def hexArithOTarget (pkg : Package) (src : String) : FetchM (Job FilePath) := do
  let stem := (src.dropEnd 2).toString
  let oFile := pkg.dir / defaultBuildDir / "HexArith" / "ffi" / s!"{stem}.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexArith" / "ffi" / src
  buildFileAfterDep oFile srcTarget fun srcFile => do
    -- `LEAN_EXPORTING` makes `LEAN_EXPORT` a dllexport on Windows, as Lake
    -- does for Lean's own C; a carrier DLL otherwise hides these symbols.
    let flags := #["-I", (← getLeanIncludeDir).toString, "-fPIC", "-O3",
      "-DLEAN_EXPORTING"]
    -- Mathlib's sandbox permits writes in the build directory, but not /tmp.
    -- Set TMPDIR for this compiler process only, including compiler wrappers.
    createParentDirs oFile
    proc {
      cmd := "cc"
      args := #["-c", "-o", oFile.toString, srcFile.toString] ++ flags
      env := #[("TMPDIR", some (← IO.FS.realPath (oFile.parent.getD ".")).toString)]
    }

-- Object files rather than an archive: a library's shared form keeps every
-- object it is given, while an archive contributes only referenced members.
target hexarithWideO pkg : FilePath := hexArithOTarget pkg "wide_arith.c"

-- TODO(lean4#15160): remove extended_gcd.c after the pinned toolchain provides
-- Nat.extendedGcd: https://github.com/leanprover/lean4/pull/15160
target hexarithGcdO pkg : FilePath := hexArithOTarget pkg "extended_gcd.c"

target hexgroebnerRowsO pkg : FilePath := do
  let oFile := pkg.dir / defaultBuildDir / "HexGroebner" / "ffi" / "row_update.o"
  let source ← inputTextFile <| pkg.dir / "HexGroebner" / "ffi" / "row_update.c"
  let trie ← inputTextFile <| pkg.dir / "HexGroebner" / "ffi" / "trie_lookup.h"
  let inputs := source.zipWith (fun source _ => source) trie
  buildFileAfterDep oFile inputs fun srcFile => do
    createParentDirs oFile
    proc {
      cmd := "cc"
      args := #["-c", "-o", oFile.toString, srcFile.toString,
        "-I", (← getLeanIncludeDir).toString, "-fPIC", "-O3", "-DLEAN_EXPORTING"]
      env := #[("TMPDIR", some (← IO.FS.realPath (oFile.parent.getD ".")).toString)]
    }

target hexgroebnerScanO pkg : FilePath := do
  let directory := pkg.dir / "HexGroebner" / "ffi"
  let source ← inputTextFile (directory / "matrix_scan.c")
  let simd ← inputTextFile (directory / "matrix_simd.h")
  let body ← inputTextFile (directory / "matrix_scan_impl.h")
  let inputs := (source.zipWith (fun source _ => source) simd).zipWith
    (fun source _ => source) body
  buildO (pkg.dir / defaultBuildDir / "HexGroebner" / "ffi" / "matrix_scan.o") inputs
    #["-I", (← getLeanIncludeDir).toString]
    #["-O3", "-Wall", "-Wextra", "-fPIC", "-DLEAN_EXPORTING"]
    (extraDepTrace := do addLeanTrace; pure BuildTrace.nil)

target hexmodarithO pkg : FilePath := zmod64MulOTarget pkg

target hexecpppariio pkg : FilePath := do
  let oFile := pkg.dir / defaultBuildDir / "HexECPPTheory" / "ffi" / "pari_pipe.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexECPPTheory" / "ffi" / "pari_pipe.c"
  let oTarget ← buildFileAfterDep oFile srcTarget fun srcFile => do
    createParentDirs oFile
    proc {
      cmd := "cc"
      args := #["-c", "-o", oFile.toString, srcFile.toString,
        "-I", (← getLeanIncludeDir).toString, "-fPIC", "-O2", "-std=c11"]
      env := #[("TMPDIR", some (← IO.FS.realPath (oFile.parent.getD ".")).toString)]
    }
  buildStaticLib (pkg.staticLibDir / nameToStaticLib "hexecpppariio") #[oTarget]

target hexintfactorpariio pkg : FilePath := do
  let oFile := pkg.dir / defaultBuildDir / "HexIntFactor" / "ffi" / "pari_pipe.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexIntFactor" / "ffi" / "pari_pipe.c"
  let oTarget ← buildFileAfterDep oFile srcTarget fun srcFile => do
    createParentDirs oFile
    proc {
      cmd := "cc"
      args := #["-c", "-o", oFile.toString, srcFile.toString,
        "-I", (← getLeanIncludeDir).toString, "-fPIC", "-O2", "-std=c11"]
      env := #[("TMPDIR", some (← IO.FS.realPath (oFile.parent.getD ".")).toString)]
    }
  buildStaticLib (pkg.staticLibDir / nameToStaticLib "hexintfactorpariio") #[oTarget]

private def hexlllProviderOTarget (pkg : Package) : FetchM (Job FilePath) := do
  let oFile := pkg.dir / defaultBuildDir / "HexLLL" / "ffi" / "lean_hexlll_provider.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexLLL" / "ffi" / "lean_hexlll_provider.c"
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (← getLeanIncludeDir).toString, "-fPIC", "-O3"]
    compileO oFile srcFile flags

extern_lib hexlllffi (pkg) := do
  let name := nameToStaticLib "hexlllffi"
  let oTarget ← hexlllProviderOTarget pkg
  buildStaticLib (pkg.staticLibDir / name) #[oTarget]

private def nautyVendorOTarget (pkg : Package) (src : String) : FetchM (Job FilePath) := do
  let stem := (src.dropEnd 2).toString
  let oFile := pkg.dir / defaultBuildDir / "vendor" / "nauty-2.9.3" / s!"{stem}.o"
  let srcTarget ← inputTextFile <| pkg.dir / "vendor" / "nauty-2.9.3" / src
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (pkg.dir / "vendor" / "nauty-2.9.3").toString,
      "-fPIC", "-O2", "-std=c11", "-DUSE_TLS"]
    compileO oFile srcFile flags

private def nautyCanonOTarget (pkg : Package) : FetchM (Job FilePath) := do
  let oFile := pkg.dir / defaultBuildDir / "Hex" / "BenchOracle" / "ffi" /
    "nauty_canon.o"
  let srcTarget ← inputTextFile <| pkg.dir / "Hex" / "BenchOracle" / "ffi" /
    "nauty_canon.c"
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (← getLeanIncludeDir).toString,
      "-I", (pkg.dir / "vendor" / "nauty-2.9.3").toString,
      "-fPIC", "-O2", "-std=c11", "-DUSE_TLS"]
    compileO oFile srcFile flags

extern_lib hexnautyffi (pkg) := do
  let name := nameToStaticLib "hexnautyffi"
  let vendorTargets ← #["nauty.c", "nautil.c", "naugraph.c", "schreier.c",
    "naurng.c"].mapM (nautyVendorOTarget pkg)
  let shimTarget ← nautyCanonOTarget pkg
  buildStaticLib (pkg.staticLibDir / name) (vendorTargets.push shimTarget)

lean_lib Hex where

-- Mathlib-free dependencies and producers called during elaboration.
lean_lib HexBasic

lean_lib HexTruncatedSeries where

@[default_target]
lean_lib HexTruncatedSeriesTheory where

lean_lib HexArith where
  precompileModules := true

-- The C objects ride on a separate library that owns the modules binding them.
-- Lake links a module's native library against the whole shared library of any
-- *other* library it imports, objects included, but never adds its own
-- library's `moreLinkObjs`; Windows resolves every symbol at link time, so the
-- objects must sit in a different library from the modules that import them.
-- Declared after `HexArith`, because Lake gives a module to the last library
-- that claims it. These modules import nothing from `HexArith`, and
-- `extended_gcd.c` calls back into `HexArith.Nat.ExtendedGcd`, so both sides
-- of that callback live in one shared library. The single root named after the
-- library makes Lake load it as a plugin; Lean loads every plain dynlib before
-- any plugin, so a carrier that is not a plugin cannot depend on one.
lean_lib HexArithNative where
  roots := #[`HexArithNative]
  globs := #[.one `HexArithNative, .one `HexArith.UInt64.Wide,
    .one `HexArith.Nat.ExtendedGcd]
  precompileModules := true
  moreLinkObjs := #[hexarithWideO, hexarithGcdO]
  -- TODO(lean4#15160): remove -lgmp with the local extended_gcd.c adapter.
  moreLinkArgs := #["-lgmp"]

lean_lib HexPoly where

lean_lib HexPolyFast where

@[default_target]
lean_lib HexOrderedFn where

@[default_target]
lean_lib HexOrderedFnTheory where

@[default_target]
lean_lib HexOrderedFnTests where
  globs := #[.one `HexOrderedFn.Tests, .one `HexOrderedFnTheory.Tests,
    .one `HexOrderedFn.InfinitesimalTests, .one `HexOrderedFnTheory.InfinitesimalTests,
    .one `HexOrderedFn.ExtensionTests, .one `HexOrderedFnTheory.LiouvilleTests,
    .one `HexOrderedFnTheory.LintTests]

lean_lib HexMvPoly where

lean_lib HexGroebner where

lean_lib HexGroebnerNative where
  roots := #[`HexGroebnerNative]
  globs := #[.one `HexGroebnerNative, .one `HexGroebner.Native]
  precompileModules := true
  moreLinkObjs := #[hexgroebnerRowsO]

-- Matrix bindings import the row bindings, so they need a separate carrier.
lean_lib HexGroebnerMatrixNative where
  roots := #[`HexGroebnerMatrixNative]
  globs := #[.one `HexGroebnerMatrixNative, .one `HexGroebner.NativeScan,
    .one `HexGroebner.NativeGather]
  precompileModules := true
  moreLinkObjs := #[hexgroebnerScanO]

lean_lib HexGroebnerTrieNative where
  roots := #[`HexGroebnerTrieNative]
  globs := #[.one `HexGroebnerTrieNative, .one `HexGroebner.NativeTrie]
  precompileModules := true

@[default_target]
lean_lib HexRealFormula where

@[default_target]
lean_lib HexRealFormulaTheory where

lean_lib HexMvGcd where

@[default_target]
lean_lib HexGenericRank where

@[default_target]
lean_lib HexGenericRankTheory where

lean_lib HexReflect where

@[default_target]
lean_lib HexReflectTheory where

@[default_target]
lean_lib HexKronecker where

@[default_target]
lean_lib HexKroneckerTheory where

@[default_target]
lean_lib HexKroneckerTests where
  globs := #[.one `HexKroneckerTheory.Tests]

lean_lib HexSparsePoly where

lean_lib HexModArith where
  precompileModules := true

-- Carries `zmod64_mul.c` for the modules that bind it; see `HexArithNative`.
lean_lib HexModArithNative where
  roots := #[`HexModArithNative]
  globs := #[.one `HexModArithNative, .one `HexModArith.WordMod,
    .one `HexModArith.Residue]
  precompileModules := true
  moreLinkObjs := #[hexmodarithO]

lean_lib HexModular where

@[default_target]
lean_lib HexModularMatrix where

@[default_target]
lean_lib HexModularMatrixTheory where

lean_lib HexGF2 where
  precompileModules := true

lean_lib HexPolyZ where

lean_lib HexPolyZGcd where

@[default_target]
lean_lib HexRationalFn where

@[default_target]
lean_lib HexRationalFnTheory where

lean_lib HexRoots where

lean_lib HexResultant where

lean_lib HexNumberField where

lean_lib HexRealAlgebraic where

@[default_target]
lean_lib HexRealAlgebraicTheory where

@[default_target]
lean_lib HexRealAlgebraicTheoryTests where
  globs := #[.one `HexRealAlgebraicTheory.Tests]

lean_lib HexNumberFieldTower where

lean_lib HexPolyFp where
  precompileModules := true

lean_lib HexGFqRing where

lean_lib HexGFqField where

lean_lib HexBerlekamp where

lean_lib HexHensel where
  -- `WordPoly.mul` has a native convolution extern used by downstream
  -- interpreter-time guards, so its module dynlib must export the stub.
  precompileModules := true

lean_lib HexMvHensel where

lean_lib HexMvFactor where

lean_lib HexConway where

lean_lib HexGFq where

lean_lib HexPrimality

lean_lib HexECPP

lean_lib HexIntFactor where
  globs := #[`HexIntFactor, `HexIntFactor.Pari, `HexIntFactor.Export,
    `HexIntFactor.Replay, `HexIntFactor.Mixed.Replay, `HexIntFactor.Mixed.Import,
    `HexIntFactor.Mixed.Pari, `HexIntFactor.Mixed.Export,
    `HexIntFactor.Mixed.Frozen.Small].map Glob.one
  -- The registered construction provider must also execute natively.
  precompileModules := true

-- Large frozen ECPP endpoints have measured finite replay allocations.
lean_lib HexIntFactorMixedFrozen where
  roots := #[`HexIntFactor.Mixed.Frozen.CaseA, `HexIntFactor.Mixed.Frozen.CaseB,
    `HexIntFactor.Mixed.Frozen.Partial]

lean_lib HexIntFactorTests where
  globs := #[`HexIntFactor.ImportTests, `HexIntFactor.PariTests,
    `HexIntFactor.ExportTests, `HexIntFactor.Mixed.ImportTests,
    `HexIntFactor.Mixed.ExportTests,
    `HexIntFactor.Frozen.Case0,
    `HexIntFactor.Frozen.Case1,
    `HexIntFactor.Frozen.Case2,
    `HexIntFactor.Frozen.Case3,
    `HexIntFactor.Frozen.Case4,
    `HexIntFactor.Frozen.Case5,
    `HexIntFactor.Frozen.Case6, `HexIntFactor.Frozen.Partial12
    ].map Glob.one

lean_lib HexBerlekampZassenhaus where

lean_lib HexRealRoots where

@[default_target]
lean_lib HexSturm where

@[default_target]
lean_lib HexSignDet where

@[default_target]
lean_lib HexSignDetTheory where
  leanOptions := #[⟨`autoImplicit, false⟩]

lean_lib HexRealClosure where
  -- The runnable selected-root tests use `#eval` across the library boundary.
  precompileModules := true

@[default_target]
lean_lib HexRealClosureTests where
  globs := #[.one `HexRealClosure.Tests, .one `HexRealClosure.BaseJsonTests, .one `HexRealClosure.BaseHistoryTests, .one `HexRealClosure.PackingTests, .one `HexRealClosure.InversePackingTests, .one `HexRealClosure.ValueSignsTests, .one `HexRealClosure.RootOrderTests,
    .one `HexRealClosure.RootPolicyTests, .one `HexRealClosure.RootFactorsTests, .one `HexRealClosure.TowerRootsTests,
    .one `HexRealClosure.RootCollectionTests, .one `HexRealClosure.TowerPresentationTests,
    .one `HexRealClosure.LocalSampleTests, .one `HexRealClosure.LiveContextTests,
    .one `HexRealClosure.ReconciledGatherTests, .one `HexRealClosure.ReconciledBaseTests,
    .one `HexRealClosure.LiveRequestTests,
    .one `HexRealClosure.SignatureCodecTests,
    .one `HexRealClosure.TrivialTests, .one `HexRealClosure.TrivialTowerTests,
    .one `HexRealClosure.TowerEnlargeOrderTests,
    .one `HexRealClosure.BaseEvaluateTests, .one `HexRealClosure.BasePermutationTests,
    .one `HexRealClosure.TowerTransportTests, .one `HexRealClosure.BaseInclusionTests,
    .one `HexRealClosure.SharedBaseTests, .one `HexRealClosure.BaseReconciliationTests]

-- Native CI capacity probes for the actual certificate/context codecs.
lean_exe hexrealclosure_codec_bytes where
  srcDir := "conformance"
  root := `HexRealClosure.CodecBytesDriver

-- The deep fixture is type-checked above; only its execution is outside routine CI.
lean_exe hexrealclosure_transport_tests where
  root := `HexRealClosure.TowerTransportTests

@[default_target]
lean_lib HexRealClosureTheory where

@[default_target]
lean_lib HexRealClosureTheoryTests where
  globs := #[.one `HexRealClosureTheory.BaseTests,
    .one `HexRealClosureTheory.BaseSubsequenceTests,
    .one `HexRealClosureTheory.BaseStagedReorderTests,
    .one `HexRealClosureTheory.ReprProviderData,
    .one `HexRealClosureTheory.ReprProviderTests]

@[default_target]
lean_lib HexSturmTheory where

@[default_target]
lean_lib HexSturmTheoryTests where
  globs := #[.one `HexSturmTheory.Tests,
    .one `HexSturmTheory.Tests.Replay.Accepted,
    .one `HexSturmTheory.Tests.Replay.Rejected,
    .one `HexSturmTheory.Tests.Replay.Baseline,
    .one `HexSturmTheory.LintTests]

lean_lib HexInterval where

@[default_target]
lean_lib HexPolyTheory where

@[default_target]
lean_lib HexGroebnerTheory where
  roots := #[`HexGroebnerTheory, `HexGroebnerTheory.Examples, `HexGroebnerTheory.MemberExample, `HexGroebnerTheory.DivisionExample, `HexGroebnerTheory.GeneratedExample, `HexGroebnerTheory.PolynomialExample, `HexGroebnerTheory.Audit]

@[default_target]
lean_lib HexMvPolyTheory where

@[default_target]
lean_lib HexSparsePolyTheory where

@[default_target]
lean_lib HexModArithTheory where

@[default_target]
lean_lib HexPolyZTheory where

@[default_target]
lean_lib HexPolyZGcdTheory where

@[default_target]
lean_lib HexRootsTheory where

@[default_target]
lean_lib HexResultantTheory where

@[default_target]
lean_lib HexNumberFieldTheory where

@[default_target]
lean_lib HexNumberFieldTowerTheory where

@[default_target]
lean_lib HexPolyFpTheory where

lean_lib HexBerlekampTheory where

@[default_target]
lean_lib HexHenselTheory where

@[default_target]
lean_lib HexGF2Theory where

@[default_target]
lean_lib HexGFqTheory where

@[default_target]
lean_lib HexBerlekampZassenhausTheory where

@[default_target]
lean_lib HexPrimalityTheory where

lean_lib HexECPPTheory where
  roots := #[`HexECPPTheory, `HexECPPTheory.Native, `HexECPPTheory.Pari]

-- Lake selects the last matching library. Keep the Mathlib-free IO sidecar
-- after the bridge so only this module needs a shared native library.
lean_lib HexECPPTheoryPariIO where
  roots := #[`HexECPPTheory.Pari.IO]
  globs := #[.one `HexECPPTheory.Pari.IO]
  precompileModules := true
  moreLinkObjs := #[hexecpppariio]

-- Only the optional producer's interruptible pipe module needs native IO.
lean_lib HexIntFactorPariIO where
  roots := #[`HexIntFactor.Pari.IO]
  globs := #[.one `HexIntFactor.Pari.IO]
  precompileModules := true
  moreLinkObjs := #[hexintfactorpariio]

-- The release aggregate also builds these modules. Its manifest equality
-- check requires that registration; all owners use the same Lean settings.
lean_lib HexECPPTheoryTests where
  globs := #[.one `HexECPPTheory.Tests, .one `HexECPPTheory.LintTests]

@[default_target]
lean_lib HexIntFactorTheory where
  roots := #[`HexIntFactorTheory, `HexIntFactorTheory.Mixed]

lean_lib HexMatrix

-- Native compilation accelerates the producer. Consumers whose artifact cache
-- does not distribute native libraries can set `hexPermGroupNative=false`.
@[default_target]
lean_lib HexPermGroup where
  precompileModules := get_config? hexPermGroupNative != some "false"

@[default_target]
lean_lib HexPermGroupTheory where

@[default_target]
lean_lib HexPermGroupTests where
  globs := #[.one `HexPermGroup.Tests, .one `HexPermGroup.CertificateTests,
    .one `HexPermGroup.ImportTests,
    .one `HexPermGroupTheory.Tests, .one `HexPermGroupTheory.CertificateTests,
    .one `HexPermGroupTheory.TacticTests]

lean_lib HexGraph where

lean_lib HexGraphIso

@[default_target]
lean_lib HexGraphIsoTheory where

lean_lib HexCharPoly where
  precompileModules := true

lean_lib HexMinPoly where

lean_lib HexPolySmith where

@[default_target]
lean_lib HexPolySmithTheory where

lean_lib HexRowReduce

lean_lib HexPosDef

@[default_target]
lean_lib HexPosDefTheory

@[default_target]
lean_lib HexPosDefTheoryTests where
  globs := #[`HexPosDefTheory.Tests].map Glob.one

@[default_target]
lean_lib HexPosDefTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexPosDefTheory.ProofProbe.E8, `HexPosDefTheory.ProofProbe.Gram8,
    `HexPosDefTheory.ProofProbe.Gram16, `HexPosDefTheory.ProofProbe.Gram32].map Glob.one

lean_lib HexDeterminant

lean_lib HexBareiss

lean_lib HexDeterminantalIdeal where

lean_lib HexDet where

lean_lib HexRank where
  precompileModules := true

lean_lib HexHermite where
  precompileModules := true

lean_lib HexSmith where
  precompileModules := true

lean_lib HexHermiteTheory where

lean_lib HexSmithTheory where

lean_lib HexGramSchmidt where

lean_lib HexLatticeEnum where

@[default_target]
lean_lib HexLatticeEnumTheory where

@[default_target]
lean_lib HexLatticeEnumTests where
  globs := #[`HexLatticeEnumTheory.Tests, `HexLatticeEnumTheory.LintTests]

lean_lib HexLLL where
  precompileModules := true
  extraDepTargets := #[`hexlllffi]
  -- `dlopen` lives in libdl on Linux, in libc on macOS, and is absent on
  -- Windows, where the provider uses LoadLibrary instead.
  moreLinkArgs :=
    if System.Platform.isOSX || System.Platform.isWindows then
      #[]
    else
      #["-ldl"]

@[default_target]
lean_lib HexMatrixTheory where

@[default_target]
lean_lib HexCharPolyTheory where

@[default_target]
lean_lib HexMinPolyTheory where

@[default_target]
lean_lib HexRowReduceTheory where

@[default_target]
lean_lib HexDeterminantTheory where

@[default_target]
lean_lib HexDeterminantalIdealTheory where

@[default_target]
lean_lib HexDeterminantalIdealTests where
  globs := #[`HexDeterminantalIdealTheory.Tests]

@[default_target]
lean_lib HexPolyDet where

@[default_target]
lean_lib HexPolyDetTheory where

lean_lib HexPolyDetTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexPolyDetTheory.ProofProbe.Numeric2Hex,
    `HexPolyDetTheory.ProofProbe.Symbolic2Hex,
    `HexPolyDetTheory.ProofProbe.Quotient2Hex,
    `HexPolyDetTheory.ProofProbe.ResultNumeric2Hex,
    `HexPolyDetTheory.ProofProbe.ResultSymbolic2Hex,
    `HexPolyDetTheory.ProofProbe.OriginalQuadratic4,
    `HexPolyDetTheory.ProofProbe.RankOne10].map Glob.one

@[default_target]
lean_lib HexBareissTheory where

lean_lib HexBareissTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexBareissTheory.ProofProbe.Baseline,
    `HexBareissTheory.ProofProbe.MathlibBaseline,
    `HexBareissTheory.ProofProbe.Dense8Hex,
    `HexBareissTheory.ProofProbe.Dense8Mathlib,
    `HexBareissTheory.ProofProbe.Dense12Hex,
    `HexBareissTheory.ProofProbe.Dense12Mathlib,
    `HexBareissTheory.ProofProbe.Dense16Hex,
    `HexBareissTheory.ProofProbe.Dense16Mathlib,
    `HexBareissTheory.ProofProbe.Dense32Hex,
    `HexBareissTheory.ProofProbe.Tridiagonal16Hex,
    `HexBareissTheory.ProofProbe.Tridiagonal16Mathlib,
    `HexBareissTheory.ProofProbe.Vandermonde8Hex,
    `HexBareissTheory.ProofProbe.Vandermonde8Mathlib,
    `HexBareissTheory.ProofProbe.Singular16Hex,
    `HexBareissTheory.ProofProbe.Singular16Mathlib,
    `HexBareissTheory.ProofProbe.Large8Bits64Hex,
    `HexBareissTheory.ProofProbe.Large8Bits64Mathlib,
    `HexBareissTheory.ProofProbe.Large4Bits256Hex,
    `HexBareissTheory.ProofProbe.Large4Bits256Mathlib,
    `HexBareissTheory.ProofProbe.Rational8Hex,
    `HexBareissTheory.ProofProbe.Rational8Mathlib]

@[default_target]
lean_lib HexDetTheory where

lean_lib HexRankTheory where

@[default_target]
lean_lib HexRankTests where
  globs := #[`HexRankTheory.Tests, `HexRankTheory.NumberFieldTests]

@[default_target]
lean_lib HexGenericRankTests where
  globs := #[`HexGenericRankTheory.Tests]

lean_lib HexDeterminantalIdealTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexDeterminantalIdealTheory.ProofProbe.Full2R1,
    `HexDeterminantalIdealTheory.ProofProbe.Full2R2,
    `HexDeterminantalIdealTheory.ProofProbe.Low2R1].map Glob.one

lean_lib HexGenericRankTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexGenericRankTheory.ProofProbe.VariableGeneric,
    `HexGenericRankTheory.ProofProbe.VariableHypothesis,
    `HexGenericRankTheory.ProofProbe.VariableSideGoal,
    `HexGenericRankTheory.ProofProbe.FiniteGeneric].map Glob.one

lean_lib HexRankTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexRankTheory.ProofProbe.Dense8Hex,
    `HexRankTheory.ProofProbe.Deficient16Hex,
    `HexRankTheory.ProofProbe.Rational8Hex,
    `HexRankTheory.ProofProbe.Quadratic8Hex,
    `HexRankTheory.ProofProbe.Algebraic8Hex,
    `HexRankTheory.ProofProbe.NumberFieldSupport].map Glob.one

@[default_target]
lean_lib HexGramSchmidtTheory where

@[default_target]
lean_lib HexLLLTheory where

@[default_target]
lean_lib HexRealRootsTheory where

@[default_target]
lean_lib HexRCF where

-- Optional development adapter: its shared frontend is not yet published.
@[default_target]
lean_lib HexRCFRealFormula where
  srcDir := "adapters"
  globs := #[`HexRCF.RealFormula]

@[default_target]
lean_lib HexRCFRealCoefficients where
  srcDir := "adapters"
  globs := #[`HexRCF.RealCoefficients.FieldSelection, `HexRCF.RealCoefficients.SourceSelection, `HexRCF.RealCoefficients.RootQuote, `HexRCF.RealCoefficients.RationalQuote, `HexRCF.RealCoefficients.ScalarQuote, `HexRCF.RealCoefficients.ScalarPacketQuote,
    `HexRCF.RealCoefficients.RowOperations, `HexRCF.RealCoefficients.CellReuse, `HexRCF.RealCoefficients.CellPackets,
    `HexRCF.RealCoefficients.CellOperations, `HexRCF.RealCoefficients.CompleteReplay, `HexRCF.RealCoefficients.RootTableCodec, `HexRCF.RealCoefficients.RootCodec, `HexRCF.RealCoefficients.CellFootprint, `HexRCF.RealCoefficients.CellEncode, `HexRCF.RealCoefficients.CellCodec, `HexRCF.RealCoefficients.SectorEncode, `HexRCF.RealCoefficients.CellPacketRead, `HexRCF.RealCoefficients.CellPacketConvert,
    `HexRCF.RealCoefficients.CellPacketTransport, `HexRCF.RealCoefficients.RepresentationCarrier, `HexRCF.RealCoefficients.RootCells, `HexRCF.RealCoefficients.RepresentationCells, `HexRCF.RealCoefficients.BoundarySigns, `HexRCF.RealCoefficients.SectorSamples, `HexRCF.RealCoefficients.PointRows, `HexRCF.RealCoefficients.CellReplay, `HexRCF.RealCoefficients.RowReplay, `HexRCF.RealCoefficients.SectorReplay, `HexRCF.RealCoefficients.CellRead, `HexRCF.RealCoefficients.CellBuild, `HexRCF.RealCoefficients.CellDiscover, `HexRCF.RealCoefficients.CellAlignment, `HexRCF.RealCoefficients.SectorRequest, `HexRCF.RealCoefficients.CellProgress, `HexRCF.RealCoefficients.CellDecision, `HexRCF.RealCoefficients.CellExecution, `HexRCF.RealCoefficients.NumberFieldCells, `HexRCF.RealCoefficients.RowEncode, `HexRCF.RealCoefficients.CellQuote, `HexRCF.RealCoefficients, `HexRCF.RealCoefficients.Reify,
    `HexRCF.RealCoefficients.Specialize, `HexRCF.RealCoefficients.Coefficients,
    `HexRCF.RealCoefficients.RootAliases, `HexRCF.RealCoefficients.Conversion,
    `HexRCF.RealCoefficients.AlgebraicPreparation, `HexRCF.RealCoefficients.RealModel,
    `HexRCF.RealCoefficients.Interpret,
    `HexRCF.RealCoefficients.Formula, `HexRCF.RealCoefficients.Field,
    `HexRCF.RealCoefficients.LiteralSign, `HexRCF.RealCoefficients.SignIndex,
    `HexRCF.RealCoefficients.FieldIndex,
    `HexRCF.RealCoefficients.IntervalSign, `HexRCF.RealCoefficients.SquareRoot,
    `HexRCF.RealCoefficients.CommonTactic,
    `HexRCF.RealCoefficients.CommonPresentation, `HexRCF.RealCoefficients.SourceIdentity,
    `HexRCF.RealCoefficients.FieldSpecialize,
    `HexRCF.RealCoefficients.RepresentationSpecialize,
    `HexRCF.RealCoefficients.Samples, `HexRCF.RealCoefficients.Gather, `HexRCF.RealCoefficients.GatherCells, `HexRCF.RealCoefficients.AlgebraicCells,
    `HexRCF.RealCoefficients.RegisteredGather, `HexRCF.RealCoefficients.ReconciledGather,
    `HexRCF.RealCoefficients.SelectedFormula,
    `HexRCF.RealCoefficients.InverseReplay,
    `HexRCF.RealCoefficients.SelectedBytes,
    `HexRCF.RealCoefficients.Realization, `HexRCF.RealCoefficients.NativeFormula,
    `HexRCF.RealCoefficients.NativeSpecialize,
    `HexRCF.RealCoefficients.NativeSamples,
    `HexRCF.RealCoefficients.NativeSources,
    `HexRCF.RealCoefficients.NativeSelection,
    `HexRCF.RealCoefficients.SectionReplay, `HexRCF.RealCoefficients.ScalarPacket,
    `HexRCF.RealCoefficients.SectionBuild, `HexRCF.RealCoefficients.SectionQuote,
    `HexRCF.RealCoefficients.PointReplay, `HexRCF.RealCoefficients.PointBuild,
    `HexRCF.RealCoefficients.PointQuote, `HexRCF.RealCoefficients.Quote,
    `HexRCF.RealCoefficients.RootReplay, `HexRCF.RealCoefficients.RootBuild, `HexRCF.RealCoefficients.RootTable,
    `HexRCF.RealCoefficients.RootTransport,
    `HexRCF.RealCoefficients.NumberField,
    `HexRCF.RealCoefficients.SignInputs,
    `HexRCF.RealCoefficients.FieldCarrier, `HexRCF.RealCoefficients.Carrier,
    `HexRCF.RealCoefficients.IsolationCheck, `HexRCF.RealCoefficients.Isolations,
    `HexRCF.RealCoefficients.IsolationBuild, `HexRCF.RealCoefficients.IsolationSemantics,
    `HexRCF.RealCoefficients.IsolationAssembly, `HexRCF.RealCoefficients.IsolationProgress,
    `HexRCF.RealCoefficients.RadicalCheck, `HexRCF.RealCoefficients.Radical,
    `HexRCF.RealCoefficients.RadicalBuild, `HexRCF.RealCoefficients.RadicalProgress,
    `HexRCF.RealCoefficients.FieldDecision, `HexRCF.RealCoefficients.FieldIsolate,
    `HexRCF.RealCoefficients.FieldBuild, `HexRCF.RealCoefficients.FieldSignProgress,
    `HexRCF.RealCoefficients.FieldBuildProgress,
    `HexRCF.RealCoefficients.FieldRoots,
    `HexRCF.RealCoefficients.FieldDecisionProgress,
    `HexRCF.RealCoefficients.FieldBuildBudget,
    `HexRCF.RealCoefficients.FieldRootSigns, `HexRCF.RealCoefficients.FieldRootSignsProgress,
    `HexRCF.RealCoefficients.FieldReplay,
    `HexRCF.RealCoefficients.FieldRefinement,
    `HexRCF.RealCoefficients.FieldLiteral,
    `HexRCF.RealCoefficients.FieldRuntime,
    `HexRCF.RealCoefficients.Preparation,
    `HexRCF.RealCoefficients.FiniteReplay, `HexRCF.RealCoefficients.FiniteSigns,
    `HexRCF.RealCoefficients.FiniteQuote,
    `HexRCF.RealCoefficients.Replay, `HexRCF.RealCoefficients.FieldCompile,
    `HexRCF.RealCoefficients.SquareTwo,
    `HexRCF.RealCoefficients.CubeTwo,
    `HexRCF.RealCoefficients.Selected,
    `HexRCF.RealCoefficients.Tactic,
    `HexRCF.RealCoefficients.CellFormula,
    `HexRCF.RealCoefficients.Registration,
    `HexRCF.RealCoefficients.AlgebraicBounds,
    `HexRCF.RealCoefficients.RationalRoot,
    `HexRCF.RealCoefficients.AlgebraicRoot,
    `HexRCF.RealCoefficients.Finite].map Glob.one

-- Semantic results connecting accepted queries to roots and selected values.
@[default_target]
lean_lib HexQuerySemantics where
  srcDir := "adapters"
  globs := #[`HexSturmTheory.Tests.Replay.Semantics,
    `HexSturmTheory.Tests.Replay.SemanticsBaseline,
    `HexRealClosureTheory.Specialize, `HexRealClosureTheory.SpecializeTests,
    `HexRealClosureTheory.SignFacts, `HexRealClosureTheory.SignRequests,
    `HexRealClosureTheory.SignEvidence, `HexRealClosureTheory.FactReplay,
    `HexRealClosureTheory.KernelReplay, `HexRealClosureTheory.NativePackets,
    `HexRealClosureTheory.NativeModels, `HexRealClosureTheory.SignReplay, `HexRealClosureTheory.NativeReplay, `HexRealClosureTheory.NativeValues, `HexRealClosureTheory.NativeRecords, `HexRealClosureTheory.NativeFactory, `HexRealClosureTheory.NativeCodecs, `HexRealClosureTheory.NativeReaders, `HexRealClosureTheory.NativeAssembly, `HexRealClosureTheory.NativeAssemblyModels,
    `HexRealClosureTheory.Packing, `HexRealClosureTheory.InversePacking, `HexRealClosureTheory.InverseEquation, `HexRealClosureTheory.SuppliedInverse, `HexRealClosureTheory.PackingArithmetic, `HexRealClosureTheory.ValueSigns, `HexRealClosureTheory.FinitePoint,
    `HexRealClosureTheory.PackingQuery, `HexRealClosureTheory.PackingMoment, `HexRealClosureTheory.PackingReduction, `HexRealClosureTheory.PackingReplay, `HexRealClosureTheory.FiniteRead, `HexRealClosureTheory.BaseFinite, `HexRealClosureTheory.PackingInventory, `HexRealClosureTheory.BaseFiniteReplay, `HexRealClosureTheory.FiniteData, `HexRealClosureTheory.FiniteSupport, `HexRealClosureTheory.FiniteBatch, `HexRealClosureTheory.NativeBatch, `HexRealClosureTheory.FiniteOperands, `HexRealClosureTheory.FiniteLift, `HexRealClosureTheory.FiniteScalars, `HexRealClosureTheory.FiniteIndex, `HexRealClosureTheory.FiniteLists, `HexRealClosureTheory.FiniteBase, `HexRealClosureTheory.FiniteDependencies, `HexRealClosureTheory.FiniteConditions, `HexRealClosureTheory.FiniteReconstruction, `HexRealClosureTheory.FiniteChain, `HexRealClosureTheory.PackingNext,
    `HexRealClosureTheory.TransportPolynomial, `HexRealClosureTheory.TransportProduct,
    `HexRealClosureTheory.TransportArithmetic, `HexRealClosureTheory.TransportQuery, `HexRealClosureTheory.TransportTests,
    `HexRealClosureTheory.TransportPower, `HexRealClosureTheory.TransportTarski,
    `HexRealClosureTheory.TransportRing,
    `HexRealClosureTheory.TransportClosed, `HexRealClosureTheory.TransportClosedQuery, `HexRealClosureTheory.TransportClosedReduction, `HexRealClosureTheory.TransportRegular,
    `HexRealClosureTheory.TransportReduction, `HexRealClosureTheory.TransportPreparation, `HexRealClosureTheory.TransportMoment, `HexRealClosureTheory.TransportReplay, `HexRealClosureTheory.TransportSample, `HexRealClosureTheory.TransportDescriptor, `HexRealClosureTheory.TransportInventory, `HexRealClosureTheory.TransportSelected, `HexRealClosureTheory.TransportFiniteTests,
    `HexRealClosureTheory.AlgebraicTransport, `HexRealClosureTheory.AlgebraicYun,
    `HexRealClosureTheory.AlgebraicReencode,
    `HexRealClosureTheory.AlgebraicRoots,
    `HexRealClosureTheory.SpecializePolynomial, `HexRealClosureTheory.SpecializeRegular, `HexRealClosureTheory.SpecializeQuery, `HexRealClosureTheory.SpecializeTarski,
    `HexRealClosureTheory.SpecializeReduction,
    `HexRealClosureTheory.SpecializeMoment,
    `HexRealClosureTheory.SpecializeReplay,
    `HexRealClosureTheory.SpecializeNested,
    `HexRealClosureTheory.SpecializeFractionRing,
    `HexRealClosureTheory.MonicEvaluation,
    `HexRealClosureTheory.RegularEvaluation,
    `HexRealClosureTheory.ModelEvaluation,
    `HexRealClosureTheory.AlgebraicEvaluation, `HexRealClosureTheory.ModelInventory,
    `HexRealClosureTheory.SuffixEvaluation,
    `HexRealClosureTheory.StagedEvaluation,
    `HexRealClosureTheory.BaseEvaluation,
    `HexRealClosureTheory.NativeRealization,
    `HexRealClosureTheory.SharedRealization,
    `HexRealClosureTheory.SharedRealizationTests,
    `HexRealClosureTheory.NativeRealizationTests,
    `HexRealClosureTheory.CoefficientMap, `HexRealClosureTheory.CoefficientComposition,
    `HexRealClosureTheory.CoefficientQuery,
    `HexRealClosureTheory.CoefficientTarski,
    `HexRealClosureTheory.CoefficientEmbeddingTests,
    `HexRealClosureTheory.CoefficientEmbedding,
    `HexRealClosureTheory.CoefficientSelected,
    `HexRealClosureTheory.CoefficientDescriptor,
    `HexRealClosureTheory.CoefficientReplay,
    `HexRealClosureTheory.CoefficientMoment,
    `HexRealClosureTheory.CoefficientReduction,
    `HexRealClosureTheory.SpecializeSample,
    `HexRealClosureTheory.SpecializeSelected,
    `HexRealClosureTheory.SpecializeDescriptor,
    `HexRealClosureTheory.Algebraic, `HexRealClosureTheory.AlgebraicClean,
    `HexRealClosureTheory.TowerModel, `HexRealClosureTheory.TowerModelTests,
    `HexRealClosureTheory.BaseModel,
    `HexRealClosureTheory.BaseOrder,
    `HexRealClosureTheory.BaseMapModel,
    `HexRealClosureTheory.BaseReconciliationModel,
    `HexRealClosureTheory.BaseReconstruction,
    `HexRealClosureTheory.BaseReconstructionTests,
    `HexRealClosureTheory.ReconciledContext,
    `HexRealClosureTheory.ReconciledGatherModel,
    `HexRealClosureTheory.ReconciledGatherTests,
    `HexRealClosureTheory.ReconciledLive,
    `HexRealClosureTheory.ReconciledEnlargementTests,
    `HexRealClosureTheory.ReconciledRealization,
    `HexRealClosureTheory.ReconciledRealizationTests,
    `HexRealClosureTheory.ReconciledCatalog,
    `HexRealClosureTheory.ConstructedCatalog,
    `HexRealClosureTheory.BaseHistoryTests,
    `HexRealClosureTheory.ReconciledCatalogTests,
    `HexRealClosureTheory.OwnerReader,
    `HexRealClosureTheory.BaseFactory,
    `HexRealClosureTheory.ContextModel,
    `HexRealClosureTheory.BaseFactoryTests, `HexRealClosureTheory.BaseGatherTests,
    `HexRealClosureTheory.CacheModels,
    `HexRealClosureTheory.CacheRebuild,
    `HexRealClosureTheory.CacheGather,
    `HexRealClosureTheory.GatherTests,
    `HexRealClosureTheory.SharedPresentation,
    `HexRealClosureTheory.SharedPresentationTests,
    `HexRealClosureTheory.TowerAlgebraic, `HexRealClosureTheory.TowerRefinement,
    `HexRealClosureTheory.TowerTransport, `HexRealClosureTheory.TowerTransportTests,
    `HexRealClosureTheory.TowerReuse,
    `HexRealClosureTheory.TowerInclusion, `HexRealClosureTheory.LiveContext,
    `HexRealClosureTheory.LiveRequest, `HexRealClosureTheory.LiveRequestTests,
    `HexRealClosureTheory.TowerYun,
    `HexRealClosureTheory.AlgebraicValue, `HexRealClosureTheory.BaseClean, `HexRealClosureTheory.AlgebraicTower,
    `HexRealClosureTheory.SelectedRoot,
    `HexRealClosureTheory.Canonical, `HexRealClosureTheory.Element, `HexRealClosureTheory.QAdjoin,
    `HexRealClosureTheory.NumberField, `HexRealClosureTheory.NumberFieldTower,
    `HexRealClosureTheory.Polynomial, `HexRealClosureTheory.Yun,
    `HexRealClosureTheory.YunInvariant, `HexRealClosureTheory.Bounds,
    `HexRealClosureTheory.Deflation, `HexRealClosureTheory.Bisection,
    `HexRealClosureTheory.BisectionRoots, `HexRealClosureTheory.BisectionFrontier,
    `HexRealClosureTheory.BisectionCounts, `HexRealClosureTheory.Isolation,
    `HexRealClosureTheory.BisectionFactor, `HexRealClosureTheory.IsolationFactor,
    `HexRealClosureTheory.TowerRootPolicy, `HexRealClosureTheory.RootPolicy, `HexRealClosureTheory.IsolationPolicy,
    `HexRealClosureTheory.ZeroFactor, `HexRealClosureTheory.IsolationRoots,
    `HexRealClosureTheory.IsolationTotal,
    `HexRealClosureTheory.RootIntervals, `HexRealClosureTheory.RootOrder,
    `HexRealClosureTheory.RootFactors,
    `HexRealClosureTheory.Trivial, `HexRealClosureTheory.TrivialTower, `HexRealClosureTheory.TrivialTowerTests,
    `HexRealClosureTheory.RootTotal, `HexRealClosureTheory.TowerRoots,
    `HexRealClosureTheory.RootTransport,
    `HexRealClosureTheory.RootCollection, `HexRealClosureTheory.RootList,
    `HexRealClosureTheory.Sample, `HexRealClosureTheory.LocalSample,
    `HexRealClosureTheory.LocalSampleTests,
    `HexRealClosureTheory.SampleTests,
    `HexRealClosureTheory.TowerCoverage, `HexRealClosureTheory.Presentation,
    `HexRealClosureTheory.PresentationTests,
    `HexRealClosureTheory.TowerNaturality,
    `HexRealClosureTheory.Ambient, `HexRealClosureTheory.AmbientTests,
    `HexRealClosureTheory.BaseAlgebraicity, `HexRealClosureTheory.BaseBound,
    `HexRealClosureTheory.EnlargementTests,
    `HexRealClosureTheory.Union, `HexRealClosureTheory.TowerUnion,
    `HexRealClosureTheory.TowerRestriction, `HexRealClosureTheory.TowerEnlarge,
    `HexRealClosureTheory.TowerEnlargeOrder, `HexRealClosureTheory.TowerEnlargeOrderTests,
    `HexRealClosureTheory.UnionTests].map Glob.one

lean_exe hexrealclosure_root_order_tests where
  root := `HexRealClosure.RootOrderTests

-- Ordinary-import consumers of merged family APIs, also built as an isolated
-- local downstream project in experiments/RealClosureConsumer.
@[default_target]
lean_lib RealClosureConsumer where
  srcDir := "examples"
  globs := #[.submodules `RealClosureConsumer]

lean_exe hexlll_external_reduction where
  root := `HexLLL.ExternalReduction

-- Multi-file bench drivers: their modules live under `bench/` and are owned by
-- a precompiled lean_lib (mirroring the released bench sub-project), so the bench
-- exes can root into them. Single-file bench drivers instead carry
-- `srcDir := "bench"` on their own `lean_exe`.
lean_lib HexLLLBenchSupport where
  srcDir := "bench"
  globs := #[`HexLLLBench, `HexLLLBench.Inputs, `HexLLLBench.Targets]

lean_lib HexRankBenchSupport where
  srcDir := "bench"
  globs := #[`HexRank.Bench.Quotient]

lean_lib HexGF2BenchSupport where
  srcDir := "bench"
  globs := #[`HexGF2.Bench]

lean_lib HexBerlekampKernelProbe where
  srcDir := "bench"
  globs := #[`HexBench.BerlekampKernel]

lean_lib HexPrimalityKernelProbe where
  srcDir := "bench"
  globs := #[`HexPrimalityBench.Inputs, `HexBench.PrimalityKernel,
    `HexPrimality.PMinusOneFixtures, `HexIntFactor.PMinusOneFixtures,
    `HexPrimality.PMinusOneMeasure, `HexPrimality.PMinusOneParents].map Glob.one ++
    -- Computational diagnostics emit no proof and observe clocks/counters.
    #[.submodules `HexPrimality.EcmDiagnostics]

lean_lib HexPrimalityElabProbe where
  srcDir := "bench"
  globs := #[`HexPrimalityBench.Inputs, `HexPrimality.ProofProbe.Support,
    `HexPrimality.ProofProbe.CoreBaseline,
    `HexPrimality.ProofProbe.Core512,
    `HexPrimality.ProofProbe.CoreExhausted,
    `HexPrimality.ProofProbe.CoreOverBudget,
    `HexIntFactor.ProofProbe.PrimalityExhausted,
    `HexPrimalityTheory.ProofProbe.MathlibBaseline,
    `HexPrimalityTheory.ProofProbe.Mathlib512,
    `HexPrimalityTheory.ProofProbe.MathlibExhausted,
    `HexPrimalityTheory.ProofProbe.MathlibOverBudget,
    `HexPrimalityTheory.ProofProbe.Negative25,
    `HexPrimalityTheory.ProofProbe.Negative32,
    `HexPrimalityTheory.ProofProbe.Negative64,
    `HexPrimalityTheory.ProofProbe.Negative64Null,
    `HexPrimalityTheory.ProofProbe.Negative65,
    `HexPrimalityTheory.ProofProbe.Negative512,
    `HexPrimalityTheory.ProofProbe.Negative512Odd,
    `HexPrimalityTheory.ProofProbe.NegativeExhausted512]

lean_lib HexPrimalityTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexPrimalityTheory.ProofProbe.Support,
    `HexPrimalityTheory.ProofProbe.FactorExperiment,
    `HexPrimalityTheory.ProofProbe.Baseline,
    `HexPrimalityTheory.ProofProbe.Input31,
    `HexPrimalityTheory.ProofProbe.Literal31,
    `HexPrimalityTheory.ProofProbe.Reify31,
    `HexPrimalityTheory.ProofProbe.Replay31,
    `HexPrimalityTheory.ProofProbe.Primality31,
    `HexPrimalityTheory.ProofProbe.Input512,
    `HexPrimalityTheory.ProofProbe.Literal512,
    `HexPrimalityTheory.ProofProbe.Reify512,
    `HexPrimalityTheory.ProofProbe.Replay512,
    `HexPrimalityTheory.ProofProbe.Primality512,
    `HexPrimalityTheory.ProofProbe.NormNumTrial,
    `HexPrimalityTheory.ProofProbe.NormNumThreshold,
    `HexPrimalityTheory.ProofProbe.NormNum512,
    `HexPrimalityTheory.ProofProbe.MathlibBaseline,
    `HexPrimalityTheory.ProofProbe.Mathlib512,
    `HexPrimalityTheory.ProofProbe.MathlibExhausted,
    `HexPrimalityTheory.ProofProbe.MathlibOverBudget,
    `HexPrimalityTheory.ProofProbe.Negative25,
    `HexPrimalityTheory.ProofProbe.Negative32,
    `HexPrimalityTheory.ProofProbe.Negative64,
    `HexPrimalityTheory.ProofProbe.Negative64Null,
    `HexPrimalityTheory.ProofProbe.Negative65,
    `HexPrimalityTheory.ProofProbe.Negative512,
    `HexPrimalityTheory.ProofProbe.Negative512Odd,
    `HexPrimalityTheory.ProofProbe.Adoption,
    `HexPrimalityTheory.ProofProbe.NegativeExhausted512].map Glob.one ++
    #[.submodules `HexPrimalityTheory.ProofProbe.FactorCorpus]

lean_lib HexECPPTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexECPPTheory.ProofProbe.NativeGeneration,
    `HexECPPTheory.ProofProbe.Native512Baseline,
    `HexECPPTheory.ProofProbe.Native512Reify,
    `HexECPPTheory.ProofProbe.Native512Direct,
    `HexECPPTheory.ProofProbe.Native128_0,
    `HexECPPTheory.ProofProbe.NativeBaseline,
    `HexECPPTheory.ProofProbe.NativeReify,
    `HexECPPTheory.ProofProbe.NativeDirect,
    `HexECPPTheory.ProofProbe.NativeHoldout,
    `HexECPPTheory.ProofProbe.NativeValidation,
    `HexECPPTheory.ProofProbe.NativeUpdated,
    `HexECPPTheory.ProofProbe.Native256_0,
    `HexECPPTheory.ProofProbe.Native256_1,
    `HexECPPTheory.ProofProbe.Native256_2,
    `HexECPPTheory.ProofProbe.Support,
    `HexECPPTheory.ProofProbe.Support17,
    `HexECPPTheory.ProofProbe.Ecpp17,
    `HexECPPTheory.ProofProbe.Pock17,
    `HexECPPTheory.ProofProbe.Baseline65,
    `HexECPPTheory.ProofProbe.Reify65,
    `HexECPPTheory.ProofProbe.Direct65,
    `HexECPPTheory.ProofProbe.Replay65,
    `HexECPPTheory.ProofProbe.Replay256,
    `HexECPPTheory.ProofProbe.Replay512].map Glob.one

lean_lib HexPrimalityConstructionProbe where
  srcDir := "bench"
  globs := #[.submodules `HexPrimality.ProofProbe.Curve25519]

lean_lib HexPrimalityElabProbeScientific where
  srcDir := "bench"
  globs := #[`HexPrimalityBench.Inputs, `HexPrimality.ProofProbe.Support,
    `HexPrimality.ProofProbe.CoreBaseline,
    `HexPrimality.ProofProbe.Bit31.Input,
    `HexPrimality.ProofProbe.Bit31.Search,
    `HexPrimality.ProofProbe.Bit31.Literal,
    `HexPrimality.ProofProbe.Bit31.Replay,
    `HexPrimality.ProofProbe.Bit31.Tactic,
    `HexPrimality.ProofProbe.Bit61.Input,
    `HexPrimality.ProofProbe.Bit61.Search,
    `HexPrimality.ProofProbe.Bit61.Literal,
    `HexPrimality.ProofProbe.Bit61.Replay,
    `HexPrimality.ProofProbe.Bit61.Tactic,
    `HexPrimality.ProofProbe.Bit123.Input,
    `HexPrimality.ProofProbe.Bit123.Search,
    `HexPrimality.ProofProbe.Bit123.Literal,
    `HexPrimality.ProofProbe.Bit123.Replay,
    `HexPrimality.ProofProbe.Bit123.Tactic,
    `HexPrimality.ProofProbe.Bit256.Input,
    `HexPrimality.ProofProbe.Bit256.Search,
    `HexPrimality.ProofProbe.Bit256.Literal,
    `HexPrimality.ProofProbe.Bit256.Replay,
    `HexPrimality.ProofProbe.Bit256.Tactic,
    `HexPrimality.ProofProbe.Bit511.Input,
    `HexPrimality.ProofProbe.Bit511.Search,
    `HexPrimality.ProofProbe.Bit511.Literal,
    `HexPrimality.ProofProbe.Bit511.Replay,
    `HexPrimality.ProofProbe.Bit511.Tactic,
    `HexPrimality.ProofProbe.Bit512.Input,
    `HexPrimality.ProofProbe.Bit512.Search,
    `HexPrimality.ProofProbe.Bit512.Literal,
    `HexPrimality.ProofProbe.Bit512.Replay,
    `HexPrimality.ProofProbe.Bit512.Tactic].map Glob.one ++ #[.submodules `HexPrimality.ProofProbe.PMinusOne]

-- Explicit companion probes for large mixed frozen data.
lean_lib HexIntFactorTheoryProofProbe where
  srcDir := "bench"
  globs := #[Glob.one `HexIntFactorTheory.ProofProbe.Mixed]

lean_lib HexIntFactorTheoryTests where
  globs := #[Glob.one `HexIntFactorTheory.MixedTests]

lean_lib HexIntFactorKernelProbe where
  srcDir := "bench"
  globs := #[`HexBench.IntFactorKernel, `HexIntFactor.FieldBench,
    `HexIntFactor.ProofProbe.Support,
    `HexIntFactor.ProofProbe.Replay1,
    `HexIntFactor.ProofProbe.Replay10,
    `HexIntFactor.ProofProbe.PrimalityExhausted].map Glob.one

lean_lib HexMvGcdKernelProbe where
  srcDir := "bench"
  globs := #[`HexMvGcd.Kernel]

lean_lib HexMvGcdBenchSupport where
  srcDir := "bench"
  globs := #[`HexMvGcd.Families, `HexMvGcd.Matrix,
    `HexMvGcd.ComparatorCases, `HexMvGcd.Comparators,
    `HexMvGcd.Profile, `HexMvGcdFlint, `HexMvGcdSingular]

lean_lib HexMvPolyBenchSupport where
  srcDir := "bench"
  globs := #[`HexMvPolyCorpus, `HexMvPoly.Sorted, `HexMvPoly.SortedTests]

lean_lib HexModularBenchSupport where
  srcDir := "bench"
  globs := #[`HexModularBench.Comparator]

lean_lib HexMvPolyTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexMvPolyTheory.ProofProbe.Examples].map Glob.one

lean_lib HexIntervalExperiment where
  globs := #[`HexInterval.Experiment.Representation,
    `HexInterval.Experiment.Rational, `HexInterval.Experiment.Center,
    `HexInterval.Experiment.Scale, `HexInterval.Experiment.Propagator,
    `HexInterval.Experiment.Policy, `HexInterval.Experiment.PolicyFrontier,
    `HexInterval.Experiment.PolicyDriver,
    `HexInterval.Experiment.PackageRegistry,
    `HexInterval.Experiment.DyadicInterval,
    `HexInterval.Experiment.DyadicRules,
    `HexInterval.Experiment.StructuralMatcher,
    `HexInterval.Experiment.PayloadArena,
    `HexInterval.Experiment.PayloadSession,
    `HexInterval.Experiment.PolicySession,
    `HexInterval.Experiment.TargetRun,
    `HexInterval.Experiment.StagedPolicy,
    `HexInterval.Experiment.AdaptivePolicy,
    `HexInterval.Experiment.PolicyFeature,
    `HexInterval.Experiment.FeaturePolicy,
    `HexInterval.Experiment.BranchStart,
    `HexInterval.Experiment.BranchTree,
    `HexInterval.Experiment.BranchProof,
    `HexInterval.Experiment.SemanticReplay,
    `HexInterval.Experiment.ChronologicalReplay,
    `HexInterval.Experiment.GenericInstanceReconstruction,
    `HexInterval.Experiment.OperationSemantics,
    `HexInterval.Experiment.ProofEmitter,
    `HexInterval.Experiment.ProofRegistry,
    `HexInterval.Experiment.Frontend,
    `HexInterval.Experiment.FrontendEncoder,
    `HexInterval.Experiment.ProofFrontend,
    `HexInterval.Experiment.GoalFrontend,
    `HexInterval.Experiment.GoalClosure,
    `HexInterval.Experiment.TraceReplay,
    `HexInterval.Experiment.SineSign,
    `HexInterval.Experiment.ExpSign,
    `HexInterval.Experiment.PntLogTable,
    `HexInterval.Experiment.PntNestedLog,
    `HexInterval.Experiment.PntExpTail,
    `HexInterval.Experiment.PntTable12,
    `HexInterval.Experiment.PntTable12Ordinary,
    `HexInterval.Experiment.PntTable10Shard,
    `HexInterval.Experiment.PntTable10Convex,
    `HexInterval.Experiment.PntTable10Pointwise,
    `HexInterval.Experiment.PntTable10LargePointwise,
    `HexInterval.Experiment.PntTable10LogCoupled,
    `HexInterval.Experiment.PntTable10A2,
    `HexInterval.Experiment.PntTable12Log,
    `HexInterval.Experiment.PntFks2ShardData,
    `HexInterval.Experiment.PntFks2Shard,
    `HexInterval.Experiment.PntFks2FamilyData00,
    `HexInterval.Experiment.PntFks2FamilyData01,
    `HexInterval.Experiment.PntFks2FamilyData02,
    `HexInterval.Experiment.PntFks2FamilyData03,
    `HexInterval.Experiment.PntFks2FamilyData04,
    `HexInterval.Experiment.PntFks2FamilyData05,
    `HexInterval.Experiment.PntFks2FamilyData06,
    `HexInterval.Experiment.PntFks2FamilyData07,
    `HexInterval.Experiment.PntFks2FamilyData08,
    `HexInterval.Experiment.PntFks2FamilyData09,
    `HexInterval.Experiment.PntFks2FamilyData10,
    `HexInterval.Experiment.PntFks2FamilyData12,
    `HexInterval.Experiment.PntFks2FamilyData13,
    `HexInterval.Experiment.PntFks2FamilyData,
    `HexInterval.Experiment.PntFks2Family,
    `HexInterval.Experiment.PntFks2Structure,
    `HexInterval.Experiment.PntFks2Xpow,
    `HexInterval.Experiment.CosBillion,
    `HexInterval.Experiment.LogTablePrecision,
    `HexInterval.Experiment.PntLogNatural,
    `HexInterval.Experiment.PntFks2Nested,
    `HexInterval.Experiment.PntLogRational,
    `HexInterval.Experiment.PntExpNegative,
    `HexInterval.Experiment.PntExpPoint,
    `HexInterval.Experiment.PntNestedLogTwo,
    `HexInterval.Experiment.PntPiPoint,
    `HexInterval.Experiment.IntegralCanary,
    `HexInterval.Experiment.PntBKLNWExp,
    `HexInterval.Experiment.PntBKLNWPow,
    `HexInterval.Experiment.PntDusartExp,
    `HexInterval.Experiment.PntFks2Mu,
    `HexInterval.Experiment.PntExpUpper,
    `HexInterval.Experiment.PntRamanujanTheta,
    `HexInterval.Experiment.SinTen,
    `HexInterval.Experiment.SinTenInterval,
    `HexInterval.Experiment.MixedFunctions,
    `HexInterval.Experiment.MixedInstantiation].map Glob.one

lean_lib HexIntervalTheoryExperiment where
  globs := #[`HexIntervalTheory.Experiment.Arithmetic,
    `HexIntervalTheory.Experiment.Center,
    `HexIntervalTheory.Experiment.Centered,
    `HexIntervalTheory.Experiment.DyadicInterval,
    `HexIntervalTheory.Experiment.SineSign,
    `HexIntervalTheory.Experiment.ExpSign,
    `HexIntervalTheory.Experiment.PntLogTable,
    `HexIntervalTheory.Experiment.PntNestedLog,
    `HexIntervalTheory.Experiment.PntExpTail,
    `HexIntervalTheory.Experiment.PntTable12,
    `HexIntervalTheory.Experiment.PntTable12Ordinary,
    `HexIntervalTheory.Experiment.PntTable10Shard,
    `HexIntervalTheory.Experiment.PntTable10Convex,
    `HexIntervalTheory.Experiment.PntTable10Pointwise,
    `HexIntervalTheory.Experiment.PntTable10LargePointwise,
    `HexIntervalTheory.Experiment.PntTable10LogCoupled,
    `HexIntervalTheory.Experiment.PntTable10A2,
    `HexIntervalTheory.Experiment.PntTable10Exact,
    `HexIntervalTheory.Experiment.PntTable12Log,
    `HexIntervalTheory.Experiment.PntFks2Shard,
    `HexIntervalTheory.Experiment.PntFks2Xpow,
    `HexIntervalTheory.Experiment.CosBillion,
    `HexIntervalTheory.Experiment.LogTablePrecision,
    `HexIntervalTheory.Experiment.PntLogNatural,
    `HexIntervalTheory.Experiment.PntFks2Nested,
    `HexIntervalTheory.Experiment.PntLogRational,
    `HexIntervalTheory.Experiment.PntExpNegative,
    `HexIntervalTheory.Experiment.PntExpPoint,
    `HexIntervalTheory.Experiment.PntNestedLogTwo,
    `HexIntervalTheory.Experiment.PntPiPoint,
    `HexIntervalTheory.Experiment.IntegralCanary,
    `HexIntervalTheory.Experiment.PntBKLNWExp,
    `HexIntervalTheory.Experiment.PntBKLNWPow,
    `HexIntervalTheory.Experiment.PntDusartExp,
    `HexIntervalTheory.Experiment.PntFks2Mu,
    `HexIntervalTheory.Experiment.PntExpUpper,
    `HexIntervalTheory.Experiment.PntRamanujanTheta,
    `HexIntervalTheory.Experiment.PntPrimeLogSmall,
    `HexIntervalTheory.Experiment.PntChebyshev,
    `HexIntervalAlgebraic.Experiment.PolynomialDispatch,
    `HexIntervalAlgebraic.Experiment.PolynomialDispatchProof,
    `HexIntervalTheory.Experiment.SinTen,
    `HexIntervalTheory.Experiment.SinTenInterval,
    `HexIntervalTheory.Experiment.MixedFunctions,
    `HexIntervalTheory.Experiment.MixedInstantiation].map Glob.one

@[default_target]
lean_lib HexIntervalTheory where
  globs := #[`HexIntervalTheory, `HexIntervalTheory.Interval,
    `HexIntervalTheory.Addition, `HexIntervalTheory.Subtraction,
    `HexIntervalTheory.MinMax, `HexIntervalTheory.Absolute,
    `HexIntervalTheory.Multiplication,
    `HexIntervalTheory.Power, `HexIntervalTheory.Split,
    `HexIntervalTheory.Inverse, `HexIntervalTheory.Division,
    `HexIntervalTheory.Regularize, `HexIntervalTheory.Program,
    `HexIntervalTheory.Proof, `HexIntervalTheory.Rule,
    `HexIntervalTheory.Frontend,
    `HexIntervalTheory.Tactic].map Glob.one

lean_lib HexIntervalReplayProbe where
  srcDir := "bench"
  globs := #[`HexInterval.ReplayBaseline, `HexInterval.ReplayBundled,
    `HexInterval.ReplayChecked, `HexInterval.ReplayRationalBaseline,
    `HexInterval.ReplayRationalDirect, `HexInterval.ReplayRationalChecked,
    `HexInterval.ReplayRational, `HexInterval.ImportBundled,
    `HexInterval.ImportChecked, `HexInterval.WhnfBundled,
    `HexInterval.WhnfChecked, `HexInterval.WhnfBaseline,
    `HexInterval.WhnfRationalDirect, `HexInterval.WhnfRationalChecked,
    `HexInterval.WhnfRationalBaseline, `HexInterval.ReplayCenterBaseline,
    `HexInterval.ReplayCenterChecked, `HexInterval.WhnfCenterChecked,
    `HexInterval.WhnfCenterBaseline, `HexInterval.WhnfScaleChecked,
    `HexInterval.WhnfScaleBaseline, `HexInterval.ReplayScaleChecked,
    `HexInterval.ReplayScaleBaseline]

lean_lib HexIntervalTheoryReplayProbe where
  srcDir := "bench"
  globs := #[`HexIntervalTheory.CenterDirect,
    `HexIntervalTheory.CenterReflected].map Glob.one

lean_lib HexRealRootsTheoryReplayProbe where
  srcDir := "bench"
  globs := #[`HexRealRootsTheory.ProofProbe.Natural6,
    `HexRealRootsTheory.ProofProbe.Refined2,
    `HexRealRootsTheory.ProofProbe.RealClosed].map Glob.one

lean_lib HexBerlekampZassenhausTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexBerlekampZassenhausTheory.ProofProbe.Factor4,
    `HexBerlekampZassenhausTheory.ProofProbe.Irreducible4,
    `HexBerlekampZassenhausTheory.ProofProbe.Repeated8,
    `HexBerlekampZassenhausTheory.ProofProbe.Kernel4].map Glob.one

lean_lib HexBerlekampTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexBerlekampTheory.ProofProbe.Factor4,
    `HexBerlekampTheory.ProofProbe.Irreducible4,
    `HexBerlekampTheory.ProofProbe.Repeated8].map Glob.one

lean_lib HexSignDetTheoryProofProbe where
  srcDir := "bench"
  globs := #[.submodules `HexSignDetTheory.ProofProbe]

-- Correctness diagnostics remain CI-built outside the benchmark root.
lean_lib HexSignDetTheoryDiagnostics where
  srcDir := "conformance"
  globs := #[.submodules `HexSignDetTheory.Diagnostics]

-- Depth-three kernel reductions retain their separate manual target.
lean_lib HexSignDetTheoryDepthThree where
  srcDir := "conformance"
  globs := #[.submodules `HexSignDetTheory.DepthThree]

lean_lib HexRealFormulaProofProbe where
  srcDir := "bench"
  globs := #[`HexRealFormulaTheory.ProofProbe.Support,
    `HexRealFormulaTheory.ProofProbe.Parameterized,
    `HexRealFormulaTheory.ProofProbe.Alternation].map Glob.one

lean_lib HexRCFBenchSupport where
  srcDir := "bench"
  globs := #[`HexRCF.BenchHash].map Glob.one

lean_lib HexRCFProofProbe where
  srcDir := "bench"
  globs := #[`HexRCF.ProofProbe.Examples,
    `HexRCF.ProofProbe.Registered.Unused,
    `HexRCF.ProofProbe.Registered.Support,
    `HexRCF.ProofProbe.Registered.Tactic].map Glob.one

-- Paired proof-construction diagnostics are manual builds, outside CI.
lean_lib HexRCFProofProbeMeasurements where
  srcDir := "bench"
  globs := #[`HexRCF.ProofProbe.Supplied.Reconstruct,
    `HexRCF.ProofProbe.Supplied.Reuse,
    `HexRCF.ProofProbe.Points.Section, `HexRCF.ProofProbe.Points.Point].map Glob.one

-- Deliberately explicit: the four-boundary enlarged-tower stress case is
-- retained without adding its multi-minute producer cost to every CI build.
-- Explicit original-input stress case: a further algebraic root with an
-- independent algebraic upper bound. Routine conformance stays separate.
lean_lib HexRCFAlgebraicCellsStress where
  srcDir := "conformance"
  globs := #[.one `HexRCF.AlgebraicCellsStress]

lean_lib HexRCFCellRequestedStress where
  srcDir := "conformance"
  globs := #[.one `HexRCF.CellRequestedStress]

-- Conformance #guard drivers live under `conformance/` and are built by this
-- library (mirroring the released conformance sub-projects). Alongside each
-- library's `Conformance` core module, the heavier cross-check sweeps and
-- extern-path fast checks (`CrossCheck` / `FastCheck`) also live here so the
-- implementation-vs-testing boundary stays legible; they elaborate their
-- `#guard`s in the same `lake build`. EmitFixtures drivers are the
-- `*_emit_fixtures` exes below, carrying `srcDir := "conformance"`.
/-- Libraries whose conformance modules are not built while they are parked.
HexInterval is parked: none of its libraries, executables or conformance
modules are built in CI. Remove a prefix here to restore its conformance. -/
def parkedConformancePrefixes : List String := ["HexInterval"]

def isParkedGlob : Glob → Bool
  | .one n | .submodules n | .andSubmodules n =>
    parkedConformancePrefixes.any (n.getRoot.toString.startsWith ·)

lean_lib HexConformance where
  srcDir := "conformance"
  globs := Array.filter (fun g => !isParkedGlob g) <| #[
`HexPosDef.Conformance, `HexArith.Conformance, `HexArith.CrossCheck, `HexBerlekamp.Conformance, `HexBerlekampZassenhaus.Conformance, `HexBerlekampZassenhaus.CrossCheck, `HexBerlekampZassenhausTheory.Conformance, `HexConway.Conformance, `HexGF2.Conformance, `HexGF2.CrossCheck, `HexGF2.FastCheck, `HexGFq.Conformance, `HexGFq.CrossCheck, `HexGFqField.Conformance, `HexGFqRing.Conformance, `HexGramSchmidt.Conformance, `HexGraphIso.Conformance, `HexHensel.Conformance, `HexHensel.CrossCheck, `HexInterval.Conformance, `HexIntervalTheory.IntervalConformance, `HexInterval.CenterConformance, `HexInterval.ScaleConformance, `HexInterval.PropagatorConformance, `HexInterval.ScopeConformance, `HexInterval.StructuralMatcherConformance, `HexInterval.MatcherSchedulerConformance, `HexInterval.NestedBranchConformance, `HexInterval.StructureViewConformance, `HexInterval.PolicyConformance, `HexInterval.PolicyFrontierConformance, `HexInterval.PolicyDriverConformance, `HexInterval.PackageRegistryConformance, `HexInterval.DyadicIntervalConformance, `HexInterval.DyadicRulesConformance, `HexInterval.PayloadArenaConformance, `HexInterval.PayloadSessionConformance, `HexInterval.PolicySessionConformance, `HexInterval.PolicyFunctionConformance, `HexInterval.SemanticReplayConformance, `HexInterval.ChronologicalReplayConformance, `HexInterval.GenericInstanceReconstructionConformance, `HexInterval.ProofEmitterConformance, `HexInterval.TraceReplayConformance, `HexInterval.SinTenIntervalConformance, `HexIntervalTheory.DyadicIntervalConformance, `HexIntervalTheory.CenteredConformance, `HexIntervalTheory.SineSignConformance, `HexIntervalTheory.SineProofConformance, `HexIntervalTheory.SineTacticConformance, `HexIntervalTheory.ProofRegistryConformance, `HexIntervalTheory.ExpSignConformance, `HexIntervalTheory.ReluConformance, `HexIntervalTheory.RefuteConformance, `HexIntervalTheory.PntLogTableConformance, `HexIntervalTheory.PntNestedLogConformance, `HexIntervalTheory.PntExpTailConformance, `HexIntervalTheory.PntTable12Conformance, `HexIntervalTheory.PntTable12OrdinaryConformance, `HexIntervalAlgebraic.PolynomialDispatchConformance, `HexIntervalTheory.PntTable12LogConformance, `HexIntervalTheory.PntFks2ShardConformance, `HexIntervalTheory.LogTablePrecisionConformance, `HexIntervalTheory.IntegralCanaryConformance, `HexIntervalTheory.PntBKLNWExpConformance, `HexIntervalTheory.PntBKLNWPowConformance, `HexIntervalTheory.PntPrimeLogSmallConformance, `HexIntervalTheory.PntDusartExpConformance, `HexIntervalTheory.SinTenConformance, `HexIntervalTheory.SinTenIntervalConformance, `HexIntervalTheory.CosBillionConformance, `HexHermite.Conformance, `HexLLL.Conformance, `HexMatrix.Conformance, `HexRealFormula.Conformance, `HexRealFormulaTheory.Conformance, `HexRealFormulaTheory.Arithmetic, `HexMvPolyFixtures, `HexMvPoly.Conformance, `HexGroebner.Conformance, `HexGroebner.CertificateConformance, `HexGroebner.DivisionConformance, `HexGroebner.DivisionAPIConformance, `HexGroebner.MembershipConformance, `HexGroebner.BasisReplayConformance, `HexGroebner.TraceConformance, `HexGroebner.CertificateProducerConformance, `HexGroebner.ProducerConformance, `HexGroebner.BasisConformance, `HexGroebner.NormalFormConformance, `HexGroebner.DivisionFixtures, `HexGroebner.MonomialConformance, `HexGroebner.PackedWordConformance, `HexGroebner.ByteConformance, `HexGroebner.ProductConformance, `HexGroebner.ReducerCacheConformance, `HexGroebner.ReducerConformance, `HexGroebner.NativeConformance, `HexGroebner.TrieConformance, `HexGroebner.ScanConformance, `HexGroebner.GatherConformance, `HexGroebner.MatrixNativeConformance, `HexGroebner.NativeChecks, `HexGroebner.PairRowsConformance, `HexGroebner.F4Conformance, `HexGroebner.F4Fixtures, `HexGroebner.Fixtures, `HexMvPolyTheory.Conformance, `HexSparsePolyFixtures, `HexSparsePoly.Conformance, `HexRowReduce.Conformance, `HexDeterminant.Conformance, `HexDeterminantalIdealFixtures, `HexDeterminantalIdeal.Conformance, `HexDeterminant.Carriers, `HexBareiss.Fixtures, `HexBareiss.Conformance, `HexModularMatrix.Fixtures, `HexModularMatrix.Conformance, `HexDet.Conformance, `HexDet.Carriers, `HexCharPoly.Fixtures, `HexCharPoly.Carriers, `HexCharPoly.Conformance, `HexModArith.Conformance, `HexModArith.FastCheck, `HexModular.Conformance, `HexPolyZGcd.Conformance, `HexMvGcd.Conformance, `HexNumberField.Conformance, `HexNumberFieldTower.Conformance, `HexPoly.Conformance, `HexPrimality.CertificateProducer, `HexPrimality.ConstructionConformance, `HexPrimality.ConstructionRetry, `HexPrimality.ConstructionRegistration, `HexPrimality.Curve25519Replay, `HexPrimality.Curve448Replay, `HexPrimality.SqufofConformance, `HexPrimality.Conformance, `HexECPP.NativeConformance, `HexECPP.Conformance, `HexECPP.Fixture17, `HexECPP.PolicyProbe, `HexECPP.Fixture65, `HexECPP.Fixture256, `HexECPP.Fixture512, `HexECPP.PariFixtures, `HexECPP.ImportConformance, `HexECPPTheory.NativeConformance, `HexECPPTheory.NativeFixtures, `HexECPPTheory.Conformance, `HexECPPTheory.CompactFixtures, `HexECPPTheory.CompactReject, `HexECPPTheory.PariProcess, `HexECPPTheory.Reject, `HexECPPTheory.HasseAudit, `HexECPPTheory.SoundnessAudit, `HexPrimalityTheory.Conformance, `HexPrimalityTheoryConformance.OptIn, `HexPolyFp.Conformance, `HexPolyZ.Conformance, `HexRCF.Conformance, `HexRealRoots.Conformance, `HexRealRootsTheory.Conformance, `HexResultant.Conformance, `HexRoots.Conformance].map Glob.one ++
    #[`HexRCF.DependentQuoteData, `HexRCF.DependentQuote, `HexRCF.DependentQuoteProofs,
      `HexRCF.DependentScalarQuote, `HexRCF.DependentScalarProofs,
      `HexRCF.PublicSignPacket, `HexRCF.PublicSignPacketValues, `HexRCF.PublicSignPacketControls, `HexRCF.PublicSignPacketProofs,
      `HexRCF.RootQuoteData, `HexRCF.RootQuoteCases,
      `HexRCF.RootQuoteSource, `HexRCF.RootQuoteConformance, `HexRCF.RationalQuoteData, `HexRCF.RationalQuoteCases, `HexRCF.RationalQuoteConformance, `HexRCF.ScalarQuoteCases, `HexRCF.ScalarQuoteConformance, `HexRCF.ScalarQuotePublic, `HexRCF.SharedQuoteCases, `HexRCF.SharedQuoteConformance, `HexRCF.SharedQuoteCallbacks, `HexRCF.SharedQuoteCallbackProofs, `HexRCF.SignPacketQuote, `HexRCF.SignPacketProofs, `HexRCF.RecursiveScalarQuote, `HexRCF.RecursiveScalarProofs, `HexRCF.RecursiveScalarPublic, `HexRCF.PolynomialQuotePublic,
      `HexRCF.RootTableQuote.Cases, `HexRCF.RootTableQuote.Input, `HexRCF.RootTableQuote.Table, `HexRCF.RootTableQuote.Semantics, `HexRCF.RootTableQuote.Conformance, `HexRCF.RootTableQuote.Runtime,
      `HexRCF.SourceIdentityKernel, `HexRCF.SourceIdentityCases, `HexRCF.MaximalCoefficientsKernel, `HexRCF.MaximalCoefficientsConformance, `HexRCF.MaximalCoefficients, `HexRCF.CellReplay.AssembledKernel, `HexRCF.CellReplay.Assembled, `HexRCF.CellReplay.OperationsPublic, `HexRCF.CellReplay.OperationsKernel, `HexRCF.CellReplay.Operations, `HexRCF.CellReplay.Algebraic.Emit, `HexRCF.CellReplay.Algebraic.MutationData0, `HexRCF.CellReplay.Algebraic.Mutations, `HexRCF.CellReplay.Algebraic.Refusals, `HexRCF.CellReplay.Algebraic.Guards, `HexRCF.CellReplay.Algebraic.Meaning, `HexRCF.CellReplay.Algebraic.Boolean, `HexRCF.CellReplay.Algebraic.BooleanSources, `HexRCF.CellReplay.Algebraic.BooleanBinding, `HexRCF.CellReplay.Algebraic.BooleanQuoted, `HexRCF.CellBuildConformance, `HexRCF.CellDiscoverLinear, `HexRCF.CellDiscoverAlgebraic, `HexRCF.CellDiscoverCases, `HexRCF.CellDiscoverProofs, `HexRCF.CellRequestedConformance, `HexRCF.CellDecisionProofs, `HexRCF.CellCodecProofs, `HexRCF.CellExecutionProofs, `HexRCF.NumberFieldCellsConformance, `HexRCF.GatherCellsConformance, `HexRCF.RealModelConformance, `HexRCF.AlgebraicPreparationCases, `HexRCF.AlgebraicPreparationConformance, `HexRCF.SourceAcceptancePublic, `HexRCF.AlgebraicCellsConformance, `HexRCF.CellReplay.Algebraic.Canonical, `HexRCF.CellReplay.Algebraic.Check, `HexRCF.CellReplay.Algebraic.Convert, `HexRCF.CellReplay.Algebraic.Inputs, `HexRCF.CellReplay.Algebraic.LiteralData0, `HexRCF.CellReplay.Algebraic.LiteralData1, `HexRCF.CellReplay.Algebraic.Literals, `HexRCF.CellReplay.Algebraic.Quote, `HexRCF.CellReplay.Algebraic.Quoted, `HexRCF.CellReplay.Algebraic.CompleteQuote, `HexRCF.CellReplay.Algebraic.CompleteQuoted, `HexRCF.CellReplay.Algebraic.Radical, `HexRCF.CellReplay.Algebraic.Read, `HexRCF.CellReplay.Algebraic.Records, `HexRCF.CellReplay.Algebraic.ScalarData0, `HexRCF.CellReplay.Algebraic.ScalarData1, `HexRCF.CellReplay.Algebraic.Scalars, `HexRCF.CellReplay.Algebraic.Schema, `HexRCF.CellReplay.Algebraic.Sections, `HexPolyDet.Conformance, `HexRank.Conformance, `HexGenericRank.Conformance, `HexGenericRank.Fixtures, `HexRowReduce.FieldFixtures, `HexRealFormulaTheory.ReifierConformance, `HexRCF.RealFormulaConformance, `HexRCF.RealCoefficientsConformance, `HexRCF.AlgebraicProgress, `HexRCF.IsolationProgress, `HexRCF.RadicalProgress, `HexRCF.ProductionProgress, `HexRCF.FieldRootsConformance, `HexRCF.CertificationInputs, `HexRCF.RationalSources, `HexRCF.ProofEvidence, `HexRCF.CheckedConversions, `HexRCF.ReplayModes, `HexRCF.CarrierModes, `HexRCF.SignIndex, `HexRCF.PreparedCoefficients, `HexRCF.FiniteReplay, `HexRCF.FiniteSignsConformance, `HexRCF.CellReplay.OutsideLiterals, `HexRCF.CellReplay.Zero, `HexRCF.CellReplay.ZeroLiterals, `HexRCF.CellReplay.Valuation, `HexRCF.CellReplay.ModuleCheck, `HexRCF.CellReplay.Schema, `HexRCF.CellReplay.Check, `HexRCF.CellReplay.Ordinary, `HexRCF.CellReplay.Quote, `HexRCF.CellReplay.Controls, `HexRCF.CellReplay.Quoted, `HexRCF.CellReplay.Refusals, `HexRCF.CellReplay.Emit, `HexRCF.CellReplay.LiteralData0, `HexRCF.CellReplay.Literals, `HexRCF.CellReplay.MutationData0, `HexRCF.CellReplay.Mutations, `HexRCF.FiniteMatrix.Binding, `HexRCF.FiniteMatrix.Guards.Binding, `HexRCF.FiniteMatrix.Guards.Quotient.Binding, `HexRCF.FiniteMatrix.Guards.Quotient.Controls, `HexRCF.FiniteMatrix.Guards.Quotient.Emit, `HexRCF.FiniteMatrix.Guards.Quotient.Literals, `HexRCF.FiniteMatrix.Guards.Quotient.Ordinary, `HexRCF.FiniteMatrix.Guards.Quotient.Quote, `HexRCF.FiniteMatrix.Guards.Quotient.Reader, `HexRCF.FiniteMatrix.Guards.Quotient.Records, `HexRCF.FiniteMatrix.Guards.Quotient.Source, `HexRCF.FiniteMatrix.Guards.Controls, `HexRCF.FiniteMatrix.Guards.Data, `HexRCF.FiniteMatrix.Guards.Domains, `HexRCF.FiniteMatrix.Guards.Emit, `HexRCF.FiniteMatrix.Guards.LiteralData0, `HexRCF.FiniteMatrix.Guards.Literals, `HexRCF.FiniteMatrix.Guards.Meaning, `HexRCF.FiniteMatrix.Guards.MutationData0, `HexRCF.FiniteMatrix.Guards.Mutations, `HexRCF.FiniteMatrix.Guards.Ordinary, `HexRCF.FiniteMatrix.Guards.Quote, `HexRCF.FiniteMatrix.Guards.Read, `HexRCF.FiniteMatrix.Guards.Records, `HexRCF.FiniteMatrix.Guards.Refusals, `HexRCF.FiniteMatrix.Guards.Schema, `HexRCF.FiniteMatrix.Data, `HexRCF.FiniteMatrix.Emit, `HexRCF.FiniteMatrix.Inputs, `HexRCF.FiniteMatrix.KernelControls, `HexRCF.FiniteMatrix.LiteralData0, `HexRCF.FiniteMatrix.LiteralData1, `HexRCF.FiniteMatrix.LiteralData2, `HexRCF.FiniteMatrix.LiteralData3, `HexRCF.FiniteMatrix.LiteralData4, `HexRCF.FiniteMatrix.LiteralData5, `HexRCF.FiniteMatrix.Literals, `HexRCF.FiniteMatrix.ModuleCheck, `HexRCF.FiniteMatrix.Ordinary, `HexRCF.FiniteMatrix.Packings, `HexRCF.FiniteMatrix.Quote, `HexRCF.FiniteMatrix.Controls, `HexRCF.FiniteMatrix.Refusals, `HexRCF.FiniteMatrix.Read, `HexRCF.FiniteMatrix.Restore, `HexRCF.FiniteMatrix.Schema, `HexRCF.FiniteMatrix.Selected, `HexRCF.FiniteMatrix.Semantics, `HexRCF.FiniteMatrix.Signs, `HexRCF.TowerSamples, `HexRCF.Samples, `HexRCF.RealizationData, `HexRCF.Realization, `HexRCF.NumberField, `HexRCF.Gather, `HexRCF.GatherCatalog, `HexRCF.RegisteredGatherConformance, `HexRCF.GeneratorWindowInputs, `HexRCF.GeneratorWindow, `HexRCF.CertificationProofs, `HexRCF.SuppliedIrreducible, `HexRCF.SuppliedIrreducibleProofs, `HexRCF.SuppliedBudget, `HexRCF.NativeFormulaConformance, `HexRCF.NativeSpecializeConformance, `HexRCF.NativeSamplesConformance, `HexRCF.NativeSampleModelConformance, `HexRCF.NativeSampleModelLiterals, `HexRCF.NativeSourcesConformance, `HexRCF.NativeSelectionLiterals, `HexRCF.NativeSelectionConformance, `HexRCF.NativeSelectionOrdinaryConformance, `HexRCF.SourceSelectionCases, `HexRCF.SourceSelectionNegativeLiterals, `HexRCF.SourceSelectionNegative, `HexRCF.SourceSelectionConformance, `HexRCF.SourceSelectionNative, `HexRCF.SourceSelectionProofs, `HexRCF.SourceSelectionKernel, `HexRCF.SourceSelectionPublic, `HexRCF.FieldSelectionConformance, `HexRCF.NativeSelectionOrderedConformance, `HexRCF.SectionReplayConformance, `HexRCF.SectionProduceConformance, `HexRCF.SectionOrdinaryConformance, `HexRCF.PointReplayConformance, `HexRCF.PointProduceConformance, `HexRCF.PointOrdinaryConformance, `HexRCF.RootReplayLiterals, `HexRCF.RootReplayConformance, `HexRCF.RootReplayOrdinaryConformance, `HexRCF.NestedRootLiterals, `HexRCF.NestedRootProduceConformance, `HexRCF.NestedRootOrdinaryConformance, `HexRCF.RootTransportData, `HexRCF.RootTransportLiterals, `HexRCF.RootTransportConformance, `HexRCF.RootTransportOrdinaryConformance, `HexRCF.NestedTransport.Frame, `HexRCF.NestedTransport.Context, `HexRCF.NestedTransport.Map, `HexRCF.NestedTransport.Conversion, `HexRCF.NestedTransport.Fields, `HexRCF.NestedTransport.Restore, `HexRCF.NestedTransport.Predecessor, `HexRCF.NestedTransport.Facts, `HexRCF.NestedTransport.Constants, `HexRCF.NestedTransport.Operations, `HexRCF.NestedTransport.RootRead, `HexRCF.NestedTransport.Read, `HexRCF.NestedTransport.Model, `HexRCF.NestedTransport.Source, `HexRCF.NestedTransport.Ordinary, `HexRCF.NestedTransport.Controls, `HexRCF.NestedTransport.Literals, `HexRCF.NestedTransport.EndpointLiterals, `HexRCF.NestedTransport.SignLiterals, `HexRCF.NestedTransport.SignData, `HexRCF.TotalAlgebraicProofs, `HexRCF.AlgebraicDivision, `HexRCF.NormalizedCoefficients, `HexRCF.NormalizedInputs, `HexRCF.RegisteredConstants, `HexRCF.NamedConstants, `HexRCF.NamedConstantProofs, `HexRCF.MixedConstants, `HexRCF.CoarseConstants, `HexRCF.RealCoefficientTactic, `HexRCF.RealCoefficientCommonField, `HexRCF.CommonFieldPresentation, `HexRCF.RootAliasesConformance, `HexRCF.RationalRoots, `HexRCF.AlgebraicRoots, `HexRCF.FormulaConformance, `HexRCF.LiteralSignConformance, `HexRCF.FieldSpecializeConformance, `HexRCF.SignDetFieldProofs, `HexRCF.AdmissionConformance, `HexRCF.IsolationConformance].map Glob.one

    ++ #[
      `HexRCF.SelectedRoot.Packing, `HexRCF.SelectedRoot.PackingData,
      `HexRCF.SelectedRoot.InverseData, `HexRCF.SelectedRoot.InverseReplay,
      `HexRCF.SelectedRoot.InverseControls, `HexRCF.InverseFixture,
      `HexRCF.SelectedRoot.PackingReplay, `HexRCF.SelectedRoot.PackingMissing, `HexRCF.SelectedRoot.PackingAudit,
      `HexRCF.SelectedRoot.CatalogData, `HexRCF.SelectedRoot.CatalogByteData,
      `HexRCF.SelectedRoot.CatalogSource, `HexRCF.SelectedRoot.Catalog, `HexRCF.SelectedRoot.CatalogBytes,
      `HexRCF.SelectedRoot.CatalogControls, `HexRCF.SelectedRoot.CatalogAudit,
      `HexRCF.SelectedRoot.ByteAudit, `HexRCF.SelectedRoot.ByteBounds, `HexRCF.SelectedRoot.ByteChecks,
      `HexRCF.SelectedRoot.ByteData, `HexRCF.SelectedRoot.ByteProofs,
      `HexRCF.SelectedRoot.Audit, `HexRCF.SelectedRoot.Checks, `HexRCF.SelectedRoot.Collect,
      `HexRCF.SelectedRoot.Controls, `HexRCF.SelectedRoot.Data, `HexRCF.SelectedRoot.Frozen,
      `HexRCF.SelectedRoot.FrozenCollect, `HexRCF.SelectedRoot.KernelCheck, `HexRCF.SelectedRoot.Intermediates, `HexRCF.SelectedRoot.Literals,
      `HexRCF.SelectedRoot.PacketFields, `HexRCF.SelectedRoot.Packets, `HexRCF.SelectedRoot.Proofs,
      `HexRCF.SelectedRoot.Read, `HexRCF.SelectedRoot.Refusals, `HexRCF.SelectedRoot.ReplayTools,
      `HexRCF.SelectedRoot.Row, `HexRCF.SelectedRoot.RowCollect, `HexRCF.SelectedRoot.RowIntermediates,
      `HexRCF.SelectedRoot.RowTools, `HexRCF.SelectedRoot.Source, `HexRCF.SelectedRoot.Upper].map Glob.one

    ++ #[`HexRealAlgebraic.Conformance, `HexRealAlgebraic.Checks,
      `HexRealAlgebraic.FieldSignConformance, `HexNumberField.ComplexChecks,
      `HexRealAlgebraic.ReprChecks, `HexRealClosure.ReprChecks, `HexRealAlgebraicTheory.FieldSignConformance].map Glob.one

    ++ #[`HexReflect.TestProviders, `HexReflect.Conformance, `HexReflect.ScopeConformance, `HexReflect.ResidueConformance].map Glob.one

    -- Kernel reduction of structured readers through ordinary public imports.
    ++ #[`HexSignDet.PublicCodec, `HexRCF.PublicGraphCodec].map Glob.one

    ++ #[`HexSignDet.CommonField, `HexSignDet.Conformance, `HexSignDet.CrossCheck, `HexSignDet.FastCheck, `HexSignDet.JsonBytes, `HexSignDet.DescriptorCodec, `HexSignDet.Infinitesimal].map Glob.one

    ++ #[`HexRealClosure.BisectionFrontierTests, `HexRealClosure.IsolationTests,
      `HexRealClosureTheory.CoefficientSignsConformance,
      `HexRealClosureTheory.DependenciesConformance,
      `HexRealClosureTheory.PackingConformance,
      `HexRealClosureTheory.ContextOperationsConformance,
      `HexRealClosureTheory.ContextOperationsPublic,
      `HexRealClosureTheory.NestedSignsConformance,
      `HexRealClosureTheory.SignCodecConformance,
      `HexRealClosureTheory.SignFactsConformance,
      `HexRealClosureTheory.SignRequestsConformance,
      `HexRealClosureTheory.SignEvidenceConformance].map Glob.one

    ++ #[`HexSturm.Fixtures, `HexSturm.Conformance].map Glob.one

    ++ #[`HexKronecker.Conformance].map Glob.one

    ++ #[`HexSmith.Conformance].map Glob.one

    ++ #[`HexMinPoly.Fixtures, `HexMinPoly.Conformance].map Glob.one

    ++ #[`HexTruncatedSeries.Conformance].map Glob.one

    ++ #[`HexPolyFast.Conformance, `HexPolyFast.Lint].map Glob.one

    ++ #[`HexRationalFn.Conformance, `HexRationalFn.Domains, `HexOrderedFn.Conformance].map Glob.one

    ++ #[`HexLatticeEnum.Conformance].map Glob.one

    ++ #[`HexMvHensel.Conformance, `HexMvFactor.Conformance].map Glob.one

    ++ #[`HexIntFactor.Conformance, `HexIntFactor.EcmTables,
      `HexIntFactor.FieldReplay,
      `HexIntFactor.PrimalityConformance].map Glob.one

    ++ #[`HexPolySmith.Conformance].map Glob.one

    ++ #[`HexIntervalTheory.PntLogNaturalConformance,
      `HexIntervalTheory.PntLogRationalConformance,
      `HexIntervalTheory.PntExpNegativeConformance,
      `HexIntervalTheory.PntExpPointConformance].map Glob.one

    ++ #[`HexIntervalTheory.PntNestedLogTwoConformance,
      `HexIntervalTheory.PntPiPointConformance].map Glob.one

    ++ #[`HexIntervalTheory.PntChebyshevConformance].map Glob.one

    ++ #[`HexIntervalTheory.PntFks2MuConformance,
      `HexIntervalTheory.PntExpUpperConformance,
      `HexIntervalTheory.PntRamanujanThetaConformance].map Glob.one

    ++ #[`HexIntervalTheory.PntFks2NestedConformance].map Glob.one

    ++ #[`HexIntervalTheory.PntFks2StructureConformance].map Glob.one

    ++ #[`HexIntervalTheory.PntTable10ShardConformance,
      `HexIntervalTheory.PntTable10ConvexConformance,
      `HexIntervalTheory.PntTable10PointwiseConformance,
      `HexIntervalTheory.PntTable10LargePointwiseConformance,
      `HexIntervalTheory.PntTable10LogCoupledConformance,
      `HexIntervalTheory.PntTable10A2Conformance,
      `HexIntervalTheory.PntTable10ExactConformance].map Glob.one

    ++ #[`HexInterval.StagedPolicyConformance].map Glob.one

    ++ #[`HexIntervalTheory.ArithmeticConformance].map Glob.one

    ++ #[`HexInterval.MinMaxConformance,
      `HexIntervalTheory.MinMaxConformance].map Glob.one

    ++ #[`HexGraphIso.Cases, `HexGraphIso.SparseCases, `HexPermGroup.Conformance,
      `HexPermGroup.KernelConformance, `HexPermGroup.Limits].map Glob.one

    ++ #[`HexInterval.PolicyFeatureConformance,
      `HexInterval.FeaturePolicyConformance,
      `HexInterval.SearchConformance,
      `HexInterval.ExecutableConformance,
      `HexInterval.RuntimeConformance,
      `HexIntervalTheory.RuntimeProofConformance,
      `HexIntervalTheory.RuntimeTerminalConformance,
      `HexIntervalTheory.RuntimeRuleConformance,
      `HexIntervalTheory.RuntimeEmitConformance,
      `HexIntervalTheory.ProgramProofConformance,
      `HexIntervalTheory.DriverConformance,
      `HexIntervalTheory.ControllerConformance,
      `HexIntervalTheory.ExecutableControllerConformance,
      `HexIntervalTheory.RuleConformance,
      `HexIntervalTheory.FrontendConformance,
      `HexIntervalTheory.TacticConformance,
      `HexIntervalTheory.MixedFunctionsConformance,
      `HexIntervalTheory.MixedInstantiationConformance,
      `HexIntervalTheory.ExactBranchConformance].map Glob.one

    ++ #[`HexECPPTheory.CompositeDivisors, `HexECPPTheory.NodeBudget,
      `HexECPPTheory.ModuleImports].map Glob.one

-- The expensive complete-family Mathlib proofs are owned only by this
-- non-default library. They are excluded from both merge-gating
-- `HexIntervalTheoryExperiment` and `HexConformance`.
lean_lib HexIntervalPntFks2Local where
  globs := #[`HexIntervalTheory.Experiment.PntFks2XpowProof00,
    `HexIntervalTheory.Experiment.PntFks2XpowProof01,
    `HexIntervalTheory.Experiment.PntFks2XpowProof02,
    `HexIntervalTheory.Experiment.PntFks2XpowProof03,
    `HexIntervalTheory.Experiment.PntFks2XpowProof04,
    `HexIntervalTheory.Experiment.PntFks2XpowProof05,
    `HexIntervalTheory.Experiment.PntFks2XpowResults,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof00,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof01,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof02,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof03,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof04,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof05,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof06,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof07,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof08,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof09,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof10,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof12,
    `HexIntervalTheory.Experiment.PntFks2FamilyProof13,
    `HexIntervalTheory.Experiment.PntFks2Family].map Glob.one

lean_lib HexIntervalPntFks2ConformanceLocal where
  srcDir := "conformance"
  globs := #[`HexIntervalTheory.PntFks2XpowConformance].map Glob.one

-- The local executable owns the complete runtime and guarded-axiom driver.
lean_exe hex_interval_pnt_fks2_local where
  srcDir := "conformance"
  root := `HexIntervalTheory.PntFks2FamilyConformance

-- Public umbrellas intentionally contain only the supported API. Executable
-- examples and regression tests are compiled through this separate target so
-- removing them from an umbrella cannot silently remove them from CI.
lean_lib HexReleaseTests where
  globs := #[`HexArith.ExtendedGcdTests, `HexECPPTheory.Tests, `HexPoly.InterpretTests, `HexPoly.PseudoTests,
    `HexPolyTheory.InterpretTests, `HexPolyTheory.PseudoTests,
    `HexMatrixTheory.Tests,
    `HexPolyTheory.LiteralTests,
    `HexBareissTheory.Tests,
    `HexRowReduceTheory.Tests,
    `HexBerlekamp.FactorTacticTests,
    `HexBerlekampTheory.FactorPolyTests,
    `HexBerlekampZassenhaus.FactorTacticTests,
    `HexBerlekampZassenhausTheory.FactorPolyTests,
    `HexBerlekampZassenhausTheory.PublicReplayTests,
    `HexBerlekampZassenhausTheory.QuotationTests,
    `HexBerlekampZassenhausTheory.IrreducibilityTests,
    `HexRealRoots.ReplayTest,
    `HexRealRoots.TarskiTests,
    `HexRealRootsTheory.IsolateRootsTests,
    `HexRealRootsTheory.IsolateRootsElabTests,
    `HexRealRootsTheory.SturmTests,
    `HexRealRootsTheory.RealRootCountTests,
    `HexRealRootsTheory.TarskiTests,
    `HexRootsTheory.Examples,
    `HexPrimality.Examples.Curve25519,
    `HexModular.KernelTests, `HexModular.LoopTests,
    `HexMvPoly.KernelTests,
    `HexMvPoly.KernelResidueTests,
    `HexMvPolyTheory.KernelResidueTests,
    `HexSparsePoly.KernelTests,
    `HexGraphIso.TestGraphs,
    `HexGraphIso.SparseTests,
    `HexGraphIso.TacticTests,
    `HexGraphIso.ModuleBoundaryTests,
    `HexBasic.ModuleBoundaryTests,
    `HexGraphIsoTheory.TacticTests,
    `HexGraphIsoTheory.SparseTacticTests,
    `HexPermGroup.Tests,
    `HexPermGroup.CertificateTests,
    `HexPermGroup.ImportTests,
    `HexPermGroupTheory.Tests,
    `HexPermGroupTheory.CertificateTests,
    `HexPermGroupTheory.TacticTests,
    `HexNumberFieldTower.Embed,
    `HexRCF.LanguageTests,
    `HexRCF.SturmBuilderTests,
    `HexRCF.CarrierTests,
    `HexRCF.IsolationsTests,
    `HexRCF.SeparationTests,
    `HexRCF.CellsTests,
    `HexRCF.CommonRootTests,
    `HexRCF.SignMatrixTests,
    `HexRCF.BuilderTests,
    `HexRCF.CertificateTests,
    `HexRCF.DecisionTests,
    `HexRCF.ReifyTests,
    `HexRCF.HandlerTests.Support, `HexRCF.HandlerTests.Async,
    `HexRCF.HandlerTests,
    `HexRCF.LintTests]
    -- a name array mapped through Glob.one: an array literal this long is
    -- elaborated in chunks, on which the name-to-glob coercion fails
    |>.map Glob.one

-- TODO(lean4#15160): after removing the backport, keep the Hex signed API
-- regression coverage and remove copied upstream primitive cases.
lean_exe hexarith_extgcd_tests where
  root := `HexArith.ExtendedGcdTests

-- Build-only regression roots for the structural matrix frontends.
@[default_target]
lean_lib HexStructuralTacticTests where
  globs := #[`HexPolyDetTheory.Tests, `HexMinPolyTheory.Tests, `HexSmithTheory.Tests, `HexHermiteTheory.Tests, `HexRowReduceTheory.Tests]

lean_lib HexStructuralTacticProofProbe where
  srcDir := "bench"
  globs := #[.submodules `HexMinPolyTheory.ProofProbe,
    .submodules `HexSmithTheory.ProofProbe, .submodules `HexHermiteTheory.ProofProbe,
    .submodules `HexRowReduceTheory.ProofProbe]

-- Verification-only modules for the incubating multivariate factorization
-- stack. Keep this separate from the released-test target, whose module list
-- must exactly mirror the repositories already present in the release manifest.
lean_lib HexMvFactorizationTests where
  globs := #[`HexPolyZGcd.Kernel,
    `HexMvGcd.KernelTests,
    `HexMvGcd.CertTests,
    `HexMvGcd.Eval,
    `HexMvGcd.SquarefreeTests,
    `HexMvHensel.KernelTests,
    `HexMvHensel.ShiftTests,
    `HexMvHensel.UniTests,
    `HexMvHensel.DiophantineTests,
    `HexMvHensel.SeedTests,
    `HexMvHensel.CertTests,
    `HexMvHensel.LiftTests,
    `HexMvHensel.CompleteTests,
    `HexMvFactor.KernelTests,
    `HexMvFactor.KroneckerTests,
    `HexMvFactor.LeadingTests,
    `HexMvFactor.PointTests,
    `HexMvFactor.InputTests,
    `HexMvFactor.EezTests,
    `HexMvFactor.FactorTests,
    `HexMvFactor.CompleteTests]

-- Complete development imports for the two factorization packages. Their
-- ordinary umbrellas deliberately expose only the supported release API.
lean_lib HexFactorizationModules where
  globs := #[`HexECPPTheory.Native, `HexECPPTheory.Pari,
    `HexBerlekampZassenhaus.All,
    `HexBerlekampZassenhausTheory.All]

-- Monorepo-only lint regression for the sparse-poly pair; the kernel
-- probes live in HexReleaseTests alongside the release manifest's
-- test_modules entry.
@[default_target]
lean_lib HexSparsePolyTests where
  globs := #[`HexSparsePolyTheory.LintTests]

-- Declaration linting runs in monorepo CI. The lint source is copied to the
-- mirror with its bridge library; mirror CI builds the published API.
@[default_target]
lean_lib HexTruncatedSeriesTests where
  globs := #[`HexTruncatedSeriesTheory.LintTests]

-- Monorepo-only lint regression for the integer Smith pair. It moves into the
-- release-manifest-backed test target when the pair is published.
@[default_target]
lean_lib HexSmithTests where
  globs := #[`HexSmith.QuickstartTests,
    `HexSmithTheory.LintTests,
    `HexSmithTheory.QuickstartTests]

-- HexCharPoly is not yet a published split repository (its released.yml
-- entries were withdrawn until the phase pipeline completes), so its
-- verification-only elaborator regressions stay separate from the
-- release-manifest-backed target above; they rejoin HexReleaseTests (and
-- the manifest's test_modules) at publication.
@[default_target]
lean_lib HexCharPolyTests where
  globs := #[`HexCharPoly.CharPolyElabTests,
    `HexCharPolyTheory.CharPolyElabTests]

-- Mirrors the released aggregate's module-system umbrella, so a library that
-- never adopted the module system fails here instead of after the publish-out
-- sync. `check_released_manifest.py` keeps the import list equal to the
-- `leanprover/hex` pins in `scripts/release/released.yml`.
@[default_target]
lean_lib HexAggregateCheck where

-- Canonical end-to-end examples are release artifacts rather than public API.
-- Keep their target separate for the same reason as the regression tests.
lean_lib HexReleaseExamples where
  globs := #[`Examples.Release1, `Examples.Release3, `Examples.Release4, `Examples.Release5,
    `Examples.FiniteFields, `Examples.DeterminantKernelProof, `Examples.RowReduce]

lean_exe hexrowreduce_emit_fixtures where
  srcDir := "conformance"
  root := `HexRowReduce.EmitFixtures

lean_exe hexdeterminant_emit_fixtures where
  srcDir := "conformance"
  root := `HexDeterminant.EmitFixtures

lean_exe hexdeterminant_emit_carrier_fixtures where
  srcDir := "conformance"
  root := `HexDeterminant.EmitCarrierFixtures

lean_exe hexpolydet_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyDet.EmitFixtures

lean_exe hexbareiss_emit_carrier_fixtures where
  srcDir := "conformance"
  root := `HexBareiss.EmitCarrierFixtures

lean_exe hexmodularmatrix_emit_fixtures where
  srcDir := "conformance"
  root := `HexModularMatrix.EmitFixtures

lean_exe hexbareiss_emit_fixtures where
  srcDir := "conformance"
  root := `HexBareiss.EmitFixtures

lean_exe hexdet_emit_fixtures where
  srcDir := "conformance"
  root := `HexDet.EmitFixtures

lean_exe hexdet_emit_carrier_fixtures where
  srcDir := "conformance"
  root := `HexDet.EmitCarrierFixtures

lean_exe hexgenericrank_emit_fixtures where
  srcDir := "conformance"
  root := `HexGenericRank.EmitFixtures

lean_exe hexrank_emit_fixtures where
  srcDir := "conformance"
  root := `HexRank.EmitFixtures

lean_exe hexhermite_emit_fixtures where
  srcDir := "conformance"
  root := `HexHermite.EmitFixtures

lean_exe hexsmith_emit_fixtures where
  srcDir := "conformance"
  root := `HexSmith.EmitFixtures

lean_exe hexcharpoly_emit_carrier_fixtures where
  srcDir := "conformance"
  root := `HexCharPoly.EmitCarrierFixtures

lean_exe hexcharpoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexCharPoly.EmitFixtures

lean_exe hexminpoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexMinPoly.EmitFixtures

lean_exe hexgramschmidt_emit_fixtures where
  srcDir := "conformance"
  root := `HexGramSchmidt.EmitFixtures

lean_exe hexlll_emit_fixtures where
  srcDir := "conformance"
  root := `HexLLL.EmitFixtures

lean_exe hexlatticeenum_emit_fixtures where
  srcDir := "conformance"
  root := `HexLatticeEnum.EmitFixtures

lean_exe hexsturm_emit_fixtures where
  srcDir := "conformance"
  root := `HexSturm.EmitFixtures

lean_exe hexrealroots_emit_fixtures where
  srcDir := "conformance"
  root := `HexRealRoots.EmitFixtures

lean_exe hexsigndet_emit_fixtures where
  srcDir := "conformance"
  root := `HexSignDet.EmitFixtures

lean_exe hexsigndet_emit_field_signs where
  srcDir := "conformance"
  root := `HexSignDet.EmitFieldSigns

lean_exe hexsigndet_emit_common_fields where
  srcDir := "conformance"
  root := `HexSignDet.EmitCommonFields

lean_exe hexsigndet_json_bytes where
  srcDir := "conformance"
  root := `HexSignDet.JsonBytesDriver

lean_exe hexsigndet_emit_nested_fields where
  srcDir := "conformance"
  root := `HexSignDet.EmitNestedFields

lean_exe hexsigndet_emit_infinitesimal where
  srcDir := "conformance"
  root := `HexSignDet.EmitInfinitesimal

-- Compiled sign-determination checks over genuine number fields. Mathlib-free.
lean_exe hexsigndet_field_checks where
  srcDir := "conformance"
  root := `HexSignDet.FieldChecks

lean_exe hexrealformula_emit_fixtures where
  srcDir := "conformance"
  root := `HexRealFormula.EmitFixtures

lean_exe hexrcf_emit_fixtures where
  srcDir := "conformance"
  root := `HexRCF.EmitFixtures

lean_exe hexroots_emit_fixtures where
  srcDir := "conformance"
  root := `HexRoots.EmitFixtures

lean_exe hexrealalgebraic_emit_fixtures where
  srcDir := "conformance"
  root := `HexRealAlgebraic.EmitFixtures

lean_exe hexrealalgebraic_conformance where
  srcDir := "conformance"
  root := `HexRealAlgebraic.RunChecks

lean_exe hexnumberfield_emit_fixtures where
  srcDir := "conformance"
  root := `HexNumberField.EmitFixtures

lean_exe hexnumberfieldtower_emit_fixtures where
  srcDir := "conformance"
  root := `HexNumberFieldTower.EmitFixtures

lean_exe hexresultant_emit_fixtures where
  srcDir := "conformance"
  root := `HexResultant.EmitFixtures

lean_exe hexsparsepoly_bench where
  srcDir := "bench"
  root := `HexSparsePoly.Bench

lean_exe hexsparsepoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexSparsePoly.EmitFixtures

lean_lib HexGroebnerBenchSupport where
  srcDir := "bench"
  globs := #[`HexGroebner.Bench.Cauchy, `HexGroebner.Bench.Mersenne]

lean_exe hexgroebner_bench where
  srcDir := "bench"
  root := `HexGroebner.Bench

lean_exe hexgroebner_emit_f4 where
  srcDir := "conformance"
  root := `HexGroebner.EmitF4

lean_exe hexgroebner_emit_fixtures where
  srcDir := "conformance"
  root := `HexGroebner.EmitFixtures

lean_exe hexmvpoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexMvPoly.EmitFixtures

lean_exe hexdeterminantalideal_emit_fixtures where
  srcDir := "conformance"
  root := `HexDeterminantalIdeal.EmitFixtures

lean_exe hextruncatedseries_emit_fixtures where
  srcDir := "conformance"
  root := `HexTruncatedSeries.EmitFixtures

lean_exe hexmodular_emit_fixtures where
  srcDir := "conformance"
  root := `HexModular.EmitFixtures

lean_exe hexgraphiso_emit_fixtures where
  srcDir := "conformance"
  root := `HexGraphIso.EmitFixtures

lean_exe hexgraphiso_sparse_probe where
  srcDir := "conformance"
  root := `HexGraphIso.SparseProbe

lean_exe hexgraphiso_emit_sparse where
  srcDir := "conformance"
  root := `HexGraphIso.EmitSparse

lean_exe hexgraphiso_sparse_bench where
  srcDir := "bench"
  root := `HexGraphIso.SparseBench

lean_exe hexpermgroup_emit_fixtures where
  srcDir := "conformance"
  root := `HexPermGroup.EmitFixtures

lean_exe hexgraphiso_emit_campaign where
  srcDir := "conformance"
  root := `HexGraphIso.EmitCampaign

lean_exe hexpolyzgcd_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyZGcd.EmitFixtures

lean_exe hexpolysmith_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolySmith.EmitFixtures

lean_exe hexrationalfn_emit_fixtures where
  srcDir := "conformance"
  root := `HexRationalFn.EmitFixtures

lean_exe hexmodular_bench where
  srcDir := "bench"
  root := `HexModular.Bench
  extraDepTargets := #[`HexModularBenchSupport]

lean_exe hexmvgcd_emit_fixtures where
  srcDir := "conformance"
  root := `HexMvGcd.EmitFixtures

lean_exe hexmvhensel_emit_fixtures where
  srcDir := "conformance"
  root := `HexMvHensel.EmitFixtures

lean_exe hexmvfactor_emit_fixtures where
  srcDir := "conformance"
  root := `HexMvFactor.EmitFixtures

lean_exe hexroots_bench where
  srcDir := "bench"
  root := `HexRoots.Bench

lean_exe hexresultant_bench where
  srcDir := "bench"
  root := `HexResultant.Bench

lean_exe hexnumberfield_bench where
  srcDir := "bench"
  root := `HexNumberField.Bench

lean_exe hexrealclosure_bench where
  srcDir := "bench"
  root := `HexRealClosure.Bench

lean_exe hexrealclosure_phase4 where
  srcDir := "bench"
  root := `HexRealClosure.Phase4

lean_exe hexrealclosure_nested_normalization where
  srcDir := "bench"
  root := `HexRealClosure.NestedNormalization

lean_exe hexrealclosure_replay_size where
  srcDir := "conformance"
  root := `HexRealClosure.ReplaySize

lean_exe hexrealclosure_trivial_tests where
  root := `HexRealClosure.TrivialTowerTests

lean_exe hexrealclosure_trivial_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.TrivialConformance

lean_exe hexrealclosure_number_field_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.NumberFieldConformance

lean_exe hexrealclosure_number_field_samples where
  srcDir := "conformance"
  root := `HexRealClosure.NumberFieldSamples
lean_exe hexrealclosure_bytes_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.BytesConformance

lean_exe hexrealclosure_bounds_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.BoundsConformance

lean_lib HexRealClosureConformanceSupport where
  srcDir := "conformance"
  globs := #[.one `HexRealClosure.NestedReplay]

lean_exe hexrealclosure_sample_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.SampleConformance

lean_exe hexrealclosure_isolation_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.IsolationConformance

lean_exe hexrealclosure_deflation_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.DeflationConformance

lean_exe hexnumberfieldtower_bench where
  srcDir := "bench"
  root := `HexNumberFieldTower.Bench

lean_exe hexroots_demo where
  srcDir := "examples"
  root := `HexRootsDemo

lean_exe hexmatrix_bench where
  srcDir := "bench"
  root := `HexMatrix.Bench

-- The graph_iso fresh-module probes (SPEC/hex-graph-iso § Benchmarks and
-- SPEC/hex-graph-iso-theory § Tests): build-only structural checks of the
-- four release probe cases on each tactic route. The scheduled-only CFI
-- pair has its own target so the merge build stays inside its budget.
lean_lib HexGraphIsoProofProbe where
  srcDir := "bench"
  globs := #[`HexGraphIso.ProofProbe.Support,
    `HexGraphIso.ProofProbe.Positive12,
    `HexGraphIso.ProofProbe.Negative12,
    `HexGraphIso.ProofProbe.Coloured10Pos,
    `HexGraphIso.ProofProbe.Coloured10Neg].map Glob.one

lean_lib HexGraphIsoSparseProofProbe where
  srcDir := "bench"
  globs := #[`HexGraphIso.SparseProofProbe.Support,
    `HexGraphIso.SparseProofProbe.Positive12,
    `HexGraphIso.SparseProofProbe.Negative12,
    `HexGraphIso.SparseProofProbe.Coloured10Pos,
    `HexGraphIso.SparseProofProbe.Coloured10Neg]

lean_lib HexPermGroupTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexPermGroupTheory.ProofProbe.Kernel]

lean_lib HexGraphIsoTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexGraphIsoTheory.ProofProbe.Support,
    `HexGraphIsoTheory.ProofProbe.MathlibPositive12,
    `HexGraphIsoTheory.ProofProbe.MathlibNegative12].map Glob.one

lean_exe hexgraphiso_bench where
  srcDir := "bench"
  root := `HexGraphIso.Bench

lean_exe hexpermgroup_bench where
  srcDir := "bench"
  root := `HexPermGroup.Bench

-- Local/scheduled per-instance sweep for the cactus plots
-- (scripts/plots/hexgraphiso-cactus.py); not part of merge CI.
lean_exe hexgraphiso_cactus where
  srcDir := "bench"
  root := `HexGraphIso.Cactus

-- Stage-decomposition profiler for the canonicalization pipeline
-- (local tool; see bench/HexGraphIso/Profile.lean for methodology).
lean_exe hexgraphiso_profile where
  srcDir := "bench"
  root := `HexGraphIso.Profile

lean_exe hexrowreduce_bench where
  srcDir := "bench"
  root := `HexRowReduce.Bench

lean_exe hexdeterminant_bench where
  srcDir := "bench"
  root := `HexDeterminant.Bench

lean_exe hexdeterminantalideal_bench where
  srcDir := "bench"
  root := `HexDeterminantalIdeal.Bench

lean_exe hexmodularmatrix_bench where
  srcDir := "bench"
  root := `HexModularMatrix.Bench

lean_exe hexpolydet_bench where
  srcDir := "bench"
  root := `HexPolyDet.Bench

lean_exe hexbareiss_bench where
  srcDir := "bench"
  root := `HexBareiss.Bench

lean_exe hexposdef_bench where
  srcDir := "bench"
  root := `HexPosDef.Bench

lean_exe hexposdef_emit_fixtures where
  srcDir := "conformance"
  root := `HexPosDef.EmitFixtures

lean_exe hexdet_bench where
  srcDir := "bench"
  root := `HexDet.Bench

lean_exe hexgenericrank_bench where
  srcDir := "bench"
  root := `HexGenericRank.Bench

lean_exe hexrank_bench where
  srcDir := "bench"
  root := `HexRank.Bench

lean_exe hexhermite_bench where
  srcDir := "bench"
  root := `HexHermite.Bench

lean_exe hexsmith_bench where
  srcDir := "bench"
  root := `HexSmith.Bench

lean_exe hexcharpoly_bench where
  srcDir := "bench"
  root := `HexCharPoly.Bench

lean_exe hexminpoly_bench where
  srcDir := "bench"
  root := `HexMinPoly.Bench

lean_exe hexgramschmidt_bench where
  srcDir := "bench"
  root := `HexGramSchmidt.Bench

lean_exe hexsigndet_bench where
  srcDir := "bench"
  root := `HexSignDet.Bench

lean_exe hexsigndet_arithmetic_trace where
  srcDir := "bench"
  root := `HexSignDet.ArithmeticTrace

lean_lib HexSignDetBenchSupport where
  srcDir := "bench"
  globs := #[.one `HexSignDet.Input, .one `HexSignDet.Phases, .one `HexSignDet.Small,
    .one `HexSignDet.Paired, .one `HexSignDet.Maximal, .one `HexSignDet.Joint,
    .one `HexSignDet.MaximalMatrix, .one `HexSignDet.Height, .one `HexSignDet.NestedSigns,
    .one `HexSignDet.NestedTables, .one `HexSignDet.SharedRoots, .one `HexSignDet.InteractingTrace]

lean_exe hexrealalgebraic_bench where
  srcDir := "bench"
  root := `HexRealAlgebraic.Bench

lean_lib HexSturmBenchSupport where
  srcDir := "bench"
  globs := #[.one `HexSturm.Frontend]

lean_exe hexsturm_compare_exports where
  srcDir := "bench"
  root := `HexSturm.CompareExports

lean_exe hexsturm_bench where
  srcDir := "bench"
  root := `HexSturm.Bench

lean_exe hexrealroots_bench where
  srcDir := "bench"
  root := `HexRealRoots.Bench

lean_exe hexrealformula_bench where
  srcDir := "bench"
  root := `HexRealFormula.Bench

lean_exe hexrcf_bench where
  srcDir := "bench"
  root := `HexRCF.Bench

lean_exe hexlll_bench where
  srcDir := "bench"
  supportInterpreter := true
  root := `HexLLLBench.Main

lean_exe hexlll_gram_bench where
  srcDir := "bench"
  root := `HexLLLBench.GramBench

lean_exe hex_arith_floor where
  srcDir := "bench"
  root := `HexBench.ArithFloor

lean_exe hex_interval_representation_spike where
  srcDir := "bench"
  root := `HexBench.IntervalRepresentationSpike

lean_exe hex_interval_center_spike where
  srcDir := "bench"
  root := `HexBench.IntervalCenterSpike

lean_exe hex_interval_scale_spike where
  srcDir := "bench"
  root := `HexBench.IntervalScaleSpike

lean_exe hex_interval_scheduler_spike where
  srcDir := "bench"
  root := `HexInterval.IntervalSchedulerSpike

lean_exe hex_interval_policy_frontier_spike where
  srcDir := "bench"
  root := `HexInterval.IntervalPolicyFrontierSpike

lean_exe hexinterval_decision_bench where
  srcDir := "bench"
  root := `HexInterval.DecisionBench

lean_exe hexbz_factor_service where
  srcDir := "bench"
  root := `HexBench.FactorService

lean_exe hexbz_root_split_probe where
  srcDir := "bench"
  root := `HexBench.RootSplitProbe

lean_exe hexarith_bench where
  srcDir := "bench"
  root := `HexArith.Bench

lean_exe hexpoly_bench where
  srcDir := "bench"
  root := `HexPoly.Bench

lean_exe hexpolysmith_bench where
  srcDir := "bench"
  root := `HexPolySmith.Bench

lean_exe hexmvpoly_bench where
  srcDir := "bench"
  root := `HexMvPoly.Bench

lean_exe hexreflect_bench where
  srcDir := "bench"
  root := `HexReflect.Bench

lean_exe hexmvgcd_bench where
  srcDir := "bench"
  root := `HexMvGcd.Bench

lean_exe hextruncatedseries_bench where
  srcDir := "bench"
  root := `HexTruncatedSeries.Bench

lean_exe hexpolyfast_bench where
  srcDir := "bench"
  root := `HexPolyFast.Bench

lean_exe hexrationalfn_bench where
  srcDir := "bench"
  root := `HexRationalFn.Bench

lean_exe hexorderedfn_liouville_test where
  root := `HexOrderedFnTheory.LiouvilleRun

lean_exe hexorderedfn_emit_real_fixtures where
  srcDir := "conformance"
  root := `HexOrderedFn.EmitRealFixtures

lean_exe hexorderedfn_emit_fixtures where
  srcDir := "conformance"
  root := `HexOrderedFn.EmitFixtures

lean_exe hexorderedfn_bench where
  srcDir := "bench"
  root := `HexOrderedFn.Bench

lean_lib HexRationalFnBenchSupport where
  srcDir := "bench"
  roots := #[`HexRationalFn.Scaling, `HexRationalFn.Families,
    `HexRationalFn.Workloads, `HexRationalFn.Fixtures, `HexRationalFn.Nested]

lean_lib HexRationalFnKernelProbe where
  srcDir := "bench"
  globs := #[`HexRationalFn.ProofProbe.Support,
    `HexRationalFn.ProofProbe.Replay4,
    `HexRationalFn.ProofProbe.Reject64].map Glob.one

lean_exe hexpolyfast_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyFast.EmitFixtures

lean_exe hexpoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexPoly.EmitFixtures

lean_exe hexkronecker_emit_fixtures where
  srcDir := "conformance"
  root := `HexKronecker.EmitFixtures

lean_exe hexkronecker_bench where
  srcDir := "bench"
  root := `HexKronecker.Bench

lean_exe hexpolyfp_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyFp.EmitFixtures

lean_exe hexberlekamp_emit_fixtures where
  srcDir := "conformance"
  root := `HexBerlekamp.EmitFixtures

lean_exe hexbz_emit_fixtures where
  srcDir := "conformance"
  root := `HexBerlekampZassenhaus.EmitFixtures

lean_exe hexbz_bench where
  srcDir := "bench"
  root := `HexBerlekampZassenhaus.Bench

lean_exe hexgfq_emit_fixtures where
  srcDir := "conformance"
  root := `HexGFq.EmitFixtures

lean_exe hexgf2_emit_fixtures where
  srcDir := "conformance"
  root := `HexGF2.EmitFixtures

lean_exe hexhensel_emit_fixtures where
  srcDir := "conformance"
  root := `HexHensel.EmitFixtures

lean_exe hexprimality_emit_fixtures where
  srcDir := "conformance"
  root := `HexPrimality.EmitFixtures

lean_exe hexecpp_emit_fixtures where
  srcDir := "conformance"
  root := `HexECPP.EmitFixtures

lean_exe hexintfactor_emit_fixtures where
  srcDir := "conformance"
  root := `HexIntFactor.EmitFixtures

lean_exe hexconway_emit_fixtures where
  srcDir := "conformance"
  root := `HexConway.EmitFixtures

lean_exe hexgfqring_emit_fixtures where
  srcDir := "conformance"
  root := `HexGFqRing.EmitFixtures

lean_exe hexgfqfield_emit_fixtures where
  srcDir := "conformance"
  root := `HexGFqField.EmitFixtures

lean_exe hexpolyz_bench where
  srcDir := "bench"
  root := `HexPolyZ.Bench

lean_exe hexpolyzgcd_bench where
  srcDir := "bench"
  root := `HexPolyZGcd.Bench

lean_exe hexpolyz_kronecker_crossover where
  srcDir := "bench"
  root := `HexPolyZ.KroneckerCrossover

lean_exe hexpolyz_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyZ.EmitFixtures

lean_exe hexmodarith_bench where
  srcDir := "bench"
  root := `HexModArith.Bench

lean_exe hexgf2_bench where
  srcDir := "bench"
  root := `HexGF2Bench

-- No bench exes for `Hex*Theory` libraries — see
-- SPEC/benchmarking.md §Mathlib-free benches. The Mathlib-side libraries
-- are proof-only; there is no computational kernel to benchmark.

lean_exe hexpolyfp_bench where
  srcDir := "bench"
  root := `HexPolyFp.Bench

lean_exe hexgfqring_bench where
  srcDir := "bench"
  root := `HexGFqRing.Bench

lean_exe hexgfqfield_bench where
  srcDir := "bench"
  root := `HexGFqField.Bench

lean_exe hexgfq_bench where
  srcDir := "bench"
  root := `HexGFq.Bench

lean_exe hexhensel_bench where
  srcDir := "bench"
  root := `HexHensel.Bench

lean_exe hexprimality_bench where
  srcDir := "bench"
  root := `HexPrimality.Bench

lean_exe hexprimality_squfof_measure where
  srcDir := "bench"
  root := `HexPrimality.SqufofMeasure
lean_exe hexecpp_bench where
  srcDir := "bench"
  root := `HexECPP.Bench

lean_exe hexprimality_policy_probe where
  srcDir := "bench"
  root := `HexPrimality.PolicyProbe

lean_exe hexprimality_field_probe where
  srcDir := "bench"
  root := `HexPrimality.FieldProbe

lean_exe hexprimality_factor_experiment where
  srcDir := "bench"
  root := `HexPrimality.FactorExperiment

lean_exe hexprimality_fuel_probe where
  srcDir := "bench"
  root := `HexPrimality.FuelProbe

-- Expensive exact construction guards run only for the owning library in CI.
lean_lib HexIntFactorFieldConformance where
  srcDir := "conformance"
  globs := #[`HexIntFactor.FieldConstruction, `HexIntFactor.FieldMathlib].map Glob.one

lean_exe hexintfactor_field_bench where
  srcDir := "bench"
  root := `HexIntFactor.FieldSearchBench

lean_exe hexintfactor_bench where
  srcDir := "bench"
  root := `HexIntFactor.Bench

lean_exe hexberlekamp_bench where
  srcDir := "bench"
  root := `HexBerlekamp.Bench

-- Local (non-CI, non-LeanBench) comparison driver for the Strassen base-kernel
-- measurement; emits JSON for `scripts/plots/strassen-base-kernel-comparison.py`.
lean_exe hexstrassen_compare where
  srcDir := "bench"
  root := `HexStrassen.Compare

lean_exe hexconway_replay where
  srcDir := "bench"
  root := `HexConway.Replay

lean_exe hexconway_bench where
  srcDir := "bench"
  root := `HexConway.Bench

@[default_target]
lean_lib HexManual where

lean_exe hexlatticeenum_bench where
  srcDir := "bench"
  root := `HexLatticeEnum.Bench

lean_exe tower_factor_diff where
  srcDir := "bench"
  root := `HexNumberFieldTower.FactorDiff

lean_exe hexgraphiso_emit_trace where
  srcDir := "conformance"
  root := `HexGraphIso.EmitTrace

lean_exe hexnumberfield_quadratic where
  srcDir := "bench"
  root := `HexNumberField.Quadratic

lean_lib HexCharPolyTheoryProofProbe where
  srcDir := "bench"
  globs := #[`HexCharPolyTheory.ProofProbe.Support,
    `HexCharPolyTheory.ProofProbe.BlockSupport,
    `HexCharPolyTheory.ProofProbe.ComputedSupport,
    `HexCharPolyTheory.ProofProbe.Examples].map Glob.one

-- Manual issue-10301 experiments; neither target belongs to the default build or CI.
lean_lib CadSampleCostsExperiment where
  srcDir := "experiments"
  globs := #[.submodules `CadSampleCosts]

lean_exe cad_sample_costs where
  srcDir := "experiments"
  root := `CadSampleCosts.Runtime

-- Serial native ECPP campaign driver; no Mathlib dependency.
lean_exe hexecpp_native where
  srcDir := "bench"
  root := `HexECPP.Native

-- Full current construction comparator, including the registered ECM retry.
lean_exe hexecpp_compare where
  srcDir := "bench"
  root := `HexECPP.Compare

-- Larger CFI correctness fixtures are optional manual builds.
lean_lib HexGraphIsoCfiDiagnostics where
  srcDir := "conformance"
  globs := #[`HexGraphIso.Diagnostics.DenseCfi,
    `HexGraphIso.Diagnostics.SparseCfi].map Glob.one

-- Focused larger symbolic determinant correctness fixtures.
lean_lib HexPolyDetTheoryDiagnostics where
  srcDir := "conformance"
  globs := #[.submodules `HexPolyDetTheory.Diagnostics]

-- Generated paired measurement arms, outside the representative CI target.
lean_lib HexCharPolyTheoryMeasurements where
  srcDir := "bench"
  globs := #[
    `HexCharPolyTheory.ProofProbe.Dense4Check,
    `HexCharPolyTheory.ProofProbe.Dense4Block,
    `HexCharPolyTheory.ProofProbe.Dense4Quoted,
    `HexCharPolyTheory.ProofProbe.Dense4Computed,
    `HexCharPolyTheory.ProofProbe.Dense4Rank,
    `HexCharPolyTheory.ProofProbe.Dense4Original,
    `HexCharPolyTheory.ProofProbe.Dense4Packed,
    `HexCharPolyTheory.ProofProbe.Dense8Check,
    `HexCharPolyTheory.ProofProbe.Dense8Block,
    `HexCharPolyTheory.ProofProbe.Dense8Quoted,
    `HexCharPolyTheory.ProofProbe.Dense8Computed,
    `HexCharPolyTheory.ProofProbe.Dense8Rank,
    `HexCharPolyTheory.ProofProbe.Dense8Original,
    `HexCharPolyTheory.ProofProbe.Dense8Packed,
    `HexCharPolyTheory.ProofProbe.Dense16Check,
    `HexCharPolyTheory.ProofProbe.Dense16Block,
    `HexCharPolyTheory.ProofProbe.Dense16Quoted,
    `HexCharPolyTheory.ProofProbe.Dense16Computed,
    `HexCharPolyTheory.ProofProbe.Dense16Rank,
    `HexCharPolyTheory.ProofProbe.Dense16Original,
    `HexCharPolyTheory.ProofProbe.Dense16Packed,
    `HexCharPolyTheory.ProofProbe.Dense32Check,
    `HexCharPolyTheory.ProofProbe.Dense32Block,
    `HexCharPolyTheory.ProofProbe.Dense32Quoted,
    `HexCharPolyTheory.ProofProbe.Dense32Computed,
    `HexCharPolyTheory.ProofProbe.Dense32Rank,
    `HexCharPolyTheory.ProofProbe.Dense32Original,
    `HexCharPolyTheory.ProofProbe.Dense32Packed,
    `HexCharPolyTheory.ProofProbe.Dense16Candidate,
    `HexCharPolyTheory.ProofProbe.Dense16Reference].map Glob.one

-- Fixed CM data and bounded roots for the independent analytic oracle.
lean_exe hexecpp_emit_class_polynomials where
  srcDir := "conformance"
  root := `HexECPP.EmitClassPolynomials

lean_lib KernelReplayExperiment where
  srcDir := "experiments"
  globs := #[.one `KernelReplay.Assemble, .one `KernelReplay.Json, .one `KernelReplay.Generated,
    .one `KernelReplay.NativePackets,
    .one `KernelReplay.NativeModels,
    .one `KernelReplay.NativeReplay,
    .one `KernelReplay.NativeValues,
    .one `KernelReplay.NativeFactory,
    .one `KernelReplay.NativeChildren,
    .one `KernelReplay.NativeReaders,
    .one `KernelReplay.NativeAssembly,
    .one `KernelReplay.NativeAssemblyModels,
    .one `KernelReplay.NativeAssemblyStaged,
    .one `KernelReplay.FrameEncode,
    .one `KernelReplay.FrameData,
    .one `KernelReplay.FrameDataProbe,
    .one `KernelReplay.FrameSource,
    .one `KernelReplay.NativeAssemblyNestedData,
    .one `KernelReplay.FrameNested,
    .one `KernelReplay.FrameJoint,
    .one `KernelReplay.GuardNativeFrontier,
    .one `KernelReplay.GuardNativeBindings,
    .one `KernelReplay.GuardNativeAudit,
    .one `KernelReplay.GuardRecordStore,
    .one `KernelReplay.GuardRecordReplay,
    .one `KernelReplay.GuardRecordAudit,
    .one `KernelReplay.GuardInventoryReplay,
    .one `KernelReplay.GuardInventoryAudit,
    .one `KernelReplay.GuardInventoryPublic,
    .one `KernelReplay.GuardInventoryPublicAudit,
    .one `KernelReplay.GuardDescriptorInputs,
    .one `KernelReplay.GuardDescriptorInputsAudit,
    .one `KernelReplay.GuardCoefficientIndex,
    .one `KernelReplay.GuardDescriptorReductions,
    .one `KernelReplay.GuardDescriptorReductionsAudit,
    .one `KernelReplay.GuardCoefficientControl,
    .one `KernelReplay.GuardPrimitiveFacts,
    .one `KernelReplay.GuardPrimitiveAudit,
    .one `KernelReplay.GuardDescriptorSupplier,
    .one `KernelReplay.GuardChainStart,
    .one `KernelReplay.GuardChainEnd,
    .one `KernelReplay.GuardChainPublic,
    .one `KernelReplay.GuardChainPublicAudit,
    .one `KernelReplay.GuardMomentFirst,
    .one `KernelReplay.GuardMomentPublic,
    .one `KernelReplay.GuardMomentPublicAudit,
    .one `KernelReplay.GuardNextChainStart,
    .one `KernelReplay.GuardNextChainEnd,
    .one `KernelReplay.GuardNextChainPublic,
    .one `KernelReplay.GuardNextChainPublicAudit,
    .one `KernelReplay.GuardRemainderStart,
    .one `KernelReplay.GuardRemainderEnd,
    .one `KernelReplay.GuardRemainderPublic,
    .one `KernelReplay.GuardRemainderPublicAudit,
    .one `KernelReplay.GuardMomentSecond,
    .one `KernelReplay.GuardMomentSecondPublic,
    .one `KernelReplay.GuardMomentSecondPublicAudit,
    .one `KernelReplay.GuardLastChainStart,
    .one `KernelReplay.GuardLastChainEnd,
    .one `KernelReplay.GuardLastChainPublic,
    .one `KernelReplay.GuardLastChainPublicAudit,
    .one `KernelReplay.GuardLastRemainderStart,
    .one `KernelReplay.GuardRecurrenceShape,
    .one `KernelReplay.GuardRecurrenceInputs,
    .one `KernelReplay.GuardRecurrenceEnd,
    .one `KernelReplay.GuardLastRemainderEnd,
    .one `KernelReplay.GuardLastRemainderPublic,
    .one `KernelReplay.GuardLastRemainderPublicAudit,
    .one `KernelReplay.GuardMomentLast,
    .one `KernelReplay.GuardMomentAll,
    .one `KernelReplay.GuardMomentAllPublic,
    .one `KernelReplay.GuardMomentAllPublicAudit,
    .one `KernelReplay.GuardDescriptorPoint,
    .one `KernelReplay.GuardDescriptorPublic,
    .one `KernelReplay.GuardDescriptorPublicAudit,
    .one `KernelReplay.GuardPackingShape,
    .one `KernelReplay.GuardPackingNodeInputs,
    .one `KernelReplay.GuardPackingInputsAudit,
    .one `KernelReplay.GuardPackingQueries,
    .one `KernelReplay.GuardPackingRoot,
    .one `KernelReplay.GuardPackingRootPublic,
    .one `KernelReplay.GuardPackingRootPublicAudit,
    .one `KernelReplay.GuardPackingLeaf,
    .one `KernelReplay.GuardPackingBranchInputs,
    .one `KernelReplay.GuardPackingBranchQueries,
    .one `KernelReplay.GuardPackingBranch,
    .one `KernelReplay.GuardPackingBranchPublic,
    .one `KernelReplay.GuardPackingBranchPublicAudit,
    .one `KernelReplay.GuardPackingRightInputs,
    .one `KernelReplay.GuardPackingRightQueries,
    .one `KernelReplay.GuardPackingRight,
    .one `KernelReplay.GuardPackingRightPublic,
    .one `KernelReplay.GuardPackingRightPublicAudit,
    .one `KernelReplay.GuardPackingRecord,
    .one `KernelReplay.GuardPackingRecordPublic,
    .one `KernelReplay.GuardPackingRecordPublicAudit,
    .one `KernelReplay.GuardRemainingShape,
    .one `KernelReplay.GuardRemainingInputs,
    .one `KernelReplay.GuardCoefficientReduce,
    .one `KernelReplay.GuardCoefficientReduceControl,
    .one `KernelReplay.GuardRemainingControlAudit,
    .one `KernelReplay.GuardRemainingInput00,
    .one `KernelReplay.GuardRemainingInput01,
    .one `KernelReplay.GuardRemainingInput02,
    .one `KernelReplay.GuardRemainingInput03,
    .one `KernelReplay.GuardRemainingInput04,
    .one `KernelReplay.GuardRemainingInput05,
    .one `KernelReplay.GuardRemainingInput06,
    .one `KernelReplay.GuardRemainingInput07,
    .one `KernelReplay.GuardRemainingInput08,
    .one `KernelReplay.GuardRemainingInput09,
    .one `KernelReplay.GuardRemainingInputsAudit,
    .one `KernelReplay.GuardRemainingQuery,
    .one `KernelReplay.GuardRemainingChain00,
    .one `KernelReplay.GuardRemainingChain01,
    .one `KernelReplay.GuardRemainingProof00,
    .one `KernelReplay.GuardRemainingFirstPublic,
    .one `KernelReplay.GuardRemainingFirstPublicAudit,
    .one `KernelReplay.GuardRemainingProof01,
    .one `KernelReplay.GuardRemainingRootQueriesPublic,
    .one `KernelReplay.GuardRemainingRootQueriesAudit,
    .one `KernelReplay.GuardRemainingProof02,
    .one `KernelReplay.GuardRemainingProof03,
    .one `KernelReplay.GuardRemainingProof04,
    .one `KernelReplay.GuardRemainingProof05,
    .one `KernelReplay.GuardRemainingProof06,
    .one `KernelReplay.GuardRemainingProof07,
    .one `KernelReplay.GuardRemainingProof08,
    .one `KernelReplay.GuardRemainingProof09,
    .one `KernelReplay.GuardRemainingProof10,
    .one `KernelReplay.GuardRemainingProof11,
    .one `KernelReplay.GuardRemainingQueriesPublic,
    .one `KernelReplay.GuardRemainingQueriesAudit,
    .one `KernelReplay.GuardRemainingProof12,
    .one `KernelReplay.GuardRemainingProof13,
    .one `KernelReplay.GuardRemainingProof14,
    .one `KernelReplay.GuardRemainingProof15,
    .one `KernelReplay.GuardRemainingProof16,
    .one `KernelReplay.GuardRemainingProof17,
    .one `KernelReplay.GuardRemainingProof18,
    .one `KernelReplay.GuardRemainingProof19,
    .one `KernelReplay.GuardRemainingProof20,
    .one `KernelReplay.GuardRemainingProof21,
    .one `KernelReplay.GuardRemainingProof22,
    .one `KernelReplay.GuardRemainingProof23,
    .one `KernelReplay.GuardLastQueriesPublic,
    .one `KernelReplay.GuardLastQueriesAudit,
    .one `KernelReplay.GuardRemainingNodes,
    .one `KernelReplay.GuardRemainingNodesPublic,
    .one `KernelReplay.GuardRemainingNodesAudit,
    .one `KernelReplay.GuardRemainingRecords,
    .one `KernelReplay.GuardRemainingRecord2,
    .one `KernelReplay.GuardRemainingRecordsPublic,
    .one `KernelReplay.GuardRemainingRecordsAudit,
    .one `KernelReplay.GuardSecondData,
    .one `KernelReplay.GuardSecondPublic,
    .one `KernelReplay.GuardSecondPublicAudit,
    .one `KernelReplay.GuardOperand,
    .one `KernelReplay.GuardFrontierStore,
    .one `KernelReplay.GuardFrontier,
    .one `KernelReplay.GuardFrontierBindings,
    .one `KernelReplay.GuardRecordExt,
    .one `KernelReplay.GuardReplayBindings,
    .one `KernelReplay.GuardReplayBindingsAudit,
    .one `KernelReplay.GuardObligations,
    .one `KernelReplay.GuardFirstPublic,
    .one `KernelReplay.GuardFirstPublicAudit,
    .one `KernelReplay.GuardObligations01,
    .one `KernelReplay.GuardObligations02,
    .one `KernelReplay.GuardObligations03,
    .one `KernelReplay.GuardObligations04,
    .one `KernelReplay.GuardObligations05,
    .one `KernelReplay.GuardObligations06,
    .one `KernelReplay.GuardPrefixAudit,
    .one `KernelReplay.GuardObligations07,
    .one `KernelReplay.GuardObligations08,
    .one `KernelReplay.GuardObligations09,
    .one `KernelReplay.GuardObligations10,
    .one `KernelReplay.GuardObligations11,
    .one `KernelReplay.GuardObligations12,
    .one `KernelReplay.GuardObligations13,
    .one `KernelReplay.GuardObligations14,
    .one `KernelReplay.GuardObligations15,
    .one `KernelReplay.GuardObligations16,
    .one `KernelReplay.GuardObligations17,
    .one `KernelReplay.GuardObligations18,
    .one `KernelReplay.GuardObligations19,
    .one `KernelReplay.GuardObligations20,
    .one `KernelReplay.GuardObligations21,
    .one `KernelReplay.GuardObligations22,
    .one `KernelReplay.GuardObligations23,
    .one `KernelReplay.GuardObligations24,
    .one `KernelReplay.GuardObligations25,
    .one `KernelReplay.GuardObligations26,
    .one `KernelReplay.GuardObligations27,
    .one `KernelReplay.GuardObligations28,
    .one `KernelReplay.GuardObligations29,
    .one `KernelReplay.GuardObligations30,
    .one `KernelReplay.GuardObligations31,
    .one `KernelReplay.GuardObligations32,
    .one `KernelReplay.GuardObligations33,
    .one `KernelReplay.GuardObligations34,
    .one `KernelReplay.GuardObligations35,
    .one `KernelReplay.GuardObligations36,
    .one `KernelReplay.GuardObligations37,
    .one `KernelReplay.GuardObligations38,
    .one `KernelReplay.GuardObligations39,
    .one `KernelReplay.GuardObligations40,
    .one `KernelReplay.GuardObligations41,
    .one `KernelReplay.GuardObligations42,
    .one `KernelReplay.GuardObligations43,
    .one `KernelReplay.GuardObligations44,
    .one `KernelReplay.GuardObligations45,
    .one `KernelReplay.GuardObligations46,
    .one `KernelReplay.GuardObligations47,
    .one `KernelReplay.GuardObligations48,
    .one `KernelReplay.GuardObligations49,
    .one `KernelReplay.GuardObligations50,
    .one `KernelReplay.GuardObligations51,
    .one `KernelReplay.GuardObligations52,
    .one `KernelReplay.GuardObligations53,
    .one `KernelReplay.GuardObligations54,
    .one `KernelReplay.GuardObligations55,
    .one `KernelReplay.GuardObligations56,
    .one `KernelReplay.GuardObligations57,
    .one `KernelReplay.GuardObligations58,
    .one `KernelReplay.GuardObligations59,
    .one `KernelReplay.GuardObligations60,
    .one `KernelReplay.GuardObligations61,
    .one `KernelReplay.GuardObligations62,
    .one `KernelReplay.GuardObligations63,
    .one `KernelReplay.GuardObligations64,
    .one `KernelReplay.GuardObligations65,
    .one `KernelReplay.GuardObligations66,
    .one `KernelReplay.GuardObligations67,
    .one `KernelReplay.GuardObligations68,
    .one `KernelReplay.GuardObligations69,
    .one `KernelReplay.GuardObligations70,
    .one `KernelReplay.GuardObligations71,
    .one `KernelReplay.GuardObligations72,
    .one `KernelReplay.GuardObligations73,
    .one `KernelReplay.GuardObligations74,
    .one `KernelReplay.GuardObligations75,
    .one `KernelReplay.GuardObligations76,
    .one `KernelReplay.GuardObligations77,
    .one `KernelReplay.GuardObligations78,
    .one `KernelReplay.GuardObligations79,
    .one `KernelReplay.GuardObligations80,
    .one `KernelReplay.GuardObligations81,
    .one `KernelReplay.GuardObligations82,
    .one `KernelReplay.GuardObligations83,
    .one `KernelReplay.GuardObligations84,
    .one `KernelReplay.GuardObligations85,
    .one `KernelReplay.GuardObligations86,
    .one `KernelReplay.GuardObligations87,
    .one `KernelReplay.GuardObligations88,
    .one `KernelReplay.GuardObligations89,
    .one `KernelReplay.GuardObligations90,
    .one `KernelReplay.GuardObligations91,
    .one `KernelReplay.GuardObligations92,
    .one `KernelReplay.GuardObligations93,
    .one `KernelReplay.GuardObligations94,
    .one `KernelReplay.GuardObligations95,
    .one `KernelReplay.GuardObligations96,
    .one `KernelReplay.GuardObligations97,
    .one `KernelReplay.GuardObligations98,
    .one `KernelReplay.GuardObligations99,
    .one `KernelReplay.GuardObligations100,
    .one `KernelReplay.GuardObligations101,
    .one `KernelReplay.GuardObligations102,
    .one `KernelReplay.GuardObligations103,
    .one `KernelReplay.GuardObligations104,
    .one `KernelReplay.GuardObligations105,
    .one `KernelReplay.GuardObligations106,
    .one `KernelReplay.GuardObligations107,
    .one `KernelReplay.GuardObligations108,
    .one `KernelReplay.GuardObligations109,
    .one `KernelReplay.GuardObligations110,
    .one `KernelReplay.GuardObligations111,
    .one `KernelReplay.GuardObligations112,
    .one `KernelReplay.GuardObligations113,
    .one `KernelReplay.GuardObligations114,
    .one `KernelReplay.GuardObligations115,
    .one `KernelReplay.GuardObligations116,
    .one `KernelReplay.GuardObligations117,
    .one `KernelReplay.GuardObligations118,
    .one `KernelReplay.GuardObligations119,
    .one `KernelReplay.GuardObligations120,
    .one `KernelReplay.GuardObligations121,
    .one `KernelReplay.GuardObligations122,
    .one `KernelReplay.GuardObligations123,
    .one `KernelReplay.GuardObligations124,
    .one `KernelReplay.GuardObligations125,
    .one `KernelReplay.GuardObligations126,
    .one `KernelReplay.GuardObligations127,
    .one `KernelReplay.GuardObligations128,
    .one `KernelReplay.GuardObligations129,
    .one `KernelReplay.GuardObligations130,
    .one `KernelReplay.GuardObligations131,
    .one `KernelReplay.GuardObligations132,
    .one `KernelReplay.GuardObligations133,
    .one `KernelReplay.GuardObligations134,
    .one `KernelReplay.GuardObligations135,
    .one `KernelReplay.GuardObligations136,
    .one `KernelReplay.GuardObligations137,
    .one `KernelReplay.GuardObligations138,
    .one `KernelReplay.GuardObligations139,
    .one `KernelReplay.GuardObligations140,
    .one `KernelReplay.GuardObligations141,
    .one `KernelReplay.GuardObligations142,
    .one `KernelReplay.GuardObligations143,
    .one `KernelReplay.GuardObligations144,
    .one `KernelReplay.GuardObligations145,
    .one `KernelReplay.GuardObligations146,
    .one `KernelReplay.GuardObligations147,
    .one `KernelReplay.GuardObligations148,
    .one `KernelReplay.GuardObligations149,
    .one `KernelReplay.GuardObligations150,
    .one `KernelReplay.GuardObligations151,
    .one `KernelReplay.GuardObligations152,
    .one `KernelReplay.GuardObligations153,
    .one `KernelReplay.GuardObligations154,
    .one `KernelReplay.GuardObligations155,
    .one `KernelReplay.GuardObligations156,
    .one `KernelReplay.GuardObligations157,
    .one `KernelReplay.GuardObligations158,
    .one `KernelReplay.GuardObligations159,
    .one `KernelReplay.GuardObligations160,
    .one `KernelReplay.GuardObligations161,
    .one `KernelReplay.GuardObligations162,
    .one `KernelReplay.GuardObligations163,
    .one `KernelReplay.GuardObligations164,
    .one `KernelReplay.GuardObligations165,
    .one `KernelReplay.GuardObligations166,
    .one `KernelReplay.GuardObligations167,
    .one `KernelReplay.GuardObligations168,
    .one `KernelReplay.GuardObligations169,
    .one `KernelReplay.GuardObligations170,
    .one `KernelReplay.GuardObligations171,
    .one `KernelReplay.GuardObligations172,
    .one `KernelReplay.GuardObligations173,
    .one `KernelReplay.GuardObligations174,
    .one `KernelReplay.GuardObligations175,
    .one `KernelReplay.GuardObligations176,
    .one `KernelReplay.GuardObligations177,
    .one `KernelReplay.GuardObligations178,
    .one `KernelReplay.GuardObligations179,
    .one `KernelReplay.GuardObligations180,
    .one `KernelReplay.GuardObligations181,
    .one `KernelReplay.GuardObligations182,
    .one `KernelReplay.GuardObligations183,
    .one `KernelReplay.GuardObligations184,
    .one `KernelReplay.GuardObligations185,
    .one `KernelReplay.GuardObligations186,
    .one `KernelReplay.GuardObligations187,
    .one `KernelReplay.GuardObligations188,
    .one `KernelReplay.GuardObligations189,
    .one `KernelReplay.GuardObligations190,
    .one `KernelReplay.GuardObligations191,
    .one `KernelReplay.GuardObligations192,
    .one `KernelReplay.GuardObligations193,
    .one `KernelReplay.GuardObligations194,
    .one `KernelReplay.GuardObligations195,
    .one `KernelReplay.GuardObligations196,
    .one `KernelReplay.GuardObligations197,
    .one `KernelReplay.GuardObligations198,
    .one `KernelReplay.GuardObligations199,
    .one `KernelReplay.GuardObligations200,
    .one `KernelReplay.GuardObligations201,
    .one `KernelReplay.GuardObligations202,
    .one `KernelReplay.GuardObligations203,
    .one `KernelReplay.GuardObligations204,
    .one `KernelReplay.GuardObligations205,
    .one `KernelReplay.GuardObligations206,
    .one `KernelReplay.GuardObligations207,
    .one `KernelReplay.GuardObligations208,
    .one `KernelReplay.GuardObligations209,
    .one `KernelReplay.GuardObligations210,
    .one `KernelReplay.GuardObligations211,
    .one `KernelReplay.GuardObligations212,
    .one `KernelReplay.GuardObligations213,
    .one `KernelReplay.GuardObligations214,
    .one `KernelReplay.GuardObligations215,
    .one `KernelReplay.GuardObligations216,
    .one `KernelReplay.GuardObligations217,
    .one `KernelReplay.GuardObligations218,
    .one `KernelReplay.GuardObligations219,
    .one `KernelReplay.GuardObligations220,
    .one `KernelReplay.GuardObligations221,
    .one `KernelReplay.GuardObligations222,
    .one `KernelReplay.GuardObligations223,
    .one `KernelReplay.GuardObligations224,
    .one `KernelReplay.GuardObligations225,
    .one `KernelReplay.GuardObligations226,
    .one `KernelReplay.GuardObligations227,
    .one `KernelReplay.GuardObligations228,
    .one `KernelReplay.GuardObligations229,
    .one `KernelReplay.GuardObligations230,
    .one `KernelReplay.GuardObligations231,
    .one `KernelReplay.GuardObligations232,
    .one `KernelReplay.GuardObligations233,
    .one `KernelReplay.GuardObligations234,
    .one `KernelReplay.GuardObligations235,
    .one `KernelReplay.GuardObligations236,
    .one `KernelReplay.GuardObligations237,
    .one `KernelReplay.GuardObligations238,
    .one `KernelReplay.GuardObligations239,
    .one `KernelReplay.GuardObligations240,
    .one `KernelReplay.GuardObligations241,
    .one `KernelReplay.GuardObligations242,
    .one `KernelReplay.GuardObligations243,
    .one `KernelReplay.GuardObligations244,
    .one `KernelReplay.GuardObligations245,
    .one `KernelReplay.GuardObligations246,
    .one `KernelReplay.GuardObligations247,
    .one `KernelReplay.GuardObligations248,
    .one `KernelReplay.GuardObligations249,
    .one `KernelReplay.GuardObligations250,
    .one `KernelReplay.GuardObligations251,
    .one `KernelReplay.GuardObligations252,
    .one `KernelReplay.GuardObligations253,
    .one `KernelReplay.GuardObligations254,
    .one `KernelReplay.GuardObligations255,
    .one `KernelReplay.GuardObligations256,
    .one `KernelReplay.GuardObligations257,
    .one `KernelReplay.GuardObligations258,
    .one `KernelReplay.GuardObligations259,
    .one `KernelReplay.GuardObligations260,
    .one `KernelReplay.GuardObligations261,
    .one `KernelReplay.GuardObligations262,
    .one `KernelReplay.GuardObligations263,
    .one `KernelReplay.GuardObligations264,
    .one `KernelReplay.GuardObligations265,
    .one `KernelReplay.GuardObligations266,
    .one `KernelReplay.GuardObligations267,
    .one `KernelReplay.GuardObligations268,
    .one `KernelReplay.GuardObligations269,
    .one `KernelReplay.GuardObligations270,
    .one `KernelReplay.GuardObligations271,
    .one `KernelReplay.GuardObligations272,
    .one `KernelReplay.GuardObligations273,
    .one `KernelReplay.GuardObligations274,
    .one `KernelReplay.GuardObligations275,
    .one `KernelReplay.GuardObligations276,
    .one `KernelReplay.GuardObligations277,
    .one `KernelReplay.GuardObligations278,
    .one `KernelReplay.GuardObligations279,
    .one `KernelReplay.GuardObligations280,
    .one `KernelReplay.GuardObligations281,
    .one `KernelReplay.GuardObligations282,
    .one `KernelReplay.GuardObligations283,
    .one `KernelReplay.GuardObligations284,
    .one `KernelReplay.GuardObligations285,
    .one `KernelReplay.GuardObligations286,
    .one `KernelReplay.GuardObligations287,
    .one `KernelReplay.GuardObligations288,
    .one `KernelReplay.GuardObligations289,
    .one `KernelReplay.GuardObligations290,
    .one `KernelReplay.GuardObligations291,
    .one `KernelReplay.GuardObligations292,
    .one `KernelReplay.GuardObligations293,
    .one `KernelReplay.GuardObligations294,
    .one `KernelReplay.GuardObligations295,
    .one `KernelReplay.GuardObligations296,
    .one `KernelReplay.GuardObligations297,
    .one `KernelReplay.GuardObligations298,
    .one `KernelReplay.GuardObligations299,
    .one `KernelReplay.GuardObligations300,
    .one `KernelReplay.GuardObligations301,
    .one `KernelReplay.GuardObligations302,
    .one `KernelReplay.GuardObligations303,
    .one `KernelReplay.GuardObligations304,
    .one `KernelReplay.GuardObligations305,
    .one `KernelReplay.GuardObligations306,
    .one `KernelReplay.GuardObligations307,
    .one `KernelReplay.GuardObligations308,
    .one `KernelReplay.GuardObligations309,
    .one `KernelReplay.GuardObligations310,
    .one `KernelReplay.GuardObligations311,
    .one `KernelReplay.GuardObligations312,
    .one `KernelReplay.GuardObligations313,
    .one `KernelReplay.GuardObligations314,
    .one `KernelReplay.GuardObligations315,
    .one `KernelReplay.GuardObligations316,
    .one `KernelReplay.GuardObligations317,
    .one `KernelReplay.GuardObligations318,
    .one `KernelReplay.GuardObligations319,
    .one `KernelReplay.GuardObligations320,
    .one `KernelReplay.GuardObligations321,
    .one `KernelReplay.GuardObligations322,
    .one `KernelReplay.GuardObligations323,
    .one `KernelReplay.GuardObligations324,
    .one `KernelReplay.GuardObligations325,
    .one `KernelReplay.GuardObligations326,
    .one `KernelReplay.GuardObligations327,
    .one `KernelReplay.GuardObligations328,
    .one `KernelReplay.GuardObligations329,
    .one `KernelReplay.GuardObligations330,
    .one `KernelReplay.GuardObligations331,
    .one `KernelReplay.GuardObligations332,
    .one `KernelReplay.GuardObligations333,
    .one `KernelReplay.GuardObligations334,
    .one `KernelReplay.GuardObligations335,
    .one `KernelReplay.GuardObligations336,
    .one `KernelReplay.GuardObligations337,
    .one `KernelReplay.GuardObligations338,
    .one `KernelReplay.GuardObligations339,
    .one `KernelReplay.GuardObligations340,
    .one `KernelReplay.GuardObligations341,
    .one `KernelReplay.GuardObligations342,
    .one `KernelReplay.GuardObligations343,
    .one `KernelReplay.GuardObligations344,
    .one `KernelReplay.GuardObligations345,
    .one `KernelReplay.GuardObligations346,
    .one `KernelReplay.GuardObligations347,
    .one `KernelReplay.GuardObligations348,
    .one `KernelReplay.GuardObligations349,
    .one `KernelReplay.GuardObligations350,
    .one `KernelReplay.GuardObligations351,
    .one `KernelReplay.GuardObligations352,
    .one `KernelReplay.GuardObligations353,
    .one `KernelReplay.GuardObligations354,
    .one `KernelReplay.GuardObligations355,
    .one `KernelReplay.GuardObligations356,
    .one `KernelReplay.GuardObligations357,
    .one `KernelReplay.GuardObligations358,
    .one `KernelReplay.GuardObligations359,
    .one `KernelReplay.GuardObligations360,
    .one `KernelReplay.GuardObligations361,
    .one `KernelReplay.GuardObligations362,
    .one `KernelReplay.GuardObligations363,
    .one `KernelReplay.GuardObligations364,
    .one `KernelReplay.GuardObligations365,
    .one `KernelReplay.GuardObligations366,
    .one `KernelReplay.GuardObligations367,
    .one `KernelReplay.GuardObligations368,
    .one `KernelReplay.GuardObligations369,
    .one `KernelReplay.GuardObligations370,
    .one `KernelReplay.GuardObligations371,
    .one `KernelReplay.GuardObligations372,
    .one `KernelReplay.GuardObligations373,
    .one `KernelReplay.GuardObligations374,
    .one `KernelReplay.GuardObligations375,
    .one `KernelReplay.GuardObligations376,
    .one `KernelReplay.GuardObligations377,
    .one `KernelReplay.GuardObligations378,
    .one `KernelReplay.GuardObligations379,
    .one `KernelReplay.GuardObligations380,
    .one `KernelReplay.GuardObligations381,
    .one `KernelReplay.GuardObligations382,
    .one `KernelReplay.GuardObligations383,
    .one `KernelReplay.GuardObligations384,
    .one `KernelReplay.GuardObligations385,
    .one `KernelReplay.GuardObligations386,
    .one `KernelReplay.GuardObligations387,
    .one `KernelReplay.GuardObligations388,
    .one `KernelReplay.GuardObligations389,
    .one `KernelReplay.GuardObligations390,
    .one `KernelReplay.GuardObligations391,
    .one `KernelReplay.GuardObligations392,
    .one `KernelReplay.GuardObligations393,
    .one `KernelReplay.GuardObligations394,
    .one `KernelReplay.GuardObligations395,
    .one `KernelReplay.GuardObligations396,
    .one `KernelReplay.GuardObligations397,
    .one `KernelReplay.GuardObligations398,
    .one `KernelReplay.GuardObligations399,
    .one `KernelReplay.GuardObligations400,
    .one `KernelReplay.GuardObligations401,
    .one `KernelReplay.GuardObligations402,
    .one `KernelReplay.GuardObligations403,
    .one `KernelReplay.GuardObligations404,
    .one `KernelReplay.GuardObligations405,
    .one `KernelReplay.GuardObligations406,
    .one `KernelReplay.GuardObligations407,
    .one `KernelReplay.GuardObligations408,
    .one `KernelReplay.GuardObligations409,
    .one `KernelReplay.GuardObligations410,
    .one `KernelReplay.GuardObligations411,
    .one `KernelReplay.GuardObligations412,
    .one `KernelReplay.GuardObligations413,
    .one `KernelReplay.GuardObligations414,
    .one `KernelReplay.GuardObligations415,
    .one `KernelReplay.GuardObligations416,
    .one `KernelReplay.GuardObligations417,
    .one `KernelReplay.GuardObligations418,
    .one `KernelReplay.GuardObligations419,
    .one `KernelReplay.GuardObligations420,
    .one `KernelReplay.GuardObligations421,
    .one `KernelReplay.GuardObligations422,
    .one `KernelReplay.GuardObligations423,
    .one `KernelReplay.GuardObligations424,
    .one `KernelReplay.GuardObligations425,
    .one `KernelReplay.GuardObligations426,
    .one `KernelReplay.GuardObligations427,
    .one `KernelReplay.GuardObligations428,
    .one `KernelReplay.GuardObligations429,
    .one `KernelReplay.GuardObligations430,
    .one `KernelReplay.GuardObligations431,
    .one `KernelReplay.GuardObligations432,
    .one `KernelReplay.GuardObligations433,
    .one `KernelReplay.GuardObligations434,
    .one `KernelReplay.GuardObligations435,
    .one `KernelReplay.GuardObligations436,
    .one `KernelReplay.GuardObligations437,
    .one `KernelReplay.GuardObligations438,
    .one `KernelReplay.GuardObligations439,
    .one `KernelReplay.GuardObligations440,
    .one `KernelReplay.GuardObligations441,
    .one `KernelReplay.GuardObligations442,
    .one `KernelReplay.GuardObligations443,
    .one `KernelReplay.GuardObligations444,
    .one `KernelReplay.GuardObligations445,
    .one `KernelReplay.GuardJoint,
    .one `KernelReplay.GuardDependencyAudit,
    .one `KernelReplay.GuardDependencyControls,
    .one `KernelReplay.GuardJointAudit,
    .one `KernelReplay.GuardJointPublic,
    .one `KernelReplay.GuardJointPublicAudit,
    .one `KernelReplay.GuardJointExport,
    .one `KernelReplay.GuardJointUse,
    .one `KernelReplay.GuardSupportInventory,
    .one `KernelReplay.GuardSupportCandidate01,
    .one `KernelReplay.GuardSupportCandidate02,
    .one `KernelReplay.GuardSupportCandidate03,
    .one `KernelReplay.GuardSupportCandidate04,
    .one `KernelReplay.GuardSupportCandidate05,
    .one `KernelReplay.GuardSupportCandidate06,
    .one `KernelReplay.GuardSupportCandidate07,
    .one `KernelReplay.GuardSupportCandidate08,
    .one `KernelReplay.GuardSupportCandidate09,
    .one `KernelReplay.GuardSupportCandidate10,
    .one `KernelReplay.GuardSupportCandidate11,
    .one `KernelReplay.GuardSupportCandidate12,
    .one `KernelReplay.GuardSupportCandidate13,
    .one `KernelReplay.GuardSupportCandidate14,
    .one `KernelReplay.GuardSupportCandidate15,
    .one `KernelReplay.GuardSupportCandidate16,
    .one `KernelReplay.GuardSupportCandidate17,
    .one `KernelReplay.GuardAgreementRules,
    .one `KernelReplay.GuardBaseAgreement,
    .one `KernelReplay.GuardBasePrefixAudit,
    .one `KernelReplay.GuardBaseAgreement01,
    .one `KernelReplay.GuardBaseAgreement02,
    .one `KernelReplay.GuardBaseAgreement03,
    .one `KernelReplay.GuardBaseAgreement04,
    .one `KernelReplay.GuardBaseAgreement05,
    .one `KernelReplay.GuardBaseAgreement06,
    .one `KernelReplay.GuardBaseAgreement07,
    .one `KernelReplay.GuardBaseAgreement08,
    .one `KernelReplay.GuardBaseAgreement09,
    .one `KernelReplay.GuardBaseAgreement10,
    .one `KernelReplay.GuardBaseAgreement11,
    .one `KernelReplay.GuardBaseAgreement12,
    .one `KernelReplay.GuardBaseAgreement13,
    .one `KernelReplay.GuardBaseAgreement14,
    .one `KernelReplay.GuardBaseAgreement15,
    .one `KernelReplay.GuardBaseAgreement16,
    .one `KernelReplay.GuardBaseAgreement17,
    .one `KernelReplay.GuardBaseAgreement18,
    .one `KernelReplay.GuardBaseAgreement19,
    .one `KernelReplay.GuardBaseAgreement20,
    .one `KernelReplay.GuardBaseAgreement21,
    .one `KernelReplay.GuardBaseAgreement22,
    .one `KernelReplay.GuardBaseAgreement23,
    .one `KernelReplay.GuardBaseAgreement24,
    .one `KernelReplay.GuardBaseAgreement25,
    .one `KernelReplay.GuardBaseAgreement26,
    .one `KernelReplay.GuardBaseAgreement27,
    .one `KernelReplay.GuardBaseAgreement28,
    .one `KernelReplay.GuardBaseAgreement29,
    .one `KernelReplay.GuardBaseAgreement30,
    .one `KernelReplay.GuardBaseAgreement31,
    .one `KernelReplay.GuardBaseAgreement32,
    .one `KernelReplay.GuardBaseAgreement33,
    .one `KernelReplay.GuardBaseAgreement34,
    .one `KernelReplay.GuardBaseAgreement35,
    .one `KernelReplay.GuardBaseAgreement36,
    .one `KernelReplay.GuardBaseAgreement37,
    .one `KernelReplay.GuardBaseAgreement38,
    .one `KernelReplay.GuardBaseAgreement39,
    .one `KernelReplay.GuardBaseAgreement40,
    .one `KernelReplay.GuardBaseAgreement41,
    .one `KernelReplay.GuardBaseAgreement42,
    .one `KernelReplay.GuardBaseAgreement43,
    .one `KernelReplay.GuardBaseAgreement44,
    .one `KernelReplay.GuardBaseAgreement45,
    .one `KernelReplay.GuardBaseAgreement46,
    .one `KernelReplay.GuardBaseAgreement47,
    .one `KernelReplay.GuardBaseAgreement48,
    .one `KernelReplay.GuardBaseAgreement49,
    .one `KernelReplay.GuardBaseAgreement50,
    .one `KernelReplay.GuardBaseAgreement51,
    .one `KernelReplay.GuardBaseAgreement52,
    .one `KernelReplay.GuardBaseAgreement53,
    .one `KernelReplay.GuardBaseAgreement54,
    .one `KernelReplay.GuardBaseAgreement55,
    .one `KernelReplay.GuardBaseAgreement56,
    .one `KernelReplay.GuardBaseAgreement57,
    .one `KernelReplay.GuardBaseAgreement58,
    .one `KernelReplay.GuardBaseAgreement59,
    .one `KernelReplay.GuardBaseAgreement60,
    .one `KernelReplay.GuardBaseAgreement61,
    .one `KernelReplay.GuardBaseAgreement62,
    .one `KernelReplay.GuardBaseAgreement63,
    .one `KernelReplay.GuardBaseAgreement64,
    .one `KernelReplay.GuardBaseAgreement65,
    .one `KernelReplay.GuardBaseAgreement66,
    .one `KernelReplay.GuardBaseAgreement67,
    .one `KernelReplay.GuardBaseAgreement68,
    .one `KernelReplay.GuardBaseAgreement69,
    .one `KernelReplay.GuardBaseAgreement70,
    .one `KernelReplay.GuardBaseAgreement71,
    .one `KernelReplay.GuardBaseAgreement72,
    .one `KernelReplay.GuardBaseAgreement73,
    .one `KernelReplay.GuardBaseAgreement74,
    .one `KernelReplay.GuardBaseAgreement75,
    .one `KernelReplay.GuardBaseAgreement76,
    .one `KernelReplay.GuardBaseAgreement77,
    .one `KernelReplay.GuardBaseAgreement78,
    .one `KernelReplay.GuardBaseAgreement79,
    .one `KernelReplay.GuardBaseAgreement80,
    .one `KernelReplay.GuardBaseAgreement81,
    .one `KernelReplay.GuardBaseAgreement82,
    .one `KernelReplay.GuardBaseAgreement83,
    .one `KernelReplay.GuardBaseAgreement84,
    .one `KernelReplay.GuardBaseAgreement85,
    .one `KernelReplay.GuardBaseAgreement86,
    .one `KernelReplay.GuardBaseAgreement87,
    .one `KernelReplay.GuardBaseAgreement88,
    .one `KernelReplay.GuardBaseAgreement89,
    .one `KernelReplay.GuardBaseAgreement90,
    .one `KernelReplay.GuardBaseAgreement91,
    .one `KernelReplay.GuardBaseAgreement92,
    .one `KernelReplay.GuardBaseAgreement93,
    .one `KernelReplay.GuardBaseAgreement94,
    .one `KernelReplay.GuardBaseAgreement95,
    .one `KernelReplay.GuardBaseAgreement96,
    .one `KernelReplay.GuardBaseAgreement97,
    .one `KernelReplay.GuardBaseAgreement98,
    .one `KernelReplay.GuardBaseAgreement99,
    .one `KernelReplay.GuardBaseAgreement100,
    .one `KernelReplay.GuardBaseAgreement101,
    .one `KernelReplay.GuardBaseAgreement102,
    .one `KernelReplay.GuardBaseAgreement103,
    .one `KernelReplay.GuardBaseAgreement104,
    .one `KernelReplay.GuardBaseAgreement105,
    .one `KernelReplay.GuardBaseAgreement106,
    .one `KernelReplay.GuardBaseAgreement107,
    .one `KernelReplay.GuardBaseAgreement108,
    .one `KernelReplay.GuardBaseAgreement109,
    .one `KernelReplay.GuardBaseAgreement110,
    .one `KernelReplay.GuardBaseAgreement111,
    .one `KernelReplay.GuardBaseAgreement112,
    .one `KernelReplay.GuardBaseAgreement113,
    .one `KernelReplay.GuardBaseAgreement114,
    .one `KernelReplay.GuardBaseAgreement115,
    .one `KernelReplay.GuardBaseAgreement116,
    .one `KernelReplay.GuardBaseAgreement117,
    .one `KernelReplay.GuardBaseAgreement118,
    .one `KernelReplay.GuardBaseAgreement119,
    .one `KernelReplay.GuardBaseAgreement120,
    .one `KernelReplay.GuardBaseAgreement121,
    .one `KernelReplay.GuardBaseAgreement122,
    .one `KernelReplay.GuardBaseAgreement123,
    .one `KernelReplay.GuardBaseAgreement124,
    .one `KernelReplay.GuardBaseAgreement125,
    .one `KernelReplay.GuardBaseAgreement126,
    .one `KernelReplay.GuardBaseAgreement127,
    .one `KernelReplay.GuardBaseAgreement128,
    .one `KernelReplay.GuardBaseAgreement129,
    .one `KernelReplay.GuardBaseAllAudit,
    .one `KernelReplay.GuardJoinPrefixAudit,
    .one `KernelReplay.GuardLiveFrameAudit,
    .one `KernelReplay.ConstructedBaseAudit,
    .one `KernelReplay.FiniteChecks,
    .one `KernelReplay.GuardAgreementJoin,
    .one `KernelReplay.GuardAgreementJoin01,
    .one `KernelReplay.GuardAgreementJoin02,
    .one `KernelReplay.GuardAgreementJoin03,
    .one `KernelReplay.GuardAgreementJoin04,
    .one `KernelReplay.GuardAgreementJoin05,
    .one `KernelReplay.GuardAgreementJoin06,
    .one `KernelReplay.GuardAgreementJoin07,
    .one `KernelReplay.GuardAgreementJoin08,
    .one `KernelReplay.GuardAgreementJoin09,
    .one `KernelReplay.GuardAgreementJoin10,
    .one `KernelReplay.GuardAgreementJoin11,
    .one `KernelReplay.GuardAgreementJoin12,
    .one `KernelReplay.GuardAgreementJoin13,
    .one `KernelReplay.GuardAgreementJoin14,
    .one `KernelReplay.GuardAgreementJoin15,
    .one `KernelReplay.GuardAgreementJoin16,
    .one `KernelReplay.GuardAgreementJoin17,
    .one `KernelReplay.GuardAgreementJoin18,
    .one `KernelReplay.GuardAgreementJoin19,
    .one `KernelReplay.GuardAgreementJoin20,
    .one `KernelReplay.GuardAgreementJoin21,
    .one `KernelReplay.GuardAgreementJoin22,
    .one `KernelReplay.GuardAgreementJoin23,
    .one `KernelReplay.GuardAgreementJoin24,
    .one `KernelReplay.GuardAgreementJoin25,
    .one `KernelReplay.GuardAgreementJoin26,
    .one `KernelReplay.GuardAgreementJoin27,
    .one `KernelReplay.GuardAgreementJoin28,
    .one `KernelReplay.GuardAgreementFinal,
    .one `KernelReplay.GuardAgreementPublic,
    .one `KernelReplay.GuardAgreementPublicAudit,
    .one `KernelReplay.Guard208Audit,
    .one `KernelReplay.GuardAllAudit,
    .one `KernelReplay.GuardSupportSource,
    .one `KernelReplay.GuardProduct,
    .one `KernelReplay.GuardProductPublic,
    .one `KernelReplay.GuardProductPublicAudit,
    .one `KernelReplay.GuardCoefficientFence,
    .one `KernelReplay.FrameFrontier,
    .one `KernelReplay.FrameOwners, .one `KernelReplay.FrameOperand,
    .one `KernelReplay.FrameStorage,
    .one `KernelReplay.FramePublic,
    .one `KernelReplay.DecisionTrace,
    .one `KernelReplay.CoefficientSuffix,
    .one `KernelReplay.CoefficientMembers,
    .one `KernelReplay.BaseLookup,
    .one `KernelReplay.CoefficientLookup, .one `KernelReplay.PackingLookup,
    .one `KernelReplay.LookupReplay,
    .one `KernelReplay.ProofAudit,
    .one `KernelReplay.AxiomClosure, .one `KernelReplay.AxiomClosureNative, .one `KernelReplay.AxiomClosureTest,
    .one `KernelReplay.AxiomClosureImports, .one `KernelReplay.SupportAudit,
    .one `KernelReplay.ProviderHistoryAudit,
    .one `KernelReplay.RationalCodecAudit,
    .one `KernelReplay.FiniteRange,
    .one `KernelReplay.CoefficientMembers, .one `KernelReplay.CoefficientEntry,
    .one `KernelReplay.NativeAssemblyUse,
    .one `KernelReplay.Packing,
    .one `KernelReplay.PackingProbe, .one `KernelReplay.Inverse, .one `KernelReplay.ValueSigns, .one `KernelReplay.InverseDemand, .one `KernelReplay.RationalRoot, .one `KernelReplay.FiniteTower, .one `KernelReplay.FiniteTowerPackets, .one `KernelReplay.FiniteTowerProbe, .one `KernelReplay.FiniteTowerThom, .one `KernelReplay.FiniteTowerUse, .one `KernelReplay.FiniteData, .one `KernelReplay.FiniteSupport, .one `KernelReplay.FiniteOperands, .one `KernelReplay.FiniteLift, .one `KernelReplay.FiniteBase, .one `KernelReplay.FiniteDependencies, .one `KernelReplay.FiniteReconstruction, .one `KernelReplay.FiniteChain, .one `KernelReplay.FiniteThomWitness, .one `KernelReplay.FiniteThomJoint, .one `KernelReplay.FiniteWitness, .one `KernelReplay.FiniteJoint,
    .one `KernelReplay.FiniteTowerReal,
    .one `KernelReplay.Nested, .one `KernelReplay.NestedProbe,
    .one `KernelReplay.FactOperations, .one `KernelReplay.FactOperationsProbe,
    .one `KernelReplay.Root, .one `KernelReplay.RootProbe,
    .one `KernelReplay.ProofProbe,
    .one `KernelReplay.InProcessProbe, .one `KernelReplay.LowerProbe, .one `KernelReplay.LowerProof]

lean_exe hexsigndet_kernel_replay_probe where
  supportInterpreter := true
  srcDir := "experiments"
  root := `KernelReplay.Main

lean_exe hexsigndet_inprocess_replay_probe where
  srcDir := "experiments"
  root := `KernelReplay.InProcessMain

lean_exe hexrealclosure_policy_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.RootPolicyConformance

lean_exe hexrealclosure_normalization_bench where
  srcDir := "bench"
  root := `HexRealClosure.Normalization

lean_exe hexrealclosure_basic_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.BasicConformance

lean_exe hexrealclosure_rioboo_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.RiobooConformance

lean_exe hexrealclosure_strz_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.StrzConformance

lean_exe hexrealclosure_root_format_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.RootFormatConformance

lean_exe hexrealclosure_repr_conformance where
  srcDir := "conformance"
  root := `HexRealClosure.ReprConformance

lean_exe hexsigndet_nested_trace where
  srcDir := "bench"
  root := `HexSignDet.NestedTrace

lean_exe hexsigndet_interacting_trace where
  srcDir := "bench"
  root := `HexSignDet.InteractingTraceMain

lean_exe hexsigndet_interacting_bench where
  srcDir := "bench"
  root := `HexSignDet.InteractingBench

/-- Mathlib-free supplied inverse certificate producer for conformance regeneration. -/
lean_exe hexrcf_inverse_fixture where
  srcDir := "conformance"
  root := `HexRCF.InverseFixture

lean_exe hexrealclosure_samples_bench where
  srcDir := "bench"
  root := `HexRealClosure.SampleMeasurements

lean_exe hexrealclosure_trivial_bench where
  srcDir := "bench"
  root := `HexRealClosure.TrivialMeasurements

lean_exe hexgroebner_emit_division where
  srcDir := "conformance"
  root := `HexGroebner.EmitDivision
