from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root));payload={}
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();runtime=tree_listing(FAMILY,'HEAD');checks=tree_listing(CHECKS,'HEAD')
def add(name,path):
 assert name not in payload,name
 payload[name]=path.read_bytes()
for kind in ['native','full']:
 source=state/f'dense-final-{kind}-status.json';records=json.loads(source.read_text())
 assert len(records)==(2 if kind=='native' else 9)
 assert all(row['exit_code']==0 and all(row[key]==value for key,value in identity.items())for row in records)
 add(kind+'-status.json',source)
 add(kind+'-checks.py',state/f'dense-final-{kind}-checks.py')
payload['runtime.manifest']=runtime.encode();payload['checks.manifest']=checks.encode()
for listing,prefix in [(runtime,'runtime-sources/'),(checks,'checks-sources/')]:
 for line in listing.splitlines():
  _,oid,rest=line.split(' ',2);_,name=rest.split('\t')
  payload[prefix+name]=subprocess.check_output(['git','cat-file','blob',oid])
for row in json.loads((state/'dense-final-full-status.json').read_text()):add(row['name']+'.log',Path(row['log']))
for compiler in ['clang','gcc']:
 add(compiler+'.log',state/f'dense-final-{compiler}.log')
 for path in sorted((state/f'dense-final-{compiler}').rglob('*')):
  if path.is_file() and '.lake' not in path.relative_to(state/f'dense-final-{compiler}').parts:add('probes/'+compiler+'/'+str(path.relative_to(state/f'dense-final-{compiler}')),path)
for path in sorted((state/'dense-active-production/enabled/inputs').glob('*.json')):
 if path.name!='suite.json':add('usage-inputs/'+path.name,path)
for label,prefix,commit in [('types','dense-review-harness-failed','aed24bcfc20007b2e9b8f6dbc4f6f7d6ba8ad6e0'),('depth','dense-review-harness-depth','41d7c2b347')]:
 for name in ['clang.log','native-status.json']:
  add('harness-failures/'+label+'/'+name,state/(prefix+'-dense-review-'+name))
 payload['harness-failures/'+label+'/check_groebner_matrix.py']=subprocess.check_output(['git','show',commit+':scripts/ci/check_groebner_matrix.py'])
for name in ['clang.log','native-status.json']:
 add('harness-failures/bulk-fixture/'+name,state/('dense-bulk-fixture-failed-dense-bulk-'+name))
payload['harness-failures/bulk-fixture/DenseMatrixConformance.lean']=subprocess.check_output(['git','show','a0b65825c66f34a02b0040693538535fb67f0c3e:conformance/HexGroebner/DenseMatrixConformance.lean'])
add('report-generator.py',root/'scripts/bench/groebner_dense_report.py')
add('pack-guards.py',Path(__file__))
payload['implementation.patch']=subprocess.check_output(['git','diff','ab0caa2e114ee90d323b867a8892fc42e6a09ffb..HEAD','--no-ext-diff'])
manifest={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())}
payload['sha256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=state/f'f4-dense-checks-{identity["checks_fingerprint"]}.tar.xz'
with lzma.open(out,'wb',preset=6)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-dense-checks/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
