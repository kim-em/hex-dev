from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root));payload={}
from scripts.bench.groebner_checks import source_identity
identity=source_identity();base=s/'avx512-optin-production';meta=json.loads((base/'f4/metadata.json').read_text())
def add(name,path):assert name not in payload;payload[name]=path.read_bytes()
for path in sorted((s/'avx512-assertion-mutants').rglob('*')):
 if path.is_file() and path.name!='test':add('mutations/'+str(path.relative_to(s/'avx512-assertion-mutants')),path)
for case in sorted({row['case']for row in meta['samples']}):
 for cc in ['clang','gcc']:
  command=json.loads((s/f'avx512-optin-{cc}/usage-results'/f'{case}-false.command.json').read_text());path=Path(command[-1]);assert hashlib.sha256(path.read_bytes()).hexdigest()==meta['input_sha256'][case+'.json']
  if cc=='clang':add('usage-inputs/'+case+'.json',path)
config=json.loads((root/'.lake/config/0/lakefile.olean.trace').read_text());binaries={'compute':'hexgroebner_compute','compute-reference':'hexgroebner_compute_full','bench':'hexgroebner_bench'};effective=dict(options=config['options'],binary_sha256={k:hashlib.sha256((root/'.lake/build/bin'/v).read_bytes()).hexdigest()for k,v in binaries.items()},**identity)
assert effective['options']=={} and effective['binary_sha256']==json.loads((s/'avx512-default-production/manifest.json').read_text())['binary_sha256']
payload['effective-build-config.json']=(json.dumps(effective,indent=2)+'\n').encode()
compilers={}
for record in json.loads((s/'avx512-optin-native-status.json').read_text()):
 command=record['compiler'];compilers[record['name']]=dict(command=command,sha256=hashlib.sha256(Path(command).resolve().read_bytes()).hexdigest(),version=subprocess.check_output([command,'--version'],text=True))
payload['sanitizer-compilers.json']=(json.dumps(compilers,indent=2)+'\n').encode();add('pack.py',Path(__file__))
digests={name:hashlib.sha256(data).hexdigest()for name,data in sorted(payload.items())};payload['sha256.json']=(json.dumps(digests,indent=2)+'\n').encode();out=s/('f4-avx512-audit-'+identity['source_fingerprint']+'.tar.xz')
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-avx512-audit/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(digests),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
