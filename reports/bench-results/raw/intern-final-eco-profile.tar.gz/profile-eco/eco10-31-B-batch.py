import subprocess,json,pathlib
exe='/tmp/hex-groebner-intern-final-production/binaries/compare-intern-final'
inp='/tmp/hex-groebner-compare/eco10-31.json'
root=pathlib.Path('/tmp/hex-groebner-intern-final-production/profile-eco')
for i in range(8):
 with (root/('eco10-31-B'+'-'+str(i)+'.stdout')).open('w') as out,(root/('eco10-31-B'+'-'+str(i)+'.stderr')).open('w') as err:
  subprocess.run([exe,inp],stdout=out,stderr=err,check=True)
