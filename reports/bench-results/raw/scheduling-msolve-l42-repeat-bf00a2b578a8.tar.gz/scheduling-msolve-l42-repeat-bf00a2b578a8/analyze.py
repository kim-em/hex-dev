from pathlib import Path
import json,statistics,collections
base=Path(__file__).resolve().parent

def summary(values):
 return dict(geomean=statistics.geometric_mean(values),median=statistics.median(values),minimum=min(values),maximum=max(values))

out={}
for d in sorted(base.iterdir()):
 if not d.is_dir() or not (d/'metadata.json').exists():continue
 m=json.loads((d/'metadata.json').read_text());pairs=collections.defaultdict(dict)
 for r in m['samples']:pairs[r['case'],r['block']][r['arm']]=r
 assert all(r['status']=='ok' and r.get('complete_basis_equal') for r in m['samples'])
 rows=[]
 for (case,block),pair in pairs.items():
  a,b=pair['A'],pair['B'];row=dict(case=case,block=block,family=a['family'],p=a['p'],process_ratio=a['wall_nanos']/b['wall_nanos'] if m['msolve_mode'] else b['wall_nanos']/a['wall_nanos'])
  if not m['msolve_mode']:
   x,y=a['statistics'],b['statistics'];row.update(candidate_ratio=y['candidate_nanos']/x['candidate_nanos'],baseline=x,candidate=y)
  rows.append(row)
 families={}
 for family in sorted({r['family'] for r in rows}):
  selected=[r for r in rows if r['family']==family];v=dict(process=summary([r['process_ratio'] for r in selected]))
  if not m['msolve_mode']:v['candidate']=summary([r['candidate_ratio'] for r in selected])
  families[family]=v
 result=dict(ratio_direction='Hex/msolve process' if m['msolve_mode'] else 'B/A',cpu=m['cpu'],pairs=len(rows),failures=0,process=summary([r['process_ratio'] for r in rows]),families=families,ratios=rows)
 if not m['msolve_mode']:result['candidate']=summary([r['candidate_ratio'] for r in rows])
 (d/'counter-analysis.json').write_text(json.dumps(result,indent=2)+'\n');out[d.name]=result
 print(d.name,result.get('candidate'),result['process'],flush=True)
(base/'counter-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
