from pathlib import Path
import json,statistics,collections
base=Path(__file__).resolve().parent;analyses=json.loads((base/'counter-analysis.json').read_text());result={}
def summary(v):return dict(geomean=statistics.geometric_mean(v),median=statistics.median(v),minimum=min(v),maximum=max(v))
for kind in ['degree-vs-sugar','before-after','msolve-l2','msolve-l42']:
 selected=[(k,v) for k,v in analyses.items() if k in [kind+'-bf00a2b578a8',kind+'-repeat-bf00a2b578a8']];assert len(selected)==2
 rows=[dict(r,campaign=k) for k,v in selected for r in v['ratios']];families={}
 for f in sorted({r['family'] for r in rows}):
  fr=[r for r in rows if r['family']==f];values=dict(process=summary([r['process_ratio'] for r in fr]))
  if 'candidate_ratio' in fr[0]:values['candidate']=summary([r['candidate_ratio'] for r in fr])
  families[f]=values
 cases={}
 for case in sorted({r['case'] for r in rows}):
  cr=[r for r in rows if r['case']==case];v=dict(process=summary([r['process_ratio'] for r in cr]))
  if 'candidate_ratio' in cr[0]:
   v['candidate']=summary([r['candidate_ratio'] for r in cr]);v['counters']={}
   for arm in ['baseline','candidate']:
    counts=[{k:v for k,v in r[arm].items() if k!='candidate_nanos'} for r in cr];assert all(x==counts[0] for x in counts);v['counters'][arm]=counts[0]
  cases[case]=v
 r=dict(cpus=[v['cpu'] for _,v in selected],process=summary([r['process_ratio'] for r in rows]),family_balanced_process=statistics.geometric_mean([v['process']['geomean'] for v in families.values()]),families=families,cases=cases,pairs=len(rows),completed_processes=2*len(rows),failed_processes=0,timeouts=0)
 if 'candidate_ratio' in rows[0]:r.update(candidate=summary([r['candidate_ratio'] for r in rows]),candidate_extremes=[min(rows,key=lambda r:r['candidate_ratio']),max(rows,key=lambda r:r['candidate_ratio'])])
 result[kind]=r;print(kind,{k:v for k,v in r.items() if k not in ['families','cases','candidate_extremes']},flush=True)
(base/'pooled-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
