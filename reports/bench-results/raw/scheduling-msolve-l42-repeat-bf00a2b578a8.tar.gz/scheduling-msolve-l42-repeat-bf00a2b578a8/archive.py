from pathlib import Path
import json,tarfile,hashlib,subprocess,shutil
root=Path('/tmp/hex-groebner-scheduling-dev');cli=Path('/tmp/hex-groebner-scheduling-production');final=Path('/tmp/hex-groebner-scheduling-oracle-production');dest=root/'reports/bench-results/raw';catalog=[]
def sources(directory,folder,listing):
 (directory/(folder+'.manifest')).write_text(listing)
 for line in listing.splitlines():
  header,name=line.split('\t',1);oid=header.split()[1];p=directory/folder/name;p.parent.mkdir(parents=True,exist_ok=True);data=subprocess.check_output(['git','cat-file','blob',oid],cwd=root);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;p.write_bytes(data)
def archive(stage,name):
 p=dest/(name+'.tar.gz');assert not p.exists()
 with tarfile.open(p,'w:gz') as t:t.add(stage,arcname=name)
 row=dict(archive=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest());catalog.append(row);print(json.dumps(row),flush=True)
for base in [cli,final]:
 for d in sorted(base.iterdir()):
  if not d.is_dir() or not (d/'metadata.json').exists():continue
  m=json.loads((d/'metadata.json').read_text());sources(d,'root-sources',m['source_manifest']);baseline=m.get('baseline_manifest')
  if not baseline and base==final:baseline=json.loads((final/'bench-binaries/baseline-manifest.json').read_text());shutil.copy2(final/'bench-binaries/baseline-bench-metadata.json',d/'baseline-bench-metadata.json')
  if baseline:
   (d/'baseline-manifest.json').write_text(json.dumps(baseline,indent=2)+'\n');sources(d,'baseline-sources',baseline['source_manifest'])
  if m.get('msolve_mode'):
   ms=Path('/tmp/hex-groebner-msolve');assert hashlib.sha256((ms/'src/neogb/.libs/libneogb.so.4.0.0').read_bytes()).hexdigest()==m['msolve_engine_sha256']
   for n in ['config.log','config.h','config.status','Makefile','src/neogb/Makefile']:shutil.copy2(ms/n,d/('msolve-'+n.replace('/','-')))
   for n in ['issue-10987-msolve-native-build.log','issue-10987-msolve-native-configure-with-deps.log','issue-10987-msolve-native-compiler-probe.log','issue-10987-build-msolve-native.sh']:shutil.copy2(Path('/tmp')/n,d/n)
   shutil.copy2('/tmp/hex-groebner-mersenne-dispatch-production/msolve-source-3672113ee2c6.tar',d/'msolve-source-3672113ee2c6.tar')
  for n in ['analyze.py','pool.py','pooled-analysis.json','analyze-fixed.py','fixed-analysis.json','source-comparison.json']:
   if (base/n).exists():shutil.copy2(base/n,d/n)
  shutil.copy2(__file__,d/'archive.py');archive(d,'scheduling-'+d.name)
stage=final/'validation';stage.mkdir(exist_ok=False)
for n in ['manifest.json','source.manifest','build.log','groebner_freeze.py','fixed-analysis.json','source-comparison.json']:shutil.copy2(final/n,stage/n)
shutil.copytree(final/'root-sources',stage/'root-sources')
for base,prefix in [(cli,'measured-')]:
 for n in ['manifest.json','source.manifest','build.log','groebner_freeze.py','counter-analysis.json','pooled-analysis.json']:shutil.copy2(base/n,stage/(prefix+n))
logs=['all-conformance-final','driver-check','oracles-final','san','gcc-san','bench-verify','dag-final','phase4-final','manifest-final','headers-final','lines-final','oracle-tests-final','freeze-tests','conformance-build','conformance-final','conformance-fixed','oracles','fixture-diff']
for n in logs:
 for suffix in ['.log','.json']:
  p=Path('/tmp/issue-10987-scheduling-'+n+suffix)
  if p.exists():shutil.copy2(p,stage/p.name)
for folder in ['conformance/HexGroebner','conformance-fixtures/HexGroebner']:shutil.copytree(root/folder,stage/folder)
for n in ['scripts/oracle/groebner_corpus.py','scripts/oracle/groebner_sympy.py','scripts/oracle/groebner_singular.py','scripts/oracle/test_groebner_sympy.py','scripts/ci/check_groebner_driver.py','scripts/ci/check_groebner_matrix.py','scripts/ci/check_groebner_rows.sh']:
 p=stage/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/n,p)
shutil.copy2(__file__,stage/'archive.py')
(stage/'scope.json').write_text(json.dumps(dict(cli_source='bf00a2b578a8',final_source='6ede9cb261a4',scope='CLI campaigns use the original frozen c73e6196c3 computational snapshot. Final independent oracle corpus validation changes only scripts/oracle/groebner_singular.py within the measured family. A second fresh 188-job freeze produces byte-identical default and full-init executables. Eight 64-process CLI campaigns retain the first observation and exactly one unchanged repeat of each of four comparisons; 256 complete basis pairs agree, with no failures/timeouts. Repeats run from a separate unchanged c73 checkout, not the oracle-adjusted source. Two registered fixed campaigns retain 240 complete matching points and one unchanged repeat. All 1957 conformance/theory targets, both 1134-case CLI corpora, 175 matrix/1134 independent basis/1288 division oracles, four Clang and four GCC ASan/UBSan variants, 32 benchmark smoke checks and project audits pass. Original constructor and corpus-size integration failures are retained. Candidate generation, certificate generation, independent verification and kernel checking remain separate. No held-out suite, performance leadership, complete deterministic producer proof or compiler-change impossibility claim.'),indent=2)+'\n')
archive(stage,'scheduling-validation-6ede9cb261a4');Path('/tmp/issue-10987-scheduling-archive-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
