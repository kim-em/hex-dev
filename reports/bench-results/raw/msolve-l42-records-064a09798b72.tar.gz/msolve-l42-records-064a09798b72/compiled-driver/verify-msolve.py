import json,pathlib,sys,math,statistics
sys.path.insert(0,'/home/kim/worktrees/hex-dev/hex-dev-issue-10987')
from scripts.oracle.groebner_singular import polynomial,canonical
root=pathlib.Path('/tmp/hex-groebner-compare');base=pathlib.Path('/tmp/hex-groebner-pair-rows-production');g=lambda v:math.exp(sum(map(math.log,v))/len(v))
for out in sorted(base.glob('msolve-l*-records-*')):
 m=json.loads((out/'metadata.json').read_text());samples=[json.loads(line) for line in (out/'samples.jsonl').read_text().splitlines()];ratios=[];comparisons=[];cases={}
 for case in json.loads((root/'diagnostic-suite.json').read_text())['cases']:
  v=[]
  for block in [0,1]:
   a,b=[next(x for x in samples if x['case']==case['name'] and x['block']==block and x['arm']==arm) for arm in ('A','B')]
   assert a['status']==b['status']=='ok';payload=''.join(line for line in (out/f"{case['name']}-b{block}-B.basis").read_text().splitlines() if not line.startswith('#')).strip();assert payload.startswith('[') and payload.endswith(']:')
   parsed=sorted(polynomial(s,case['variables'],case['p']) for s in payload[1:-2].split(','));hex_basis=canonical(json.loads((out/f"{case['name']}-b{block}-A.stdout").read_text())['basis']);assert hex_basis==parsed,(out,case)
   comparisons.append(dict(case=case['name'],block=block,equal=True,polynomials=len(hex_basis)));x=a['wall_nanos']/b['wall_nanos'];v.append(x);ratios.append(x)
  cases[case['name']]=v
 analysis=dict(cpu=m['cpu'],samples=len(samples),complete_bases_equal=len(comparisons),hex_over_msolve_process_geomean=g(ratios),hex_over_msolve_process_median=statistics.median(ratios),range=[min(ratios),max(ratios)],per_case=cases)
 (out/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n');(out/'output-comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
 print(out.name,{k:v for k,v in analysis.items() if k!='per_case'})
 for c,v in cases.items():print(c,*[round(x,2) for x in v])
