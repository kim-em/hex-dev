from pathlib import Path
import json,tarfile,hashlib,shutil,subprocess
repo=Path('/tmp/hex-groebner-packed-targets-dev');base=Path('/tmp/hex-groebner-packed-targets-final-production');m=json.loads((base/'manifest.json').read_text());prior=json.loads(Path('/tmp/hex-groebner-packed-targets-layout-production/manifest.json').read_text());assert m['binary_sha256']==prior['binary_sha256'];assert 'Build completed successfully' in Path('/tmp/issue-10987-pr11010-endpoint-build.log').read_text()
fp=m['source_fingerprint'];name='packed-targets-final-'+fp;stage=Path('/tmp/hex-groebner-archive-staging')/name;stage.mkdir(exist_ok=False)
for n in ['manifest.json','build.log','groebner_freeze.py','source.manifest']:shutil.copy2(base/n,stage/n)
(stage/'root-sources.manifest').write_text(m['source_manifest'])
count=0
for line in m['source_manifest'].splitlines():
 h,n=line.split('\t',1);oid=h.split()[1];data=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;p=stage/'root-sources'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);count+=1
for n in ['conformance/HexGroebner/SchedulingResumeConformance.lean','conformance/HexGroebner/HitConformance.lean','scripts/ci/check_groebner_matrix.py']:
 p=stage/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,p)
shutil.copy2('/tmp/issue-10987-pr11010-endpoint-build.log',stage/'endpoint-build.log')
(stage/'scope.json').write_text(json.dumps(dict(scope='Final ABI comments explicitly limit object-count guard coverage: scalar-layout changes and reordered fields still require complete manual ABI synchronization. Source9bac12f60779 differs from8d139a1e1c57 only by computational source comments. A fresh272-job detached build independently reproduces both minimal and full compute binary SHA256 values exactly. No new timing campaign and no cross-source pooling. Strengthen the scheduling test so exhaustion at work==total.work is explicitly rejected in both untraced and traced paths. The279-job endpoint/owned conformance build passes. Broader2170-job build, full oracles, driver,32benchmark checks,8sanitizer variants, layout/alias tests and resize fault tests are retained under8d139a1e1c57. Final source source blobs and exact strengthened test sources are included.',source_fingerprint=fp,prior_source_fingerprint=prior['source_fingerprint'],byte_identical_both_drivers=True,physical_source_files=count),indent=2)+'\n')
shutil.copy2(__file__,stage/'archive.py');target=repo/'reports/bench-results/raw'/(name+'.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
a=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),fingerprint=fp,physical_source_files=count);Path('/tmp/issue-10987-packed-targets-final-catalog.json').write_text(json.dumps(a,indent=2)+'\n');print(a)
