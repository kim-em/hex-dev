from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.oracle.groebner_singular import expression
s=Path('/home/kim/tmp/issue-10987');old=s/'binary-dense-suite';out=s/'binary-canonical-suite';out.mkdir(exist_ok=False);suite=json.loads((old/'suite.json').read_text())
for case in suite['cases']:
 inp=old/(case['name']+'.json');d=json.loads(inp.read_text());normalized=[];seen=set()
 for g in d['generators']:
  coefficients={}
  for powers,c in g:
   key=tuple(powers);coefficients[key]=(coefficients.get(key,0)+c)%d['p']
  g=[[list(powers),c]for powers,c in sorted(coefficients.items(),key=lambda item:(sum(item[0]),tuple(-e for e in reversed(item[0]))),reverse=True)if c]
  key=json.dumps(g)
  if g and key not in seen:seen.add(key);normalized.append(g)
 d['generators']=normalized;assert normalized
 (out/inp.name).write_text(json.dumps(d,indent=2)+'\n');(out/(case['name']+'.ms')).write_text(','.join('x'+str(i)for i in range(d['variables']))+'\n2\n'+',\n'.join(expression(g)for g in normalized)+'\n')
 case['canonical_source_sha256']=hashlib.sha256(inp.read_bytes()).hexdigest();case['canonicalization']='Combine equal monomials modulo2; drop zero terms/zero generators; deduplicate equal polynomials; sort terms grevlex. Both engines receive this same canonical system.'
 print(case['name'],len(normalized),flush=True)
suite['protocol']['name']='Canonical ordinary-F2 comparator development suite; same ideals as original signed-lift/MQ systems; no acceptance claim';(out/'suite.json').write_text(json.dumps(suite,indent=2)+'\n')
