from pathlib import Path
import os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'f2-xor-only-production'
command=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'binary-dense-suite/suite.json'),'--hex-scheduling','degree','--baseline-scheduling','degree','--hex',str(base/'binaries/compute'),'--baseline',str(state/'retirement-depth-production/binaries/compute'),'--baseline-manifest',str(state/'retirement-depth-production/manifest.json'),'--hex-dense-pivots','false','--baseline-dense-pivots','false','--output',str(base/'f2-false')]
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
result=subprocess.run(command,env=env);(base/'measure-f4.py').write_bytes(Path(__file__).read_bytes());raise SystemExit(result.returncode)
