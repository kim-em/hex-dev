from pathlib import Path
import hashlib,json,random,sys
root=Path.cwd();sys.path.insert(0,str(root));from scripts.oracle.groebner_singular import expression
s=Path('/home/kim/tmp/issue-10987');original=s/'native-cc-option-production/f4/inputs';out=s/'binary-dense-suite';out.mkdir(exist_ok=False);plan=json.loads((original/'suite.json').read_text());cases=[]
def put(name,family,inp,provenance):
 (out/(name+'.json')).write_text(json.dumps(inp,indent=2)+'\n');(out/(name+'.ms')).write_text(','.join('x'+str(i)for i in range(inp['variables']))+'\n2\n'+',\n'.join(expression(g)for g in inp['generators'])+'\n');cases.append(dict(name=name,family=family,p=2,variables=inp['variables'],provenance=provenance))
for row in plan['cases']:
 if row['p']!=32003:continue
 p=original/(row['name']+'.json');inp=json.loads(p.read_text());mod=inp['p']
 for g in inp['generators']:
  for term in g:term[1]=(term[1]if 2*term[1]<=mod else term[1]-mod)%2
 inp['p']=2;name=row['name'].removesuffix('-15')+'-f2'
 put(name,row['family'],inp,dict(source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),map='centered signed lift of32003 residues, then reduction modulo2; ordinary polynomial ring; characteristic degenerations retained'))
for n,m in [(8,8),(9,9),(10,10)]:
 rng=random.Random(1098727+n);supports=[]
 for i in range(n):
  e=[0]*n;e[i]=1;supports.append(e)
 for i in range(n):
  for j in range(i,n):
   e=[0]*n;e[i]+=1;e[j]+=1;supports.append(e)
 generators=[]
 for _ in range(m):generators.append([[e,1]for e in supports if rng.getrandbits(1)])
 put(f'mq{n}-f2','mq',dict(p=2,variables=n,order='grevlex',generators=generators),dict(seed=1098727+n,generator='Bernoulli coefficients on all degree1/2 monomials including squares; zero planted root; no field equations'))
protocol=dict(plan['protocol']);protocol['name']='Fixed ordinary-F2 development suite: signed-lift family inputs plus three independently seeded MQ systems; no acceptance claim';(out/'suite.json').write_text(json.dumps(dict(cases=cases,protocol=protocol),indent=2)+'\n');print(len(cases),'cases',flush=True)
