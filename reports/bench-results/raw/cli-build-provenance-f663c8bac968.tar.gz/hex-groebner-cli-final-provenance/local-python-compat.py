import os
if not hasattr(os, 'pidfd_open'):
    import ctypes
    _libc = ctypes.CDLL(None, use_errno=True)
    _libc.pidfd_open.argtypes = [ctypes.c_int, ctypes.c_uint]
    _libc.pidfd_open.restype = ctypes.c_int
    def pidfd_open(pid, flags=0):
        result = _libc.pidfd_open(pid, flags)
        if result < 0:
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code))
        return result
    os.pidfd_open = pidfd_open
import signal
if not hasattr(signal, 'pidfd_send_signal'):
    import ctypes
    _signals = ctypes.CDLL(None, use_errno=True)
    _signals.pidfd_send_signal.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint]
    _signals.pidfd_send_signal.restype = ctypes.c_int
    def pidfd_send_signal(fd, sig, siginfo=None, flags=0):
        if siginfo is not None:
            raise NotImplementedError('local compatibility supports siginfo=None')
        result = _signals.pidfd_send_signal(fd, sig, None, flags)
        if result < 0:
            code = ctypes.get_errno()
            raise OSError(code, os.strerror(code))
    signal.pidfd_send_signal = pidfd_send_signal
