set -euo pipefail
python3 -m unittest scripts/ci/test_check_benches_mathlib_free.py
python3 -m unittest scripts/ci/test_check_bench_verify_budget.py
python3 -m unittest scripts/ci/test_classify_changed_libraries.py scripts/ci/test_oracle_build.py
python3 -m unittest scripts/ci/test_check_persistent_flint_warmup.py
python3 -m unittest scripts/bench/test_fresh_module_sweep.py
python3 -m unittest scripts/bench/test_primality_factor_corpus.py
python3 -m unittest scripts/bench/test_pminusone_reports.py
python3 -m unittest scripts/bench/test_rationalfn_flint.py scripts/bench/test_rationalfn_constants.py
python3 -m unittest scripts/bench/test_sign_det_sparse.py
python3 -m unittest scripts/bench/test_sign_det_compare.py
python3 -m unittest scripts/bench/test_sign_det_allocations.py
python3 -m unittest scripts/bench/test_sign_det_memory.py
python3 -m unittest scripts/bench/test_sign_det_maximal.py
python3 -m unittest scripts/bench/test_sign_det_maximal_workflow.py
python3 -m scripts.bench.sign_det_maximal_workflow_archive
python3 -m unittest scripts/bench/test_sign_det_maximal_matrix.py
python3 -m unittest scripts/bench/test_sign_det_matrix_wide.py
python3 -m unittest scripts/bench/test_sign_det_joint.py
python3 -m unittest scripts/bench/test_sign_det_joint_timing.py
python3 -m unittest scripts/bench/test_sign_det_nested_trace.py
python3 -c "from pathlib import Path; from scripts.bench.sign_det_trace_archive import check_retained; root = Path('reports/bench-results/sign-det-arithmetic-trace'); [check_retained(p) for p in [root / 'observations.jsonl', root / 'initial/observations.jsonl']]"
python3 -m scripts.bench.sign_det_operand_archive
python3 -m unittest scripts/bench/test_sign_det_nested_signs.py scripts/bench/test_sign_det_nested_tables.py
python3 scripts/bench/sign_det_joint.py reports/data/sign-det-joint/9651d8947/inventory.jsonl --retained
python3 -m unittest scripts/bench/test_sign_det_retained.py
python3 -m unittest scripts/bench/test_sign_det_height.py
python3 -m unittest scripts/bench/test_primality_policy_sweeps.py
python3 -m unittest scripts/bench/test_primality_replay_attribution.py
python3 -m unittest scripts/bench/test_primality_negative_sweep.py
python3 -m unittest scripts/bench/test_primality_mathlib_proof_sweep.py
python3 -m unittest scripts/bench/test_intfactor_phase4.py
python3 -m unittest scripts/profile/test_normalize_perf.py
python3 -m unittest scripts/profile/test_elf_symbols.py
python3 -m unittest scripts/profile/test_real_closure.py
python3 -m unittest scripts/bench/test_core_telemetry.py
python3 -m unittest scripts/bench/test_build_nested_normalization_counts.py
python3 -m unittest scripts/bench/test_real_closure_nested_measurement.py
python3 -m unittest scripts/bench/test_real_closure_nested_archive.py
python3 -m unittest scripts/bench/test_tower_factor_compare.py
python3 -m unittest scripts/oracle/test_flint_mpoly_bench.py
python3 -m unittest scripts/oracle/test_flint_fmpq_bench.py
python3 -m unittest scripts/oracle/test_singular_mpoly_bench.py
python3 -m unittest scripts/oracle/test_rcf_flint_bench.py
python3 scripts/ci/check_persistent_flint_warmup.py
