import Lake
open Lake DSL
package GroebnerRoundTrace
require Hex from "/tmp/hex-groebner-mersenne-dispatch-dev"
lean_exe round_trace where
  root := `Main
