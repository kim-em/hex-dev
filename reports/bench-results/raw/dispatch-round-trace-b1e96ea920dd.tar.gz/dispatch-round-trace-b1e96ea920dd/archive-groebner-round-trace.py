from pathlib import Path
import json,subprocess,shutil,hashlib,tarfile
p=Path('/tmp/hex-groebner-round-trace');out=p/'archive';out.mkdir(exist_ok=False)
prod=Path('/tmp/hex-groebner-mersenne-dispatch-production');comparison=prod/'msolve-l2-records-b1e96ea920dd'
for name in ['Main.lean','lakefile.lean','lake-manifest.json','lean-toolchain']:
 shutil.copy2(p/name,out/name)
shutil.copytree(p/'records',out/'records')
shutil.copy2('/tmp/issue-10987-round-trace-build.log',out/'build.log');shutil.copy2(__file__,out/Path(__file__).name)
meta=json.loads((comparison/'metadata.json').read_text());listing=(comparison/'source.manifest').read_text();(out/'source.manifest').write_text(listing)
for line in listing.splitlines():
 _,oid,rest=line.split(' ',2);_,name=rest.split('\t');f=out/'root-sources'/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','cat-file','blob',oid],cwd='/tmp/hex-groebner-mersenne-dispatch-dev'))
for row in json.loads((p/'records/summary.json').read_text()):
 case=row['case'];shutil.copy2(Path('/tmp/hex-groebner-compare')/(case+'.json'),out/(case+'.json'))
 reference=comparison/(case+'-b0-A.stdout');actual=json.loads((p/'records'/(case+'.stdout')).read_text());expected=json.loads(reference.read_text());assert actual['basis']==expected['basis'];shutil.copy2(reference,out/(case+'-reference.stdout'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(out/'metadata.json').write_text(json.dumps({'source_fingerprint':'b1e96ea920dd','commit':'d031fbf200698c78e461ed4d16e03411a1d9c959','executable_sha256':sha(p/'.lake/build/bin/round_trace'),'scope':'Explanatory counters only, no timing claim; decoding uncharged; reference complete bases from the retained msolve exact-mode comparison.','files':{str(f.relative_to(out)):sha(f) for f in sorted(out.rglob('*')) if f.is_file()}},indent=2)+'\n')
target=Path('/tmp/hex-groebner-evidence-review/reports/bench-results/raw/dispatch-round-trace-b1e96ea920dd.tar.gz');assert not target.exists()
with tarfile.open(target,'w:gz') as t:t.add(out,arcname='dispatch-round-trace-b1e96ea920dd')
print(target.name,sha(target))
