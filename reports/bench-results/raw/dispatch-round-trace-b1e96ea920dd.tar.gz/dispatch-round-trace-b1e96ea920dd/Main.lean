import HexGroebner
import Lean.Data.Json

open Hex.Groebner Lean

def parseTerm (j : Json) : Except String RawTerm := do
  let values ← j.getArr?
  if values.size != 2 then throw "term needs [exponents,coefficient]"
  let powers ← values[0]!.getArr? >>= fun a => a.mapM Json.getNat?
  let c ← values[1]!.getNat?
  if c ≥ 2^64 then throw "coefficient exceeds UInt64"
  return ⟨powers, c.toUInt64⟩

def parseInput (j : Json) : Except String (Context × Array RawPolynomial) := do
  let modulus ← j.getObjValAs? Nat "p"
  if h : Hex.Nat.isPrimeTrial modulus = true then
    if bound : modulus < 2^31 then
      let field : PrimeField := ⟨modulus.toUInt64, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using Hex.Nat.isPrimeTrial_isPrime h, by
        simpa [UInt64.toNat_ofNat, Nat.mod_eq_of_lt (by omega : modulus < 2^64)] using bound⟩
      let variables ← j.getObjValAs? Nat "variables"
      let order ← j.getObjValAs? String "order"
      let order ← match order with
        | "grevlex" => pure TermOrder.grevlex
        | "grlex" => pure TermOrder.grlex
        | "lex" => pure TermOrder.lex
        | _ => throw "unknown order"
      let generators ← j.getObjVal? "generators" >>= Json.getArr? >>= fun a =>
        a.mapM fun p => p.getArr? >>= fun a => a.mapM parseTerm
      return (⟨field, variables, order⟩, generators)
    else throw "modulus out of bounds"
  else throw "not prime"

def emitPolynomial (p : RawPolynomial) : Json := .arr (p.map fun t =>
  .arr #[toJson t.exponents, toJson t.coefficient.toNat])

def phaseName : F4.Phase → String
  | .input => "input"
  | .pairs => "pairs"
  | .interreduce => "interreduce"
  | .complete => "complete"

def main (args : List String) : IO Unit := do
  let [filename] := args | throw (IO.userError "round_trace input.json")
  let json ← IO.ofExcept (Json.parse (← IO.FS.readFile filename))
  let (context, generators) ← IO.ofExcept (parseInput json)
  let limits : Limits := {
    work := 100000000000
    packedBytes := 16 * 1024 * 1024 * 1024
    matrixEntries := 1000000000
    pairs := 100000000
    monomials := 10000000 }
  let mut checkpoint : F4.Checkpoint := {}
  let mut workspace : Workspace := ⟨{ arity := context.variables }, {}⟩
  let mut records : Array Json := #[]
  for step in [:10000] do
    if checkpoint.phase == .complete then
      let basis := checkpoint.basis.map fun g => g.polynomial.toRaw context.field workspace.table
      IO.println (Json.mkObj [("basis", .arr (basis.map emitPolynomial)),
        ("steps", .arr records), ("scope",toJson "explanatory stage counters; no timing claim; decode work not charged here")]).compress
      return
    let phase := phaseName checkpoint.phase
    let old := workspace.statistics
    let (result, nextWorkspace) := (F4.step context limits generators checkpoint).run workspace
    workspace := nextWorkspace
    checkpoint ← match result with
      | .ok value => pure value
      | .error error => throw (IO.userError s!"trace error {reprStr error}")
    let stats := workspace.statistics
    records := records.push (Json.mkObj [
      ("step",toJson step), ("phase",toJson phase),
      ("round",toJson stats.rounds), ("basis",toJson checkpoint.basis.size),
      ("basis_terms",toJson (checkpoint.basis.foldl (fun n g => n+g.polynomial.size) 0)),
      ("pending_pairs",toJson checkpoint.queue.heap.size),
      ("monomials",toJson workspace.table.count),
      ("work_delta",toJson (stats.work-old.work)),
      ("matrix_calls_delta",toJson (stats.matrixCalls-old.matrixCalls)),
      ("matrix_rows_delta",toJson (stats.matrixRows-old.matrixRows)),
      ("matrix_entries_delta",toJson (stats.matrixEntries-old.matrixEntries)),
      ("generated_pairs_delta",toJson (stats.pairs-old.pairs))])
  throw (IO.userError "trace step limit")
