// Lean compiler output
// Module: HexGroebner.Runtime
// Imports: public import Init public meta import Init public import HexGroebner.Monomial public import HexGroebner.Elimination
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Ordering_ctorIdx(uint8_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_string_length(lean_object*);
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_set(lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_Groebner_MonomialTable_compare(lean_object*, uint8_t, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_Groebner_instBEqMonomialError_beq(uint8_t, uint8_t);
uint8_t lp_Hex_Hex_Groebner_instBEqMatrixError_beq(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* l_Std_Format_fill(lean_object*);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
uint64_t lp_Hex_BarrettCtx_mk___redArg(uint64_t);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_nat_log2(lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
uint64_t lp_Hex_BarrettCtx_mulMod(uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorIdx(uint8_t);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
uint64_t lean_uint64_mix_hash(uint64_t, uint64_t);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
uint64_t lean_uint64_of_nat(lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* l_Repr_addAppParen(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_MonomialTable_mapProducts(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
extern lean_object* l_ByteArray_empty;
extern lean_object* l_System_Platform_numBits;
lean_object* lean_nat_pow(lean_object*, lean_object*);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
uint8_t lp_Hex_Hex_Groebner_PrimeField_width(uint64_t);
lean_object* lean_byte_array_size(lean_object*);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
uint8_t lean_byte_array_uget(lean_object*, size_t);
lean_object* lean_usize_to_nat(size_t);
lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr(uint8_t, lean_object*);
lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_MonomialTable_combineOwned(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* lp_Hex_Hex_Groebner_MonomialTable_internOwned(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqContext_decEq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqContext_decEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqContext(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqContext___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_Groebner_instReprRawTerm_repr_spec__1(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0_spec__2_spec__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0_spec__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0(lean_object*, lean_object*);
static const lean_string_object lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "#["};
static const lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__0 = (const lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__0_value;
static const lean_string_object lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ","};
static const lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__1 = (const lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__1_value;
static const lean_ctor_object lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__1_value)}};
static const lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__2 = (const lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__2_value;
static const lean_ctor_object lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__2_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__3 = (const lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__3_value;
static const lean_string_object lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "]"};
static const lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__4 = (const lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__4_value;
static lean_once_cell_t lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__5;
static lean_once_cell_t lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__6;
static const lean_ctor_object lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__0_value)}};
static const lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__7 = (const lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__7_value;
static const lean_ctor_object lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__4_value)}};
static const lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__8 = (const lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__8_value;
static const lean_string_object lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "#[]"};
static const lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__9 = (const lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__9_value;
static const lean_ctor_object lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__9_value)}};
static const lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__10 = (const lean_object*)&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__10_value;
LEAN_EXPORT lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0(lean_object*);
static const lean_string_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "{ "};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "exponents"};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__3_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = " := "};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__5_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__3_value),((lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__5_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__6_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__7;
static const lean_string_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "coefficient"};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__8_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__9_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__10;
static const lean_string_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = " }"};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__11 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__11_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__12;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__13;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__14 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__14_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__11_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__15 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__15_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprRawTerm___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprRawTerm_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprRawTerm = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqRawTerm_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqRawTerm_beq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqRawTerm___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqRawTerm_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqRawTerm___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqRawTerm___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqRawTerm = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqRawTerm___closed__0_value;
static const lean_array_object lp_Hex_Hex_Groebner_instInhabitedRawTerm_default___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_Groebner_instInhabitedRawTerm_default___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedRawTerm_default___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instInhabitedRawTerm_default___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 8, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instInhabitedRawTerm_default___closed__0_value),LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex_Hex_Groebner_instInhabitedRawTerm_default___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedRawTerm_default___closed__1_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedRawTerm_default = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedRawTerm_default___closed__1_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedRawTerm = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedRawTerm_default___closed__1_value;
LEAN_EXPORT uint64_t lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_instHashableRawTerm_hash_spec__0(lean_object*, size_t, size_t, uint64_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_instHashableRawTerm_hash_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_instHashableRawTerm_hash(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instHashableRawTerm_hash___boxed(lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instHashableRawTerm___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instHashableRawTerm_hash___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instHashableRawTerm___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instHashableRawTerm___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instHashableRawTerm = (const lean_object*)&lp_Hex_Hex_Groebner_instHashableRawTerm___closed__0_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instInhabitedPolynomial_default___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instInhabitedPolynomial_default___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedPolynomial_default;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedPolynomial;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_size(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_size___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monomial(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monomial___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Polynomial_coefficient(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_coefficient___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_work_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_work_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_work_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_work_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_monomials_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_monomials_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_monomials_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_monomials_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_pairs_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_pairs_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_pairs_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_pairs_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_rounds_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_rounds_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_rounds_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_rounds_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_basis_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_basis_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_basis_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_basis_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_variables_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_variables_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_variables_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_variables_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqF4Resource_beq(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqF4Resource_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqF4Resource___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqF4Resource_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqF4Resource___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqF4Resource___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqF4Resource = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqF4Resource___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 29, .m_capacity = 29, .m_length = 28, .m_data = "Hex.Groebner.F4Resource.work"};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__1_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 36, .m_capacity = 36, .m_length = 35, .m_data = "Hex.Groebner.F4Resource.packedBytes"};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__3_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "Hex.Groebner.F4Resource.monomials"};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__5_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "Hex.Groebner.F4Resource.pairs"};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__6_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__6_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__7 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__7_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 31, .m_capacity = 31, .m_length = 30, .m_data = "Hex.Groebner.F4Resource.rounds"};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__8_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__9_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 38, .m_capacity = 38, .m_length = 37, .m_data = "Hex.Groebner.F4Resource.matrixEntries"};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__10 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__10_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__10_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__11 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__11_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "Hex.Groebner.F4Resource.matrixRows"};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__12 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__12_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__12_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__13 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__13_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "Hex.Groebner.F4Resource.basis"};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__14 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__14_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__14_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__15 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__15_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "Hex.Groebner.F4Resource.variables"};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__16 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__16_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__16_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__17 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__17_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr(uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprF4Resource___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprF4Resource_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprF4Resource = (const lean_object*)&lp_Hex_Hex_Groebner_instReprF4Resource___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_arity_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_arity_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_coefficient_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_coefficient_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_representation_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_representation_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_exhausted_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_exhausted_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_matrix_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_matrix_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqComputeError_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqComputeError_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqComputeError___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqComputeError_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqComputeError___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqComputeError___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqComputeError = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqComputeError___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 32, .m_capacity = 32, .m_length = 31, .m_data = "Hex.Groebner.ComputeError.arity"};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__1_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__2_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 38, .m_capacity = 38, .m_length = 37, .m_data = "Hex.Groebner.ComputeError.coefficient"};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__3_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__3_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__4_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__5_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 41, .m_capacity = 41, .m_length = 40, .m_data = "Hex.Groebner.ComputeError.representation"};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__6_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__6_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__7 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__7_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__7_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__8_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 36, .m_capacity = 36, .m_length = 35, .m_data = "Hex.Groebner.ComputeError.exhausted"};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__9_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__9_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__10 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__10_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__10_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__11 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__11_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "Hex.Groebner.ComputeError.matrix"};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__12 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__12_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__12_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__13 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__13_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__13_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__14 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__14_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprComputeError___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprComputeError_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprComputeError___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprComputeError = (const lean_object*)&lp_Hex_Hex_Groebner_instReprComputeError___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instInhabitedLimits_default___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*10 + 8, .m_other = 10, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(100000000) << 1) | 1)),((lean_object*)(((size_t)(268435456) << 1) | 1)),((lean_object*)(((size_t)(1000000) << 1) | 1)),((lean_object*)(((size_t)(1000000) << 1) | 1)),((lean_object*)(((size_t)(10000) << 1) | 1)),((lean_object*)(((size_t)(10000000) << 1) | 1)),((lean_object*)(((size_t)(10000000) << 1) | 1)),((lean_object*)(((size_t)(100000) << 1) | 1)),((lean_object*)(((size_t)(10000) << 1) | 1)),((lean_object*)(((size_t)(1024) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(1, 1, 1, 1, 0, 0, 0, 0)}};
static const lean_object* lp_Hex_Hex_Groebner_instInhabitedLimits_default___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedLimits_default___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedLimits_default = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedLimits_default___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedLimits = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedLimits_default___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "work"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__2_value),((lean_object*)&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__5_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__3_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__4;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "allocatedBytes"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__5_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__5_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__6_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__7;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "pairs"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__8_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__9_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__10;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "rounds"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__11 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__11_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__11_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__12 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__12_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__13_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__13;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "matrixEntries"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__14 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__14_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__14_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__15 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__15_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__16_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__16;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "matrixRows"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__17 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__17_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__17_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__18 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__18_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__19_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__19;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "matrixCalls"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__20 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__20_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__20_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__21 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__21_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "peakMatrixRows"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__22 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__22_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__22_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__23 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__23_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "peakMatrixEntries"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__24 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__24_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__24_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__25 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__25_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__26_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__26;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "largestBatch"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__27 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__27_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__28_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__27_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__28 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__28_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__29_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__29;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__30_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "productPairs"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__30 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__30_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__31_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__30_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__31 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__31_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "chainPairs"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__32 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__32_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__33_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__32_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__33 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__33_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__34_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "gmPairs"};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__34 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__34_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__35_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__34_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__35 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__35_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__36_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__36;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprStatistics___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprStatistics_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprStatistics___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprStatistics = (const lean_object*)&lp_Hex_Hex_Groebner_instReprStatistics___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqStatistics_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqStatistics_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqStatistics___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqStatistics_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqStatistics___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqStatistics___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqStatistics = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqStatistics___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instInhabitedStatistics_default___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*13 + 0, .m_other = 13, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instInhabitedStatistics_default___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedStatistics_default___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedStatistics_default = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedStatistics_default___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedStatistics = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedStatistics_default___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_spend___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_spend___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_spend___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_spend___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 3}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_spend___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_spend___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_spend___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Computation_spend___closed__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_spend___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_spend___closed__2_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_spend(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_spend___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Groebner_Computation_allocate___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_Computation_allocate___closed__0;
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_allocate___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 2}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_allocate___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_allocate___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_allocate___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Computation_allocate___closed__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_allocate___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_allocate___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_allocate___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 3}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_allocate___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_allocate___closed__3_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_allocate___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Computation_allocate___closed__3_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_allocate___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_allocate___closed__4_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_allocate(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_allocate___boxed(lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 3}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome___redArg___closed__0 = (const lean_object*)&lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableResult(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_products(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_products___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_intern___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_intern___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_intern(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_combine___lam__0(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_combine___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_combine(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_combine___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0___redArg(lean_object*, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_inverse___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Computation_spend___closed__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_inverse___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_inverse___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_inverse___closed__1___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_Computation_inverse___closed__1___boxed__const__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_inverse___closed__1___boxed__const__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_inverse___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Computation_inverse___closed__1___boxed__const__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_inverse___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_inverse___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_inverse(uint64_t, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_inverse___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0(lean_object*, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg___closed__0;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex_Hex_Groebner_Computation_sort___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Computation_spend___closed__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Computation_sort___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Computation_sort___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_sort(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_sort___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqContext_decEq(lean_object* v_x_1_, lean_object* v_x_2_){
_start:
{
uint64_t v_field_3_; lean_object* v_variables_4_; uint8_t v_order_5_; uint64_t v_field_6_; lean_object* v_variables_7_; uint8_t v_order_8_; uint8_t v___x_9_; 
v_field_3_ = lean_ctor_get_uint64(v_x_1_, sizeof(void*)*1);
v_variables_4_ = lean_ctor_get(v_x_1_, 0);
v_order_5_ = lean_ctor_get_uint8(v_x_1_, sizeof(void*)*1 + 8);
v_field_6_ = lean_ctor_get_uint64(v_x_2_, sizeof(void*)*1);
v_variables_7_ = lean_ctor_get(v_x_2_, 0);
v_order_8_ = lean_ctor_get_uint8(v_x_2_, sizeof(void*)*1 + 8);
v___x_9_ = lean_uint64_dec_eq(v_field_3_, v_field_6_);
if (v___x_9_ == 0)
{
return v___x_9_;
}
else
{
uint8_t v___x_10_; 
v___x_10_ = lean_nat_dec_eq(v_variables_4_, v_variables_7_);
if (v___x_10_ == 0)
{
return v___x_10_;
}
else
{
lean_object* v___x_11_; lean_object* v___x_12_; uint8_t v___x_13_; 
v___x_11_ = lp_Hex_Hex_Groebner_TermOrder_ctorIdx(v_order_5_);
v___x_12_ = lp_Hex_Hex_Groebner_TermOrder_ctorIdx(v_order_8_);
v___x_13_ = lean_nat_dec_eq(v___x_11_, v___x_12_);
lean_dec(v___x_12_);
lean_dec(v___x_11_);
return v___x_13_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqContext_decEq___boxed(lean_object* v_x_14_, lean_object* v_x_15_){
_start:
{
uint8_t v_res_16_; lean_object* v_r_17_; 
v_res_16_ = lp_Hex_Hex_Groebner_instDecidableEqContext_decEq(v_x_14_, v_x_15_);
lean_dec_ref(v_x_15_);
lean_dec_ref(v_x_14_);
v_r_17_ = lean_box(v_res_16_);
return v_r_17_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqContext(lean_object* v_x_18_, lean_object* v_x_19_){
_start:
{
uint8_t v___x_20_; 
v___x_20_ = lp_Hex_Hex_Groebner_instDecidableEqContext_decEq(v_x_18_, v_x_19_);
return v___x_20_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqContext___boxed(lean_object* v_x_21_, lean_object* v_x_22_){
_start:
{
uint8_t v_res_23_; lean_object* v_r_24_; 
v_res_23_ = lp_Hex_Hex_Groebner_instDecidableEqContext(v_x_21_, v_x_22_);
lean_dec_ref(v_x_22_);
lean_dec_ref(v_x_21_);
v_r_24_ = lean_box(v_res_23_);
return v_r_24_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_Groebner_instReprRawTerm_repr_spec__1(lean_object* v_a_25_){
_start:
{
lean_object* v___x_26_; 
v___x_26_ = lean_nat_to_int(v_a_25_);
return v___x_26_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0___lam__0(lean_object* v___y_27_){
_start:
{
lean_object* v___x_28_; lean_object* v___x_29_; 
v___x_28_ = l_Nat_reprFast(v___y_27_);
v___x_29_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_29_, 0, v___x_28_);
return v___x_29_;
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0_spec__2_spec__3(lean_object* v_x_30_, lean_object* v_x_31_, lean_object* v_x_32_){
_start:
{
if (lean_obj_tag(v_x_32_) == 0)
{
lean_dec(v_x_30_);
return v_x_31_;
}
else
{
lean_object* v_head_33_; lean_object* v_tail_34_; lean_object* v___x_36_; uint8_t v_isShared_37_; uint8_t v_isSharedCheck_45_; 
v_head_33_ = lean_ctor_get(v_x_32_, 0);
v_tail_34_ = lean_ctor_get(v_x_32_, 1);
v_isSharedCheck_45_ = !lean_is_exclusive(v_x_32_);
if (v_isSharedCheck_45_ == 0)
{
v___x_36_ = v_x_32_;
v_isShared_37_ = v_isSharedCheck_45_;
goto v_resetjp_35_;
}
else
{
lean_inc(v_tail_34_);
lean_inc(v_head_33_);
lean_dec(v_x_32_);
v___x_36_ = lean_box(0);
v_isShared_37_ = v_isSharedCheck_45_;
goto v_resetjp_35_;
}
v_resetjp_35_:
{
lean_object* v___x_39_; 
lean_inc(v_x_30_);
if (v_isShared_37_ == 0)
{
lean_ctor_set_tag(v___x_36_, 5);
lean_ctor_set(v___x_36_, 1, v_x_30_);
lean_ctor_set(v___x_36_, 0, v_x_31_);
v___x_39_ = v___x_36_;
goto v_reusejp_38_;
}
else
{
lean_object* v_reuseFailAlloc_44_; 
v_reuseFailAlloc_44_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_44_, 0, v_x_31_);
lean_ctor_set(v_reuseFailAlloc_44_, 1, v_x_30_);
v___x_39_ = v_reuseFailAlloc_44_;
goto v_reusejp_38_;
}
v_reusejp_38_:
{
lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; 
v___x_40_ = l_Nat_reprFast(v_head_33_);
v___x_41_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_41_, 0, v___x_40_);
v___x_42_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_42_, 0, v___x_39_);
lean_ctor_set(v___x_42_, 1, v___x_41_);
v_x_31_ = v___x_42_;
v_x_32_ = v_tail_34_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0_spec__2(lean_object* v_x_46_, lean_object* v_x_47_, lean_object* v_x_48_){
_start:
{
if (lean_obj_tag(v_x_48_) == 0)
{
lean_dec(v_x_46_);
return v_x_47_;
}
else
{
lean_object* v_head_49_; lean_object* v_tail_50_; lean_object* v___x_52_; uint8_t v_isShared_53_; uint8_t v_isSharedCheck_61_; 
v_head_49_ = lean_ctor_get(v_x_48_, 0);
v_tail_50_ = lean_ctor_get(v_x_48_, 1);
v_isSharedCheck_61_ = !lean_is_exclusive(v_x_48_);
if (v_isSharedCheck_61_ == 0)
{
v___x_52_ = v_x_48_;
v_isShared_53_ = v_isSharedCheck_61_;
goto v_resetjp_51_;
}
else
{
lean_inc(v_tail_50_);
lean_inc(v_head_49_);
lean_dec(v_x_48_);
v___x_52_ = lean_box(0);
v_isShared_53_ = v_isSharedCheck_61_;
goto v_resetjp_51_;
}
v_resetjp_51_:
{
lean_object* v___x_55_; 
lean_inc(v_x_46_);
if (v_isShared_53_ == 0)
{
lean_ctor_set_tag(v___x_52_, 5);
lean_ctor_set(v___x_52_, 1, v_x_46_);
lean_ctor_set(v___x_52_, 0, v_x_47_);
v___x_55_ = v___x_52_;
goto v_reusejp_54_;
}
else
{
lean_object* v_reuseFailAlloc_60_; 
v_reuseFailAlloc_60_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_60_, 0, v_x_47_);
lean_ctor_set(v_reuseFailAlloc_60_, 1, v_x_46_);
v___x_55_ = v_reuseFailAlloc_60_;
goto v_reusejp_54_;
}
v_reusejp_54_:
{
lean_object* v___x_56_; lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; 
v___x_56_ = l_Nat_reprFast(v_head_49_);
v___x_57_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_57_, 0, v___x_56_);
v___x_58_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_58_, 0, v___x_55_);
lean_ctor_set(v___x_58_, 1, v___x_57_);
v___x_59_ = lp_Hex_List_foldl___at___00List_foldl___at___00Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0_spec__2_spec__3(v_x_46_, v___x_58_, v_tail_50_);
return v___x_59_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0(lean_object* v_x_62_, lean_object* v_x_63_){
_start:
{
if (lean_obj_tag(v_x_62_) == 0)
{
lean_object* v___x_64_; 
lean_dec(v_x_63_);
v___x_64_ = lean_box(0);
return v___x_64_;
}
else
{
lean_object* v_tail_65_; 
v_tail_65_ = lean_ctor_get(v_x_62_, 1);
if (lean_obj_tag(v_tail_65_) == 0)
{
lean_object* v_head_66_; lean_object* v___x_67_; 
lean_dec(v_x_63_);
v_head_66_ = lean_ctor_get(v_x_62_, 0);
lean_inc(v_head_66_);
lean_dec_ref_known(v_x_62_, 2);
v___x_67_ = lp_Hex_Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0___lam__0(v_head_66_);
return v___x_67_;
}
else
{
lean_object* v_head_68_; lean_object* v___x_69_; lean_object* v___x_70_; 
lean_inc(v_tail_65_);
v_head_68_ = lean_ctor_get(v_x_62_, 0);
lean_inc(v_head_68_);
lean_dec_ref_known(v_x_62_, 2);
v___x_69_ = lp_Hex_Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0___lam__0(v_head_68_);
v___x_70_ = lp_Hex_List_foldl___at___00Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0_spec__2(v_x_63_, v___x_69_, v_tail_65_);
return v___x_70_;
}
}
}
}
static lean_object* _init_lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__5(void){
_start:
{
lean_object* v___x_79_; lean_object* v___x_80_; 
v___x_79_ = ((lean_object*)(lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__0));
v___x_80_ = lean_string_length(v___x_79_);
return v___x_80_;
}
}
static lean_object* _init_lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__6(void){
_start:
{
lean_object* v___x_81_; lean_object* v___x_82_; 
v___x_81_ = lean_obj_once(&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__5, &lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__5_once, _init_lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__5);
v___x_82_ = lean_nat_to_int(v___x_81_);
return v___x_82_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0(lean_object* v_xs_90_){
_start:
{
lean_object* v___x_91_; lean_object* v___x_92_; uint8_t v___x_93_; 
v___x_91_ = lean_array_get_size(v_xs_90_);
v___x_92_ = lean_unsigned_to_nat(0u);
v___x_93_ = lean_nat_dec_eq(v___x_91_, v___x_92_);
if (v___x_93_ == 0)
{
lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v___x_97_; lean_object* v___x_98_; lean_object* v___x_99_; lean_object* v___x_100_; lean_object* v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; 
v___x_94_ = lean_array_to_list(v_xs_90_);
v___x_95_ = ((lean_object*)(lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__3));
v___x_96_ = lp_Hex_Std_Format_joinSep___at___00Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0_spec__0(v___x_94_, v___x_95_);
v___x_97_ = lean_obj_once(&lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__6, &lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__6_once, _init_lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__6);
v___x_98_ = ((lean_object*)(lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__7));
v___x_99_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_99_, 0, v___x_98_);
lean_ctor_set(v___x_99_, 1, v___x_96_);
v___x_100_ = ((lean_object*)(lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__8));
v___x_101_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_101_, 0, v___x_99_);
lean_ctor_set(v___x_101_, 1, v___x_100_);
v___x_102_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_102_, 0, v___x_97_);
lean_ctor_set(v___x_102_, 1, v___x_101_);
v___x_103_ = l_Std_Format_fill(v___x_102_);
return v___x_103_;
}
else
{
lean_object* v___x_104_; 
lean_dec_ref(v_xs_90_);
v___x_104_ = ((lean_object*)(lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__10));
return v___x_104_;
}
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__7(void){
_start:
{
lean_object* v___x_118_; lean_object* v___x_119_; 
v___x_118_ = lean_unsigned_to_nat(13u);
v___x_119_ = lean_nat_to_int(v___x_118_);
return v___x_119_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__10(void){
_start:
{
lean_object* v___x_123_; lean_object* v___x_124_; 
v___x_123_ = lean_unsigned_to_nat(15u);
v___x_124_ = lean_nat_to_int(v___x_123_);
return v___x_124_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__12(void){
_start:
{
lean_object* v___x_126_; lean_object* v___x_127_; 
v___x_126_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__0));
v___x_127_ = lean_string_length(v___x_126_);
return v___x_127_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__13(void){
_start:
{
lean_object* v___x_128_; lean_object* v___x_129_; 
v___x_128_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__12, &lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__12_once, _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__12);
v___x_129_ = lean_nat_to_int(v___x_128_);
return v___x_129_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg(lean_object* v_x_134_){
_start:
{
lean_object* v_exponents_135_; uint64_t v_coefficient_136_; lean_object* v___x_137_; lean_object* v___x_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; uint8_t v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; lean_object* v___x_157_; lean_object* v___x_158_; lean_object* v___x_159_; lean_object* v___x_160_; lean_object* v___x_161_; lean_object* v___x_162_; lean_object* v___x_163_; lean_object* v___x_164_; lean_object* v___x_165_; 
v_exponents_135_ = lean_ctor_get(v_x_134_, 0);
lean_inc_ref(v_exponents_135_);
v_coefficient_136_ = lean_ctor_get_uint64(v_x_134_, sizeof(void*)*1);
lean_dec_ref(v_x_134_);
v___x_137_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__5));
v___x_138_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__6));
v___x_139_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__7, &lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__7);
v___x_140_ = lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0(v_exponents_135_);
v___x_141_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_141_, 0, v___x_139_);
lean_ctor_set(v___x_141_, 1, v___x_140_);
v___x_142_ = 0;
v___x_143_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_143_, 0, v___x_141_);
lean_ctor_set_uint8(v___x_143_, sizeof(void*)*1, v___x_142_);
v___x_144_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_144_, 0, v___x_138_);
lean_ctor_set(v___x_144_, 1, v___x_143_);
v___x_145_ = ((lean_object*)(lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__2));
v___x_146_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_146_, 0, v___x_144_);
lean_ctor_set(v___x_146_, 1, v___x_145_);
v___x_147_ = lean_box(1);
v___x_148_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_148_, 0, v___x_146_);
lean_ctor_set(v___x_148_, 1, v___x_147_);
v___x_149_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__9));
v___x_150_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_150_, 0, v___x_148_);
lean_ctor_set(v___x_150_, 1, v___x_149_);
v___x_151_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_151_, 0, v___x_150_);
lean_ctor_set(v___x_151_, 1, v___x_137_);
v___x_152_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__10, &lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__10_once, _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__10);
v___x_153_ = lean_uint64_to_nat(v_coefficient_136_);
v___x_154_ = l_Nat_reprFast(v___x_153_);
v___x_155_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_155_, 0, v___x_154_);
v___x_156_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_156_, 0, v___x_152_);
lean_ctor_set(v___x_156_, 1, v___x_155_);
v___x_157_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_157_, 0, v___x_156_);
lean_ctor_set_uint8(v___x_157_, sizeof(void*)*1, v___x_142_);
v___x_158_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_158_, 0, v___x_151_);
lean_ctor_set(v___x_158_, 1, v___x_157_);
v___x_159_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__13, &lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__13_once, _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__13);
v___x_160_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__14));
v___x_161_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_161_, 0, v___x_160_);
lean_ctor_set(v___x_161_, 1, v___x_158_);
v___x_162_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__15));
v___x_163_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_163_, 0, v___x_161_);
lean_ctor_set(v___x_163_, 1, v___x_162_);
v___x_164_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_164_, 0, v___x_159_);
lean_ctor_set(v___x_164_, 1, v___x_163_);
v___x_165_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_165_, 0, v___x_164_);
lean_ctor_set_uint8(v___x_165_, sizeof(void*)*1, v___x_142_);
return v___x_165_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr(lean_object* v_x_166_, lean_object* v_prec_167_){
_start:
{
lean_object* v___x_168_; 
v___x_168_ = lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg(v_x_166_);
return v___x_168_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRawTerm_repr___boxed(lean_object* v_x_169_, lean_object* v_prec_170_){
_start:
{
lean_object* v_res_171_; 
v_res_171_ = lp_Hex_Hex_Groebner_instReprRawTerm_repr(v_x_169_, v_prec_170_);
lean_dec(v_prec_170_);
return v_res_171_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0___redArg(lean_object* v_xs_174_, lean_object* v_ys_175_, lean_object* v_x_176_){
_start:
{
lean_object* v_zero_177_; uint8_t v_isZero_178_; 
v_zero_177_ = lean_unsigned_to_nat(0u);
v_isZero_178_ = lean_nat_dec_eq(v_x_176_, v_zero_177_);
if (v_isZero_178_ == 1)
{
lean_dec(v_x_176_);
return v_isZero_178_;
}
else
{
lean_object* v_one_179_; lean_object* v_n_180_; lean_object* v___x_181_; lean_object* v___x_182_; uint8_t v___x_183_; 
v_one_179_ = lean_unsigned_to_nat(1u);
v_n_180_ = lean_nat_sub(v_x_176_, v_one_179_);
lean_dec(v_x_176_);
v___x_181_ = lean_array_fget_borrowed(v_xs_174_, v_n_180_);
v___x_182_ = lean_array_fget_borrowed(v_ys_175_, v_n_180_);
v___x_183_ = lean_nat_dec_eq(v___x_181_, v___x_182_);
if (v___x_183_ == 0)
{
lean_dec(v_n_180_);
return v___x_183_;
}
else
{
v_x_176_ = v_n_180_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0___redArg___boxed(lean_object* v_xs_185_, lean_object* v_ys_186_, lean_object* v_x_187_){
_start:
{
uint8_t v_res_188_; lean_object* v_r_189_; 
v_res_188_ = lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0___redArg(v_xs_185_, v_ys_186_, v_x_187_);
lean_dec_ref(v_ys_186_);
lean_dec_ref(v_xs_185_);
v_r_189_ = lean_box(v_res_188_);
return v_r_189_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqRawTerm_beq(lean_object* v_x_190_, lean_object* v_x_191_){
_start:
{
lean_object* v_exponents_192_; uint64_t v_coefficient_193_; lean_object* v_exponents_194_; uint64_t v_coefficient_195_; lean_object* v___x_196_; lean_object* v___x_197_; uint8_t v___x_198_; 
v_exponents_192_ = lean_ctor_get(v_x_190_, 0);
v_coefficient_193_ = lean_ctor_get_uint64(v_x_190_, sizeof(void*)*1);
v_exponents_194_ = lean_ctor_get(v_x_191_, 0);
v_coefficient_195_ = lean_ctor_get_uint64(v_x_191_, sizeof(void*)*1);
v___x_196_ = lean_array_get_size(v_exponents_192_);
v___x_197_ = lean_array_get_size(v_exponents_194_);
v___x_198_ = lean_nat_dec_eq(v___x_196_, v___x_197_);
if (v___x_198_ == 0)
{
return v___x_198_;
}
else
{
uint8_t v___x_199_; 
v___x_199_ = lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0___redArg(v_exponents_192_, v_exponents_194_, v___x_196_);
if (v___x_199_ == 0)
{
return v___x_199_;
}
else
{
uint8_t v___x_200_; 
v___x_200_ = lean_uint64_dec_eq(v_coefficient_193_, v_coefficient_195_);
return v___x_200_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqRawTerm_beq___boxed(lean_object* v_x_201_, lean_object* v_x_202_){
_start:
{
uint8_t v_res_203_; lean_object* v_r_204_; 
v_res_203_ = lp_Hex_Hex_Groebner_instBEqRawTerm_beq(v_x_201_, v_x_202_);
lean_dec_ref(v_x_202_);
lean_dec_ref(v_x_201_);
v_r_204_ = lean_box(v_res_203_);
return v_r_204_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0(lean_object* v_xs_205_, lean_object* v_ys_206_, lean_object* v_hsz_207_, lean_object* v_x_208_, lean_object* v_x_209_){
_start:
{
uint8_t v___x_210_; 
v___x_210_ = lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0___redArg(v_xs_205_, v_ys_206_, v_x_208_);
return v___x_210_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0___boxed(lean_object* v_xs_211_, lean_object* v_ys_212_, lean_object* v_hsz_213_, lean_object* v_x_214_, lean_object* v_x_215_){
_start:
{
uint8_t v_res_216_; lean_object* v_r_217_; 
v_res_216_ = lp_Hex_Array_isEqvAux___at___00Hex_Groebner_instBEqRawTerm_beq_spec__0(v_xs_211_, v_ys_212_, v_hsz_213_, v_x_214_, v_x_215_);
lean_dec_ref(v_ys_212_);
lean_dec_ref(v_xs_211_);
v_r_217_ = lean_box(v_res_216_);
return v_r_217_;
}
}
LEAN_EXPORT uint64_t lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_instHashableRawTerm_hash_spec__0(lean_object* v_as_227_, size_t v_i_228_, size_t v_stop_229_, uint64_t v_b_230_){
_start:
{
uint8_t v___x_231_; 
v___x_231_ = lean_usize_dec_eq(v_i_228_, v_stop_229_);
if (v___x_231_ == 0)
{
lean_object* v___x_232_; uint64_t v___x_233_; uint64_t v___x_234_; size_t v___x_235_; size_t v___x_236_; 
v___x_232_ = lean_array_uget_borrowed(v_as_227_, v_i_228_);
v___x_233_ = lean_uint64_of_nat(v___x_232_);
v___x_234_ = lean_uint64_mix_hash(v_b_230_, v___x_233_);
v___x_235_ = ((size_t)1ULL);
v___x_236_ = lean_usize_add(v_i_228_, v___x_235_);
v_i_228_ = v___x_236_;
v_b_230_ = v___x_234_;
goto _start;
}
else
{
return v_b_230_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_instHashableRawTerm_hash_spec__0___boxed(lean_object* v_as_238_, lean_object* v_i_239_, lean_object* v_stop_240_, lean_object* v_b_241_){
_start:
{
size_t v_i_boxed_242_; size_t v_stop_boxed_243_; uint64_t v_b_boxed_244_; uint64_t v_res_245_; lean_object* v_r_246_; 
v_i_boxed_242_ = lean_unbox_usize(v_i_239_);
lean_dec(v_i_239_);
v_stop_boxed_243_ = lean_unbox_usize(v_stop_240_);
lean_dec(v_stop_240_);
v_b_boxed_244_ = lean_unbox_uint64(v_b_241_);
lean_dec_ref(v_b_241_);
v_res_245_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_instHashableRawTerm_hash_spec__0(v_as_238_, v_i_boxed_242_, v_stop_boxed_243_, v_b_boxed_244_);
lean_dec_ref(v_as_238_);
v_r_246_ = lean_box_uint64(v_res_245_);
return v_r_246_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_instHashableRawTerm_hash(lean_object* v_x_247_){
_start:
{
lean_object* v_exponents_248_; uint64_t v_coefficient_249_; uint64_t v___x_250_; uint64_t v___y_252_; uint64_t v___x_255_; lean_object* v___x_256_; lean_object* v___x_257_; uint8_t v___x_258_; 
v_exponents_248_ = lean_ctor_get(v_x_247_, 0);
v_coefficient_249_ = lean_ctor_get_uint64(v_x_247_, sizeof(void*)*1);
v___x_250_ = 0ULL;
v___x_255_ = 7ULL;
v___x_256_ = lean_unsigned_to_nat(0u);
v___x_257_ = lean_array_get_size(v_exponents_248_);
v___x_258_ = lean_nat_dec_lt(v___x_256_, v___x_257_);
if (v___x_258_ == 0)
{
v___y_252_ = v___x_255_;
goto v___jp_251_;
}
else
{
size_t v___x_259_; size_t v___x_260_; uint64_t v___x_261_; 
v___x_259_ = ((size_t)0ULL);
v___x_260_ = lean_usize_of_nat(v___x_257_);
v___x_261_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_instHashableRawTerm_hash_spec__0(v_exponents_248_, v___x_259_, v___x_260_, v___x_255_);
v___y_252_ = v___x_261_;
goto v___jp_251_;
}
v___jp_251_:
{
uint64_t v___x_253_; uint64_t v___x_254_; 
v___x_253_ = lean_uint64_mix_hash(v___x_250_, v___y_252_);
v___x_254_ = lean_uint64_mix_hash(v___x_253_, v_coefficient_249_);
return v___x_254_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instHashableRawTerm_hash___boxed(lean_object* v_x_262_){
_start:
{
uint64_t v_res_263_; lean_object* v_r_264_; 
v_res_263_ = lp_Hex_Hex_Groebner_instHashableRawTerm_hash(v_x_262_);
lean_dec_ref(v_x_262_);
v_r_264_ = lean_box_uint64(v_res_263_);
return v_r_264_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedPolynomial_default___closed__0(void){
_start:
{
lean_object* v___x_267_; lean_object* v___x_268_; 
v___x_267_ = l_ByteArray_empty;
v___x_268_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_268_, 0, v___x_267_);
lean_ctor_set(v___x_268_, 1, v___x_267_);
return v___x_268_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedPolynomial_default(void){
_start:
{
lean_object* v___x_269_; 
v___x_269_ = lean_obj_once(&lp_Hex_Hex_Groebner_instInhabitedPolynomial_default___closed__0, &lp_Hex_Hex_Groebner_instInhabitedPolynomial_default___closed__0_once, _init_lp_Hex_Hex_Groebner_instInhabitedPolynomial_default___closed__0);
return v___x_269_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedPolynomial(void){
_start:
{
lean_object* v___x_270_; 
v___x_270_ = lp_Hex_Hex_Groebner_instInhabitedPolynomial_default;
return v___x_270_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_size(lean_object* v_p_271_){
_start:
{
lean_object* v_support_272_; lean_object* v___x_273_; lean_object* v___x_274_; lean_object* v___x_275_; 
v_support_272_ = lean_ctor_get(v_p_271_, 0);
v___x_273_ = lean_byte_array_size(v_support_272_);
v___x_274_ = lean_unsigned_to_nat(2u);
v___x_275_ = lean_nat_shiftr(v___x_273_, v___x_274_);
return v___x_275_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_size___boxed(lean_object* v_p_276_){
_start:
{
lean_object* v_res_277_; 
v_res_277_ = lp_Hex_Hex_Groebner_Polynomial_size(v_p_276_);
lean_dec_ref(v_p_276_);
return v_res_277_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(lean_object* v_xs_278_, lean_object* v_i_279_){
_start:
{
lean_object* v___x_280_; uint8_t v___x_281_; 
v___x_280_ = lean_byte_array_size(v_xs_278_);
v___x_281_ = lean_nat_dec_lt(v_i_279_, v___x_280_);
return v___x_281_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0___boxed(lean_object* v_xs_282_, lean_object* v_i_283_){
_start:
{
uint8_t v_res_284_; lean_object* v_r_285_; 
v_res_284_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_xs_282_, v_i_283_);
lean_dec(v_i_283_);
lean_dec_ref(v_xs_282_);
v_r_285_ = lean_box(v_res_284_);
return v_r_285_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monomial(lean_object* v_p_286_, lean_object* v_i_287_){
_start:
{
uint64_t v___y_289_; uint8_t v___y_290_; lean_object* v_support_296_; uint8_t v___x_297_; lean_object* v___x_298_; lean_object* v_offset_299_; uint64_t v___y_301_; uint8_t v___y_302_; uint64_t v___y_315_; uint8_t v___y_316_; uint8_t v___y_329_; uint8_t v___y_339_; lean_object* v___x_370_; lean_object* v___x_371_; uint8_t v___x_372_; 
v_support_296_ = lean_ctor_get(v_p_286_, 0);
v___x_297_ = 0;
v___x_298_ = lean_unsigned_to_nat(4u);
v_offset_299_ = lean_nat_mul(v_i_287_, v___x_298_);
v___x_370_ = lean_nat_add(v_offset_299_, v___x_298_);
v___x_371_ = lean_byte_array_size(v_support_296_);
v___x_372_ = lean_nat_dec_le(v___x_370_, v___x_371_);
if (v___x_372_ == 0)
{
lean_dec(v___x_370_);
v___y_339_ = v___x_372_;
goto v___jp_338_;
}
else
{
size_t v___x_373_; lean_object* v___x_374_; uint8_t v___x_375_; 
v___x_373_ = lean_usize_of_nat(v___x_370_);
v___x_374_ = lean_usize_to_nat(v___x_373_);
v___x_375_ = lean_nat_dec_eq(v___x_374_, v___x_370_);
lean_dec(v___x_370_);
lean_dec(v___x_374_);
v___y_339_ = v___x_375_;
goto v___jp_338_;
}
v___jp_288_:
{
uint64_t v___x_291_; uint64_t v___x_292_; uint64_t v___x_293_; uint64_t v___x_294_; lean_object* v___x_295_; 
v___x_291_ = lean_uint8_to_uint64(v___y_290_);
v___x_292_ = 24ULL;
v___x_293_ = lean_uint64_shift_left(v___x_291_, v___x_292_);
v___x_294_ = lean_uint64_lor(v___y_289_, v___x_293_);
v___x_295_ = lean_uint64_to_nat(v___x_294_);
return v___x_295_;
}
v___jp_300_:
{
uint64_t v___x_303_; uint64_t v___x_304_; uint64_t v___x_305_; uint64_t v___x_306_; lean_object* v___x_307_; lean_object* v___x_308_; uint8_t v___x_309_; 
v___x_303_ = lean_uint8_to_uint64(v___y_302_);
v___x_304_ = 16ULL;
v___x_305_ = lean_uint64_shift_left(v___x_303_, v___x_304_);
v___x_306_ = lean_uint64_lor(v___y_301_, v___x_305_);
v___x_307_ = lean_unsigned_to_nat(3u);
v___x_308_ = lean_nat_add(v_offset_299_, v___x_307_);
lean_dec(v_offset_299_);
v___x_309_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_support_296_, v___x_308_);
if (v___x_309_ == 0)
{
lean_object* v___x_310_; lean_object* v___x_311_; uint8_t v___x_312_; 
lean_dec(v___x_308_);
v___x_310_ = lean_box(v___x_297_);
v___x_311_ = l_outOfBounds___redArg(v___x_310_);
lean_dec(v___x_310_);
v___x_312_ = lean_unbox(v___x_311_);
lean_dec(v___x_311_);
v___y_289_ = v___x_306_;
v___y_290_ = v___x_312_;
goto v___jp_288_;
}
else
{
uint8_t v___x_313_; 
v___x_313_ = lean_byte_array_fget(v_support_296_, v___x_308_);
lean_dec(v___x_308_);
v___y_289_ = v___x_306_;
v___y_290_ = v___x_313_;
goto v___jp_288_;
}
}
v___jp_314_:
{
uint64_t v___x_317_; uint64_t v___x_318_; uint64_t v___x_319_; uint64_t v___x_320_; lean_object* v___x_321_; lean_object* v___x_322_; uint8_t v___x_323_; 
v___x_317_ = lean_uint8_to_uint64(v___y_316_);
v___x_318_ = 8ULL;
v___x_319_ = lean_uint64_shift_left(v___x_317_, v___x_318_);
v___x_320_ = lean_uint64_lor(v___y_315_, v___x_319_);
v___x_321_ = lean_unsigned_to_nat(2u);
v___x_322_ = lean_nat_add(v_offset_299_, v___x_321_);
v___x_323_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_support_296_, v___x_322_);
if (v___x_323_ == 0)
{
lean_object* v___x_324_; lean_object* v___x_325_; uint8_t v___x_326_; 
lean_dec(v___x_322_);
v___x_324_ = lean_box(v___x_297_);
v___x_325_ = l_outOfBounds___redArg(v___x_324_);
lean_dec(v___x_324_);
v___x_326_ = lean_unbox(v___x_325_);
lean_dec(v___x_325_);
v___y_301_ = v___x_320_;
v___y_302_ = v___x_326_;
goto v___jp_300_;
}
else
{
uint8_t v___x_327_; 
v___x_327_ = lean_byte_array_fget(v_support_296_, v___x_322_);
lean_dec(v___x_322_);
v___y_301_ = v___x_320_;
v___y_302_ = v___x_327_;
goto v___jp_300_;
}
}
v___jp_328_:
{
uint64_t v_a_330_; lean_object* v___x_331_; lean_object* v___x_332_; uint8_t v___x_333_; 
v_a_330_ = lean_uint8_to_uint64(v___y_329_);
v___x_331_ = lean_unsigned_to_nat(1u);
v___x_332_ = lean_nat_add(v_offset_299_, v___x_331_);
v___x_333_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_support_296_, v___x_332_);
if (v___x_333_ == 0)
{
lean_object* v___x_334_; lean_object* v___x_335_; uint8_t v___x_336_; 
lean_dec(v___x_332_);
v___x_334_ = lean_box(v___x_297_);
v___x_335_ = l_outOfBounds___redArg(v___x_334_);
lean_dec(v___x_334_);
v___x_336_ = lean_unbox(v___x_335_);
lean_dec(v___x_335_);
v___y_315_ = v_a_330_;
v___y_316_ = v___x_336_;
goto v___jp_314_;
}
else
{
uint8_t v___x_337_; 
v___x_337_ = lean_byte_array_fget(v_support_296_, v___x_332_);
lean_dec(v___x_332_);
v___y_315_ = v_a_330_;
v___y_316_ = v___x_337_;
goto v___jp_314_;
}
}
v___jp_338_:
{
if (v___y_339_ == 0)
{
uint8_t v___x_340_; 
v___x_340_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_support_296_, v_offset_299_);
if (v___x_340_ == 0)
{
lean_object* v___x_341_; lean_object* v___x_342_; uint8_t v___x_343_; 
v___x_341_ = lean_box(v___x_297_);
v___x_342_ = l_outOfBounds___redArg(v___x_341_);
lean_dec(v___x_341_);
v___x_343_ = lean_unbox(v___x_342_);
lean_dec(v___x_342_);
v___y_329_ = v___x_343_;
goto v___jp_328_;
}
else
{
uint8_t v___x_344_; 
v___x_344_ = lean_byte_array_fget(v_support_296_, v_offset_299_);
v___y_329_ = v___x_344_;
goto v___jp_328_;
}
}
else
{
size_t v_pos_345_; uint8_t v___x_346_; uint64_t v_a_347_; size_t v___x_348_; size_t v___x_349_; uint8_t v___x_350_; uint64_t v___x_351_; uint64_t v___x_352_; uint64_t v___x_353_; uint64_t v___x_354_; size_t v___x_355_; size_t v___x_356_; uint8_t v___x_357_; uint64_t v___x_358_; uint64_t v___x_359_; uint64_t v___x_360_; uint64_t v___x_361_; size_t v___x_362_; size_t v___x_363_; uint8_t v___x_364_; uint64_t v___x_365_; uint64_t v___x_366_; uint64_t v___x_367_; uint64_t v___x_368_; lean_object* v___x_369_; 
v_pos_345_ = lean_usize_of_nat(v_offset_299_);
lean_dec(v_offset_299_);
v___x_346_ = lean_byte_array_uget(v_support_296_, v_pos_345_);
v_a_347_ = lean_uint8_to_uint64(v___x_346_);
v___x_348_ = ((size_t)1ULL);
v___x_349_ = lean_usize_add(v_pos_345_, v___x_348_);
v___x_350_ = lean_byte_array_uget(v_support_296_, v___x_349_);
v___x_351_ = lean_uint8_to_uint64(v___x_350_);
v___x_352_ = 8ULL;
v___x_353_ = lean_uint64_shift_left(v___x_351_, v___x_352_);
v___x_354_ = lean_uint64_lor(v_a_347_, v___x_353_);
v___x_355_ = ((size_t)2ULL);
v___x_356_ = lean_usize_add(v_pos_345_, v___x_355_);
v___x_357_ = lean_byte_array_uget(v_support_296_, v___x_356_);
v___x_358_ = lean_uint8_to_uint64(v___x_357_);
v___x_359_ = 16ULL;
v___x_360_ = lean_uint64_shift_left(v___x_358_, v___x_359_);
v___x_361_ = lean_uint64_lor(v___x_354_, v___x_360_);
v___x_362_ = ((size_t)3ULL);
v___x_363_ = lean_usize_add(v_pos_345_, v___x_362_);
v___x_364_ = lean_byte_array_uget(v_support_296_, v___x_363_);
v___x_365_ = lean_uint8_to_uint64(v___x_364_);
v___x_366_ = 24ULL;
v___x_367_ = lean_uint64_shift_left(v___x_365_, v___x_366_);
v___x_368_ = lean_uint64_lor(v___x_361_, v___x_367_);
v___x_369_ = lean_uint64_to_nat(v___x_368_);
return v___x_369_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monomial___boxed(lean_object* v_p_376_, lean_object* v_i_377_){
_start:
{
lean_object* v_res_378_; 
v_res_378_ = lp_Hex_Hex_Groebner_Polynomial_monomial(v_p_376_, v_i_377_);
lean_dec(v_i_377_);
lean_dec_ref(v_p_376_);
return v_res_378_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_Polynomial_coefficient(lean_object* v_p_379_, uint64_t v_field_380_, lean_object* v_i_381_){
_start:
{
uint64_t v___y_383_; uint8_t v___y_384_; uint64_t v___y_390_; uint8_t v___y_391_; lean_object* v_coefficients_396_; uint8_t v___x_397_; uint8_t v___x_398_; lean_object* v___y_400_; uint64_t v___y_401_; uint8_t v___y_402_; lean_object* v___y_415_; uint64_t v___y_416_; uint8_t v___y_417_; lean_object* v___y_430_; uint8_t v___y_431_; lean_object* v___y_448_; uint8_t v___y_449_; lean_object* v___y_487_; 
v_coefficients_396_ = lean_ctor_get(v_p_379_, 1);
v___x_397_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_380_);
v___x_398_ = 0;
switch(v___x_397_)
{
case 0:
{
lean_object* v___x_495_; 
v___x_495_ = lean_unsigned_to_nat(1u);
v___y_487_ = v___x_495_;
goto v___jp_486_;
}
case 1:
{
lean_object* v___x_496_; 
v___x_496_ = lean_unsigned_to_nat(2u);
v___y_487_ = v___x_496_;
goto v___jp_486_;
}
default: 
{
lean_object* v___x_497_; 
v___x_497_ = lean_unsigned_to_nat(4u);
v___y_487_ = v___x_497_;
goto v___jp_486_;
}
}
v___jp_382_:
{
uint64_t v___x_385_; uint64_t v___x_386_; uint64_t v___x_387_; uint64_t v___x_388_; 
v___x_385_ = lean_uint8_to_uint64(v___y_384_);
v___x_386_ = 24ULL;
v___x_387_ = lean_uint64_shift_left(v___x_385_, v___x_386_);
v___x_388_ = lean_uint64_lor(v___y_383_, v___x_387_);
return v___x_388_;
}
v___jp_389_:
{
uint64_t v___x_392_; uint64_t v___x_393_; uint64_t v___x_394_; uint64_t v___x_395_; 
v___x_392_ = lean_uint8_to_uint64(v___y_391_);
v___x_393_ = 8ULL;
v___x_394_ = lean_uint64_shift_left(v___x_392_, v___x_393_);
v___x_395_ = lean_uint64_lor(v___y_390_, v___x_394_);
return v___x_395_;
}
v___jp_399_:
{
uint64_t v___x_403_; uint64_t v___x_404_; uint64_t v___x_405_; uint64_t v___x_406_; lean_object* v___x_407_; lean_object* v___x_408_; uint8_t v___x_409_; 
v___x_403_ = lean_uint8_to_uint64(v___y_402_);
v___x_404_ = 16ULL;
v___x_405_ = lean_uint64_shift_left(v___x_403_, v___x_404_);
v___x_406_ = lean_uint64_lor(v___y_401_, v___x_405_);
v___x_407_ = lean_unsigned_to_nat(3u);
v___x_408_ = lean_nat_add(v___y_400_, v___x_407_);
lean_dec(v___y_400_);
v___x_409_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_coefficients_396_, v___x_408_);
if (v___x_409_ == 0)
{
lean_object* v___x_410_; lean_object* v___x_411_; uint8_t v___x_412_; 
lean_dec(v___x_408_);
v___x_410_ = lean_box(v___x_398_);
v___x_411_ = l_outOfBounds___redArg(v___x_410_);
lean_dec(v___x_410_);
v___x_412_ = lean_unbox(v___x_411_);
lean_dec(v___x_411_);
v___y_383_ = v___x_406_;
v___y_384_ = v___x_412_;
goto v___jp_382_;
}
else
{
uint8_t v___x_413_; 
v___x_413_ = lean_byte_array_fget(v_coefficients_396_, v___x_408_);
lean_dec(v___x_408_);
v___y_383_ = v___x_406_;
v___y_384_ = v___x_413_;
goto v___jp_382_;
}
}
v___jp_414_:
{
uint64_t v___x_418_; uint64_t v___x_419_; uint64_t v___x_420_; uint64_t v___x_421_; lean_object* v___x_422_; lean_object* v___x_423_; uint8_t v___x_424_; 
v___x_418_ = lean_uint8_to_uint64(v___y_417_);
v___x_419_ = 8ULL;
v___x_420_ = lean_uint64_shift_left(v___x_418_, v___x_419_);
v___x_421_ = lean_uint64_lor(v___y_416_, v___x_420_);
v___x_422_ = lean_unsigned_to_nat(2u);
v___x_423_ = lean_nat_add(v___y_415_, v___x_422_);
v___x_424_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_coefficients_396_, v___x_423_);
if (v___x_424_ == 0)
{
lean_object* v___x_425_; lean_object* v___x_426_; uint8_t v___x_427_; 
lean_dec(v___x_423_);
v___x_425_ = lean_box(v___x_398_);
v___x_426_ = l_outOfBounds___redArg(v___x_425_);
lean_dec(v___x_425_);
v___x_427_ = lean_unbox(v___x_426_);
lean_dec(v___x_426_);
v___y_400_ = v___y_415_;
v___y_401_ = v___x_421_;
v___y_402_ = v___x_427_;
goto v___jp_399_;
}
else
{
uint8_t v___x_428_; 
v___x_428_ = lean_byte_array_fget(v_coefficients_396_, v___x_423_);
lean_dec(v___x_423_);
v___y_400_ = v___y_415_;
v___y_401_ = v___x_421_;
v___y_402_ = v___x_428_;
goto v___jp_399_;
}
}
v___jp_429_:
{
uint64_t v_a_432_; 
v_a_432_ = lean_uint8_to_uint64(v___y_431_);
switch(v___x_397_)
{
case 0:
{
lean_dec(v___y_430_);
return v_a_432_;
}
case 1:
{
lean_object* v___x_433_; lean_object* v___x_434_; uint8_t v___x_435_; 
v___x_433_ = lean_unsigned_to_nat(1u);
v___x_434_ = lean_nat_add(v___y_430_, v___x_433_);
lean_dec(v___y_430_);
v___x_435_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_coefficients_396_, v___x_434_);
if (v___x_435_ == 0)
{
lean_object* v___x_436_; lean_object* v___x_437_; uint8_t v___x_438_; 
lean_dec(v___x_434_);
v___x_436_ = lean_box(v___x_398_);
v___x_437_ = l_outOfBounds___redArg(v___x_436_);
lean_dec(v___x_436_);
v___x_438_ = lean_unbox(v___x_437_);
lean_dec(v___x_437_);
v___y_390_ = v_a_432_;
v___y_391_ = v___x_438_;
goto v___jp_389_;
}
else
{
uint8_t v___x_439_; 
v___x_439_ = lean_byte_array_fget(v_coefficients_396_, v___x_434_);
lean_dec(v___x_434_);
v___y_390_ = v_a_432_;
v___y_391_ = v___x_439_;
goto v___jp_389_;
}
}
default: 
{
lean_object* v___x_440_; lean_object* v___x_441_; uint8_t v___x_442_; 
v___x_440_ = lean_unsigned_to_nat(1u);
v___x_441_ = lean_nat_add(v___y_430_, v___x_440_);
v___x_442_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_coefficients_396_, v___x_441_);
if (v___x_442_ == 0)
{
lean_object* v___x_443_; lean_object* v___x_444_; uint8_t v___x_445_; 
lean_dec(v___x_441_);
v___x_443_ = lean_box(v___x_398_);
v___x_444_ = l_outOfBounds___redArg(v___x_443_);
lean_dec(v___x_443_);
v___x_445_ = lean_unbox(v___x_444_);
lean_dec(v___x_444_);
v___y_415_ = v___y_430_;
v___y_416_ = v_a_432_;
v___y_417_ = v___x_445_;
goto v___jp_414_;
}
else
{
uint8_t v___x_446_; 
v___x_446_ = lean_byte_array_fget(v_coefficients_396_, v___x_441_);
lean_dec(v___x_441_);
v___y_415_ = v___y_430_;
v___y_416_ = v_a_432_;
v___y_417_ = v___x_446_;
goto v___jp_414_;
}
}
}
}
v___jp_447_:
{
if (v___y_449_ == 0)
{
uint8_t v___x_450_; 
v___x_450_ = lp_Hex_Hex_Groebner_Polynomial_monomial___lam__0(v_coefficients_396_, v___y_448_);
if (v___x_450_ == 0)
{
lean_object* v___x_451_; lean_object* v___x_452_; uint8_t v___x_453_; 
v___x_451_ = lean_box(v___x_398_);
v___x_452_ = l_outOfBounds___redArg(v___x_451_);
lean_dec(v___x_451_);
v___x_453_ = lean_unbox(v___x_452_);
lean_dec(v___x_452_);
v___y_430_ = v___y_448_;
v___y_431_ = v___x_453_;
goto v___jp_429_;
}
else
{
uint8_t v___x_454_; 
v___x_454_ = lean_byte_array_fget(v_coefficients_396_, v___y_448_);
v___y_430_ = v___y_448_;
v___y_431_ = v___x_454_;
goto v___jp_429_;
}
}
else
{
size_t v_pos_455_; uint8_t v___x_456_; uint64_t v_a_457_; 
v_pos_455_ = lean_usize_of_nat(v___y_448_);
lean_dec(v___y_448_);
v___x_456_ = lean_byte_array_uget(v_coefficients_396_, v_pos_455_);
v_a_457_ = lean_uint8_to_uint64(v___x_456_);
switch(v___x_397_)
{
case 0:
{
return v_a_457_;
}
case 1:
{
size_t v___x_458_; size_t v___x_459_; uint8_t v___x_460_; uint64_t v___x_461_; uint64_t v___x_462_; uint64_t v___x_463_; uint64_t v___x_464_; 
v___x_458_ = ((size_t)1ULL);
v___x_459_ = lean_usize_add(v_pos_455_, v___x_458_);
v___x_460_ = lean_byte_array_uget(v_coefficients_396_, v___x_459_);
v___x_461_ = lean_uint8_to_uint64(v___x_460_);
v___x_462_ = 8ULL;
v___x_463_ = lean_uint64_shift_left(v___x_461_, v___x_462_);
v___x_464_ = lean_uint64_lor(v_a_457_, v___x_463_);
return v___x_464_;
}
default: 
{
size_t v___x_465_; size_t v___x_466_; uint8_t v___x_467_; uint64_t v___x_468_; uint64_t v___x_469_; uint64_t v___x_470_; uint64_t v___x_471_; size_t v___x_472_; size_t v___x_473_; uint8_t v___x_474_; uint64_t v___x_475_; uint64_t v___x_476_; uint64_t v___x_477_; uint64_t v___x_478_; size_t v___x_479_; size_t v___x_480_; uint8_t v___x_481_; uint64_t v___x_482_; uint64_t v___x_483_; uint64_t v___x_484_; uint64_t v___x_485_; 
v___x_465_ = ((size_t)1ULL);
v___x_466_ = lean_usize_add(v_pos_455_, v___x_465_);
v___x_467_ = lean_byte_array_uget(v_coefficients_396_, v___x_466_);
v___x_468_ = lean_uint8_to_uint64(v___x_467_);
v___x_469_ = 8ULL;
v___x_470_ = lean_uint64_shift_left(v___x_468_, v___x_469_);
v___x_471_ = lean_uint64_lor(v_a_457_, v___x_470_);
v___x_472_ = ((size_t)2ULL);
v___x_473_ = lean_usize_add(v_pos_455_, v___x_472_);
v___x_474_ = lean_byte_array_uget(v_coefficients_396_, v___x_473_);
v___x_475_ = lean_uint8_to_uint64(v___x_474_);
v___x_476_ = 16ULL;
v___x_477_ = lean_uint64_shift_left(v___x_475_, v___x_476_);
v___x_478_ = lean_uint64_lor(v___x_471_, v___x_477_);
v___x_479_ = ((size_t)3ULL);
v___x_480_ = lean_usize_add(v_pos_455_, v___x_479_);
v___x_481_ = lean_byte_array_uget(v_coefficients_396_, v___x_480_);
v___x_482_ = lean_uint8_to_uint64(v___x_481_);
v___x_483_ = 24ULL;
v___x_484_ = lean_uint64_shift_left(v___x_482_, v___x_483_);
v___x_485_ = lean_uint64_lor(v___x_478_, v___x_484_);
return v___x_485_;
}
}
}
}
v___jp_486_:
{
lean_object* v_offset_488_; lean_object* v___x_489_; lean_object* v___x_490_; uint8_t v___x_491_; 
v_offset_488_ = lean_nat_mul(v_i_381_, v___y_487_);
v___x_489_ = lean_nat_add(v_offset_488_, v___y_487_);
v___x_490_ = lean_byte_array_size(v_coefficients_396_);
v___x_491_ = lean_nat_dec_le(v___x_489_, v___x_490_);
if (v___x_491_ == 0)
{
lean_dec(v___x_489_);
v___y_448_ = v_offset_488_;
v___y_449_ = v___x_491_;
goto v___jp_447_;
}
else
{
size_t v___x_492_; lean_object* v___x_493_; uint8_t v___x_494_; 
v___x_492_ = lean_usize_of_nat(v___x_489_);
v___x_493_ = lean_usize_to_nat(v___x_492_);
v___x_494_ = lean_nat_dec_eq(v___x_493_, v___x_489_);
lean_dec(v___x_489_);
lean_dec(v___x_493_);
v___y_448_ = v_offset_488_;
v___y_449_ = v___x_494_;
goto v___jp_447_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_coefficient___boxed(lean_object* v_p_498_, lean_object* v_field_499_, lean_object* v_i_500_){
_start:
{
uint64_t v_field_boxed_501_; uint64_t v_res_502_; lean_object* v_r_503_; 
v_field_boxed_501_ = lean_unbox_uint64(v_field_499_);
lean_dec_ref(v_field_499_);
v_res_502_ = lp_Hex_Hex_Groebner_Polynomial_coefficient(v_p_498_, v_field_boxed_501_, v_i_500_);
lean_dec(v_i_500_);
lean_dec_ref(v_p_498_);
v_r_503_ = lean_box_uint64(v_res_502_);
return v_r_503_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorIdx(uint8_t v_x_504_){
_start:
{
switch(v_x_504_)
{
case 0:
{
lean_object* v___x_505_; 
v___x_505_ = lean_unsigned_to_nat(0u);
return v___x_505_;
}
case 1:
{
lean_object* v___x_506_; 
v___x_506_ = lean_unsigned_to_nat(1u);
return v___x_506_;
}
case 2:
{
lean_object* v___x_507_; 
v___x_507_ = lean_unsigned_to_nat(2u);
return v___x_507_;
}
case 3:
{
lean_object* v___x_508_; 
v___x_508_ = lean_unsigned_to_nat(3u);
return v___x_508_;
}
case 4:
{
lean_object* v___x_509_; 
v___x_509_ = lean_unsigned_to_nat(4u);
return v___x_509_;
}
case 5:
{
lean_object* v___x_510_; 
v___x_510_ = lean_unsigned_to_nat(5u);
return v___x_510_;
}
case 6:
{
lean_object* v___x_511_; 
v___x_511_ = lean_unsigned_to_nat(6u);
return v___x_511_;
}
case 7:
{
lean_object* v___x_512_; 
v___x_512_ = lean_unsigned_to_nat(7u);
return v___x_512_;
}
default: 
{
lean_object* v___x_513_; 
v___x_513_ = lean_unsigned_to_nat(8u);
return v___x_513_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorIdx___boxed(lean_object* v_x_514_){
_start:
{
uint8_t v_x_boxed_515_; lean_object* v_res_516_; 
v_x_boxed_515_ = lean_unbox(v_x_514_);
v_res_516_ = lp_Hex_Hex_Groebner_F4Resource_ctorIdx(v_x_boxed_515_);
return v_res_516_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorElim___redArg(lean_object* v_k_517_){
_start:
{
lean_inc(v_k_517_);
return v_k_517_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorElim___redArg___boxed(lean_object* v_k_518_){
_start:
{
lean_object* v_res_519_; 
v_res_519_ = lp_Hex_Hex_Groebner_F4Resource_ctorElim___redArg(v_k_518_);
lean_dec(v_k_518_);
return v_res_519_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorElim(lean_object* v_motive_520_, lean_object* v_ctorIdx_521_, uint8_t v_t_522_, lean_object* v_h_523_, lean_object* v_k_524_){
_start:
{
lean_inc(v_k_524_);
return v_k_524_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_ctorElim___boxed(lean_object* v_motive_525_, lean_object* v_ctorIdx_526_, lean_object* v_t_527_, lean_object* v_h_528_, lean_object* v_k_529_){
_start:
{
uint8_t v_t_boxed_530_; lean_object* v_res_531_; 
v_t_boxed_530_ = lean_unbox(v_t_527_);
v_res_531_ = lp_Hex_Hex_Groebner_F4Resource_ctorElim(v_motive_525_, v_ctorIdx_526_, v_t_boxed_530_, v_h_528_, v_k_529_);
lean_dec(v_k_529_);
lean_dec(v_ctorIdx_526_);
return v_res_531_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_work_elim___redArg(lean_object* v_work_532_){
_start:
{
lean_inc(v_work_532_);
return v_work_532_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_work_elim___redArg___boxed(lean_object* v_work_533_){
_start:
{
lean_object* v_res_534_; 
v_res_534_ = lp_Hex_Hex_Groebner_F4Resource_work_elim___redArg(v_work_533_);
lean_dec(v_work_533_);
return v_res_534_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_work_elim(lean_object* v_motive_535_, uint8_t v_t_536_, lean_object* v_h_537_, lean_object* v_work_538_){
_start:
{
lean_inc(v_work_538_);
return v_work_538_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_work_elim___boxed(lean_object* v_motive_539_, lean_object* v_t_540_, lean_object* v_h_541_, lean_object* v_work_542_){
_start:
{
uint8_t v_t_boxed_543_; lean_object* v_res_544_; 
v_t_boxed_543_ = lean_unbox(v_t_540_);
v_res_544_ = lp_Hex_Hex_Groebner_F4Resource_work_elim(v_motive_539_, v_t_boxed_543_, v_h_541_, v_work_542_);
lean_dec(v_work_542_);
return v_res_544_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim___redArg(lean_object* v_packedBytes_545_){
_start:
{
lean_inc(v_packedBytes_545_);
return v_packedBytes_545_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim___redArg___boxed(lean_object* v_packedBytes_546_){
_start:
{
lean_object* v_res_547_; 
v_res_547_ = lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim___redArg(v_packedBytes_546_);
lean_dec(v_packedBytes_546_);
return v_res_547_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim(lean_object* v_motive_548_, uint8_t v_t_549_, lean_object* v_h_550_, lean_object* v_packedBytes_551_){
_start:
{
lean_inc(v_packedBytes_551_);
return v_packedBytes_551_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim___boxed(lean_object* v_motive_552_, lean_object* v_t_553_, lean_object* v_h_554_, lean_object* v_packedBytes_555_){
_start:
{
uint8_t v_t_boxed_556_; lean_object* v_res_557_; 
v_t_boxed_556_ = lean_unbox(v_t_553_);
v_res_557_ = lp_Hex_Hex_Groebner_F4Resource_packedBytes_elim(v_motive_552_, v_t_boxed_556_, v_h_554_, v_packedBytes_555_);
lean_dec(v_packedBytes_555_);
return v_res_557_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_monomials_elim___redArg(lean_object* v_monomials_558_){
_start:
{
lean_inc(v_monomials_558_);
return v_monomials_558_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_monomials_elim___redArg___boxed(lean_object* v_monomials_559_){
_start:
{
lean_object* v_res_560_; 
v_res_560_ = lp_Hex_Hex_Groebner_F4Resource_monomials_elim___redArg(v_monomials_559_);
lean_dec(v_monomials_559_);
return v_res_560_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_monomials_elim(lean_object* v_motive_561_, uint8_t v_t_562_, lean_object* v_h_563_, lean_object* v_monomials_564_){
_start:
{
lean_inc(v_monomials_564_);
return v_monomials_564_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_monomials_elim___boxed(lean_object* v_motive_565_, lean_object* v_t_566_, lean_object* v_h_567_, lean_object* v_monomials_568_){
_start:
{
uint8_t v_t_boxed_569_; lean_object* v_res_570_; 
v_t_boxed_569_ = lean_unbox(v_t_566_);
v_res_570_ = lp_Hex_Hex_Groebner_F4Resource_monomials_elim(v_motive_565_, v_t_boxed_569_, v_h_567_, v_monomials_568_);
lean_dec(v_monomials_568_);
return v_res_570_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_pairs_elim___redArg(lean_object* v_pairs_571_){
_start:
{
lean_inc(v_pairs_571_);
return v_pairs_571_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_pairs_elim___redArg___boxed(lean_object* v_pairs_572_){
_start:
{
lean_object* v_res_573_; 
v_res_573_ = lp_Hex_Hex_Groebner_F4Resource_pairs_elim___redArg(v_pairs_572_);
lean_dec(v_pairs_572_);
return v_res_573_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_pairs_elim(lean_object* v_motive_574_, uint8_t v_t_575_, lean_object* v_h_576_, lean_object* v_pairs_577_){
_start:
{
lean_inc(v_pairs_577_);
return v_pairs_577_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_pairs_elim___boxed(lean_object* v_motive_578_, lean_object* v_t_579_, lean_object* v_h_580_, lean_object* v_pairs_581_){
_start:
{
uint8_t v_t_boxed_582_; lean_object* v_res_583_; 
v_t_boxed_582_ = lean_unbox(v_t_579_);
v_res_583_ = lp_Hex_Hex_Groebner_F4Resource_pairs_elim(v_motive_578_, v_t_boxed_582_, v_h_580_, v_pairs_581_);
lean_dec(v_pairs_581_);
return v_res_583_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_rounds_elim___redArg(lean_object* v_rounds_584_){
_start:
{
lean_inc(v_rounds_584_);
return v_rounds_584_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_rounds_elim___redArg___boxed(lean_object* v_rounds_585_){
_start:
{
lean_object* v_res_586_; 
v_res_586_ = lp_Hex_Hex_Groebner_F4Resource_rounds_elim___redArg(v_rounds_585_);
lean_dec(v_rounds_585_);
return v_res_586_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_rounds_elim(lean_object* v_motive_587_, uint8_t v_t_588_, lean_object* v_h_589_, lean_object* v_rounds_590_){
_start:
{
lean_inc(v_rounds_590_);
return v_rounds_590_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_rounds_elim___boxed(lean_object* v_motive_591_, lean_object* v_t_592_, lean_object* v_h_593_, lean_object* v_rounds_594_){
_start:
{
uint8_t v_t_boxed_595_; lean_object* v_res_596_; 
v_t_boxed_595_ = lean_unbox(v_t_592_);
v_res_596_ = lp_Hex_Hex_Groebner_F4Resource_rounds_elim(v_motive_591_, v_t_boxed_595_, v_h_593_, v_rounds_594_);
lean_dec(v_rounds_594_);
return v_res_596_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim___redArg(lean_object* v_matrixEntries_597_){
_start:
{
lean_inc(v_matrixEntries_597_);
return v_matrixEntries_597_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim___redArg___boxed(lean_object* v_matrixEntries_598_){
_start:
{
lean_object* v_res_599_; 
v_res_599_ = lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim___redArg(v_matrixEntries_598_);
lean_dec(v_matrixEntries_598_);
return v_res_599_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim(lean_object* v_motive_600_, uint8_t v_t_601_, lean_object* v_h_602_, lean_object* v_matrixEntries_603_){
_start:
{
lean_inc(v_matrixEntries_603_);
return v_matrixEntries_603_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim___boxed(lean_object* v_motive_604_, lean_object* v_t_605_, lean_object* v_h_606_, lean_object* v_matrixEntries_607_){
_start:
{
uint8_t v_t_boxed_608_; lean_object* v_res_609_; 
v_t_boxed_608_ = lean_unbox(v_t_605_);
v_res_609_ = lp_Hex_Hex_Groebner_F4Resource_matrixEntries_elim(v_motive_604_, v_t_boxed_608_, v_h_606_, v_matrixEntries_607_);
lean_dec(v_matrixEntries_607_);
return v_res_609_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim___redArg(lean_object* v_matrixRows_610_){
_start:
{
lean_inc(v_matrixRows_610_);
return v_matrixRows_610_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim___redArg___boxed(lean_object* v_matrixRows_611_){
_start:
{
lean_object* v_res_612_; 
v_res_612_ = lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim___redArg(v_matrixRows_611_);
lean_dec(v_matrixRows_611_);
return v_res_612_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim(lean_object* v_motive_613_, uint8_t v_t_614_, lean_object* v_h_615_, lean_object* v_matrixRows_616_){
_start:
{
lean_inc(v_matrixRows_616_);
return v_matrixRows_616_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim___boxed(lean_object* v_motive_617_, lean_object* v_t_618_, lean_object* v_h_619_, lean_object* v_matrixRows_620_){
_start:
{
uint8_t v_t_boxed_621_; lean_object* v_res_622_; 
v_t_boxed_621_ = lean_unbox(v_t_618_);
v_res_622_ = lp_Hex_Hex_Groebner_F4Resource_matrixRows_elim(v_motive_617_, v_t_boxed_621_, v_h_619_, v_matrixRows_620_);
lean_dec(v_matrixRows_620_);
return v_res_622_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_basis_elim___redArg(lean_object* v_basis_623_){
_start:
{
lean_inc(v_basis_623_);
return v_basis_623_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_basis_elim___redArg___boxed(lean_object* v_basis_624_){
_start:
{
lean_object* v_res_625_; 
v_res_625_ = lp_Hex_Hex_Groebner_F4Resource_basis_elim___redArg(v_basis_624_);
lean_dec(v_basis_624_);
return v_res_625_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_basis_elim(lean_object* v_motive_626_, uint8_t v_t_627_, lean_object* v_h_628_, lean_object* v_basis_629_){
_start:
{
lean_inc(v_basis_629_);
return v_basis_629_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_basis_elim___boxed(lean_object* v_motive_630_, lean_object* v_t_631_, lean_object* v_h_632_, lean_object* v_basis_633_){
_start:
{
uint8_t v_t_boxed_634_; lean_object* v_res_635_; 
v_t_boxed_634_ = lean_unbox(v_t_631_);
v_res_635_ = lp_Hex_Hex_Groebner_F4Resource_basis_elim(v_motive_630_, v_t_boxed_634_, v_h_632_, v_basis_633_);
lean_dec(v_basis_633_);
return v_res_635_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_variables_elim___redArg(lean_object* v_variables_636_){
_start:
{
lean_inc(v_variables_636_);
return v_variables_636_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_variables_elim___redArg___boxed(lean_object* v_variables_637_){
_start:
{
lean_object* v_res_638_; 
v_res_638_ = lp_Hex_Hex_Groebner_F4Resource_variables_elim___redArg(v_variables_637_);
lean_dec(v_variables_637_);
return v_res_638_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_variables_elim(lean_object* v_motive_639_, uint8_t v_t_640_, lean_object* v_h_641_, lean_object* v_variables_642_){
_start:
{
lean_inc(v_variables_642_);
return v_variables_642_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_F4Resource_variables_elim___boxed(lean_object* v_motive_643_, lean_object* v_t_644_, lean_object* v_h_645_, lean_object* v_variables_646_){
_start:
{
uint8_t v_t_boxed_647_; lean_object* v_res_648_; 
v_t_boxed_647_ = lean_unbox(v_t_644_);
v_res_648_ = lp_Hex_Hex_Groebner_F4Resource_variables_elim(v_motive_643_, v_t_boxed_647_, v_h_645_, v_variables_646_);
lean_dec(v_variables_646_);
return v_res_648_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqF4Resource_beq(uint8_t v_x_649_, uint8_t v_y_650_){
_start:
{
lean_object* v___x_651_; lean_object* v___x_652_; uint8_t v___x_653_; 
v___x_651_ = lp_Hex_Hex_Groebner_F4Resource_ctorIdx(v_x_649_);
v___x_652_ = lp_Hex_Hex_Groebner_F4Resource_ctorIdx(v_y_650_);
v___x_653_ = lean_nat_dec_eq(v___x_651_, v___x_652_);
lean_dec(v___x_652_);
lean_dec(v___x_651_);
return v___x_653_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqF4Resource_beq___boxed(lean_object* v_x_654_, lean_object* v_y_655_){
_start:
{
uint8_t v_x_21__boxed_656_; uint8_t v_y_22__boxed_657_; uint8_t v_res_658_; lean_object* v_r_659_; 
v_x_21__boxed_656_ = lean_unbox(v_x_654_);
v_y_22__boxed_657_ = lean_unbox(v_y_655_);
v_res_658_ = lp_Hex_Hex_Groebner_instBEqF4Resource_beq(v_x_21__boxed_656_, v_y_22__boxed_657_);
v_r_659_ = lean_box(v_res_658_);
return v_r_659_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18(void){
_start:
{
lean_object* v___x_689_; lean_object* v___x_690_; 
v___x_689_ = lean_unsigned_to_nat(2u);
v___x_690_ = lean_nat_to_int(v___x_689_);
return v___x_690_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19(void){
_start:
{
lean_object* v___x_691_; lean_object* v___x_692_; 
v___x_691_ = lean_unsigned_to_nat(1u);
v___x_692_ = lean_nat_to_int(v___x_691_);
return v___x_692_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr(uint8_t v_x_693_, lean_object* v_prec_694_){
_start:
{
lean_object* v___y_696_; lean_object* v___y_703_; lean_object* v___y_710_; lean_object* v___y_717_; lean_object* v___y_724_; lean_object* v___y_731_; lean_object* v___y_738_; lean_object* v___y_745_; lean_object* v___y_752_; 
switch(v_x_693_)
{
case 0:
{
lean_object* v___x_758_; uint8_t v___x_759_; 
v___x_758_ = lean_unsigned_to_nat(1024u);
v___x_759_ = lean_nat_dec_le(v___x_758_, v_prec_694_);
if (v___x_759_ == 0)
{
lean_object* v___x_760_; 
v___x_760_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_696_ = v___x_760_;
goto v___jp_695_;
}
else
{
lean_object* v___x_761_; 
v___x_761_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_696_ = v___x_761_;
goto v___jp_695_;
}
}
case 1:
{
lean_object* v___x_762_; uint8_t v___x_763_; 
v___x_762_ = lean_unsigned_to_nat(1024u);
v___x_763_ = lean_nat_dec_le(v___x_762_, v_prec_694_);
if (v___x_763_ == 0)
{
lean_object* v___x_764_; 
v___x_764_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_703_ = v___x_764_;
goto v___jp_702_;
}
else
{
lean_object* v___x_765_; 
v___x_765_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_703_ = v___x_765_;
goto v___jp_702_;
}
}
case 2:
{
lean_object* v___x_766_; uint8_t v___x_767_; 
v___x_766_ = lean_unsigned_to_nat(1024u);
v___x_767_ = lean_nat_dec_le(v___x_766_, v_prec_694_);
if (v___x_767_ == 0)
{
lean_object* v___x_768_; 
v___x_768_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_710_ = v___x_768_;
goto v___jp_709_;
}
else
{
lean_object* v___x_769_; 
v___x_769_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_710_ = v___x_769_;
goto v___jp_709_;
}
}
case 3:
{
lean_object* v___x_770_; uint8_t v___x_771_; 
v___x_770_ = lean_unsigned_to_nat(1024u);
v___x_771_ = lean_nat_dec_le(v___x_770_, v_prec_694_);
if (v___x_771_ == 0)
{
lean_object* v___x_772_; 
v___x_772_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_717_ = v___x_772_;
goto v___jp_716_;
}
else
{
lean_object* v___x_773_; 
v___x_773_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_717_ = v___x_773_;
goto v___jp_716_;
}
}
case 4:
{
lean_object* v___x_774_; uint8_t v___x_775_; 
v___x_774_ = lean_unsigned_to_nat(1024u);
v___x_775_ = lean_nat_dec_le(v___x_774_, v_prec_694_);
if (v___x_775_ == 0)
{
lean_object* v___x_776_; 
v___x_776_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_724_ = v___x_776_;
goto v___jp_723_;
}
else
{
lean_object* v___x_777_; 
v___x_777_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_724_ = v___x_777_;
goto v___jp_723_;
}
}
case 5:
{
lean_object* v___x_778_; uint8_t v___x_779_; 
v___x_778_ = lean_unsigned_to_nat(1024u);
v___x_779_ = lean_nat_dec_le(v___x_778_, v_prec_694_);
if (v___x_779_ == 0)
{
lean_object* v___x_780_; 
v___x_780_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_731_ = v___x_780_;
goto v___jp_730_;
}
else
{
lean_object* v___x_781_; 
v___x_781_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_731_ = v___x_781_;
goto v___jp_730_;
}
}
case 6:
{
lean_object* v___x_782_; uint8_t v___x_783_; 
v___x_782_ = lean_unsigned_to_nat(1024u);
v___x_783_ = lean_nat_dec_le(v___x_782_, v_prec_694_);
if (v___x_783_ == 0)
{
lean_object* v___x_784_; 
v___x_784_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_738_ = v___x_784_;
goto v___jp_737_;
}
else
{
lean_object* v___x_785_; 
v___x_785_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_738_ = v___x_785_;
goto v___jp_737_;
}
}
case 7:
{
lean_object* v___x_786_; uint8_t v___x_787_; 
v___x_786_ = lean_unsigned_to_nat(1024u);
v___x_787_ = lean_nat_dec_le(v___x_786_, v_prec_694_);
if (v___x_787_ == 0)
{
lean_object* v___x_788_; 
v___x_788_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_745_ = v___x_788_;
goto v___jp_744_;
}
else
{
lean_object* v___x_789_; 
v___x_789_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_745_ = v___x_789_;
goto v___jp_744_;
}
}
default: 
{
lean_object* v___x_790_; uint8_t v___x_791_; 
v___x_790_ = lean_unsigned_to_nat(1024u);
v___x_791_ = lean_nat_dec_le(v___x_790_, v_prec_694_);
if (v___x_791_ == 0)
{
lean_object* v___x_792_; 
v___x_792_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_752_ = v___x_792_;
goto v___jp_751_;
}
else
{
lean_object* v___x_793_; 
v___x_793_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_752_ = v___x_793_;
goto v___jp_751_;
}
}
}
v___jp_695_:
{
lean_object* v___x_697_; lean_object* v___x_698_; uint8_t v___x_699_; lean_object* v___x_700_; lean_object* v___x_701_; 
v___x_697_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__1));
lean_inc(v___y_696_);
v___x_698_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_698_, 0, v___y_696_);
lean_ctor_set(v___x_698_, 1, v___x_697_);
v___x_699_ = 0;
v___x_700_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_700_, 0, v___x_698_);
lean_ctor_set_uint8(v___x_700_, sizeof(void*)*1, v___x_699_);
v___x_701_ = l_Repr_addAppParen(v___x_700_, v_prec_694_);
return v___x_701_;
}
v___jp_702_:
{
lean_object* v___x_704_; lean_object* v___x_705_; uint8_t v___x_706_; lean_object* v___x_707_; lean_object* v___x_708_; 
v___x_704_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__3));
lean_inc(v___y_703_);
v___x_705_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_705_, 0, v___y_703_);
lean_ctor_set(v___x_705_, 1, v___x_704_);
v___x_706_ = 0;
v___x_707_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_707_, 0, v___x_705_);
lean_ctor_set_uint8(v___x_707_, sizeof(void*)*1, v___x_706_);
v___x_708_ = l_Repr_addAppParen(v___x_707_, v_prec_694_);
return v___x_708_;
}
v___jp_709_:
{
lean_object* v___x_711_; lean_object* v___x_712_; uint8_t v___x_713_; lean_object* v___x_714_; lean_object* v___x_715_; 
v___x_711_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__5));
lean_inc(v___y_710_);
v___x_712_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_712_, 0, v___y_710_);
lean_ctor_set(v___x_712_, 1, v___x_711_);
v___x_713_ = 0;
v___x_714_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_714_, 0, v___x_712_);
lean_ctor_set_uint8(v___x_714_, sizeof(void*)*1, v___x_713_);
v___x_715_ = l_Repr_addAppParen(v___x_714_, v_prec_694_);
return v___x_715_;
}
v___jp_716_:
{
lean_object* v___x_718_; lean_object* v___x_719_; uint8_t v___x_720_; lean_object* v___x_721_; lean_object* v___x_722_; 
v___x_718_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__7));
lean_inc(v___y_717_);
v___x_719_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_719_, 0, v___y_717_);
lean_ctor_set(v___x_719_, 1, v___x_718_);
v___x_720_ = 0;
v___x_721_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_721_, 0, v___x_719_);
lean_ctor_set_uint8(v___x_721_, sizeof(void*)*1, v___x_720_);
v___x_722_ = l_Repr_addAppParen(v___x_721_, v_prec_694_);
return v___x_722_;
}
v___jp_723_:
{
lean_object* v___x_725_; lean_object* v___x_726_; uint8_t v___x_727_; lean_object* v___x_728_; lean_object* v___x_729_; 
v___x_725_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__9));
lean_inc(v___y_724_);
v___x_726_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_726_, 0, v___y_724_);
lean_ctor_set(v___x_726_, 1, v___x_725_);
v___x_727_ = 0;
v___x_728_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_728_, 0, v___x_726_);
lean_ctor_set_uint8(v___x_728_, sizeof(void*)*1, v___x_727_);
v___x_729_ = l_Repr_addAppParen(v___x_728_, v_prec_694_);
return v___x_729_;
}
v___jp_730_:
{
lean_object* v___x_732_; lean_object* v___x_733_; uint8_t v___x_734_; lean_object* v___x_735_; lean_object* v___x_736_; 
v___x_732_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__11));
lean_inc(v___y_731_);
v___x_733_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_733_, 0, v___y_731_);
lean_ctor_set(v___x_733_, 1, v___x_732_);
v___x_734_ = 0;
v___x_735_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_735_, 0, v___x_733_);
lean_ctor_set_uint8(v___x_735_, sizeof(void*)*1, v___x_734_);
v___x_736_ = l_Repr_addAppParen(v___x_735_, v_prec_694_);
return v___x_736_;
}
v___jp_737_:
{
lean_object* v___x_739_; lean_object* v___x_740_; uint8_t v___x_741_; lean_object* v___x_742_; lean_object* v___x_743_; 
v___x_739_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__13));
lean_inc(v___y_738_);
v___x_740_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_740_, 0, v___y_738_);
lean_ctor_set(v___x_740_, 1, v___x_739_);
v___x_741_ = 0;
v___x_742_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_742_, 0, v___x_740_);
lean_ctor_set_uint8(v___x_742_, sizeof(void*)*1, v___x_741_);
v___x_743_ = l_Repr_addAppParen(v___x_742_, v_prec_694_);
return v___x_743_;
}
v___jp_744_:
{
lean_object* v___x_746_; lean_object* v___x_747_; uint8_t v___x_748_; lean_object* v___x_749_; lean_object* v___x_750_; 
v___x_746_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__15));
lean_inc(v___y_745_);
v___x_747_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_747_, 0, v___y_745_);
lean_ctor_set(v___x_747_, 1, v___x_746_);
v___x_748_ = 0;
v___x_749_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_749_, 0, v___x_747_);
lean_ctor_set_uint8(v___x_749_, sizeof(void*)*1, v___x_748_);
v___x_750_ = l_Repr_addAppParen(v___x_749_, v_prec_694_);
return v___x_750_;
}
v___jp_751_:
{
lean_object* v___x_753_; lean_object* v___x_754_; uint8_t v___x_755_; lean_object* v___x_756_; lean_object* v___x_757_; 
v___x_753_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__17));
lean_inc(v___y_752_);
v___x_754_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_754_, 0, v___y_752_);
lean_ctor_set(v___x_754_, 1, v___x_753_);
v___x_755_ = 0;
v___x_756_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_756_, 0, v___x_754_);
lean_ctor_set_uint8(v___x_756_, sizeof(void*)*1, v___x_755_);
v___x_757_ = l_Repr_addAppParen(v___x_756_, v_prec_694_);
return v___x_757_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprF4Resource_repr___boxed(lean_object* v_x_794_, lean_object* v_prec_795_){
_start:
{
uint8_t v_x_495__boxed_796_; lean_object* v_res_797_; 
v_x_495__boxed_796_ = lean_unbox(v_x_794_);
v_res_797_ = lp_Hex_Hex_Groebner_instReprF4Resource_repr(v_x_495__boxed_796_, v_prec_795_);
lean_dec(v_prec_795_);
return v_res_797_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorIdx(lean_object* v_x_800_){
_start:
{
switch(lean_obj_tag(v_x_800_))
{
case 0:
{
lean_object* v___x_801_; 
v___x_801_ = lean_unsigned_to_nat(0u);
return v___x_801_;
}
case 1:
{
lean_object* v___x_802_; 
v___x_802_ = lean_unsigned_to_nat(1u);
return v___x_802_;
}
case 2:
{
lean_object* v___x_803_; 
v___x_803_ = lean_unsigned_to_nat(2u);
return v___x_803_;
}
case 3:
{
lean_object* v___x_804_; 
v___x_804_ = lean_unsigned_to_nat(3u);
return v___x_804_;
}
default: 
{
lean_object* v___x_805_; 
v___x_805_ = lean_unsigned_to_nat(4u);
return v___x_805_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorIdx___boxed(lean_object* v_x_806_){
_start:
{
lean_object* v_res_807_; 
v_res_807_ = lp_Hex_Hex_Groebner_ComputeError_ctorIdx(v_x_806_);
lean_dec_ref(v_x_806_);
return v_res_807_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(lean_object* v_t_808_, lean_object* v_k_809_){
_start:
{
switch(lean_obj_tag(v_t_808_))
{
case 2:
{
uint8_t v_error_810_; lean_object* v___x_811_; lean_object* v___x_812_; 
v_error_810_ = lean_ctor_get_uint8(v_t_808_, 0);
lean_dec_ref_known(v_t_808_, 0);
v___x_811_ = lean_box(v_error_810_);
v___x_812_ = lean_apply_1(v_k_809_, v___x_811_);
return v___x_812_;
}
case 3:
{
uint8_t v_resource_813_; lean_object* v___x_814_; lean_object* v___x_815_; 
v_resource_813_ = lean_ctor_get_uint8(v_t_808_, 0);
lean_dec_ref_known(v_t_808_, 0);
v___x_814_ = lean_box(v_resource_813_);
v___x_815_ = lean_apply_1(v_k_809_, v___x_814_);
return v___x_815_;
}
case 4:
{
lean_object* v_error_816_; lean_object* v___x_817_; 
v_error_816_ = lean_ctor_get(v_t_808_, 0);
lean_inc(v_error_816_);
lean_dec_ref_known(v_t_808_, 1);
v___x_817_ = lean_apply_1(v_k_809_, v_error_816_);
return v___x_817_;
}
default: 
{
lean_object* v_polynomial_818_; lean_object* v_term_819_; lean_object* v___x_820_; 
v_polynomial_818_ = lean_ctor_get(v_t_808_, 0);
lean_inc(v_polynomial_818_);
v_term_819_ = lean_ctor_get(v_t_808_, 1);
lean_inc(v_term_819_);
lean_dec_ref(v_t_808_);
v___x_820_ = lean_apply_2(v_k_809_, v_polynomial_818_, v_term_819_);
return v___x_820_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorElim(lean_object* v_motive_821_, lean_object* v_ctorIdx_822_, lean_object* v_t_823_, lean_object* v_h_824_, lean_object* v_k_825_){
_start:
{
lean_object* v___x_826_; 
v___x_826_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_823_, v_k_825_);
return v___x_826_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_ctorElim___boxed(lean_object* v_motive_827_, lean_object* v_ctorIdx_828_, lean_object* v_t_829_, lean_object* v_h_830_, lean_object* v_k_831_){
_start:
{
lean_object* v_res_832_; 
v_res_832_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim(v_motive_827_, v_ctorIdx_828_, v_t_829_, v_h_830_, v_k_831_);
lean_dec(v_ctorIdx_828_);
return v_res_832_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_arity_elim___redArg(lean_object* v_t_833_, lean_object* v_arity_834_){
_start:
{
lean_object* v___x_835_; 
v___x_835_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_833_, v_arity_834_);
return v___x_835_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_arity_elim(lean_object* v_motive_836_, lean_object* v_t_837_, lean_object* v_h_838_, lean_object* v_arity_839_){
_start:
{
lean_object* v___x_840_; 
v___x_840_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_837_, v_arity_839_);
return v___x_840_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_coefficient_elim___redArg(lean_object* v_t_841_, lean_object* v_coefficient_842_){
_start:
{
lean_object* v___x_843_; 
v___x_843_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_841_, v_coefficient_842_);
return v___x_843_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_coefficient_elim(lean_object* v_motive_844_, lean_object* v_t_845_, lean_object* v_h_846_, lean_object* v_coefficient_847_){
_start:
{
lean_object* v___x_848_; 
v___x_848_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_845_, v_coefficient_847_);
return v___x_848_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_representation_elim___redArg(lean_object* v_t_849_, lean_object* v_representation_850_){
_start:
{
lean_object* v___x_851_; 
v___x_851_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_849_, v_representation_850_);
return v___x_851_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_representation_elim(lean_object* v_motive_852_, lean_object* v_t_853_, lean_object* v_h_854_, lean_object* v_representation_855_){
_start:
{
lean_object* v___x_856_; 
v___x_856_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_853_, v_representation_855_);
return v___x_856_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_exhausted_elim___redArg(lean_object* v_t_857_, lean_object* v_exhausted_858_){
_start:
{
lean_object* v___x_859_; 
v___x_859_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_857_, v_exhausted_858_);
return v___x_859_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_exhausted_elim(lean_object* v_motive_860_, lean_object* v_t_861_, lean_object* v_h_862_, lean_object* v_exhausted_863_){
_start:
{
lean_object* v___x_864_; 
v___x_864_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_861_, v_exhausted_863_);
return v___x_864_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_matrix_elim___redArg(lean_object* v_t_865_, lean_object* v_matrix_866_){
_start:
{
lean_object* v___x_867_; 
v___x_867_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_865_, v_matrix_866_);
return v___x_867_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_ComputeError_matrix_elim(lean_object* v_motive_868_, lean_object* v_t_869_, lean_object* v_h_870_, lean_object* v_matrix_871_){
_start:
{
lean_object* v___x_872_; 
v___x_872_ = lp_Hex_Hex_Groebner_ComputeError_ctorElim___redArg(v_t_869_, v_matrix_871_);
return v___x_872_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqComputeError_beq(lean_object* v_x_873_, lean_object* v_x_874_){
_start:
{
lean_object* v_a_876_; lean_object* v_a_877_; lean_object* v_b_878_; lean_object* v_b_879_; 
switch(lean_obj_tag(v_x_873_))
{
case 0:
{
if (lean_obj_tag(v_x_874_) == 0)
{
lean_object* v_polynomial_882_; lean_object* v_term_883_; lean_object* v_polynomial_884_; lean_object* v_term_885_; 
v_polynomial_882_ = lean_ctor_get(v_x_873_, 0);
v_term_883_ = lean_ctor_get(v_x_873_, 1);
v_polynomial_884_ = lean_ctor_get(v_x_874_, 0);
v_term_885_ = lean_ctor_get(v_x_874_, 1);
v_a_876_ = v_polynomial_882_;
v_a_877_ = v_term_883_;
v_b_878_ = v_polynomial_884_;
v_b_879_ = v_term_885_;
goto v___jp_875_;
}
else
{
uint8_t v___x_886_; 
v___x_886_ = 0;
return v___x_886_;
}
}
case 1:
{
if (lean_obj_tag(v_x_874_) == 1)
{
lean_object* v_polynomial_887_; lean_object* v_term_888_; lean_object* v_polynomial_889_; lean_object* v_term_890_; 
v_polynomial_887_ = lean_ctor_get(v_x_873_, 0);
v_term_888_ = lean_ctor_get(v_x_873_, 1);
v_polynomial_889_ = lean_ctor_get(v_x_874_, 0);
v_term_890_ = lean_ctor_get(v_x_874_, 1);
v_a_876_ = v_polynomial_887_;
v_a_877_ = v_term_888_;
v_b_878_ = v_polynomial_889_;
v_b_879_ = v_term_890_;
goto v___jp_875_;
}
else
{
uint8_t v___x_891_; 
v___x_891_ = 0;
return v___x_891_;
}
}
case 2:
{
if (lean_obj_tag(v_x_874_) == 2)
{
uint8_t v_error_892_; uint8_t v_error_893_; uint8_t v___x_894_; 
v_error_892_ = lean_ctor_get_uint8(v_x_873_, 0);
v_error_893_ = lean_ctor_get_uint8(v_x_874_, 0);
v___x_894_ = lp_Hex_Hex_Groebner_instBEqMonomialError_beq(v_error_892_, v_error_893_);
return v___x_894_;
}
else
{
uint8_t v___x_895_; 
v___x_895_ = 0;
return v___x_895_;
}
}
case 3:
{
if (lean_obj_tag(v_x_874_) == 3)
{
uint8_t v_resource_896_; uint8_t v_resource_897_; uint8_t v___x_898_; 
v_resource_896_ = lean_ctor_get_uint8(v_x_873_, 0);
v_resource_897_ = lean_ctor_get_uint8(v_x_874_, 0);
v___x_898_ = lp_Hex_Hex_Groebner_instBEqF4Resource_beq(v_resource_896_, v_resource_897_);
return v___x_898_;
}
else
{
uint8_t v___x_899_; 
v___x_899_ = 0;
return v___x_899_;
}
}
default: 
{
if (lean_obj_tag(v_x_874_) == 4)
{
lean_object* v_error_900_; lean_object* v_error_901_; uint8_t v___x_902_; 
v_error_900_ = lean_ctor_get(v_x_873_, 0);
v_error_901_ = lean_ctor_get(v_x_874_, 0);
v___x_902_ = lp_Hex_Hex_Groebner_instBEqMatrixError_beq(v_error_900_, v_error_901_);
return v___x_902_;
}
else
{
uint8_t v___x_903_; 
v___x_903_ = 0;
return v___x_903_;
}
}
}
v___jp_875_:
{
uint8_t v___x_880_; 
v___x_880_ = lean_nat_dec_eq(v_a_876_, v_b_878_);
if (v___x_880_ == 0)
{
return v___x_880_;
}
else
{
uint8_t v___x_881_; 
v___x_881_ = lean_nat_dec_eq(v_a_877_, v_b_879_);
return v___x_881_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqComputeError_beq___boxed(lean_object* v_x_904_, lean_object* v_x_905_){
_start:
{
uint8_t v_res_906_; lean_object* v_r_907_; 
v_res_906_ = lp_Hex_Hex_Groebner_instBEqComputeError_beq(v_x_904_, v_x_905_);
lean_dec_ref(v_x_905_);
lean_dec_ref(v_x_904_);
v_r_907_ = lean_box(v_res_906_);
return v_r_907_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr(lean_object* v_x_940_, lean_object* v_prec_941_){
_start:
{
switch(lean_obj_tag(v_x_940_))
{
case 0:
{
lean_object* v_polynomial_942_; lean_object* v_term_943_; lean_object* v___x_945_; uint8_t v_isShared_946_; uint8_t v_isSharedCheck_968_; 
v_polynomial_942_ = lean_ctor_get(v_x_940_, 0);
v_term_943_ = lean_ctor_get(v_x_940_, 1);
v_isSharedCheck_968_ = !lean_is_exclusive(v_x_940_);
if (v_isSharedCheck_968_ == 0)
{
v___x_945_ = v_x_940_;
v_isShared_946_ = v_isSharedCheck_968_;
goto v_resetjp_944_;
}
else
{
lean_inc(v_term_943_);
lean_inc(v_polynomial_942_);
lean_dec(v_x_940_);
v___x_945_ = lean_box(0);
v_isShared_946_ = v_isSharedCheck_968_;
goto v_resetjp_944_;
}
v_resetjp_944_:
{
lean_object* v___y_948_; lean_object* v___x_964_; uint8_t v___x_965_; 
v___x_964_ = lean_unsigned_to_nat(1024u);
v___x_965_ = lean_nat_dec_le(v___x_964_, v_prec_941_);
if (v___x_965_ == 0)
{
lean_object* v___x_966_; 
v___x_966_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_948_ = v___x_966_;
goto v___jp_947_;
}
else
{
lean_object* v___x_967_; 
v___x_967_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_948_ = v___x_967_;
goto v___jp_947_;
}
v___jp_947_:
{
lean_object* v___x_949_; lean_object* v___x_950_; lean_object* v___x_951_; lean_object* v___x_952_; lean_object* v___x_954_; 
v___x_949_ = lean_box(1);
v___x_950_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__2));
v___x_951_ = l_Nat_reprFast(v_polynomial_942_);
v___x_952_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_952_, 0, v___x_951_);
if (v_isShared_946_ == 0)
{
lean_ctor_set_tag(v___x_945_, 5);
lean_ctor_set(v___x_945_, 1, v___x_952_);
lean_ctor_set(v___x_945_, 0, v___x_950_);
v___x_954_ = v___x_945_;
goto v_reusejp_953_;
}
else
{
lean_object* v_reuseFailAlloc_963_; 
v_reuseFailAlloc_963_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_963_, 0, v___x_950_);
lean_ctor_set(v_reuseFailAlloc_963_, 1, v___x_952_);
v___x_954_ = v_reuseFailAlloc_963_;
goto v_reusejp_953_;
}
v_reusejp_953_:
{
lean_object* v___x_955_; lean_object* v___x_956_; lean_object* v___x_957_; lean_object* v___x_958_; lean_object* v___x_959_; uint8_t v___x_960_; lean_object* v___x_961_; lean_object* v___x_962_; 
v___x_955_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_955_, 0, v___x_954_);
lean_ctor_set(v___x_955_, 1, v___x_949_);
v___x_956_ = l_Nat_reprFast(v_term_943_);
v___x_957_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_957_, 0, v___x_956_);
v___x_958_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_958_, 0, v___x_955_);
lean_ctor_set(v___x_958_, 1, v___x_957_);
lean_inc(v___y_948_);
v___x_959_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_959_, 0, v___y_948_);
lean_ctor_set(v___x_959_, 1, v___x_958_);
v___x_960_ = 0;
v___x_961_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_961_, 0, v___x_959_);
lean_ctor_set_uint8(v___x_961_, sizeof(void*)*1, v___x_960_);
v___x_962_ = l_Repr_addAppParen(v___x_961_, v_prec_941_);
return v___x_962_;
}
}
}
}
case 1:
{
lean_object* v_polynomial_969_; lean_object* v_term_970_; lean_object* v___x_972_; uint8_t v_isShared_973_; uint8_t v_isSharedCheck_995_; 
v_polynomial_969_ = lean_ctor_get(v_x_940_, 0);
v_term_970_ = lean_ctor_get(v_x_940_, 1);
v_isSharedCheck_995_ = !lean_is_exclusive(v_x_940_);
if (v_isSharedCheck_995_ == 0)
{
v___x_972_ = v_x_940_;
v_isShared_973_ = v_isSharedCheck_995_;
goto v_resetjp_971_;
}
else
{
lean_inc(v_term_970_);
lean_inc(v_polynomial_969_);
lean_dec(v_x_940_);
v___x_972_ = lean_box(0);
v_isShared_973_ = v_isSharedCheck_995_;
goto v_resetjp_971_;
}
v_resetjp_971_:
{
lean_object* v___y_975_; lean_object* v___x_991_; uint8_t v___x_992_; 
v___x_991_ = lean_unsigned_to_nat(1024u);
v___x_992_ = lean_nat_dec_le(v___x_991_, v_prec_941_);
if (v___x_992_ == 0)
{
lean_object* v___x_993_; 
v___x_993_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_975_ = v___x_993_;
goto v___jp_974_;
}
else
{
lean_object* v___x_994_; 
v___x_994_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_975_ = v___x_994_;
goto v___jp_974_;
}
v___jp_974_:
{
lean_object* v___x_976_; lean_object* v___x_977_; lean_object* v___x_978_; lean_object* v___x_979_; lean_object* v___x_981_; 
v___x_976_ = lean_box(1);
v___x_977_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__5));
v___x_978_ = l_Nat_reprFast(v_polynomial_969_);
v___x_979_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_979_, 0, v___x_978_);
if (v_isShared_973_ == 0)
{
lean_ctor_set_tag(v___x_972_, 5);
lean_ctor_set(v___x_972_, 1, v___x_979_);
lean_ctor_set(v___x_972_, 0, v___x_977_);
v___x_981_ = v___x_972_;
goto v_reusejp_980_;
}
else
{
lean_object* v_reuseFailAlloc_990_; 
v_reuseFailAlloc_990_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_990_, 0, v___x_977_);
lean_ctor_set(v_reuseFailAlloc_990_, 1, v___x_979_);
v___x_981_ = v_reuseFailAlloc_990_;
goto v_reusejp_980_;
}
v_reusejp_980_:
{
lean_object* v___x_982_; lean_object* v___x_983_; lean_object* v___x_984_; lean_object* v___x_985_; lean_object* v___x_986_; uint8_t v___x_987_; lean_object* v___x_988_; lean_object* v___x_989_; 
v___x_982_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_982_, 0, v___x_981_);
lean_ctor_set(v___x_982_, 1, v___x_976_);
v___x_983_ = l_Nat_reprFast(v_term_970_);
v___x_984_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_984_, 0, v___x_983_);
v___x_985_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_985_, 0, v___x_982_);
lean_ctor_set(v___x_985_, 1, v___x_984_);
lean_inc(v___y_975_);
v___x_986_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_986_, 0, v___y_975_);
lean_ctor_set(v___x_986_, 1, v___x_985_);
v___x_987_ = 0;
v___x_988_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_988_, 0, v___x_986_);
lean_ctor_set_uint8(v___x_988_, sizeof(void*)*1, v___x_987_);
v___x_989_ = l_Repr_addAppParen(v___x_988_, v_prec_941_);
return v___x_989_;
}
}
}
}
case 2:
{
uint8_t v_error_996_; lean_object* v___y_998_; lean_object* v___x_1007_; uint8_t v___x_1008_; 
v_error_996_ = lean_ctor_get_uint8(v_x_940_, 0);
lean_dec_ref_known(v_x_940_, 0);
v___x_1007_ = lean_unsigned_to_nat(1024u);
v___x_1008_ = lean_nat_dec_le(v___x_1007_, v_prec_941_);
if (v___x_1008_ == 0)
{
lean_object* v___x_1009_; 
v___x_1009_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_998_ = v___x_1009_;
goto v___jp_997_;
}
else
{
lean_object* v___x_1010_; 
v___x_1010_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_998_ = v___x_1010_;
goto v___jp_997_;
}
v___jp_997_:
{
lean_object* v___x_999_; lean_object* v___x_1000_; lean_object* v___x_1001_; lean_object* v___x_1002_; lean_object* v___x_1003_; uint8_t v___x_1004_; lean_object* v___x_1005_; lean_object* v___x_1006_; 
v___x_999_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__8));
v___x_1000_ = lean_unsigned_to_nat(1024u);
v___x_1001_ = lp_Hex_Hex_Groebner_instReprMonomialError_repr(v_error_996_, v___x_1000_);
v___x_1002_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1002_, 0, v___x_999_);
lean_ctor_set(v___x_1002_, 1, v___x_1001_);
lean_inc(v___y_998_);
v___x_1003_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1003_, 0, v___y_998_);
lean_ctor_set(v___x_1003_, 1, v___x_1002_);
v___x_1004_ = 0;
v___x_1005_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1005_, 0, v___x_1003_);
lean_ctor_set_uint8(v___x_1005_, sizeof(void*)*1, v___x_1004_);
v___x_1006_ = l_Repr_addAppParen(v___x_1005_, v_prec_941_);
return v___x_1006_;
}
}
case 3:
{
uint8_t v_resource_1011_; lean_object* v___y_1013_; lean_object* v___x_1022_; uint8_t v___x_1023_; 
v_resource_1011_ = lean_ctor_get_uint8(v_x_940_, 0);
lean_dec_ref_known(v_x_940_, 0);
v___x_1022_ = lean_unsigned_to_nat(1024u);
v___x_1023_ = lean_nat_dec_le(v___x_1022_, v_prec_941_);
if (v___x_1023_ == 0)
{
lean_object* v___x_1024_; 
v___x_1024_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_1013_ = v___x_1024_;
goto v___jp_1012_;
}
else
{
lean_object* v___x_1025_; 
v___x_1025_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_1013_ = v___x_1025_;
goto v___jp_1012_;
}
v___jp_1012_:
{
lean_object* v___x_1014_; lean_object* v___x_1015_; lean_object* v___x_1016_; lean_object* v___x_1017_; lean_object* v___x_1018_; uint8_t v___x_1019_; lean_object* v___x_1020_; lean_object* v___x_1021_; 
v___x_1014_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__11));
v___x_1015_ = lean_unsigned_to_nat(1024u);
v___x_1016_ = lp_Hex_Hex_Groebner_instReprF4Resource_repr(v_resource_1011_, v___x_1015_);
v___x_1017_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1017_, 0, v___x_1014_);
lean_ctor_set(v___x_1017_, 1, v___x_1016_);
lean_inc(v___y_1013_);
v___x_1018_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1018_, 0, v___y_1013_);
lean_ctor_set(v___x_1018_, 1, v___x_1017_);
v___x_1019_ = 0;
v___x_1020_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1020_, 0, v___x_1018_);
lean_ctor_set_uint8(v___x_1020_, sizeof(void*)*1, v___x_1019_);
v___x_1021_ = l_Repr_addAppParen(v___x_1020_, v_prec_941_);
return v___x_1021_;
}
}
default: 
{
lean_object* v_error_1026_; lean_object* v___y_1028_; lean_object* v___x_1037_; uint8_t v___x_1038_; 
v_error_1026_ = lean_ctor_get(v_x_940_, 0);
lean_inc(v_error_1026_);
lean_dec_ref_known(v_x_940_, 1);
v___x_1037_ = lean_unsigned_to_nat(1024u);
v___x_1038_ = lean_nat_dec_le(v___x_1037_, v_prec_941_);
if (v___x_1038_ == 0)
{
lean_object* v___x_1039_; 
v___x_1039_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__18);
v___y_1028_ = v___x_1039_;
goto v___jp_1027_;
}
else
{
lean_object* v___x_1040_; 
v___x_1040_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19, &lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprF4Resource_repr___closed__19);
v___y_1028_ = v___x_1040_;
goto v___jp_1027_;
}
v___jp_1027_:
{
lean_object* v___x_1029_; lean_object* v___x_1030_; lean_object* v___x_1031_; lean_object* v___x_1032_; lean_object* v___x_1033_; uint8_t v___x_1034_; lean_object* v___x_1035_; lean_object* v___x_1036_; 
v___x_1029_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprComputeError_repr___closed__14));
v___x_1030_ = lean_unsigned_to_nat(1024u);
v___x_1031_ = lp_Hex_Hex_Groebner_instReprMatrixError_repr(v_error_1026_, v___x_1030_);
v___x_1032_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1032_, 0, v___x_1029_);
lean_ctor_set(v___x_1032_, 1, v___x_1031_);
lean_inc(v___y_1028_);
v___x_1033_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1033_, 0, v___y_1028_);
lean_ctor_set(v___x_1033_, 1, v___x_1032_);
v___x_1034_ = 0;
v___x_1035_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1035_, 0, v___x_1033_);
lean_ctor_set_uint8(v___x_1035_, sizeof(void*)*1, v___x_1034_);
v___x_1036_ = l_Repr_addAppParen(v___x_1035_, v_prec_941_);
return v___x_1036_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprComputeError_repr___boxed(lean_object* v_x_1041_, lean_object* v_prec_1042_){
_start:
{
lean_object* v_res_1043_; 
v_res_1043_ = lp_Hex_Hex_Groebner_instReprComputeError_repr(v_x_1041_, v_prec_1042_);
lean_dec(v_prec_1042_);
return v_res_1043_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__4(void){
_start:
{
lean_object* v___x_1066_; lean_object* v___x_1067_; 
v___x_1066_ = lean_unsigned_to_nat(8u);
v___x_1067_ = lean_nat_to_int(v___x_1066_);
return v___x_1067_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__7(void){
_start:
{
lean_object* v___x_1071_; lean_object* v___x_1072_; 
v___x_1071_ = lean_unsigned_to_nat(18u);
v___x_1072_ = lean_nat_to_int(v___x_1071_);
return v___x_1072_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__10(void){
_start:
{
lean_object* v___x_1076_; lean_object* v___x_1077_; 
v___x_1076_ = lean_unsigned_to_nat(9u);
v___x_1077_ = lean_nat_to_int(v___x_1076_);
return v___x_1077_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__13(void){
_start:
{
lean_object* v___x_1081_; lean_object* v___x_1082_; 
v___x_1081_ = lean_unsigned_to_nat(10u);
v___x_1082_ = lean_nat_to_int(v___x_1081_);
return v___x_1082_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__16(void){
_start:
{
lean_object* v___x_1086_; lean_object* v___x_1087_; 
v___x_1086_ = lean_unsigned_to_nat(17u);
v___x_1087_ = lean_nat_to_int(v___x_1086_);
return v___x_1087_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__19(void){
_start:
{
lean_object* v___x_1091_; lean_object* v___x_1092_; 
v___x_1091_ = lean_unsigned_to_nat(14u);
v___x_1092_ = lean_nat_to_int(v___x_1091_);
return v___x_1092_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__26(void){
_start:
{
lean_object* v___x_1102_; lean_object* v___x_1103_; 
v___x_1102_ = lean_unsigned_to_nat(21u);
v___x_1103_ = lean_nat_to_int(v___x_1102_);
return v___x_1103_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__29(void){
_start:
{
lean_object* v___x_1107_; lean_object* v___x_1108_; 
v___x_1107_ = lean_unsigned_to_nat(16u);
v___x_1108_ = lean_nat_to_int(v___x_1107_);
return v___x_1108_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__36(void){
_start:
{
lean_object* v___x_1118_; lean_object* v___x_1119_; 
v___x_1118_ = lean_unsigned_to_nat(11u);
v___x_1119_ = lean_nat_to_int(v___x_1118_);
return v___x_1119_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg(lean_object* v_x_1120_){
_start:
{
lean_object* v_work_1121_; lean_object* v_allocatedBytes_1122_; lean_object* v_pairs_1123_; lean_object* v_rounds_1124_; lean_object* v_matrixEntries_1125_; lean_object* v_matrixRows_1126_; lean_object* v_matrixCalls_1127_; lean_object* v_peakMatrixRows_1128_; lean_object* v_peakMatrixEntries_1129_; lean_object* v_largestBatch_1130_; lean_object* v_productPairs_1131_; lean_object* v_chainPairs_1132_; lean_object* v_gmPairs_1133_; lean_object* v___x_1134_; lean_object* v___x_1135_; lean_object* v___x_1136_; lean_object* v___x_1137_; lean_object* v___x_1138_; lean_object* v___x_1139_; uint8_t v___x_1140_; lean_object* v___x_1141_; lean_object* v___x_1142_; lean_object* v___x_1143_; lean_object* v___x_1144_; lean_object* v___x_1145_; lean_object* v___x_1146_; lean_object* v___x_1147_; lean_object* v___x_1148_; lean_object* v___x_1149_; lean_object* v___x_1150_; lean_object* v___x_1151_; lean_object* v___x_1152_; lean_object* v___x_1153_; lean_object* v___x_1154_; lean_object* v___x_1155_; lean_object* v___x_1156_; lean_object* v___x_1157_; lean_object* v___x_1158_; lean_object* v___x_1159_; lean_object* v___x_1160_; lean_object* v___x_1161_; lean_object* v___x_1162_; lean_object* v___x_1163_; lean_object* v___x_1164_; lean_object* v___x_1165_; lean_object* v___x_1166_; lean_object* v___x_1167_; lean_object* v___x_1168_; lean_object* v___x_1169_; lean_object* v___x_1170_; lean_object* v___x_1171_; lean_object* v___x_1172_; lean_object* v___x_1173_; lean_object* v___x_1174_; lean_object* v___x_1175_; lean_object* v___x_1176_; lean_object* v___x_1177_; lean_object* v___x_1178_; lean_object* v___x_1179_; lean_object* v___x_1180_; lean_object* v___x_1181_; lean_object* v___x_1182_; lean_object* v___x_1183_; lean_object* v___x_1184_; lean_object* v___x_1185_; lean_object* v___x_1186_; lean_object* v___x_1187_; lean_object* v___x_1188_; lean_object* v___x_1189_; lean_object* v___x_1190_; lean_object* v___x_1191_; lean_object* v___x_1192_; lean_object* v___x_1193_; lean_object* v___x_1194_; lean_object* v___x_1195_; lean_object* v___x_1196_; lean_object* v___x_1197_; lean_object* v___x_1198_; lean_object* v___x_1199_; lean_object* v___x_1200_; lean_object* v___x_1201_; lean_object* v___x_1202_; lean_object* v___x_1203_; lean_object* v___x_1204_; lean_object* v___x_1205_; lean_object* v___x_1206_; lean_object* v___x_1207_; lean_object* v___x_1208_; lean_object* v___x_1209_; lean_object* v___x_1210_; lean_object* v___x_1211_; lean_object* v___x_1212_; lean_object* v___x_1213_; lean_object* v___x_1214_; lean_object* v___x_1215_; lean_object* v___x_1216_; lean_object* v___x_1217_; lean_object* v___x_1218_; lean_object* v___x_1219_; lean_object* v___x_1220_; lean_object* v___x_1221_; lean_object* v___x_1222_; lean_object* v___x_1223_; lean_object* v___x_1224_; lean_object* v___x_1225_; lean_object* v___x_1226_; lean_object* v___x_1227_; lean_object* v___x_1228_; lean_object* v___x_1229_; lean_object* v___x_1230_; lean_object* v___x_1231_; lean_object* v___x_1232_; lean_object* v___x_1233_; lean_object* v___x_1234_; lean_object* v___x_1235_; lean_object* v___x_1236_; lean_object* v___x_1237_; lean_object* v___x_1238_; lean_object* v___x_1239_; lean_object* v___x_1240_; lean_object* v___x_1241_; lean_object* v___x_1242_; lean_object* v___x_1243_; lean_object* v___x_1244_; lean_object* v___x_1245_; lean_object* v___x_1246_; lean_object* v___x_1247_; lean_object* v___x_1248_; lean_object* v___x_1249_; lean_object* v___x_1250_; lean_object* v___x_1251_; lean_object* v___x_1252_; lean_object* v___x_1253_; lean_object* v___x_1254_; lean_object* v___x_1255_; lean_object* v___x_1256_; lean_object* v___x_1257_; lean_object* v___x_1258_; lean_object* v___x_1259_; lean_object* v___x_1260_; lean_object* v___x_1261_; lean_object* v___x_1262_; lean_object* v___x_1263_; lean_object* v___x_1264_; lean_object* v___x_1265_; lean_object* v___x_1266_; lean_object* v___x_1267_; lean_object* v___x_1268_; lean_object* v___x_1269_; lean_object* v___x_1270_; lean_object* v___x_1271_; lean_object* v___x_1272_; lean_object* v___x_1273_; lean_object* v___x_1274_; lean_object* v___x_1275_; lean_object* v___x_1276_; lean_object* v___x_1277_; lean_object* v___x_1278_; lean_object* v___x_1279_; lean_object* v___x_1280_; 
v_work_1121_ = lean_ctor_get(v_x_1120_, 0);
lean_inc(v_work_1121_);
v_allocatedBytes_1122_ = lean_ctor_get(v_x_1120_, 1);
lean_inc(v_allocatedBytes_1122_);
v_pairs_1123_ = lean_ctor_get(v_x_1120_, 2);
lean_inc(v_pairs_1123_);
v_rounds_1124_ = lean_ctor_get(v_x_1120_, 3);
lean_inc(v_rounds_1124_);
v_matrixEntries_1125_ = lean_ctor_get(v_x_1120_, 4);
lean_inc(v_matrixEntries_1125_);
v_matrixRows_1126_ = lean_ctor_get(v_x_1120_, 5);
lean_inc(v_matrixRows_1126_);
v_matrixCalls_1127_ = lean_ctor_get(v_x_1120_, 6);
lean_inc(v_matrixCalls_1127_);
v_peakMatrixRows_1128_ = lean_ctor_get(v_x_1120_, 7);
lean_inc(v_peakMatrixRows_1128_);
v_peakMatrixEntries_1129_ = lean_ctor_get(v_x_1120_, 8);
lean_inc(v_peakMatrixEntries_1129_);
v_largestBatch_1130_ = lean_ctor_get(v_x_1120_, 9);
lean_inc(v_largestBatch_1130_);
v_productPairs_1131_ = lean_ctor_get(v_x_1120_, 10);
lean_inc(v_productPairs_1131_);
v_chainPairs_1132_ = lean_ctor_get(v_x_1120_, 11);
lean_inc(v_chainPairs_1132_);
v_gmPairs_1133_ = lean_ctor_get(v_x_1120_, 12);
lean_inc(v_gmPairs_1133_);
lean_dec_ref(v_x_1120_);
v___x_1134_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__5));
v___x_1135_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__3));
v___x_1136_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__4, &lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__4_once, _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__4);
v___x_1137_ = l_Nat_reprFast(v_work_1121_);
v___x_1138_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1138_, 0, v___x_1137_);
v___x_1139_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1139_, 0, v___x_1136_);
lean_ctor_set(v___x_1139_, 1, v___x_1138_);
v___x_1140_ = 0;
v___x_1141_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1141_, 0, v___x_1139_);
lean_ctor_set_uint8(v___x_1141_, sizeof(void*)*1, v___x_1140_);
v___x_1142_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1142_, 0, v___x_1135_);
lean_ctor_set(v___x_1142_, 1, v___x_1141_);
v___x_1143_ = ((lean_object*)(lp_Hex_Array_repr___at___00Hex_Groebner_instReprRawTerm_repr_spec__0___closed__2));
v___x_1144_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1144_, 0, v___x_1142_);
lean_ctor_set(v___x_1144_, 1, v___x_1143_);
v___x_1145_ = lean_box(1);
v___x_1146_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1146_, 0, v___x_1144_);
lean_ctor_set(v___x_1146_, 1, v___x_1145_);
v___x_1147_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__6));
v___x_1148_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1148_, 0, v___x_1146_);
lean_ctor_set(v___x_1148_, 1, v___x_1147_);
v___x_1149_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1149_, 0, v___x_1148_);
lean_ctor_set(v___x_1149_, 1, v___x_1134_);
v___x_1150_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__7, &lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__7);
v___x_1151_ = l_Nat_reprFast(v_allocatedBytes_1122_);
v___x_1152_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1152_, 0, v___x_1151_);
v___x_1153_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1153_, 0, v___x_1150_);
lean_ctor_set(v___x_1153_, 1, v___x_1152_);
v___x_1154_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1154_, 0, v___x_1153_);
lean_ctor_set_uint8(v___x_1154_, sizeof(void*)*1, v___x_1140_);
v___x_1155_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1155_, 0, v___x_1149_);
lean_ctor_set(v___x_1155_, 1, v___x_1154_);
v___x_1156_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1156_, 0, v___x_1155_);
lean_ctor_set(v___x_1156_, 1, v___x_1143_);
v___x_1157_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1157_, 0, v___x_1156_);
lean_ctor_set(v___x_1157_, 1, v___x_1145_);
v___x_1158_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__9));
v___x_1159_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1159_, 0, v___x_1157_);
lean_ctor_set(v___x_1159_, 1, v___x_1158_);
v___x_1160_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1160_, 0, v___x_1159_);
lean_ctor_set(v___x_1160_, 1, v___x_1134_);
v___x_1161_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__10, &lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__10_once, _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__10);
v___x_1162_ = l_Nat_reprFast(v_pairs_1123_);
v___x_1163_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1163_, 0, v___x_1162_);
v___x_1164_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1164_, 0, v___x_1161_);
lean_ctor_set(v___x_1164_, 1, v___x_1163_);
v___x_1165_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1165_, 0, v___x_1164_);
lean_ctor_set_uint8(v___x_1165_, sizeof(void*)*1, v___x_1140_);
v___x_1166_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1166_, 0, v___x_1160_);
lean_ctor_set(v___x_1166_, 1, v___x_1165_);
v___x_1167_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1167_, 0, v___x_1166_);
lean_ctor_set(v___x_1167_, 1, v___x_1143_);
v___x_1168_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1168_, 0, v___x_1167_);
lean_ctor_set(v___x_1168_, 1, v___x_1145_);
v___x_1169_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__12));
v___x_1170_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1170_, 0, v___x_1168_);
lean_ctor_set(v___x_1170_, 1, v___x_1169_);
v___x_1171_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1171_, 0, v___x_1170_);
lean_ctor_set(v___x_1171_, 1, v___x_1134_);
v___x_1172_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__13, &lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__13_once, _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__13);
v___x_1173_ = l_Nat_reprFast(v_rounds_1124_);
v___x_1174_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1174_, 0, v___x_1173_);
v___x_1175_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1175_, 0, v___x_1172_);
lean_ctor_set(v___x_1175_, 1, v___x_1174_);
v___x_1176_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1176_, 0, v___x_1175_);
lean_ctor_set_uint8(v___x_1176_, sizeof(void*)*1, v___x_1140_);
v___x_1177_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1177_, 0, v___x_1171_);
lean_ctor_set(v___x_1177_, 1, v___x_1176_);
v___x_1178_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1178_, 0, v___x_1177_);
lean_ctor_set(v___x_1178_, 1, v___x_1143_);
v___x_1179_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1179_, 0, v___x_1178_);
lean_ctor_set(v___x_1179_, 1, v___x_1145_);
v___x_1180_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__15));
v___x_1181_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1181_, 0, v___x_1179_);
lean_ctor_set(v___x_1181_, 1, v___x_1180_);
v___x_1182_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1182_, 0, v___x_1181_);
lean_ctor_set(v___x_1182_, 1, v___x_1134_);
v___x_1183_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__16, &lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__16_once, _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__16);
v___x_1184_ = l_Nat_reprFast(v_matrixEntries_1125_);
v___x_1185_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1185_, 0, v___x_1184_);
v___x_1186_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1186_, 0, v___x_1183_);
lean_ctor_set(v___x_1186_, 1, v___x_1185_);
v___x_1187_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1187_, 0, v___x_1186_);
lean_ctor_set_uint8(v___x_1187_, sizeof(void*)*1, v___x_1140_);
v___x_1188_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1188_, 0, v___x_1182_);
lean_ctor_set(v___x_1188_, 1, v___x_1187_);
v___x_1189_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1189_, 0, v___x_1188_);
lean_ctor_set(v___x_1189_, 1, v___x_1143_);
v___x_1190_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1190_, 0, v___x_1189_);
lean_ctor_set(v___x_1190_, 1, v___x_1145_);
v___x_1191_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__18));
v___x_1192_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1192_, 0, v___x_1190_);
lean_ctor_set(v___x_1192_, 1, v___x_1191_);
v___x_1193_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1193_, 0, v___x_1192_);
lean_ctor_set(v___x_1193_, 1, v___x_1134_);
v___x_1194_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__19, &lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__19_once, _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__19);
v___x_1195_ = l_Nat_reprFast(v_matrixRows_1126_);
v___x_1196_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1196_, 0, v___x_1195_);
v___x_1197_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1197_, 0, v___x_1194_);
lean_ctor_set(v___x_1197_, 1, v___x_1196_);
v___x_1198_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1198_, 0, v___x_1197_);
lean_ctor_set_uint8(v___x_1198_, sizeof(void*)*1, v___x_1140_);
v___x_1199_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1199_, 0, v___x_1193_);
lean_ctor_set(v___x_1199_, 1, v___x_1198_);
v___x_1200_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1200_, 0, v___x_1199_);
lean_ctor_set(v___x_1200_, 1, v___x_1143_);
v___x_1201_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1201_, 0, v___x_1200_);
lean_ctor_set(v___x_1201_, 1, v___x_1145_);
v___x_1202_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__21));
v___x_1203_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1203_, 0, v___x_1201_);
lean_ctor_set(v___x_1203_, 1, v___x_1202_);
v___x_1204_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1204_, 0, v___x_1203_);
lean_ctor_set(v___x_1204_, 1, v___x_1134_);
v___x_1205_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__10, &lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__10_once, _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__10);
v___x_1206_ = l_Nat_reprFast(v_matrixCalls_1127_);
v___x_1207_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1207_, 0, v___x_1206_);
v___x_1208_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1208_, 0, v___x_1205_);
lean_ctor_set(v___x_1208_, 1, v___x_1207_);
v___x_1209_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1209_, 0, v___x_1208_);
lean_ctor_set_uint8(v___x_1209_, sizeof(void*)*1, v___x_1140_);
v___x_1210_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1210_, 0, v___x_1204_);
lean_ctor_set(v___x_1210_, 1, v___x_1209_);
v___x_1211_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1211_, 0, v___x_1210_);
lean_ctor_set(v___x_1211_, 1, v___x_1143_);
v___x_1212_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1212_, 0, v___x_1211_);
lean_ctor_set(v___x_1212_, 1, v___x_1145_);
v___x_1213_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__23));
v___x_1214_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1214_, 0, v___x_1212_);
lean_ctor_set(v___x_1214_, 1, v___x_1213_);
v___x_1215_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1215_, 0, v___x_1214_);
lean_ctor_set(v___x_1215_, 1, v___x_1134_);
v___x_1216_ = l_Nat_reprFast(v_peakMatrixRows_1128_);
v___x_1217_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1217_, 0, v___x_1216_);
v___x_1218_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1218_, 0, v___x_1150_);
lean_ctor_set(v___x_1218_, 1, v___x_1217_);
v___x_1219_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1219_, 0, v___x_1218_);
lean_ctor_set_uint8(v___x_1219_, sizeof(void*)*1, v___x_1140_);
v___x_1220_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1220_, 0, v___x_1215_);
lean_ctor_set(v___x_1220_, 1, v___x_1219_);
v___x_1221_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1221_, 0, v___x_1220_);
lean_ctor_set(v___x_1221_, 1, v___x_1143_);
v___x_1222_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1222_, 0, v___x_1221_);
lean_ctor_set(v___x_1222_, 1, v___x_1145_);
v___x_1223_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__25));
v___x_1224_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1224_, 0, v___x_1222_);
lean_ctor_set(v___x_1224_, 1, v___x_1223_);
v___x_1225_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1225_, 0, v___x_1224_);
lean_ctor_set(v___x_1225_, 1, v___x_1134_);
v___x_1226_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__26, &lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__26_once, _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__26);
v___x_1227_ = l_Nat_reprFast(v_peakMatrixEntries_1129_);
v___x_1228_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1228_, 0, v___x_1227_);
v___x_1229_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1229_, 0, v___x_1226_);
lean_ctor_set(v___x_1229_, 1, v___x_1228_);
v___x_1230_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1230_, 0, v___x_1229_);
lean_ctor_set_uint8(v___x_1230_, sizeof(void*)*1, v___x_1140_);
v___x_1231_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1231_, 0, v___x_1225_);
lean_ctor_set(v___x_1231_, 1, v___x_1230_);
v___x_1232_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1232_, 0, v___x_1231_);
lean_ctor_set(v___x_1232_, 1, v___x_1143_);
v___x_1233_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1233_, 0, v___x_1232_);
lean_ctor_set(v___x_1233_, 1, v___x_1145_);
v___x_1234_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__28));
v___x_1235_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1235_, 0, v___x_1233_);
lean_ctor_set(v___x_1235_, 1, v___x_1234_);
v___x_1236_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1236_, 0, v___x_1235_);
lean_ctor_set(v___x_1236_, 1, v___x_1134_);
v___x_1237_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__29, &lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__29_once, _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__29);
v___x_1238_ = l_Nat_reprFast(v_largestBatch_1130_);
v___x_1239_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1239_, 0, v___x_1238_);
v___x_1240_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1240_, 0, v___x_1237_);
lean_ctor_set(v___x_1240_, 1, v___x_1239_);
v___x_1241_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1241_, 0, v___x_1240_);
lean_ctor_set_uint8(v___x_1241_, sizeof(void*)*1, v___x_1140_);
v___x_1242_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1242_, 0, v___x_1236_);
lean_ctor_set(v___x_1242_, 1, v___x_1241_);
v___x_1243_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1243_, 0, v___x_1242_);
lean_ctor_set(v___x_1243_, 1, v___x_1143_);
v___x_1244_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1244_, 0, v___x_1243_);
lean_ctor_set(v___x_1244_, 1, v___x_1145_);
v___x_1245_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__31));
v___x_1246_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1246_, 0, v___x_1244_);
lean_ctor_set(v___x_1246_, 1, v___x_1245_);
v___x_1247_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1247_, 0, v___x_1246_);
lean_ctor_set(v___x_1247_, 1, v___x_1134_);
v___x_1248_ = l_Nat_reprFast(v_productPairs_1131_);
v___x_1249_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1249_, 0, v___x_1248_);
v___x_1250_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1250_, 0, v___x_1237_);
lean_ctor_set(v___x_1250_, 1, v___x_1249_);
v___x_1251_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1251_, 0, v___x_1250_);
lean_ctor_set_uint8(v___x_1251_, sizeof(void*)*1, v___x_1140_);
v___x_1252_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1252_, 0, v___x_1247_);
lean_ctor_set(v___x_1252_, 1, v___x_1251_);
v___x_1253_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1253_, 0, v___x_1252_);
lean_ctor_set(v___x_1253_, 1, v___x_1143_);
v___x_1254_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1254_, 0, v___x_1253_);
lean_ctor_set(v___x_1254_, 1, v___x_1145_);
v___x_1255_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__33));
v___x_1256_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1256_, 0, v___x_1254_);
lean_ctor_set(v___x_1256_, 1, v___x_1255_);
v___x_1257_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1257_, 0, v___x_1256_);
lean_ctor_set(v___x_1257_, 1, v___x_1134_);
v___x_1258_ = l_Nat_reprFast(v_chainPairs_1132_);
v___x_1259_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1259_, 0, v___x_1258_);
v___x_1260_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1260_, 0, v___x_1194_);
lean_ctor_set(v___x_1260_, 1, v___x_1259_);
v___x_1261_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1261_, 0, v___x_1260_);
lean_ctor_set_uint8(v___x_1261_, sizeof(void*)*1, v___x_1140_);
v___x_1262_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1262_, 0, v___x_1257_);
lean_ctor_set(v___x_1262_, 1, v___x_1261_);
v___x_1263_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1263_, 0, v___x_1262_);
lean_ctor_set(v___x_1263_, 1, v___x_1143_);
v___x_1264_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1264_, 0, v___x_1263_);
lean_ctor_set(v___x_1264_, 1, v___x_1145_);
v___x_1265_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__35));
v___x_1266_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1266_, 0, v___x_1264_);
lean_ctor_set(v___x_1266_, 1, v___x_1265_);
v___x_1267_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1267_, 0, v___x_1266_);
lean_ctor_set(v___x_1267_, 1, v___x_1134_);
v___x_1268_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__36, &lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__36_once, _init_lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg___closed__36);
v___x_1269_ = l_Nat_reprFast(v_gmPairs_1133_);
v___x_1270_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_1270_, 0, v___x_1269_);
v___x_1271_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1271_, 0, v___x_1268_);
lean_ctor_set(v___x_1271_, 1, v___x_1270_);
v___x_1272_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1272_, 0, v___x_1271_);
lean_ctor_set_uint8(v___x_1272_, sizeof(void*)*1, v___x_1140_);
v___x_1273_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1273_, 0, v___x_1267_);
lean_ctor_set(v___x_1273_, 1, v___x_1272_);
v___x_1274_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__13, &lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__13_once, _init_lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__13);
v___x_1275_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__14));
v___x_1276_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1276_, 0, v___x_1275_);
lean_ctor_set(v___x_1276_, 1, v___x_1273_);
v___x_1277_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRawTerm_repr___redArg___closed__15));
v___x_1278_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_1278_, 0, v___x_1276_);
lean_ctor_set(v___x_1278_, 1, v___x_1277_);
v___x_1279_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1279_, 0, v___x_1274_);
lean_ctor_set(v___x_1279_, 1, v___x_1278_);
v___x_1280_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_1280_, 0, v___x_1279_);
lean_ctor_set_uint8(v___x_1280_, sizeof(void*)*1, v___x_1140_);
return v___x_1280_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr(lean_object* v_x_1281_, lean_object* v_prec_1282_){
_start:
{
lean_object* v___x_1283_; 
v___x_1283_ = lp_Hex_Hex_Groebner_instReprStatistics_repr___redArg(v_x_1281_);
return v___x_1283_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprStatistics_repr___boxed(lean_object* v_x_1284_, lean_object* v_prec_1285_){
_start:
{
lean_object* v_res_1286_; 
v_res_1286_ = lp_Hex_Hex_Groebner_instReprStatistics_repr(v_x_1284_, v_prec_1285_);
lean_dec(v_prec_1285_);
return v_res_1286_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqStatistics_beq(lean_object* v_x_1289_, lean_object* v_x_1290_){
_start:
{
lean_object* v_work_1291_; lean_object* v_allocatedBytes_1292_; lean_object* v_pairs_1293_; lean_object* v_rounds_1294_; lean_object* v_matrixEntries_1295_; lean_object* v_matrixRows_1296_; lean_object* v_matrixCalls_1297_; lean_object* v_peakMatrixRows_1298_; lean_object* v_peakMatrixEntries_1299_; lean_object* v_largestBatch_1300_; lean_object* v_productPairs_1301_; lean_object* v_chainPairs_1302_; lean_object* v_gmPairs_1303_; lean_object* v_work_1304_; lean_object* v_allocatedBytes_1305_; lean_object* v_pairs_1306_; lean_object* v_rounds_1307_; lean_object* v_matrixEntries_1308_; lean_object* v_matrixRows_1309_; lean_object* v_matrixCalls_1310_; lean_object* v_peakMatrixRows_1311_; lean_object* v_peakMatrixEntries_1312_; lean_object* v_largestBatch_1313_; lean_object* v_productPairs_1314_; lean_object* v_chainPairs_1315_; lean_object* v_gmPairs_1316_; uint8_t v___x_1317_; 
v_work_1291_ = lean_ctor_get(v_x_1289_, 0);
v_allocatedBytes_1292_ = lean_ctor_get(v_x_1289_, 1);
v_pairs_1293_ = lean_ctor_get(v_x_1289_, 2);
v_rounds_1294_ = lean_ctor_get(v_x_1289_, 3);
v_matrixEntries_1295_ = lean_ctor_get(v_x_1289_, 4);
v_matrixRows_1296_ = lean_ctor_get(v_x_1289_, 5);
v_matrixCalls_1297_ = lean_ctor_get(v_x_1289_, 6);
v_peakMatrixRows_1298_ = lean_ctor_get(v_x_1289_, 7);
v_peakMatrixEntries_1299_ = lean_ctor_get(v_x_1289_, 8);
v_largestBatch_1300_ = lean_ctor_get(v_x_1289_, 9);
v_productPairs_1301_ = lean_ctor_get(v_x_1289_, 10);
v_chainPairs_1302_ = lean_ctor_get(v_x_1289_, 11);
v_gmPairs_1303_ = lean_ctor_get(v_x_1289_, 12);
v_work_1304_ = lean_ctor_get(v_x_1290_, 0);
v_allocatedBytes_1305_ = lean_ctor_get(v_x_1290_, 1);
v_pairs_1306_ = lean_ctor_get(v_x_1290_, 2);
v_rounds_1307_ = lean_ctor_get(v_x_1290_, 3);
v_matrixEntries_1308_ = lean_ctor_get(v_x_1290_, 4);
v_matrixRows_1309_ = lean_ctor_get(v_x_1290_, 5);
v_matrixCalls_1310_ = lean_ctor_get(v_x_1290_, 6);
v_peakMatrixRows_1311_ = lean_ctor_get(v_x_1290_, 7);
v_peakMatrixEntries_1312_ = lean_ctor_get(v_x_1290_, 8);
v_largestBatch_1313_ = lean_ctor_get(v_x_1290_, 9);
v_productPairs_1314_ = lean_ctor_get(v_x_1290_, 10);
v_chainPairs_1315_ = lean_ctor_get(v_x_1290_, 11);
v_gmPairs_1316_ = lean_ctor_get(v_x_1290_, 12);
v___x_1317_ = lean_nat_dec_eq(v_work_1291_, v_work_1304_);
if (v___x_1317_ == 0)
{
return v___x_1317_;
}
else
{
uint8_t v___x_1318_; 
v___x_1318_ = lean_nat_dec_eq(v_allocatedBytes_1292_, v_allocatedBytes_1305_);
if (v___x_1318_ == 0)
{
return v___x_1318_;
}
else
{
uint8_t v___x_1319_; 
v___x_1319_ = lean_nat_dec_eq(v_pairs_1293_, v_pairs_1306_);
if (v___x_1319_ == 0)
{
return v___x_1319_;
}
else
{
uint8_t v___x_1320_; 
v___x_1320_ = lean_nat_dec_eq(v_rounds_1294_, v_rounds_1307_);
if (v___x_1320_ == 0)
{
return v___x_1320_;
}
else
{
uint8_t v___x_1321_; 
v___x_1321_ = lean_nat_dec_eq(v_matrixEntries_1295_, v_matrixEntries_1308_);
if (v___x_1321_ == 0)
{
return v___x_1321_;
}
else
{
uint8_t v___x_1322_; 
v___x_1322_ = lean_nat_dec_eq(v_matrixRows_1296_, v_matrixRows_1309_);
if (v___x_1322_ == 0)
{
return v___x_1322_;
}
else
{
uint8_t v___x_1323_; 
v___x_1323_ = lean_nat_dec_eq(v_matrixCalls_1297_, v_matrixCalls_1310_);
if (v___x_1323_ == 0)
{
return v___x_1323_;
}
else
{
uint8_t v___x_1324_; 
v___x_1324_ = lean_nat_dec_eq(v_peakMatrixRows_1298_, v_peakMatrixRows_1311_);
if (v___x_1324_ == 0)
{
return v___x_1324_;
}
else
{
uint8_t v___x_1325_; 
v___x_1325_ = lean_nat_dec_eq(v_peakMatrixEntries_1299_, v_peakMatrixEntries_1312_);
if (v___x_1325_ == 0)
{
return v___x_1325_;
}
else
{
uint8_t v___x_1326_; 
v___x_1326_ = lean_nat_dec_eq(v_largestBatch_1300_, v_largestBatch_1313_);
if (v___x_1326_ == 0)
{
return v___x_1326_;
}
else
{
uint8_t v___x_1327_; 
v___x_1327_ = lean_nat_dec_eq(v_productPairs_1301_, v_productPairs_1314_);
if (v___x_1327_ == 0)
{
return v___x_1327_;
}
else
{
uint8_t v___x_1328_; 
v___x_1328_ = lean_nat_dec_eq(v_chainPairs_1302_, v_chainPairs_1315_);
if (v___x_1328_ == 0)
{
return v___x_1328_;
}
else
{
uint8_t v___x_1329_; 
v___x_1329_ = lean_nat_dec_eq(v_gmPairs_1303_, v_gmPairs_1316_);
return v___x_1329_;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqStatistics_beq___boxed(lean_object* v_x_1330_, lean_object* v_x_1331_){
_start:
{
uint8_t v_res_1332_; lean_object* v_r_1333_; 
v_res_1332_ = lp_Hex_Hex_Groebner_instBEqStatistics_beq(v_x_1330_, v_x_1331_);
lean_dec_ref(v_x_1331_);
lean_dec_ref(v_x_1330_);
v_r_1333_ = lean_box(v_res_1332_);
return v_r_1333_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_spend(lean_object* v_limits_1346_, lean_object* v_amount_1347_, lean_object* v_a_1348_){
_start:
{
lean_object* v_statistics_1349_; lean_object* v_table_1350_; lean_object* v_work_1351_; lean_object* v_allocatedBytes_1352_; lean_object* v_pairs_1353_; lean_object* v_rounds_1354_; lean_object* v_matrixEntries_1355_; lean_object* v_matrixRows_1356_; lean_object* v_matrixCalls_1357_; lean_object* v_peakMatrixRows_1358_; lean_object* v_peakMatrixEntries_1359_; lean_object* v_largestBatch_1360_; lean_object* v_productPairs_1361_; lean_object* v_chainPairs_1362_; lean_object* v_gmPairs_1363_; lean_object* v___x_1365_; uint8_t v_isShared_1366_; uint8_t v_isSharedCheck_1386_; 
v_statistics_1349_ = lean_ctor_get(v_a_1348_, 1);
lean_inc_ref(v_statistics_1349_);
v_table_1350_ = lean_ctor_get(v_a_1348_, 0);
v_work_1351_ = lean_ctor_get(v_statistics_1349_, 0);
v_allocatedBytes_1352_ = lean_ctor_get(v_statistics_1349_, 1);
v_pairs_1353_ = lean_ctor_get(v_statistics_1349_, 2);
v_rounds_1354_ = lean_ctor_get(v_statistics_1349_, 3);
v_matrixEntries_1355_ = lean_ctor_get(v_statistics_1349_, 4);
v_matrixRows_1356_ = lean_ctor_get(v_statistics_1349_, 5);
v_matrixCalls_1357_ = lean_ctor_get(v_statistics_1349_, 6);
v_peakMatrixRows_1358_ = lean_ctor_get(v_statistics_1349_, 7);
v_peakMatrixEntries_1359_ = lean_ctor_get(v_statistics_1349_, 8);
v_largestBatch_1360_ = lean_ctor_get(v_statistics_1349_, 9);
v_productPairs_1361_ = lean_ctor_get(v_statistics_1349_, 10);
v_chainPairs_1362_ = lean_ctor_get(v_statistics_1349_, 11);
v_gmPairs_1363_ = lean_ctor_get(v_statistics_1349_, 12);
v_isSharedCheck_1386_ = !lean_is_exclusive(v_statistics_1349_);
if (v_isSharedCheck_1386_ == 0)
{
v___x_1365_ = v_statistics_1349_;
v_isShared_1366_ = v_isSharedCheck_1386_;
goto v_resetjp_1364_;
}
else
{
lean_inc(v_gmPairs_1363_);
lean_inc(v_chainPairs_1362_);
lean_inc(v_productPairs_1361_);
lean_inc(v_largestBatch_1360_);
lean_inc(v_peakMatrixEntries_1359_);
lean_inc(v_peakMatrixRows_1358_);
lean_inc(v_matrixCalls_1357_);
lean_inc(v_matrixRows_1356_);
lean_inc(v_matrixEntries_1355_);
lean_inc(v_rounds_1354_);
lean_inc(v_pairs_1353_);
lean_inc(v_allocatedBytes_1352_);
lean_inc(v_work_1351_);
lean_dec(v_statistics_1349_);
v___x_1365_ = lean_box(0);
v_isShared_1366_ = v_isSharedCheck_1386_;
goto v_resetjp_1364_;
}
v_resetjp_1364_:
{
lean_object* v_work_1367_; lean_object* v_work_1368_; uint8_t v___x_1369_; 
v_work_1367_ = lean_ctor_get(v_limits_1346_, 0);
v_work_1368_ = lean_nat_add(v_work_1351_, v_amount_1347_);
lean_dec(v_work_1351_);
v___x_1369_ = lean_nat_dec_lt(v_work_1367_, v_work_1368_);
if (v___x_1369_ == 0)
{
lean_object* v___x_1371_; uint8_t v_isShared_1372_; uint8_t v_isSharedCheck_1381_; 
lean_inc_ref(v_table_1350_);
v_isSharedCheck_1381_ = !lean_is_exclusive(v_a_1348_);
if (v_isSharedCheck_1381_ == 0)
{
lean_object* v_unused_1382_; lean_object* v_unused_1383_; 
v_unused_1382_ = lean_ctor_get(v_a_1348_, 1);
lean_dec(v_unused_1382_);
v_unused_1383_ = lean_ctor_get(v_a_1348_, 0);
lean_dec(v_unused_1383_);
v___x_1371_ = v_a_1348_;
v_isShared_1372_ = v_isSharedCheck_1381_;
goto v_resetjp_1370_;
}
else
{
lean_dec(v_a_1348_);
v___x_1371_ = lean_box(0);
v_isShared_1372_ = v_isSharedCheck_1381_;
goto v_resetjp_1370_;
}
v_resetjp_1370_:
{
lean_object* v___x_1374_; 
if (v_isShared_1366_ == 0)
{
lean_ctor_set(v___x_1365_, 0, v_work_1368_);
v___x_1374_ = v___x_1365_;
goto v_reusejp_1373_;
}
else
{
lean_object* v_reuseFailAlloc_1380_; 
v_reuseFailAlloc_1380_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_1380_, 0, v_work_1368_);
lean_ctor_set(v_reuseFailAlloc_1380_, 1, v_allocatedBytes_1352_);
lean_ctor_set(v_reuseFailAlloc_1380_, 2, v_pairs_1353_);
lean_ctor_set(v_reuseFailAlloc_1380_, 3, v_rounds_1354_);
lean_ctor_set(v_reuseFailAlloc_1380_, 4, v_matrixEntries_1355_);
lean_ctor_set(v_reuseFailAlloc_1380_, 5, v_matrixRows_1356_);
lean_ctor_set(v_reuseFailAlloc_1380_, 6, v_matrixCalls_1357_);
lean_ctor_set(v_reuseFailAlloc_1380_, 7, v_peakMatrixRows_1358_);
lean_ctor_set(v_reuseFailAlloc_1380_, 8, v_peakMatrixEntries_1359_);
lean_ctor_set(v_reuseFailAlloc_1380_, 9, v_largestBatch_1360_);
lean_ctor_set(v_reuseFailAlloc_1380_, 10, v_productPairs_1361_);
lean_ctor_set(v_reuseFailAlloc_1380_, 11, v_chainPairs_1362_);
lean_ctor_set(v_reuseFailAlloc_1380_, 12, v_gmPairs_1363_);
v___x_1374_ = v_reuseFailAlloc_1380_;
goto v_reusejp_1373_;
}
v_reusejp_1373_:
{
lean_object* v___x_1376_; 
if (v_isShared_1372_ == 0)
{
lean_ctor_set(v___x_1371_, 1, v___x_1374_);
v___x_1376_ = v___x_1371_;
goto v_reusejp_1375_;
}
else
{
lean_object* v_reuseFailAlloc_1379_; 
v_reuseFailAlloc_1379_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1379_, 0, v_table_1350_);
lean_ctor_set(v_reuseFailAlloc_1379_, 1, v___x_1374_);
v___x_1376_ = v_reuseFailAlloc_1379_;
goto v_reusejp_1375_;
}
v_reusejp_1375_:
{
lean_object* v___x_1377_; lean_object* v___x_1378_; 
v___x_1377_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_spend___closed__0));
v___x_1378_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1378_, 0, v___x_1377_);
lean_ctor_set(v___x_1378_, 1, v___x_1376_);
return v___x_1378_;
}
}
}
}
else
{
lean_object* v___x_1384_; lean_object* v___x_1385_; 
lean_dec(v_work_1368_);
lean_del_object(v___x_1365_);
lean_dec(v_gmPairs_1363_);
lean_dec(v_chainPairs_1362_);
lean_dec(v_productPairs_1361_);
lean_dec(v_largestBatch_1360_);
lean_dec(v_peakMatrixEntries_1359_);
lean_dec(v_peakMatrixRows_1358_);
lean_dec(v_matrixCalls_1357_);
lean_dec(v_matrixRows_1356_);
lean_dec(v_matrixEntries_1355_);
lean_dec(v_rounds_1354_);
lean_dec(v_pairs_1353_);
lean_dec(v_allocatedBytes_1352_);
v___x_1384_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_spend___closed__2));
v___x_1385_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1385_, 0, v___x_1384_);
lean_ctor_set(v___x_1385_, 1, v_a_1348_);
return v___x_1385_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_spend___boxed(lean_object* v_limits_1387_, lean_object* v_amount_1388_, lean_object* v_a_1389_){
_start:
{
lean_object* v_res_1390_; 
v_res_1390_ = lp_Hex_Hex_Groebner_Computation_spend(v_limits_1387_, v_amount_1388_, v_a_1389_);
lean_dec(v_amount_1388_);
lean_dec_ref(v_limits_1387_);
return v_res_1390_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_Computation_allocate___closed__0(void){
_start:
{
lean_object* v___x_1391_; lean_object* v___x_1392_; lean_object* v___x_1393_; 
v___x_1391_ = l_System_Platform_numBits;
v___x_1392_ = lean_unsigned_to_nat(2u);
v___x_1393_ = lean_nat_pow(v___x_1392_, v___x_1391_);
return v___x_1393_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_allocate(lean_object* v_limits_1402_, lean_object* v_amount_1403_, lean_object* v_a_1404_){
_start:
{
lean_object* v_statistics_1405_; lean_object* v_table_1406_; lean_object* v_work_1407_; lean_object* v_allocatedBytes_1408_; lean_object* v_pairs_1409_; lean_object* v_rounds_1410_; lean_object* v_matrixEntries_1411_; lean_object* v_matrixRows_1412_; lean_object* v_matrixCalls_1413_; lean_object* v_peakMatrixRows_1414_; lean_object* v_peakMatrixEntries_1415_; lean_object* v_largestBatch_1416_; lean_object* v_productPairs_1417_; lean_object* v_chainPairs_1418_; lean_object* v_gmPairs_1419_; lean_object* v___x_1421_; uint8_t v_isShared_1422_; uint8_t v_isSharedCheck_1487_; 
v_statistics_1405_ = lean_ctor_get(v_a_1404_, 1);
lean_inc_ref(v_statistics_1405_);
v_table_1406_ = lean_ctor_get(v_a_1404_, 0);
v_work_1407_ = lean_ctor_get(v_statistics_1405_, 0);
v_allocatedBytes_1408_ = lean_ctor_get(v_statistics_1405_, 1);
v_pairs_1409_ = lean_ctor_get(v_statistics_1405_, 2);
v_rounds_1410_ = lean_ctor_get(v_statistics_1405_, 3);
v_matrixEntries_1411_ = lean_ctor_get(v_statistics_1405_, 4);
v_matrixRows_1412_ = lean_ctor_get(v_statistics_1405_, 5);
v_matrixCalls_1413_ = lean_ctor_get(v_statistics_1405_, 6);
v_peakMatrixRows_1414_ = lean_ctor_get(v_statistics_1405_, 7);
v_peakMatrixEntries_1415_ = lean_ctor_get(v_statistics_1405_, 8);
v_largestBatch_1416_ = lean_ctor_get(v_statistics_1405_, 9);
v_productPairs_1417_ = lean_ctor_get(v_statistics_1405_, 10);
v_chainPairs_1418_ = lean_ctor_get(v_statistics_1405_, 11);
v_gmPairs_1419_ = lean_ctor_get(v_statistics_1405_, 12);
v_isSharedCheck_1487_ = !lean_is_exclusive(v_statistics_1405_);
if (v_isSharedCheck_1487_ == 0)
{
v___x_1421_ = v_statistics_1405_;
v_isShared_1422_ = v_isSharedCheck_1487_;
goto v_resetjp_1420_;
}
else
{
lean_inc(v_gmPairs_1419_);
lean_inc(v_chainPairs_1418_);
lean_inc(v_productPairs_1417_);
lean_inc(v_largestBatch_1416_);
lean_inc(v_peakMatrixEntries_1415_);
lean_inc(v_peakMatrixRows_1414_);
lean_inc(v_matrixCalls_1413_);
lean_inc(v_matrixRows_1412_);
lean_inc(v_matrixEntries_1411_);
lean_inc(v_rounds_1410_);
lean_inc(v_pairs_1409_);
lean_inc(v_allocatedBytes_1408_);
lean_inc(v_work_1407_);
lean_dec(v_statistics_1405_);
v___x_1421_ = lean_box(0);
v_isShared_1422_ = v_isSharedCheck_1487_;
goto v_resetjp_1420_;
}
v_resetjp_1420_:
{
lean_object* v_arity_1423_; lean_object* v_exponents_1424_; lean_object* v_metadata_1425_; lean_object* v_count_1426_; lean_object* v_workspace_1427_; lean_object* v_products_1428_; lean_object* v_allocated_1429_; lean_object* v___x_1430_; lean_object* v___x_1431_; lean_object* v___x_1432_; lean_object* v___y_1434_; lean_object* v___x_1474_; lean_object* v___y_1476_; lean_object* v___x_1478_; uint8_t v___x_1479_; 
v_arity_1423_ = lean_ctor_get(v_table_1406_, 0);
v_exponents_1424_ = lean_ctor_get(v_table_1406_, 1);
v_metadata_1425_ = lean_ctor_get(v_table_1406_, 2);
v_count_1426_ = lean_ctor_get(v_table_1406_, 3);
v_workspace_1427_ = lean_ctor_get(v_table_1406_, 4);
v_products_1428_ = lean_ctor_get(v_table_1406_, 6);
lean_inc_ref(v_products_1428_);
v_allocated_1429_ = lean_nat_add(v_allocatedBytes_1408_, v_amount_1403_);
lean_dec(v_allocatedBytes_1408_);
v___x_1430_ = lean_byte_array_size(v_exponents_1424_);
v___x_1431_ = lean_byte_array_size(v_metadata_1425_);
v___x_1432_ = lean_nat_add(v___x_1430_, v___x_1431_);
v___x_1474_ = lean_byte_array_size(v_workspace_1427_);
v___x_1478_ = lean_unsigned_to_nat(0u);
v___x_1479_ = lean_nat_dec_eq(v_count_1426_, v___x_1478_);
if (v___x_1479_ == 0)
{
uint8_t v___x_1480_; 
v___x_1480_ = lean_nat_dec_lt(v___x_1478_, v_arity_1423_);
if (v___x_1480_ == 0)
{
v___y_1476_ = v___x_1478_;
goto v___jp_1475_;
}
else
{
lean_object* v___x_1481_; uint8_t v___x_1482_; 
v___x_1481_ = lean_unsigned_to_nat(4096u);
v___x_1482_ = lean_nat_dec_le(v_arity_1423_, v___x_1481_);
if (v___x_1482_ == 0)
{
v___y_1476_ = v___x_1478_;
goto v___jp_1475_;
}
else
{
lean_object* v___x_1483_; lean_object* v___x_1484_; lean_object* v___x_1485_; lean_object* v___x_1486_; 
v___x_1483_ = lean_unsigned_to_nat(4u);
v___x_1484_ = lean_nat_mul(v_arity_1423_, v___x_1483_);
v___x_1485_ = lean_unsigned_to_nat(28u);
v___x_1486_ = lean_nat_add(v___x_1484_, v___x_1485_);
lean_dec(v___x_1484_);
v___y_1476_ = v___x_1486_;
goto v___jp_1475_;
}
}
}
else
{
v___y_1476_ = v___x_1478_;
goto v___jp_1475_;
}
v___jp_1433_:
{
lean_object* v_size_1435_; lean_object* v___x_1437_; uint8_t v_isShared_1438_; uint8_t v_isSharedCheck_1472_; 
v_size_1435_ = lean_ctor_get(v_products_1428_, 0);
v_isSharedCheck_1472_ = !lean_is_exclusive(v_products_1428_);
if (v_isSharedCheck_1472_ == 0)
{
lean_object* v_unused_1473_; 
v_unused_1473_ = lean_ctor_get(v_products_1428_, 1);
lean_dec(v_unused_1473_);
v___x_1437_ = v_products_1428_;
v_isShared_1438_ = v_isSharedCheck_1472_;
goto v_resetjp_1436_;
}
else
{
lean_inc(v_size_1435_);
lean_dec(v_products_1428_);
v___x_1437_ = lean_box(0);
v_isShared_1438_ = v_isSharedCheck_1472_;
goto v_resetjp_1436_;
}
v_resetjp_1436_:
{
lean_object* v_packedBytes_1439_; lean_object* v___x_1440_; lean_object* v___x_1441_; lean_object* v___x_1442_; lean_object* v___x_1443_; lean_object* v_total_1444_; uint8_t v___x_1445_; 
v_packedBytes_1439_ = lean_ctor_get(v_limits_1402_, 1);
v___x_1440_ = lean_nat_add(v___x_1432_, v___y_1434_);
lean_dec(v___y_1434_);
lean_dec(v___x_1432_);
v___x_1441_ = lean_unsigned_to_nat(12u);
v___x_1442_ = lean_nat_mul(v___x_1441_, v_size_1435_);
lean_dec(v_size_1435_);
v___x_1443_ = lean_nat_add(v___x_1440_, v___x_1442_);
lean_dec(v___x_1442_);
lean_dec(v___x_1440_);
v_total_1444_ = lean_nat_add(v_allocated_1429_, v___x_1443_);
lean_dec(v___x_1443_);
v___x_1445_ = lean_nat_dec_lt(v_packedBytes_1439_, v_total_1444_);
lean_dec(v_total_1444_);
if (v___x_1445_ == 0)
{
lean_object* v___x_1446_; uint8_t v___x_1447_; 
v___x_1446_ = lean_obj_once(&lp_Hex_Hex_Groebner_Computation_allocate___closed__0, &lp_Hex_Hex_Groebner_Computation_allocate___closed__0_once, _init_lp_Hex_Hex_Groebner_Computation_allocate___closed__0);
v___x_1447_ = lean_nat_dec_le(v___x_1446_, v_amount_1403_);
if (v___x_1447_ == 0)
{
lean_object* v___x_1449_; uint8_t v_isShared_1450_; uint8_t v_isSharedCheck_1461_; 
lean_inc_ref(v_table_1406_);
v_isSharedCheck_1461_ = !lean_is_exclusive(v_a_1404_);
if (v_isSharedCheck_1461_ == 0)
{
lean_object* v_unused_1462_; lean_object* v_unused_1463_; 
v_unused_1462_ = lean_ctor_get(v_a_1404_, 1);
lean_dec(v_unused_1462_);
v_unused_1463_ = lean_ctor_get(v_a_1404_, 0);
lean_dec(v_unused_1463_);
v___x_1449_ = v_a_1404_;
v_isShared_1450_ = v_isSharedCheck_1461_;
goto v_resetjp_1448_;
}
else
{
lean_dec(v_a_1404_);
v___x_1449_ = lean_box(0);
v_isShared_1450_ = v_isSharedCheck_1461_;
goto v_resetjp_1448_;
}
v_resetjp_1448_:
{
lean_object* v___x_1452_; 
if (v_isShared_1422_ == 0)
{
lean_ctor_set(v___x_1421_, 1, v_allocated_1429_);
v___x_1452_ = v___x_1421_;
goto v_reusejp_1451_;
}
else
{
lean_object* v_reuseFailAlloc_1460_; 
v_reuseFailAlloc_1460_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_1460_, 0, v_work_1407_);
lean_ctor_set(v_reuseFailAlloc_1460_, 1, v_allocated_1429_);
lean_ctor_set(v_reuseFailAlloc_1460_, 2, v_pairs_1409_);
lean_ctor_set(v_reuseFailAlloc_1460_, 3, v_rounds_1410_);
lean_ctor_set(v_reuseFailAlloc_1460_, 4, v_matrixEntries_1411_);
lean_ctor_set(v_reuseFailAlloc_1460_, 5, v_matrixRows_1412_);
lean_ctor_set(v_reuseFailAlloc_1460_, 6, v_matrixCalls_1413_);
lean_ctor_set(v_reuseFailAlloc_1460_, 7, v_peakMatrixRows_1414_);
lean_ctor_set(v_reuseFailAlloc_1460_, 8, v_peakMatrixEntries_1415_);
lean_ctor_set(v_reuseFailAlloc_1460_, 9, v_largestBatch_1416_);
lean_ctor_set(v_reuseFailAlloc_1460_, 10, v_productPairs_1417_);
lean_ctor_set(v_reuseFailAlloc_1460_, 11, v_chainPairs_1418_);
lean_ctor_set(v_reuseFailAlloc_1460_, 12, v_gmPairs_1419_);
v___x_1452_ = v_reuseFailAlloc_1460_;
goto v_reusejp_1451_;
}
v_reusejp_1451_:
{
lean_object* v___x_1454_; 
if (v_isShared_1450_ == 0)
{
lean_ctor_set(v___x_1449_, 1, v___x_1452_);
v___x_1454_ = v___x_1449_;
goto v_reusejp_1453_;
}
else
{
lean_object* v_reuseFailAlloc_1459_; 
v_reuseFailAlloc_1459_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1459_, 0, v_table_1406_);
lean_ctor_set(v_reuseFailAlloc_1459_, 1, v___x_1452_);
v___x_1454_ = v_reuseFailAlloc_1459_;
goto v_reusejp_1453_;
}
v_reusejp_1453_:
{
lean_object* v___x_1455_; lean_object* v___x_1457_; 
v___x_1455_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_spend___closed__0));
if (v_isShared_1438_ == 0)
{
lean_ctor_set(v___x_1437_, 1, v___x_1454_);
lean_ctor_set(v___x_1437_, 0, v___x_1455_);
v___x_1457_ = v___x_1437_;
goto v_reusejp_1456_;
}
else
{
lean_object* v_reuseFailAlloc_1458_; 
v_reuseFailAlloc_1458_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1458_, 0, v___x_1455_);
lean_ctor_set(v_reuseFailAlloc_1458_, 1, v___x_1454_);
v___x_1457_ = v_reuseFailAlloc_1458_;
goto v_reusejp_1456_;
}
v_reusejp_1456_:
{
return v___x_1457_;
}
}
}
}
}
else
{
lean_object* v___x_1464_; lean_object* v___x_1466_; 
lean_dec(v_allocated_1429_);
lean_del_object(v___x_1421_);
lean_dec(v_gmPairs_1419_);
lean_dec(v_chainPairs_1418_);
lean_dec(v_productPairs_1417_);
lean_dec(v_largestBatch_1416_);
lean_dec(v_peakMatrixEntries_1415_);
lean_dec(v_peakMatrixRows_1414_);
lean_dec(v_matrixCalls_1413_);
lean_dec(v_matrixRows_1412_);
lean_dec(v_matrixEntries_1411_);
lean_dec(v_rounds_1410_);
lean_dec(v_pairs_1409_);
lean_dec(v_work_1407_);
v___x_1464_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_allocate___closed__2));
if (v_isShared_1438_ == 0)
{
lean_ctor_set(v___x_1437_, 1, v_a_1404_);
lean_ctor_set(v___x_1437_, 0, v___x_1464_);
v___x_1466_ = v___x_1437_;
goto v_reusejp_1465_;
}
else
{
lean_object* v_reuseFailAlloc_1467_; 
v_reuseFailAlloc_1467_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1467_, 0, v___x_1464_);
lean_ctor_set(v_reuseFailAlloc_1467_, 1, v_a_1404_);
v___x_1466_ = v_reuseFailAlloc_1467_;
goto v_reusejp_1465_;
}
v_reusejp_1465_:
{
return v___x_1466_;
}
}
}
else
{
lean_object* v___x_1468_; lean_object* v___x_1470_; 
lean_dec(v_allocated_1429_);
lean_del_object(v___x_1421_);
lean_dec(v_gmPairs_1419_);
lean_dec(v_chainPairs_1418_);
lean_dec(v_productPairs_1417_);
lean_dec(v_largestBatch_1416_);
lean_dec(v_peakMatrixEntries_1415_);
lean_dec(v_peakMatrixRows_1414_);
lean_dec(v_matrixCalls_1413_);
lean_dec(v_matrixRows_1412_);
lean_dec(v_matrixEntries_1411_);
lean_dec(v_rounds_1410_);
lean_dec(v_pairs_1409_);
lean_dec(v_work_1407_);
v___x_1468_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_allocate___closed__4));
if (v_isShared_1438_ == 0)
{
lean_ctor_set(v___x_1437_, 1, v_a_1404_);
lean_ctor_set(v___x_1437_, 0, v___x_1468_);
v___x_1470_ = v___x_1437_;
goto v_reusejp_1469_;
}
else
{
lean_object* v_reuseFailAlloc_1471_; 
v_reuseFailAlloc_1471_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1471_, 0, v___x_1468_);
lean_ctor_set(v_reuseFailAlloc_1471_, 1, v_a_1404_);
v___x_1470_ = v_reuseFailAlloc_1471_;
goto v_reusejp_1469_;
}
v_reusejp_1469_:
{
return v___x_1470_;
}
}
}
}
v___jp_1475_:
{
uint8_t v___x_1477_; 
v___x_1477_ = lean_nat_dec_le(v___x_1474_, v___y_1476_);
if (v___x_1477_ == 0)
{
lean_dec(v___y_1476_);
v___y_1434_ = v___x_1474_;
goto v___jp_1433_;
}
else
{
v___y_1434_ = v___y_1476_;
goto v___jp_1433_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_allocate___boxed(lean_object* v_limits_1488_, lean_object* v_amount_1489_, lean_object* v_a_1490_){
_start:
{
lean_object* v_res_1491_; 
v_res_1491_ = lp_Hex_Hex_Groebner_Computation_allocate(v_limits_1488_, v_amount_1489_, v_a_1490_);
lean_dec(v_amount_1489_);
lean_dec_ref(v_limits_1488_);
return v_res_1491_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome___redArg(lean_object* v_statistics_1494_, lean_object* v_table_1495_, lean_object* v_result_1496_){
_start:
{
if (lean_obj_tag(v_result_1496_) == 0)
{
lean_object* v_a_1497_; lean_object* v___x_1499_; uint8_t v_isShared_1500_; uint8_t v_isSharedCheck_1534_; 
v_a_1497_ = lean_ctor_get(v_result_1496_, 0);
v_isSharedCheck_1534_ = !lean_is_exclusive(v_result_1496_);
if (v_isSharedCheck_1534_ == 0)
{
v___x_1499_ = v_result_1496_;
v_isShared_1500_ = v_isSharedCheck_1534_;
goto v_resetjp_1498_;
}
else
{
lean_inc(v_a_1497_);
lean_dec(v_result_1496_);
v___x_1499_ = lean_box(0);
v_isShared_1500_ = v_isSharedCheck_1534_;
goto v_resetjp_1498_;
}
v_resetjp_1498_:
{
uint8_t v_error_1501_; lean_object* v_work_1502_; lean_object* v___y_1504_; 
v_error_1501_ = lean_ctor_get_uint8(v_a_1497_, sizeof(void*)*1);
v_work_1502_ = lean_ctor_get(v_a_1497_, 0);
lean_inc(v_work_1502_);
lean_dec(v_a_1497_);
switch(v_error_1501_)
{
case 8:
{
lean_object* v___x_1530_; 
v___x_1530_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_spend___closed__1));
v___y_1504_ = v___x_1530_;
goto v___jp_1503_;
}
case 6:
{
lean_object* v___x_1531_; 
v___x_1531_ = ((lean_object*)(lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome___redArg___closed__0));
v___y_1504_ = v___x_1531_;
goto v___jp_1503_;
}
case 7:
{
lean_object* v___x_1532_; 
v___x_1532_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_allocate___closed__3));
v___y_1504_ = v___x_1532_;
goto v___jp_1503_;
}
default: 
{
lean_object* v___x_1533_; 
v___x_1533_ = lean_alloc_ctor(2, 0, 1);
lean_ctor_set_uint8(v___x_1533_, 0, v_error_1501_);
v___y_1504_ = v___x_1533_;
goto v___jp_1503_;
}
}
v___jp_1503_:
{
lean_object* v_allocatedBytes_1505_; lean_object* v_pairs_1506_; lean_object* v_rounds_1507_; lean_object* v_matrixEntries_1508_; lean_object* v_matrixRows_1509_; lean_object* v_matrixCalls_1510_; lean_object* v_peakMatrixRows_1511_; lean_object* v_peakMatrixEntries_1512_; lean_object* v_largestBatch_1513_; lean_object* v_productPairs_1514_; lean_object* v_chainPairs_1515_; lean_object* v_gmPairs_1516_; lean_object* v___x_1518_; uint8_t v_isShared_1519_; uint8_t v_isSharedCheck_1528_; 
v_allocatedBytes_1505_ = lean_ctor_get(v_statistics_1494_, 1);
v_pairs_1506_ = lean_ctor_get(v_statistics_1494_, 2);
v_rounds_1507_ = lean_ctor_get(v_statistics_1494_, 3);
v_matrixEntries_1508_ = lean_ctor_get(v_statistics_1494_, 4);
v_matrixRows_1509_ = lean_ctor_get(v_statistics_1494_, 5);
v_matrixCalls_1510_ = lean_ctor_get(v_statistics_1494_, 6);
v_peakMatrixRows_1511_ = lean_ctor_get(v_statistics_1494_, 7);
v_peakMatrixEntries_1512_ = lean_ctor_get(v_statistics_1494_, 8);
v_largestBatch_1513_ = lean_ctor_get(v_statistics_1494_, 9);
v_productPairs_1514_ = lean_ctor_get(v_statistics_1494_, 10);
v_chainPairs_1515_ = lean_ctor_get(v_statistics_1494_, 11);
v_gmPairs_1516_ = lean_ctor_get(v_statistics_1494_, 12);
v_isSharedCheck_1528_ = !lean_is_exclusive(v_statistics_1494_);
if (v_isSharedCheck_1528_ == 0)
{
lean_object* v_unused_1529_; 
v_unused_1529_ = lean_ctor_get(v_statistics_1494_, 0);
lean_dec(v_unused_1529_);
v___x_1518_ = v_statistics_1494_;
v_isShared_1519_ = v_isSharedCheck_1528_;
goto v_resetjp_1517_;
}
else
{
lean_inc(v_gmPairs_1516_);
lean_inc(v_chainPairs_1515_);
lean_inc(v_productPairs_1514_);
lean_inc(v_largestBatch_1513_);
lean_inc(v_peakMatrixEntries_1512_);
lean_inc(v_peakMatrixRows_1511_);
lean_inc(v_matrixCalls_1510_);
lean_inc(v_matrixRows_1509_);
lean_inc(v_matrixEntries_1508_);
lean_inc(v_rounds_1507_);
lean_inc(v_pairs_1506_);
lean_inc(v_allocatedBytes_1505_);
lean_dec(v_statistics_1494_);
v___x_1518_ = lean_box(0);
v_isShared_1519_ = v_isSharedCheck_1528_;
goto v_resetjp_1517_;
}
v_resetjp_1517_:
{
lean_object* v___x_1521_; 
if (v_isShared_1500_ == 0)
{
lean_ctor_set(v___x_1499_, 0, v___y_1504_);
v___x_1521_ = v___x_1499_;
goto v_reusejp_1520_;
}
else
{
lean_object* v_reuseFailAlloc_1527_; 
v_reuseFailAlloc_1527_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1527_, 0, v___y_1504_);
v___x_1521_ = v_reuseFailAlloc_1527_;
goto v_reusejp_1520_;
}
v_reusejp_1520_:
{
lean_object* v___x_1523_; 
if (v_isShared_1519_ == 0)
{
lean_ctor_set(v___x_1518_, 0, v_work_1502_);
v___x_1523_ = v___x_1518_;
goto v_reusejp_1522_;
}
else
{
lean_object* v_reuseFailAlloc_1526_; 
v_reuseFailAlloc_1526_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_1526_, 0, v_work_1502_);
lean_ctor_set(v_reuseFailAlloc_1526_, 1, v_allocatedBytes_1505_);
lean_ctor_set(v_reuseFailAlloc_1526_, 2, v_pairs_1506_);
lean_ctor_set(v_reuseFailAlloc_1526_, 3, v_rounds_1507_);
lean_ctor_set(v_reuseFailAlloc_1526_, 4, v_matrixEntries_1508_);
lean_ctor_set(v_reuseFailAlloc_1526_, 5, v_matrixRows_1509_);
lean_ctor_set(v_reuseFailAlloc_1526_, 6, v_matrixCalls_1510_);
lean_ctor_set(v_reuseFailAlloc_1526_, 7, v_peakMatrixRows_1511_);
lean_ctor_set(v_reuseFailAlloc_1526_, 8, v_peakMatrixEntries_1512_);
lean_ctor_set(v_reuseFailAlloc_1526_, 9, v_largestBatch_1513_);
lean_ctor_set(v_reuseFailAlloc_1526_, 10, v_productPairs_1514_);
lean_ctor_set(v_reuseFailAlloc_1526_, 11, v_chainPairs_1515_);
lean_ctor_set(v_reuseFailAlloc_1526_, 12, v_gmPairs_1516_);
v___x_1523_ = v_reuseFailAlloc_1526_;
goto v_reusejp_1522_;
}
v_reusejp_1522_:
{
lean_object* v___x_1524_; lean_object* v___x_1525_; 
v___x_1524_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1524_, 0, v_table_1495_);
lean_ctor_set(v___x_1524_, 1, v___x_1523_);
v___x_1525_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1525_, 0, v___x_1521_);
lean_ctor_set(v___x_1525_, 1, v___x_1524_);
return v___x_1525_;
}
}
}
}
}
}
else
{
lean_object* v_a_1535_; lean_object* v___x_1537_; uint8_t v_isShared_1538_; uint8_t v_isSharedCheck_1565_; 
v_a_1535_ = lean_ctor_get(v_result_1496_, 0);
v_isSharedCheck_1565_ = !lean_is_exclusive(v_result_1496_);
if (v_isSharedCheck_1565_ == 0)
{
v___x_1537_ = v_result_1496_;
v_isShared_1538_ = v_isSharedCheck_1565_;
goto v_resetjp_1536_;
}
else
{
lean_inc(v_a_1535_);
lean_dec(v_result_1496_);
v___x_1537_ = lean_box(0);
v_isShared_1538_ = v_isSharedCheck_1565_;
goto v_resetjp_1536_;
}
v_resetjp_1536_:
{
lean_object* v_work_1539_; lean_object* v_allocatedBytes_1540_; lean_object* v_pairs_1541_; lean_object* v_rounds_1542_; lean_object* v_matrixEntries_1543_; lean_object* v_matrixRows_1544_; lean_object* v_matrixCalls_1545_; lean_object* v_peakMatrixRows_1546_; lean_object* v_peakMatrixEntries_1547_; lean_object* v_largestBatch_1548_; lean_object* v_productPairs_1549_; lean_object* v_chainPairs_1550_; lean_object* v_gmPairs_1551_; lean_object* v___x_1553_; uint8_t v_isShared_1554_; uint8_t v_isSharedCheck_1563_; 
v_work_1539_ = lean_ctor_get(v_table_1495_, 8);
v_allocatedBytes_1540_ = lean_ctor_get(v_statistics_1494_, 1);
v_pairs_1541_ = lean_ctor_get(v_statistics_1494_, 2);
v_rounds_1542_ = lean_ctor_get(v_statistics_1494_, 3);
v_matrixEntries_1543_ = lean_ctor_get(v_statistics_1494_, 4);
v_matrixRows_1544_ = lean_ctor_get(v_statistics_1494_, 5);
v_matrixCalls_1545_ = lean_ctor_get(v_statistics_1494_, 6);
v_peakMatrixRows_1546_ = lean_ctor_get(v_statistics_1494_, 7);
v_peakMatrixEntries_1547_ = lean_ctor_get(v_statistics_1494_, 8);
v_largestBatch_1548_ = lean_ctor_get(v_statistics_1494_, 9);
v_productPairs_1549_ = lean_ctor_get(v_statistics_1494_, 10);
v_chainPairs_1550_ = lean_ctor_get(v_statistics_1494_, 11);
v_gmPairs_1551_ = lean_ctor_get(v_statistics_1494_, 12);
v_isSharedCheck_1563_ = !lean_is_exclusive(v_statistics_1494_);
if (v_isSharedCheck_1563_ == 0)
{
lean_object* v_unused_1564_; 
v_unused_1564_ = lean_ctor_get(v_statistics_1494_, 0);
lean_dec(v_unused_1564_);
v___x_1553_ = v_statistics_1494_;
v_isShared_1554_ = v_isSharedCheck_1563_;
goto v_resetjp_1552_;
}
else
{
lean_inc(v_gmPairs_1551_);
lean_inc(v_chainPairs_1550_);
lean_inc(v_productPairs_1549_);
lean_inc(v_largestBatch_1548_);
lean_inc(v_peakMatrixEntries_1547_);
lean_inc(v_peakMatrixRows_1546_);
lean_inc(v_matrixCalls_1545_);
lean_inc(v_matrixRows_1544_);
lean_inc(v_matrixEntries_1543_);
lean_inc(v_rounds_1542_);
lean_inc(v_pairs_1541_);
lean_inc(v_allocatedBytes_1540_);
lean_dec(v_statistics_1494_);
v___x_1553_ = lean_box(0);
v_isShared_1554_ = v_isSharedCheck_1563_;
goto v_resetjp_1552_;
}
v_resetjp_1552_:
{
lean_object* v___x_1556_; 
if (v_isShared_1538_ == 0)
{
v___x_1556_ = v___x_1537_;
goto v_reusejp_1555_;
}
else
{
lean_object* v_reuseFailAlloc_1562_; 
v_reuseFailAlloc_1562_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1562_, 0, v_a_1535_);
v___x_1556_ = v_reuseFailAlloc_1562_;
goto v_reusejp_1555_;
}
v_reusejp_1555_:
{
lean_object* v___x_1558_; 
lean_inc(v_work_1539_);
if (v_isShared_1554_ == 0)
{
lean_ctor_set(v___x_1553_, 0, v_work_1539_);
v___x_1558_ = v___x_1553_;
goto v_reusejp_1557_;
}
else
{
lean_object* v_reuseFailAlloc_1561_; 
v_reuseFailAlloc_1561_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_1561_, 0, v_work_1539_);
lean_ctor_set(v_reuseFailAlloc_1561_, 1, v_allocatedBytes_1540_);
lean_ctor_set(v_reuseFailAlloc_1561_, 2, v_pairs_1541_);
lean_ctor_set(v_reuseFailAlloc_1561_, 3, v_rounds_1542_);
lean_ctor_set(v_reuseFailAlloc_1561_, 4, v_matrixEntries_1543_);
lean_ctor_set(v_reuseFailAlloc_1561_, 5, v_matrixRows_1544_);
lean_ctor_set(v_reuseFailAlloc_1561_, 6, v_matrixCalls_1545_);
lean_ctor_set(v_reuseFailAlloc_1561_, 7, v_peakMatrixRows_1546_);
lean_ctor_set(v_reuseFailAlloc_1561_, 8, v_peakMatrixEntries_1547_);
lean_ctor_set(v_reuseFailAlloc_1561_, 9, v_largestBatch_1548_);
lean_ctor_set(v_reuseFailAlloc_1561_, 10, v_productPairs_1549_);
lean_ctor_set(v_reuseFailAlloc_1561_, 11, v_chainPairs_1550_);
lean_ctor_set(v_reuseFailAlloc_1561_, 12, v_gmPairs_1551_);
v___x_1558_ = v_reuseFailAlloc_1561_;
goto v_reusejp_1557_;
}
v_reusejp_1557_:
{
lean_object* v___x_1559_; lean_object* v___x_1560_; 
v___x_1559_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1559_, 0, v_table_1495_);
lean_ctor_set(v___x_1559_, 1, v___x_1558_);
v___x_1560_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1560_, 0, v___x_1556_);
lean_ctor_set(v___x_1560_, 1, v___x_1559_);
return v___x_1560_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome(lean_object* v_00_u03b1_1566_, lean_object* v_statistics_1567_, lean_object* v_table_1568_, lean_object* v_result_1569_){
_start:
{
lean_object* v___x_1570_; 
v___x_1570_ = lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome___redArg(v_statistics_1567_, v_table_1568_, v_result_1569_);
return v___x_1570_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableResult(lean_object* v_limits_1571_, lean_object* v_operation_1572_, lean_object* v_a_1573_){
_start:
{
lean_object* v_table_1574_; lean_object* v_statistics_1575_; lean_object* v_arity_1576_; uint8_t v_width_1577_; lean_object* v_exponents_1578_; lean_object* v_metadata_1579_; lean_object* v_count_1580_; lean_object* v_workspace_1581_; lean_object* v_buckets_1582_; lean_object* v_products_1583_; lean_object* v_hashBits_1584_; lean_object* v___x_1586_; uint8_t v_isShared_1587_; uint8_t v_isSharedCheck_1601_; 
v_table_1574_ = lean_ctor_get(v_a_1573_, 0);
lean_inc_ref(v_table_1574_);
v_statistics_1575_ = lean_ctor_get(v_a_1573_, 1);
lean_inc_ref(v_statistics_1575_);
lean_dec_ref(v_a_1573_);
v_arity_1576_ = lean_ctor_get(v_table_1574_, 0);
v_width_1577_ = lean_ctor_get_uint8(v_table_1574_, sizeof(void*)*9);
v_exponents_1578_ = lean_ctor_get(v_table_1574_, 1);
v_metadata_1579_ = lean_ctor_get(v_table_1574_, 2);
v_count_1580_ = lean_ctor_get(v_table_1574_, 3);
v_workspace_1581_ = lean_ctor_get(v_table_1574_, 4);
v_buckets_1582_ = lean_ctor_get(v_table_1574_, 5);
v_products_1583_ = lean_ctor_get(v_table_1574_, 6);
v_hashBits_1584_ = lean_ctor_get(v_table_1574_, 7);
v_isSharedCheck_1601_ = !lean_is_exclusive(v_table_1574_);
if (v_isSharedCheck_1601_ == 0)
{
lean_object* v_unused_1602_; 
v_unused_1602_ = lean_ctor_get(v_table_1574_, 8);
lean_dec(v_unused_1602_);
v___x_1586_ = v_table_1574_;
v_isShared_1587_ = v_isSharedCheck_1601_;
goto v_resetjp_1585_;
}
else
{
lean_inc(v_hashBits_1584_);
lean_inc(v_products_1583_);
lean_inc(v_buckets_1582_);
lean_inc(v_workspace_1581_);
lean_inc(v_count_1580_);
lean_inc(v_metadata_1579_);
lean_inc(v_exponents_1578_);
lean_inc(v_arity_1576_);
lean_dec(v_table_1574_);
v___x_1586_ = lean_box(0);
v_isShared_1587_ = v_isSharedCheck_1601_;
goto v_resetjp_1585_;
}
v_resetjp_1585_:
{
lean_object* v_work_1588_; lean_object* v_allocatedBytes_1589_; lean_object* v_work_1590_; lean_object* v_packedBytes_1591_; lean_object* v_monomials_1592_; lean_object* v_table_1594_; 
v_work_1588_ = lean_ctor_get(v_statistics_1575_, 0);
v_allocatedBytes_1589_ = lean_ctor_get(v_statistics_1575_, 1);
v_work_1590_ = lean_ctor_get(v_limits_1571_, 0);
lean_inc(v_work_1590_);
v_packedBytes_1591_ = lean_ctor_get(v_limits_1571_, 1);
lean_inc(v_packedBytes_1591_);
v_monomials_1592_ = lean_ctor_get(v_limits_1571_, 2);
lean_inc(v_monomials_1592_);
lean_dec_ref(v_limits_1571_);
lean_inc(v_work_1588_);
if (v_isShared_1587_ == 0)
{
lean_ctor_set(v___x_1586_, 8, v_work_1588_);
v_table_1594_ = v___x_1586_;
goto v_reusejp_1593_;
}
else
{
lean_object* v_reuseFailAlloc_1600_; 
v_reuseFailAlloc_1600_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_reuseFailAlloc_1600_, 0, v_arity_1576_);
lean_ctor_set(v_reuseFailAlloc_1600_, 1, v_exponents_1578_);
lean_ctor_set(v_reuseFailAlloc_1600_, 2, v_metadata_1579_);
lean_ctor_set(v_reuseFailAlloc_1600_, 3, v_count_1580_);
lean_ctor_set(v_reuseFailAlloc_1600_, 4, v_workspace_1581_);
lean_ctor_set(v_reuseFailAlloc_1600_, 5, v_buckets_1582_);
lean_ctor_set(v_reuseFailAlloc_1600_, 6, v_products_1583_);
lean_ctor_set(v_reuseFailAlloc_1600_, 7, v_hashBits_1584_);
lean_ctor_set(v_reuseFailAlloc_1600_, 8, v_work_1588_);
lean_ctor_set_uint8(v_reuseFailAlloc_1600_, sizeof(void*)*9, v_width_1577_);
v_table_1594_ = v_reuseFailAlloc_1600_;
goto v_reusejp_1593_;
}
v_reusejp_1593_:
{
lean_object* v___x_1595_; lean_object* v_outcome_1596_; lean_object* v_result_1597_; lean_object* v_table_1598_; lean_object* v___x_1599_; 
v___x_1595_ = lean_nat_sub(v_packedBytes_1591_, v_allocatedBytes_1589_);
lean_dec(v_packedBytes_1591_);
v_outcome_1596_ = lean_apply_4(v_operation_1572_, v_table_1594_, v_monomials_1592_, v___x_1595_, v_work_1590_);
v_result_1597_ = lean_ctor_get(v_outcome_1596_, 0);
lean_inc_ref(v_result_1597_);
v_table_1598_ = lean_ctor_get(v_outcome_1596_, 1);
lean_inc_ref(v_table_1598_);
lean_dec_ref(v_outcome_1596_);
v___x_1599_ = lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome___redArg(v_statistics_1575_, v_table_1598_, v_result_1597_);
return v___x_1599_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_products(lean_object* v_limits_1603_, lean_object* v_support_1604_, lean_object* v_multiplier_1605_, lean_object* v_a_1606_){
_start:
{
lean_object* v_table_1607_; lean_object* v_statistics_1608_; lean_object* v_arity_1609_; uint8_t v_width_1610_; lean_object* v_exponents_1611_; lean_object* v_metadata_1612_; lean_object* v_count_1613_; lean_object* v_workspace_1614_; lean_object* v_buckets_1615_; lean_object* v_products_1616_; lean_object* v_hashBits_1617_; lean_object* v___x_1619_; uint8_t v_isShared_1620_; uint8_t v_isSharedCheck_1635_; 
v_table_1607_ = lean_ctor_get(v_a_1606_, 0);
lean_inc_ref(v_table_1607_);
v_statistics_1608_ = lean_ctor_get(v_a_1606_, 1);
lean_inc_ref(v_statistics_1608_);
lean_dec_ref(v_a_1606_);
v_arity_1609_ = lean_ctor_get(v_table_1607_, 0);
v_width_1610_ = lean_ctor_get_uint8(v_table_1607_, sizeof(void*)*9);
v_exponents_1611_ = lean_ctor_get(v_table_1607_, 1);
v_metadata_1612_ = lean_ctor_get(v_table_1607_, 2);
v_count_1613_ = lean_ctor_get(v_table_1607_, 3);
v_workspace_1614_ = lean_ctor_get(v_table_1607_, 4);
v_buckets_1615_ = lean_ctor_get(v_table_1607_, 5);
v_products_1616_ = lean_ctor_get(v_table_1607_, 6);
v_hashBits_1617_ = lean_ctor_get(v_table_1607_, 7);
v_isSharedCheck_1635_ = !lean_is_exclusive(v_table_1607_);
if (v_isSharedCheck_1635_ == 0)
{
lean_object* v_unused_1636_; 
v_unused_1636_ = lean_ctor_get(v_table_1607_, 8);
lean_dec(v_unused_1636_);
v___x_1619_ = v_table_1607_;
v_isShared_1620_ = v_isSharedCheck_1635_;
goto v_resetjp_1618_;
}
else
{
lean_inc(v_hashBits_1617_);
lean_inc(v_products_1616_);
lean_inc(v_buckets_1615_);
lean_inc(v_workspace_1614_);
lean_inc(v_count_1613_);
lean_inc(v_metadata_1612_);
lean_inc(v_exponents_1611_);
lean_inc(v_arity_1609_);
lean_dec(v_table_1607_);
v___x_1619_ = lean_box(0);
v_isShared_1620_ = v_isSharedCheck_1635_;
goto v_resetjp_1618_;
}
v_resetjp_1618_:
{
lean_object* v_work_1621_; lean_object* v_allocatedBytes_1622_; lean_object* v_work_1623_; lean_object* v_packedBytes_1624_; lean_object* v_monomials_1625_; uint8_t v_nativeMonomials_1626_; lean_object* v_table_1628_; 
v_work_1621_ = lean_ctor_get(v_statistics_1608_, 0);
v_allocatedBytes_1622_ = lean_ctor_get(v_statistics_1608_, 1);
v_work_1623_ = lean_ctor_get(v_limits_1603_, 0);
lean_inc(v_work_1623_);
v_packedBytes_1624_ = lean_ctor_get(v_limits_1603_, 1);
lean_inc(v_packedBytes_1624_);
v_monomials_1625_ = lean_ctor_get(v_limits_1603_, 2);
lean_inc(v_monomials_1625_);
v_nativeMonomials_1626_ = lean_ctor_get_uint8(v_limits_1603_, sizeof(void*)*10 + 1);
lean_dec_ref(v_limits_1603_);
lean_inc(v_work_1621_);
if (v_isShared_1620_ == 0)
{
lean_ctor_set(v___x_1619_, 8, v_work_1621_);
v_table_1628_ = v___x_1619_;
goto v_reusejp_1627_;
}
else
{
lean_object* v_reuseFailAlloc_1634_; 
v_reuseFailAlloc_1634_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_reuseFailAlloc_1634_, 0, v_arity_1609_);
lean_ctor_set(v_reuseFailAlloc_1634_, 1, v_exponents_1611_);
lean_ctor_set(v_reuseFailAlloc_1634_, 2, v_metadata_1612_);
lean_ctor_set(v_reuseFailAlloc_1634_, 3, v_count_1613_);
lean_ctor_set(v_reuseFailAlloc_1634_, 4, v_workspace_1614_);
lean_ctor_set(v_reuseFailAlloc_1634_, 5, v_buckets_1615_);
lean_ctor_set(v_reuseFailAlloc_1634_, 6, v_products_1616_);
lean_ctor_set(v_reuseFailAlloc_1634_, 7, v_hashBits_1617_);
lean_ctor_set(v_reuseFailAlloc_1634_, 8, v_work_1621_);
lean_ctor_set_uint8(v_reuseFailAlloc_1634_, sizeof(void*)*9, v_width_1610_);
v_table_1628_ = v_reuseFailAlloc_1634_;
goto v_reusejp_1627_;
}
v_reusejp_1627_:
{
lean_object* v___x_1629_; lean_object* v_outcome_1630_; lean_object* v_result_1631_; lean_object* v_table_1632_; lean_object* v___x_1633_; 
v___x_1629_ = lean_nat_sub(v_packedBytes_1624_, v_allocatedBytes_1622_);
lean_dec(v_packedBytes_1624_);
v_outcome_1630_ = lp_Hex_Hex_Groebner_MonomialTable_mapProducts(v_table_1628_, v_support_1604_, v_multiplier_1605_, v_monomials_1625_, v___x_1629_, v_work_1623_, v_nativeMonomials_1626_);
lean_dec(v___x_1629_);
lean_dec(v_monomials_1625_);
v_result_1631_ = lean_ctor_get(v_outcome_1630_, 0);
lean_inc_ref(v_result_1631_);
v_table_1632_ = lean_ctor_get(v_outcome_1630_, 1);
lean_inc_ref(v_table_1632_);
lean_dec_ref(v_outcome_1630_);
v___x_1633_ = lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableOutcome___redArg(v_statistics_1608_, v_table_1632_, v_result_1631_);
return v___x_1633_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_products___boxed(lean_object* v_limits_1637_, lean_object* v_support_1638_, lean_object* v_multiplier_1639_, lean_object* v_a_1640_){
_start:
{
lean_object* v_res_1641_; 
v_res_1641_ = lp_Hex_Hex_Groebner_Computation_products(v_limits_1637_, v_support_1638_, v_multiplier_1639_, v_a_1640_);
lean_dec_ref(v_support_1638_);
return v_res_1641_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_intern___lam__0(lean_object* v_values_1642_, lean_object* v_table_1643_, lean_object* v_count_1644_, lean_object* v_bytes_1645_, lean_object* v_work_1646_){
_start:
{
lean_object* v___x_1647_; 
v___x_1647_ = lp_Hex_Hex_Groebner_MonomialTable_internOwned(v_table_1643_, v_values_1642_, v_count_1644_, v_bytes_1645_, v_work_1646_);
return v___x_1647_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_intern___lam__0___boxed(lean_object* v_values_1648_, lean_object* v_table_1649_, lean_object* v_count_1650_, lean_object* v_bytes_1651_, lean_object* v_work_1652_){
_start:
{
lean_object* v_res_1653_; 
v_res_1653_ = lp_Hex_Hex_Groebner_Computation_intern___lam__0(v_values_1648_, v_table_1649_, v_count_1650_, v_bytes_1651_, v_work_1652_);
lean_dec(v_bytes_1651_);
lean_dec(v_count_1650_);
lean_dec_ref(v_values_1648_);
return v_res_1653_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_intern(lean_object* v_limits_1654_, lean_object* v_values_1655_, lean_object* v_a_1656_){
_start:
{
lean_object* v___f_1657_; lean_object* v___x_1658_; 
v___f_1657_ = lean_alloc_closure((void*)(lp_Hex_Hex_Groebner_Computation_intern___lam__0___boxed), 5, 1);
lean_closure_set(v___f_1657_, 0, v_values_1655_);
v___x_1658_ = lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableResult(v_limits_1654_, v___f_1657_, v_a_1656_);
return v___x_1658_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_combine___lam__0(lean_object* v_limits_1659_, uint8_t v_operation_1660_, lean_object* v_a_1661_, lean_object* v_b_1662_, lean_object* v_table_1663_, lean_object* v_count_1664_, lean_object* v_bytes_1665_, lean_object* v_work_1666_){
_start:
{
uint8_t v_nativeMonomials_1667_; lean_object* v___x_1668_; 
v_nativeMonomials_1667_ = lean_ctor_get_uint8(v_limits_1659_, sizeof(void*)*10 + 1);
v___x_1668_ = lp_Hex_Hex_Groebner_MonomialTable_combineOwned(v_table_1663_, v_operation_1660_, v_a_1661_, v_b_1662_, v_count_1664_, v_bytes_1665_, v_work_1666_, v_nativeMonomials_1667_);
return v___x_1668_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_combine___lam__0___boxed(lean_object* v_limits_1669_, lean_object* v_operation_1670_, lean_object* v_a_1671_, lean_object* v_b_1672_, lean_object* v_table_1673_, lean_object* v_count_1674_, lean_object* v_bytes_1675_, lean_object* v_work_1676_){
_start:
{
uint8_t v_operation_boxed_1677_; lean_object* v_res_1678_; 
v_operation_boxed_1677_ = lean_unbox(v_operation_1670_);
v_res_1678_ = lp_Hex_Hex_Groebner_Computation_combine___lam__0(v_limits_1669_, v_operation_boxed_1677_, v_a_1671_, v_b_1672_, v_table_1673_, v_count_1674_, v_bytes_1675_, v_work_1676_);
lean_dec(v_bytes_1675_);
lean_dec(v_count_1674_);
lean_dec(v_b_1672_);
lean_dec(v_a_1671_);
lean_dec_ref(v_limits_1669_);
return v_res_1678_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_combine(lean_object* v_limits_1679_, uint8_t v_operation_1680_, lean_object* v_a_1681_, lean_object* v_b_1682_, lean_object* v_a_1683_){
_start:
{
lean_object* v___x_1684_; lean_object* v___f_1685_; lean_object* v___x_1686_; 
v___x_1684_ = lean_box(v_operation_1680_);
lean_inc_ref(v_limits_1679_);
v___f_1685_ = lean_alloc_closure((void*)(lp_Hex_Hex_Groebner_Computation_combine___lam__0___boxed), 8, 4);
lean_closure_set(v___f_1685_, 0, v_limits_1679_);
lean_closure_set(v___f_1685_, 1, v___x_1684_);
lean_closure_set(v___f_1685_, 2, v_a_1681_);
lean_closure_set(v___f_1685_, 3, v_b_1682_);
v___x_1686_ = lp_Hex___private_HexGroebner_Runtime_0__Hex_Groebner_Computation_tableResult(v_limits_1679_, v___f_1685_, v_a_1683_);
return v___x_1686_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_combine___boxed(lean_object* v_limits_1687_, lean_object* v_operation_1688_, lean_object* v_a_1689_, lean_object* v_b_1690_, lean_object* v_a_1691_){
_start:
{
uint8_t v_operation_boxed_1692_; lean_object* v_res_1693_; 
v_operation_boxed_1692_ = lean_unbox(v_operation_1688_);
v_res_1693_ = lp_Hex_Hex_Groebner_Computation_combine(v_limits_1687_, v_operation_boxed_1692_, v_a_1689_, v_b_1690_, v_a_1691_);
return v_res_1693_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0___redArg(lean_object* v_limits_1694_, uint64_t v___x_1695_, uint64_t v_ctx_1696_, lean_object* v_range_1697_, lean_object* v_b_1698_, lean_object* v_i_1699_, lean_object* v___y_1700_){
_start:
{
lean_object* v_a_1702_; lean_object* v_snd_1703_; lean_object* v_stop_1706_; lean_object* v_step_1707_; lean_object* v_a_1709_; lean_object* v_snd_1710_; uint8_t v___x_1713_; 
v_stop_1706_ = lean_ctor_get(v_range_1697_, 1);
v_step_1707_ = lean_ctor_get(v_range_1697_, 2);
v___x_1713_ = lean_nat_dec_lt(v_i_1699_, v_stop_1706_);
if (v___x_1713_ == 0)
{
lean_object* v___x_1714_; lean_object* v___x_1715_; 
lean_dec(v_i_1699_);
v___x_1714_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1714_, 0, v_b_1698_);
v___x_1715_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1715_, 0, v___x_1714_);
lean_ctor_set(v___x_1715_, 1, v___y_1700_);
return v___x_1715_;
}
else
{
lean_object* v_snd_1716_; lean_object* v_fst_1717_; lean_object* v___x_1719_; uint8_t v_isShared_1720_; uint8_t v_isSharedCheck_1838_; 
v_snd_1716_ = lean_ctor_get(v_b_1698_, 1);
v_fst_1717_ = lean_ctor_get(v_b_1698_, 0);
v_isSharedCheck_1838_ = !lean_is_exclusive(v_b_1698_);
if (v_isSharedCheck_1838_ == 0)
{
v___x_1719_ = v_b_1698_;
v_isShared_1720_ = v_isSharedCheck_1838_;
goto v_resetjp_1718_;
}
else
{
lean_inc(v_snd_1716_);
lean_inc(v_fst_1717_);
lean_dec(v_b_1698_);
v___x_1719_ = lean_box(0);
v_isShared_1720_ = v_isSharedCheck_1838_;
goto v_resetjp_1718_;
}
v_resetjp_1718_:
{
lean_object* v_fst_1721_; lean_object* v_snd_1722_; lean_object* v___x_1724_; uint8_t v_isShared_1725_; uint8_t v_isSharedCheck_1837_; 
v_fst_1721_ = lean_ctor_get(v_snd_1716_, 0);
v_snd_1722_ = lean_ctor_get(v_snd_1716_, 1);
v_isSharedCheck_1837_ = !lean_is_exclusive(v_snd_1716_);
if (v_isSharedCheck_1837_ == 0)
{
v___x_1724_ = v_snd_1716_;
v_isShared_1725_ = v_isSharedCheck_1837_;
goto v_resetjp_1723_;
}
else
{
lean_inc(v_snd_1722_);
lean_inc(v_fst_1721_);
lean_dec(v_snd_1716_);
v___x_1724_ = lean_box(0);
v_isShared_1725_ = v_isSharedCheck_1837_;
goto v_resetjp_1723_;
}
v_resetjp_1723_:
{
lean_object* v___x_1726_; uint8_t v___x_1727_; 
v___x_1726_ = lean_unsigned_to_nat(0u);
v___x_1727_ = lean_nat_dec_eq(v_fst_1721_, v___x_1726_);
if (v___x_1727_ == 0)
{
lean_object* v___x_1728_; uint64_t v_result_1730_; lean_object* v___y_1731_; lean_object* v___x_1787_; lean_object* v___x_1788_; uint8_t v___x_1789_; 
v___x_1728_ = lean_unsigned_to_nat(1u);
v___x_1787_ = lean_unsigned_to_nat(2u);
v___x_1788_ = lean_nat_mod(v_fst_1721_, v___x_1787_);
v___x_1789_ = lean_nat_dec_eq(v___x_1788_, v___x_1728_);
lean_dec(v___x_1788_);
if (v___x_1789_ == 0)
{
uint64_t v___x_1790_; 
v___x_1790_ = lean_unbox_uint64(v_snd_1722_);
lean_dec(v_snd_1722_);
v_result_1730_ = v___x_1790_;
v___y_1731_ = v___y_1700_;
goto v___jp_1729_;
}
else
{
lean_object* v_statistics_1791_; lean_object* v_table_1792_; lean_object* v_work_1793_; lean_object* v_allocatedBytes_1794_; lean_object* v_pairs_1795_; lean_object* v_rounds_1796_; lean_object* v_matrixEntries_1797_; lean_object* v_matrixRows_1798_; lean_object* v_matrixCalls_1799_; lean_object* v_peakMatrixRows_1800_; lean_object* v_peakMatrixEntries_1801_; lean_object* v_largestBatch_1802_; lean_object* v_productPairs_1803_; lean_object* v_chainPairs_1804_; lean_object* v_gmPairs_1805_; lean_object* v___x_1807_; uint8_t v_isShared_1808_; uint8_t v_isSharedCheck_1828_; 
v_statistics_1791_ = lean_ctor_get(v___y_1700_, 1);
lean_inc_ref(v_statistics_1791_);
v_table_1792_ = lean_ctor_get(v___y_1700_, 0);
v_work_1793_ = lean_ctor_get(v_statistics_1791_, 0);
v_allocatedBytes_1794_ = lean_ctor_get(v_statistics_1791_, 1);
v_pairs_1795_ = lean_ctor_get(v_statistics_1791_, 2);
v_rounds_1796_ = lean_ctor_get(v_statistics_1791_, 3);
v_matrixEntries_1797_ = lean_ctor_get(v_statistics_1791_, 4);
v_matrixRows_1798_ = lean_ctor_get(v_statistics_1791_, 5);
v_matrixCalls_1799_ = lean_ctor_get(v_statistics_1791_, 6);
v_peakMatrixRows_1800_ = lean_ctor_get(v_statistics_1791_, 7);
v_peakMatrixEntries_1801_ = lean_ctor_get(v_statistics_1791_, 8);
v_largestBatch_1802_ = lean_ctor_get(v_statistics_1791_, 9);
v_productPairs_1803_ = lean_ctor_get(v_statistics_1791_, 10);
v_chainPairs_1804_ = lean_ctor_get(v_statistics_1791_, 11);
v_gmPairs_1805_ = lean_ctor_get(v_statistics_1791_, 12);
v_isSharedCheck_1828_ = !lean_is_exclusive(v_statistics_1791_);
if (v_isSharedCheck_1828_ == 0)
{
v___x_1807_ = v_statistics_1791_;
v_isShared_1808_ = v_isSharedCheck_1828_;
goto v_resetjp_1806_;
}
else
{
lean_inc(v_gmPairs_1805_);
lean_inc(v_chainPairs_1804_);
lean_inc(v_productPairs_1803_);
lean_inc(v_largestBatch_1802_);
lean_inc(v_peakMatrixEntries_1801_);
lean_inc(v_peakMatrixRows_1800_);
lean_inc(v_matrixCalls_1799_);
lean_inc(v_matrixRows_1798_);
lean_inc(v_matrixEntries_1797_);
lean_inc(v_rounds_1796_);
lean_inc(v_pairs_1795_);
lean_inc(v_allocatedBytes_1794_);
lean_inc(v_work_1793_);
lean_dec(v_statistics_1791_);
v___x_1807_ = lean_box(0);
v_isShared_1808_ = v_isSharedCheck_1828_;
goto v_resetjp_1806_;
}
v_resetjp_1806_:
{
lean_object* v_work_1809_; lean_object* v_work_1810_; uint8_t v___x_1811_; 
v_work_1809_ = lean_ctor_get(v_limits_1694_, 0);
v_work_1810_ = lean_nat_add(v_work_1793_, v___x_1728_);
lean_dec(v_work_1793_);
v___x_1811_ = lean_nat_dec_lt(v_work_1809_, v_work_1810_);
if (v___x_1811_ == 0)
{
lean_object* v___x_1813_; uint8_t v_isShared_1814_; uint8_t v_isSharedCheck_1824_; 
lean_inc_ref(v_table_1792_);
v_isSharedCheck_1824_ = !lean_is_exclusive(v___y_1700_);
if (v_isSharedCheck_1824_ == 0)
{
lean_object* v_unused_1825_; lean_object* v_unused_1826_; 
v_unused_1825_ = lean_ctor_get(v___y_1700_, 1);
lean_dec(v_unused_1825_);
v_unused_1826_ = lean_ctor_get(v___y_1700_, 0);
lean_dec(v_unused_1826_);
v___x_1813_ = v___y_1700_;
v_isShared_1814_ = v_isSharedCheck_1824_;
goto v_resetjp_1812_;
}
else
{
lean_dec(v___y_1700_);
v___x_1813_ = lean_box(0);
v_isShared_1814_ = v_isSharedCheck_1824_;
goto v_resetjp_1812_;
}
v_resetjp_1812_:
{
lean_object* v___x_1816_; 
if (v_isShared_1808_ == 0)
{
lean_ctor_set(v___x_1807_, 0, v_work_1810_);
v___x_1816_ = v___x_1807_;
goto v_reusejp_1815_;
}
else
{
lean_object* v_reuseFailAlloc_1823_; 
v_reuseFailAlloc_1823_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_1823_, 0, v_work_1810_);
lean_ctor_set(v_reuseFailAlloc_1823_, 1, v_allocatedBytes_1794_);
lean_ctor_set(v_reuseFailAlloc_1823_, 2, v_pairs_1795_);
lean_ctor_set(v_reuseFailAlloc_1823_, 3, v_rounds_1796_);
lean_ctor_set(v_reuseFailAlloc_1823_, 4, v_matrixEntries_1797_);
lean_ctor_set(v_reuseFailAlloc_1823_, 5, v_matrixRows_1798_);
lean_ctor_set(v_reuseFailAlloc_1823_, 6, v_matrixCalls_1799_);
lean_ctor_set(v_reuseFailAlloc_1823_, 7, v_peakMatrixRows_1800_);
lean_ctor_set(v_reuseFailAlloc_1823_, 8, v_peakMatrixEntries_1801_);
lean_ctor_set(v_reuseFailAlloc_1823_, 9, v_largestBatch_1802_);
lean_ctor_set(v_reuseFailAlloc_1823_, 10, v_productPairs_1803_);
lean_ctor_set(v_reuseFailAlloc_1823_, 11, v_chainPairs_1804_);
lean_ctor_set(v_reuseFailAlloc_1823_, 12, v_gmPairs_1805_);
v___x_1816_ = v_reuseFailAlloc_1823_;
goto v_reusejp_1815_;
}
v_reusejp_1815_:
{
lean_object* v___x_1818_; 
if (v_isShared_1814_ == 0)
{
lean_ctor_set(v___x_1813_, 1, v___x_1816_);
v___x_1818_ = v___x_1813_;
goto v_reusejp_1817_;
}
else
{
lean_object* v_reuseFailAlloc_1822_; 
v_reuseFailAlloc_1822_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1822_, 0, v_table_1792_);
lean_ctor_set(v_reuseFailAlloc_1822_, 1, v___x_1816_);
v___x_1818_ = v_reuseFailAlloc_1822_;
goto v_reusejp_1817_;
}
v_reusejp_1817_:
{
uint64_t v___x_1819_; uint64_t v___x_1820_; uint64_t v___x_1821_; 
v___x_1819_ = lean_unbox_uint64(v_snd_1722_);
lean_dec(v_snd_1722_);
v___x_1820_ = lean_unbox_uint64(v_fst_1717_);
v___x_1821_ = lp_Hex_BarrettCtx_mulMod(v___x_1695_, v_ctx_1696_, v___x_1819_, v___x_1820_);
v_result_1730_ = v___x_1821_;
v___y_1731_ = v___x_1818_;
goto v___jp_1729_;
}
}
}
}
else
{
lean_object* v___x_1827_; 
lean_dec(v_work_1810_);
lean_del_object(v___x_1807_);
lean_dec(v_gmPairs_1805_);
lean_dec(v_chainPairs_1804_);
lean_dec(v_productPairs_1803_);
lean_dec(v_largestBatch_1802_);
lean_dec(v_peakMatrixEntries_1801_);
lean_dec(v_peakMatrixRows_1800_);
lean_dec(v_matrixCalls_1799_);
lean_dec(v_matrixRows_1798_);
lean_dec(v_matrixEntries_1797_);
lean_dec(v_rounds_1796_);
lean_dec(v_pairs_1795_);
lean_dec(v_allocatedBytes_1794_);
lean_del_object(v___x_1724_);
lean_dec(v_snd_1722_);
lean_dec(v_fst_1721_);
lean_del_object(v___x_1719_);
lean_dec(v_fst_1717_);
lean_dec(v_i_1699_);
v___x_1827_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_spend___closed__1));
v_a_1702_ = v___x_1827_;
v_snd_1703_ = v___y_1700_;
goto v___jp_1701_;
}
}
}
v___jp_1729_:
{
lean_object* v___x_1732_; uint8_t v___x_1733_; 
v___x_1732_ = lean_nat_shiftr(v_fst_1721_, v___x_1728_);
lean_dec(v_fst_1721_);
v___x_1733_ = lean_nat_dec_lt(v___x_1726_, v___x_1732_);
if (v___x_1733_ == 0)
{
lean_object* v___x_1734_; lean_object* v___x_1736_; 
v___x_1734_ = lean_box_uint64(v_result_1730_);
if (v_isShared_1725_ == 0)
{
lean_ctor_set(v___x_1724_, 1, v___x_1734_);
lean_ctor_set(v___x_1724_, 0, v___x_1732_);
v___x_1736_ = v___x_1724_;
goto v_reusejp_1735_;
}
else
{
lean_object* v_reuseFailAlloc_1740_; 
v_reuseFailAlloc_1740_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1740_, 0, v___x_1732_);
lean_ctor_set(v_reuseFailAlloc_1740_, 1, v___x_1734_);
v___x_1736_ = v_reuseFailAlloc_1740_;
goto v_reusejp_1735_;
}
v_reusejp_1735_:
{
lean_object* v___x_1738_; 
if (v_isShared_1720_ == 0)
{
lean_ctor_set(v___x_1719_, 1, v___x_1736_);
v___x_1738_ = v___x_1719_;
goto v_reusejp_1737_;
}
else
{
lean_object* v_reuseFailAlloc_1739_; 
v_reuseFailAlloc_1739_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1739_, 0, v_fst_1717_);
lean_ctor_set(v_reuseFailAlloc_1739_, 1, v___x_1736_);
v___x_1738_ = v_reuseFailAlloc_1739_;
goto v_reusejp_1737_;
}
v_reusejp_1737_:
{
v_a_1709_ = v___x_1738_;
v_snd_1710_ = v___y_1731_;
goto v___jp_1708_;
}
}
}
else
{
lean_object* v_statistics_1741_; lean_object* v_table_1742_; lean_object* v_work_1743_; lean_object* v_allocatedBytes_1744_; lean_object* v_pairs_1745_; lean_object* v_rounds_1746_; lean_object* v_matrixEntries_1747_; lean_object* v_matrixRows_1748_; lean_object* v_matrixCalls_1749_; lean_object* v_peakMatrixRows_1750_; lean_object* v_peakMatrixEntries_1751_; lean_object* v_largestBatch_1752_; lean_object* v_productPairs_1753_; lean_object* v_chainPairs_1754_; lean_object* v_gmPairs_1755_; lean_object* v___x_1757_; uint8_t v_isShared_1758_; uint8_t v_isSharedCheck_1786_; 
v_statistics_1741_ = lean_ctor_get(v___y_1731_, 1);
lean_inc_ref(v_statistics_1741_);
v_table_1742_ = lean_ctor_get(v___y_1731_, 0);
v_work_1743_ = lean_ctor_get(v_statistics_1741_, 0);
v_allocatedBytes_1744_ = lean_ctor_get(v_statistics_1741_, 1);
v_pairs_1745_ = lean_ctor_get(v_statistics_1741_, 2);
v_rounds_1746_ = lean_ctor_get(v_statistics_1741_, 3);
v_matrixEntries_1747_ = lean_ctor_get(v_statistics_1741_, 4);
v_matrixRows_1748_ = lean_ctor_get(v_statistics_1741_, 5);
v_matrixCalls_1749_ = lean_ctor_get(v_statistics_1741_, 6);
v_peakMatrixRows_1750_ = lean_ctor_get(v_statistics_1741_, 7);
v_peakMatrixEntries_1751_ = lean_ctor_get(v_statistics_1741_, 8);
v_largestBatch_1752_ = lean_ctor_get(v_statistics_1741_, 9);
v_productPairs_1753_ = lean_ctor_get(v_statistics_1741_, 10);
v_chainPairs_1754_ = lean_ctor_get(v_statistics_1741_, 11);
v_gmPairs_1755_ = lean_ctor_get(v_statistics_1741_, 12);
v_isSharedCheck_1786_ = !lean_is_exclusive(v_statistics_1741_);
if (v_isSharedCheck_1786_ == 0)
{
v___x_1757_ = v_statistics_1741_;
v_isShared_1758_ = v_isSharedCheck_1786_;
goto v_resetjp_1756_;
}
else
{
lean_inc(v_gmPairs_1755_);
lean_inc(v_chainPairs_1754_);
lean_inc(v_productPairs_1753_);
lean_inc(v_largestBatch_1752_);
lean_inc(v_peakMatrixEntries_1751_);
lean_inc(v_peakMatrixRows_1750_);
lean_inc(v_matrixCalls_1749_);
lean_inc(v_matrixRows_1748_);
lean_inc(v_matrixEntries_1747_);
lean_inc(v_rounds_1746_);
lean_inc(v_pairs_1745_);
lean_inc(v_allocatedBytes_1744_);
lean_inc(v_work_1743_);
lean_dec(v_statistics_1741_);
v___x_1757_ = lean_box(0);
v_isShared_1758_ = v_isSharedCheck_1786_;
goto v_resetjp_1756_;
}
v_resetjp_1756_:
{
lean_object* v_work_1759_; lean_object* v_work_1760_; uint8_t v___x_1761_; 
v_work_1759_ = lean_ctor_get(v_limits_1694_, 0);
v_work_1760_ = lean_nat_add(v_work_1743_, v___x_1728_);
lean_dec(v_work_1743_);
v___x_1761_ = lean_nat_dec_lt(v_work_1759_, v_work_1760_);
if (v___x_1761_ == 0)
{
lean_object* v___x_1763_; uint8_t v_isShared_1764_; uint8_t v_isSharedCheck_1782_; 
lean_inc_ref(v_table_1742_);
v_isSharedCheck_1782_ = !lean_is_exclusive(v___y_1731_);
if (v_isSharedCheck_1782_ == 0)
{
lean_object* v_unused_1783_; lean_object* v_unused_1784_; 
v_unused_1783_ = lean_ctor_get(v___y_1731_, 1);
lean_dec(v_unused_1783_);
v_unused_1784_ = lean_ctor_get(v___y_1731_, 0);
lean_dec(v_unused_1784_);
v___x_1763_ = v___y_1731_;
v_isShared_1764_ = v_isSharedCheck_1782_;
goto v_resetjp_1762_;
}
else
{
lean_dec(v___y_1731_);
v___x_1763_ = lean_box(0);
v_isShared_1764_ = v_isSharedCheck_1782_;
goto v_resetjp_1762_;
}
v_resetjp_1762_:
{
lean_object* v___x_1766_; 
if (v_isShared_1758_ == 0)
{
lean_ctor_set(v___x_1757_, 0, v_work_1760_);
v___x_1766_ = v___x_1757_;
goto v_reusejp_1765_;
}
else
{
lean_object* v_reuseFailAlloc_1781_; 
v_reuseFailAlloc_1781_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_1781_, 0, v_work_1760_);
lean_ctor_set(v_reuseFailAlloc_1781_, 1, v_allocatedBytes_1744_);
lean_ctor_set(v_reuseFailAlloc_1781_, 2, v_pairs_1745_);
lean_ctor_set(v_reuseFailAlloc_1781_, 3, v_rounds_1746_);
lean_ctor_set(v_reuseFailAlloc_1781_, 4, v_matrixEntries_1747_);
lean_ctor_set(v_reuseFailAlloc_1781_, 5, v_matrixRows_1748_);
lean_ctor_set(v_reuseFailAlloc_1781_, 6, v_matrixCalls_1749_);
lean_ctor_set(v_reuseFailAlloc_1781_, 7, v_peakMatrixRows_1750_);
lean_ctor_set(v_reuseFailAlloc_1781_, 8, v_peakMatrixEntries_1751_);
lean_ctor_set(v_reuseFailAlloc_1781_, 9, v_largestBatch_1752_);
lean_ctor_set(v_reuseFailAlloc_1781_, 10, v_productPairs_1753_);
lean_ctor_set(v_reuseFailAlloc_1781_, 11, v_chainPairs_1754_);
lean_ctor_set(v_reuseFailAlloc_1781_, 12, v_gmPairs_1755_);
v___x_1766_ = v_reuseFailAlloc_1781_;
goto v_reusejp_1765_;
}
v_reusejp_1765_:
{
lean_object* v___x_1768_; 
if (v_isShared_1764_ == 0)
{
lean_ctor_set(v___x_1763_, 1, v___x_1766_);
v___x_1768_ = v___x_1763_;
goto v_reusejp_1767_;
}
else
{
lean_object* v_reuseFailAlloc_1780_; 
v_reuseFailAlloc_1780_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1780_, 0, v_table_1742_);
lean_ctor_set(v_reuseFailAlloc_1780_, 1, v___x_1766_);
v___x_1768_ = v_reuseFailAlloc_1780_;
goto v_reusejp_1767_;
}
v_reusejp_1767_:
{
uint64_t v___x_1769_; uint64_t v___x_1770_; uint64_t v___x_1771_; lean_object* v___x_1772_; lean_object* v___x_1774_; 
v___x_1769_ = lean_unbox_uint64(v_fst_1717_);
v___x_1770_ = lean_unbox_uint64(v_fst_1717_);
lean_dec(v_fst_1717_);
v___x_1771_ = lp_Hex_BarrettCtx_mulMod(v___x_1695_, v_ctx_1696_, v___x_1769_, v___x_1770_);
v___x_1772_ = lean_box_uint64(v_result_1730_);
if (v_isShared_1725_ == 0)
{
lean_ctor_set(v___x_1724_, 1, v___x_1772_);
lean_ctor_set(v___x_1724_, 0, v___x_1732_);
v___x_1774_ = v___x_1724_;
goto v_reusejp_1773_;
}
else
{
lean_object* v_reuseFailAlloc_1779_; 
v_reuseFailAlloc_1779_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1779_, 0, v___x_1732_);
lean_ctor_set(v_reuseFailAlloc_1779_, 1, v___x_1772_);
v___x_1774_ = v_reuseFailAlloc_1779_;
goto v_reusejp_1773_;
}
v_reusejp_1773_:
{
lean_object* v___x_1775_; lean_object* v___x_1777_; 
v___x_1775_ = lean_box_uint64(v___x_1771_);
if (v_isShared_1720_ == 0)
{
lean_ctor_set(v___x_1719_, 1, v___x_1774_);
lean_ctor_set(v___x_1719_, 0, v___x_1775_);
v___x_1777_ = v___x_1719_;
goto v_reusejp_1776_;
}
else
{
lean_object* v_reuseFailAlloc_1778_; 
v_reuseFailAlloc_1778_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1778_, 0, v___x_1775_);
lean_ctor_set(v_reuseFailAlloc_1778_, 1, v___x_1774_);
v___x_1777_ = v_reuseFailAlloc_1778_;
goto v_reusejp_1776_;
}
v_reusejp_1776_:
{
v_a_1709_ = v___x_1777_;
v_snd_1710_ = v___x_1768_;
goto v___jp_1708_;
}
}
}
}
}
}
else
{
lean_object* v___x_1785_; 
lean_dec(v_work_1760_);
lean_del_object(v___x_1757_);
lean_dec(v_gmPairs_1755_);
lean_dec(v_chainPairs_1754_);
lean_dec(v_productPairs_1753_);
lean_dec(v_largestBatch_1752_);
lean_dec(v_peakMatrixEntries_1751_);
lean_dec(v_peakMatrixRows_1750_);
lean_dec(v_matrixCalls_1749_);
lean_dec(v_matrixRows_1748_);
lean_dec(v_matrixEntries_1747_);
lean_dec(v_rounds_1746_);
lean_dec(v_pairs_1745_);
lean_dec(v_allocatedBytes_1744_);
lean_dec(v___x_1732_);
lean_del_object(v___x_1724_);
lean_del_object(v___x_1719_);
lean_dec(v_fst_1717_);
lean_dec(v_i_1699_);
v___x_1785_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_spend___closed__1));
v_a_1702_ = v___x_1785_;
v_snd_1703_ = v___y_1731_;
goto v___jp_1701_;
}
}
}
}
}
else
{
lean_object* v___x_1830_; 
lean_dec(v_i_1699_);
if (v_isShared_1725_ == 0)
{
v___x_1830_ = v___x_1724_;
goto v_reusejp_1829_;
}
else
{
lean_object* v_reuseFailAlloc_1836_; 
v_reuseFailAlloc_1836_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1836_, 0, v_fst_1721_);
lean_ctor_set(v_reuseFailAlloc_1836_, 1, v_snd_1722_);
v___x_1830_ = v_reuseFailAlloc_1836_;
goto v_reusejp_1829_;
}
v_reusejp_1829_:
{
lean_object* v___x_1832_; 
if (v_isShared_1720_ == 0)
{
lean_ctor_set(v___x_1719_, 1, v___x_1830_);
v___x_1832_ = v___x_1719_;
goto v_reusejp_1831_;
}
else
{
lean_object* v_reuseFailAlloc_1835_; 
v_reuseFailAlloc_1835_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1835_, 0, v_fst_1717_);
lean_ctor_set(v_reuseFailAlloc_1835_, 1, v___x_1830_);
v___x_1832_ = v_reuseFailAlloc_1835_;
goto v_reusejp_1831_;
}
v_reusejp_1831_:
{
lean_object* v___x_1833_; lean_object* v___x_1834_; 
v___x_1833_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1833_, 0, v___x_1832_);
v___x_1834_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1834_, 0, v___x_1833_);
lean_ctor_set(v___x_1834_, 1, v___y_1700_);
return v___x_1834_;
}
}
}
}
}
}
v___jp_1701_:
{
lean_object* v___x_1704_; lean_object* v___x_1705_; 
lean_inc_ref(v_a_1702_);
v___x_1704_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1704_, 0, v_a_1702_);
v___x_1705_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1705_, 0, v___x_1704_);
lean_ctor_set(v___x_1705_, 1, v_snd_1703_);
return v___x_1705_;
}
v___jp_1708_:
{
lean_object* v___x_1711_; 
v___x_1711_ = lean_nat_add(v_i_1699_, v_step_1707_);
lean_dec(v_i_1699_);
v_b_1698_ = v_a_1709_;
v_i_1699_ = v___x_1711_;
v___y_1700_ = v_snd_1710_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0___redArg___boxed(lean_object* v_limits_1839_, lean_object* v___x_1840_, lean_object* v_ctx_1841_, lean_object* v_range_1842_, lean_object* v_b_1843_, lean_object* v_i_1844_, lean_object* v___y_1845_){
_start:
{
uint64_t v___x_4107__boxed_1846_; uint64_t v_ctx_boxed_1847_; lean_object* v_res_1848_; 
v___x_4107__boxed_1846_ = lean_unbox_uint64(v___x_1840_);
lean_dec_ref(v___x_1840_);
v_ctx_boxed_1847_ = lean_unbox_uint64(v_ctx_1841_);
lean_dec_ref(v_ctx_1841_);
v_res_1848_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0___redArg(v_limits_1839_, v___x_4107__boxed_1846_, v_ctx_boxed_1847_, v_range_1842_, v_b_1843_, v_i_1844_, v___y_1845_);
lean_dec_ref(v_range_1842_);
lean_dec_ref(v_limits_1839_);
return v_res_1848_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_inverse(uint64_t v_field_1855_, lean_object* v_limits_1856_, uint64_t v_a_1857_, lean_object* v_a_1858_){
_start:
{
uint64_t v_result_1859_; uint8_t v___x_1860_; 
v_result_1859_ = 1ULL;
v___x_1860_ = lean_uint64_dec_eq(v_a_1857_, v_result_1859_);
if (v___x_1860_ == 0)
{
lean_object* v___x_1861_; uint64_t v_ctx_1862_; lean_object* v___x_1863_; lean_object* v___x_1864_; lean_object* v_exponent_1865_; lean_object* v___x_1866_; lean_object* v___x_1867_; lean_object* v___x_1868_; lean_object* v___x_1869_; lean_object* v___x_1870_; lean_object* v___x_1871_; lean_object* v___x_1872_; lean_object* v___x_1873_; lean_object* v___x_1874_; lean_object* v_fst_1875_; 
v___x_1861_ = lean_unsigned_to_nat(1u);
v_ctx_1862_ = lp_Hex_BarrettCtx_mk___redArg(v_field_1855_);
v___x_1863_ = lean_uint64_to_nat(v_field_1855_);
v___x_1864_ = lean_unsigned_to_nat(2u);
v_exponent_1865_ = lean_nat_sub(v___x_1863_, v___x_1864_);
v___x_1866_ = lean_unsigned_to_nat(0u);
v___x_1867_ = lean_nat_log2(v___x_1863_);
lean_dec(v___x_1863_);
v___x_1868_ = lean_nat_add(v___x_1867_, v___x_1861_);
lean_dec(v___x_1867_);
v___x_1869_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1869_, 0, v___x_1866_);
lean_ctor_set(v___x_1869_, 1, v___x_1868_);
lean_ctor_set(v___x_1869_, 2, v___x_1861_);
v___x_1870_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_inverse___closed__1___boxed__const__1));
v___x_1871_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1871_, 0, v_exponent_1865_);
lean_ctor_set(v___x_1871_, 1, v___x_1870_);
v___x_1872_ = lean_box_uint64(v_a_1857_);
v___x_1873_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1873_, 0, v___x_1872_);
lean_ctor_set(v___x_1873_, 1, v___x_1871_);
v___x_1874_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0___redArg(v_limits_1856_, v_field_1855_, v_ctx_1862_, v___x_1869_, v___x_1873_, v___x_1866_, v_a_1858_);
lean_dec_ref_known(v___x_1869_, 3);
v_fst_1875_ = lean_ctor_get(v___x_1874_, 0);
lean_inc(v_fst_1875_);
if (lean_obj_tag(v_fst_1875_) == 0)
{
lean_object* v_snd_1876_; lean_object* v___x_1878_; uint8_t v_isShared_1879_; uint8_t v_isSharedCheck_1884_; 
lean_dec_ref_known(v_fst_1875_, 1);
v_snd_1876_ = lean_ctor_get(v___x_1874_, 1);
v_isSharedCheck_1884_ = !lean_is_exclusive(v___x_1874_);
if (v_isSharedCheck_1884_ == 0)
{
lean_object* v_unused_1885_; 
v_unused_1885_ = lean_ctor_get(v___x_1874_, 0);
lean_dec(v_unused_1885_);
v___x_1878_ = v___x_1874_;
v_isShared_1879_ = v_isSharedCheck_1884_;
goto v_resetjp_1877_;
}
else
{
lean_inc(v_snd_1876_);
lean_dec(v___x_1874_);
v___x_1878_ = lean_box(0);
v_isShared_1879_ = v_isSharedCheck_1884_;
goto v_resetjp_1877_;
}
v_resetjp_1877_:
{
lean_object* v___x_1880_; lean_object* v___x_1882_; 
v___x_1880_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_inverse___closed__0));
if (v_isShared_1879_ == 0)
{
lean_ctor_set(v___x_1878_, 0, v___x_1880_);
v___x_1882_ = v___x_1878_;
goto v_reusejp_1881_;
}
else
{
lean_object* v_reuseFailAlloc_1883_; 
v_reuseFailAlloc_1883_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1883_, 0, v___x_1880_);
lean_ctor_set(v_reuseFailAlloc_1883_, 1, v_snd_1876_);
v___x_1882_ = v_reuseFailAlloc_1883_;
goto v_reusejp_1881_;
}
v_reusejp_1881_:
{
return v___x_1882_;
}
}
}
else
{
lean_object* v_a_1886_; lean_object* v___x_1888_; uint8_t v_isShared_1889_; uint8_t v_isSharedCheck_1904_; 
v_a_1886_ = lean_ctor_get(v_fst_1875_, 0);
v_isSharedCheck_1904_ = !lean_is_exclusive(v_fst_1875_);
if (v_isSharedCheck_1904_ == 0)
{
v___x_1888_ = v_fst_1875_;
v_isShared_1889_ = v_isSharedCheck_1904_;
goto v_resetjp_1887_;
}
else
{
lean_inc(v_a_1886_);
lean_dec(v_fst_1875_);
v___x_1888_ = lean_box(0);
v_isShared_1889_ = v_isSharedCheck_1904_;
goto v_resetjp_1887_;
}
v_resetjp_1887_:
{
lean_object* v_snd_1890_; lean_object* v_snd_1891_; lean_object* v_snd_1892_; lean_object* v___x_1894_; uint8_t v_isShared_1895_; uint8_t v_isSharedCheck_1902_; 
v_snd_1890_ = lean_ctor_get(v_a_1886_, 1);
lean_inc(v_snd_1890_);
lean_dec(v_a_1886_);
v_snd_1891_ = lean_ctor_get(v___x_1874_, 1);
lean_inc(v_snd_1891_);
lean_dec_ref(v___x_1874_);
v_snd_1892_ = lean_ctor_get(v_snd_1890_, 1);
v_isSharedCheck_1902_ = !lean_is_exclusive(v_snd_1890_);
if (v_isSharedCheck_1902_ == 0)
{
lean_object* v_unused_1903_; 
v_unused_1903_ = lean_ctor_get(v_snd_1890_, 0);
lean_dec(v_unused_1903_);
v___x_1894_ = v_snd_1890_;
v_isShared_1895_ = v_isSharedCheck_1902_;
goto v_resetjp_1893_;
}
else
{
lean_inc(v_snd_1892_);
lean_dec(v_snd_1890_);
v___x_1894_ = lean_box(0);
v_isShared_1895_ = v_isSharedCheck_1902_;
goto v_resetjp_1893_;
}
v_resetjp_1893_:
{
lean_object* v___x_1897_; 
if (v_isShared_1889_ == 0)
{
lean_ctor_set(v___x_1888_, 0, v_snd_1892_);
v___x_1897_ = v___x_1888_;
goto v_reusejp_1896_;
}
else
{
lean_object* v_reuseFailAlloc_1901_; 
v_reuseFailAlloc_1901_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1901_, 0, v_snd_1892_);
v___x_1897_ = v_reuseFailAlloc_1901_;
goto v_reusejp_1896_;
}
v_reusejp_1896_:
{
lean_object* v___x_1899_; 
if (v_isShared_1895_ == 0)
{
lean_ctor_set(v___x_1894_, 1, v_snd_1891_);
lean_ctor_set(v___x_1894_, 0, v___x_1897_);
v___x_1899_ = v___x_1894_;
goto v_reusejp_1898_;
}
else
{
lean_object* v_reuseFailAlloc_1900_; 
v_reuseFailAlloc_1900_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1900_, 0, v___x_1897_);
lean_ctor_set(v_reuseFailAlloc_1900_, 1, v_snd_1891_);
v___x_1899_ = v_reuseFailAlloc_1900_;
goto v_reusejp_1898_;
}
v_reusejp_1898_:
{
return v___x_1899_;
}
}
}
}
}
}
else
{
lean_object* v___x_1905_; lean_object* v___x_1906_; 
v___x_1905_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_inverse___closed__1));
v___x_1906_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1906_, 0, v___x_1905_);
lean_ctor_set(v___x_1906_, 1, v_a_1858_);
return v___x_1906_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_inverse___boxed(lean_object* v_field_1907_, lean_object* v_limits_1908_, lean_object* v_a_1909_, lean_object* v_a_1910_){
_start:
{
uint64_t v_field_boxed_1911_; uint64_t v_a_boxed_1912_; lean_object* v_res_1913_; 
v_field_boxed_1911_ = lean_unbox_uint64(v_field_1907_);
lean_dec_ref(v_field_1907_);
v_a_boxed_1912_ = lean_unbox_uint64(v_a_1909_);
lean_dec_ref(v_a_1909_);
v_res_1913_ = lp_Hex_Hex_Groebner_Computation_inverse(v_field_boxed_1911_, v_limits_1908_, v_a_boxed_1912_, v_a_1910_);
lean_dec_ref(v_limits_1908_);
return v_res_1913_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0(lean_object* v_limits_1914_, uint64_t v___x_1915_, uint64_t v_ctx_1916_, lean_object* v_range_1917_, lean_object* v_b_1918_, lean_object* v_i_1919_, lean_object* v_hs_1920_, lean_object* v_hl_1921_, lean_object* v___y_1922_){
_start:
{
lean_object* v___x_1923_; 
v___x_1923_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0___redArg(v_limits_1914_, v___x_1915_, v_ctx_1916_, v_range_1917_, v_b_1918_, v_i_1919_, v___y_1922_);
return v___x_1923_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0___boxed(lean_object* v_limits_1924_, lean_object* v___x_1925_, lean_object* v_ctx_1926_, lean_object* v_range_1927_, lean_object* v_b_1928_, lean_object* v_i_1929_, lean_object* v_hs_1930_, lean_object* v_hl_1931_, lean_object* v___y_1932_){
_start:
{
uint64_t v___x_4420__boxed_1933_; uint64_t v_ctx_boxed_1934_; lean_object* v_res_1935_; 
v___x_4420__boxed_1933_ = lean_unbox_uint64(v___x_1925_);
lean_dec_ref(v___x_1925_);
v_ctx_boxed_1934_ = lean_unbox_uint64(v_ctx_1926_);
lean_dec_ref(v_ctx_1926_);
v_res_1935_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_inverse_spec__0(v_limits_1924_, v___x_4420__boxed_1933_, v_ctx_boxed_1934_, v_range_1927_, v_b_1928_, v_i_1929_, v_hs_1930_, v_hl_1931_, v___y_1932_);
lean_dec_ref(v_range_1927_);
lean_dec_ref(v_limits_1924_);
return v_res_1935_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg___closed__0(void){
_start:
{
uint8_t v___x_1936_; lean_object* v___x_1937_; 
v___x_1936_ = 0;
v___x_1937_ = l_Ordering_ctorIdx(v___x_1936_);
return v___x_1937_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg(lean_object* v___x_1938_, lean_object* v___y_1939_, lean_object* v___y_1940_, lean_object* v_context_1941_, lean_object* v_table_1942_, lean_object* v_range_1943_, lean_object* v_b_1944_, lean_object* v_i_1945_, lean_object* v___y_1946_){
_start:
{
lean_object* v_stop_1947_; lean_object* v_step_1948_; lean_object* v_a_1950_; lean_object* v_snd_1951_; uint8_t v___x_1954_; 
v_stop_1947_ = lean_ctor_get(v_range_1943_, 1);
v_step_1948_ = lean_ctor_get(v_range_1943_, 2);
v___x_1954_ = lean_nat_dec_lt(v_i_1945_, v_stop_1947_);
if (v___x_1954_ == 0)
{
lean_object* v___x_1955_; lean_object* v___x_1956_; 
lean_dec(v_i_1945_);
v___x_1955_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1955_, 0, v_b_1944_);
v___x_1956_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1956_, 0, v___x_1955_);
lean_ctor_set(v___x_1956_, 1, v___y_1946_);
return v___x_1956_;
}
else
{
lean_object* v_snd_1957_; lean_object* v_fst_1958_; lean_object* v___x_1960_; uint8_t v_isShared_1961_; uint8_t v_isSharedCheck_1995_; 
v_snd_1957_ = lean_ctor_get(v_b_1944_, 1);
v_fst_1958_ = lean_ctor_get(v_b_1944_, 0);
v_isSharedCheck_1995_ = !lean_is_exclusive(v_b_1944_);
if (v_isSharedCheck_1995_ == 0)
{
v___x_1960_ = v_b_1944_;
v_isShared_1961_ = v_isSharedCheck_1995_;
goto v_resetjp_1959_;
}
else
{
lean_inc(v_snd_1957_);
lean_inc(v_fst_1958_);
lean_dec(v_b_1944_);
v___x_1960_ = lean_box(0);
v_isShared_1961_ = v_isSharedCheck_1995_;
goto v_resetjp_1959_;
}
v_resetjp_1959_:
{
lean_object* v_fst_1962_; lean_object* v_snd_1963_; lean_object* v___x_1965_; uint8_t v_isShared_1966_; uint8_t v_isSharedCheck_1994_; 
v_fst_1962_ = lean_ctor_get(v_snd_1957_, 0);
v_snd_1963_ = lean_ctor_get(v_snd_1957_, 1);
v_isSharedCheck_1994_ = !lean_is_exclusive(v_snd_1957_);
if (v_isSharedCheck_1994_ == 0)
{
v___x_1965_ = v_snd_1957_;
v_isShared_1966_ = v_isSharedCheck_1994_;
goto v_resetjp_1964_;
}
else
{
lean_inc(v_snd_1963_);
lean_inc(v_fst_1962_);
lean_dec(v_snd_1957_);
v___x_1965_ = lean_box(0);
v_isShared_1966_ = v_isSharedCheck_1994_;
goto v_resetjp_1964_;
}
v_resetjp_1964_:
{
lean_object* v___x_1967_; lean_object* v_width_1968_; uint8_t v___x_1985_; 
v___x_1967_ = lean_unsigned_to_nat(0u);
v_width_1968_ = lean_unsigned_to_nat(1u);
v___x_1985_ = lean_nat_dec_lt(v_fst_1962_, v___y_1939_);
if (v___x_1985_ == 0)
{
lean_del_object(v___x_1965_);
lean_del_object(v___x_1960_);
goto v___jp_1979_;
}
else
{
uint8_t v___x_1986_; 
v___x_1986_ = lean_nat_dec_le(v___y_1940_, v_snd_1963_);
if (v___x_1986_ == 0)
{
uint8_t v_order_1987_; lean_object* v___x_1988_; lean_object* v___x_1989_; uint8_t v___x_1990_; lean_object* v___x_1991_; lean_object* v___x_1992_; uint8_t v___x_1993_; 
v_order_1987_ = lean_ctor_get_uint8(v_context_1941_, sizeof(void*)*1 + 8);
v___x_1988_ = lean_array_get_borrowed(v___x_1967_, v___x_1938_, v_fst_1962_);
v___x_1989_ = lean_array_get_borrowed(v___x_1967_, v___x_1938_, v_snd_1963_);
v___x_1990_ = lp_Hex_Hex_Groebner_MonomialTable_compare(v_table_1942_, v_order_1987_, v___x_1988_, v___x_1989_);
v___x_1991_ = l_Ordering_ctorIdx(v___x_1990_);
v___x_1992_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg___closed__0);
v___x_1993_ = lean_nat_dec_eq(v___x_1991_, v___x_1992_);
lean_dec(v___x_1991_);
if (v___x_1993_ == 0)
{
goto v___jp_1969_;
}
else
{
lean_del_object(v___x_1965_);
lean_del_object(v___x_1960_);
goto v___jp_1979_;
}
}
else
{
goto v___jp_1969_;
}
}
v___jp_1969_:
{
lean_object* v___x_1970_; lean_object* v___x_1971_; lean_object* v___x_1972_; lean_object* v___x_1974_; 
v___x_1970_ = lean_array_get_borrowed(v___x_1967_, v___x_1938_, v_fst_1962_);
lean_inc(v___x_1970_);
v___x_1971_ = lean_array_set(v_fst_1958_, v_i_1945_, v___x_1970_);
v___x_1972_ = lean_nat_add(v_fst_1962_, v_width_1968_);
lean_dec(v_fst_1962_);
if (v_isShared_1966_ == 0)
{
lean_ctor_set(v___x_1965_, 0, v___x_1972_);
v___x_1974_ = v___x_1965_;
goto v_reusejp_1973_;
}
else
{
lean_object* v_reuseFailAlloc_1978_; 
v_reuseFailAlloc_1978_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1978_, 0, v___x_1972_);
lean_ctor_set(v_reuseFailAlloc_1978_, 1, v_snd_1963_);
v___x_1974_ = v_reuseFailAlloc_1978_;
goto v_reusejp_1973_;
}
v_reusejp_1973_:
{
lean_object* v___x_1976_; 
if (v_isShared_1961_ == 0)
{
lean_ctor_set(v___x_1960_, 1, v___x_1974_);
lean_ctor_set(v___x_1960_, 0, v___x_1971_);
v___x_1976_ = v___x_1960_;
goto v_reusejp_1975_;
}
else
{
lean_object* v_reuseFailAlloc_1977_; 
v_reuseFailAlloc_1977_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1977_, 0, v___x_1971_);
lean_ctor_set(v_reuseFailAlloc_1977_, 1, v___x_1974_);
v___x_1976_ = v_reuseFailAlloc_1977_;
goto v_reusejp_1975_;
}
v_reusejp_1975_:
{
v_a_1950_ = v___x_1976_;
v_snd_1951_ = v___y_1946_;
goto v___jp_1949_;
}
}
}
v___jp_1979_:
{
lean_object* v___x_1980_; lean_object* v___x_1981_; lean_object* v___x_1982_; lean_object* v___x_1983_; lean_object* v___x_1984_; 
v___x_1980_ = lean_array_get_borrowed(v___x_1967_, v___x_1938_, v_snd_1963_);
lean_inc(v___x_1980_);
v___x_1981_ = lean_array_set(v_fst_1958_, v_i_1945_, v___x_1980_);
v___x_1982_ = lean_nat_add(v_snd_1963_, v_width_1968_);
lean_dec(v_snd_1963_);
v___x_1983_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1983_, 0, v_fst_1962_);
lean_ctor_set(v___x_1983_, 1, v___x_1982_);
v___x_1984_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1984_, 0, v___x_1981_);
lean_ctor_set(v___x_1984_, 1, v___x_1983_);
v_a_1950_ = v___x_1984_;
v_snd_1951_ = v___y_1946_;
goto v___jp_1949_;
}
}
}
}
v___jp_1949_:
{
lean_object* v___x_1952_; 
v___x_1952_ = lean_nat_add(v_i_1945_, v_step_1948_);
lean_dec(v_i_1945_);
v_b_1944_ = v_a_1950_;
v_i_1945_ = v___x_1952_;
v___y_1946_ = v_snd_1951_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg___boxed(lean_object* v___x_1996_, lean_object* v___y_1997_, lean_object* v___y_1998_, lean_object* v_context_1999_, lean_object* v_table_2000_, lean_object* v_range_2001_, lean_object* v_b_2002_, lean_object* v_i_2003_, lean_object* v___y_2004_){
_start:
{
lean_object* v_res_2005_; 
v_res_2005_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg(v___x_1996_, v___y_1997_, v___y_1998_, v_context_1999_, v_table_2000_, v_range_2001_, v_b_2002_, v_i_2003_, v___y_2004_);
lean_dec_ref(v_range_2001_);
lean_dec_ref(v_table_2000_);
lean_dec_ref(v_context_1999_);
lean_dec(v___y_1998_);
lean_dec(v___y_1997_);
lean_dec_ref(v___x_1996_);
return v_res_2005_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1___redArg(lean_object* v___x_2006_, lean_object* v___x_2007_, lean_object* v_context_2008_, lean_object* v_table_2009_, lean_object* v___x_2010_, lean_object* v___x_2011_, lean_object* v_range_2012_, lean_object* v_b_2013_, lean_object* v_i_2014_, lean_object* v___y_2015_){
_start:
{
lean_object* v_stop_2016_; lean_object* v_step_2017_; uint8_t v___x_2018_; 
v_stop_2016_ = lean_ctor_get(v_range_2012_, 1);
v_step_2017_ = lean_ctor_get(v_range_2012_, 2);
v___x_2018_ = lean_nat_dec_lt(v_i_2014_, v_stop_2016_);
if (v___x_2018_ == 0)
{
lean_object* v___x_2019_; lean_object* v___x_2020_; 
lean_dec(v_i_2014_);
lean_dec(v___x_2011_);
v___x_2019_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2019_, 0, v_b_2013_);
v___x_2020_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2020_, 0, v___x_2019_);
lean_ctor_set(v___x_2020_, 1, v___y_2015_);
return v___x_2020_;
}
else
{
lean_object* v___x_2021_; lean_object* v_width_2022_; lean_object* v___x_2023_; lean_object* v___x_2024_; lean_object* v___y_2026_; lean_object* v___y_2027_; lean_object* v___y_2039_; lean_object* v___x_2042_; uint8_t v___x_2043_; 
v___x_2021_ = lean_unsigned_to_nat(2u);
v_width_2022_ = lean_unsigned_to_nat(1u);
v___x_2023_ = lean_nat_mul(v_i_2014_, v___x_2021_);
v___x_2024_ = lean_nat_mul(v___x_2023_, v___x_2006_);
lean_dec(v___x_2023_);
v___x_2042_ = lean_nat_add(v___x_2024_, v___x_2006_);
v___x_2043_ = lean_nat_dec_le(v___x_2042_, v___x_2011_);
if (v___x_2043_ == 0)
{
lean_dec(v___x_2042_);
lean_inc(v___x_2011_);
v___y_2039_ = v___x_2011_;
goto v___jp_2038_;
}
else
{
v___y_2039_ = v___x_2042_;
goto v___jp_2038_;
}
v___jp_2025_:
{
lean_object* v___x_2028_; lean_object* v___x_2029_; lean_object* v___x_2030_; lean_object* v___x_2031_; lean_object* v_fst_2032_; lean_object* v_a_2033_; lean_object* v_snd_2034_; lean_object* v_fst_2035_; lean_object* v___x_2036_; 
lean_inc(v___y_2027_);
lean_inc_n(v___x_2024_, 2);
v___x_2028_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2028_, 0, v___x_2024_);
lean_ctor_set(v___x_2028_, 1, v___y_2027_);
lean_ctor_set(v___x_2028_, 2, v_width_2022_);
lean_inc(v___y_2026_);
v___x_2029_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2029_, 0, v___x_2024_);
lean_ctor_set(v___x_2029_, 1, v___y_2026_);
v___x_2030_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2030_, 0, v_b_2013_);
lean_ctor_set(v___x_2030_, 1, v___x_2029_);
v___x_2031_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg(v___x_2007_, v___y_2026_, v___y_2027_, v_context_2008_, v_table_2009_, v___x_2028_, v___x_2030_, v___x_2024_, v___y_2015_);
lean_dec_ref_known(v___x_2028_, 3);
lean_dec(v___y_2027_);
lean_dec(v___y_2026_);
v_fst_2032_ = lean_ctor_get(v___x_2031_, 0);
lean_inc(v_fst_2032_);
v_a_2033_ = lean_ctor_get(v_fst_2032_, 0);
lean_inc(v_a_2033_);
lean_dec(v_fst_2032_);
v_snd_2034_ = lean_ctor_get(v___x_2031_, 1);
lean_inc(v_snd_2034_);
lean_dec_ref(v___x_2031_);
v_fst_2035_ = lean_ctor_get(v_a_2033_, 0);
lean_inc(v_fst_2035_);
lean_dec(v_a_2033_);
v___x_2036_ = lean_nat_add(v_i_2014_, v_step_2017_);
lean_dec(v_i_2014_);
v_b_2013_ = v_fst_2035_;
v_i_2014_ = v___x_2036_;
v___y_2015_ = v_snd_2034_;
goto _start;
}
v___jp_2038_:
{
lean_object* v___x_2040_; uint8_t v___x_2041_; 
v___x_2040_ = lean_nat_add(v___x_2024_, v___x_2010_);
v___x_2041_ = lean_nat_dec_le(v___x_2040_, v___x_2011_);
if (v___x_2041_ == 0)
{
lean_dec(v___x_2040_);
lean_inc(v___x_2011_);
v___y_2026_ = v___y_2039_;
v___y_2027_ = v___x_2011_;
goto v___jp_2025_;
}
else
{
v___y_2026_ = v___y_2039_;
v___y_2027_ = v___x_2040_;
goto v___jp_2025_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1___redArg___boxed(lean_object* v___x_2044_, lean_object* v___x_2045_, lean_object* v_context_2046_, lean_object* v_table_2047_, lean_object* v___x_2048_, lean_object* v___x_2049_, lean_object* v_range_2050_, lean_object* v_b_2051_, lean_object* v_i_2052_, lean_object* v___y_2053_){
_start:
{
lean_object* v_res_2054_; 
v_res_2054_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1___redArg(v___x_2044_, v___x_2045_, v_context_2046_, v_table_2047_, v___x_2048_, v___x_2049_, v_range_2050_, v_b_2051_, v_i_2052_, v___y_2053_);
lean_dec_ref(v_range_2050_);
lean_dec(v___x_2048_);
lean_dec_ref(v_table_2047_);
lean_dec_ref(v_context_2046_);
lean_dec_ref(v___x_2045_);
lean_dec(v___x_2044_);
return v_res_2054_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2___redArg(lean_object* v___x_2055_, lean_object* v_context_2056_, lean_object* v_table_2057_, lean_object* v_range_2058_, lean_object* v_b_2059_, lean_object* v_i_2060_, lean_object* v___y_2061_){
_start:
{
lean_object* v_stop_2062_; lean_object* v_step_2063_; uint8_t v___x_2064_; 
v_stop_2062_ = lean_ctor_get(v_range_2058_, 1);
v_step_2063_ = lean_ctor_get(v_range_2058_, 2);
v___x_2064_ = lean_nat_dec_lt(v_i_2060_, v_stop_2062_);
if (v___x_2064_ == 0)
{
lean_object* v___x_2065_; lean_object* v___x_2066_; 
lean_dec(v_i_2060_);
lean_dec(v___x_2055_);
v___x_2065_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2065_, 0, v_b_2059_);
v___x_2066_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2066_, 0, v___x_2065_);
lean_ctor_set(v___x_2066_, 1, v___y_2061_);
return v___x_2066_;
}
else
{
lean_object* v_snd_2067_; lean_object* v_fst_2068_; lean_object* v___x_2070_; uint8_t v_isShared_2071_; uint8_t v_isSharedCheck_2130_; 
v_snd_2067_ = lean_ctor_get(v_b_2059_, 1);
v_fst_2068_ = lean_ctor_get(v_b_2059_, 0);
v_isSharedCheck_2130_ = !lean_is_exclusive(v_b_2059_);
if (v_isSharedCheck_2130_ == 0)
{
v___x_2070_ = v_b_2059_;
v_isShared_2071_ = v_isSharedCheck_2130_;
goto v_resetjp_2069_;
}
else
{
lean_inc(v_snd_2067_);
lean_inc(v_fst_2068_);
lean_dec(v_b_2059_);
v___x_2070_ = lean_box(0);
v_isShared_2071_ = v_isSharedCheck_2130_;
goto v_resetjp_2069_;
}
v_resetjp_2069_:
{
lean_object* v_fst_2072_; lean_object* v_snd_2073_; lean_object* v___x_2075_; uint8_t v_isShared_2076_; uint8_t v_isSharedCheck_2129_; 
v_fst_2072_ = lean_ctor_get(v_snd_2067_, 0);
v_snd_2073_ = lean_ctor_get(v_snd_2067_, 1);
v_isSharedCheck_2129_ = !lean_is_exclusive(v_snd_2067_);
if (v_isSharedCheck_2129_ == 0)
{
v___x_2075_ = v_snd_2067_;
v_isShared_2076_ = v_isSharedCheck_2129_;
goto v_resetjp_2074_;
}
else
{
lean_inc(v_snd_2073_);
lean_inc(v_fst_2072_);
lean_dec(v_snd_2067_);
v___x_2075_ = lean_box(0);
v_isShared_2076_ = v_isSharedCheck_2129_;
goto v_resetjp_2074_;
}
v_resetjp_2074_:
{
uint8_t v___x_2077_; 
v___x_2077_ = lean_nat_dec_le(v___x_2055_, v_snd_2073_);
if (v___x_2077_ == 0)
{
lean_object* v_width_2078_; lean_object* v___x_2079_; lean_object* v___x_2080_; lean_object* v___x_2081_; lean_object* v___x_2082_; lean_object* v___x_2083_; lean_object* v___x_2084_; lean_object* v___x_2085_; lean_object* v___x_2086_; lean_object* v_fst_2087_; 
lean_del_object(v___x_2070_);
v_width_2078_ = lean_unsigned_to_nat(1u);
v___x_2079_ = lean_unsigned_to_nat(0u);
v___x_2080_ = lean_unsigned_to_nat(2u);
v___x_2081_ = lean_nat_mul(v___x_2080_, v_snd_2073_);
v___x_2082_ = lean_nat_add(v___x_2055_, v___x_2081_);
v___x_2083_ = lean_nat_sub(v___x_2082_, v_width_2078_);
lean_dec(v___x_2082_);
v___x_2084_ = lean_nat_div(v___x_2083_, v___x_2081_);
lean_dec(v___x_2083_);
v___x_2085_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2085_, 0, v___x_2079_);
lean_ctor_set(v___x_2085_, 1, v___x_2084_);
lean_ctor_set(v___x_2085_, 2, v_width_2078_);
lean_inc(v___x_2055_);
v___x_2086_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1___redArg(v_snd_2073_, v_fst_2068_, v_context_2056_, v_table_2057_, v___x_2081_, v___x_2055_, v___x_2085_, v_fst_2072_, v___x_2079_, v___y_2061_);
lean_dec_ref_known(v___x_2085_, 3);
lean_dec(v___x_2081_);
v_fst_2087_ = lean_ctor_get(v___x_2086_, 0);
lean_inc(v_fst_2087_);
if (lean_obj_tag(v_fst_2087_) == 0)
{
lean_object* v_snd_2088_; lean_object* v___x_2090_; uint8_t v_isShared_2091_; uint8_t v_isSharedCheck_2103_; 
lean_del_object(v___x_2075_);
lean_dec(v_snd_2073_);
lean_dec(v_fst_2068_);
lean_dec(v_i_2060_);
lean_dec(v___x_2055_);
v_snd_2088_ = lean_ctor_get(v___x_2086_, 1);
v_isSharedCheck_2103_ = !lean_is_exclusive(v___x_2086_);
if (v_isSharedCheck_2103_ == 0)
{
lean_object* v_unused_2104_; 
v_unused_2104_ = lean_ctor_get(v___x_2086_, 0);
lean_dec(v_unused_2104_);
v___x_2090_ = v___x_2086_;
v_isShared_2091_ = v_isSharedCheck_2103_;
goto v_resetjp_2089_;
}
else
{
lean_inc(v_snd_2088_);
lean_dec(v___x_2086_);
v___x_2090_ = lean_box(0);
v_isShared_2091_ = v_isSharedCheck_2103_;
goto v_resetjp_2089_;
}
v_resetjp_2089_:
{
lean_object* v_a_2092_; lean_object* v___x_2094_; uint8_t v_isShared_2095_; uint8_t v_isSharedCheck_2102_; 
v_a_2092_ = lean_ctor_get(v_fst_2087_, 0);
v_isSharedCheck_2102_ = !lean_is_exclusive(v_fst_2087_);
if (v_isSharedCheck_2102_ == 0)
{
v___x_2094_ = v_fst_2087_;
v_isShared_2095_ = v_isSharedCheck_2102_;
goto v_resetjp_2093_;
}
else
{
lean_inc(v_a_2092_);
lean_dec(v_fst_2087_);
v___x_2094_ = lean_box(0);
v_isShared_2095_ = v_isSharedCheck_2102_;
goto v_resetjp_2093_;
}
v_resetjp_2093_:
{
lean_object* v___x_2097_; 
if (v_isShared_2095_ == 0)
{
v___x_2097_ = v___x_2094_;
goto v_reusejp_2096_;
}
else
{
lean_object* v_reuseFailAlloc_2101_; 
v_reuseFailAlloc_2101_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2101_, 0, v_a_2092_);
v___x_2097_ = v_reuseFailAlloc_2101_;
goto v_reusejp_2096_;
}
v_reusejp_2096_:
{
lean_object* v___x_2099_; 
if (v_isShared_2091_ == 0)
{
lean_ctor_set(v___x_2090_, 0, v___x_2097_);
v___x_2099_ = v___x_2090_;
goto v_reusejp_2098_;
}
else
{
lean_object* v_reuseFailAlloc_2100_; 
v_reuseFailAlloc_2100_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2100_, 0, v___x_2097_);
lean_ctor_set(v_reuseFailAlloc_2100_, 1, v_snd_2088_);
v___x_2099_ = v_reuseFailAlloc_2100_;
goto v_reusejp_2098_;
}
v_reusejp_2098_:
{
return v___x_2099_;
}
}
}
}
}
else
{
lean_object* v_snd_2105_; lean_object* v___x_2107_; uint8_t v_isShared_2108_; uint8_t v_isSharedCheck_2119_; 
v_snd_2105_ = lean_ctor_get(v___x_2086_, 1);
v_isSharedCheck_2119_ = !lean_is_exclusive(v___x_2086_);
if (v_isSharedCheck_2119_ == 0)
{
lean_object* v_unused_2120_; 
v_unused_2120_ = lean_ctor_get(v___x_2086_, 0);
lean_dec(v_unused_2120_);
v___x_2107_ = v___x_2086_;
v_isShared_2108_ = v_isSharedCheck_2119_;
goto v_resetjp_2106_;
}
else
{
lean_inc(v_snd_2105_);
lean_dec(v___x_2086_);
v___x_2107_ = lean_box(0);
v_isShared_2108_ = v_isSharedCheck_2119_;
goto v_resetjp_2106_;
}
v_resetjp_2106_:
{
lean_object* v_a_2109_; lean_object* v___x_2110_; lean_object* v___x_2112_; 
v_a_2109_ = lean_ctor_get(v_fst_2087_, 0);
lean_inc(v_a_2109_);
lean_dec_ref_known(v_fst_2087_, 1);
v___x_2110_ = lean_nat_mul(v_snd_2073_, v___x_2080_);
lean_dec(v_snd_2073_);
if (v_isShared_2108_ == 0)
{
lean_ctor_set(v___x_2107_, 1, v___x_2110_);
lean_ctor_set(v___x_2107_, 0, v_fst_2068_);
v___x_2112_ = v___x_2107_;
goto v_reusejp_2111_;
}
else
{
lean_object* v_reuseFailAlloc_2118_; 
v_reuseFailAlloc_2118_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2118_, 0, v_fst_2068_);
lean_ctor_set(v_reuseFailAlloc_2118_, 1, v___x_2110_);
v___x_2112_ = v_reuseFailAlloc_2118_;
goto v_reusejp_2111_;
}
v_reusejp_2111_:
{
lean_object* v___x_2114_; 
if (v_isShared_2076_ == 0)
{
lean_ctor_set(v___x_2075_, 1, v___x_2112_);
lean_ctor_set(v___x_2075_, 0, v_a_2109_);
v___x_2114_ = v___x_2075_;
goto v_reusejp_2113_;
}
else
{
lean_object* v_reuseFailAlloc_2117_; 
v_reuseFailAlloc_2117_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2117_, 0, v_a_2109_);
lean_ctor_set(v_reuseFailAlloc_2117_, 1, v___x_2112_);
v___x_2114_ = v_reuseFailAlloc_2117_;
goto v_reusejp_2113_;
}
v_reusejp_2113_:
{
lean_object* v___x_2115_; 
v___x_2115_ = lean_nat_add(v_i_2060_, v_step_2063_);
lean_dec(v_i_2060_);
v_b_2059_ = v___x_2114_;
v_i_2060_ = v___x_2115_;
v___y_2061_ = v_snd_2105_;
goto _start;
}
}
}
}
}
else
{
lean_object* v___x_2122_; 
lean_dec(v_i_2060_);
lean_dec(v___x_2055_);
if (v_isShared_2076_ == 0)
{
v___x_2122_ = v___x_2075_;
goto v_reusejp_2121_;
}
else
{
lean_object* v_reuseFailAlloc_2128_; 
v_reuseFailAlloc_2128_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2128_, 0, v_fst_2072_);
lean_ctor_set(v_reuseFailAlloc_2128_, 1, v_snd_2073_);
v___x_2122_ = v_reuseFailAlloc_2128_;
goto v_reusejp_2121_;
}
v_reusejp_2121_:
{
lean_object* v___x_2124_; 
if (v_isShared_2071_ == 0)
{
lean_ctor_set(v___x_2070_, 1, v___x_2122_);
v___x_2124_ = v___x_2070_;
goto v_reusejp_2123_;
}
else
{
lean_object* v_reuseFailAlloc_2127_; 
v_reuseFailAlloc_2127_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2127_, 0, v_fst_2068_);
lean_ctor_set(v_reuseFailAlloc_2127_, 1, v___x_2122_);
v___x_2124_ = v_reuseFailAlloc_2127_;
goto v_reusejp_2123_;
}
v_reusejp_2123_:
{
lean_object* v___x_2125_; lean_object* v___x_2126_; 
v___x_2125_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2125_, 0, v___x_2124_);
v___x_2126_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2126_, 0, v___x_2125_);
lean_ctor_set(v___x_2126_, 1, v___y_2061_);
return v___x_2126_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2___redArg___boxed(lean_object* v___x_2131_, lean_object* v_context_2132_, lean_object* v_table_2133_, lean_object* v_range_2134_, lean_object* v_b_2135_, lean_object* v_i_2136_, lean_object* v___y_2137_){
_start:
{
lean_object* v_res_2138_; 
v_res_2138_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2___redArg(v___x_2131_, v_context_2132_, v_table_2133_, v_range_2134_, v_b_2135_, v_i_2136_, v___y_2137_);
lean_dec_ref(v_range_2134_);
lean_dec_ref(v_table_2133_);
lean_dec_ref(v_context_2132_);
return v_res_2138_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_sort(lean_object* v_context_2141_, lean_object* v_limits_2142_, lean_object* v_ids_2143_, lean_object* v_a_2144_){
_start:
{
lean_object* v_statistics_2145_; lean_object* v_variables_2146_; lean_object* v_table_2147_; lean_object* v_work_2148_; lean_object* v_allocatedBytes_2149_; lean_object* v_pairs_2150_; lean_object* v_rounds_2151_; lean_object* v_matrixEntries_2152_; lean_object* v_matrixRows_2153_; lean_object* v_matrixCalls_2154_; lean_object* v_peakMatrixRows_2155_; lean_object* v_peakMatrixEntries_2156_; lean_object* v_largestBatch_2157_; lean_object* v_productPairs_2158_; lean_object* v_chainPairs_2159_; lean_object* v_gmPairs_2160_; lean_object* v___x_2162_; uint8_t v_isShared_2163_; uint8_t v_isSharedCheck_2230_; 
v_statistics_2145_ = lean_ctor_get(v_a_2144_, 1);
lean_inc_ref(v_statistics_2145_);
v_variables_2146_ = lean_ctor_get(v_context_2141_, 0);
v_table_2147_ = lean_ctor_get(v_a_2144_, 0);
v_work_2148_ = lean_ctor_get(v_statistics_2145_, 0);
v_allocatedBytes_2149_ = lean_ctor_get(v_statistics_2145_, 1);
v_pairs_2150_ = lean_ctor_get(v_statistics_2145_, 2);
v_rounds_2151_ = lean_ctor_get(v_statistics_2145_, 3);
v_matrixEntries_2152_ = lean_ctor_get(v_statistics_2145_, 4);
v_matrixRows_2153_ = lean_ctor_get(v_statistics_2145_, 5);
v_matrixCalls_2154_ = lean_ctor_get(v_statistics_2145_, 6);
v_peakMatrixRows_2155_ = lean_ctor_get(v_statistics_2145_, 7);
v_peakMatrixEntries_2156_ = lean_ctor_get(v_statistics_2145_, 8);
v_largestBatch_2157_ = lean_ctor_get(v_statistics_2145_, 9);
v_productPairs_2158_ = lean_ctor_get(v_statistics_2145_, 10);
v_chainPairs_2159_ = lean_ctor_get(v_statistics_2145_, 11);
v_gmPairs_2160_ = lean_ctor_get(v_statistics_2145_, 12);
v_isSharedCheck_2230_ = !lean_is_exclusive(v_statistics_2145_);
if (v_isSharedCheck_2230_ == 0)
{
v___x_2162_ = v_statistics_2145_;
v_isShared_2163_ = v_isSharedCheck_2230_;
goto v_resetjp_2161_;
}
else
{
lean_inc(v_gmPairs_2160_);
lean_inc(v_chainPairs_2159_);
lean_inc(v_productPairs_2158_);
lean_inc(v_largestBatch_2157_);
lean_inc(v_peakMatrixEntries_2156_);
lean_inc(v_peakMatrixRows_2155_);
lean_inc(v_matrixCalls_2154_);
lean_inc(v_matrixRows_2153_);
lean_inc(v_matrixEntries_2152_);
lean_inc(v_rounds_2151_);
lean_inc(v_pairs_2150_);
lean_inc(v_allocatedBytes_2149_);
lean_inc(v_work_2148_);
lean_dec(v_statistics_2145_);
v___x_2162_ = lean_box(0);
v_isShared_2163_ = v_isSharedCheck_2230_;
goto v_resetjp_2161_;
}
v_resetjp_2161_:
{
lean_object* v_work_2164_; lean_object* v___x_2165_; lean_object* v___x_2166_; lean_object* v_width_2167_; lean_object* v___x_2168_; lean_object* v___x_2169_; lean_object* v___x_2170_; lean_object* v___x_2171_; lean_object* v_work_2172_; uint8_t v___x_2173_; 
v_work_2164_ = lean_ctor_get(v_limits_2142_, 0);
v___x_2165_ = lean_array_get_size(v_ids_2143_);
v___x_2166_ = lean_nat_log2(v___x_2165_);
v_width_2167_ = lean_unsigned_to_nat(1u);
v___x_2168_ = lean_nat_add(v___x_2166_, v_width_2167_);
lean_dec(v___x_2166_);
v___x_2169_ = lean_nat_mul(v___x_2165_, v___x_2168_);
v___x_2170_ = lean_nat_add(v_variables_2146_, v_width_2167_);
v___x_2171_ = lean_nat_mul(v___x_2169_, v___x_2170_);
lean_dec(v___x_2170_);
lean_dec(v___x_2169_);
v_work_2172_ = lean_nat_add(v_work_2148_, v___x_2171_);
lean_dec(v___x_2171_);
lean_dec(v_work_2148_);
v___x_2173_ = lean_nat_dec_lt(v_work_2164_, v_work_2172_);
if (v___x_2173_ == 0)
{
lean_object* v___x_2175_; uint8_t v_isShared_2176_; uint8_t v_isSharedCheck_2225_; 
lean_inc_ref(v_table_2147_);
v_isSharedCheck_2225_ = !lean_is_exclusive(v_a_2144_);
if (v_isSharedCheck_2225_ == 0)
{
lean_object* v_unused_2226_; lean_object* v_unused_2227_; 
v_unused_2226_ = lean_ctor_get(v_a_2144_, 1);
lean_dec(v_unused_2226_);
v_unused_2227_ = lean_ctor_get(v_a_2144_, 0);
lean_dec(v_unused_2227_);
v___x_2175_ = v_a_2144_;
v_isShared_2176_ = v_isSharedCheck_2225_;
goto v_resetjp_2174_;
}
else
{
lean_dec(v_a_2144_);
v___x_2175_ = lean_box(0);
v_isShared_2176_ = v_isSharedCheck_2225_;
goto v_resetjp_2174_;
}
v_resetjp_2174_:
{
lean_object* v___x_2178_; 
if (v_isShared_2163_ == 0)
{
lean_ctor_set(v___x_2162_, 0, v_work_2172_);
v___x_2178_ = v___x_2162_;
goto v_reusejp_2177_;
}
else
{
lean_object* v_reuseFailAlloc_2224_; 
v_reuseFailAlloc_2224_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_2224_, 0, v_work_2172_);
lean_ctor_set(v_reuseFailAlloc_2224_, 1, v_allocatedBytes_2149_);
lean_ctor_set(v_reuseFailAlloc_2224_, 2, v_pairs_2150_);
lean_ctor_set(v_reuseFailAlloc_2224_, 3, v_rounds_2151_);
lean_ctor_set(v_reuseFailAlloc_2224_, 4, v_matrixEntries_2152_);
lean_ctor_set(v_reuseFailAlloc_2224_, 5, v_matrixRows_2153_);
lean_ctor_set(v_reuseFailAlloc_2224_, 6, v_matrixCalls_2154_);
lean_ctor_set(v_reuseFailAlloc_2224_, 7, v_peakMatrixRows_2155_);
lean_ctor_set(v_reuseFailAlloc_2224_, 8, v_peakMatrixEntries_2156_);
lean_ctor_set(v_reuseFailAlloc_2224_, 9, v_largestBatch_2157_);
lean_ctor_set(v_reuseFailAlloc_2224_, 10, v_productPairs_2158_);
lean_ctor_set(v_reuseFailAlloc_2224_, 11, v_chainPairs_2159_);
lean_ctor_set(v_reuseFailAlloc_2224_, 12, v_gmPairs_2160_);
v___x_2178_ = v_reuseFailAlloc_2224_;
goto v_reusejp_2177_;
}
v_reusejp_2177_:
{
lean_object* v___x_2180_; 
lean_inc_ref(v_table_2147_);
if (v_isShared_2176_ == 0)
{
lean_ctor_set(v___x_2175_, 1, v___x_2178_);
v___x_2180_ = v___x_2175_;
goto v_reusejp_2179_;
}
else
{
lean_object* v_reuseFailAlloc_2223_; 
v_reuseFailAlloc_2223_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2223_, 0, v_table_2147_);
lean_ctor_set(v_reuseFailAlloc_2223_, 1, v___x_2178_);
v___x_2180_ = v_reuseFailAlloc_2223_;
goto v_reusejp_2179_;
}
v_reusejp_2179_:
{
lean_object* v___x_2181_; lean_object* v_destination_2182_; lean_object* v___x_2183_; lean_object* v___x_2184_; lean_object* v___x_2185_; lean_object* v___x_2186_; lean_object* v_fst_2187_; 
v___x_2181_ = lean_unsigned_to_nat(0u);
v_destination_2182_ = lean_mk_array(v___x_2165_, v___x_2181_);
v___x_2183_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2183_, 0, v___x_2181_);
lean_ctor_set(v___x_2183_, 1, v___x_2168_);
lean_ctor_set(v___x_2183_, 2, v_width_2167_);
v___x_2184_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2184_, 0, v_destination_2182_);
lean_ctor_set(v___x_2184_, 1, v_width_2167_);
v___x_2185_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2185_, 0, v_ids_2143_);
lean_ctor_set(v___x_2185_, 1, v___x_2184_);
v___x_2186_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2___redArg(v___x_2165_, v_context_2141_, v_table_2147_, v___x_2183_, v___x_2185_, v___x_2181_, v___x_2180_);
lean_dec_ref_known(v___x_2183_, 3);
lean_dec_ref(v_table_2147_);
v_fst_2187_ = lean_ctor_get(v___x_2186_, 0);
lean_inc(v_fst_2187_);
if (lean_obj_tag(v_fst_2187_) == 0)
{
lean_object* v_snd_2188_; lean_object* v___x_2190_; uint8_t v_isShared_2191_; uint8_t v_isSharedCheck_2203_; 
v_snd_2188_ = lean_ctor_get(v___x_2186_, 1);
v_isSharedCheck_2203_ = !lean_is_exclusive(v___x_2186_);
if (v_isSharedCheck_2203_ == 0)
{
lean_object* v_unused_2204_; 
v_unused_2204_ = lean_ctor_get(v___x_2186_, 0);
lean_dec(v_unused_2204_);
v___x_2190_ = v___x_2186_;
v_isShared_2191_ = v_isSharedCheck_2203_;
goto v_resetjp_2189_;
}
else
{
lean_inc(v_snd_2188_);
lean_dec(v___x_2186_);
v___x_2190_ = lean_box(0);
v_isShared_2191_ = v_isSharedCheck_2203_;
goto v_resetjp_2189_;
}
v_resetjp_2189_:
{
lean_object* v_a_2192_; lean_object* v___x_2194_; uint8_t v_isShared_2195_; uint8_t v_isSharedCheck_2202_; 
v_a_2192_ = lean_ctor_get(v_fst_2187_, 0);
v_isSharedCheck_2202_ = !lean_is_exclusive(v_fst_2187_);
if (v_isSharedCheck_2202_ == 0)
{
v___x_2194_ = v_fst_2187_;
v_isShared_2195_ = v_isSharedCheck_2202_;
goto v_resetjp_2193_;
}
else
{
lean_inc(v_a_2192_);
lean_dec(v_fst_2187_);
v___x_2194_ = lean_box(0);
v_isShared_2195_ = v_isSharedCheck_2202_;
goto v_resetjp_2193_;
}
v_resetjp_2193_:
{
lean_object* v___x_2197_; 
if (v_isShared_2195_ == 0)
{
v___x_2197_ = v___x_2194_;
goto v_reusejp_2196_;
}
else
{
lean_object* v_reuseFailAlloc_2201_; 
v_reuseFailAlloc_2201_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2201_, 0, v_a_2192_);
v___x_2197_ = v_reuseFailAlloc_2201_;
goto v_reusejp_2196_;
}
v_reusejp_2196_:
{
lean_object* v___x_2199_; 
if (v_isShared_2191_ == 0)
{
lean_ctor_set(v___x_2190_, 0, v___x_2197_);
v___x_2199_ = v___x_2190_;
goto v_reusejp_2198_;
}
else
{
lean_object* v_reuseFailAlloc_2200_; 
v_reuseFailAlloc_2200_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2200_, 0, v___x_2197_);
lean_ctor_set(v_reuseFailAlloc_2200_, 1, v_snd_2188_);
v___x_2199_ = v_reuseFailAlloc_2200_;
goto v_reusejp_2198_;
}
v_reusejp_2198_:
{
return v___x_2199_;
}
}
}
}
}
else
{
lean_object* v_a_2205_; lean_object* v___x_2207_; uint8_t v_isShared_2208_; uint8_t v_isSharedCheck_2222_; 
v_a_2205_ = lean_ctor_get(v_fst_2187_, 0);
v_isSharedCheck_2222_ = !lean_is_exclusive(v_fst_2187_);
if (v_isSharedCheck_2222_ == 0)
{
v___x_2207_ = v_fst_2187_;
v_isShared_2208_ = v_isSharedCheck_2222_;
goto v_resetjp_2206_;
}
else
{
lean_inc(v_a_2205_);
lean_dec(v_fst_2187_);
v___x_2207_ = lean_box(0);
v_isShared_2208_ = v_isSharedCheck_2222_;
goto v_resetjp_2206_;
}
v_resetjp_2206_:
{
lean_object* v_snd_2209_; lean_object* v_fst_2210_; lean_object* v___x_2212_; uint8_t v_isShared_2213_; uint8_t v_isSharedCheck_2220_; 
v_snd_2209_ = lean_ctor_get(v___x_2186_, 1);
lean_inc(v_snd_2209_);
lean_dec_ref(v___x_2186_);
v_fst_2210_ = lean_ctor_get(v_a_2205_, 0);
v_isSharedCheck_2220_ = !lean_is_exclusive(v_a_2205_);
if (v_isSharedCheck_2220_ == 0)
{
lean_object* v_unused_2221_; 
v_unused_2221_ = lean_ctor_get(v_a_2205_, 1);
lean_dec(v_unused_2221_);
v___x_2212_ = v_a_2205_;
v_isShared_2213_ = v_isSharedCheck_2220_;
goto v_resetjp_2211_;
}
else
{
lean_inc(v_fst_2210_);
lean_dec(v_a_2205_);
v___x_2212_ = lean_box(0);
v_isShared_2213_ = v_isSharedCheck_2220_;
goto v_resetjp_2211_;
}
v_resetjp_2211_:
{
lean_object* v___x_2215_; 
if (v_isShared_2208_ == 0)
{
lean_ctor_set(v___x_2207_, 0, v_fst_2210_);
v___x_2215_ = v___x_2207_;
goto v_reusejp_2214_;
}
else
{
lean_object* v_reuseFailAlloc_2219_; 
v_reuseFailAlloc_2219_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2219_, 0, v_fst_2210_);
v___x_2215_ = v_reuseFailAlloc_2219_;
goto v_reusejp_2214_;
}
v_reusejp_2214_:
{
lean_object* v___x_2217_; 
if (v_isShared_2213_ == 0)
{
lean_ctor_set(v___x_2212_, 1, v_snd_2209_);
lean_ctor_set(v___x_2212_, 0, v___x_2215_);
v___x_2217_ = v___x_2212_;
goto v_reusejp_2216_;
}
else
{
lean_object* v_reuseFailAlloc_2218_; 
v_reuseFailAlloc_2218_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2218_, 0, v___x_2215_);
lean_ctor_set(v_reuseFailAlloc_2218_, 1, v_snd_2209_);
v___x_2217_ = v_reuseFailAlloc_2218_;
goto v_reusejp_2216_;
}
v_reusejp_2216_:
{
return v___x_2217_;
}
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_2228_; lean_object* v___x_2229_; 
lean_dec(v_work_2172_);
lean_dec(v___x_2168_);
lean_del_object(v___x_2162_);
lean_dec(v_gmPairs_2160_);
lean_dec(v_chainPairs_2159_);
lean_dec(v_productPairs_2158_);
lean_dec(v_largestBatch_2157_);
lean_dec(v_peakMatrixEntries_2156_);
lean_dec(v_peakMatrixRows_2155_);
lean_dec(v_matrixCalls_2154_);
lean_dec(v_matrixRows_2153_);
lean_dec(v_matrixEntries_2152_);
lean_dec(v_rounds_2151_);
lean_dec(v_pairs_2150_);
lean_dec(v_allocatedBytes_2149_);
lean_dec_ref(v_ids_2143_);
v___x_2228_ = ((lean_object*)(lp_Hex_Hex_Groebner_Computation_sort___closed__0));
v___x_2229_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2229_, 0, v___x_2228_);
lean_ctor_set(v___x_2229_, 1, v_a_2144_);
return v___x_2229_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Computation_sort___boxed(lean_object* v_context_2231_, lean_object* v_limits_2232_, lean_object* v_ids_2233_, lean_object* v_a_2234_){
_start:
{
lean_object* v_res_2235_; 
v_res_2235_ = lp_Hex_Hex_Groebner_Computation_sort(v_context_2231_, v_limits_2232_, v_ids_2233_, v_a_2234_);
lean_dec_ref(v_limits_2232_);
lean_dec_ref(v_context_2231_);
return v_res_2235_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0(lean_object* v___x_2236_, lean_object* v___y_2237_, lean_object* v___y_2238_, lean_object* v_context_2239_, lean_object* v_table_2240_, lean_object* v_range_2241_, lean_object* v_b_2242_, lean_object* v_i_2243_, lean_object* v_hs_2244_, lean_object* v_hl_2245_, lean_object* v___y_2246_){
_start:
{
lean_object* v___x_2247_; 
v___x_2247_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___redArg(v___x_2236_, v___y_2237_, v___y_2238_, v_context_2239_, v_table_2240_, v_range_2241_, v_b_2242_, v_i_2243_, v___y_2246_);
return v___x_2247_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0___boxed(lean_object* v___x_2248_, lean_object* v___y_2249_, lean_object* v___y_2250_, lean_object* v_context_2251_, lean_object* v_table_2252_, lean_object* v_range_2253_, lean_object* v_b_2254_, lean_object* v_i_2255_, lean_object* v_hs_2256_, lean_object* v_hl_2257_, lean_object* v___y_2258_){
_start:
{
lean_object* v_res_2259_; 
v_res_2259_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__0(v___x_2248_, v___y_2249_, v___y_2250_, v_context_2251_, v_table_2252_, v_range_2253_, v_b_2254_, v_i_2255_, v_hs_2256_, v_hl_2257_, v___y_2258_);
lean_dec_ref(v_range_2253_);
lean_dec_ref(v_table_2252_);
lean_dec_ref(v_context_2251_);
lean_dec(v___y_2250_);
lean_dec(v___y_2249_);
lean_dec_ref(v___x_2248_);
return v_res_2259_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1(lean_object* v___x_2260_, lean_object* v___x_2261_, lean_object* v_context_2262_, lean_object* v_table_2263_, lean_object* v___x_2264_, lean_object* v___x_2265_, lean_object* v_range_2266_, lean_object* v_b_2267_, lean_object* v_i_2268_, lean_object* v_hs_2269_, lean_object* v_hl_2270_, lean_object* v___y_2271_){
_start:
{
lean_object* v___x_2272_; 
v___x_2272_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1___redArg(v___x_2260_, v___x_2261_, v_context_2262_, v_table_2263_, v___x_2264_, v___x_2265_, v_range_2266_, v_b_2267_, v_i_2268_, v___y_2271_);
return v___x_2272_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1___boxed(lean_object* v___x_2273_, lean_object* v___x_2274_, lean_object* v_context_2275_, lean_object* v_table_2276_, lean_object* v___x_2277_, lean_object* v___x_2278_, lean_object* v_range_2279_, lean_object* v_b_2280_, lean_object* v_i_2281_, lean_object* v_hs_2282_, lean_object* v_hl_2283_, lean_object* v___y_2284_){
_start:
{
lean_object* v_res_2285_; 
v_res_2285_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__1(v___x_2273_, v___x_2274_, v_context_2275_, v_table_2276_, v___x_2277_, v___x_2278_, v_range_2279_, v_b_2280_, v_i_2281_, v_hs_2282_, v_hl_2283_, v___y_2284_);
lean_dec_ref(v_range_2279_);
lean_dec(v___x_2277_);
lean_dec_ref(v_table_2276_);
lean_dec_ref(v_context_2275_);
lean_dec_ref(v___x_2274_);
lean_dec(v___x_2273_);
return v_res_2285_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2(lean_object* v___x_2286_, lean_object* v_context_2287_, lean_object* v_table_2288_, lean_object* v_range_2289_, lean_object* v_b_2290_, lean_object* v_i_2291_, lean_object* v_hs_2292_, lean_object* v_hl_2293_, lean_object* v___y_2294_){
_start:
{
lean_object* v___x_2295_; 
v___x_2295_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2___redArg(v___x_2286_, v_context_2287_, v_table_2288_, v_range_2289_, v_b_2290_, v_i_2291_, v___y_2294_);
return v___x_2295_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2___boxed(lean_object* v___x_2296_, lean_object* v_context_2297_, lean_object* v_table_2298_, lean_object* v_range_2299_, lean_object* v_b_2300_, lean_object* v_i_2301_, lean_object* v_hs_2302_, lean_object* v_hl_2303_, lean_object* v___y_2304_){
_start:
{
lean_object* v_res_2305_; 
v_res_2305_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Computation_sort_spec__2(v___x_2296_, v_context_2297_, v_table_2298_, v_range_2299_, v_b_2300_, v_i_2301_, v_hs_2302_, v_hl_2303_, v___y_2304_);
lean_dec_ref(v_range_2299_);
lean_dec_ref(v_table_2298_);
lean_dec_ref(v_context_2297_);
return v_res_2305_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Monomial(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Elimination(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_Runtime(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Monomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Elimination(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_Groebner_instInhabitedPolynomial_default = _init_lp_Hex_Hex_Groebner_instInhabitedPolynomial_default();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedPolynomial_default);
lp_Hex_Hex_Groebner_instInhabitedPolynomial = _init_lp_Hex_Hex_Groebner_instInhabitedPolynomial();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedPolynomial);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_Runtime(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Monomial(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Elimination(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_Runtime(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Monomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Elimination(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Runtime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_Runtime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_Runtime(builtin);
}
#ifdef __cplusplus
}
#endif
