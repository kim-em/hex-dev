// Lean compiler output
// Module: HexGroebner.IndexPair
// Imports: public import Init public meta import Init public import Std.Data.HashMap
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
uint64_t lean_uint64_mul(uint64_t, uint64_t);
uint64_t lean_uint64_of_nat(lean_object*);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_IndexPair_pack(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_pack___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_IndexPair_instBEq___aux__1(uint64_t, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_instBEq___aux__1___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_IndexPair_instBEq___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_IndexPair_instBEq___aux__1___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_IndexPair_instBEq___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_IndexPair_instBEq___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_IndexPair_instBEq = (const lean_object*)&lp_Hex_Hex_Groebner_IndexPair_instBEq___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_IndexPair_instDecidableEq___aux__1(uint64_t, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_instDecidableEq___aux__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_IndexPair_instDecidableEq(uint64_t, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_instDecidableEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_IndexPair_hash(uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_hash___boxed(lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_IndexPair_instHashable___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_IndexPair_hash___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_IndexPair_instHashable___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_IndexPair_instHashable___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_IndexPair_instHashable = (const lean_object*)&lp_Hex_Hex_Groebner_IndexPair_instHashable___closed__0_value;
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_IndexPair_pack(lean_object* v_left_1_, lean_object* v_right_2_){
_start:
{
uint64_t v___x_3_; uint64_t v___x_4_; uint64_t v___x_5_; uint64_t v___x_6_; uint64_t v___x_7_; 
v___x_3_ = lean_uint64_of_nat(v_left_1_);
v___x_4_ = 32ULL;
v___x_5_ = lean_uint64_shift_left(v___x_3_, v___x_4_);
v___x_6_ = lean_uint64_of_nat(v_right_2_);
v___x_7_ = lean_uint64_lor(v___x_5_, v___x_6_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_pack___boxed(lean_object* v_left_8_, lean_object* v_right_9_){
_start:
{
uint64_t v_res_10_; lean_object* v_r_11_; 
v_res_10_ = lp_Hex_Hex_Groebner_IndexPair_pack(v_left_8_, v_right_9_);
lean_dec(v_right_9_);
lean_dec(v_left_8_);
v_r_11_ = lean_box_uint64(v_res_10_);
return v_r_11_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_IndexPair_instBEq___aux__1(uint64_t v_a_12_, uint64_t v_b_13_){
_start:
{
uint8_t v___x_14_; 
v___x_14_ = lean_uint64_dec_eq(v_a_12_, v_b_13_);
return v___x_14_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_instBEq___aux__1___boxed(lean_object* v_a_15_, lean_object* v_b_16_){
_start:
{
uint64_t v_a_boxed_17_; uint64_t v_b_boxed_18_; uint8_t v_res_19_; lean_object* v_r_20_; 
v_a_boxed_17_ = lean_unbox_uint64(v_a_15_);
lean_dec_ref(v_a_15_);
v_b_boxed_18_ = lean_unbox_uint64(v_b_16_);
lean_dec_ref(v_b_16_);
v_res_19_ = lp_Hex_Hex_Groebner_IndexPair_instBEq___aux__1(v_a_boxed_17_, v_b_boxed_18_);
v_r_20_ = lean_box(v_res_19_);
return v_r_20_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_IndexPair_instDecidableEq___aux__1(uint64_t v_a_23_, uint64_t v_b_24_){
_start:
{
uint8_t v___x_25_; 
v___x_25_ = lean_uint64_dec_eq(v_a_23_, v_b_24_);
return v___x_25_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_instDecidableEq___aux__1___boxed(lean_object* v_a_26_, lean_object* v_b_27_){
_start:
{
uint64_t v_a_boxed_28_; uint64_t v_b_boxed_29_; uint8_t v_res_30_; lean_object* v_r_31_; 
v_a_boxed_28_ = lean_unbox_uint64(v_a_26_);
lean_dec_ref(v_a_26_);
v_b_boxed_29_ = lean_unbox_uint64(v_b_27_);
lean_dec_ref(v_b_27_);
v_res_30_ = lp_Hex_Hex_Groebner_IndexPair_instDecidableEq___aux__1(v_a_boxed_28_, v_b_boxed_29_);
v_r_31_ = lean_box(v_res_30_);
return v_r_31_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_IndexPair_instDecidableEq(uint64_t v_a_32_, uint64_t v_b_33_){
_start:
{
uint8_t v___x_34_; 
v___x_34_ = lean_uint64_dec_eq(v_a_32_, v_b_33_);
return v___x_34_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_instDecidableEq___boxed(lean_object* v_a_35_, lean_object* v_b_36_){
_start:
{
uint64_t v_a_boxed_37_; uint64_t v_b_boxed_38_; uint8_t v_res_39_; lean_object* v_r_40_; 
v_a_boxed_37_ = lean_unbox_uint64(v_a_35_);
lean_dec_ref(v_a_35_);
v_b_boxed_38_ = lean_unbox_uint64(v_b_36_);
lean_dec_ref(v_b_36_);
v_res_39_ = lp_Hex_Hex_Groebner_IndexPair_instDecidableEq(v_a_boxed_37_, v_b_boxed_38_);
v_r_40_ = lean_box(v_res_39_);
return v_r_40_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_IndexPair_hash(uint64_t v_key_41_){
_start:
{
uint64_t v___x_42_; uint64_t v___x_43_; uint64_t v___x_44_; uint64_t v___x_45_; uint64_t v_x_46_; uint64_t v___x_47_; uint64_t v___x_48_; uint64_t v___x_49_; uint64_t v___x_50_; uint64_t v_x_51_; uint64_t v___x_52_; uint64_t v___x_53_; uint64_t v___x_54_; 
v___x_42_ = 30ULL;
v___x_43_ = lean_uint64_shift_right(v_key_41_, v___x_42_);
v___x_44_ = lean_uint64_xor(v_key_41_, v___x_43_);
v___x_45_ = 13787848793156543929ULL;
v_x_46_ = lean_uint64_mul(v___x_44_, v___x_45_);
v___x_47_ = 27ULL;
v___x_48_ = lean_uint64_shift_right(v_x_46_, v___x_47_);
v___x_49_ = lean_uint64_xor(v_x_46_, v___x_48_);
v___x_50_ = 10723151780598845931ULL;
v_x_51_ = lean_uint64_mul(v___x_49_, v___x_50_);
v___x_52_ = 31ULL;
v___x_53_ = lean_uint64_shift_right(v_x_51_, v___x_52_);
v___x_54_ = lean_uint64_xor(v_x_51_, v___x_53_);
return v___x_54_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_IndexPair_hash___boxed(lean_object* v_key_55_){
_start:
{
uint64_t v_key_boxed_56_; uint64_t v_res_57_; lean_object* v_r_58_; 
v_key_boxed_56_ = lean_unbox_uint64(v_key_55_);
lean_dec_ref(v_key_55_);
v_res_57_ = lp_Hex_Hex_Groebner_IndexPair_hash(v_key_boxed_56_);
v_r_58_ = lean_box_uint64(v_res_57_);
return v_r_58_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Std_Data_HashMap(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_IndexPair(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Std_Data_HashMap(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_IndexPair(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Std_Data_HashMap(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_IndexPair(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Std_Data_HashMap(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_IndexPair(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_IndexPair(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_IndexPair(builtin);
}
#ifdef __cplusplus
}
#endif
