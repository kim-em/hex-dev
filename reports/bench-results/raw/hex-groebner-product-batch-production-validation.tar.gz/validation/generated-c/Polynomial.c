// Lean compiler output
// Module: HexGroebner.Polynomial
// Imports: public import Init public meta import Init public import HexGroebner.Runtime public import HexMvPoly.Basic
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
extern lean_object* lp_Hex_Hex_Groebner_instInhabitedRawTerm_default;
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t lean_uint64_dec_le(uint64_t, uint64_t);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* lp_Hex_Hex_Groebner_Computation_intern(lean_object*, lean_object*, lean_object*);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
size_t lean_uint64_to_usize(uint64_t);
size_t lean_usize_of_nat(lean_object*);
size_t lean_usize_sub(size_t, size_t);
size_t lean_usize_land(size_t, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* lean_array_propagate_mark(lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* lean_array_fset(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
uint64_t lean_uint64_add(uint64_t, uint64_t);
uint64_t lean_uint64_sub(uint64_t, uint64_t);
uint8_t lean_uint64_to_uint8(uint64_t);
lean_object* lean_byte_array_push(lean_object*, uint8_t);
uint8_t lp_Hex_Hex_Groebner_PrimeField_width(uint64_t);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
lean_object* lean_byte_array_size(lean_object*);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
uint8_t lean_byte_array_uget(lean_object*, size_t);
lean_object* lean_usize_to_nat(size_t);
lean_object* lean_uint64_to_nat(uint64_t);
uint8_t lp_Hex_Hex_Groebner_MonomialTable_compare(lean_object*, uint8_t, lean_object*, lean_object*);
lean_object* l_instMonadOption___lam__0(lean_object*, lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Computation_allocate(lean_object*, lean_object*, lean_object*);
extern lean_object* l_ByteArray_empty;
uint64_t lp_Hex_Hex_ZMod64_ofNat___redArg(lean_object*, lean_object*);
lean_object* l_Option_bind(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instMonadOption___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instMonadOption___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instMonadOption___lam__1(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instFunctorOption___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Option_map(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* l_List_mapM_loop___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_TermOrder_cmp___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
uint64_t lp_Hex_Hex_ZMod64_zero___redArg(lean_object*);
lean_object* lp_Hex_Hex_ZMod64_addImpl___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_ZMod64_instDecidableEq___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instBEqOfDecidableEq___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_MvPoly_ofTerms___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__6(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Computation_combine(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
uint64_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Computation_products(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Array_range(lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lp_Hex_Hex_Groebner_MonomialTable_exponentsAt(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_MvPoly_termsList___redArg(lean_object*);
lean_object* lean_array_mk(lean_object*);
lean_object* l_Id_instMonad___lam__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__3(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__2___boxed(lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
lean_object* l_mkPanicMessageWithDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_panic_fn_borrowed(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Computation_inverse(uint64_t, lean_object*, uint64_t, lean_object*);
uint64_t lp_Hex_BarrettCtx_mk___redArg(uint64_t);
lean_object* lean_mk_empty_byte_array(lean_object*);
uint64_t lp_Hex_BarrettCtx_mulMod(uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* lp_Hex_Hex_Groebner_Computation_sort(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_bytes(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_bytes___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Polynomial_0__Hex_Groebner_Polynomial_append(uint64_t, lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Polynomial_0__Hex_Groebner_Polynomial_append___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3___redArg___boxed(lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 2}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(2, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___closed__0_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___closed__0_value)}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___closed__1 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__3___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3_spec__12___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
LEAN_EXPORT const lean_object* lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13___boxed__const__1 = (const lean_object*)&lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13___boxed__const__1_value;
LEAN_EXPORT uint64_t lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13___boxed(lean_object*);
static const lean_string_object lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 43, .m_capacity = 43, .m_length = 42, .m_data = "Std.Data.DHashMap.Internal.AssocList.Basic"};
static const lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__0 = (const lean_object*)&lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__0_value;
static const lean_string_object lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 37, .m_capacity = 37, .m_length = 36, .m_data = "Std.DHashMap.Internal.AssocList.get!"};
static const lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__1 = (const lean_object*)&lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__1_value;
static const lean_string_object lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "key is not present in hash table"};
static const lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__2 = (const lean_object*)&lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__2_value;
static lean_once_cell_t lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__3;
LEAN_EXPORT uint64_t lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__7(lean_object*, uint64_t, lean_object*, size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_normalize_spec__5(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_normalize_spec__5___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00Hex_Groebner_Polynomial_normalize_spec__8(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00Hex_Groebner_Polynomial_normalize_spec__8___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_Polynomial_normalize_spec__9(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_Polynomial_normalize_spec__9___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Groebner_Polynomial_normalize___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_Polynomial_normalize___closed__0;
static lean_once_cell_t lp_Hex_Hex_Groebner_Polynomial_normalize___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_Polynomial_normalize___closed__1;
static lean_once_cell_t lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2;
static const lean_ctor_object lp_Hex_Hex_Groebner_Polynomial_normalize___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 3}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_normalize___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_normalize___closed__3_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Polynomial_normalize___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_normalize___closed__3_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_normalize___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_normalize___closed__4_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_normalize(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_normalize___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3_spec__12(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg(uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Groebner_Polynomial_scale___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_Polynomial_scale___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_scale(lean_object*, lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_scale___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0(uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monic(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monic___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_multiply___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_multiply(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_multiply___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0___redArg(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex_Hex_Groebner_Polynomial_subtract___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_subtract___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_subtract___closed__0_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_Polynomial_subtract___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_Polynomial_subtract___closed__1;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_subtract(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_subtract___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_sPolynomial(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_sPolynomial___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0(lean_object*, uint64_t, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toRaw(uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toRaw___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instMonadOption___lam__0, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__0_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instMonadOption___lam__1, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__1_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instMonadOption___lam__2___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__2_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instMonadOption___lam__3___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__3_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instFunctorOption___lam__0, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__4_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Option_map, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__5_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__5_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__6_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__6_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__0_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__1_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__2_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__3_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__7 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__7_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Option_bind, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__7_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__8_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__9_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg(uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___lam__0___boxed(lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__0_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__0, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__1_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__1___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__2_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__2___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__3_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__3, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__4_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__4___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__5_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__5___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__6_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__6, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__7 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__7_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__1_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__8_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__3_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__4_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__5_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__6_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__9_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__9_value),((lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__7_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__10 = (const lean_object*)&lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__10_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_bytes(lean_object* v_context_1_, lean_object* v_p_2_){
_start:
{
lean_object* v_support_3_; uint64_t v_field_4_; lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; lean_object* v___y_10_; uint8_t v___x_13_; 
v_support_3_ = lean_ctor_get(v_p_2_, 0);
v_field_4_ = lean_ctor_get_uint64(v_context_1_, sizeof(void*)*1);
v___x_5_ = lean_byte_array_size(v_support_3_);
v___x_6_ = lean_unsigned_to_nat(2u);
v___x_7_ = lean_nat_shiftr(v___x_5_, v___x_6_);
v___x_8_ = lean_unsigned_to_nat(4u);
v___x_13_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_4_);
switch(v___x_13_)
{
case 0:
{
lean_object* v___x_14_; 
v___x_14_ = lean_unsigned_to_nat(1u);
v___y_10_ = v___x_14_;
goto v___jp_9_;
}
case 1:
{
v___y_10_ = v___x_6_;
goto v___jp_9_;
}
default: 
{
v___y_10_ = v___x_8_;
goto v___jp_9_;
}
}
v___jp_9_:
{
lean_object* v___x_11_; lean_object* v___x_12_; 
v___x_11_ = lean_nat_add(v___x_8_, v___y_10_);
v___x_12_ = lean_nat_mul(v___x_7_, v___x_11_);
lean_dec(v___x_11_);
lean_dec(v___x_7_);
return v___x_12_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_bytes___boxed(lean_object* v_context_15_, lean_object* v_p_16_){
_start:
{
lean_object* v_res_17_; 
v_res_17_ = lp_Hex_Hex_Groebner_Polynomial_bytes(v_context_15_, v_p_16_);
lean_dec_ref(v_p_16_);
lean_dec_ref(v_context_15_);
return v_res_17_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Polynomial_0__Hex_Groebner_Polynomial_append(uint64_t v_field_18_, lean_object* v_p_19_, lean_object* v_id_20_, uint64_t v_c_21_){
_start:
{
lean_object* v_support_22_; lean_object* v_coefficients_23_; lean_object* v___x_25_; uint8_t v_isShared_26_; uint8_t v_isSharedCheck_66_; 
v_support_22_ = lean_ctor_get(v_p_19_, 0);
v_coefficients_23_ = lean_ctor_get(v_p_19_, 1);
v_isSharedCheck_66_ = !lean_is_exclusive(v_p_19_);
if (v_isSharedCheck_66_ == 0)
{
v___x_25_ = v_p_19_;
v_isShared_26_ = v_isSharedCheck_66_;
goto v_resetjp_24_;
}
else
{
lean_inc(v_coefficients_23_);
lean_inc(v_support_22_);
lean_dec(v_p_19_);
v___x_25_ = lean_box(0);
v_isShared_26_ = v_isSharedCheck_66_;
goto v_resetjp_24_;
}
v_resetjp_24_:
{
uint64_t v___x_27_; uint8_t v___x_28_; lean_object* v_data_29_; uint64_t v___x_30_; uint64_t v___x_31_; uint8_t v___x_32_; lean_object* v___x_33_; uint64_t v___x_34_; uint64_t v___x_35_; uint8_t v___x_36_; lean_object* v___x_37_; uint64_t v___x_38_; uint64_t v___x_39_; uint8_t v___x_40_; lean_object* v___x_41_; uint8_t v___x_42_; uint8_t v___x_43_; lean_object* v_data_44_; 
v___x_27_ = lean_uint64_of_nat(v_id_20_);
v___x_28_ = lean_uint64_to_uint8(v___x_27_);
v_data_29_ = lean_byte_array_push(v_support_22_, v___x_28_);
v___x_30_ = 8ULL;
v___x_31_ = lean_uint64_shift_right(v___x_27_, v___x_30_);
v___x_32_ = lean_uint64_to_uint8(v___x_31_);
v___x_33_ = lean_byte_array_push(v_data_29_, v___x_32_);
v___x_34_ = 16ULL;
v___x_35_ = lean_uint64_shift_right(v___x_27_, v___x_34_);
v___x_36_ = lean_uint64_to_uint8(v___x_35_);
v___x_37_ = lean_byte_array_push(v___x_33_, v___x_36_);
v___x_38_ = 24ULL;
v___x_39_ = lean_uint64_shift_right(v___x_27_, v___x_38_);
v___x_40_ = lean_uint64_to_uint8(v___x_39_);
v___x_41_ = lean_byte_array_push(v___x_37_, v___x_40_);
v___x_42_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_18_);
v___x_43_ = lean_uint64_to_uint8(v_c_21_);
v_data_44_ = lean_byte_array_push(v_coefficients_23_, v___x_43_);
switch(v___x_42_)
{
case 0:
{
lean_object* v___x_46_; 
if (v_isShared_26_ == 0)
{
lean_ctor_set(v___x_25_, 1, v_data_44_);
lean_ctor_set(v___x_25_, 0, v___x_41_);
v___x_46_ = v___x_25_;
goto v_reusejp_45_;
}
else
{
lean_object* v_reuseFailAlloc_47_; 
v_reuseFailAlloc_47_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_47_, 0, v___x_41_);
lean_ctor_set(v_reuseFailAlloc_47_, 1, v_data_44_);
v___x_46_ = v_reuseFailAlloc_47_;
goto v_reusejp_45_;
}
v_reusejp_45_:
{
return v___x_46_;
}
}
case 1:
{
uint64_t v___x_48_; uint8_t v___x_49_; lean_object* v___x_50_; lean_object* v___x_52_; 
v___x_48_ = lean_uint64_shift_right(v_c_21_, v___x_30_);
v___x_49_ = lean_uint64_to_uint8(v___x_48_);
v___x_50_ = lean_byte_array_push(v_data_44_, v___x_49_);
if (v_isShared_26_ == 0)
{
lean_ctor_set(v___x_25_, 1, v___x_50_);
lean_ctor_set(v___x_25_, 0, v___x_41_);
v___x_52_ = v___x_25_;
goto v_reusejp_51_;
}
else
{
lean_object* v_reuseFailAlloc_53_; 
v_reuseFailAlloc_53_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_53_, 0, v___x_41_);
lean_ctor_set(v_reuseFailAlloc_53_, 1, v___x_50_);
v___x_52_ = v_reuseFailAlloc_53_;
goto v_reusejp_51_;
}
v_reusejp_51_:
{
return v___x_52_;
}
}
default: 
{
uint64_t v___x_54_; uint8_t v___x_55_; lean_object* v___x_56_; uint64_t v___x_57_; uint8_t v___x_58_; lean_object* v___x_59_; uint64_t v___x_60_; uint8_t v___x_61_; lean_object* v___x_62_; lean_object* v___x_64_; 
v___x_54_ = lean_uint64_shift_right(v_c_21_, v___x_30_);
v___x_55_ = lean_uint64_to_uint8(v___x_54_);
v___x_56_ = lean_byte_array_push(v_data_44_, v___x_55_);
v___x_57_ = lean_uint64_shift_right(v_c_21_, v___x_34_);
v___x_58_ = lean_uint64_to_uint8(v___x_57_);
v___x_59_ = lean_byte_array_push(v___x_56_, v___x_58_);
v___x_60_ = lean_uint64_shift_right(v_c_21_, v___x_38_);
v___x_61_ = lean_uint64_to_uint8(v___x_60_);
v___x_62_ = lean_byte_array_push(v___x_59_, v___x_61_);
if (v_isShared_26_ == 0)
{
lean_ctor_set(v___x_25_, 1, v___x_62_);
lean_ctor_set(v___x_25_, 0, v___x_41_);
v___x_64_ = v___x_25_;
goto v_reusejp_63_;
}
else
{
lean_object* v_reuseFailAlloc_65_; 
v_reuseFailAlloc_65_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_65_, 0, v___x_41_);
lean_ctor_set(v_reuseFailAlloc_65_, 1, v___x_62_);
v___x_64_ = v_reuseFailAlloc_65_;
goto v_reusejp_63_;
}
v_reusejp_63_:
{
return v___x_64_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Polynomial_0__Hex_Groebner_Polynomial_append___boxed(lean_object* v_field_67_, lean_object* v_p_68_, lean_object* v_id_69_, lean_object* v_c_70_){
_start:
{
uint64_t v_field_boxed_71_; uint64_t v_c_boxed_72_; lean_object* v_res_73_; 
v_field_boxed_71_ = lean_unbox_uint64(v_field_67_);
lean_dec_ref(v_field_67_);
v_c_boxed_72_ = lean_unbox_uint64(v_c_70_);
lean_dec_ref(v_c_70_);
v_res_73_ = lp_Hex___private_HexGroebner_Polynomial_0__Hex_Groebner_Polynomial_append(v_field_boxed_71_, v_p_68_, v_id_69_, v_c_boxed_72_);
lean_dec(v_id_69_);
return v_res_73_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7___redArg(lean_object* v_a_74_, lean_object* v_x_75_){
_start:
{
if (lean_obj_tag(v_x_75_) == 0)
{
lean_object* v___x_76_; 
v___x_76_ = lean_box(0);
return v___x_76_;
}
else
{
lean_object* v_key_77_; lean_object* v_value_78_; lean_object* v_tail_79_; uint8_t v___x_80_; 
v_key_77_ = lean_ctor_get(v_x_75_, 0);
v_value_78_ = lean_ctor_get(v_x_75_, 1);
v_tail_79_ = lean_ctor_get(v_x_75_, 2);
v___x_80_ = lean_nat_dec_eq(v_key_77_, v_a_74_);
if (v___x_80_ == 0)
{
v_x_75_ = v_tail_79_;
goto _start;
}
else
{
lean_object* v___x_82_; 
lean_inc(v_value_78_);
v___x_82_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_82_, 0, v_value_78_);
return v___x_82_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7___redArg___boxed(lean_object* v_a_83_, lean_object* v_x_84_){
_start:
{
lean_object* v_res_85_; 
v_res_85_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7___redArg(v_a_83_, v_x_84_);
lean_dec(v_x_84_);
lean_dec(v_a_83_);
return v_res_85_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3___redArg(lean_object* v_m_86_, lean_object* v_a_87_){
_start:
{
lean_object* v_buckets_88_; lean_object* v___x_89_; uint64_t v___x_90_; uint64_t v___x_91_; uint64_t v___x_92_; uint64_t v_fold_93_; uint64_t v___x_94_; uint64_t v___x_95_; uint64_t v___x_96_; size_t v___x_97_; size_t v___x_98_; size_t v___x_99_; size_t v___x_100_; size_t v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; 
v_buckets_88_ = lean_ctor_get(v_m_86_, 1);
v___x_89_ = lean_array_get_size(v_buckets_88_);
v___x_90_ = lean_uint64_of_nat(v_a_87_);
v___x_91_ = 32ULL;
v___x_92_ = lean_uint64_shift_right(v___x_90_, v___x_91_);
v_fold_93_ = lean_uint64_xor(v___x_90_, v___x_92_);
v___x_94_ = 16ULL;
v___x_95_ = lean_uint64_shift_right(v_fold_93_, v___x_94_);
v___x_96_ = lean_uint64_xor(v_fold_93_, v___x_95_);
v___x_97_ = lean_uint64_to_usize(v___x_96_);
v___x_98_ = lean_usize_of_nat(v___x_89_);
v___x_99_ = ((size_t)1ULL);
v___x_100_ = lean_usize_sub(v___x_98_, v___x_99_);
v___x_101_ = lean_usize_land(v___x_97_, v___x_100_);
v___x_102_ = lean_array_uget_borrowed(v_buckets_88_, v___x_101_);
v___x_103_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7___redArg(v_a_87_, v___x_102_);
return v___x_103_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3___redArg___boxed(lean_object* v_m_104_, lean_object* v_a_105_){
_start:
{
lean_object* v_res_106_; 
v_res_106_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3___redArg(v_m_104_, v_a_105_);
lean_dec(v_a_105_);
lean_dec_ref(v_m_104_);
return v_res_106_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0(lean_object* v_as_111_, size_t v_sz_112_, size_t v_i_113_, lean_object* v_b_114_, lean_object* v___y_115_){
_start:
{
uint8_t v___x_116_; 
v___x_116_ = lean_usize_dec_lt(v_i_113_, v_sz_112_);
if (v___x_116_ == 0)
{
lean_object* v___x_117_; lean_object* v___x_118_; 
v___x_117_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_117_, 0, v_b_114_);
v___x_118_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_118_, 0, v___x_117_);
lean_ctor_set(v___x_118_, 1, v___y_115_);
return v___x_118_;
}
else
{
lean_object* v_a_119_; lean_object* v___x_120_; uint8_t v___x_121_; 
v_a_119_ = lean_array_uget_borrowed(v_as_111_, v_i_113_);
v___x_120_ = lean_unsigned_to_nat(4294967295u);
v___x_121_ = lean_nat_dec_lt(v___x_120_, v_a_119_);
if (v___x_121_ == 0)
{
uint64_t v___x_122_; lean_object* v___x_123_; lean_object* v___x_124_; size_t v___x_125_; size_t v___x_126_; 
v___x_122_ = lean_uint64_of_nat(v_a_119_);
v___x_123_ = lean_box_uint64(v___x_122_);
v___x_124_ = lean_array_push(v_b_114_, v___x_123_);
v___x_125_ = ((size_t)1ULL);
v___x_126_ = lean_usize_add(v_i_113_, v___x_125_);
v_i_113_ = v___x_126_;
v_b_114_ = v___x_124_;
goto _start;
}
else
{
lean_object* v___x_128_; lean_object* v___x_129_; 
lean_dec_ref(v_b_114_);
v___x_128_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___closed__1));
v___x_129_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_129_, 0, v___x_128_);
lean_ctor_set(v___x_129_, 1, v___y_115_);
return v___x_129_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0___boxed(lean_object* v_as_130_, lean_object* v_sz_131_, lean_object* v_i_132_, lean_object* v_b_133_, lean_object* v___y_134_){
_start:
{
size_t v_sz_boxed_135_; size_t v_i_boxed_136_; lean_object* v_res_137_; 
v_sz_boxed_135_ = lean_unbox_usize(v_sz_131_);
lean_dec(v_sz_131_);
v_i_boxed_136_ = lean_unbox_usize(v_i_132_);
lean_dec(v_i_132_);
v_res_137_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0(v_as_130_, v_sz_boxed_135_, v_i_boxed_136_, v_b_133_, v___y_134_);
lean_dec_ref(v_as_130_);
return v_res_137_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__3___redArg(lean_object* v_a_138_, lean_object* v_b_139_, lean_object* v_x_140_){
_start:
{
if (lean_obj_tag(v_x_140_) == 0)
{
lean_dec(v_b_139_);
lean_dec(v_a_138_);
return v_x_140_;
}
else
{
lean_object* v_key_141_; lean_object* v_value_142_; lean_object* v_tail_143_; lean_object* v___x_145_; uint8_t v_isShared_146_; uint8_t v_isSharedCheck_155_; 
v_key_141_ = lean_ctor_get(v_x_140_, 0);
v_value_142_ = lean_ctor_get(v_x_140_, 1);
v_tail_143_ = lean_ctor_get(v_x_140_, 2);
v_isSharedCheck_155_ = !lean_is_exclusive(v_x_140_);
if (v_isSharedCheck_155_ == 0)
{
v___x_145_ = v_x_140_;
v_isShared_146_ = v_isSharedCheck_155_;
goto v_resetjp_144_;
}
else
{
lean_inc(v_tail_143_);
lean_inc(v_value_142_);
lean_inc(v_key_141_);
lean_dec(v_x_140_);
v___x_145_ = lean_box(0);
v_isShared_146_ = v_isSharedCheck_155_;
goto v_resetjp_144_;
}
v_resetjp_144_:
{
uint8_t v___x_147_; 
v___x_147_ = lean_nat_dec_eq(v_key_141_, v_a_138_);
if (v___x_147_ == 0)
{
lean_object* v___x_148_; lean_object* v___x_150_; 
v___x_148_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__3___redArg(v_a_138_, v_b_139_, v_tail_143_);
if (v_isShared_146_ == 0)
{
lean_ctor_set(v___x_145_, 2, v___x_148_);
v___x_150_ = v___x_145_;
goto v_reusejp_149_;
}
else
{
lean_object* v_reuseFailAlloc_151_; 
v_reuseFailAlloc_151_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_151_, 0, v_key_141_);
lean_ctor_set(v_reuseFailAlloc_151_, 1, v_value_142_);
lean_ctor_set(v_reuseFailAlloc_151_, 2, v___x_148_);
v___x_150_ = v_reuseFailAlloc_151_;
goto v_reusejp_149_;
}
v_reusejp_149_:
{
return v___x_150_;
}
}
else
{
lean_object* v___x_153_; 
lean_dec(v_value_142_);
lean_dec(v_key_141_);
if (v_isShared_146_ == 0)
{
lean_ctor_set(v___x_145_, 1, v_b_139_);
lean_ctor_set(v___x_145_, 0, v_a_138_);
v___x_153_ = v___x_145_;
goto v_reusejp_152_;
}
else
{
lean_object* v_reuseFailAlloc_154_; 
v_reuseFailAlloc_154_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_154_, 0, v_a_138_);
lean_ctor_set(v_reuseFailAlloc_154_, 1, v_b_139_);
lean_ctor_set(v_reuseFailAlloc_154_, 2, v_tail_143_);
v___x_153_ = v_reuseFailAlloc_154_;
goto v_reusejp_152_;
}
v_reusejp_152_:
{
return v___x_153_;
}
}
}
}
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___redArg(lean_object* v_a_156_, lean_object* v_x_157_){
_start:
{
if (lean_obj_tag(v_x_157_) == 0)
{
uint8_t v___x_158_; 
v___x_158_ = 0;
return v___x_158_;
}
else
{
lean_object* v_key_159_; lean_object* v_tail_160_; uint8_t v___x_161_; 
v_key_159_ = lean_ctor_get(v_x_157_, 0);
v_tail_160_ = lean_ctor_get(v_x_157_, 2);
v___x_161_ = lean_nat_dec_eq(v_key_159_, v_a_156_);
if (v___x_161_ == 0)
{
v_x_157_ = v_tail_160_;
goto _start;
}
else
{
return v___x_161_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___redArg___boxed(lean_object* v_a_163_, lean_object* v_x_164_){
_start:
{
uint8_t v_res_165_; lean_object* v_r_166_; 
v_res_165_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___redArg(v_a_163_, v_x_164_);
lean_dec(v_x_164_);
lean_dec(v_a_163_);
v_r_166_ = lean_box(v_res_165_);
return v_r_166_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3_spec__12___redArg(lean_object* v_x_167_, lean_object* v_x_168_){
_start:
{
if (lean_obj_tag(v_x_168_) == 0)
{
return v_x_167_;
}
else
{
lean_object* v_key_169_; lean_object* v_value_170_; lean_object* v_tail_171_; lean_object* v___x_173_; uint8_t v_isShared_174_; uint8_t v_isSharedCheck_194_; 
v_key_169_ = lean_ctor_get(v_x_168_, 0);
v_value_170_ = lean_ctor_get(v_x_168_, 1);
v_tail_171_ = lean_ctor_get(v_x_168_, 2);
v_isSharedCheck_194_ = !lean_is_exclusive(v_x_168_);
if (v_isSharedCheck_194_ == 0)
{
v___x_173_ = v_x_168_;
v_isShared_174_ = v_isSharedCheck_194_;
goto v_resetjp_172_;
}
else
{
lean_inc(v_tail_171_);
lean_inc(v_value_170_);
lean_inc(v_key_169_);
lean_dec(v_x_168_);
v___x_173_ = lean_box(0);
v_isShared_174_ = v_isSharedCheck_194_;
goto v_resetjp_172_;
}
v_resetjp_172_:
{
lean_object* v___x_175_; uint64_t v___x_176_; uint64_t v___x_177_; uint64_t v___x_178_; uint64_t v_fold_179_; uint64_t v___x_180_; uint64_t v___x_181_; uint64_t v___x_182_; size_t v___x_183_; size_t v___x_184_; size_t v___x_185_; size_t v___x_186_; size_t v___x_187_; lean_object* v___x_188_; lean_object* v___x_190_; 
v___x_175_ = lean_array_get_size(v_x_167_);
v___x_176_ = lean_uint64_of_nat(v_key_169_);
v___x_177_ = 32ULL;
v___x_178_ = lean_uint64_shift_right(v___x_176_, v___x_177_);
v_fold_179_ = lean_uint64_xor(v___x_176_, v___x_178_);
v___x_180_ = 16ULL;
v___x_181_ = lean_uint64_shift_right(v_fold_179_, v___x_180_);
v___x_182_ = lean_uint64_xor(v_fold_179_, v___x_181_);
v___x_183_ = lean_uint64_to_usize(v___x_182_);
v___x_184_ = lean_usize_of_nat(v___x_175_);
v___x_185_ = ((size_t)1ULL);
v___x_186_ = lean_usize_sub(v___x_184_, v___x_185_);
v___x_187_ = lean_usize_land(v___x_183_, v___x_186_);
v___x_188_ = lean_array_uget_borrowed(v_x_167_, v___x_187_);
lean_inc(v___x_188_);
if (v_isShared_174_ == 0)
{
lean_ctor_set(v___x_173_, 2, v___x_188_);
v___x_190_ = v___x_173_;
goto v_reusejp_189_;
}
else
{
lean_object* v_reuseFailAlloc_193_; 
v_reuseFailAlloc_193_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_193_, 0, v_key_169_);
lean_ctor_set(v_reuseFailAlloc_193_, 1, v_value_170_);
lean_ctor_set(v_reuseFailAlloc_193_, 2, v___x_188_);
v___x_190_ = v_reuseFailAlloc_193_;
goto v_reusejp_189_;
}
v_reusejp_189_:
{
lean_object* v___x_191_; 
v___x_191_ = lean_array_uset(v_x_167_, v___x_187_, v___x_190_);
v_x_167_ = v___x_191_;
v_x_168_ = v_tail_171_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3___redArg(lean_object* v_i_195_, lean_object* v_source_196_, lean_object* v_target_197_){
_start:
{
lean_object* v___x_198_; uint8_t v___x_199_; 
v___x_198_ = lean_array_get_size(v_source_196_);
v___x_199_ = lean_nat_dec_lt(v_i_195_, v___x_198_);
if (v___x_199_ == 0)
{
lean_dec_ref(v_source_196_);
lean_dec(v_i_195_);
return v_target_197_;
}
else
{
lean_object* v_es_200_; lean_object* v___x_201_; lean_object* v_source_202_; lean_object* v_target_203_; lean_object* v___x_204_; lean_object* v___x_205_; 
v_es_200_ = lean_array_fget(v_source_196_, v_i_195_);
v___x_201_ = lean_box(0);
v_source_202_ = lean_array_fset(v_source_196_, v_i_195_, v___x_201_);
v_target_203_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3_spec__12___redArg(v_target_197_, v_es_200_);
v___x_204_ = lean_unsigned_to_nat(1u);
v___x_205_ = lean_nat_add(v_i_195_, v___x_204_);
lean_dec(v_i_195_);
v_i_195_ = v___x_205_;
v_source_196_ = v_source_202_;
v_target_197_ = v_target_203_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2___redArg(lean_object* v_data_207_){
_start:
{
lean_object* v___x_208_; lean_object* v___x_209_; lean_object* v_nbuckets_210_; lean_object* v___x_211_; lean_object* v___x_212_; lean_object* v___x_213_; lean_object* v___x_214_; lean_object* v___x_215_; 
v___x_208_ = lean_array_get_size(v_data_207_);
v___x_209_ = lean_unsigned_to_nat(2u);
v_nbuckets_210_ = lean_nat_mul(v___x_208_, v___x_209_);
v___x_211_ = lean_unsigned_to_nat(0u);
v___x_212_ = lean_box(0);
v___x_213_ = lean_mk_array(v_nbuckets_210_, v___x_212_);
v___x_214_ = lean_array_propagate_mark(v_data_207_, v___x_213_);
v___x_215_ = lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3___redArg(v___x_211_, v_data_207_, v___x_214_);
return v___x_215_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1___redArg(lean_object* v_m_216_, lean_object* v_a_217_, lean_object* v_b_218_){
_start:
{
lean_object* v_size_219_; lean_object* v_buckets_220_; lean_object* v___x_222_; uint8_t v_isShared_223_; uint8_t v_isSharedCheck_263_; 
v_size_219_ = lean_ctor_get(v_m_216_, 0);
v_buckets_220_ = lean_ctor_get(v_m_216_, 1);
v_isSharedCheck_263_ = !lean_is_exclusive(v_m_216_);
if (v_isSharedCheck_263_ == 0)
{
v___x_222_ = v_m_216_;
v_isShared_223_ = v_isSharedCheck_263_;
goto v_resetjp_221_;
}
else
{
lean_inc(v_buckets_220_);
lean_inc(v_size_219_);
lean_dec(v_m_216_);
v___x_222_ = lean_box(0);
v_isShared_223_ = v_isSharedCheck_263_;
goto v_resetjp_221_;
}
v_resetjp_221_:
{
lean_object* v___x_224_; uint64_t v___x_225_; uint64_t v___x_226_; uint64_t v___x_227_; uint64_t v_fold_228_; uint64_t v___x_229_; uint64_t v___x_230_; uint64_t v___x_231_; size_t v___x_232_; size_t v___x_233_; size_t v___x_234_; size_t v___x_235_; size_t v___x_236_; lean_object* v_bkt_237_; uint8_t v___x_238_; 
v___x_224_ = lean_array_get_size(v_buckets_220_);
v___x_225_ = lean_uint64_of_nat(v_a_217_);
v___x_226_ = 32ULL;
v___x_227_ = lean_uint64_shift_right(v___x_225_, v___x_226_);
v_fold_228_ = lean_uint64_xor(v___x_225_, v___x_227_);
v___x_229_ = 16ULL;
v___x_230_ = lean_uint64_shift_right(v_fold_228_, v___x_229_);
v___x_231_ = lean_uint64_xor(v_fold_228_, v___x_230_);
v___x_232_ = lean_uint64_to_usize(v___x_231_);
v___x_233_ = lean_usize_of_nat(v___x_224_);
v___x_234_ = ((size_t)1ULL);
v___x_235_ = lean_usize_sub(v___x_233_, v___x_234_);
v___x_236_ = lean_usize_land(v___x_232_, v___x_235_);
v_bkt_237_ = lean_array_uget_borrowed(v_buckets_220_, v___x_236_);
v___x_238_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___redArg(v_a_217_, v_bkt_237_);
if (v___x_238_ == 0)
{
lean_object* v___x_239_; lean_object* v_size_x27_240_; lean_object* v___x_241_; lean_object* v_buckets_x27_242_; lean_object* v___x_243_; lean_object* v___x_244_; lean_object* v___x_245_; lean_object* v___x_246_; lean_object* v___x_247_; uint8_t v___x_248_; 
v___x_239_ = lean_unsigned_to_nat(1u);
v_size_x27_240_ = lean_nat_add(v_size_219_, v___x_239_);
lean_dec(v_size_219_);
lean_inc(v_bkt_237_);
v___x_241_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v___x_241_, 0, v_a_217_);
lean_ctor_set(v___x_241_, 1, v_b_218_);
lean_ctor_set(v___x_241_, 2, v_bkt_237_);
v_buckets_x27_242_ = lean_array_uset(v_buckets_220_, v___x_236_, v___x_241_);
v___x_243_ = lean_unsigned_to_nat(4u);
v___x_244_ = lean_nat_mul(v_size_x27_240_, v___x_243_);
v___x_245_ = lean_unsigned_to_nat(3u);
v___x_246_ = lean_nat_div(v___x_244_, v___x_245_);
lean_dec(v___x_244_);
v___x_247_ = lean_array_get_size(v_buckets_x27_242_);
v___x_248_ = lean_nat_dec_le(v___x_246_, v___x_247_);
lean_dec(v___x_246_);
if (v___x_248_ == 0)
{
lean_object* v_val_249_; lean_object* v___x_251_; 
v_val_249_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2___redArg(v_buckets_x27_242_);
if (v_isShared_223_ == 0)
{
lean_ctor_set(v___x_222_, 1, v_val_249_);
lean_ctor_set(v___x_222_, 0, v_size_x27_240_);
v___x_251_ = v___x_222_;
goto v_reusejp_250_;
}
else
{
lean_object* v_reuseFailAlloc_252_; 
v_reuseFailAlloc_252_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_252_, 0, v_size_x27_240_);
lean_ctor_set(v_reuseFailAlloc_252_, 1, v_val_249_);
v___x_251_ = v_reuseFailAlloc_252_;
goto v_reusejp_250_;
}
v_reusejp_250_:
{
return v___x_251_;
}
}
else
{
lean_object* v___x_254_; 
if (v_isShared_223_ == 0)
{
lean_ctor_set(v___x_222_, 1, v_buckets_x27_242_);
lean_ctor_set(v___x_222_, 0, v_size_x27_240_);
v___x_254_ = v___x_222_;
goto v_reusejp_253_;
}
else
{
lean_object* v_reuseFailAlloc_255_; 
v_reuseFailAlloc_255_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_255_, 0, v_size_x27_240_);
lean_ctor_set(v_reuseFailAlloc_255_, 1, v_buckets_x27_242_);
v___x_254_ = v_reuseFailAlloc_255_;
goto v_reusejp_253_;
}
v_reusejp_253_:
{
return v___x_254_;
}
}
}
else
{
lean_object* v___x_256_; lean_object* v_buckets_x27_257_; lean_object* v___x_258_; lean_object* v___x_259_; lean_object* v___x_261_; 
lean_inc(v_bkt_237_);
v___x_256_ = lean_box(0);
v_buckets_x27_257_ = lean_array_uset(v_buckets_220_, v___x_236_, v___x_256_);
v___x_258_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__3___redArg(v_a_217_, v_b_218_, v_bkt_237_);
v___x_259_ = lean_array_uset(v_buckets_x27_257_, v___x_236_, v___x_258_);
if (v_isShared_223_ == 0)
{
lean_ctor_set(v___x_222_, 1, v___x_259_);
v___x_261_ = v___x_222_;
goto v_reusejp_260_;
}
else
{
lean_object* v_reuseFailAlloc_262_; 
v_reuseFailAlloc_262_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_262_, 0, v_size_219_);
lean_ctor_set(v_reuseFailAlloc_262_, 1, v___x_259_);
v___x_261_ = v_reuseFailAlloc_262_;
goto v_reusejp_260_;
}
v_reusejp_260_:
{
return v___x_261_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___redArg(lean_object* v_a_264_, lean_object* v_x_265_){
_start:
{
if (lean_obj_tag(v_x_265_) == 0)
{
return v_x_265_;
}
else
{
lean_object* v_key_266_; lean_object* v_value_267_; lean_object* v_tail_268_; lean_object* v___x_270_; uint8_t v_isShared_271_; uint8_t v_isSharedCheck_277_; 
v_key_266_ = lean_ctor_get(v_x_265_, 0);
v_value_267_ = lean_ctor_get(v_x_265_, 1);
v_tail_268_ = lean_ctor_get(v_x_265_, 2);
v_isSharedCheck_277_ = !lean_is_exclusive(v_x_265_);
if (v_isSharedCheck_277_ == 0)
{
v___x_270_ = v_x_265_;
v_isShared_271_ = v_isSharedCheck_277_;
goto v_resetjp_269_;
}
else
{
lean_inc(v_tail_268_);
lean_inc(v_value_267_);
lean_inc(v_key_266_);
lean_dec(v_x_265_);
v___x_270_ = lean_box(0);
v_isShared_271_ = v_isSharedCheck_277_;
goto v_resetjp_269_;
}
v_resetjp_269_:
{
uint8_t v___x_272_; 
v___x_272_ = lean_nat_dec_eq(v_key_266_, v_a_264_);
if (v___x_272_ == 0)
{
lean_object* v___x_273_; lean_object* v___x_275_; 
v___x_273_ = lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___redArg(v_a_264_, v_tail_268_);
if (v_isShared_271_ == 0)
{
lean_ctor_set(v___x_270_, 2, v___x_273_);
v___x_275_ = v___x_270_;
goto v_reusejp_274_;
}
else
{
lean_object* v_reuseFailAlloc_276_; 
v_reuseFailAlloc_276_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_276_, 0, v_key_266_);
lean_ctor_set(v_reuseFailAlloc_276_, 1, v_value_267_);
lean_ctor_set(v_reuseFailAlloc_276_, 2, v___x_273_);
v___x_275_ = v_reuseFailAlloc_276_;
goto v_reusejp_274_;
}
v_reusejp_274_:
{
return v___x_275_;
}
}
else
{
lean_del_object(v___x_270_);
lean_dec(v_value_267_);
lean_dec(v_key_266_);
return v_tail_268_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___redArg___boxed(lean_object* v_a_278_, lean_object* v_x_279_){
_start:
{
lean_object* v_res_280_; 
v_res_280_ = lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___redArg(v_a_278_, v_x_279_);
lean_dec(v_a_278_);
return v_res_280_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2___redArg(lean_object* v_m_281_, lean_object* v_a_282_){
_start:
{
lean_object* v_size_283_; lean_object* v_buckets_284_; lean_object* v___x_285_; uint64_t v___x_286_; uint64_t v___x_287_; uint64_t v___x_288_; uint64_t v_fold_289_; uint64_t v___x_290_; uint64_t v___x_291_; uint64_t v___x_292_; size_t v___x_293_; size_t v___x_294_; size_t v___x_295_; size_t v___x_296_; size_t v___x_297_; lean_object* v_bkt_298_; uint8_t v___x_299_; 
v_size_283_ = lean_ctor_get(v_m_281_, 0);
v_buckets_284_ = lean_ctor_get(v_m_281_, 1);
v___x_285_ = lean_array_get_size(v_buckets_284_);
v___x_286_ = lean_uint64_of_nat(v_a_282_);
v___x_287_ = 32ULL;
v___x_288_ = lean_uint64_shift_right(v___x_286_, v___x_287_);
v_fold_289_ = lean_uint64_xor(v___x_286_, v___x_288_);
v___x_290_ = 16ULL;
v___x_291_ = lean_uint64_shift_right(v_fold_289_, v___x_290_);
v___x_292_ = lean_uint64_xor(v_fold_289_, v___x_291_);
v___x_293_ = lean_uint64_to_usize(v___x_292_);
v___x_294_ = lean_usize_of_nat(v___x_285_);
v___x_295_ = ((size_t)1ULL);
v___x_296_ = lean_usize_sub(v___x_294_, v___x_295_);
v___x_297_ = lean_usize_land(v___x_293_, v___x_296_);
v_bkt_298_ = lean_array_uget_borrowed(v_buckets_284_, v___x_297_);
v___x_299_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___redArg(v_a_282_, v_bkt_298_);
if (v___x_299_ == 0)
{
return v_m_281_;
}
else
{
lean_object* v___x_301_; uint8_t v_isShared_302_; uint8_t v_isSharedCheck_312_; 
lean_inc(v_bkt_298_);
lean_inc_ref(v_buckets_284_);
lean_inc(v_size_283_);
v_isSharedCheck_312_ = !lean_is_exclusive(v_m_281_);
if (v_isSharedCheck_312_ == 0)
{
lean_object* v_unused_313_; lean_object* v_unused_314_; 
v_unused_313_ = lean_ctor_get(v_m_281_, 1);
lean_dec(v_unused_313_);
v_unused_314_ = lean_ctor_get(v_m_281_, 0);
lean_dec(v_unused_314_);
v___x_301_ = v_m_281_;
v_isShared_302_ = v_isSharedCheck_312_;
goto v_resetjp_300_;
}
else
{
lean_dec(v_m_281_);
v___x_301_ = lean_box(0);
v_isShared_302_ = v_isSharedCheck_312_;
goto v_resetjp_300_;
}
v_resetjp_300_:
{
lean_object* v___x_303_; lean_object* v_buckets_x27_304_; lean_object* v___x_305_; lean_object* v___x_306_; lean_object* v___x_307_; lean_object* v___x_308_; lean_object* v___x_310_; 
v___x_303_ = lean_box(0);
v_buckets_x27_304_ = lean_array_uset(v_buckets_284_, v___x_297_, v___x_303_);
v___x_305_ = lean_unsigned_to_nat(1u);
v___x_306_ = lean_nat_sub(v_size_283_, v___x_305_);
lean_dec(v_size_283_);
v___x_307_ = lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___redArg(v_a_282_, v_bkt_298_);
v___x_308_ = lean_array_uset(v_buckets_x27_304_, v___x_297_, v___x_307_);
if (v_isShared_302_ == 0)
{
lean_ctor_set(v___x_301_, 1, v___x_308_);
lean_ctor_set(v___x_301_, 0, v___x_306_);
v___x_310_ = v___x_301_;
goto v_reusejp_309_;
}
else
{
lean_object* v_reuseFailAlloc_311_; 
v_reuseFailAlloc_311_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_311_, 0, v___x_306_);
lean_ctor_set(v_reuseFailAlloc_311_, 1, v___x_308_);
v___x_310_ = v_reuseFailAlloc_311_;
goto v_reusejp_309_;
}
v_reusejp_309_:
{
return v___x_310_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2___redArg___boxed(lean_object* v_m_315_, lean_object* v_a_316_){
_start:
{
lean_object* v_res_317_; 
v_res_317_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2___redArg(v_m_315_, v_a_316_);
lean_dec(v_a_316_);
return v_res_317_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4___redArg(lean_object* v_raw_318_, lean_object* v___x_319_, lean_object* v_index_320_, lean_object* v_context_321_, lean_object* v_limits_322_, lean_object* v_range_323_, lean_object* v_b_324_, lean_object* v_i_325_, lean_object* v___y_326_){
_start:
{
lean_object* v_a_328_; lean_object* v_snd_329_; lean_object* v_stop_332_; lean_object* v_step_333_; lean_object* v_a_335_; lean_object* v_snd_336_; uint8_t v___x_339_; 
v_stop_332_ = lean_ctor_get(v_range_323_, 1);
v_step_333_ = lean_ctor_get(v_range_323_, 2);
v___x_339_ = lean_nat_dec_lt(v_i_325_, v_stop_332_);
if (v___x_339_ == 0)
{
lean_object* v___x_340_; lean_object* v___x_341_; 
lean_dec(v_i_325_);
lean_dec_ref(v_limits_322_);
lean_dec(v_index_320_);
v___x_340_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_340_, 0, v_b_324_);
v___x_341_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_341_, 0, v___x_340_);
lean_ctor_set(v___x_341_, 1, v___y_326_);
return v___x_341_;
}
else
{
lean_object* v___x_342_; lean_object* v___x_343_; lean_object* v_exponents_344_; uint64_t v_coefficient_345_; lean_object* v___x_346_; uint8_t v___x_347_; 
v___x_342_ = lp_Hex_Hex_Groebner_instInhabitedRawTerm_default;
v___x_343_ = lean_array_get_borrowed(v___x_342_, v_raw_318_, v_i_325_);
v_exponents_344_ = lean_ctor_get(v___x_343_, 0);
v_coefficient_345_ = lean_ctor_get_uint64(v___x_343_, sizeof(void*)*1);
v___x_346_ = lean_array_get_size(v_exponents_344_);
v___x_347_ = lean_nat_dec_eq(v___x_346_, v___x_319_);
if (v___x_347_ == 0)
{
lean_object* v___x_348_; 
lean_dec_ref(v_b_324_);
lean_dec_ref(v_limits_322_);
v___x_348_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_348_, 0, v_index_320_);
lean_ctor_set(v___x_348_, 1, v_i_325_);
v_a_328_ = v___x_348_;
v_snd_329_ = v___y_326_;
goto v___jp_327_;
}
else
{
uint64_t v_field_349_; uint8_t v___x_350_; 
v_field_349_ = lean_ctor_get_uint64(v_context_321_, sizeof(void*)*1);
v___x_350_ = lean_uint64_dec_le(v_field_349_, v_coefficient_345_);
if (v___x_350_ == 0)
{
uint64_t v___x_351_; uint8_t v___x_352_; 
v___x_351_ = 0ULL;
v___x_352_ = lean_uint64_dec_eq(v_coefficient_345_, v___x_351_);
if (v___x_352_ == 0)
{
lean_object* v___x_353_; size_t v_sz_354_; size_t v___x_355_; lean_object* v___x_356_; lean_object* v_fst_357_; 
v___x_353_ = lean_mk_empty_array_with_capacity(v___x_319_);
v_sz_354_ = lean_array_size(v_exponents_344_);
v___x_355_ = ((size_t)0ULL);
v___x_356_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__0(v_exponents_344_, v_sz_354_, v___x_355_, v___x_353_, v___y_326_);
v_fst_357_ = lean_ctor_get(v___x_356_, 0);
lean_inc(v_fst_357_);
if (lean_obj_tag(v_fst_357_) == 0)
{
lean_object* v_snd_358_; lean_object* v_a_359_; 
lean_dec(v_i_325_);
lean_dec_ref(v_b_324_);
lean_dec_ref(v_limits_322_);
lean_dec(v_index_320_);
v_snd_358_ = lean_ctor_get(v___x_356_, 1);
lean_inc(v_snd_358_);
lean_dec_ref(v___x_356_);
v_a_359_ = lean_ctor_get(v_fst_357_, 0);
lean_inc(v_a_359_);
lean_dec_ref_known(v_fst_357_, 1);
v_a_328_ = v_a_359_;
v_snd_329_ = v_snd_358_;
goto v___jp_327_;
}
else
{
lean_object* v_snd_360_; lean_object* v_a_361_; lean_object* v___x_362_; lean_object* v_fst_363_; 
v_snd_360_ = lean_ctor_get(v___x_356_, 1);
lean_inc(v_snd_360_);
lean_dec_ref(v___x_356_);
v_a_361_ = lean_ctor_get(v_fst_357_, 0);
lean_inc(v_a_361_);
lean_dec_ref_known(v_fst_357_, 1);
lean_inc_ref(v_limits_322_);
v___x_362_ = lp_Hex_Hex_Groebner_Computation_intern(v_limits_322_, v_a_361_, v_snd_360_);
v_fst_363_ = lean_ctor_get(v___x_362_, 0);
lean_inc(v_fst_363_);
if (lean_obj_tag(v_fst_363_) == 0)
{
lean_object* v_snd_364_; lean_object* v_a_365_; 
lean_dec(v_i_325_);
lean_dec_ref(v_b_324_);
lean_dec_ref(v_limits_322_);
lean_dec(v_index_320_);
v_snd_364_ = lean_ctor_get(v___x_362_, 1);
lean_inc(v_snd_364_);
lean_dec_ref(v___x_362_);
v_a_365_ = lean_ctor_get(v_fst_363_, 0);
lean_inc(v_a_365_);
lean_dec_ref_known(v_fst_363_, 1);
v_a_328_ = v_a_365_;
v_snd_329_ = v_snd_364_;
goto v___jp_327_;
}
else
{
lean_object* v_snd_366_; lean_object* v_a_367_; uint64_t v___y_369_; uint64_t v___y_375_; lean_object* v___x_379_; 
v_snd_366_ = lean_ctor_get(v___x_362_, 1);
lean_inc(v_snd_366_);
lean_dec_ref(v___x_362_);
v_a_367_ = lean_ctor_get(v_fst_363_, 0);
lean_inc(v_a_367_);
lean_dec_ref_known(v_fst_363_, 1);
v___x_379_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3___redArg(v_b_324_, v_a_367_);
if (lean_obj_tag(v___x_379_) == 0)
{
v___y_375_ = v___x_351_;
goto v___jp_374_;
}
else
{
lean_object* v_val_380_; uint64_t v___x_381_; 
v_val_380_ = lean_ctor_get(v___x_379_, 0);
lean_inc(v_val_380_);
lean_dec_ref_known(v___x_379_, 1);
v___x_381_ = lean_unbox_uint64(v_val_380_);
lean_dec(v_val_380_);
v___y_375_ = v___x_381_;
goto v___jp_374_;
}
v___jp_368_:
{
uint8_t v___x_370_; 
v___x_370_ = lean_uint64_dec_eq(v___y_369_, v___x_351_);
if (v___x_370_ == 0)
{
lean_object* v___x_371_; lean_object* v___x_372_; 
v___x_371_ = lean_box_uint64(v___y_369_);
v___x_372_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1___redArg(v_b_324_, v_a_367_, v___x_371_);
v_a_335_ = v___x_372_;
v_snd_336_ = v_snd_366_;
goto v___jp_334_;
}
else
{
lean_object* v___x_373_; 
v___x_373_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2___redArg(v_b_324_, v_a_367_);
lean_dec(v_a_367_);
v_a_335_ = v___x_373_;
v_snd_336_ = v_snd_366_;
goto v___jp_334_;
}
}
v___jp_374_:
{
uint64_t v___x_376_; uint8_t v___x_377_; 
v___x_376_ = lean_uint64_add(v___y_375_, v_coefficient_345_);
v___x_377_ = lean_uint64_dec_le(v_field_349_, v___x_376_);
if (v___x_377_ == 0)
{
v___y_369_ = v___x_376_;
goto v___jp_368_;
}
else
{
uint64_t v___x_378_; 
v___x_378_ = lean_uint64_sub(v___x_376_, v_field_349_);
v___y_369_ = v___x_378_;
goto v___jp_368_;
}
}
}
}
}
else
{
v_a_335_ = v_b_324_;
v_snd_336_ = v___y_326_;
goto v___jp_334_;
}
}
else
{
lean_object* v___x_382_; 
lean_dec_ref(v_b_324_);
lean_dec_ref(v_limits_322_);
v___x_382_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_382_, 0, v_index_320_);
lean_ctor_set(v___x_382_, 1, v_i_325_);
v_a_328_ = v___x_382_;
v_snd_329_ = v___y_326_;
goto v___jp_327_;
}
}
}
v___jp_327_:
{
lean_object* v___x_330_; lean_object* v___x_331_; 
v___x_330_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_330_, 0, v_a_328_);
v___x_331_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_331_, 0, v___x_330_);
lean_ctor_set(v___x_331_, 1, v_snd_329_);
return v___x_331_;
}
v___jp_334_:
{
lean_object* v___x_337_; 
v___x_337_ = lean_nat_add(v_i_325_, v_step_333_);
lean_dec(v_i_325_);
v_b_324_ = v_a_335_;
v_i_325_ = v___x_337_;
v___y_326_ = v_snd_336_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4___redArg___boxed(lean_object* v_raw_383_, lean_object* v___x_384_, lean_object* v_index_385_, lean_object* v_context_386_, lean_object* v_limits_387_, lean_object* v_range_388_, lean_object* v_b_389_, lean_object* v_i_390_, lean_object* v___y_391_){
_start:
{
lean_object* v_res_392_; 
v_res_392_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4___redArg(v_raw_383_, v___x_384_, v_index_385_, v_context_386_, v_limits_387_, v_range_388_, v_b_389_, v_i_390_, v___y_391_);
lean_dec_ref(v_range_388_);
lean_dec_ref(v_context_386_);
lean_dec(v___x_384_);
lean_dec_ref(v_raw_383_);
return v_res_392_;
}
}
LEAN_EXPORT uint64_t lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13(lean_object* v_msg_395_){
_start:
{
lean_object* v___x_396_; lean_object* v___x_397_; uint64_t v___x_398_; 
v___x_396_ = ((lean_object*)(lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13___boxed__const__1));
v___x_397_ = lean_panic_fn_borrowed(v___x_396_, v_msg_395_);
v___x_398_ = lean_unbox_uint64(v___x_397_);
lean_dec(v___x_397_);
return v___x_398_;
}
}
LEAN_EXPORT lean_object* lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13___boxed(lean_object* v_msg_399_){
_start:
{
uint64_t v_res_400_; lean_object* v_r_401_; 
v_res_400_ = lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13(v_msg_399_);
v_r_401_ = lean_box_uint64(v_res_400_);
return v_r_401_;
}
}
static lean_object* _init_lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__3(void){
_start:
{
lean_object* v___x_405_; lean_object* v___x_406_; lean_object* v___x_407_; lean_object* v___x_408_; lean_object* v___x_409_; lean_object* v___x_410_; 
v___x_405_ = ((lean_object*)(lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__2));
v___x_406_ = lean_unsigned_to_nat(11u);
v___x_407_ = lean_unsigned_to_nat(163u);
v___x_408_ = ((lean_object*)(lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__1));
v___x_409_ = ((lean_object*)(lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__0));
v___x_410_ = l_mkPanicMessageWithDecl(v___x_409_, v___x_408_, v___x_407_, v___x_406_, v___x_405_);
return v___x_410_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11(lean_object* v_a_411_, lean_object* v_x_412_){
_start:
{
if (lean_obj_tag(v_x_412_) == 0)
{
lean_object* v___x_413_; uint64_t v___x_414_; 
v___x_413_ = lean_obj_once(&lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__3, &lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__3_once, _init_lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___closed__3);
v___x_414_ = lp_Hex_panic___at___00Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11_spec__13(v___x_413_);
return v___x_414_;
}
else
{
lean_object* v_key_415_; lean_object* v_value_416_; lean_object* v_tail_417_; uint8_t v___x_418_; 
v_key_415_ = lean_ctor_get(v_x_412_, 0);
v_value_416_ = lean_ctor_get(v_x_412_, 1);
v_tail_417_ = lean_ctor_get(v_x_412_, 2);
v___x_418_ = lean_nat_dec_eq(v_key_415_, v_a_411_);
if (v___x_418_ == 0)
{
v_x_412_ = v_tail_417_;
goto _start;
}
else
{
uint64_t v___x_420_; 
v___x_420_ = lean_unbox_uint64(v_value_416_);
return v___x_420_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11___boxed(lean_object* v_a_421_, lean_object* v_x_422_){
_start:
{
uint64_t v_res_423_; lean_object* v_r_424_; 
v_res_423_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11(v_a_421_, v_x_422_);
lean_dec(v_x_422_);
lean_dec(v_a_421_);
v_r_424_ = lean_box_uint64(v_res_423_);
return v_r_424_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6(lean_object* v_m_425_, lean_object* v_a_426_){
_start:
{
lean_object* v_buckets_427_; lean_object* v___x_428_; uint64_t v___x_429_; uint64_t v___x_430_; uint64_t v___x_431_; uint64_t v_fold_432_; uint64_t v___x_433_; uint64_t v___x_434_; uint64_t v___x_435_; size_t v___x_436_; size_t v___x_437_; size_t v___x_438_; size_t v___x_439_; size_t v___x_440_; lean_object* v___x_441_; uint64_t v___x_442_; 
v_buckets_427_ = lean_ctor_get(v_m_425_, 1);
v___x_428_ = lean_array_get_size(v_buckets_427_);
v___x_429_ = lean_uint64_of_nat(v_a_426_);
v___x_430_ = 32ULL;
v___x_431_ = lean_uint64_shift_right(v___x_429_, v___x_430_);
v_fold_432_ = lean_uint64_xor(v___x_429_, v___x_431_);
v___x_433_ = 16ULL;
v___x_434_ = lean_uint64_shift_right(v_fold_432_, v___x_433_);
v___x_435_ = lean_uint64_xor(v_fold_432_, v___x_434_);
v___x_436_ = lean_uint64_to_usize(v___x_435_);
v___x_437_ = lean_usize_of_nat(v___x_428_);
v___x_438_ = ((size_t)1ULL);
v___x_439_ = lean_usize_sub(v___x_437_, v___x_438_);
v___x_440_ = lean_usize_land(v___x_436_, v___x_439_);
v___x_441_ = lean_array_uget_borrowed(v_buckets_427_, v___x_440_);
v___x_442_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x21___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6_spec__11(v_a_426_, v___x_441_);
return v___x_442_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6___boxed(lean_object* v_m_443_, lean_object* v_a_444_){
_start:
{
uint64_t v_res_445_; lean_object* v_r_446_; 
v_res_445_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6(v_m_443_, v_a_444_);
lean_dec(v_a_444_);
lean_dec_ref(v_m_443_);
v_r_446_ = lean_box_uint64(v_res_445_);
return v_r_446_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__7(lean_object* v_a_447_, uint64_t v___x_448_, lean_object* v_as_449_, size_t v_sz_450_, size_t v_i_451_, lean_object* v_b_452_, lean_object* v___y_453_){
_start:
{
uint8_t v___x_454_; 
v___x_454_ = lean_usize_dec_lt(v_i_451_, v_sz_450_);
if (v___x_454_ == 0)
{
lean_object* v___x_455_; lean_object* v___x_456_; 
v___x_455_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_455_, 0, v_b_452_);
v___x_456_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_456_, 0, v___x_455_);
lean_ctor_set(v___x_456_, 1, v___y_453_);
return v___x_456_;
}
else
{
lean_object* v_a_457_; uint64_t v___x_458_; lean_object* v___x_459_; size_t v___x_460_; size_t v___x_461_; 
v_a_457_ = lean_array_uget_borrowed(v_as_449_, v_i_451_);
v___x_458_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x21___at___00Hex_Groebner_Polynomial_normalize_spec__6(v_a_447_, v_a_457_);
v___x_459_ = lp_Hex___private_HexGroebner_Polynomial_0__Hex_Groebner_Polynomial_append(v___x_448_, v_b_452_, v_a_457_, v___x_458_);
v___x_460_ = ((size_t)1ULL);
v___x_461_ = lean_usize_add(v_i_451_, v___x_460_);
v_i_451_ = v___x_461_;
v_b_452_ = v___x_459_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__7___boxed(lean_object* v_a_463_, lean_object* v___x_464_, lean_object* v_as_465_, lean_object* v_sz_466_, lean_object* v_i_467_, lean_object* v_b_468_, lean_object* v___y_469_){
_start:
{
uint64_t v___x_11724__boxed_470_; size_t v_sz_boxed_471_; size_t v_i_boxed_472_; lean_object* v_res_473_; 
v___x_11724__boxed_470_ = lean_unbox_uint64(v___x_464_);
lean_dec_ref(v___x_464_);
v_sz_boxed_471_ = lean_unbox_usize(v_sz_466_);
lean_dec(v_sz_466_);
v_i_boxed_472_ = lean_unbox_usize(v_i_467_);
lean_dec(v_i_467_);
v_res_473_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__7(v_a_463_, v___x_11724__boxed_470_, v_as_465_, v_sz_boxed_471_, v_i_boxed_472_, v_b_468_, v___y_469_);
lean_dec_ref(v_as_465_);
lean_dec_ref(v_a_463_);
return v_res_473_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_normalize_spec__5(size_t v_sz_474_, size_t v_i_475_, lean_object* v_bs_476_){
_start:
{
uint8_t v___x_477_; 
v___x_477_ = lean_usize_dec_lt(v_i_475_, v_sz_474_);
if (v___x_477_ == 0)
{
return v_bs_476_;
}
else
{
lean_object* v_v_478_; lean_object* v_fst_479_; lean_object* v___x_480_; lean_object* v_bs_x27_481_; size_t v___x_482_; size_t v___x_483_; lean_object* v___x_484_; 
v_v_478_ = lean_array_uget_borrowed(v_bs_476_, v_i_475_);
v_fst_479_ = lean_ctor_get(v_v_478_, 0);
lean_inc(v_fst_479_);
v___x_480_ = lean_unsigned_to_nat(0u);
v_bs_x27_481_ = lean_array_uset(v_bs_476_, v_i_475_, v___x_480_);
v___x_482_ = ((size_t)1ULL);
v___x_483_ = lean_usize_add(v_i_475_, v___x_482_);
v___x_484_ = lean_array_uset(v_bs_x27_481_, v_i_475_, v_fst_479_);
v_i_475_ = v___x_483_;
v_bs_476_ = v___x_484_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_normalize_spec__5___boxed(lean_object* v_sz_486_, lean_object* v_i_487_, lean_object* v_bs_488_){
_start:
{
size_t v_sz_boxed_489_; size_t v_i_boxed_490_; lean_object* v_res_491_; 
v_sz_boxed_489_ = lean_unbox_usize(v_sz_486_);
lean_dec(v_sz_486_);
v_i_boxed_490_ = lean_unbox_usize(v_i_487_);
lean_dec(v_i_487_);
v_res_491_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_normalize_spec__5(v_sz_boxed_489_, v_i_boxed_490_, v_bs_488_);
return v_res_491_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00Hex_Groebner_Polynomial_normalize_spec__8(lean_object* v_x_492_, lean_object* v_x_493_){
_start:
{
if (lean_obj_tag(v_x_493_) == 0)
{
return v_x_492_;
}
else
{
lean_object* v_key_494_; lean_object* v_value_495_; lean_object* v_tail_496_; lean_object* v___x_497_; lean_object* v___x_498_; 
v_key_494_ = lean_ctor_get(v_x_493_, 0);
v_value_495_ = lean_ctor_get(v_x_493_, 1);
v_tail_496_ = lean_ctor_get(v_x_493_, 2);
lean_inc(v_value_495_);
lean_inc(v_key_494_);
v___x_497_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_497_, 0, v_key_494_);
lean_ctor_set(v___x_497_, 1, v_value_495_);
v___x_498_ = lean_array_push(v_x_492_, v___x_497_);
v_x_492_ = v___x_498_;
v_x_493_ = v_tail_496_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00Hex_Groebner_Polynomial_normalize_spec__8___boxed(lean_object* v_x_500_, lean_object* v_x_501_){
_start:
{
lean_object* v_res_502_; 
v_res_502_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00Hex_Groebner_Polynomial_normalize_spec__8(v_x_500_, v_x_501_);
lean_dec(v_x_501_);
return v_res_502_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_Polynomial_normalize_spec__9(lean_object* v_as_503_, size_t v_i_504_, size_t v_stop_505_, lean_object* v_b_506_){
_start:
{
uint8_t v___x_507_; 
v___x_507_ = lean_usize_dec_eq(v_i_504_, v_stop_505_);
if (v___x_507_ == 0)
{
lean_object* v___x_508_; lean_object* v___x_509_; size_t v___x_510_; size_t v___x_511_; 
v___x_508_ = lean_array_uget_borrowed(v_as_503_, v_i_504_);
v___x_509_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00Hex_Groebner_Polynomial_normalize_spec__8(v_b_506_, v___x_508_);
v___x_510_ = ((size_t)1ULL);
v___x_511_ = lean_usize_add(v_i_504_, v___x_510_);
v_i_504_ = v___x_511_;
v_b_506_ = v___x_509_;
goto _start;
}
else
{
return v_b_506_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_Polynomial_normalize_spec__9___boxed(lean_object* v_as_513_, lean_object* v_i_514_, lean_object* v_stop_515_, lean_object* v_b_516_){
_start:
{
size_t v_i_boxed_517_; size_t v_stop_boxed_518_; lean_object* v_res_519_; 
v_i_boxed_517_ = lean_unbox_usize(v_i_514_);
lean_dec(v_i_514_);
v_stop_boxed_518_ = lean_unbox_usize(v_stop_515_);
lean_dec(v_stop_515_);
v_res_519_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_Polynomial_normalize_spec__9(v_as_513_, v_i_boxed_517_, v_stop_boxed_518_, v_b_516_);
lean_dec_ref(v_as_513_);
return v_res_519_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_Polynomial_normalize___closed__0(void){
_start:
{
lean_object* v___x_520_; lean_object* v___x_521_; lean_object* v___x_522_; 
v___x_520_ = lean_box(0);
v___x_521_ = lean_unsigned_to_nat(16u);
v___x_522_ = lean_mk_array(v___x_521_, v___x_520_);
return v___x_522_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_Polynomial_normalize___closed__1(void){
_start:
{
lean_object* v___x_523_; lean_object* v___x_524_; lean_object* v_coefficients_525_; 
v___x_523_ = lean_obj_once(&lp_Hex_Hex_Groebner_Polynomial_normalize___closed__0, &lp_Hex_Hex_Groebner_Polynomial_normalize___closed__0_once, _init_lp_Hex_Hex_Groebner_Polynomial_normalize___closed__0);
v___x_524_ = lean_unsigned_to_nat(0u);
v_coefficients_525_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_coefficients_525_, 0, v___x_524_);
lean_ctor_set(v_coefficients_525_, 1, v___x_523_);
return v_coefficients_525_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2(void){
_start:
{
lean_object* v___x_526_; lean_object* v_p_527_; 
v___x_526_ = l_ByteArray_empty;
v_p_527_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_p_527_, 0, v___x_526_);
lean_ctor_set(v_p_527_, 1, v___x_526_);
return v_p_527_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_normalize(lean_object* v_context_532_, lean_object* v_limits_533_, lean_object* v_index_534_, lean_object* v_raw_535_, lean_object* v_a_536_){
_start:
{
lean_object* v_statistics_537_; uint64_t v_field_538_; lean_object* v_variables_539_; lean_object* v_table_540_; lean_object* v_work_541_; lean_object* v_allocatedBytes_542_; lean_object* v_pairs_543_; lean_object* v_rounds_544_; lean_object* v_matrixEntries_545_; lean_object* v_matrixRows_546_; lean_object* v_matrixCalls_547_; lean_object* v_peakMatrixRows_548_; lean_object* v_peakMatrixEntries_549_; lean_object* v_largestBatch_550_; lean_object* v_productPairs_551_; lean_object* v_chainPairs_552_; lean_object* v_gmPairs_553_; lean_object* v___x_555_; uint8_t v_isShared_556_; uint8_t v_isSharedCheck_672_; 
v_statistics_537_ = lean_ctor_get(v_a_536_, 1);
lean_inc_ref(v_statistics_537_);
v_field_538_ = lean_ctor_get_uint64(v_context_532_, sizeof(void*)*1);
v_variables_539_ = lean_ctor_get(v_context_532_, 0);
v_table_540_ = lean_ctor_get(v_a_536_, 0);
v_work_541_ = lean_ctor_get(v_statistics_537_, 0);
v_allocatedBytes_542_ = lean_ctor_get(v_statistics_537_, 1);
v_pairs_543_ = lean_ctor_get(v_statistics_537_, 2);
v_rounds_544_ = lean_ctor_get(v_statistics_537_, 3);
v_matrixEntries_545_ = lean_ctor_get(v_statistics_537_, 4);
v_matrixRows_546_ = lean_ctor_get(v_statistics_537_, 5);
v_matrixCalls_547_ = lean_ctor_get(v_statistics_537_, 6);
v_peakMatrixRows_548_ = lean_ctor_get(v_statistics_537_, 7);
v_peakMatrixEntries_549_ = lean_ctor_get(v_statistics_537_, 8);
v_largestBatch_550_ = lean_ctor_get(v_statistics_537_, 9);
v_productPairs_551_ = lean_ctor_get(v_statistics_537_, 10);
v_chainPairs_552_ = lean_ctor_get(v_statistics_537_, 11);
v_gmPairs_553_ = lean_ctor_get(v_statistics_537_, 12);
v_isSharedCheck_672_ = !lean_is_exclusive(v_statistics_537_);
if (v_isSharedCheck_672_ == 0)
{
v___x_555_ = v_statistics_537_;
v_isShared_556_ = v_isSharedCheck_672_;
goto v_resetjp_554_;
}
else
{
lean_inc(v_gmPairs_553_);
lean_inc(v_chainPairs_552_);
lean_inc(v_productPairs_551_);
lean_inc(v_largestBatch_550_);
lean_inc(v_peakMatrixEntries_549_);
lean_inc(v_peakMatrixRows_548_);
lean_inc(v_matrixCalls_547_);
lean_inc(v_matrixRows_546_);
lean_inc(v_matrixEntries_545_);
lean_inc(v_rounds_544_);
lean_inc(v_pairs_543_);
lean_inc(v_allocatedBytes_542_);
lean_inc(v_work_541_);
lean_dec(v_statistics_537_);
v___x_555_ = lean_box(0);
v_isShared_556_ = v_isSharedCheck_672_;
goto v_resetjp_554_;
}
v_resetjp_554_:
{
lean_object* v_work_557_; lean_object* v___x_558_; lean_object* v___x_559_; lean_object* v___x_560_; lean_object* v___x_561_; lean_object* v_work_562_; uint8_t v___x_563_; 
v_work_557_ = lean_ctor_get(v_limits_533_, 0);
v___x_558_ = lean_array_get_size(v_raw_535_);
v___x_559_ = lean_unsigned_to_nat(1u);
v___x_560_ = lean_nat_add(v_variables_539_, v___x_559_);
v___x_561_ = lean_nat_mul(v___x_558_, v___x_560_);
lean_dec(v___x_560_);
v_work_562_ = lean_nat_add(v_work_541_, v___x_561_);
lean_dec(v___x_561_);
lean_dec(v_work_541_);
v___x_563_ = lean_nat_dec_lt(v_work_557_, v_work_562_);
if (v___x_563_ == 0)
{
lean_object* v___x_565_; uint8_t v_isShared_566_; uint8_t v_isSharedCheck_667_; 
lean_inc_ref(v_table_540_);
v_isSharedCheck_667_ = !lean_is_exclusive(v_a_536_);
if (v_isSharedCheck_667_ == 0)
{
lean_object* v_unused_668_; lean_object* v_unused_669_; 
v_unused_668_ = lean_ctor_get(v_a_536_, 1);
lean_dec(v_unused_668_);
v_unused_669_ = lean_ctor_get(v_a_536_, 0);
lean_dec(v_unused_669_);
v___x_565_ = v_a_536_;
v_isShared_566_ = v_isSharedCheck_667_;
goto v_resetjp_564_;
}
else
{
lean_dec(v_a_536_);
v___x_565_ = lean_box(0);
v_isShared_566_ = v_isSharedCheck_667_;
goto v_resetjp_564_;
}
v_resetjp_564_:
{
lean_object* v___x_568_; 
if (v_isShared_556_ == 0)
{
lean_ctor_set(v___x_555_, 0, v_work_562_);
v___x_568_ = v___x_555_;
goto v_reusejp_567_;
}
else
{
lean_object* v_reuseFailAlloc_666_; 
v_reuseFailAlloc_666_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_666_, 0, v_work_562_);
lean_ctor_set(v_reuseFailAlloc_666_, 1, v_allocatedBytes_542_);
lean_ctor_set(v_reuseFailAlloc_666_, 2, v_pairs_543_);
lean_ctor_set(v_reuseFailAlloc_666_, 3, v_rounds_544_);
lean_ctor_set(v_reuseFailAlloc_666_, 4, v_matrixEntries_545_);
lean_ctor_set(v_reuseFailAlloc_666_, 5, v_matrixRows_546_);
lean_ctor_set(v_reuseFailAlloc_666_, 6, v_matrixCalls_547_);
lean_ctor_set(v_reuseFailAlloc_666_, 7, v_peakMatrixRows_548_);
lean_ctor_set(v_reuseFailAlloc_666_, 8, v_peakMatrixEntries_549_);
lean_ctor_set(v_reuseFailAlloc_666_, 9, v_largestBatch_550_);
lean_ctor_set(v_reuseFailAlloc_666_, 10, v_productPairs_551_);
lean_ctor_set(v_reuseFailAlloc_666_, 11, v_chainPairs_552_);
lean_ctor_set(v_reuseFailAlloc_666_, 12, v_gmPairs_553_);
v___x_568_ = v_reuseFailAlloc_666_;
goto v_reusejp_567_;
}
v_reusejp_567_:
{
lean_object* v___x_570_; 
if (v_isShared_566_ == 0)
{
lean_ctor_set(v___x_565_, 1, v___x_568_);
v___x_570_ = v___x_565_;
goto v_reusejp_569_;
}
else
{
lean_object* v_reuseFailAlloc_665_; 
v_reuseFailAlloc_665_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_665_, 0, v_table_540_);
lean_ctor_set(v_reuseFailAlloc_665_, 1, v___x_568_);
v___x_570_ = v_reuseFailAlloc_665_;
goto v_reusejp_569_;
}
v_reusejp_569_:
{
lean_object* v___x_571_; lean_object* v_coefficients_572_; lean_object* v___x_573_; lean_object* v___x_574_; lean_object* v_fst_575_; 
v___x_571_ = lean_unsigned_to_nat(0u);
v_coefficients_572_ = lean_obj_once(&lp_Hex_Hex_Groebner_Polynomial_normalize___closed__1, &lp_Hex_Hex_Groebner_Polynomial_normalize___closed__1_once, _init_lp_Hex_Hex_Groebner_Polynomial_normalize___closed__1);
v___x_573_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_573_, 0, v___x_571_);
lean_ctor_set(v___x_573_, 1, v___x_558_);
lean_ctor_set(v___x_573_, 2, v___x_559_);
lean_inc_ref(v_limits_533_);
v___x_574_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4___redArg(v_raw_535_, v_variables_539_, v_index_534_, v_context_532_, v_limits_533_, v___x_573_, v_coefficients_572_, v___x_571_, v___x_570_);
lean_dec_ref_known(v___x_573_, 3);
v_fst_575_ = lean_ctor_get(v___x_574_, 0);
lean_inc(v_fst_575_);
if (lean_obj_tag(v_fst_575_) == 0)
{
lean_object* v_snd_576_; lean_object* v___x_578_; uint8_t v_isShared_579_; uint8_t v_isSharedCheck_591_; 
lean_dec_ref(v_limits_533_);
v_snd_576_ = lean_ctor_get(v___x_574_, 1);
v_isSharedCheck_591_ = !lean_is_exclusive(v___x_574_);
if (v_isSharedCheck_591_ == 0)
{
lean_object* v_unused_592_; 
v_unused_592_ = lean_ctor_get(v___x_574_, 0);
lean_dec(v_unused_592_);
v___x_578_ = v___x_574_;
v_isShared_579_ = v_isSharedCheck_591_;
goto v_resetjp_577_;
}
else
{
lean_inc(v_snd_576_);
lean_dec(v___x_574_);
v___x_578_ = lean_box(0);
v_isShared_579_ = v_isSharedCheck_591_;
goto v_resetjp_577_;
}
v_resetjp_577_:
{
lean_object* v_a_580_; lean_object* v___x_582_; uint8_t v_isShared_583_; uint8_t v_isSharedCheck_590_; 
v_a_580_ = lean_ctor_get(v_fst_575_, 0);
v_isSharedCheck_590_ = !lean_is_exclusive(v_fst_575_);
if (v_isSharedCheck_590_ == 0)
{
v___x_582_ = v_fst_575_;
v_isShared_583_ = v_isSharedCheck_590_;
goto v_resetjp_581_;
}
else
{
lean_inc(v_a_580_);
lean_dec(v_fst_575_);
v___x_582_ = lean_box(0);
v_isShared_583_ = v_isSharedCheck_590_;
goto v_resetjp_581_;
}
v_resetjp_581_:
{
lean_object* v___x_585_; 
if (v_isShared_583_ == 0)
{
v___x_585_ = v___x_582_;
goto v_reusejp_584_;
}
else
{
lean_object* v_reuseFailAlloc_589_; 
v_reuseFailAlloc_589_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_589_, 0, v_a_580_);
v___x_585_ = v_reuseFailAlloc_589_;
goto v_reusejp_584_;
}
v_reusejp_584_:
{
lean_object* v___x_587_; 
if (v_isShared_579_ == 0)
{
lean_ctor_set(v___x_578_, 0, v___x_585_);
v___x_587_ = v___x_578_;
goto v_reusejp_586_;
}
else
{
lean_object* v_reuseFailAlloc_588_; 
v_reuseFailAlloc_588_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_588_, 0, v___x_585_);
lean_ctor_set(v_reuseFailAlloc_588_, 1, v_snd_576_);
v___x_587_ = v_reuseFailAlloc_588_;
goto v_reusejp_586_;
}
v_reusejp_586_:
{
return v___x_587_;
}
}
}
}
}
else
{
lean_object* v_snd_593_; lean_object* v_a_594_; size_t v___y_596_; lean_object* v___y_597_; lean_object* v___y_598_; lean_object* v___y_599_; lean_object* v___y_600_; lean_object* v___y_601_; lean_object* v___y_628_; lean_object* v_size_657_; lean_object* v_buckets_658_; lean_object* v___x_659_; lean_object* v___x_660_; uint8_t v___x_661_; 
v_snd_593_ = lean_ctor_get(v___x_574_, 1);
lean_inc(v_snd_593_);
lean_dec_ref(v___x_574_);
v_a_594_ = lean_ctor_get(v_fst_575_, 0);
lean_inc(v_a_594_);
lean_dec_ref_known(v_fst_575_, 1);
v_size_657_ = lean_ctor_get(v_a_594_, 0);
v_buckets_658_ = lean_ctor_get(v_a_594_, 1);
v___x_659_ = lean_mk_empty_array_with_capacity(v_size_657_);
v___x_660_ = lean_array_get_size(v_buckets_658_);
v___x_661_ = lean_nat_dec_lt(v___x_571_, v___x_660_);
if (v___x_661_ == 0)
{
v___y_628_ = v___x_659_;
goto v___jp_627_;
}
else
{
size_t v___x_662_; size_t v___x_663_; lean_object* v___x_664_; 
v___x_662_ = ((size_t)0ULL);
v___x_663_ = lean_usize_of_nat(v___x_660_);
v___x_664_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00Hex_Groebner_Polynomial_normalize_spec__9(v_buckets_658_, v___x_662_, v___x_663_, v___x_659_);
v___y_628_ = v___x_664_;
goto v___jp_627_;
}
v___jp_595_:
{
lean_object* v___x_602_; lean_object* v___x_603_; lean_object* v___x_604_; lean_object* v_fst_605_; 
v___x_602_ = lean_nat_add(v___y_598_, v___y_601_);
v___x_603_ = lean_nat_mul(v___y_599_, v___x_602_);
lean_dec(v___x_602_);
lean_dec(v___y_599_);
v___x_604_ = lp_Hex_Hex_Groebner_Computation_allocate(v_limits_533_, v___x_603_, v___y_597_);
lean_dec(v___x_603_);
lean_dec_ref(v_limits_533_);
v_fst_605_ = lean_ctor_get(v___x_604_, 0);
lean_inc(v_fst_605_);
if (lean_obj_tag(v_fst_605_) == 0)
{
lean_object* v_snd_606_; lean_object* v___x_608_; uint8_t v_isShared_609_; uint8_t v_isSharedCheck_621_; 
lean_dec_ref(v___y_600_);
lean_dec(v_a_594_);
v_snd_606_ = lean_ctor_get(v___x_604_, 1);
v_isSharedCheck_621_ = !lean_is_exclusive(v___x_604_);
if (v_isSharedCheck_621_ == 0)
{
lean_object* v_unused_622_; 
v_unused_622_ = lean_ctor_get(v___x_604_, 0);
lean_dec(v_unused_622_);
v___x_608_ = v___x_604_;
v_isShared_609_ = v_isSharedCheck_621_;
goto v_resetjp_607_;
}
else
{
lean_inc(v_snd_606_);
lean_dec(v___x_604_);
v___x_608_ = lean_box(0);
v_isShared_609_ = v_isSharedCheck_621_;
goto v_resetjp_607_;
}
v_resetjp_607_:
{
lean_object* v_a_610_; lean_object* v___x_612_; uint8_t v_isShared_613_; uint8_t v_isSharedCheck_620_; 
v_a_610_ = lean_ctor_get(v_fst_605_, 0);
v_isSharedCheck_620_ = !lean_is_exclusive(v_fst_605_);
if (v_isSharedCheck_620_ == 0)
{
v___x_612_ = v_fst_605_;
v_isShared_613_ = v_isSharedCheck_620_;
goto v_resetjp_611_;
}
else
{
lean_inc(v_a_610_);
lean_dec(v_fst_605_);
v___x_612_ = lean_box(0);
v_isShared_613_ = v_isSharedCheck_620_;
goto v_resetjp_611_;
}
v_resetjp_611_:
{
lean_object* v___x_615_; 
if (v_isShared_613_ == 0)
{
v___x_615_ = v___x_612_;
goto v_reusejp_614_;
}
else
{
lean_object* v_reuseFailAlloc_619_; 
v_reuseFailAlloc_619_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_619_, 0, v_a_610_);
v___x_615_ = v_reuseFailAlloc_619_;
goto v_reusejp_614_;
}
v_reusejp_614_:
{
lean_object* v___x_617_; 
if (v_isShared_609_ == 0)
{
lean_ctor_set(v___x_608_, 0, v___x_615_);
v___x_617_ = v___x_608_;
goto v_reusejp_616_;
}
else
{
lean_object* v_reuseFailAlloc_618_; 
v_reuseFailAlloc_618_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_618_, 0, v___x_615_);
lean_ctor_set(v_reuseFailAlloc_618_, 1, v_snd_606_);
v___x_617_ = v_reuseFailAlloc_618_;
goto v_reusejp_616_;
}
v_reusejp_616_:
{
return v___x_617_;
}
}
}
}
}
else
{
lean_object* v_snd_623_; lean_object* v_p_624_; size_t v_sz_625_; lean_object* v___x_626_; 
lean_dec_ref_known(v_fst_605_, 1);
v_snd_623_ = lean_ctor_get(v___x_604_, 1);
lean_inc(v_snd_623_);
lean_dec_ref(v___x_604_);
v_p_624_ = lean_obj_once(&lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2, &lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2_once, _init_lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2);
v_sz_625_ = lean_array_size(v___y_600_);
v___x_626_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Polynomial_normalize_spec__7(v_a_594_, v_field_538_, v___y_600_, v_sz_625_, v___y_596_, v_p_624_, v_snd_623_);
lean_dec_ref(v___y_600_);
lean_dec(v_a_594_);
return v___x_626_;
}
}
v___jp_627_:
{
size_t v_sz_629_; size_t v___x_630_; lean_object* v___x_631_; lean_object* v___x_632_; lean_object* v_fst_633_; 
v_sz_629_ = lean_array_size(v___y_628_);
v___x_630_ = ((size_t)0ULL);
v___x_631_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_normalize_spec__5(v_sz_629_, v___x_630_, v___y_628_);
v___x_632_ = lp_Hex_Hex_Groebner_Computation_sort(v_context_532_, v_limits_533_, v___x_631_, v_snd_593_);
v_fst_633_ = lean_ctor_get(v___x_632_, 0);
lean_inc(v_fst_633_);
if (lean_obj_tag(v_fst_633_) == 0)
{
lean_object* v_snd_634_; lean_object* v___x_636_; uint8_t v_isShared_637_; uint8_t v_isSharedCheck_649_; 
lean_dec(v_a_594_);
lean_dec_ref(v_limits_533_);
v_snd_634_ = lean_ctor_get(v___x_632_, 1);
v_isSharedCheck_649_ = !lean_is_exclusive(v___x_632_);
if (v_isSharedCheck_649_ == 0)
{
lean_object* v_unused_650_; 
v_unused_650_ = lean_ctor_get(v___x_632_, 0);
lean_dec(v_unused_650_);
v___x_636_ = v___x_632_;
v_isShared_637_ = v_isSharedCheck_649_;
goto v_resetjp_635_;
}
else
{
lean_inc(v_snd_634_);
lean_dec(v___x_632_);
v___x_636_ = lean_box(0);
v_isShared_637_ = v_isSharedCheck_649_;
goto v_resetjp_635_;
}
v_resetjp_635_:
{
lean_object* v_a_638_; lean_object* v___x_640_; uint8_t v_isShared_641_; uint8_t v_isSharedCheck_648_; 
v_a_638_ = lean_ctor_get(v_fst_633_, 0);
v_isSharedCheck_648_ = !lean_is_exclusive(v_fst_633_);
if (v_isSharedCheck_648_ == 0)
{
v___x_640_ = v_fst_633_;
v_isShared_641_ = v_isSharedCheck_648_;
goto v_resetjp_639_;
}
else
{
lean_inc(v_a_638_);
lean_dec(v_fst_633_);
v___x_640_ = lean_box(0);
v_isShared_641_ = v_isSharedCheck_648_;
goto v_resetjp_639_;
}
v_resetjp_639_:
{
lean_object* v___x_643_; 
if (v_isShared_641_ == 0)
{
v___x_643_ = v___x_640_;
goto v_reusejp_642_;
}
else
{
lean_object* v_reuseFailAlloc_647_; 
v_reuseFailAlloc_647_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_647_, 0, v_a_638_);
v___x_643_ = v_reuseFailAlloc_647_;
goto v_reusejp_642_;
}
v_reusejp_642_:
{
lean_object* v___x_645_; 
if (v_isShared_637_ == 0)
{
lean_ctor_set(v___x_636_, 0, v___x_643_);
v___x_645_ = v___x_636_;
goto v_reusejp_644_;
}
else
{
lean_object* v_reuseFailAlloc_646_; 
v_reuseFailAlloc_646_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_646_, 0, v___x_643_);
lean_ctor_set(v_reuseFailAlloc_646_, 1, v_snd_634_);
v___x_645_ = v_reuseFailAlloc_646_;
goto v_reusejp_644_;
}
v_reusejp_644_:
{
return v___x_645_;
}
}
}
}
}
else
{
lean_object* v_snd_651_; lean_object* v_a_652_; lean_object* v___x_653_; lean_object* v___x_654_; uint8_t v___x_655_; 
v_snd_651_ = lean_ctor_get(v___x_632_, 1);
lean_inc(v_snd_651_);
lean_dec_ref(v___x_632_);
v_a_652_ = lean_ctor_get(v_fst_633_, 0);
lean_inc(v_a_652_);
lean_dec_ref_known(v_fst_633_, 1);
v___x_653_ = lean_array_get_size(v_a_652_);
v___x_654_ = lean_unsigned_to_nat(4u);
v___x_655_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_538_);
switch(v___x_655_)
{
case 0:
{
v___y_596_ = v___x_630_;
v___y_597_ = v_snd_651_;
v___y_598_ = v___x_654_;
v___y_599_ = v___x_653_;
v___y_600_ = v_a_652_;
v___y_601_ = v___x_559_;
goto v___jp_595_;
}
case 1:
{
lean_object* v___x_656_; 
v___x_656_ = lean_unsigned_to_nat(2u);
v___y_596_ = v___x_630_;
v___y_597_ = v_snd_651_;
v___y_598_ = v___x_654_;
v___y_599_ = v___x_653_;
v___y_600_ = v_a_652_;
v___y_601_ = v___x_656_;
goto v___jp_595_;
}
default: 
{
v___y_596_ = v___x_630_;
v___y_597_ = v_snd_651_;
v___y_598_ = v___x_654_;
v___y_599_ = v___x_653_;
v___y_600_ = v_a_652_;
v___y_601_ = v___x_654_;
goto v___jp_595_;
}
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_670_; lean_object* v___x_671_; 
lean_dec(v_work_562_);
lean_del_object(v___x_555_);
lean_dec(v_gmPairs_553_);
lean_dec(v_chainPairs_552_);
lean_dec(v_productPairs_551_);
lean_dec(v_largestBatch_550_);
lean_dec(v_peakMatrixEntries_549_);
lean_dec(v_peakMatrixRows_548_);
lean_dec(v_matrixCalls_547_);
lean_dec(v_matrixRows_546_);
lean_dec(v_matrixEntries_545_);
lean_dec(v_rounds_544_);
lean_dec(v_pairs_543_);
lean_dec(v_allocatedBytes_542_);
lean_dec(v_index_534_);
lean_dec_ref(v_limits_533_);
v___x_670_ = ((lean_object*)(lp_Hex_Hex_Groebner_Polynomial_normalize___closed__4));
v___x_671_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_671_, 0, v___x_670_);
lean_ctor_set(v___x_671_, 1, v_a_536_);
return v___x_671_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_normalize___boxed(lean_object* v_context_673_, lean_object* v_limits_674_, lean_object* v_index_675_, lean_object* v_raw_676_, lean_object* v_a_677_){
_start:
{
lean_object* v_res_678_; 
v_res_678_ = lp_Hex_Hex_Groebner_Polynomial_normalize(v_context_673_, v_limits_674_, v_index_675_, v_raw_676_, v_a_677_);
lean_dec_ref(v_raw_676_);
lean_dec_ref(v_context_673_);
return v_res_678_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1(lean_object* v_00_u03b2_679_, lean_object* v_m_680_, lean_object* v_a_681_, lean_object* v_b_682_){
_start:
{
lean_object* v___x_683_; 
v___x_683_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1___redArg(v_m_680_, v_a_681_, v_b_682_);
return v___x_683_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2(lean_object* v_00_u03b2_684_, lean_object* v_m_685_, lean_object* v_a_686_){
_start:
{
lean_object* v___x_687_; 
v___x_687_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2___redArg(v_m_685_, v_a_686_);
return v___x_687_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2___boxed(lean_object* v_00_u03b2_688_, lean_object* v_m_689_, lean_object* v_a_690_){
_start:
{
lean_object* v_res_691_; 
v_res_691_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2(v_00_u03b2_688_, v_m_689_, v_a_690_);
lean_dec(v_a_690_);
return v_res_691_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3(lean_object* v_00_u03b2_692_, lean_object* v_m_693_, lean_object* v_a_694_){
_start:
{
lean_object* v___x_695_; 
v___x_695_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3___redArg(v_m_693_, v_a_694_);
return v___x_695_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3___boxed(lean_object* v_00_u03b2_696_, lean_object* v_m_697_, lean_object* v_a_698_){
_start:
{
lean_object* v_res_699_; 
v_res_699_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3(v_00_u03b2_696_, v_m_697_, v_a_698_);
lean_dec(v_a_698_);
lean_dec_ref(v_m_697_);
return v_res_699_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4(lean_object* v_raw_700_, lean_object* v___x_701_, lean_object* v_index_702_, lean_object* v_context_703_, lean_object* v_limits_704_, lean_object* v_range_705_, lean_object* v_b_706_, lean_object* v_i_707_, lean_object* v_hs_708_, lean_object* v_hl_709_, lean_object* v___y_710_){
_start:
{
lean_object* v___x_711_; 
v___x_711_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4___redArg(v_raw_700_, v___x_701_, v_index_702_, v_context_703_, v_limits_704_, v_range_705_, v_b_706_, v_i_707_, v___y_710_);
return v___x_711_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4___boxed(lean_object* v_raw_712_, lean_object* v___x_713_, lean_object* v_index_714_, lean_object* v_context_715_, lean_object* v_limits_716_, lean_object* v_range_717_, lean_object* v_b_718_, lean_object* v_i_719_, lean_object* v_hs_720_, lean_object* v_hl_721_, lean_object* v___y_722_){
_start:
{
lean_object* v_res_723_; 
v_res_723_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_normalize_spec__4(v_raw_712_, v___x_713_, v_index_714_, v_context_715_, v_limits_716_, v_range_717_, v_b_718_, v_i_719_, v_hs_720_, v_hl_721_, v___y_722_);
lean_dec_ref(v_range_717_);
lean_dec_ref(v_context_715_);
lean_dec(v___x_713_);
lean_dec_ref(v_raw_712_);
return v_res_723_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1(lean_object* v_00_u03b2_724_, lean_object* v_a_725_, lean_object* v_x_726_){
_start:
{
uint8_t v___x_727_; 
v___x_727_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___redArg(v_a_725_, v_x_726_);
return v___x_727_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1___boxed(lean_object* v_00_u03b2_728_, lean_object* v_a_729_, lean_object* v_x_730_){
_start:
{
uint8_t v_res_731_; lean_object* v_r_732_; 
v_res_731_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__1(v_00_u03b2_728_, v_a_729_, v_x_730_);
lean_dec(v_x_730_);
lean_dec(v_a_729_);
v_r_732_ = lean_box(v_res_731_);
return v_r_732_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2(lean_object* v_00_u03b2_733_, lean_object* v_data_734_){
_start:
{
lean_object* v___x_735_; 
v___x_735_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2___redArg(v_data_734_);
return v___x_735_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__3(lean_object* v_00_u03b2_736_, lean_object* v_a_737_, lean_object* v_b_738_, lean_object* v_x_739_){
_start:
{
lean_object* v___x_740_; 
v___x_740_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__3___redArg(v_a_737_, v_b_738_, v_x_739_);
return v___x_740_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5(lean_object* v_00_u03b2_741_, lean_object* v_a_742_, lean_object* v_x_743_){
_start:
{
lean_object* v___x_744_; 
v___x_744_ = lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___redArg(v_a_742_, v_x_743_);
return v___x_744_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5___boxed(lean_object* v_00_u03b2_745_, lean_object* v_a_746_, lean_object* v_x_747_){
_start:
{
lean_object* v_res_748_; 
v_res_748_ = lp_Hex_Std_DHashMap_Internal_AssocList_erase___at___00Std_DHashMap_Internal_Raw_u2080_erase___at___00Hex_Groebner_Polynomial_normalize_spec__2_spec__5(v_00_u03b2_745_, v_a_746_, v_x_747_);
lean_dec(v_a_746_);
return v_res_748_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7(lean_object* v_00_u03b2_749_, lean_object* v_a_750_, lean_object* v_x_751_){
_start:
{
lean_object* v___x_752_; 
v___x_752_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7___redArg(v_a_750_, v_x_751_);
return v___x_752_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7___boxed(lean_object* v_00_u03b2_753_, lean_object* v_a_754_, lean_object* v_x_755_){
_start:
{
lean_object* v_res_756_; 
v_res_756_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_Polynomial_normalize_spec__3_spec__7(v_00_u03b2_753_, v_a_754_, v_x_755_);
lean_dec(v_x_755_);
lean_dec(v_a_754_);
return v_res_756_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3(lean_object* v_00_u03b2_757_, lean_object* v_i_758_, lean_object* v_source_759_, lean_object* v_target_760_){
_start:
{
lean_object* v___x_761_; 
v___x_761_ = lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3___redArg(v_i_758_, v_source_759_, v_target_760_);
return v___x_761_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3_spec__12(lean_object* v_00_u03b2_762_, lean_object* v_x_763_, lean_object* v_x_764_){
_start:
{
lean_object* v___x_765_; 
v___x_765_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Hex_Groebner_Polynomial_normalize_spec__1_spec__2_spec__3_spec__12___redArg(v_x_763_, v_x_764_);
return v___x_765_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(lean_object* v_xs_766_, lean_object* v_i_767_){
_start:
{
lean_object* v___x_768_; uint8_t v___x_769_; 
v___x_768_ = lean_byte_array_size(v_xs_766_);
v___x_769_ = lean_nat_dec_lt(v_i_767_, v___x_768_);
return v___x_769_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0___boxed(lean_object* v_xs_770_, lean_object* v_i_771_){
_start:
{
uint8_t v_res_772_; lean_object* v_r_773_; 
v_res_772_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_xs_770_, v_i_771_);
lean_dec(v_i_771_);
lean_dec_ref(v_xs_770_);
v_r_773_ = lean_box(v_res_772_);
return v_r_773_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg(uint64_t v___x_774_, uint64_t v_ctx_775_, uint64_t v_factor_776_, lean_object* v_p_777_, lean_object* v_range_778_, lean_object* v_b_779_, lean_object* v_i_780_, lean_object* v___y_781_){
_start:
{
lean_object* v_stop_782_; lean_object* v_step_783_; lean_object* v_a_785_; lean_object* v_snd_786_; uint8_t v___x_789_; 
v_stop_782_ = lean_ctor_get(v_range_778_, 1);
v_step_783_ = lean_ctor_get(v_range_778_, 2);
v___x_789_ = lean_nat_dec_lt(v_i_780_, v_stop_782_);
if (v___x_789_ == 0)
{
lean_object* v___x_790_; lean_object* v___x_791_; 
lean_dec(v_i_780_);
v___x_790_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_790_, 0, v_b_779_);
v___x_791_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_791_, 0, v___x_790_);
lean_ctor_set(v___x_791_, 1, v___y_781_);
return v___x_791_;
}
else
{
lean_object* v_coefficients_792_; uint8_t v___x_793_; uint64_t v___y_795_; uint64_t v___y_816_; uint8_t v___y_817_; uint64_t v___y_823_; uint8_t v___y_824_; uint8_t v___x_829_; lean_object* v___y_831_; uint64_t v___y_832_; uint8_t v___y_833_; lean_object* v___y_846_; uint64_t v___y_847_; uint8_t v___y_848_; lean_object* v___y_861_; uint8_t v___y_862_; lean_object* v___y_879_; uint8_t v___y_880_; lean_object* v___y_918_; 
v_coefficients_792_ = lean_ctor_get(v_p_777_, 1);
v___x_793_ = lp_Hex_Hex_Groebner_PrimeField_width(v___x_774_);
v___x_829_ = 0;
switch(v___x_793_)
{
case 0:
{
lean_object* v___x_926_; 
v___x_926_ = lean_unsigned_to_nat(1u);
v___y_918_ = v___x_926_;
goto v___jp_917_;
}
case 1:
{
lean_object* v___x_927_; 
v___x_927_ = lean_unsigned_to_nat(2u);
v___y_918_ = v___x_927_;
goto v___jp_917_;
}
default: 
{
lean_object* v___x_928_; 
v___x_928_ = lean_unsigned_to_nat(4u);
v___y_918_ = v___x_928_;
goto v___jp_917_;
}
}
v___jp_794_:
{
uint64_t v___x_796_; uint8_t v___x_797_; lean_object* v_data_798_; 
v___x_796_ = lp_Hex_BarrettCtx_mulMod(v___x_774_, v_ctx_775_, v___y_795_, v_factor_776_);
v___x_797_ = lean_uint64_to_uint8(v___x_796_);
v_data_798_ = lean_byte_array_push(v_b_779_, v___x_797_);
switch(v___x_793_)
{
case 0:
{
v_a_785_ = v_data_798_;
v_snd_786_ = v___y_781_;
goto v___jp_784_;
}
case 1:
{
uint64_t v___x_799_; uint64_t v___x_800_; uint8_t v___x_801_; lean_object* v___x_802_; 
v___x_799_ = 8ULL;
v___x_800_ = lean_uint64_shift_right(v___x_796_, v___x_799_);
v___x_801_ = lean_uint64_to_uint8(v___x_800_);
v___x_802_ = lean_byte_array_push(v_data_798_, v___x_801_);
v_a_785_ = v___x_802_;
v_snd_786_ = v___y_781_;
goto v___jp_784_;
}
default: 
{
uint64_t v___x_803_; uint64_t v___x_804_; uint8_t v___x_805_; lean_object* v___x_806_; uint64_t v___x_807_; uint64_t v___x_808_; uint8_t v___x_809_; lean_object* v___x_810_; uint64_t v___x_811_; uint64_t v___x_812_; uint8_t v___x_813_; lean_object* v___x_814_; 
v___x_803_ = 8ULL;
v___x_804_ = lean_uint64_shift_right(v___x_796_, v___x_803_);
v___x_805_ = lean_uint64_to_uint8(v___x_804_);
v___x_806_ = lean_byte_array_push(v_data_798_, v___x_805_);
v___x_807_ = 16ULL;
v___x_808_ = lean_uint64_shift_right(v___x_796_, v___x_807_);
v___x_809_ = lean_uint64_to_uint8(v___x_808_);
v___x_810_ = lean_byte_array_push(v___x_806_, v___x_809_);
v___x_811_ = 24ULL;
v___x_812_ = lean_uint64_shift_right(v___x_796_, v___x_811_);
v___x_813_ = lean_uint64_to_uint8(v___x_812_);
v___x_814_ = lean_byte_array_push(v___x_810_, v___x_813_);
v_a_785_ = v___x_814_;
v_snd_786_ = v___y_781_;
goto v___jp_784_;
}
}
}
v___jp_815_:
{
uint64_t v___x_818_; uint64_t v___x_819_; uint64_t v___x_820_; uint64_t v___x_821_; 
v___x_818_ = lean_uint8_to_uint64(v___y_817_);
v___x_819_ = 24ULL;
v___x_820_ = lean_uint64_shift_left(v___x_818_, v___x_819_);
v___x_821_ = lean_uint64_lor(v___y_816_, v___x_820_);
v___y_795_ = v___x_821_;
goto v___jp_794_;
}
v___jp_822_:
{
uint64_t v___x_825_; uint64_t v___x_826_; uint64_t v___x_827_; uint64_t v___x_828_; 
v___x_825_ = lean_uint8_to_uint64(v___y_824_);
v___x_826_ = 8ULL;
v___x_827_ = lean_uint64_shift_left(v___x_825_, v___x_826_);
v___x_828_ = lean_uint64_lor(v___y_823_, v___x_827_);
v___y_795_ = v___x_828_;
goto v___jp_794_;
}
v___jp_830_:
{
uint64_t v___x_834_; uint64_t v___x_835_; uint64_t v___x_836_; uint64_t v___x_837_; lean_object* v___x_838_; lean_object* v___x_839_; uint8_t v___x_840_; 
v___x_834_ = lean_uint8_to_uint64(v___y_833_);
v___x_835_ = 16ULL;
v___x_836_ = lean_uint64_shift_left(v___x_834_, v___x_835_);
v___x_837_ = lean_uint64_lor(v___y_832_, v___x_836_);
v___x_838_ = lean_unsigned_to_nat(3u);
v___x_839_ = lean_nat_add(v___y_831_, v___x_838_);
lean_dec(v___y_831_);
v___x_840_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_792_, v___x_839_);
if (v___x_840_ == 0)
{
lean_object* v___x_841_; lean_object* v___x_842_; uint8_t v___x_843_; 
lean_dec(v___x_839_);
v___x_841_ = lean_box(v___x_829_);
v___x_842_ = l_outOfBounds___redArg(v___x_841_);
lean_dec(v___x_841_);
v___x_843_ = lean_unbox(v___x_842_);
lean_dec(v___x_842_);
v___y_816_ = v___x_837_;
v___y_817_ = v___x_843_;
goto v___jp_815_;
}
else
{
uint8_t v___x_844_; 
v___x_844_ = lean_byte_array_fget(v_coefficients_792_, v___x_839_);
lean_dec(v___x_839_);
v___y_816_ = v___x_837_;
v___y_817_ = v___x_844_;
goto v___jp_815_;
}
}
v___jp_845_:
{
uint64_t v___x_849_; uint64_t v___x_850_; uint64_t v___x_851_; uint64_t v___x_852_; lean_object* v___x_853_; lean_object* v___x_854_; uint8_t v___x_855_; 
v___x_849_ = lean_uint8_to_uint64(v___y_848_);
v___x_850_ = 8ULL;
v___x_851_ = lean_uint64_shift_left(v___x_849_, v___x_850_);
v___x_852_ = lean_uint64_lor(v___y_847_, v___x_851_);
v___x_853_ = lean_unsigned_to_nat(2u);
v___x_854_ = lean_nat_add(v___y_846_, v___x_853_);
v___x_855_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_792_, v___x_854_);
if (v___x_855_ == 0)
{
lean_object* v___x_856_; lean_object* v___x_857_; uint8_t v___x_858_; 
lean_dec(v___x_854_);
v___x_856_ = lean_box(v___x_829_);
v___x_857_ = l_outOfBounds___redArg(v___x_856_);
lean_dec(v___x_856_);
v___x_858_ = lean_unbox(v___x_857_);
lean_dec(v___x_857_);
v___y_831_ = v___y_846_;
v___y_832_ = v___x_852_;
v___y_833_ = v___x_858_;
goto v___jp_830_;
}
else
{
uint8_t v___x_859_; 
v___x_859_ = lean_byte_array_fget(v_coefficients_792_, v___x_854_);
lean_dec(v___x_854_);
v___y_831_ = v___y_846_;
v___y_832_ = v___x_852_;
v___y_833_ = v___x_859_;
goto v___jp_830_;
}
}
v___jp_860_:
{
uint64_t v_a_863_; 
v_a_863_ = lean_uint8_to_uint64(v___y_862_);
switch(v___x_793_)
{
case 0:
{
lean_dec(v___y_861_);
v___y_795_ = v_a_863_;
goto v___jp_794_;
}
case 1:
{
lean_object* v___x_864_; lean_object* v___x_865_; uint8_t v___x_866_; 
v___x_864_ = lean_unsigned_to_nat(1u);
v___x_865_ = lean_nat_add(v___y_861_, v___x_864_);
lean_dec(v___y_861_);
v___x_866_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_792_, v___x_865_);
if (v___x_866_ == 0)
{
lean_object* v___x_867_; lean_object* v___x_868_; uint8_t v___x_869_; 
lean_dec(v___x_865_);
v___x_867_ = lean_box(v___x_829_);
v___x_868_ = l_outOfBounds___redArg(v___x_867_);
lean_dec(v___x_867_);
v___x_869_ = lean_unbox(v___x_868_);
lean_dec(v___x_868_);
v___y_823_ = v_a_863_;
v___y_824_ = v___x_869_;
goto v___jp_822_;
}
else
{
uint8_t v___x_870_; 
v___x_870_ = lean_byte_array_fget(v_coefficients_792_, v___x_865_);
lean_dec(v___x_865_);
v___y_823_ = v_a_863_;
v___y_824_ = v___x_870_;
goto v___jp_822_;
}
}
default: 
{
lean_object* v___x_871_; lean_object* v___x_872_; uint8_t v___x_873_; 
v___x_871_ = lean_unsigned_to_nat(1u);
v___x_872_ = lean_nat_add(v___y_861_, v___x_871_);
v___x_873_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_792_, v___x_872_);
if (v___x_873_ == 0)
{
lean_object* v___x_874_; lean_object* v___x_875_; uint8_t v___x_876_; 
lean_dec(v___x_872_);
v___x_874_ = lean_box(v___x_829_);
v___x_875_ = l_outOfBounds___redArg(v___x_874_);
lean_dec(v___x_874_);
v___x_876_ = lean_unbox(v___x_875_);
lean_dec(v___x_875_);
v___y_846_ = v___y_861_;
v___y_847_ = v_a_863_;
v___y_848_ = v___x_876_;
goto v___jp_845_;
}
else
{
uint8_t v___x_877_; 
v___x_877_ = lean_byte_array_fget(v_coefficients_792_, v___x_872_);
lean_dec(v___x_872_);
v___y_846_ = v___y_861_;
v___y_847_ = v_a_863_;
v___y_848_ = v___x_877_;
goto v___jp_845_;
}
}
}
}
v___jp_878_:
{
if (v___y_880_ == 0)
{
uint8_t v___x_881_; 
v___x_881_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_792_, v___y_879_);
if (v___x_881_ == 0)
{
lean_object* v___x_882_; lean_object* v___x_883_; uint8_t v___x_884_; 
v___x_882_ = lean_box(v___x_829_);
v___x_883_ = l_outOfBounds___redArg(v___x_882_);
lean_dec(v___x_882_);
v___x_884_ = lean_unbox(v___x_883_);
lean_dec(v___x_883_);
v___y_861_ = v___y_879_;
v___y_862_ = v___x_884_;
goto v___jp_860_;
}
else
{
uint8_t v___x_885_; 
v___x_885_ = lean_byte_array_fget(v_coefficients_792_, v___y_879_);
v___y_861_ = v___y_879_;
v___y_862_ = v___x_885_;
goto v___jp_860_;
}
}
else
{
size_t v_pos_886_; uint8_t v___x_887_; uint64_t v_a_888_; 
v_pos_886_ = lean_usize_of_nat(v___y_879_);
lean_dec(v___y_879_);
v___x_887_ = lean_byte_array_uget(v_coefficients_792_, v_pos_886_);
v_a_888_ = lean_uint8_to_uint64(v___x_887_);
switch(v___x_793_)
{
case 0:
{
v___y_795_ = v_a_888_;
goto v___jp_794_;
}
case 1:
{
size_t v___x_889_; size_t v___x_890_; uint8_t v___x_891_; uint64_t v___x_892_; uint64_t v___x_893_; uint64_t v___x_894_; uint64_t v___x_895_; 
v___x_889_ = ((size_t)1ULL);
v___x_890_ = lean_usize_add(v_pos_886_, v___x_889_);
v___x_891_ = lean_byte_array_uget(v_coefficients_792_, v___x_890_);
v___x_892_ = lean_uint8_to_uint64(v___x_891_);
v___x_893_ = 8ULL;
v___x_894_ = lean_uint64_shift_left(v___x_892_, v___x_893_);
v___x_895_ = lean_uint64_lor(v_a_888_, v___x_894_);
v___y_795_ = v___x_895_;
goto v___jp_794_;
}
default: 
{
size_t v___x_896_; size_t v___x_897_; uint8_t v___x_898_; uint64_t v___x_899_; uint64_t v___x_900_; uint64_t v___x_901_; uint64_t v___x_902_; size_t v___x_903_; size_t v___x_904_; uint8_t v___x_905_; uint64_t v___x_906_; uint64_t v___x_907_; uint64_t v___x_908_; uint64_t v___x_909_; size_t v___x_910_; size_t v___x_911_; uint8_t v___x_912_; uint64_t v___x_913_; uint64_t v___x_914_; uint64_t v___x_915_; uint64_t v___x_916_; 
v___x_896_ = ((size_t)1ULL);
v___x_897_ = lean_usize_add(v_pos_886_, v___x_896_);
v___x_898_ = lean_byte_array_uget(v_coefficients_792_, v___x_897_);
v___x_899_ = lean_uint8_to_uint64(v___x_898_);
v___x_900_ = 8ULL;
v___x_901_ = lean_uint64_shift_left(v___x_899_, v___x_900_);
v___x_902_ = lean_uint64_lor(v_a_888_, v___x_901_);
v___x_903_ = ((size_t)2ULL);
v___x_904_ = lean_usize_add(v_pos_886_, v___x_903_);
v___x_905_ = lean_byte_array_uget(v_coefficients_792_, v___x_904_);
v___x_906_ = lean_uint8_to_uint64(v___x_905_);
v___x_907_ = 16ULL;
v___x_908_ = lean_uint64_shift_left(v___x_906_, v___x_907_);
v___x_909_ = lean_uint64_lor(v___x_902_, v___x_908_);
v___x_910_ = ((size_t)3ULL);
v___x_911_ = lean_usize_add(v_pos_886_, v___x_910_);
v___x_912_ = lean_byte_array_uget(v_coefficients_792_, v___x_911_);
v___x_913_ = lean_uint8_to_uint64(v___x_912_);
v___x_914_ = 24ULL;
v___x_915_ = lean_uint64_shift_left(v___x_913_, v___x_914_);
v___x_916_ = lean_uint64_lor(v___x_909_, v___x_915_);
v___y_795_ = v___x_916_;
goto v___jp_794_;
}
}
}
}
v___jp_917_:
{
lean_object* v_offset_919_; lean_object* v___x_920_; lean_object* v___x_921_; uint8_t v___x_922_; 
v_offset_919_ = lean_nat_mul(v_i_780_, v___y_918_);
v___x_920_ = lean_nat_add(v_offset_919_, v___y_918_);
v___x_921_ = lean_byte_array_size(v_coefficients_792_);
v___x_922_ = lean_nat_dec_le(v___x_920_, v___x_921_);
if (v___x_922_ == 0)
{
lean_dec(v___x_920_);
v___y_879_ = v_offset_919_;
v___y_880_ = v___x_922_;
goto v___jp_878_;
}
else
{
size_t v___x_923_; lean_object* v___x_924_; uint8_t v___x_925_; 
v___x_923_ = lean_usize_of_nat(v___x_920_);
v___x_924_ = lean_usize_to_nat(v___x_923_);
v___x_925_ = lean_nat_dec_eq(v___x_924_, v___x_920_);
lean_dec(v___x_920_);
lean_dec(v___x_924_);
v___y_879_ = v_offset_919_;
v___y_880_ = v___x_925_;
goto v___jp_878_;
}
}
}
v___jp_784_:
{
lean_object* v___x_787_; 
v___x_787_ = lean_nat_add(v_i_780_, v_step_783_);
lean_dec(v_i_780_);
v_b_779_ = v_a_785_;
v_i_780_ = v___x_787_;
v___y_781_ = v_snd_786_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___boxed(lean_object* v___x_929_, lean_object* v_ctx_930_, lean_object* v_factor_931_, lean_object* v_p_932_, lean_object* v_range_933_, lean_object* v_b_934_, lean_object* v_i_935_, lean_object* v___y_936_){
_start:
{
uint64_t v___x_4724__boxed_937_; uint64_t v_ctx_boxed_938_; uint64_t v_factor_boxed_939_; lean_object* v_res_940_; 
v___x_4724__boxed_937_ = lean_unbox_uint64(v___x_929_);
lean_dec_ref(v___x_929_);
v_ctx_boxed_938_ = lean_unbox_uint64(v_ctx_930_);
lean_dec_ref(v_ctx_930_);
v_factor_boxed_939_ = lean_unbox_uint64(v_factor_931_);
lean_dec_ref(v_factor_931_);
v_res_940_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg(v___x_4724__boxed_937_, v_ctx_boxed_938_, v_factor_boxed_939_, v_p_932_, v_range_933_, v_b_934_, v_i_935_, v___y_936_);
lean_dec_ref(v_range_933_);
lean_dec_ref(v_p_932_);
return v_res_940_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_Polynomial_scale___closed__0(void){
_start:
{
lean_object* v___x_941_; lean_object* v___x_942_; 
v___x_941_ = lean_obj_once(&lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2, &lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2_once, _init_lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2);
v___x_942_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_942_, 0, v___x_941_);
return v___x_942_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_scale(lean_object* v_context_943_, lean_object* v_limits_944_, lean_object* v_p_945_, uint64_t v_factor_946_, lean_object* v_a_947_){
_start:
{
uint64_t v___x_951_; uint8_t v___x_952_; 
v___x_951_ = 1ULL;
v___x_952_ = lean_uint64_dec_eq(v_factor_946_, v___x_951_);
if (v___x_952_ == 0)
{
lean_object* v_support_953_; lean_object* v_coefficients_954_; lean_object* v___x_955_; lean_object* v___x_956_; lean_object* v___x_957_; lean_object* v___x_958_; uint8_t v___x_959_; 
v_support_953_ = lean_ctor_get(v_p_945_, 0);
v_coefficients_954_ = lean_ctor_get(v_p_945_, 1);
v___x_955_ = lean_byte_array_size(v_support_953_);
v___x_956_ = lean_unsigned_to_nat(2u);
v___x_957_ = lean_nat_shiftr(v___x_955_, v___x_956_);
v___x_958_ = lean_unsigned_to_nat(0u);
v___x_959_ = lean_nat_dec_eq(v___x_957_, v___x_958_);
if (v___x_959_ == 0)
{
uint64_t v___x_960_; uint8_t v___x_961_; 
lean_inc_ref(v_support_953_);
v___x_960_ = 0ULL;
v___x_961_ = lean_uint64_dec_eq(v_factor_946_, v___x_960_);
if (v___x_961_ == 0)
{
lean_object* v_statistics_962_; lean_object* v_table_963_; lean_object* v_work_964_; lean_object* v_allocatedBytes_965_; lean_object* v_pairs_966_; lean_object* v_rounds_967_; lean_object* v_matrixEntries_968_; lean_object* v_matrixRows_969_; lean_object* v_matrixCalls_970_; lean_object* v_peakMatrixRows_971_; lean_object* v_peakMatrixEntries_972_; lean_object* v_largestBatch_973_; lean_object* v_productPairs_974_; lean_object* v_chainPairs_975_; lean_object* v_gmPairs_976_; lean_object* v___x_978_; uint8_t v_isShared_979_; uint8_t v_isSharedCheck_1050_; 
v_statistics_962_ = lean_ctor_get(v_a_947_, 1);
lean_inc_ref(v_statistics_962_);
v_table_963_ = lean_ctor_get(v_a_947_, 0);
v_work_964_ = lean_ctor_get(v_statistics_962_, 0);
v_allocatedBytes_965_ = lean_ctor_get(v_statistics_962_, 1);
v_pairs_966_ = lean_ctor_get(v_statistics_962_, 2);
v_rounds_967_ = lean_ctor_get(v_statistics_962_, 3);
v_matrixEntries_968_ = lean_ctor_get(v_statistics_962_, 4);
v_matrixRows_969_ = lean_ctor_get(v_statistics_962_, 5);
v_matrixCalls_970_ = lean_ctor_get(v_statistics_962_, 6);
v_peakMatrixRows_971_ = lean_ctor_get(v_statistics_962_, 7);
v_peakMatrixEntries_972_ = lean_ctor_get(v_statistics_962_, 8);
v_largestBatch_973_ = lean_ctor_get(v_statistics_962_, 9);
v_productPairs_974_ = lean_ctor_get(v_statistics_962_, 10);
v_chainPairs_975_ = lean_ctor_get(v_statistics_962_, 11);
v_gmPairs_976_ = lean_ctor_get(v_statistics_962_, 12);
v_isSharedCheck_1050_ = !lean_is_exclusive(v_statistics_962_);
if (v_isSharedCheck_1050_ == 0)
{
v___x_978_ = v_statistics_962_;
v_isShared_979_ = v_isSharedCheck_1050_;
goto v_resetjp_977_;
}
else
{
lean_inc(v_gmPairs_976_);
lean_inc(v_chainPairs_975_);
lean_inc(v_productPairs_974_);
lean_inc(v_largestBatch_973_);
lean_inc(v_peakMatrixEntries_972_);
lean_inc(v_peakMatrixRows_971_);
lean_inc(v_matrixCalls_970_);
lean_inc(v_matrixRows_969_);
lean_inc(v_matrixEntries_968_);
lean_inc(v_rounds_967_);
lean_inc(v_pairs_966_);
lean_inc(v_allocatedBytes_965_);
lean_inc(v_work_964_);
lean_dec(v_statistics_962_);
v___x_978_ = lean_box(0);
v_isShared_979_ = v_isSharedCheck_1050_;
goto v_resetjp_977_;
}
v_resetjp_977_:
{
lean_object* v_work_980_; lean_object* v_work_981_; uint8_t v___x_982_; 
v_work_980_ = lean_ctor_get(v_limits_944_, 0);
v_work_981_ = lean_nat_add(v_work_964_, v___x_957_);
lean_dec(v_work_964_);
v___x_982_ = lean_nat_dec_lt(v_work_980_, v_work_981_);
if (v___x_982_ == 0)
{
lean_object* v___x_984_; uint8_t v_isShared_985_; uint8_t v_isSharedCheck_1045_; 
lean_inc_ref(v_table_963_);
v_isSharedCheck_1045_ = !lean_is_exclusive(v_a_947_);
if (v_isSharedCheck_1045_ == 0)
{
lean_object* v_unused_1046_; lean_object* v_unused_1047_; 
v_unused_1046_ = lean_ctor_get(v_a_947_, 1);
lean_dec(v_unused_1046_);
v_unused_1047_ = lean_ctor_get(v_a_947_, 0);
lean_dec(v_unused_1047_);
v___x_984_ = v_a_947_;
v_isShared_985_ = v_isSharedCheck_1045_;
goto v_resetjp_983_;
}
else
{
lean_dec(v_a_947_);
v___x_984_ = lean_box(0);
v_isShared_985_ = v_isSharedCheck_1045_;
goto v_resetjp_983_;
}
v_resetjp_983_:
{
lean_object* v___x_987_; 
if (v_isShared_979_ == 0)
{
lean_ctor_set(v___x_978_, 0, v_work_981_);
v___x_987_ = v___x_978_;
goto v_reusejp_986_;
}
else
{
lean_object* v_reuseFailAlloc_1044_; 
v_reuseFailAlloc_1044_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_1044_, 0, v_work_981_);
lean_ctor_set(v_reuseFailAlloc_1044_, 1, v_allocatedBytes_965_);
lean_ctor_set(v_reuseFailAlloc_1044_, 2, v_pairs_966_);
lean_ctor_set(v_reuseFailAlloc_1044_, 3, v_rounds_967_);
lean_ctor_set(v_reuseFailAlloc_1044_, 4, v_matrixEntries_968_);
lean_ctor_set(v_reuseFailAlloc_1044_, 5, v_matrixRows_969_);
lean_ctor_set(v_reuseFailAlloc_1044_, 6, v_matrixCalls_970_);
lean_ctor_set(v_reuseFailAlloc_1044_, 7, v_peakMatrixRows_971_);
lean_ctor_set(v_reuseFailAlloc_1044_, 8, v_peakMatrixEntries_972_);
lean_ctor_set(v_reuseFailAlloc_1044_, 9, v_largestBatch_973_);
lean_ctor_set(v_reuseFailAlloc_1044_, 10, v_productPairs_974_);
lean_ctor_set(v_reuseFailAlloc_1044_, 11, v_chainPairs_975_);
lean_ctor_set(v_reuseFailAlloc_1044_, 12, v_gmPairs_976_);
v___x_987_ = v_reuseFailAlloc_1044_;
goto v_reusejp_986_;
}
v_reusejp_986_:
{
lean_object* v___x_989_; 
if (v_isShared_985_ == 0)
{
lean_ctor_set(v___x_984_, 1, v___x_987_);
v___x_989_ = v___x_984_;
goto v_reusejp_988_;
}
else
{
lean_object* v_reuseFailAlloc_1043_; 
v_reuseFailAlloc_1043_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1043_, 0, v_table_963_);
lean_ctor_set(v_reuseFailAlloc_1043_, 1, v___x_987_);
v___x_989_ = v_reuseFailAlloc_1043_;
goto v_reusejp_988_;
}
v_reusejp_988_:
{
lean_object* v___x_990_; lean_object* v___x_991_; lean_object* v_fst_992_; 
v___x_990_ = lean_byte_array_size(v_coefficients_954_);
v___x_991_ = lp_Hex_Hex_Groebner_Computation_allocate(v_limits_944_, v___x_990_, v___x_989_);
v_fst_992_ = lean_ctor_get(v___x_991_, 0);
lean_inc(v_fst_992_);
if (lean_obj_tag(v_fst_992_) == 0)
{
lean_object* v_snd_993_; lean_object* v___x_995_; uint8_t v_isShared_996_; uint8_t v_isSharedCheck_1008_; 
lean_dec(v___x_957_);
lean_dec_ref(v_support_953_);
lean_dec_ref(v_p_945_);
v_snd_993_ = lean_ctor_get(v___x_991_, 1);
v_isSharedCheck_1008_ = !lean_is_exclusive(v___x_991_);
if (v_isSharedCheck_1008_ == 0)
{
lean_object* v_unused_1009_; 
v_unused_1009_ = lean_ctor_get(v___x_991_, 0);
lean_dec(v_unused_1009_);
v___x_995_ = v___x_991_;
v_isShared_996_ = v_isSharedCheck_1008_;
goto v_resetjp_994_;
}
else
{
lean_inc(v_snd_993_);
lean_dec(v___x_991_);
v___x_995_ = lean_box(0);
v_isShared_996_ = v_isSharedCheck_1008_;
goto v_resetjp_994_;
}
v_resetjp_994_:
{
lean_object* v_a_997_; lean_object* v___x_999_; uint8_t v_isShared_1000_; uint8_t v_isSharedCheck_1007_; 
v_a_997_ = lean_ctor_get(v_fst_992_, 0);
v_isSharedCheck_1007_ = !lean_is_exclusive(v_fst_992_);
if (v_isSharedCheck_1007_ == 0)
{
v___x_999_ = v_fst_992_;
v_isShared_1000_ = v_isSharedCheck_1007_;
goto v_resetjp_998_;
}
else
{
lean_inc(v_a_997_);
lean_dec(v_fst_992_);
v___x_999_ = lean_box(0);
v_isShared_1000_ = v_isSharedCheck_1007_;
goto v_resetjp_998_;
}
v_resetjp_998_:
{
lean_object* v___x_1002_; 
if (v_isShared_1000_ == 0)
{
v___x_1002_ = v___x_999_;
goto v_reusejp_1001_;
}
else
{
lean_object* v_reuseFailAlloc_1006_; 
v_reuseFailAlloc_1006_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1006_, 0, v_a_997_);
v___x_1002_ = v_reuseFailAlloc_1006_;
goto v_reusejp_1001_;
}
v_reusejp_1001_:
{
lean_object* v___x_1004_; 
if (v_isShared_996_ == 0)
{
lean_ctor_set(v___x_995_, 0, v___x_1002_);
v___x_1004_ = v___x_995_;
goto v_reusejp_1003_;
}
else
{
lean_object* v_reuseFailAlloc_1005_; 
v_reuseFailAlloc_1005_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1005_, 0, v___x_1002_);
lean_ctor_set(v_reuseFailAlloc_1005_, 1, v_snd_993_);
v___x_1004_ = v_reuseFailAlloc_1005_;
goto v_reusejp_1003_;
}
v_reusejp_1003_:
{
return v___x_1004_;
}
}
}
}
}
else
{
lean_object* v_snd_1010_; uint64_t v_field_1011_; lean_object* v___x_1012_; uint64_t v_ctx_1013_; lean_object* v_coefficients_1014_; lean_object* v___x_1015_; lean_object* v___x_1016_; lean_object* v___x_1018_; uint8_t v_isShared_1019_; uint8_t v_isSharedCheck_1040_; 
lean_dec_ref_known(v_fst_992_, 1);
v_snd_1010_ = lean_ctor_get(v___x_991_, 1);
lean_inc(v_snd_1010_);
lean_dec_ref(v___x_991_);
v_field_1011_ = lean_ctor_get_uint64(v_context_943_, sizeof(void*)*1);
v___x_1012_ = lean_unsigned_to_nat(1u);
v_ctx_1013_ = lp_Hex_BarrettCtx_mk___redArg(v_field_1011_);
v_coefficients_1014_ = lean_mk_empty_byte_array(v___x_990_);
v___x_1015_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1015_, 0, v___x_958_);
lean_ctor_set(v___x_1015_, 1, v___x_957_);
lean_ctor_set(v___x_1015_, 2, v___x_1012_);
v___x_1016_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg(v_field_1011_, v_ctx_1013_, v_factor_946_, v_p_945_, v___x_1015_, v_coefficients_1014_, v___x_958_, v_snd_1010_);
lean_dec_ref_known(v___x_1015_, 3);
v_isSharedCheck_1040_ = !lean_is_exclusive(v_p_945_);
if (v_isSharedCheck_1040_ == 0)
{
lean_object* v_unused_1041_; lean_object* v_unused_1042_; 
v_unused_1041_ = lean_ctor_get(v_p_945_, 1);
lean_dec(v_unused_1041_);
v_unused_1042_ = lean_ctor_get(v_p_945_, 0);
lean_dec(v_unused_1042_);
v___x_1018_ = v_p_945_;
v_isShared_1019_ = v_isSharedCheck_1040_;
goto v_resetjp_1017_;
}
else
{
lean_dec(v_p_945_);
v___x_1018_ = lean_box(0);
v_isShared_1019_ = v_isSharedCheck_1040_;
goto v_resetjp_1017_;
}
v_resetjp_1017_:
{
lean_object* v_fst_1020_; lean_object* v_snd_1021_; lean_object* v___x_1023_; uint8_t v_isShared_1024_; uint8_t v_isSharedCheck_1039_; 
v_fst_1020_ = lean_ctor_get(v___x_1016_, 0);
v_snd_1021_ = lean_ctor_get(v___x_1016_, 1);
v_isSharedCheck_1039_ = !lean_is_exclusive(v___x_1016_);
if (v_isSharedCheck_1039_ == 0)
{
v___x_1023_ = v___x_1016_;
v_isShared_1024_ = v_isSharedCheck_1039_;
goto v_resetjp_1022_;
}
else
{
lean_inc(v_snd_1021_);
lean_inc(v_fst_1020_);
lean_dec(v___x_1016_);
v___x_1023_ = lean_box(0);
v_isShared_1024_ = v_isSharedCheck_1039_;
goto v_resetjp_1022_;
}
v_resetjp_1022_:
{
lean_object* v_a_1025_; lean_object* v___x_1027_; uint8_t v_isShared_1028_; uint8_t v_isSharedCheck_1038_; 
v_a_1025_ = lean_ctor_get(v_fst_1020_, 0);
v_isSharedCheck_1038_ = !lean_is_exclusive(v_fst_1020_);
if (v_isSharedCheck_1038_ == 0)
{
v___x_1027_ = v_fst_1020_;
v_isShared_1028_ = v_isSharedCheck_1038_;
goto v_resetjp_1026_;
}
else
{
lean_inc(v_a_1025_);
lean_dec(v_fst_1020_);
v___x_1027_ = lean_box(0);
v_isShared_1028_ = v_isSharedCheck_1038_;
goto v_resetjp_1026_;
}
v_resetjp_1026_:
{
lean_object* v___x_1030_; 
if (v_isShared_1019_ == 0)
{
lean_ctor_set(v___x_1018_, 1, v_a_1025_);
v___x_1030_ = v___x_1018_;
goto v_reusejp_1029_;
}
else
{
lean_object* v_reuseFailAlloc_1037_; 
v_reuseFailAlloc_1037_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1037_, 0, v_support_953_);
lean_ctor_set(v_reuseFailAlloc_1037_, 1, v_a_1025_);
v___x_1030_ = v_reuseFailAlloc_1037_;
goto v_reusejp_1029_;
}
v_reusejp_1029_:
{
lean_object* v___x_1032_; 
if (v_isShared_1028_ == 0)
{
lean_ctor_set(v___x_1027_, 0, v___x_1030_);
v___x_1032_ = v___x_1027_;
goto v_reusejp_1031_;
}
else
{
lean_object* v_reuseFailAlloc_1036_; 
v_reuseFailAlloc_1036_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1036_, 0, v___x_1030_);
v___x_1032_ = v_reuseFailAlloc_1036_;
goto v_reusejp_1031_;
}
v_reusejp_1031_:
{
lean_object* v___x_1034_; 
if (v_isShared_1024_ == 0)
{
lean_ctor_set(v___x_1023_, 0, v___x_1032_);
v___x_1034_ = v___x_1023_;
goto v_reusejp_1033_;
}
else
{
lean_object* v_reuseFailAlloc_1035_; 
v_reuseFailAlloc_1035_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1035_, 0, v___x_1032_);
lean_ctor_set(v_reuseFailAlloc_1035_, 1, v_snd_1021_);
v___x_1034_ = v_reuseFailAlloc_1035_;
goto v_reusejp_1033_;
}
v_reusejp_1033_:
{
return v___x_1034_;
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_1048_; lean_object* v___x_1049_; 
lean_dec(v_work_981_);
lean_del_object(v___x_978_);
lean_dec(v_gmPairs_976_);
lean_dec(v_chainPairs_975_);
lean_dec(v_productPairs_974_);
lean_dec(v_largestBatch_973_);
lean_dec(v_peakMatrixEntries_972_);
lean_dec(v_peakMatrixRows_971_);
lean_dec(v_matrixCalls_970_);
lean_dec(v_matrixRows_969_);
lean_dec(v_matrixEntries_968_);
lean_dec(v_rounds_967_);
lean_dec(v_pairs_966_);
lean_dec(v_allocatedBytes_965_);
lean_dec(v___x_957_);
lean_dec_ref(v_support_953_);
lean_dec_ref(v_p_945_);
v___x_1048_ = ((lean_object*)(lp_Hex_Hex_Groebner_Polynomial_normalize___closed__4));
v___x_1049_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1049_, 0, v___x_1048_);
lean_ctor_set(v___x_1049_, 1, v_a_947_);
return v___x_1049_;
}
}
}
else
{
lean_object* v___x_1051_; lean_object* v___x_1052_; 
lean_dec(v___x_957_);
lean_dec_ref(v_support_953_);
lean_dec_ref(v_p_945_);
v___x_1051_ = lean_obj_once(&lp_Hex_Hex_Groebner_Polynomial_scale___closed__0, &lp_Hex_Hex_Groebner_Polynomial_scale___closed__0_once, _init_lp_Hex_Hex_Groebner_Polynomial_scale___closed__0);
v___x_1052_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1052_, 0, v___x_1051_);
lean_ctor_set(v___x_1052_, 1, v_a_947_);
return v___x_1052_;
}
}
else
{
lean_dec(v___x_957_);
goto v___jp_948_;
}
}
else
{
goto v___jp_948_;
}
v___jp_948_:
{
lean_object* v___x_949_; lean_object* v___x_950_; 
v___x_949_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_949_, 0, v_p_945_);
v___x_950_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_950_, 0, v___x_949_);
lean_ctor_set(v___x_950_, 1, v_a_947_);
return v___x_950_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_scale___boxed(lean_object* v_context_1053_, lean_object* v_limits_1054_, lean_object* v_p_1055_, lean_object* v_factor_1056_, lean_object* v_a_1057_){
_start:
{
uint64_t v_factor_boxed_1058_; lean_object* v_res_1059_; 
v_factor_boxed_1058_ = lean_unbox_uint64(v_factor_1056_);
lean_dec_ref(v_factor_1056_);
v_res_1059_ = lp_Hex_Hex_Groebner_Polynomial_scale(v_context_1053_, v_limits_1054_, v_p_1055_, v_factor_boxed_1058_, v_a_1057_);
lean_dec_ref(v_limits_1054_);
lean_dec_ref(v_context_1053_);
return v_res_1059_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0(uint64_t v___x_1060_, uint64_t v_ctx_1061_, uint64_t v_factor_1062_, lean_object* v_p_1063_, lean_object* v_range_1064_, lean_object* v_b_1065_, lean_object* v_i_1066_, lean_object* v_hs_1067_, lean_object* v_hl_1068_, lean_object* v___y_1069_){
_start:
{
lean_object* v___x_1070_; 
v___x_1070_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg(v___x_1060_, v_ctx_1061_, v_factor_1062_, v_p_1063_, v_range_1064_, v_b_1065_, v_i_1066_, v___y_1069_);
return v___x_1070_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___boxed(lean_object* v___x_1071_, lean_object* v_ctx_1072_, lean_object* v_factor_1073_, lean_object* v_p_1074_, lean_object* v_range_1075_, lean_object* v_b_1076_, lean_object* v_i_1077_, lean_object* v_hs_1078_, lean_object* v_hl_1079_, lean_object* v___y_1080_){
_start:
{
uint64_t v___x_5191__boxed_1081_; uint64_t v_ctx_boxed_1082_; uint64_t v_factor_boxed_1083_; lean_object* v_res_1084_; 
v___x_5191__boxed_1081_ = lean_unbox_uint64(v___x_1071_);
lean_dec_ref(v___x_1071_);
v_ctx_boxed_1082_ = lean_unbox_uint64(v_ctx_1072_);
lean_dec_ref(v_ctx_1072_);
v_factor_boxed_1083_ = lean_unbox_uint64(v_factor_1073_);
lean_dec_ref(v_factor_1073_);
v_res_1084_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0(v___x_5191__boxed_1081_, v_ctx_boxed_1082_, v_factor_boxed_1083_, v_p_1074_, v_range_1075_, v_b_1076_, v_i_1077_, v_hs_1078_, v_hl_1079_, v___y_1080_);
lean_dec_ref(v_range_1075_);
lean_dec_ref(v_p_1074_);
return v_res_1084_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monic(lean_object* v_context_1085_, lean_object* v_limits_1086_, lean_object* v_p_1087_, lean_object* v_a_1088_){
_start:
{
uint64_t v___y_1093_; uint64_t v___y_1094_; uint64_t v___y_1119_; uint64_t v___y_1120_; uint8_t v___y_1121_; uint64_t v___y_1127_; uint64_t v___y_1128_; uint8_t v___y_1129_; lean_object* v_support_1134_; lean_object* v_coefficients_1135_; lean_object* v___x_1136_; lean_object* v___x_1137_; lean_object* v___x_1138_; lean_object* v___x_1139_; uint8_t v___x_1140_; 
v_support_1134_ = lean_ctor_get(v_p_1087_, 0);
v_coefficients_1135_ = lean_ctor_get(v_p_1087_, 1);
v___x_1136_ = lean_byte_array_size(v_support_1134_);
v___x_1137_ = lean_unsigned_to_nat(2u);
v___x_1138_ = lean_nat_shiftr(v___x_1136_, v___x_1137_);
v___x_1139_ = lean_unsigned_to_nat(0u);
v___x_1140_ = lean_nat_dec_eq(v___x_1138_, v___x_1139_);
lean_dec(v___x_1138_);
if (v___x_1140_ == 0)
{
uint64_t v_field_1141_; uint64_t v___y_1143_; uint8_t v___y_1144_; lean_object* v___y_1145_; uint64_t v___y_1146_; uint8_t v___y_1147_; uint64_t v___y_1159_; uint8_t v___y_1160_; lean_object* v___y_1161_; uint64_t v___y_1162_; uint8_t v___y_1163_; uint64_t v___y_1174_; uint8_t v___y_1175_; lean_object* v___y_1176_; uint8_t v___y_1177_; uint8_t v___y_1178_; uint64_t v___y_1193_; uint8_t v___y_1194_; lean_object* v___y_1195_; uint8_t v___y_1196_; uint8_t v___y_1197_; uint64_t v___y_1231_; uint8_t v___y_1232_; lean_object* v___y_1233_; uint8_t v___y_1234_; lean_object* v___y_1235_; uint64_t v___y_1242_; uint64_t v___y_1250_; uint8_t v___y_1251_; uint64_t v___y_1257_; uint8_t v___y_1258_; uint8_t v___x_1263_; uint8_t v___x_1264_; uint64_t v___y_1266_; uint8_t v___y_1267_; uint64_t v___y_1279_; uint8_t v___y_1280_; uint8_t v___y_1291_; uint8_t v___y_1306_; lean_object* v___y_1340_; 
v_field_1141_ = lean_ctor_get_uint64(v_context_1085_, sizeof(void*)*1);
v___x_1263_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_1141_);
v___x_1264_ = 0;
switch(v___x_1263_)
{
case 0:
{
lean_object* v___x_1346_; 
v___x_1346_ = lean_unsigned_to_nat(1u);
v___y_1340_ = v___x_1346_;
goto v___jp_1339_;
}
case 1:
{
v___y_1340_ = v___x_1137_;
goto v___jp_1339_;
}
default: 
{
lean_object* v___x_1347_; 
v___x_1347_ = lean_unsigned_to_nat(4u);
v___y_1340_ = v___x_1347_;
goto v___jp_1339_;
}
}
v___jp_1142_:
{
uint64_t v___x_1148_; uint64_t v___x_1149_; uint64_t v___x_1150_; uint64_t v___x_1151_; lean_object* v___x_1152_; uint8_t v___x_1153_; 
v___x_1148_ = lean_uint8_to_uint64(v___y_1147_);
v___x_1149_ = 16ULL;
v___x_1150_ = lean_uint64_shift_left(v___x_1148_, v___x_1149_);
v___x_1151_ = lean_uint64_lor(v___y_1146_, v___x_1150_);
v___x_1152_ = lean_unsigned_to_nat(3u);
v___x_1153_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1145_, v___x_1152_);
if (v___x_1153_ == 0)
{
lean_object* v___x_1154_; lean_object* v___x_1155_; uint8_t v___x_1156_; 
lean_dec_ref(v___y_1145_);
v___x_1154_ = lean_box(v___y_1144_);
v___x_1155_ = l_outOfBounds___redArg(v___x_1154_);
lean_dec(v___x_1154_);
v___x_1156_ = lean_unbox(v___x_1155_);
lean_dec(v___x_1155_);
v___y_1119_ = v___y_1143_;
v___y_1120_ = v___x_1151_;
v___y_1121_ = v___x_1156_;
goto v___jp_1118_;
}
else
{
uint8_t v___x_1157_; 
v___x_1157_ = lean_byte_array_fget(v___y_1145_, v___x_1152_);
lean_dec_ref(v___y_1145_);
v___y_1119_ = v___y_1143_;
v___y_1120_ = v___x_1151_;
v___y_1121_ = v___x_1157_;
goto v___jp_1118_;
}
}
v___jp_1158_:
{
uint64_t v___x_1164_; uint64_t v___x_1165_; uint64_t v___x_1166_; uint64_t v___x_1167_; uint8_t v___x_1168_; 
v___x_1164_ = lean_uint8_to_uint64(v___y_1163_);
v___x_1165_ = 8ULL;
v___x_1166_ = lean_uint64_shift_left(v___x_1164_, v___x_1165_);
v___x_1167_ = lean_uint64_lor(v___y_1162_, v___x_1166_);
v___x_1168_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1161_, v___x_1137_);
if (v___x_1168_ == 0)
{
lean_object* v___x_1169_; lean_object* v___x_1170_; uint8_t v___x_1171_; 
v___x_1169_ = lean_box(v___y_1160_);
v___x_1170_ = l_outOfBounds___redArg(v___x_1169_);
lean_dec(v___x_1169_);
v___x_1171_ = lean_unbox(v___x_1170_);
lean_dec(v___x_1170_);
v___y_1143_ = v___y_1159_;
v___y_1144_ = v___y_1160_;
v___y_1145_ = v___y_1161_;
v___y_1146_ = v___x_1167_;
v___y_1147_ = v___x_1171_;
goto v___jp_1142_;
}
else
{
uint8_t v___x_1172_; 
v___x_1172_ = lean_byte_array_fget(v___y_1161_, v___x_1137_);
v___y_1143_ = v___y_1159_;
v___y_1144_ = v___y_1160_;
v___y_1145_ = v___y_1161_;
v___y_1146_ = v___x_1167_;
v___y_1147_ = v___x_1172_;
goto v___jp_1142_;
}
}
v___jp_1173_:
{
uint64_t v_a_1179_; 
v_a_1179_ = lean_uint8_to_uint64(v___y_1178_);
switch(v___y_1177_)
{
case 0:
{
lean_dec_ref(v___y_1176_);
v___y_1093_ = v___y_1174_;
v___y_1094_ = v_a_1179_;
goto v___jp_1092_;
}
case 1:
{
lean_object* v___x_1180_; uint8_t v___x_1181_; 
v___x_1180_ = lean_unsigned_to_nat(1u);
v___x_1181_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1176_, v___x_1180_);
if (v___x_1181_ == 0)
{
lean_object* v___x_1182_; lean_object* v___x_1183_; uint8_t v___x_1184_; 
lean_dec_ref(v___y_1176_);
v___x_1182_ = lean_box(v___y_1175_);
v___x_1183_ = l_outOfBounds___redArg(v___x_1182_);
lean_dec(v___x_1182_);
v___x_1184_ = lean_unbox(v___x_1183_);
lean_dec(v___x_1183_);
v___y_1127_ = v___y_1174_;
v___y_1128_ = v_a_1179_;
v___y_1129_ = v___x_1184_;
goto v___jp_1126_;
}
else
{
uint8_t v___x_1185_; 
v___x_1185_ = lean_byte_array_fget(v___y_1176_, v___x_1180_);
lean_dec_ref(v___y_1176_);
v___y_1127_ = v___y_1174_;
v___y_1128_ = v_a_1179_;
v___y_1129_ = v___x_1185_;
goto v___jp_1126_;
}
}
default: 
{
lean_object* v___x_1186_; uint8_t v___x_1187_; 
v___x_1186_ = lean_unsigned_to_nat(1u);
v___x_1187_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1176_, v___x_1186_);
if (v___x_1187_ == 0)
{
lean_object* v___x_1188_; lean_object* v___x_1189_; uint8_t v___x_1190_; 
v___x_1188_ = lean_box(v___y_1175_);
v___x_1189_ = l_outOfBounds___redArg(v___x_1188_);
lean_dec(v___x_1188_);
v___x_1190_ = lean_unbox(v___x_1189_);
lean_dec(v___x_1189_);
v___y_1159_ = v___y_1174_;
v___y_1160_ = v___y_1175_;
v___y_1161_ = v___y_1176_;
v___y_1162_ = v_a_1179_;
v___y_1163_ = v___x_1190_;
goto v___jp_1158_;
}
else
{
uint8_t v___x_1191_; 
v___x_1191_ = lean_byte_array_fget(v___y_1176_, v___x_1186_);
v___y_1159_ = v___y_1174_;
v___y_1160_ = v___y_1175_;
v___y_1161_ = v___y_1176_;
v___y_1162_ = v_a_1179_;
v___y_1163_ = v___x_1191_;
goto v___jp_1158_;
}
}
}
}
v___jp_1192_:
{
if (v___y_1197_ == 0)
{
uint8_t v___x_1198_; 
v___x_1198_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1195_, v___x_1139_);
if (v___x_1198_ == 0)
{
lean_object* v___x_1199_; lean_object* v___x_1200_; uint8_t v___x_1201_; 
v___x_1199_ = lean_box(v___y_1194_);
v___x_1200_ = l_outOfBounds___redArg(v___x_1199_);
lean_dec(v___x_1199_);
v___x_1201_ = lean_unbox(v___x_1200_);
lean_dec(v___x_1200_);
v___y_1174_ = v___y_1193_;
v___y_1175_ = v___y_1194_;
v___y_1176_ = v___y_1195_;
v___y_1177_ = v___y_1196_;
v___y_1178_ = v___x_1201_;
goto v___jp_1173_;
}
else
{
uint8_t v___x_1202_; 
v___x_1202_ = lean_byte_array_fget(v___y_1195_, v___x_1139_);
v___y_1174_ = v___y_1193_;
v___y_1175_ = v___y_1194_;
v___y_1176_ = v___y_1195_;
v___y_1177_ = v___y_1196_;
v___y_1178_ = v___x_1202_;
goto v___jp_1173_;
}
}
else
{
size_t v_pos_1203_; uint8_t v___x_1204_; uint64_t v_a_1205_; 
v_pos_1203_ = ((size_t)0ULL);
v___x_1204_ = lean_byte_array_uget(v___y_1195_, v_pos_1203_);
v_a_1205_ = lean_uint8_to_uint64(v___x_1204_);
switch(v___y_1196_)
{
case 0:
{
lean_dec_ref(v___y_1195_);
v___y_1093_ = v___y_1193_;
v___y_1094_ = v_a_1205_;
goto v___jp_1092_;
}
case 1:
{
size_t v___x_1206_; uint8_t v___x_1207_; uint64_t v___x_1208_; uint64_t v___x_1209_; uint64_t v___x_1210_; uint64_t v___x_1211_; 
v___x_1206_ = ((size_t)1ULL);
v___x_1207_ = lean_byte_array_uget(v___y_1195_, v___x_1206_);
lean_dec_ref(v___y_1195_);
v___x_1208_ = lean_uint8_to_uint64(v___x_1207_);
v___x_1209_ = 8ULL;
v___x_1210_ = lean_uint64_shift_left(v___x_1208_, v___x_1209_);
v___x_1211_ = lean_uint64_lor(v_a_1205_, v___x_1210_);
v___y_1093_ = v___y_1193_;
v___y_1094_ = v___x_1211_;
goto v___jp_1092_;
}
default: 
{
size_t v___x_1212_; uint8_t v___x_1213_; uint64_t v___x_1214_; uint64_t v___x_1215_; uint64_t v___x_1216_; uint64_t v___x_1217_; size_t v___x_1218_; uint8_t v___x_1219_; uint64_t v___x_1220_; uint64_t v___x_1221_; uint64_t v___x_1222_; uint64_t v___x_1223_; size_t v___x_1224_; uint8_t v___x_1225_; uint64_t v___x_1226_; uint64_t v___x_1227_; uint64_t v___x_1228_; uint64_t v___x_1229_; 
v___x_1212_ = ((size_t)1ULL);
v___x_1213_ = lean_byte_array_uget(v___y_1195_, v___x_1212_);
v___x_1214_ = lean_uint8_to_uint64(v___x_1213_);
v___x_1215_ = 8ULL;
v___x_1216_ = lean_uint64_shift_left(v___x_1214_, v___x_1215_);
v___x_1217_ = lean_uint64_lor(v_a_1205_, v___x_1216_);
v___x_1218_ = ((size_t)2ULL);
v___x_1219_ = lean_byte_array_uget(v___y_1195_, v___x_1218_);
v___x_1220_ = lean_uint8_to_uint64(v___x_1219_);
v___x_1221_ = 16ULL;
v___x_1222_ = lean_uint64_shift_left(v___x_1220_, v___x_1221_);
v___x_1223_ = lean_uint64_lor(v___x_1217_, v___x_1222_);
v___x_1224_ = ((size_t)3ULL);
v___x_1225_ = lean_byte_array_uget(v___y_1195_, v___x_1224_);
lean_dec_ref(v___y_1195_);
v___x_1226_ = lean_uint8_to_uint64(v___x_1225_);
v___x_1227_ = 24ULL;
v___x_1228_ = lean_uint64_shift_left(v___x_1226_, v___x_1227_);
v___x_1229_ = lean_uint64_lor(v___x_1223_, v___x_1228_);
v___y_1093_ = v___y_1193_;
v___y_1094_ = v___x_1229_;
goto v___jp_1092_;
}
}
}
}
v___jp_1230_:
{
lean_object* v___x_1236_; uint8_t v___x_1237_; 
v___x_1236_ = lean_byte_array_size(v___y_1233_);
v___x_1237_ = lean_nat_dec_le(v___y_1235_, v___x_1236_);
if (v___x_1237_ == 0)
{
v___y_1193_ = v___y_1231_;
v___y_1194_ = v___y_1232_;
v___y_1195_ = v___y_1233_;
v___y_1196_ = v___y_1234_;
v___y_1197_ = v___x_1237_;
goto v___jp_1192_;
}
else
{
size_t v___x_1238_; lean_object* v___x_1239_; uint8_t v___x_1240_; 
v___x_1238_ = lean_usize_of_nat(v___y_1235_);
v___x_1239_ = lean_usize_to_nat(v___x_1238_);
v___x_1240_ = lean_nat_dec_eq(v___x_1239_, v___y_1235_);
lean_dec(v___x_1239_);
v___y_1193_ = v___y_1231_;
v___y_1194_ = v___y_1232_;
v___y_1195_ = v___y_1233_;
v___y_1196_ = v___y_1234_;
v___y_1197_ = v___x_1240_;
goto v___jp_1192_;
}
}
v___jp_1241_:
{
uint64_t v___x_1243_; uint8_t v___x_1244_; 
v___x_1243_ = 1ULL;
v___x_1244_ = lean_uint64_dec_eq(v___y_1242_, v___x_1243_);
if (v___x_1244_ == 0)
{
uint8_t v___x_1245_; uint8_t v___x_1246_; 
v___x_1245_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_1141_);
v___x_1246_ = 0;
switch(v___x_1245_)
{
case 0:
{
lean_object* v___x_1247_; 
v___x_1247_ = lean_unsigned_to_nat(1u);
lean_inc_ref(v_coefficients_1135_);
v___y_1231_ = v_field_1141_;
v___y_1232_ = v___x_1246_;
v___y_1233_ = v_coefficients_1135_;
v___y_1234_ = v___x_1245_;
v___y_1235_ = v___x_1247_;
goto v___jp_1230_;
}
case 1:
{
lean_inc_ref(v_coefficients_1135_);
v___y_1231_ = v_field_1141_;
v___y_1232_ = v___x_1246_;
v___y_1233_ = v_coefficients_1135_;
v___y_1234_ = v___x_1245_;
v___y_1235_ = v___x_1137_;
goto v___jp_1230_;
}
default: 
{
lean_object* v___x_1248_; 
v___x_1248_ = lean_unsigned_to_nat(4u);
lean_inc_ref(v_coefficients_1135_);
v___y_1231_ = v_field_1141_;
v___y_1232_ = v___x_1246_;
v___y_1233_ = v_coefficients_1135_;
v___y_1234_ = v___x_1245_;
v___y_1235_ = v___x_1248_;
goto v___jp_1230_;
}
}
}
else
{
goto v___jp_1089_;
}
}
v___jp_1249_:
{
uint64_t v___x_1252_; uint64_t v___x_1253_; uint64_t v___x_1254_; uint64_t v___x_1255_; 
v___x_1252_ = lean_uint8_to_uint64(v___y_1251_);
v___x_1253_ = 24ULL;
v___x_1254_ = lean_uint64_shift_left(v___x_1252_, v___x_1253_);
v___x_1255_ = lean_uint64_lor(v___y_1250_, v___x_1254_);
v___y_1242_ = v___x_1255_;
goto v___jp_1241_;
}
v___jp_1256_:
{
uint64_t v___x_1259_; uint64_t v___x_1260_; uint64_t v___x_1261_; uint64_t v___x_1262_; 
v___x_1259_ = lean_uint8_to_uint64(v___y_1258_);
v___x_1260_ = 8ULL;
v___x_1261_ = lean_uint64_shift_left(v___x_1259_, v___x_1260_);
v___x_1262_ = lean_uint64_lor(v___y_1257_, v___x_1261_);
v___y_1242_ = v___x_1262_;
goto v___jp_1241_;
}
v___jp_1265_:
{
uint64_t v___x_1268_; uint64_t v___x_1269_; uint64_t v___x_1270_; uint64_t v___x_1271_; lean_object* v___x_1272_; uint8_t v___x_1273_; 
v___x_1268_ = lean_uint8_to_uint64(v___y_1267_);
v___x_1269_ = 16ULL;
v___x_1270_ = lean_uint64_shift_left(v___x_1268_, v___x_1269_);
v___x_1271_ = lean_uint64_lor(v___y_1266_, v___x_1270_);
v___x_1272_ = lean_unsigned_to_nat(3u);
v___x_1273_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_1135_, v___x_1272_);
if (v___x_1273_ == 0)
{
lean_object* v___x_1274_; lean_object* v___x_1275_; uint8_t v___x_1276_; 
v___x_1274_ = lean_box(v___x_1264_);
v___x_1275_ = l_outOfBounds___redArg(v___x_1274_);
lean_dec(v___x_1274_);
v___x_1276_ = lean_unbox(v___x_1275_);
lean_dec(v___x_1275_);
v___y_1250_ = v___x_1271_;
v___y_1251_ = v___x_1276_;
goto v___jp_1249_;
}
else
{
uint8_t v___x_1277_; 
v___x_1277_ = lean_byte_array_fget(v_coefficients_1135_, v___x_1272_);
v___y_1250_ = v___x_1271_;
v___y_1251_ = v___x_1277_;
goto v___jp_1249_;
}
}
v___jp_1278_:
{
uint64_t v___x_1281_; uint64_t v___x_1282_; uint64_t v___x_1283_; uint64_t v___x_1284_; uint8_t v___x_1285_; 
v___x_1281_ = lean_uint8_to_uint64(v___y_1280_);
v___x_1282_ = 8ULL;
v___x_1283_ = lean_uint64_shift_left(v___x_1281_, v___x_1282_);
v___x_1284_ = lean_uint64_lor(v___y_1279_, v___x_1283_);
v___x_1285_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_1135_, v___x_1137_);
if (v___x_1285_ == 0)
{
lean_object* v___x_1286_; lean_object* v___x_1287_; uint8_t v___x_1288_; 
v___x_1286_ = lean_box(v___x_1264_);
v___x_1287_ = l_outOfBounds___redArg(v___x_1286_);
lean_dec(v___x_1286_);
v___x_1288_ = lean_unbox(v___x_1287_);
lean_dec(v___x_1287_);
v___y_1266_ = v___x_1284_;
v___y_1267_ = v___x_1288_;
goto v___jp_1265_;
}
else
{
uint8_t v___x_1289_; 
v___x_1289_ = lean_byte_array_fget(v_coefficients_1135_, v___x_1137_);
v___y_1266_ = v___x_1284_;
v___y_1267_ = v___x_1289_;
goto v___jp_1265_;
}
}
v___jp_1290_:
{
uint64_t v_a_1292_; 
v_a_1292_ = lean_uint8_to_uint64(v___y_1291_);
switch(v___x_1263_)
{
case 0:
{
v___y_1242_ = v_a_1292_;
goto v___jp_1241_;
}
case 1:
{
lean_object* v___x_1293_; uint8_t v___x_1294_; 
v___x_1293_ = lean_unsigned_to_nat(1u);
v___x_1294_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_1135_, v___x_1293_);
if (v___x_1294_ == 0)
{
lean_object* v___x_1295_; lean_object* v___x_1296_; uint8_t v___x_1297_; 
v___x_1295_ = lean_box(v___x_1264_);
v___x_1296_ = l_outOfBounds___redArg(v___x_1295_);
lean_dec(v___x_1295_);
v___x_1297_ = lean_unbox(v___x_1296_);
lean_dec(v___x_1296_);
v___y_1257_ = v_a_1292_;
v___y_1258_ = v___x_1297_;
goto v___jp_1256_;
}
else
{
uint8_t v___x_1298_; 
v___x_1298_ = lean_byte_array_fget(v_coefficients_1135_, v___x_1293_);
v___y_1257_ = v_a_1292_;
v___y_1258_ = v___x_1298_;
goto v___jp_1256_;
}
}
default: 
{
lean_object* v___x_1299_; uint8_t v___x_1300_; 
v___x_1299_ = lean_unsigned_to_nat(1u);
v___x_1300_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_1135_, v___x_1299_);
if (v___x_1300_ == 0)
{
lean_object* v___x_1301_; lean_object* v___x_1302_; uint8_t v___x_1303_; 
v___x_1301_ = lean_box(v___x_1264_);
v___x_1302_ = l_outOfBounds___redArg(v___x_1301_);
lean_dec(v___x_1301_);
v___x_1303_ = lean_unbox(v___x_1302_);
lean_dec(v___x_1302_);
v___y_1279_ = v_a_1292_;
v___y_1280_ = v___x_1303_;
goto v___jp_1278_;
}
else
{
uint8_t v___x_1304_; 
v___x_1304_ = lean_byte_array_fget(v_coefficients_1135_, v___x_1299_);
v___y_1279_ = v_a_1292_;
v___y_1280_ = v___x_1304_;
goto v___jp_1278_;
}
}
}
}
v___jp_1305_:
{
if (v___y_1306_ == 0)
{
uint8_t v___x_1307_; 
v___x_1307_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_coefficients_1135_, v___x_1139_);
if (v___x_1307_ == 0)
{
lean_object* v___x_1308_; lean_object* v___x_1309_; uint8_t v___x_1310_; 
v___x_1308_ = lean_box(v___x_1264_);
v___x_1309_ = l_outOfBounds___redArg(v___x_1308_);
lean_dec(v___x_1308_);
v___x_1310_ = lean_unbox(v___x_1309_);
lean_dec(v___x_1309_);
v___y_1291_ = v___x_1310_;
goto v___jp_1290_;
}
else
{
uint8_t v___x_1311_; 
v___x_1311_ = lean_byte_array_fget(v_coefficients_1135_, v___x_1139_);
v___y_1291_ = v___x_1311_;
goto v___jp_1290_;
}
}
else
{
size_t v_pos_1312_; uint8_t v___x_1313_; uint64_t v_a_1314_; 
v_pos_1312_ = ((size_t)0ULL);
v___x_1313_ = lean_byte_array_uget(v_coefficients_1135_, v_pos_1312_);
v_a_1314_ = lean_uint8_to_uint64(v___x_1313_);
switch(v___x_1263_)
{
case 0:
{
v___y_1242_ = v_a_1314_;
goto v___jp_1241_;
}
case 1:
{
size_t v___x_1315_; uint8_t v___x_1316_; uint64_t v___x_1317_; uint64_t v___x_1318_; uint64_t v___x_1319_; uint64_t v___x_1320_; 
v___x_1315_ = ((size_t)1ULL);
v___x_1316_ = lean_byte_array_uget(v_coefficients_1135_, v___x_1315_);
v___x_1317_ = lean_uint8_to_uint64(v___x_1316_);
v___x_1318_ = 8ULL;
v___x_1319_ = lean_uint64_shift_left(v___x_1317_, v___x_1318_);
v___x_1320_ = lean_uint64_lor(v_a_1314_, v___x_1319_);
v___y_1242_ = v___x_1320_;
goto v___jp_1241_;
}
default: 
{
size_t v___x_1321_; uint8_t v___x_1322_; uint64_t v___x_1323_; uint64_t v___x_1324_; uint64_t v___x_1325_; uint64_t v___x_1326_; size_t v___x_1327_; uint8_t v___x_1328_; uint64_t v___x_1329_; uint64_t v___x_1330_; uint64_t v___x_1331_; uint64_t v___x_1332_; size_t v___x_1333_; uint8_t v___x_1334_; uint64_t v___x_1335_; uint64_t v___x_1336_; uint64_t v___x_1337_; uint64_t v___x_1338_; 
v___x_1321_ = ((size_t)1ULL);
v___x_1322_ = lean_byte_array_uget(v_coefficients_1135_, v___x_1321_);
v___x_1323_ = lean_uint8_to_uint64(v___x_1322_);
v___x_1324_ = 8ULL;
v___x_1325_ = lean_uint64_shift_left(v___x_1323_, v___x_1324_);
v___x_1326_ = lean_uint64_lor(v_a_1314_, v___x_1325_);
v___x_1327_ = ((size_t)2ULL);
v___x_1328_ = lean_byte_array_uget(v_coefficients_1135_, v___x_1327_);
v___x_1329_ = lean_uint8_to_uint64(v___x_1328_);
v___x_1330_ = 16ULL;
v___x_1331_ = lean_uint64_shift_left(v___x_1329_, v___x_1330_);
v___x_1332_ = lean_uint64_lor(v___x_1326_, v___x_1331_);
v___x_1333_ = ((size_t)3ULL);
v___x_1334_ = lean_byte_array_uget(v_coefficients_1135_, v___x_1333_);
v___x_1335_ = lean_uint8_to_uint64(v___x_1334_);
v___x_1336_ = 24ULL;
v___x_1337_ = lean_uint64_shift_left(v___x_1335_, v___x_1336_);
v___x_1338_ = lean_uint64_lor(v___x_1332_, v___x_1337_);
v___y_1242_ = v___x_1338_;
goto v___jp_1241_;
}
}
}
}
v___jp_1339_:
{
lean_object* v___x_1341_; uint8_t v___x_1342_; 
v___x_1341_ = lean_byte_array_size(v_coefficients_1135_);
v___x_1342_ = lean_nat_dec_le(v___y_1340_, v___x_1341_);
if (v___x_1342_ == 0)
{
v___y_1306_ = v___x_1342_;
goto v___jp_1305_;
}
else
{
size_t v___x_1343_; lean_object* v___x_1344_; uint8_t v___x_1345_; 
v___x_1343_ = lean_usize_of_nat(v___y_1340_);
v___x_1344_ = lean_usize_to_nat(v___x_1343_);
v___x_1345_ = lean_nat_dec_eq(v___x_1344_, v___y_1340_);
lean_dec(v___x_1344_);
v___y_1306_ = v___x_1345_;
goto v___jp_1305_;
}
}
}
else
{
goto v___jp_1089_;
}
v___jp_1089_:
{
lean_object* v___x_1090_; lean_object* v___x_1091_; 
v___x_1090_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1090_, 0, v_p_1087_);
v___x_1091_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1091_, 0, v___x_1090_);
lean_ctor_set(v___x_1091_, 1, v_a_1088_);
return v___x_1091_;
}
v___jp_1092_:
{
lean_object* v___x_1095_; lean_object* v_fst_1096_; 
v___x_1095_ = lp_Hex_Hex_Groebner_Computation_inverse(v___y_1093_, v_limits_1086_, v___y_1094_, v_a_1088_);
v_fst_1096_ = lean_ctor_get(v___x_1095_, 0);
lean_inc(v_fst_1096_);
if (lean_obj_tag(v_fst_1096_) == 0)
{
lean_object* v_snd_1097_; lean_object* v___x_1099_; uint8_t v_isShared_1100_; uint8_t v_isSharedCheck_1112_; 
lean_dec_ref(v_p_1087_);
v_snd_1097_ = lean_ctor_get(v___x_1095_, 1);
v_isSharedCheck_1112_ = !lean_is_exclusive(v___x_1095_);
if (v_isSharedCheck_1112_ == 0)
{
lean_object* v_unused_1113_; 
v_unused_1113_ = lean_ctor_get(v___x_1095_, 0);
lean_dec(v_unused_1113_);
v___x_1099_ = v___x_1095_;
v_isShared_1100_ = v_isSharedCheck_1112_;
goto v_resetjp_1098_;
}
else
{
lean_inc(v_snd_1097_);
lean_dec(v___x_1095_);
v___x_1099_ = lean_box(0);
v_isShared_1100_ = v_isSharedCheck_1112_;
goto v_resetjp_1098_;
}
v_resetjp_1098_:
{
lean_object* v_a_1101_; lean_object* v___x_1103_; uint8_t v_isShared_1104_; uint8_t v_isSharedCheck_1111_; 
v_a_1101_ = lean_ctor_get(v_fst_1096_, 0);
v_isSharedCheck_1111_ = !lean_is_exclusive(v_fst_1096_);
if (v_isSharedCheck_1111_ == 0)
{
v___x_1103_ = v_fst_1096_;
v_isShared_1104_ = v_isSharedCheck_1111_;
goto v_resetjp_1102_;
}
else
{
lean_inc(v_a_1101_);
lean_dec(v_fst_1096_);
v___x_1103_ = lean_box(0);
v_isShared_1104_ = v_isSharedCheck_1111_;
goto v_resetjp_1102_;
}
v_resetjp_1102_:
{
lean_object* v___x_1106_; 
if (v_isShared_1104_ == 0)
{
v___x_1106_ = v___x_1103_;
goto v_reusejp_1105_;
}
else
{
lean_object* v_reuseFailAlloc_1110_; 
v_reuseFailAlloc_1110_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1110_, 0, v_a_1101_);
v___x_1106_ = v_reuseFailAlloc_1110_;
goto v_reusejp_1105_;
}
v_reusejp_1105_:
{
lean_object* v___x_1108_; 
if (v_isShared_1100_ == 0)
{
lean_ctor_set(v___x_1099_, 0, v___x_1106_);
v___x_1108_ = v___x_1099_;
goto v_reusejp_1107_;
}
else
{
lean_object* v_reuseFailAlloc_1109_; 
v_reuseFailAlloc_1109_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1109_, 0, v___x_1106_);
lean_ctor_set(v_reuseFailAlloc_1109_, 1, v_snd_1097_);
v___x_1108_ = v_reuseFailAlloc_1109_;
goto v_reusejp_1107_;
}
v_reusejp_1107_:
{
return v___x_1108_;
}
}
}
}
}
else
{
lean_object* v_snd_1114_; lean_object* v_a_1115_; uint64_t v___x_1116_; lean_object* v___x_1117_; 
v_snd_1114_ = lean_ctor_get(v___x_1095_, 1);
lean_inc(v_snd_1114_);
lean_dec_ref(v___x_1095_);
v_a_1115_ = lean_ctor_get(v_fst_1096_, 0);
lean_inc(v_a_1115_);
lean_dec_ref_known(v_fst_1096_, 1);
v___x_1116_ = lean_unbox_uint64(v_a_1115_);
lean_dec(v_a_1115_);
v___x_1117_ = lp_Hex_Hex_Groebner_Polynomial_scale(v_context_1085_, v_limits_1086_, v_p_1087_, v___x_1116_, v_snd_1114_);
return v___x_1117_;
}
}
v___jp_1118_:
{
uint64_t v___x_1122_; uint64_t v___x_1123_; uint64_t v___x_1124_; uint64_t v___x_1125_; 
v___x_1122_ = lean_uint8_to_uint64(v___y_1121_);
v___x_1123_ = 24ULL;
v___x_1124_ = lean_uint64_shift_left(v___x_1122_, v___x_1123_);
v___x_1125_ = lean_uint64_lor(v___y_1120_, v___x_1124_);
v___y_1093_ = v___y_1119_;
v___y_1094_ = v___x_1125_;
goto v___jp_1092_;
}
v___jp_1126_:
{
uint64_t v___x_1130_; uint64_t v___x_1131_; uint64_t v___x_1132_; uint64_t v___x_1133_; 
v___x_1130_ = lean_uint8_to_uint64(v___y_1129_);
v___x_1131_ = 8ULL;
v___x_1132_ = lean_uint64_shift_left(v___x_1130_, v___x_1131_);
v___x_1133_ = lean_uint64_lor(v___y_1128_, v___x_1132_);
v___y_1093_ = v___y_1127_;
v___y_1094_ = v___x_1133_;
goto v___jp_1092_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_monic___boxed(lean_object* v_context_1348_, lean_object* v_limits_1349_, lean_object* v_p_1350_, lean_object* v_a_1351_){
_start:
{
lean_object* v_res_1352_; 
v_res_1352_ = lp_Hex_Hex_Groebner_Polynomial_monic(v_context_1348_, v_limits_1349_, v_p_1350_, v_a_1351_);
lean_dec_ref(v_limits_1349_);
lean_dec_ref(v_context_1348_);
return v_res_1352_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_multiply___redArg(lean_object* v_limits_1353_, lean_object* v_p_1354_, lean_object* v_monomial_1355_, lean_object* v_a_1356_){
_start:
{
lean_object* v_table_1357_; lean_object* v_metadata_1358_; lean_object* v___x_1359_; lean_object* v___x_1360_; uint64_t v___x_1361_; lean_object* v___x_1362_; lean_object* v___x_1363_; uint8_t v___x_1364_; 
v_table_1357_ = lean_ctor_get(v_a_1356_, 0);
v_metadata_1358_ = lean_ctor_get(v_table_1357_, 2);
v___x_1359_ = lean_unsigned_to_nat(3u);
v___x_1360_ = lean_nat_mul(v___x_1359_, v_monomial_1355_);
v___x_1361_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1358_, v___x_1360_);
lean_dec(v___x_1360_);
v___x_1362_ = lean_uint64_to_nat(v___x_1361_);
v___x_1363_ = lean_unsigned_to_nat(0u);
v___x_1364_ = lean_nat_dec_eq(v___x_1362_, v___x_1363_);
lean_dec(v___x_1362_);
if (v___x_1364_ == 0)
{
lean_object* v_support_1365_; lean_object* v_coefficients_1366_; lean_object* v___x_1368_; uint8_t v_isShared_1369_; uint8_t v_isSharedCheck_1453_; 
v_support_1365_ = lean_ctor_get(v_p_1354_, 0);
v_coefficients_1366_ = lean_ctor_get(v_p_1354_, 1);
v_isSharedCheck_1453_ = !lean_is_exclusive(v_p_1354_);
if (v_isSharedCheck_1453_ == 0)
{
v___x_1368_ = v_p_1354_;
v_isShared_1369_ = v_isSharedCheck_1453_;
goto v_resetjp_1367_;
}
else
{
lean_inc(v_coefficients_1366_);
lean_inc(v_support_1365_);
lean_dec(v_p_1354_);
v___x_1368_ = lean_box(0);
v_isShared_1369_ = v_isSharedCheck_1453_;
goto v_resetjp_1367_;
}
v_resetjp_1367_:
{
lean_object* v___x_1370_; lean_object* v___x_1371_; lean_object* v_fst_1372_; 
v___x_1370_ = lean_byte_array_size(v_support_1365_);
v___x_1371_ = lp_Hex_Hex_Groebner_Computation_allocate(v_limits_1353_, v___x_1370_, v_a_1356_);
v_fst_1372_ = lean_ctor_get(v___x_1371_, 0);
lean_inc(v_fst_1372_);
if (lean_obj_tag(v_fst_1372_) == 0)
{
lean_object* v_snd_1373_; lean_object* v___x_1375_; uint8_t v_isShared_1376_; uint8_t v_isSharedCheck_1388_; 
lean_del_object(v___x_1368_);
lean_dec_ref(v_coefficients_1366_);
lean_dec_ref(v_support_1365_);
lean_dec(v_monomial_1355_);
lean_dec_ref(v_limits_1353_);
v_snd_1373_ = lean_ctor_get(v___x_1371_, 1);
v_isSharedCheck_1388_ = !lean_is_exclusive(v___x_1371_);
if (v_isSharedCheck_1388_ == 0)
{
lean_object* v_unused_1389_; 
v_unused_1389_ = lean_ctor_get(v___x_1371_, 0);
lean_dec(v_unused_1389_);
v___x_1375_ = v___x_1371_;
v_isShared_1376_ = v_isSharedCheck_1388_;
goto v_resetjp_1374_;
}
else
{
lean_inc(v_snd_1373_);
lean_dec(v___x_1371_);
v___x_1375_ = lean_box(0);
v_isShared_1376_ = v_isSharedCheck_1388_;
goto v_resetjp_1374_;
}
v_resetjp_1374_:
{
lean_object* v_a_1377_; lean_object* v___x_1379_; uint8_t v_isShared_1380_; uint8_t v_isSharedCheck_1387_; 
v_a_1377_ = lean_ctor_get(v_fst_1372_, 0);
v_isSharedCheck_1387_ = !lean_is_exclusive(v_fst_1372_);
if (v_isSharedCheck_1387_ == 0)
{
v___x_1379_ = v_fst_1372_;
v_isShared_1380_ = v_isSharedCheck_1387_;
goto v_resetjp_1378_;
}
else
{
lean_inc(v_a_1377_);
lean_dec(v_fst_1372_);
v___x_1379_ = lean_box(0);
v_isShared_1380_ = v_isSharedCheck_1387_;
goto v_resetjp_1378_;
}
v_resetjp_1378_:
{
lean_object* v___x_1382_; 
if (v_isShared_1380_ == 0)
{
v___x_1382_ = v___x_1379_;
goto v_reusejp_1381_;
}
else
{
lean_object* v_reuseFailAlloc_1386_; 
v_reuseFailAlloc_1386_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1386_, 0, v_a_1377_);
v___x_1382_ = v_reuseFailAlloc_1386_;
goto v_reusejp_1381_;
}
v_reusejp_1381_:
{
lean_object* v___x_1384_; 
if (v_isShared_1376_ == 0)
{
lean_ctor_set(v___x_1375_, 0, v___x_1382_);
v___x_1384_ = v___x_1375_;
goto v_reusejp_1383_;
}
else
{
lean_object* v_reuseFailAlloc_1385_; 
v_reuseFailAlloc_1385_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1385_, 0, v___x_1382_);
lean_ctor_set(v_reuseFailAlloc_1385_, 1, v_snd_1373_);
v___x_1384_ = v_reuseFailAlloc_1385_;
goto v_reusejp_1383_;
}
v_reusejp_1383_:
{
return v___x_1384_;
}
}
}
}
}
else
{
lean_object* v_snd_1390_; lean_object* v___x_1392_; uint8_t v_isShared_1393_; uint8_t v_isSharedCheck_1451_; 
v_snd_1390_ = lean_ctor_get(v___x_1371_, 1);
v_isSharedCheck_1451_ = !lean_is_exclusive(v___x_1371_);
if (v_isSharedCheck_1451_ == 0)
{
lean_object* v_unused_1452_; 
v_unused_1452_ = lean_ctor_get(v___x_1371_, 0);
lean_dec(v_unused_1452_);
v___x_1392_ = v___x_1371_;
v_isShared_1393_ = v_isSharedCheck_1451_;
goto v_resetjp_1391_;
}
else
{
lean_inc(v_snd_1390_);
lean_dec(v___x_1371_);
v___x_1392_ = lean_box(0);
v_isShared_1393_ = v_isSharedCheck_1451_;
goto v_resetjp_1391_;
}
v_resetjp_1391_:
{
lean_object* v___x_1395_; uint8_t v_isShared_1396_; uint8_t v_isSharedCheck_1449_; 
v_isSharedCheck_1449_ = !lean_is_exclusive(v_fst_1372_);
if (v_isSharedCheck_1449_ == 0)
{
lean_object* v_unused_1450_; 
v_unused_1450_ = lean_ctor_get(v_fst_1372_, 0);
lean_dec(v_unused_1450_);
v___x_1395_ = v_fst_1372_;
v_isShared_1396_ = v_isSharedCheck_1449_;
goto v_resetjp_1394_;
}
else
{
lean_dec(v_fst_1372_);
v___x_1395_ = lean_box(0);
v_isShared_1396_ = v_isSharedCheck_1449_;
goto v_resetjp_1394_;
}
v_resetjp_1394_:
{
lean_object* v___x_1397_; lean_object* v___x_1398_; uint8_t v___x_1399_; 
v___x_1397_ = lean_unsigned_to_nat(2u);
v___x_1398_ = lean_nat_shiftr(v___x_1370_, v___x_1397_);
v___x_1399_ = lean_nat_dec_eq(v___x_1398_, v___x_1363_);
lean_dec(v___x_1398_);
if (v___x_1399_ == 0)
{
lean_object* v___x_1400_; lean_object* v_fst_1401_; 
lean_del_object(v___x_1395_);
lean_del_object(v___x_1392_);
v___x_1400_ = lp_Hex_Hex_Groebner_Computation_products(v_limits_1353_, v_support_1365_, v_monomial_1355_, v_snd_1390_);
lean_dec_ref(v_support_1365_);
v_fst_1401_ = lean_ctor_get(v___x_1400_, 0);
lean_inc(v_fst_1401_);
if (lean_obj_tag(v_fst_1401_) == 0)
{
lean_object* v_snd_1402_; lean_object* v___x_1404_; uint8_t v_isShared_1405_; uint8_t v_isSharedCheck_1417_; 
lean_del_object(v___x_1368_);
lean_dec_ref(v_coefficients_1366_);
v_snd_1402_ = lean_ctor_get(v___x_1400_, 1);
v_isSharedCheck_1417_ = !lean_is_exclusive(v___x_1400_);
if (v_isSharedCheck_1417_ == 0)
{
lean_object* v_unused_1418_; 
v_unused_1418_ = lean_ctor_get(v___x_1400_, 0);
lean_dec(v_unused_1418_);
v___x_1404_ = v___x_1400_;
v_isShared_1405_ = v_isSharedCheck_1417_;
goto v_resetjp_1403_;
}
else
{
lean_inc(v_snd_1402_);
lean_dec(v___x_1400_);
v___x_1404_ = lean_box(0);
v_isShared_1405_ = v_isSharedCheck_1417_;
goto v_resetjp_1403_;
}
v_resetjp_1403_:
{
lean_object* v_a_1406_; lean_object* v___x_1408_; uint8_t v_isShared_1409_; uint8_t v_isSharedCheck_1416_; 
v_a_1406_ = lean_ctor_get(v_fst_1401_, 0);
v_isSharedCheck_1416_ = !lean_is_exclusive(v_fst_1401_);
if (v_isSharedCheck_1416_ == 0)
{
v___x_1408_ = v_fst_1401_;
v_isShared_1409_ = v_isSharedCheck_1416_;
goto v_resetjp_1407_;
}
else
{
lean_inc(v_a_1406_);
lean_dec(v_fst_1401_);
v___x_1408_ = lean_box(0);
v_isShared_1409_ = v_isSharedCheck_1416_;
goto v_resetjp_1407_;
}
v_resetjp_1407_:
{
lean_object* v___x_1411_; 
if (v_isShared_1409_ == 0)
{
v___x_1411_ = v___x_1408_;
goto v_reusejp_1410_;
}
else
{
lean_object* v_reuseFailAlloc_1415_; 
v_reuseFailAlloc_1415_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1415_, 0, v_a_1406_);
v___x_1411_ = v_reuseFailAlloc_1415_;
goto v_reusejp_1410_;
}
v_reusejp_1410_:
{
lean_object* v___x_1413_; 
if (v_isShared_1405_ == 0)
{
lean_ctor_set(v___x_1404_, 0, v___x_1411_);
v___x_1413_ = v___x_1404_;
goto v_reusejp_1412_;
}
else
{
lean_object* v_reuseFailAlloc_1414_; 
v_reuseFailAlloc_1414_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1414_, 0, v___x_1411_);
lean_ctor_set(v_reuseFailAlloc_1414_, 1, v_snd_1402_);
v___x_1413_ = v_reuseFailAlloc_1414_;
goto v_reusejp_1412_;
}
v_reusejp_1412_:
{
return v___x_1413_;
}
}
}
}
}
else
{
lean_object* v_snd_1419_; lean_object* v___x_1421_; uint8_t v_isShared_1422_; uint8_t v_isSharedCheck_1437_; 
v_snd_1419_ = lean_ctor_get(v___x_1400_, 1);
v_isSharedCheck_1437_ = !lean_is_exclusive(v___x_1400_);
if (v_isSharedCheck_1437_ == 0)
{
lean_object* v_unused_1438_; 
v_unused_1438_ = lean_ctor_get(v___x_1400_, 0);
lean_dec(v_unused_1438_);
v___x_1421_ = v___x_1400_;
v_isShared_1422_ = v_isSharedCheck_1437_;
goto v_resetjp_1420_;
}
else
{
lean_inc(v_snd_1419_);
lean_dec(v___x_1400_);
v___x_1421_ = lean_box(0);
v_isShared_1422_ = v_isSharedCheck_1437_;
goto v_resetjp_1420_;
}
v_resetjp_1420_:
{
lean_object* v_a_1423_; lean_object* v___x_1425_; uint8_t v_isShared_1426_; uint8_t v_isSharedCheck_1436_; 
v_a_1423_ = lean_ctor_get(v_fst_1401_, 0);
v_isSharedCheck_1436_ = !lean_is_exclusive(v_fst_1401_);
if (v_isSharedCheck_1436_ == 0)
{
v___x_1425_ = v_fst_1401_;
v_isShared_1426_ = v_isSharedCheck_1436_;
goto v_resetjp_1424_;
}
else
{
lean_inc(v_a_1423_);
lean_dec(v_fst_1401_);
v___x_1425_ = lean_box(0);
v_isShared_1426_ = v_isSharedCheck_1436_;
goto v_resetjp_1424_;
}
v_resetjp_1424_:
{
lean_object* v___x_1428_; 
if (v_isShared_1369_ == 0)
{
lean_ctor_set(v___x_1368_, 0, v_a_1423_);
v___x_1428_ = v___x_1368_;
goto v_reusejp_1427_;
}
else
{
lean_object* v_reuseFailAlloc_1435_; 
v_reuseFailAlloc_1435_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1435_, 0, v_a_1423_);
lean_ctor_set(v_reuseFailAlloc_1435_, 1, v_coefficients_1366_);
v___x_1428_ = v_reuseFailAlloc_1435_;
goto v_reusejp_1427_;
}
v_reusejp_1427_:
{
lean_object* v___x_1430_; 
if (v_isShared_1426_ == 0)
{
lean_ctor_set(v___x_1425_, 0, v___x_1428_);
v___x_1430_ = v___x_1425_;
goto v_reusejp_1429_;
}
else
{
lean_object* v_reuseFailAlloc_1434_; 
v_reuseFailAlloc_1434_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1434_, 0, v___x_1428_);
v___x_1430_ = v_reuseFailAlloc_1434_;
goto v_reusejp_1429_;
}
v_reusejp_1429_:
{
lean_object* v___x_1432_; 
if (v_isShared_1422_ == 0)
{
lean_ctor_set(v___x_1421_, 0, v___x_1430_);
v___x_1432_ = v___x_1421_;
goto v_reusejp_1431_;
}
else
{
lean_object* v_reuseFailAlloc_1433_; 
v_reuseFailAlloc_1433_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1433_, 0, v___x_1430_);
lean_ctor_set(v_reuseFailAlloc_1433_, 1, v_snd_1419_);
v___x_1432_ = v_reuseFailAlloc_1433_;
goto v_reusejp_1431_;
}
v_reusejp_1431_:
{
return v___x_1432_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_1439_; lean_object* v___x_1441_; 
lean_dec_ref(v_support_1365_);
lean_dec(v_monomial_1355_);
lean_dec_ref(v_limits_1353_);
v___x_1439_ = l_ByteArray_empty;
if (v_isShared_1369_ == 0)
{
lean_ctor_set(v___x_1368_, 0, v___x_1439_);
v___x_1441_ = v___x_1368_;
goto v_reusejp_1440_;
}
else
{
lean_object* v_reuseFailAlloc_1448_; 
v_reuseFailAlloc_1448_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1448_, 0, v___x_1439_);
lean_ctor_set(v_reuseFailAlloc_1448_, 1, v_coefficients_1366_);
v___x_1441_ = v_reuseFailAlloc_1448_;
goto v_reusejp_1440_;
}
v_reusejp_1440_:
{
lean_object* v___x_1443_; 
if (v_isShared_1396_ == 0)
{
lean_ctor_set(v___x_1395_, 0, v___x_1441_);
v___x_1443_ = v___x_1395_;
goto v_reusejp_1442_;
}
else
{
lean_object* v_reuseFailAlloc_1447_; 
v_reuseFailAlloc_1447_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1447_, 0, v___x_1441_);
v___x_1443_ = v_reuseFailAlloc_1447_;
goto v_reusejp_1442_;
}
v_reusejp_1442_:
{
lean_object* v___x_1445_; 
if (v_isShared_1393_ == 0)
{
lean_ctor_set(v___x_1392_, 0, v___x_1443_);
v___x_1445_ = v___x_1392_;
goto v_reusejp_1444_;
}
else
{
lean_object* v_reuseFailAlloc_1446_; 
v_reuseFailAlloc_1446_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1446_, 0, v___x_1443_);
lean_ctor_set(v_reuseFailAlloc_1446_, 1, v_snd_1390_);
v___x_1445_ = v_reuseFailAlloc_1446_;
goto v_reusejp_1444_;
}
v_reusejp_1444_:
{
return v___x_1445_;
}
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_1454_; lean_object* v___x_1455_; 
lean_dec(v_monomial_1355_);
lean_dec_ref(v_limits_1353_);
v___x_1454_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1454_, 0, v_p_1354_);
v___x_1455_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1455_, 0, v___x_1454_);
lean_ctor_set(v___x_1455_, 1, v_a_1356_);
return v___x_1455_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_multiply(lean_object* v___context_1456_, lean_object* v_limits_1457_, lean_object* v_p_1458_, lean_object* v_monomial_1459_, lean_object* v_a_1460_){
_start:
{
lean_object* v___x_1461_; 
v___x_1461_ = lp_Hex_Hex_Groebner_Polynomial_multiply___redArg(v_limits_1457_, v_p_1458_, v_monomial_1459_, v_a_1460_);
return v___x_1461_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_multiply___boxed(lean_object* v___context_1462_, lean_object* v_limits_1463_, lean_object* v_p_1464_, lean_object* v_monomial_1465_, lean_object* v_a_1466_){
_start:
{
lean_object* v_res_1467_; 
v_res_1467_ = lp_Hex_Hex_Groebner_Polynomial_multiply(v___context_1462_, v_limits_1463_, v_p_1464_, v_monomial_1465_, v_a_1466_);
lean_dec_ref(v___context_1462_);
return v_res_1467_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0___redArg(uint64_t v___x_1468_, lean_object* v_q_1469_, lean_object* v_p_1470_, lean_object* v___x_1471_, lean_object* v___x_1472_, lean_object* v_context_1473_, lean_object* v_table_1474_, lean_object* v_range_1475_, lean_object* v_b_1476_, lean_object* v_i_1477_, lean_object* v___y_1478_){
_start:
{
lean_object* v_stop_1479_; lean_object* v_step_1480_; lean_object* v_a_1482_; lean_object* v_snd_1483_; uint8_t v___x_1486_; 
v_stop_1479_ = lean_ctor_get(v_range_1475_, 1);
v_step_1480_ = lean_ctor_get(v_range_1475_, 2);
v___x_1486_ = lean_nat_dec_lt(v_i_1477_, v_stop_1479_);
if (v___x_1486_ == 0)
{
lean_object* v___x_1487_; lean_object* v___x_1488_; 
lean_dec(v_i_1477_);
v___x_1487_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1487_, 0, v_b_1476_);
v___x_1488_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1488_, 0, v___x_1487_);
lean_ctor_set(v___x_1488_, 1, v___y_1478_);
return v___x_1488_;
}
else
{
lean_object* v_snd_1489_; lean_object* v_fst_1490_; lean_object* v___x_1492_; uint8_t v_isShared_1493_; uint8_t v_isSharedCheck_2607_; 
v_snd_1489_ = lean_ctor_get(v_b_1476_, 1);
v_fst_1490_ = lean_ctor_get(v_b_1476_, 0);
v_isSharedCheck_2607_ = !lean_is_exclusive(v_b_1476_);
if (v_isSharedCheck_2607_ == 0)
{
v___x_1492_ = v_b_1476_;
v_isShared_1493_ = v_isSharedCheck_2607_;
goto v_resetjp_1491_;
}
else
{
lean_inc(v_snd_1489_);
lean_inc(v_fst_1490_);
lean_dec(v_b_1476_);
v___x_1492_ = lean_box(0);
v_isShared_1493_ = v_isSharedCheck_2607_;
goto v_resetjp_1491_;
}
v_resetjp_1491_:
{
lean_object* v_fst_1494_; lean_object* v_snd_1495_; lean_object* v___x_1497_; uint8_t v_isShared_1498_; uint8_t v_isSharedCheck_2606_; 
v_fst_1494_ = lean_ctor_get(v_snd_1489_, 0);
v_snd_1495_ = lean_ctor_get(v_snd_1489_, 1);
v_isSharedCheck_2606_ = !lean_is_exclusive(v_snd_1489_);
if (v_isSharedCheck_2606_ == 0)
{
v___x_1497_ = v_snd_1489_;
v_isShared_1498_ = v_isSharedCheck_2606_;
goto v_resetjp_1496_;
}
else
{
lean_inc(v_snd_1495_);
lean_inc(v_fst_1494_);
lean_dec(v_snd_1489_);
v___x_1497_ = lean_box(0);
v_isShared_1498_ = v_isSharedCheck_2606_;
goto v_resetjp_1496_;
}
v_resetjp_1496_:
{
lean_object* v___x_1499_; lean_object* v___y_1501_; uint64_t v___y_1502_; uint64_t v___y_1513_; lean_object* v___y_1514_; uint8_t v___y_1515_; uint64_t v___y_1521_; lean_object* v___y_1522_; uint8_t v___y_1523_; lean_object* v___y_1529_; lean_object* v___y_1530_; uint64_t v___y_1531_; uint8_t v___y_1532_; lean_object* v___y_1533_; uint8_t v___y_1534_; uint64_t v___y_1547_; lean_object* v___y_1548_; lean_object* v___y_1549_; uint8_t v___y_1550_; lean_object* v___y_1551_; uint8_t v___y_1552_; lean_object* v___y_1565_; lean_object* v___y_1566_; uint8_t v___y_1567_; uint8_t v___y_1568_; lean_object* v___y_1569_; uint8_t v___y_1570_; lean_object* v___y_1585_; lean_object* v___y_1586_; uint8_t v___y_1587_; uint8_t v___y_1588_; lean_object* v___y_1589_; uint8_t v___y_1590_; lean_object* v___y_1628_; lean_object* v___y_1629_; uint8_t v___y_1630_; uint8_t v___y_1631_; lean_object* v___y_1632_; lean_object* v___y_1641_; uint64_t v___y_1648_; uint8_t v___y_1649_; uint8_t v___y_1656_; uint64_t v___y_1657_; lean_object* v___y_1658_; lean_object* v___y_1659_; uint8_t v___y_1660_; uint8_t v___y_1673_; uint64_t v___y_1674_; lean_object* v___y_1675_; lean_object* v___y_1676_; uint8_t v___y_1677_; uint8_t v___y_1690_; lean_object* v___y_1691_; lean_object* v___y_1692_; uint8_t v___y_1693_; uint8_t v___y_1702_; lean_object* v___y_1703_; lean_object* v___y_1704_; uint8_t v___y_1705_; lean_object* v___y_1748_; uint64_t v___y_1749_; uint64_t v___y_1755_; lean_object* v___y_1756_; uint8_t v___y_1757_; lean_object* v___y_1763_; uint8_t v___y_1764_; uint64_t v___y_1765_; lean_object* v___y_1766_; lean_object* v___y_1767_; uint8_t v___y_1768_; lean_object* v___y_1781_; uint8_t v___y_1782_; uint64_t v___y_1783_; lean_object* v___y_1784_; lean_object* v___y_1785_; uint8_t v___y_1786_; uint64_t v___y_1799_; lean_object* v___y_1800_; uint8_t v___y_1801_; uint8_t v___y_1807_; lean_object* v___y_1808_; uint8_t v___y_1809_; lean_object* v___y_1810_; lean_object* v___y_1811_; uint8_t v___y_1812_; uint8_t v___y_1827_; lean_object* v___y_1828_; uint8_t v___y_1829_; lean_object* v___y_1830_; lean_object* v___y_1831_; uint8_t v___y_1832_; uint8_t v___y_1870_; uint8_t v___y_1871_; lean_object* v___y_1872_; lean_object* v___y_1873_; lean_object* v___y_1874_; lean_object* v___y_1883_; uint64_t v___y_1890_; uint8_t v___y_1891_; uint8_t v___y_1898_; lean_object* v___y_1899_; uint64_t v___y_1900_; lean_object* v___y_1901_; uint8_t v___y_1902_; lean_object* v___y_1915_; uint8_t v___y_1916_; lean_object* v___y_1917_; uint64_t v___y_1918_; uint8_t v___y_1919_; uint8_t v___y_1932_; lean_object* v___y_1933_; lean_object* v___y_1934_; uint8_t v___y_1935_; uint8_t v___y_1944_; lean_object* v___y_1945_; lean_object* v___y_1946_; uint8_t v___y_1947_; lean_object* v_result_1990_; lean_object* v___y_1991_; uint64_t v___y_1997_; lean_object* v___y_1998_; uint64_t v___y_2001_; uint64_t v___y_2002_; uint8_t v___y_2003_; uint64_t v___y_2010_; lean_object* v___y_2011_; lean_object* v___y_2012_; uint64_t v___y_2013_; uint8_t v___y_2014_; uint8_t v___y_2015_; uint64_t v___y_2028_; lean_object* v___y_2029_; lean_object* v___y_2030_; uint8_t v___y_2031_; uint64_t v___y_2032_; uint8_t v___y_2033_; uint64_t v___y_2046_; lean_object* v___y_2047_; lean_object* v___y_2048_; uint8_t v___y_2049_; uint8_t v___y_2050_; uint64_t v___y_2059_; lean_object* v___y_2060_; lean_object* v___y_2061_; uint8_t v___y_2062_; uint8_t v___y_2063_; uint64_t v___y_2095_; uint64_t v___y_2109_; uint64_t v___y_2110_; uint64_t v___y_2116_; uint64_t v___y_2117_; uint8_t v___y_2118_; lean_object* v___y_2124_; uint64_t v___y_2125_; uint8_t v___y_2126_; lean_object* v___y_2127_; uint64_t v___y_2128_; uint8_t v___y_2129_; uint64_t v___y_2142_; uint64_t v___y_2143_; lean_object* v___y_2144_; uint8_t v___y_2145_; lean_object* v___y_2146_; uint8_t v___y_2147_; uint64_t v___y_2160_; uint64_t v___y_2161_; uint8_t v___y_2162_; lean_object* v___y_2168_; uint64_t v___y_2169_; uint8_t v___y_2170_; uint8_t v___y_2171_; lean_object* v___y_2172_; uint8_t v___y_2173_; uint64_t v___y_2188_; lean_object* v___y_2189_; uint8_t v___y_2190_; uint8_t v___y_2191_; lean_object* v___y_2192_; uint8_t v___y_2193_; uint64_t v___y_2231_; uint8_t v___y_2232_; uint8_t v___y_2233_; lean_object* v___y_2234_; lean_object* v___y_2235_; uint64_t v___y_2244_; uint64_t v___y_2251_; uint8_t v___y_2252_; uint64_t v___y_2258_; uint8_t v___y_2259_; uint8_t v___y_2265_; lean_object* v___y_2266_; uint64_t v___y_2267_; lean_object* v___y_2268_; uint8_t v___y_2269_; uint8_t v___y_2282_; lean_object* v___y_2283_; lean_object* v___y_2284_; uint64_t v___y_2285_; uint8_t v___y_2286_; uint8_t v___y_2299_; lean_object* v___y_2300_; lean_object* v___y_2301_; uint8_t v___y_2302_; uint8_t v___y_2303_; uint8_t v___y_2318_; lean_object* v___y_2319_; lean_object* v___y_2320_; uint8_t v___y_2321_; uint8_t v___y_2322_; uint8_t v___y_2360_; lean_object* v___y_2361_; uint8_t v___y_2362_; lean_object* v___y_2363_; lean_object* v___y_2372_; uint8_t v___y_2373_; lean_object* v___y_2374_; uint64_t v___y_2382_; lean_object* v___y_2383_; uint8_t v___y_2384_; uint8_t v___y_2385_; lean_object* v___y_2392_; lean_object* v___y_2393_; uint8_t v___y_2394_; uint64_t v___y_2395_; lean_object* v___y_2396_; uint8_t v___y_2397_; uint8_t v___y_2398_; lean_object* v___y_2411_; lean_object* v___y_2412_; uint8_t v___y_2413_; uint8_t v___y_2414_; lean_object* v___y_2415_; uint64_t v___y_2416_; uint8_t v___y_2417_; lean_object* v___y_2430_; lean_object* v___y_2431_; uint8_t v___y_2432_; lean_object* v___y_2433_; uint8_t v___y_2434_; uint8_t v___y_2435_; lean_object* v___y_2444_; lean_object* v___y_2445_; uint8_t v___y_2446_; uint8_t v___y_2447_; lean_object* v___y_2448_; uint8_t v___y_2449_; uint8_t v___y_2481_; lean_object* v___y_2482_; uint64_t v___y_2494_; uint8_t v___y_2495_; uint8_t v___y_2496_; lean_object* v___y_2503_; uint64_t v___y_2504_; lean_object* v___y_2505_; uint8_t v___y_2506_; uint8_t v___y_2507_; uint8_t v___y_2508_; lean_object* v___y_2521_; lean_object* v___y_2522_; uint64_t v___y_2523_; uint8_t v___y_2524_; uint8_t v___y_2525_; uint8_t v___y_2526_; lean_object* v___y_2539_; lean_object* v___y_2540_; uint8_t v___y_2541_; uint8_t v___y_2542_; uint8_t v___y_2543_; lean_object* v___y_2552_; lean_object* v___y_2553_; uint8_t v___y_2554_; uint8_t v___y_2555_; uint8_t v___y_2556_; uint8_t v___x_2587_; 
v___x_1499_ = lean_unsigned_to_nat(1u);
v___x_2587_ = lean_nat_dec_le(v___x_1471_, v_fst_1494_);
if (v___x_2587_ == 0)
{
goto v___jp_2588_;
}
else
{
uint8_t v___x_2601_; 
v___x_2601_ = lean_nat_dec_le(v___x_1472_, v_snd_1495_);
if (v___x_2601_ == 0)
{
goto v___jp_2588_;
}
else
{
lean_object* v___x_2602_; lean_object* v___x_2603_; lean_object* v___x_2604_; lean_object* v___x_2605_; 
lean_del_object(v___x_1497_);
lean_del_object(v___x_1492_);
lean_dec(v_i_1477_);
v___x_2602_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2602_, 0, v_fst_1494_);
lean_ctor_set(v___x_2602_, 1, v_snd_1495_);
v___x_2603_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2603_, 0, v_fst_1490_);
lean_ctor_set(v___x_2603_, 1, v___x_2602_);
v___x_2604_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2604_, 0, v___x_2603_);
v___x_2605_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2605_, 0, v___x_2604_);
lean_ctor_set(v___x_2605_, 1, v___y_1478_);
return v___x_2605_;
}
}
v___jp_1500_:
{
uint64_t v___x_1503_; lean_object* v___x_1504_; lean_object* v___x_1505_; lean_object* v___x_1507_; 
v___x_1503_ = lean_uint64_sub(v___x_1468_, v___y_1502_);
v___x_1504_ = lp_Hex___private_HexGroebner_Polynomial_0__Hex_Groebner_Polynomial_append(v___x_1468_, v_fst_1490_, v___y_1501_, v___x_1503_);
lean_dec(v___y_1501_);
v___x_1505_ = lean_nat_add(v_snd_1495_, v___x_1499_);
lean_dec(v_snd_1495_);
if (v_isShared_1498_ == 0)
{
lean_ctor_set(v___x_1497_, 1, v___x_1505_);
v___x_1507_ = v___x_1497_;
goto v_reusejp_1506_;
}
else
{
lean_object* v_reuseFailAlloc_1511_; 
v_reuseFailAlloc_1511_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1511_, 0, v_fst_1494_);
lean_ctor_set(v_reuseFailAlloc_1511_, 1, v___x_1505_);
v___x_1507_ = v_reuseFailAlloc_1511_;
goto v_reusejp_1506_;
}
v_reusejp_1506_:
{
lean_object* v___x_1509_; 
if (v_isShared_1493_ == 0)
{
lean_ctor_set(v___x_1492_, 1, v___x_1507_);
lean_ctor_set(v___x_1492_, 0, v___x_1504_);
v___x_1509_ = v___x_1492_;
goto v_reusejp_1508_;
}
else
{
lean_object* v_reuseFailAlloc_1510_; 
v_reuseFailAlloc_1510_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1510_, 0, v___x_1504_);
lean_ctor_set(v_reuseFailAlloc_1510_, 1, v___x_1507_);
v___x_1509_ = v_reuseFailAlloc_1510_;
goto v_reusejp_1508_;
}
v_reusejp_1508_:
{
v_a_1482_ = v___x_1509_;
v_snd_1483_ = v___y_1478_;
goto v___jp_1481_;
}
}
}
v___jp_1512_:
{
uint64_t v___x_1516_; uint64_t v___x_1517_; uint64_t v___x_1518_; uint64_t v___x_1519_; 
v___x_1516_ = lean_uint8_to_uint64(v___y_1515_);
v___x_1517_ = 8ULL;
v___x_1518_ = lean_uint64_shift_left(v___x_1516_, v___x_1517_);
v___x_1519_ = lean_uint64_lor(v___y_1513_, v___x_1518_);
v___y_1501_ = v___y_1514_;
v___y_1502_ = v___x_1519_;
goto v___jp_1500_;
}
v___jp_1520_:
{
uint64_t v___x_1524_; uint64_t v___x_1525_; uint64_t v___x_1526_; uint64_t v___x_1527_; 
v___x_1524_ = lean_uint8_to_uint64(v___y_1523_);
v___x_1525_ = 24ULL;
v___x_1526_ = lean_uint64_shift_left(v___x_1524_, v___x_1525_);
v___x_1527_ = lean_uint64_lor(v___y_1521_, v___x_1526_);
v___y_1501_ = v___y_1522_;
v___y_1502_ = v___x_1527_;
goto v___jp_1500_;
}
v___jp_1528_:
{
uint64_t v___x_1535_; uint64_t v___x_1536_; uint64_t v___x_1537_; uint64_t v___x_1538_; lean_object* v___x_1539_; lean_object* v___x_1540_; uint8_t v___x_1541_; 
v___x_1535_ = lean_uint8_to_uint64(v___y_1534_);
v___x_1536_ = 16ULL;
v___x_1537_ = lean_uint64_shift_left(v___x_1535_, v___x_1536_);
v___x_1538_ = lean_uint64_lor(v___y_1531_, v___x_1537_);
v___x_1539_ = lean_unsigned_to_nat(3u);
v___x_1540_ = lean_nat_add(v___y_1533_, v___x_1539_);
lean_dec(v___y_1533_);
v___x_1541_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1529_, v___x_1540_);
if (v___x_1541_ == 0)
{
lean_object* v___x_1542_; lean_object* v___x_1543_; uint8_t v___x_1544_; 
lean_dec(v___x_1540_);
v___x_1542_ = lean_box(v___y_1532_);
v___x_1543_ = l_outOfBounds___redArg(v___x_1542_);
lean_dec(v___x_1542_);
v___x_1544_ = lean_unbox(v___x_1543_);
lean_dec(v___x_1543_);
v___y_1521_ = v___x_1538_;
v___y_1522_ = v___y_1530_;
v___y_1523_ = v___x_1544_;
goto v___jp_1520_;
}
else
{
uint8_t v___x_1545_; 
v___x_1545_ = lean_byte_array_fget(v___y_1529_, v___x_1540_);
lean_dec(v___x_1540_);
v___y_1521_ = v___x_1538_;
v___y_1522_ = v___y_1530_;
v___y_1523_ = v___x_1545_;
goto v___jp_1520_;
}
}
v___jp_1546_:
{
uint64_t v___x_1553_; uint64_t v___x_1554_; uint64_t v___x_1555_; uint64_t v___x_1556_; lean_object* v___x_1557_; lean_object* v___x_1558_; uint8_t v___x_1559_; 
v___x_1553_ = lean_uint8_to_uint64(v___y_1552_);
v___x_1554_ = 8ULL;
v___x_1555_ = lean_uint64_shift_left(v___x_1553_, v___x_1554_);
v___x_1556_ = lean_uint64_lor(v___y_1547_, v___x_1555_);
v___x_1557_ = lean_unsigned_to_nat(2u);
v___x_1558_ = lean_nat_add(v___y_1551_, v___x_1557_);
v___x_1559_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1548_, v___x_1558_);
if (v___x_1559_ == 0)
{
lean_object* v___x_1560_; lean_object* v___x_1561_; uint8_t v___x_1562_; 
lean_dec(v___x_1558_);
v___x_1560_ = lean_box(v___y_1550_);
v___x_1561_ = l_outOfBounds___redArg(v___x_1560_);
lean_dec(v___x_1560_);
v___x_1562_ = lean_unbox(v___x_1561_);
lean_dec(v___x_1561_);
v___y_1529_ = v___y_1548_;
v___y_1530_ = v___y_1549_;
v___y_1531_ = v___x_1556_;
v___y_1532_ = v___y_1550_;
v___y_1533_ = v___y_1551_;
v___y_1534_ = v___x_1562_;
goto v___jp_1528_;
}
else
{
uint8_t v___x_1563_; 
v___x_1563_ = lean_byte_array_fget(v___y_1548_, v___x_1558_);
lean_dec(v___x_1558_);
v___y_1529_ = v___y_1548_;
v___y_1530_ = v___y_1549_;
v___y_1531_ = v___x_1556_;
v___y_1532_ = v___y_1550_;
v___y_1533_ = v___y_1551_;
v___y_1534_ = v___x_1563_;
goto v___jp_1528_;
}
}
v___jp_1564_:
{
uint64_t v_a_1571_; 
v_a_1571_ = lean_uint8_to_uint64(v___y_1570_);
switch(v___y_1568_)
{
case 0:
{
lean_dec(v___y_1569_);
v___y_1501_ = v___y_1566_;
v___y_1502_ = v_a_1571_;
goto v___jp_1500_;
}
case 1:
{
lean_object* v___x_1572_; uint8_t v___x_1573_; 
v___x_1572_ = lean_nat_add(v___y_1569_, v___x_1499_);
lean_dec(v___y_1569_);
v___x_1573_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1565_, v___x_1572_);
if (v___x_1573_ == 0)
{
lean_object* v___x_1574_; lean_object* v___x_1575_; uint8_t v___x_1576_; 
lean_dec(v___x_1572_);
v___x_1574_ = lean_box(v___y_1567_);
v___x_1575_ = l_outOfBounds___redArg(v___x_1574_);
lean_dec(v___x_1574_);
v___x_1576_ = lean_unbox(v___x_1575_);
lean_dec(v___x_1575_);
v___y_1513_ = v_a_1571_;
v___y_1514_ = v___y_1566_;
v___y_1515_ = v___x_1576_;
goto v___jp_1512_;
}
else
{
uint8_t v___x_1577_; 
v___x_1577_ = lean_byte_array_fget(v___y_1565_, v___x_1572_);
lean_dec(v___x_1572_);
v___y_1513_ = v_a_1571_;
v___y_1514_ = v___y_1566_;
v___y_1515_ = v___x_1577_;
goto v___jp_1512_;
}
}
default: 
{
lean_object* v___x_1578_; uint8_t v___x_1579_; 
v___x_1578_ = lean_nat_add(v___y_1569_, v___x_1499_);
v___x_1579_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1565_, v___x_1578_);
if (v___x_1579_ == 0)
{
lean_object* v___x_1580_; lean_object* v___x_1581_; uint8_t v___x_1582_; 
lean_dec(v___x_1578_);
v___x_1580_ = lean_box(v___y_1567_);
v___x_1581_ = l_outOfBounds___redArg(v___x_1580_);
lean_dec(v___x_1580_);
v___x_1582_ = lean_unbox(v___x_1581_);
lean_dec(v___x_1581_);
v___y_1547_ = v_a_1571_;
v___y_1548_ = v___y_1565_;
v___y_1549_ = v___y_1566_;
v___y_1550_ = v___y_1567_;
v___y_1551_ = v___y_1569_;
v___y_1552_ = v___x_1582_;
goto v___jp_1546_;
}
else
{
uint8_t v___x_1583_; 
v___x_1583_ = lean_byte_array_fget(v___y_1565_, v___x_1578_);
lean_dec(v___x_1578_);
v___y_1547_ = v_a_1571_;
v___y_1548_ = v___y_1565_;
v___y_1549_ = v___y_1566_;
v___y_1550_ = v___y_1567_;
v___y_1551_ = v___y_1569_;
v___y_1552_ = v___x_1583_;
goto v___jp_1546_;
}
}
}
}
v___jp_1584_:
{
if (v___y_1590_ == 0)
{
uint8_t v___x_1591_; 
v___x_1591_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1585_, v___y_1589_);
if (v___x_1591_ == 0)
{
lean_object* v___x_1592_; lean_object* v___x_1593_; uint8_t v___x_1594_; 
v___x_1592_ = lean_box(v___y_1587_);
v___x_1593_ = l_outOfBounds___redArg(v___x_1592_);
lean_dec(v___x_1592_);
v___x_1594_ = lean_unbox(v___x_1593_);
lean_dec(v___x_1593_);
v___y_1565_ = v___y_1585_;
v___y_1566_ = v___y_1586_;
v___y_1567_ = v___y_1587_;
v___y_1568_ = v___y_1588_;
v___y_1569_ = v___y_1589_;
v___y_1570_ = v___x_1594_;
goto v___jp_1564_;
}
else
{
uint8_t v___x_1595_; 
v___x_1595_ = lean_byte_array_fget(v___y_1585_, v___y_1589_);
v___y_1565_ = v___y_1585_;
v___y_1566_ = v___y_1586_;
v___y_1567_ = v___y_1587_;
v___y_1568_ = v___y_1588_;
v___y_1569_ = v___y_1589_;
v___y_1570_ = v___x_1595_;
goto v___jp_1564_;
}
}
else
{
size_t v_pos_1596_; uint8_t v___x_1597_; uint64_t v_a_1598_; 
v_pos_1596_ = lean_usize_of_nat(v___y_1589_);
lean_dec(v___y_1589_);
v___x_1597_ = lean_byte_array_uget(v___y_1585_, v_pos_1596_);
v_a_1598_ = lean_uint8_to_uint64(v___x_1597_);
switch(v___y_1588_)
{
case 0:
{
v___y_1501_ = v___y_1586_;
v___y_1502_ = v_a_1598_;
goto v___jp_1500_;
}
case 1:
{
size_t v___x_1599_; size_t v___x_1600_; uint8_t v___x_1601_; uint64_t v___x_1602_; uint64_t v___x_1603_; uint64_t v___x_1604_; uint64_t v___x_1605_; 
v___x_1599_ = ((size_t)1ULL);
v___x_1600_ = lean_usize_add(v_pos_1596_, v___x_1599_);
v___x_1601_ = lean_byte_array_uget(v___y_1585_, v___x_1600_);
v___x_1602_ = lean_uint8_to_uint64(v___x_1601_);
v___x_1603_ = 8ULL;
v___x_1604_ = lean_uint64_shift_left(v___x_1602_, v___x_1603_);
v___x_1605_ = lean_uint64_lor(v_a_1598_, v___x_1604_);
v___y_1501_ = v___y_1586_;
v___y_1502_ = v___x_1605_;
goto v___jp_1500_;
}
default: 
{
size_t v___x_1606_; size_t v___x_1607_; uint8_t v___x_1608_; uint64_t v___x_1609_; uint64_t v___x_1610_; uint64_t v___x_1611_; uint64_t v___x_1612_; size_t v___x_1613_; size_t v___x_1614_; uint8_t v___x_1615_; uint64_t v___x_1616_; uint64_t v___x_1617_; uint64_t v___x_1618_; uint64_t v___x_1619_; size_t v___x_1620_; size_t v___x_1621_; uint8_t v___x_1622_; uint64_t v___x_1623_; uint64_t v___x_1624_; uint64_t v___x_1625_; uint64_t v___x_1626_; 
v___x_1606_ = ((size_t)1ULL);
v___x_1607_ = lean_usize_add(v_pos_1596_, v___x_1606_);
v___x_1608_ = lean_byte_array_uget(v___y_1585_, v___x_1607_);
v___x_1609_ = lean_uint8_to_uint64(v___x_1608_);
v___x_1610_ = 8ULL;
v___x_1611_ = lean_uint64_shift_left(v___x_1609_, v___x_1610_);
v___x_1612_ = lean_uint64_lor(v_a_1598_, v___x_1611_);
v___x_1613_ = ((size_t)2ULL);
v___x_1614_ = lean_usize_add(v_pos_1596_, v___x_1613_);
v___x_1615_ = lean_byte_array_uget(v___y_1585_, v___x_1614_);
v___x_1616_ = lean_uint8_to_uint64(v___x_1615_);
v___x_1617_ = 16ULL;
v___x_1618_ = lean_uint64_shift_left(v___x_1616_, v___x_1617_);
v___x_1619_ = lean_uint64_lor(v___x_1612_, v___x_1618_);
v___x_1620_ = ((size_t)3ULL);
v___x_1621_ = lean_usize_add(v_pos_1596_, v___x_1620_);
v___x_1622_ = lean_byte_array_uget(v___y_1585_, v___x_1621_);
v___x_1623_ = lean_uint8_to_uint64(v___x_1622_);
v___x_1624_ = 24ULL;
v___x_1625_ = lean_uint64_shift_left(v___x_1623_, v___x_1624_);
v___x_1626_ = lean_uint64_lor(v___x_1619_, v___x_1625_);
v___y_1501_ = v___y_1586_;
v___y_1502_ = v___x_1626_;
goto v___jp_1500_;
}
}
}
}
v___jp_1627_:
{
lean_object* v_offset_1633_; lean_object* v___x_1634_; lean_object* v___x_1635_; uint8_t v___x_1636_; 
v_offset_1633_ = lean_nat_mul(v_snd_1495_, v___y_1632_);
v___x_1634_ = lean_nat_add(v_offset_1633_, v___y_1632_);
v___x_1635_ = lean_byte_array_size(v___y_1628_);
v___x_1636_ = lean_nat_dec_le(v___x_1634_, v___x_1635_);
if (v___x_1636_ == 0)
{
lean_dec(v___x_1634_);
v___y_1585_ = v___y_1628_;
v___y_1586_ = v___y_1629_;
v___y_1587_ = v___y_1630_;
v___y_1588_ = v___y_1631_;
v___y_1589_ = v_offset_1633_;
v___y_1590_ = v___x_1636_;
goto v___jp_1584_;
}
else
{
size_t v___x_1637_; lean_object* v___x_1638_; uint8_t v___x_1639_; 
v___x_1637_ = lean_usize_of_nat(v___x_1634_);
v___x_1638_ = lean_usize_to_nat(v___x_1637_);
v___x_1639_ = lean_nat_dec_eq(v___x_1638_, v___x_1634_);
lean_dec(v___x_1634_);
lean_dec(v___x_1638_);
v___y_1585_ = v___y_1628_;
v___y_1586_ = v___y_1629_;
v___y_1587_ = v___y_1630_;
v___y_1588_ = v___y_1631_;
v___y_1589_ = v_offset_1633_;
v___y_1590_ = v___x_1639_;
goto v___jp_1584_;
}
}
v___jp_1640_:
{
lean_object* v_coefficients_1642_; uint8_t v___x_1643_; uint8_t v___x_1644_; 
v_coefficients_1642_ = lean_ctor_get(v_q_1469_, 1);
v___x_1643_ = lp_Hex_Hex_Groebner_PrimeField_width(v___x_1468_);
v___x_1644_ = 0;
switch(v___x_1643_)
{
case 0:
{
v___y_1628_ = v_coefficients_1642_;
v___y_1629_ = v___y_1641_;
v___y_1630_ = v___x_1644_;
v___y_1631_ = v___x_1643_;
v___y_1632_ = v___x_1499_;
goto v___jp_1627_;
}
case 1:
{
lean_object* v___x_1645_; 
v___x_1645_ = lean_unsigned_to_nat(2u);
v___y_1628_ = v_coefficients_1642_;
v___y_1629_ = v___y_1641_;
v___y_1630_ = v___x_1644_;
v___y_1631_ = v___x_1643_;
v___y_1632_ = v___x_1645_;
goto v___jp_1627_;
}
default: 
{
lean_object* v___x_1646_; 
v___x_1646_ = lean_unsigned_to_nat(4u);
v___y_1628_ = v_coefficients_1642_;
v___y_1629_ = v___y_1641_;
v___y_1630_ = v___x_1644_;
v___y_1631_ = v___x_1643_;
v___y_1632_ = v___x_1646_;
goto v___jp_1627_;
}
}
}
v___jp_1647_:
{
uint64_t v___x_1650_; uint64_t v___x_1651_; uint64_t v___x_1652_; uint64_t v___x_1653_; lean_object* v___x_1654_; 
v___x_1650_ = lean_uint8_to_uint64(v___y_1649_);
v___x_1651_ = 24ULL;
v___x_1652_ = lean_uint64_shift_left(v___x_1650_, v___x_1651_);
v___x_1653_ = lean_uint64_lor(v___y_1648_, v___x_1652_);
v___x_1654_ = lean_uint64_to_nat(v___x_1653_);
v___y_1641_ = v___x_1654_;
goto v___jp_1640_;
}
v___jp_1655_:
{
uint64_t v___x_1661_; uint64_t v___x_1662_; uint64_t v___x_1663_; uint64_t v___x_1664_; lean_object* v___x_1665_; lean_object* v___x_1666_; uint8_t v___x_1667_; 
v___x_1661_ = lean_uint8_to_uint64(v___y_1660_);
v___x_1662_ = 16ULL;
v___x_1663_ = lean_uint64_shift_left(v___x_1661_, v___x_1662_);
v___x_1664_ = lean_uint64_lor(v___y_1657_, v___x_1663_);
v___x_1665_ = lean_unsigned_to_nat(3u);
v___x_1666_ = lean_nat_add(v___y_1659_, v___x_1665_);
lean_dec(v___y_1659_);
v___x_1667_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1658_, v___x_1666_);
if (v___x_1667_ == 0)
{
lean_object* v___x_1668_; lean_object* v___x_1669_; uint8_t v___x_1670_; 
lean_dec(v___x_1666_);
v___x_1668_ = lean_box(v___y_1656_);
v___x_1669_ = l_outOfBounds___redArg(v___x_1668_);
lean_dec(v___x_1668_);
v___x_1670_ = lean_unbox(v___x_1669_);
lean_dec(v___x_1669_);
v___y_1648_ = v___x_1664_;
v___y_1649_ = v___x_1670_;
goto v___jp_1647_;
}
else
{
uint8_t v___x_1671_; 
v___x_1671_ = lean_byte_array_fget(v___y_1658_, v___x_1666_);
lean_dec(v___x_1666_);
v___y_1648_ = v___x_1664_;
v___y_1649_ = v___x_1671_;
goto v___jp_1647_;
}
}
v___jp_1672_:
{
uint64_t v___x_1678_; uint64_t v___x_1679_; uint64_t v___x_1680_; uint64_t v___x_1681_; lean_object* v___x_1682_; lean_object* v___x_1683_; uint8_t v___x_1684_; 
v___x_1678_ = lean_uint8_to_uint64(v___y_1677_);
v___x_1679_ = 8ULL;
v___x_1680_ = lean_uint64_shift_left(v___x_1678_, v___x_1679_);
v___x_1681_ = lean_uint64_lor(v___y_1674_, v___x_1680_);
v___x_1682_ = lean_unsigned_to_nat(2u);
v___x_1683_ = lean_nat_add(v___y_1675_, v___x_1682_);
v___x_1684_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1676_, v___x_1683_);
if (v___x_1684_ == 0)
{
lean_object* v___x_1685_; lean_object* v___x_1686_; uint8_t v___x_1687_; 
lean_dec(v___x_1683_);
v___x_1685_ = lean_box(v___y_1673_);
v___x_1686_ = l_outOfBounds___redArg(v___x_1685_);
lean_dec(v___x_1685_);
v___x_1687_ = lean_unbox(v___x_1686_);
lean_dec(v___x_1686_);
v___y_1656_ = v___y_1673_;
v___y_1657_ = v___x_1681_;
v___y_1658_ = v___y_1676_;
v___y_1659_ = v___y_1675_;
v___y_1660_ = v___x_1687_;
goto v___jp_1655_;
}
else
{
uint8_t v___x_1688_; 
v___x_1688_ = lean_byte_array_fget(v___y_1676_, v___x_1683_);
lean_dec(v___x_1683_);
v___y_1656_ = v___y_1673_;
v___y_1657_ = v___x_1681_;
v___y_1658_ = v___y_1676_;
v___y_1659_ = v___y_1675_;
v___y_1660_ = v___x_1688_;
goto v___jp_1655_;
}
}
v___jp_1689_:
{
uint64_t v_a_1694_; lean_object* v___x_1695_; uint8_t v___x_1696_; 
v_a_1694_ = lean_uint8_to_uint64(v___y_1693_);
v___x_1695_ = lean_nat_add(v___y_1692_, v___x_1499_);
v___x_1696_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1691_, v___x_1695_);
if (v___x_1696_ == 0)
{
lean_object* v___x_1697_; lean_object* v___x_1698_; uint8_t v___x_1699_; 
lean_dec(v___x_1695_);
v___x_1697_ = lean_box(v___y_1690_);
v___x_1698_ = l_outOfBounds___redArg(v___x_1697_);
lean_dec(v___x_1697_);
v___x_1699_ = lean_unbox(v___x_1698_);
lean_dec(v___x_1698_);
v___y_1673_ = v___y_1690_;
v___y_1674_ = v_a_1694_;
v___y_1675_ = v___y_1692_;
v___y_1676_ = v___y_1691_;
v___y_1677_ = v___x_1699_;
goto v___jp_1672_;
}
else
{
uint8_t v___x_1700_; 
v___x_1700_ = lean_byte_array_fget(v___y_1691_, v___x_1695_);
lean_dec(v___x_1695_);
v___y_1673_ = v___y_1690_;
v___y_1674_ = v_a_1694_;
v___y_1675_ = v___y_1692_;
v___y_1676_ = v___y_1691_;
v___y_1677_ = v___x_1700_;
goto v___jp_1672_;
}
}
v___jp_1701_:
{
if (v___y_1705_ == 0)
{
uint8_t v___x_1706_; 
v___x_1706_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1704_, v___y_1703_);
if (v___x_1706_ == 0)
{
lean_object* v___x_1707_; lean_object* v___x_1708_; uint8_t v___x_1709_; 
v___x_1707_ = lean_box(v___y_1702_);
v___x_1708_ = l_outOfBounds___redArg(v___x_1707_);
lean_dec(v___x_1707_);
v___x_1709_ = lean_unbox(v___x_1708_);
lean_dec(v___x_1708_);
v___y_1690_ = v___y_1702_;
v___y_1691_ = v___y_1704_;
v___y_1692_ = v___y_1703_;
v___y_1693_ = v___x_1709_;
goto v___jp_1689_;
}
else
{
uint8_t v___x_1710_; 
v___x_1710_ = lean_byte_array_fget(v___y_1704_, v___y_1703_);
v___y_1690_ = v___y_1702_;
v___y_1691_ = v___y_1704_;
v___y_1692_ = v___y_1703_;
v___y_1693_ = v___x_1710_;
goto v___jp_1689_;
}
}
else
{
size_t v_pos_1711_; uint8_t v___x_1712_; uint64_t v_a_1713_; size_t v___x_1714_; size_t v___x_1715_; uint8_t v___x_1716_; uint64_t v___x_1717_; uint64_t v___x_1718_; uint64_t v___x_1719_; uint64_t v___x_1720_; size_t v___x_1721_; size_t v___x_1722_; uint8_t v___x_1723_; uint64_t v___x_1724_; uint64_t v___x_1725_; uint64_t v___x_1726_; uint64_t v___x_1727_; size_t v___x_1728_; size_t v___x_1729_; uint8_t v___x_1730_; uint64_t v___x_1731_; uint64_t v___x_1732_; uint64_t v___x_1733_; uint64_t v___x_1734_; lean_object* v___x_1735_; 
v_pos_1711_ = lean_usize_of_nat(v___y_1703_);
lean_dec(v___y_1703_);
v___x_1712_ = lean_byte_array_uget(v___y_1704_, v_pos_1711_);
v_a_1713_ = lean_uint8_to_uint64(v___x_1712_);
v___x_1714_ = ((size_t)1ULL);
v___x_1715_ = lean_usize_add(v_pos_1711_, v___x_1714_);
v___x_1716_ = lean_byte_array_uget(v___y_1704_, v___x_1715_);
v___x_1717_ = lean_uint8_to_uint64(v___x_1716_);
v___x_1718_ = 8ULL;
v___x_1719_ = lean_uint64_shift_left(v___x_1717_, v___x_1718_);
v___x_1720_ = lean_uint64_lor(v_a_1713_, v___x_1719_);
v___x_1721_ = ((size_t)2ULL);
v___x_1722_ = lean_usize_add(v_pos_1711_, v___x_1721_);
v___x_1723_ = lean_byte_array_uget(v___y_1704_, v___x_1722_);
v___x_1724_ = lean_uint8_to_uint64(v___x_1723_);
v___x_1725_ = 16ULL;
v___x_1726_ = lean_uint64_shift_left(v___x_1724_, v___x_1725_);
v___x_1727_ = lean_uint64_lor(v___x_1720_, v___x_1726_);
v___x_1728_ = ((size_t)3ULL);
v___x_1729_ = lean_usize_add(v_pos_1711_, v___x_1728_);
v___x_1730_ = lean_byte_array_uget(v___y_1704_, v___x_1729_);
v___x_1731_ = lean_uint8_to_uint64(v___x_1730_);
v___x_1732_ = 24ULL;
v___x_1733_ = lean_uint64_shift_left(v___x_1731_, v___x_1732_);
v___x_1734_ = lean_uint64_lor(v___x_1727_, v___x_1733_);
v___x_1735_ = lean_uint64_to_nat(v___x_1734_);
v___y_1641_ = v___x_1735_;
goto v___jp_1640_;
}
}
v___jp_1736_:
{
lean_object* v_support_1737_; uint8_t v___x_1738_; lean_object* v___x_1739_; lean_object* v_offset_1740_; lean_object* v___x_1741_; lean_object* v___x_1742_; uint8_t v___x_1743_; 
v_support_1737_ = lean_ctor_get(v_q_1469_, 0);
v___x_1738_ = 0;
v___x_1739_ = lean_unsigned_to_nat(4u);
v_offset_1740_ = lean_nat_mul(v_snd_1495_, v___x_1739_);
v___x_1741_ = lean_nat_add(v_offset_1740_, v___x_1739_);
v___x_1742_ = lean_byte_array_size(v_support_1737_);
v___x_1743_ = lean_nat_dec_le(v___x_1741_, v___x_1742_);
if (v___x_1743_ == 0)
{
lean_dec(v___x_1741_);
v___y_1702_ = v___x_1738_;
v___y_1703_ = v_offset_1740_;
v___y_1704_ = v_support_1737_;
v___y_1705_ = v___x_1743_;
goto v___jp_1701_;
}
else
{
size_t v___x_1744_; lean_object* v___x_1745_; uint8_t v___x_1746_; 
v___x_1744_ = lean_usize_of_nat(v___x_1741_);
v___x_1745_ = lean_usize_to_nat(v___x_1744_);
v___x_1746_ = lean_nat_dec_eq(v___x_1745_, v___x_1741_);
lean_dec(v___x_1741_);
lean_dec(v___x_1745_);
v___y_1702_ = v___x_1738_;
v___y_1703_ = v_offset_1740_;
v___y_1704_ = v_support_1737_;
v___y_1705_ = v___x_1746_;
goto v___jp_1701_;
}
}
v___jp_1747_:
{
lean_object* v___x_1750_; lean_object* v___x_1751_; lean_object* v___x_1752_; lean_object* v___x_1753_; 
v___x_1750_ = lp_Hex___private_HexGroebner_Polynomial_0__Hex_Groebner_Polynomial_append(v___x_1468_, v_fst_1490_, v___y_1748_, v___y_1749_);
lean_dec(v___y_1748_);
v___x_1751_ = lean_nat_add(v_fst_1494_, v___x_1499_);
lean_dec(v_fst_1494_);
v___x_1752_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1752_, 0, v___x_1751_);
lean_ctor_set(v___x_1752_, 1, v_snd_1495_);
v___x_1753_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1753_, 0, v___x_1750_);
lean_ctor_set(v___x_1753_, 1, v___x_1752_);
v_a_1482_ = v___x_1753_;
v_snd_1483_ = v___y_1478_;
goto v___jp_1481_;
}
v___jp_1754_:
{
uint64_t v___x_1758_; uint64_t v___x_1759_; uint64_t v___x_1760_; uint64_t v___x_1761_; 
v___x_1758_ = lean_uint8_to_uint64(v___y_1757_);
v___x_1759_ = 24ULL;
v___x_1760_ = lean_uint64_shift_left(v___x_1758_, v___x_1759_);
v___x_1761_ = lean_uint64_lor(v___y_1755_, v___x_1760_);
v___y_1748_ = v___y_1756_;
v___y_1749_ = v___x_1761_;
goto v___jp_1747_;
}
v___jp_1762_:
{
uint64_t v___x_1769_; uint64_t v___x_1770_; uint64_t v___x_1771_; uint64_t v___x_1772_; lean_object* v___x_1773_; lean_object* v___x_1774_; uint8_t v___x_1775_; 
v___x_1769_ = lean_uint8_to_uint64(v___y_1768_);
v___x_1770_ = 16ULL;
v___x_1771_ = lean_uint64_shift_left(v___x_1769_, v___x_1770_);
v___x_1772_ = lean_uint64_lor(v___y_1765_, v___x_1771_);
v___x_1773_ = lean_unsigned_to_nat(3u);
v___x_1774_ = lean_nat_add(v___y_1763_, v___x_1773_);
lean_dec(v___y_1763_);
v___x_1775_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1767_, v___x_1774_);
if (v___x_1775_ == 0)
{
lean_object* v___x_1776_; lean_object* v___x_1777_; uint8_t v___x_1778_; 
lean_dec(v___x_1774_);
v___x_1776_ = lean_box(v___y_1764_);
v___x_1777_ = l_outOfBounds___redArg(v___x_1776_);
lean_dec(v___x_1776_);
v___x_1778_ = lean_unbox(v___x_1777_);
lean_dec(v___x_1777_);
v___y_1755_ = v___x_1772_;
v___y_1756_ = v___y_1766_;
v___y_1757_ = v___x_1778_;
goto v___jp_1754_;
}
else
{
uint8_t v___x_1779_; 
v___x_1779_ = lean_byte_array_fget(v___y_1767_, v___x_1774_);
lean_dec(v___x_1774_);
v___y_1755_ = v___x_1772_;
v___y_1756_ = v___y_1766_;
v___y_1757_ = v___x_1779_;
goto v___jp_1754_;
}
}
v___jp_1780_:
{
uint64_t v___x_1787_; uint64_t v___x_1788_; uint64_t v___x_1789_; uint64_t v___x_1790_; lean_object* v___x_1791_; lean_object* v___x_1792_; uint8_t v___x_1793_; 
v___x_1787_ = lean_uint8_to_uint64(v___y_1786_);
v___x_1788_ = 8ULL;
v___x_1789_ = lean_uint64_shift_left(v___x_1787_, v___x_1788_);
v___x_1790_ = lean_uint64_lor(v___y_1783_, v___x_1789_);
v___x_1791_ = lean_unsigned_to_nat(2u);
v___x_1792_ = lean_nat_add(v___y_1781_, v___x_1791_);
v___x_1793_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1785_, v___x_1792_);
if (v___x_1793_ == 0)
{
lean_object* v___x_1794_; lean_object* v___x_1795_; uint8_t v___x_1796_; 
lean_dec(v___x_1792_);
v___x_1794_ = lean_box(v___y_1782_);
v___x_1795_ = l_outOfBounds___redArg(v___x_1794_);
lean_dec(v___x_1794_);
v___x_1796_ = lean_unbox(v___x_1795_);
lean_dec(v___x_1795_);
v___y_1763_ = v___y_1781_;
v___y_1764_ = v___y_1782_;
v___y_1765_ = v___x_1790_;
v___y_1766_ = v___y_1784_;
v___y_1767_ = v___y_1785_;
v___y_1768_ = v___x_1796_;
goto v___jp_1762_;
}
else
{
uint8_t v___x_1797_; 
v___x_1797_ = lean_byte_array_fget(v___y_1785_, v___x_1792_);
lean_dec(v___x_1792_);
v___y_1763_ = v___y_1781_;
v___y_1764_ = v___y_1782_;
v___y_1765_ = v___x_1790_;
v___y_1766_ = v___y_1784_;
v___y_1767_ = v___y_1785_;
v___y_1768_ = v___x_1797_;
goto v___jp_1762_;
}
}
v___jp_1798_:
{
uint64_t v___x_1802_; uint64_t v___x_1803_; uint64_t v___x_1804_; uint64_t v___x_1805_; 
v___x_1802_ = lean_uint8_to_uint64(v___y_1801_);
v___x_1803_ = 8ULL;
v___x_1804_ = lean_uint64_shift_left(v___x_1802_, v___x_1803_);
v___x_1805_ = lean_uint64_lor(v___y_1799_, v___x_1804_);
v___y_1748_ = v___y_1800_;
v___y_1749_ = v___x_1805_;
goto v___jp_1747_;
}
v___jp_1806_:
{
uint64_t v_a_1813_; 
v_a_1813_ = lean_uint8_to_uint64(v___y_1812_);
switch(v___y_1807_)
{
case 0:
{
lean_dec(v___y_1808_);
v___y_1748_ = v___y_1810_;
v___y_1749_ = v_a_1813_;
goto v___jp_1747_;
}
case 1:
{
lean_object* v___x_1814_; uint8_t v___x_1815_; 
v___x_1814_ = lean_nat_add(v___y_1808_, v___x_1499_);
lean_dec(v___y_1808_);
v___x_1815_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1811_, v___x_1814_);
if (v___x_1815_ == 0)
{
lean_object* v___x_1816_; lean_object* v___x_1817_; uint8_t v___x_1818_; 
lean_dec(v___x_1814_);
v___x_1816_ = lean_box(v___y_1809_);
v___x_1817_ = l_outOfBounds___redArg(v___x_1816_);
lean_dec(v___x_1816_);
v___x_1818_ = lean_unbox(v___x_1817_);
lean_dec(v___x_1817_);
v___y_1799_ = v_a_1813_;
v___y_1800_ = v___y_1810_;
v___y_1801_ = v___x_1818_;
goto v___jp_1798_;
}
else
{
uint8_t v___x_1819_; 
v___x_1819_ = lean_byte_array_fget(v___y_1811_, v___x_1814_);
lean_dec(v___x_1814_);
v___y_1799_ = v_a_1813_;
v___y_1800_ = v___y_1810_;
v___y_1801_ = v___x_1819_;
goto v___jp_1798_;
}
}
default: 
{
lean_object* v___x_1820_; uint8_t v___x_1821_; 
v___x_1820_ = lean_nat_add(v___y_1808_, v___x_1499_);
v___x_1821_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1811_, v___x_1820_);
if (v___x_1821_ == 0)
{
lean_object* v___x_1822_; lean_object* v___x_1823_; uint8_t v___x_1824_; 
lean_dec(v___x_1820_);
v___x_1822_ = lean_box(v___y_1809_);
v___x_1823_ = l_outOfBounds___redArg(v___x_1822_);
lean_dec(v___x_1822_);
v___x_1824_ = lean_unbox(v___x_1823_);
lean_dec(v___x_1823_);
v___y_1781_ = v___y_1808_;
v___y_1782_ = v___y_1809_;
v___y_1783_ = v_a_1813_;
v___y_1784_ = v___y_1810_;
v___y_1785_ = v___y_1811_;
v___y_1786_ = v___x_1824_;
goto v___jp_1780_;
}
else
{
uint8_t v___x_1825_; 
v___x_1825_ = lean_byte_array_fget(v___y_1811_, v___x_1820_);
lean_dec(v___x_1820_);
v___y_1781_ = v___y_1808_;
v___y_1782_ = v___y_1809_;
v___y_1783_ = v_a_1813_;
v___y_1784_ = v___y_1810_;
v___y_1785_ = v___y_1811_;
v___y_1786_ = v___x_1825_;
goto v___jp_1780_;
}
}
}
}
v___jp_1826_:
{
if (v___y_1832_ == 0)
{
uint8_t v___x_1833_; 
v___x_1833_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1831_, v___y_1828_);
if (v___x_1833_ == 0)
{
lean_object* v___x_1834_; lean_object* v___x_1835_; uint8_t v___x_1836_; 
v___x_1834_ = lean_box(v___y_1829_);
v___x_1835_ = l_outOfBounds___redArg(v___x_1834_);
lean_dec(v___x_1834_);
v___x_1836_ = lean_unbox(v___x_1835_);
lean_dec(v___x_1835_);
v___y_1807_ = v___y_1827_;
v___y_1808_ = v___y_1828_;
v___y_1809_ = v___y_1829_;
v___y_1810_ = v___y_1830_;
v___y_1811_ = v___y_1831_;
v___y_1812_ = v___x_1836_;
goto v___jp_1806_;
}
else
{
uint8_t v___x_1837_; 
v___x_1837_ = lean_byte_array_fget(v___y_1831_, v___y_1828_);
v___y_1807_ = v___y_1827_;
v___y_1808_ = v___y_1828_;
v___y_1809_ = v___y_1829_;
v___y_1810_ = v___y_1830_;
v___y_1811_ = v___y_1831_;
v___y_1812_ = v___x_1837_;
goto v___jp_1806_;
}
}
else
{
size_t v_pos_1838_; uint8_t v___x_1839_; uint64_t v_a_1840_; 
v_pos_1838_ = lean_usize_of_nat(v___y_1828_);
lean_dec(v___y_1828_);
v___x_1839_ = lean_byte_array_uget(v___y_1831_, v_pos_1838_);
v_a_1840_ = lean_uint8_to_uint64(v___x_1839_);
switch(v___y_1827_)
{
case 0:
{
v___y_1748_ = v___y_1830_;
v___y_1749_ = v_a_1840_;
goto v___jp_1747_;
}
case 1:
{
size_t v___x_1841_; size_t v___x_1842_; uint8_t v___x_1843_; uint64_t v___x_1844_; uint64_t v___x_1845_; uint64_t v___x_1846_; uint64_t v___x_1847_; 
v___x_1841_ = ((size_t)1ULL);
v___x_1842_ = lean_usize_add(v_pos_1838_, v___x_1841_);
v___x_1843_ = lean_byte_array_uget(v___y_1831_, v___x_1842_);
v___x_1844_ = lean_uint8_to_uint64(v___x_1843_);
v___x_1845_ = 8ULL;
v___x_1846_ = lean_uint64_shift_left(v___x_1844_, v___x_1845_);
v___x_1847_ = lean_uint64_lor(v_a_1840_, v___x_1846_);
v___y_1748_ = v___y_1830_;
v___y_1749_ = v___x_1847_;
goto v___jp_1747_;
}
default: 
{
size_t v___x_1848_; size_t v___x_1849_; uint8_t v___x_1850_; uint64_t v___x_1851_; uint64_t v___x_1852_; uint64_t v___x_1853_; uint64_t v___x_1854_; size_t v___x_1855_; size_t v___x_1856_; uint8_t v___x_1857_; uint64_t v___x_1858_; uint64_t v___x_1859_; uint64_t v___x_1860_; uint64_t v___x_1861_; size_t v___x_1862_; size_t v___x_1863_; uint8_t v___x_1864_; uint64_t v___x_1865_; uint64_t v___x_1866_; uint64_t v___x_1867_; uint64_t v___x_1868_; 
v___x_1848_ = ((size_t)1ULL);
v___x_1849_ = lean_usize_add(v_pos_1838_, v___x_1848_);
v___x_1850_ = lean_byte_array_uget(v___y_1831_, v___x_1849_);
v___x_1851_ = lean_uint8_to_uint64(v___x_1850_);
v___x_1852_ = 8ULL;
v___x_1853_ = lean_uint64_shift_left(v___x_1851_, v___x_1852_);
v___x_1854_ = lean_uint64_lor(v_a_1840_, v___x_1853_);
v___x_1855_ = ((size_t)2ULL);
v___x_1856_ = lean_usize_add(v_pos_1838_, v___x_1855_);
v___x_1857_ = lean_byte_array_uget(v___y_1831_, v___x_1856_);
v___x_1858_ = lean_uint8_to_uint64(v___x_1857_);
v___x_1859_ = 16ULL;
v___x_1860_ = lean_uint64_shift_left(v___x_1858_, v___x_1859_);
v___x_1861_ = lean_uint64_lor(v___x_1854_, v___x_1860_);
v___x_1862_ = ((size_t)3ULL);
v___x_1863_ = lean_usize_add(v_pos_1838_, v___x_1862_);
v___x_1864_ = lean_byte_array_uget(v___y_1831_, v___x_1863_);
v___x_1865_ = lean_uint8_to_uint64(v___x_1864_);
v___x_1866_ = 24ULL;
v___x_1867_ = lean_uint64_shift_left(v___x_1865_, v___x_1866_);
v___x_1868_ = lean_uint64_lor(v___x_1861_, v___x_1867_);
v___y_1748_ = v___y_1830_;
v___y_1749_ = v___x_1868_;
goto v___jp_1747_;
}
}
}
}
v___jp_1869_:
{
lean_object* v_offset_1875_; lean_object* v___x_1876_; lean_object* v___x_1877_; uint8_t v___x_1878_; 
v_offset_1875_ = lean_nat_mul(v_fst_1494_, v___y_1874_);
v___x_1876_ = lean_nat_add(v_offset_1875_, v___y_1874_);
v___x_1877_ = lean_byte_array_size(v___y_1873_);
v___x_1878_ = lean_nat_dec_le(v___x_1876_, v___x_1877_);
if (v___x_1878_ == 0)
{
lean_dec(v___x_1876_);
v___y_1827_ = v___y_1870_;
v___y_1828_ = v_offset_1875_;
v___y_1829_ = v___y_1871_;
v___y_1830_ = v___y_1872_;
v___y_1831_ = v___y_1873_;
v___y_1832_ = v___x_1878_;
goto v___jp_1826_;
}
else
{
size_t v___x_1879_; lean_object* v___x_1880_; uint8_t v___x_1881_; 
v___x_1879_ = lean_usize_of_nat(v___x_1876_);
v___x_1880_ = lean_usize_to_nat(v___x_1879_);
v___x_1881_ = lean_nat_dec_eq(v___x_1880_, v___x_1876_);
lean_dec(v___x_1876_);
lean_dec(v___x_1880_);
v___y_1827_ = v___y_1870_;
v___y_1828_ = v_offset_1875_;
v___y_1829_ = v___y_1871_;
v___y_1830_ = v___y_1872_;
v___y_1831_ = v___y_1873_;
v___y_1832_ = v___x_1881_;
goto v___jp_1826_;
}
}
v___jp_1882_:
{
lean_object* v_coefficients_1884_; uint8_t v___x_1885_; uint8_t v___x_1886_; 
v_coefficients_1884_ = lean_ctor_get(v_p_1470_, 1);
v___x_1885_ = lp_Hex_Hex_Groebner_PrimeField_width(v___x_1468_);
v___x_1886_ = 0;
switch(v___x_1885_)
{
case 0:
{
v___y_1870_ = v___x_1885_;
v___y_1871_ = v___x_1886_;
v___y_1872_ = v___y_1883_;
v___y_1873_ = v_coefficients_1884_;
v___y_1874_ = v___x_1499_;
goto v___jp_1869_;
}
case 1:
{
lean_object* v___x_1887_; 
v___x_1887_ = lean_unsigned_to_nat(2u);
v___y_1870_ = v___x_1885_;
v___y_1871_ = v___x_1886_;
v___y_1872_ = v___y_1883_;
v___y_1873_ = v_coefficients_1884_;
v___y_1874_ = v___x_1887_;
goto v___jp_1869_;
}
default: 
{
lean_object* v___x_1888_; 
v___x_1888_ = lean_unsigned_to_nat(4u);
v___y_1870_ = v___x_1885_;
v___y_1871_ = v___x_1886_;
v___y_1872_ = v___y_1883_;
v___y_1873_ = v_coefficients_1884_;
v___y_1874_ = v___x_1888_;
goto v___jp_1869_;
}
}
}
v___jp_1889_:
{
uint64_t v___x_1892_; uint64_t v___x_1893_; uint64_t v___x_1894_; uint64_t v___x_1895_; lean_object* v___x_1896_; 
v___x_1892_ = lean_uint8_to_uint64(v___y_1891_);
v___x_1893_ = 24ULL;
v___x_1894_ = lean_uint64_shift_left(v___x_1892_, v___x_1893_);
v___x_1895_ = lean_uint64_lor(v___y_1890_, v___x_1894_);
v___x_1896_ = lean_uint64_to_nat(v___x_1895_);
v___y_1883_ = v___x_1896_;
goto v___jp_1882_;
}
v___jp_1897_:
{
uint64_t v___x_1903_; uint64_t v___x_1904_; uint64_t v___x_1905_; uint64_t v___x_1906_; lean_object* v___x_1907_; lean_object* v___x_1908_; uint8_t v___x_1909_; 
v___x_1903_ = lean_uint8_to_uint64(v___y_1902_);
v___x_1904_ = 16ULL;
v___x_1905_ = lean_uint64_shift_left(v___x_1903_, v___x_1904_);
v___x_1906_ = lean_uint64_lor(v___y_1900_, v___x_1905_);
v___x_1907_ = lean_unsigned_to_nat(3u);
v___x_1908_ = lean_nat_add(v___y_1899_, v___x_1907_);
lean_dec(v___y_1899_);
v___x_1909_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1901_, v___x_1908_);
if (v___x_1909_ == 0)
{
lean_object* v___x_1910_; lean_object* v___x_1911_; uint8_t v___x_1912_; 
lean_dec(v___x_1908_);
v___x_1910_ = lean_box(v___y_1898_);
v___x_1911_ = l_outOfBounds___redArg(v___x_1910_);
lean_dec(v___x_1910_);
v___x_1912_ = lean_unbox(v___x_1911_);
lean_dec(v___x_1911_);
v___y_1890_ = v___x_1906_;
v___y_1891_ = v___x_1912_;
goto v___jp_1889_;
}
else
{
uint8_t v___x_1913_; 
v___x_1913_ = lean_byte_array_fget(v___y_1901_, v___x_1908_);
lean_dec(v___x_1908_);
v___y_1890_ = v___x_1906_;
v___y_1891_ = v___x_1913_;
goto v___jp_1889_;
}
}
v___jp_1914_:
{
uint64_t v___x_1920_; uint64_t v___x_1921_; uint64_t v___x_1922_; uint64_t v___x_1923_; lean_object* v___x_1924_; lean_object* v___x_1925_; uint8_t v___x_1926_; 
v___x_1920_ = lean_uint8_to_uint64(v___y_1919_);
v___x_1921_ = 8ULL;
v___x_1922_ = lean_uint64_shift_left(v___x_1920_, v___x_1921_);
v___x_1923_ = lean_uint64_lor(v___y_1918_, v___x_1922_);
v___x_1924_ = lean_unsigned_to_nat(2u);
v___x_1925_ = lean_nat_add(v___y_1915_, v___x_1924_);
v___x_1926_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1917_, v___x_1925_);
if (v___x_1926_ == 0)
{
lean_object* v___x_1927_; lean_object* v___x_1928_; uint8_t v___x_1929_; 
lean_dec(v___x_1925_);
v___x_1927_ = lean_box(v___y_1916_);
v___x_1928_ = l_outOfBounds___redArg(v___x_1927_);
lean_dec(v___x_1927_);
v___x_1929_ = lean_unbox(v___x_1928_);
lean_dec(v___x_1928_);
v___y_1898_ = v___y_1916_;
v___y_1899_ = v___y_1915_;
v___y_1900_ = v___x_1923_;
v___y_1901_ = v___y_1917_;
v___y_1902_ = v___x_1929_;
goto v___jp_1897_;
}
else
{
uint8_t v___x_1930_; 
v___x_1930_ = lean_byte_array_fget(v___y_1917_, v___x_1925_);
lean_dec(v___x_1925_);
v___y_1898_ = v___y_1916_;
v___y_1899_ = v___y_1915_;
v___y_1900_ = v___x_1923_;
v___y_1901_ = v___y_1917_;
v___y_1902_ = v___x_1930_;
goto v___jp_1897_;
}
}
v___jp_1931_:
{
uint64_t v_a_1936_; lean_object* v___x_1937_; uint8_t v___x_1938_; 
v_a_1936_ = lean_uint8_to_uint64(v___y_1935_);
v___x_1937_ = lean_nat_add(v___y_1933_, v___x_1499_);
v___x_1938_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1934_, v___x_1937_);
if (v___x_1938_ == 0)
{
lean_object* v___x_1939_; lean_object* v___x_1940_; uint8_t v___x_1941_; 
lean_dec(v___x_1937_);
v___x_1939_ = lean_box(v___y_1932_);
v___x_1940_ = l_outOfBounds___redArg(v___x_1939_);
lean_dec(v___x_1939_);
v___x_1941_ = lean_unbox(v___x_1940_);
lean_dec(v___x_1940_);
v___y_1915_ = v___y_1933_;
v___y_1916_ = v___y_1932_;
v___y_1917_ = v___y_1934_;
v___y_1918_ = v_a_1936_;
v___y_1919_ = v___x_1941_;
goto v___jp_1914_;
}
else
{
uint8_t v___x_1942_; 
v___x_1942_ = lean_byte_array_fget(v___y_1934_, v___x_1937_);
lean_dec(v___x_1937_);
v___y_1915_ = v___y_1933_;
v___y_1916_ = v___y_1932_;
v___y_1917_ = v___y_1934_;
v___y_1918_ = v_a_1936_;
v___y_1919_ = v___x_1942_;
goto v___jp_1914_;
}
}
v___jp_1943_:
{
if (v___y_1947_ == 0)
{
uint8_t v___x_1948_; 
v___x_1948_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_1946_, v___y_1945_);
if (v___x_1948_ == 0)
{
lean_object* v___x_1949_; lean_object* v___x_1950_; uint8_t v___x_1951_; 
v___x_1949_ = lean_box(v___y_1944_);
v___x_1950_ = l_outOfBounds___redArg(v___x_1949_);
lean_dec(v___x_1949_);
v___x_1951_ = lean_unbox(v___x_1950_);
lean_dec(v___x_1950_);
v___y_1932_ = v___y_1944_;
v___y_1933_ = v___y_1945_;
v___y_1934_ = v___y_1946_;
v___y_1935_ = v___x_1951_;
goto v___jp_1931_;
}
else
{
uint8_t v___x_1952_; 
v___x_1952_ = lean_byte_array_fget(v___y_1946_, v___y_1945_);
v___y_1932_ = v___y_1944_;
v___y_1933_ = v___y_1945_;
v___y_1934_ = v___y_1946_;
v___y_1935_ = v___x_1952_;
goto v___jp_1931_;
}
}
else
{
size_t v_pos_1953_; uint8_t v___x_1954_; uint64_t v_a_1955_; size_t v___x_1956_; size_t v___x_1957_; uint8_t v___x_1958_; uint64_t v___x_1959_; uint64_t v___x_1960_; uint64_t v___x_1961_; uint64_t v___x_1962_; size_t v___x_1963_; size_t v___x_1964_; uint8_t v___x_1965_; uint64_t v___x_1966_; uint64_t v___x_1967_; uint64_t v___x_1968_; uint64_t v___x_1969_; size_t v___x_1970_; size_t v___x_1971_; uint8_t v___x_1972_; uint64_t v___x_1973_; uint64_t v___x_1974_; uint64_t v___x_1975_; uint64_t v___x_1976_; lean_object* v___x_1977_; 
v_pos_1953_ = lean_usize_of_nat(v___y_1945_);
lean_dec(v___y_1945_);
v___x_1954_ = lean_byte_array_uget(v___y_1946_, v_pos_1953_);
v_a_1955_ = lean_uint8_to_uint64(v___x_1954_);
v___x_1956_ = ((size_t)1ULL);
v___x_1957_ = lean_usize_add(v_pos_1953_, v___x_1956_);
v___x_1958_ = lean_byte_array_uget(v___y_1946_, v___x_1957_);
v___x_1959_ = lean_uint8_to_uint64(v___x_1958_);
v___x_1960_ = 8ULL;
v___x_1961_ = lean_uint64_shift_left(v___x_1959_, v___x_1960_);
v___x_1962_ = lean_uint64_lor(v_a_1955_, v___x_1961_);
v___x_1963_ = ((size_t)2ULL);
v___x_1964_ = lean_usize_add(v_pos_1953_, v___x_1963_);
v___x_1965_ = lean_byte_array_uget(v___y_1946_, v___x_1964_);
v___x_1966_ = lean_uint8_to_uint64(v___x_1965_);
v___x_1967_ = 16ULL;
v___x_1968_ = lean_uint64_shift_left(v___x_1966_, v___x_1967_);
v___x_1969_ = lean_uint64_lor(v___x_1962_, v___x_1968_);
v___x_1970_ = ((size_t)3ULL);
v___x_1971_ = lean_usize_add(v_pos_1953_, v___x_1970_);
v___x_1972_ = lean_byte_array_uget(v___y_1946_, v___x_1971_);
v___x_1973_ = lean_uint8_to_uint64(v___x_1972_);
v___x_1974_ = 24ULL;
v___x_1975_ = lean_uint64_shift_left(v___x_1973_, v___x_1974_);
v___x_1976_ = lean_uint64_lor(v___x_1969_, v___x_1975_);
v___x_1977_ = lean_uint64_to_nat(v___x_1976_);
v___y_1883_ = v___x_1977_;
goto v___jp_1882_;
}
}
v___jp_1978_:
{
lean_object* v_support_1979_; uint8_t v___x_1980_; lean_object* v___x_1981_; lean_object* v_offset_1982_; lean_object* v___x_1983_; lean_object* v___x_1984_; uint8_t v___x_1985_; 
v_support_1979_ = lean_ctor_get(v_p_1470_, 0);
v___x_1980_ = 0;
v___x_1981_ = lean_unsigned_to_nat(4u);
v_offset_1982_ = lean_nat_mul(v_fst_1494_, v___x_1981_);
v___x_1983_ = lean_nat_add(v_offset_1982_, v___x_1981_);
v___x_1984_ = lean_byte_array_size(v_support_1979_);
v___x_1985_ = lean_nat_dec_le(v___x_1983_, v___x_1984_);
if (v___x_1985_ == 0)
{
lean_dec(v___x_1983_);
v___y_1944_ = v___x_1980_;
v___y_1945_ = v_offset_1982_;
v___y_1946_ = v_support_1979_;
v___y_1947_ = v___x_1985_;
goto v___jp_1943_;
}
else
{
size_t v___x_1986_; lean_object* v___x_1987_; uint8_t v___x_1988_; 
v___x_1986_ = lean_usize_of_nat(v___x_1983_);
v___x_1987_ = lean_usize_to_nat(v___x_1986_);
v___x_1988_ = lean_nat_dec_eq(v___x_1987_, v___x_1983_);
lean_dec(v___x_1983_);
lean_dec(v___x_1987_);
v___y_1944_ = v___x_1980_;
v___y_1945_ = v_offset_1982_;
v___y_1946_ = v_support_1979_;
v___y_1947_ = v___x_1988_;
goto v___jp_1943_;
}
}
v___jp_1989_:
{
lean_object* v___x_1992_; lean_object* v___x_1993_; lean_object* v___x_1994_; lean_object* v___x_1995_; 
v___x_1992_ = lean_nat_add(v_fst_1494_, v___x_1499_);
lean_dec(v_fst_1494_);
v___x_1993_ = lean_nat_add(v_snd_1495_, v___x_1499_);
lean_dec(v_snd_1495_);
v___x_1994_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1994_, 0, v___x_1992_);
lean_ctor_set(v___x_1994_, 1, v___x_1993_);
v___x_1995_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1995_, 0, v_result_1990_);
lean_ctor_set(v___x_1995_, 1, v___x_1994_);
v_a_1482_ = v___x_1995_;
v_snd_1483_ = v___y_1991_;
goto v___jp_1481_;
}
v___jp_1996_:
{
lean_object* v___x_1999_; 
v___x_1999_ = lp_Hex___private_HexGroebner_Polynomial_0__Hex_Groebner_Polynomial_append(v___x_1468_, v_fst_1490_, v___y_1998_, v___y_1997_);
lean_dec(v___y_1998_);
v_result_1990_ = v___x_1999_;
v___y_1991_ = v___y_1478_;
goto v___jp_1989_;
}
v___jp_2000_:
{
uint64_t v___x_2004_; uint64_t v___x_2005_; uint64_t v___x_2006_; uint64_t v___x_2007_; lean_object* v___x_2008_; 
v___x_2004_ = lean_uint8_to_uint64(v___y_2003_);
v___x_2005_ = 24ULL;
v___x_2006_ = lean_uint64_shift_left(v___x_2004_, v___x_2005_);
v___x_2007_ = lean_uint64_lor(v___y_2002_, v___x_2006_);
v___x_2008_ = lean_uint64_to_nat(v___x_2007_);
v___y_1997_ = v___y_2001_;
v___y_1998_ = v___x_2008_;
goto v___jp_1996_;
}
v___jp_2009_:
{
uint64_t v___x_2016_; uint64_t v___x_2017_; uint64_t v___x_2018_; uint64_t v___x_2019_; lean_object* v___x_2020_; lean_object* v___x_2021_; uint8_t v___x_2022_; 
v___x_2016_ = lean_uint8_to_uint64(v___y_2015_);
v___x_2017_ = 16ULL;
v___x_2018_ = lean_uint64_shift_left(v___x_2016_, v___x_2017_);
v___x_2019_ = lean_uint64_lor(v___y_2013_, v___x_2018_);
v___x_2020_ = lean_unsigned_to_nat(3u);
v___x_2021_ = lean_nat_add(v___y_2012_, v___x_2020_);
lean_dec(v___y_2012_);
v___x_2022_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2011_, v___x_2021_);
if (v___x_2022_ == 0)
{
lean_object* v___x_2023_; lean_object* v___x_2024_; uint8_t v___x_2025_; 
lean_dec(v___x_2021_);
v___x_2023_ = lean_box(v___y_2014_);
v___x_2024_ = l_outOfBounds___redArg(v___x_2023_);
lean_dec(v___x_2023_);
v___x_2025_ = lean_unbox(v___x_2024_);
lean_dec(v___x_2024_);
v___y_2001_ = v___y_2010_;
v___y_2002_ = v___x_2019_;
v___y_2003_ = v___x_2025_;
goto v___jp_2000_;
}
else
{
uint8_t v___x_2026_; 
v___x_2026_ = lean_byte_array_fget(v___y_2011_, v___x_2021_);
lean_dec(v___x_2021_);
v___y_2001_ = v___y_2010_;
v___y_2002_ = v___x_2019_;
v___y_2003_ = v___x_2026_;
goto v___jp_2000_;
}
}
v___jp_2027_:
{
uint64_t v___x_2034_; uint64_t v___x_2035_; uint64_t v___x_2036_; uint64_t v___x_2037_; lean_object* v___x_2038_; lean_object* v___x_2039_; uint8_t v___x_2040_; 
v___x_2034_ = lean_uint8_to_uint64(v___y_2033_);
v___x_2035_ = 8ULL;
v___x_2036_ = lean_uint64_shift_left(v___x_2034_, v___x_2035_);
v___x_2037_ = lean_uint64_lor(v___y_2032_, v___x_2036_);
v___x_2038_ = lean_unsigned_to_nat(2u);
v___x_2039_ = lean_nat_add(v___y_2030_, v___x_2038_);
v___x_2040_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2029_, v___x_2039_);
if (v___x_2040_ == 0)
{
lean_object* v___x_2041_; lean_object* v___x_2042_; uint8_t v___x_2043_; 
lean_dec(v___x_2039_);
v___x_2041_ = lean_box(v___y_2031_);
v___x_2042_ = l_outOfBounds___redArg(v___x_2041_);
lean_dec(v___x_2041_);
v___x_2043_ = lean_unbox(v___x_2042_);
lean_dec(v___x_2042_);
v___y_2010_ = v___y_2028_;
v___y_2011_ = v___y_2029_;
v___y_2012_ = v___y_2030_;
v___y_2013_ = v___x_2037_;
v___y_2014_ = v___y_2031_;
v___y_2015_ = v___x_2043_;
goto v___jp_2009_;
}
else
{
uint8_t v___x_2044_; 
v___x_2044_ = lean_byte_array_fget(v___y_2029_, v___x_2039_);
lean_dec(v___x_2039_);
v___y_2010_ = v___y_2028_;
v___y_2011_ = v___y_2029_;
v___y_2012_ = v___y_2030_;
v___y_2013_ = v___x_2037_;
v___y_2014_ = v___y_2031_;
v___y_2015_ = v___x_2044_;
goto v___jp_2009_;
}
}
v___jp_2045_:
{
uint64_t v_a_2051_; lean_object* v___x_2052_; uint8_t v___x_2053_; 
v_a_2051_ = lean_uint8_to_uint64(v___y_2050_);
v___x_2052_ = lean_nat_add(v___y_2048_, v___x_1499_);
v___x_2053_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2047_, v___x_2052_);
if (v___x_2053_ == 0)
{
lean_object* v___x_2054_; lean_object* v___x_2055_; uint8_t v___x_2056_; 
lean_dec(v___x_2052_);
v___x_2054_ = lean_box(v___y_2049_);
v___x_2055_ = l_outOfBounds___redArg(v___x_2054_);
lean_dec(v___x_2054_);
v___x_2056_ = lean_unbox(v___x_2055_);
lean_dec(v___x_2055_);
v___y_2028_ = v___y_2046_;
v___y_2029_ = v___y_2047_;
v___y_2030_ = v___y_2048_;
v___y_2031_ = v___y_2049_;
v___y_2032_ = v_a_2051_;
v___y_2033_ = v___x_2056_;
goto v___jp_2027_;
}
else
{
uint8_t v___x_2057_; 
v___x_2057_ = lean_byte_array_fget(v___y_2047_, v___x_2052_);
lean_dec(v___x_2052_);
v___y_2028_ = v___y_2046_;
v___y_2029_ = v___y_2047_;
v___y_2030_ = v___y_2048_;
v___y_2031_ = v___y_2049_;
v___y_2032_ = v_a_2051_;
v___y_2033_ = v___x_2057_;
goto v___jp_2027_;
}
}
v___jp_2058_:
{
if (v___y_2063_ == 0)
{
uint8_t v___x_2064_; 
v___x_2064_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2060_, v___y_2061_);
if (v___x_2064_ == 0)
{
lean_object* v___x_2065_; lean_object* v___x_2066_; uint8_t v___x_2067_; 
v___x_2065_ = lean_box(v___y_2062_);
v___x_2066_ = l_outOfBounds___redArg(v___x_2065_);
lean_dec(v___x_2065_);
v___x_2067_ = lean_unbox(v___x_2066_);
lean_dec(v___x_2066_);
v___y_2046_ = v___y_2059_;
v___y_2047_ = v___y_2060_;
v___y_2048_ = v___y_2061_;
v___y_2049_ = v___y_2062_;
v___y_2050_ = v___x_2067_;
goto v___jp_2045_;
}
else
{
uint8_t v___x_2068_; 
v___x_2068_ = lean_byte_array_fget(v___y_2060_, v___y_2061_);
v___y_2046_ = v___y_2059_;
v___y_2047_ = v___y_2060_;
v___y_2048_ = v___y_2061_;
v___y_2049_ = v___y_2062_;
v___y_2050_ = v___x_2068_;
goto v___jp_2045_;
}
}
else
{
size_t v_pos_2069_; uint8_t v___x_2070_; uint64_t v_a_2071_; size_t v___x_2072_; size_t v___x_2073_; uint8_t v___x_2074_; uint64_t v___x_2075_; uint64_t v___x_2076_; uint64_t v___x_2077_; uint64_t v___x_2078_; size_t v___x_2079_; size_t v___x_2080_; uint8_t v___x_2081_; uint64_t v___x_2082_; uint64_t v___x_2083_; uint64_t v___x_2084_; uint64_t v___x_2085_; size_t v___x_2086_; size_t v___x_2087_; uint8_t v___x_2088_; uint64_t v___x_2089_; uint64_t v___x_2090_; uint64_t v___x_2091_; uint64_t v___x_2092_; lean_object* v___x_2093_; 
v_pos_2069_ = lean_usize_of_nat(v___y_2061_);
lean_dec(v___y_2061_);
v___x_2070_ = lean_byte_array_uget(v___y_2060_, v_pos_2069_);
v_a_2071_ = lean_uint8_to_uint64(v___x_2070_);
v___x_2072_ = ((size_t)1ULL);
v___x_2073_ = lean_usize_add(v_pos_2069_, v___x_2072_);
v___x_2074_ = lean_byte_array_uget(v___y_2060_, v___x_2073_);
v___x_2075_ = lean_uint8_to_uint64(v___x_2074_);
v___x_2076_ = 8ULL;
v___x_2077_ = lean_uint64_shift_left(v___x_2075_, v___x_2076_);
v___x_2078_ = lean_uint64_lor(v_a_2071_, v___x_2077_);
v___x_2079_ = ((size_t)2ULL);
v___x_2080_ = lean_usize_add(v_pos_2069_, v___x_2079_);
v___x_2081_ = lean_byte_array_uget(v___y_2060_, v___x_2080_);
v___x_2082_ = lean_uint8_to_uint64(v___x_2081_);
v___x_2083_ = 16ULL;
v___x_2084_ = lean_uint64_shift_left(v___x_2082_, v___x_2083_);
v___x_2085_ = lean_uint64_lor(v___x_2078_, v___x_2084_);
v___x_2086_ = ((size_t)3ULL);
v___x_2087_ = lean_usize_add(v_pos_2069_, v___x_2086_);
v___x_2088_ = lean_byte_array_uget(v___y_2060_, v___x_2087_);
v___x_2089_ = lean_uint8_to_uint64(v___x_2088_);
v___x_2090_ = 24ULL;
v___x_2091_ = lean_uint64_shift_left(v___x_2089_, v___x_2090_);
v___x_2092_ = lean_uint64_lor(v___x_2085_, v___x_2091_);
v___x_2093_ = lean_uint64_to_nat(v___x_2092_);
v___y_1997_ = v___y_2059_;
v___y_1998_ = v___x_2093_;
goto v___jp_1996_;
}
}
v___jp_2094_:
{
uint64_t v___x_2096_; uint8_t v___x_2097_; 
v___x_2096_ = 0ULL;
v___x_2097_ = lean_uint64_dec_eq(v___y_2095_, v___x_2096_);
if (v___x_2097_ == 0)
{
lean_object* v_support_2098_; uint8_t v___x_2099_; lean_object* v___x_2100_; lean_object* v_offset_2101_; lean_object* v___x_2102_; lean_object* v___x_2103_; uint8_t v___x_2104_; 
v_support_2098_ = lean_ctor_get(v_p_1470_, 0);
v___x_2099_ = 0;
v___x_2100_ = lean_unsigned_to_nat(4u);
v_offset_2101_ = lean_nat_mul(v_fst_1494_, v___x_2100_);
v___x_2102_ = lean_nat_add(v_offset_2101_, v___x_2100_);
v___x_2103_ = lean_byte_array_size(v_support_2098_);
v___x_2104_ = lean_nat_dec_le(v___x_2102_, v___x_2103_);
if (v___x_2104_ == 0)
{
lean_dec(v___x_2102_);
v___y_2059_ = v___y_2095_;
v___y_2060_ = v_support_2098_;
v___y_2061_ = v_offset_2101_;
v___y_2062_ = v___x_2099_;
v___y_2063_ = v___x_2104_;
goto v___jp_2058_;
}
else
{
size_t v___x_2105_; lean_object* v___x_2106_; uint8_t v___x_2107_; 
v___x_2105_ = lean_usize_of_nat(v___x_2102_);
v___x_2106_ = lean_usize_to_nat(v___x_2105_);
v___x_2107_ = lean_nat_dec_eq(v___x_2106_, v___x_2102_);
lean_dec(v___x_2102_);
lean_dec(v___x_2106_);
v___y_2059_ = v___y_2095_;
v___y_2060_ = v_support_2098_;
v___y_2061_ = v_offset_2101_;
v___y_2062_ = v___x_2099_;
v___y_2063_ = v___x_2107_;
goto v___jp_2058_;
}
}
else
{
v_result_1990_ = v_fst_1490_;
v___y_1991_ = v___y_1478_;
goto v___jp_1989_;
}
}
v___jp_2108_:
{
uint8_t v___x_2111_; 
v___x_2111_ = lean_uint64_dec_le(v___y_2110_, v___y_2109_);
if (v___x_2111_ == 0)
{
uint64_t v___x_2112_; uint64_t v___x_2113_; 
v___x_2112_ = lean_uint64_add(v___y_2109_, v___x_1468_);
v___x_2113_ = lean_uint64_sub(v___x_2112_, v___y_2110_);
v___y_2095_ = v___x_2113_;
goto v___jp_2094_;
}
else
{
uint64_t v___x_2114_; 
v___x_2114_ = lean_uint64_sub(v___y_2109_, v___y_2110_);
v___y_2095_ = v___x_2114_;
goto v___jp_2094_;
}
}
v___jp_2115_:
{
uint64_t v___x_2119_; uint64_t v___x_2120_; uint64_t v___x_2121_; uint64_t v___x_2122_; 
v___x_2119_ = lean_uint8_to_uint64(v___y_2118_);
v___x_2120_ = 24ULL;
v___x_2121_ = lean_uint64_shift_left(v___x_2119_, v___x_2120_);
v___x_2122_ = lean_uint64_lor(v___y_2117_, v___x_2121_);
v___y_2109_ = v___y_2116_;
v___y_2110_ = v___x_2122_;
goto v___jp_2108_;
}
v___jp_2123_:
{
uint64_t v___x_2130_; uint64_t v___x_2131_; uint64_t v___x_2132_; uint64_t v___x_2133_; lean_object* v___x_2134_; lean_object* v___x_2135_; uint8_t v___x_2136_; 
v___x_2130_ = lean_uint8_to_uint64(v___y_2129_);
v___x_2131_ = 16ULL;
v___x_2132_ = lean_uint64_shift_left(v___x_2130_, v___x_2131_);
v___x_2133_ = lean_uint64_lor(v___y_2128_, v___x_2132_);
v___x_2134_ = lean_unsigned_to_nat(3u);
v___x_2135_ = lean_nat_add(v___y_2124_, v___x_2134_);
lean_dec(v___y_2124_);
v___x_2136_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2127_, v___x_2135_);
if (v___x_2136_ == 0)
{
lean_object* v___x_2137_; lean_object* v___x_2138_; uint8_t v___x_2139_; 
lean_dec(v___x_2135_);
v___x_2137_ = lean_box(v___y_2126_);
v___x_2138_ = l_outOfBounds___redArg(v___x_2137_);
lean_dec(v___x_2137_);
v___x_2139_ = lean_unbox(v___x_2138_);
lean_dec(v___x_2138_);
v___y_2116_ = v___y_2125_;
v___y_2117_ = v___x_2133_;
v___y_2118_ = v___x_2139_;
goto v___jp_2115_;
}
else
{
uint8_t v___x_2140_; 
v___x_2140_ = lean_byte_array_fget(v___y_2127_, v___x_2135_);
lean_dec(v___x_2135_);
v___y_2116_ = v___y_2125_;
v___y_2117_ = v___x_2133_;
v___y_2118_ = v___x_2140_;
goto v___jp_2115_;
}
}
v___jp_2141_:
{
uint64_t v___x_2148_; uint64_t v___x_2149_; uint64_t v___x_2150_; uint64_t v___x_2151_; lean_object* v___x_2152_; lean_object* v___x_2153_; uint8_t v___x_2154_; 
v___x_2148_ = lean_uint8_to_uint64(v___y_2147_);
v___x_2149_ = 8ULL;
v___x_2150_ = lean_uint64_shift_left(v___x_2148_, v___x_2149_);
v___x_2151_ = lean_uint64_lor(v___y_2142_, v___x_2150_);
v___x_2152_ = lean_unsigned_to_nat(2u);
v___x_2153_ = lean_nat_add(v___y_2144_, v___x_2152_);
v___x_2154_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2146_, v___x_2153_);
if (v___x_2154_ == 0)
{
lean_object* v___x_2155_; lean_object* v___x_2156_; uint8_t v___x_2157_; 
lean_dec(v___x_2153_);
v___x_2155_ = lean_box(v___y_2145_);
v___x_2156_ = l_outOfBounds___redArg(v___x_2155_);
lean_dec(v___x_2155_);
v___x_2157_ = lean_unbox(v___x_2156_);
lean_dec(v___x_2156_);
v___y_2124_ = v___y_2144_;
v___y_2125_ = v___y_2143_;
v___y_2126_ = v___y_2145_;
v___y_2127_ = v___y_2146_;
v___y_2128_ = v___x_2151_;
v___y_2129_ = v___x_2157_;
goto v___jp_2123_;
}
else
{
uint8_t v___x_2158_; 
v___x_2158_ = lean_byte_array_fget(v___y_2146_, v___x_2153_);
lean_dec(v___x_2153_);
v___y_2124_ = v___y_2144_;
v___y_2125_ = v___y_2143_;
v___y_2126_ = v___y_2145_;
v___y_2127_ = v___y_2146_;
v___y_2128_ = v___x_2151_;
v___y_2129_ = v___x_2158_;
goto v___jp_2123_;
}
}
v___jp_2159_:
{
uint64_t v___x_2163_; uint64_t v___x_2164_; uint64_t v___x_2165_; uint64_t v___x_2166_; 
v___x_2163_ = lean_uint8_to_uint64(v___y_2162_);
v___x_2164_ = 8ULL;
v___x_2165_ = lean_uint64_shift_left(v___x_2163_, v___x_2164_);
v___x_2166_ = lean_uint64_lor(v___y_2160_, v___x_2165_);
v___y_2109_ = v___y_2161_;
v___y_2110_ = v___x_2166_;
goto v___jp_2108_;
}
v___jp_2167_:
{
uint64_t v_a_2174_; 
v_a_2174_ = lean_uint8_to_uint64(v___y_2173_);
switch(v___y_2170_)
{
case 0:
{
lean_dec(v___y_2168_);
v___y_2109_ = v___y_2169_;
v___y_2110_ = v_a_2174_;
goto v___jp_2108_;
}
case 1:
{
lean_object* v___x_2175_; uint8_t v___x_2176_; 
v___x_2175_ = lean_nat_add(v___y_2168_, v___x_1499_);
lean_dec(v___y_2168_);
v___x_2176_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2172_, v___x_2175_);
if (v___x_2176_ == 0)
{
lean_object* v___x_2177_; lean_object* v___x_2178_; uint8_t v___x_2179_; 
lean_dec(v___x_2175_);
v___x_2177_ = lean_box(v___y_2171_);
v___x_2178_ = l_outOfBounds___redArg(v___x_2177_);
lean_dec(v___x_2177_);
v___x_2179_ = lean_unbox(v___x_2178_);
lean_dec(v___x_2178_);
v___y_2160_ = v_a_2174_;
v___y_2161_ = v___y_2169_;
v___y_2162_ = v___x_2179_;
goto v___jp_2159_;
}
else
{
uint8_t v___x_2180_; 
v___x_2180_ = lean_byte_array_fget(v___y_2172_, v___x_2175_);
lean_dec(v___x_2175_);
v___y_2160_ = v_a_2174_;
v___y_2161_ = v___y_2169_;
v___y_2162_ = v___x_2180_;
goto v___jp_2159_;
}
}
default: 
{
lean_object* v___x_2181_; uint8_t v___x_2182_; 
v___x_2181_ = lean_nat_add(v___y_2168_, v___x_1499_);
v___x_2182_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2172_, v___x_2181_);
if (v___x_2182_ == 0)
{
lean_object* v___x_2183_; lean_object* v___x_2184_; uint8_t v___x_2185_; 
lean_dec(v___x_2181_);
v___x_2183_ = lean_box(v___y_2171_);
v___x_2184_ = l_outOfBounds___redArg(v___x_2183_);
lean_dec(v___x_2183_);
v___x_2185_ = lean_unbox(v___x_2184_);
lean_dec(v___x_2184_);
v___y_2142_ = v_a_2174_;
v___y_2143_ = v___y_2169_;
v___y_2144_ = v___y_2168_;
v___y_2145_ = v___y_2171_;
v___y_2146_ = v___y_2172_;
v___y_2147_ = v___x_2185_;
goto v___jp_2141_;
}
else
{
uint8_t v___x_2186_; 
v___x_2186_ = lean_byte_array_fget(v___y_2172_, v___x_2181_);
lean_dec(v___x_2181_);
v___y_2142_ = v_a_2174_;
v___y_2143_ = v___y_2169_;
v___y_2144_ = v___y_2168_;
v___y_2145_ = v___y_2171_;
v___y_2146_ = v___y_2172_;
v___y_2147_ = v___x_2186_;
goto v___jp_2141_;
}
}
}
}
v___jp_2187_:
{
if (v___y_2193_ == 0)
{
uint8_t v___x_2194_; 
v___x_2194_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2192_, v___y_2189_);
if (v___x_2194_ == 0)
{
lean_object* v___x_2195_; lean_object* v___x_2196_; uint8_t v___x_2197_; 
v___x_2195_ = lean_box(v___y_2191_);
v___x_2196_ = l_outOfBounds___redArg(v___x_2195_);
lean_dec(v___x_2195_);
v___x_2197_ = lean_unbox(v___x_2196_);
lean_dec(v___x_2196_);
v___y_2168_ = v___y_2189_;
v___y_2169_ = v___y_2188_;
v___y_2170_ = v___y_2190_;
v___y_2171_ = v___y_2191_;
v___y_2172_ = v___y_2192_;
v___y_2173_ = v___x_2197_;
goto v___jp_2167_;
}
else
{
uint8_t v___x_2198_; 
v___x_2198_ = lean_byte_array_fget(v___y_2192_, v___y_2189_);
v___y_2168_ = v___y_2189_;
v___y_2169_ = v___y_2188_;
v___y_2170_ = v___y_2190_;
v___y_2171_ = v___y_2191_;
v___y_2172_ = v___y_2192_;
v___y_2173_ = v___x_2198_;
goto v___jp_2167_;
}
}
else
{
size_t v_pos_2199_; uint8_t v___x_2200_; uint64_t v_a_2201_; 
v_pos_2199_ = lean_usize_of_nat(v___y_2189_);
lean_dec(v___y_2189_);
v___x_2200_ = lean_byte_array_uget(v___y_2192_, v_pos_2199_);
v_a_2201_ = lean_uint8_to_uint64(v___x_2200_);
switch(v___y_2190_)
{
case 0:
{
v___y_2109_ = v___y_2188_;
v___y_2110_ = v_a_2201_;
goto v___jp_2108_;
}
case 1:
{
size_t v___x_2202_; size_t v___x_2203_; uint8_t v___x_2204_; uint64_t v___x_2205_; uint64_t v___x_2206_; uint64_t v___x_2207_; uint64_t v___x_2208_; 
v___x_2202_ = ((size_t)1ULL);
v___x_2203_ = lean_usize_add(v_pos_2199_, v___x_2202_);
v___x_2204_ = lean_byte_array_uget(v___y_2192_, v___x_2203_);
v___x_2205_ = lean_uint8_to_uint64(v___x_2204_);
v___x_2206_ = 8ULL;
v___x_2207_ = lean_uint64_shift_left(v___x_2205_, v___x_2206_);
v___x_2208_ = lean_uint64_lor(v_a_2201_, v___x_2207_);
v___y_2109_ = v___y_2188_;
v___y_2110_ = v___x_2208_;
goto v___jp_2108_;
}
default: 
{
size_t v___x_2209_; size_t v___x_2210_; uint8_t v___x_2211_; uint64_t v___x_2212_; uint64_t v___x_2213_; uint64_t v___x_2214_; uint64_t v___x_2215_; size_t v___x_2216_; size_t v___x_2217_; uint8_t v___x_2218_; uint64_t v___x_2219_; uint64_t v___x_2220_; uint64_t v___x_2221_; uint64_t v___x_2222_; size_t v___x_2223_; size_t v___x_2224_; uint8_t v___x_2225_; uint64_t v___x_2226_; uint64_t v___x_2227_; uint64_t v___x_2228_; uint64_t v___x_2229_; 
v___x_2209_ = ((size_t)1ULL);
v___x_2210_ = lean_usize_add(v_pos_2199_, v___x_2209_);
v___x_2211_ = lean_byte_array_uget(v___y_2192_, v___x_2210_);
v___x_2212_ = lean_uint8_to_uint64(v___x_2211_);
v___x_2213_ = 8ULL;
v___x_2214_ = lean_uint64_shift_left(v___x_2212_, v___x_2213_);
v___x_2215_ = lean_uint64_lor(v_a_2201_, v___x_2214_);
v___x_2216_ = ((size_t)2ULL);
v___x_2217_ = lean_usize_add(v_pos_2199_, v___x_2216_);
v___x_2218_ = lean_byte_array_uget(v___y_2192_, v___x_2217_);
v___x_2219_ = lean_uint8_to_uint64(v___x_2218_);
v___x_2220_ = 16ULL;
v___x_2221_ = lean_uint64_shift_left(v___x_2219_, v___x_2220_);
v___x_2222_ = lean_uint64_lor(v___x_2215_, v___x_2221_);
v___x_2223_ = ((size_t)3ULL);
v___x_2224_ = lean_usize_add(v_pos_2199_, v___x_2223_);
v___x_2225_ = lean_byte_array_uget(v___y_2192_, v___x_2224_);
v___x_2226_ = lean_uint8_to_uint64(v___x_2225_);
v___x_2227_ = 24ULL;
v___x_2228_ = lean_uint64_shift_left(v___x_2226_, v___x_2227_);
v___x_2229_ = lean_uint64_lor(v___x_2222_, v___x_2228_);
v___y_2109_ = v___y_2188_;
v___y_2110_ = v___x_2229_;
goto v___jp_2108_;
}
}
}
}
v___jp_2230_:
{
lean_object* v_offset_2236_; lean_object* v___x_2237_; lean_object* v___x_2238_; uint8_t v___x_2239_; 
v_offset_2236_ = lean_nat_mul(v_snd_1495_, v___y_2235_);
v___x_2237_ = lean_nat_add(v_offset_2236_, v___y_2235_);
v___x_2238_ = lean_byte_array_size(v___y_2234_);
v___x_2239_ = lean_nat_dec_le(v___x_2237_, v___x_2238_);
if (v___x_2239_ == 0)
{
lean_dec(v___x_2237_);
v___y_2188_ = v___y_2231_;
v___y_2189_ = v_offset_2236_;
v___y_2190_ = v___y_2232_;
v___y_2191_ = v___y_2233_;
v___y_2192_ = v___y_2234_;
v___y_2193_ = v___x_2239_;
goto v___jp_2187_;
}
else
{
size_t v___x_2240_; lean_object* v___x_2241_; uint8_t v___x_2242_; 
v___x_2240_ = lean_usize_of_nat(v___x_2237_);
v___x_2241_ = lean_usize_to_nat(v___x_2240_);
v___x_2242_ = lean_nat_dec_eq(v___x_2241_, v___x_2237_);
lean_dec(v___x_2237_);
lean_dec(v___x_2241_);
v___y_2188_ = v___y_2231_;
v___y_2189_ = v_offset_2236_;
v___y_2190_ = v___y_2232_;
v___y_2191_ = v___y_2233_;
v___y_2192_ = v___y_2234_;
v___y_2193_ = v___x_2242_;
goto v___jp_2187_;
}
}
v___jp_2243_:
{
lean_object* v_coefficients_2245_; uint8_t v___x_2246_; uint8_t v___x_2247_; 
v_coefficients_2245_ = lean_ctor_get(v_q_1469_, 1);
v___x_2246_ = lp_Hex_Hex_Groebner_PrimeField_width(v___x_1468_);
v___x_2247_ = 0;
switch(v___x_2246_)
{
case 0:
{
v___y_2231_ = v___y_2244_;
v___y_2232_ = v___x_2246_;
v___y_2233_ = v___x_2247_;
v___y_2234_ = v_coefficients_2245_;
v___y_2235_ = v___x_1499_;
goto v___jp_2230_;
}
case 1:
{
lean_object* v___x_2248_; 
v___x_2248_ = lean_unsigned_to_nat(2u);
v___y_2231_ = v___y_2244_;
v___y_2232_ = v___x_2246_;
v___y_2233_ = v___x_2247_;
v___y_2234_ = v_coefficients_2245_;
v___y_2235_ = v___x_2248_;
goto v___jp_2230_;
}
default: 
{
lean_object* v___x_2249_; 
v___x_2249_ = lean_unsigned_to_nat(4u);
v___y_2231_ = v___y_2244_;
v___y_2232_ = v___x_2246_;
v___y_2233_ = v___x_2247_;
v___y_2234_ = v_coefficients_2245_;
v___y_2235_ = v___x_2249_;
goto v___jp_2230_;
}
}
}
v___jp_2250_:
{
uint64_t v___x_2253_; uint64_t v___x_2254_; uint64_t v___x_2255_; uint64_t v___x_2256_; 
v___x_2253_ = lean_uint8_to_uint64(v___y_2252_);
v___x_2254_ = 8ULL;
v___x_2255_ = lean_uint64_shift_left(v___x_2253_, v___x_2254_);
v___x_2256_ = lean_uint64_lor(v___y_2251_, v___x_2255_);
v___y_2244_ = v___x_2256_;
goto v___jp_2243_;
}
v___jp_2257_:
{
uint64_t v___x_2260_; uint64_t v___x_2261_; uint64_t v___x_2262_; uint64_t v___x_2263_; 
v___x_2260_ = lean_uint8_to_uint64(v___y_2259_);
v___x_2261_ = 24ULL;
v___x_2262_ = lean_uint64_shift_left(v___x_2260_, v___x_2261_);
v___x_2263_ = lean_uint64_lor(v___y_2258_, v___x_2262_);
v___y_2244_ = v___x_2263_;
goto v___jp_2243_;
}
v___jp_2264_:
{
uint64_t v___x_2270_; uint64_t v___x_2271_; uint64_t v___x_2272_; uint64_t v___x_2273_; lean_object* v___x_2274_; lean_object* v___x_2275_; uint8_t v___x_2276_; 
v___x_2270_ = lean_uint8_to_uint64(v___y_2269_);
v___x_2271_ = 16ULL;
v___x_2272_ = lean_uint64_shift_left(v___x_2270_, v___x_2271_);
v___x_2273_ = lean_uint64_lor(v___y_2267_, v___x_2272_);
v___x_2274_ = lean_unsigned_to_nat(3u);
v___x_2275_ = lean_nat_add(v___y_2268_, v___x_2274_);
lean_dec(v___y_2268_);
v___x_2276_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2266_, v___x_2275_);
if (v___x_2276_ == 0)
{
lean_object* v___x_2277_; lean_object* v___x_2278_; uint8_t v___x_2279_; 
lean_dec(v___x_2275_);
v___x_2277_ = lean_box(v___y_2265_);
v___x_2278_ = l_outOfBounds___redArg(v___x_2277_);
lean_dec(v___x_2277_);
v___x_2279_ = lean_unbox(v___x_2278_);
lean_dec(v___x_2278_);
v___y_2258_ = v___x_2273_;
v___y_2259_ = v___x_2279_;
goto v___jp_2257_;
}
else
{
uint8_t v___x_2280_; 
v___x_2280_ = lean_byte_array_fget(v___y_2266_, v___x_2275_);
lean_dec(v___x_2275_);
v___y_2258_ = v___x_2273_;
v___y_2259_ = v___x_2280_;
goto v___jp_2257_;
}
}
v___jp_2281_:
{
uint64_t v___x_2287_; uint64_t v___x_2288_; uint64_t v___x_2289_; uint64_t v___x_2290_; lean_object* v___x_2291_; lean_object* v___x_2292_; uint8_t v___x_2293_; 
v___x_2287_ = lean_uint8_to_uint64(v___y_2286_);
v___x_2288_ = 8ULL;
v___x_2289_ = lean_uint64_shift_left(v___x_2287_, v___x_2288_);
v___x_2290_ = lean_uint64_lor(v___y_2285_, v___x_2289_);
v___x_2291_ = lean_unsigned_to_nat(2u);
v___x_2292_ = lean_nat_add(v___y_2284_, v___x_2291_);
v___x_2293_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2283_, v___x_2292_);
if (v___x_2293_ == 0)
{
lean_object* v___x_2294_; lean_object* v___x_2295_; uint8_t v___x_2296_; 
lean_dec(v___x_2292_);
v___x_2294_ = lean_box(v___y_2282_);
v___x_2295_ = l_outOfBounds___redArg(v___x_2294_);
lean_dec(v___x_2294_);
v___x_2296_ = lean_unbox(v___x_2295_);
lean_dec(v___x_2295_);
v___y_2265_ = v___y_2282_;
v___y_2266_ = v___y_2283_;
v___y_2267_ = v___x_2290_;
v___y_2268_ = v___y_2284_;
v___y_2269_ = v___x_2296_;
goto v___jp_2264_;
}
else
{
uint8_t v___x_2297_; 
v___x_2297_ = lean_byte_array_fget(v___y_2283_, v___x_2292_);
lean_dec(v___x_2292_);
v___y_2265_ = v___y_2282_;
v___y_2266_ = v___y_2283_;
v___y_2267_ = v___x_2290_;
v___y_2268_ = v___y_2284_;
v___y_2269_ = v___x_2297_;
goto v___jp_2264_;
}
}
v___jp_2298_:
{
uint64_t v_a_2304_; 
v_a_2304_ = lean_uint8_to_uint64(v___y_2303_);
switch(v___y_2302_)
{
case 0:
{
lean_dec(v___y_2301_);
v___y_2244_ = v_a_2304_;
goto v___jp_2243_;
}
case 1:
{
lean_object* v___x_2305_; uint8_t v___x_2306_; 
v___x_2305_ = lean_nat_add(v___y_2301_, v___x_1499_);
lean_dec(v___y_2301_);
v___x_2306_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2300_, v___x_2305_);
if (v___x_2306_ == 0)
{
lean_object* v___x_2307_; lean_object* v___x_2308_; uint8_t v___x_2309_; 
lean_dec(v___x_2305_);
v___x_2307_ = lean_box(v___y_2299_);
v___x_2308_ = l_outOfBounds___redArg(v___x_2307_);
lean_dec(v___x_2307_);
v___x_2309_ = lean_unbox(v___x_2308_);
lean_dec(v___x_2308_);
v___y_2251_ = v_a_2304_;
v___y_2252_ = v___x_2309_;
goto v___jp_2250_;
}
else
{
uint8_t v___x_2310_; 
v___x_2310_ = lean_byte_array_fget(v___y_2300_, v___x_2305_);
lean_dec(v___x_2305_);
v___y_2251_ = v_a_2304_;
v___y_2252_ = v___x_2310_;
goto v___jp_2250_;
}
}
default: 
{
lean_object* v___x_2311_; uint8_t v___x_2312_; 
v___x_2311_ = lean_nat_add(v___y_2301_, v___x_1499_);
v___x_2312_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2300_, v___x_2311_);
if (v___x_2312_ == 0)
{
lean_object* v___x_2313_; lean_object* v___x_2314_; uint8_t v___x_2315_; 
lean_dec(v___x_2311_);
v___x_2313_ = lean_box(v___y_2299_);
v___x_2314_ = l_outOfBounds___redArg(v___x_2313_);
lean_dec(v___x_2313_);
v___x_2315_ = lean_unbox(v___x_2314_);
lean_dec(v___x_2314_);
v___y_2282_ = v___y_2299_;
v___y_2283_ = v___y_2300_;
v___y_2284_ = v___y_2301_;
v___y_2285_ = v_a_2304_;
v___y_2286_ = v___x_2315_;
goto v___jp_2281_;
}
else
{
uint8_t v___x_2316_; 
v___x_2316_ = lean_byte_array_fget(v___y_2300_, v___x_2311_);
lean_dec(v___x_2311_);
v___y_2282_ = v___y_2299_;
v___y_2283_ = v___y_2300_;
v___y_2284_ = v___y_2301_;
v___y_2285_ = v_a_2304_;
v___y_2286_ = v___x_2316_;
goto v___jp_2281_;
}
}
}
}
v___jp_2317_:
{
if (v___y_2322_ == 0)
{
uint8_t v___x_2323_; 
v___x_2323_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2319_, v___y_2320_);
if (v___x_2323_ == 0)
{
lean_object* v___x_2324_; lean_object* v___x_2325_; uint8_t v___x_2326_; 
v___x_2324_ = lean_box(v___y_2318_);
v___x_2325_ = l_outOfBounds___redArg(v___x_2324_);
lean_dec(v___x_2324_);
v___x_2326_ = lean_unbox(v___x_2325_);
lean_dec(v___x_2325_);
v___y_2299_ = v___y_2318_;
v___y_2300_ = v___y_2319_;
v___y_2301_ = v___y_2320_;
v___y_2302_ = v___y_2321_;
v___y_2303_ = v___x_2326_;
goto v___jp_2298_;
}
else
{
uint8_t v___x_2327_; 
v___x_2327_ = lean_byte_array_fget(v___y_2319_, v___y_2320_);
v___y_2299_ = v___y_2318_;
v___y_2300_ = v___y_2319_;
v___y_2301_ = v___y_2320_;
v___y_2302_ = v___y_2321_;
v___y_2303_ = v___x_2327_;
goto v___jp_2298_;
}
}
else
{
size_t v_pos_2328_; uint8_t v___x_2329_; uint64_t v_a_2330_; 
v_pos_2328_ = lean_usize_of_nat(v___y_2320_);
lean_dec(v___y_2320_);
v___x_2329_ = lean_byte_array_uget(v___y_2319_, v_pos_2328_);
v_a_2330_ = lean_uint8_to_uint64(v___x_2329_);
switch(v___y_2321_)
{
case 0:
{
v___y_2244_ = v_a_2330_;
goto v___jp_2243_;
}
case 1:
{
size_t v___x_2331_; size_t v___x_2332_; uint8_t v___x_2333_; uint64_t v___x_2334_; uint64_t v___x_2335_; uint64_t v___x_2336_; uint64_t v___x_2337_; 
v___x_2331_ = ((size_t)1ULL);
v___x_2332_ = lean_usize_add(v_pos_2328_, v___x_2331_);
v___x_2333_ = lean_byte_array_uget(v___y_2319_, v___x_2332_);
v___x_2334_ = lean_uint8_to_uint64(v___x_2333_);
v___x_2335_ = 8ULL;
v___x_2336_ = lean_uint64_shift_left(v___x_2334_, v___x_2335_);
v___x_2337_ = lean_uint64_lor(v_a_2330_, v___x_2336_);
v___y_2244_ = v___x_2337_;
goto v___jp_2243_;
}
default: 
{
size_t v___x_2338_; size_t v___x_2339_; uint8_t v___x_2340_; uint64_t v___x_2341_; uint64_t v___x_2342_; uint64_t v___x_2343_; uint64_t v___x_2344_; size_t v___x_2345_; size_t v___x_2346_; uint8_t v___x_2347_; uint64_t v___x_2348_; uint64_t v___x_2349_; uint64_t v___x_2350_; uint64_t v___x_2351_; size_t v___x_2352_; size_t v___x_2353_; uint8_t v___x_2354_; uint64_t v___x_2355_; uint64_t v___x_2356_; uint64_t v___x_2357_; uint64_t v___x_2358_; 
v___x_2338_ = ((size_t)1ULL);
v___x_2339_ = lean_usize_add(v_pos_2328_, v___x_2338_);
v___x_2340_ = lean_byte_array_uget(v___y_2319_, v___x_2339_);
v___x_2341_ = lean_uint8_to_uint64(v___x_2340_);
v___x_2342_ = 8ULL;
v___x_2343_ = lean_uint64_shift_left(v___x_2341_, v___x_2342_);
v___x_2344_ = lean_uint64_lor(v_a_2330_, v___x_2343_);
v___x_2345_ = ((size_t)2ULL);
v___x_2346_ = lean_usize_add(v_pos_2328_, v___x_2345_);
v___x_2347_ = lean_byte_array_uget(v___y_2319_, v___x_2346_);
v___x_2348_ = lean_uint8_to_uint64(v___x_2347_);
v___x_2349_ = 16ULL;
v___x_2350_ = lean_uint64_shift_left(v___x_2348_, v___x_2349_);
v___x_2351_ = lean_uint64_lor(v___x_2344_, v___x_2350_);
v___x_2352_ = ((size_t)3ULL);
v___x_2353_ = lean_usize_add(v_pos_2328_, v___x_2352_);
v___x_2354_ = lean_byte_array_uget(v___y_2319_, v___x_2353_);
v___x_2355_ = lean_uint8_to_uint64(v___x_2354_);
v___x_2356_ = 24ULL;
v___x_2357_ = lean_uint64_shift_left(v___x_2355_, v___x_2356_);
v___x_2358_ = lean_uint64_lor(v___x_2351_, v___x_2357_);
v___y_2244_ = v___x_2358_;
goto v___jp_2243_;
}
}
}
}
v___jp_2359_:
{
lean_object* v_offset_2364_; lean_object* v___x_2365_; lean_object* v___x_2366_; uint8_t v___x_2367_; 
v_offset_2364_ = lean_nat_mul(v_fst_1494_, v___y_2363_);
v___x_2365_ = lean_nat_add(v_offset_2364_, v___y_2363_);
v___x_2366_ = lean_byte_array_size(v___y_2361_);
v___x_2367_ = lean_nat_dec_le(v___x_2365_, v___x_2366_);
if (v___x_2367_ == 0)
{
lean_dec(v___x_2365_);
v___y_2318_ = v___y_2360_;
v___y_2319_ = v___y_2361_;
v___y_2320_ = v_offset_2364_;
v___y_2321_ = v___y_2362_;
v___y_2322_ = v___x_2367_;
goto v___jp_2317_;
}
else
{
size_t v___x_2368_; lean_object* v___x_2369_; uint8_t v___x_2370_; 
v___x_2368_ = lean_usize_of_nat(v___x_2365_);
v___x_2369_ = lean_usize_to_nat(v___x_2368_);
v___x_2370_ = lean_nat_dec_eq(v___x_2369_, v___x_2365_);
lean_dec(v___x_2365_);
lean_dec(v___x_2369_);
v___y_2318_ = v___y_2360_;
v___y_2319_ = v___y_2361_;
v___y_2320_ = v_offset_2364_;
v___y_2321_ = v___y_2362_;
v___y_2322_ = v___x_2370_;
goto v___jp_2317_;
}
}
v___jp_2371_:
{
uint8_t v___x_2375_; 
v___x_2375_ = lp_Hex_Hex_Groebner_MonomialTable_compare(v_table_1474_, v___y_2373_, v___y_2372_, v___y_2374_);
lean_dec(v___y_2374_);
lean_dec(v___y_2372_);
switch(v___x_2375_)
{
case 0:
{
goto v___jp_1736_;
}
case 1:
{
lean_object* v_coefficients_2376_; uint8_t v___x_2377_; uint8_t v___x_2378_; 
lean_del_object(v___x_1497_);
lean_del_object(v___x_1492_);
v_coefficients_2376_ = lean_ctor_get(v_p_1470_, 1);
v___x_2377_ = lp_Hex_Hex_Groebner_PrimeField_width(v___x_1468_);
v___x_2378_ = 0;
switch(v___x_2377_)
{
case 0:
{
v___y_2360_ = v___x_2378_;
v___y_2361_ = v_coefficients_2376_;
v___y_2362_ = v___x_2377_;
v___y_2363_ = v___x_1499_;
goto v___jp_2359_;
}
case 1:
{
lean_object* v___x_2379_; 
v___x_2379_ = lean_unsigned_to_nat(2u);
v___y_2360_ = v___x_2378_;
v___y_2361_ = v_coefficients_2376_;
v___y_2362_ = v___x_2377_;
v___y_2363_ = v___x_2379_;
goto v___jp_2359_;
}
default: 
{
lean_object* v___x_2380_; 
v___x_2380_ = lean_unsigned_to_nat(4u);
v___y_2360_ = v___x_2378_;
v___y_2361_ = v_coefficients_2376_;
v___y_2362_ = v___x_2377_;
v___y_2363_ = v___x_2380_;
goto v___jp_2359_;
}
}
}
default: 
{
lean_del_object(v___x_1497_);
lean_del_object(v___x_1492_);
goto v___jp_1978_;
}
}
}
v___jp_2381_:
{
uint64_t v___x_2386_; uint64_t v___x_2387_; uint64_t v___x_2388_; uint64_t v___x_2389_; lean_object* v___x_2390_; 
v___x_2386_ = lean_uint8_to_uint64(v___y_2385_);
v___x_2387_ = 24ULL;
v___x_2388_ = lean_uint64_shift_left(v___x_2386_, v___x_2387_);
v___x_2389_ = lean_uint64_lor(v___y_2382_, v___x_2388_);
v___x_2390_ = lean_uint64_to_nat(v___x_2389_);
v___y_2372_ = v___y_2383_;
v___y_2373_ = v___y_2384_;
v___y_2374_ = v___x_2390_;
goto v___jp_2371_;
}
v___jp_2391_:
{
uint64_t v___x_2399_; uint64_t v___x_2400_; uint64_t v___x_2401_; uint64_t v___x_2402_; lean_object* v___x_2403_; lean_object* v___x_2404_; uint8_t v___x_2405_; 
v___x_2399_ = lean_uint8_to_uint64(v___y_2398_);
v___x_2400_ = 16ULL;
v___x_2401_ = lean_uint64_shift_left(v___x_2399_, v___x_2400_);
v___x_2402_ = lean_uint64_lor(v___y_2395_, v___x_2401_);
v___x_2403_ = lean_unsigned_to_nat(3u);
v___x_2404_ = lean_nat_add(v___y_2396_, v___x_2403_);
lean_dec(v___y_2396_);
v___x_2405_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2392_, v___x_2404_);
if (v___x_2405_ == 0)
{
lean_object* v___x_2406_; lean_object* v___x_2407_; uint8_t v___x_2408_; 
lean_dec(v___x_2404_);
v___x_2406_ = lean_box(v___y_2394_);
v___x_2407_ = l_outOfBounds___redArg(v___x_2406_);
lean_dec(v___x_2406_);
v___x_2408_ = lean_unbox(v___x_2407_);
lean_dec(v___x_2407_);
v___y_2382_ = v___x_2402_;
v___y_2383_ = v___y_2393_;
v___y_2384_ = v___y_2397_;
v___y_2385_ = v___x_2408_;
goto v___jp_2381_;
}
else
{
uint8_t v___x_2409_; 
v___x_2409_ = lean_byte_array_fget(v___y_2392_, v___x_2404_);
lean_dec(v___x_2404_);
v___y_2382_ = v___x_2402_;
v___y_2383_ = v___y_2393_;
v___y_2384_ = v___y_2397_;
v___y_2385_ = v___x_2409_;
goto v___jp_2381_;
}
}
v___jp_2410_:
{
uint64_t v___x_2418_; uint64_t v___x_2419_; uint64_t v___x_2420_; uint64_t v___x_2421_; lean_object* v___x_2422_; lean_object* v___x_2423_; uint8_t v___x_2424_; 
v___x_2418_ = lean_uint8_to_uint64(v___y_2417_);
v___x_2419_ = 8ULL;
v___x_2420_ = lean_uint64_shift_left(v___x_2418_, v___x_2419_);
v___x_2421_ = lean_uint64_lor(v___y_2416_, v___x_2420_);
v___x_2422_ = lean_unsigned_to_nat(2u);
v___x_2423_ = lean_nat_add(v___y_2415_, v___x_2422_);
v___x_2424_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2411_, v___x_2423_);
if (v___x_2424_ == 0)
{
lean_object* v___x_2425_; lean_object* v___x_2426_; uint8_t v___x_2427_; 
lean_dec(v___x_2423_);
v___x_2425_ = lean_box(v___y_2413_);
v___x_2426_ = l_outOfBounds___redArg(v___x_2425_);
lean_dec(v___x_2425_);
v___x_2427_ = lean_unbox(v___x_2426_);
lean_dec(v___x_2426_);
v___y_2392_ = v___y_2411_;
v___y_2393_ = v___y_2412_;
v___y_2394_ = v___y_2413_;
v___y_2395_ = v___x_2421_;
v___y_2396_ = v___y_2415_;
v___y_2397_ = v___y_2414_;
v___y_2398_ = v___x_2427_;
goto v___jp_2391_;
}
else
{
uint8_t v___x_2428_; 
v___x_2428_ = lean_byte_array_fget(v___y_2411_, v___x_2423_);
lean_dec(v___x_2423_);
v___y_2392_ = v___y_2411_;
v___y_2393_ = v___y_2412_;
v___y_2394_ = v___y_2413_;
v___y_2395_ = v___x_2421_;
v___y_2396_ = v___y_2415_;
v___y_2397_ = v___y_2414_;
v___y_2398_ = v___x_2428_;
goto v___jp_2391_;
}
}
v___jp_2429_:
{
uint64_t v_a_2436_; lean_object* v___x_2437_; uint8_t v___x_2438_; 
v_a_2436_ = lean_uint8_to_uint64(v___y_2435_);
v___x_2437_ = lean_nat_add(v___y_2433_, v___x_1499_);
v___x_2438_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2430_, v___x_2437_);
if (v___x_2438_ == 0)
{
lean_object* v___x_2439_; lean_object* v___x_2440_; uint8_t v___x_2441_; 
lean_dec(v___x_2437_);
v___x_2439_ = lean_box(v___y_2432_);
v___x_2440_ = l_outOfBounds___redArg(v___x_2439_);
lean_dec(v___x_2439_);
v___x_2441_ = lean_unbox(v___x_2440_);
lean_dec(v___x_2440_);
v___y_2411_ = v___y_2430_;
v___y_2412_ = v___y_2431_;
v___y_2413_ = v___y_2432_;
v___y_2414_ = v___y_2434_;
v___y_2415_ = v___y_2433_;
v___y_2416_ = v_a_2436_;
v___y_2417_ = v___x_2441_;
goto v___jp_2410_;
}
else
{
uint8_t v___x_2442_; 
v___x_2442_ = lean_byte_array_fget(v___y_2430_, v___x_2437_);
lean_dec(v___x_2437_);
v___y_2411_ = v___y_2430_;
v___y_2412_ = v___y_2431_;
v___y_2413_ = v___y_2432_;
v___y_2414_ = v___y_2434_;
v___y_2415_ = v___y_2433_;
v___y_2416_ = v_a_2436_;
v___y_2417_ = v___x_2442_;
goto v___jp_2410_;
}
}
v___jp_2443_:
{
if (v___y_2449_ == 0)
{
uint8_t v___x_2450_; 
v___x_2450_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2444_, v___y_2448_);
if (v___x_2450_ == 0)
{
lean_object* v___x_2451_; lean_object* v___x_2452_; uint8_t v___x_2453_; 
v___x_2451_ = lean_box(v___y_2446_);
v___x_2452_ = l_outOfBounds___redArg(v___x_2451_);
lean_dec(v___x_2451_);
v___x_2453_ = lean_unbox(v___x_2452_);
lean_dec(v___x_2452_);
v___y_2430_ = v___y_2444_;
v___y_2431_ = v___y_2445_;
v___y_2432_ = v___y_2446_;
v___y_2433_ = v___y_2448_;
v___y_2434_ = v___y_2447_;
v___y_2435_ = v___x_2453_;
goto v___jp_2429_;
}
else
{
uint8_t v___x_2454_; 
v___x_2454_ = lean_byte_array_fget(v___y_2444_, v___y_2448_);
v___y_2430_ = v___y_2444_;
v___y_2431_ = v___y_2445_;
v___y_2432_ = v___y_2446_;
v___y_2433_ = v___y_2448_;
v___y_2434_ = v___y_2447_;
v___y_2435_ = v___x_2454_;
goto v___jp_2429_;
}
}
else
{
size_t v_pos_2455_; uint8_t v___x_2456_; uint64_t v_a_2457_; size_t v___x_2458_; size_t v___x_2459_; uint8_t v___x_2460_; uint64_t v___x_2461_; uint64_t v___x_2462_; uint64_t v___x_2463_; uint64_t v___x_2464_; size_t v___x_2465_; size_t v___x_2466_; uint8_t v___x_2467_; uint64_t v___x_2468_; uint64_t v___x_2469_; uint64_t v___x_2470_; uint64_t v___x_2471_; size_t v___x_2472_; size_t v___x_2473_; uint8_t v___x_2474_; uint64_t v___x_2475_; uint64_t v___x_2476_; uint64_t v___x_2477_; uint64_t v___x_2478_; lean_object* v___x_2479_; 
v_pos_2455_ = lean_usize_of_nat(v___y_2448_);
lean_dec(v___y_2448_);
v___x_2456_ = lean_byte_array_uget(v___y_2444_, v_pos_2455_);
v_a_2457_ = lean_uint8_to_uint64(v___x_2456_);
v___x_2458_ = ((size_t)1ULL);
v___x_2459_ = lean_usize_add(v_pos_2455_, v___x_2458_);
v___x_2460_ = lean_byte_array_uget(v___y_2444_, v___x_2459_);
v___x_2461_ = lean_uint8_to_uint64(v___x_2460_);
v___x_2462_ = 8ULL;
v___x_2463_ = lean_uint64_shift_left(v___x_2461_, v___x_2462_);
v___x_2464_ = lean_uint64_lor(v_a_2457_, v___x_2463_);
v___x_2465_ = ((size_t)2ULL);
v___x_2466_ = lean_usize_add(v_pos_2455_, v___x_2465_);
v___x_2467_ = lean_byte_array_uget(v___y_2444_, v___x_2466_);
v___x_2468_ = lean_uint8_to_uint64(v___x_2467_);
v___x_2469_ = 16ULL;
v___x_2470_ = lean_uint64_shift_left(v___x_2468_, v___x_2469_);
v___x_2471_ = lean_uint64_lor(v___x_2464_, v___x_2470_);
v___x_2472_ = ((size_t)3ULL);
v___x_2473_ = lean_usize_add(v_pos_2455_, v___x_2472_);
v___x_2474_ = lean_byte_array_uget(v___y_2444_, v___x_2473_);
v___x_2475_ = lean_uint8_to_uint64(v___x_2474_);
v___x_2476_ = 24ULL;
v___x_2477_ = lean_uint64_shift_left(v___x_2475_, v___x_2476_);
v___x_2478_ = lean_uint64_lor(v___x_2471_, v___x_2477_);
v___x_2479_ = lean_uint64_to_nat(v___x_2478_);
v___y_2372_ = v___y_2445_;
v___y_2373_ = v___y_2447_;
v___y_2374_ = v___x_2479_;
goto v___jp_2371_;
}
}
v___jp_2480_:
{
lean_object* v_support_2483_; uint8_t v___x_2484_; lean_object* v___x_2485_; lean_object* v_offset_2486_; lean_object* v___x_2487_; lean_object* v___x_2488_; uint8_t v___x_2489_; 
v_support_2483_ = lean_ctor_get(v_q_1469_, 0);
v___x_2484_ = 0;
v___x_2485_ = lean_unsigned_to_nat(4u);
v_offset_2486_ = lean_nat_mul(v_snd_1495_, v___x_2485_);
v___x_2487_ = lean_nat_add(v_offset_2486_, v___x_2485_);
v___x_2488_ = lean_byte_array_size(v_support_2483_);
v___x_2489_ = lean_nat_dec_le(v___x_2487_, v___x_2488_);
if (v___x_2489_ == 0)
{
lean_dec(v___x_2487_);
v___y_2444_ = v_support_2483_;
v___y_2445_ = v___y_2482_;
v___y_2446_ = v___x_2484_;
v___y_2447_ = v___y_2481_;
v___y_2448_ = v_offset_2486_;
v___y_2449_ = v___x_2489_;
goto v___jp_2443_;
}
else
{
size_t v___x_2490_; lean_object* v___x_2491_; uint8_t v___x_2492_; 
v___x_2490_ = lean_usize_of_nat(v___x_2487_);
v___x_2491_ = lean_usize_to_nat(v___x_2490_);
v___x_2492_ = lean_nat_dec_eq(v___x_2491_, v___x_2487_);
lean_dec(v___x_2487_);
lean_dec(v___x_2491_);
v___y_2444_ = v_support_2483_;
v___y_2445_ = v___y_2482_;
v___y_2446_ = v___x_2484_;
v___y_2447_ = v___y_2481_;
v___y_2448_ = v_offset_2486_;
v___y_2449_ = v___x_2492_;
goto v___jp_2443_;
}
}
v___jp_2493_:
{
uint64_t v___x_2497_; uint64_t v___x_2498_; uint64_t v___x_2499_; uint64_t v___x_2500_; lean_object* v___x_2501_; 
v___x_2497_ = lean_uint8_to_uint64(v___y_2496_);
v___x_2498_ = 24ULL;
v___x_2499_ = lean_uint64_shift_left(v___x_2497_, v___x_2498_);
v___x_2500_ = lean_uint64_lor(v___y_2494_, v___x_2499_);
v___x_2501_ = lean_uint64_to_nat(v___x_2500_);
v___y_2481_ = v___y_2495_;
v___y_2482_ = v___x_2501_;
goto v___jp_2480_;
}
v___jp_2502_:
{
uint64_t v___x_2509_; uint64_t v___x_2510_; uint64_t v___x_2511_; uint64_t v___x_2512_; lean_object* v___x_2513_; lean_object* v___x_2514_; uint8_t v___x_2515_; 
v___x_2509_ = lean_uint8_to_uint64(v___y_2508_);
v___x_2510_ = 16ULL;
v___x_2511_ = lean_uint64_shift_left(v___x_2509_, v___x_2510_);
v___x_2512_ = lean_uint64_lor(v___y_2504_, v___x_2511_);
v___x_2513_ = lean_unsigned_to_nat(3u);
v___x_2514_ = lean_nat_add(v___y_2503_, v___x_2513_);
lean_dec(v___y_2503_);
v___x_2515_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2505_, v___x_2514_);
if (v___x_2515_ == 0)
{
lean_object* v___x_2516_; lean_object* v___x_2517_; uint8_t v___x_2518_; 
lean_dec(v___x_2514_);
v___x_2516_ = lean_box(v___y_2506_);
v___x_2517_ = l_outOfBounds___redArg(v___x_2516_);
lean_dec(v___x_2516_);
v___x_2518_ = lean_unbox(v___x_2517_);
lean_dec(v___x_2517_);
v___y_2494_ = v___x_2512_;
v___y_2495_ = v___y_2507_;
v___y_2496_ = v___x_2518_;
goto v___jp_2493_;
}
else
{
uint8_t v___x_2519_; 
v___x_2519_ = lean_byte_array_fget(v___y_2505_, v___x_2514_);
lean_dec(v___x_2514_);
v___y_2494_ = v___x_2512_;
v___y_2495_ = v___y_2507_;
v___y_2496_ = v___x_2519_;
goto v___jp_2493_;
}
}
v___jp_2520_:
{
uint64_t v___x_2527_; uint64_t v___x_2528_; uint64_t v___x_2529_; uint64_t v___x_2530_; lean_object* v___x_2531_; lean_object* v___x_2532_; uint8_t v___x_2533_; 
v___x_2527_ = lean_uint8_to_uint64(v___y_2526_);
v___x_2528_ = 8ULL;
v___x_2529_ = lean_uint64_shift_left(v___x_2527_, v___x_2528_);
v___x_2530_ = lean_uint64_lor(v___y_2523_, v___x_2529_);
v___x_2531_ = lean_unsigned_to_nat(2u);
v___x_2532_ = lean_nat_add(v___y_2521_, v___x_2531_);
v___x_2533_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2522_, v___x_2532_);
if (v___x_2533_ == 0)
{
lean_object* v___x_2534_; lean_object* v___x_2535_; uint8_t v___x_2536_; 
lean_dec(v___x_2532_);
v___x_2534_ = lean_box(v___y_2524_);
v___x_2535_ = l_outOfBounds___redArg(v___x_2534_);
lean_dec(v___x_2534_);
v___x_2536_ = lean_unbox(v___x_2535_);
lean_dec(v___x_2535_);
v___y_2503_ = v___y_2521_;
v___y_2504_ = v___x_2530_;
v___y_2505_ = v___y_2522_;
v___y_2506_ = v___y_2524_;
v___y_2507_ = v___y_2525_;
v___y_2508_ = v___x_2536_;
goto v___jp_2502_;
}
else
{
uint8_t v___x_2537_; 
v___x_2537_ = lean_byte_array_fget(v___y_2522_, v___x_2532_);
lean_dec(v___x_2532_);
v___y_2503_ = v___y_2521_;
v___y_2504_ = v___x_2530_;
v___y_2505_ = v___y_2522_;
v___y_2506_ = v___y_2524_;
v___y_2507_ = v___y_2525_;
v___y_2508_ = v___x_2537_;
goto v___jp_2502_;
}
}
v___jp_2538_:
{
uint64_t v_a_2544_; lean_object* v___x_2545_; uint8_t v___x_2546_; 
v_a_2544_ = lean_uint8_to_uint64(v___y_2543_);
v___x_2545_ = lean_nat_add(v___y_2539_, v___x_1499_);
v___x_2546_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2540_, v___x_2545_);
if (v___x_2546_ == 0)
{
lean_object* v___x_2547_; lean_object* v___x_2548_; uint8_t v___x_2549_; 
lean_dec(v___x_2545_);
v___x_2547_ = lean_box(v___y_2541_);
v___x_2548_ = l_outOfBounds___redArg(v___x_2547_);
lean_dec(v___x_2547_);
v___x_2549_ = lean_unbox(v___x_2548_);
lean_dec(v___x_2548_);
v___y_2521_ = v___y_2539_;
v___y_2522_ = v___y_2540_;
v___y_2523_ = v_a_2544_;
v___y_2524_ = v___y_2541_;
v___y_2525_ = v___y_2542_;
v___y_2526_ = v___x_2549_;
goto v___jp_2520_;
}
else
{
uint8_t v___x_2550_; 
v___x_2550_ = lean_byte_array_fget(v___y_2540_, v___x_2545_);
lean_dec(v___x_2545_);
v___y_2521_ = v___y_2539_;
v___y_2522_ = v___y_2540_;
v___y_2523_ = v_a_2544_;
v___y_2524_ = v___y_2541_;
v___y_2525_ = v___y_2542_;
v___y_2526_ = v___x_2550_;
goto v___jp_2520_;
}
}
v___jp_2551_:
{
if (v___y_2556_ == 0)
{
uint8_t v___x_2557_; 
v___x_2557_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2553_, v___y_2552_);
if (v___x_2557_ == 0)
{
lean_object* v___x_2558_; lean_object* v___x_2559_; uint8_t v___x_2560_; 
v___x_2558_ = lean_box(v___y_2554_);
v___x_2559_ = l_outOfBounds___redArg(v___x_2558_);
lean_dec(v___x_2558_);
v___x_2560_ = lean_unbox(v___x_2559_);
lean_dec(v___x_2559_);
v___y_2539_ = v___y_2552_;
v___y_2540_ = v___y_2553_;
v___y_2541_ = v___y_2554_;
v___y_2542_ = v___y_2555_;
v___y_2543_ = v___x_2560_;
goto v___jp_2538_;
}
else
{
uint8_t v___x_2561_; 
v___x_2561_ = lean_byte_array_fget(v___y_2553_, v___y_2552_);
v___y_2539_ = v___y_2552_;
v___y_2540_ = v___y_2553_;
v___y_2541_ = v___y_2554_;
v___y_2542_ = v___y_2555_;
v___y_2543_ = v___x_2561_;
goto v___jp_2538_;
}
}
else
{
size_t v_pos_2562_; uint8_t v___x_2563_; uint64_t v_a_2564_; size_t v___x_2565_; size_t v___x_2566_; uint8_t v___x_2567_; uint64_t v___x_2568_; uint64_t v___x_2569_; uint64_t v___x_2570_; uint64_t v___x_2571_; size_t v___x_2572_; size_t v___x_2573_; uint8_t v___x_2574_; uint64_t v___x_2575_; uint64_t v___x_2576_; uint64_t v___x_2577_; uint64_t v___x_2578_; size_t v___x_2579_; size_t v___x_2580_; uint8_t v___x_2581_; uint64_t v___x_2582_; uint64_t v___x_2583_; uint64_t v___x_2584_; uint64_t v___x_2585_; lean_object* v___x_2586_; 
v_pos_2562_ = lean_usize_of_nat(v___y_2552_);
lean_dec(v___y_2552_);
v___x_2563_ = lean_byte_array_uget(v___y_2553_, v_pos_2562_);
v_a_2564_ = lean_uint8_to_uint64(v___x_2563_);
v___x_2565_ = ((size_t)1ULL);
v___x_2566_ = lean_usize_add(v_pos_2562_, v___x_2565_);
v___x_2567_ = lean_byte_array_uget(v___y_2553_, v___x_2566_);
v___x_2568_ = lean_uint8_to_uint64(v___x_2567_);
v___x_2569_ = 8ULL;
v___x_2570_ = lean_uint64_shift_left(v___x_2568_, v___x_2569_);
v___x_2571_ = lean_uint64_lor(v_a_2564_, v___x_2570_);
v___x_2572_ = ((size_t)2ULL);
v___x_2573_ = lean_usize_add(v_pos_2562_, v___x_2572_);
v___x_2574_ = lean_byte_array_uget(v___y_2553_, v___x_2573_);
v___x_2575_ = lean_uint8_to_uint64(v___x_2574_);
v___x_2576_ = 16ULL;
v___x_2577_ = lean_uint64_shift_left(v___x_2575_, v___x_2576_);
v___x_2578_ = lean_uint64_lor(v___x_2571_, v___x_2577_);
v___x_2579_ = ((size_t)3ULL);
v___x_2580_ = lean_usize_add(v_pos_2562_, v___x_2579_);
v___x_2581_ = lean_byte_array_uget(v___y_2553_, v___x_2580_);
v___x_2582_ = lean_uint8_to_uint64(v___x_2581_);
v___x_2583_ = 24ULL;
v___x_2584_ = lean_uint64_shift_left(v___x_2582_, v___x_2583_);
v___x_2585_ = lean_uint64_lor(v___x_2578_, v___x_2584_);
v___x_2586_ = lean_uint64_to_nat(v___x_2585_);
v___y_2481_ = v___y_2555_;
v___y_2482_ = v___x_2586_;
goto v___jp_2480_;
}
}
v___jp_2588_:
{
if (v___x_2587_ == 0)
{
uint8_t v___x_2589_; 
v___x_2589_ = lean_nat_dec_le(v___x_1472_, v_snd_1495_);
if (v___x_2589_ == 0)
{
uint8_t v_order_2590_; lean_object* v_support_2591_; uint8_t v___x_2592_; lean_object* v___x_2593_; lean_object* v_offset_2594_; lean_object* v___x_2595_; lean_object* v___x_2596_; uint8_t v___x_2597_; 
v_order_2590_ = lean_ctor_get_uint8(v_context_1473_, sizeof(void*)*1 + 8);
v_support_2591_ = lean_ctor_get(v_p_1470_, 0);
v___x_2592_ = 0;
v___x_2593_ = lean_unsigned_to_nat(4u);
v_offset_2594_ = lean_nat_mul(v_fst_1494_, v___x_2593_);
v___x_2595_ = lean_nat_add(v_offset_2594_, v___x_2593_);
v___x_2596_ = lean_byte_array_size(v_support_2591_);
v___x_2597_ = lean_nat_dec_le(v___x_2595_, v___x_2596_);
if (v___x_2597_ == 0)
{
lean_dec(v___x_2595_);
v___y_2552_ = v_offset_2594_;
v___y_2553_ = v_support_2591_;
v___y_2554_ = v___x_2592_;
v___y_2555_ = v_order_2590_;
v___y_2556_ = v___x_2597_;
goto v___jp_2551_;
}
else
{
size_t v___x_2598_; lean_object* v___x_2599_; uint8_t v___x_2600_; 
v___x_2598_ = lean_usize_of_nat(v___x_2595_);
v___x_2599_ = lean_usize_to_nat(v___x_2598_);
v___x_2600_ = lean_nat_dec_eq(v___x_2599_, v___x_2595_);
lean_dec(v___x_2595_);
lean_dec(v___x_2599_);
v___y_2552_ = v_offset_2594_;
v___y_2553_ = v_support_2591_;
v___y_2554_ = v___x_2592_;
v___y_2555_ = v_order_2590_;
v___y_2556_ = v___x_2600_;
goto v___jp_2551_;
}
}
else
{
lean_del_object(v___x_1497_);
lean_del_object(v___x_1492_);
goto v___jp_1978_;
}
}
else
{
goto v___jp_1736_;
}
}
}
}
}
v___jp_1481_:
{
lean_object* v___x_1484_; 
v___x_1484_ = lean_nat_add(v_i_1477_, v_step_1480_);
lean_dec(v_i_1477_);
v_b_1476_ = v_a_1482_;
v_i_1477_ = v___x_1484_;
v___y_1478_ = v_snd_1483_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0___redArg___boxed(lean_object* v___x_2608_, lean_object* v_q_2609_, lean_object* v_p_2610_, lean_object* v___x_2611_, lean_object* v___x_2612_, lean_object* v_context_2613_, lean_object* v_table_2614_, lean_object* v_range_2615_, lean_object* v_b_2616_, lean_object* v_i_2617_, lean_object* v___y_2618_){
_start:
{
uint64_t v___x_15905__boxed_2619_; lean_object* v_res_2620_; 
v___x_15905__boxed_2619_ = lean_unbox_uint64(v___x_2608_);
lean_dec_ref(v___x_2608_);
v_res_2620_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0___redArg(v___x_15905__boxed_2619_, v_q_2609_, v_p_2610_, v___x_2611_, v___x_2612_, v_context_2613_, v_table_2614_, v_range_2615_, v_b_2616_, v_i_2617_, v___y_2618_);
lean_dec_ref(v_range_2615_);
lean_dec_ref(v_table_2614_);
lean_dec_ref(v_context_2613_);
lean_dec(v___x_2612_);
lean_dec(v___x_2611_);
lean_dec_ref(v_p_2610_);
lean_dec_ref(v_q_2609_);
return v_res_2620_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_Polynomial_subtract___closed__1(void){
_start:
{
lean_object* v___x_2623_; lean_object* v_result_2624_; lean_object* v___x_2625_; 
v___x_2623_ = ((lean_object*)(lp_Hex_Hex_Groebner_Polynomial_subtract___closed__0));
v_result_2624_ = lean_obj_once(&lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2, &lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2_once, _init_lp_Hex_Hex_Groebner_Polynomial_normalize___closed__2);
v___x_2625_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2625_, 0, v_result_2624_);
lean_ctor_set(v___x_2625_, 1, v___x_2623_);
return v___x_2625_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_subtract(lean_object* v_context_2626_, lean_object* v_limits_2627_, lean_object* v_p_2628_, lean_object* v_q_2629_, lean_object* v_a_2630_){
_start:
{
lean_object* v_statistics_2631_; lean_object* v_support_2632_; lean_object* v_support_2633_; uint64_t v_field_2634_; lean_object* v_variables_2635_; lean_object* v_table_2636_; lean_object* v_work_2637_; lean_object* v_allocatedBytes_2638_; lean_object* v_pairs_2639_; lean_object* v_rounds_2640_; lean_object* v_matrixEntries_2641_; lean_object* v_matrixRows_2642_; lean_object* v_matrixCalls_2643_; lean_object* v_peakMatrixRows_2644_; lean_object* v_peakMatrixEntries_2645_; lean_object* v_largestBatch_2646_; lean_object* v_productPairs_2647_; lean_object* v_chainPairs_2648_; lean_object* v_gmPairs_2649_; lean_object* v___x_2651_; uint8_t v_isShared_2652_; uint8_t v_isSharedCheck_2736_; 
v_statistics_2631_ = lean_ctor_get(v_a_2630_, 1);
lean_inc_ref(v_statistics_2631_);
v_support_2632_ = lean_ctor_get(v_p_2628_, 0);
v_support_2633_ = lean_ctor_get(v_q_2629_, 0);
v_field_2634_ = lean_ctor_get_uint64(v_context_2626_, sizeof(void*)*1);
v_variables_2635_ = lean_ctor_get(v_context_2626_, 0);
v_table_2636_ = lean_ctor_get(v_a_2630_, 0);
v_work_2637_ = lean_ctor_get(v_statistics_2631_, 0);
v_allocatedBytes_2638_ = lean_ctor_get(v_statistics_2631_, 1);
v_pairs_2639_ = lean_ctor_get(v_statistics_2631_, 2);
v_rounds_2640_ = lean_ctor_get(v_statistics_2631_, 3);
v_matrixEntries_2641_ = lean_ctor_get(v_statistics_2631_, 4);
v_matrixRows_2642_ = lean_ctor_get(v_statistics_2631_, 5);
v_matrixCalls_2643_ = lean_ctor_get(v_statistics_2631_, 6);
v_peakMatrixRows_2644_ = lean_ctor_get(v_statistics_2631_, 7);
v_peakMatrixEntries_2645_ = lean_ctor_get(v_statistics_2631_, 8);
v_largestBatch_2646_ = lean_ctor_get(v_statistics_2631_, 9);
v_productPairs_2647_ = lean_ctor_get(v_statistics_2631_, 10);
v_chainPairs_2648_ = lean_ctor_get(v_statistics_2631_, 11);
v_gmPairs_2649_ = lean_ctor_get(v_statistics_2631_, 12);
v_isSharedCheck_2736_ = !lean_is_exclusive(v_statistics_2631_);
if (v_isSharedCheck_2736_ == 0)
{
v___x_2651_ = v_statistics_2631_;
v_isShared_2652_ = v_isSharedCheck_2736_;
goto v_resetjp_2650_;
}
else
{
lean_inc(v_gmPairs_2649_);
lean_inc(v_chainPairs_2648_);
lean_inc(v_productPairs_2647_);
lean_inc(v_largestBatch_2646_);
lean_inc(v_peakMatrixEntries_2645_);
lean_inc(v_peakMatrixRows_2644_);
lean_inc(v_matrixCalls_2643_);
lean_inc(v_matrixRows_2642_);
lean_inc(v_matrixEntries_2641_);
lean_inc(v_rounds_2640_);
lean_inc(v_pairs_2639_);
lean_inc(v_allocatedBytes_2638_);
lean_inc(v_work_2637_);
lean_dec(v_statistics_2631_);
v___x_2651_ = lean_box(0);
v_isShared_2652_ = v_isSharedCheck_2736_;
goto v_resetjp_2650_;
}
v_resetjp_2650_:
{
lean_object* v_work_2653_; lean_object* v___x_2654_; lean_object* v___x_2655_; lean_object* v___x_2656_; lean_object* v___x_2657_; lean_object* v___x_2658_; lean_object* v___x_2659_; lean_object* v___x_2660_; lean_object* v___x_2661_; lean_object* v___x_2662_; lean_object* v_work_2663_; uint8_t v___x_2664_; 
v_work_2653_ = lean_ctor_get(v_limits_2627_, 0);
v___x_2654_ = lean_byte_array_size(v_support_2632_);
v___x_2655_ = lean_unsigned_to_nat(2u);
v___x_2656_ = lean_nat_shiftr(v___x_2654_, v___x_2655_);
v___x_2657_ = lean_byte_array_size(v_support_2633_);
v___x_2658_ = lean_nat_shiftr(v___x_2657_, v___x_2655_);
v___x_2659_ = lean_nat_add(v___x_2656_, v___x_2658_);
v___x_2660_ = lean_unsigned_to_nat(1u);
v___x_2661_ = lean_nat_add(v_variables_2635_, v___x_2660_);
v___x_2662_ = lean_nat_mul(v___x_2659_, v___x_2661_);
lean_dec(v___x_2661_);
v_work_2663_ = lean_nat_add(v_work_2637_, v___x_2662_);
lean_dec(v___x_2662_);
lean_dec(v_work_2637_);
v___x_2664_ = lean_nat_dec_lt(v_work_2653_, v_work_2663_);
if (v___x_2664_ == 0)
{
lean_object* v___x_2666_; uint8_t v_isShared_2667_; uint8_t v_isSharedCheck_2723_; 
lean_inc_ref(v_table_2636_);
v_isSharedCheck_2723_ = !lean_is_exclusive(v_a_2630_);
if (v_isSharedCheck_2723_ == 0)
{
lean_object* v_unused_2724_; lean_object* v_unused_2725_; 
v_unused_2724_ = lean_ctor_get(v_a_2630_, 1);
lean_dec(v_unused_2724_);
v_unused_2725_ = lean_ctor_get(v_a_2630_, 0);
lean_dec(v_unused_2725_);
v___x_2666_ = v_a_2630_;
v_isShared_2667_ = v_isSharedCheck_2723_;
goto v_resetjp_2665_;
}
else
{
lean_dec(v_a_2630_);
v___x_2666_ = lean_box(0);
v_isShared_2667_ = v_isSharedCheck_2723_;
goto v_resetjp_2665_;
}
v_resetjp_2665_:
{
lean_object* v___x_2669_; 
if (v_isShared_2652_ == 0)
{
lean_ctor_set(v___x_2651_, 0, v_work_2663_);
v___x_2669_ = v___x_2651_;
goto v_reusejp_2668_;
}
else
{
lean_object* v_reuseFailAlloc_2722_; 
v_reuseFailAlloc_2722_ = lean_alloc_ctor(0, 13, 0);
lean_ctor_set(v_reuseFailAlloc_2722_, 0, v_work_2663_);
lean_ctor_set(v_reuseFailAlloc_2722_, 1, v_allocatedBytes_2638_);
lean_ctor_set(v_reuseFailAlloc_2722_, 2, v_pairs_2639_);
lean_ctor_set(v_reuseFailAlloc_2722_, 3, v_rounds_2640_);
lean_ctor_set(v_reuseFailAlloc_2722_, 4, v_matrixEntries_2641_);
lean_ctor_set(v_reuseFailAlloc_2722_, 5, v_matrixRows_2642_);
lean_ctor_set(v_reuseFailAlloc_2722_, 6, v_matrixCalls_2643_);
lean_ctor_set(v_reuseFailAlloc_2722_, 7, v_peakMatrixRows_2644_);
lean_ctor_set(v_reuseFailAlloc_2722_, 8, v_peakMatrixEntries_2645_);
lean_ctor_set(v_reuseFailAlloc_2722_, 9, v_largestBatch_2646_);
lean_ctor_set(v_reuseFailAlloc_2722_, 10, v_productPairs_2647_);
lean_ctor_set(v_reuseFailAlloc_2722_, 11, v_chainPairs_2648_);
lean_ctor_set(v_reuseFailAlloc_2722_, 12, v_gmPairs_2649_);
v___x_2669_ = v_reuseFailAlloc_2722_;
goto v_reusejp_2668_;
}
v_reusejp_2668_:
{
lean_object* v___x_2671_; 
lean_inc_ref(v_table_2636_);
if (v_isShared_2667_ == 0)
{
lean_ctor_set(v___x_2666_, 1, v___x_2669_);
v___x_2671_ = v___x_2666_;
goto v_reusejp_2670_;
}
else
{
lean_object* v_reuseFailAlloc_2721_; 
v_reuseFailAlloc_2721_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2721_, 0, v_table_2636_);
lean_ctor_set(v_reuseFailAlloc_2721_, 1, v___x_2669_);
v___x_2671_ = v_reuseFailAlloc_2721_;
goto v_reusejp_2670_;
}
v_reusejp_2670_:
{
lean_object* v___x_2672_; lean_object* v___y_2674_; uint8_t v___x_2720_; 
v___x_2672_ = lean_unsigned_to_nat(4u);
v___x_2720_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_2634_);
switch(v___x_2720_)
{
case 0:
{
v___y_2674_ = v___x_2660_;
goto v___jp_2673_;
}
case 1:
{
v___y_2674_ = v___x_2655_;
goto v___jp_2673_;
}
default: 
{
v___y_2674_ = v___x_2672_;
goto v___jp_2673_;
}
}
v___jp_2673_:
{
lean_object* v___x_2675_; lean_object* v___x_2676_; lean_object* v___x_2677_; lean_object* v_fst_2678_; 
v___x_2675_ = lean_nat_add(v___x_2672_, v___y_2674_);
v___x_2676_ = lean_nat_mul(v___x_2659_, v___x_2675_);
lean_dec(v___x_2675_);
v___x_2677_ = lp_Hex_Hex_Groebner_Computation_allocate(v_limits_2627_, v___x_2676_, v___x_2671_);
lean_dec(v___x_2676_);
v_fst_2678_ = lean_ctor_get(v___x_2677_, 0);
lean_inc(v_fst_2678_);
if (lean_obj_tag(v_fst_2678_) == 0)
{
lean_object* v_snd_2679_; lean_object* v___x_2681_; uint8_t v_isShared_2682_; uint8_t v_isSharedCheck_2694_; 
lean_dec(v___x_2659_);
lean_dec(v___x_2658_);
lean_dec(v___x_2656_);
lean_dec_ref(v_table_2636_);
lean_dec_ref(v_q_2629_);
v_snd_2679_ = lean_ctor_get(v___x_2677_, 1);
v_isSharedCheck_2694_ = !lean_is_exclusive(v___x_2677_);
if (v_isSharedCheck_2694_ == 0)
{
lean_object* v_unused_2695_; 
v_unused_2695_ = lean_ctor_get(v___x_2677_, 0);
lean_dec(v_unused_2695_);
v___x_2681_ = v___x_2677_;
v_isShared_2682_ = v_isSharedCheck_2694_;
goto v_resetjp_2680_;
}
else
{
lean_inc(v_snd_2679_);
lean_dec(v___x_2677_);
v___x_2681_ = lean_box(0);
v_isShared_2682_ = v_isSharedCheck_2694_;
goto v_resetjp_2680_;
}
v_resetjp_2680_:
{
lean_object* v_a_2683_; lean_object* v___x_2685_; uint8_t v_isShared_2686_; uint8_t v_isSharedCheck_2693_; 
v_a_2683_ = lean_ctor_get(v_fst_2678_, 0);
v_isSharedCheck_2693_ = !lean_is_exclusive(v_fst_2678_);
if (v_isSharedCheck_2693_ == 0)
{
v___x_2685_ = v_fst_2678_;
v_isShared_2686_ = v_isSharedCheck_2693_;
goto v_resetjp_2684_;
}
else
{
lean_inc(v_a_2683_);
lean_dec(v_fst_2678_);
v___x_2685_ = lean_box(0);
v_isShared_2686_ = v_isSharedCheck_2693_;
goto v_resetjp_2684_;
}
v_resetjp_2684_:
{
lean_object* v___x_2688_; 
if (v_isShared_2686_ == 0)
{
v___x_2688_ = v___x_2685_;
goto v_reusejp_2687_;
}
else
{
lean_object* v_reuseFailAlloc_2692_; 
v_reuseFailAlloc_2692_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2692_, 0, v_a_2683_);
v___x_2688_ = v_reuseFailAlloc_2692_;
goto v_reusejp_2687_;
}
v_reusejp_2687_:
{
lean_object* v___x_2690_; 
if (v_isShared_2682_ == 0)
{
lean_ctor_set(v___x_2681_, 0, v___x_2688_);
v___x_2690_ = v___x_2681_;
goto v_reusejp_2689_;
}
else
{
lean_object* v_reuseFailAlloc_2691_; 
v_reuseFailAlloc_2691_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2691_, 0, v___x_2688_);
lean_ctor_set(v_reuseFailAlloc_2691_, 1, v_snd_2679_);
v___x_2690_ = v_reuseFailAlloc_2691_;
goto v_reusejp_2689_;
}
v_reusejp_2689_:
{
return v___x_2690_;
}
}
}
}
}
else
{
lean_object* v_snd_2696_; lean_object* v_i_2697_; lean_object* v___x_2698_; lean_object* v___x_2699_; lean_object* v___x_2700_; lean_object* v_fst_2701_; lean_object* v_a_2702_; lean_object* v___x_2704_; uint8_t v_isShared_2705_; uint8_t v_isSharedCheck_2719_; 
lean_dec_ref_known(v_fst_2678_, 1);
v_snd_2696_ = lean_ctor_get(v___x_2677_, 1);
lean_inc(v_snd_2696_);
lean_dec_ref(v___x_2677_);
v_i_2697_ = lean_unsigned_to_nat(0u);
v___x_2698_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2698_, 0, v_i_2697_);
lean_ctor_set(v___x_2698_, 1, v___x_2659_);
lean_ctor_set(v___x_2698_, 2, v___x_2660_);
v___x_2699_ = lean_obj_once(&lp_Hex_Hex_Groebner_Polynomial_subtract___closed__1, &lp_Hex_Hex_Groebner_Polynomial_subtract___closed__1_once, _init_lp_Hex_Hex_Groebner_Polynomial_subtract___closed__1);
v___x_2700_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0___redArg(v_field_2634_, v_q_2629_, v_p_2628_, v___x_2656_, v___x_2658_, v_context_2626_, v_table_2636_, v___x_2698_, v___x_2699_, v_i_2697_, v_snd_2696_);
lean_dec_ref_known(v___x_2698_, 3);
lean_dec_ref(v_table_2636_);
lean_dec(v___x_2658_);
lean_dec(v___x_2656_);
lean_dec_ref(v_q_2629_);
v_fst_2701_ = lean_ctor_get(v___x_2700_, 0);
lean_inc(v_fst_2701_);
v_a_2702_ = lean_ctor_get(v_fst_2701_, 0);
v_isSharedCheck_2719_ = !lean_is_exclusive(v_fst_2701_);
if (v_isSharedCheck_2719_ == 0)
{
v___x_2704_ = v_fst_2701_;
v_isShared_2705_ = v_isSharedCheck_2719_;
goto v_resetjp_2703_;
}
else
{
lean_inc(v_a_2702_);
lean_dec(v_fst_2701_);
v___x_2704_ = lean_box(0);
v_isShared_2705_ = v_isSharedCheck_2719_;
goto v_resetjp_2703_;
}
v_resetjp_2703_:
{
lean_object* v_snd_2706_; lean_object* v_fst_2707_; lean_object* v___x_2709_; uint8_t v_isShared_2710_; uint8_t v_isSharedCheck_2717_; 
v_snd_2706_ = lean_ctor_get(v___x_2700_, 1);
lean_inc(v_snd_2706_);
lean_dec_ref(v___x_2700_);
v_fst_2707_ = lean_ctor_get(v_a_2702_, 0);
v_isSharedCheck_2717_ = !lean_is_exclusive(v_a_2702_);
if (v_isSharedCheck_2717_ == 0)
{
lean_object* v_unused_2718_; 
v_unused_2718_ = lean_ctor_get(v_a_2702_, 1);
lean_dec(v_unused_2718_);
v___x_2709_ = v_a_2702_;
v_isShared_2710_ = v_isSharedCheck_2717_;
goto v_resetjp_2708_;
}
else
{
lean_inc(v_fst_2707_);
lean_dec(v_a_2702_);
v___x_2709_ = lean_box(0);
v_isShared_2710_ = v_isSharedCheck_2717_;
goto v_resetjp_2708_;
}
v_resetjp_2708_:
{
lean_object* v___x_2712_; 
if (v_isShared_2705_ == 0)
{
lean_ctor_set(v___x_2704_, 0, v_fst_2707_);
v___x_2712_ = v___x_2704_;
goto v_reusejp_2711_;
}
else
{
lean_object* v_reuseFailAlloc_2716_; 
v_reuseFailAlloc_2716_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2716_, 0, v_fst_2707_);
v___x_2712_ = v_reuseFailAlloc_2716_;
goto v_reusejp_2711_;
}
v_reusejp_2711_:
{
lean_object* v___x_2714_; 
if (v_isShared_2710_ == 0)
{
lean_ctor_set(v___x_2709_, 1, v_snd_2706_);
lean_ctor_set(v___x_2709_, 0, v___x_2712_);
v___x_2714_ = v___x_2709_;
goto v_reusejp_2713_;
}
else
{
lean_object* v_reuseFailAlloc_2715_; 
v_reuseFailAlloc_2715_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2715_, 0, v___x_2712_);
lean_ctor_set(v_reuseFailAlloc_2715_, 1, v_snd_2706_);
v___x_2714_ = v_reuseFailAlloc_2715_;
goto v_reusejp_2713_;
}
v_reusejp_2713_:
{
return v___x_2714_;
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_2727_; uint8_t v_isShared_2728_; uint8_t v_isSharedCheck_2733_; 
lean_dec(v_work_2663_);
lean_dec(v___x_2659_);
lean_dec(v___x_2658_);
lean_dec(v___x_2656_);
lean_del_object(v___x_2651_);
lean_dec(v_gmPairs_2649_);
lean_dec(v_chainPairs_2648_);
lean_dec(v_productPairs_2647_);
lean_dec(v_largestBatch_2646_);
lean_dec(v_peakMatrixEntries_2645_);
lean_dec(v_peakMatrixRows_2644_);
lean_dec(v_matrixCalls_2643_);
lean_dec(v_matrixRows_2642_);
lean_dec(v_matrixEntries_2641_);
lean_dec(v_rounds_2640_);
lean_dec(v_pairs_2639_);
lean_dec(v_allocatedBytes_2638_);
v_isSharedCheck_2733_ = !lean_is_exclusive(v_q_2629_);
if (v_isSharedCheck_2733_ == 0)
{
lean_object* v_unused_2734_; lean_object* v_unused_2735_; 
v_unused_2734_ = lean_ctor_get(v_q_2629_, 1);
lean_dec(v_unused_2734_);
v_unused_2735_ = lean_ctor_get(v_q_2629_, 0);
lean_dec(v_unused_2735_);
v___x_2727_ = v_q_2629_;
v_isShared_2728_ = v_isSharedCheck_2733_;
goto v_resetjp_2726_;
}
else
{
lean_dec(v_q_2629_);
v___x_2727_ = lean_box(0);
v_isShared_2728_ = v_isSharedCheck_2733_;
goto v_resetjp_2726_;
}
v_resetjp_2726_:
{
lean_object* v___x_2729_; lean_object* v___x_2731_; 
v___x_2729_ = ((lean_object*)(lp_Hex_Hex_Groebner_Polynomial_normalize___closed__4));
if (v_isShared_2728_ == 0)
{
lean_ctor_set(v___x_2727_, 1, v_a_2630_);
lean_ctor_set(v___x_2727_, 0, v___x_2729_);
v___x_2731_ = v___x_2727_;
goto v_reusejp_2730_;
}
else
{
lean_object* v_reuseFailAlloc_2732_; 
v_reuseFailAlloc_2732_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2732_, 0, v___x_2729_);
lean_ctor_set(v_reuseFailAlloc_2732_, 1, v_a_2630_);
v___x_2731_ = v_reuseFailAlloc_2732_;
goto v_reusejp_2730_;
}
v_reusejp_2730_:
{
return v___x_2731_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_subtract___boxed(lean_object* v_context_2737_, lean_object* v_limits_2738_, lean_object* v_p_2739_, lean_object* v_q_2740_, lean_object* v_a_2741_){
_start:
{
lean_object* v_res_2742_; 
v_res_2742_ = lp_Hex_Hex_Groebner_Polynomial_subtract(v_context_2737_, v_limits_2738_, v_p_2739_, v_q_2740_, v_a_2741_);
lean_dec_ref(v_p_2739_);
lean_dec_ref(v_limits_2738_);
lean_dec_ref(v_context_2737_);
return v_res_2742_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0(uint64_t v___x_2743_, lean_object* v_q_2744_, lean_object* v_p_2745_, lean_object* v___x_2746_, lean_object* v___x_2747_, lean_object* v_context_2748_, lean_object* v_table_2749_, lean_object* v_range_2750_, lean_object* v_b_2751_, lean_object* v_i_2752_, lean_object* v_hs_2753_, lean_object* v_hl_2754_, lean_object* v___y_2755_){
_start:
{
lean_object* v___x_2756_; 
v___x_2756_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0___redArg(v___x_2743_, v_q_2744_, v_p_2745_, v___x_2746_, v___x_2747_, v_context_2748_, v_table_2749_, v_range_2750_, v_b_2751_, v_i_2752_, v___y_2755_);
return v___x_2756_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0___boxed(lean_object* v___x_2757_, lean_object* v_q_2758_, lean_object* v_p_2759_, lean_object* v___x_2760_, lean_object* v___x_2761_, lean_object* v_context_2762_, lean_object* v_table_2763_, lean_object* v_range_2764_, lean_object* v_b_2765_, lean_object* v_i_2766_, lean_object* v_hs_2767_, lean_object* v_hl_2768_, lean_object* v___y_2769_){
_start:
{
uint64_t v___x_18255__boxed_2770_; lean_object* v_res_2771_; 
v___x_18255__boxed_2770_ = lean_unbox_uint64(v___x_2757_);
lean_dec_ref(v___x_2757_);
v_res_2771_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_subtract_spec__0(v___x_18255__boxed_2770_, v_q_2758_, v_p_2759_, v___x_2760_, v___x_2761_, v_context_2762_, v_table_2763_, v_range_2764_, v_b_2765_, v_i_2766_, v_hs_2767_, v_hl_2768_, v___y_2769_);
lean_dec_ref(v_range_2764_);
lean_dec_ref(v_table_2763_);
lean_dec_ref(v_context_2762_);
lean_dec(v___x_2761_);
lean_dec(v___x_2760_);
lean_dec_ref(v_p_2759_);
lean_dec_ref(v_q_2758_);
return v_res_2771_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_sPolynomial(lean_object* v_context_2772_, lean_object* v_limits_2773_, lean_object* v_f_2774_, lean_object* v_g_2775_, lean_object* v_a_2776_){
_start:
{
lean_object* v_support_2777_; uint8_t v___x_2778_; lean_object* v___y_2780_; lean_object* v___y_2781_; lean_object* v___y_2856_; lean_object* v___y_2857_; uint64_t v___y_2881_; lean_object* v___y_2882_; uint8_t v___y_2883_; lean_object* v___y_2890_; uint64_t v___y_2891_; lean_object* v___y_2892_; uint8_t v___y_2893_; uint8_t v___y_2894_; lean_object* v___y_2906_; lean_object* v___y_2907_; uint8_t v___y_2908_; uint64_t v___y_2909_; uint8_t v___y_2910_; lean_object* v___y_2922_; lean_object* v___y_2923_; uint8_t v___y_2924_; uint8_t v___y_2925_; lean_object* v___y_2934_; uint64_t v___y_2970_; uint8_t v___y_2971_; lean_object* v___x_2977_; lean_object* v___x_2978_; uint8_t v___x_2979_; 
v_support_2777_ = lean_ctor_get(v_f_2774_, 0);
v___x_2778_ = 0;
v___x_2977_ = lean_unsigned_to_nat(4u);
v___x_2978_ = lean_byte_array_size(v_support_2777_);
v___x_2979_ = lean_nat_dec_le(v___x_2977_, v___x_2978_);
if (v___x_2979_ == 0)
{
if (v___x_2979_ == 0)
{
uint8_t v___x_2980_; uint64_t v___y_2982_; uint8_t v___y_2983_; uint64_t v___y_2995_; uint8_t v___y_2996_; uint8_t v___y_3008_; lean_object* v_offset_3016_; uint8_t v___x_3017_; 
v___x_2980_ = 0;
v_offset_3016_ = lean_unsigned_to_nat(0u);
v___x_3017_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_support_2777_, v_offset_3016_);
if (v___x_3017_ == 0)
{
lean_object* v___x_3018_; lean_object* v___x_3019_; uint8_t v___x_3020_; 
v___x_3018_ = lean_box(v___x_2980_);
v___x_3019_ = l_outOfBounds___redArg(v___x_3018_);
lean_dec(v___x_3018_);
v___x_3020_ = lean_unbox(v___x_3019_);
lean_dec(v___x_3019_);
v___y_3008_ = v___x_3020_;
goto v___jp_3007_;
}
else
{
uint8_t v___x_3021_; 
v___x_3021_ = lean_byte_array_fget(v_support_2777_, v_offset_3016_);
v___y_3008_ = v___x_3021_;
goto v___jp_3007_;
}
v___jp_2981_:
{
uint64_t v___x_2984_; uint64_t v___x_2985_; uint64_t v___x_2986_; uint64_t v___x_2987_; lean_object* v___x_2988_; uint8_t v___x_2989_; 
v___x_2984_ = lean_uint8_to_uint64(v___y_2983_);
v___x_2985_ = 16ULL;
v___x_2986_ = lean_uint64_shift_left(v___x_2984_, v___x_2985_);
v___x_2987_ = lean_uint64_lor(v___y_2982_, v___x_2986_);
v___x_2988_ = lean_unsigned_to_nat(3u);
v___x_2989_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_support_2777_, v___x_2988_);
if (v___x_2989_ == 0)
{
lean_object* v___x_2990_; lean_object* v___x_2991_; uint8_t v___x_2992_; 
v___x_2990_ = lean_box(v___x_2980_);
v___x_2991_ = l_outOfBounds___redArg(v___x_2990_);
lean_dec(v___x_2990_);
v___x_2992_ = lean_unbox(v___x_2991_);
lean_dec(v___x_2991_);
v___y_2970_ = v___x_2987_;
v___y_2971_ = v___x_2992_;
goto v___jp_2969_;
}
else
{
uint8_t v___x_2993_; 
v___x_2993_ = lean_byte_array_fget(v_support_2777_, v___x_2988_);
v___y_2970_ = v___x_2987_;
v___y_2971_ = v___x_2993_;
goto v___jp_2969_;
}
}
v___jp_2994_:
{
uint64_t v___x_2997_; uint64_t v___x_2998_; uint64_t v___x_2999_; uint64_t v___x_3000_; lean_object* v___x_3001_; uint8_t v___x_3002_; 
v___x_2997_ = lean_uint8_to_uint64(v___y_2996_);
v___x_2998_ = 8ULL;
v___x_2999_ = lean_uint64_shift_left(v___x_2997_, v___x_2998_);
v___x_3000_ = lean_uint64_lor(v___y_2995_, v___x_2999_);
v___x_3001_ = lean_unsigned_to_nat(2u);
v___x_3002_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_support_2777_, v___x_3001_);
if (v___x_3002_ == 0)
{
lean_object* v___x_3003_; lean_object* v___x_3004_; uint8_t v___x_3005_; 
v___x_3003_ = lean_box(v___x_2980_);
v___x_3004_ = l_outOfBounds___redArg(v___x_3003_);
lean_dec(v___x_3003_);
v___x_3005_ = lean_unbox(v___x_3004_);
lean_dec(v___x_3004_);
v___y_2982_ = v___x_3000_;
v___y_2983_ = v___x_3005_;
goto v___jp_2981_;
}
else
{
uint8_t v___x_3006_; 
v___x_3006_ = lean_byte_array_fget(v_support_2777_, v___x_3001_);
v___y_2982_ = v___x_3000_;
v___y_2983_ = v___x_3006_;
goto v___jp_2981_;
}
}
v___jp_3007_:
{
uint64_t v_a_3009_; lean_object* v___x_3010_; uint8_t v___x_3011_; 
v_a_3009_ = lean_uint8_to_uint64(v___y_3008_);
v___x_3010_ = lean_unsigned_to_nat(1u);
v___x_3011_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_support_2777_, v___x_3010_);
if (v___x_3011_ == 0)
{
lean_object* v___x_3012_; lean_object* v___x_3013_; uint8_t v___x_3014_; 
v___x_3012_ = lean_box(v___x_2980_);
v___x_3013_ = l_outOfBounds___redArg(v___x_3012_);
lean_dec(v___x_3012_);
v___x_3014_ = lean_unbox(v___x_3013_);
lean_dec(v___x_3013_);
v___y_2995_ = v_a_3009_;
v___y_2996_ = v___x_3014_;
goto v___jp_2994_;
}
else
{
uint8_t v___x_3015_; 
v___x_3015_ = lean_byte_array_fget(v_support_2777_, v___x_3010_);
v___y_2995_ = v_a_3009_;
v___y_2996_ = v___x_3015_;
goto v___jp_2994_;
}
}
}
else
{
goto v___jp_2946_;
}
}
else
{
goto v___jp_2946_;
}
v___jp_2779_:
{
lean_object* v___x_2782_; lean_object* v_fst_2783_; 
lean_inc(v___y_2781_);
lean_inc(v___y_2780_);
lean_inc_ref(v_limits_2773_);
v___x_2782_ = lp_Hex_Hex_Groebner_Computation_combine(v_limits_2773_, v___x_2778_, v___y_2780_, v___y_2781_, v_a_2776_);
v_fst_2783_ = lean_ctor_get(v___x_2782_, 0);
lean_inc(v_fst_2783_);
if (lean_obj_tag(v_fst_2783_) == 0)
{
lean_object* v_snd_2784_; lean_object* v___x_2786_; uint8_t v_isShared_2787_; uint8_t v_isSharedCheck_2799_; 
lean_dec(v___y_2781_);
lean_dec(v___y_2780_);
lean_dec_ref(v_g_2775_);
lean_dec_ref(v_f_2774_);
lean_dec_ref(v_limits_2773_);
v_snd_2784_ = lean_ctor_get(v___x_2782_, 1);
v_isSharedCheck_2799_ = !lean_is_exclusive(v___x_2782_);
if (v_isSharedCheck_2799_ == 0)
{
lean_object* v_unused_2800_; 
v_unused_2800_ = lean_ctor_get(v___x_2782_, 0);
lean_dec(v_unused_2800_);
v___x_2786_ = v___x_2782_;
v_isShared_2787_ = v_isSharedCheck_2799_;
goto v_resetjp_2785_;
}
else
{
lean_inc(v_snd_2784_);
lean_dec(v___x_2782_);
v___x_2786_ = lean_box(0);
v_isShared_2787_ = v_isSharedCheck_2799_;
goto v_resetjp_2785_;
}
v_resetjp_2785_:
{
lean_object* v_a_2788_; lean_object* v___x_2790_; uint8_t v_isShared_2791_; uint8_t v_isSharedCheck_2798_; 
v_a_2788_ = lean_ctor_get(v_fst_2783_, 0);
v_isSharedCheck_2798_ = !lean_is_exclusive(v_fst_2783_);
if (v_isSharedCheck_2798_ == 0)
{
v___x_2790_ = v_fst_2783_;
v_isShared_2791_ = v_isSharedCheck_2798_;
goto v_resetjp_2789_;
}
else
{
lean_inc(v_a_2788_);
lean_dec(v_fst_2783_);
v___x_2790_ = lean_box(0);
v_isShared_2791_ = v_isSharedCheck_2798_;
goto v_resetjp_2789_;
}
v_resetjp_2789_:
{
lean_object* v___x_2793_; 
if (v_isShared_2791_ == 0)
{
v___x_2793_ = v___x_2790_;
goto v_reusejp_2792_;
}
else
{
lean_object* v_reuseFailAlloc_2797_; 
v_reuseFailAlloc_2797_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2797_, 0, v_a_2788_);
v___x_2793_ = v_reuseFailAlloc_2797_;
goto v_reusejp_2792_;
}
v_reusejp_2792_:
{
lean_object* v___x_2795_; 
if (v_isShared_2787_ == 0)
{
lean_ctor_set(v___x_2786_, 0, v___x_2793_);
v___x_2795_ = v___x_2786_;
goto v_reusejp_2794_;
}
else
{
lean_object* v_reuseFailAlloc_2796_; 
v_reuseFailAlloc_2796_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2796_, 0, v___x_2793_);
lean_ctor_set(v_reuseFailAlloc_2796_, 1, v_snd_2784_);
v___x_2795_ = v_reuseFailAlloc_2796_;
goto v_reusejp_2794_;
}
v_reusejp_2794_:
{
return v___x_2795_;
}
}
}
}
}
else
{
lean_object* v_snd_2801_; lean_object* v_a_2802_; uint8_t v___x_2803_; lean_object* v___x_2804_; lean_object* v_fst_2805_; 
v_snd_2801_ = lean_ctor_get(v___x_2782_, 1);
lean_inc(v_snd_2801_);
lean_dec_ref(v___x_2782_);
v_a_2802_ = lean_ctor_get(v_fst_2783_, 0);
lean_inc_n(v_a_2802_, 2);
lean_dec_ref_known(v_fst_2783_, 1);
v___x_2803_ = 2;
lean_inc_ref(v_limits_2773_);
v___x_2804_ = lp_Hex_Hex_Groebner_Computation_combine(v_limits_2773_, v___x_2803_, v_a_2802_, v___y_2780_, v_snd_2801_);
v_fst_2805_ = lean_ctor_get(v___x_2804_, 0);
lean_inc(v_fst_2805_);
if (lean_obj_tag(v_fst_2805_) == 0)
{
lean_object* v_snd_2806_; lean_object* v___x_2808_; uint8_t v_isShared_2809_; uint8_t v_isSharedCheck_2821_; 
lean_dec(v_a_2802_);
lean_dec(v___y_2781_);
lean_dec_ref(v_g_2775_);
lean_dec_ref(v_f_2774_);
lean_dec_ref(v_limits_2773_);
v_snd_2806_ = lean_ctor_get(v___x_2804_, 1);
v_isSharedCheck_2821_ = !lean_is_exclusive(v___x_2804_);
if (v_isSharedCheck_2821_ == 0)
{
lean_object* v_unused_2822_; 
v_unused_2822_ = lean_ctor_get(v___x_2804_, 0);
lean_dec(v_unused_2822_);
v___x_2808_ = v___x_2804_;
v_isShared_2809_ = v_isSharedCheck_2821_;
goto v_resetjp_2807_;
}
else
{
lean_inc(v_snd_2806_);
lean_dec(v___x_2804_);
v___x_2808_ = lean_box(0);
v_isShared_2809_ = v_isSharedCheck_2821_;
goto v_resetjp_2807_;
}
v_resetjp_2807_:
{
lean_object* v_a_2810_; lean_object* v___x_2812_; uint8_t v_isShared_2813_; uint8_t v_isSharedCheck_2820_; 
v_a_2810_ = lean_ctor_get(v_fst_2805_, 0);
v_isSharedCheck_2820_ = !lean_is_exclusive(v_fst_2805_);
if (v_isSharedCheck_2820_ == 0)
{
v___x_2812_ = v_fst_2805_;
v_isShared_2813_ = v_isSharedCheck_2820_;
goto v_resetjp_2811_;
}
else
{
lean_inc(v_a_2810_);
lean_dec(v_fst_2805_);
v___x_2812_ = lean_box(0);
v_isShared_2813_ = v_isSharedCheck_2820_;
goto v_resetjp_2811_;
}
v_resetjp_2811_:
{
lean_object* v___x_2815_; 
if (v_isShared_2813_ == 0)
{
v___x_2815_ = v___x_2812_;
goto v_reusejp_2814_;
}
else
{
lean_object* v_reuseFailAlloc_2819_; 
v_reuseFailAlloc_2819_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2819_, 0, v_a_2810_);
v___x_2815_ = v_reuseFailAlloc_2819_;
goto v_reusejp_2814_;
}
v_reusejp_2814_:
{
lean_object* v___x_2817_; 
if (v_isShared_2809_ == 0)
{
lean_ctor_set(v___x_2808_, 0, v___x_2815_);
v___x_2817_ = v___x_2808_;
goto v_reusejp_2816_;
}
else
{
lean_object* v_reuseFailAlloc_2818_; 
v_reuseFailAlloc_2818_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2818_, 0, v___x_2815_);
lean_ctor_set(v_reuseFailAlloc_2818_, 1, v_snd_2806_);
v___x_2817_ = v_reuseFailAlloc_2818_;
goto v_reusejp_2816_;
}
v_reusejp_2816_:
{
return v___x_2817_;
}
}
}
}
}
else
{
lean_object* v_snd_2823_; lean_object* v_a_2824_; lean_object* v___x_2825_; lean_object* v_fst_2826_; 
v_snd_2823_ = lean_ctor_get(v___x_2804_, 1);
lean_inc(v_snd_2823_);
lean_dec_ref(v___x_2804_);
v_a_2824_ = lean_ctor_get(v_fst_2805_, 0);
lean_inc(v_a_2824_);
lean_dec_ref_known(v_fst_2805_, 1);
lean_inc_ref(v_limits_2773_);
v___x_2825_ = lp_Hex_Hex_Groebner_Computation_combine(v_limits_2773_, v___x_2803_, v_a_2802_, v___y_2781_, v_snd_2823_);
v_fst_2826_ = lean_ctor_get(v___x_2825_, 0);
lean_inc(v_fst_2826_);
if (lean_obj_tag(v_fst_2826_) == 0)
{
lean_object* v_snd_2827_; lean_object* v___x_2829_; uint8_t v_isShared_2830_; uint8_t v_isSharedCheck_2842_; 
lean_dec(v_a_2824_);
lean_dec_ref(v_g_2775_);
lean_dec_ref(v_f_2774_);
lean_dec_ref(v_limits_2773_);
v_snd_2827_ = lean_ctor_get(v___x_2825_, 1);
v_isSharedCheck_2842_ = !lean_is_exclusive(v___x_2825_);
if (v_isSharedCheck_2842_ == 0)
{
lean_object* v_unused_2843_; 
v_unused_2843_ = lean_ctor_get(v___x_2825_, 0);
lean_dec(v_unused_2843_);
v___x_2829_ = v___x_2825_;
v_isShared_2830_ = v_isSharedCheck_2842_;
goto v_resetjp_2828_;
}
else
{
lean_inc(v_snd_2827_);
lean_dec(v___x_2825_);
v___x_2829_ = lean_box(0);
v_isShared_2830_ = v_isSharedCheck_2842_;
goto v_resetjp_2828_;
}
v_resetjp_2828_:
{
lean_object* v_a_2831_; lean_object* v___x_2833_; uint8_t v_isShared_2834_; uint8_t v_isSharedCheck_2841_; 
v_a_2831_ = lean_ctor_get(v_fst_2826_, 0);
v_isSharedCheck_2841_ = !lean_is_exclusive(v_fst_2826_);
if (v_isSharedCheck_2841_ == 0)
{
v___x_2833_ = v_fst_2826_;
v_isShared_2834_ = v_isSharedCheck_2841_;
goto v_resetjp_2832_;
}
else
{
lean_inc(v_a_2831_);
lean_dec(v_fst_2826_);
v___x_2833_ = lean_box(0);
v_isShared_2834_ = v_isSharedCheck_2841_;
goto v_resetjp_2832_;
}
v_resetjp_2832_:
{
lean_object* v___x_2836_; 
if (v_isShared_2834_ == 0)
{
v___x_2836_ = v___x_2833_;
goto v_reusejp_2835_;
}
else
{
lean_object* v_reuseFailAlloc_2840_; 
v_reuseFailAlloc_2840_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2840_, 0, v_a_2831_);
v___x_2836_ = v_reuseFailAlloc_2840_;
goto v_reusejp_2835_;
}
v_reusejp_2835_:
{
lean_object* v___x_2838_; 
if (v_isShared_2830_ == 0)
{
lean_ctor_set(v___x_2829_, 0, v___x_2836_);
v___x_2838_ = v___x_2829_;
goto v_reusejp_2837_;
}
else
{
lean_object* v_reuseFailAlloc_2839_; 
v_reuseFailAlloc_2839_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2839_, 0, v___x_2836_);
lean_ctor_set(v_reuseFailAlloc_2839_, 1, v_snd_2827_);
v___x_2838_ = v_reuseFailAlloc_2839_;
goto v_reusejp_2837_;
}
v_reusejp_2837_:
{
return v___x_2838_;
}
}
}
}
}
else
{
lean_object* v_snd_2844_; lean_object* v_a_2845_; lean_object* v___x_2846_; lean_object* v_fst_2847_; 
v_snd_2844_ = lean_ctor_get(v___x_2825_, 1);
lean_inc(v_snd_2844_);
lean_dec_ref(v___x_2825_);
v_a_2845_ = lean_ctor_get(v_fst_2826_, 0);
lean_inc(v_a_2845_);
lean_dec_ref_known(v_fst_2826_, 1);
lean_inc_ref(v_limits_2773_);
v___x_2846_ = lp_Hex_Hex_Groebner_Polynomial_multiply___redArg(v_limits_2773_, v_f_2774_, v_a_2824_, v_snd_2844_);
v_fst_2847_ = lean_ctor_get(v___x_2846_, 0);
lean_inc(v_fst_2847_);
if (lean_obj_tag(v_fst_2847_) == 0)
{
lean_dec_ref_known(v_fst_2847_, 1);
lean_dec(v_a_2845_);
lean_dec_ref(v_g_2775_);
lean_dec_ref(v_limits_2773_);
return v___x_2846_;
}
else
{
lean_object* v_snd_2848_; lean_object* v_a_2849_; lean_object* v___x_2850_; lean_object* v_fst_2851_; 
v_snd_2848_ = lean_ctor_get(v___x_2846_, 1);
lean_inc(v_snd_2848_);
lean_dec_ref(v___x_2846_);
v_a_2849_ = lean_ctor_get(v_fst_2847_, 0);
lean_inc(v_a_2849_);
lean_dec_ref_known(v_fst_2847_, 1);
lean_inc_ref(v_limits_2773_);
v___x_2850_ = lp_Hex_Hex_Groebner_Polynomial_multiply___redArg(v_limits_2773_, v_g_2775_, v_a_2845_, v_snd_2848_);
v_fst_2851_ = lean_ctor_get(v___x_2850_, 0);
lean_inc(v_fst_2851_);
if (lean_obj_tag(v_fst_2851_) == 0)
{
lean_dec_ref_known(v_fst_2851_, 1);
lean_dec(v_a_2849_);
lean_dec_ref(v_limits_2773_);
return v___x_2850_;
}
else
{
lean_object* v_snd_2852_; lean_object* v_a_2853_; lean_object* v___x_2854_; 
v_snd_2852_ = lean_ctor_get(v___x_2850_, 1);
lean_inc(v_snd_2852_);
lean_dec_ref(v___x_2850_);
v_a_2853_ = lean_ctor_get(v_fst_2851_, 0);
lean_inc(v_a_2853_);
lean_dec_ref_known(v_fst_2851_, 1);
v___x_2854_ = lp_Hex_Hex_Groebner_Polynomial_subtract(v_context_2772_, v_limits_2773_, v_a_2849_, v_a_2853_, v_snd_2852_);
lean_dec(v_a_2849_);
lean_dec_ref(v_limits_2773_);
return v___x_2854_;
}
}
}
}
}
}
v___jp_2855_:
{
size_t v_pos_2858_; uint8_t v___x_2859_; uint64_t v_a_2860_; size_t v___x_2861_; uint8_t v___x_2862_; uint64_t v___x_2863_; uint64_t v___x_2864_; uint64_t v___x_2865_; uint64_t v___x_2866_; size_t v___x_2867_; uint8_t v___x_2868_; uint64_t v___x_2869_; uint64_t v___x_2870_; uint64_t v___x_2871_; uint64_t v___x_2872_; size_t v___x_2873_; uint8_t v___x_2874_; uint64_t v___x_2875_; uint64_t v___x_2876_; uint64_t v___x_2877_; uint64_t v___x_2878_; lean_object* v___x_2879_; 
v_pos_2858_ = ((size_t)0ULL);
v___x_2859_ = lean_byte_array_uget(v___y_2856_, v_pos_2858_);
v_a_2860_ = lean_uint8_to_uint64(v___x_2859_);
v___x_2861_ = ((size_t)1ULL);
v___x_2862_ = lean_byte_array_uget(v___y_2856_, v___x_2861_);
v___x_2863_ = lean_uint8_to_uint64(v___x_2862_);
v___x_2864_ = 8ULL;
v___x_2865_ = lean_uint64_shift_left(v___x_2863_, v___x_2864_);
v___x_2866_ = lean_uint64_lor(v_a_2860_, v___x_2865_);
v___x_2867_ = ((size_t)2ULL);
v___x_2868_ = lean_byte_array_uget(v___y_2856_, v___x_2867_);
v___x_2869_ = lean_uint8_to_uint64(v___x_2868_);
v___x_2870_ = 16ULL;
v___x_2871_ = lean_uint64_shift_left(v___x_2869_, v___x_2870_);
v___x_2872_ = lean_uint64_lor(v___x_2866_, v___x_2871_);
v___x_2873_ = ((size_t)3ULL);
v___x_2874_ = lean_byte_array_uget(v___y_2856_, v___x_2873_);
lean_dec_ref(v___y_2856_);
v___x_2875_ = lean_uint8_to_uint64(v___x_2874_);
v___x_2876_ = 24ULL;
v___x_2877_ = lean_uint64_shift_left(v___x_2875_, v___x_2876_);
v___x_2878_ = lean_uint64_lor(v___x_2872_, v___x_2877_);
v___x_2879_ = lean_uint64_to_nat(v___x_2878_);
v___y_2780_ = v___y_2857_;
v___y_2781_ = v___x_2879_;
goto v___jp_2779_;
}
v___jp_2880_:
{
uint64_t v___x_2884_; uint64_t v___x_2885_; uint64_t v___x_2886_; uint64_t v___x_2887_; lean_object* v___x_2888_; 
v___x_2884_ = lean_uint8_to_uint64(v___y_2883_);
v___x_2885_ = 24ULL;
v___x_2886_ = lean_uint64_shift_left(v___x_2884_, v___x_2885_);
v___x_2887_ = lean_uint64_lor(v___y_2881_, v___x_2886_);
v___x_2888_ = lean_uint64_to_nat(v___x_2887_);
v___y_2780_ = v___y_2882_;
v___y_2781_ = v___x_2888_;
goto v___jp_2779_;
}
v___jp_2889_:
{
uint64_t v___x_2895_; uint64_t v___x_2896_; uint64_t v___x_2897_; uint64_t v___x_2898_; lean_object* v___x_2899_; uint8_t v___x_2900_; 
v___x_2895_ = lean_uint8_to_uint64(v___y_2894_);
v___x_2896_ = 16ULL;
v___x_2897_ = lean_uint64_shift_left(v___x_2895_, v___x_2896_);
v___x_2898_ = lean_uint64_lor(v___y_2891_, v___x_2897_);
v___x_2899_ = lean_unsigned_to_nat(3u);
v___x_2900_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2890_, v___x_2899_);
if (v___x_2900_ == 0)
{
lean_object* v___x_2901_; lean_object* v___x_2902_; uint8_t v___x_2903_; 
lean_dec_ref(v___y_2890_);
v___x_2901_ = lean_box(v___y_2893_);
v___x_2902_ = l_outOfBounds___redArg(v___x_2901_);
lean_dec(v___x_2901_);
v___x_2903_ = lean_unbox(v___x_2902_);
lean_dec(v___x_2902_);
v___y_2881_ = v___x_2898_;
v___y_2882_ = v___y_2892_;
v___y_2883_ = v___x_2903_;
goto v___jp_2880_;
}
else
{
uint8_t v___x_2904_; 
v___x_2904_ = lean_byte_array_fget(v___y_2890_, v___x_2899_);
lean_dec_ref(v___y_2890_);
v___y_2881_ = v___x_2898_;
v___y_2882_ = v___y_2892_;
v___y_2883_ = v___x_2904_;
goto v___jp_2880_;
}
}
v___jp_2905_:
{
uint64_t v___x_2911_; uint64_t v___x_2912_; uint64_t v___x_2913_; uint64_t v___x_2914_; lean_object* v___x_2915_; uint8_t v___x_2916_; 
v___x_2911_ = lean_uint8_to_uint64(v___y_2910_);
v___x_2912_ = 8ULL;
v___x_2913_ = lean_uint64_shift_left(v___x_2911_, v___x_2912_);
v___x_2914_ = lean_uint64_lor(v___y_2909_, v___x_2913_);
v___x_2915_ = lean_unsigned_to_nat(2u);
v___x_2916_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2906_, v___x_2915_);
if (v___x_2916_ == 0)
{
lean_object* v___x_2917_; lean_object* v___x_2918_; uint8_t v___x_2919_; 
v___x_2917_ = lean_box(v___y_2908_);
v___x_2918_ = l_outOfBounds___redArg(v___x_2917_);
lean_dec(v___x_2917_);
v___x_2919_ = lean_unbox(v___x_2918_);
lean_dec(v___x_2918_);
v___y_2890_ = v___y_2906_;
v___y_2891_ = v___x_2914_;
v___y_2892_ = v___y_2907_;
v___y_2893_ = v___y_2908_;
v___y_2894_ = v___x_2919_;
goto v___jp_2889_;
}
else
{
uint8_t v___x_2920_; 
v___x_2920_ = lean_byte_array_fget(v___y_2906_, v___x_2915_);
v___y_2890_ = v___y_2906_;
v___y_2891_ = v___x_2914_;
v___y_2892_ = v___y_2907_;
v___y_2893_ = v___y_2908_;
v___y_2894_ = v___x_2920_;
goto v___jp_2889_;
}
}
v___jp_2921_:
{
uint64_t v_a_2926_; lean_object* v___x_2927_; uint8_t v___x_2928_; 
v_a_2926_ = lean_uint8_to_uint64(v___y_2925_);
v___x_2927_ = lean_unsigned_to_nat(1u);
v___x_2928_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v___y_2922_, v___x_2927_);
if (v___x_2928_ == 0)
{
lean_object* v___x_2929_; lean_object* v___x_2930_; uint8_t v___x_2931_; 
v___x_2929_ = lean_box(v___y_2924_);
v___x_2930_ = l_outOfBounds___redArg(v___x_2929_);
lean_dec(v___x_2929_);
v___x_2931_ = lean_unbox(v___x_2930_);
lean_dec(v___x_2930_);
v___y_2906_ = v___y_2922_;
v___y_2907_ = v___y_2923_;
v___y_2908_ = v___y_2924_;
v___y_2909_ = v_a_2926_;
v___y_2910_ = v___x_2931_;
goto v___jp_2905_;
}
else
{
uint8_t v___x_2932_; 
v___x_2932_ = lean_byte_array_fget(v___y_2922_, v___x_2927_);
v___y_2906_ = v___y_2922_;
v___y_2907_ = v___y_2923_;
v___y_2908_ = v___y_2924_;
v___y_2909_ = v_a_2926_;
v___y_2910_ = v___x_2932_;
goto v___jp_2905_;
}
}
v___jp_2933_:
{
lean_object* v_support_2935_; lean_object* v___x_2936_; lean_object* v___x_2937_; uint8_t v___x_2938_; 
v_support_2935_ = lean_ctor_get(v_g_2775_, 0);
v___x_2936_ = lean_unsigned_to_nat(4u);
v___x_2937_ = lean_byte_array_size(v_support_2935_);
v___x_2938_ = lean_nat_dec_le(v___x_2936_, v___x_2937_);
if (v___x_2938_ == 0)
{
if (v___x_2938_ == 0)
{
uint8_t v___x_2939_; lean_object* v_offset_2940_; uint8_t v___x_2941_; 
v___x_2939_ = 0;
v_offset_2940_ = lean_unsigned_to_nat(0u);
v___x_2941_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Polynomial_scale_spec__0___redArg___lam__0(v_support_2935_, v_offset_2940_);
if (v___x_2941_ == 0)
{
lean_object* v___x_2942_; lean_object* v___x_2943_; uint8_t v___x_2944_; 
v___x_2942_ = lean_box(v___x_2939_);
v___x_2943_ = l_outOfBounds___redArg(v___x_2942_);
lean_dec(v___x_2942_);
v___x_2944_ = lean_unbox(v___x_2943_);
lean_dec(v___x_2943_);
lean_inc_ref(v_support_2935_);
v___y_2922_ = v_support_2935_;
v___y_2923_ = v___y_2934_;
v___y_2924_ = v___x_2939_;
v___y_2925_ = v___x_2944_;
goto v___jp_2921_;
}
else
{
uint8_t v___x_2945_; 
v___x_2945_ = lean_byte_array_fget(v_support_2935_, v_offset_2940_);
lean_inc_ref(v_support_2935_);
v___y_2922_ = v_support_2935_;
v___y_2923_ = v___y_2934_;
v___y_2924_ = v___x_2939_;
v___y_2925_ = v___x_2945_;
goto v___jp_2921_;
}
}
else
{
lean_inc_ref(v_support_2935_);
v___y_2856_ = v_support_2935_;
v___y_2857_ = v___y_2934_;
goto v___jp_2855_;
}
}
else
{
lean_inc_ref(v_support_2935_);
v___y_2856_ = v_support_2935_;
v___y_2857_ = v___y_2934_;
goto v___jp_2855_;
}
}
v___jp_2946_:
{
size_t v_pos_2947_; uint8_t v___x_2948_; uint64_t v_a_2949_; size_t v___x_2950_; uint8_t v___x_2951_; uint64_t v___x_2952_; uint64_t v___x_2953_; uint64_t v___x_2954_; uint64_t v___x_2955_; size_t v___x_2956_; uint8_t v___x_2957_; uint64_t v___x_2958_; uint64_t v___x_2959_; uint64_t v___x_2960_; uint64_t v___x_2961_; size_t v___x_2962_; uint8_t v___x_2963_; uint64_t v___x_2964_; uint64_t v___x_2965_; uint64_t v___x_2966_; uint64_t v___x_2967_; lean_object* v___x_2968_; 
v_pos_2947_ = ((size_t)0ULL);
v___x_2948_ = lean_byte_array_uget(v_support_2777_, v_pos_2947_);
v_a_2949_ = lean_uint8_to_uint64(v___x_2948_);
v___x_2950_ = ((size_t)1ULL);
v___x_2951_ = lean_byte_array_uget(v_support_2777_, v___x_2950_);
v___x_2952_ = lean_uint8_to_uint64(v___x_2951_);
v___x_2953_ = 8ULL;
v___x_2954_ = lean_uint64_shift_left(v___x_2952_, v___x_2953_);
v___x_2955_ = lean_uint64_lor(v_a_2949_, v___x_2954_);
v___x_2956_ = ((size_t)2ULL);
v___x_2957_ = lean_byte_array_uget(v_support_2777_, v___x_2956_);
v___x_2958_ = lean_uint8_to_uint64(v___x_2957_);
v___x_2959_ = 16ULL;
v___x_2960_ = lean_uint64_shift_left(v___x_2958_, v___x_2959_);
v___x_2961_ = lean_uint64_lor(v___x_2955_, v___x_2960_);
v___x_2962_ = ((size_t)3ULL);
v___x_2963_ = lean_byte_array_uget(v_support_2777_, v___x_2962_);
v___x_2964_ = lean_uint8_to_uint64(v___x_2963_);
v___x_2965_ = 24ULL;
v___x_2966_ = lean_uint64_shift_left(v___x_2964_, v___x_2965_);
v___x_2967_ = lean_uint64_lor(v___x_2961_, v___x_2966_);
v___x_2968_ = lean_uint64_to_nat(v___x_2967_);
v___y_2934_ = v___x_2968_;
goto v___jp_2933_;
}
v___jp_2969_:
{
uint64_t v___x_2972_; uint64_t v___x_2973_; uint64_t v___x_2974_; uint64_t v___x_2975_; lean_object* v___x_2976_; 
v___x_2972_ = lean_uint8_to_uint64(v___y_2971_);
v___x_2973_ = 24ULL;
v___x_2974_ = lean_uint64_shift_left(v___x_2972_, v___x_2973_);
v___x_2975_ = lean_uint64_lor(v___y_2970_, v___x_2974_);
v___x_2976_ = lean_uint64_to_nat(v___x_2975_);
v___y_2934_ = v___x_2976_;
goto v___jp_2933_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_sPolynomial___boxed(lean_object* v_context_3022_, lean_object* v_limits_3023_, lean_object* v_f_3024_, lean_object* v_g_3025_, lean_object* v_a_3026_){
_start:
{
lean_object* v_res_3027_; 
v_res_3027_ = lp_Hex_Hex_Groebner_Polynomial_sPolynomial(v_context_3022_, v_limits_3023_, v_f_3024_, v_g_3025_, v_a_3026_);
lean_dec_ref(v_context_3022_);
return v_res_3027_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(lean_object* v_xs_3028_, lean_object* v_i_3029_){
_start:
{
lean_object* v___x_3030_; uint8_t v___x_3031_; 
v___x_3030_ = lean_byte_array_size(v_xs_3028_);
v___x_3031_ = lean_nat_dec_lt(v_i_3029_, v___x_3030_);
return v___x_3031_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0___boxed(lean_object* v_xs_3032_, lean_object* v_i_3033_){
_start:
{
uint8_t v_res_3034_; lean_object* v_r_3035_; 
v_res_3034_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v_xs_3032_, v_i_3033_);
lean_dec(v_i_3033_);
lean_dec_ref(v_xs_3032_);
v_r_3035_ = lean_box(v_res_3034_);
return v_r_3035_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0(lean_object* v_table_3036_, uint64_t v_field_3037_, lean_object* v_p_3038_, size_t v_sz_3039_, size_t v_i_3040_, lean_object* v_bs_3041_){
_start:
{
uint8_t v___x_3042_; 
v___x_3042_ = lean_usize_dec_lt(v_i_3040_, v_sz_3039_);
if (v___x_3042_ == 0)
{
lean_dec_ref(v_table_3036_);
return v_bs_3041_;
}
else
{
lean_object* v_support_3043_; lean_object* v_coefficients_3044_; lean_object* v_v_3045_; lean_object* v___x_3046_; lean_object* v_bs_x27_3047_; lean_object* v___y_3049_; uint64_t v___y_3055_; lean_object* v___y_3056_; uint8_t v___y_3057_; lean_object* v___y_3064_; uint8_t v___y_3065_; lean_object* v___y_3066_; lean_object* v___y_3067_; uint64_t v___y_3068_; uint8_t v___y_3069_; uint64_t v___y_3082_; lean_object* v___y_3083_; uint8_t v___y_3084_; lean_object* v___y_3085_; lean_object* v___y_3086_; uint8_t v___y_3087_; uint64_t v___y_3100_; lean_object* v___y_3101_; uint8_t v___y_3102_; lean_object* v___y_3109_; uint8_t v___y_3110_; uint8_t v___y_3111_; lean_object* v___y_3112_; lean_object* v___y_3113_; uint8_t v___y_3114_; lean_object* v___y_3132_; uint8_t v___y_3133_; uint8_t v___y_3134_; lean_object* v___y_3135_; lean_object* v___y_3136_; uint8_t v___y_3137_; lean_object* v___y_3178_; uint8_t v___y_3179_; uint8_t v___y_3180_; lean_object* v___y_3181_; lean_object* v___y_3182_; lean_object* v___y_3191_; uint64_t v___y_3199_; uint8_t v___y_3200_; uint8_t v___x_3206_; lean_object* v___x_3207_; lean_object* v_offset_3208_; uint64_t v___y_3210_; uint8_t v___y_3211_; uint64_t v___y_3224_; uint8_t v___y_3225_; uint8_t v___y_3238_; uint8_t v___y_3248_; lean_object* v___x_3279_; lean_object* v___x_3280_; uint8_t v___x_3281_; 
v_support_3043_ = lean_ctor_get(v_p_3038_, 0);
v_coefficients_3044_ = lean_ctor_get(v_p_3038_, 1);
v_v_3045_ = lean_array_uget(v_bs_3041_, v_i_3040_);
v___x_3046_ = lean_unsigned_to_nat(0u);
v_bs_x27_3047_ = lean_array_uset(v_bs_3041_, v_i_3040_, v___x_3046_);
v___x_3206_ = 0;
v___x_3207_ = lean_unsigned_to_nat(4u);
v_offset_3208_ = lean_nat_mul(v_v_3045_, v___x_3207_);
v___x_3279_ = lean_nat_add(v_offset_3208_, v___x_3207_);
v___x_3280_ = lean_byte_array_size(v_support_3043_);
v___x_3281_ = lean_nat_dec_le(v___x_3279_, v___x_3280_);
if (v___x_3281_ == 0)
{
lean_dec(v___x_3279_);
v___y_3248_ = v___x_3281_;
goto v___jp_3247_;
}
else
{
size_t v___x_3282_; lean_object* v___x_3283_; uint8_t v___x_3284_; 
v___x_3282_ = lean_usize_of_nat(v___x_3279_);
v___x_3283_ = lean_usize_to_nat(v___x_3282_);
v___x_3284_ = lean_nat_dec_eq(v___x_3283_, v___x_3279_);
lean_dec(v___x_3279_);
lean_dec(v___x_3283_);
v___y_3248_ = v___x_3284_;
goto v___jp_3247_;
}
v___jp_3048_:
{
size_t v___x_3050_; size_t v___x_3051_; lean_object* v___x_3052_; 
v___x_3050_ = ((size_t)1ULL);
v___x_3051_ = lean_usize_add(v_i_3040_, v___x_3050_);
v___x_3052_ = lean_array_uset(v_bs_x27_3047_, v_i_3040_, v___y_3049_);
v_i_3040_ = v___x_3051_;
v_bs_3041_ = v___x_3052_;
goto _start;
}
v___jp_3054_:
{
uint64_t v___x_3058_; uint64_t v___x_3059_; uint64_t v___x_3060_; uint64_t v___x_3061_; lean_object* v___x_3062_; 
v___x_3058_ = lean_uint8_to_uint64(v___y_3057_);
v___x_3059_ = 24ULL;
v___x_3060_ = lean_uint64_shift_left(v___x_3058_, v___x_3059_);
v___x_3061_ = lean_uint64_lor(v___y_3055_, v___x_3060_);
v___x_3062_ = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(v___x_3062_, 0, v___y_3056_);
lean_ctor_set_uint64(v___x_3062_, sizeof(void*)*1, v___x_3061_);
v___y_3049_ = v___x_3062_;
goto v___jp_3048_;
}
v___jp_3063_:
{
uint64_t v___x_3070_; uint64_t v___x_3071_; uint64_t v___x_3072_; uint64_t v___x_3073_; lean_object* v___x_3074_; lean_object* v___x_3075_; uint8_t v___x_3076_; 
v___x_3070_ = lean_uint8_to_uint64(v___y_3069_);
v___x_3071_ = 16ULL;
v___x_3072_ = lean_uint64_shift_left(v___x_3070_, v___x_3071_);
v___x_3073_ = lean_uint64_lor(v___y_3068_, v___x_3072_);
v___x_3074_ = lean_unsigned_to_nat(3u);
v___x_3075_ = lean_nat_add(v___y_3066_, v___x_3074_);
lean_dec(v___y_3066_);
v___x_3076_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v___y_3064_, v___x_3075_);
if (v___x_3076_ == 0)
{
lean_object* v___x_3077_; lean_object* v___x_3078_; uint8_t v___x_3079_; 
lean_dec(v___x_3075_);
v___x_3077_ = lean_box(v___y_3065_);
v___x_3078_ = l_outOfBounds___redArg(v___x_3077_);
lean_dec(v___x_3077_);
v___x_3079_ = lean_unbox(v___x_3078_);
lean_dec(v___x_3078_);
v___y_3055_ = v___x_3073_;
v___y_3056_ = v___y_3067_;
v___y_3057_ = v___x_3079_;
goto v___jp_3054_;
}
else
{
uint8_t v___x_3080_; 
v___x_3080_ = lean_byte_array_fget(v___y_3064_, v___x_3075_);
lean_dec(v___x_3075_);
v___y_3055_ = v___x_3073_;
v___y_3056_ = v___y_3067_;
v___y_3057_ = v___x_3080_;
goto v___jp_3054_;
}
}
v___jp_3081_:
{
uint64_t v___x_3088_; uint64_t v___x_3089_; uint64_t v___x_3090_; uint64_t v___x_3091_; lean_object* v___x_3092_; lean_object* v___x_3093_; uint8_t v___x_3094_; 
v___x_3088_ = lean_uint8_to_uint64(v___y_3087_);
v___x_3089_ = 8ULL;
v___x_3090_ = lean_uint64_shift_left(v___x_3088_, v___x_3089_);
v___x_3091_ = lean_uint64_lor(v___y_3082_, v___x_3090_);
v___x_3092_ = lean_unsigned_to_nat(2u);
v___x_3093_ = lean_nat_add(v___y_3085_, v___x_3092_);
v___x_3094_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v___y_3083_, v___x_3093_);
if (v___x_3094_ == 0)
{
lean_object* v___x_3095_; lean_object* v___x_3096_; uint8_t v___x_3097_; 
lean_dec(v___x_3093_);
v___x_3095_ = lean_box(v___y_3084_);
v___x_3096_ = l_outOfBounds___redArg(v___x_3095_);
lean_dec(v___x_3095_);
v___x_3097_ = lean_unbox(v___x_3096_);
lean_dec(v___x_3096_);
v___y_3064_ = v___y_3083_;
v___y_3065_ = v___y_3084_;
v___y_3066_ = v___y_3085_;
v___y_3067_ = v___y_3086_;
v___y_3068_ = v___x_3091_;
v___y_3069_ = v___x_3097_;
goto v___jp_3063_;
}
else
{
uint8_t v___x_3098_; 
v___x_3098_ = lean_byte_array_fget(v___y_3083_, v___x_3093_);
lean_dec(v___x_3093_);
v___y_3064_ = v___y_3083_;
v___y_3065_ = v___y_3084_;
v___y_3066_ = v___y_3085_;
v___y_3067_ = v___y_3086_;
v___y_3068_ = v___x_3091_;
v___y_3069_ = v___x_3098_;
goto v___jp_3063_;
}
}
v___jp_3099_:
{
uint64_t v___x_3103_; uint64_t v___x_3104_; uint64_t v___x_3105_; uint64_t v___x_3106_; lean_object* v___x_3107_; 
v___x_3103_ = lean_uint8_to_uint64(v___y_3102_);
v___x_3104_ = 8ULL;
v___x_3105_ = lean_uint64_shift_left(v___x_3103_, v___x_3104_);
v___x_3106_ = lean_uint64_lor(v___y_3100_, v___x_3105_);
v___x_3107_ = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(v___x_3107_, 0, v___y_3101_);
lean_ctor_set_uint64(v___x_3107_, sizeof(void*)*1, v___x_3106_);
v___y_3049_ = v___x_3107_;
goto v___jp_3048_;
}
v___jp_3108_:
{
uint64_t v_a_3115_; 
v_a_3115_ = lean_uint8_to_uint64(v___y_3114_);
switch(v___y_3111_)
{
case 0:
{
lean_object* v___x_3116_; 
lean_dec(v___y_3112_);
v___x_3116_ = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(v___x_3116_, 0, v___y_3113_);
lean_ctor_set_uint64(v___x_3116_, sizeof(void*)*1, v_a_3115_);
v___y_3049_ = v___x_3116_;
goto v___jp_3048_;
}
case 1:
{
lean_object* v___x_3117_; lean_object* v___x_3118_; uint8_t v___x_3119_; 
v___x_3117_ = lean_unsigned_to_nat(1u);
v___x_3118_ = lean_nat_add(v___y_3112_, v___x_3117_);
lean_dec(v___y_3112_);
v___x_3119_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v___y_3109_, v___x_3118_);
if (v___x_3119_ == 0)
{
lean_object* v___x_3120_; lean_object* v___x_3121_; uint8_t v___x_3122_; 
lean_dec(v___x_3118_);
v___x_3120_ = lean_box(v___y_3110_);
v___x_3121_ = l_outOfBounds___redArg(v___x_3120_);
lean_dec(v___x_3120_);
v___x_3122_ = lean_unbox(v___x_3121_);
lean_dec(v___x_3121_);
v___y_3100_ = v_a_3115_;
v___y_3101_ = v___y_3113_;
v___y_3102_ = v___x_3122_;
goto v___jp_3099_;
}
else
{
uint8_t v___x_3123_; 
v___x_3123_ = lean_byte_array_fget(v___y_3109_, v___x_3118_);
lean_dec(v___x_3118_);
v___y_3100_ = v_a_3115_;
v___y_3101_ = v___y_3113_;
v___y_3102_ = v___x_3123_;
goto v___jp_3099_;
}
}
default: 
{
lean_object* v___x_3124_; lean_object* v___x_3125_; uint8_t v___x_3126_; 
v___x_3124_ = lean_unsigned_to_nat(1u);
v___x_3125_ = lean_nat_add(v___y_3112_, v___x_3124_);
v___x_3126_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v___y_3109_, v___x_3125_);
if (v___x_3126_ == 0)
{
lean_object* v___x_3127_; lean_object* v___x_3128_; uint8_t v___x_3129_; 
lean_dec(v___x_3125_);
v___x_3127_ = lean_box(v___y_3110_);
v___x_3128_ = l_outOfBounds___redArg(v___x_3127_);
lean_dec(v___x_3127_);
v___x_3129_ = lean_unbox(v___x_3128_);
lean_dec(v___x_3128_);
v___y_3082_ = v_a_3115_;
v___y_3083_ = v___y_3109_;
v___y_3084_ = v___y_3110_;
v___y_3085_ = v___y_3112_;
v___y_3086_ = v___y_3113_;
v___y_3087_ = v___x_3129_;
goto v___jp_3081_;
}
else
{
uint8_t v___x_3130_; 
v___x_3130_ = lean_byte_array_fget(v___y_3109_, v___x_3125_);
lean_dec(v___x_3125_);
v___y_3082_ = v_a_3115_;
v___y_3083_ = v___y_3109_;
v___y_3084_ = v___y_3110_;
v___y_3085_ = v___y_3112_;
v___y_3086_ = v___y_3113_;
v___y_3087_ = v___x_3130_;
goto v___jp_3081_;
}
}
}
}
v___jp_3131_:
{
if (v___y_3137_ == 0)
{
uint8_t v___x_3138_; 
v___x_3138_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v___y_3132_, v___y_3135_);
if (v___x_3138_ == 0)
{
lean_object* v___x_3139_; lean_object* v___x_3140_; uint8_t v___x_3141_; 
v___x_3139_ = lean_box(v___y_3133_);
v___x_3140_ = l_outOfBounds___redArg(v___x_3139_);
lean_dec(v___x_3139_);
v___x_3141_ = lean_unbox(v___x_3140_);
lean_dec(v___x_3140_);
v___y_3109_ = v___y_3132_;
v___y_3110_ = v___y_3133_;
v___y_3111_ = v___y_3134_;
v___y_3112_ = v___y_3135_;
v___y_3113_ = v___y_3136_;
v___y_3114_ = v___x_3141_;
goto v___jp_3108_;
}
else
{
uint8_t v___x_3142_; 
v___x_3142_ = lean_byte_array_fget(v___y_3132_, v___y_3135_);
v___y_3109_ = v___y_3132_;
v___y_3110_ = v___y_3133_;
v___y_3111_ = v___y_3134_;
v___y_3112_ = v___y_3135_;
v___y_3113_ = v___y_3136_;
v___y_3114_ = v___x_3142_;
goto v___jp_3108_;
}
}
else
{
size_t v_pos_3143_; uint8_t v___x_3144_; uint64_t v_a_3145_; 
v_pos_3143_ = lean_usize_of_nat(v___y_3135_);
lean_dec(v___y_3135_);
v___x_3144_ = lean_byte_array_uget(v___y_3132_, v_pos_3143_);
v_a_3145_ = lean_uint8_to_uint64(v___x_3144_);
switch(v___y_3134_)
{
case 0:
{
lean_object* v___x_3146_; 
v___x_3146_ = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(v___x_3146_, 0, v___y_3136_);
lean_ctor_set_uint64(v___x_3146_, sizeof(void*)*1, v_a_3145_);
v___y_3049_ = v___x_3146_;
goto v___jp_3048_;
}
case 1:
{
size_t v___x_3147_; size_t v___x_3148_; uint8_t v___x_3149_; uint64_t v___x_3150_; uint64_t v___x_3151_; uint64_t v___x_3152_; uint64_t v___x_3153_; lean_object* v___x_3154_; 
v___x_3147_ = ((size_t)1ULL);
v___x_3148_ = lean_usize_add(v_pos_3143_, v___x_3147_);
v___x_3149_ = lean_byte_array_uget(v___y_3132_, v___x_3148_);
v___x_3150_ = lean_uint8_to_uint64(v___x_3149_);
v___x_3151_ = 8ULL;
v___x_3152_ = lean_uint64_shift_left(v___x_3150_, v___x_3151_);
v___x_3153_ = lean_uint64_lor(v_a_3145_, v___x_3152_);
v___x_3154_ = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(v___x_3154_, 0, v___y_3136_);
lean_ctor_set_uint64(v___x_3154_, sizeof(void*)*1, v___x_3153_);
v___y_3049_ = v___x_3154_;
goto v___jp_3048_;
}
default: 
{
size_t v___x_3155_; size_t v___x_3156_; uint8_t v___x_3157_; uint64_t v___x_3158_; uint64_t v___x_3159_; uint64_t v___x_3160_; uint64_t v___x_3161_; size_t v___x_3162_; size_t v___x_3163_; uint8_t v___x_3164_; uint64_t v___x_3165_; uint64_t v___x_3166_; uint64_t v___x_3167_; uint64_t v___x_3168_; size_t v___x_3169_; size_t v___x_3170_; uint8_t v___x_3171_; uint64_t v___x_3172_; uint64_t v___x_3173_; uint64_t v___x_3174_; uint64_t v___x_3175_; lean_object* v___x_3176_; 
v___x_3155_ = ((size_t)1ULL);
v___x_3156_ = lean_usize_add(v_pos_3143_, v___x_3155_);
v___x_3157_ = lean_byte_array_uget(v___y_3132_, v___x_3156_);
v___x_3158_ = lean_uint8_to_uint64(v___x_3157_);
v___x_3159_ = 8ULL;
v___x_3160_ = lean_uint64_shift_left(v___x_3158_, v___x_3159_);
v___x_3161_ = lean_uint64_lor(v_a_3145_, v___x_3160_);
v___x_3162_ = ((size_t)2ULL);
v___x_3163_ = lean_usize_add(v_pos_3143_, v___x_3162_);
v___x_3164_ = lean_byte_array_uget(v___y_3132_, v___x_3163_);
v___x_3165_ = lean_uint8_to_uint64(v___x_3164_);
v___x_3166_ = 16ULL;
v___x_3167_ = lean_uint64_shift_left(v___x_3165_, v___x_3166_);
v___x_3168_ = lean_uint64_lor(v___x_3161_, v___x_3167_);
v___x_3169_ = ((size_t)3ULL);
v___x_3170_ = lean_usize_add(v_pos_3143_, v___x_3169_);
v___x_3171_ = lean_byte_array_uget(v___y_3132_, v___x_3170_);
v___x_3172_ = lean_uint8_to_uint64(v___x_3171_);
v___x_3173_ = 24ULL;
v___x_3174_ = lean_uint64_shift_left(v___x_3172_, v___x_3173_);
v___x_3175_ = lean_uint64_lor(v___x_3168_, v___x_3174_);
v___x_3176_ = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(v___x_3176_, 0, v___y_3136_);
lean_ctor_set_uint64(v___x_3176_, sizeof(void*)*1, v___x_3175_);
v___y_3049_ = v___x_3176_;
goto v___jp_3048_;
}
}
}
}
v___jp_3177_:
{
lean_object* v_offset_3183_; lean_object* v___x_3184_; lean_object* v___x_3185_; uint8_t v___x_3186_; 
v_offset_3183_ = lean_nat_mul(v_v_3045_, v___y_3182_);
lean_dec(v_v_3045_);
v___x_3184_ = lean_nat_add(v_offset_3183_, v___y_3182_);
v___x_3185_ = lean_byte_array_size(v___y_3178_);
v___x_3186_ = lean_nat_dec_le(v___x_3184_, v___x_3185_);
if (v___x_3186_ == 0)
{
lean_dec(v___x_3184_);
v___y_3132_ = v___y_3178_;
v___y_3133_ = v___y_3179_;
v___y_3134_ = v___y_3180_;
v___y_3135_ = v_offset_3183_;
v___y_3136_ = v___y_3181_;
v___y_3137_ = v___x_3186_;
goto v___jp_3131_;
}
else
{
size_t v___x_3187_; lean_object* v___x_3188_; uint8_t v___x_3189_; 
v___x_3187_ = lean_usize_of_nat(v___x_3184_);
v___x_3188_ = lean_usize_to_nat(v___x_3187_);
v___x_3189_ = lean_nat_dec_eq(v___x_3188_, v___x_3184_);
lean_dec(v___x_3184_);
lean_dec(v___x_3188_);
v___y_3132_ = v___y_3178_;
v___y_3133_ = v___y_3179_;
v___y_3134_ = v___y_3180_;
v___y_3135_ = v_offset_3183_;
v___y_3136_ = v___y_3181_;
v___y_3137_ = v___x_3189_;
goto v___jp_3131_;
}
}
v___jp_3190_:
{
lean_object* v___x_3192_; uint8_t v___x_3193_; uint8_t v___x_3194_; 
lean_inc_ref(v_table_3036_);
v___x_3192_ = lp_Hex_Hex_Groebner_MonomialTable_exponentsAt(v_table_3036_, v___y_3191_);
lean_dec(v___y_3191_);
v___x_3193_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_3037_);
v___x_3194_ = 0;
switch(v___x_3193_)
{
case 0:
{
lean_object* v___x_3195_; 
v___x_3195_ = lean_unsigned_to_nat(1u);
v___y_3178_ = v_coefficients_3044_;
v___y_3179_ = v___x_3194_;
v___y_3180_ = v___x_3193_;
v___y_3181_ = v___x_3192_;
v___y_3182_ = v___x_3195_;
goto v___jp_3177_;
}
case 1:
{
lean_object* v___x_3196_; 
v___x_3196_ = lean_unsigned_to_nat(2u);
v___y_3178_ = v_coefficients_3044_;
v___y_3179_ = v___x_3194_;
v___y_3180_ = v___x_3193_;
v___y_3181_ = v___x_3192_;
v___y_3182_ = v___x_3196_;
goto v___jp_3177_;
}
default: 
{
lean_object* v___x_3197_; 
v___x_3197_ = lean_unsigned_to_nat(4u);
v___y_3178_ = v_coefficients_3044_;
v___y_3179_ = v___x_3194_;
v___y_3180_ = v___x_3193_;
v___y_3181_ = v___x_3192_;
v___y_3182_ = v___x_3197_;
goto v___jp_3177_;
}
}
}
v___jp_3198_:
{
uint64_t v___x_3201_; uint64_t v___x_3202_; uint64_t v___x_3203_; uint64_t v___x_3204_; lean_object* v___x_3205_; 
v___x_3201_ = lean_uint8_to_uint64(v___y_3200_);
v___x_3202_ = 24ULL;
v___x_3203_ = lean_uint64_shift_left(v___x_3201_, v___x_3202_);
v___x_3204_ = lean_uint64_lor(v___y_3199_, v___x_3203_);
v___x_3205_ = lean_uint64_to_nat(v___x_3204_);
v___y_3191_ = v___x_3205_;
goto v___jp_3190_;
}
v___jp_3209_:
{
uint64_t v___x_3212_; uint64_t v___x_3213_; uint64_t v___x_3214_; uint64_t v___x_3215_; lean_object* v___x_3216_; lean_object* v___x_3217_; uint8_t v___x_3218_; 
v___x_3212_ = lean_uint8_to_uint64(v___y_3211_);
v___x_3213_ = 16ULL;
v___x_3214_ = lean_uint64_shift_left(v___x_3212_, v___x_3213_);
v___x_3215_ = lean_uint64_lor(v___y_3210_, v___x_3214_);
v___x_3216_ = lean_unsigned_to_nat(3u);
v___x_3217_ = lean_nat_add(v_offset_3208_, v___x_3216_);
lean_dec(v_offset_3208_);
v___x_3218_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v_support_3043_, v___x_3217_);
if (v___x_3218_ == 0)
{
lean_object* v___x_3219_; lean_object* v___x_3220_; uint8_t v___x_3221_; 
lean_dec(v___x_3217_);
v___x_3219_ = lean_box(v___x_3206_);
v___x_3220_ = l_outOfBounds___redArg(v___x_3219_);
lean_dec(v___x_3219_);
v___x_3221_ = lean_unbox(v___x_3220_);
lean_dec(v___x_3220_);
v___y_3199_ = v___x_3215_;
v___y_3200_ = v___x_3221_;
goto v___jp_3198_;
}
else
{
uint8_t v___x_3222_; 
v___x_3222_ = lean_byte_array_fget(v_support_3043_, v___x_3217_);
lean_dec(v___x_3217_);
v___y_3199_ = v___x_3215_;
v___y_3200_ = v___x_3222_;
goto v___jp_3198_;
}
}
v___jp_3223_:
{
uint64_t v___x_3226_; uint64_t v___x_3227_; uint64_t v___x_3228_; uint64_t v___x_3229_; lean_object* v___x_3230_; lean_object* v___x_3231_; uint8_t v___x_3232_; 
v___x_3226_ = lean_uint8_to_uint64(v___y_3225_);
v___x_3227_ = 8ULL;
v___x_3228_ = lean_uint64_shift_left(v___x_3226_, v___x_3227_);
v___x_3229_ = lean_uint64_lor(v___y_3224_, v___x_3228_);
v___x_3230_ = lean_unsigned_to_nat(2u);
v___x_3231_ = lean_nat_add(v_offset_3208_, v___x_3230_);
v___x_3232_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v_support_3043_, v___x_3231_);
if (v___x_3232_ == 0)
{
lean_object* v___x_3233_; lean_object* v___x_3234_; uint8_t v___x_3235_; 
lean_dec(v___x_3231_);
v___x_3233_ = lean_box(v___x_3206_);
v___x_3234_ = l_outOfBounds___redArg(v___x_3233_);
lean_dec(v___x_3233_);
v___x_3235_ = lean_unbox(v___x_3234_);
lean_dec(v___x_3234_);
v___y_3210_ = v___x_3229_;
v___y_3211_ = v___x_3235_;
goto v___jp_3209_;
}
else
{
uint8_t v___x_3236_; 
v___x_3236_ = lean_byte_array_fget(v_support_3043_, v___x_3231_);
lean_dec(v___x_3231_);
v___y_3210_ = v___x_3229_;
v___y_3211_ = v___x_3236_;
goto v___jp_3209_;
}
}
v___jp_3237_:
{
uint64_t v_a_3239_; lean_object* v___x_3240_; lean_object* v___x_3241_; uint8_t v___x_3242_; 
v_a_3239_ = lean_uint8_to_uint64(v___y_3238_);
v___x_3240_ = lean_unsigned_to_nat(1u);
v___x_3241_ = lean_nat_add(v_offset_3208_, v___x_3240_);
v___x_3242_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v_support_3043_, v___x_3241_);
if (v___x_3242_ == 0)
{
lean_object* v___x_3243_; lean_object* v___x_3244_; uint8_t v___x_3245_; 
lean_dec(v___x_3241_);
v___x_3243_ = lean_box(v___x_3206_);
v___x_3244_ = l_outOfBounds___redArg(v___x_3243_);
lean_dec(v___x_3243_);
v___x_3245_ = lean_unbox(v___x_3244_);
lean_dec(v___x_3244_);
v___y_3224_ = v_a_3239_;
v___y_3225_ = v___x_3245_;
goto v___jp_3223_;
}
else
{
uint8_t v___x_3246_; 
v___x_3246_ = lean_byte_array_fget(v_support_3043_, v___x_3241_);
lean_dec(v___x_3241_);
v___y_3224_ = v_a_3239_;
v___y_3225_ = v___x_3246_;
goto v___jp_3223_;
}
}
v___jp_3247_:
{
if (v___y_3248_ == 0)
{
uint8_t v___x_3249_; 
v___x_3249_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___lam__0(v_support_3043_, v_offset_3208_);
if (v___x_3249_ == 0)
{
lean_object* v___x_3250_; lean_object* v___x_3251_; uint8_t v___x_3252_; 
v___x_3250_ = lean_box(v___x_3206_);
v___x_3251_ = l_outOfBounds___redArg(v___x_3250_);
lean_dec(v___x_3250_);
v___x_3252_ = lean_unbox(v___x_3251_);
lean_dec(v___x_3251_);
v___y_3238_ = v___x_3252_;
goto v___jp_3237_;
}
else
{
uint8_t v___x_3253_; 
v___x_3253_ = lean_byte_array_fget(v_support_3043_, v_offset_3208_);
v___y_3238_ = v___x_3253_;
goto v___jp_3237_;
}
}
else
{
size_t v_pos_3254_; uint8_t v___x_3255_; uint64_t v_a_3256_; size_t v___x_3257_; size_t v___x_3258_; uint8_t v___x_3259_; uint64_t v___x_3260_; uint64_t v___x_3261_; uint64_t v___x_3262_; uint64_t v___x_3263_; size_t v___x_3264_; size_t v___x_3265_; uint8_t v___x_3266_; uint64_t v___x_3267_; uint64_t v___x_3268_; uint64_t v___x_3269_; uint64_t v___x_3270_; size_t v___x_3271_; size_t v___x_3272_; uint8_t v___x_3273_; uint64_t v___x_3274_; uint64_t v___x_3275_; uint64_t v___x_3276_; uint64_t v___x_3277_; lean_object* v___x_3278_; 
v_pos_3254_ = lean_usize_of_nat(v_offset_3208_);
lean_dec(v_offset_3208_);
v___x_3255_ = lean_byte_array_uget(v_support_3043_, v_pos_3254_);
v_a_3256_ = lean_uint8_to_uint64(v___x_3255_);
v___x_3257_ = ((size_t)1ULL);
v___x_3258_ = lean_usize_add(v_pos_3254_, v___x_3257_);
v___x_3259_ = lean_byte_array_uget(v_support_3043_, v___x_3258_);
v___x_3260_ = lean_uint8_to_uint64(v___x_3259_);
v___x_3261_ = 8ULL;
v___x_3262_ = lean_uint64_shift_left(v___x_3260_, v___x_3261_);
v___x_3263_ = lean_uint64_lor(v_a_3256_, v___x_3262_);
v___x_3264_ = ((size_t)2ULL);
v___x_3265_ = lean_usize_add(v_pos_3254_, v___x_3264_);
v___x_3266_ = lean_byte_array_uget(v_support_3043_, v___x_3265_);
v___x_3267_ = lean_uint8_to_uint64(v___x_3266_);
v___x_3268_ = 16ULL;
v___x_3269_ = lean_uint64_shift_left(v___x_3267_, v___x_3268_);
v___x_3270_ = lean_uint64_lor(v___x_3263_, v___x_3269_);
v___x_3271_ = ((size_t)3ULL);
v___x_3272_ = lean_usize_add(v_pos_3254_, v___x_3271_);
v___x_3273_ = lean_byte_array_uget(v_support_3043_, v___x_3272_);
v___x_3274_ = lean_uint8_to_uint64(v___x_3273_);
v___x_3275_ = 24ULL;
v___x_3276_ = lean_uint64_shift_left(v___x_3274_, v___x_3275_);
v___x_3277_ = lean_uint64_lor(v___x_3270_, v___x_3276_);
v___x_3278_ = lean_uint64_to_nat(v___x_3277_);
v___y_3191_ = v___x_3278_;
goto v___jp_3190_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0___boxed(lean_object* v_table_3285_, lean_object* v_field_3286_, lean_object* v_p_3287_, lean_object* v_sz_3288_, lean_object* v_i_3289_, lean_object* v_bs_3290_){
_start:
{
uint64_t v_field_boxed_3291_; size_t v_sz_boxed_3292_; size_t v_i_boxed_3293_; lean_object* v_res_3294_; 
v_field_boxed_3291_ = lean_unbox_uint64(v_field_3286_);
lean_dec_ref(v_field_3286_);
v_sz_boxed_3292_ = lean_unbox_usize(v_sz_3288_);
lean_dec(v_sz_3288_);
v_i_boxed_3293_ = lean_unbox_usize(v_i_3289_);
lean_dec(v_i_3289_);
v_res_3294_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0(v_table_3285_, v_field_boxed_3291_, v_p_3287_, v_sz_boxed_3292_, v_i_boxed_3293_, v_bs_3290_);
lean_dec_ref(v_p_3287_);
return v_res_3294_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toRaw(uint64_t v_field_3295_, lean_object* v_table_3296_, lean_object* v_p_3297_){
_start:
{
lean_object* v_support_3298_; lean_object* v___x_3299_; lean_object* v___x_3300_; lean_object* v___x_3301_; lean_object* v___x_3302_; size_t v_sz_3303_; size_t v___x_3304_; lean_object* v___x_3305_; 
v_support_3298_ = lean_ctor_get(v_p_3297_, 0);
v___x_3299_ = lean_byte_array_size(v_support_3298_);
v___x_3300_ = lean_unsigned_to_nat(2u);
v___x_3301_ = lean_nat_shiftr(v___x_3299_, v___x_3300_);
v___x_3302_ = l_Array_range(v___x_3301_);
v_sz_3303_ = lean_array_size(v___x_3302_);
v___x_3304_ = ((size_t)0ULL);
v___x_3305_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_Polynomial_toRaw_spec__0(v_table_3296_, v_field_3295_, v_p_3297_, v_sz_3303_, v___x_3304_, v___x_3302_);
return v___x_3305_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toRaw___boxed(lean_object* v_field_3306_, lean_object* v_table_3307_, lean_object* v_p_3308_){
_start:
{
uint64_t v_field_boxed_3309_; lean_object* v_res_3310_; 
v_field_boxed_3309_ = lean_unbox_uint64(v_field_3306_);
lean_dec_ref(v_field_3306_);
v_res_3310_ = lp_Hex_Hex_Groebner_Polynomial_toRaw(v_field_boxed_3309_, v_table_3307_, v_p_3308_);
lean_dec_ref(v_p_3308_);
return v_res_3310_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___lam__0(lean_object* v_n_3311_, lean_object* v_p_3312_, lean_object* v_term_3313_){
_start:
{
lean_object* v_exponents_3314_; uint64_t v_coefficient_3315_; lean_object* v___x_3316_; uint8_t v___x_3317_; 
v_exponents_3314_ = lean_ctor_get(v_term_3313_, 0);
v_coefficient_3315_ = lean_ctor_get_uint64(v_term_3313_, sizeof(void*)*1);
v___x_3316_ = lean_array_get_size(v_exponents_3314_);
v___x_3317_ = lean_nat_dec_eq(v___x_3316_, v_n_3311_);
if (v___x_3317_ == 0)
{
lean_object* v___x_3318_; 
v___x_3318_ = lean_box(0);
return v___x_3318_;
}
else
{
lean_object* v___x_3319_; uint8_t v___x_3320_; 
v___x_3319_ = lean_uint64_to_nat(v_coefficient_3315_);
v___x_3320_ = lean_nat_dec_le(v_p_3312_, v___x_3319_);
if (v___x_3320_ == 0)
{
uint64_t v___x_3321_; lean_object* v___x_3322_; lean_object* v___x_3323_; lean_object* v___x_3324_; 
v___x_3321_ = lp_Hex_Hex_ZMod64_ofNat___redArg(v_p_3312_, v___x_3319_);
lean_dec(v___x_3319_);
v___x_3322_ = lean_box_uint64(v___x_3321_);
lean_inc_ref(v_exponents_3314_);
v___x_3323_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3323_, 0, v_exponents_3314_);
lean_ctor_set(v___x_3323_, 1, v___x_3322_);
v___x_3324_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3324_, 0, v___x_3323_);
return v___x_3324_;
}
else
{
lean_object* v___x_3325_; 
lean_dec(v___x_3319_);
v___x_3325_ = lean_box(0);
return v___x_3325_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___lam__0___boxed(lean_object* v_n_3326_, lean_object* v_p_3327_, lean_object* v_term_3328_){
_start:
{
lean_object* v_res_3329_; 
v_res_3329_ = lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___lam__0(v_n_3326_, v_p_3327_, v_term_3328_);
lean_dec_ref(v_term_3328_);
lean_dec(v_p_3327_);
lean_dec(v_n_3326_);
return v_res_3329_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg(uint8_t v_order_3349_, lean_object* v_p_3350_, lean_object* v_n_3351_, lean_object* v_raw_3352_){
_start:
{
lean_object* v___f_3353_; lean_object* v___x_3354_; lean_object* v___x_3355_; lean_object* v___x_3356_; lean_object* v___x_3357_; 
lean_inc(v_p_3350_);
lean_inc(v_n_3351_);
v___f_3353_ = lean_alloc_closure((void*)(lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___lam__0___boxed), 3, 2);
lean_closure_set(v___f_3353_, 0, v_n_3351_);
lean_closure_set(v___f_3353_, 1, v_p_3350_);
v___x_3354_ = ((lean_object*)(lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___closed__9));
v___x_3355_ = lean_array_to_list(v_raw_3352_);
v___x_3356_ = lean_box(0);
v___x_3357_ = l_List_mapM_loop___redArg(v___x_3354_, v___f_3353_, v___x_3355_, v___x_3356_);
if (lean_obj_tag(v___x_3357_) == 0)
{
lean_object* v___x_3358_; 
lean_dec(v_n_3351_);
lean_dec(v_p_3350_);
v___x_3358_ = lean_box(0);
return v___x_3358_;
}
else
{
lean_object* v_val_3359_; lean_object* v___x_3361_; uint8_t v_isShared_3362_; uint8_t v_isSharedCheck_3374_; 
v_val_3359_ = lean_ctor_get(v___x_3357_, 0);
v_isSharedCheck_3374_ = !lean_is_exclusive(v___x_3357_);
if (v_isSharedCheck_3374_ == 0)
{
v___x_3361_ = v___x_3357_;
v_isShared_3362_ = v_isSharedCheck_3374_;
goto v_resetjp_3360_;
}
else
{
lean_inc(v_val_3359_);
lean_dec(v___x_3357_);
v___x_3361_ = lean_box(0);
v_isShared_3362_ = v_isSharedCheck_3374_;
goto v_resetjp_3360_;
}
v_resetjp_3360_:
{
lean_object* v___x_3363_; lean_object* v___x_3364_; uint64_t v___x_3365_; lean_object* v___x_3366_; lean_object* v___x_3367_; lean_object* v___f_3368_; lean_object* v___x_3369_; lean_object* v___x_3370_; lean_object* v___x_3372_; 
v___x_3363_ = lean_box(v_order_3349_);
v___x_3364_ = lean_alloc_closure((void*)(lp_Hex_Hex_Groebner_TermOrder_cmp___boxed), 4, 2);
lean_closure_set(v___x_3364_, 0, v___x_3363_);
lean_closure_set(v___x_3364_, 1, v_n_3351_);
v___x_3365_ = lp_Hex_Hex_ZMod64_zero___redArg(v_p_3350_);
lean_inc(v_p_3350_);
v___x_3366_ = lean_alloc_closure((void*)(lp_Hex_Hex_ZMod64_addImpl___boxed), 4, 2);
lean_closure_set(v___x_3366_, 0, v_p_3350_);
lean_closure_set(v___x_3366_, 1, lean_box(0));
v___x_3367_ = lean_alloc_closure((void*)(lp_Hex_Hex_ZMod64_instDecidableEq___boxed), 4, 2);
lean_closure_set(v___x_3367_, 0, v_p_3350_);
lean_closure_set(v___x_3367_, 1, lean_box(0));
v___f_3368_ = lean_alloc_closure((void*)(l_instBEqOfDecidableEq___redArg___lam__0___boxed), 3, 1);
lean_closure_set(v___f_3368_, 0, v___x_3367_);
v___x_3369_ = lean_box_uint64(v___x_3365_);
v___x_3370_ = lp_Hex_Hex_MvPoly_ofTerms___redArg(v___x_3364_, v___x_3369_, v___x_3366_, v___f_3368_, v_val_3359_);
if (v_isShared_3362_ == 0)
{
lean_ctor_set(v___x_3361_, 0, v___x_3370_);
v___x_3372_ = v___x_3361_;
goto v_reusejp_3371_;
}
else
{
lean_object* v_reuseFailAlloc_3373_; 
v_reuseFailAlloc_3373_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3373_, 0, v___x_3370_);
v___x_3372_ = v_reuseFailAlloc_3373_;
goto v_reusejp_3371_;
}
v_reusejp_3371_:
{
return v___x_3372_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg___boxed(lean_object* v_order_3375_, lean_object* v_p_3376_, lean_object* v_n_3377_, lean_object* v_raw_3378_){
_start:
{
uint8_t v_order_boxed_3379_; lean_object* v_res_3380_; 
v_order_boxed_3379_ = lean_unbox(v_order_3375_);
v_res_3380_ = lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg(v_order_boxed_3379_, v_p_3376_, v_n_3377_, v_raw_3378_);
return v_res_3380_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly(uint8_t v_order_3381_, lean_object* v_p_3382_, lean_object* v_inst_3383_, lean_object* v_n_3384_, lean_object* v_raw_3385_){
_start:
{
lean_object* v___x_3386_; 
v___x_3386_ = lp_Hex_Hex_Groebner_Polynomial_toMvPoly___redArg(v_order_3381_, v_p_3382_, v_n_3384_, v_raw_3385_);
return v___x_3386_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_toMvPoly___boxed(lean_object* v_order_3387_, lean_object* v_p_3388_, lean_object* v_inst_3389_, lean_object* v_n_3390_, lean_object* v_raw_3391_){
_start:
{
uint8_t v_order_boxed_3392_; lean_object* v_res_3393_; 
v_order_boxed_3392_ = lean_unbox(v_order_3387_);
v_res_3393_ = lp_Hex_Hex_Groebner_Polynomial_toMvPoly(v_order_boxed_3392_, v_p_3388_, v_inst_3389_, v_n_3390_, v_raw_3391_);
return v_res_3393_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___lam__0(lean_object* v_x_3394_){
_start:
{
lean_object* v_fst_3395_; lean_object* v_snd_3396_; lean_object* v___x_3397_; uint64_t v___x_3398_; 
v_fst_3395_ = lean_ctor_get(v_x_3394_, 0);
v_snd_3396_ = lean_ctor_get(v_x_3394_, 1);
lean_inc(v_fst_3395_);
v___x_3397_ = lean_alloc_ctor(0, 1, 8);
lean_ctor_set(v___x_3397_, 0, v_fst_3395_);
v___x_3398_ = lean_unbox_uint64(v_snd_3396_);
lean_ctor_set_uint64(v___x_3397_, sizeof(void*)*1, v___x_3398_);
return v___x_3397_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___lam__0___boxed(lean_object* v_x_3399_){
_start:
{
lean_object* v_res_3400_; 
v_res_3400_ = lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___lam__0(v_x_3399_);
lean_dec_ref(v_x_3399_);
return v_res_3400_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg(lean_object* v_f_3421_){
_start:
{
lean_object* v___f_3422_; lean_object* v___x_3423_; lean_object* v___x_3424_; lean_object* v___x_3425_; size_t v_sz_3426_; size_t v___x_3427_; lean_object* v___x_3428_; 
v___f_3422_ = ((lean_object*)(lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__0));
v___x_3423_ = lp_Hex_Hex_MvPoly_termsList___redArg(v_f_3421_);
v___x_3424_ = lean_array_mk(v___x_3423_);
v___x_3425_ = ((lean_object*)(lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg___closed__10));
v_sz_3426_ = lean_array_size(v___x_3424_);
v___x_3427_ = ((size_t)0ULL);
v___x_3428_ = l___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map(lean_box(0), lean_box(0), lean_box(0), v___x_3425_, v___f_3422_, v_sz_3426_, v___x_3427_, v___x_3424_);
return v___x_3428_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly(uint8_t v_order_3429_, lean_object* v_p_3430_, lean_object* v_inst_3431_, lean_object* v_n_3432_, lean_object* v_f_3433_){
_start:
{
lean_object* v___x_3434_; 
v___x_3434_ = lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___redArg(v_f_3433_);
return v___x_3434_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Polynomial_ofMvPoly___boxed(lean_object* v_order_3435_, lean_object* v_p_3436_, lean_object* v_inst_3437_, lean_object* v_n_3438_, lean_object* v_f_3439_){
_start:
{
uint8_t v_order_boxed_3440_; lean_object* v_res_3441_; 
v_order_boxed_3440_ = lean_unbox(v_order_3435_);
v_res_3441_ = lp_Hex_Hex_Groebner_Polynomial_ofMvPoly(v_order_boxed_3440_, v_p_3436_, v_inst_3437_, v_n_3438_, v_f_3439_);
lean_dec(v_n_3438_);
lean_dec(v_p_3436_);
return v_res_3441_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Runtime(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexMvPoly_Basic(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_Polynomial(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Runtime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexMvPoly_Basic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_Polynomial(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Runtime(uint8_t builtin);
lean_object* initialize_Hex_HexMvPoly_Basic(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_Polynomial(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Runtime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexMvPoly_Basic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Polynomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_Polynomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_Polynomial(builtin);
}
#ifdef __cplusplus
}
#endif
