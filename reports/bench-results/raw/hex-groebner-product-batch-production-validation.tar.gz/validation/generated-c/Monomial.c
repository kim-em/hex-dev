// Lean compiler output
// Module: HexGroebner.Monomial
// Imports: public import Init public meta import Init public import HexGroebner.PackedWord public import HexGroebner.Native public import HexMvPoly.Mono public import HexGroebner.IndexPair
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
uint8_t lean_uint64_to_uint8(uint64_t);
lean_object* lean_byte_array_push(lean_object*, uint8_t);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
lean_object* l_Repr_addAppParen(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_byte_array_size(lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
extern lean_object* l_System_Platform_numBits;
lean_object* lean_nat_pow(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
uint8_t lean_uint64_dec_le(uint64_t, uint64_t);
uint64_t lean_uint64_add(uint64_t, uint64_t);
uint64_t lean_uint64_sub(uint64_t, uint64_t);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t lean_uint64_dec_lt(uint64_t, uint64_t);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_byte_array_uget(lean_object*, size_t);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_usize_to_nat(size_t);
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
uint64_t lean_uint64_of_nat(lean_object*);
uint64_t lean_uint64_land(uint64_t, uint64_t);
lean_object* lean_array_get_size(lean_object*);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
size_t lean_uint64_to_usize(uint64_t);
size_t lean_usize_sub(size_t, size_t);
size_t lean_usize_land(size_t, size_t);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
lean_object* lean_mk_array(lean_object*, lean_object*);
lean_object* lean_array_propagate_mark(lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* lean_array_fset(lean_object*, lean_object*, lean_object*);
uint8_t lp_Hex_Hex_Groebner_instBEqWidth_beq(uint8_t, uint8_t);
lean_object* lean_mk_empty_byte_array(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint64_t lean_uint64_mul(uint64_t, uint64_t);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* lean_nat_mod(lean_object*, lean_object*);
uint8_t lean_uint8_of_nat(lean_object*);
uint8_t lean_hex_groebner_equal_monomial(uint8_t, uint64_t, uint64_t, lean_object*, lean_object*);
lean_object* lean_hex_groebner_prepare_monomial(uint8_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*);
uint64_t lp_Hex_Hex_Groebner_Packed_read64Fast(lean_object*, lean_object*);
extern lean_object* l_ByteArray_empty;
lean_object* lean_string_length(lean_object*);
lean_object* lean_uint32_to_nat(uint32_t);
uint64_t lean_uint32_to_uint64(uint32_t);
uint32_t lean_uint32_of_nat(lean_object*);
lean_object* l_Array_range(lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* l_Id_instMonad___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instHashableUInt64___lam__0___boxed(lean_object*);
lean_object* l_Id_instMonad___lam__3(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Ordering_ctorIdx(uint8_t);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__6(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__2___boxed(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_Mono_lex___redArg(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_Mono_grlex(lean_object*, lean_object*, lean_object*);
uint8_t lp_Hex_Hex_Mono_grevlex(lean_object*, lean_object*, lean_object*);
lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instDecidableEqUInt64___boxed(lean_object*, lean_object*);
lean_object* l_instBEqOfDecidableEq___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_lex_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_lex_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_lex_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_lex_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grlex_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grlex_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grlex_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grlex_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grevlex_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grevlex_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grevlex_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grevlex_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqTermOrder_beq(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqTermOrder_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqTermOrder___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqTermOrder_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqTermOrder___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqTermOrder___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqTermOrder = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqTermOrder___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "Hex.Groebner.TermOrder.lex"};
static const lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__1_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 29, .m_capacity = 29, .m_length = 28, .m_data = "Hex.Groebner.TermOrder.grlex"};
static const lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__3_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 31, .m_capacity = 31, .m_length = 30, .m_data = "Hex.Groebner.TermOrder.grevlex"};
static const lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__5_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr(uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprTermOrder___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprTermOrder_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprTermOrder___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprTermOrder = (const lean_object*)&lp_Hex_Hex_Groebner_instReprTermOrder___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_TermOrder_ofNat(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ofNat___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqTermOrder(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqTermOrder___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instInhabitedTermOrder_default;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instInhabitedTermOrder;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_TermOrder_cmp(uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_cmp___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_arity_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_arity_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_arity_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_arity_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_index_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_index_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_index_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_index_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_exponent_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_exponent_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_exponent_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_exponent_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_degree_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_degree_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_degree_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_degree_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_address_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_address_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_address_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_address_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_storage_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_storage_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_storage_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_storage_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_monomials_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_monomials_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_monomials_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_monomials_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_work_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_work_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_work_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_work_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqMonomialError_beq(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqMonomialError_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqMonomialError___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqMonomialError_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqMonomialError___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqMonomialError___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqMonomialError = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqMonomialError___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "Hex.Groebner.MonomialError.arity"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__1_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "Hex.Groebner.MonomialError.index"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__3_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 36, .m_capacity = 36, .m_length = 35, .m_data = "Hex.Groebner.MonomialError.exponent"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__5_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "Hex.Groebner.MonomialError.degree"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__6_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__6_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__7 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__7_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "Hex.Groebner.MonomialError.address"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__8_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__9_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "Hex.Groebner.MonomialError.storage"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__10 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__10_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__10_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__11 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__11_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 37, .m_capacity = 37, .m_length = 36, .m_data = "Hex.Groebner.MonomialError.monomials"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__12 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__12_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__12_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__13 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__13_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 39, .m_capacity = 39, .m_length = 38, .m_data = "Hex.Groebner.MonomialError.packedBytes"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__14 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__14_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__14_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__15 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__15_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 32, .m_capacity = 32, .m_length = 31, .m_data = "Hex.Groebner.MonomialError.work"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__16 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__16_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__16_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__17 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__17_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr(uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprMonomialError___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprMonomialError_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprMonomialError = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialError___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqMonomialFailure_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqMonomialFailure_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqMonomialFailure___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqMonomialFailure_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqMonomialFailure___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqMonomialFailure___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqMonomialFailure = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqMonomialFailure___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_Groebner_instReprMonomialFailure_repr_spec__0(lean_object*);
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "{ "};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "error"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__3_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = " := "};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__5_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__3_value),((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__5_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__6_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__7;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ","};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__8_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__9_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "work"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__10 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__10_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__10_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__11 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__11_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__12;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = " }"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__13 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__13_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__14;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__15;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__16 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__16_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__13_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__17 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__17_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprMonomialFailure___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMonomialFailure___closed__0_value;
LEAN_EXPORT uint64_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_reserve(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_reserve___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_workspaceBytes(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_workspaceBytes___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_bytes(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_bytes___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_shape(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_shape___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_MonomialTable_exponent(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_exponent___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_degree(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_degree___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_MonomialTable_mask(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_mask___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_MonomialTable_hashAt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_hashAt___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_exponentsAt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_exponentsAt___boxed(lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_MonomialTable_divides(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_divides___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_Groebner_MonomialTable_compare___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_MonomialTable_compare___closed__0;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_MonomialTable_compare(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_compare___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
LEAN_EXPORT const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg___boxed__const__1 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg___boxed__const__1_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1___redArg(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen(lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___lam__0(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__0, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__0 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__0_value;
static const lean_closure_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__1___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__1 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__1_value;
static const lean_closure_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__2___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__2 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__2_value;
static const lean_closure_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__3, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__3 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__3_value;
static const lean_closure_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__4___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__4 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__4_value;
static const lean_closure_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__5___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__5 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__5_value;
static const lean_closure_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__6, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__6 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__6_value;
static const lean_ctor_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__0_value),((lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__1_value)}};
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__7 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__7_value;
static const lean_ctor_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__7_value),((lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__2_value),((lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__3_value),((lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__4_value),((lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__5_value)}};
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__8 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__8_value;
static const lean_ctor_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__8_value),((lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__6_value)}};
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__9 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__9_value;
static const lean_closure_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instHashableUInt64___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__10 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__10_value;
static lean_once_cell_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__11;
static lean_once_cell_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12;
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append(lean_object*, uint8_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7_spec__9___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5___redArg(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4___redArg(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___redArg(uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___redArg(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2___redArg(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2(lean_object*, lean_object*, uint8_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5___redArg(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___redArg(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__0___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(37, 35, 34, 132, 228, 156, 242, 203)}};
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__0___boxed__const__1 = (const lean_object*)&lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__0___boxed__const__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg___boxed__const__1_value),((lean_object*)&lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__0___boxed__const__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__1_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__2;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_internOwned(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_internOwned___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3(lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3(lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6(lean_object*, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7_spec__9(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_intern(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_intern___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation_beq(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation = (const lean_object*)&lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1(lean_object*, lean_object*, uint8_t, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__0(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked___closed__0 = (const lean_object*)&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0___redArg(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2_spec__3___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___redArg(uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0___redArg(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss(lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0(lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2(lean_object*, uint64_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2_spec__3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0___redArg(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___redArg(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_combineOwned(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_combineOwned___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0(lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_mapProducts(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_mapProducts___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_combine(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_combine___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorIdx(uint8_t v_x_1_){
_start:
{
switch(v_x_1_)
{
case 0:
{
lean_object* v___x_2_; 
v___x_2_ = lean_unsigned_to_nat(0u);
return v___x_2_;
}
case 1:
{
lean_object* v___x_3_; 
v___x_3_ = lean_unsigned_to_nat(1u);
return v___x_3_;
}
default: 
{
lean_object* v___x_4_; 
v___x_4_ = lean_unsigned_to_nat(2u);
return v___x_4_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorIdx___boxed(lean_object* v_x_5_){
_start:
{
uint8_t v_x_boxed_6_; lean_object* v_res_7_; 
v_x_boxed_6_ = lean_unbox(v_x_5_);
v_res_7_ = lp_Hex_Hex_Groebner_TermOrder_ctorIdx(v_x_boxed_6_);
return v_res_7_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorElim___redArg(lean_object* v_k_8_){
_start:
{
lean_inc(v_k_8_);
return v_k_8_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorElim___redArg___boxed(lean_object* v_k_9_){
_start:
{
lean_object* v_res_10_; 
v_res_10_ = lp_Hex_Hex_Groebner_TermOrder_ctorElim___redArg(v_k_9_);
lean_dec(v_k_9_);
return v_res_10_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorElim(lean_object* v_motive_11_, lean_object* v_ctorIdx_12_, uint8_t v_t_13_, lean_object* v_h_14_, lean_object* v_k_15_){
_start:
{
lean_inc(v_k_15_);
return v_k_15_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ctorElim___boxed(lean_object* v_motive_16_, lean_object* v_ctorIdx_17_, lean_object* v_t_18_, lean_object* v_h_19_, lean_object* v_k_20_){
_start:
{
uint8_t v_t_boxed_21_; lean_object* v_res_22_; 
v_t_boxed_21_ = lean_unbox(v_t_18_);
v_res_22_ = lp_Hex_Hex_Groebner_TermOrder_ctorElim(v_motive_16_, v_ctorIdx_17_, v_t_boxed_21_, v_h_19_, v_k_20_);
lean_dec(v_k_20_);
lean_dec(v_ctorIdx_17_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_lex_elim___redArg(lean_object* v_lex_23_){
_start:
{
lean_inc(v_lex_23_);
return v_lex_23_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_lex_elim___redArg___boxed(lean_object* v_lex_24_){
_start:
{
lean_object* v_res_25_; 
v_res_25_ = lp_Hex_Hex_Groebner_TermOrder_lex_elim___redArg(v_lex_24_);
lean_dec(v_lex_24_);
return v_res_25_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_lex_elim(lean_object* v_motive_26_, uint8_t v_t_27_, lean_object* v_h_28_, lean_object* v_lex_29_){
_start:
{
lean_inc(v_lex_29_);
return v_lex_29_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_lex_elim___boxed(lean_object* v_motive_30_, lean_object* v_t_31_, lean_object* v_h_32_, lean_object* v_lex_33_){
_start:
{
uint8_t v_t_boxed_34_; lean_object* v_res_35_; 
v_t_boxed_34_ = lean_unbox(v_t_31_);
v_res_35_ = lp_Hex_Hex_Groebner_TermOrder_lex_elim(v_motive_30_, v_t_boxed_34_, v_h_32_, v_lex_33_);
lean_dec(v_lex_33_);
return v_res_35_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grlex_elim___redArg(lean_object* v_grlex_36_){
_start:
{
lean_inc(v_grlex_36_);
return v_grlex_36_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grlex_elim___redArg___boxed(lean_object* v_grlex_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_Hex_Hex_Groebner_TermOrder_grlex_elim___redArg(v_grlex_37_);
lean_dec(v_grlex_37_);
return v_res_38_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grlex_elim(lean_object* v_motive_39_, uint8_t v_t_40_, lean_object* v_h_41_, lean_object* v_grlex_42_){
_start:
{
lean_inc(v_grlex_42_);
return v_grlex_42_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grlex_elim___boxed(lean_object* v_motive_43_, lean_object* v_t_44_, lean_object* v_h_45_, lean_object* v_grlex_46_){
_start:
{
uint8_t v_t_boxed_47_; lean_object* v_res_48_; 
v_t_boxed_47_ = lean_unbox(v_t_44_);
v_res_48_ = lp_Hex_Hex_Groebner_TermOrder_grlex_elim(v_motive_43_, v_t_boxed_47_, v_h_45_, v_grlex_46_);
lean_dec(v_grlex_46_);
return v_res_48_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grevlex_elim___redArg(lean_object* v_grevlex_49_){
_start:
{
lean_inc(v_grevlex_49_);
return v_grevlex_49_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grevlex_elim___redArg___boxed(lean_object* v_grevlex_50_){
_start:
{
lean_object* v_res_51_; 
v_res_51_ = lp_Hex_Hex_Groebner_TermOrder_grevlex_elim___redArg(v_grevlex_50_);
lean_dec(v_grevlex_50_);
return v_res_51_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grevlex_elim(lean_object* v_motive_52_, uint8_t v_t_53_, lean_object* v_h_54_, lean_object* v_grevlex_55_){
_start:
{
lean_inc(v_grevlex_55_);
return v_grevlex_55_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_grevlex_elim___boxed(lean_object* v_motive_56_, lean_object* v_t_57_, lean_object* v_h_58_, lean_object* v_grevlex_59_){
_start:
{
uint8_t v_t_boxed_60_; lean_object* v_res_61_; 
v_t_boxed_60_ = lean_unbox(v_t_57_);
v_res_61_ = lp_Hex_Hex_Groebner_TermOrder_grevlex_elim(v_motive_56_, v_t_boxed_60_, v_h_58_, v_grevlex_59_);
lean_dec(v_grevlex_59_);
return v_res_61_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqTermOrder_beq(uint8_t v_x_62_, uint8_t v_y_63_){
_start:
{
lean_object* v___x_64_; lean_object* v___x_65_; uint8_t v___x_66_; 
v___x_64_ = lp_Hex_Hex_Groebner_TermOrder_ctorIdx(v_x_62_);
v___x_65_ = lp_Hex_Hex_Groebner_TermOrder_ctorIdx(v_y_63_);
v___x_66_ = lean_nat_dec_eq(v___x_64_, v___x_65_);
lean_dec(v___x_65_);
lean_dec(v___x_64_);
return v___x_66_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqTermOrder_beq___boxed(lean_object* v_x_67_, lean_object* v_y_68_){
_start:
{
uint8_t v_x_21__boxed_69_; uint8_t v_y_22__boxed_70_; uint8_t v_res_71_; lean_object* v_r_72_; 
v_x_21__boxed_69_ = lean_unbox(v_x_67_);
v_y_22__boxed_70_ = lean_unbox(v_y_68_);
v_res_71_ = lp_Hex_Hex_Groebner_instBEqTermOrder_beq(v_x_21__boxed_69_, v_y_22__boxed_70_);
v_r_72_ = lean_box(v_res_71_);
return v_r_72_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6(void){
_start:
{
lean_object* v___x_84_; lean_object* v___x_85_; 
v___x_84_ = lean_unsigned_to_nat(2u);
v___x_85_ = lean_nat_to_int(v___x_84_);
return v___x_85_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7(void){
_start:
{
lean_object* v___x_86_; lean_object* v___x_87_; 
v___x_86_ = lean_unsigned_to_nat(1u);
v___x_87_ = lean_nat_to_int(v___x_86_);
return v___x_87_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr(uint8_t v_x_88_, lean_object* v_prec_89_){
_start:
{
lean_object* v___y_91_; lean_object* v___y_98_; lean_object* v___y_105_; 
switch(v_x_88_)
{
case 0:
{
lean_object* v___x_111_; uint8_t v___x_112_; 
v___x_111_ = lean_unsigned_to_nat(1024u);
v___x_112_ = lean_nat_dec_le(v___x_111_, v_prec_89_);
if (v___x_112_ == 0)
{
lean_object* v___x_113_; 
v___x_113_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_91_ = v___x_113_;
goto v___jp_90_;
}
else
{
lean_object* v___x_114_; 
v___x_114_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_91_ = v___x_114_;
goto v___jp_90_;
}
}
case 1:
{
lean_object* v___x_115_; uint8_t v___x_116_; 
v___x_115_ = lean_unsigned_to_nat(1024u);
v___x_116_ = lean_nat_dec_le(v___x_115_, v_prec_89_);
if (v___x_116_ == 0)
{
lean_object* v___x_117_; 
v___x_117_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_98_ = v___x_117_;
goto v___jp_97_;
}
else
{
lean_object* v___x_118_; 
v___x_118_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_98_ = v___x_118_;
goto v___jp_97_;
}
}
default: 
{
lean_object* v___x_119_; uint8_t v___x_120_; 
v___x_119_ = lean_unsigned_to_nat(1024u);
v___x_120_ = lean_nat_dec_le(v___x_119_, v_prec_89_);
if (v___x_120_ == 0)
{
lean_object* v___x_121_; 
v___x_121_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_105_ = v___x_121_;
goto v___jp_104_;
}
else
{
lean_object* v___x_122_; 
v___x_122_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_105_ = v___x_122_;
goto v___jp_104_;
}
}
}
v___jp_90_:
{
lean_object* v___x_92_; lean_object* v___x_93_; uint8_t v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; 
v___x_92_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__1));
lean_inc(v___y_91_);
v___x_93_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_93_, 0, v___y_91_);
lean_ctor_set(v___x_93_, 1, v___x_92_);
v___x_94_ = 0;
v___x_95_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_95_, 0, v___x_93_);
lean_ctor_set_uint8(v___x_95_, sizeof(void*)*1, v___x_94_);
v___x_96_ = l_Repr_addAppParen(v___x_95_, v_prec_89_);
return v___x_96_;
}
v___jp_97_:
{
lean_object* v___x_99_; lean_object* v___x_100_; uint8_t v___x_101_; lean_object* v___x_102_; lean_object* v___x_103_; 
v___x_99_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__3));
lean_inc(v___y_98_);
v___x_100_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_100_, 0, v___y_98_);
lean_ctor_set(v___x_100_, 1, v___x_99_);
v___x_101_ = 0;
v___x_102_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_102_, 0, v___x_100_);
lean_ctor_set_uint8(v___x_102_, sizeof(void*)*1, v___x_101_);
v___x_103_ = l_Repr_addAppParen(v___x_102_, v_prec_89_);
return v___x_103_;
}
v___jp_104_:
{
lean_object* v___x_106_; lean_object* v___x_107_; uint8_t v___x_108_; lean_object* v___x_109_; lean_object* v___x_110_; 
v___x_106_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__5));
lean_inc(v___y_105_);
v___x_107_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_107_, 0, v___y_105_);
lean_ctor_set(v___x_107_, 1, v___x_106_);
v___x_108_ = 0;
v___x_109_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_109_, 0, v___x_107_);
lean_ctor_set_uint8(v___x_109_, sizeof(void*)*1, v___x_108_);
v___x_110_ = l_Repr_addAppParen(v___x_109_, v_prec_89_);
return v___x_110_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprTermOrder_repr___boxed(lean_object* v_x_123_, lean_object* v_prec_124_){
_start:
{
uint8_t v_x_171__boxed_125_; lean_object* v_res_126_; 
v_x_171__boxed_125_ = lean_unbox(v_x_123_);
v_res_126_ = lp_Hex_Hex_Groebner_instReprTermOrder_repr(v_x_171__boxed_125_, v_prec_124_);
lean_dec(v_prec_124_);
return v_res_126_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_TermOrder_ofNat(lean_object* v_n_129_){
_start:
{
lean_object* v___x_130_; uint8_t v___x_131_; 
v___x_130_ = lean_unsigned_to_nat(0u);
v___x_131_ = lean_nat_dec_le(v_n_129_, v___x_130_);
if (v___x_131_ == 0)
{
lean_object* v___x_132_; uint8_t v___x_133_; 
v___x_132_ = lean_unsigned_to_nat(1u);
v___x_133_ = lean_nat_dec_le(v_n_129_, v___x_132_);
if (v___x_133_ == 0)
{
uint8_t v___x_134_; 
v___x_134_ = 2;
return v___x_134_;
}
else
{
uint8_t v___x_135_; 
v___x_135_ = 1;
return v___x_135_;
}
}
else
{
uint8_t v___x_136_; 
v___x_136_ = 0;
return v___x_136_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_ofNat___boxed(lean_object* v_n_137_){
_start:
{
uint8_t v_res_138_; lean_object* v_r_139_; 
v_res_138_ = lp_Hex_Hex_Groebner_TermOrder_ofNat(v_n_137_);
lean_dec(v_n_137_);
v_r_139_ = lean_box(v_res_138_);
return v_r_139_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instDecidableEqTermOrder(uint8_t v_x_140_, uint8_t v_y_141_){
_start:
{
lean_object* v___x_142_; lean_object* v___x_143_; uint8_t v___x_144_; 
v___x_142_ = lp_Hex_Hex_Groebner_TermOrder_ctorIdx(v_x_140_);
v___x_143_ = lp_Hex_Hex_Groebner_TermOrder_ctorIdx(v_y_141_);
v___x_144_ = lean_nat_dec_eq(v___x_142_, v___x_143_);
lean_dec(v___x_143_);
lean_dec(v___x_142_);
return v___x_144_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instDecidableEqTermOrder___boxed(lean_object* v_x_145_, lean_object* v_y_146_){
_start:
{
uint8_t v_x_20__boxed_147_; uint8_t v_y_21__boxed_148_; uint8_t v_res_149_; lean_object* v_r_150_; 
v_x_20__boxed_147_ = lean_unbox(v_x_145_);
v_y_21__boxed_148_ = lean_unbox(v_y_146_);
v_res_149_ = lp_Hex_Hex_Groebner_instDecidableEqTermOrder(v_x_20__boxed_147_, v_y_21__boxed_148_);
v_r_150_ = lean_box(v_res_149_);
return v_r_150_;
}
}
static uint8_t _init_lp_Hex_Hex_Groebner_instInhabitedTermOrder_default(void){
_start:
{
uint8_t v___x_151_; 
v___x_151_ = 0;
return v___x_151_;
}
}
static uint8_t _init_lp_Hex_Hex_Groebner_instInhabitedTermOrder(void){
_start:
{
uint8_t v___x_152_; 
v___x_152_ = 0;
return v___x_152_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_TermOrder_cmp(uint8_t v_order_153_, lean_object* v_n_154_, lean_object* v_a_155_, lean_object* v_a_156_){
_start:
{
switch(v_order_153_)
{
case 0:
{
uint8_t v___x_157_; 
lean_dec(v_n_154_);
v___x_157_ = lp_Hex_Hex_Mono_lex___redArg(v_a_155_, v_a_156_);
return v___x_157_;
}
case 1:
{
uint8_t v___x_158_; 
v___x_158_ = lp_Hex_Hex_Mono_grlex(v_n_154_, v_a_155_, v_a_156_);
return v___x_158_;
}
default: 
{
uint8_t v___x_159_; 
v___x_159_ = lp_Hex_Hex_Mono_grevlex(v_n_154_, v_a_155_, v_a_156_);
return v___x_159_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_TermOrder_cmp___boxed(lean_object* v_order_160_, lean_object* v_n_161_, lean_object* v_a_162_, lean_object* v_a_163_){
_start:
{
uint8_t v_order_boxed_164_; uint8_t v_res_165_; lean_object* v_r_166_; 
v_order_boxed_164_ = lean_unbox(v_order_160_);
v_res_165_ = lp_Hex_Hex_Groebner_TermOrder_cmp(v_order_boxed_164_, v_n_161_, v_a_162_, v_a_163_);
v_r_166_ = lean_box(v_res_165_);
return v_r_166_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorIdx(uint8_t v_x_167_){
_start:
{
switch(v_x_167_)
{
case 0:
{
lean_object* v___x_168_; 
v___x_168_ = lean_unsigned_to_nat(0u);
return v___x_168_;
}
case 1:
{
lean_object* v___x_169_; 
v___x_169_ = lean_unsigned_to_nat(1u);
return v___x_169_;
}
case 2:
{
lean_object* v___x_170_; 
v___x_170_ = lean_unsigned_to_nat(2u);
return v___x_170_;
}
case 3:
{
lean_object* v___x_171_; 
v___x_171_ = lean_unsigned_to_nat(3u);
return v___x_171_;
}
case 4:
{
lean_object* v___x_172_; 
v___x_172_ = lean_unsigned_to_nat(4u);
return v___x_172_;
}
case 5:
{
lean_object* v___x_173_; 
v___x_173_ = lean_unsigned_to_nat(5u);
return v___x_173_;
}
case 6:
{
lean_object* v___x_174_; 
v___x_174_ = lean_unsigned_to_nat(6u);
return v___x_174_;
}
case 7:
{
lean_object* v___x_175_; 
v___x_175_ = lean_unsigned_to_nat(7u);
return v___x_175_;
}
default: 
{
lean_object* v___x_176_; 
v___x_176_ = lean_unsigned_to_nat(8u);
return v___x_176_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorIdx___boxed(lean_object* v_x_177_){
_start:
{
uint8_t v_x_boxed_178_; lean_object* v_res_179_; 
v_x_boxed_178_ = lean_unbox(v_x_177_);
v_res_179_ = lp_Hex_Hex_Groebner_MonomialError_ctorIdx(v_x_boxed_178_);
return v_res_179_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorElim___redArg(lean_object* v_k_180_){
_start:
{
lean_inc(v_k_180_);
return v_k_180_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorElim___redArg___boxed(lean_object* v_k_181_){
_start:
{
lean_object* v_res_182_; 
v_res_182_ = lp_Hex_Hex_Groebner_MonomialError_ctorElim___redArg(v_k_181_);
lean_dec(v_k_181_);
return v_res_182_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorElim(lean_object* v_motive_183_, lean_object* v_ctorIdx_184_, uint8_t v_t_185_, lean_object* v_h_186_, lean_object* v_k_187_){
_start:
{
lean_inc(v_k_187_);
return v_k_187_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_ctorElim___boxed(lean_object* v_motive_188_, lean_object* v_ctorIdx_189_, lean_object* v_t_190_, lean_object* v_h_191_, lean_object* v_k_192_){
_start:
{
uint8_t v_t_boxed_193_; lean_object* v_res_194_; 
v_t_boxed_193_ = lean_unbox(v_t_190_);
v_res_194_ = lp_Hex_Hex_Groebner_MonomialError_ctorElim(v_motive_188_, v_ctorIdx_189_, v_t_boxed_193_, v_h_191_, v_k_192_);
lean_dec(v_k_192_);
lean_dec(v_ctorIdx_189_);
return v_res_194_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_arity_elim___redArg(lean_object* v_arity_195_){
_start:
{
lean_inc(v_arity_195_);
return v_arity_195_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_arity_elim___redArg___boxed(lean_object* v_arity_196_){
_start:
{
lean_object* v_res_197_; 
v_res_197_ = lp_Hex_Hex_Groebner_MonomialError_arity_elim___redArg(v_arity_196_);
lean_dec(v_arity_196_);
return v_res_197_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_arity_elim(lean_object* v_motive_198_, uint8_t v_t_199_, lean_object* v_h_200_, lean_object* v_arity_201_){
_start:
{
lean_inc(v_arity_201_);
return v_arity_201_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_arity_elim___boxed(lean_object* v_motive_202_, lean_object* v_t_203_, lean_object* v_h_204_, lean_object* v_arity_205_){
_start:
{
uint8_t v_t_boxed_206_; lean_object* v_res_207_; 
v_t_boxed_206_ = lean_unbox(v_t_203_);
v_res_207_ = lp_Hex_Hex_Groebner_MonomialError_arity_elim(v_motive_202_, v_t_boxed_206_, v_h_204_, v_arity_205_);
lean_dec(v_arity_205_);
return v_res_207_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_index_elim___redArg(lean_object* v_index_208_){
_start:
{
lean_inc(v_index_208_);
return v_index_208_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_index_elim___redArg___boxed(lean_object* v_index_209_){
_start:
{
lean_object* v_res_210_; 
v_res_210_ = lp_Hex_Hex_Groebner_MonomialError_index_elim___redArg(v_index_209_);
lean_dec(v_index_209_);
return v_res_210_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_index_elim(lean_object* v_motive_211_, uint8_t v_t_212_, lean_object* v_h_213_, lean_object* v_index_214_){
_start:
{
lean_inc(v_index_214_);
return v_index_214_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_index_elim___boxed(lean_object* v_motive_215_, lean_object* v_t_216_, lean_object* v_h_217_, lean_object* v_index_218_){
_start:
{
uint8_t v_t_boxed_219_; lean_object* v_res_220_; 
v_t_boxed_219_ = lean_unbox(v_t_216_);
v_res_220_ = lp_Hex_Hex_Groebner_MonomialError_index_elim(v_motive_215_, v_t_boxed_219_, v_h_217_, v_index_218_);
lean_dec(v_index_218_);
return v_res_220_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_exponent_elim___redArg(lean_object* v_exponent_221_){
_start:
{
lean_inc(v_exponent_221_);
return v_exponent_221_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_exponent_elim___redArg___boxed(lean_object* v_exponent_222_){
_start:
{
lean_object* v_res_223_; 
v_res_223_ = lp_Hex_Hex_Groebner_MonomialError_exponent_elim___redArg(v_exponent_222_);
lean_dec(v_exponent_222_);
return v_res_223_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_exponent_elim(lean_object* v_motive_224_, uint8_t v_t_225_, lean_object* v_h_226_, lean_object* v_exponent_227_){
_start:
{
lean_inc(v_exponent_227_);
return v_exponent_227_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_exponent_elim___boxed(lean_object* v_motive_228_, lean_object* v_t_229_, lean_object* v_h_230_, lean_object* v_exponent_231_){
_start:
{
uint8_t v_t_boxed_232_; lean_object* v_res_233_; 
v_t_boxed_232_ = lean_unbox(v_t_229_);
v_res_233_ = lp_Hex_Hex_Groebner_MonomialError_exponent_elim(v_motive_228_, v_t_boxed_232_, v_h_230_, v_exponent_231_);
lean_dec(v_exponent_231_);
return v_res_233_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_degree_elim___redArg(lean_object* v_degree_234_){
_start:
{
lean_inc(v_degree_234_);
return v_degree_234_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_degree_elim___redArg___boxed(lean_object* v_degree_235_){
_start:
{
lean_object* v_res_236_; 
v_res_236_ = lp_Hex_Hex_Groebner_MonomialError_degree_elim___redArg(v_degree_235_);
lean_dec(v_degree_235_);
return v_res_236_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_degree_elim(lean_object* v_motive_237_, uint8_t v_t_238_, lean_object* v_h_239_, lean_object* v_degree_240_){
_start:
{
lean_inc(v_degree_240_);
return v_degree_240_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_degree_elim___boxed(lean_object* v_motive_241_, lean_object* v_t_242_, lean_object* v_h_243_, lean_object* v_degree_244_){
_start:
{
uint8_t v_t_boxed_245_; lean_object* v_res_246_; 
v_t_boxed_245_ = lean_unbox(v_t_242_);
v_res_246_ = lp_Hex_Hex_Groebner_MonomialError_degree_elim(v_motive_241_, v_t_boxed_245_, v_h_243_, v_degree_244_);
lean_dec(v_degree_244_);
return v_res_246_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_address_elim___redArg(lean_object* v_address_247_){
_start:
{
lean_inc(v_address_247_);
return v_address_247_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_address_elim___redArg___boxed(lean_object* v_address_248_){
_start:
{
lean_object* v_res_249_; 
v_res_249_ = lp_Hex_Hex_Groebner_MonomialError_address_elim___redArg(v_address_248_);
lean_dec(v_address_248_);
return v_res_249_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_address_elim(lean_object* v_motive_250_, uint8_t v_t_251_, lean_object* v_h_252_, lean_object* v_address_253_){
_start:
{
lean_inc(v_address_253_);
return v_address_253_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_address_elim___boxed(lean_object* v_motive_254_, lean_object* v_t_255_, lean_object* v_h_256_, lean_object* v_address_257_){
_start:
{
uint8_t v_t_boxed_258_; lean_object* v_res_259_; 
v_t_boxed_258_ = lean_unbox(v_t_255_);
v_res_259_ = lp_Hex_Hex_Groebner_MonomialError_address_elim(v_motive_254_, v_t_boxed_258_, v_h_256_, v_address_257_);
lean_dec(v_address_257_);
return v_res_259_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_storage_elim___redArg(lean_object* v_storage_260_){
_start:
{
lean_inc(v_storage_260_);
return v_storage_260_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_storage_elim___redArg___boxed(lean_object* v_storage_261_){
_start:
{
lean_object* v_res_262_; 
v_res_262_ = lp_Hex_Hex_Groebner_MonomialError_storage_elim___redArg(v_storage_261_);
lean_dec(v_storage_261_);
return v_res_262_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_storage_elim(lean_object* v_motive_263_, uint8_t v_t_264_, lean_object* v_h_265_, lean_object* v_storage_266_){
_start:
{
lean_inc(v_storage_266_);
return v_storage_266_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_storage_elim___boxed(lean_object* v_motive_267_, lean_object* v_t_268_, lean_object* v_h_269_, lean_object* v_storage_270_){
_start:
{
uint8_t v_t_boxed_271_; lean_object* v_res_272_; 
v_t_boxed_271_ = lean_unbox(v_t_268_);
v_res_272_ = lp_Hex_Hex_Groebner_MonomialError_storage_elim(v_motive_267_, v_t_boxed_271_, v_h_269_, v_storage_270_);
lean_dec(v_storage_270_);
return v_res_272_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_monomials_elim___redArg(lean_object* v_monomials_273_){
_start:
{
lean_inc(v_monomials_273_);
return v_monomials_273_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_monomials_elim___redArg___boxed(lean_object* v_monomials_274_){
_start:
{
lean_object* v_res_275_; 
v_res_275_ = lp_Hex_Hex_Groebner_MonomialError_monomials_elim___redArg(v_monomials_274_);
lean_dec(v_monomials_274_);
return v_res_275_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_monomials_elim(lean_object* v_motive_276_, uint8_t v_t_277_, lean_object* v_h_278_, lean_object* v_monomials_279_){
_start:
{
lean_inc(v_monomials_279_);
return v_monomials_279_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_monomials_elim___boxed(lean_object* v_motive_280_, lean_object* v_t_281_, lean_object* v_h_282_, lean_object* v_monomials_283_){
_start:
{
uint8_t v_t_boxed_284_; lean_object* v_res_285_; 
v_t_boxed_284_ = lean_unbox(v_t_281_);
v_res_285_ = lp_Hex_Hex_Groebner_MonomialError_monomials_elim(v_motive_280_, v_t_boxed_284_, v_h_282_, v_monomials_283_);
lean_dec(v_monomials_283_);
return v_res_285_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim___redArg(lean_object* v_packedBytes_286_){
_start:
{
lean_inc(v_packedBytes_286_);
return v_packedBytes_286_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim___redArg___boxed(lean_object* v_packedBytes_287_){
_start:
{
lean_object* v_res_288_; 
v_res_288_ = lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim___redArg(v_packedBytes_287_);
lean_dec(v_packedBytes_287_);
return v_res_288_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim(lean_object* v_motive_289_, uint8_t v_t_290_, lean_object* v_h_291_, lean_object* v_packedBytes_292_){
_start:
{
lean_inc(v_packedBytes_292_);
return v_packedBytes_292_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim___boxed(lean_object* v_motive_293_, lean_object* v_t_294_, lean_object* v_h_295_, lean_object* v_packedBytes_296_){
_start:
{
uint8_t v_t_boxed_297_; lean_object* v_res_298_; 
v_t_boxed_297_ = lean_unbox(v_t_294_);
v_res_298_ = lp_Hex_Hex_Groebner_MonomialError_packedBytes_elim(v_motive_293_, v_t_boxed_297_, v_h_295_, v_packedBytes_296_);
lean_dec(v_packedBytes_296_);
return v_res_298_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_work_elim___redArg(lean_object* v_work_299_){
_start:
{
lean_inc(v_work_299_);
return v_work_299_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_work_elim___redArg___boxed(lean_object* v_work_300_){
_start:
{
lean_object* v_res_301_; 
v_res_301_ = lp_Hex_Hex_Groebner_MonomialError_work_elim___redArg(v_work_300_);
lean_dec(v_work_300_);
return v_res_301_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_work_elim(lean_object* v_motive_302_, uint8_t v_t_303_, lean_object* v_h_304_, lean_object* v_work_305_){
_start:
{
lean_inc(v_work_305_);
return v_work_305_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialError_work_elim___boxed(lean_object* v_motive_306_, lean_object* v_t_307_, lean_object* v_h_308_, lean_object* v_work_309_){
_start:
{
uint8_t v_t_boxed_310_; lean_object* v_res_311_; 
v_t_boxed_310_ = lean_unbox(v_t_307_);
v_res_311_ = lp_Hex_Hex_Groebner_MonomialError_work_elim(v_motive_306_, v_t_boxed_310_, v_h_308_, v_work_309_);
lean_dec(v_work_309_);
return v_res_311_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqMonomialError_beq(uint8_t v_x_312_, uint8_t v_y_313_){
_start:
{
lean_object* v___x_314_; lean_object* v___x_315_; uint8_t v___x_316_; 
v___x_314_ = lp_Hex_Hex_Groebner_MonomialError_ctorIdx(v_x_312_);
v___x_315_ = lp_Hex_Hex_Groebner_MonomialError_ctorIdx(v_y_313_);
v___x_316_ = lean_nat_dec_eq(v___x_314_, v___x_315_);
lean_dec(v___x_315_);
lean_dec(v___x_314_);
return v___x_316_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqMonomialError_beq___boxed(lean_object* v_x_317_, lean_object* v_y_318_){
_start:
{
uint8_t v_x_21__boxed_319_; uint8_t v_y_22__boxed_320_; uint8_t v_res_321_; lean_object* v_r_322_; 
v_x_21__boxed_319_ = lean_unbox(v_x_317_);
v_y_22__boxed_320_ = lean_unbox(v_y_318_);
v_res_321_ = lp_Hex_Hex_Groebner_instBEqMonomialError_beq(v_x_21__boxed_319_, v_y_22__boxed_320_);
v_r_322_ = lean_box(v_res_321_);
return v_r_322_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr(uint8_t v_x_352_, lean_object* v_prec_353_){
_start:
{
lean_object* v___y_355_; lean_object* v___y_362_; lean_object* v___y_369_; lean_object* v___y_376_; lean_object* v___y_383_; lean_object* v___y_390_; lean_object* v___y_397_; lean_object* v___y_404_; lean_object* v___y_411_; 
switch(v_x_352_)
{
case 0:
{
lean_object* v___x_417_; uint8_t v___x_418_; 
v___x_417_ = lean_unsigned_to_nat(1024u);
v___x_418_ = lean_nat_dec_le(v___x_417_, v_prec_353_);
if (v___x_418_ == 0)
{
lean_object* v___x_419_; 
v___x_419_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_355_ = v___x_419_;
goto v___jp_354_;
}
else
{
lean_object* v___x_420_; 
v___x_420_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_355_ = v___x_420_;
goto v___jp_354_;
}
}
case 1:
{
lean_object* v___x_421_; uint8_t v___x_422_; 
v___x_421_ = lean_unsigned_to_nat(1024u);
v___x_422_ = lean_nat_dec_le(v___x_421_, v_prec_353_);
if (v___x_422_ == 0)
{
lean_object* v___x_423_; 
v___x_423_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_362_ = v___x_423_;
goto v___jp_361_;
}
else
{
lean_object* v___x_424_; 
v___x_424_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_362_ = v___x_424_;
goto v___jp_361_;
}
}
case 2:
{
lean_object* v___x_425_; uint8_t v___x_426_; 
v___x_425_ = lean_unsigned_to_nat(1024u);
v___x_426_ = lean_nat_dec_le(v___x_425_, v_prec_353_);
if (v___x_426_ == 0)
{
lean_object* v___x_427_; 
v___x_427_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_369_ = v___x_427_;
goto v___jp_368_;
}
else
{
lean_object* v___x_428_; 
v___x_428_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_369_ = v___x_428_;
goto v___jp_368_;
}
}
case 3:
{
lean_object* v___x_429_; uint8_t v___x_430_; 
v___x_429_ = lean_unsigned_to_nat(1024u);
v___x_430_ = lean_nat_dec_le(v___x_429_, v_prec_353_);
if (v___x_430_ == 0)
{
lean_object* v___x_431_; 
v___x_431_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_376_ = v___x_431_;
goto v___jp_375_;
}
else
{
lean_object* v___x_432_; 
v___x_432_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_376_ = v___x_432_;
goto v___jp_375_;
}
}
case 4:
{
lean_object* v___x_433_; uint8_t v___x_434_; 
v___x_433_ = lean_unsigned_to_nat(1024u);
v___x_434_ = lean_nat_dec_le(v___x_433_, v_prec_353_);
if (v___x_434_ == 0)
{
lean_object* v___x_435_; 
v___x_435_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_383_ = v___x_435_;
goto v___jp_382_;
}
else
{
lean_object* v___x_436_; 
v___x_436_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_383_ = v___x_436_;
goto v___jp_382_;
}
}
case 5:
{
lean_object* v___x_437_; uint8_t v___x_438_; 
v___x_437_ = lean_unsigned_to_nat(1024u);
v___x_438_ = lean_nat_dec_le(v___x_437_, v_prec_353_);
if (v___x_438_ == 0)
{
lean_object* v___x_439_; 
v___x_439_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_390_ = v___x_439_;
goto v___jp_389_;
}
else
{
lean_object* v___x_440_; 
v___x_440_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_390_ = v___x_440_;
goto v___jp_389_;
}
}
case 6:
{
lean_object* v___x_441_; uint8_t v___x_442_; 
v___x_441_ = lean_unsigned_to_nat(1024u);
v___x_442_ = lean_nat_dec_le(v___x_441_, v_prec_353_);
if (v___x_442_ == 0)
{
lean_object* v___x_443_; 
v___x_443_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_397_ = v___x_443_;
goto v___jp_396_;
}
else
{
lean_object* v___x_444_; 
v___x_444_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_397_ = v___x_444_;
goto v___jp_396_;
}
}
case 7:
{
lean_object* v___x_445_; uint8_t v___x_446_; 
v___x_445_ = lean_unsigned_to_nat(1024u);
v___x_446_ = lean_nat_dec_le(v___x_445_, v_prec_353_);
if (v___x_446_ == 0)
{
lean_object* v___x_447_; 
v___x_447_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_404_ = v___x_447_;
goto v___jp_403_;
}
else
{
lean_object* v___x_448_; 
v___x_448_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_404_ = v___x_448_;
goto v___jp_403_;
}
}
default: 
{
lean_object* v___x_449_; uint8_t v___x_450_; 
v___x_449_ = lean_unsigned_to_nat(1024u);
v___x_450_ = lean_nat_dec_le(v___x_449_, v_prec_353_);
if (v___x_450_ == 0)
{
lean_object* v___x_451_; 
v___x_451_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__6);
v___y_411_ = v___x_451_;
goto v___jp_410_;
}
else
{
lean_object* v___x_452_; 
v___x_452_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7, &lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprTermOrder_repr___closed__7);
v___y_411_ = v___x_452_;
goto v___jp_410_;
}
}
}
v___jp_354_:
{
lean_object* v___x_356_; lean_object* v___x_357_; uint8_t v___x_358_; lean_object* v___x_359_; lean_object* v___x_360_; 
v___x_356_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__1));
lean_inc(v___y_355_);
v___x_357_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_357_, 0, v___y_355_);
lean_ctor_set(v___x_357_, 1, v___x_356_);
v___x_358_ = 0;
v___x_359_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_359_, 0, v___x_357_);
lean_ctor_set_uint8(v___x_359_, sizeof(void*)*1, v___x_358_);
v___x_360_ = l_Repr_addAppParen(v___x_359_, v_prec_353_);
return v___x_360_;
}
v___jp_361_:
{
lean_object* v___x_363_; lean_object* v___x_364_; uint8_t v___x_365_; lean_object* v___x_366_; lean_object* v___x_367_; 
v___x_363_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__3));
lean_inc(v___y_362_);
v___x_364_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_364_, 0, v___y_362_);
lean_ctor_set(v___x_364_, 1, v___x_363_);
v___x_365_ = 0;
v___x_366_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_366_, 0, v___x_364_);
lean_ctor_set_uint8(v___x_366_, sizeof(void*)*1, v___x_365_);
v___x_367_ = l_Repr_addAppParen(v___x_366_, v_prec_353_);
return v___x_367_;
}
v___jp_368_:
{
lean_object* v___x_370_; lean_object* v___x_371_; uint8_t v___x_372_; lean_object* v___x_373_; lean_object* v___x_374_; 
v___x_370_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__5));
lean_inc(v___y_369_);
v___x_371_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_371_, 0, v___y_369_);
lean_ctor_set(v___x_371_, 1, v___x_370_);
v___x_372_ = 0;
v___x_373_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_373_, 0, v___x_371_);
lean_ctor_set_uint8(v___x_373_, sizeof(void*)*1, v___x_372_);
v___x_374_ = l_Repr_addAppParen(v___x_373_, v_prec_353_);
return v___x_374_;
}
v___jp_375_:
{
lean_object* v___x_377_; lean_object* v___x_378_; uint8_t v___x_379_; lean_object* v___x_380_; lean_object* v___x_381_; 
v___x_377_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__7));
lean_inc(v___y_376_);
v___x_378_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_378_, 0, v___y_376_);
lean_ctor_set(v___x_378_, 1, v___x_377_);
v___x_379_ = 0;
v___x_380_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_380_, 0, v___x_378_);
lean_ctor_set_uint8(v___x_380_, sizeof(void*)*1, v___x_379_);
v___x_381_ = l_Repr_addAppParen(v___x_380_, v_prec_353_);
return v___x_381_;
}
v___jp_382_:
{
lean_object* v___x_384_; lean_object* v___x_385_; uint8_t v___x_386_; lean_object* v___x_387_; lean_object* v___x_388_; 
v___x_384_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__9));
lean_inc(v___y_383_);
v___x_385_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_385_, 0, v___y_383_);
lean_ctor_set(v___x_385_, 1, v___x_384_);
v___x_386_ = 0;
v___x_387_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_387_, 0, v___x_385_);
lean_ctor_set_uint8(v___x_387_, sizeof(void*)*1, v___x_386_);
v___x_388_ = l_Repr_addAppParen(v___x_387_, v_prec_353_);
return v___x_388_;
}
v___jp_389_:
{
lean_object* v___x_391_; lean_object* v___x_392_; uint8_t v___x_393_; lean_object* v___x_394_; lean_object* v___x_395_; 
v___x_391_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__11));
lean_inc(v___y_390_);
v___x_392_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_392_, 0, v___y_390_);
lean_ctor_set(v___x_392_, 1, v___x_391_);
v___x_393_ = 0;
v___x_394_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_394_, 0, v___x_392_);
lean_ctor_set_uint8(v___x_394_, sizeof(void*)*1, v___x_393_);
v___x_395_ = l_Repr_addAppParen(v___x_394_, v_prec_353_);
return v___x_395_;
}
v___jp_396_:
{
lean_object* v___x_398_; lean_object* v___x_399_; uint8_t v___x_400_; lean_object* v___x_401_; lean_object* v___x_402_; 
v___x_398_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__13));
lean_inc(v___y_397_);
v___x_399_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_399_, 0, v___y_397_);
lean_ctor_set(v___x_399_, 1, v___x_398_);
v___x_400_ = 0;
v___x_401_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_401_, 0, v___x_399_);
lean_ctor_set_uint8(v___x_401_, sizeof(void*)*1, v___x_400_);
v___x_402_ = l_Repr_addAppParen(v___x_401_, v_prec_353_);
return v___x_402_;
}
v___jp_403_:
{
lean_object* v___x_405_; lean_object* v___x_406_; uint8_t v___x_407_; lean_object* v___x_408_; lean_object* v___x_409_; 
v___x_405_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__15));
lean_inc(v___y_404_);
v___x_406_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_406_, 0, v___y_404_);
lean_ctor_set(v___x_406_, 1, v___x_405_);
v___x_407_ = 0;
v___x_408_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_408_, 0, v___x_406_);
lean_ctor_set_uint8(v___x_408_, sizeof(void*)*1, v___x_407_);
v___x_409_ = l_Repr_addAppParen(v___x_408_, v_prec_353_);
return v___x_409_;
}
v___jp_410_:
{
lean_object* v___x_412_; lean_object* v___x_413_; uint8_t v___x_414_; lean_object* v___x_415_; lean_object* v___x_416_; 
v___x_412_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialError_repr___closed__17));
lean_inc(v___y_411_);
v___x_413_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_413_, 0, v___y_411_);
lean_ctor_set(v___x_413_, 1, v___x_412_);
v___x_414_ = 0;
v___x_415_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_415_, 0, v___x_413_);
lean_ctor_set_uint8(v___x_415_, sizeof(void*)*1, v___x_414_);
v___x_416_ = l_Repr_addAppParen(v___x_415_, v_prec_353_);
return v___x_416_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialError_repr___boxed(lean_object* v_x_453_, lean_object* v_prec_454_){
_start:
{
uint8_t v_x_491__boxed_455_; lean_object* v_res_456_; 
v_x_491__boxed_455_ = lean_unbox(v_x_453_);
v_res_456_ = lp_Hex_Hex_Groebner_instReprMonomialError_repr(v_x_491__boxed_455_, v_prec_454_);
lean_dec(v_prec_454_);
return v_res_456_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqMonomialFailure_beq(lean_object* v_x_459_, lean_object* v_x_460_){
_start:
{
uint8_t v_error_461_; lean_object* v_work_462_; uint8_t v_error_463_; lean_object* v_work_464_; uint8_t v___x_465_; 
v_error_461_ = lean_ctor_get_uint8(v_x_459_, sizeof(void*)*1);
v_work_462_ = lean_ctor_get(v_x_459_, 0);
v_error_463_ = lean_ctor_get_uint8(v_x_460_, sizeof(void*)*1);
v_work_464_ = lean_ctor_get(v_x_460_, 0);
v___x_465_ = lp_Hex_Hex_Groebner_instBEqMonomialError_beq(v_error_461_, v_error_463_);
if (v___x_465_ == 0)
{
return v___x_465_;
}
else
{
uint8_t v___x_466_; 
v___x_466_ = lean_nat_dec_eq(v_work_462_, v_work_464_);
return v___x_466_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqMonomialFailure_beq___boxed(lean_object* v_x_467_, lean_object* v_x_468_){
_start:
{
uint8_t v_res_469_; lean_object* v_r_470_; 
v_res_469_ = lp_Hex_Hex_Groebner_instBEqMonomialFailure_beq(v_x_467_, v_x_468_);
lean_dec_ref(v_x_468_);
lean_dec_ref(v_x_467_);
v_r_470_ = lean_box(v_res_469_);
return v_r_470_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_Groebner_instReprMonomialFailure_repr_spec__0(lean_object* v_a_473_){
_start:
{
lean_object* v___x_474_; 
v___x_474_ = lean_nat_to_int(v_a_473_);
return v___x_474_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__7(void){
_start:
{
lean_object* v___x_488_; lean_object* v___x_489_; 
v___x_488_ = lean_unsigned_to_nat(9u);
v___x_489_ = lean_nat_to_int(v___x_488_);
return v___x_489_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__12(void){
_start:
{
lean_object* v___x_496_; lean_object* v___x_497_; 
v___x_496_ = lean_unsigned_to_nat(8u);
v___x_497_ = lean_nat_to_int(v___x_496_);
return v___x_497_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__14(void){
_start:
{
lean_object* v___x_499_; lean_object* v___x_500_; 
v___x_499_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__0));
v___x_500_ = lean_string_length(v___x_499_);
return v___x_500_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__15(void){
_start:
{
lean_object* v___x_501_; lean_object* v___x_502_; 
v___x_501_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__14, &lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__14);
v___x_502_ = lean_nat_to_int(v___x_501_);
return v___x_502_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg(lean_object* v_x_507_){
_start:
{
uint8_t v_error_508_; lean_object* v_work_509_; lean_object* v___x_511_; uint8_t v_isShared_512_; uint8_t v_isSharedCheck_544_; 
v_error_508_ = lean_ctor_get_uint8(v_x_507_, sizeof(void*)*1);
v_work_509_ = lean_ctor_get(v_x_507_, 0);
v_isSharedCheck_544_ = !lean_is_exclusive(v_x_507_);
if (v_isSharedCheck_544_ == 0)
{
v___x_511_ = v_x_507_;
v_isShared_512_ = v_isSharedCheck_544_;
goto v_resetjp_510_;
}
else
{
lean_inc(v_work_509_);
lean_dec(v_x_507_);
v___x_511_ = lean_box(0);
v_isShared_512_ = v_isSharedCheck_544_;
goto v_resetjp_510_;
}
v_resetjp_510_:
{
lean_object* v___x_513_; lean_object* v___x_514_; lean_object* v___x_515_; lean_object* v___x_516_; lean_object* v___x_517_; lean_object* v___x_518_; uint8_t v___x_519_; lean_object* v___x_521_; 
v___x_513_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__5));
v___x_514_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__6));
v___x_515_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__7, &lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__7);
v___x_516_ = lean_unsigned_to_nat(0u);
v___x_517_ = lp_Hex_Hex_Groebner_instReprMonomialError_repr(v_error_508_, v___x_516_);
v___x_518_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_518_, 0, v___x_515_);
lean_ctor_set(v___x_518_, 1, v___x_517_);
v___x_519_ = 0;
if (v_isShared_512_ == 0)
{
lean_ctor_set_tag(v___x_511_, 6);
lean_ctor_set(v___x_511_, 0, v___x_518_);
v___x_521_ = v___x_511_;
goto v_reusejp_520_;
}
else
{
lean_object* v_reuseFailAlloc_543_; 
v_reuseFailAlloc_543_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v_reuseFailAlloc_543_, 0, v___x_518_);
v___x_521_ = v_reuseFailAlloc_543_;
goto v_reusejp_520_;
}
v_reusejp_520_:
{
lean_object* v___x_522_; lean_object* v___x_523_; lean_object* v___x_524_; lean_object* v___x_525_; lean_object* v___x_526_; lean_object* v___x_527_; lean_object* v___x_528_; lean_object* v___x_529_; lean_object* v___x_530_; lean_object* v___x_531_; lean_object* v___x_532_; lean_object* v___x_533_; lean_object* v___x_534_; lean_object* v___x_535_; lean_object* v___x_536_; lean_object* v___x_537_; lean_object* v___x_538_; lean_object* v___x_539_; lean_object* v___x_540_; lean_object* v___x_541_; lean_object* v___x_542_; 
lean_ctor_set_uint8(v___x_521_, sizeof(void*)*1, v___x_519_);
v___x_522_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_522_, 0, v___x_514_);
lean_ctor_set(v___x_522_, 1, v___x_521_);
v___x_523_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__9));
v___x_524_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_524_, 0, v___x_522_);
lean_ctor_set(v___x_524_, 1, v___x_523_);
v___x_525_ = lean_box(1);
v___x_526_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_526_, 0, v___x_524_);
lean_ctor_set(v___x_526_, 1, v___x_525_);
v___x_527_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__11));
v___x_528_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_528_, 0, v___x_526_);
lean_ctor_set(v___x_528_, 1, v___x_527_);
v___x_529_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_529_, 0, v___x_528_);
lean_ctor_set(v___x_529_, 1, v___x_513_);
v___x_530_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__12, &lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__12_once, _init_lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__12);
v___x_531_ = l_Nat_reprFast(v_work_509_);
v___x_532_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_532_, 0, v___x_531_);
v___x_533_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_533_, 0, v___x_530_);
lean_ctor_set(v___x_533_, 1, v___x_532_);
v___x_534_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_534_, 0, v___x_533_);
lean_ctor_set_uint8(v___x_534_, sizeof(void*)*1, v___x_519_);
v___x_535_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_535_, 0, v___x_529_);
lean_ctor_set(v___x_535_, 1, v___x_534_);
v___x_536_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__15, &lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__15);
v___x_537_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__16));
v___x_538_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_538_, 0, v___x_537_);
lean_ctor_set(v___x_538_, 1, v___x_535_);
v___x_539_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg___closed__17));
v___x_540_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_540_, 0, v___x_538_);
lean_ctor_set(v___x_540_, 1, v___x_539_);
v___x_541_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_541_, 0, v___x_536_);
lean_ctor_set(v___x_541_, 1, v___x_540_);
v___x_542_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_542_, 0, v___x_541_);
lean_ctor_set_uint8(v___x_542_, sizeof(void*)*1, v___x_519_);
return v___x_542_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr(lean_object* v_x_545_, lean_object* v_prec_546_){
_start:
{
lean_object* v___x_547_; 
v___x_547_ = lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___redArg(v_x_545_);
return v___x_547_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMonomialFailure_repr___boxed(lean_object* v_x_548_, lean_object* v_prec_549_){
_start:
{
lean_object* v_res_550_; 
v_res_550_ = lp_Hex_Hex_Groebner_instReprMonomialFailure_repr(v_x_548_, v_prec_549_);
lean_dec(v_prec_549_);
return v_res_550_;
}
}
LEAN_EXPORT uint64_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(lean_object* v_bytes_553_, lean_object* v_index_554_){
_start:
{
lean_object* v___x_555_; lean_object* v___x_556_; uint64_t v___x_557_; 
v___x_555_ = lean_unsigned_to_nat(8u);
v___x_556_ = lean_nat_mul(v_index_554_, v___x_555_);
v___x_557_ = lp_Hex_Hex_Groebner_Packed_read64Fast(v_bytes_553_, v___x_556_);
lean_dec(v___x_556_);
return v___x_557_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord___boxed(lean_object* v_bytes_558_, lean_object* v_index_559_){
_start:
{
uint64_t v_res_560_; lean_object* v_r_561_; 
v_res_560_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_bytes_558_, v_index_559_);
lean_dec(v_index_559_);
lean_dec_ref(v_bytes_558_);
v_r_561_ = lean_box_uint64(v_res_560_);
return v_r_561_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_reserve(lean_object* v_arity_562_){
_start:
{
lean_object* v___x_563_; uint8_t v___x_564_; 
v___x_563_ = lean_unsigned_to_nat(0u);
v___x_564_ = lean_nat_dec_lt(v___x_563_, v_arity_562_);
if (v___x_564_ == 0)
{
return v___x_563_;
}
else
{
lean_object* v___x_565_; uint8_t v___x_566_; 
v___x_565_ = lean_unsigned_to_nat(4096u);
v___x_566_ = lean_nat_dec_le(v_arity_562_, v___x_565_);
if (v___x_566_ == 0)
{
return v___x_563_;
}
else
{
lean_object* v___x_567_; lean_object* v___x_568_; lean_object* v___x_569_; lean_object* v___x_570_; 
v___x_567_ = lean_unsigned_to_nat(4u);
v___x_568_ = lean_nat_mul(v_arity_562_, v___x_567_);
v___x_569_ = lean_unsigned_to_nat(28u);
v___x_570_ = lean_nat_add(v___x_568_, v___x_569_);
lean_dec(v___x_568_);
return v___x_570_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_reserve___boxed(lean_object* v_arity_571_){
_start:
{
lean_object* v_res_572_; 
v_res_572_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_reserve(v_arity_571_);
lean_dec(v_arity_571_);
return v_res_572_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_workspaceBytes(lean_object* v_table_573_){
_start:
{
lean_object* v_arity_574_; lean_object* v_count_575_; lean_object* v_workspace_576_; lean_object* v___x_577_; lean_object* v___y_579_; lean_object* v___x_581_; uint8_t v___x_582_; 
v_arity_574_ = lean_ctor_get(v_table_573_, 0);
v_count_575_ = lean_ctor_get(v_table_573_, 3);
v_workspace_576_ = lean_ctor_get(v_table_573_, 4);
v___x_577_ = lean_byte_array_size(v_workspace_576_);
v___x_581_ = lean_unsigned_to_nat(0u);
v___x_582_ = lean_nat_dec_eq(v_count_575_, v___x_581_);
if (v___x_582_ == 0)
{
uint8_t v___x_583_; 
v___x_583_ = lean_nat_dec_lt(v___x_581_, v_arity_574_);
if (v___x_583_ == 0)
{
v___y_579_ = v___x_581_;
goto v___jp_578_;
}
else
{
lean_object* v___x_584_; uint8_t v___x_585_; 
v___x_584_ = lean_unsigned_to_nat(4096u);
v___x_585_ = lean_nat_dec_le(v_arity_574_, v___x_584_);
if (v___x_585_ == 0)
{
v___y_579_ = v___x_581_;
goto v___jp_578_;
}
else
{
lean_object* v___x_586_; lean_object* v___x_587_; lean_object* v___x_588_; lean_object* v___x_589_; 
v___x_586_ = lean_unsigned_to_nat(4u);
v___x_587_ = lean_nat_mul(v_arity_574_, v___x_586_);
v___x_588_ = lean_unsigned_to_nat(28u);
v___x_589_ = lean_nat_add(v___x_587_, v___x_588_);
lean_dec(v___x_587_);
v___y_579_ = v___x_589_;
goto v___jp_578_;
}
}
}
else
{
v___y_579_ = v___x_581_;
goto v___jp_578_;
}
v___jp_578_:
{
uint8_t v___x_580_; 
v___x_580_ = lean_nat_dec_le(v___x_577_, v___y_579_);
if (v___x_580_ == 0)
{
lean_dec(v___y_579_);
return v___x_577_;
}
else
{
return v___y_579_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_workspaceBytes___boxed(lean_object* v_table_590_){
_start:
{
lean_object* v_res_591_; 
v_res_591_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_workspaceBytes(v_table_590_);
lean_dec_ref(v_table_590_);
return v_res_591_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_bytes(lean_object* v_table_592_){
_start:
{
lean_object* v_arity_593_; lean_object* v_exponents_594_; lean_object* v_metadata_595_; lean_object* v_count_596_; lean_object* v_workspace_597_; lean_object* v_products_598_; lean_object* v___x_599_; lean_object* v___x_600_; lean_object* v___x_601_; lean_object* v___y_603_; lean_object* v___x_609_; lean_object* v___y_611_; lean_object* v___x_613_; uint8_t v___x_614_; 
v_arity_593_ = lean_ctor_get(v_table_592_, 0);
v_exponents_594_ = lean_ctor_get(v_table_592_, 1);
v_metadata_595_ = lean_ctor_get(v_table_592_, 2);
v_count_596_ = lean_ctor_get(v_table_592_, 3);
v_workspace_597_ = lean_ctor_get(v_table_592_, 4);
v_products_598_ = lean_ctor_get(v_table_592_, 6);
v___x_599_ = lean_byte_array_size(v_exponents_594_);
v___x_600_ = lean_byte_array_size(v_metadata_595_);
v___x_601_ = lean_nat_add(v___x_599_, v___x_600_);
v___x_609_ = lean_byte_array_size(v_workspace_597_);
v___x_613_ = lean_unsigned_to_nat(0u);
v___x_614_ = lean_nat_dec_eq(v_count_596_, v___x_613_);
if (v___x_614_ == 0)
{
uint8_t v___x_615_; 
v___x_615_ = lean_nat_dec_lt(v___x_613_, v_arity_593_);
if (v___x_615_ == 0)
{
v___y_611_ = v___x_613_;
goto v___jp_610_;
}
else
{
lean_object* v___x_616_; uint8_t v___x_617_; 
v___x_616_ = lean_unsigned_to_nat(4096u);
v___x_617_ = lean_nat_dec_le(v_arity_593_, v___x_616_);
if (v___x_617_ == 0)
{
v___y_611_ = v___x_613_;
goto v___jp_610_;
}
else
{
lean_object* v___x_618_; lean_object* v___x_619_; lean_object* v___x_620_; lean_object* v___x_621_; 
v___x_618_ = lean_unsigned_to_nat(4u);
v___x_619_ = lean_nat_mul(v_arity_593_, v___x_618_);
v___x_620_ = lean_unsigned_to_nat(28u);
v___x_621_ = lean_nat_add(v___x_619_, v___x_620_);
lean_dec(v___x_619_);
v___y_611_ = v___x_621_;
goto v___jp_610_;
}
}
}
else
{
v___y_611_ = v___x_613_;
goto v___jp_610_;
}
v___jp_602_:
{
lean_object* v_size_604_; lean_object* v___x_605_; lean_object* v___x_606_; lean_object* v___x_607_; lean_object* v___x_608_; 
v_size_604_ = lean_ctor_get(v_products_598_, 0);
v___x_605_ = lean_nat_add(v___x_601_, v___y_603_);
lean_dec(v___y_603_);
lean_dec(v___x_601_);
v___x_606_ = lean_unsigned_to_nat(12u);
v___x_607_ = lean_nat_mul(v___x_606_, v_size_604_);
v___x_608_ = lean_nat_add(v___x_605_, v___x_607_);
lean_dec(v___x_607_);
lean_dec(v___x_605_);
return v___x_608_;
}
v___jp_610_:
{
uint8_t v___x_612_; 
v___x_612_ = lean_nat_dec_le(v___x_609_, v___y_611_);
if (v___x_612_ == 0)
{
lean_dec(v___y_611_);
v___y_603_ = v___x_609_;
goto v___jp_602_;
}
else
{
v___y_603_ = v___y_611_;
goto v___jp_602_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_bytes___boxed(lean_object* v_table_622_){
_start:
{
lean_object* v_res_623_; 
v_res_623_ = lp_Hex_Hex_Groebner_MonomialTable_bytes(v_table_622_);
lean_dec_ref(v_table_622_);
return v_res_623_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_shape(lean_object* v_table_624_){
_start:
{
lean_object* v_arity_625_; uint8_t v_width_626_; lean_object* v_exponents_627_; lean_object* v_metadata_628_; lean_object* v_count_629_; lean_object* v___x_630_; lean_object* v___x_631_; lean_object* v___y_633_; 
v_arity_625_ = lean_ctor_get(v_table_624_, 0);
v_width_626_ = lean_ctor_get_uint8(v_table_624_, sizeof(void*)*9);
v_exponents_627_ = lean_ctor_get(v_table_624_, 1);
v_metadata_628_ = lean_ctor_get(v_table_624_, 2);
v_count_629_ = lean_ctor_get(v_table_624_, 3);
v___x_630_ = lean_byte_array_size(v_exponents_627_);
v___x_631_ = lean_nat_mul(v_count_629_, v_arity_625_);
switch(v_width_626_)
{
case 0:
{
lean_object* v___x_640_; 
v___x_640_ = lean_unsigned_to_nat(1u);
v___y_633_ = v___x_640_;
goto v___jp_632_;
}
case 1:
{
lean_object* v___x_641_; 
v___x_641_ = lean_unsigned_to_nat(2u);
v___y_633_ = v___x_641_;
goto v___jp_632_;
}
default: 
{
lean_object* v___x_642_; 
v___x_642_ = lean_unsigned_to_nat(4u);
v___y_633_ = v___x_642_;
goto v___jp_632_;
}
}
v___jp_632_:
{
lean_object* v___x_634_; uint8_t v___x_635_; 
v___x_634_ = lean_nat_mul(v___x_631_, v___y_633_);
lean_dec(v___x_631_);
v___x_635_ = lean_nat_dec_eq(v___x_630_, v___x_634_);
lean_dec(v___x_634_);
if (v___x_635_ == 0)
{
return v___x_635_;
}
else
{
lean_object* v___x_636_; lean_object* v___x_637_; lean_object* v___x_638_; uint8_t v___x_639_; 
v___x_636_ = lean_byte_array_size(v_metadata_628_);
v___x_637_ = lean_unsigned_to_nat(24u);
v___x_638_ = lean_nat_mul(v_count_629_, v___x_637_);
v___x_639_ = lean_nat_dec_eq(v___x_636_, v___x_638_);
lean_dec(v___x_638_);
return v___x_639_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_shape___boxed(lean_object* v_table_643_){
_start:
{
uint8_t v_res_644_; lean_object* v_r_645_; 
v_res_644_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_shape(v_table_643_);
lean_dec_ref(v_table_643_);
v_r_645_ = lean_box(v_res_644_);
return v_r_645_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(lean_object* v_bytes_646_, uint64_t v_value_647_){
_start:
{
uint64_t v___x_648_; uint64_t v___x_649_; uint8_t v___x_650_; lean_object* v_data_651_; uint64_t v___x_652_; uint64_t v___x_653_; uint8_t v___x_654_; lean_object* v___x_655_; uint64_t v___x_656_; uint64_t v___x_657_; uint8_t v___x_658_; lean_object* v___x_659_; uint64_t v___x_660_; uint64_t v___x_661_; uint8_t v___x_662_; lean_object* v___x_663_; uint64_t v___x_664_; uint64_t v___x_665_; uint8_t v___x_666_; lean_object* v_data_667_; uint64_t v___x_668_; uint8_t v___x_669_; lean_object* v___x_670_; uint64_t v___x_671_; uint8_t v___x_672_; lean_object* v___x_673_; uint64_t v___x_674_; uint8_t v___x_675_; lean_object* v___x_676_; 
v___x_648_ = 4294967295ULL;
v___x_649_ = lean_uint64_land(v_value_647_, v___x_648_);
v___x_650_ = lean_uint64_to_uint8(v___x_649_);
v_data_651_ = lean_byte_array_push(v_bytes_646_, v___x_650_);
v___x_652_ = 8ULL;
v___x_653_ = lean_uint64_shift_right(v___x_649_, v___x_652_);
v___x_654_ = lean_uint64_to_uint8(v___x_653_);
v___x_655_ = lean_byte_array_push(v_data_651_, v___x_654_);
v___x_656_ = 16ULL;
v___x_657_ = lean_uint64_shift_right(v___x_649_, v___x_656_);
v___x_658_ = lean_uint64_to_uint8(v___x_657_);
v___x_659_ = lean_byte_array_push(v___x_655_, v___x_658_);
v___x_660_ = 24ULL;
v___x_661_ = lean_uint64_shift_right(v___x_649_, v___x_660_);
v___x_662_ = lean_uint64_to_uint8(v___x_661_);
v___x_663_ = lean_byte_array_push(v___x_659_, v___x_662_);
v___x_664_ = 32ULL;
v___x_665_ = lean_uint64_shift_right(v_value_647_, v___x_664_);
v___x_666_ = lean_uint64_to_uint8(v___x_665_);
v_data_667_ = lean_byte_array_push(v___x_663_, v___x_666_);
v___x_668_ = lean_uint64_shift_right(v___x_665_, v___x_652_);
v___x_669_ = lean_uint64_to_uint8(v___x_668_);
v___x_670_ = lean_byte_array_push(v_data_667_, v___x_669_);
v___x_671_ = lean_uint64_shift_right(v___x_665_, v___x_656_);
v___x_672_ = lean_uint64_to_uint8(v___x_671_);
v___x_673_ = lean_byte_array_push(v___x_670_, v___x_672_);
v___x_674_ = lean_uint64_shift_right(v___x_665_, v___x_660_);
v___x_675_ = lean_uint64_to_uint8(v___x_674_);
v___x_676_ = lean_byte_array_push(v___x_673_, v___x_675_);
return v___x_676_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64___boxed(lean_object* v_bytes_677_, lean_object* v_value_678_){
_start:
{
uint64_t v_value_boxed_679_; lean_object* v_res_680_; 
v_value_boxed_679_ = lean_unbox_uint64(v_value_678_);
lean_dec_ref(v_value_678_);
v_res_680_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v_bytes_677_, v_value_boxed_679_);
return v_res_680_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(lean_object* v_xs_681_, lean_object* v_i_682_){
_start:
{
lean_object* v___x_683_; uint8_t v___x_684_; 
v___x_683_ = lean_byte_array_size(v_xs_681_);
v___x_684_ = lean_nat_dec_lt(v_i_682_, v___x_683_);
return v___x_684_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0___boxed(lean_object* v_xs_685_, lean_object* v_i_686_){
_start:
{
uint8_t v_res_687_; lean_object* v_r_688_; 
v_res_687_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_xs_685_, v_i_686_);
lean_dec(v_i_686_);
lean_dec_ref(v_xs_685_);
v_r_688_ = lean_box(v_res_687_);
return v_r_688_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_MonomialTable_exponent(lean_object* v_table_689_, lean_object* v_id_690_, lean_object* v_coordinate_691_){
_start:
{
uint64_t v___y_693_; uint8_t v___y_694_; uint64_t v___y_700_; uint8_t v___y_701_; lean_object* v_arity_706_; uint8_t v_width_707_; lean_object* v_exponents_708_; lean_object* v___x_709_; lean_object* v___x_710_; uint8_t v___x_711_; lean_object* v___y_713_; uint64_t v___y_714_; uint8_t v___y_715_; lean_object* v___y_728_; uint64_t v___y_729_; uint8_t v___y_730_; lean_object* v___y_743_; uint8_t v___y_744_; lean_object* v___y_761_; uint8_t v___y_762_; lean_object* v___y_800_; 
v_arity_706_ = lean_ctor_get(v_table_689_, 0);
v_width_707_ = lean_ctor_get_uint8(v_table_689_, sizeof(void*)*9);
v_exponents_708_ = lean_ctor_get(v_table_689_, 1);
v___x_709_ = lean_nat_mul(v_id_690_, v_arity_706_);
v___x_710_ = lean_nat_add(v___x_709_, v_coordinate_691_);
lean_dec(v___x_709_);
v___x_711_ = 0;
switch(v_width_707_)
{
case 0:
{
lean_object* v___x_808_; 
v___x_808_ = lean_unsigned_to_nat(1u);
v___y_800_ = v___x_808_;
goto v___jp_799_;
}
case 1:
{
lean_object* v___x_809_; 
v___x_809_ = lean_unsigned_to_nat(2u);
v___y_800_ = v___x_809_;
goto v___jp_799_;
}
default: 
{
lean_object* v___x_810_; 
v___x_810_ = lean_unsigned_to_nat(4u);
v___y_800_ = v___x_810_;
goto v___jp_799_;
}
}
v___jp_692_:
{
uint64_t v___x_695_; uint64_t v___x_696_; uint64_t v___x_697_; uint64_t v___x_698_; 
v___x_695_ = lean_uint8_to_uint64(v___y_694_);
v___x_696_ = 24ULL;
v___x_697_ = lean_uint64_shift_left(v___x_695_, v___x_696_);
v___x_698_ = lean_uint64_lor(v___y_693_, v___x_697_);
return v___x_698_;
}
v___jp_699_:
{
uint64_t v___x_702_; uint64_t v___x_703_; uint64_t v___x_704_; uint64_t v___x_705_; 
v___x_702_ = lean_uint8_to_uint64(v___y_701_);
v___x_703_ = 8ULL;
v___x_704_ = lean_uint64_shift_left(v___x_702_, v___x_703_);
v___x_705_ = lean_uint64_lor(v___y_700_, v___x_704_);
return v___x_705_;
}
v___jp_712_:
{
uint64_t v___x_716_; uint64_t v___x_717_; uint64_t v___x_718_; uint64_t v___x_719_; lean_object* v___x_720_; lean_object* v___x_721_; uint8_t v___x_722_; 
v___x_716_ = lean_uint8_to_uint64(v___y_715_);
v___x_717_ = 16ULL;
v___x_718_ = lean_uint64_shift_left(v___x_716_, v___x_717_);
v___x_719_ = lean_uint64_lor(v___y_714_, v___x_718_);
v___x_720_ = lean_unsigned_to_nat(3u);
v___x_721_ = lean_nat_add(v___y_713_, v___x_720_);
lean_dec(v___y_713_);
v___x_722_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_708_, v___x_721_);
if (v___x_722_ == 0)
{
lean_object* v___x_723_; lean_object* v___x_724_; uint8_t v___x_725_; 
lean_dec(v___x_721_);
v___x_723_ = lean_box(v___x_711_);
v___x_724_ = l_outOfBounds___redArg(v___x_723_);
lean_dec(v___x_723_);
v___x_725_ = lean_unbox(v___x_724_);
lean_dec(v___x_724_);
v___y_693_ = v___x_719_;
v___y_694_ = v___x_725_;
goto v___jp_692_;
}
else
{
uint8_t v___x_726_; 
v___x_726_ = lean_byte_array_fget(v_exponents_708_, v___x_721_);
lean_dec(v___x_721_);
v___y_693_ = v___x_719_;
v___y_694_ = v___x_726_;
goto v___jp_692_;
}
}
v___jp_727_:
{
uint64_t v___x_731_; uint64_t v___x_732_; uint64_t v___x_733_; uint64_t v___x_734_; lean_object* v___x_735_; lean_object* v___x_736_; uint8_t v___x_737_; 
v___x_731_ = lean_uint8_to_uint64(v___y_730_);
v___x_732_ = 8ULL;
v___x_733_ = lean_uint64_shift_left(v___x_731_, v___x_732_);
v___x_734_ = lean_uint64_lor(v___y_729_, v___x_733_);
v___x_735_ = lean_unsigned_to_nat(2u);
v___x_736_ = lean_nat_add(v___y_728_, v___x_735_);
v___x_737_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_708_, v___x_736_);
if (v___x_737_ == 0)
{
lean_object* v___x_738_; lean_object* v___x_739_; uint8_t v___x_740_; 
lean_dec(v___x_736_);
v___x_738_ = lean_box(v___x_711_);
v___x_739_ = l_outOfBounds___redArg(v___x_738_);
lean_dec(v___x_738_);
v___x_740_ = lean_unbox(v___x_739_);
lean_dec(v___x_739_);
v___y_713_ = v___y_728_;
v___y_714_ = v___x_734_;
v___y_715_ = v___x_740_;
goto v___jp_712_;
}
else
{
uint8_t v___x_741_; 
v___x_741_ = lean_byte_array_fget(v_exponents_708_, v___x_736_);
lean_dec(v___x_736_);
v___y_713_ = v___y_728_;
v___y_714_ = v___x_734_;
v___y_715_ = v___x_741_;
goto v___jp_712_;
}
}
v___jp_742_:
{
uint64_t v_a_745_; 
v_a_745_ = lean_uint8_to_uint64(v___y_744_);
switch(v_width_707_)
{
case 0:
{
lean_dec(v___y_743_);
return v_a_745_;
}
case 1:
{
lean_object* v___x_746_; lean_object* v___x_747_; uint8_t v___x_748_; 
v___x_746_ = lean_unsigned_to_nat(1u);
v___x_747_ = lean_nat_add(v___y_743_, v___x_746_);
lean_dec(v___y_743_);
v___x_748_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_708_, v___x_747_);
if (v___x_748_ == 0)
{
lean_object* v___x_749_; lean_object* v___x_750_; uint8_t v___x_751_; 
lean_dec(v___x_747_);
v___x_749_ = lean_box(v___x_711_);
v___x_750_ = l_outOfBounds___redArg(v___x_749_);
lean_dec(v___x_749_);
v___x_751_ = lean_unbox(v___x_750_);
lean_dec(v___x_750_);
v___y_700_ = v_a_745_;
v___y_701_ = v___x_751_;
goto v___jp_699_;
}
else
{
uint8_t v___x_752_; 
v___x_752_ = lean_byte_array_fget(v_exponents_708_, v___x_747_);
lean_dec(v___x_747_);
v___y_700_ = v_a_745_;
v___y_701_ = v___x_752_;
goto v___jp_699_;
}
}
default: 
{
lean_object* v___x_753_; lean_object* v___x_754_; uint8_t v___x_755_; 
v___x_753_ = lean_unsigned_to_nat(1u);
v___x_754_ = lean_nat_add(v___y_743_, v___x_753_);
v___x_755_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_708_, v___x_754_);
if (v___x_755_ == 0)
{
lean_object* v___x_756_; lean_object* v___x_757_; uint8_t v___x_758_; 
lean_dec(v___x_754_);
v___x_756_ = lean_box(v___x_711_);
v___x_757_ = l_outOfBounds___redArg(v___x_756_);
lean_dec(v___x_756_);
v___x_758_ = lean_unbox(v___x_757_);
lean_dec(v___x_757_);
v___y_728_ = v___y_743_;
v___y_729_ = v_a_745_;
v___y_730_ = v___x_758_;
goto v___jp_727_;
}
else
{
uint8_t v___x_759_; 
v___x_759_ = lean_byte_array_fget(v_exponents_708_, v___x_754_);
lean_dec(v___x_754_);
v___y_728_ = v___y_743_;
v___y_729_ = v_a_745_;
v___y_730_ = v___x_759_;
goto v___jp_727_;
}
}
}
}
v___jp_760_:
{
if (v___y_762_ == 0)
{
uint8_t v___x_763_; 
v___x_763_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_708_, v___y_761_);
if (v___x_763_ == 0)
{
lean_object* v___x_764_; lean_object* v___x_765_; uint8_t v___x_766_; 
v___x_764_ = lean_box(v___x_711_);
v___x_765_ = l_outOfBounds___redArg(v___x_764_);
lean_dec(v___x_764_);
v___x_766_ = lean_unbox(v___x_765_);
lean_dec(v___x_765_);
v___y_743_ = v___y_761_;
v___y_744_ = v___x_766_;
goto v___jp_742_;
}
else
{
uint8_t v___x_767_; 
v___x_767_ = lean_byte_array_fget(v_exponents_708_, v___y_761_);
v___y_743_ = v___y_761_;
v___y_744_ = v___x_767_;
goto v___jp_742_;
}
}
else
{
size_t v_pos_768_; uint8_t v___x_769_; uint64_t v_a_770_; 
v_pos_768_ = lean_usize_of_nat(v___y_761_);
lean_dec(v___y_761_);
v___x_769_ = lean_byte_array_uget(v_exponents_708_, v_pos_768_);
v_a_770_ = lean_uint8_to_uint64(v___x_769_);
switch(v_width_707_)
{
case 0:
{
return v_a_770_;
}
case 1:
{
size_t v___x_771_; size_t v___x_772_; uint8_t v___x_773_; uint64_t v___x_774_; uint64_t v___x_775_; uint64_t v___x_776_; uint64_t v___x_777_; 
v___x_771_ = ((size_t)1ULL);
v___x_772_ = lean_usize_add(v_pos_768_, v___x_771_);
v___x_773_ = lean_byte_array_uget(v_exponents_708_, v___x_772_);
v___x_774_ = lean_uint8_to_uint64(v___x_773_);
v___x_775_ = 8ULL;
v___x_776_ = lean_uint64_shift_left(v___x_774_, v___x_775_);
v___x_777_ = lean_uint64_lor(v_a_770_, v___x_776_);
return v___x_777_;
}
default: 
{
size_t v___x_778_; size_t v___x_779_; uint8_t v___x_780_; uint64_t v___x_781_; uint64_t v___x_782_; uint64_t v___x_783_; uint64_t v___x_784_; size_t v___x_785_; size_t v___x_786_; uint8_t v___x_787_; uint64_t v___x_788_; uint64_t v___x_789_; uint64_t v___x_790_; uint64_t v___x_791_; size_t v___x_792_; size_t v___x_793_; uint8_t v___x_794_; uint64_t v___x_795_; uint64_t v___x_796_; uint64_t v___x_797_; uint64_t v___x_798_; 
v___x_778_ = ((size_t)1ULL);
v___x_779_ = lean_usize_add(v_pos_768_, v___x_778_);
v___x_780_ = lean_byte_array_uget(v_exponents_708_, v___x_779_);
v___x_781_ = lean_uint8_to_uint64(v___x_780_);
v___x_782_ = 8ULL;
v___x_783_ = lean_uint64_shift_left(v___x_781_, v___x_782_);
v___x_784_ = lean_uint64_lor(v_a_770_, v___x_783_);
v___x_785_ = ((size_t)2ULL);
v___x_786_ = lean_usize_add(v_pos_768_, v___x_785_);
v___x_787_ = lean_byte_array_uget(v_exponents_708_, v___x_786_);
v___x_788_ = lean_uint8_to_uint64(v___x_787_);
v___x_789_ = 16ULL;
v___x_790_ = lean_uint64_shift_left(v___x_788_, v___x_789_);
v___x_791_ = lean_uint64_lor(v___x_784_, v___x_790_);
v___x_792_ = ((size_t)3ULL);
v___x_793_ = lean_usize_add(v_pos_768_, v___x_792_);
v___x_794_ = lean_byte_array_uget(v_exponents_708_, v___x_793_);
v___x_795_ = lean_uint8_to_uint64(v___x_794_);
v___x_796_ = 24ULL;
v___x_797_ = lean_uint64_shift_left(v___x_795_, v___x_796_);
v___x_798_ = lean_uint64_lor(v___x_791_, v___x_797_);
return v___x_798_;
}
}
}
}
v___jp_799_:
{
lean_object* v_offset_801_; lean_object* v___x_802_; lean_object* v___x_803_; uint8_t v___x_804_; 
v_offset_801_ = lean_nat_mul(v___x_710_, v___y_800_);
lean_dec(v___x_710_);
v___x_802_ = lean_nat_add(v_offset_801_, v___y_800_);
v___x_803_ = lean_byte_array_size(v_exponents_708_);
v___x_804_ = lean_nat_dec_le(v___x_802_, v___x_803_);
if (v___x_804_ == 0)
{
lean_dec(v___x_802_);
v___y_761_ = v_offset_801_;
v___y_762_ = v___x_804_;
goto v___jp_760_;
}
else
{
size_t v___x_805_; lean_object* v___x_806_; uint8_t v___x_807_; 
v___x_805_ = lean_usize_of_nat(v___x_802_);
v___x_806_ = lean_usize_to_nat(v___x_805_);
v___x_807_ = lean_nat_dec_eq(v___x_806_, v___x_802_);
lean_dec(v___x_802_);
lean_dec(v___x_806_);
v___y_761_ = v_offset_801_;
v___y_762_ = v___x_807_;
goto v___jp_760_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_exponent___boxed(lean_object* v_table_811_, lean_object* v_id_812_, lean_object* v_coordinate_813_){
_start:
{
uint64_t v_res_814_; lean_object* v_r_815_; 
v_res_814_ = lp_Hex_Hex_Groebner_MonomialTable_exponent(v_table_811_, v_id_812_, v_coordinate_813_);
lean_dec(v_coordinate_813_);
lean_dec(v_id_812_);
lean_dec_ref(v_table_811_);
v_r_815_ = lean_box_uint64(v_res_814_);
return v_r_815_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_degree(lean_object* v_table_816_, lean_object* v_id_817_){
_start:
{
lean_object* v_metadata_818_; lean_object* v___x_819_; lean_object* v___x_820_; uint64_t v___x_821_; lean_object* v___x_822_; 
v_metadata_818_ = lean_ctor_get(v_table_816_, 2);
v___x_819_ = lean_unsigned_to_nat(3u);
v___x_820_ = lean_nat_mul(v___x_819_, v_id_817_);
v___x_821_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_818_, v___x_820_);
lean_dec(v___x_820_);
v___x_822_ = lean_uint64_to_nat(v___x_821_);
return v___x_822_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_degree___boxed(lean_object* v_table_823_, lean_object* v_id_824_){
_start:
{
lean_object* v_res_825_; 
v_res_825_ = lp_Hex_Hex_Groebner_MonomialTable_degree(v_table_823_, v_id_824_);
lean_dec(v_id_824_);
lean_dec_ref(v_table_823_);
return v_res_825_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_MonomialTable_mask(lean_object* v_table_826_, lean_object* v_id_827_){
_start:
{
lean_object* v_metadata_828_; lean_object* v___x_829_; lean_object* v___x_830_; lean_object* v___x_831_; lean_object* v___x_832_; uint64_t v___x_833_; 
v_metadata_828_ = lean_ctor_get(v_table_826_, 2);
v___x_829_ = lean_unsigned_to_nat(3u);
v___x_830_ = lean_nat_mul(v___x_829_, v_id_827_);
v___x_831_ = lean_unsigned_to_nat(1u);
v___x_832_ = lean_nat_add(v___x_830_, v___x_831_);
lean_dec(v___x_830_);
v___x_833_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_828_, v___x_832_);
lean_dec(v___x_832_);
return v___x_833_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_mask___boxed(lean_object* v_table_834_, lean_object* v_id_835_){
_start:
{
uint64_t v_res_836_; lean_object* v_r_837_; 
v_res_836_ = lp_Hex_Hex_Groebner_MonomialTable_mask(v_table_834_, v_id_835_);
lean_dec(v_id_835_);
lean_dec_ref(v_table_834_);
v_r_837_ = lean_box_uint64(v_res_836_);
return v_r_837_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_Groebner_MonomialTable_hashAt(lean_object* v_table_838_, lean_object* v_id_839_){
_start:
{
lean_object* v_metadata_840_; lean_object* v___x_841_; lean_object* v___x_842_; lean_object* v___x_843_; lean_object* v___x_844_; uint64_t v___x_845_; 
v_metadata_840_ = lean_ctor_get(v_table_838_, 2);
v___x_841_ = lean_unsigned_to_nat(3u);
v___x_842_ = lean_nat_mul(v___x_841_, v_id_839_);
v___x_843_ = lean_unsigned_to_nat(2u);
v___x_844_ = lean_nat_add(v___x_842_, v___x_843_);
lean_dec(v___x_842_);
v___x_845_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_840_, v___x_844_);
lean_dec(v___x_844_);
return v___x_845_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_hashAt___boxed(lean_object* v_table_846_, lean_object* v_id_847_){
_start:
{
uint64_t v_res_848_; lean_object* v_r_849_; 
v_res_848_ = lp_Hex_Hex_Groebner_MonomialTable_hashAt(v_table_846_, v_id_847_);
lean_dec(v_id_847_);
lean_dec_ref(v_table_846_);
v_r_849_ = lean_box_uint64(v_res_848_);
return v_r_849_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0(lean_object* v_xs_850_, lean_object* v_i_851_){
_start:
{
lean_object* v___x_852_; uint8_t v___x_853_; 
v___x_852_ = lean_byte_array_size(v_xs_850_);
v___x_853_ = lean_nat_dec_lt(v_i_851_, v___x_852_);
return v___x_853_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0___boxed(lean_object* v_xs_854_, lean_object* v_i_855_){
_start:
{
uint8_t v_res_856_; lean_object* v_r_857_; 
v_res_856_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0(v_xs_854_, v_i_855_);
lean_dec(v_i_855_);
lean_dec_ref(v_xs_854_);
v_r_857_ = lean_box(v_res_856_);
return v_r_857_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0(lean_object* v_table_858_, lean_object* v_id_859_, size_t v_sz_860_, size_t v_i_861_, lean_object* v_bs_862_){
_start:
{
uint8_t v___x_863_; 
v___x_863_ = lean_usize_dec_lt(v_i_861_, v_sz_860_);
if (v___x_863_ == 0)
{
return v_bs_862_;
}
else
{
lean_object* v_arity_864_; uint8_t v_width_865_; lean_object* v_exponents_866_; lean_object* v_v_867_; lean_object* v___x_868_; lean_object* v_bs_x27_869_; lean_object* v___y_871_; uint64_t v___y_877_; uint8_t v___y_878_; uint64_t v___y_885_; uint8_t v___y_886_; lean_object* v___x_892_; lean_object* v___x_893_; uint8_t v___x_894_; lean_object* v___y_896_; uint64_t v___y_897_; uint8_t v___y_898_; lean_object* v___y_911_; uint64_t v___y_912_; uint8_t v___y_913_; lean_object* v___y_926_; uint8_t v___y_927_; lean_object* v___y_945_; uint8_t v___y_946_; lean_object* v___y_987_; 
v_arity_864_ = lean_ctor_get(v_table_858_, 0);
v_width_865_ = lean_ctor_get_uint8(v_table_858_, sizeof(void*)*9);
v_exponents_866_ = lean_ctor_get(v_table_858_, 1);
v_v_867_ = lean_array_uget(v_bs_862_, v_i_861_);
v___x_868_ = lean_unsigned_to_nat(0u);
v_bs_x27_869_ = lean_array_uset(v_bs_862_, v_i_861_, v___x_868_);
v___x_892_ = lean_nat_mul(v_id_859_, v_arity_864_);
v___x_893_ = lean_nat_add(v___x_892_, v_v_867_);
lean_dec(v_v_867_);
lean_dec(v___x_892_);
v___x_894_ = 0;
switch(v_width_865_)
{
case 0:
{
lean_object* v___x_995_; 
v___x_995_ = lean_unsigned_to_nat(1u);
v___y_987_ = v___x_995_;
goto v___jp_986_;
}
case 1:
{
lean_object* v___x_996_; 
v___x_996_ = lean_unsigned_to_nat(2u);
v___y_987_ = v___x_996_;
goto v___jp_986_;
}
default: 
{
lean_object* v___x_997_; 
v___x_997_ = lean_unsigned_to_nat(4u);
v___y_987_ = v___x_997_;
goto v___jp_986_;
}
}
v___jp_870_:
{
size_t v___x_872_; size_t v___x_873_; lean_object* v___x_874_; 
v___x_872_ = ((size_t)1ULL);
v___x_873_ = lean_usize_add(v_i_861_, v___x_872_);
v___x_874_ = lean_array_uset(v_bs_x27_869_, v_i_861_, v___y_871_);
v_i_861_ = v___x_873_;
v_bs_862_ = v___x_874_;
goto _start;
}
v___jp_876_:
{
uint64_t v___x_879_; uint64_t v___x_880_; uint64_t v___x_881_; uint64_t v___x_882_; lean_object* v___x_883_; 
v___x_879_ = lean_uint8_to_uint64(v___y_878_);
v___x_880_ = 24ULL;
v___x_881_ = lean_uint64_shift_left(v___x_879_, v___x_880_);
v___x_882_ = lean_uint64_lor(v___y_877_, v___x_881_);
v___x_883_ = lean_uint64_to_nat(v___x_882_);
v___y_871_ = v___x_883_;
goto v___jp_870_;
}
v___jp_884_:
{
uint64_t v___x_887_; uint64_t v___x_888_; uint64_t v___x_889_; uint64_t v___x_890_; lean_object* v___x_891_; 
v___x_887_ = lean_uint8_to_uint64(v___y_886_);
v___x_888_ = 8ULL;
v___x_889_ = lean_uint64_shift_left(v___x_887_, v___x_888_);
v___x_890_ = lean_uint64_lor(v___y_885_, v___x_889_);
v___x_891_ = lean_uint64_to_nat(v___x_890_);
v___y_871_ = v___x_891_;
goto v___jp_870_;
}
v___jp_895_:
{
uint64_t v___x_899_; uint64_t v___x_900_; uint64_t v___x_901_; uint64_t v___x_902_; lean_object* v___x_903_; lean_object* v___x_904_; uint8_t v___x_905_; 
v___x_899_ = lean_uint8_to_uint64(v___y_898_);
v___x_900_ = 16ULL;
v___x_901_ = lean_uint64_shift_left(v___x_899_, v___x_900_);
v___x_902_ = lean_uint64_lor(v___y_897_, v___x_901_);
v___x_903_ = lean_unsigned_to_nat(3u);
v___x_904_ = lean_nat_add(v___y_896_, v___x_903_);
lean_dec(v___y_896_);
v___x_905_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0(v_exponents_866_, v___x_904_);
if (v___x_905_ == 0)
{
lean_object* v___x_906_; lean_object* v___x_907_; uint8_t v___x_908_; 
lean_dec(v___x_904_);
v___x_906_ = lean_box(v___x_894_);
v___x_907_ = l_outOfBounds___redArg(v___x_906_);
lean_dec(v___x_906_);
v___x_908_ = lean_unbox(v___x_907_);
lean_dec(v___x_907_);
v___y_877_ = v___x_902_;
v___y_878_ = v___x_908_;
goto v___jp_876_;
}
else
{
uint8_t v___x_909_; 
v___x_909_ = lean_byte_array_fget(v_exponents_866_, v___x_904_);
lean_dec(v___x_904_);
v___y_877_ = v___x_902_;
v___y_878_ = v___x_909_;
goto v___jp_876_;
}
}
v___jp_910_:
{
uint64_t v___x_914_; uint64_t v___x_915_; uint64_t v___x_916_; uint64_t v___x_917_; lean_object* v___x_918_; lean_object* v___x_919_; uint8_t v___x_920_; 
v___x_914_ = lean_uint8_to_uint64(v___y_913_);
v___x_915_ = 8ULL;
v___x_916_ = lean_uint64_shift_left(v___x_914_, v___x_915_);
v___x_917_ = lean_uint64_lor(v___y_912_, v___x_916_);
v___x_918_ = lean_unsigned_to_nat(2u);
v___x_919_ = lean_nat_add(v___y_911_, v___x_918_);
v___x_920_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0(v_exponents_866_, v___x_919_);
if (v___x_920_ == 0)
{
lean_object* v___x_921_; lean_object* v___x_922_; uint8_t v___x_923_; 
lean_dec(v___x_919_);
v___x_921_ = lean_box(v___x_894_);
v___x_922_ = l_outOfBounds___redArg(v___x_921_);
lean_dec(v___x_921_);
v___x_923_ = lean_unbox(v___x_922_);
lean_dec(v___x_922_);
v___y_896_ = v___y_911_;
v___y_897_ = v___x_917_;
v___y_898_ = v___x_923_;
goto v___jp_895_;
}
else
{
uint8_t v___x_924_; 
v___x_924_ = lean_byte_array_fget(v_exponents_866_, v___x_919_);
lean_dec(v___x_919_);
v___y_896_ = v___y_911_;
v___y_897_ = v___x_917_;
v___y_898_ = v___x_924_;
goto v___jp_895_;
}
}
v___jp_925_:
{
uint64_t v_a_928_; 
v_a_928_ = lean_uint8_to_uint64(v___y_927_);
switch(v_width_865_)
{
case 0:
{
lean_object* v___x_929_; 
lean_dec(v___y_926_);
v___x_929_ = lean_uint64_to_nat(v_a_928_);
v___y_871_ = v___x_929_;
goto v___jp_870_;
}
case 1:
{
lean_object* v___x_930_; lean_object* v___x_931_; uint8_t v___x_932_; 
v___x_930_ = lean_unsigned_to_nat(1u);
v___x_931_ = lean_nat_add(v___y_926_, v___x_930_);
lean_dec(v___y_926_);
v___x_932_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0(v_exponents_866_, v___x_931_);
if (v___x_932_ == 0)
{
lean_object* v___x_933_; lean_object* v___x_934_; uint8_t v___x_935_; 
lean_dec(v___x_931_);
v___x_933_ = lean_box(v___x_894_);
v___x_934_ = l_outOfBounds___redArg(v___x_933_);
lean_dec(v___x_933_);
v___x_935_ = lean_unbox(v___x_934_);
lean_dec(v___x_934_);
v___y_885_ = v_a_928_;
v___y_886_ = v___x_935_;
goto v___jp_884_;
}
else
{
uint8_t v___x_936_; 
v___x_936_ = lean_byte_array_fget(v_exponents_866_, v___x_931_);
lean_dec(v___x_931_);
v___y_885_ = v_a_928_;
v___y_886_ = v___x_936_;
goto v___jp_884_;
}
}
default: 
{
lean_object* v___x_937_; lean_object* v___x_938_; uint8_t v___x_939_; 
v___x_937_ = lean_unsigned_to_nat(1u);
v___x_938_ = lean_nat_add(v___y_926_, v___x_937_);
v___x_939_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0(v_exponents_866_, v___x_938_);
if (v___x_939_ == 0)
{
lean_object* v___x_940_; lean_object* v___x_941_; uint8_t v___x_942_; 
lean_dec(v___x_938_);
v___x_940_ = lean_box(v___x_894_);
v___x_941_ = l_outOfBounds___redArg(v___x_940_);
lean_dec(v___x_940_);
v___x_942_ = lean_unbox(v___x_941_);
lean_dec(v___x_941_);
v___y_911_ = v___y_926_;
v___y_912_ = v_a_928_;
v___y_913_ = v___x_942_;
goto v___jp_910_;
}
else
{
uint8_t v___x_943_; 
v___x_943_ = lean_byte_array_fget(v_exponents_866_, v___x_938_);
lean_dec(v___x_938_);
v___y_911_ = v___y_926_;
v___y_912_ = v_a_928_;
v___y_913_ = v___x_943_;
goto v___jp_910_;
}
}
}
}
v___jp_944_:
{
if (v___y_946_ == 0)
{
uint8_t v___x_947_; 
v___x_947_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___lam__0(v_exponents_866_, v___y_945_);
if (v___x_947_ == 0)
{
lean_object* v___x_948_; lean_object* v___x_949_; uint8_t v___x_950_; 
v___x_948_ = lean_box(v___x_894_);
v___x_949_ = l_outOfBounds___redArg(v___x_948_);
lean_dec(v___x_948_);
v___x_950_ = lean_unbox(v___x_949_);
lean_dec(v___x_949_);
v___y_926_ = v___y_945_;
v___y_927_ = v___x_950_;
goto v___jp_925_;
}
else
{
uint8_t v___x_951_; 
v___x_951_ = lean_byte_array_fget(v_exponents_866_, v___y_945_);
v___y_926_ = v___y_945_;
v___y_927_ = v___x_951_;
goto v___jp_925_;
}
}
else
{
size_t v_pos_952_; uint8_t v___x_953_; uint64_t v_a_954_; 
v_pos_952_ = lean_usize_of_nat(v___y_945_);
lean_dec(v___y_945_);
v___x_953_ = lean_byte_array_uget(v_exponents_866_, v_pos_952_);
v_a_954_ = lean_uint8_to_uint64(v___x_953_);
switch(v_width_865_)
{
case 0:
{
lean_object* v___x_955_; 
v___x_955_ = lean_uint64_to_nat(v_a_954_);
v___y_871_ = v___x_955_;
goto v___jp_870_;
}
case 1:
{
size_t v___x_956_; size_t v___x_957_; uint8_t v___x_958_; uint64_t v___x_959_; uint64_t v___x_960_; uint64_t v___x_961_; uint64_t v___x_962_; lean_object* v___x_963_; 
v___x_956_ = ((size_t)1ULL);
v___x_957_ = lean_usize_add(v_pos_952_, v___x_956_);
v___x_958_ = lean_byte_array_uget(v_exponents_866_, v___x_957_);
v___x_959_ = lean_uint8_to_uint64(v___x_958_);
v___x_960_ = 8ULL;
v___x_961_ = lean_uint64_shift_left(v___x_959_, v___x_960_);
v___x_962_ = lean_uint64_lor(v_a_954_, v___x_961_);
v___x_963_ = lean_uint64_to_nat(v___x_962_);
v___y_871_ = v___x_963_;
goto v___jp_870_;
}
default: 
{
size_t v___x_964_; size_t v___x_965_; uint8_t v___x_966_; uint64_t v___x_967_; uint64_t v___x_968_; uint64_t v___x_969_; uint64_t v___x_970_; size_t v___x_971_; size_t v___x_972_; uint8_t v___x_973_; uint64_t v___x_974_; uint64_t v___x_975_; uint64_t v___x_976_; uint64_t v___x_977_; size_t v___x_978_; size_t v___x_979_; uint8_t v___x_980_; uint64_t v___x_981_; uint64_t v___x_982_; uint64_t v___x_983_; uint64_t v___x_984_; lean_object* v___x_985_; 
v___x_964_ = ((size_t)1ULL);
v___x_965_ = lean_usize_add(v_pos_952_, v___x_964_);
v___x_966_ = lean_byte_array_uget(v_exponents_866_, v___x_965_);
v___x_967_ = lean_uint8_to_uint64(v___x_966_);
v___x_968_ = 8ULL;
v___x_969_ = lean_uint64_shift_left(v___x_967_, v___x_968_);
v___x_970_ = lean_uint64_lor(v_a_954_, v___x_969_);
v___x_971_ = ((size_t)2ULL);
v___x_972_ = lean_usize_add(v_pos_952_, v___x_971_);
v___x_973_ = lean_byte_array_uget(v_exponents_866_, v___x_972_);
v___x_974_ = lean_uint8_to_uint64(v___x_973_);
v___x_975_ = 16ULL;
v___x_976_ = lean_uint64_shift_left(v___x_974_, v___x_975_);
v___x_977_ = lean_uint64_lor(v___x_970_, v___x_976_);
v___x_978_ = ((size_t)3ULL);
v___x_979_ = lean_usize_add(v_pos_952_, v___x_978_);
v___x_980_ = lean_byte_array_uget(v_exponents_866_, v___x_979_);
v___x_981_ = lean_uint8_to_uint64(v___x_980_);
v___x_982_ = 24ULL;
v___x_983_ = lean_uint64_shift_left(v___x_981_, v___x_982_);
v___x_984_ = lean_uint64_lor(v___x_977_, v___x_983_);
v___x_985_ = lean_uint64_to_nat(v___x_984_);
v___y_871_ = v___x_985_;
goto v___jp_870_;
}
}
}
}
v___jp_986_:
{
lean_object* v_offset_988_; lean_object* v___x_989_; lean_object* v___x_990_; uint8_t v___x_991_; 
v_offset_988_ = lean_nat_mul(v___x_893_, v___y_987_);
lean_dec(v___x_893_);
v___x_989_ = lean_nat_add(v_offset_988_, v___y_987_);
v___x_990_ = lean_byte_array_size(v_exponents_866_);
v___x_991_ = lean_nat_dec_le(v___x_989_, v___x_990_);
if (v___x_991_ == 0)
{
lean_dec(v___x_989_);
v___y_945_ = v_offset_988_;
v___y_946_ = v___x_991_;
goto v___jp_944_;
}
else
{
size_t v___x_992_; lean_object* v___x_993_; uint8_t v___x_994_; 
v___x_992_ = lean_usize_of_nat(v___x_989_);
v___x_993_ = lean_usize_to_nat(v___x_992_);
v___x_994_ = lean_nat_dec_eq(v___x_993_, v___x_989_);
lean_dec(v___x_989_);
lean_dec(v___x_993_);
v___y_945_ = v_offset_988_;
v___y_946_ = v___x_994_;
goto v___jp_944_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0___boxed(lean_object* v_table_998_, lean_object* v_id_999_, lean_object* v_sz_1000_, lean_object* v_i_1001_, lean_object* v_bs_1002_){
_start:
{
size_t v_sz_boxed_1003_; size_t v_i_boxed_1004_; lean_object* v_res_1005_; 
v_sz_boxed_1003_ = lean_unbox_usize(v_sz_1000_);
lean_dec(v_sz_1000_);
v_i_boxed_1004_ = lean_unbox_usize(v_i_1001_);
lean_dec(v_i_1001_);
v_res_1005_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0(v_table_998_, v_id_999_, v_sz_boxed_1003_, v_i_boxed_1004_, v_bs_1002_);
lean_dec(v_id_999_);
lean_dec_ref(v_table_998_);
return v_res_1005_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_exponentsAt(lean_object* v_table_1006_, lean_object* v_id_1007_){
_start:
{
lean_object* v_arity_1008_; lean_object* v___x_1009_; size_t v_sz_1010_; size_t v___x_1011_; lean_object* v___x_1012_; 
v_arity_1008_ = lean_ctor_get(v_table_1006_, 0);
lean_inc(v_arity_1008_);
v___x_1009_ = l_Array_range(v_arity_1008_);
v_sz_1010_ = lean_array_size(v___x_1009_);
v___x_1011_ = ((size_t)0ULL);
v___x_1012_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_mapMUnsafe_map___at___00Hex_Groebner_MonomialTable_exponentsAt_spec__0(v_table_1006_, v_id_1007_, v_sz_1010_, v___x_1011_, v___x_1009_);
lean_dec_ref(v_table_1006_);
return v___x_1012_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_exponentsAt___boxed(lean_object* v_table_1013_, lean_object* v_id_1014_){
_start:
{
lean_object* v_res_1015_; 
v_res_1015_ = lp_Hex_Hex_Groebner_MonomialTable_exponentsAt(v_table_1013_, v_id_1014_);
lean_dec(v_id_1014_);
return v_res_1015_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg(lean_object* v___x_1019_, lean_object* v_b_1020_, lean_object* v_table_1021_, lean_object* v_a_1022_, lean_object* v_range_1023_, lean_object* v_b_1024_, lean_object* v_i_1025_){
_start:
{
lean_object* v_stop_1026_; lean_object* v_step_1027_; uint8_t v___x_1028_; 
v_stop_1026_ = lean_ctor_get(v_range_1023_, 1);
v_step_1027_ = lean_ctor_get(v_range_1023_, 2);
v___x_1028_ = lean_nat_dec_lt(v_i_1025_, v_stop_1026_);
if (v___x_1028_ == 0)
{
lean_dec(v_i_1025_);
lean_inc_ref(v_b_1024_);
return v_b_1024_;
}
else
{
lean_object* v_arity_1029_; uint8_t v_width_1030_; lean_object* v_exponents_1031_; lean_object* v___x_1032_; lean_object* v___x_1033_; uint8_t v___x_1034_; uint64_t v___y_1036_; uint64_t v___y_1037_; uint64_t v___y_1045_; uint64_t v___y_1046_; uint8_t v___y_1047_; lean_object* v___y_1053_; uint64_t v___y_1054_; uint64_t v___y_1055_; uint8_t v___y_1056_; lean_object* v___y_1057_; uint8_t v___y_1058_; lean_object* v___y_1071_; uint64_t v___y_1072_; uint64_t v___y_1073_; uint8_t v___y_1074_; lean_object* v___y_1075_; uint8_t v___y_1076_; uint64_t v___y_1089_; uint64_t v___y_1090_; uint8_t v___y_1091_; lean_object* v___y_1097_; uint64_t v___y_1098_; uint8_t v___y_1099_; lean_object* v___y_1100_; uint8_t v___y_1101_; uint8_t v___y_1102_; lean_object* v___y_1119_; uint64_t v___y_1120_; uint8_t v___y_1121_; lean_object* v___y_1122_; uint8_t v___y_1123_; uint8_t v___y_1124_; lean_object* v___y_1162_; uint64_t v___y_1163_; uint8_t v___y_1164_; uint8_t v___y_1165_; lean_object* v___y_1166_; lean_object* v___y_1167_; uint64_t v___y_1176_; uint64_t v___y_1184_; uint8_t v___y_1185_; uint64_t v___y_1191_; uint8_t v___y_1192_; lean_object* v___x_1197_; lean_object* v___x_1198_; uint8_t v___x_1199_; uint64_t v___y_1201_; lean_object* v___y_1202_; uint8_t v___y_1203_; lean_object* v___y_1216_; uint64_t v___y_1217_; uint8_t v___y_1218_; lean_object* v___y_1231_; uint8_t v___y_1232_; lean_object* v___y_1249_; uint8_t v___y_1250_; lean_object* v___y_1288_; 
v_arity_1029_ = lean_ctor_get(v_table_1021_, 0);
v_width_1030_ = lean_ctor_get_uint8(v_table_1021_, sizeof(void*)*9);
v_exponents_1031_ = lean_ctor_get(v_table_1021_, 1);
v___x_1032_ = lean_box(0);
v___x_1033_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg___closed__0));
v___x_1034_ = lean_nat_dec_le(v___x_1019_, v_b_1020_);
v___x_1197_ = lean_nat_mul(v_b_1020_, v_arity_1029_);
v___x_1198_ = lean_nat_add(v___x_1197_, v_i_1025_);
lean_dec(v___x_1197_);
v___x_1199_ = 0;
switch(v_width_1030_)
{
case 0:
{
lean_object* v___x_1296_; 
v___x_1296_ = lean_unsigned_to_nat(1u);
v___y_1288_ = v___x_1296_;
goto v___jp_1287_;
}
case 1:
{
lean_object* v___x_1297_; 
v___x_1297_ = lean_unsigned_to_nat(2u);
v___y_1288_ = v___x_1297_;
goto v___jp_1287_;
}
default: 
{
lean_object* v___x_1298_; 
v___x_1298_ = lean_unsigned_to_nat(4u);
v___y_1288_ = v___x_1298_;
goto v___jp_1287_;
}
}
v___jp_1035_:
{
uint8_t v___x_1038_; 
v___x_1038_ = lean_uint64_dec_lt(v___y_1036_, v___y_1037_);
if (v___x_1038_ == 0)
{
lean_object* v___x_1039_; 
v___x_1039_ = lean_nat_add(v_i_1025_, v_step_1027_);
lean_dec(v_i_1025_);
v_b_1024_ = v___x_1033_;
v_i_1025_ = v___x_1039_;
goto _start;
}
else
{
lean_object* v___x_1041_; lean_object* v___x_1042_; lean_object* v___x_1043_; 
lean_dec(v_i_1025_);
v___x_1041_ = lean_box(v___x_1034_);
v___x_1042_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1042_, 0, v___x_1041_);
v___x_1043_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1043_, 0, v___x_1042_);
lean_ctor_set(v___x_1043_, 1, v___x_1032_);
return v___x_1043_;
}
}
v___jp_1044_:
{
uint64_t v___x_1048_; uint64_t v___x_1049_; uint64_t v___x_1050_; uint64_t v___x_1051_; 
v___x_1048_ = lean_uint8_to_uint64(v___y_1047_);
v___x_1049_ = 24ULL;
v___x_1050_ = lean_uint64_shift_left(v___x_1048_, v___x_1049_);
v___x_1051_ = lean_uint64_lor(v___y_1046_, v___x_1050_);
v___y_1036_ = v___y_1045_;
v___y_1037_ = v___x_1051_;
goto v___jp_1035_;
}
v___jp_1052_:
{
uint64_t v___x_1059_; uint64_t v___x_1060_; uint64_t v___x_1061_; uint64_t v___x_1062_; lean_object* v___x_1063_; lean_object* v___x_1064_; uint8_t v___x_1065_; 
v___x_1059_ = lean_uint8_to_uint64(v___y_1058_);
v___x_1060_ = 16ULL;
v___x_1061_ = lean_uint64_shift_left(v___x_1059_, v___x_1060_);
v___x_1062_ = lean_uint64_lor(v___y_1054_, v___x_1061_);
v___x_1063_ = lean_unsigned_to_nat(3u);
v___x_1064_ = lean_nat_add(v___y_1057_, v___x_1063_);
lean_dec(v___y_1057_);
v___x_1065_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1053_, v___x_1064_);
if (v___x_1065_ == 0)
{
lean_object* v___x_1066_; lean_object* v___x_1067_; uint8_t v___x_1068_; 
lean_dec(v___x_1064_);
v___x_1066_ = lean_box(v___y_1056_);
v___x_1067_ = l_outOfBounds___redArg(v___x_1066_);
lean_dec(v___x_1066_);
v___x_1068_ = lean_unbox(v___x_1067_);
lean_dec(v___x_1067_);
v___y_1045_ = v___y_1055_;
v___y_1046_ = v___x_1062_;
v___y_1047_ = v___x_1068_;
goto v___jp_1044_;
}
else
{
uint8_t v___x_1069_; 
v___x_1069_ = lean_byte_array_fget(v___y_1053_, v___x_1064_);
lean_dec(v___x_1064_);
v___y_1045_ = v___y_1055_;
v___y_1046_ = v___x_1062_;
v___y_1047_ = v___x_1069_;
goto v___jp_1044_;
}
}
v___jp_1070_:
{
uint64_t v___x_1077_; uint64_t v___x_1078_; uint64_t v___x_1079_; uint64_t v___x_1080_; lean_object* v___x_1081_; lean_object* v___x_1082_; uint8_t v___x_1083_; 
v___x_1077_ = lean_uint8_to_uint64(v___y_1076_);
v___x_1078_ = 8ULL;
v___x_1079_ = lean_uint64_shift_left(v___x_1077_, v___x_1078_);
v___x_1080_ = lean_uint64_lor(v___y_1072_, v___x_1079_);
v___x_1081_ = lean_unsigned_to_nat(2u);
v___x_1082_ = lean_nat_add(v___y_1075_, v___x_1081_);
v___x_1083_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1071_, v___x_1082_);
if (v___x_1083_ == 0)
{
lean_object* v___x_1084_; lean_object* v___x_1085_; uint8_t v___x_1086_; 
lean_dec(v___x_1082_);
v___x_1084_ = lean_box(v___y_1074_);
v___x_1085_ = l_outOfBounds___redArg(v___x_1084_);
lean_dec(v___x_1084_);
v___x_1086_ = lean_unbox(v___x_1085_);
lean_dec(v___x_1085_);
v___y_1053_ = v___y_1071_;
v___y_1054_ = v___x_1080_;
v___y_1055_ = v___y_1073_;
v___y_1056_ = v___y_1074_;
v___y_1057_ = v___y_1075_;
v___y_1058_ = v___x_1086_;
goto v___jp_1052_;
}
else
{
uint8_t v___x_1087_; 
v___x_1087_ = lean_byte_array_fget(v___y_1071_, v___x_1082_);
lean_dec(v___x_1082_);
v___y_1053_ = v___y_1071_;
v___y_1054_ = v___x_1080_;
v___y_1055_ = v___y_1073_;
v___y_1056_ = v___y_1074_;
v___y_1057_ = v___y_1075_;
v___y_1058_ = v___x_1087_;
goto v___jp_1052_;
}
}
v___jp_1088_:
{
uint64_t v___x_1092_; uint64_t v___x_1093_; uint64_t v___x_1094_; uint64_t v___x_1095_; 
v___x_1092_ = lean_uint8_to_uint64(v___y_1091_);
v___x_1093_ = 8ULL;
v___x_1094_ = lean_uint64_shift_left(v___x_1092_, v___x_1093_);
v___x_1095_ = lean_uint64_lor(v___y_1089_, v___x_1094_);
v___y_1036_ = v___y_1090_;
v___y_1037_ = v___x_1095_;
goto v___jp_1035_;
}
v___jp_1096_:
{
uint64_t v_a_1103_; 
v_a_1103_ = lean_uint8_to_uint64(v___y_1102_);
switch(v___y_1101_)
{
case 0:
{
lean_dec(v___y_1100_);
v___y_1036_ = v___y_1098_;
v___y_1037_ = v_a_1103_;
goto v___jp_1035_;
}
case 1:
{
lean_object* v___x_1104_; lean_object* v___x_1105_; uint8_t v___x_1106_; 
v___x_1104_ = lean_unsigned_to_nat(1u);
v___x_1105_ = lean_nat_add(v___y_1100_, v___x_1104_);
lean_dec(v___y_1100_);
v___x_1106_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1097_, v___x_1105_);
if (v___x_1106_ == 0)
{
lean_object* v___x_1107_; lean_object* v___x_1108_; uint8_t v___x_1109_; 
lean_dec(v___x_1105_);
v___x_1107_ = lean_box(v___y_1099_);
v___x_1108_ = l_outOfBounds___redArg(v___x_1107_);
lean_dec(v___x_1107_);
v___x_1109_ = lean_unbox(v___x_1108_);
lean_dec(v___x_1108_);
v___y_1089_ = v_a_1103_;
v___y_1090_ = v___y_1098_;
v___y_1091_ = v___x_1109_;
goto v___jp_1088_;
}
else
{
uint8_t v___x_1110_; 
v___x_1110_ = lean_byte_array_fget(v___y_1097_, v___x_1105_);
lean_dec(v___x_1105_);
v___y_1089_ = v_a_1103_;
v___y_1090_ = v___y_1098_;
v___y_1091_ = v___x_1110_;
goto v___jp_1088_;
}
}
default: 
{
lean_object* v___x_1111_; lean_object* v___x_1112_; uint8_t v___x_1113_; 
v___x_1111_ = lean_unsigned_to_nat(1u);
v___x_1112_ = lean_nat_add(v___y_1100_, v___x_1111_);
v___x_1113_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1097_, v___x_1112_);
if (v___x_1113_ == 0)
{
lean_object* v___x_1114_; lean_object* v___x_1115_; uint8_t v___x_1116_; 
lean_dec(v___x_1112_);
v___x_1114_ = lean_box(v___y_1099_);
v___x_1115_ = l_outOfBounds___redArg(v___x_1114_);
lean_dec(v___x_1114_);
v___x_1116_ = lean_unbox(v___x_1115_);
lean_dec(v___x_1115_);
v___y_1071_ = v___y_1097_;
v___y_1072_ = v_a_1103_;
v___y_1073_ = v___y_1098_;
v___y_1074_ = v___y_1099_;
v___y_1075_ = v___y_1100_;
v___y_1076_ = v___x_1116_;
goto v___jp_1070_;
}
else
{
uint8_t v___x_1117_; 
v___x_1117_ = lean_byte_array_fget(v___y_1097_, v___x_1112_);
lean_dec(v___x_1112_);
v___y_1071_ = v___y_1097_;
v___y_1072_ = v_a_1103_;
v___y_1073_ = v___y_1098_;
v___y_1074_ = v___y_1099_;
v___y_1075_ = v___y_1100_;
v___y_1076_ = v___x_1117_;
goto v___jp_1070_;
}
}
}
}
v___jp_1118_:
{
if (v___y_1124_ == 0)
{
uint8_t v___x_1125_; 
v___x_1125_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1119_, v___y_1122_);
if (v___x_1125_ == 0)
{
lean_object* v___x_1126_; lean_object* v___x_1127_; uint8_t v___x_1128_; 
v___x_1126_ = lean_box(v___y_1121_);
v___x_1127_ = l_outOfBounds___redArg(v___x_1126_);
lean_dec(v___x_1126_);
v___x_1128_ = lean_unbox(v___x_1127_);
lean_dec(v___x_1127_);
v___y_1097_ = v___y_1119_;
v___y_1098_ = v___y_1120_;
v___y_1099_ = v___y_1121_;
v___y_1100_ = v___y_1122_;
v___y_1101_ = v___y_1123_;
v___y_1102_ = v___x_1128_;
goto v___jp_1096_;
}
else
{
uint8_t v___x_1129_; 
v___x_1129_ = lean_byte_array_fget(v___y_1119_, v___y_1122_);
v___y_1097_ = v___y_1119_;
v___y_1098_ = v___y_1120_;
v___y_1099_ = v___y_1121_;
v___y_1100_ = v___y_1122_;
v___y_1101_ = v___y_1123_;
v___y_1102_ = v___x_1129_;
goto v___jp_1096_;
}
}
else
{
size_t v_pos_1130_; uint8_t v___x_1131_; uint64_t v_a_1132_; 
v_pos_1130_ = lean_usize_of_nat(v___y_1122_);
lean_dec(v___y_1122_);
v___x_1131_ = lean_byte_array_uget(v___y_1119_, v_pos_1130_);
v_a_1132_ = lean_uint8_to_uint64(v___x_1131_);
switch(v___y_1123_)
{
case 0:
{
v___y_1036_ = v___y_1120_;
v___y_1037_ = v_a_1132_;
goto v___jp_1035_;
}
case 1:
{
size_t v___x_1133_; size_t v___x_1134_; uint8_t v___x_1135_; uint64_t v___x_1136_; uint64_t v___x_1137_; uint64_t v___x_1138_; uint64_t v___x_1139_; 
v___x_1133_ = ((size_t)1ULL);
v___x_1134_ = lean_usize_add(v_pos_1130_, v___x_1133_);
v___x_1135_ = lean_byte_array_uget(v___y_1119_, v___x_1134_);
v___x_1136_ = lean_uint8_to_uint64(v___x_1135_);
v___x_1137_ = 8ULL;
v___x_1138_ = lean_uint64_shift_left(v___x_1136_, v___x_1137_);
v___x_1139_ = lean_uint64_lor(v_a_1132_, v___x_1138_);
v___y_1036_ = v___y_1120_;
v___y_1037_ = v___x_1139_;
goto v___jp_1035_;
}
default: 
{
size_t v___x_1140_; size_t v___x_1141_; uint8_t v___x_1142_; uint64_t v___x_1143_; uint64_t v___x_1144_; uint64_t v___x_1145_; uint64_t v___x_1146_; size_t v___x_1147_; size_t v___x_1148_; uint8_t v___x_1149_; uint64_t v___x_1150_; uint64_t v___x_1151_; uint64_t v___x_1152_; uint64_t v___x_1153_; size_t v___x_1154_; size_t v___x_1155_; uint8_t v___x_1156_; uint64_t v___x_1157_; uint64_t v___x_1158_; uint64_t v___x_1159_; uint64_t v___x_1160_; 
v___x_1140_ = ((size_t)1ULL);
v___x_1141_ = lean_usize_add(v_pos_1130_, v___x_1140_);
v___x_1142_ = lean_byte_array_uget(v___y_1119_, v___x_1141_);
v___x_1143_ = lean_uint8_to_uint64(v___x_1142_);
v___x_1144_ = 8ULL;
v___x_1145_ = lean_uint64_shift_left(v___x_1143_, v___x_1144_);
v___x_1146_ = lean_uint64_lor(v_a_1132_, v___x_1145_);
v___x_1147_ = ((size_t)2ULL);
v___x_1148_ = lean_usize_add(v_pos_1130_, v___x_1147_);
v___x_1149_ = lean_byte_array_uget(v___y_1119_, v___x_1148_);
v___x_1150_ = lean_uint8_to_uint64(v___x_1149_);
v___x_1151_ = 16ULL;
v___x_1152_ = lean_uint64_shift_left(v___x_1150_, v___x_1151_);
v___x_1153_ = lean_uint64_lor(v___x_1146_, v___x_1152_);
v___x_1154_ = ((size_t)3ULL);
v___x_1155_ = lean_usize_add(v_pos_1130_, v___x_1154_);
v___x_1156_ = lean_byte_array_uget(v___y_1119_, v___x_1155_);
v___x_1157_ = lean_uint8_to_uint64(v___x_1156_);
v___x_1158_ = 24ULL;
v___x_1159_ = lean_uint64_shift_left(v___x_1157_, v___x_1158_);
v___x_1160_ = lean_uint64_lor(v___x_1153_, v___x_1159_);
v___y_1036_ = v___y_1120_;
v___y_1037_ = v___x_1160_;
goto v___jp_1035_;
}
}
}
}
v___jp_1161_:
{
lean_object* v_offset_1168_; lean_object* v___x_1169_; lean_object* v___x_1170_; uint8_t v___x_1171_; 
v_offset_1168_ = lean_nat_mul(v___y_1166_, v___y_1167_);
lean_dec(v___y_1166_);
v___x_1169_ = lean_nat_add(v_offset_1168_, v___y_1167_);
v___x_1170_ = lean_byte_array_size(v___y_1162_);
v___x_1171_ = lean_nat_dec_le(v___x_1169_, v___x_1170_);
if (v___x_1171_ == 0)
{
lean_dec(v___x_1169_);
v___y_1119_ = v___y_1162_;
v___y_1120_ = v___y_1163_;
v___y_1121_ = v___y_1164_;
v___y_1122_ = v_offset_1168_;
v___y_1123_ = v___y_1165_;
v___y_1124_ = v___x_1171_;
goto v___jp_1118_;
}
else
{
size_t v___x_1172_; lean_object* v___x_1173_; uint8_t v___x_1174_; 
v___x_1172_ = lean_usize_of_nat(v___x_1169_);
v___x_1173_ = lean_usize_to_nat(v___x_1172_);
v___x_1174_ = lean_nat_dec_eq(v___x_1173_, v___x_1169_);
lean_dec(v___x_1169_);
lean_dec(v___x_1173_);
v___y_1119_ = v___y_1162_;
v___y_1120_ = v___y_1163_;
v___y_1121_ = v___y_1164_;
v___y_1122_ = v_offset_1168_;
v___y_1123_ = v___y_1165_;
v___y_1124_ = v___x_1174_;
goto v___jp_1118_;
}
}
v___jp_1175_:
{
lean_object* v___x_1177_; lean_object* v___x_1178_; uint8_t v___x_1179_; 
v___x_1177_ = lean_nat_mul(v_a_1022_, v_arity_1029_);
v___x_1178_ = lean_nat_add(v___x_1177_, v_i_1025_);
lean_dec(v___x_1177_);
v___x_1179_ = 0;
switch(v_width_1030_)
{
case 0:
{
lean_object* v___x_1180_; 
v___x_1180_ = lean_unsigned_to_nat(1u);
v___y_1162_ = v_exponents_1031_;
v___y_1163_ = v___y_1176_;
v___y_1164_ = v___x_1179_;
v___y_1165_ = v_width_1030_;
v___y_1166_ = v___x_1178_;
v___y_1167_ = v___x_1180_;
goto v___jp_1161_;
}
case 1:
{
lean_object* v___x_1181_; 
v___x_1181_ = lean_unsigned_to_nat(2u);
v___y_1162_ = v_exponents_1031_;
v___y_1163_ = v___y_1176_;
v___y_1164_ = v___x_1179_;
v___y_1165_ = v_width_1030_;
v___y_1166_ = v___x_1178_;
v___y_1167_ = v___x_1181_;
goto v___jp_1161_;
}
default: 
{
lean_object* v___x_1182_; 
v___x_1182_ = lean_unsigned_to_nat(4u);
v___y_1162_ = v_exponents_1031_;
v___y_1163_ = v___y_1176_;
v___y_1164_ = v___x_1179_;
v___y_1165_ = v_width_1030_;
v___y_1166_ = v___x_1178_;
v___y_1167_ = v___x_1182_;
goto v___jp_1161_;
}
}
}
v___jp_1183_:
{
uint64_t v___x_1186_; uint64_t v___x_1187_; uint64_t v___x_1188_; uint64_t v___x_1189_; 
v___x_1186_ = lean_uint8_to_uint64(v___y_1185_);
v___x_1187_ = 24ULL;
v___x_1188_ = lean_uint64_shift_left(v___x_1186_, v___x_1187_);
v___x_1189_ = lean_uint64_lor(v___y_1184_, v___x_1188_);
v___y_1176_ = v___x_1189_;
goto v___jp_1175_;
}
v___jp_1190_:
{
uint64_t v___x_1193_; uint64_t v___x_1194_; uint64_t v___x_1195_; uint64_t v___x_1196_; 
v___x_1193_ = lean_uint8_to_uint64(v___y_1192_);
v___x_1194_ = 8ULL;
v___x_1195_ = lean_uint64_shift_left(v___x_1193_, v___x_1194_);
v___x_1196_ = lean_uint64_lor(v___y_1191_, v___x_1195_);
v___y_1176_ = v___x_1196_;
goto v___jp_1175_;
}
v___jp_1200_:
{
uint64_t v___x_1204_; uint64_t v___x_1205_; uint64_t v___x_1206_; uint64_t v___x_1207_; lean_object* v___x_1208_; lean_object* v___x_1209_; uint8_t v___x_1210_; 
v___x_1204_ = lean_uint8_to_uint64(v___y_1203_);
v___x_1205_ = 16ULL;
v___x_1206_ = lean_uint64_shift_left(v___x_1204_, v___x_1205_);
v___x_1207_ = lean_uint64_lor(v___y_1201_, v___x_1206_);
v___x_1208_ = lean_unsigned_to_nat(3u);
v___x_1209_ = lean_nat_add(v___y_1202_, v___x_1208_);
lean_dec(v___y_1202_);
v___x_1210_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1031_, v___x_1209_);
if (v___x_1210_ == 0)
{
lean_object* v___x_1211_; lean_object* v___x_1212_; uint8_t v___x_1213_; 
lean_dec(v___x_1209_);
v___x_1211_ = lean_box(v___x_1199_);
v___x_1212_ = l_outOfBounds___redArg(v___x_1211_);
lean_dec(v___x_1211_);
v___x_1213_ = lean_unbox(v___x_1212_);
lean_dec(v___x_1212_);
v___y_1184_ = v___x_1207_;
v___y_1185_ = v___x_1213_;
goto v___jp_1183_;
}
else
{
uint8_t v___x_1214_; 
v___x_1214_ = lean_byte_array_fget(v_exponents_1031_, v___x_1209_);
lean_dec(v___x_1209_);
v___y_1184_ = v___x_1207_;
v___y_1185_ = v___x_1214_;
goto v___jp_1183_;
}
}
v___jp_1215_:
{
uint64_t v___x_1219_; uint64_t v___x_1220_; uint64_t v___x_1221_; uint64_t v___x_1222_; lean_object* v___x_1223_; lean_object* v___x_1224_; uint8_t v___x_1225_; 
v___x_1219_ = lean_uint8_to_uint64(v___y_1218_);
v___x_1220_ = 8ULL;
v___x_1221_ = lean_uint64_shift_left(v___x_1219_, v___x_1220_);
v___x_1222_ = lean_uint64_lor(v___y_1217_, v___x_1221_);
v___x_1223_ = lean_unsigned_to_nat(2u);
v___x_1224_ = lean_nat_add(v___y_1216_, v___x_1223_);
v___x_1225_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1031_, v___x_1224_);
if (v___x_1225_ == 0)
{
lean_object* v___x_1226_; lean_object* v___x_1227_; uint8_t v___x_1228_; 
lean_dec(v___x_1224_);
v___x_1226_ = lean_box(v___x_1199_);
v___x_1227_ = l_outOfBounds___redArg(v___x_1226_);
lean_dec(v___x_1226_);
v___x_1228_ = lean_unbox(v___x_1227_);
lean_dec(v___x_1227_);
v___y_1201_ = v___x_1222_;
v___y_1202_ = v___y_1216_;
v___y_1203_ = v___x_1228_;
goto v___jp_1200_;
}
else
{
uint8_t v___x_1229_; 
v___x_1229_ = lean_byte_array_fget(v_exponents_1031_, v___x_1224_);
lean_dec(v___x_1224_);
v___y_1201_ = v___x_1222_;
v___y_1202_ = v___y_1216_;
v___y_1203_ = v___x_1229_;
goto v___jp_1200_;
}
}
v___jp_1230_:
{
uint64_t v_a_1233_; 
v_a_1233_ = lean_uint8_to_uint64(v___y_1232_);
switch(v_width_1030_)
{
case 0:
{
lean_dec(v___y_1231_);
v___y_1176_ = v_a_1233_;
goto v___jp_1175_;
}
case 1:
{
lean_object* v___x_1234_; lean_object* v___x_1235_; uint8_t v___x_1236_; 
v___x_1234_ = lean_unsigned_to_nat(1u);
v___x_1235_ = lean_nat_add(v___y_1231_, v___x_1234_);
lean_dec(v___y_1231_);
v___x_1236_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1031_, v___x_1235_);
if (v___x_1236_ == 0)
{
lean_object* v___x_1237_; lean_object* v___x_1238_; uint8_t v___x_1239_; 
lean_dec(v___x_1235_);
v___x_1237_ = lean_box(v___x_1199_);
v___x_1238_ = l_outOfBounds___redArg(v___x_1237_);
lean_dec(v___x_1237_);
v___x_1239_ = lean_unbox(v___x_1238_);
lean_dec(v___x_1238_);
v___y_1191_ = v_a_1233_;
v___y_1192_ = v___x_1239_;
goto v___jp_1190_;
}
else
{
uint8_t v___x_1240_; 
v___x_1240_ = lean_byte_array_fget(v_exponents_1031_, v___x_1235_);
lean_dec(v___x_1235_);
v___y_1191_ = v_a_1233_;
v___y_1192_ = v___x_1240_;
goto v___jp_1190_;
}
}
default: 
{
lean_object* v___x_1241_; lean_object* v___x_1242_; uint8_t v___x_1243_; 
v___x_1241_ = lean_unsigned_to_nat(1u);
v___x_1242_ = lean_nat_add(v___y_1231_, v___x_1241_);
v___x_1243_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1031_, v___x_1242_);
if (v___x_1243_ == 0)
{
lean_object* v___x_1244_; lean_object* v___x_1245_; uint8_t v___x_1246_; 
lean_dec(v___x_1242_);
v___x_1244_ = lean_box(v___x_1199_);
v___x_1245_ = l_outOfBounds___redArg(v___x_1244_);
lean_dec(v___x_1244_);
v___x_1246_ = lean_unbox(v___x_1245_);
lean_dec(v___x_1245_);
v___y_1216_ = v___y_1231_;
v___y_1217_ = v_a_1233_;
v___y_1218_ = v___x_1246_;
goto v___jp_1215_;
}
else
{
uint8_t v___x_1247_; 
v___x_1247_ = lean_byte_array_fget(v_exponents_1031_, v___x_1242_);
lean_dec(v___x_1242_);
v___y_1216_ = v___y_1231_;
v___y_1217_ = v_a_1233_;
v___y_1218_ = v___x_1247_;
goto v___jp_1215_;
}
}
}
}
v___jp_1248_:
{
if (v___y_1250_ == 0)
{
uint8_t v___x_1251_; 
v___x_1251_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1031_, v___y_1249_);
if (v___x_1251_ == 0)
{
lean_object* v___x_1252_; lean_object* v___x_1253_; uint8_t v___x_1254_; 
v___x_1252_ = lean_box(v___x_1199_);
v___x_1253_ = l_outOfBounds___redArg(v___x_1252_);
lean_dec(v___x_1252_);
v___x_1254_ = lean_unbox(v___x_1253_);
lean_dec(v___x_1253_);
v___y_1231_ = v___y_1249_;
v___y_1232_ = v___x_1254_;
goto v___jp_1230_;
}
else
{
uint8_t v___x_1255_; 
v___x_1255_ = lean_byte_array_fget(v_exponents_1031_, v___y_1249_);
v___y_1231_ = v___y_1249_;
v___y_1232_ = v___x_1255_;
goto v___jp_1230_;
}
}
else
{
size_t v_pos_1256_; uint8_t v___x_1257_; uint64_t v_a_1258_; 
v_pos_1256_ = lean_usize_of_nat(v___y_1249_);
lean_dec(v___y_1249_);
v___x_1257_ = lean_byte_array_uget(v_exponents_1031_, v_pos_1256_);
v_a_1258_ = lean_uint8_to_uint64(v___x_1257_);
switch(v_width_1030_)
{
case 0:
{
v___y_1176_ = v_a_1258_;
goto v___jp_1175_;
}
case 1:
{
size_t v___x_1259_; size_t v___x_1260_; uint8_t v___x_1261_; uint64_t v___x_1262_; uint64_t v___x_1263_; uint64_t v___x_1264_; uint64_t v___x_1265_; 
v___x_1259_ = ((size_t)1ULL);
v___x_1260_ = lean_usize_add(v_pos_1256_, v___x_1259_);
v___x_1261_ = lean_byte_array_uget(v_exponents_1031_, v___x_1260_);
v___x_1262_ = lean_uint8_to_uint64(v___x_1261_);
v___x_1263_ = 8ULL;
v___x_1264_ = lean_uint64_shift_left(v___x_1262_, v___x_1263_);
v___x_1265_ = lean_uint64_lor(v_a_1258_, v___x_1264_);
v___y_1176_ = v___x_1265_;
goto v___jp_1175_;
}
default: 
{
size_t v___x_1266_; size_t v___x_1267_; uint8_t v___x_1268_; uint64_t v___x_1269_; uint64_t v___x_1270_; uint64_t v___x_1271_; uint64_t v___x_1272_; size_t v___x_1273_; size_t v___x_1274_; uint8_t v___x_1275_; uint64_t v___x_1276_; uint64_t v___x_1277_; uint64_t v___x_1278_; uint64_t v___x_1279_; size_t v___x_1280_; size_t v___x_1281_; uint8_t v___x_1282_; uint64_t v___x_1283_; uint64_t v___x_1284_; uint64_t v___x_1285_; uint64_t v___x_1286_; 
v___x_1266_ = ((size_t)1ULL);
v___x_1267_ = lean_usize_add(v_pos_1256_, v___x_1266_);
v___x_1268_ = lean_byte_array_uget(v_exponents_1031_, v___x_1267_);
v___x_1269_ = lean_uint8_to_uint64(v___x_1268_);
v___x_1270_ = 8ULL;
v___x_1271_ = lean_uint64_shift_left(v___x_1269_, v___x_1270_);
v___x_1272_ = lean_uint64_lor(v_a_1258_, v___x_1271_);
v___x_1273_ = ((size_t)2ULL);
v___x_1274_ = lean_usize_add(v_pos_1256_, v___x_1273_);
v___x_1275_ = lean_byte_array_uget(v_exponents_1031_, v___x_1274_);
v___x_1276_ = lean_uint8_to_uint64(v___x_1275_);
v___x_1277_ = 16ULL;
v___x_1278_ = lean_uint64_shift_left(v___x_1276_, v___x_1277_);
v___x_1279_ = lean_uint64_lor(v___x_1272_, v___x_1278_);
v___x_1280_ = ((size_t)3ULL);
v___x_1281_ = lean_usize_add(v_pos_1256_, v___x_1280_);
v___x_1282_ = lean_byte_array_uget(v_exponents_1031_, v___x_1281_);
v___x_1283_ = lean_uint8_to_uint64(v___x_1282_);
v___x_1284_ = 24ULL;
v___x_1285_ = lean_uint64_shift_left(v___x_1283_, v___x_1284_);
v___x_1286_ = lean_uint64_lor(v___x_1279_, v___x_1285_);
v___y_1176_ = v___x_1286_;
goto v___jp_1175_;
}
}
}
}
v___jp_1287_:
{
lean_object* v_offset_1289_; lean_object* v___x_1290_; lean_object* v___x_1291_; uint8_t v___x_1292_; 
v_offset_1289_ = lean_nat_mul(v___x_1198_, v___y_1288_);
lean_dec(v___x_1198_);
v___x_1290_ = lean_nat_add(v_offset_1289_, v___y_1288_);
v___x_1291_ = lean_byte_array_size(v_exponents_1031_);
v___x_1292_ = lean_nat_dec_le(v___x_1290_, v___x_1291_);
if (v___x_1292_ == 0)
{
lean_dec(v___x_1290_);
v___y_1249_ = v_offset_1289_;
v___y_1250_ = v___x_1292_;
goto v___jp_1248_;
}
else
{
size_t v___x_1293_; lean_object* v___x_1294_; uint8_t v___x_1295_; 
v___x_1293_ = lean_usize_of_nat(v___x_1290_);
v___x_1294_ = lean_usize_to_nat(v___x_1293_);
v___x_1295_ = lean_nat_dec_eq(v___x_1294_, v___x_1290_);
lean_dec(v___x_1290_);
lean_dec(v___x_1294_);
v___y_1249_ = v_offset_1289_;
v___y_1250_ = v___x_1295_;
goto v___jp_1248_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg___boxed(lean_object* v___x_1299_, lean_object* v_b_1300_, lean_object* v_table_1301_, lean_object* v_a_1302_, lean_object* v_range_1303_, lean_object* v_b_1304_, lean_object* v_i_1305_){
_start:
{
lean_object* v_res_1306_; 
v_res_1306_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg(v___x_1299_, v_b_1300_, v_table_1301_, v_a_1302_, v_range_1303_, v_b_1304_, v_i_1305_);
lean_dec_ref(v_b_1304_);
lean_dec_ref(v_range_1303_);
lean_dec(v_a_1302_);
lean_dec_ref(v_table_1301_);
lean_dec(v_b_1300_);
lean_dec(v___x_1299_);
return v_res_1306_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_MonomialTable_divides(lean_object* v_table_1307_, lean_object* v_a_1308_, lean_object* v_b_1309_){
_start:
{
lean_object* v_arity_1310_; lean_object* v_metadata_1311_; lean_object* v_count_1312_; uint8_t v___x_1313_; 
v_arity_1310_ = lean_ctor_get(v_table_1307_, 0);
v_metadata_1311_ = lean_ctor_get(v_table_1307_, 2);
v_count_1312_ = lean_ctor_get(v_table_1307_, 3);
v___x_1313_ = lean_nat_dec_le(v_count_1312_, v_a_1308_);
if (v___x_1313_ == 0)
{
uint8_t v___x_1314_; 
v___x_1314_ = lean_nat_dec_le(v_count_1312_, v_b_1309_);
if (v___x_1314_ == 0)
{
lean_object* v___x_1315_; lean_object* v___x_1316_; uint64_t v___x_1317_; lean_object* v___x_1318_; lean_object* v___x_1319_; uint64_t v___x_1320_; lean_object* v___x_1321_; uint8_t v___x_1322_; 
v___x_1315_ = lean_unsigned_to_nat(3u);
v___x_1316_ = lean_nat_mul(v___x_1315_, v_b_1309_);
v___x_1317_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1311_, v___x_1316_);
v___x_1318_ = lean_uint64_to_nat(v___x_1317_);
v___x_1319_ = lean_nat_mul(v___x_1315_, v_a_1308_);
v___x_1320_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1311_, v___x_1319_);
v___x_1321_ = lean_uint64_to_nat(v___x_1320_);
v___x_1322_ = lean_nat_dec_lt(v___x_1318_, v___x_1321_);
lean_dec(v___x_1321_);
lean_dec(v___x_1318_);
if (v___x_1322_ == 0)
{
lean_object* v___x_1323_; lean_object* v___x_1324_; uint64_t v___x_1325_; lean_object* v___x_1326_; uint64_t v___x_1327_; uint64_t v___x_1328_; uint8_t v___x_1329_; 
v___x_1323_ = lean_unsigned_to_nat(1u);
v___x_1324_ = lean_nat_add(v___x_1319_, v___x_1323_);
lean_dec(v___x_1319_);
v___x_1325_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1311_, v___x_1324_);
lean_dec(v___x_1324_);
v___x_1326_ = lean_nat_add(v___x_1316_, v___x_1323_);
lean_dec(v___x_1316_);
v___x_1327_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1311_, v___x_1326_);
lean_dec(v___x_1326_);
v___x_1328_ = lean_uint64_land(v___x_1325_, v___x_1327_);
v___x_1329_ = lean_uint64_dec_eq(v___x_1328_, v___x_1325_);
if (v___x_1329_ == 0)
{
return v___x_1314_;
}
else
{
lean_object* v___x_1330_; lean_object* v___x_1331_; lean_object* v___x_1332_; lean_object* v___x_1333_; lean_object* v_fst_1334_; 
v___x_1330_ = lean_unsigned_to_nat(0u);
lean_inc(v_arity_1310_);
v___x_1331_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1331_, 0, v___x_1330_);
lean_ctor_set(v___x_1331_, 1, v_arity_1310_);
lean_ctor_set(v___x_1331_, 2, v___x_1323_);
v___x_1332_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg___closed__0));
v___x_1333_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg(v_count_1312_, v_b_1309_, v_table_1307_, v_a_1308_, v___x_1331_, v___x_1332_, v___x_1330_);
lean_dec_ref_known(v___x_1331_, 3);
v_fst_1334_ = lean_ctor_get(v___x_1333_, 0);
lean_inc(v_fst_1334_);
lean_dec_ref(v___x_1333_);
if (lean_obj_tag(v_fst_1334_) == 0)
{
return v___x_1329_;
}
else
{
lean_object* v_val_1335_; uint8_t v___x_1336_; 
v_val_1335_ = lean_ctor_get(v_fst_1334_, 0);
lean_inc(v_val_1335_);
lean_dec_ref_known(v_fst_1334_, 1);
v___x_1336_ = lean_unbox(v_val_1335_);
lean_dec(v_val_1335_);
return v___x_1336_;
}
}
}
else
{
lean_dec(v___x_1319_);
lean_dec(v___x_1316_);
return v___x_1314_;
}
}
else
{
return v___x_1313_;
}
}
else
{
uint8_t v___x_1337_; 
v___x_1337_ = 0;
return v___x_1337_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_divides___boxed(lean_object* v_table_1338_, lean_object* v_a_1339_, lean_object* v_b_1340_){
_start:
{
uint8_t v_res_1341_; lean_object* v_r_1342_; 
v_res_1341_ = lp_Hex_Hex_Groebner_MonomialTable_divides(v_table_1338_, v_a_1339_, v_b_1340_);
lean_dec(v_b_1340_);
lean_dec(v_a_1339_);
lean_dec_ref(v_table_1338_);
v_r_1342_ = lean_box(v_res_1341_);
return v_r_1342_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0(lean_object* v___x_1343_, lean_object* v_b_1344_, lean_object* v_table_1345_, lean_object* v_a_1346_, lean_object* v_range_1347_, lean_object* v_b_1348_, lean_object* v_i_1349_, lean_object* v_hs_1350_, lean_object* v_hl_1351_){
_start:
{
lean_object* v___x_1352_; 
v___x_1352_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg(v___x_1343_, v_b_1344_, v_table_1345_, v_a_1346_, v_range_1347_, v_b_1348_, v_i_1349_);
return v___x_1352_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___boxed(lean_object* v___x_1353_, lean_object* v_b_1354_, lean_object* v_table_1355_, lean_object* v_a_1356_, lean_object* v_range_1357_, lean_object* v_b_1358_, lean_object* v_i_1359_, lean_object* v_hs_1360_, lean_object* v_hl_1361_){
_start:
{
lean_object* v_res_1362_; 
v_res_1362_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0(v___x_1353_, v_b_1354_, v_table_1355_, v_a_1356_, v_range_1357_, v_b_1358_, v_i_1359_, v_hs_1360_, v_hl_1361_);
lean_dec_ref(v_b_1358_);
lean_dec_ref(v_range_1357_);
lean_dec(v_a_1356_);
lean_dec_ref(v_table_1355_);
lean_dec(v_b_1354_);
lean_dec(v___x_1353_);
return v_res_1362_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg(uint8_t v_order_1366_, lean_object* v_table_1367_, lean_object* v_b_1368_, lean_object* v_a_1369_, lean_object* v___x_1370_, lean_object* v_range_1371_, lean_object* v_b_1372_, lean_object* v_i_1373_){
_start:
{
lean_object* v_stop_1374_; lean_object* v_step_1375_; uint8_t v___x_1376_; 
v_stop_1374_ = lean_ctor_get(v_range_1371_, 1);
v_step_1375_ = lean_ctor_get(v_range_1371_, 2);
v___x_1376_ = lean_nat_dec_lt(v_i_1373_, v_stop_1374_);
if (v___x_1376_ == 0)
{
lean_dec(v_i_1373_);
lean_inc_ref(v_b_1372_);
return v_b_1372_;
}
else
{
lean_object* v___x_1377_; uint8_t v___y_1379_; lean_object* v___x_1383_; lean_object* v___x_1384_; uint8_t v___x_1385_; uint8_t v___x_1386_; uint64_t v___y_1388_; uint64_t v___y_1389_; uint64_t v___y_1403_; uint64_t v___y_1404_; uint8_t v___y_1405_; lean_object* v___y_1411_; uint64_t v___y_1412_; uint64_t v___y_1413_; uint8_t v___y_1414_; lean_object* v___y_1415_; uint8_t v___y_1416_; lean_object* v___y_1429_; uint64_t v___y_1430_; lean_object* v___y_1431_; uint8_t v___y_1432_; uint64_t v___y_1433_; uint8_t v___y_1434_; uint64_t v___y_1447_; uint64_t v___y_1448_; uint8_t v___y_1449_; lean_object* v___y_1455_; uint64_t v___y_1456_; uint8_t v___y_1457_; uint8_t v___y_1458_; lean_object* v___y_1459_; uint8_t v___y_1460_; lean_object* v___y_1475_; uint64_t v___y_1476_; uint8_t v___y_1477_; uint8_t v___y_1478_; lean_object* v___y_1479_; uint8_t v___y_1480_; uint64_t v___y_1518_; uint8_t v___y_1519_; lean_object* v___y_1520_; lean_object* v___y_1521_; uint8_t v___y_1522_; lean_object* v___y_1523_; lean_object* v___y_1532_; uint64_t v___y_1533_; lean_object* v___y_1543_; uint64_t v___y_1544_; uint8_t v___y_1545_; lean_object* v___y_1551_; lean_object* v___y_1552_; lean_object* v___y_1553_; uint8_t v___y_1554_; uint64_t v___y_1555_; uint8_t v___y_1556_; lean_object* v___y_1569_; lean_object* v___y_1570_; lean_object* v___y_1571_; uint8_t v___y_1572_; uint64_t v___y_1573_; uint8_t v___y_1574_; lean_object* v___y_1587_; uint64_t v___y_1588_; uint8_t v___y_1589_; lean_object* v___y_1595_; lean_object* v___y_1596_; lean_object* v___y_1597_; uint8_t v___y_1598_; uint8_t v___y_1599_; uint8_t v___y_1600_; lean_object* v___y_1615_; lean_object* v___y_1616_; lean_object* v___y_1617_; uint8_t v___y_1618_; uint8_t v___y_1619_; uint8_t v___y_1620_; lean_object* v___y_1658_; lean_object* v___y_1659_; uint8_t v___y_1660_; uint8_t v___y_1661_; lean_object* v___y_1662_; lean_object* v___y_1663_; lean_object* v___y_1672_; 
v___x_1377_ = lean_box(0);
v___x_1383_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg___closed__0));
v___x_1384_ = lean_unsigned_to_nat(1u);
v___x_1385_ = 2;
v___x_1386_ = lp_Hex_Hex_Groebner_instBEqTermOrder_beq(v_order_1366_, v___x_1385_);
if (v___x_1386_ == 0)
{
lean_inc(v_i_1373_);
v___y_1672_ = v_i_1373_;
goto v___jp_1671_;
}
else
{
lean_object* v___x_1681_; lean_object* v___x_1682_; 
v___x_1681_ = lean_nat_sub(v___x_1370_, v___x_1384_);
v___x_1682_ = lean_nat_sub(v___x_1681_, v_i_1373_);
lean_dec(v___x_1681_);
v___y_1672_ = v___x_1682_;
goto v___jp_1671_;
}
v___jp_1378_:
{
lean_object* v___x_1380_; lean_object* v___x_1381_; lean_object* v___x_1382_; 
v___x_1380_ = lean_box(v___y_1379_);
v___x_1381_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1381_, 0, v___x_1380_);
v___x_1382_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1382_, 0, v___x_1381_);
lean_ctor_set(v___x_1382_, 1, v___x_1377_);
return v___x_1382_;
}
v___jp_1387_:
{
uint8_t v___x_1390_; 
v___x_1390_ = lean_uint64_dec_eq(v___y_1388_, v___y_1389_);
if (v___x_1390_ == 0)
{
lean_dec(v_i_1373_);
if (v___x_1386_ == 0)
{
uint8_t v___x_1391_; 
v___x_1391_ = lean_uint64_dec_lt(v___y_1388_, v___y_1389_);
if (v___x_1391_ == 0)
{
if (v___x_1390_ == 0)
{
uint8_t v___x_1392_; 
v___x_1392_ = 2;
v___y_1379_ = v___x_1392_;
goto v___jp_1378_;
}
else
{
uint8_t v___x_1393_; 
v___x_1393_ = 1;
v___y_1379_ = v___x_1393_;
goto v___jp_1378_;
}
}
else
{
uint8_t v___x_1394_; 
v___x_1394_ = 0;
v___y_1379_ = v___x_1394_;
goto v___jp_1378_;
}
}
else
{
uint8_t v___x_1395_; 
v___x_1395_ = lean_uint64_dec_lt(v___y_1389_, v___y_1388_);
if (v___x_1395_ == 0)
{
uint8_t v___x_1396_; 
v___x_1396_ = lean_uint64_dec_eq(v___y_1389_, v___y_1388_);
if (v___x_1396_ == 0)
{
uint8_t v___x_1397_; 
v___x_1397_ = 2;
v___y_1379_ = v___x_1397_;
goto v___jp_1378_;
}
else
{
uint8_t v___x_1398_; 
v___x_1398_ = 1;
v___y_1379_ = v___x_1398_;
goto v___jp_1378_;
}
}
else
{
uint8_t v___x_1399_; 
v___x_1399_ = 0;
v___y_1379_ = v___x_1399_;
goto v___jp_1378_;
}
}
}
else
{
lean_object* v___x_1400_; 
v___x_1400_ = lean_nat_add(v_i_1373_, v_step_1375_);
lean_dec(v_i_1373_);
v_b_1372_ = v___x_1383_;
v_i_1373_ = v___x_1400_;
goto _start;
}
}
v___jp_1402_:
{
uint64_t v___x_1406_; uint64_t v___x_1407_; uint64_t v___x_1408_; uint64_t v___x_1409_; 
v___x_1406_ = lean_uint8_to_uint64(v___y_1405_);
v___x_1407_ = 24ULL;
v___x_1408_ = lean_uint64_shift_left(v___x_1406_, v___x_1407_);
v___x_1409_ = lean_uint64_lor(v___y_1404_, v___x_1408_);
v___y_1388_ = v___y_1403_;
v___y_1389_ = v___x_1409_;
goto v___jp_1387_;
}
v___jp_1410_:
{
uint64_t v___x_1417_; uint64_t v___x_1418_; uint64_t v___x_1419_; uint64_t v___x_1420_; lean_object* v___x_1421_; lean_object* v___x_1422_; uint8_t v___x_1423_; 
v___x_1417_ = lean_uint8_to_uint64(v___y_1416_);
v___x_1418_ = 16ULL;
v___x_1419_ = lean_uint64_shift_left(v___x_1417_, v___x_1418_);
v___x_1420_ = lean_uint64_lor(v___y_1413_, v___x_1419_);
v___x_1421_ = lean_unsigned_to_nat(3u);
v___x_1422_ = lean_nat_add(v___y_1411_, v___x_1421_);
lean_dec(v___y_1411_);
v___x_1423_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1415_, v___x_1422_);
if (v___x_1423_ == 0)
{
lean_object* v___x_1424_; lean_object* v___x_1425_; uint8_t v___x_1426_; 
lean_dec(v___x_1422_);
v___x_1424_ = lean_box(v___y_1414_);
v___x_1425_ = l_outOfBounds___redArg(v___x_1424_);
lean_dec(v___x_1424_);
v___x_1426_ = lean_unbox(v___x_1425_);
lean_dec(v___x_1425_);
v___y_1403_ = v___y_1412_;
v___y_1404_ = v___x_1420_;
v___y_1405_ = v___x_1426_;
goto v___jp_1402_;
}
else
{
uint8_t v___x_1427_; 
v___x_1427_ = lean_byte_array_fget(v___y_1415_, v___x_1422_);
lean_dec(v___x_1422_);
v___y_1403_ = v___y_1412_;
v___y_1404_ = v___x_1420_;
v___y_1405_ = v___x_1427_;
goto v___jp_1402_;
}
}
v___jp_1428_:
{
uint64_t v___x_1435_; uint64_t v___x_1436_; uint64_t v___x_1437_; uint64_t v___x_1438_; lean_object* v___x_1439_; lean_object* v___x_1440_; uint8_t v___x_1441_; 
v___x_1435_ = lean_uint8_to_uint64(v___y_1434_);
v___x_1436_ = 8ULL;
v___x_1437_ = lean_uint64_shift_left(v___x_1435_, v___x_1436_);
v___x_1438_ = lean_uint64_lor(v___y_1433_, v___x_1437_);
v___x_1439_ = lean_unsigned_to_nat(2u);
v___x_1440_ = lean_nat_add(v___y_1429_, v___x_1439_);
v___x_1441_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1431_, v___x_1440_);
if (v___x_1441_ == 0)
{
lean_object* v___x_1442_; lean_object* v___x_1443_; uint8_t v___x_1444_; 
lean_dec(v___x_1440_);
v___x_1442_ = lean_box(v___y_1432_);
v___x_1443_ = l_outOfBounds___redArg(v___x_1442_);
lean_dec(v___x_1442_);
v___x_1444_ = lean_unbox(v___x_1443_);
lean_dec(v___x_1443_);
v___y_1411_ = v___y_1429_;
v___y_1412_ = v___y_1430_;
v___y_1413_ = v___x_1438_;
v___y_1414_ = v___y_1432_;
v___y_1415_ = v___y_1431_;
v___y_1416_ = v___x_1444_;
goto v___jp_1410_;
}
else
{
uint8_t v___x_1445_; 
v___x_1445_ = lean_byte_array_fget(v___y_1431_, v___x_1440_);
lean_dec(v___x_1440_);
v___y_1411_ = v___y_1429_;
v___y_1412_ = v___y_1430_;
v___y_1413_ = v___x_1438_;
v___y_1414_ = v___y_1432_;
v___y_1415_ = v___y_1431_;
v___y_1416_ = v___x_1445_;
goto v___jp_1410_;
}
}
v___jp_1446_:
{
uint64_t v___x_1450_; uint64_t v___x_1451_; uint64_t v___x_1452_; uint64_t v___x_1453_; 
v___x_1450_ = lean_uint8_to_uint64(v___y_1449_);
v___x_1451_ = 8ULL;
v___x_1452_ = lean_uint64_shift_left(v___x_1450_, v___x_1451_);
v___x_1453_ = lean_uint64_lor(v___y_1448_, v___x_1452_);
v___y_1388_ = v___y_1447_;
v___y_1389_ = v___x_1453_;
goto v___jp_1387_;
}
v___jp_1454_:
{
uint64_t v_a_1461_; 
v_a_1461_ = lean_uint8_to_uint64(v___y_1460_);
switch(v___y_1457_)
{
case 0:
{
lean_dec(v___y_1455_);
v___y_1388_ = v___y_1456_;
v___y_1389_ = v_a_1461_;
goto v___jp_1387_;
}
case 1:
{
lean_object* v___x_1462_; uint8_t v___x_1463_; 
v___x_1462_ = lean_nat_add(v___y_1455_, v___x_1384_);
lean_dec(v___y_1455_);
v___x_1463_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1459_, v___x_1462_);
if (v___x_1463_ == 0)
{
lean_object* v___x_1464_; lean_object* v___x_1465_; uint8_t v___x_1466_; 
lean_dec(v___x_1462_);
v___x_1464_ = lean_box(v___y_1458_);
v___x_1465_ = l_outOfBounds___redArg(v___x_1464_);
lean_dec(v___x_1464_);
v___x_1466_ = lean_unbox(v___x_1465_);
lean_dec(v___x_1465_);
v___y_1447_ = v___y_1456_;
v___y_1448_ = v_a_1461_;
v___y_1449_ = v___x_1466_;
goto v___jp_1446_;
}
else
{
uint8_t v___x_1467_; 
v___x_1467_ = lean_byte_array_fget(v___y_1459_, v___x_1462_);
lean_dec(v___x_1462_);
v___y_1447_ = v___y_1456_;
v___y_1448_ = v_a_1461_;
v___y_1449_ = v___x_1467_;
goto v___jp_1446_;
}
}
default: 
{
lean_object* v___x_1468_; uint8_t v___x_1469_; 
v___x_1468_ = lean_nat_add(v___y_1455_, v___x_1384_);
v___x_1469_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1459_, v___x_1468_);
if (v___x_1469_ == 0)
{
lean_object* v___x_1470_; lean_object* v___x_1471_; uint8_t v___x_1472_; 
lean_dec(v___x_1468_);
v___x_1470_ = lean_box(v___y_1458_);
v___x_1471_ = l_outOfBounds___redArg(v___x_1470_);
lean_dec(v___x_1470_);
v___x_1472_ = lean_unbox(v___x_1471_);
lean_dec(v___x_1471_);
v___y_1429_ = v___y_1455_;
v___y_1430_ = v___y_1456_;
v___y_1431_ = v___y_1459_;
v___y_1432_ = v___y_1458_;
v___y_1433_ = v_a_1461_;
v___y_1434_ = v___x_1472_;
goto v___jp_1428_;
}
else
{
uint8_t v___x_1473_; 
v___x_1473_ = lean_byte_array_fget(v___y_1459_, v___x_1468_);
lean_dec(v___x_1468_);
v___y_1429_ = v___y_1455_;
v___y_1430_ = v___y_1456_;
v___y_1431_ = v___y_1459_;
v___y_1432_ = v___y_1458_;
v___y_1433_ = v_a_1461_;
v___y_1434_ = v___x_1473_;
goto v___jp_1428_;
}
}
}
}
v___jp_1474_:
{
if (v___y_1480_ == 0)
{
uint8_t v___x_1481_; 
v___x_1481_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1479_, v___y_1475_);
if (v___x_1481_ == 0)
{
lean_object* v___x_1482_; lean_object* v___x_1483_; uint8_t v___x_1484_; 
v___x_1482_ = lean_box(v___y_1478_);
v___x_1483_ = l_outOfBounds___redArg(v___x_1482_);
lean_dec(v___x_1482_);
v___x_1484_ = lean_unbox(v___x_1483_);
lean_dec(v___x_1483_);
v___y_1455_ = v___y_1475_;
v___y_1456_ = v___y_1476_;
v___y_1457_ = v___y_1477_;
v___y_1458_ = v___y_1478_;
v___y_1459_ = v___y_1479_;
v___y_1460_ = v___x_1484_;
goto v___jp_1454_;
}
else
{
uint8_t v___x_1485_; 
v___x_1485_ = lean_byte_array_fget(v___y_1479_, v___y_1475_);
v___y_1455_ = v___y_1475_;
v___y_1456_ = v___y_1476_;
v___y_1457_ = v___y_1477_;
v___y_1458_ = v___y_1478_;
v___y_1459_ = v___y_1479_;
v___y_1460_ = v___x_1485_;
goto v___jp_1454_;
}
}
else
{
size_t v_pos_1486_; uint8_t v___x_1487_; uint64_t v_a_1488_; 
v_pos_1486_ = lean_usize_of_nat(v___y_1475_);
lean_dec(v___y_1475_);
v___x_1487_ = lean_byte_array_uget(v___y_1479_, v_pos_1486_);
v_a_1488_ = lean_uint8_to_uint64(v___x_1487_);
switch(v___y_1477_)
{
case 0:
{
v___y_1388_ = v___y_1476_;
v___y_1389_ = v_a_1488_;
goto v___jp_1387_;
}
case 1:
{
size_t v___x_1489_; size_t v___x_1490_; uint8_t v___x_1491_; uint64_t v___x_1492_; uint64_t v___x_1493_; uint64_t v___x_1494_; uint64_t v___x_1495_; 
v___x_1489_ = ((size_t)1ULL);
v___x_1490_ = lean_usize_add(v_pos_1486_, v___x_1489_);
v___x_1491_ = lean_byte_array_uget(v___y_1479_, v___x_1490_);
v___x_1492_ = lean_uint8_to_uint64(v___x_1491_);
v___x_1493_ = 8ULL;
v___x_1494_ = lean_uint64_shift_left(v___x_1492_, v___x_1493_);
v___x_1495_ = lean_uint64_lor(v_a_1488_, v___x_1494_);
v___y_1388_ = v___y_1476_;
v___y_1389_ = v___x_1495_;
goto v___jp_1387_;
}
default: 
{
size_t v___x_1496_; size_t v___x_1497_; uint8_t v___x_1498_; uint64_t v___x_1499_; uint64_t v___x_1500_; uint64_t v___x_1501_; uint64_t v___x_1502_; size_t v___x_1503_; size_t v___x_1504_; uint8_t v___x_1505_; uint64_t v___x_1506_; uint64_t v___x_1507_; uint64_t v___x_1508_; uint64_t v___x_1509_; size_t v___x_1510_; size_t v___x_1511_; uint8_t v___x_1512_; uint64_t v___x_1513_; uint64_t v___x_1514_; uint64_t v___x_1515_; uint64_t v___x_1516_; 
v___x_1496_ = ((size_t)1ULL);
v___x_1497_ = lean_usize_add(v_pos_1486_, v___x_1496_);
v___x_1498_ = lean_byte_array_uget(v___y_1479_, v___x_1497_);
v___x_1499_ = lean_uint8_to_uint64(v___x_1498_);
v___x_1500_ = 8ULL;
v___x_1501_ = lean_uint64_shift_left(v___x_1499_, v___x_1500_);
v___x_1502_ = lean_uint64_lor(v_a_1488_, v___x_1501_);
v___x_1503_ = ((size_t)2ULL);
v___x_1504_ = lean_usize_add(v_pos_1486_, v___x_1503_);
v___x_1505_ = lean_byte_array_uget(v___y_1479_, v___x_1504_);
v___x_1506_ = lean_uint8_to_uint64(v___x_1505_);
v___x_1507_ = 16ULL;
v___x_1508_ = lean_uint64_shift_left(v___x_1506_, v___x_1507_);
v___x_1509_ = lean_uint64_lor(v___x_1502_, v___x_1508_);
v___x_1510_ = ((size_t)3ULL);
v___x_1511_ = lean_usize_add(v_pos_1486_, v___x_1510_);
v___x_1512_ = lean_byte_array_uget(v___y_1479_, v___x_1511_);
v___x_1513_ = lean_uint8_to_uint64(v___x_1512_);
v___x_1514_ = 24ULL;
v___x_1515_ = lean_uint64_shift_left(v___x_1513_, v___x_1514_);
v___x_1516_ = lean_uint64_lor(v___x_1509_, v___x_1515_);
v___y_1388_ = v___y_1476_;
v___y_1389_ = v___x_1516_;
goto v___jp_1387_;
}
}
}
}
v___jp_1517_:
{
lean_object* v_offset_1524_; lean_object* v___x_1525_; lean_object* v___x_1526_; uint8_t v___x_1527_; 
v_offset_1524_ = lean_nat_mul(v___y_1520_, v___y_1523_);
lean_dec(v___y_1520_);
v___x_1525_ = lean_nat_add(v_offset_1524_, v___y_1523_);
v___x_1526_ = lean_byte_array_size(v___y_1521_);
v___x_1527_ = lean_nat_dec_le(v___x_1525_, v___x_1526_);
if (v___x_1527_ == 0)
{
lean_dec(v___x_1525_);
v___y_1475_ = v_offset_1524_;
v___y_1476_ = v___y_1518_;
v___y_1477_ = v___y_1519_;
v___y_1478_ = v___y_1522_;
v___y_1479_ = v___y_1521_;
v___y_1480_ = v___x_1527_;
goto v___jp_1474_;
}
else
{
size_t v___x_1528_; lean_object* v___x_1529_; uint8_t v___x_1530_; 
v___x_1528_ = lean_usize_of_nat(v___x_1525_);
v___x_1529_ = lean_usize_to_nat(v___x_1528_);
v___x_1530_ = lean_nat_dec_eq(v___x_1529_, v___x_1525_);
lean_dec(v___x_1525_);
lean_dec(v___x_1529_);
v___y_1475_ = v_offset_1524_;
v___y_1476_ = v___y_1518_;
v___y_1477_ = v___y_1519_;
v___y_1478_ = v___y_1522_;
v___y_1479_ = v___y_1521_;
v___y_1480_ = v___x_1530_;
goto v___jp_1474_;
}
}
v___jp_1531_:
{
lean_object* v_arity_1534_; uint8_t v_width_1535_; lean_object* v_exponents_1536_; lean_object* v___x_1537_; lean_object* v___x_1538_; uint8_t v___x_1539_; 
v_arity_1534_ = lean_ctor_get(v_table_1367_, 0);
v_width_1535_ = lean_ctor_get_uint8(v_table_1367_, sizeof(void*)*9);
v_exponents_1536_ = lean_ctor_get(v_table_1367_, 1);
v___x_1537_ = lean_nat_mul(v_b_1368_, v_arity_1534_);
v___x_1538_ = lean_nat_add(v___x_1537_, v___y_1532_);
lean_dec(v___y_1532_);
lean_dec(v___x_1537_);
v___x_1539_ = 0;
switch(v_width_1535_)
{
case 0:
{
v___y_1518_ = v___y_1533_;
v___y_1519_ = v_width_1535_;
v___y_1520_ = v___x_1538_;
v___y_1521_ = v_exponents_1536_;
v___y_1522_ = v___x_1539_;
v___y_1523_ = v___x_1384_;
goto v___jp_1517_;
}
case 1:
{
lean_object* v___x_1540_; 
v___x_1540_ = lean_unsigned_to_nat(2u);
v___y_1518_ = v___y_1533_;
v___y_1519_ = v_width_1535_;
v___y_1520_ = v___x_1538_;
v___y_1521_ = v_exponents_1536_;
v___y_1522_ = v___x_1539_;
v___y_1523_ = v___x_1540_;
goto v___jp_1517_;
}
default: 
{
lean_object* v___x_1541_; 
v___x_1541_ = lean_unsigned_to_nat(4u);
v___y_1518_ = v___y_1533_;
v___y_1519_ = v_width_1535_;
v___y_1520_ = v___x_1538_;
v___y_1521_ = v_exponents_1536_;
v___y_1522_ = v___x_1539_;
v___y_1523_ = v___x_1541_;
goto v___jp_1517_;
}
}
}
v___jp_1542_:
{
uint64_t v___x_1546_; uint64_t v___x_1547_; uint64_t v___x_1548_; uint64_t v___x_1549_; 
v___x_1546_ = lean_uint8_to_uint64(v___y_1545_);
v___x_1547_ = 24ULL;
v___x_1548_ = lean_uint64_shift_left(v___x_1546_, v___x_1547_);
v___x_1549_ = lean_uint64_lor(v___y_1544_, v___x_1548_);
v___y_1532_ = v___y_1543_;
v___y_1533_ = v___x_1549_;
goto v___jp_1531_;
}
v___jp_1550_:
{
uint64_t v___x_1557_; uint64_t v___x_1558_; uint64_t v___x_1559_; uint64_t v___x_1560_; lean_object* v___x_1561_; lean_object* v___x_1562_; uint8_t v___x_1563_; 
v___x_1557_ = lean_uint8_to_uint64(v___y_1556_);
v___x_1558_ = 16ULL;
v___x_1559_ = lean_uint64_shift_left(v___x_1557_, v___x_1558_);
v___x_1560_ = lean_uint64_lor(v___y_1555_, v___x_1559_);
v___x_1561_ = lean_unsigned_to_nat(3u);
v___x_1562_ = lean_nat_add(v___y_1553_, v___x_1561_);
lean_dec(v___y_1553_);
v___x_1563_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1551_, v___x_1562_);
if (v___x_1563_ == 0)
{
lean_object* v___x_1564_; lean_object* v___x_1565_; uint8_t v___x_1566_; 
lean_dec(v___x_1562_);
v___x_1564_ = lean_box(v___y_1554_);
v___x_1565_ = l_outOfBounds___redArg(v___x_1564_);
lean_dec(v___x_1564_);
v___x_1566_ = lean_unbox(v___x_1565_);
lean_dec(v___x_1565_);
v___y_1543_ = v___y_1552_;
v___y_1544_ = v___x_1560_;
v___y_1545_ = v___x_1566_;
goto v___jp_1542_;
}
else
{
uint8_t v___x_1567_; 
v___x_1567_ = lean_byte_array_fget(v___y_1551_, v___x_1562_);
lean_dec(v___x_1562_);
v___y_1543_ = v___y_1552_;
v___y_1544_ = v___x_1560_;
v___y_1545_ = v___x_1567_;
goto v___jp_1542_;
}
}
v___jp_1568_:
{
uint64_t v___x_1575_; uint64_t v___x_1576_; uint64_t v___x_1577_; uint64_t v___x_1578_; lean_object* v___x_1579_; lean_object* v___x_1580_; uint8_t v___x_1581_; 
v___x_1575_ = lean_uint8_to_uint64(v___y_1574_);
v___x_1576_ = 8ULL;
v___x_1577_ = lean_uint64_shift_left(v___x_1575_, v___x_1576_);
v___x_1578_ = lean_uint64_lor(v___y_1573_, v___x_1577_);
v___x_1579_ = lean_unsigned_to_nat(2u);
v___x_1580_ = lean_nat_add(v___y_1571_, v___x_1579_);
v___x_1581_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1570_, v___x_1580_);
if (v___x_1581_ == 0)
{
lean_object* v___x_1582_; lean_object* v___x_1583_; uint8_t v___x_1584_; 
lean_dec(v___x_1580_);
v___x_1582_ = lean_box(v___y_1572_);
v___x_1583_ = l_outOfBounds___redArg(v___x_1582_);
lean_dec(v___x_1582_);
v___x_1584_ = lean_unbox(v___x_1583_);
lean_dec(v___x_1583_);
v___y_1551_ = v___y_1570_;
v___y_1552_ = v___y_1569_;
v___y_1553_ = v___y_1571_;
v___y_1554_ = v___y_1572_;
v___y_1555_ = v___x_1578_;
v___y_1556_ = v___x_1584_;
goto v___jp_1550_;
}
else
{
uint8_t v___x_1585_; 
v___x_1585_ = lean_byte_array_fget(v___y_1570_, v___x_1580_);
lean_dec(v___x_1580_);
v___y_1551_ = v___y_1570_;
v___y_1552_ = v___y_1569_;
v___y_1553_ = v___y_1571_;
v___y_1554_ = v___y_1572_;
v___y_1555_ = v___x_1578_;
v___y_1556_ = v___x_1585_;
goto v___jp_1550_;
}
}
v___jp_1586_:
{
uint64_t v___x_1590_; uint64_t v___x_1591_; uint64_t v___x_1592_; uint64_t v___x_1593_; 
v___x_1590_ = lean_uint8_to_uint64(v___y_1589_);
v___x_1591_ = 8ULL;
v___x_1592_ = lean_uint64_shift_left(v___x_1590_, v___x_1591_);
v___x_1593_ = lean_uint64_lor(v___y_1588_, v___x_1592_);
v___y_1532_ = v___y_1587_;
v___y_1533_ = v___x_1593_;
goto v___jp_1531_;
}
v___jp_1594_:
{
uint64_t v_a_1601_; 
v_a_1601_ = lean_uint8_to_uint64(v___y_1600_);
switch(v___y_1598_)
{
case 0:
{
lean_dec(v___y_1597_);
v___y_1532_ = v___y_1596_;
v___y_1533_ = v_a_1601_;
goto v___jp_1531_;
}
case 1:
{
lean_object* v___x_1602_; uint8_t v___x_1603_; 
v___x_1602_ = lean_nat_add(v___y_1597_, v___x_1384_);
lean_dec(v___y_1597_);
v___x_1603_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1595_, v___x_1602_);
if (v___x_1603_ == 0)
{
lean_object* v___x_1604_; lean_object* v___x_1605_; uint8_t v___x_1606_; 
lean_dec(v___x_1602_);
v___x_1604_ = lean_box(v___y_1599_);
v___x_1605_ = l_outOfBounds___redArg(v___x_1604_);
lean_dec(v___x_1604_);
v___x_1606_ = lean_unbox(v___x_1605_);
lean_dec(v___x_1605_);
v___y_1587_ = v___y_1596_;
v___y_1588_ = v_a_1601_;
v___y_1589_ = v___x_1606_;
goto v___jp_1586_;
}
else
{
uint8_t v___x_1607_; 
v___x_1607_ = lean_byte_array_fget(v___y_1595_, v___x_1602_);
lean_dec(v___x_1602_);
v___y_1587_ = v___y_1596_;
v___y_1588_ = v_a_1601_;
v___y_1589_ = v___x_1607_;
goto v___jp_1586_;
}
}
default: 
{
lean_object* v___x_1608_; uint8_t v___x_1609_; 
v___x_1608_ = lean_nat_add(v___y_1597_, v___x_1384_);
v___x_1609_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1595_, v___x_1608_);
if (v___x_1609_ == 0)
{
lean_object* v___x_1610_; lean_object* v___x_1611_; uint8_t v___x_1612_; 
lean_dec(v___x_1608_);
v___x_1610_ = lean_box(v___y_1599_);
v___x_1611_ = l_outOfBounds___redArg(v___x_1610_);
lean_dec(v___x_1610_);
v___x_1612_ = lean_unbox(v___x_1611_);
lean_dec(v___x_1611_);
v___y_1569_ = v___y_1596_;
v___y_1570_ = v___y_1595_;
v___y_1571_ = v___y_1597_;
v___y_1572_ = v___y_1599_;
v___y_1573_ = v_a_1601_;
v___y_1574_ = v___x_1612_;
goto v___jp_1568_;
}
else
{
uint8_t v___x_1613_; 
v___x_1613_ = lean_byte_array_fget(v___y_1595_, v___x_1608_);
lean_dec(v___x_1608_);
v___y_1569_ = v___y_1596_;
v___y_1570_ = v___y_1595_;
v___y_1571_ = v___y_1597_;
v___y_1572_ = v___y_1599_;
v___y_1573_ = v_a_1601_;
v___y_1574_ = v___x_1613_;
goto v___jp_1568_;
}
}
}
}
v___jp_1614_:
{
if (v___y_1620_ == 0)
{
uint8_t v___x_1621_; 
v___x_1621_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_1616_, v___y_1617_);
if (v___x_1621_ == 0)
{
lean_object* v___x_1622_; lean_object* v___x_1623_; uint8_t v___x_1624_; 
v___x_1622_ = lean_box(v___y_1619_);
v___x_1623_ = l_outOfBounds___redArg(v___x_1622_);
lean_dec(v___x_1622_);
v___x_1624_ = lean_unbox(v___x_1623_);
lean_dec(v___x_1623_);
v___y_1595_ = v___y_1616_;
v___y_1596_ = v___y_1615_;
v___y_1597_ = v___y_1617_;
v___y_1598_ = v___y_1618_;
v___y_1599_ = v___y_1619_;
v___y_1600_ = v___x_1624_;
goto v___jp_1594_;
}
else
{
uint8_t v___x_1625_; 
v___x_1625_ = lean_byte_array_fget(v___y_1616_, v___y_1617_);
v___y_1595_ = v___y_1616_;
v___y_1596_ = v___y_1615_;
v___y_1597_ = v___y_1617_;
v___y_1598_ = v___y_1618_;
v___y_1599_ = v___y_1619_;
v___y_1600_ = v___x_1625_;
goto v___jp_1594_;
}
}
else
{
size_t v_pos_1626_; uint8_t v___x_1627_; uint64_t v_a_1628_; 
v_pos_1626_ = lean_usize_of_nat(v___y_1617_);
lean_dec(v___y_1617_);
v___x_1627_ = lean_byte_array_uget(v___y_1616_, v_pos_1626_);
v_a_1628_ = lean_uint8_to_uint64(v___x_1627_);
switch(v___y_1618_)
{
case 0:
{
v___y_1532_ = v___y_1615_;
v___y_1533_ = v_a_1628_;
goto v___jp_1531_;
}
case 1:
{
size_t v___x_1629_; size_t v___x_1630_; uint8_t v___x_1631_; uint64_t v___x_1632_; uint64_t v___x_1633_; uint64_t v___x_1634_; uint64_t v___x_1635_; 
v___x_1629_ = ((size_t)1ULL);
v___x_1630_ = lean_usize_add(v_pos_1626_, v___x_1629_);
v___x_1631_ = lean_byte_array_uget(v___y_1616_, v___x_1630_);
v___x_1632_ = lean_uint8_to_uint64(v___x_1631_);
v___x_1633_ = 8ULL;
v___x_1634_ = lean_uint64_shift_left(v___x_1632_, v___x_1633_);
v___x_1635_ = lean_uint64_lor(v_a_1628_, v___x_1634_);
v___y_1532_ = v___y_1615_;
v___y_1533_ = v___x_1635_;
goto v___jp_1531_;
}
default: 
{
size_t v___x_1636_; size_t v___x_1637_; uint8_t v___x_1638_; uint64_t v___x_1639_; uint64_t v___x_1640_; uint64_t v___x_1641_; uint64_t v___x_1642_; size_t v___x_1643_; size_t v___x_1644_; uint8_t v___x_1645_; uint64_t v___x_1646_; uint64_t v___x_1647_; uint64_t v___x_1648_; uint64_t v___x_1649_; size_t v___x_1650_; size_t v___x_1651_; uint8_t v___x_1652_; uint64_t v___x_1653_; uint64_t v___x_1654_; uint64_t v___x_1655_; uint64_t v___x_1656_; 
v___x_1636_ = ((size_t)1ULL);
v___x_1637_ = lean_usize_add(v_pos_1626_, v___x_1636_);
v___x_1638_ = lean_byte_array_uget(v___y_1616_, v___x_1637_);
v___x_1639_ = lean_uint8_to_uint64(v___x_1638_);
v___x_1640_ = 8ULL;
v___x_1641_ = lean_uint64_shift_left(v___x_1639_, v___x_1640_);
v___x_1642_ = lean_uint64_lor(v_a_1628_, v___x_1641_);
v___x_1643_ = ((size_t)2ULL);
v___x_1644_ = lean_usize_add(v_pos_1626_, v___x_1643_);
v___x_1645_ = lean_byte_array_uget(v___y_1616_, v___x_1644_);
v___x_1646_ = lean_uint8_to_uint64(v___x_1645_);
v___x_1647_ = 16ULL;
v___x_1648_ = lean_uint64_shift_left(v___x_1646_, v___x_1647_);
v___x_1649_ = lean_uint64_lor(v___x_1642_, v___x_1648_);
v___x_1650_ = ((size_t)3ULL);
v___x_1651_ = lean_usize_add(v_pos_1626_, v___x_1650_);
v___x_1652_ = lean_byte_array_uget(v___y_1616_, v___x_1651_);
v___x_1653_ = lean_uint8_to_uint64(v___x_1652_);
v___x_1654_ = 24ULL;
v___x_1655_ = lean_uint64_shift_left(v___x_1653_, v___x_1654_);
v___x_1656_ = lean_uint64_lor(v___x_1649_, v___x_1655_);
v___y_1532_ = v___y_1615_;
v___y_1533_ = v___x_1656_;
goto v___jp_1531_;
}
}
}
}
v___jp_1657_:
{
lean_object* v_offset_1664_; lean_object* v___x_1665_; lean_object* v___x_1666_; uint8_t v___x_1667_; 
v_offset_1664_ = lean_nat_mul(v___y_1662_, v___y_1663_);
lean_dec(v___y_1662_);
v___x_1665_ = lean_nat_add(v_offset_1664_, v___y_1663_);
v___x_1666_ = lean_byte_array_size(v___y_1659_);
v___x_1667_ = lean_nat_dec_le(v___x_1665_, v___x_1666_);
if (v___x_1667_ == 0)
{
lean_dec(v___x_1665_);
v___y_1615_ = v___y_1658_;
v___y_1616_ = v___y_1659_;
v___y_1617_ = v_offset_1664_;
v___y_1618_ = v___y_1660_;
v___y_1619_ = v___y_1661_;
v___y_1620_ = v___x_1667_;
goto v___jp_1614_;
}
else
{
size_t v___x_1668_; lean_object* v___x_1669_; uint8_t v___x_1670_; 
v___x_1668_ = lean_usize_of_nat(v___x_1665_);
v___x_1669_ = lean_usize_to_nat(v___x_1668_);
v___x_1670_ = lean_nat_dec_eq(v___x_1669_, v___x_1665_);
lean_dec(v___x_1665_);
lean_dec(v___x_1669_);
v___y_1615_ = v___y_1658_;
v___y_1616_ = v___y_1659_;
v___y_1617_ = v_offset_1664_;
v___y_1618_ = v___y_1660_;
v___y_1619_ = v___y_1661_;
v___y_1620_ = v___x_1670_;
goto v___jp_1614_;
}
}
v___jp_1671_:
{
lean_object* v_arity_1673_; uint8_t v_width_1674_; lean_object* v_exponents_1675_; lean_object* v___x_1676_; lean_object* v___x_1677_; uint8_t v___x_1678_; 
v_arity_1673_ = lean_ctor_get(v_table_1367_, 0);
v_width_1674_ = lean_ctor_get_uint8(v_table_1367_, sizeof(void*)*9);
v_exponents_1675_ = lean_ctor_get(v_table_1367_, 1);
v___x_1676_ = lean_nat_mul(v_a_1369_, v_arity_1673_);
v___x_1677_ = lean_nat_add(v___x_1676_, v___y_1672_);
lean_dec(v___x_1676_);
v___x_1678_ = 0;
switch(v_width_1674_)
{
case 0:
{
v___y_1658_ = v___y_1672_;
v___y_1659_ = v_exponents_1675_;
v___y_1660_ = v_width_1674_;
v___y_1661_ = v___x_1678_;
v___y_1662_ = v___x_1677_;
v___y_1663_ = v___x_1384_;
goto v___jp_1657_;
}
case 1:
{
lean_object* v___x_1679_; 
v___x_1679_ = lean_unsigned_to_nat(2u);
v___y_1658_ = v___y_1672_;
v___y_1659_ = v_exponents_1675_;
v___y_1660_ = v_width_1674_;
v___y_1661_ = v___x_1678_;
v___y_1662_ = v___x_1677_;
v___y_1663_ = v___x_1679_;
goto v___jp_1657_;
}
default: 
{
lean_object* v___x_1680_; 
v___x_1680_ = lean_unsigned_to_nat(4u);
v___y_1658_ = v___y_1672_;
v___y_1659_ = v_exponents_1675_;
v___y_1660_ = v_width_1674_;
v___y_1661_ = v___x_1678_;
v___y_1662_ = v___x_1677_;
v___y_1663_ = v___x_1680_;
goto v___jp_1657_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg___boxed(lean_object* v_order_1683_, lean_object* v_table_1684_, lean_object* v_b_1685_, lean_object* v_a_1686_, lean_object* v___x_1687_, lean_object* v_range_1688_, lean_object* v_b_1689_, lean_object* v_i_1690_){
_start:
{
uint8_t v_order_boxed_1691_; lean_object* v_res_1692_; 
v_order_boxed_1691_ = lean_unbox(v_order_1683_);
v_res_1692_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg(v_order_boxed_1691_, v_table_1684_, v_b_1685_, v_a_1686_, v___x_1687_, v_range_1688_, v_b_1689_, v_i_1690_);
lean_dec_ref(v_b_1689_);
lean_dec_ref(v_range_1688_);
lean_dec(v___x_1687_);
lean_dec(v_a_1686_);
lean_dec(v_b_1685_);
lean_dec_ref(v_table_1684_);
return v_res_1692_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_MonomialTable_compare___closed__0(void){
_start:
{
uint8_t v___x_1693_; lean_object* v___x_1694_; 
v___x_1693_ = 1;
v___x_1694_ = l_Ordering_ctorIdx(v___x_1693_);
return v___x_1694_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_MonomialTable_compare(lean_object* v_table_1695_, uint8_t v_order_1696_, lean_object* v_a_1697_, lean_object* v_b_1698_){
_start:
{
uint8_t v___y_1711_; uint8_t v___x_1715_; 
v___x_1715_ = lean_nat_dec_eq(v_a_1697_, v_b_1698_);
if (v___x_1715_ == 0)
{
uint8_t v___x_1716_; uint8_t v___x_1717_; 
v___x_1716_ = 0;
v___x_1717_ = lp_Hex_Hex_Groebner_instBEqTermOrder_beq(v_order_1696_, v___x_1716_);
if (v___x_1717_ == 0)
{
lean_object* v_metadata_1718_; lean_object* v___x_1719_; lean_object* v___x_1720_; uint64_t v___x_1721_; lean_object* v___x_1722_; lean_object* v___x_1723_; uint64_t v___x_1724_; lean_object* v___x_1725_; uint8_t v___x_1726_; 
v_metadata_1718_ = lean_ctor_get(v_table_1695_, 2);
v___x_1719_ = lean_unsigned_to_nat(3u);
v___x_1720_ = lean_nat_mul(v___x_1719_, v_a_1697_);
v___x_1721_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1718_, v___x_1720_);
lean_dec(v___x_1720_);
v___x_1722_ = lean_uint64_to_nat(v___x_1721_);
v___x_1723_ = lean_nat_mul(v___x_1719_, v_b_1698_);
v___x_1724_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_metaWord(v_metadata_1718_, v___x_1723_);
lean_dec(v___x_1723_);
v___x_1725_ = lean_uint64_to_nat(v___x_1724_);
v___x_1726_ = lean_nat_dec_lt(v___x_1722_, v___x_1725_);
if (v___x_1726_ == 0)
{
uint8_t v___x_1727_; 
v___x_1727_ = lean_nat_dec_eq(v___x_1722_, v___x_1725_);
lean_dec(v___x_1725_);
lean_dec(v___x_1722_);
if (v___x_1727_ == 0)
{
uint8_t v___x_1728_; 
v___x_1728_ = 2;
v___y_1711_ = v___x_1728_;
goto v___jp_1710_;
}
else
{
uint8_t v___x_1729_; 
v___x_1729_ = 1;
v___y_1711_ = v___x_1729_;
goto v___jp_1710_;
}
}
else
{
uint8_t v___x_1730_; 
lean_dec(v___x_1725_);
lean_dec(v___x_1722_);
v___x_1730_ = 0;
v___y_1711_ = v___x_1730_;
goto v___jp_1710_;
}
}
else
{
goto v___jp_1699_;
}
}
else
{
uint8_t v___x_1731_; 
v___x_1731_ = 1;
return v___x_1731_;
}
v___jp_1699_:
{
lean_object* v_arity_1700_; lean_object* v___x_1701_; lean_object* v___x_1702_; lean_object* v___x_1703_; lean_object* v___x_1704_; lean_object* v___x_1705_; lean_object* v_fst_1706_; 
v_arity_1700_ = lean_ctor_get(v_table_1695_, 0);
v___x_1701_ = lean_unsigned_to_nat(0u);
v___x_1702_ = lean_unsigned_to_nat(1u);
lean_inc(v_arity_1700_);
v___x_1703_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1703_, 0, v___x_1701_);
lean_ctor_set(v___x_1703_, 1, v_arity_1700_);
lean_ctor_set(v___x_1703_, 2, v___x_1702_);
v___x_1704_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg___closed__0));
v___x_1705_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg(v_order_1696_, v_table_1695_, v_b_1698_, v_a_1697_, v_arity_1700_, v___x_1703_, v___x_1704_, v___x_1701_);
lean_dec_ref_known(v___x_1703_, 3);
v_fst_1706_ = lean_ctor_get(v___x_1705_, 0);
lean_inc(v_fst_1706_);
lean_dec_ref(v___x_1705_);
if (lean_obj_tag(v_fst_1706_) == 0)
{
uint8_t v___x_1707_; 
v___x_1707_ = 1;
return v___x_1707_;
}
else
{
lean_object* v_val_1708_; uint8_t v___x_1709_; 
v_val_1708_ = lean_ctor_get(v_fst_1706_, 0);
lean_inc(v_val_1708_);
lean_dec_ref_known(v_fst_1706_, 1);
v___x_1709_ = lean_unbox(v_val_1708_);
lean_dec(v_val_1708_);
return v___x_1709_;
}
}
v___jp_1710_:
{
lean_object* v___x_1712_; lean_object* v___x_1713_; uint8_t v___x_1714_; 
v___x_1712_ = l_Ordering_ctorIdx(v___y_1711_);
v___x_1713_ = lean_obj_once(&lp_Hex_Hex_Groebner_MonomialTable_compare___closed__0, &lp_Hex_Hex_Groebner_MonomialTable_compare___closed__0_once, _init_lp_Hex_Hex_Groebner_MonomialTable_compare___closed__0);
v___x_1714_ = lean_nat_dec_eq(v___x_1712_, v___x_1713_);
lean_dec(v___x_1712_);
if (v___x_1714_ == 0)
{
return v___y_1711_;
}
else
{
goto v___jp_1699_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_compare___boxed(lean_object* v_table_1732_, lean_object* v_order_1733_, lean_object* v_a_1734_, lean_object* v_b_1735_){
_start:
{
uint8_t v_order_boxed_1736_; uint8_t v_res_1737_; lean_object* v_r_1738_; 
v_order_boxed_1736_ = lean_unbox(v_order_1733_);
v_res_1737_ = lp_Hex_Hex_Groebner_MonomialTable_compare(v_table_1732_, v_order_boxed_1736_, v_a_1734_, v_b_1735_);
lean_dec(v_b_1735_);
lean_dec(v_a_1734_);
lean_dec_ref(v_table_1732_);
v_r_1738_ = lean_box(v_res_1737_);
return v_r_1738_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0(uint8_t v_order_1739_, lean_object* v_table_1740_, lean_object* v_b_1741_, lean_object* v_a_1742_, lean_object* v___x_1743_, lean_object* v_range_1744_, lean_object* v_b_1745_, lean_object* v_i_1746_, lean_object* v_hs_1747_, lean_object* v_hl_1748_){
_start:
{
lean_object* v___x_1749_; 
v___x_1749_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___redArg(v_order_1739_, v_table_1740_, v_b_1741_, v_a_1742_, v___x_1743_, v_range_1744_, v_b_1745_, v_i_1746_);
return v___x_1749_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0___boxed(lean_object* v_order_1750_, lean_object* v_table_1751_, lean_object* v_b_1752_, lean_object* v_a_1753_, lean_object* v___x_1754_, lean_object* v_range_1755_, lean_object* v_b_1756_, lean_object* v_i_1757_, lean_object* v_hs_1758_, lean_object* v_hl_1759_){
_start:
{
uint8_t v_order_boxed_1760_; lean_object* v_res_1761_; 
v_order_boxed_1760_ = lean_unbox(v_order_1750_);
v_res_1761_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_compare_spec__0(v_order_boxed_1760_, v_table_1751_, v_b_1752_, v_a_1753_, v___x_1754_, v_range_1755_, v_b_1756_, v_i_1757_, v_hs_1758_, v_hl_1759_);
lean_dec_ref(v_b_1756_);
lean_dec_ref(v_range_1755_);
lean_dec(v___x_1754_);
lean_dec(v_a_1753_);
lean_dec(v_b_1752_);
lean_dec_ref(v_table_1751_);
return v_res_1761_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg(lean_object* v_values_1764_, lean_object* v_table_1765_, lean_object* v_id_1766_, lean_object* v_range_1767_, lean_object* v_b_1768_, lean_object* v_i_1769_){
_start:
{
lean_object* v_stop_1770_; lean_object* v_step_1771_; uint8_t v___x_1772_; 
v_stop_1770_ = lean_ctor_get(v_range_1767_, 1);
v_step_1771_ = lean_ctor_get(v_range_1767_, 2);
v___x_1772_ = lean_nat_dec_lt(v_i_1769_, v_stop_1770_);
if (v___x_1772_ == 0)
{
lean_dec(v_i_1769_);
lean_inc_ref(v_b_1768_);
return v_b_1768_;
}
else
{
lean_object* v_arity_1773_; uint8_t v_width_1774_; lean_object* v_exponents_1775_; lean_object* v___x_1776_; lean_object* v___x_1777_; uint64_t v___y_1779_; uint64_t v___y_1790_; uint8_t v___y_1791_; uint64_t v___y_1797_; uint8_t v___y_1798_; lean_object* v___x_1803_; lean_object* v___x_1804_; uint8_t v___x_1805_; lean_object* v___y_1807_; uint64_t v___y_1808_; uint8_t v___y_1809_; lean_object* v___y_1822_; uint64_t v___y_1823_; uint8_t v___y_1824_; lean_object* v___y_1837_; uint8_t v___y_1838_; lean_object* v___y_1855_; uint8_t v___y_1856_; lean_object* v___y_1894_; 
v_arity_1773_ = lean_ctor_get(v_table_1765_, 0);
v_width_1774_ = lean_ctor_get_uint8(v_table_1765_, sizeof(void*)*9);
v_exponents_1775_ = lean_ctor_get(v_table_1765_, 1);
v___x_1776_ = lean_box(0);
v___x_1777_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg___closed__0));
v___x_1803_ = lean_nat_mul(v_id_1766_, v_arity_1773_);
v___x_1804_ = lean_nat_add(v___x_1803_, v_i_1769_);
lean_dec(v___x_1803_);
v___x_1805_ = 0;
switch(v_width_1774_)
{
case 0:
{
lean_object* v___x_1902_; 
v___x_1902_ = lean_unsigned_to_nat(1u);
v___y_1894_ = v___x_1902_;
goto v___jp_1893_;
}
case 1:
{
lean_object* v___x_1903_; 
v___x_1903_ = lean_unsigned_to_nat(2u);
v___y_1894_ = v___x_1903_;
goto v___jp_1893_;
}
default: 
{
lean_object* v___x_1904_; 
v___x_1904_ = lean_unsigned_to_nat(4u);
v___y_1894_ = v___x_1904_;
goto v___jp_1893_;
}
}
v___jp_1778_:
{
lean_object* v___x_1780_; lean_object* v___x_1781_; uint64_t v___x_1782_; uint8_t v___x_1783_; 
v___x_1780_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg___boxed__const__1));
v___x_1781_ = lean_array_get_borrowed(v___x_1780_, v_values_1764_, v_i_1769_);
v___x_1782_ = lean_unbox_uint64(v___x_1781_);
v___x_1783_ = lean_uint64_dec_eq(v___y_1779_, v___x_1782_);
if (v___x_1783_ == 0)
{
lean_object* v___x_1784_; lean_object* v___x_1785_; lean_object* v___x_1786_; 
lean_dec(v_i_1769_);
v___x_1784_ = lean_box(v___x_1783_);
v___x_1785_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1785_, 0, v___x_1784_);
v___x_1786_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1786_, 0, v___x_1785_);
lean_ctor_set(v___x_1786_, 1, v___x_1776_);
return v___x_1786_;
}
else
{
lean_object* v___x_1787_; 
v___x_1787_ = lean_nat_add(v_i_1769_, v_step_1771_);
lean_dec(v_i_1769_);
v_b_1768_ = v___x_1777_;
v_i_1769_ = v___x_1787_;
goto _start;
}
}
v___jp_1789_:
{
uint64_t v___x_1792_; uint64_t v___x_1793_; uint64_t v___x_1794_; uint64_t v___x_1795_; 
v___x_1792_ = lean_uint8_to_uint64(v___y_1791_);
v___x_1793_ = 24ULL;
v___x_1794_ = lean_uint64_shift_left(v___x_1792_, v___x_1793_);
v___x_1795_ = lean_uint64_lor(v___y_1790_, v___x_1794_);
v___y_1779_ = v___x_1795_;
goto v___jp_1778_;
}
v___jp_1796_:
{
uint64_t v___x_1799_; uint64_t v___x_1800_; uint64_t v___x_1801_; uint64_t v___x_1802_; 
v___x_1799_ = lean_uint8_to_uint64(v___y_1798_);
v___x_1800_ = 8ULL;
v___x_1801_ = lean_uint64_shift_left(v___x_1799_, v___x_1800_);
v___x_1802_ = lean_uint64_lor(v___y_1797_, v___x_1801_);
v___y_1779_ = v___x_1802_;
goto v___jp_1778_;
}
v___jp_1806_:
{
uint64_t v___x_1810_; uint64_t v___x_1811_; uint64_t v___x_1812_; uint64_t v___x_1813_; lean_object* v___x_1814_; lean_object* v___x_1815_; uint8_t v___x_1816_; 
v___x_1810_ = lean_uint8_to_uint64(v___y_1809_);
v___x_1811_ = 16ULL;
v___x_1812_ = lean_uint64_shift_left(v___x_1810_, v___x_1811_);
v___x_1813_ = lean_uint64_lor(v___y_1808_, v___x_1812_);
v___x_1814_ = lean_unsigned_to_nat(3u);
v___x_1815_ = lean_nat_add(v___y_1807_, v___x_1814_);
lean_dec(v___y_1807_);
v___x_1816_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1775_, v___x_1815_);
if (v___x_1816_ == 0)
{
lean_object* v___x_1817_; lean_object* v___x_1818_; uint8_t v___x_1819_; 
lean_dec(v___x_1815_);
v___x_1817_ = lean_box(v___x_1805_);
v___x_1818_ = l_outOfBounds___redArg(v___x_1817_);
lean_dec(v___x_1817_);
v___x_1819_ = lean_unbox(v___x_1818_);
lean_dec(v___x_1818_);
v___y_1790_ = v___x_1813_;
v___y_1791_ = v___x_1819_;
goto v___jp_1789_;
}
else
{
uint8_t v___x_1820_; 
v___x_1820_ = lean_byte_array_fget(v_exponents_1775_, v___x_1815_);
lean_dec(v___x_1815_);
v___y_1790_ = v___x_1813_;
v___y_1791_ = v___x_1820_;
goto v___jp_1789_;
}
}
v___jp_1821_:
{
uint64_t v___x_1825_; uint64_t v___x_1826_; uint64_t v___x_1827_; uint64_t v___x_1828_; lean_object* v___x_1829_; lean_object* v___x_1830_; uint8_t v___x_1831_; 
v___x_1825_ = lean_uint8_to_uint64(v___y_1824_);
v___x_1826_ = 8ULL;
v___x_1827_ = lean_uint64_shift_left(v___x_1825_, v___x_1826_);
v___x_1828_ = lean_uint64_lor(v___y_1823_, v___x_1827_);
v___x_1829_ = lean_unsigned_to_nat(2u);
v___x_1830_ = lean_nat_add(v___y_1822_, v___x_1829_);
v___x_1831_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1775_, v___x_1830_);
if (v___x_1831_ == 0)
{
lean_object* v___x_1832_; lean_object* v___x_1833_; uint8_t v___x_1834_; 
lean_dec(v___x_1830_);
v___x_1832_ = lean_box(v___x_1805_);
v___x_1833_ = l_outOfBounds___redArg(v___x_1832_);
lean_dec(v___x_1832_);
v___x_1834_ = lean_unbox(v___x_1833_);
lean_dec(v___x_1833_);
v___y_1807_ = v___y_1822_;
v___y_1808_ = v___x_1828_;
v___y_1809_ = v___x_1834_;
goto v___jp_1806_;
}
else
{
uint8_t v___x_1835_; 
v___x_1835_ = lean_byte_array_fget(v_exponents_1775_, v___x_1830_);
lean_dec(v___x_1830_);
v___y_1807_ = v___y_1822_;
v___y_1808_ = v___x_1828_;
v___y_1809_ = v___x_1835_;
goto v___jp_1806_;
}
}
v___jp_1836_:
{
uint64_t v_a_1839_; 
v_a_1839_ = lean_uint8_to_uint64(v___y_1838_);
switch(v_width_1774_)
{
case 0:
{
lean_dec(v___y_1837_);
v___y_1779_ = v_a_1839_;
goto v___jp_1778_;
}
case 1:
{
lean_object* v___x_1840_; lean_object* v___x_1841_; uint8_t v___x_1842_; 
v___x_1840_ = lean_unsigned_to_nat(1u);
v___x_1841_ = lean_nat_add(v___y_1837_, v___x_1840_);
lean_dec(v___y_1837_);
v___x_1842_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1775_, v___x_1841_);
if (v___x_1842_ == 0)
{
lean_object* v___x_1843_; lean_object* v___x_1844_; uint8_t v___x_1845_; 
lean_dec(v___x_1841_);
v___x_1843_ = lean_box(v___x_1805_);
v___x_1844_ = l_outOfBounds___redArg(v___x_1843_);
lean_dec(v___x_1843_);
v___x_1845_ = lean_unbox(v___x_1844_);
lean_dec(v___x_1844_);
v___y_1797_ = v_a_1839_;
v___y_1798_ = v___x_1845_;
goto v___jp_1796_;
}
else
{
uint8_t v___x_1846_; 
v___x_1846_ = lean_byte_array_fget(v_exponents_1775_, v___x_1841_);
lean_dec(v___x_1841_);
v___y_1797_ = v_a_1839_;
v___y_1798_ = v___x_1846_;
goto v___jp_1796_;
}
}
default: 
{
lean_object* v___x_1847_; lean_object* v___x_1848_; uint8_t v___x_1849_; 
v___x_1847_ = lean_unsigned_to_nat(1u);
v___x_1848_ = lean_nat_add(v___y_1837_, v___x_1847_);
v___x_1849_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1775_, v___x_1848_);
if (v___x_1849_ == 0)
{
lean_object* v___x_1850_; lean_object* v___x_1851_; uint8_t v___x_1852_; 
lean_dec(v___x_1848_);
v___x_1850_ = lean_box(v___x_1805_);
v___x_1851_ = l_outOfBounds___redArg(v___x_1850_);
lean_dec(v___x_1850_);
v___x_1852_ = lean_unbox(v___x_1851_);
lean_dec(v___x_1851_);
v___y_1822_ = v___y_1837_;
v___y_1823_ = v_a_1839_;
v___y_1824_ = v___x_1852_;
goto v___jp_1821_;
}
else
{
uint8_t v___x_1853_; 
v___x_1853_ = lean_byte_array_fget(v_exponents_1775_, v___x_1848_);
lean_dec(v___x_1848_);
v___y_1822_ = v___y_1837_;
v___y_1823_ = v_a_1839_;
v___y_1824_ = v___x_1853_;
goto v___jp_1821_;
}
}
}
}
v___jp_1854_:
{
if (v___y_1856_ == 0)
{
uint8_t v___x_1857_; 
v___x_1857_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1775_, v___y_1855_);
if (v___x_1857_ == 0)
{
lean_object* v___x_1858_; lean_object* v___x_1859_; uint8_t v___x_1860_; 
v___x_1858_ = lean_box(v___x_1805_);
v___x_1859_ = l_outOfBounds___redArg(v___x_1858_);
lean_dec(v___x_1858_);
v___x_1860_ = lean_unbox(v___x_1859_);
lean_dec(v___x_1859_);
v___y_1837_ = v___y_1855_;
v___y_1838_ = v___x_1860_;
goto v___jp_1836_;
}
else
{
uint8_t v___x_1861_; 
v___x_1861_ = lean_byte_array_fget(v_exponents_1775_, v___y_1855_);
v___y_1837_ = v___y_1855_;
v___y_1838_ = v___x_1861_;
goto v___jp_1836_;
}
}
else
{
size_t v_pos_1862_; uint8_t v___x_1863_; uint64_t v_a_1864_; 
v_pos_1862_ = lean_usize_of_nat(v___y_1855_);
lean_dec(v___y_1855_);
v___x_1863_ = lean_byte_array_uget(v_exponents_1775_, v_pos_1862_);
v_a_1864_ = lean_uint8_to_uint64(v___x_1863_);
switch(v_width_1774_)
{
case 0:
{
v___y_1779_ = v_a_1864_;
goto v___jp_1778_;
}
case 1:
{
size_t v___x_1865_; size_t v___x_1866_; uint8_t v___x_1867_; uint64_t v___x_1868_; uint64_t v___x_1869_; uint64_t v___x_1870_; uint64_t v___x_1871_; 
v___x_1865_ = ((size_t)1ULL);
v___x_1866_ = lean_usize_add(v_pos_1862_, v___x_1865_);
v___x_1867_ = lean_byte_array_uget(v_exponents_1775_, v___x_1866_);
v___x_1868_ = lean_uint8_to_uint64(v___x_1867_);
v___x_1869_ = 8ULL;
v___x_1870_ = lean_uint64_shift_left(v___x_1868_, v___x_1869_);
v___x_1871_ = lean_uint64_lor(v_a_1864_, v___x_1870_);
v___y_1779_ = v___x_1871_;
goto v___jp_1778_;
}
default: 
{
size_t v___x_1872_; size_t v___x_1873_; uint8_t v___x_1874_; uint64_t v___x_1875_; uint64_t v___x_1876_; uint64_t v___x_1877_; uint64_t v___x_1878_; size_t v___x_1879_; size_t v___x_1880_; uint8_t v___x_1881_; uint64_t v___x_1882_; uint64_t v___x_1883_; uint64_t v___x_1884_; uint64_t v___x_1885_; size_t v___x_1886_; size_t v___x_1887_; uint8_t v___x_1888_; uint64_t v___x_1889_; uint64_t v___x_1890_; uint64_t v___x_1891_; uint64_t v___x_1892_; 
v___x_1872_ = ((size_t)1ULL);
v___x_1873_ = lean_usize_add(v_pos_1862_, v___x_1872_);
v___x_1874_ = lean_byte_array_uget(v_exponents_1775_, v___x_1873_);
v___x_1875_ = lean_uint8_to_uint64(v___x_1874_);
v___x_1876_ = 8ULL;
v___x_1877_ = lean_uint64_shift_left(v___x_1875_, v___x_1876_);
v___x_1878_ = lean_uint64_lor(v_a_1864_, v___x_1877_);
v___x_1879_ = ((size_t)2ULL);
v___x_1880_ = lean_usize_add(v_pos_1862_, v___x_1879_);
v___x_1881_ = lean_byte_array_uget(v_exponents_1775_, v___x_1880_);
v___x_1882_ = lean_uint8_to_uint64(v___x_1881_);
v___x_1883_ = 16ULL;
v___x_1884_ = lean_uint64_shift_left(v___x_1882_, v___x_1883_);
v___x_1885_ = lean_uint64_lor(v___x_1878_, v___x_1884_);
v___x_1886_ = ((size_t)3ULL);
v___x_1887_ = lean_usize_add(v_pos_1862_, v___x_1886_);
v___x_1888_ = lean_byte_array_uget(v_exponents_1775_, v___x_1887_);
v___x_1889_ = lean_uint8_to_uint64(v___x_1888_);
v___x_1890_ = 24ULL;
v___x_1891_ = lean_uint64_shift_left(v___x_1889_, v___x_1890_);
v___x_1892_ = lean_uint64_lor(v___x_1885_, v___x_1891_);
v___y_1779_ = v___x_1892_;
goto v___jp_1778_;
}
}
}
}
v___jp_1893_:
{
lean_object* v_offset_1895_; lean_object* v___x_1896_; lean_object* v___x_1897_; uint8_t v___x_1898_; 
v_offset_1895_ = lean_nat_mul(v___x_1804_, v___y_1894_);
lean_dec(v___x_1804_);
v___x_1896_ = lean_nat_add(v_offset_1895_, v___y_1894_);
v___x_1897_ = lean_byte_array_size(v_exponents_1775_);
v___x_1898_ = lean_nat_dec_le(v___x_1896_, v___x_1897_);
if (v___x_1898_ == 0)
{
lean_dec(v___x_1896_);
v___y_1855_ = v_offset_1895_;
v___y_1856_ = v___x_1898_;
goto v___jp_1854_;
}
else
{
size_t v___x_1899_; lean_object* v___x_1900_; uint8_t v___x_1901_; 
v___x_1899_ = lean_usize_of_nat(v___x_1896_);
v___x_1900_ = lean_usize_to_nat(v___x_1899_);
v___x_1901_ = lean_nat_dec_eq(v___x_1900_, v___x_1896_);
lean_dec(v___x_1896_);
lean_dec(v___x_1900_);
v___y_1855_ = v_offset_1895_;
v___y_1856_ = v___x_1901_;
goto v___jp_1854_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg___boxed(lean_object* v_values_1905_, lean_object* v_table_1906_, lean_object* v_id_1907_, lean_object* v_range_1908_, lean_object* v_b_1909_, lean_object* v_i_1910_){
_start:
{
lean_object* v_res_1911_; 
v_res_1911_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg(v_values_1905_, v_table_1906_, v_id_1907_, v_range_1908_, v_b_1909_, v_i_1910_);
lean_dec_ref(v_b_1909_);
lean_dec_ref(v_range_1908_);
lean_dec(v_id_1907_);
lean_dec_ref(v_table_1906_);
lean_dec_ref(v_values_1905_);
return v_res_1911_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal(lean_object* v_table_1912_, lean_object* v_id_1913_, lean_object* v_values_1914_){
_start:
{
lean_object* v_arity_1915_; lean_object* v___x_1916_; lean_object* v___x_1917_; lean_object* v___x_1918_; lean_object* v___x_1919_; lean_object* v___x_1920_; lean_object* v_fst_1921_; 
v_arity_1915_ = lean_ctor_get(v_table_1912_, 0);
v___x_1916_ = lean_unsigned_to_nat(0u);
v___x_1917_ = lean_unsigned_to_nat(1u);
lean_inc(v_arity_1915_);
v___x_1918_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1918_, 0, v___x_1916_);
lean_ctor_set(v___x_1918_, 1, v_arity_1915_);
lean_ctor_set(v___x_1918_, 2, v___x_1917_);
v___x_1919_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_divides_spec__0___redArg___closed__0));
v___x_1920_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg(v_values_1914_, v_table_1912_, v_id_1913_, v___x_1918_, v___x_1919_, v___x_1916_);
lean_dec_ref_known(v___x_1918_, 3);
v_fst_1921_ = lean_ctor_get(v___x_1920_, 0);
lean_inc(v_fst_1921_);
lean_dec_ref(v___x_1920_);
if (lean_obj_tag(v_fst_1921_) == 0)
{
uint8_t v___x_1922_; 
v___x_1922_ = 1;
return v___x_1922_;
}
else
{
lean_object* v_val_1923_; uint8_t v___x_1924_; 
v_val_1923_ = lean_ctor_get(v_fst_1921_, 0);
lean_inc(v_val_1923_);
lean_dec_ref_known(v_fst_1921_, 1);
v___x_1924_ = lean_unbox(v_val_1923_);
lean_dec(v_val_1923_);
return v___x_1924_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal___boxed(lean_object* v_table_1925_, lean_object* v_id_1926_, lean_object* v_values_1927_){
_start:
{
uint8_t v_res_1928_; lean_object* v_r_1929_; 
v_res_1928_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal(v_table_1925_, v_id_1926_, v_values_1927_);
lean_dec_ref(v_values_1927_);
lean_dec(v_id_1926_);
lean_dec_ref(v_table_1925_);
v_r_1929_ = lean_box(v_res_1928_);
return v_r_1929_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0(lean_object* v_values_1930_, lean_object* v_table_1931_, lean_object* v_id_1932_, lean_object* v_range_1933_, lean_object* v_b_1934_, lean_object* v_i_1935_, lean_object* v_hs_1936_, lean_object* v_hl_1937_){
_start:
{
lean_object* v___x_1938_; 
v___x_1938_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg(v_values_1930_, v_table_1931_, v_id_1932_, v_range_1933_, v_b_1934_, v_i_1935_);
return v___x_1938_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___boxed(lean_object* v_values_1939_, lean_object* v_table_1940_, lean_object* v_id_1941_, lean_object* v_range_1942_, lean_object* v_b_1943_, lean_object* v_i_1944_, lean_object* v_hs_1945_, lean_object* v_hl_1946_){
_start:
{
lean_object* v_res_1947_; 
v_res_1947_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0(v_values_1939_, v_table_1940_, v_id_1941_, v_range_1942_, v_b_1943_, v_i_1944_, v_hs_1945_, v_hl_1946_);
lean_dec_ref(v_b_1943_);
lean_dec_ref(v_range_1942_);
lean_dec(v_id_1941_);
lean_dec_ref(v_table_1940_);
lean_dec_ref(v_values_1939_);
return v_res_1947_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___redArg(uint8_t v_width_1948_, lean_object* v_table_1949_, lean_object* v_a_1950_, lean_object* v_range_1951_, lean_object* v_b_1952_, lean_object* v_i_1953_){
_start:
{
lean_object* v_stop_1954_; lean_object* v_step_1955_; lean_object* v_a_1957_; uint64_t v___y_1961_; uint64_t v___y_1981_; uint8_t v___y_1982_; uint64_t v___y_1988_; uint8_t v___y_1989_; uint8_t v___x_1994_; 
v_stop_1954_ = lean_ctor_get(v_range_1951_, 1);
v_step_1955_ = lean_ctor_get(v_range_1951_, 2);
v___x_1994_ = lean_nat_dec_lt(v_i_1953_, v_stop_1954_);
if (v___x_1994_ == 0)
{
lean_dec(v_i_1953_);
return v_b_1952_;
}
else
{
lean_object* v_arity_1995_; uint8_t v_width_1996_; lean_object* v_exponents_1997_; lean_object* v___x_1998_; lean_object* v___x_1999_; uint8_t v___x_2000_; lean_object* v___y_2002_; uint64_t v___y_2003_; uint8_t v___y_2004_; lean_object* v___y_2017_; uint64_t v___y_2018_; uint8_t v___y_2019_; lean_object* v___y_2032_; uint8_t v___y_2033_; lean_object* v___y_2050_; uint8_t v___y_2051_; lean_object* v___y_2089_; 
v_arity_1995_ = lean_ctor_get(v_table_1949_, 0);
v_width_1996_ = lean_ctor_get_uint8(v_table_1949_, sizeof(void*)*9);
v_exponents_1997_ = lean_ctor_get(v_table_1949_, 1);
v___x_1998_ = lean_nat_mul(v_a_1950_, v_arity_1995_);
v___x_1999_ = lean_nat_add(v___x_1998_, v_i_1953_);
lean_dec(v___x_1998_);
v___x_2000_ = 0;
switch(v_width_1996_)
{
case 0:
{
lean_object* v___x_2097_; 
v___x_2097_ = lean_unsigned_to_nat(1u);
v___y_2089_ = v___x_2097_;
goto v___jp_2088_;
}
case 1:
{
lean_object* v___x_2098_; 
v___x_2098_ = lean_unsigned_to_nat(2u);
v___y_2089_ = v___x_2098_;
goto v___jp_2088_;
}
default: 
{
lean_object* v___x_2099_; 
v___x_2099_ = lean_unsigned_to_nat(4u);
v___y_2089_ = v___x_2099_;
goto v___jp_2088_;
}
}
v___jp_2001_:
{
uint64_t v___x_2005_; uint64_t v___x_2006_; uint64_t v___x_2007_; uint64_t v___x_2008_; lean_object* v___x_2009_; lean_object* v___x_2010_; uint8_t v___x_2011_; 
v___x_2005_ = lean_uint8_to_uint64(v___y_2004_);
v___x_2006_ = 16ULL;
v___x_2007_ = lean_uint64_shift_left(v___x_2005_, v___x_2006_);
v___x_2008_ = lean_uint64_lor(v___y_2003_, v___x_2007_);
v___x_2009_ = lean_unsigned_to_nat(3u);
v___x_2010_ = lean_nat_add(v___y_2002_, v___x_2009_);
lean_dec(v___y_2002_);
v___x_2011_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1997_, v___x_2010_);
if (v___x_2011_ == 0)
{
lean_object* v___x_2012_; lean_object* v___x_2013_; uint8_t v___x_2014_; 
lean_dec(v___x_2010_);
v___x_2012_ = lean_box(v___x_2000_);
v___x_2013_ = l_outOfBounds___redArg(v___x_2012_);
lean_dec(v___x_2012_);
v___x_2014_ = lean_unbox(v___x_2013_);
lean_dec(v___x_2013_);
v___y_1981_ = v___x_2008_;
v___y_1982_ = v___x_2014_;
goto v___jp_1980_;
}
else
{
uint8_t v___x_2015_; 
v___x_2015_ = lean_byte_array_fget(v_exponents_1997_, v___x_2010_);
lean_dec(v___x_2010_);
v___y_1981_ = v___x_2008_;
v___y_1982_ = v___x_2015_;
goto v___jp_1980_;
}
}
v___jp_2016_:
{
uint64_t v___x_2020_; uint64_t v___x_2021_; uint64_t v___x_2022_; uint64_t v___x_2023_; lean_object* v___x_2024_; lean_object* v___x_2025_; uint8_t v___x_2026_; 
v___x_2020_ = lean_uint8_to_uint64(v___y_2019_);
v___x_2021_ = 8ULL;
v___x_2022_ = lean_uint64_shift_left(v___x_2020_, v___x_2021_);
v___x_2023_ = lean_uint64_lor(v___y_2018_, v___x_2022_);
v___x_2024_ = lean_unsigned_to_nat(2u);
v___x_2025_ = lean_nat_add(v___y_2017_, v___x_2024_);
v___x_2026_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1997_, v___x_2025_);
if (v___x_2026_ == 0)
{
lean_object* v___x_2027_; lean_object* v___x_2028_; uint8_t v___x_2029_; 
lean_dec(v___x_2025_);
v___x_2027_ = lean_box(v___x_2000_);
v___x_2028_ = l_outOfBounds___redArg(v___x_2027_);
lean_dec(v___x_2027_);
v___x_2029_ = lean_unbox(v___x_2028_);
lean_dec(v___x_2028_);
v___y_2002_ = v___y_2017_;
v___y_2003_ = v___x_2023_;
v___y_2004_ = v___x_2029_;
goto v___jp_2001_;
}
else
{
uint8_t v___x_2030_; 
v___x_2030_ = lean_byte_array_fget(v_exponents_1997_, v___x_2025_);
lean_dec(v___x_2025_);
v___y_2002_ = v___y_2017_;
v___y_2003_ = v___x_2023_;
v___y_2004_ = v___x_2030_;
goto v___jp_2001_;
}
}
v___jp_2031_:
{
uint64_t v_a_2034_; 
v_a_2034_ = lean_uint8_to_uint64(v___y_2033_);
switch(v_width_1996_)
{
case 0:
{
lean_dec(v___y_2032_);
v___y_1961_ = v_a_2034_;
goto v___jp_1960_;
}
case 1:
{
lean_object* v___x_2035_; lean_object* v___x_2036_; uint8_t v___x_2037_; 
v___x_2035_ = lean_unsigned_to_nat(1u);
v___x_2036_ = lean_nat_add(v___y_2032_, v___x_2035_);
lean_dec(v___y_2032_);
v___x_2037_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1997_, v___x_2036_);
if (v___x_2037_ == 0)
{
lean_object* v___x_2038_; lean_object* v___x_2039_; uint8_t v___x_2040_; 
lean_dec(v___x_2036_);
v___x_2038_ = lean_box(v___x_2000_);
v___x_2039_ = l_outOfBounds___redArg(v___x_2038_);
lean_dec(v___x_2038_);
v___x_2040_ = lean_unbox(v___x_2039_);
lean_dec(v___x_2039_);
v___y_1988_ = v_a_2034_;
v___y_1989_ = v___x_2040_;
goto v___jp_1987_;
}
else
{
uint8_t v___x_2041_; 
v___x_2041_ = lean_byte_array_fget(v_exponents_1997_, v___x_2036_);
lean_dec(v___x_2036_);
v___y_1988_ = v_a_2034_;
v___y_1989_ = v___x_2041_;
goto v___jp_1987_;
}
}
default: 
{
lean_object* v___x_2042_; lean_object* v___x_2043_; uint8_t v___x_2044_; 
v___x_2042_ = lean_unsigned_to_nat(1u);
v___x_2043_ = lean_nat_add(v___y_2032_, v___x_2042_);
v___x_2044_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1997_, v___x_2043_);
if (v___x_2044_ == 0)
{
lean_object* v___x_2045_; lean_object* v___x_2046_; uint8_t v___x_2047_; 
lean_dec(v___x_2043_);
v___x_2045_ = lean_box(v___x_2000_);
v___x_2046_ = l_outOfBounds___redArg(v___x_2045_);
lean_dec(v___x_2045_);
v___x_2047_ = lean_unbox(v___x_2046_);
lean_dec(v___x_2046_);
v___y_2017_ = v___y_2032_;
v___y_2018_ = v_a_2034_;
v___y_2019_ = v___x_2047_;
goto v___jp_2016_;
}
else
{
uint8_t v___x_2048_; 
v___x_2048_ = lean_byte_array_fget(v_exponents_1997_, v___x_2043_);
lean_dec(v___x_2043_);
v___y_2017_ = v___y_2032_;
v___y_2018_ = v_a_2034_;
v___y_2019_ = v___x_2048_;
goto v___jp_2016_;
}
}
}
}
v___jp_2049_:
{
if (v___y_2051_ == 0)
{
uint8_t v___x_2052_; 
v___x_2052_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_1997_, v___y_2050_);
if (v___x_2052_ == 0)
{
lean_object* v___x_2053_; lean_object* v___x_2054_; uint8_t v___x_2055_; 
v___x_2053_ = lean_box(v___x_2000_);
v___x_2054_ = l_outOfBounds___redArg(v___x_2053_);
lean_dec(v___x_2053_);
v___x_2055_ = lean_unbox(v___x_2054_);
lean_dec(v___x_2054_);
v___y_2032_ = v___y_2050_;
v___y_2033_ = v___x_2055_;
goto v___jp_2031_;
}
else
{
uint8_t v___x_2056_; 
v___x_2056_ = lean_byte_array_fget(v_exponents_1997_, v___y_2050_);
v___y_2032_ = v___y_2050_;
v___y_2033_ = v___x_2056_;
goto v___jp_2031_;
}
}
else
{
size_t v_pos_2057_; uint8_t v___x_2058_; uint64_t v_a_2059_; 
v_pos_2057_ = lean_usize_of_nat(v___y_2050_);
lean_dec(v___y_2050_);
v___x_2058_ = lean_byte_array_uget(v_exponents_1997_, v_pos_2057_);
v_a_2059_ = lean_uint8_to_uint64(v___x_2058_);
switch(v_width_1996_)
{
case 0:
{
v___y_1961_ = v_a_2059_;
goto v___jp_1960_;
}
case 1:
{
size_t v___x_2060_; size_t v___x_2061_; uint8_t v___x_2062_; uint64_t v___x_2063_; uint64_t v___x_2064_; uint64_t v___x_2065_; uint64_t v___x_2066_; 
v___x_2060_ = ((size_t)1ULL);
v___x_2061_ = lean_usize_add(v_pos_2057_, v___x_2060_);
v___x_2062_ = lean_byte_array_uget(v_exponents_1997_, v___x_2061_);
v___x_2063_ = lean_uint8_to_uint64(v___x_2062_);
v___x_2064_ = 8ULL;
v___x_2065_ = lean_uint64_shift_left(v___x_2063_, v___x_2064_);
v___x_2066_ = lean_uint64_lor(v_a_2059_, v___x_2065_);
v___y_1961_ = v___x_2066_;
goto v___jp_1960_;
}
default: 
{
size_t v___x_2067_; size_t v___x_2068_; uint8_t v___x_2069_; uint64_t v___x_2070_; uint64_t v___x_2071_; uint64_t v___x_2072_; uint64_t v___x_2073_; size_t v___x_2074_; size_t v___x_2075_; uint8_t v___x_2076_; uint64_t v___x_2077_; uint64_t v___x_2078_; uint64_t v___x_2079_; uint64_t v___x_2080_; size_t v___x_2081_; size_t v___x_2082_; uint8_t v___x_2083_; uint64_t v___x_2084_; uint64_t v___x_2085_; uint64_t v___x_2086_; uint64_t v___x_2087_; 
v___x_2067_ = ((size_t)1ULL);
v___x_2068_ = lean_usize_add(v_pos_2057_, v___x_2067_);
v___x_2069_ = lean_byte_array_uget(v_exponents_1997_, v___x_2068_);
v___x_2070_ = lean_uint8_to_uint64(v___x_2069_);
v___x_2071_ = 8ULL;
v___x_2072_ = lean_uint64_shift_left(v___x_2070_, v___x_2071_);
v___x_2073_ = lean_uint64_lor(v_a_2059_, v___x_2072_);
v___x_2074_ = ((size_t)2ULL);
v___x_2075_ = lean_usize_add(v_pos_2057_, v___x_2074_);
v___x_2076_ = lean_byte_array_uget(v_exponents_1997_, v___x_2075_);
v___x_2077_ = lean_uint8_to_uint64(v___x_2076_);
v___x_2078_ = 16ULL;
v___x_2079_ = lean_uint64_shift_left(v___x_2077_, v___x_2078_);
v___x_2080_ = lean_uint64_lor(v___x_2073_, v___x_2079_);
v___x_2081_ = ((size_t)3ULL);
v___x_2082_ = lean_usize_add(v_pos_2057_, v___x_2081_);
v___x_2083_ = lean_byte_array_uget(v_exponents_1997_, v___x_2082_);
v___x_2084_ = lean_uint8_to_uint64(v___x_2083_);
v___x_2085_ = 24ULL;
v___x_2086_ = lean_uint64_shift_left(v___x_2084_, v___x_2085_);
v___x_2087_ = lean_uint64_lor(v___x_2080_, v___x_2086_);
v___y_1961_ = v___x_2087_;
goto v___jp_1960_;
}
}
}
}
v___jp_2088_:
{
lean_object* v_offset_2090_; lean_object* v___x_2091_; lean_object* v___x_2092_; uint8_t v___x_2093_; 
v_offset_2090_ = lean_nat_mul(v___x_1999_, v___y_2089_);
lean_dec(v___x_1999_);
v___x_2091_ = lean_nat_add(v_offset_2090_, v___y_2089_);
v___x_2092_ = lean_byte_array_size(v_exponents_1997_);
v___x_2093_ = lean_nat_dec_le(v___x_2091_, v___x_2092_);
if (v___x_2093_ == 0)
{
lean_dec(v___x_2091_);
v___y_2050_ = v_offset_2090_;
v___y_2051_ = v___x_2093_;
goto v___jp_2049_;
}
else
{
size_t v___x_2094_; lean_object* v___x_2095_; uint8_t v___x_2096_; 
v___x_2094_ = lean_usize_of_nat(v___x_2091_);
v___x_2095_ = lean_usize_to_nat(v___x_2094_);
v___x_2096_ = lean_nat_dec_eq(v___x_2095_, v___x_2091_);
lean_dec(v___x_2091_);
lean_dec(v___x_2095_);
v___y_2050_ = v_offset_2090_;
v___y_2051_ = v___x_2096_;
goto v___jp_2049_;
}
}
}
v___jp_1956_:
{
lean_object* v___x_1958_; 
v___x_1958_ = lean_nat_add(v_i_1953_, v_step_1955_);
lean_dec(v_i_1953_);
v_b_1952_ = v_a_1957_;
v_i_1953_ = v___x_1958_;
goto _start;
}
v___jp_1960_:
{
uint8_t v___x_1962_; lean_object* v_data_1963_; 
v___x_1962_ = lean_uint64_to_uint8(v___y_1961_);
v_data_1963_ = lean_byte_array_push(v_b_1952_, v___x_1962_);
switch(v_width_1948_)
{
case 0:
{
v_a_1957_ = v_data_1963_;
goto v___jp_1956_;
}
case 1:
{
uint64_t v___x_1964_; uint64_t v___x_1965_; uint8_t v___x_1966_; lean_object* v___x_1967_; 
v___x_1964_ = 8ULL;
v___x_1965_ = lean_uint64_shift_right(v___y_1961_, v___x_1964_);
v___x_1966_ = lean_uint64_to_uint8(v___x_1965_);
v___x_1967_ = lean_byte_array_push(v_data_1963_, v___x_1966_);
v_a_1957_ = v___x_1967_;
goto v___jp_1956_;
}
default: 
{
uint64_t v___x_1968_; uint64_t v___x_1969_; uint8_t v___x_1970_; lean_object* v___x_1971_; uint64_t v___x_1972_; uint64_t v___x_1973_; uint8_t v___x_1974_; lean_object* v___x_1975_; uint64_t v___x_1976_; uint64_t v___x_1977_; uint8_t v___x_1978_; lean_object* v___x_1979_; 
v___x_1968_ = 8ULL;
v___x_1969_ = lean_uint64_shift_right(v___y_1961_, v___x_1968_);
v___x_1970_ = lean_uint64_to_uint8(v___x_1969_);
v___x_1971_ = lean_byte_array_push(v_data_1963_, v___x_1970_);
v___x_1972_ = 16ULL;
v___x_1973_ = lean_uint64_shift_right(v___y_1961_, v___x_1972_);
v___x_1974_ = lean_uint64_to_uint8(v___x_1973_);
v___x_1975_ = lean_byte_array_push(v___x_1971_, v___x_1974_);
v___x_1976_ = 24ULL;
v___x_1977_ = lean_uint64_shift_right(v___y_1961_, v___x_1976_);
v___x_1978_ = lean_uint64_to_uint8(v___x_1977_);
v___x_1979_ = lean_byte_array_push(v___x_1975_, v___x_1978_);
v_a_1957_ = v___x_1979_;
goto v___jp_1956_;
}
}
}
v___jp_1980_:
{
uint64_t v___x_1983_; uint64_t v___x_1984_; uint64_t v___x_1985_; uint64_t v___x_1986_; 
v___x_1983_ = lean_uint8_to_uint64(v___y_1982_);
v___x_1984_ = 24ULL;
v___x_1985_ = lean_uint64_shift_left(v___x_1983_, v___x_1984_);
v___x_1986_ = lean_uint64_lor(v___y_1981_, v___x_1985_);
v___y_1961_ = v___x_1986_;
goto v___jp_1960_;
}
v___jp_1987_:
{
uint64_t v___x_1990_; uint64_t v___x_1991_; uint64_t v___x_1992_; uint64_t v___x_1993_; 
v___x_1990_ = lean_uint8_to_uint64(v___y_1989_);
v___x_1991_ = 8ULL;
v___x_1992_ = lean_uint64_shift_left(v___x_1990_, v___x_1991_);
v___x_1993_ = lean_uint64_lor(v___y_1988_, v___x_1992_);
v___y_1961_ = v___x_1993_;
goto v___jp_1960_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___redArg___boxed(lean_object* v_width_2100_, lean_object* v_table_2101_, lean_object* v_a_2102_, lean_object* v_range_2103_, lean_object* v_b_2104_, lean_object* v_i_2105_){
_start:
{
uint8_t v_width_boxed_2106_; lean_object* v_res_2107_; 
v_width_boxed_2106_ = lean_unbox(v_width_2100_);
v_res_2107_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___redArg(v_width_boxed_2106_, v_table_2101_, v_a_2102_, v_range_2103_, v_b_2104_, v_i_2105_);
lean_dec_ref(v_range_2103_);
lean_dec(v_a_2102_);
lean_dec_ref(v_table_2101_);
return v_res_2107_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1___redArg(lean_object* v___x_2108_, uint8_t v_width_2109_, lean_object* v_table_2110_, lean_object* v_range_2111_, lean_object* v_b_2112_, lean_object* v_i_2113_){
_start:
{
lean_object* v_stop_2114_; lean_object* v_step_2115_; uint8_t v___x_2116_; 
v_stop_2114_ = lean_ctor_get(v_range_2111_, 1);
v_step_2115_ = lean_ctor_get(v_range_2111_, 2);
v___x_2116_ = lean_nat_dec_lt(v_i_2113_, v_stop_2114_);
if (v___x_2116_ == 0)
{
lean_dec(v_i_2113_);
lean_dec(v___x_2108_);
return v_b_2112_;
}
else
{
lean_object* v___x_2117_; lean_object* v___x_2118_; lean_object* v___x_2119_; lean_object* v___x_2120_; lean_object* v___x_2121_; 
v___x_2117_ = lean_unsigned_to_nat(0u);
v___x_2118_ = lean_unsigned_to_nat(1u);
lean_inc(v___x_2108_);
v___x_2119_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2119_, 0, v___x_2117_);
lean_ctor_set(v___x_2119_, 1, v___x_2108_);
lean_ctor_set(v___x_2119_, 2, v___x_2118_);
v___x_2120_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___redArg(v_width_2109_, v_table_2110_, v_i_2113_, v___x_2119_, v_b_2112_, v___x_2117_);
lean_dec_ref_known(v___x_2119_, 3);
v___x_2121_ = lean_nat_add(v_i_2113_, v_step_2115_);
lean_dec(v_i_2113_);
v_b_2112_ = v___x_2120_;
v_i_2113_ = v___x_2121_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1___redArg___boxed(lean_object* v___x_2123_, lean_object* v_width_2124_, lean_object* v_table_2125_, lean_object* v_range_2126_, lean_object* v_b_2127_, lean_object* v_i_2128_){
_start:
{
uint8_t v_width_boxed_2129_; lean_object* v_res_2130_; 
v_width_boxed_2129_ = lean_unbox(v_width_2124_);
v_res_2130_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1___redArg(v___x_2123_, v_width_boxed_2129_, v_table_2125_, v_range_2126_, v_b_2127_, v_i_2128_);
lean_dec_ref(v_range_2126_);
lean_dec_ref(v_table_2125_);
return v_res_2130_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1___redArg(uint8_t v_width_2131_, lean_object* v_table_2132_, lean_object* v___x_2133_, lean_object* v_range_2134_, lean_object* v_b_2135_, lean_object* v_i_2136_){
_start:
{
lean_object* v_stop_2137_; lean_object* v_step_2138_; uint8_t v___x_2139_; 
v_stop_2137_ = lean_ctor_get(v_range_2134_, 1);
v_step_2138_ = lean_ctor_get(v_range_2134_, 2);
v___x_2139_ = lean_nat_dec_lt(v_i_2136_, v_stop_2137_);
if (v___x_2139_ == 0)
{
lean_dec(v___x_2133_);
return v_b_2135_;
}
else
{
lean_object* v___x_2140_; lean_object* v___x_2141_; lean_object* v___x_2142_; lean_object* v___x_2143_; lean_object* v___x_2144_; lean_object* v___x_2145_; 
v___x_2140_ = lean_unsigned_to_nat(0u);
v___x_2141_ = lean_unsigned_to_nat(1u);
lean_inc(v___x_2133_);
v___x_2142_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2142_, 0, v___x_2140_);
lean_ctor_set(v___x_2142_, 1, v___x_2133_);
lean_ctor_set(v___x_2142_, 2, v___x_2141_);
v___x_2143_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___redArg(v_width_2131_, v_table_2132_, v_i_2136_, v___x_2142_, v_b_2135_, v___x_2140_);
lean_dec_ref_known(v___x_2142_, 3);
v___x_2144_ = lean_nat_add(v_i_2136_, v_step_2138_);
v___x_2145_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1___redArg(v___x_2133_, v_width_2131_, v_table_2132_, v_range_2134_, v___x_2143_, v___x_2144_);
return v___x_2145_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1___redArg___boxed(lean_object* v_width_2146_, lean_object* v_table_2147_, lean_object* v___x_2148_, lean_object* v_range_2149_, lean_object* v_b_2150_, lean_object* v_i_2151_){
_start:
{
uint8_t v_width_boxed_2152_; lean_object* v_res_2153_; 
v_width_boxed_2152_ = lean_unbox(v_width_2146_);
v_res_2153_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1___redArg(v_width_boxed_2152_, v_table_2147_, v___x_2148_, v_range_2149_, v_b_2150_, v_i_2151_);
lean_dec(v_i_2151_);
lean_dec_ref(v_range_2149_);
lean_dec_ref(v_table_2147_);
return v_res_2153_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen(lean_object* v_table_2154_, uint8_t v_width_2155_){
_start:
{
lean_object* v_arity_2156_; lean_object* v_metadata_2157_; lean_object* v_count_2158_; lean_object* v_workspace_2159_; lean_object* v_buckets_2160_; lean_object* v_products_2161_; lean_object* v_hashBits_2162_; lean_object* v_work_2163_; lean_object* v___x_2164_; lean_object* v___y_2166_; 
v_arity_2156_ = lean_ctor_get(v_table_2154_, 0);
lean_inc(v_arity_2156_);
v_metadata_2157_ = lean_ctor_get(v_table_2154_, 2);
lean_inc_ref(v_metadata_2157_);
v_count_2158_ = lean_ctor_get(v_table_2154_, 3);
lean_inc(v_count_2158_);
v_workspace_2159_ = lean_ctor_get(v_table_2154_, 4);
lean_inc_ref(v_workspace_2159_);
v_buckets_2160_ = lean_ctor_get(v_table_2154_, 5);
lean_inc_ref(v_buckets_2160_);
v_products_2161_ = lean_ctor_get(v_table_2154_, 6);
lean_inc_ref(v_products_2161_);
v_hashBits_2162_ = lean_ctor_get(v_table_2154_, 7);
lean_inc(v_hashBits_2162_);
v_work_2163_ = lean_ctor_get(v_table_2154_, 8);
lean_inc(v_work_2163_);
v___x_2164_ = lean_nat_mul(v_count_2158_, v_arity_2156_);
switch(v_width_2155_)
{
case 0:
{
lean_object* v___x_2189_; 
v___x_2189_ = lean_unsigned_to_nat(1u);
v___y_2166_ = v___x_2189_;
goto v___jp_2165_;
}
case 1:
{
lean_object* v___x_2190_; 
v___x_2190_ = lean_unsigned_to_nat(2u);
v___y_2166_ = v___x_2190_;
goto v___jp_2165_;
}
default: 
{
lean_object* v___x_2191_; 
v___x_2191_ = lean_unsigned_to_nat(4u);
v___y_2166_ = v___x_2191_;
goto v___jp_2165_;
}
}
v___jp_2165_:
{
lean_object* v___x_2167_; lean_object* v_exponents_2168_; lean_object* v___x_2169_; lean_object* v___x_2170_; lean_object* v___x_2171_; lean_object* v___x_2172_; lean_object* v___x_2174_; uint8_t v_isShared_2175_; uint8_t v_isSharedCheck_2179_; 
v___x_2167_ = lean_nat_mul(v___x_2164_, v___y_2166_);
lean_dec(v___x_2164_);
v_exponents_2168_ = lean_mk_empty_byte_array(v___x_2167_);
lean_dec(v___x_2167_);
v___x_2169_ = lean_unsigned_to_nat(0u);
v___x_2170_ = lean_unsigned_to_nat(1u);
lean_inc(v_count_2158_);
v___x_2171_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2171_, 0, v___x_2169_);
lean_ctor_set(v___x_2171_, 1, v_count_2158_);
lean_ctor_set(v___x_2171_, 2, v___x_2170_);
lean_inc(v_arity_2156_);
v___x_2172_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1___redArg(v_width_2155_, v_table_2154_, v_arity_2156_, v___x_2171_, v_exponents_2168_, v___x_2169_);
lean_dec_ref_known(v___x_2171_, 3);
v_isSharedCheck_2179_ = !lean_is_exclusive(v_table_2154_);
if (v_isSharedCheck_2179_ == 0)
{
lean_object* v_unused_2180_; lean_object* v_unused_2181_; lean_object* v_unused_2182_; lean_object* v_unused_2183_; lean_object* v_unused_2184_; lean_object* v_unused_2185_; lean_object* v_unused_2186_; lean_object* v_unused_2187_; lean_object* v_unused_2188_; 
v_unused_2180_ = lean_ctor_get(v_table_2154_, 8);
lean_dec(v_unused_2180_);
v_unused_2181_ = lean_ctor_get(v_table_2154_, 7);
lean_dec(v_unused_2181_);
v_unused_2182_ = lean_ctor_get(v_table_2154_, 6);
lean_dec(v_unused_2182_);
v_unused_2183_ = lean_ctor_get(v_table_2154_, 5);
lean_dec(v_unused_2183_);
v_unused_2184_ = lean_ctor_get(v_table_2154_, 4);
lean_dec(v_unused_2184_);
v_unused_2185_ = lean_ctor_get(v_table_2154_, 3);
lean_dec(v_unused_2185_);
v_unused_2186_ = lean_ctor_get(v_table_2154_, 2);
lean_dec(v_unused_2186_);
v_unused_2187_ = lean_ctor_get(v_table_2154_, 1);
lean_dec(v_unused_2187_);
v_unused_2188_ = lean_ctor_get(v_table_2154_, 0);
lean_dec(v_unused_2188_);
v___x_2174_ = v_table_2154_;
v_isShared_2175_ = v_isSharedCheck_2179_;
goto v_resetjp_2173_;
}
else
{
lean_dec(v_table_2154_);
v___x_2174_ = lean_box(0);
v_isShared_2175_ = v_isSharedCheck_2179_;
goto v_resetjp_2173_;
}
v_resetjp_2173_:
{
lean_object* v___x_2177_; 
if (v_isShared_2175_ == 0)
{
lean_ctor_set(v___x_2174_, 1, v___x_2172_);
v___x_2177_ = v___x_2174_;
goto v_reusejp_2176_;
}
else
{
lean_object* v_reuseFailAlloc_2178_; 
v_reuseFailAlloc_2178_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_reuseFailAlloc_2178_, 0, v_arity_2156_);
lean_ctor_set(v_reuseFailAlloc_2178_, 1, v___x_2172_);
lean_ctor_set(v_reuseFailAlloc_2178_, 2, v_metadata_2157_);
lean_ctor_set(v_reuseFailAlloc_2178_, 3, v_count_2158_);
lean_ctor_set(v_reuseFailAlloc_2178_, 4, v_workspace_2159_);
lean_ctor_set(v_reuseFailAlloc_2178_, 5, v_buckets_2160_);
lean_ctor_set(v_reuseFailAlloc_2178_, 6, v_products_2161_);
lean_ctor_set(v_reuseFailAlloc_2178_, 7, v_hashBits_2162_);
lean_ctor_set(v_reuseFailAlloc_2178_, 8, v_work_2163_);
v___x_2177_ = v_reuseFailAlloc_2178_;
goto v_reusejp_2176_;
}
v_reusejp_2176_:
{
lean_ctor_set_uint8(v___x_2177_, sizeof(void*)*9, v_width_2155_);
return v___x_2177_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen___boxed(lean_object* v_table_2192_, lean_object* v_width_2193_){
_start:
{
uint8_t v_width_boxed_2194_; lean_object* v_res_2195_; 
v_width_boxed_2194_ = lean_unbox(v_width_2193_);
v_res_2195_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen(v_table_2192_, v_width_boxed_2194_);
return v_res_2195_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0(uint8_t v_width_2196_, lean_object* v_table_2197_, lean_object* v_a_2198_, lean_object* v_range_2199_, lean_object* v_b_2200_, lean_object* v_i_2201_, lean_object* v_hs_2202_, lean_object* v_hl_2203_){
_start:
{
lean_object* v___x_2204_; 
v___x_2204_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___redArg(v_width_2196_, v_table_2197_, v_a_2198_, v_range_2199_, v_b_2200_, v_i_2201_);
return v___x_2204_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0___boxed(lean_object* v_width_2205_, lean_object* v_table_2206_, lean_object* v_a_2207_, lean_object* v_range_2208_, lean_object* v_b_2209_, lean_object* v_i_2210_, lean_object* v_hs_2211_, lean_object* v_hl_2212_){
_start:
{
uint8_t v_width_boxed_2213_; lean_object* v_res_2214_; 
v_width_boxed_2213_ = lean_unbox(v_width_2205_);
v_res_2214_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__0(v_width_boxed_2213_, v_table_2206_, v_a_2207_, v_range_2208_, v_b_2209_, v_i_2210_, v_hs_2211_, v_hl_2212_);
lean_dec_ref(v_range_2208_);
lean_dec(v_a_2207_);
lean_dec_ref(v_table_2206_);
return v_res_2214_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1(uint8_t v_width_2215_, lean_object* v_table_2216_, lean_object* v___x_2217_, lean_object* v_range_2218_, lean_object* v_b_2219_, lean_object* v_i_2220_, lean_object* v_hs_2221_, lean_object* v_hl_2222_){
_start:
{
lean_object* v___x_2223_; 
v___x_2223_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1___redArg(v_width_2215_, v_table_2216_, v___x_2217_, v_range_2218_, v_b_2219_, v_i_2220_);
return v___x_2223_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1___boxed(lean_object* v_width_2224_, lean_object* v_table_2225_, lean_object* v___x_2226_, lean_object* v_range_2227_, lean_object* v_b_2228_, lean_object* v_i_2229_, lean_object* v_hs_2230_, lean_object* v_hl_2231_){
_start:
{
uint8_t v_width_boxed_2232_; lean_object* v_res_2233_; 
v_width_boxed_2232_ = lean_unbox(v_width_2224_);
v_res_2233_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1(v_width_boxed_2232_, v_table_2225_, v___x_2226_, v_range_2227_, v_b_2228_, v_i_2229_, v_hs_2230_, v_hl_2231_);
lean_dec(v_i_2229_);
lean_dec_ref(v_range_2227_);
lean_dec_ref(v_table_2225_);
return v_res_2233_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1(lean_object* v___x_2234_, uint8_t v_width_2235_, lean_object* v_table_2236_, lean_object* v_range_2237_, lean_object* v_b_2238_, lean_object* v_i_2239_, lean_object* v_hs_2240_, lean_object* v_hl_2241_){
_start:
{
lean_object* v___x_2242_; 
v___x_2242_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1___redArg(v___x_2234_, v_width_2235_, v_table_2236_, v_range_2237_, v_b_2238_, v_i_2239_);
return v___x_2242_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1___boxed(lean_object* v___x_2243_, lean_object* v_width_2244_, lean_object* v_table_2245_, lean_object* v_range_2246_, lean_object* v_b_2247_, lean_object* v_i_2248_, lean_object* v_hs_2249_, lean_object* v_hl_2250_){
_start:
{
uint8_t v_width_boxed_2251_; lean_object* v_res_2252_; 
v_width_boxed_2251_ = lean_unbox(v_width_2244_);
v_res_2252_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen_spec__1_spec__1(v___x_2243_, v_width_boxed_2251_, v_table_2245_, v_range_2246_, v_b_2247_, v_i_2248_, v_hs_2249_, v_hl_2250_);
lean_dec_ref(v_range_2246_);
lean_dec_ref(v_table_2245_);
return v_res_2252_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___lam__0(lean_object* v_coordinate_2253_, uint8_t v_width_2254_, lean_object* v_a_2255_, lean_object* v_x_2256_, lean_object* v___y_2257_){
_start:
{
lean_object* v___x_2258_; uint64_t v___x_2259_; uint8_t v___x_2260_; lean_object* v_data_2261_; 
v___x_2258_ = lean_apply_1(v_coordinate_2253_, v_a_2255_);
v___x_2259_ = lean_unbox_uint64(v___x_2258_);
v___x_2260_ = lean_uint64_to_uint8(v___x_2259_);
v_data_2261_ = lean_byte_array_push(v___y_2257_, v___x_2260_);
switch(v_width_2254_)
{
case 0:
{
lean_object* v___x_2262_; 
lean_dec_ref(v___x_2258_);
v___x_2262_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2262_, 0, v_data_2261_);
return v___x_2262_;
}
case 1:
{
uint64_t v___x_2263_; uint64_t v___x_2264_; uint64_t v___x_2265_; uint8_t v___x_2266_; lean_object* v___x_2267_; lean_object* v___x_2268_; 
v___x_2263_ = 8ULL;
v___x_2264_ = lean_unbox_uint64(v___x_2258_);
lean_dec_ref(v___x_2258_);
v___x_2265_ = lean_uint64_shift_right(v___x_2264_, v___x_2263_);
v___x_2266_ = lean_uint64_to_uint8(v___x_2265_);
v___x_2267_ = lean_byte_array_push(v_data_2261_, v___x_2266_);
v___x_2268_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2268_, 0, v___x_2267_);
return v___x_2268_;
}
default: 
{
uint64_t v___x_2269_; uint64_t v___x_2270_; uint64_t v___x_2271_; uint8_t v___x_2272_; lean_object* v___x_2273_; uint64_t v___x_2274_; uint64_t v___x_2275_; uint64_t v___x_2276_; uint8_t v___x_2277_; lean_object* v___x_2278_; uint64_t v___x_2279_; uint64_t v___x_2280_; uint64_t v___x_2281_; uint8_t v___x_2282_; lean_object* v___x_2283_; lean_object* v___x_2284_; 
v___x_2269_ = 8ULL;
v___x_2270_ = lean_unbox_uint64(v___x_2258_);
v___x_2271_ = lean_uint64_shift_right(v___x_2270_, v___x_2269_);
v___x_2272_ = lean_uint64_to_uint8(v___x_2271_);
v___x_2273_ = lean_byte_array_push(v_data_2261_, v___x_2272_);
v___x_2274_ = 16ULL;
v___x_2275_ = lean_unbox_uint64(v___x_2258_);
v___x_2276_ = lean_uint64_shift_right(v___x_2275_, v___x_2274_);
v___x_2277_ = lean_uint64_to_uint8(v___x_2276_);
v___x_2278_ = lean_byte_array_push(v___x_2273_, v___x_2277_);
v___x_2279_ = 24ULL;
v___x_2280_ = lean_unbox_uint64(v___x_2258_);
lean_dec_ref(v___x_2258_);
v___x_2281_ = lean_uint64_shift_right(v___x_2280_, v___x_2279_);
v___x_2282_ = lean_uint64_to_uint8(v___x_2281_);
v___x_2283_ = lean_byte_array_push(v___x_2278_, v___x_2282_);
v___x_2284_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2284_, 0, v___x_2283_);
return v___x_2284_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___lam__0___boxed(lean_object* v_coordinate_2285_, lean_object* v_width_2286_, lean_object* v_a_2287_, lean_object* v_x_2288_, lean_object* v___y_2289_){
_start:
{
uint8_t v_width_boxed_2290_; lean_object* v_res_2291_; 
v_width_boxed_2290_ = lean_unbox(v_width_2286_);
v_res_2291_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___lam__0(v_coordinate_2285_, v_width_boxed_2290_, v_a_2287_, v_x_2288_, v___y_2289_);
return v_res_2291_;
}
}
static lean_object* _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__11(void){
_start:
{
lean_object* v___x_2312_; lean_object* v___f_2313_; 
v___x_2312_ = lean_alloc_closure((void*)(l_instDecidableEqUInt64___boxed), 2, 0);
v___f_2313_ = lean_alloc_closure((void*)(l_instBEqOfDecidableEq___redArg___lam__0___boxed), 3, 1);
lean_closure_set(v___f_2313_, 0, v___x_2312_);
return v___f_2313_;
}
}
static lean_object* _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12(void){
_start:
{
lean_object* v___x_2314_; lean_object* v___x_2315_; lean_object* v___x_2316_; 
v___x_2314_ = l_System_Platform_numBits;
v___x_2315_ = lean_unsigned_to_nat(2u);
v___x_2316_ = lean_nat_pow(v___x_2315_, v___x_2314_);
return v___x_2316_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append(lean_object* v_table_2317_, uint8_t v_width_2318_, uint64_t v_degree_2319_, uint64_t v_mask_2320_, uint64_t v_hash_2321_, lean_object* v_bucket_2322_, lean_object* v_coordinate_2323_, lean_object* v_work_2324_, lean_object* v_maxCount_2325_, lean_object* v_maxBytes_2326_, lean_object* v_maxWork_2327_){
_start:
{
lean_object* v___x_2328_; lean_object* v_arity_2329_; uint8_t v_width_2330_; lean_object* v_exponents_2331_; lean_object* v_metadata_2332_; lean_object* v_count_2333_; lean_object* v_workspace_2334_; lean_object* v_buckets_2335_; lean_object* v_products_2336_; lean_object* v_hashBits_2337_; uint8_t v___x_2338_; 
v___x_2328_ = ((lean_object*)(lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__9));
v_arity_2329_ = lean_ctor_get(v_table_2317_, 0);
v_width_2330_ = lean_ctor_get_uint8(v_table_2317_, sizeof(void*)*9);
v_exponents_2331_ = lean_ctor_get(v_table_2317_, 1);
v_metadata_2332_ = lean_ctor_get(v_table_2317_, 2);
v_count_2333_ = lean_ctor_get(v_table_2317_, 3);
v_workspace_2334_ = lean_ctor_get(v_table_2317_, 4);
v_buckets_2335_ = lean_ctor_get(v_table_2317_, 5);
v_products_2336_ = lean_ctor_get(v_table_2317_, 6);
v_hashBits_2337_ = lean_ctor_get(v_table_2317_, 7);
v___x_2338_ = lean_nat_dec_le(v_maxCount_2325_, v_count_2333_);
if (v___x_2338_ == 0)
{
lean_object* v___x_2339_; lean_object* v___x_2340_; lean_object* v___x_2341_; uint8_t v___x_2342_; 
v___x_2339_ = lean_unsigned_to_nat(4294967295u);
v___x_2340_ = lean_unsigned_to_nat(1u);
v___x_2341_ = lean_nat_add(v_count_2333_, v___x_2340_);
v___x_2342_ = lean_nat_dec_lt(v___x_2339_, v___x_2341_);
if (v___x_2342_ == 0)
{
lean_object* v___x_2343_; lean_object* v___f_2344_; lean_object* v___f_2345_; lean_object* v___y_2347_; lean_object* v_arity_2348_; uint8_t v_width_2349_; lean_object* v_exponents_2350_; lean_object* v_metadata_2351_; lean_object* v_count_2352_; lean_object* v_workspace_2353_; lean_object* v_buckets_2354_; lean_object* v_products_2355_; lean_object* v_hashBits_2356_; lean_object* v___y_2372_; lean_object* v___y_2373_; lean_object* v___y_2392_; uint8_t v___y_2393_; lean_object* v___y_2394_; lean_object* v___y_2411_; uint8_t v___y_2412_; lean_object* v___y_2415_; lean_object* v___y_2416_; lean_object* v___y_2422_; lean_object* v___y_2423_; lean_object* v___y_2424_; lean_object* v___x_2426_; lean_object* v___y_2428_; 
v___x_2343_ = lean_box(v_width_2318_);
v___f_2344_ = lean_alloc_closure((void*)(lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___lam__0___boxed), 5, 2);
lean_closure_set(v___f_2344_, 0, v_coordinate_2323_);
lean_closure_set(v___f_2344_, 1, v___x_2343_);
v___f_2345_ = ((lean_object*)(lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__10));
v___x_2426_ = lean_nat_mul(v___x_2341_, v_arity_2329_);
switch(v_width_2318_)
{
case 0:
{
v___y_2428_ = v___x_2340_;
goto v___jp_2427_;
}
case 1:
{
lean_object* v___x_2446_; 
v___x_2446_ = lean_unsigned_to_nat(2u);
v___y_2428_ = v___x_2446_;
goto v___jp_2427_;
}
default: 
{
lean_object* v___x_2447_; 
v___x_2447_ = lean_unsigned_to_nat(4u);
v___y_2428_ = v___x_2447_;
goto v___jp_2427_;
}
}
v___jp_2346_:
{
lean_object* v___x_2357_; lean_object* v___x_2358_; lean_object* v___x_2359_; lean_object* v___x_2360_; lean_object* v___x_2361_; lean_object* v___x_2362_; lean_object* v___f_2363_; lean_object* v___x_2364_; lean_object* v___x_2365_; lean_object* v___x_2366_; lean_object* v___x_2367_; lean_object* v___x_2368_; lean_object* v___x_2369_; lean_object* v___x_2370_; 
v___x_2357_ = lean_unsigned_to_nat(0u);
lean_inc(v_arity_2348_);
v___x_2358_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2358_, 0, v___x_2357_);
lean_ctor_set(v___x_2358_, 1, v_arity_2348_);
lean_ctor_set(v___x_2358_, 2, v___x_2340_);
v___x_2359_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop(lean_box(0), lean_box(0), v___x_2328_, v___x_2358_, v___f_2344_, v_exponents_2350_, v___x_2357_, lean_box(0), lean_box(0));
v___x_2360_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v_metadata_2351_, v_degree_2319_);
v___x_2361_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v___x_2360_, v_mask_2320_);
v___x_2362_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v___x_2361_, v_hash_2321_);
v___f_2363_ = lean_obj_once(&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__11, &lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__11_once, _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__11);
lean_inc(v_count_2352_);
v___x_2364_ = lean_array_push(v_bucket_2322_, v_count_2352_);
v___x_2365_ = lean_box_uint64(v_hash_2321_);
v___x_2366_ = l_Std_DHashMap_Internal_Raw_u2080_insert___redArg(v___f_2363_, v___f_2345_, v_buckets_2354_, v___x_2365_, v___x_2364_);
v___x_2367_ = lean_nat_add(v_count_2352_, v___x_2340_);
v___x_2368_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_2368_, 0, v_arity_2348_);
lean_ctor_set(v___x_2368_, 1, v___x_2359_);
lean_ctor_set(v___x_2368_, 2, v___x_2362_);
lean_ctor_set(v___x_2368_, 3, v___x_2367_);
lean_ctor_set(v___x_2368_, 4, v_workspace_2353_);
lean_ctor_set(v___x_2368_, 5, v___x_2366_);
lean_ctor_set(v___x_2368_, 6, v_products_2355_);
lean_ctor_set(v___x_2368_, 7, v_hashBits_2356_);
lean_ctor_set(v___x_2368_, 8, v___y_2347_);
lean_ctor_set_uint8(v___x_2368_, sizeof(void*)*9, v_width_2349_);
v___x_2369_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2369_, 0, v_count_2352_);
v___x_2370_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2370_, 0, v___x_2369_);
lean_ctor_set(v___x_2370_, 1, v___x_2368_);
return v___x_2370_;
}
v___jp_2371_:
{
lean_object* v_work_2374_; uint8_t v___x_2375_; 
v_work_2374_ = lean_nat_add(v___y_2372_, v___y_2373_);
lean_dec(v___y_2373_);
lean_dec(v___y_2372_);
v___x_2375_ = lean_nat_dec_lt(v_maxWork_2327_, v_work_2374_);
if (v___x_2375_ == 0)
{
uint8_t v___x_2376_; 
lean_dec(v_maxWork_2327_);
v___x_2376_ = lp_Hex_Hex_Groebner_instBEqWidth_beq(v_width_2318_, v_width_2330_);
if (v___x_2376_ == 0)
{
lean_object* v___x_2377_; lean_object* v_arity_2378_; uint8_t v_width_2379_; lean_object* v_exponents_2380_; lean_object* v_metadata_2381_; lean_object* v_count_2382_; lean_object* v_workspace_2383_; lean_object* v_buckets_2384_; lean_object* v_products_2385_; lean_object* v_hashBits_2386_; 
v___x_2377_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen(v_table_2317_, v_width_2318_);
v_arity_2378_ = lean_ctor_get(v___x_2377_, 0);
lean_inc(v_arity_2378_);
v_width_2379_ = lean_ctor_get_uint8(v___x_2377_, sizeof(void*)*9);
v_exponents_2380_ = lean_ctor_get(v___x_2377_, 1);
lean_inc_ref(v_exponents_2380_);
v_metadata_2381_ = lean_ctor_get(v___x_2377_, 2);
lean_inc_ref(v_metadata_2381_);
v_count_2382_ = lean_ctor_get(v___x_2377_, 3);
lean_inc(v_count_2382_);
v_workspace_2383_ = lean_ctor_get(v___x_2377_, 4);
lean_inc_ref(v_workspace_2383_);
v_buckets_2384_ = lean_ctor_get(v___x_2377_, 5);
lean_inc_ref(v_buckets_2384_);
v_products_2385_ = lean_ctor_get(v___x_2377_, 6);
lean_inc_ref(v_products_2385_);
v_hashBits_2386_ = lean_ctor_get(v___x_2377_, 7);
lean_inc(v_hashBits_2386_);
lean_dec_ref(v___x_2377_);
v___y_2347_ = v_work_2374_;
v_arity_2348_ = v_arity_2378_;
v_width_2349_ = v_width_2379_;
v_exponents_2350_ = v_exponents_2380_;
v_metadata_2351_ = v_metadata_2381_;
v_count_2352_ = v_count_2382_;
v_workspace_2353_ = v_workspace_2383_;
v_buckets_2354_ = v_buckets_2384_;
v_products_2355_ = v_products_2385_;
v_hashBits_2356_ = v_hashBits_2386_;
goto v___jp_2346_;
}
else
{
lean_inc(v_hashBits_2337_);
lean_inc_ref(v_products_2336_);
lean_inc_ref(v_buckets_2335_);
lean_inc_ref(v_workspace_2334_);
lean_inc(v_count_2333_);
lean_inc_ref(v_metadata_2332_);
lean_inc_ref(v_exponents_2331_);
lean_inc(v_arity_2329_);
lean_dec_ref(v_table_2317_);
v___y_2347_ = v_work_2374_;
v_arity_2348_ = v_arity_2329_;
v_width_2349_ = v_width_2330_;
v_exponents_2350_ = v_exponents_2331_;
v_metadata_2351_ = v_metadata_2332_;
v_count_2352_ = v_count_2333_;
v_workspace_2353_ = v_workspace_2334_;
v_buckets_2354_ = v_buckets_2335_;
v_products_2355_ = v_products_2336_;
v_hashBits_2356_ = v_hashBits_2337_;
goto v___jp_2346_;
}
}
else
{
uint8_t v___x_2387_; lean_object* v___x_2388_; lean_object* v___x_2389_; lean_object* v___x_2390_; 
lean_dec(v_work_2374_);
lean_dec_ref(v___f_2344_);
lean_dec_ref(v_bucket_2322_);
v___x_2387_ = 8;
v___x_2388_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2388_, 0, v_maxWork_2327_);
lean_ctor_set_uint8(v___x_2388_, sizeof(void*)*1, v___x_2387_);
v___x_2389_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2389_, 0, v___x_2388_);
v___x_2390_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2390_, 0, v___x_2389_);
lean_ctor_set(v___x_2390_, 1, v_table_2317_);
return v___x_2390_;
}
}
v___jp_2391_:
{
lean_object* v_peak_2395_; uint8_t v___x_2396_; 
v_peak_2395_ = lean_nat_add(v___y_2392_, v___y_2394_);
lean_dec(v___y_2394_);
lean_dec(v___y_2392_);
v___x_2396_ = lean_nat_dec_lt(v_maxBytes_2326_, v_peak_2395_);
if (v___x_2396_ == 0)
{
lean_object* v___x_2397_; uint8_t v___x_2398_; 
v___x_2397_ = lean_obj_once(&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12, &lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12_once, _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12);
v___x_2398_ = lean_nat_dec_le(v___x_2397_, v_peak_2395_);
lean_dec(v_peak_2395_);
if (v___x_2398_ == 0)
{
lean_object* v___x_2399_; 
v___x_2399_ = lean_nat_add(v_work_2324_, v_arity_2329_);
lean_dec(v_work_2324_);
if (v___y_2393_ == 0)
{
lean_object* v___x_2400_; 
v___x_2400_ = lean_unsigned_to_nat(0u);
v___y_2372_ = v___x_2399_;
v___y_2373_ = v___x_2400_;
goto v___jp_2371_;
}
else
{
lean_object* v___x_2401_; 
v___x_2401_ = lean_nat_mul(v_count_2333_, v_arity_2329_);
v___y_2372_ = v___x_2399_;
v___y_2373_ = v___x_2401_;
goto v___jp_2371_;
}
}
else
{
uint8_t v___x_2402_; lean_object* v___x_2403_; lean_object* v___x_2404_; lean_object* v___x_2405_; 
lean_dec_ref(v___f_2344_);
lean_dec(v_maxWork_2327_);
lean_dec_ref(v_bucket_2322_);
v___x_2402_ = 4;
v___x_2403_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2403_, 0, v_work_2324_);
lean_ctor_set_uint8(v___x_2403_, sizeof(void*)*1, v___x_2402_);
v___x_2404_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2404_, 0, v___x_2403_);
v___x_2405_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2405_, 0, v___x_2404_);
lean_ctor_set(v___x_2405_, 1, v_table_2317_);
return v___x_2405_;
}
}
else
{
uint8_t v___x_2406_; lean_object* v___x_2407_; lean_object* v___x_2408_; lean_object* v___x_2409_; 
lean_dec(v_peak_2395_);
lean_dec_ref(v___f_2344_);
lean_dec(v_maxWork_2327_);
lean_dec_ref(v_bucket_2322_);
v___x_2406_ = 7;
v___x_2407_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2407_, 0, v_work_2324_);
lean_ctor_set_uint8(v___x_2407_, sizeof(void*)*1, v___x_2406_);
v___x_2408_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2408_, 0, v___x_2407_);
v___x_2409_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2409_, 0, v___x_2408_);
lean_ctor_set(v___x_2409_, 1, v_table_2317_);
return v___x_2409_;
}
}
v___jp_2410_:
{
lean_object* v___x_2413_; 
v___x_2413_ = lean_byte_array_size(v_exponents_2331_);
v___y_2392_ = v___y_2411_;
v___y_2393_ = v___y_2412_;
v___y_2394_ = v___x_2413_;
goto v___jp_2391_;
}
v___jp_2414_:
{
lean_object* v___x_2417_; uint8_t v___x_2418_; 
v___x_2417_ = lean_nat_add(v___y_2415_, v___y_2416_);
lean_dec(v___y_2416_);
lean_dec(v___y_2415_);
v___x_2418_ = lp_Hex_Hex_Groebner_instBEqWidth_beq(v_width_2318_, v_width_2330_);
if (v___x_2418_ == 0)
{
uint8_t v___x_2419_; 
v___x_2419_ = 1;
v___y_2411_ = v___x_2417_;
v___y_2412_ = v___x_2419_;
goto v___jp_2410_;
}
else
{
if (v___x_2342_ == 0)
{
lean_object* v___x_2420_; 
v___x_2420_ = lean_unsigned_to_nat(0u);
v___y_2392_ = v___x_2417_;
v___y_2393_ = v___x_2342_;
v___y_2394_ = v___x_2420_;
goto v___jp_2391_;
}
else
{
v___y_2411_ = v___x_2417_;
v___y_2412_ = v___x_2342_;
goto v___jp_2410_;
}
}
}
v___jp_2421_:
{
uint8_t v___x_2425_; 
v___x_2425_ = lean_nat_dec_le(v___y_2423_, v___y_2424_);
if (v___x_2425_ == 0)
{
lean_dec(v___y_2424_);
v___y_2415_ = v___y_2422_;
v___y_2416_ = v___y_2423_;
goto v___jp_2414_;
}
else
{
lean_dec(v___y_2423_);
v___y_2415_ = v___y_2422_;
v___y_2416_ = v___y_2424_;
goto v___jp_2414_;
}
}
v___jp_2427_:
{
lean_object* v_size_2429_; lean_object* v___x_2430_; lean_object* v___x_2431_; lean_object* v___x_2432_; lean_object* v_size_2433_; lean_object* v___x_2434_; lean_object* v___x_2435_; lean_object* v___x_2436_; lean_object* v___x_2437_; lean_object* v___x_2438_; uint8_t v___x_2439_; 
v_size_2429_ = lean_ctor_get(v_products_2336_, 0);
v___x_2430_ = lean_nat_mul(v___x_2426_, v___y_2428_);
lean_dec(v___x_2426_);
v___x_2431_ = lean_unsigned_to_nat(24u);
v___x_2432_ = lean_nat_mul(v___x_2341_, v___x_2431_);
lean_dec(v___x_2341_);
v_size_2433_ = lean_nat_add(v___x_2430_, v___x_2432_);
lean_dec(v___x_2432_);
lean_dec(v___x_2430_);
v___x_2434_ = lean_unsigned_to_nat(12u);
v___x_2435_ = lean_nat_mul(v___x_2434_, v_size_2429_);
v___x_2436_ = lean_nat_add(v_size_2433_, v___x_2435_);
lean_dec(v___x_2435_);
lean_dec(v_size_2433_);
v___x_2437_ = lean_byte_array_size(v_workspace_2334_);
v___x_2438_ = lean_unsigned_to_nat(0u);
v___x_2439_ = lean_nat_dec_lt(v___x_2438_, v_arity_2329_);
if (v___x_2439_ == 0)
{
v___y_2422_ = v___x_2436_;
v___y_2423_ = v___x_2437_;
v___y_2424_ = v___x_2438_;
goto v___jp_2421_;
}
else
{
lean_object* v___x_2440_; uint8_t v___x_2441_; 
v___x_2440_ = lean_unsigned_to_nat(4096u);
v___x_2441_ = lean_nat_dec_le(v_arity_2329_, v___x_2440_);
if (v___x_2441_ == 0)
{
v___y_2422_ = v___x_2436_;
v___y_2423_ = v___x_2437_;
v___y_2424_ = v___x_2438_;
goto v___jp_2421_;
}
else
{
lean_object* v___x_2442_; lean_object* v___x_2443_; lean_object* v___x_2444_; lean_object* v___x_2445_; 
v___x_2442_ = lean_unsigned_to_nat(4u);
v___x_2443_ = lean_nat_mul(v_arity_2329_, v___x_2442_);
v___x_2444_ = lean_unsigned_to_nat(28u);
v___x_2445_ = lean_nat_add(v___x_2443_, v___x_2444_);
lean_dec(v___x_2443_);
v___y_2422_ = v___x_2436_;
v___y_2423_ = v___x_2437_;
v___y_2424_ = v___x_2445_;
goto v___jp_2421_;
}
}
}
}
else
{
uint8_t v___x_2448_; lean_object* v___x_2449_; lean_object* v___x_2450_; lean_object* v___x_2451_; 
lean_dec(v___x_2341_);
lean_dec(v_maxWork_2327_);
lean_dec_ref(v_coordinate_2323_);
lean_dec_ref(v_bucket_2322_);
v___x_2448_ = 1;
v___x_2449_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2449_, 0, v_work_2324_);
lean_ctor_set_uint8(v___x_2449_, sizeof(void*)*1, v___x_2448_);
v___x_2450_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2450_, 0, v___x_2449_);
v___x_2451_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2451_, 0, v___x_2450_);
lean_ctor_set(v___x_2451_, 1, v_table_2317_);
return v___x_2451_;
}
}
else
{
uint8_t v___x_2452_; lean_object* v___x_2453_; lean_object* v___x_2454_; lean_object* v___x_2455_; 
lean_dec(v_maxWork_2327_);
lean_dec_ref(v_coordinate_2323_);
lean_dec_ref(v_bucket_2322_);
v___x_2452_ = 6;
v___x_2453_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2453_, 0, v_work_2324_);
lean_ctor_set_uint8(v___x_2453_, sizeof(void*)*1, v___x_2452_);
v___x_2454_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2454_, 0, v___x_2453_);
v___x_2455_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2455_, 0, v___x_2454_);
lean_ctor_set(v___x_2455_, 1, v_table_2317_);
return v___x_2455_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___boxed(lean_object* v_table_2456_, lean_object* v_width_2457_, lean_object* v_degree_2458_, lean_object* v_mask_2459_, lean_object* v_hash_2460_, lean_object* v_bucket_2461_, lean_object* v_coordinate_2462_, lean_object* v_work_2463_, lean_object* v_maxCount_2464_, lean_object* v_maxBytes_2465_, lean_object* v_maxWork_2466_){
_start:
{
uint8_t v_width_boxed_2467_; uint64_t v_degree_boxed_2468_; uint64_t v_mask_boxed_2469_; uint64_t v_hash_boxed_2470_; lean_object* v_res_2471_; 
v_width_boxed_2467_ = lean_unbox(v_width_2457_);
v_degree_boxed_2468_ = lean_unbox_uint64(v_degree_2458_);
lean_dec_ref(v_degree_2458_);
v_mask_boxed_2469_ = lean_unbox_uint64(v_mask_2459_);
lean_dec_ref(v_mask_2459_);
v_hash_boxed_2470_ = lean_unbox_uint64(v_hash_2460_);
lean_dec_ref(v_hash_2460_);
v_res_2471_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append(v_table_2456_, v_width_boxed_2467_, v_degree_boxed_2468_, v_mask_boxed_2469_, v_hash_boxed_2470_, v_bucket_2461_, v_coordinate_2462_, v_work_2463_, v_maxCount_2464_, v_maxBytes_2465_, v_maxWork_2466_);
lean_dec(v_maxBytes_2465_);
lean_dec(v_maxCount_2464_);
return v_res_2471_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0___redArg(lean_object* v_values_2472_, lean_object* v_work_2473_, lean_object* v_table_2474_, lean_object* v_range_2475_, lean_object* v_b_2476_, lean_object* v_i_2477_){
_start:
{
lean_object* v_stop_2478_; lean_object* v_step_2479_; uint8_t v___x_2480_; 
v_stop_2478_ = lean_ctor_get(v_range_2475_, 1);
v_step_2479_ = lean_ctor_get(v_range_2475_, 2);
v___x_2480_ = lean_nat_dec_lt(v_i_2477_, v_stop_2478_);
if (v___x_2480_ == 0)
{
lean_dec(v_i_2477_);
lean_dec_ref(v_table_2474_);
lean_dec(v_work_2473_);
return v_b_2476_;
}
else
{
lean_object* v_snd_2481_; lean_object* v___x_2483_; uint8_t v_isShared_2484_; uint8_t v_isSharedCheck_2583_; 
v_snd_2481_ = lean_ctor_get(v_b_2476_, 1);
v_isSharedCheck_2583_ = !lean_is_exclusive(v_b_2476_);
if (v_isSharedCheck_2583_ == 0)
{
lean_object* v_unused_2584_; 
v_unused_2584_ = lean_ctor_get(v_b_2476_, 0);
lean_dec(v_unused_2584_);
v___x_2483_ = v_b_2476_;
v_isShared_2484_ = v_isSharedCheck_2583_;
goto v_resetjp_2482_;
}
else
{
lean_inc(v_snd_2481_);
lean_dec(v_b_2476_);
v___x_2483_ = lean_box(0);
v_isShared_2484_ = v_isSharedCheck_2583_;
goto v_resetjp_2482_;
}
v_resetjp_2482_:
{
lean_object* v_snd_2485_; lean_object* v_snd_2486_; lean_object* v_fst_2487_; lean_object* v___x_2489_; uint8_t v_isShared_2490_; uint8_t v_isSharedCheck_2581_; 
v_snd_2485_ = lean_ctor_get(v_snd_2481_, 1);
lean_inc(v_snd_2485_);
v_snd_2486_ = lean_ctor_get(v_snd_2485_, 1);
lean_inc(v_snd_2486_);
v_fst_2487_ = lean_ctor_get(v_snd_2481_, 0);
v_isSharedCheck_2581_ = !lean_is_exclusive(v_snd_2481_);
if (v_isSharedCheck_2581_ == 0)
{
lean_object* v_unused_2582_; 
v_unused_2582_ = lean_ctor_get(v_snd_2481_, 1);
lean_dec(v_unused_2582_);
v___x_2489_ = v_snd_2481_;
v_isShared_2490_ = v_isSharedCheck_2581_;
goto v_resetjp_2488_;
}
else
{
lean_inc(v_fst_2487_);
lean_dec(v_snd_2481_);
v___x_2489_ = lean_box(0);
v_isShared_2490_ = v_isSharedCheck_2581_;
goto v_resetjp_2488_;
}
v_resetjp_2488_:
{
lean_object* v_fst_2491_; lean_object* v___x_2493_; uint8_t v_isShared_2494_; uint8_t v_isSharedCheck_2579_; 
v_fst_2491_ = lean_ctor_get(v_snd_2485_, 0);
v_isSharedCheck_2579_ = !lean_is_exclusive(v_snd_2485_);
if (v_isSharedCheck_2579_ == 0)
{
lean_object* v_unused_2580_; 
v_unused_2580_ = lean_ctor_get(v_snd_2485_, 1);
lean_dec(v_unused_2580_);
v___x_2493_ = v_snd_2485_;
v_isShared_2494_ = v_isSharedCheck_2579_;
goto v_resetjp_2492_;
}
else
{
lean_inc(v_fst_2491_);
lean_dec(v_snd_2485_);
v___x_2493_ = lean_box(0);
v_isShared_2494_ = v_isSharedCheck_2579_;
goto v_resetjp_2492_;
}
v_resetjp_2492_:
{
lean_object* v_fst_2495_; lean_object* v_snd_2496_; lean_object* v___x_2498_; uint8_t v_isShared_2499_; uint8_t v_isSharedCheck_2578_; 
v_fst_2495_ = lean_ctor_get(v_snd_2486_, 0);
v_snd_2496_ = lean_ctor_get(v_snd_2486_, 1);
v_isSharedCheck_2578_ = !lean_is_exclusive(v_snd_2486_);
if (v_isSharedCheck_2578_ == 0)
{
v___x_2498_ = v_snd_2486_;
v_isShared_2499_ = v_isSharedCheck_2578_;
goto v_resetjp_2497_;
}
else
{
lean_inc(v_snd_2496_);
lean_inc(v_fst_2495_);
lean_dec(v_snd_2486_);
v___x_2498_ = lean_box(0);
v_isShared_2499_ = v_isSharedCheck_2578_;
goto v_resetjp_2497_;
}
v_resetjp_2497_:
{
uint64_t v___x_2500_; lean_object* v___x_2501_; lean_object* v___x_2502_; uint64_t v___x_2503_; uint64_t v___x_2504_; uint8_t v___x_2505_; 
v___x_2500_ = 0ULL;
v___x_2501_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg___boxed__const__1));
v___x_2502_ = lean_array_get_borrowed(v___x_2501_, v_values_2472_, v_i_2477_);
v___x_2503_ = 4294967295ULL;
v___x_2504_ = lean_unbox_uint64(v___x_2502_);
v___x_2505_ = lean_uint64_dec_lt(v___x_2503_, v___x_2504_);
if (v___x_2505_ == 0)
{
lean_object* v___x_2506_; uint8_t v___y_2508_; lean_object* v___y_2509_; uint64_t v_mask_2510_; uint8_t v_width_2534_; uint64_t v___x_2548_; uint64_t v___x_2549_; uint8_t v___x_2550_; 
v___x_2506_ = lean_box(0);
v___x_2548_ = 65535ULL;
v___x_2549_ = lean_unbox_uint64(v___x_2502_);
v___x_2550_ = lean_uint64_dec_lt(v___x_2548_, v___x_2549_);
if (v___x_2550_ == 0)
{
uint64_t v___x_2551_; uint64_t v___x_2552_; uint8_t v___x_2553_; 
v___x_2551_ = 255ULL;
v___x_2552_ = lean_unbox_uint64(v___x_2502_);
v___x_2553_ = lean_uint64_dec_lt(v___x_2551_, v___x_2552_);
if (v___x_2553_ == 0)
{
uint8_t v___x_2554_; 
v___x_2554_ = lean_unbox(v_fst_2487_);
lean_dec(v_fst_2487_);
v_width_2534_ = v___x_2554_;
goto v___jp_2533_;
}
else
{
uint8_t v___x_2555_; uint8_t v___x_2556_; uint8_t v___x_2557_; 
v___x_2555_ = 0;
v___x_2556_ = lean_unbox(v_fst_2487_);
v___x_2557_ = lp_Hex_Hex_Groebner_instBEqWidth_beq(v___x_2556_, v___x_2555_);
if (v___x_2557_ == 0)
{
uint8_t v___x_2558_; 
v___x_2558_ = lean_unbox(v_fst_2487_);
lean_dec(v_fst_2487_);
v_width_2534_ = v___x_2558_;
goto v___jp_2533_;
}
else
{
uint8_t v___x_2559_; 
lean_dec(v_fst_2487_);
v___x_2559_ = 1;
v_width_2534_ = v___x_2559_;
goto v___jp_2533_;
}
}
}
else
{
uint8_t v___x_2560_; 
lean_dec(v_fst_2487_);
v___x_2560_ = 2;
v_width_2534_ = v___x_2560_;
goto v___jp_2533_;
}
v___jp_2507_:
{
uint64_t v___x_2511_; uint64_t v___x_2512_; uint64_t v___x_2513_; uint64_t v___x_2514_; uint64_t v___x_2515_; lean_object* v___x_2516_; lean_object* v___x_2517_; lean_object* v___x_2519_; 
v___x_2511_ = lean_unbox_uint64(v_snd_2496_);
lean_dec(v_snd_2496_);
v___x_2512_ = lean_unbox_uint64(v___x_2502_);
v___x_2513_ = lean_uint64_xor(v___x_2511_, v___x_2512_);
v___x_2514_ = 1099511628211ULL;
v___x_2515_ = lean_uint64_mul(v___x_2513_, v___x_2514_);
v___x_2516_ = lean_box_uint64(v_mask_2510_);
v___x_2517_ = lean_box_uint64(v___x_2515_);
if (v_isShared_2499_ == 0)
{
lean_ctor_set(v___x_2498_, 1, v___x_2517_);
lean_ctor_set(v___x_2498_, 0, v___x_2516_);
v___x_2519_ = v___x_2498_;
goto v_reusejp_2518_;
}
else
{
lean_object* v_reuseFailAlloc_2532_; 
v_reuseFailAlloc_2532_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2532_, 0, v___x_2516_);
lean_ctor_set(v_reuseFailAlloc_2532_, 1, v___x_2517_);
v___x_2519_ = v_reuseFailAlloc_2532_;
goto v_reusejp_2518_;
}
v_reusejp_2518_:
{
lean_object* v___x_2521_; 
if (v_isShared_2494_ == 0)
{
lean_ctor_set(v___x_2493_, 1, v___x_2519_);
lean_ctor_set(v___x_2493_, 0, v___y_2509_);
v___x_2521_ = v___x_2493_;
goto v_reusejp_2520_;
}
else
{
lean_object* v_reuseFailAlloc_2531_; 
v_reuseFailAlloc_2531_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2531_, 0, v___y_2509_);
lean_ctor_set(v_reuseFailAlloc_2531_, 1, v___x_2519_);
v___x_2521_ = v_reuseFailAlloc_2531_;
goto v_reusejp_2520_;
}
v_reusejp_2520_:
{
lean_object* v___x_2522_; lean_object* v___x_2524_; 
v___x_2522_ = lean_box(v___y_2508_);
if (v_isShared_2490_ == 0)
{
lean_ctor_set(v___x_2489_, 1, v___x_2521_);
lean_ctor_set(v___x_2489_, 0, v___x_2522_);
v___x_2524_ = v___x_2489_;
goto v_reusejp_2523_;
}
else
{
lean_object* v_reuseFailAlloc_2530_; 
v_reuseFailAlloc_2530_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2530_, 0, v___x_2522_);
lean_ctor_set(v_reuseFailAlloc_2530_, 1, v___x_2521_);
v___x_2524_ = v_reuseFailAlloc_2530_;
goto v_reusejp_2523_;
}
v_reusejp_2523_:
{
lean_object* v___x_2526_; 
if (v_isShared_2484_ == 0)
{
lean_ctor_set(v___x_2483_, 1, v___x_2524_);
lean_ctor_set(v___x_2483_, 0, v___x_2506_);
v___x_2526_ = v___x_2483_;
goto v_reusejp_2525_;
}
else
{
lean_object* v_reuseFailAlloc_2529_; 
v_reuseFailAlloc_2529_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2529_, 0, v___x_2506_);
lean_ctor_set(v_reuseFailAlloc_2529_, 1, v___x_2524_);
v___x_2526_ = v_reuseFailAlloc_2529_;
goto v_reusejp_2525_;
}
v_reusejp_2525_:
{
lean_object* v___x_2527_; 
v___x_2527_ = lean_nat_add(v_i_2477_, v_step_2479_);
lean_dec(v_i_2477_);
v_b_2476_ = v___x_2526_;
v_i_2477_ = v___x_2527_;
goto _start;
}
}
}
}
}
v___jp_2533_:
{
uint64_t v___x_2535_; lean_object* v___x_2536_; lean_object* v___x_2537_; uint64_t v___x_2538_; uint8_t v___x_2539_; 
v___x_2535_ = lean_unbox_uint64(v___x_2502_);
v___x_2536_ = lean_uint64_to_nat(v___x_2535_);
v___x_2537_ = lean_nat_add(v_fst_2491_, v___x_2536_);
lean_dec(v___x_2536_);
lean_dec(v_fst_2491_);
v___x_2538_ = lean_unbox_uint64(v___x_2502_);
v___x_2539_ = lean_uint64_dec_eq(v___x_2538_, v___x_2500_);
if (v___x_2539_ == 0)
{
uint64_t v___x_2540_; lean_object* v___x_2541_; lean_object* v___x_2542_; uint64_t v___x_2543_; uint64_t v___x_2544_; uint64_t v___x_2545_; uint64_t v___x_2546_; 
v___x_2540_ = 1ULL;
v___x_2541_ = lean_unsigned_to_nat(64u);
v___x_2542_ = lean_nat_mod(v_i_2477_, v___x_2541_);
v___x_2543_ = lean_uint64_of_nat(v___x_2542_);
lean_dec(v___x_2542_);
v___x_2544_ = lean_uint64_shift_left(v___x_2540_, v___x_2543_);
v___x_2545_ = lean_unbox_uint64(v_fst_2495_);
lean_dec(v_fst_2495_);
v___x_2546_ = lean_uint64_lor(v___x_2545_, v___x_2544_);
v___y_2508_ = v_width_2534_;
v___y_2509_ = v___x_2537_;
v_mask_2510_ = v___x_2546_;
goto v___jp_2507_;
}
else
{
uint64_t v___x_2547_; 
v___x_2547_ = lean_unbox_uint64(v_fst_2495_);
lean_dec(v_fst_2495_);
v___y_2508_ = v_width_2534_;
v___y_2509_ = v___x_2537_;
v_mask_2510_ = v___x_2547_;
goto v___jp_2507_;
}
}
}
else
{
uint8_t v___x_2561_; lean_object* v___x_2562_; lean_object* v___x_2563_; lean_object* v___x_2564_; lean_object* v___x_2565_; lean_object* v___x_2567_; 
lean_dec(v_i_2477_);
v___x_2561_ = 2;
v___x_2562_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2562_, 0, v_work_2473_);
lean_ctor_set_uint8(v___x_2562_, sizeof(void*)*1, v___x_2561_);
v___x_2563_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2563_, 0, v___x_2562_);
v___x_2564_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2564_, 0, v___x_2563_);
lean_ctor_set(v___x_2564_, 1, v_table_2474_);
v___x_2565_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2565_, 0, v___x_2564_);
if (v_isShared_2499_ == 0)
{
v___x_2567_ = v___x_2498_;
goto v_reusejp_2566_;
}
else
{
lean_object* v_reuseFailAlloc_2577_; 
v_reuseFailAlloc_2577_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2577_, 0, v_fst_2495_);
lean_ctor_set(v_reuseFailAlloc_2577_, 1, v_snd_2496_);
v___x_2567_ = v_reuseFailAlloc_2577_;
goto v_reusejp_2566_;
}
v_reusejp_2566_:
{
lean_object* v___x_2569_; 
if (v_isShared_2494_ == 0)
{
lean_ctor_set(v___x_2493_, 1, v___x_2567_);
v___x_2569_ = v___x_2493_;
goto v_reusejp_2568_;
}
else
{
lean_object* v_reuseFailAlloc_2576_; 
v_reuseFailAlloc_2576_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2576_, 0, v_fst_2491_);
lean_ctor_set(v_reuseFailAlloc_2576_, 1, v___x_2567_);
v___x_2569_ = v_reuseFailAlloc_2576_;
goto v_reusejp_2568_;
}
v_reusejp_2568_:
{
lean_object* v___x_2571_; 
if (v_isShared_2490_ == 0)
{
lean_ctor_set(v___x_2489_, 1, v___x_2569_);
v___x_2571_ = v___x_2489_;
goto v_reusejp_2570_;
}
else
{
lean_object* v_reuseFailAlloc_2575_; 
v_reuseFailAlloc_2575_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2575_, 0, v_fst_2487_);
lean_ctor_set(v_reuseFailAlloc_2575_, 1, v___x_2569_);
v___x_2571_ = v_reuseFailAlloc_2575_;
goto v_reusejp_2570_;
}
v_reusejp_2570_:
{
lean_object* v___x_2573_; 
if (v_isShared_2484_ == 0)
{
lean_ctor_set(v___x_2483_, 1, v___x_2571_);
lean_ctor_set(v___x_2483_, 0, v___x_2565_);
v___x_2573_ = v___x_2483_;
goto v_reusejp_2572_;
}
else
{
lean_object* v_reuseFailAlloc_2574_; 
v_reuseFailAlloc_2574_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2574_, 0, v___x_2565_);
lean_ctor_set(v_reuseFailAlloc_2574_, 1, v___x_2571_);
v___x_2573_ = v_reuseFailAlloc_2574_;
goto v_reusejp_2572_;
}
v_reusejp_2572_:
{
return v___x_2573_;
}
}
}
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0___redArg___boxed(lean_object* v_values_2585_, lean_object* v_work_2586_, lean_object* v_table_2587_, lean_object* v_range_2588_, lean_object* v_b_2589_, lean_object* v_i_2590_){
_start:
{
lean_object* v_res_2591_; 
v_res_2591_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0___redArg(v_values_2585_, v_work_2586_, v_table_2587_, v_range_2588_, v_b_2589_, v_i_2590_);
lean_dec_ref(v_range_2588_);
lean_dec_ref(v_values_2585_);
return v_res_2591_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7_spec__9___redArg(lean_object* v_x_2592_, lean_object* v_x_2593_){
_start:
{
if (lean_obj_tag(v_x_2593_) == 0)
{
return v_x_2592_;
}
else
{
lean_object* v_key_2594_; lean_object* v_value_2595_; lean_object* v_tail_2596_; lean_object* v___x_2598_; uint8_t v_isShared_2599_; uint8_t v_isSharedCheck_2620_; 
v_key_2594_ = lean_ctor_get(v_x_2593_, 0);
v_value_2595_ = lean_ctor_get(v_x_2593_, 1);
v_tail_2596_ = lean_ctor_get(v_x_2593_, 2);
v_isSharedCheck_2620_ = !lean_is_exclusive(v_x_2593_);
if (v_isSharedCheck_2620_ == 0)
{
v___x_2598_ = v_x_2593_;
v_isShared_2599_ = v_isSharedCheck_2620_;
goto v_resetjp_2597_;
}
else
{
lean_inc(v_tail_2596_);
lean_inc(v_value_2595_);
lean_inc(v_key_2594_);
lean_dec(v_x_2593_);
v___x_2598_ = lean_box(0);
v_isShared_2599_ = v_isSharedCheck_2620_;
goto v_resetjp_2597_;
}
v_resetjp_2597_:
{
lean_object* v___x_2600_; uint64_t v___x_2601_; uint64_t v___x_2602_; uint64_t v___x_2603_; uint64_t v___x_2604_; uint64_t v_fold_2605_; uint64_t v___x_2606_; uint64_t v___x_2607_; uint64_t v___x_2608_; size_t v___x_2609_; size_t v___x_2610_; size_t v___x_2611_; size_t v___x_2612_; size_t v___x_2613_; lean_object* v___x_2614_; lean_object* v___x_2616_; 
v___x_2600_ = lean_array_get_size(v_x_2592_);
v___x_2601_ = 32ULL;
v___x_2602_ = lean_unbox_uint64(v_key_2594_);
v___x_2603_ = lean_uint64_shift_right(v___x_2602_, v___x_2601_);
v___x_2604_ = lean_unbox_uint64(v_key_2594_);
v_fold_2605_ = lean_uint64_xor(v___x_2604_, v___x_2603_);
v___x_2606_ = 16ULL;
v___x_2607_ = lean_uint64_shift_right(v_fold_2605_, v___x_2606_);
v___x_2608_ = lean_uint64_xor(v_fold_2605_, v___x_2607_);
v___x_2609_ = lean_uint64_to_usize(v___x_2608_);
v___x_2610_ = lean_usize_of_nat(v___x_2600_);
v___x_2611_ = ((size_t)1ULL);
v___x_2612_ = lean_usize_sub(v___x_2610_, v___x_2611_);
v___x_2613_ = lean_usize_land(v___x_2609_, v___x_2612_);
v___x_2614_ = lean_array_uget_borrowed(v_x_2592_, v___x_2613_);
lean_inc(v___x_2614_);
if (v_isShared_2599_ == 0)
{
lean_ctor_set(v___x_2598_, 2, v___x_2614_);
v___x_2616_ = v___x_2598_;
goto v_reusejp_2615_;
}
else
{
lean_object* v_reuseFailAlloc_2619_; 
v_reuseFailAlloc_2619_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_2619_, 0, v_key_2594_);
lean_ctor_set(v_reuseFailAlloc_2619_, 1, v_value_2595_);
lean_ctor_set(v_reuseFailAlloc_2619_, 2, v___x_2614_);
v___x_2616_ = v_reuseFailAlloc_2619_;
goto v_reusejp_2615_;
}
v_reusejp_2615_:
{
lean_object* v___x_2617_; 
v___x_2617_ = lean_array_uset(v_x_2592_, v___x_2613_, v___x_2616_);
v_x_2592_ = v___x_2617_;
v_x_2593_ = v_tail_2596_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7___redArg(lean_object* v_i_2621_, lean_object* v_source_2622_, lean_object* v_target_2623_){
_start:
{
lean_object* v___x_2624_; uint8_t v___x_2625_; 
v___x_2624_ = lean_array_get_size(v_source_2622_);
v___x_2625_ = lean_nat_dec_lt(v_i_2621_, v___x_2624_);
if (v___x_2625_ == 0)
{
lean_dec_ref(v_source_2622_);
lean_dec(v_i_2621_);
return v_target_2623_;
}
else
{
lean_object* v_es_2626_; lean_object* v___x_2627_; lean_object* v_source_2628_; lean_object* v_target_2629_; lean_object* v___x_2630_; lean_object* v___x_2631_; 
v_es_2626_ = lean_array_fget(v_source_2622_, v_i_2621_);
v___x_2627_ = lean_box(0);
v_source_2628_ = lean_array_fset(v_source_2622_, v_i_2621_, v___x_2627_);
v_target_2629_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7_spec__9___redArg(v_target_2623_, v_es_2626_);
v___x_2630_ = lean_unsigned_to_nat(1u);
v___x_2631_ = lean_nat_add(v_i_2621_, v___x_2630_);
lean_dec(v_i_2621_);
v_i_2621_ = v___x_2631_;
v_source_2622_ = v_source_2628_;
v_target_2623_ = v_target_2629_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5___redArg(lean_object* v_data_2633_){
_start:
{
lean_object* v___x_2634_; lean_object* v___x_2635_; lean_object* v_nbuckets_2636_; lean_object* v___x_2637_; lean_object* v___x_2638_; lean_object* v___x_2639_; lean_object* v___x_2640_; lean_object* v___x_2641_; 
v___x_2634_ = lean_array_get_size(v_data_2633_);
v___x_2635_ = lean_unsigned_to_nat(2u);
v_nbuckets_2636_ = lean_nat_mul(v___x_2634_, v___x_2635_);
v___x_2637_ = lean_unsigned_to_nat(0u);
v___x_2638_ = lean_box(0);
v___x_2639_ = lean_mk_array(v_nbuckets_2636_, v___x_2638_);
v___x_2640_ = lean_array_propagate_mark(v_data_2633_, v___x_2639_);
v___x_2641_ = lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7___redArg(v___x_2637_, v_data_2633_, v___x_2640_);
return v___x_2641_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4___redArg(uint64_t v_a_2642_, lean_object* v_x_2643_){
_start:
{
if (lean_obj_tag(v_x_2643_) == 0)
{
uint8_t v___x_2644_; 
v___x_2644_ = 0;
return v___x_2644_;
}
else
{
lean_object* v_key_2645_; lean_object* v_tail_2646_; uint64_t v___x_2647_; uint8_t v___x_2648_; 
v_key_2645_ = lean_ctor_get(v_x_2643_, 0);
v_tail_2646_ = lean_ctor_get(v_x_2643_, 2);
v___x_2647_ = lean_unbox_uint64(v_key_2645_);
v___x_2648_ = lean_uint64_dec_eq(v___x_2647_, v_a_2642_);
if (v___x_2648_ == 0)
{
v_x_2643_ = v_tail_2646_;
goto _start;
}
else
{
return v___x_2648_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4___redArg___boxed(lean_object* v_a_2650_, lean_object* v_x_2651_){
_start:
{
uint64_t v_a_boxed_2652_; uint8_t v_res_2653_; lean_object* v_r_2654_; 
v_a_boxed_2652_ = lean_unbox_uint64(v_a_2650_);
lean_dec_ref(v_a_2650_);
v_res_2653_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4___redArg(v_a_boxed_2652_, v_x_2651_);
lean_dec(v_x_2651_);
v_r_2654_ = lean_box(v_res_2653_);
return v_r_2654_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___redArg(uint64_t v_a_2655_, lean_object* v_b_2656_, lean_object* v_x_2657_){
_start:
{
if (lean_obj_tag(v_x_2657_) == 0)
{
lean_dec(v_b_2656_);
return v_x_2657_;
}
else
{
lean_object* v_key_2658_; lean_object* v_value_2659_; lean_object* v_tail_2660_; lean_object* v___x_2662_; uint8_t v_isShared_2663_; uint8_t v_isSharedCheck_2674_; 
v_key_2658_ = lean_ctor_get(v_x_2657_, 0);
v_value_2659_ = lean_ctor_get(v_x_2657_, 1);
v_tail_2660_ = lean_ctor_get(v_x_2657_, 2);
v_isSharedCheck_2674_ = !lean_is_exclusive(v_x_2657_);
if (v_isSharedCheck_2674_ == 0)
{
v___x_2662_ = v_x_2657_;
v_isShared_2663_ = v_isSharedCheck_2674_;
goto v_resetjp_2661_;
}
else
{
lean_inc(v_tail_2660_);
lean_inc(v_value_2659_);
lean_inc(v_key_2658_);
lean_dec(v_x_2657_);
v___x_2662_ = lean_box(0);
v_isShared_2663_ = v_isSharedCheck_2674_;
goto v_resetjp_2661_;
}
v_resetjp_2661_:
{
uint64_t v___x_2664_; uint8_t v___x_2665_; 
v___x_2664_ = lean_unbox_uint64(v_key_2658_);
v___x_2665_ = lean_uint64_dec_eq(v___x_2664_, v_a_2655_);
if (v___x_2665_ == 0)
{
lean_object* v___x_2666_; lean_object* v___x_2668_; 
v___x_2666_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___redArg(v_a_2655_, v_b_2656_, v_tail_2660_);
if (v_isShared_2663_ == 0)
{
lean_ctor_set(v___x_2662_, 2, v___x_2666_);
v___x_2668_ = v___x_2662_;
goto v_reusejp_2667_;
}
else
{
lean_object* v_reuseFailAlloc_2669_; 
v_reuseFailAlloc_2669_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_2669_, 0, v_key_2658_);
lean_ctor_set(v_reuseFailAlloc_2669_, 1, v_value_2659_);
lean_ctor_set(v_reuseFailAlloc_2669_, 2, v___x_2666_);
v___x_2668_ = v_reuseFailAlloc_2669_;
goto v_reusejp_2667_;
}
v_reusejp_2667_:
{
return v___x_2668_;
}
}
else
{
lean_object* v___x_2670_; lean_object* v___x_2672_; 
lean_dec(v_value_2659_);
lean_dec(v_key_2658_);
v___x_2670_ = lean_box_uint64(v_a_2655_);
if (v_isShared_2663_ == 0)
{
lean_ctor_set(v___x_2662_, 1, v_b_2656_);
lean_ctor_set(v___x_2662_, 0, v___x_2670_);
v___x_2672_ = v___x_2662_;
goto v_reusejp_2671_;
}
else
{
lean_object* v_reuseFailAlloc_2673_; 
v_reuseFailAlloc_2673_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_2673_, 0, v___x_2670_);
lean_ctor_set(v_reuseFailAlloc_2673_, 1, v_b_2656_);
lean_ctor_set(v_reuseFailAlloc_2673_, 2, v_tail_2660_);
v___x_2672_ = v_reuseFailAlloc_2673_;
goto v_reusejp_2671_;
}
v_reusejp_2671_:
{
return v___x_2672_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___redArg___boxed(lean_object* v_a_2675_, lean_object* v_b_2676_, lean_object* v_x_2677_){
_start:
{
uint64_t v_a_boxed_2678_; lean_object* v_res_2679_; 
v_a_boxed_2678_ = lean_unbox_uint64(v_a_2675_);
lean_dec_ref(v_a_2675_);
v_res_2679_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___redArg(v_a_boxed_2678_, v_b_2676_, v_x_2677_);
return v_res_2679_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___redArg(lean_object* v_m_2680_, uint64_t v_a_2681_, lean_object* v_b_2682_){
_start:
{
lean_object* v_size_2683_; lean_object* v_buckets_2684_; lean_object* v___x_2686_; uint8_t v_isShared_2687_; uint8_t v_isSharedCheck_2727_; 
v_size_2683_ = lean_ctor_get(v_m_2680_, 0);
v_buckets_2684_ = lean_ctor_get(v_m_2680_, 1);
v_isSharedCheck_2727_ = !lean_is_exclusive(v_m_2680_);
if (v_isSharedCheck_2727_ == 0)
{
v___x_2686_ = v_m_2680_;
v_isShared_2687_ = v_isSharedCheck_2727_;
goto v_resetjp_2685_;
}
else
{
lean_inc(v_buckets_2684_);
lean_inc(v_size_2683_);
lean_dec(v_m_2680_);
v___x_2686_ = lean_box(0);
v_isShared_2687_ = v_isSharedCheck_2727_;
goto v_resetjp_2685_;
}
v_resetjp_2685_:
{
lean_object* v___x_2688_; uint64_t v___x_2689_; uint64_t v___x_2690_; uint64_t v_fold_2691_; uint64_t v___x_2692_; uint64_t v___x_2693_; uint64_t v___x_2694_; size_t v___x_2695_; size_t v___x_2696_; size_t v___x_2697_; size_t v___x_2698_; size_t v___x_2699_; lean_object* v_bkt_2700_; uint8_t v___x_2701_; 
v___x_2688_ = lean_array_get_size(v_buckets_2684_);
v___x_2689_ = 32ULL;
v___x_2690_ = lean_uint64_shift_right(v_a_2681_, v___x_2689_);
v_fold_2691_ = lean_uint64_xor(v_a_2681_, v___x_2690_);
v___x_2692_ = 16ULL;
v___x_2693_ = lean_uint64_shift_right(v_fold_2691_, v___x_2692_);
v___x_2694_ = lean_uint64_xor(v_fold_2691_, v___x_2693_);
v___x_2695_ = lean_uint64_to_usize(v___x_2694_);
v___x_2696_ = lean_usize_of_nat(v___x_2688_);
v___x_2697_ = ((size_t)1ULL);
v___x_2698_ = lean_usize_sub(v___x_2696_, v___x_2697_);
v___x_2699_ = lean_usize_land(v___x_2695_, v___x_2698_);
v_bkt_2700_ = lean_array_uget_borrowed(v_buckets_2684_, v___x_2699_);
v___x_2701_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4___redArg(v_a_2681_, v_bkt_2700_);
if (v___x_2701_ == 0)
{
lean_object* v___x_2702_; lean_object* v_size_x27_2703_; lean_object* v___x_2704_; lean_object* v___x_2705_; lean_object* v_buckets_x27_2706_; lean_object* v___x_2707_; lean_object* v___x_2708_; lean_object* v___x_2709_; lean_object* v___x_2710_; lean_object* v___x_2711_; uint8_t v___x_2712_; 
v___x_2702_ = lean_unsigned_to_nat(1u);
v_size_x27_2703_ = lean_nat_add(v_size_2683_, v___x_2702_);
lean_dec(v_size_2683_);
v___x_2704_ = lean_box_uint64(v_a_2681_);
lean_inc(v_bkt_2700_);
v___x_2705_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v___x_2705_, 0, v___x_2704_);
lean_ctor_set(v___x_2705_, 1, v_b_2682_);
lean_ctor_set(v___x_2705_, 2, v_bkt_2700_);
v_buckets_x27_2706_ = lean_array_uset(v_buckets_2684_, v___x_2699_, v___x_2705_);
v___x_2707_ = lean_unsigned_to_nat(4u);
v___x_2708_ = lean_nat_mul(v_size_x27_2703_, v___x_2707_);
v___x_2709_ = lean_unsigned_to_nat(3u);
v___x_2710_ = lean_nat_div(v___x_2708_, v___x_2709_);
lean_dec(v___x_2708_);
v___x_2711_ = lean_array_get_size(v_buckets_x27_2706_);
v___x_2712_ = lean_nat_dec_le(v___x_2710_, v___x_2711_);
lean_dec(v___x_2710_);
if (v___x_2712_ == 0)
{
lean_object* v_val_2713_; lean_object* v___x_2715_; 
v_val_2713_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5___redArg(v_buckets_x27_2706_);
if (v_isShared_2687_ == 0)
{
lean_ctor_set(v___x_2686_, 1, v_val_2713_);
lean_ctor_set(v___x_2686_, 0, v_size_x27_2703_);
v___x_2715_ = v___x_2686_;
goto v_reusejp_2714_;
}
else
{
lean_object* v_reuseFailAlloc_2716_; 
v_reuseFailAlloc_2716_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2716_, 0, v_size_x27_2703_);
lean_ctor_set(v_reuseFailAlloc_2716_, 1, v_val_2713_);
v___x_2715_ = v_reuseFailAlloc_2716_;
goto v_reusejp_2714_;
}
v_reusejp_2714_:
{
return v___x_2715_;
}
}
else
{
lean_object* v___x_2718_; 
if (v_isShared_2687_ == 0)
{
lean_ctor_set(v___x_2686_, 1, v_buckets_x27_2706_);
lean_ctor_set(v___x_2686_, 0, v_size_x27_2703_);
v___x_2718_ = v___x_2686_;
goto v_reusejp_2717_;
}
else
{
lean_object* v_reuseFailAlloc_2719_; 
v_reuseFailAlloc_2719_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2719_, 0, v_size_x27_2703_);
lean_ctor_set(v_reuseFailAlloc_2719_, 1, v_buckets_x27_2706_);
v___x_2718_ = v_reuseFailAlloc_2719_;
goto v_reusejp_2717_;
}
v_reusejp_2717_:
{
return v___x_2718_;
}
}
}
else
{
lean_object* v___x_2720_; lean_object* v_buckets_x27_2721_; lean_object* v___x_2722_; lean_object* v___x_2723_; lean_object* v___x_2725_; 
lean_inc(v_bkt_2700_);
v___x_2720_ = lean_box(0);
v_buckets_x27_2721_ = lean_array_uset(v_buckets_2684_, v___x_2699_, v___x_2720_);
v___x_2722_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___redArg(v_a_2681_, v_b_2682_, v_bkt_2700_);
v___x_2723_ = lean_array_uset(v_buckets_x27_2721_, v___x_2699_, v___x_2722_);
if (v_isShared_2687_ == 0)
{
lean_ctor_set(v___x_2686_, 1, v___x_2723_);
v___x_2725_ = v___x_2686_;
goto v_reusejp_2724_;
}
else
{
lean_object* v_reuseFailAlloc_2726_; 
v_reuseFailAlloc_2726_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2726_, 0, v_size_2683_);
lean_ctor_set(v_reuseFailAlloc_2726_, 1, v___x_2723_);
v___x_2725_ = v_reuseFailAlloc_2726_;
goto v_reusejp_2724_;
}
v_reusejp_2724_:
{
return v___x_2725_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___redArg___boxed(lean_object* v_m_2728_, lean_object* v_a_2729_, lean_object* v_b_2730_){
_start:
{
uint64_t v_a_boxed_2731_; lean_object* v_res_2732_; 
v_a_boxed_2731_ = lean_unbox_uint64(v_a_2729_);
lean_dec_ref(v_a_2729_);
v_res_2732_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___redArg(v_m_2728_, v_a_boxed_2731_, v_b_2730_);
return v_res_2732_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2___redArg(lean_object* v_values_2733_, uint8_t v_width_2734_, lean_object* v_range_2735_, lean_object* v_b_2736_, lean_object* v_i_2737_){
_start:
{
lean_object* v_stop_2738_; lean_object* v_step_2739_; lean_object* v_a_2741_; uint8_t v___x_2744_; 
v_stop_2738_ = lean_ctor_get(v_range_2735_, 1);
v_step_2739_ = lean_ctor_get(v_range_2735_, 2);
v___x_2744_ = lean_nat_dec_lt(v_i_2737_, v_stop_2738_);
if (v___x_2744_ == 0)
{
lean_dec(v_i_2737_);
return v_b_2736_;
}
else
{
lean_object* v___x_2745_; lean_object* v___x_2746_; uint64_t v___x_2747_; uint8_t v___x_2748_; lean_object* v_data_2749_; 
v___x_2745_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal_spec__0___redArg___boxed__const__1));
v___x_2746_ = lean_array_get_borrowed(v___x_2745_, v_values_2733_, v_i_2737_);
v___x_2747_ = lean_unbox_uint64(v___x_2746_);
v___x_2748_ = lean_uint64_to_uint8(v___x_2747_);
v_data_2749_ = lean_byte_array_push(v_b_2736_, v___x_2748_);
switch(v_width_2734_)
{
case 0:
{
v_a_2741_ = v_data_2749_;
goto v___jp_2740_;
}
case 1:
{
uint64_t v___x_2750_; uint64_t v___x_2751_; uint64_t v___x_2752_; uint8_t v___x_2753_; lean_object* v___x_2754_; 
v___x_2750_ = 8ULL;
v___x_2751_ = lean_unbox_uint64(v___x_2746_);
v___x_2752_ = lean_uint64_shift_right(v___x_2751_, v___x_2750_);
v___x_2753_ = lean_uint64_to_uint8(v___x_2752_);
v___x_2754_ = lean_byte_array_push(v_data_2749_, v___x_2753_);
v_a_2741_ = v___x_2754_;
goto v___jp_2740_;
}
default: 
{
uint64_t v___x_2755_; uint64_t v___x_2756_; uint64_t v___x_2757_; uint8_t v___x_2758_; lean_object* v___x_2759_; uint64_t v___x_2760_; uint64_t v___x_2761_; uint64_t v___x_2762_; uint8_t v___x_2763_; lean_object* v___x_2764_; uint64_t v___x_2765_; uint64_t v___x_2766_; uint64_t v___x_2767_; uint8_t v___x_2768_; lean_object* v___x_2769_; 
v___x_2755_ = 8ULL;
v___x_2756_ = lean_unbox_uint64(v___x_2746_);
v___x_2757_ = lean_uint64_shift_right(v___x_2756_, v___x_2755_);
v___x_2758_ = lean_uint64_to_uint8(v___x_2757_);
v___x_2759_ = lean_byte_array_push(v_data_2749_, v___x_2758_);
v___x_2760_ = 16ULL;
v___x_2761_ = lean_unbox_uint64(v___x_2746_);
v___x_2762_ = lean_uint64_shift_right(v___x_2761_, v___x_2760_);
v___x_2763_ = lean_uint64_to_uint8(v___x_2762_);
v___x_2764_ = lean_byte_array_push(v___x_2759_, v___x_2763_);
v___x_2765_ = 24ULL;
v___x_2766_ = lean_unbox_uint64(v___x_2746_);
v___x_2767_ = lean_uint64_shift_right(v___x_2766_, v___x_2765_);
v___x_2768_ = lean_uint64_to_uint8(v___x_2767_);
v___x_2769_ = lean_byte_array_push(v___x_2764_, v___x_2768_);
v_a_2741_ = v___x_2769_;
goto v___jp_2740_;
}
}
}
v___jp_2740_:
{
lean_object* v___x_2742_; 
v___x_2742_ = lean_nat_add(v_i_2737_, v_step_2739_);
lean_dec(v_i_2737_);
v_b_2736_ = v_a_2741_;
v_i_2737_ = v___x_2742_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2___redArg___boxed(lean_object* v_values_2770_, lean_object* v_width_2771_, lean_object* v_range_2772_, lean_object* v_b_2773_, lean_object* v_i_2774_){
_start:
{
uint8_t v_width_boxed_2775_; lean_object* v_res_2776_; 
v_width_boxed_2775_ = lean_unbox(v_width_2771_);
v_res_2776_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2___redArg(v_values_2770_, v_width_boxed_2775_, v_range_2772_, v_b_2773_, v_i_2774_);
lean_dec_ref(v_range_2772_);
lean_dec_ref(v_values_2770_);
return v_res_2776_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2(lean_object* v_values_2777_, lean_object* v_table_2778_, uint8_t v_width_2779_, uint64_t v_degree_2780_, uint64_t v_mask_2781_, uint64_t v_hash_2782_, lean_object* v_bucket_2783_, lean_object* v_work_2784_, lean_object* v_maxCount_2785_, lean_object* v_maxBytes_2786_, lean_object* v_maxWork_2787_){
_start:
{
lean_object* v_arity_2788_; uint8_t v_width_2789_; lean_object* v_exponents_2790_; lean_object* v_metadata_2791_; lean_object* v_count_2792_; lean_object* v_workspace_2793_; lean_object* v_buckets_2794_; lean_object* v_products_2795_; lean_object* v_hashBits_2796_; uint8_t v___x_2797_; 
v_arity_2788_ = lean_ctor_get(v_table_2778_, 0);
v_width_2789_ = lean_ctor_get_uint8(v_table_2778_, sizeof(void*)*9);
v_exponents_2790_ = lean_ctor_get(v_table_2778_, 1);
v_metadata_2791_ = lean_ctor_get(v_table_2778_, 2);
v_count_2792_ = lean_ctor_get(v_table_2778_, 3);
v_workspace_2793_ = lean_ctor_get(v_table_2778_, 4);
v_buckets_2794_ = lean_ctor_get(v_table_2778_, 5);
v_products_2795_ = lean_ctor_get(v_table_2778_, 6);
v_hashBits_2796_ = lean_ctor_get(v_table_2778_, 7);
v___x_2797_ = lean_nat_dec_le(v_maxCount_2785_, v_count_2792_);
if (v___x_2797_ == 0)
{
lean_object* v___x_2798_; lean_object* v___x_2799_; lean_object* v___y_2801_; lean_object* v_arity_2802_; uint8_t v_width_2803_; lean_object* v_exponents_2804_; lean_object* v_metadata_2805_; lean_object* v_count_2806_; lean_object* v_workspace_2807_; lean_object* v_buckets_2808_; lean_object* v_products_2809_; lean_object* v_hashBits_2810_; lean_object* v___y_2824_; lean_object* v___y_2825_; lean_object* v___y_2844_; uint8_t v___y_2845_; lean_object* v___y_2846_; lean_object* v___y_2863_; uint8_t v___y_2864_; lean_object* v___x_2866_; uint8_t v___x_2867_; lean_object* v___y_2869_; lean_object* v___y_2870_; lean_object* v___y_2876_; lean_object* v___y_2877_; lean_object* v___y_2878_; 
v___x_2798_ = lean_unsigned_to_nat(4294967295u);
v___x_2799_ = lean_unsigned_to_nat(1u);
v___x_2866_ = lean_nat_add(v_count_2792_, v___x_2799_);
v___x_2867_ = lean_nat_dec_lt(v___x_2798_, v___x_2866_);
if (v___x_2867_ == 0)
{
lean_object* v___x_2880_; lean_object* v___y_2882_; 
v___x_2880_ = lean_nat_mul(v___x_2866_, v_arity_2788_);
switch(v_width_2779_)
{
case 0:
{
v___y_2882_ = v___x_2799_;
goto v___jp_2881_;
}
case 1:
{
lean_object* v___x_2900_; 
v___x_2900_ = lean_unsigned_to_nat(2u);
v___y_2882_ = v___x_2900_;
goto v___jp_2881_;
}
default: 
{
lean_object* v___x_2901_; 
v___x_2901_ = lean_unsigned_to_nat(4u);
v___y_2882_ = v___x_2901_;
goto v___jp_2881_;
}
}
v___jp_2881_:
{
lean_object* v_size_2883_; lean_object* v___x_2884_; lean_object* v___x_2885_; lean_object* v___x_2886_; lean_object* v_size_2887_; lean_object* v___x_2888_; lean_object* v___x_2889_; lean_object* v___x_2890_; lean_object* v___x_2891_; lean_object* v___x_2892_; uint8_t v___x_2893_; 
v_size_2883_ = lean_ctor_get(v_products_2795_, 0);
v___x_2884_ = lean_nat_mul(v___x_2880_, v___y_2882_);
lean_dec(v___x_2880_);
v___x_2885_ = lean_unsigned_to_nat(24u);
v___x_2886_ = lean_nat_mul(v___x_2866_, v___x_2885_);
lean_dec(v___x_2866_);
v_size_2887_ = lean_nat_add(v___x_2884_, v___x_2886_);
lean_dec(v___x_2886_);
lean_dec(v___x_2884_);
v___x_2888_ = lean_unsigned_to_nat(12u);
v___x_2889_ = lean_nat_mul(v___x_2888_, v_size_2883_);
v___x_2890_ = lean_nat_add(v_size_2887_, v___x_2889_);
lean_dec(v___x_2889_);
lean_dec(v_size_2887_);
v___x_2891_ = lean_byte_array_size(v_workspace_2793_);
v___x_2892_ = lean_unsigned_to_nat(0u);
v___x_2893_ = lean_nat_dec_lt(v___x_2892_, v_arity_2788_);
if (v___x_2893_ == 0)
{
v___y_2876_ = v___x_2890_;
v___y_2877_ = v___x_2891_;
v___y_2878_ = v___x_2892_;
goto v___jp_2875_;
}
else
{
lean_object* v___x_2894_; uint8_t v___x_2895_; 
v___x_2894_ = lean_unsigned_to_nat(4096u);
v___x_2895_ = lean_nat_dec_le(v_arity_2788_, v___x_2894_);
if (v___x_2895_ == 0)
{
v___y_2876_ = v___x_2890_;
v___y_2877_ = v___x_2891_;
v___y_2878_ = v___x_2892_;
goto v___jp_2875_;
}
else
{
lean_object* v___x_2896_; lean_object* v___x_2897_; lean_object* v___x_2898_; lean_object* v___x_2899_; 
v___x_2896_ = lean_unsigned_to_nat(4u);
v___x_2897_ = lean_nat_mul(v_arity_2788_, v___x_2896_);
v___x_2898_ = lean_unsigned_to_nat(28u);
v___x_2899_ = lean_nat_add(v___x_2897_, v___x_2898_);
lean_dec(v___x_2897_);
v___y_2876_ = v___x_2890_;
v___y_2877_ = v___x_2891_;
v___y_2878_ = v___x_2899_;
goto v___jp_2875_;
}
}
}
}
else
{
uint8_t v___x_2902_; lean_object* v___x_2903_; lean_object* v___x_2904_; lean_object* v___x_2905_; 
lean_dec(v___x_2866_);
lean_dec(v_maxWork_2787_);
lean_dec_ref(v_bucket_2783_);
v___x_2902_ = 1;
v___x_2903_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2903_, 0, v_work_2784_);
lean_ctor_set_uint8(v___x_2903_, sizeof(void*)*1, v___x_2902_);
v___x_2904_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2904_, 0, v___x_2903_);
v___x_2905_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2905_, 0, v___x_2904_);
lean_ctor_set(v___x_2905_, 1, v_table_2778_);
return v___x_2905_;
}
v___jp_2800_:
{
lean_object* v___x_2811_; lean_object* v___x_2812_; lean_object* v___x_2813_; lean_object* v___x_2814_; lean_object* v___x_2815_; lean_object* v___x_2816_; lean_object* v___x_2817_; lean_object* v___x_2818_; lean_object* v___x_2819_; lean_object* v___x_2820_; lean_object* v___x_2821_; lean_object* v___x_2822_; 
v___x_2811_ = lean_unsigned_to_nat(0u);
lean_inc(v_arity_2802_);
v___x_2812_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2812_, 0, v___x_2811_);
lean_ctor_set(v___x_2812_, 1, v_arity_2802_);
lean_ctor_set(v___x_2812_, 2, v___x_2799_);
v___x_2813_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2___redArg(v_values_2777_, v_width_2779_, v___x_2812_, v_exponents_2804_, v___x_2811_);
lean_dec_ref_known(v___x_2812_, 3);
v___x_2814_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v_metadata_2805_, v_degree_2780_);
v___x_2815_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v___x_2814_, v_mask_2781_);
v___x_2816_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v___x_2815_, v_hash_2782_);
lean_inc(v_count_2806_);
v___x_2817_ = lean_array_push(v_bucket_2783_, v_count_2806_);
v___x_2818_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___redArg(v_buckets_2808_, v_hash_2782_, v___x_2817_);
v___x_2819_ = lean_nat_add(v_count_2806_, v___x_2799_);
v___x_2820_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_2820_, 0, v_arity_2802_);
lean_ctor_set(v___x_2820_, 1, v___x_2813_);
lean_ctor_set(v___x_2820_, 2, v___x_2816_);
lean_ctor_set(v___x_2820_, 3, v___x_2819_);
lean_ctor_set(v___x_2820_, 4, v_workspace_2807_);
lean_ctor_set(v___x_2820_, 5, v___x_2818_);
lean_ctor_set(v___x_2820_, 6, v_products_2809_);
lean_ctor_set(v___x_2820_, 7, v_hashBits_2810_);
lean_ctor_set(v___x_2820_, 8, v___y_2801_);
lean_ctor_set_uint8(v___x_2820_, sizeof(void*)*9, v_width_2803_);
v___x_2821_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2821_, 0, v_count_2806_);
v___x_2822_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2822_, 0, v___x_2821_);
lean_ctor_set(v___x_2822_, 1, v___x_2820_);
return v___x_2822_;
}
v___jp_2823_:
{
lean_object* v_work_2826_; uint8_t v___x_2827_; 
v_work_2826_ = lean_nat_add(v___y_2824_, v___y_2825_);
lean_dec(v___y_2825_);
lean_dec(v___y_2824_);
v___x_2827_ = lean_nat_dec_lt(v_maxWork_2787_, v_work_2826_);
if (v___x_2827_ == 0)
{
uint8_t v___x_2828_; 
lean_dec(v_maxWork_2787_);
v___x_2828_ = lp_Hex_Hex_Groebner_instBEqWidth_beq(v_width_2779_, v_width_2789_);
if (v___x_2828_ == 0)
{
lean_object* v___x_2829_; lean_object* v_arity_2830_; uint8_t v_width_2831_; lean_object* v_exponents_2832_; lean_object* v_metadata_2833_; lean_object* v_count_2834_; lean_object* v_workspace_2835_; lean_object* v_buckets_2836_; lean_object* v_products_2837_; lean_object* v_hashBits_2838_; 
v___x_2829_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen(v_table_2778_, v_width_2779_);
v_arity_2830_ = lean_ctor_get(v___x_2829_, 0);
lean_inc(v_arity_2830_);
v_width_2831_ = lean_ctor_get_uint8(v___x_2829_, sizeof(void*)*9);
v_exponents_2832_ = lean_ctor_get(v___x_2829_, 1);
lean_inc_ref(v_exponents_2832_);
v_metadata_2833_ = lean_ctor_get(v___x_2829_, 2);
lean_inc_ref(v_metadata_2833_);
v_count_2834_ = lean_ctor_get(v___x_2829_, 3);
lean_inc(v_count_2834_);
v_workspace_2835_ = lean_ctor_get(v___x_2829_, 4);
lean_inc_ref(v_workspace_2835_);
v_buckets_2836_ = lean_ctor_get(v___x_2829_, 5);
lean_inc_ref(v_buckets_2836_);
v_products_2837_ = lean_ctor_get(v___x_2829_, 6);
lean_inc_ref(v_products_2837_);
v_hashBits_2838_ = lean_ctor_get(v___x_2829_, 7);
lean_inc(v_hashBits_2838_);
lean_dec_ref(v___x_2829_);
v___y_2801_ = v_work_2826_;
v_arity_2802_ = v_arity_2830_;
v_width_2803_ = v_width_2831_;
v_exponents_2804_ = v_exponents_2832_;
v_metadata_2805_ = v_metadata_2833_;
v_count_2806_ = v_count_2834_;
v_workspace_2807_ = v_workspace_2835_;
v_buckets_2808_ = v_buckets_2836_;
v_products_2809_ = v_products_2837_;
v_hashBits_2810_ = v_hashBits_2838_;
goto v___jp_2800_;
}
else
{
lean_inc(v_hashBits_2796_);
lean_inc_ref(v_products_2795_);
lean_inc_ref(v_buckets_2794_);
lean_inc_ref(v_workspace_2793_);
lean_inc(v_count_2792_);
lean_inc_ref(v_metadata_2791_);
lean_inc_ref(v_exponents_2790_);
lean_inc(v_arity_2788_);
lean_dec_ref(v_table_2778_);
v___y_2801_ = v_work_2826_;
v_arity_2802_ = v_arity_2788_;
v_width_2803_ = v_width_2789_;
v_exponents_2804_ = v_exponents_2790_;
v_metadata_2805_ = v_metadata_2791_;
v_count_2806_ = v_count_2792_;
v_workspace_2807_ = v_workspace_2793_;
v_buckets_2808_ = v_buckets_2794_;
v_products_2809_ = v_products_2795_;
v_hashBits_2810_ = v_hashBits_2796_;
goto v___jp_2800_;
}
}
else
{
uint8_t v___x_2839_; lean_object* v___x_2840_; lean_object* v___x_2841_; lean_object* v___x_2842_; 
lean_dec(v_work_2826_);
lean_dec_ref(v_bucket_2783_);
v___x_2839_ = 8;
v___x_2840_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2840_, 0, v_maxWork_2787_);
lean_ctor_set_uint8(v___x_2840_, sizeof(void*)*1, v___x_2839_);
v___x_2841_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2841_, 0, v___x_2840_);
v___x_2842_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2842_, 0, v___x_2841_);
lean_ctor_set(v___x_2842_, 1, v_table_2778_);
return v___x_2842_;
}
}
v___jp_2843_:
{
lean_object* v_peak_2847_; uint8_t v___x_2848_; 
v_peak_2847_ = lean_nat_add(v___y_2844_, v___y_2846_);
lean_dec(v___y_2846_);
lean_dec(v___y_2844_);
v___x_2848_ = lean_nat_dec_lt(v_maxBytes_2786_, v_peak_2847_);
if (v___x_2848_ == 0)
{
lean_object* v___x_2849_; uint8_t v___x_2850_; 
v___x_2849_ = lean_obj_once(&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12, &lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12_once, _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12);
v___x_2850_ = lean_nat_dec_le(v___x_2849_, v_peak_2847_);
lean_dec(v_peak_2847_);
if (v___x_2850_ == 0)
{
lean_object* v___x_2851_; 
v___x_2851_ = lean_nat_add(v_work_2784_, v_arity_2788_);
lean_dec(v_work_2784_);
if (v___y_2845_ == 0)
{
lean_object* v___x_2852_; 
v___x_2852_ = lean_unsigned_to_nat(0u);
v___y_2824_ = v___x_2851_;
v___y_2825_ = v___x_2852_;
goto v___jp_2823_;
}
else
{
lean_object* v___x_2853_; 
v___x_2853_ = lean_nat_mul(v_count_2792_, v_arity_2788_);
v___y_2824_ = v___x_2851_;
v___y_2825_ = v___x_2853_;
goto v___jp_2823_;
}
}
else
{
uint8_t v___x_2854_; lean_object* v___x_2855_; lean_object* v___x_2856_; lean_object* v___x_2857_; 
lean_dec(v_maxWork_2787_);
lean_dec_ref(v_bucket_2783_);
v___x_2854_ = 4;
v___x_2855_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2855_, 0, v_work_2784_);
lean_ctor_set_uint8(v___x_2855_, sizeof(void*)*1, v___x_2854_);
v___x_2856_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2856_, 0, v___x_2855_);
v___x_2857_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2857_, 0, v___x_2856_);
lean_ctor_set(v___x_2857_, 1, v_table_2778_);
return v___x_2857_;
}
}
else
{
uint8_t v___x_2858_; lean_object* v___x_2859_; lean_object* v___x_2860_; lean_object* v___x_2861_; 
lean_dec(v_peak_2847_);
lean_dec(v_maxWork_2787_);
lean_dec_ref(v_bucket_2783_);
v___x_2858_ = 7;
v___x_2859_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2859_, 0, v_work_2784_);
lean_ctor_set_uint8(v___x_2859_, sizeof(void*)*1, v___x_2858_);
v___x_2860_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2860_, 0, v___x_2859_);
v___x_2861_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2861_, 0, v___x_2860_);
lean_ctor_set(v___x_2861_, 1, v_table_2778_);
return v___x_2861_;
}
}
v___jp_2862_:
{
lean_object* v___x_2865_; 
v___x_2865_ = lean_byte_array_size(v_exponents_2790_);
v___y_2844_ = v___y_2863_;
v___y_2845_ = v___y_2864_;
v___y_2846_ = v___x_2865_;
goto v___jp_2843_;
}
v___jp_2868_:
{
lean_object* v___x_2871_; uint8_t v___x_2872_; 
v___x_2871_ = lean_nat_add(v___y_2869_, v___y_2870_);
lean_dec(v___y_2870_);
lean_dec(v___y_2869_);
v___x_2872_ = lp_Hex_Hex_Groebner_instBEqWidth_beq(v_width_2779_, v_width_2789_);
if (v___x_2872_ == 0)
{
uint8_t v___x_2873_; 
v___x_2873_ = 1;
v___y_2863_ = v___x_2871_;
v___y_2864_ = v___x_2873_;
goto v___jp_2862_;
}
else
{
if (v___x_2867_ == 0)
{
lean_object* v___x_2874_; 
v___x_2874_ = lean_unsigned_to_nat(0u);
v___y_2844_ = v___x_2871_;
v___y_2845_ = v___x_2867_;
v___y_2846_ = v___x_2874_;
goto v___jp_2843_;
}
else
{
v___y_2863_ = v___x_2871_;
v___y_2864_ = v___x_2867_;
goto v___jp_2862_;
}
}
}
v___jp_2875_:
{
uint8_t v___x_2879_; 
v___x_2879_ = lean_nat_dec_le(v___y_2877_, v___y_2878_);
if (v___x_2879_ == 0)
{
lean_dec(v___y_2878_);
v___y_2869_ = v___y_2876_;
v___y_2870_ = v___y_2877_;
goto v___jp_2868_;
}
else
{
lean_dec(v___y_2877_);
v___y_2869_ = v___y_2876_;
v___y_2870_ = v___y_2878_;
goto v___jp_2868_;
}
}
}
else
{
uint8_t v___x_2906_; lean_object* v___x_2907_; lean_object* v___x_2908_; lean_object* v___x_2909_; 
lean_dec(v_maxWork_2787_);
lean_dec_ref(v_bucket_2783_);
v___x_2906_ = 6;
v___x_2907_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_2907_, 0, v_work_2784_);
lean_ctor_set_uint8(v___x_2907_, sizeof(void*)*1, v___x_2906_);
v___x_2908_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2908_, 0, v___x_2907_);
v___x_2909_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2909_, 0, v___x_2908_);
lean_ctor_set(v___x_2909_, 1, v_table_2778_);
return v___x_2909_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2___boxed(lean_object* v_values_2910_, lean_object* v_table_2911_, lean_object* v_width_2912_, lean_object* v_degree_2913_, lean_object* v_mask_2914_, lean_object* v_hash_2915_, lean_object* v_bucket_2916_, lean_object* v_work_2917_, lean_object* v_maxCount_2918_, lean_object* v_maxBytes_2919_, lean_object* v_maxWork_2920_){
_start:
{
uint8_t v_width_boxed_2921_; uint64_t v_degree_boxed_2922_; uint64_t v_mask_boxed_2923_; uint64_t v_hash_boxed_2924_; lean_object* v_res_2925_; 
v_width_boxed_2921_ = lean_unbox(v_width_2912_);
v_degree_boxed_2922_ = lean_unbox_uint64(v_degree_2913_);
lean_dec_ref(v_degree_2913_);
v_mask_boxed_2923_ = lean_unbox_uint64(v_mask_2914_);
lean_dec_ref(v_mask_2914_);
v_hash_boxed_2924_ = lean_unbox_uint64(v_hash_2915_);
lean_dec_ref(v_hash_2915_);
v_res_2925_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2(v_values_2910_, v_table_2911_, v_width_boxed_2921_, v_degree_boxed_2922_, v_mask_boxed_2923_, v_hash_boxed_2924_, v_bucket_2916_, v_work_2917_, v_maxCount_2918_, v_maxBytes_2919_, v_maxWork_2920_);
lean_dec(v_maxBytes_2919_);
lean_dec(v_maxCount_2918_);
lean_dec_ref(v_values_2910_);
return v_res_2925_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5___redArg(uint64_t v_a_2926_, lean_object* v_x_2927_){
_start:
{
if (lean_obj_tag(v_x_2927_) == 0)
{
lean_object* v___x_2928_; 
v___x_2928_ = lean_box(0);
return v___x_2928_;
}
else
{
lean_object* v_key_2929_; lean_object* v_value_2930_; lean_object* v_tail_2931_; uint64_t v___x_2932_; uint8_t v___x_2933_; 
v_key_2929_ = lean_ctor_get(v_x_2927_, 0);
v_value_2930_ = lean_ctor_get(v_x_2927_, 1);
v_tail_2931_ = lean_ctor_get(v_x_2927_, 2);
v___x_2932_ = lean_unbox_uint64(v_key_2929_);
v___x_2933_ = lean_uint64_dec_eq(v___x_2932_, v_a_2926_);
if (v___x_2933_ == 0)
{
v_x_2927_ = v_tail_2931_;
goto _start;
}
else
{
lean_object* v___x_2935_; 
lean_inc(v_value_2930_);
v___x_2935_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2935_, 0, v_value_2930_);
return v___x_2935_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5___redArg___boxed(lean_object* v_a_2936_, lean_object* v_x_2937_){
_start:
{
uint64_t v_a_boxed_2938_; lean_object* v_res_2939_; 
v_a_boxed_2938_ = lean_unbox_uint64(v_a_2936_);
lean_dec_ref(v_a_2936_);
v_res_2939_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5___redArg(v_a_boxed_2938_, v_x_2937_);
lean_dec(v_x_2937_);
return v_res_2939_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___redArg(lean_object* v_m_2940_, uint64_t v_a_2941_){
_start:
{
lean_object* v_buckets_2942_; lean_object* v___x_2943_; uint64_t v___x_2944_; uint64_t v___x_2945_; uint64_t v_fold_2946_; uint64_t v___x_2947_; uint64_t v___x_2948_; uint64_t v___x_2949_; size_t v___x_2950_; size_t v___x_2951_; size_t v___x_2952_; size_t v___x_2953_; size_t v___x_2954_; lean_object* v___x_2955_; lean_object* v___x_2956_; 
v_buckets_2942_ = lean_ctor_get(v_m_2940_, 1);
v___x_2943_ = lean_array_get_size(v_buckets_2942_);
v___x_2944_ = 32ULL;
v___x_2945_ = lean_uint64_shift_right(v_a_2941_, v___x_2944_);
v_fold_2946_ = lean_uint64_xor(v_a_2941_, v___x_2945_);
v___x_2947_ = 16ULL;
v___x_2948_ = lean_uint64_shift_right(v_fold_2946_, v___x_2947_);
v___x_2949_ = lean_uint64_xor(v_fold_2946_, v___x_2948_);
v___x_2950_ = lean_uint64_to_usize(v___x_2949_);
v___x_2951_ = lean_usize_of_nat(v___x_2943_);
v___x_2952_ = ((size_t)1ULL);
v___x_2953_ = lean_usize_sub(v___x_2951_, v___x_2952_);
v___x_2954_ = lean_usize_land(v___x_2950_, v___x_2953_);
v___x_2955_ = lean_array_uget_borrowed(v_buckets_2942_, v___x_2954_);
v___x_2956_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5___redArg(v_a_2941_, v___x_2955_);
return v___x_2956_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___redArg___boxed(lean_object* v_m_2957_, lean_object* v_a_2958_){
_start:
{
uint64_t v_a_boxed_2959_; lean_object* v_res_2960_; 
v_a_boxed_2959_ = lean_unbox_uint64(v_a_2958_);
lean_dec_ref(v_a_2958_);
v_res_2960_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___redArg(v_m_2957_, v_a_boxed_2959_);
lean_dec_ref(v_m_2957_);
return v_res_2960_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__1(lean_object* v___x_2961_, lean_object* v_maxWork_2962_, lean_object* v_table_2963_, lean_object* v_values_2964_, uint8_t v_width_2965_, lean_object* v___x_2966_, lean_object* v_as_2967_, size_t v_sz_2968_, size_t v_i_2969_, lean_object* v_b_2970_){
_start:
{
uint8_t v___x_2971_; 
v___x_2971_ = lean_usize_dec_lt(v_i_2969_, v_sz_2968_);
if (v___x_2971_ == 0)
{
lean_dec_ref(v___x_2966_);
lean_dec_ref(v_table_2963_);
lean_dec(v_maxWork_2962_);
lean_dec(v___x_2961_);
return v_b_2970_;
}
else
{
lean_object* v_snd_2972_; lean_object* v___x_2974_; uint8_t v_isShared_2975_; uint8_t v_isSharedCheck_3032_; 
v_snd_2972_ = lean_ctor_get(v_b_2970_, 1);
v_isSharedCheck_3032_ = !lean_is_exclusive(v_b_2970_);
if (v_isSharedCheck_3032_ == 0)
{
lean_object* v_unused_3033_; 
v_unused_3033_ = lean_ctor_get(v_b_2970_, 0);
lean_dec(v_unused_3033_);
v___x_2974_ = v_b_2970_;
v_isShared_2975_ = v_isSharedCheck_3032_;
goto v_resetjp_2973_;
}
else
{
lean_inc(v_snd_2972_);
lean_dec(v_b_2970_);
v___x_2974_ = lean_box(0);
v_isShared_2975_ = v_isSharedCheck_3032_;
goto v_resetjp_2973_;
}
v_resetjp_2973_:
{
lean_object* v___x_2976_; uint8_t v___x_2977_; 
v___x_2976_ = lean_nat_add(v_snd_2972_, v___x_2961_);
lean_dec(v_snd_2972_);
v___x_2977_ = lean_nat_dec_lt(v_maxWork_2962_, v___x_2976_);
if (v___x_2977_ == 0)
{
lean_object* v_exponents_2978_; lean_object* v_metadata_2979_; lean_object* v_count_2980_; lean_object* v_workspace_2981_; lean_object* v_products_2982_; lean_object* v_hashBits_2983_; lean_object* v_a_2984_; uint8_t v___x_2985_; 
v_exponents_2978_ = lean_ctor_get(v_table_2963_, 1);
v_metadata_2979_ = lean_ctor_get(v_table_2963_, 2);
v_count_2980_ = lean_ctor_get(v_table_2963_, 3);
v_workspace_2981_ = lean_ctor_get(v_table_2963_, 4);
v_products_2982_ = lean_ctor_get(v_table_2963_, 6);
v_hashBits_2983_ = lean_ctor_get(v_table_2963_, 7);
v_a_2984_ = lean_array_uget_borrowed(v_as_2967_, v_i_2969_);
v___x_2985_ = lean_nat_dec_le(v_count_2980_, v_a_2984_);
if (v___x_2985_ == 0)
{
uint8_t v___x_2986_; 
v___x_2986_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_equal(v_table_2963_, v_a_2984_, v_values_2964_);
if (v___x_2986_ == 0)
{
lean_object* v___x_2987_; lean_object* v___x_2989_; 
v___x_2987_ = lean_box(0);
if (v_isShared_2975_ == 0)
{
lean_ctor_set(v___x_2974_, 1, v___x_2976_);
lean_ctor_set(v___x_2974_, 0, v___x_2987_);
v___x_2989_ = v___x_2974_;
goto v_reusejp_2988_;
}
else
{
lean_object* v_reuseFailAlloc_2993_; 
v_reuseFailAlloc_2993_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2993_, 0, v___x_2987_);
lean_ctor_set(v_reuseFailAlloc_2993_, 1, v___x_2976_);
v___x_2989_ = v_reuseFailAlloc_2993_;
goto v_reusejp_2988_;
}
v_reusejp_2988_:
{
size_t v___x_2990_; size_t v___x_2991_; 
v___x_2990_ = ((size_t)1ULL);
v___x_2991_ = lean_usize_add(v_i_2969_, v___x_2990_);
v_i_2969_ = v___x_2991_;
v_b_2970_ = v___x_2989_;
goto _start;
}
}
else
{
lean_object* v___x_2995_; uint8_t v_isShared_2996_; uint8_t v_isSharedCheck_3006_; 
lean_inc(v_hashBits_2983_);
lean_inc_ref(v_products_2982_);
lean_inc_ref(v_workspace_2981_);
lean_inc(v_count_2980_);
lean_inc_ref(v_metadata_2979_);
lean_inc_ref(v_exponents_2978_);
lean_dec(v_maxWork_2962_);
v_isSharedCheck_3006_ = !lean_is_exclusive(v_table_2963_);
if (v_isSharedCheck_3006_ == 0)
{
lean_object* v_unused_3007_; lean_object* v_unused_3008_; lean_object* v_unused_3009_; lean_object* v_unused_3010_; lean_object* v_unused_3011_; lean_object* v_unused_3012_; lean_object* v_unused_3013_; lean_object* v_unused_3014_; lean_object* v_unused_3015_; 
v_unused_3007_ = lean_ctor_get(v_table_2963_, 8);
lean_dec(v_unused_3007_);
v_unused_3008_ = lean_ctor_get(v_table_2963_, 7);
lean_dec(v_unused_3008_);
v_unused_3009_ = lean_ctor_get(v_table_2963_, 6);
lean_dec(v_unused_3009_);
v_unused_3010_ = lean_ctor_get(v_table_2963_, 5);
lean_dec(v_unused_3010_);
v_unused_3011_ = lean_ctor_get(v_table_2963_, 4);
lean_dec(v_unused_3011_);
v_unused_3012_ = lean_ctor_get(v_table_2963_, 3);
lean_dec(v_unused_3012_);
v_unused_3013_ = lean_ctor_get(v_table_2963_, 2);
lean_dec(v_unused_3013_);
v_unused_3014_ = lean_ctor_get(v_table_2963_, 1);
lean_dec(v_unused_3014_);
v_unused_3015_ = lean_ctor_get(v_table_2963_, 0);
lean_dec(v_unused_3015_);
v___x_2995_ = v_table_2963_;
v_isShared_2996_ = v_isSharedCheck_3006_;
goto v_resetjp_2994_;
}
else
{
lean_dec(v_table_2963_);
v___x_2995_ = lean_box(0);
v_isShared_2996_ = v_isSharedCheck_3006_;
goto v_resetjp_2994_;
}
v_resetjp_2994_:
{
lean_object* v___x_2997_; lean_object* v___x_2999_; 
lean_inc(v_a_2984_);
v___x_2997_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2997_, 0, v_a_2984_);
lean_inc(v___x_2976_);
if (v_isShared_2996_ == 0)
{
lean_ctor_set(v___x_2995_, 8, v___x_2976_);
lean_ctor_set(v___x_2995_, 5, v___x_2966_);
lean_ctor_set(v___x_2995_, 0, v___x_2961_);
v___x_2999_ = v___x_2995_;
goto v_reusejp_2998_;
}
else
{
lean_object* v_reuseFailAlloc_3005_; 
v_reuseFailAlloc_3005_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_reuseFailAlloc_3005_, 0, v___x_2961_);
lean_ctor_set(v_reuseFailAlloc_3005_, 1, v_exponents_2978_);
lean_ctor_set(v_reuseFailAlloc_3005_, 2, v_metadata_2979_);
lean_ctor_set(v_reuseFailAlloc_3005_, 3, v_count_2980_);
lean_ctor_set(v_reuseFailAlloc_3005_, 4, v_workspace_2981_);
lean_ctor_set(v_reuseFailAlloc_3005_, 5, v___x_2966_);
lean_ctor_set(v_reuseFailAlloc_3005_, 6, v_products_2982_);
lean_ctor_set(v_reuseFailAlloc_3005_, 7, v_hashBits_2983_);
lean_ctor_set(v_reuseFailAlloc_3005_, 8, v___x_2976_);
v___x_2999_ = v_reuseFailAlloc_3005_;
goto v_reusejp_2998_;
}
v_reusejp_2998_:
{
lean_object* v___x_3000_; lean_object* v___x_3001_; lean_object* v___x_3003_; 
lean_ctor_set_uint8(v___x_2999_, sizeof(void*)*9, v_width_2965_);
v___x_3000_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3000_, 0, v___x_2997_);
lean_ctor_set(v___x_3000_, 1, v___x_2999_);
v___x_3001_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3001_, 0, v___x_3000_);
if (v_isShared_2975_ == 0)
{
lean_ctor_set(v___x_2974_, 1, v___x_2976_);
lean_ctor_set(v___x_2974_, 0, v___x_3001_);
v___x_3003_ = v___x_2974_;
goto v_reusejp_3002_;
}
else
{
lean_object* v_reuseFailAlloc_3004_; 
v_reuseFailAlloc_3004_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3004_, 0, v___x_3001_);
lean_ctor_set(v_reuseFailAlloc_3004_, 1, v___x_2976_);
v___x_3003_ = v_reuseFailAlloc_3004_;
goto v_reusejp_3002_;
}
v_reusejp_3002_:
{
return v___x_3003_;
}
}
}
}
}
else
{
uint8_t v___x_3016_; lean_object* v___x_3017_; lean_object* v___x_3018_; lean_object* v___x_3019_; lean_object* v___x_3020_; lean_object* v___x_3022_; 
lean_dec_ref(v___x_2966_);
lean_dec(v_maxWork_2962_);
lean_dec(v___x_2961_);
v___x_3016_ = 5;
lean_inc(v___x_2976_);
v___x_3017_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_3017_, 0, v___x_2976_);
lean_ctor_set_uint8(v___x_3017_, sizeof(void*)*1, v___x_3016_);
v___x_3018_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3018_, 0, v___x_3017_);
v___x_3019_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3019_, 0, v___x_3018_);
lean_ctor_set(v___x_3019_, 1, v_table_2963_);
v___x_3020_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3020_, 0, v___x_3019_);
if (v_isShared_2975_ == 0)
{
lean_ctor_set(v___x_2974_, 1, v___x_2976_);
lean_ctor_set(v___x_2974_, 0, v___x_3020_);
v___x_3022_ = v___x_2974_;
goto v_reusejp_3021_;
}
else
{
lean_object* v_reuseFailAlloc_3023_; 
v_reuseFailAlloc_3023_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3023_, 0, v___x_3020_);
lean_ctor_set(v_reuseFailAlloc_3023_, 1, v___x_2976_);
v___x_3022_ = v_reuseFailAlloc_3023_;
goto v_reusejp_3021_;
}
v_reusejp_3021_:
{
return v___x_3022_;
}
}
}
else
{
uint8_t v___x_3024_; lean_object* v___x_3025_; lean_object* v___x_3026_; lean_object* v___x_3027_; lean_object* v___x_3028_; lean_object* v___x_3030_; 
lean_dec_ref(v___x_2966_);
lean_dec(v___x_2961_);
v___x_3024_ = 8;
v___x_3025_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_3025_, 0, v_maxWork_2962_);
lean_ctor_set_uint8(v___x_3025_, sizeof(void*)*1, v___x_3024_);
v___x_3026_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3026_, 0, v___x_3025_);
v___x_3027_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3027_, 0, v___x_3026_);
lean_ctor_set(v___x_3027_, 1, v_table_2963_);
v___x_3028_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3028_, 0, v___x_3027_);
if (v_isShared_2975_ == 0)
{
lean_ctor_set(v___x_2974_, 1, v___x_2976_);
lean_ctor_set(v___x_2974_, 0, v___x_3028_);
v___x_3030_ = v___x_2974_;
goto v_reusejp_3029_;
}
else
{
lean_object* v_reuseFailAlloc_3031_; 
v_reuseFailAlloc_3031_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3031_, 0, v___x_3028_);
lean_ctor_set(v_reuseFailAlloc_3031_, 1, v___x_2976_);
v___x_3030_ = v_reuseFailAlloc_3031_;
goto v_reusejp_3029_;
}
v_reusejp_3029_:
{
return v___x_3030_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__1___boxed(lean_object* v___x_3034_, lean_object* v_maxWork_3035_, lean_object* v_table_3036_, lean_object* v_values_3037_, lean_object* v_width_3038_, lean_object* v___x_3039_, lean_object* v_as_3040_, lean_object* v_sz_3041_, lean_object* v_i_3042_, lean_object* v_b_3043_){
_start:
{
uint8_t v_width_boxed_3044_; size_t v_sz_boxed_3045_; size_t v_i_boxed_3046_; lean_object* v_res_3047_; 
v_width_boxed_3044_ = lean_unbox(v_width_3038_);
v_sz_boxed_3045_ = lean_unbox_usize(v_sz_3041_);
lean_dec(v_sz_3041_);
v_i_boxed_3046_ = lean_unbox_usize(v_i_3042_);
lean_dec(v_i_3042_);
v_res_3047_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__1(v___x_3034_, v_maxWork_3035_, v_table_3036_, v_values_3037_, v_width_boxed_3044_, v___x_3039_, v_as_3040_, v_sz_boxed_3045_, v_i_boxed_3046_, v_b_3043_);
lean_dec_ref(v_as_3040_);
lean_dec_ref(v_values_3037_);
return v_res_3047_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__2(void){
_start:
{
lean_object* v___x_3056_; 
v___x_3056_ = lean_cstr_to_nat("18446744073709551616");
return v___x_3056_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_internOwned(lean_object* v_table_3057_, lean_object* v_values_3058_, lean_object* v_maxCount_3059_, lean_object* v_maxBytes_3060_, lean_object* v_maxWork_3061_){
_start:
{
lean_object* v_arity_3062_; uint8_t v_width_3063_; lean_object* v_exponents_3064_; lean_object* v_metadata_3065_; lean_object* v_count_3066_; lean_object* v_workspace_3067_; lean_object* v_buckets_3068_; lean_object* v_products_3069_; lean_object* v_hashBits_3070_; lean_object* v_work_3071_; lean_object* v___y_3078_; lean_object* v___y_3079_; lean_object* v___y_3080_; uint64_t v___y_3081_; lean_object* v___y_3082_; lean_object* v___y_3083_; lean_object* v___y_3084_; lean_object* v___y_3097_; lean_object* v___y_3098_; lean_object* v___y_3099_; lean_object* v___y_3100_; lean_object* v___y_3101_; lean_object* v___y_3102_; uint64_t v_hash_3103_; lean_object* v___x_3107_; lean_object* v___y_3109_; lean_object* v___y_3110_; lean_object* v___y_3111_; lean_object* v___y_3171_; lean_object* v___y_3172_; lean_object* v___y_3173_; lean_object* v___y_3174_; uint8_t v___x_3176_; 
v_arity_3062_ = lean_ctor_get(v_table_3057_, 0);
v_width_3063_ = lean_ctor_get_uint8(v_table_3057_, sizeof(void*)*9);
v_exponents_3064_ = lean_ctor_get(v_table_3057_, 1);
v_metadata_3065_ = lean_ctor_get(v_table_3057_, 2);
v_count_3066_ = lean_ctor_get(v_table_3057_, 3);
v_workspace_3067_ = lean_ctor_get(v_table_3057_, 4);
v_buckets_3068_ = lean_ctor_get(v_table_3057_, 5);
v_products_3069_ = lean_ctor_get(v_table_3057_, 6);
lean_inc_ref(v_products_3069_);
v_hashBits_3070_ = lean_ctor_get(v_table_3057_, 7);
v_work_3071_ = lean_ctor_get(v_table_3057_, 8);
v___x_3107_ = lean_array_get_size(v_values_3058_);
v___x_3176_ = lean_nat_dec_eq(v___x_3107_, v_arity_3062_);
if (v___x_3176_ == 0)
{
uint8_t v___x_3177_; lean_object* v___x_3178_; lean_object* v___x_3179_; lean_object* v___x_3180_; 
lean_dec_ref(v_products_3069_);
lean_dec(v_maxWork_3061_);
v___x_3177_ = 0;
lean_inc(v_work_3071_);
v___x_3178_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_3178_, 0, v_work_3071_);
lean_ctor_set_uint8(v___x_3178_, sizeof(void*)*1, v___x_3177_);
v___x_3179_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3179_, 0, v___x_3178_);
v___x_3180_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3180_, 0, v___x_3179_);
lean_ctor_set(v___x_3180_, 1, v_table_3057_);
return v___x_3180_;
}
else
{
lean_object* v___x_3181_; lean_object* v___x_3182_; lean_object* v___y_3184_; 
v___x_3181_ = lean_byte_array_size(v_exponents_3064_);
v___x_3182_ = lean_nat_mul(v_count_3066_, v_arity_3062_);
switch(v_width_3063_)
{
case 0:
{
lean_object* v___x_3208_; 
v___x_3208_ = lean_unsigned_to_nat(1u);
v___y_3184_ = v___x_3208_;
goto v___jp_3183_;
}
case 1:
{
lean_object* v___x_3209_; 
v___x_3209_ = lean_unsigned_to_nat(2u);
v___y_3184_ = v___x_3209_;
goto v___jp_3183_;
}
default: 
{
lean_object* v___x_3210_; 
v___x_3210_ = lean_unsigned_to_nat(4u);
v___y_3184_ = v___x_3210_;
goto v___jp_3183_;
}
}
v___jp_3183_:
{
lean_object* v___x_3185_; uint8_t v___x_3186_; 
v___x_3185_ = lean_nat_mul(v___x_3182_, v___y_3184_);
lean_dec(v___x_3182_);
v___x_3186_ = lean_nat_dec_eq(v___x_3181_, v___x_3185_);
lean_dec(v___x_3185_);
if (v___x_3186_ == 0)
{
lean_dec_ref(v_products_3069_);
lean_dec(v_maxWork_3061_);
goto v___jp_3072_;
}
else
{
lean_object* v___x_3187_; lean_object* v___x_3188_; lean_object* v___x_3189_; uint8_t v___x_3190_; 
v___x_3187_ = lean_byte_array_size(v_metadata_3065_);
v___x_3188_ = lean_unsigned_to_nat(24u);
v___x_3189_ = lean_nat_mul(v_count_3066_, v___x_3188_);
v___x_3190_ = lean_nat_dec_eq(v___x_3187_, v___x_3189_);
lean_dec(v___x_3189_);
if (v___x_3190_ == 0)
{
lean_dec_ref(v_products_3069_);
lean_dec(v_maxWork_3061_);
goto v___jp_3072_;
}
else
{
lean_object* v_work_3191_; uint8_t v___x_3192_; 
v_work_3191_ = lean_nat_add(v_work_3071_, v___x_3107_);
v___x_3192_ = lean_nat_dec_lt(v_maxWork_3061_, v_work_3191_);
if (v___x_3192_ == 0)
{
lean_object* v___x_3193_; lean_object* v___x_3194_; lean_object* v___x_3195_; uint8_t v___x_3196_; 
v___x_3193_ = lean_nat_add(v___x_3181_, v___x_3187_);
v___x_3194_ = lean_byte_array_size(v_workspace_3067_);
v___x_3195_ = lean_unsigned_to_nat(0u);
v___x_3196_ = lean_nat_dec_eq(v_count_3066_, v___x_3195_);
if (v___x_3196_ == 0)
{
uint8_t v___x_3197_; 
v___x_3197_ = lean_nat_dec_lt(v___x_3195_, v_arity_3062_);
if (v___x_3197_ == 0)
{
v___y_3171_ = v___x_3193_;
v___y_3172_ = v___x_3194_;
v___y_3173_ = v_work_3191_;
v___y_3174_ = v___x_3195_;
goto v___jp_3170_;
}
else
{
lean_object* v___x_3198_; uint8_t v___x_3199_; 
v___x_3198_ = lean_unsigned_to_nat(4096u);
v___x_3199_ = lean_nat_dec_le(v_arity_3062_, v___x_3198_);
if (v___x_3199_ == 0)
{
v___y_3171_ = v___x_3193_;
v___y_3172_ = v___x_3194_;
v___y_3173_ = v_work_3191_;
v___y_3174_ = v___x_3195_;
goto v___jp_3170_;
}
else
{
lean_object* v___x_3200_; lean_object* v___x_3201_; lean_object* v___x_3202_; lean_object* v___x_3203_; 
v___x_3200_ = lean_unsigned_to_nat(4u);
v___x_3201_ = lean_nat_mul(v_arity_3062_, v___x_3200_);
v___x_3202_ = lean_unsigned_to_nat(28u);
v___x_3203_ = lean_nat_add(v___x_3201_, v___x_3202_);
lean_dec(v___x_3201_);
v___y_3171_ = v___x_3193_;
v___y_3172_ = v___x_3194_;
v___y_3173_ = v_work_3191_;
v___y_3174_ = v___x_3203_;
goto v___jp_3170_;
}
}
}
else
{
v___y_3171_ = v___x_3193_;
v___y_3172_ = v___x_3194_;
v___y_3173_ = v_work_3191_;
v___y_3174_ = v___x_3195_;
goto v___jp_3170_;
}
}
else
{
uint8_t v___x_3204_; lean_object* v___x_3205_; lean_object* v___x_3206_; lean_object* v___x_3207_; 
lean_dec(v_work_3191_);
lean_dec_ref(v_products_3069_);
v___x_3204_ = 8;
v___x_3205_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_3205_, 0, v_maxWork_3061_);
lean_ctor_set_uint8(v___x_3205_, sizeof(void*)*1, v___x_3204_);
v___x_3206_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3206_, 0, v___x_3205_);
v___x_3207_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3207_, 0, v___x_3206_);
lean_ctor_set(v___x_3207_, 1, v_table_3057_);
return v___x_3207_;
}
}
}
}
}
v___jp_3072_:
{
uint8_t v___x_3073_; lean_object* v___x_3074_; lean_object* v___x_3075_; lean_object* v___x_3076_; 
v___x_3073_ = 5;
lean_inc(v_work_3071_);
v___x_3074_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_3074_, 0, v_work_3071_);
lean_ctor_set_uint8(v___x_3074_, sizeof(void*)*1, v___x_3073_);
v___x_3075_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3075_, 0, v___x_3074_);
v___x_3076_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3076_, 0, v___x_3075_);
lean_ctor_set(v___x_3076_, 1, v_table_3057_);
return v___x_3076_;
}
v___jp_3077_:
{
lean_object* v___x_3085_; size_t v_sz_3086_; size_t v___x_3087_; lean_object* v___x_3088_; lean_object* v_fst_3089_; 
lean_inc(v___y_3080_);
v___x_3085_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3085_, 0, v___y_3080_);
lean_ctor_set(v___x_3085_, 1, v___y_3083_);
v_sz_3086_ = lean_array_size(v___y_3084_);
v___x_3087_ = ((size_t)0ULL);
lean_inc_ref(v_buckets_3068_);
lean_inc_ref(v_table_3057_);
lean_inc(v_maxWork_3061_);
lean_inc(v_arity_3062_);
v___x_3088_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__1(v_arity_3062_, v_maxWork_3061_, v_table_3057_, v_values_3058_, v_width_3063_, v_buckets_3068_, v___y_3084_, v_sz_3086_, v___x_3087_, v___x_3085_);
v_fst_3089_ = lean_ctor_get(v___x_3088_, 0);
lean_inc(v_fst_3089_);
if (lean_obj_tag(v_fst_3089_) == 0)
{
lean_object* v_snd_3090_; uint64_t v___x_3091_; uint8_t v___x_3092_; uint64_t v___x_3093_; lean_object* v___x_3094_; 
v_snd_3090_ = lean_ctor_get(v___x_3088_, 1);
lean_inc(v_snd_3090_);
lean_dec_ref(v___x_3088_);
v___x_3091_ = lean_uint64_of_nat(v___y_3079_);
lean_dec(v___y_3079_);
v___x_3092_ = lean_unbox(v___y_3082_);
lean_dec(v___y_3082_);
v___x_3093_ = lean_unbox_uint64(v___y_3078_);
lean_dec(v___y_3078_);
v___x_3094_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2(v_values_3058_, v_table_3057_, v___x_3092_, v___x_3091_, v___x_3093_, v___y_3081_, v___y_3084_, v_snd_3090_, v_maxCount_3059_, v_maxBytes_3060_, v_maxWork_3061_);
return v___x_3094_;
}
else
{
lean_object* v_val_3095_; 
lean_dec_ref(v___x_3088_);
lean_dec_ref(v___y_3084_);
lean_dec(v___y_3082_);
lean_dec(v___y_3079_);
lean_dec(v___y_3078_);
lean_dec(v_maxWork_3061_);
lean_dec_ref(v_table_3057_);
v_val_3095_ = lean_ctor_get(v_fst_3089_, 0);
lean_inc(v_val_3095_);
lean_dec_ref_known(v_fst_3089_, 1);
return v_val_3095_;
}
}
v___jp_3096_:
{
lean_object* v___x_3104_; 
v___x_3104_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___redArg(v_buckets_3068_, v_hash_3103_);
if (lean_obj_tag(v___x_3104_) == 0)
{
lean_object* v___x_3105_; 
v___x_3105_ = lean_mk_empty_array_with_capacity(v___y_3100_);
lean_dec(v___y_3100_);
v___y_3078_ = v___y_3097_;
v___y_3079_ = v___y_3098_;
v___y_3080_ = v___y_3099_;
v___y_3081_ = v_hash_3103_;
v___y_3082_ = v___y_3102_;
v___y_3083_ = v___y_3101_;
v___y_3084_ = v___x_3105_;
goto v___jp_3077_;
}
else
{
lean_object* v_val_3106_; 
lean_dec(v___y_3100_);
v_val_3106_ = lean_ctor_get(v___x_3104_, 0);
lean_inc(v_val_3106_);
lean_dec_ref_known(v___x_3104_, 1);
v___y_3078_ = v___y_3097_;
v___y_3079_ = v___y_3098_;
v___y_3080_ = v___y_3099_;
v___y_3081_ = v_hash_3103_;
v___y_3082_ = v___y_3102_;
v___y_3083_ = v___y_3101_;
v___y_3084_ = v_val_3106_;
goto v___jp_3077_;
}
}
v___jp_3108_:
{
lean_object* v_size_3112_; lean_object* v___x_3114_; uint8_t v_isShared_3115_; uint8_t v_isSharedCheck_3168_; 
v_size_3112_ = lean_ctor_get(v_products_3069_, 0);
v_isSharedCheck_3168_ = !lean_is_exclusive(v_products_3069_);
if (v_isSharedCheck_3168_ == 0)
{
lean_object* v_unused_3169_; 
v_unused_3169_ = lean_ctor_get(v_products_3069_, 1);
lean_dec(v_unused_3169_);
v___x_3114_ = v_products_3069_;
v_isShared_3115_ = v_isSharedCheck_3168_;
goto v_resetjp_3113_;
}
else
{
lean_inc(v_size_3112_);
lean_dec(v_products_3069_);
v___x_3114_ = lean_box(0);
v_isShared_3115_ = v_isSharedCheck_3168_;
goto v_resetjp_3113_;
}
v_resetjp_3113_:
{
lean_object* v___x_3116_; lean_object* v___x_3117_; lean_object* v___x_3118_; lean_object* v___x_3119_; uint8_t v___x_3120_; 
v___x_3116_ = lean_nat_add(v___y_3109_, v___y_3111_);
lean_dec(v___y_3111_);
lean_dec(v___y_3109_);
v___x_3117_ = lean_unsigned_to_nat(12u);
v___x_3118_ = lean_nat_mul(v___x_3117_, v_size_3112_);
lean_dec(v_size_3112_);
v___x_3119_ = lean_nat_add(v___x_3116_, v___x_3118_);
lean_dec(v___x_3118_);
lean_dec(v___x_3116_);
v___x_3120_ = lean_nat_dec_lt(v_maxBytes_3060_, v___x_3119_);
lean_dec(v___x_3119_);
if (v___x_3120_ == 0)
{
lean_object* v_degree_3121_; lean_object* v___x_3122_; lean_object* v___x_3123_; lean_object* v___x_3124_; lean_object* v___x_3125_; lean_object* v___x_3126_; lean_object* v___x_3128_; 
v_degree_3121_ = lean_unsigned_to_nat(0u);
v___x_3122_ = lean_unsigned_to_nat(1u);
v___x_3123_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_3123_, 0, v_degree_3121_);
lean_ctor_set(v___x_3123_, 1, v___x_3107_);
lean_ctor_set(v___x_3123_, 2, v___x_3122_);
v___x_3124_ = lean_box(0);
v___x_3125_ = ((lean_object*)(lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__1));
v___x_3126_ = lean_box(v_width_3063_);
if (v_isShared_3115_ == 0)
{
lean_ctor_set(v___x_3114_, 1, v___x_3125_);
lean_ctor_set(v___x_3114_, 0, v___x_3126_);
v___x_3128_ = v___x_3114_;
goto v_reusejp_3127_;
}
else
{
lean_object* v_reuseFailAlloc_3161_; 
v_reuseFailAlloc_3161_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3161_, 0, v___x_3126_);
lean_ctor_set(v_reuseFailAlloc_3161_, 1, v___x_3125_);
v___x_3128_ = v_reuseFailAlloc_3161_;
goto v_reusejp_3127_;
}
v_reusejp_3127_:
{
lean_object* v___x_3129_; lean_object* v___x_3130_; lean_object* v_fst_3131_; 
v___x_3129_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3129_, 0, v___x_3124_);
lean_ctor_set(v___x_3129_, 1, v___x_3128_);
lean_inc_ref(v_table_3057_);
lean_inc(v___y_3110_);
v___x_3130_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0___redArg(v_values_3058_, v___y_3110_, v_table_3057_, v___x_3123_, v___x_3129_, v_degree_3121_);
lean_dec_ref_known(v___x_3123_, 3);
v_fst_3131_ = lean_ctor_get(v___x_3130_, 0);
lean_inc(v_fst_3131_);
if (lean_obj_tag(v_fst_3131_) == 0)
{
lean_object* v_snd_3132_; lean_object* v_snd_3133_; lean_object* v_fst_3134_; lean_object* v_fst_3135_; lean_object* v_snd_3136_; lean_object* v___x_3138_; uint8_t v_isShared_3139_; uint8_t v_isSharedCheck_3159_; 
v_snd_3132_ = lean_ctor_get(v___x_3130_, 1);
lean_inc(v_snd_3132_);
lean_dec_ref(v___x_3130_);
v_snd_3133_ = lean_ctor_get(v_snd_3132_, 1);
lean_inc(v_snd_3133_);
v_fst_3134_ = lean_ctor_get(v_snd_3132_, 0);
lean_inc(v_fst_3134_);
lean_dec(v_snd_3132_);
v_fst_3135_ = lean_ctor_get(v_snd_3133_, 0);
v_snd_3136_ = lean_ctor_get(v_snd_3133_, 1);
v_isSharedCheck_3159_ = !lean_is_exclusive(v_snd_3133_);
if (v_isSharedCheck_3159_ == 0)
{
v___x_3138_ = v_snd_3133_;
v_isShared_3139_ = v_isSharedCheck_3159_;
goto v_resetjp_3137_;
}
else
{
lean_inc(v_snd_3136_);
lean_inc(v_fst_3135_);
lean_dec(v_snd_3133_);
v___x_3138_ = lean_box(0);
v_isShared_3139_ = v_isSharedCheck_3159_;
goto v_resetjp_3137_;
}
v_resetjp_3137_:
{
lean_object* v___x_3140_; uint8_t v___x_3141_; 
v___x_3140_ = lean_obj_once(&lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__2, &lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__2_once, _init_lp_Hex_Hex_Groebner_MonomialTable_internOwned___closed__2);
v___x_3141_ = lean_nat_dec_le(v___x_3140_, v_fst_3135_);
if (v___x_3141_ == 0)
{
lean_object* v_fst_3142_; lean_object* v_snd_3143_; lean_object* v___x_3144_; uint8_t v___x_3145_; 
lean_del_object(v___x_3138_);
v_fst_3142_ = lean_ctor_get(v_snd_3136_, 0);
lean_inc(v_fst_3142_);
v_snd_3143_ = lean_ctor_get(v_snd_3136_, 1);
lean_inc(v_snd_3143_);
lean_dec(v_snd_3136_);
v___x_3144_ = lean_unsigned_to_nat(64u);
v___x_3145_ = lean_nat_dec_lt(v_hashBits_3070_, v___x_3144_);
if (v___x_3145_ == 0)
{
uint64_t v___x_3146_; 
v___x_3146_ = lean_unbox_uint64(v_snd_3143_);
lean_dec(v_snd_3143_);
v___y_3097_ = v_fst_3142_;
v___y_3098_ = v_fst_3135_;
v___y_3099_ = v___x_3124_;
v___y_3100_ = v_degree_3121_;
v___y_3101_ = v___y_3110_;
v___y_3102_ = v_fst_3134_;
v_hash_3103_ = v___x_3146_;
goto v___jp_3096_;
}
else
{
uint64_t v___x_3147_; uint64_t v___x_3148_; uint64_t v___x_3149_; uint64_t v___x_3150_; uint64_t v___x_3151_; uint64_t v___x_3152_; 
v___x_3147_ = 1ULL;
v___x_3148_ = lean_uint64_of_nat(v_hashBits_3070_);
v___x_3149_ = lean_uint64_shift_left(v___x_3147_, v___x_3148_);
v___x_3150_ = lean_uint64_sub(v___x_3149_, v___x_3147_);
v___x_3151_ = lean_unbox_uint64(v_snd_3143_);
lean_dec(v_snd_3143_);
v___x_3152_ = lean_uint64_land(v___x_3151_, v___x_3150_);
v___y_3097_ = v_fst_3142_;
v___y_3098_ = v_fst_3135_;
v___y_3099_ = v___x_3124_;
v___y_3100_ = v_degree_3121_;
v___y_3101_ = v___y_3110_;
v___y_3102_ = v_fst_3134_;
v_hash_3103_ = v___x_3152_;
goto v___jp_3096_;
}
}
else
{
uint8_t v___x_3153_; lean_object* v___x_3154_; lean_object* v___x_3155_; lean_object* v___x_3157_; 
lean_dec(v_snd_3136_);
lean_dec(v_fst_3135_);
lean_dec(v_fst_3134_);
lean_dec(v_maxWork_3061_);
v___x_3153_ = 3;
v___x_3154_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_3154_, 0, v___y_3110_);
lean_ctor_set_uint8(v___x_3154_, sizeof(void*)*1, v___x_3153_);
v___x_3155_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3155_, 0, v___x_3154_);
if (v_isShared_3139_ == 0)
{
lean_ctor_set(v___x_3138_, 1, v_table_3057_);
lean_ctor_set(v___x_3138_, 0, v___x_3155_);
v___x_3157_ = v___x_3138_;
goto v_reusejp_3156_;
}
else
{
lean_object* v_reuseFailAlloc_3158_; 
v_reuseFailAlloc_3158_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3158_, 0, v___x_3155_);
lean_ctor_set(v_reuseFailAlloc_3158_, 1, v_table_3057_);
v___x_3157_ = v_reuseFailAlloc_3158_;
goto v_reusejp_3156_;
}
v_reusejp_3156_:
{
return v___x_3157_;
}
}
}
}
else
{
lean_object* v_val_3160_; 
lean_dec_ref(v___x_3130_);
lean_dec(v___y_3110_);
lean_dec(v_maxWork_3061_);
lean_dec_ref(v_table_3057_);
v_val_3160_ = lean_ctor_get(v_fst_3131_, 0);
lean_inc(v_val_3160_);
lean_dec_ref_known(v_fst_3131_, 1);
return v_val_3160_;
}
}
}
else
{
uint8_t v___x_3162_; lean_object* v___x_3163_; lean_object* v___x_3164_; lean_object* v___x_3166_; 
lean_dec(v_maxWork_3061_);
v___x_3162_ = 7;
v___x_3163_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_3163_, 0, v___y_3110_);
lean_ctor_set_uint8(v___x_3163_, sizeof(void*)*1, v___x_3162_);
v___x_3164_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3164_, 0, v___x_3163_);
if (v_isShared_3115_ == 0)
{
lean_ctor_set(v___x_3114_, 1, v_table_3057_);
lean_ctor_set(v___x_3114_, 0, v___x_3164_);
v___x_3166_ = v___x_3114_;
goto v_reusejp_3165_;
}
else
{
lean_object* v_reuseFailAlloc_3167_; 
v_reuseFailAlloc_3167_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3167_, 0, v___x_3164_);
lean_ctor_set(v_reuseFailAlloc_3167_, 1, v_table_3057_);
v___x_3166_ = v_reuseFailAlloc_3167_;
goto v_reusejp_3165_;
}
v_reusejp_3165_:
{
return v___x_3166_;
}
}
}
}
v___jp_3170_:
{
uint8_t v___x_3175_; 
v___x_3175_ = lean_nat_dec_le(v___y_3172_, v___y_3174_);
if (v___x_3175_ == 0)
{
lean_dec(v___y_3174_);
v___y_3109_ = v___y_3171_;
v___y_3110_ = v___y_3173_;
v___y_3111_ = v___y_3172_;
goto v___jp_3108_;
}
else
{
lean_dec(v___y_3172_);
v___y_3109_ = v___y_3171_;
v___y_3110_ = v___y_3173_;
v___y_3111_ = v___y_3174_;
goto v___jp_3108_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_internOwned___boxed(lean_object* v_table_3211_, lean_object* v_values_3212_, lean_object* v_maxCount_3213_, lean_object* v_maxBytes_3214_, lean_object* v_maxWork_3215_){
_start:
{
lean_object* v_res_3216_; 
v_res_3216_ = lp_Hex_Hex_Groebner_MonomialTable_internOwned(v_table_3211_, v_values_3212_, v_maxCount_3213_, v_maxBytes_3214_, v_maxWork_3215_);
lean_dec(v_maxBytes_3214_);
lean_dec(v_maxCount_3213_);
lean_dec_ref(v_values_3212_);
return v_res_3216_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0(lean_object* v_values_3217_, lean_object* v_work_3218_, lean_object* v_table_3219_, lean_object* v_range_3220_, lean_object* v_b_3221_, lean_object* v_i_3222_, lean_object* v_hs_3223_, lean_object* v_hl_3224_){
_start:
{
lean_object* v___x_3225_; 
v___x_3225_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0___redArg(v_values_3217_, v_work_3218_, v_table_3219_, v_range_3220_, v_b_3221_, v_i_3222_);
return v___x_3225_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0___boxed(lean_object* v_values_3226_, lean_object* v_work_3227_, lean_object* v_table_3228_, lean_object* v_range_3229_, lean_object* v_b_3230_, lean_object* v_i_3231_, lean_object* v_hs_3232_, lean_object* v_hl_3233_){
_start:
{
lean_object* v_res_3234_; 
v_res_3234_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_internOwned_spec__0(v_values_3226_, v_work_3227_, v_table_3228_, v_range_3229_, v_b_3230_, v_i_3231_, v_hs_3232_, v_hl_3233_);
lean_dec_ref(v_range_3229_);
lean_dec_ref(v_values_3226_);
return v_res_3234_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3(lean_object* v_00_u03b2_3235_, lean_object* v_m_3236_, uint64_t v_a_3237_){
_start:
{
lean_object* v___x_3238_; 
v___x_3238_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___redArg(v_m_3236_, v_a_3237_);
return v___x_3238_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___boxed(lean_object* v_00_u03b2_3239_, lean_object* v_m_3240_, lean_object* v_a_3241_){
_start:
{
uint64_t v_a_boxed_3242_; lean_object* v_res_3243_; 
v_a_boxed_3242_ = lean_unbox_uint64(v_a_3241_);
lean_dec_ref(v_a_3241_);
v_res_3243_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3(v_00_u03b2_3239_, v_m_3240_, v_a_boxed_3242_);
lean_dec_ref(v_m_3240_);
return v_res_3243_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2(lean_object* v_values_3244_, uint8_t v_width_3245_, lean_object* v_range_3246_, lean_object* v_b_3247_, lean_object* v_i_3248_, lean_object* v_hs_3249_, lean_object* v_hl_3250_){
_start:
{
lean_object* v___x_3251_; 
v___x_3251_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2___redArg(v_values_3244_, v_width_3245_, v_range_3246_, v_b_3247_, v_i_3248_);
return v___x_3251_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2___boxed(lean_object* v_values_3252_, lean_object* v_width_3253_, lean_object* v_range_3254_, lean_object* v_b_3255_, lean_object* v_i_3256_, lean_object* v_hs_3257_, lean_object* v_hl_3258_){
_start:
{
uint8_t v_width_boxed_3259_; lean_object* v_res_3260_; 
v_width_boxed_3259_ = lean_unbox(v_width_3253_);
v_res_3260_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__2(v_values_3252_, v_width_boxed_3259_, v_range_3254_, v_b_3255_, v_i_3256_, v_hs_3257_, v_hl_3258_);
lean_dec_ref(v_range_3254_);
lean_dec_ref(v_values_3252_);
return v_res_3260_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3(lean_object* v_00_u03b2_3261_, lean_object* v_m_3262_, uint64_t v_a_3263_, lean_object* v_b_3264_){
_start:
{
lean_object* v___x_3265_; 
v___x_3265_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___redArg(v_m_3262_, v_a_3263_, v_b_3264_);
return v___x_3265_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___boxed(lean_object* v_00_u03b2_3266_, lean_object* v_m_3267_, lean_object* v_a_3268_, lean_object* v_b_3269_){
_start:
{
uint64_t v_a_boxed_3270_; lean_object* v_res_3271_; 
v_a_boxed_3270_ = lean_unbox_uint64(v_a_3268_);
lean_dec_ref(v_a_3268_);
v_res_3271_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3(v_00_u03b2_3266_, v_m_3267_, v_a_boxed_3270_, v_b_3269_);
return v_res_3271_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5(lean_object* v_00_u03b2_3272_, uint64_t v_a_3273_, lean_object* v_x_3274_){
_start:
{
lean_object* v___x_3275_; 
v___x_3275_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5___redArg(v_a_3273_, v_x_3274_);
return v___x_3275_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5___boxed(lean_object* v_00_u03b2_3276_, lean_object* v_a_3277_, lean_object* v_x_3278_){
_start:
{
uint64_t v_a_boxed_3279_; lean_object* v_res_3280_; 
v_a_boxed_3279_ = lean_unbox_uint64(v_a_3277_);
lean_dec_ref(v_a_3277_);
v_res_3280_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3_spec__5(v_00_u03b2_3276_, v_a_boxed_3279_, v_x_3278_);
lean_dec(v_x_3278_);
return v_res_3280_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4(lean_object* v_00_u03b2_3281_, uint64_t v_a_3282_, lean_object* v_x_3283_){
_start:
{
uint8_t v___x_3284_; 
v___x_3284_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4___redArg(v_a_3282_, v_x_3283_);
return v___x_3284_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4___boxed(lean_object* v_00_u03b2_3285_, lean_object* v_a_3286_, lean_object* v_x_3287_){
_start:
{
uint64_t v_a_boxed_3288_; uint8_t v_res_3289_; lean_object* v_r_3290_; 
v_a_boxed_3288_ = lean_unbox_uint64(v_a_3286_);
lean_dec_ref(v_a_3286_);
v_res_3289_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__4(v_00_u03b2_3285_, v_a_boxed_3288_, v_x_3287_);
lean_dec(v_x_3287_);
v_r_3290_ = lean_box(v_res_3289_);
return v_r_3290_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5(lean_object* v_00_u03b2_3291_, lean_object* v_data_3292_){
_start:
{
lean_object* v___x_3293_; 
v___x_3293_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5___redArg(v_data_3292_);
return v___x_3293_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6(lean_object* v_00_u03b2_3294_, uint64_t v_a_3295_, lean_object* v_b_3296_, lean_object* v_x_3297_){
_start:
{
lean_object* v___x_3298_; 
v___x_3298_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___redArg(v_a_3295_, v_b_3296_, v_x_3297_);
return v___x_3298_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6___boxed(lean_object* v_00_u03b2_3299_, lean_object* v_a_3300_, lean_object* v_b_3301_, lean_object* v_x_3302_){
_start:
{
uint64_t v_a_boxed_3303_; lean_object* v_res_3304_; 
v_a_boxed_3303_ = lean_unbox_uint64(v_a_3300_);
lean_dec_ref(v_a_3300_);
v_res_3304_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__6(v_00_u03b2_3299_, v_a_boxed_3303_, v_b_3301_, v_x_3302_);
return v_res_3304_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7(lean_object* v_00_u03b2_3305_, lean_object* v_i_3306_, lean_object* v_source_3307_, lean_object* v_target_3308_){
_start:
{
lean_object* v___x_3309_; 
v___x_3309_ = lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7___redArg(v_i_3306_, v_source_3307_, v_target_3308_);
return v___x_3309_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7_spec__9(lean_object* v_00_u03b2_3310_, lean_object* v_x_3311_, lean_object* v_x_3312_){
_start:
{
lean_object* v___x_3313_; 
v___x_3313_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3_spec__5_spec__7_spec__9___redArg(v_x_3311_, v_x_3312_);
return v___x_3313_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_intern(lean_object* v_table_3314_, lean_object* v_values_3315_, lean_object* v_maxCount_3316_, lean_object* v_maxBytes_3317_, lean_object* v_maxWork_3318_){
_start:
{
lean_object* v_outcome_3319_; lean_object* v_result_3320_; 
v_outcome_3319_ = lp_Hex_Hex_Groebner_MonomialTable_internOwned(v_table_3314_, v_values_3315_, v_maxCount_3316_, v_maxBytes_3317_, v_maxWork_3318_);
v_result_3320_ = lean_ctor_get(v_outcome_3319_, 0);
lean_inc_ref(v_result_3320_);
if (lean_obj_tag(v_result_3320_) == 0)
{
lean_object* v_a_3321_; lean_object* v___x_3323_; uint8_t v_isShared_3324_; uint8_t v_isSharedCheck_3328_; 
lean_dec_ref(v_outcome_3319_);
v_a_3321_ = lean_ctor_get(v_result_3320_, 0);
v_isSharedCheck_3328_ = !lean_is_exclusive(v_result_3320_);
if (v_isSharedCheck_3328_ == 0)
{
v___x_3323_ = v_result_3320_;
v_isShared_3324_ = v_isSharedCheck_3328_;
goto v_resetjp_3322_;
}
else
{
lean_inc(v_a_3321_);
lean_dec(v_result_3320_);
v___x_3323_ = lean_box(0);
v_isShared_3324_ = v_isSharedCheck_3328_;
goto v_resetjp_3322_;
}
v_resetjp_3322_:
{
lean_object* v___x_3326_; 
if (v_isShared_3324_ == 0)
{
v___x_3326_ = v___x_3323_;
goto v_reusejp_3325_;
}
else
{
lean_object* v_reuseFailAlloc_3327_; 
v_reuseFailAlloc_3327_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3327_, 0, v_a_3321_);
v___x_3326_ = v_reuseFailAlloc_3327_;
goto v_reusejp_3325_;
}
v_reusejp_3325_:
{
return v___x_3326_;
}
}
}
else
{
lean_object* v_table_3329_; lean_object* v___x_3331_; uint8_t v_isShared_3332_; uint8_t v_isSharedCheck_3344_; 
v_table_3329_ = lean_ctor_get(v_outcome_3319_, 1);
v_isSharedCheck_3344_ = !lean_is_exclusive(v_outcome_3319_);
if (v_isSharedCheck_3344_ == 0)
{
lean_object* v_unused_3345_; 
v_unused_3345_ = lean_ctor_get(v_outcome_3319_, 0);
lean_dec(v_unused_3345_);
v___x_3331_ = v_outcome_3319_;
v_isShared_3332_ = v_isSharedCheck_3344_;
goto v_resetjp_3330_;
}
else
{
lean_inc(v_table_3329_);
lean_dec(v_outcome_3319_);
v___x_3331_ = lean_box(0);
v_isShared_3332_ = v_isSharedCheck_3344_;
goto v_resetjp_3330_;
}
v_resetjp_3330_:
{
lean_object* v_a_3333_; lean_object* v___x_3335_; uint8_t v_isShared_3336_; uint8_t v_isSharedCheck_3343_; 
v_a_3333_ = lean_ctor_get(v_result_3320_, 0);
v_isSharedCheck_3343_ = !lean_is_exclusive(v_result_3320_);
if (v_isSharedCheck_3343_ == 0)
{
v___x_3335_ = v_result_3320_;
v_isShared_3336_ = v_isSharedCheck_3343_;
goto v_resetjp_3334_;
}
else
{
lean_inc(v_a_3333_);
lean_dec(v_result_3320_);
v___x_3335_ = lean_box(0);
v_isShared_3336_ = v_isSharedCheck_3343_;
goto v_resetjp_3334_;
}
v_resetjp_3334_:
{
lean_object* v___x_3338_; 
if (v_isShared_3332_ == 0)
{
lean_ctor_set(v___x_3331_, 0, v_a_3333_);
v___x_3338_ = v___x_3331_;
goto v_reusejp_3337_;
}
else
{
lean_object* v_reuseFailAlloc_3342_; 
v_reuseFailAlloc_3342_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3342_, 0, v_a_3333_);
lean_ctor_set(v_reuseFailAlloc_3342_, 1, v_table_3329_);
v___x_3338_ = v_reuseFailAlloc_3342_;
goto v_reusejp_3337_;
}
v_reusejp_3337_:
{
lean_object* v___x_3340_; 
if (v_isShared_3336_ == 0)
{
lean_ctor_set(v___x_3335_, 0, v___x_3338_);
v___x_3340_ = v___x_3335_;
goto v_reusejp_3339_;
}
else
{
lean_object* v_reuseFailAlloc_3341_; 
v_reuseFailAlloc_3341_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3341_, 0, v___x_3338_);
v___x_3340_ = v_reuseFailAlloc_3341_;
goto v_reusejp_3339_;
}
v_reusejp_3339_:
{
return v___x_3340_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_intern___boxed(lean_object* v_table_3346_, lean_object* v_values_3347_, lean_object* v_maxCount_3348_, lean_object* v_maxBytes_3349_, lean_object* v_maxWork_3350_){
_start:
{
lean_object* v_res_3351_; 
v_res_3351_ = lp_Hex_Hex_Groebner_MonomialTable_intern(v_table_3346_, v_values_3347_, v_maxCount_3348_, v_maxBytes_3349_, v_maxWork_3350_);
lean_dec(v_maxBytes_3349_);
lean_dec(v_maxCount_3348_);
lean_dec_ref(v_values_3347_);
return v_res_3351_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorIdx(uint8_t v_x_3352_){
_start:
{
switch(v_x_3352_)
{
case 0:
{
lean_object* v___x_3353_; 
v___x_3353_ = lean_unsigned_to_nat(0u);
return v___x_3353_;
}
case 1:
{
lean_object* v___x_3354_; 
v___x_3354_ = lean_unsigned_to_nat(1u);
return v___x_3354_;
}
default: 
{
lean_object* v___x_3355_; 
v___x_3355_ = lean_unsigned_to_nat(2u);
return v___x_3355_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorIdx___boxed(lean_object* v_x_3356_){
_start:
{
uint8_t v_x_boxed_3357_; lean_object* v_res_3358_; 
v_x_boxed_3357_ = lean_unbox(v_x_3356_);
v_res_3358_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorIdx(v_x_boxed_3357_);
return v_res_3358_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim___redArg(lean_object* v_k_3359_){
_start:
{
lean_inc(v_k_3359_);
return v_k_3359_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim___redArg___boxed(lean_object* v_k_3360_){
_start:
{
lean_object* v_res_3361_; 
v_res_3361_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim___redArg(v_k_3360_);
lean_dec(v_k_3360_);
return v_res_3361_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim(lean_object* v_motive_3362_, lean_object* v_ctorIdx_3363_, uint8_t v_t_3364_, lean_object* v_h_3365_, lean_object* v_k_3366_){
_start:
{
lean_inc(v_k_3366_);
return v_k_3366_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim___boxed(lean_object* v_motive_3367_, lean_object* v_ctorIdx_3368_, lean_object* v_t_3369_, lean_object* v_h_3370_, lean_object* v_k_3371_){
_start:
{
uint8_t v_t_boxed_3372_; lean_object* v_res_3373_; 
v_t_boxed_3372_ = lean_unbox(v_t_3369_);
v_res_3373_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorElim(v_motive_3367_, v_ctorIdx_3368_, v_t_boxed_3372_, v_h_3370_, v_k_3371_);
lean_dec(v_k_3371_);
lean_dec(v_ctorIdx_3368_);
return v_res_3373_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim___redArg(lean_object* v_lcm_3374_){
_start:
{
lean_inc(v_lcm_3374_);
return v_lcm_3374_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim___redArg___boxed(lean_object* v_lcm_3375_){
_start:
{
lean_object* v_res_3376_; 
v_res_3376_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim___redArg(v_lcm_3375_);
lean_dec(v_lcm_3375_);
return v_res_3376_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim(lean_object* v_motive_3377_, uint8_t v_t_3378_, lean_object* v_h_3379_, lean_object* v_lcm_3380_){
_start:
{
lean_inc(v_lcm_3380_);
return v_lcm_3380_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim___boxed(lean_object* v_motive_3381_, lean_object* v_t_3382_, lean_object* v_h_3383_, lean_object* v_lcm_3384_){
_start:
{
uint8_t v_t_boxed_3385_; lean_object* v_res_3386_; 
v_t_boxed_3385_ = lean_unbox(v_t_3382_);
v_res_3386_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_lcm_elim(v_motive_3381_, v_t_boxed_3385_, v_h_3383_, v_lcm_3384_);
lean_dec(v_lcm_3384_);
return v_res_3386_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim___redArg(lean_object* v_product_3387_){
_start:
{
lean_inc(v_product_3387_);
return v_product_3387_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim___redArg___boxed(lean_object* v_product_3388_){
_start:
{
lean_object* v_res_3389_; 
v_res_3389_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim___redArg(v_product_3388_);
lean_dec(v_product_3388_);
return v_res_3389_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim(lean_object* v_motive_3390_, uint8_t v_t_3391_, lean_object* v_h_3392_, lean_object* v_product_3393_){
_start:
{
lean_inc(v_product_3393_);
return v_product_3393_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim___boxed(lean_object* v_motive_3394_, lean_object* v_t_3395_, lean_object* v_h_3396_, lean_object* v_product_3397_){
_start:
{
uint8_t v_t_boxed_3398_; lean_object* v_res_3399_; 
v_t_boxed_3398_ = lean_unbox(v_t_3395_);
v_res_3399_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_product_elim(v_motive_3394_, v_t_boxed_3398_, v_h_3396_, v_product_3397_);
lean_dec(v_product_3397_);
return v_res_3399_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim___redArg(lean_object* v_quotient_3400_){
_start:
{
lean_inc(v_quotient_3400_);
return v_quotient_3400_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim___redArg___boxed(lean_object* v_quotient_3401_){
_start:
{
lean_object* v_res_3402_; 
v_res_3402_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim___redArg(v_quotient_3401_);
lean_dec(v_quotient_3401_);
return v_res_3402_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim(lean_object* v_motive_3403_, uint8_t v_t_3404_, lean_object* v_h_3405_, lean_object* v_quotient_3406_){
_start:
{
lean_inc(v_quotient_3406_);
return v_quotient_3406_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim___boxed(lean_object* v_motive_3407_, lean_object* v_t_3408_, lean_object* v_h_3409_, lean_object* v_quotient_3410_){
_start:
{
uint8_t v_t_boxed_3411_; lean_object* v_res_3412_; 
v_t_boxed_3411_ = lean_unbox(v_t_3408_);
v_res_3412_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_quotient_elim(v_motive_3407_, v_t_boxed_3411_, v_h_3409_, v_quotient_3410_);
lean_dec(v_quotient_3410_);
return v_res_3412_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation_beq(uint8_t v_x_3413_, uint8_t v_y_3414_){
_start:
{
lean_object* v___x_3415_; lean_object* v___x_3416_; uint8_t v___x_3417_; 
v___x_3415_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorIdx(v_x_3413_);
v___x_3416_ = lp_Hex_Hex_Groebner_MonomialTable_Operation_ctorIdx(v_y_3414_);
v___x_3417_ = lean_nat_dec_eq(v___x_3415_, v___x_3416_);
lean_dec(v___x_3416_);
lean_dec(v___x_3415_);
return v___x_3417_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation_beq___boxed(lean_object* v_x_3418_, lean_object* v_y_3419_){
_start:
{
uint8_t v_x_21__boxed_3420_; uint8_t v_y_22__boxed_3421_; uint8_t v_res_3422_; lean_object* v_r_3423_; 
v_x_21__boxed_3420_ = lean_unbox(v_x_3418_);
v_y_22__boxed_3421_ = lean_unbox(v_y_3419_);
v_res_3422_ = lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation_beq(v_x_21__boxed_3420_, v_y_22__boxed_3421_);
v_r_3423_ = lean_box(v_res_3422_);
return v_r_3423_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0___redArg(uint8_t v_operation_3426_, lean_object* v_work_3427_, lean_object* v_table_3428_, lean_object* v_b_3429_, lean_object* v_a_3430_, lean_object* v_range_3431_, lean_object* v_b_3432_, lean_object* v_i_3433_){
_start:
{
lean_object* v_stop_3434_; lean_object* v_step_3435_; uint8_t v___x_3436_; 
v_stop_3434_ = lean_ctor_get(v_range_3431_, 1);
v_step_3435_ = lean_ctor_get(v_range_3431_, 2);
v___x_3436_ = lean_nat_dec_lt(v_i_3433_, v_stop_3434_);
if (v___x_3436_ == 0)
{
lean_dec(v_i_3433_);
lean_dec_ref(v_table_3428_);
lean_dec(v_work_3427_);
return v_b_3432_;
}
else
{
lean_object* v_snd_3437_; lean_object* v___x_3439_; uint8_t v_isShared_3440_; uint8_t v_isSharedCheck_3743_; 
v_snd_3437_ = lean_ctor_get(v_b_3432_, 1);
v_isSharedCheck_3743_ = !lean_is_exclusive(v_b_3432_);
if (v_isSharedCheck_3743_ == 0)
{
lean_object* v_unused_3744_; 
v_unused_3744_ = lean_ctor_get(v_b_3432_, 0);
lean_dec(v_unused_3744_);
v___x_3439_ = v_b_3432_;
v_isShared_3440_ = v_isSharedCheck_3743_;
goto v_resetjp_3438_;
}
else
{
lean_inc(v_snd_3437_);
lean_dec(v_b_3432_);
v___x_3439_ = lean_box(0);
v_isShared_3440_ = v_isSharedCheck_3743_;
goto v_resetjp_3438_;
}
v_resetjp_3438_:
{
lean_object* v_arity_3441_; uint8_t v_width_3442_; lean_object* v_exponents_3443_; lean_object* v___x_3444_; uint64_t v___y_3446_; uint64_t v___y_3455_; uint64_t v___y_3456_; uint8_t v___y_3457_; uint64_t v___y_3468_; uint64_t v___y_3469_; uint8_t v___y_3470_; uint64_t v___y_3481_; uint64_t v___y_3482_; uint64_t v___y_3489_; uint64_t v___y_3490_; uint8_t v___y_3491_; uint64_t v___y_3497_; lean_object* v___y_3498_; uint8_t v___y_3499_; lean_object* v___y_3500_; uint64_t v___y_3501_; uint8_t v___y_3502_; uint64_t v___y_3515_; uint64_t v___y_3516_; lean_object* v___y_3517_; uint8_t v___y_3518_; lean_object* v___y_3519_; uint8_t v___y_3520_; uint64_t v___y_3533_; uint64_t v___y_3534_; uint8_t v___y_3535_; uint64_t v___y_3541_; lean_object* v___y_3542_; uint8_t v___y_3543_; uint8_t v___y_3544_; lean_object* v___y_3545_; uint8_t v___y_3546_; uint64_t v___y_3563_; lean_object* v___y_3564_; uint8_t v___y_3565_; uint8_t v___y_3566_; lean_object* v___y_3567_; uint8_t v___y_3568_; uint64_t v___y_3606_; uint8_t v___y_3607_; lean_object* v___y_3608_; lean_object* v___y_3609_; uint8_t v___y_3610_; lean_object* v___y_3611_; uint64_t v___y_3620_; uint64_t v___y_3628_; uint8_t v___y_3629_; uint64_t v___y_3635_; uint8_t v___y_3636_; lean_object* v___x_3641_; lean_object* v___x_3642_; uint8_t v___x_3643_; lean_object* v___y_3645_; uint64_t v___y_3646_; uint8_t v___y_3647_; uint64_t v___y_3660_; lean_object* v___y_3661_; uint8_t v___y_3662_; lean_object* v___y_3675_; uint8_t v___y_3676_; lean_object* v___y_3693_; uint8_t v___y_3694_; lean_object* v___y_3732_; 
v_arity_3441_ = lean_ctor_get(v_table_3428_, 0);
v_width_3442_ = lean_ctor_get_uint8(v_table_3428_, sizeof(void*)*9);
v_exponents_3443_ = lean_ctor_get(v_table_3428_, 1);
v___x_3444_ = lean_box(0);
v___x_3641_ = lean_nat_mul(v_a_3430_, v_arity_3441_);
v___x_3642_ = lean_nat_add(v___x_3641_, v_i_3433_);
lean_dec(v___x_3641_);
v___x_3643_ = 0;
switch(v_width_3442_)
{
case 0:
{
lean_object* v___x_3740_; 
v___x_3740_ = lean_unsigned_to_nat(1u);
v___y_3732_ = v___x_3740_;
goto v___jp_3731_;
}
case 1:
{
lean_object* v___x_3741_; 
v___x_3741_ = lean_unsigned_to_nat(2u);
v___y_3732_ = v___x_3741_;
goto v___jp_3731_;
}
default: 
{
lean_object* v___x_3742_; 
v___x_3742_ = lean_unsigned_to_nat(4u);
v___y_3732_ = v___x_3742_;
goto v___jp_3731_;
}
}
v___jp_3445_:
{
lean_object* v___x_3447_; lean_object* v___x_3448_; lean_object* v___x_3450_; 
v___x_3447_ = lean_box_uint64(v___y_3446_);
v___x_3448_ = lean_array_push(v_snd_3437_, v___x_3447_);
if (v_isShared_3440_ == 0)
{
lean_ctor_set(v___x_3439_, 1, v___x_3448_);
lean_ctor_set(v___x_3439_, 0, v___x_3444_);
v___x_3450_ = v___x_3439_;
goto v_reusejp_3449_;
}
else
{
lean_object* v_reuseFailAlloc_3453_; 
v_reuseFailAlloc_3453_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3453_, 0, v___x_3444_);
lean_ctor_set(v_reuseFailAlloc_3453_, 1, v___x_3448_);
v___x_3450_ = v_reuseFailAlloc_3453_;
goto v_reusejp_3449_;
}
v_reusejp_3449_:
{
lean_object* v___x_3451_; 
v___x_3451_ = lean_nat_add(v_i_3433_, v_step_3435_);
lean_dec(v_i_3433_);
v_b_3432_ = v___x_3450_;
v_i_3433_ = v___x_3451_;
goto _start;
}
}
v___jp_3454_:
{
if (v___y_3457_ == 0)
{
switch(v_operation_3426_)
{
case 0:
{
uint8_t v___x_3458_; 
v___x_3458_ = lean_uint64_dec_le(v___y_3455_, v___y_3456_);
if (v___x_3458_ == 0)
{
v___y_3446_ = v___y_3455_;
goto v___jp_3445_;
}
else
{
v___y_3446_ = v___y_3456_;
goto v___jp_3445_;
}
}
case 1:
{
uint64_t v___x_3459_; 
v___x_3459_ = lean_uint64_add(v___y_3455_, v___y_3456_);
v___y_3446_ = v___x_3459_;
goto v___jp_3445_;
}
default: 
{
uint64_t v___x_3460_; 
v___x_3460_ = lean_uint64_sub(v___y_3455_, v___y_3456_);
v___y_3446_ = v___x_3460_;
goto v___jp_3445_;
}
}
}
else
{
uint8_t v___x_3461_; lean_object* v___x_3462_; lean_object* v___x_3463_; lean_object* v___x_3464_; lean_object* v___x_3465_; lean_object* v___x_3466_; 
lean_del_object(v___x_3439_);
lean_dec(v_i_3433_);
v___x_3461_ = 2;
v___x_3462_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_3462_, 0, v_work_3427_);
lean_ctor_set_uint8(v___x_3462_, sizeof(void*)*1, v___x_3461_);
v___x_3463_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3463_, 0, v___x_3462_);
v___x_3464_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3464_, 0, v___x_3463_);
lean_ctor_set(v___x_3464_, 1, v_table_3428_);
v___x_3465_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3465_, 0, v___x_3464_);
v___x_3466_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3466_, 0, v___x_3465_);
lean_ctor_set(v___x_3466_, 1, v_snd_3437_);
return v___x_3466_;
}
}
v___jp_3467_:
{
if (v___y_3470_ == 0)
{
uint8_t v___x_3471_; uint8_t v___x_3472_; 
v___x_3471_ = 2;
v___x_3472_ = lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation_beq(v_operation_3426_, v___x_3471_);
if (v___x_3472_ == 0)
{
v___y_3455_ = v___y_3468_;
v___y_3456_ = v___y_3469_;
v___y_3457_ = v___x_3472_;
goto v___jp_3454_;
}
else
{
uint8_t v___x_3473_; 
v___x_3473_ = lean_uint64_dec_lt(v___y_3468_, v___y_3469_);
v___y_3455_ = v___y_3468_;
v___y_3456_ = v___y_3469_;
v___y_3457_ = v___x_3473_;
goto v___jp_3454_;
}
}
else
{
uint8_t v___x_3474_; lean_object* v___x_3475_; lean_object* v___x_3476_; lean_object* v___x_3477_; lean_object* v___x_3478_; lean_object* v___x_3479_; 
lean_del_object(v___x_3439_);
lean_dec(v_i_3433_);
v___x_3474_ = 2;
v___x_3475_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_3475_, 0, v_work_3427_);
lean_ctor_set_uint8(v___x_3475_, sizeof(void*)*1, v___x_3474_);
v___x_3476_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3476_, 0, v___x_3475_);
v___x_3477_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3477_, 0, v___x_3476_);
lean_ctor_set(v___x_3477_, 1, v_table_3428_);
v___x_3478_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3478_, 0, v___x_3477_);
v___x_3479_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3479_, 0, v___x_3478_);
lean_ctor_set(v___x_3479_, 1, v_snd_3437_);
return v___x_3479_;
}
}
v___jp_3480_:
{
uint8_t v___x_3483_; uint8_t v___x_3484_; 
v___x_3483_ = 1;
v___x_3484_ = lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation_beq(v_operation_3426_, v___x_3483_);
if (v___x_3484_ == 0)
{
v___y_3468_ = v___y_3481_;
v___y_3469_ = v___y_3482_;
v___y_3470_ = v___x_3484_;
goto v___jp_3467_;
}
else
{
uint64_t v___x_3485_; uint64_t v___x_3486_; uint8_t v___x_3487_; 
v___x_3485_ = 4294967295ULL;
v___x_3486_ = lean_uint64_add(v___y_3481_, v___y_3482_);
v___x_3487_ = lean_uint64_dec_lt(v___x_3485_, v___x_3486_);
v___y_3468_ = v___y_3481_;
v___y_3469_ = v___y_3482_;
v___y_3470_ = v___x_3487_;
goto v___jp_3467_;
}
}
v___jp_3488_:
{
uint64_t v___x_3492_; uint64_t v___x_3493_; uint64_t v___x_3494_; uint64_t v___x_3495_; 
v___x_3492_ = lean_uint8_to_uint64(v___y_3491_);
v___x_3493_ = 24ULL;
v___x_3494_ = lean_uint64_shift_left(v___x_3492_, v___x_3493_);
v___x_3495_ = lean_uint64_lor(v___y_3489_, v___x_3494_);
v___y_3481_ = v___y_3490_;
v___y_3482_ = v___x_3495_;
goto v___jp_3480_;
}
v___jp_3496_:
{
uint64_t v___x_3503_; uint64_t v___x_3504_; uint64_t v___x_3505_; uint64_t v___x_3506_; lean_object* v___x_3507_; lean_object* v___x_3508_; uint8_t v___x_3509_; 
v___x_3503_ = lean_uint8_to_uint64(v___y_3502_);
v___x_3504_ = 16ULL;
v___x_3505_ = lean_uint64_shift_left(v___x_3503_, v___x_3504_);
v___x_3506_ = lean_uint64_lor(v___y_3501_, v___x_3505_);
v___x_3507_ = lean_unsigned_to_nat(3u);
v___x_3508_ = lean_nat_add(v___y_3498_, v___x_3507_);
lean_dec(v___y_3498_);
v___x_3509_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_3500_, v___x_3508_);
if (v___x_3509_ == 0)
{
lean_object* v___x_3510_; lean_object* v___x_3511_; uint8_t v___x_3512_; 
lean_dec(v___x_3508_);
lean_dec_ref(v___y_3500_);
v___x_3510_ = lean_box(v___y_3499_);
v___x_3511_ = l_outOfBounds___redArg(v___x_3510_);
lean_dec(v___x_3510_);
v___x_3512_ = lean_unbox(v___x_3511_);
lean_dec(v___x_3511_);
v___y_3489_ = v___x_3506_;
v___y_3490_ = v___y_3497_;
v___y_3491_ = v___x_3512_;
goto v___jp_3488_;
}
else
{
uint8_t v___x_3513_; 
v___x_3513_ = lean_byte_array_fget(v___y_3500_, v___x_3508_);
lean_dec(v___x_3508_);
lean_dec_ref(v___y_3500_);
v___y_3489_ = v___x_3506_;
v___y_3490_ = v___y_3497_;
v___y_3491_ = v___x_3513_;
goto v___jp_3488_;
}
}
v___jp_3514_:
{
uint64_t v___x_3521_; uint64_t v___x_3522_; uint64_t v___x_3523_; uint64_t v___x_3524_; lean_object* v___x_3525_; lean_object* v___x_3526_; uint8_t v___x_3527_; 
v___x_3521_ = lean_uint8_to_uint64(v___y_3520_);
v___x_3522_ = 8ULL;
v___x_3523_ = lean_uint64_shift_left(v___x_3521_, v___x_3522_);
v___x_3524_ = lean_uint64_lor(v___y_3515_, v___x_3523_);
v___x_3525_ = lean_unsigned_to_nat(2u);
v___x_3526_ = lean_nat_add(v___y_3517_, v___x_3525_);
v___x_3527_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_3519_, v___x_3526_);
if (v___x_3527_ == 0)
{
lean_object* v___x_3528_; lean_object* v___x_3529_; uint8_t v___x_3530_; 
lean_dec(v___x_3526_);
v___x_3528_ = lean_box(v___y_3518_);
v___x_3529_ = l_outOfBounds___redArg(v___x_3528_);
lean_dec(v___x_3528_);
v___x_3530_ = lean_unbox(v___x_3529_);
lean_dec(v___x_3529_);
v___y_3497_ = v___y_3516_;
v___y_3498_ = v___y_3517_;
v___y_3499_ = v___y_3518_;
v___y_3500_ = v___y_3519_;
v___y_3501_ = v___x_3524_;
v___y_3502_ = v___x_3530_;
goto v___jp_3496_;
}
else
{
uint8_t v___x_3531_; 
v___x_3531_ = lean_byte_array_fget(v___y_3519_, v___x_3526_);
lean_dec(v___x_3526_);
v___y_3497_ = v___y_3516_;
v___y_3498_ = v___y_3517_;
v___y_3499_ = v___y_3518_;
v___y_3500_ = v___y_3519_;
v___y_3501_ = v___x_3524_;
v___y_3502_ = v___x_3531_;
goto v___jp_3496_;
}
}
v___jp_3532_:
{
uint64_t v___x_3536_; uint64_t v___x_3537_; uint64_t v___x_3538_; uint64_t v___x_3539_; 
v___x_3536_ = lean_uint8_to_uint64(v___y_3535_);
v___x_3537_ = 8ULL;
v___x_3538_ = lean_uint64_shift_left(v___x_3536_, v___x_3537_);
v___x_3539_ = lean_uint64_lor(v___y_3533_, v___x_3538_);
v___y_3481_ = v___y_3534_;
v___y_3482_ = v___x_3539_;
goto v___jp_3480_;
}
v___jp_3540_:
{
uint64_t v_a_3547_; 
v_a_3547_ = lean_uint8_to_uint64(v___y_3546_);
switch(v___y_3544_)
{
case 0:
{
lean_dec_ref(v___y_3545_);
lean_dec(v___y_3542_);
v___y_3481_ = v___y_3541_;
v___y_3482_ = v_a_3547_;
goto v___jp_3480_;
}
case 1:
{
lean_object* v___x_3548_; lean_object* v___x_3549_; uint8_t v___x_3550_; 
v___x_3548_ = lean_unsigned_to_nat(1u);
v___x_3549_ = lean_nat_add(v___y_3542_, v___x_3548_);
lean_dec(v___y_3542_);
v___x_3550_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_3545_, v___x_3549_);
if (v___x_3550_ == 0)
{
lean_object* v___x_3551_; lean_object* v___x_3552_; uint8_t v___x_3553_; 
lean_dec(v___x_3549_);
lean_dec_ref(v___y_3545_);
v___x_3551_ = lean_box(v___y_3543_);
v___x_3552_ = l_outOfBounds___redArg(v___x_3551_);
lean_dec(v___x_3551_);
v___x_3553_ = lean_unbox(v___x_3552_);
lean_dec(v___x_3552_);
v___y_3533_ = v_a_3547_;
v___y_3534_ = v___y_3541_;
v___y_3535_ = v___x_3553_;
goto v___jp_3532_;
}
else
{
uint8_t v___x_3554_; 
v___x_3554_ = lean_byte_array_fget(v___y_3545_, v___x_3549_);
lean_dec(v___x_3549_);
lean_dec_ref(v___y_3545_);
v___y_3533_ = v_a_3547_;
v___y_3534_ = v___y_3541_;
v___y_3535_ = v___x_3554_;
goto v___jp_3532_;
}
}
default: 
{
lean_object* v___x_3555_; lean_object* v___x_3556_; uint8_t v___x_3557_; 
v___x_3555_ = lean_unsigned_to_nat(1u);
v___x_3556_ = lean_nat_add(v___y_3542_, v___x_3555_);
v___x_3557_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_3545_, v___x_3556_);
if (v___x_3557_ == 0)
{
lean_object* v___x_3558_; lean_object* v___x_3559_; uint8_t v___x_3560_; 
lean_dec(v___x_3556_);
v___x_3558_ = lean_box(v___y_3543_);
v___x_3559_ = l_outOfBounds___redArg(v___x_3558_);
lean_dec(v___x_3558_);
v___x_3560_ = lean_unbox(v___x_3559_);
lean_dec(v___x_3559_);
v___y_3515_ = v_a_3547_;
v___y_3516_ = v___y_3541_;
v___y_3517_ = v___y_3542_;
v___y_3518_ = v___y_3543_;
v___y_3519_ = v___y_3545_;
v___y_3520_ = v___x_3560_;
goto v___jp_3514_;
}
else
{
uint8_t v___x_3561_; 
v___x_3561_ = lean_byte_array_fget(v___y_3545_, v___x_3556_);
lean_dec(v___x_3556_);
v___y_3515_ = v_a_3547_;
v___y_3516_ = v___y_3541_;
v___y_3517_ = v___y_3542_;
v___y_3518_ = v___y_3543_;
v___y_3519_ = v___y_3545_;
v___y_3520_ = v___x_3561_;
goto v___jp_3514_;
}
}
}
}
v___jp_3562_:
{
if (v___y_3568_ == 0)
{
uint8_t v___x_3569_; 
v___x_3569_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_3567_, v___y_3564_);
if (v___x_3569_ == 0)
{
lean_object* v___x_3570_; lean_object* v___x_3571_; uint8_t v___x_3572_; 
v___x_3570_ = lean_box(v___y_3565_);
v___x_3571_ = l_outOfBounds___redArg(v___x_3570_);
lean_dec(v___x_3570_);
v___x_3572_ = lean_unbox(v___x_3571_);
lean_dec(v___x_3571_);
v___y_3541_ = v___y_3563_;
v___y_3542_ = v___y_3564_;
v___y_3543_ = v___y_3565_;
v___y_3544_ = v___y_3566_;
v___y_3545_ = v___y_3567_;
v___y_3546_ = v___x_3572_;
goto v___jp_3540_;
}
else
{
uint8_t v___x_3573_; 
v___x_3573_ = lean_byte_array_fget(v___y_3567_, v___y_3564_);
v___y_3541_ = v___y_3563_;
v___y_3542_ = v___y_3564_;
v___y_3543_ = v___y_3565_;
v___y_3544_ = v___y_3566_;
v___y_3545_ = v___y_3567_;
v___y_3546_ = v___x_3573_;
goto v___jp_3540_;
}
}
else
{
size_t v_pos_3574_; uint8_t v___x_3575_; uint64_t v_a_3576_; 
v_pos_3574_ = lean_usize_of_nat(v___y_3564_);
lean_dec(v___y_3564_);
v___x_3575_ = lean_byte_array_uget(v___y_3567_, v_pos_3574_);
v_a_3576_ = lean_uint8_to_uint64(v___x_3575_);
switch(v___y_3566_)
{
case 0:
{
lean_dec_ref(v___y_3567_);
v___y_3481_ = v___y_3563_;
v___y_3482_ = v_a_3576_;
goto v___jp_3480_;
}
case 1:
{
size_t v___x_3577_; size_t v___x_3578_; uint8_t v___x_3579_; uint64_t v___x_3580_; uint64_t v___x_3581_; uint64_t v___x_3582_; uint64_t v___x_3583_; 
v___x_3577_ = ((size_t)1ULL);
v___x_3578_ = lean_usize_add(v_pos_3574_, v___x_3577_);
v___x_3579_ = lean_byte_array_uget(v___y_3567_, v___x_3578_);
lean_dec_ref(v___y_3567_);
v___x_3580_ = lean_uint8_to_uint64(v___x_3579_);
v___x_3581_ = 8ULL;
v___x_3582_ = lean_uint64_shift_left(v___x_3580_, v___x_3581_);
v___x_3583_ = lean_uint64_lor(v_a_3576_, v___x_3582_);
v___y_3481_ = v___y_3563_;
v___y_3482_ = v___x_3583_;
goto v___jp_3480_;
}
default: 
{
size_t v___x_3584_; size_t v___x_3585_; uint8_t v___x_3586_; uint64_t v___x_3587_; uint64_t v___x_3588_; uint64_t v___x_3589_; uint64_t v___x_3590_; size_t v___x_3591_; size_t v___x_3592_; uint8_t v___x_3593_; uint64_t v___x_3594_; uint64_t v___x_3595_; uint64_t v___x_3596_; uint64_t v___x_3597_; size_t v___x_3598_; size_t v___x_3599_; uint8_t v___x_3600_; uint64_t v___x_3601_; uint64_t v___x_3602_; uint64_t v___x_3603_; uint64_t v___x_3604_; 
v___x_3584_ = ((size_t)1ULL);
v___x_3585_ = lean_usize_add(v_pos_3574_, v___x_3584_);
v___x_3586_ = lean_byte_array_uget(v___y_3567_, v___x_3585_);
v___x_3587_ = lean_uint8_to_uint64(v___x_3586_);
v___x_3588_ = 8ULL;
v___x_3589_ = lean_uint64_shift_left(v___x_3587_, v___x_3588_);
v___x_3590_ = lean_uint64_lor(v_a_3576_, v___x_3589_);
v___x_3591_ = ((size_t)2ULL);
v___x_3592_ = lean_usize_add(v_pos_3574_, v___x_3591_);
v___x_3593_ = lean_byte_array_uget(v___y_3567_, v___x_3592_);
v___x_3594_ = lean_uint8_to_uint64(v___x_3593_);
v___x_3595_ = 16ULL;
v___x_3596_ = lean_uint64_shift_left(v___x_3594_, v___x_3595_);
v___x_3597_ = lean_uint64_lor(v___x_3590_, v___x_3596_);
v___x_3598_ = ((size_t)3ULL);
v___x_3599_ = lean_usize_add(v_pos_3574_, v___x_3598_);
v___x_3600_ = lean_byte_array_uget(v___y_3567_, v___x_3599_);
lean_dec_ref(v___y_3567_);
v___x_3601_ = lean_uint8_to_uint64(v___x_3600_);
v___x_3602_ = 24ULL;
v___x_3603_ = lean_uint64_shift_left(v___x_3601_, v___x_3602_);
v___x_3604_ = lean_uint64_lor(v___x_3597_, v___x_3603_);
v___y_3481_ = v___y_3563_;
v___y_3482_ = v___x_3604_;
goto v___jp_3480_;
}
}
}
}
v___jp_3605_:
{
lean_object* v_offset_3612_; lean_object* v___x_3613_; lean_object* v___x_3614_; uint8_t v___x_3615_; 
v_offset_3612_ = lean_nat_mul(v___y_3608_, v___y_3611_);
lean_dec(v___y_3608_);
v___x_3613_ = lean_nat_add(v_offset_3612_, v___y_3611_);
v___x_3614_ = lean_byte_array_size(v___y_3609_);
v___x_3615_ = lean_nat_dec_le(v___x_3613_, v___x_3614_);
if (v___x_3615_ == 0)
{
lean_dec(v___x_3613_);
v___y_3563_ = v___y_3606_;
v___y_3564_ = v_offset_3612_;
v___y_3565_ = v___y_3607_;
v___y_3566_ = v___y_3610_;
v___y_3567_ = v___y_3609_;
v___y_3568_ = v___x_3615_;
goto v___jp_3562_;
}
else
{
size_t v___x_3616_; lean_object* v___x_3617_; uint8_t v___x_3618_; 
v___x_3616_ = lean_usize_of_nat(v___x_3613_);
v___x_3617_ = lean_usize_to_nat(v___x_3616_);
v___x_3618_ = lean_nat_dec_eq(v___x_3617_, v___x_3613_);
lean_dec(v___x_3613_);
lean_dec(v___x_3617_);
v___y_3563_ = v___y_3606_;
v___y_3564_ = v_offset_3612_;
v___y_3565_ = v___y_3607_;
v___y_3566_ = v___y_3610_;
v___y_3567_ = v___y_3609_;
v___y_3568_ = v___x_3618_;
goto v___jp_3562_;
}
}
v___jp_3619_:
{
lean_object* v___x_3621_; lean_object* v___x_3622_; uint8_t v___x_3623_; 
v___x_3621_ = lean_nat_mul(v_b_3429_, v_arity_3441_);
v___x_3622_ = lean_nat_add(v___x_3621_, v_i_3433_);
lean_dec(v___x_3621_);
v___x_3623_ = 0;
switch(v_width_3442_)
{
case 0:
{
lean_object* v___x_3624_; 
v___x_3624_ = lean_unsigned_to_nat(1u);
lean_inc_ref(v_exponents_3443_);
v___y_3606_ = v___y_3620_;
v___y_3607_ = v___x_3623_;
v___y_3608_ = v___x_3622_;
v___y_3609_ = v_exponents_3443_;
v___y_3610_ = v_width_3442_;
v___y_3611_ = v___x_3624_;
goto v___jp_3605_;
}
case 1:
{
lean_object* v___x_3625_; 
v___x_3625_ = lean_unsigned_to_nat(2u);
lean_inc_ref(v_exponents_3443_);
v___y_3606_ = v___y_3620_;
v___y_3607_ = v___x_3623_;
v___y_3608_ = v___x_3622_;
v___y_3609_ = v_exponents_3443_;
v___y_3610_ = v_width_3442_;
v___y_3611_ = v___x_3625_;
goto v___jp_3605_;
}
default: 
{
lean_object* v___x_3626_; 
v___x_3626_ = lean_unsigned_to_nat(4u);
lean_inc_ref(v_exponents_3443_);
v___y_3606_ = v___y_3620_;
v___y_3607_ = v___x_3623_;
v___y_3608_ = v___x_3622_;
v___y_3609_ = v_exponents_3443_;
v___y_3610_ = v_width_3442_;
v___y_3611_ = v___x_3626_;
goto v___jp_3605_;
}
}
}
v___jp_3627_:
{
uint64_t v___x_3630_; uint64_t v___x_3631_; uint64_t v___x_3632_; uint64_t v___x_3633_; 
v___x_3630_ = lean_uint8_to_uint64(v___y_3629_);
v___x_3631_ = 24ULL;
v___x_3632_ = lean_uint64_shift_left(v___x_3630_, v___x_3631_);
v___x_3633_ = lean_uint64_lor(v___y_3628_, v___x_3632_);
v___y_3620_ = v___x_3633_;
goto v___jp_3619_;
}
v___jp_3634_:
{
uint64_t v___x_3637_; uint64_t v___x_3638_; uint64_t v___x_3639_; uint64_t v___x_3640_; 
v___x_3637_ = lean_uint8_to_uint64(v___y_3636_);
v___x_3638_ = 8ULL;
v___x_3639_ = lean_uint64_shift_left(v___x_3637_, v___x_3638_);
v___x_3640_ = lean_uint64_lor(v___y_3635_, v___x_3639_);
v___y_3620_ = v___x_3640_;
goto v___jp_3619_;
}
v___jp_3644_:
{
uint64_t v___x_3648_; uint64_t v___x_3649_; uint64_t v___x_3650_; uint64_t v___x_3651_; lean_object* v___x_3652_; lean_object* v___x_3653_; uint8_t v___x_3654_; 
v___x_3648_ = lean_uint8_to_uint64(v___y_3647_);
v___x_3649_ = 16ULL;
v___x_3650_ = lean_uint64_shift_left(v___x_3648_, v___x_3649_);
v___x_3651_ = lean_uint64_lor(v___y_3646_, v___x_3650_);
v___x_3652_ = lean_unsigned_to_nat(3u);
v___x_3653_ = lean_nat_add(v___y_3645_, v___x_3652_);
lean_dec(v___y_3645_);
v___x_3654_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_3443_, v___x_3653_);
if (v___x_3654_ == 0)
{
lean_object* v___x_3655_; lean_object* v___x_3656_; uint8_t v___x_3657_; 
lean_dec(v___x_3653_);
v___x_3655_ = lean_box(v___x_3643_);
v___x_3656_ = l_outOfBounds___redArg(v___x_3655_);
lean_dec(v___x_3655_);
v___x_3657_ = lean_unbox(v___x_3656_);
lean_dec(v___x_3656_);
v___y_3628_ = v___x_3651_;
v___y_3629_ = v___x_3657_;
goto v___jp_3627_;
}
else
{
uint8_t v___x_3658_; 
v___x_3658_ = lean_byte_array_fget(v_exponents_3443_, v___x_3653_);
lean_dec(v___x_3653_);
v___y_3628_ = v___x_3651_;
v___y_3629_ = v___x_3658_;
goto v___jp_3627_;
}
}
v___jp_3659_:
{
uint64_t v___x_3663_; uint64_t v___x_3664_; uint64_t v___x_3665_; uint64_t v___x_3666_; lean_object* v___x_3667_; lean_object* v___x_3668_; uint8_t v___x_3669_; 
v___x_3663_ = lean_uint8_to_uint64(v___y_3662_);
v___x_3664_ = 8ULL;
v___x_3665_ = lean_uint64_shift_left(v___x_3663_, v___x_3664_);
v___x_3666_ = lean_uint64_lor(v___y_3660_, v___x_3665_);
v___x_3667_ = lean_unsigned_to_nat(2u);
v___x_3668_ = lean_nat_add(v___y_3661_, v___x_3667_);
v___x_3669_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_3443_, v___x_3668_);
if (v___x_3669_ == 0)
{
lean_object* v___x_3670_; lean_object* v___x_3671_; uint8_t v___x_3672_; 
lean_dec(v___x_3668_);
v___x_3670_ = lean_box(v___x_3643_);
v___x_3671_ = l_outOfBounds___redArg(v___x_3670_);
lean_dec(v___x_3670_);
v___x_3672_ = lean_unbox(v___x_3671_);
lean_dec(v___x_3671_);
v___y_3645_ = v___y_3661_;
v___y_3646_ = v___x_3666_;
v___y_3647_ = v___x_3672_;
goto v___jp_3644_;
}
else
{
uint8_t v___x_3673_; 
v___x_3673_ = lean_byte_array_fget(v_exponents_3443_, v___x_3668_);
lean_dec(v___x_3668_);
v___y_3645_ = v___y_3661_;
v___y_3646_ = v___x_3666_;
v___y_3647_ = v___x_3673_;
goto v___jp_3644_;
}
}
v___jp_3674_:
{
uint64_t v_a_3677_; 
v_a_3677_ = lean_uint8_to_uint64(v___y_3676_);
switch(v_width_3442_)
{
case 0:
{
lean_dec(v___y_3675_);
v___y_3620_ = v_a_3677_;
goto v___jp_3619_;
}
case 1:
{
lean_object* v___x_3678_; lean_object* v___x_3679_; uint8_t v___x_3680_; 
v___x_3678_ = lean_unsigned_to_nat(1u);
v___x_3679_ = lean_nat_add(v___y_3675_, v___x_3678_);
lean_dec(v___y_3675_);
v___x_3680_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_3443_, v___x_3679_);
if (v___x_3680_ == 0)
{
lean_object* v___x_3681_; lean_object* v___x_3682_; uint8_t v___x_3683_; 
lean_dec(v___x_3679_);
v___x_3681_ = lean_box(v___x_3643_);
v___x_3682_ = l_outOfBounds___redArg(v___x_3681_);
lean_dec(v___x_3681_);
v___x_3683_ = lean_unbox(v___x_3682_);
lean_dec(v___x_3682_);
v___y_3635_ = v_a_3677_;
v___y_3636_ = v___x_3683_;
goto v___jp_3634_;
}
else
{
uint8_t v___x_3684_; 
v___x_3684_ = lean_byte_array_fget(v_exponents_3443_, v___x_3679_);
lean_dec(v___x_3679_);
v___y_3635_ = v_a_3677_;
v___y_3636_ = v___x_3684_;
goto v___jp_3634_;
}
}
default: 
{
lean_object* v___x_3685_; lean_object* v___x_3686_; uint8_t v___x_3687_; 
v___x_3685_ = lean_unsigned_to_nat(1u);
v___x_3686_ = lean_nat_add(v___y_3675_, v___x_3685_);
v___x_3687_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_3443_, v___x_3686_);
if (v___x_3687_ == 0)
{
lean_object* v___x_3688_; lean_object* v___x_3689_; uint8_t v___x_3690_; 
lean_dec(v___x_3686_);
v___x_3688_ = lean_box(v___x_3643_);
v___x_3689_ = l_outOfBounds___redArg(v___x_3688_);
lean_dec(v___x_3688_);
v___x_3690_ = lean_unbox(v___x_3689_);
lean_dec(v___x_3689_);
v___y_3660_ = v_a_3677_;
v___y_3661_ = v___y_3675_;
v___y_3662_ = v___x_3690_;
goto v___jp_3659_;
}
else
{
uint8_t v___x_3691_; 
v___x_3691_ = lean_byte_array_fget(v_exponents_3443_, v___x_3686_);
lean_dec(v___x_3686_);
v___y_3660_ = v_a_3677_;
v___y_3661_ = v___y_3675_;
v___y_3662_ = v___x_3691_;
goto v___jp_3659_;
}
}
}
}
v___jp_3692_:
{
if (v___y_3694_ == 0)
{
uint8_t v___x_3695_; 
v___x_3695_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_exponents_3443_, v___y_3693_);
if (v___x_3695_ == 0)
{
lean_object* v___x_3696_; lean_object* v___x_3697_; uint8_t v___x_3698_; 
v___x_3696_ = lean_box(v___x_3643_);
v___x_3697_ = l_outOfBounds___redArg(v___x_3696_);
lean_dec(v___x_3696_);
v___x_3698_ = lean_unbox(v___x_3697_);
lean_dec(v___x_3697_);
v___y_3675_ = v___y_3693_;
v___y_3676_ = v___x_3698_;
goto v___jp_3674_;
}
else
{
uint8_t v___x_3699_; 
v___x_3699_ = lean_byte_array_fget(v_exponents_3443_, v___y_3693_);
v___y_3675_ = v___y_3693_;
v___y_3676_ = v___x_3699_;
goto v___jp_3674_;
}
}
else
{
size_t v_pos_3700_; uint8_t v___x_3701_; uint64_t v_a_3702_; 
v_pos_3700_ = lean_usize_of_nat(v___y_3693_);
lean_dec(v___y_3693_);
v___x_3701_ = lean_byte_array_uget(v_exponents_3443_, v_pos_3700_);
v_a_3702_ = lean_uint8_to_uint64(v___x_3701_);
switch(v_width_3442_)
{
case 0:
{
v___y_3620_ = v_a_3702_;
goto v___jp_3619_;
}
case 1:
{
size_t v___x_3703_; size_t v___x_3704_; uint8_t v___x_3705_; uint64_t v___x_3706_; uint64_t v___x_3707_; uint64_t v___x_3708_; uint64_t v___x_3709_; 
v___x_3703_ = ((size_t)1ULL);
v___x_3704_ = lean_usize_add(v_pos_3700_, v___x_3703_);
v___x_3705_ = lean_byte_array_uget(v_exponents_3443_, v___x_3704_);
v___x_3706_ = lean_uint8_to_uint64(v___x_3705_);
v___x_3707_ = 8ULL;
v___x_3708_ = lean_uint64_shift_left(v___x_3706_, v___x_3707_);
v___x_3709_ = lean_uint64_lor(v_a_3702_, v___x_3708_);
v___y_3620_ = v___x_3709_;
goto v___jp_3619_;
}
default: 
{
size_t v___x_3710_; size_t v___x_3711_; uint8_t v___x_3712_; uint64_t v___x_3713_; uint64_t v___x_3714_; uint64_t v___x_3715_; uint64_t v___x_3716_; size_t v___x_3717_; size_t v___x_3718_; uint8_t v___x_3719_; uint64_t v___x_3720_; uint64_t v___x_3721_; uint64_t v___x_3722_; uint64_t v___x_3723_; size_t v___x_3724_; size_t v___x_3725_; uint8_t v___x_3726_; uint64_t v___x_3727_; uint64_t v___x_3728_; uint64_t v___x_3729_; uint64_t v___x_3730_; 
v___x_3710_ = ((size_t)1ULL);
v___x_3711_ = lean_usize_add(v_pos_3700_, v___x_3710_);
v___x_3712_ = lean_byte_array_uget(v_exponents_3443_, v___x_3711_);
v___x_3713_ = lean_uint8_to_uint64(v___x_3712_);
v___x_3714_ = 8ULL;
v___x_3715_ = lean_uint64_shift_left(v___x_3713_, v___x_3714_);
v___x_3716_ = lean_uint64_lor(v_a_3702_, v___x_3715_);
v___x_3717_ = ((size_t)2ULL);
v___x_3718_ = lean_usize_add(v_pos_3700_, v___x_3717_);
v___x_3719_ = lean_byte_array_uget(v_exponents_3443_, v___x_3718_);
v___x_3720_ = lean_uint8_to_uint64(v___x_3719_);
v___x_3721_ = 16ULL;
v___x_3722_ = lean_uint64_shift_left(v___x_3720_, v___x_3721_);
v___x_3723_ = lean_uint64_lor(v___x_3716_, v___x_3722_);
v___x_3724_ = ((size_t)3ULL);
v___x_3725_ = lean_usize_add(v_pos_3700_, v___x_3724_);
v___x_3726_ = lean_byte_array_uget(v_exponents_3443_, v___x_3725_);
v___x_3727_ = lean_uint8_to_uint64(v___x_3726_);
v___x_3728_ = 24ULL;
v___x_3729_ = lean_uint64_shift_left(v___x_3727_, v___x_3728_);
v___x_3730_ = lean_uint64_lor(v___x_3723_, v___x_3729_);
v___y_3620_ = v___x_3730_;
goto v___jp_3619_;
}
}
}
}
v___jp_3731_:
{
lean_object* v_offset_3733_; lean_object* v___x_3734_; lean_object* v___x_3735_; uint8_t v___x_3736_; 
v_offset_3733_ = lean_nat_mul(v___x_3642_, v___y_3732_);
lean_dec(v___x_3642_);
v___x_3734_ = lean_nat_add(v_offset_3733_, v___y_3732_);
v___x_3735_ = lean_byte_array_size(v_exponents_3443_);
v___x_3736_ = lean_nat_dec_le(v___x_3734_, v___x_3735_);
if (v___x_3736_ == 0)
{
lean_dec(v___x_3734_);
v___y_3693_ = v_offset_3733_;
v___y_3694_ = v___x_3736_;
goto v___jp_3692_;
}
else
{
size_t v___x_3737_; lean_object* v___x_3738_; uint8_t v___x_3739_; 
v___x_3737_ = lean_usize_of_nat(v___x_3734_);
v___x_3738_ = lean_usize_to_nat(v___x_3737_);
v___x_3739_ = lean_nat_dec_eq(v___x_3738_, v___x_3734_);
lean_dec(v___x_3734_);
lean_dec(v___x_3738_);
v___y_3693_ = v_offset_3733_;
v___y_3694_ = v___x_3739_;
goto v___jp_3692_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0___redArg___boxed(lean_object* v_operation_3745_, lean_object* v_work_3746_, lean_object* v_table_3747_, lean_object* v_b_3748_, lean_object* v_a_3749_, lean_object* v_range_3750_, lean_object* v_b_3751_, lean_object* v_i_3752_){
_start:
{
uint8_t v_operation_boxed_3753_; lean_object* v_res_3754_; 
v_operation_boxed_3753_ = lean_unbox(v_operation_3745_);
v_res_3754_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0___redArg(v_operation_boxed_3753_, v_work_3746_, v_table_3747_, v_b_3748_, v_a_3749_, v_range_3750_, v_b_3751_, v_i_3752_);
lean_dec_ref(v_range_3750_);
lean_dec(v_a_3749_);
lean_dec(v_b_3748_);
return v_res_3754_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable(lean_object* v_table_3755_, uint8_t v_operation_3756_, lean_object* v_a_3757_, lean_object* v_b_3758_, lean_object* v_maxCount_3759_, lean_object* v_maxBytes_3760_, lean_object* v_maxWork_3761_, lean_object* v_work_3762_){
_start:
{
lean_object* v_arity_3763_; uint8_t v_width_3764_; lean_object* v_exponents_3765_; lean_object* v_metadata_3766_; lean_object* v_count_3767_; lean_object* v_workspace_3768_; lean_object* v_buckets_3769_; lean_object* v_products_3770_; lean_object* v_hashBits_3771_; lean_object* v_values_3772_; lean_object* v___x_3773_; lean_object* v___x_3774_; lean_object* v___x_3775_; lean_object* v___x_3776_; lean_object* v___x_3777_; lean_object* v___x_3778_; lean_object* v_fst_3779_; 
v_arity_3763_ = lean_ctor_get(v_table_3755_, 0);
lean_inc_n(v_arity_3763_, 2);
v_width_3764_ = lean_ctor_get_uint8(v_table_3755_, sizeof(void*)*9);
v_exponents_3765_ = lean_ctor_get(v_table_3755_, 1);
lean_inc_ref(v_exponents_3765_);
v_metadata_3766_ = lean_ctor_get(v_table_3755_, 2);
lean_inc_ref(v_metadata_3766_);
v_count_3767_ = lean_ctor_get(v_table_3755_, 3);
lean_inc(v_count_3767_);
v_workspace_3768_ = lean_ctor_get(v_table_3755_, 4);
lean_inc_ref(v_workspace_3768_);
v_buckets_3769_ = lean_ctor_get(v_table_3755_, 5);
lean_inc_ref(v_buckets_3769_);
v_products_3770_ = lean_ctor_get(v_table_3755_, 6);
lean_inc_ref(v_products_3770_);
v_hashBits_3771_ = lean_ctor_get(v_table_3755_, 7);
lean_inc(v_hashBits_3771_);
v_values_3772_ = lean_mk_empty_array_with_capacity(v_arity_3763_);
v___x_3773_ = lean_unsigned_to_nat(0u);
v___x_3774_ = lean_unsigned_to_nat(1u);
v___x_3775_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_3775_, 0, v___x_3773_);
lean_ctor_set(v___x_3775_, 1, v_arity_3763_);
lean_ctor_set(v___x_3775_, 2, v___x_3774_);
v___x_3776_ = lean_box(0);
v___x_3777_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3777_, 0, v___x_3776_);
lean_ctor_set(v___x_3777_, 1, v_values_3772_);
lean_inc(v_work_3762_);
v___x_3778_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0___redArg(v_operation_3756_, v_work_3762_, v_table_3755_, v_b_3758_, v_a_3757_, v___x_3775_, v___x_3777_, v___x_3773_);
lean_dec_ref_known(v___x_3775_, 3);
v_fst_3779_ = lean_ctor_get(v___x_3778_, 0);
lean_inc(v_fst_3779_);
if (lean_obj_tag(v_fst_3779_) == 0)
{
lean_object* v_snd_3780_; lean_object* v___x_3781_; lean_object* v___x_3782_; 
v_snd_3780_ = lean_ctor_get(v___x_3778_, 1);
lean_inc(v_snd_3780_);
lean_dec_ref(v___x_3778_);
v___x_3781_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_3781_, 0, v_arity_3763_);
lean_ctor_set(v___x_3781_, 1, v_exponents_3765_);
lean_ctor_set(v___x_3781_, 2, v_metadata_3766_);
lean_ctor_set(v___x_3781_, 3, v_count_3767_);
lean_ctor_set(v___x_3781_, 4, v_workspace_3768_);
lean_ctor_set(v___x_3781_, 5, v_buckets_3769_);
lean_ctor_set(v___x_3781_, 6, v_products_3770_);
lean_ctor_set(v___x_3781_, 7, v_hashBits_3771_);
lean_ctor_set(v___x_3781_, 8, v_work_3762_);
lean_ctor_set_uint8(v___x_3781_, sizeof(void*)*9, v_width_3764_);
v___x_3782_ = lp_Hex_Hex_Groebner_MonomialTable_internOwned(v___x_3781_, v_snd_3780_, v_maxCount_3759_, v_maxBytes_3760_, v_maxWork_3761_);
lean_dec(v_snd_3780_);
return v___x_3782_;
}
else
{
lean_object* v_val_3783_; 
lean_dec_ref(v___x_3778_);
lean_dec(v_hashBits_3771_);
lean_dec_ref(v_products_3770_);
lean_dec_ref(v_buckets_3769_);
lean_dec_ref(v_workspace_3768_);
lean_dec(v_count_3767_);
lean_dec_ref(v_metadata_3766_);
lean_dec_ref(v_exponents_3765_);
lean_dec(v_arity_3763_);
lean_dec(v_work_3762_);
lean_dec(v_maxWork_3761_);
v_val_3783_ = lean_ctor_get(v_fst_3779_, 0);
lean_inc(v_val_3783_);
lean_dec_ref_known(v_fst_3779_, 1);
return v_val_3783_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable___boxed(lean_object* v_table_3784_, lean_object* v_operation_3785_, lean_object* v_a_3786_, lean_object* v_b_3787_, lean_object* v_maxCount_3788_, lean_object* v_maxBytes_3789_, lean_object* v_maxWork_3790_, lean_object* v_work_3791_){
_start:
{
uint8_t v_operation_boxed_3792_; lean_object* v_res_3793_; 
v_operation_boxed_3792_ = lean_unbox(v_operation_3785_);
v_res_3793_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable(v_table_3784_, v_operation_boxed_3792_, v_a_3786_, v_b_3787_, v_maxCount_3788_, v_maxBytes_3789_, v_maxWork_3790_, v_work_3791_);
lean_dec(v_maxBytes_3789_);
lean_dec(v_maxCount_3788_);
lean_dec(v_b_3787_);
lean_dec(v_a_3786_);
return v_res_3793_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0(uint8_t v_operation_3794_, lean_object* v_work_3795_, lean_object* v_table_3796_, lean_object* v_b_3797_, lean_object* v_a_3798_, lean_object* v_range_3799_, lean_object* v_b_3800_, lean_object* v_i_3801_, lean_object* v_hs_3802_, lean_object* v_hl_3803_){
_start:
{
lean_object* v___x_3804_; 
v___x_3804_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0___redArg(v_operation_3794_, v_work_3795_, v_table_3796_, v_b_3797_, v_a_3798_, v_range_3799_, v_b_3800_, v_i_3801_);
return v___x_3804_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0___boxed(lean_object* v_operation_3805_, lean_object* v_work_3806_, lean_object* v_table_3807_, lean_object* v_b_3808_, lean_object* v_a_3809_, lean_object* v_range_3810_, lean_object* v_b_3811_, lean_object* v_i_3812_, lean_object* v_hs_3813_, lean_object* v_hl_3814_){
_start:
{
uint8_t v_operation_boxed_3815_; lean_object* v_res_3816_; 
v_operation_boxed_3815_ = lean_unbox(v_operation_3805_);
v_res_3816_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable_spec__0(v_operation_boxed_3815_, v_work_3806_, v_table_3807_, v_b_3808_, v_a_3809_, v_range_3810_, v_b_3811_, v_i_3812_, v_hs_3813_, v_hl_3814_);
lean_dec_ref(v_range_3810_);
lean_dec(v_a_3809_);
lean_dec(v_b_3808_);
return v_res_3816_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0___redArg(lean_object* v_range_3817_, lean_object* v_b_3818_, lean_object* v_i_3819_){
_start:
{
lean_object* v_stop_3820_; lean_object* v_step_3821_; uint8_t v___x_3822_; 
v_stop_3820_ = lean_ctor_get(v_range_3817_, 1);
v_step_3821_ = lean_ctor_get(v_range_3817_, 2);
v___x_3822_ = lean_nat_dec_lt(v_i_3819_, v_stop_3820_);
if (v___x_3822_ == 0)
{
lean_dec(v_i_3819_);
return v_b_3818_;
}
else
{
uint8_t v___x_3823_; lean_object* v___x_3824_; lean_object* v___x_3825_; 
v___x_3823_ = 0;
v___x_3824_ = lean_byte_array_push(v_b_3818_, v___x_3823_);
v___x_3825_ = lean_nat_add(v_i_3819_, v_step_3821_);
lean_dec(v_i_3819_);
v_b_3818_ = v___x_3824_;
v_i_3819_ = v___x_3825_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0___redArg___boxed(lean_object* v_range_3827_, lean_object* v_b_3828_, lean_object* v_i_3829_){
_start:
{
lean_object* v_res_3830_; 
v_res_3830_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0___redArg(v_range_3827_, v_b_3828_, v_i_3829_);
lean_dec_ref(v_range_3827_);
return v_res_3830_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros(lean_object* v_size_3831_){
_start:
{
lean_object* v_bytes_3832_; lean_object* v___x_3833_; lean_object* v___x_3834_; lean_object* v___x_3835_; lean_object* v___x_3836_; 
v_bytes_3832_ = lean_mk_empty_byte_array(v_size_3831_);
v___x_3833_ = lean_unsigned_to_nat(0u);
v___x_3834_ = lean_unsigned_to_nat(1u);
v___x_3835_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_3835_, 0, v___x_3833_);
lean_ctor_set(v___x_3835_, 1, v_size_3831_);
lean_ctor_set(v___x_3835_, 2, v___x_3834_);
v___x_3836_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0___redArg(v___x_3835_, v_bytes_3832_, v___x_3833_);
lean_dec_ref_known(v___x_3835_, 3);
return v___x_3836_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0(lean_object* v_range_3837_, lean_object* v_b_3838_, lean_object* v_i_3839_, lean_object* v_hs_3840_, lean_object* v_hl_3841_){
_start:
{
lean_object* v___x_3842_; 
v___x_3842_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0___redArg(v_range_3837_, v_b_3838_, v_i_3839_);
return v___x_3842_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0___boxed(lean_object* v_range_3843_, lean_object* v_b_3844_, lean_object* v_i_3845_, lean_object* v_hs_3846_, lean_object* v_hl_3847_){
_start:
{
lean_object* v_res_3848_; 
v_res_3848_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros_spec__0(v_range_3843_, v_b_3844_, v_i_3845_, v_hs_3846_, v_hl_3847_);
lean_dec_ref(v_range_3843_);
return v_res_3848_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1___redArg(uint8_t v_width_3849_, lean_object* v_val_3850_, lean_object* v_range_3851_, lean_object* v_b_3852_, lean_object* v_i_3853_){
_start:
{
lean_object* v_stop_3854_; lean_object* v_step_3855_; lean_object* v_a_3857_; uint64_t v___y_3861_; uint64_t v___y_3881_; uint8_t v___y_3882_; uint8_t v___x_3887_; 
v_stop_3854_ = lean_ctor_get(v_range_3851_, 1);
v_step_3855_ = lean_ctor_get(v_range_3851_, 2);
v___x_3887_ = lean_nat_dec_lt(v_i_3853_, v_stop_3854_);
if (v___x_3887_ == 0)
{
lean_dec(v_i_3853_);
return v_b_3852_;
}
else
{
uint8_t v___x_3888_; lean_object* v___x_3889_; lean_object* v_offset_3890_; uint64_t v___y_3892_; uint8_t v___y_3893_; uint64_t v___y_3906_; uint8_t v___y_3907_; uint8_t v___y_3920_; uint8_t v___y_3930_; lean_object* v___x_3960_; lean_object* v___x_3961_; uint8_t v___x_3962_; 
v___x_3888_ = 0;
v___x_3889_ = lean_unsigned_to_nat(4u);
v_offset_3890_ = lean_nat_mul(v_i_3853_, v___x_3889_);
v___x_3960_ = lean_nat_add(v_offset_3890_, v___x_3889_);
v___x_3961_ = lean_byte_array_size(v_val_3850_);
v___x_3962_ = lean_nat_dec_le(v___x_3960_, v___x_3961_);
if (v___x_3962_ == 0)
{
lean_dec(v___x_3960_);
v___y_3930_ = v___x_3962_;
goto v___jp_3929_;
}
else
{
size_t v___x_3963_; lean_object* v___x_3964_; uint8_t v___x_3965_; 
v___x_3963_ = lean_usize_of_nat(v___x_3960_);
v___x_3964_ = lean_usize_to_nat(v___x_3963_);
v___x_3965_ = lean_nat_dec_eq(v___x_3964_, v___x_3960_);
lean_dec(v___x_3960_);
lean_dec(v___x_3964_);
v___y_3930_ = v___x_3965_;
goto v___jp_3929_;
}
v___jp_3891_:
{
uint64_t v___x_3894_; uint64_t v___x_3895_; uint64_t v___x_3896_; uint64_t v___x_3897_; lean_object* v___x_3898_; lean_object* v___x_3899_; uint8_t v___x_3900_; 
v___x_3894_ = lean_uint8_to_uint64(v___y_3893_);
v___x_3895_ = 16ULL;
v___x_3896_ = lean_uint64_shift_left(v___x_3894_, v___x_3895_);
v___x_3897_ = lean_uint64_lor(v___y_3892_, v___x_3896_);
v___x_3898_ = lean_unsigned_to_nat(3u);
v___x_3899_ = lean_nat_add(v_offset_3890_, v___x_3898_);
lean_dec(v_offset_3890_);
v___x_3900_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_val_3850_, v___x_3899_);
if (v___x_3900_ == 0)
{
lean_object* v___x_3901_; lean_object* v___x_3902_; uint8_t v___x_3903_; 
lean_dec(v___x_3899_);
v___x_3901_ = lean_box(v___x_3888_);
v___x_3902_ = l_outOfBounds___redArg(v___x_3901_);
lean_dec(v___x_3901_);
v___x_3903_ = lean_unbox(v___x_3902_);
lean_dec(v___x_3902_);
v___y_3881_ = v___x_3897_;
v___y_3882_ = v___x_3903_;
goto v___jp_3880_;
}
else
{
uint8_t v___x_3904_; 
v___x_3904_ = lean_byte_array_fget(v_val_3850_, v___x_3899_);
lean_dec(v___x_3899_);
v___y_3881_ = v___x_3897_;
v___y_3882_ = v___x_3904_;
goto v___jp_3880_;
}
}
v___jp_3905_:
{
uint64_t v___x_3908_; uint64_t v___x_3909_; uint64_t v___x_3910_; uint64_t v___x_3911_; lean_object* v___x_3912_; lean_object* v___x_3913_; uint8_t v___x_3914_; 
v___x_3908_ = lean_uint8_to_uint64(v___y_3907_);
v___x_3909_ = 8ULL;
v___x_3910_ = lean_uint64_shift_left(v___x_3908_, v___x_3909_);
v___x_3911_ = lean_uint64_lor(v___y_3906_, v___x_3910_);
v___x_3912_ = lean_unsigned_to_nat(2u);
v___x_3913_ = lean_nat_add(v_offset_3890_, v___x_3912_);
v___x_3914_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_val_3850_, v___x_3913_);
if (v___x_3914_ == 0)
{
lean_object* v___x_3915_; lean_object* v___x_3916_; uint8_t v___x_3917_; 
lean_dec(v___x_3913_);
v___x_3915_ = lean_box(v___x_3888_);
v___x_3916_ = l_outOfBounds___redArg(v___x_3915_);
lean_dec(v___x_3915_);
v___x_3917_ = lean_unbox(v___x_3916_);
lean_dec(v___x_3916_);
v___y_3892_ = v___x_3911_;
v___y_3893_ = v___x_3917_;
goto v___jp_3891_;
}
else
{
uint8_t v___x_3918_; 
v___x_3918_ = lean_byte_array_fget(v_val_3850_, v___x_3913_);
lean_dec(v___x_3913_);
v___y_3892_ = v___x_3911_;
v___y_3893_ = v___x_3918_;
goto v___jp_3891_;
}
}
v___jp_3919_:
{
uint64_t v_a_3921_; lean_object* v___x_3922_; lean_object* v___x_3923_; uint8_t v___x_3924_; 
v_a_3921_ = lean_uint8_to_uint64(v___y_3920_);
v___x_3922_ = lean_unsigned_to_nat(1u);
v___x_3923_ = lean_nat_add(v_offset_3890_, v___x_3922_);
v___x_3924_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_val_3850_, v___x_3923_);
if (v___x_3924_ == 0)
{
lean_object* v___x_3925_; lean_object* v___x_3926_; uint8_t v___x_3927_; 
lean_dec(v___x_3923_);
v___x_3925_ = lean_box(v___x_3888_);
v___x_3926_ = l_outOfBounds___redArg(v___x_3925_);
lean_dec(v___x_3925_);
v___x_3927_ = lean_unbox(v___x_3926_);
lean_dec(v___x_3926_);
v___y_3906_ = v_a_3921_;
v___y_3907_ = v___x_3927_;
goto v___jp_3905_;
}
else
{
uint8_t v___x_3928_; 
v___x_3928_ = lean_byte_array_fget(v_val_3850_, v___x_3923_);
lean_dec(v___x_3923_);
v___y_3906_ = v_a_3921_;
v___y_3907_ = v___x_3928_;
goto v___jp_3905_;
}
}
v___jp_3929_:
{
if (v___y_3930_ == 0)
{
uint8_t v___x_3931_; 
v___x_3931_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_val_3850_, v_offset_3890_);
if (v___x_3931_ == 0)
{
lean_object* v___x_3932_; lean_object* v___x_3933_; uint8_t v___x_3934_; 
v___x_3932_ = lean_box(v___x_3888_);
v___x_3933_ = l_outOfBounds___redArg(v___x_3932_);
lean_dec(v___x_3932_);
v___x_3934_ = lean_unbox(v___x_3933_);
lean_dec(v___x_3933_);
v___y_3920_ = v___x_3934_;
goto v___jp_3919_;
}
else
{
uint8_t v___x_3935_; 
v___x_3935_ = lean_byte_array_fget(v_val_3850_, v_offset_3890_);
v___y_3920_ = v___x_3935_;
goto v___jp_3919_;
}
}
else
{
size_t v_pos_3936_; uint8_t v___x_3937_; uint64_t v_a_3938_; size_t v___x_3939_; size_t v___x_3940_; uint8_t v___x_3941_; uint64_t v___x_3942_; uint64_t v___x_3943_; uint64_t v___x_3944_; uint64_t v___x_3945_; size_t v___x_3946_; size_t v___x_3947_; uint8_t v___x_3948_; uint64_t v___x_3949_; uint64_t v___x_3950_; uint64_t v___x_3951_; uint64_t v___x_3952_; size_t v___x_3953_; size_t v___x_3954_; uint8_t v___x_3955_; uint64_t v___x_3956_; uint64_t v___x_3957_; uint64_t v___x_3958_; uint64_t v___x_3959_; 
v_pos_3936_ = lean_usize_of_nat(v_offset_3890_);
lean_dec(v_offset_3890_);
v___x_3937_ = lean_byte_array_uget(v_val_3850_, v_pos_3936_);
v_a_3938_ = lean_uint8_to_uint64(v___x_3937_);
v___x_3939_ = ((size_t)1ULL);
v___x_3940_ = lean_usize_add(v_pos_3936_, v___x_3939_);
v___x_3941_ = lean_byte_array_uget(v_val_3850_, v___x_3940_);
v___x_3942_ = lean_uint8_to_uint64(v___x_3941_);
v___x_3943_ = 8ULL;
v___x_3944_ = lean_uint64_shift_left(v___x_3942_, v___x_3943_);
v___x_3945_ = lean_uint64_lor(v_a_3938_, v___x_3944_);
v___x_3946_ = ((size_t)2ULL);
v___x_3947_ = lean_usize_add(v_pos_3936_, v___x_3946_);
v___x_3948_ = lean_byte_array_uget(v_val_3850_, v___x_3947_);
v___x_3949_ = lean_uint8_to_uint64(v___x_3948_);
v___x_3950_ = 16ULL;
v___x_3951_ = lean_uint64_shift_left(v___x_3949_, v___x_3950_);
v___x_3952_ = lean_uint64_lor(v___x_3945_, v___x_3951_);
v___x_3953_ = ((size_t)3ULL);
v___x_3954_ = lean_usize_add(v_pos_3936_, v___x_3953_);
v___x_3955_ = lean_byte_array_uget(v_val_3850_, v___x_3954_);
v___x_3956_ = lean_uint8_to_uint64(v___x_3955_);
v___x_3957_ = 24ULL;
v___x_3958_ = lean_uint64_shift_left(v___x_3956_, v___x_3957_);
v___x_3959_ = lean_uint64_lor(v___x_3952_, v___x_3958_);
v___y_3861_ = v___x_3959_;
goto v___jp_3860_;
}
}
}
v___jp_3856_:
{
lean_object* v___x_3858_; 
v___x_3858_ = lean_nat_add(v_i_3853_, v_step_3855_);
lean_dec(v_i_3853_);
v_b_3852_ = v_a_3857_;
v_i_3853_ = v___x_3858_;
goto _start;
}
v___jp_3860_:
{
uint8_t v___x_3862_; lean_object* v_data_3863_; 
v___x_3862_ = lean_uint64_to_uint8(v___y_3861_);
v_data_3863_ = lean_byte_array_push(v_b_3852_, v___x_3862_);
switch(v_width_3849_)
{
case 0:
{
v_a_3857_ = v_data_3863_;
goto v___jp_3856_;
}
case 1:
{
uint64_t v___x_3864_; uint64_t v___x_3865_; uint8_t v___x_3866_; lean_object* v___x_3867_; 
v___x_3864_ = 8ULL;
v___x_3865_ = lean_uint64_shift_right(v___y_3861_, v___x_3864_);
v___x_3866_ = lean_uint64_to_uint8(v___x_3865_);
v___x_3867_ = lean_byte_array_push(v_data_3863_, v___x_3866_);
v_a_3857_ = v___x_3867_;
goto v___jp_3856_;
}
default: 
{
uint64_t v___x_3868_; uint64_t v___x_3869_; uint8_t v___x_3870_; lean_object* v___x_3871_; uint64_t v___x_3872_; uint64_t v___x_3873_; uint8_t v___x_3874_; lean_object* v___x_3875_; uint64_t v___x_3876_; uint64_t v___x_3877_; uint8_t v___x_3878_; lean_object* v___x_3879_; 
v___x_3868_ = 8ULL;
v___x_3869_ = lean_uint64_shift_right(v___y_3861_, v___x_3868_);
v___x_3870_ = lean_uint64_to_uint8(v___x_3869_);
v___x_3871_ = lean_byte_array_push(v_data_3863_, v___x_3870_);
v___x_3872_ = 16ULL;
v___x_3873_ = lean_uint64_shift_right(v___y_3861_, v___x_3872_);
v___x_3874_ = lean_uint64_to_uint8(v___x_3873_);
v___x_3875_ = lean_byte_array_push(v___x_3871_, v___x_3874_);
v___x_3876_ = 24ULL;
v___x_3877_ = lean_uint64_shift_right(v___y_3861_, v___x_3876_);
v___x_3878_ = lean_uint64_to_uint8(v___x_3877_);
v___x_3879_ = lean_byte_array_push(v___x_3875_, v___x_3878_);
v_a_3857_ = v___x_3879_;
goto v___jp_3856_;
}
}
}
v___jp_3880_:
{
uint64_t v___x_3883_; uint64_t v___x_3884_; uint64_t v___x_3885_; uint64_t v___x_3886_; 
v___x_3883_ = lean_uint8_to_uint64(v___y_3882_);
v___x_3884_ = 24ULL;
v___x_3885_ = lean_uint64_shift_left(v___x_3883_, v___x_3884_);
v___x_3886_ = lean_uint64_lor(v___y_3881_, v___x_3885_);
v___y_3861_ = v___x_3886_;
goto v___jp_3860_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1___redArg___boxed(lean_object* v_width_3966_, lean_object* v_val_3967_, lean_object* v_range_3968_, lean_object* v_b_3969_, lean_object* v_i_3970_){
_start:
{
uint8_t v_width_boxed_3971_; lean_object* v_res_3972_; 
v_width_boxed_3971_ = lean_unbox(v_width_3966_);
v_res_3972_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1___redArg(v_width_boxed_3971_, v_val_3967_, v_range_3968_, v_b_3969_, v_i_3970_);
lean_dec_ref(v_range_3968_);
lean_dec_ref(v_val_3967_);
return v_res_3972_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1(lean_object* v_val_3973_, lean_object* v_table_3974_, uint8_t v_width_3975_, uint64_t v_degree_3976_, uint64_t v_mask_3977_, uint64_t v_hash_3978_, lean_object* v_bucket_3979_, lean_object* v_work_3980_, lean_object* v_maxCount_3981_, lean_object* v_maxBytes_3982_, lean_object* v_maxWork_3983_){
_start:
{
lean_object* v_arity_3984_; uint8_t v_width_3985_; lean_object* v_exponents_3986_; lean_object* v_metadata_3987_; lean_object* v_count_3988_; lean_object* v_workspace_3989_; lean_object* v_buckets_3990_; lean_object* v_products_3991_; lean_object* v_hashBits_3992_; uint8_t v___x_3993_; 
v_arity_3984_ = lean_ctor_get(v_table_3974_, 0);
v_width_3985_ = lean_ctor_get_uint8(v_table_3974_, sizeof(void*)*9);
v_exponents_3986_ = lean_ctor_get(v_table_3974_, 1);
v_metadata_3987_ = lean_ctor_get(v_table_3974_, 2);
v_count_3988_ = lean_ctor_get(v_table_3974_, 3);
v_workspace_3989_ = lean_ctor_get(v_table_3974_, 4);
v_buckets_3990_ = lean_ctor_get(v_table_3974_, 5);
v_products_3991_ = lean_ctor_get(v_table_3974_, 6);
v_hashBits_3992_ = lean_ctor_get(v_table_3974_, 7);
v___x_3993_ = lean_nat_dec_le(v_maxCount_3981_, v_count_3988_);
if (v___x_3993_ == 0)
{
lean_object* v___x_3994_; lean_object* v___x_3995_; lean_object* v___y_3997_; lean_object* v_arity_3998_; uint8_t v_width_3999_; lean_object* v_exponents_4000_; lean_object* v_metadata_4001_; lean_object* v_count_4002_; lean_object* v_workspace_4003_; lean_object* v_buckets_4004_; lean_object* v_products_4005_; lean_object* v_hashBits_4006_; lean_object* v___y_4020_; lean_object* v___y_4021_; lean_object* v___y_4040_; uint8_t v___y_4041_; lean_object* v___y_4042_; lean_object* v___y_4059_; uint8_t v___y_4060_; lean_object* v___x_4062_; uint8_t v___x_4063_; lean_object* v___y_4065_; lean_object* v___y_4066_; lean_object* v___y_4072_; lean_object* v___y_4073_; lean_object* v___y_4074_; 
v___x_3994_ = lean_unsigned_to_nat(4294967295u);
v___x_3995_ = lean_unsigned_to_nat(1u);
v___x_4062_ = lean_nat_add(v_count_3988_, v___x_3995_);
v___x_4063_ = lean_nat_dec_lt(v___x_3994_, v___x_4062_);
if (v___x_4063_ == 0)
{
lean_object* v___x_4076_; lean_object* v___y_4078_; 
v___x_4076_ = lean_nat_mul(v___x_4062_, v_arity_3984_);
switch(v_width_3975_)
{
case 0:
{
v___y_4078_ = v___x_3995_;
goto v___jp_4077_;
}
case 1:
{
lean_object* v___x_4096_; 
v___x_4096_ = lean_unsigned_to_nat(2u);
v___y_4078_ = v___x_4096_;
goto v___jp_4077_;
}
default: 
{
lean_object* v___x_4097_; 
v___x_4097_ = lean_unsigned_to_nat(4u);
v___y_4078_ = v___x_4097_;
goto v___jp_4077_;
}
}
v___jp_4077_:
{
lean_object* v_size_4079_; lean_object* v___x_4080_; lean_object* v___x_4081_; lean_object* v___x_4082_; lean_object* v_size_4083_; lean_object* v___x_4084_; lean_object* v___x_4085_; lean_object* v___x_4086_; lean_object* v___x_4087_; lean_object* v___x_4088_; uint8_t v___x_4089_; 
v_size_4079_ = lean_ctor_get(v_products_3991_, 0);
v___x_4080_ = lean_nat_mul(v___x_4076_, v___y_4078_);
lean_dec(v___x_4076_);
v___x_4081_ = lean_unsigned_to_nat(24u);
v___x_4082_ = lean_nat_mul(v___x_4062_, v___x_4081_);
lean_dec(v___x_4062_);
v_size_4083_ = lean_nat_add(v___x_4080_, v___x_4082_);
lean_dec(v___x_4082_);
lean_dec(v___x_4080_);
v___x_4084_ = lean_unsigned_to_nat(12u);
v___x_4085_ = lean_nat_mul(v___x_4084_, v_size_4079_);
v___x_4086_ = lean_nat_add(v_size_4083_, v___x_4085_);
lean_dec(v___x_4085_);
lean_dec(v_size_4083_);
v___x_4087_ = lean_byte_array_size(v_workspace_3989_);
v___x_4088_ = lean_unsigned_to_nat(0u);
v___x_4089_ = lean_nat_dec_lt(v___x_4088_, v_arity_3984_);
if (v___x_4089_ == 0)
{
v___y_4072_ = v___x_4086_;
v___y_4073_ = v___x_4087_;
v___y_4074_ = v___x_4088_;
goto v___jp_4071_;
}
else
{
lean_object* v___x_4090_; uint8_t v___x_4091_; 
v___x_4090_ = lean_unsigned_to_nat(4096u);
v___x_4091_ = lean_nat_dec_le(v_arity_3984_, v___x_4090_);
if (v___x_4091_ == 0)
{
v___y_4072_ = v___x_4086_;
v___y_4073_ = v___x_4087_;
v___y_4074_ = v___x_4088_;
goto v___jp_4071_;
}
else
{
lean_object* v___x_4092_; lean_object* v___x_4093_; lean_object* v___x_4094_; lean_object* v___x_4095_; 
v___x_4092_ = lean_unsigned_to_nat(4u);
v___x_4093_ = lean_nat_mul(v_arity_3984_, v___x_4092_);
v___x_4094_ = lean_unsigned_to_nat(28u);
v___x_4095_ = lean_nat_add(v___x_4093_, v___x_4094_);
lean_dec(v___x_4093_);
v___y_4072_ = v___x_4086_;
v___y_4073_ = v___x_4087_;
v___y_4074_ = v___x_4095_;
goto v___jp_4071_;
}
}
}
}
else
{
uint8_t v___x_4098_; lean_object* v___x_4099_; lean_object* v___x_4100_; lean_object* v___x_4101_; 
lean_dec(v___x_4062_);
lean_dec(v_maxWork_3983_);
lean_dec_ref(v_bucket_3979_);
v___x_4098_ = 1;
v___x_4099_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4099_, 0, v_work_3980_);
lean_ctor_set_uint8(v___x_4099_, sizeof(void*)*1, v___x_4098_);
v___x_4100_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4100_, 0, v___x_4099_);
v___x_4101_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4101_, 0, v___x_4100_);
lean_ctor_set(v___x_4101_, 1, v_table_3974_);
return v___x_4101_;
}
v___jp_3996_:
{
lean_object* v___x_4007_; lean_object* v___x_4008_; lean_object* v___x_4009_; lean_object* v___x_4010_; lean_object* v___x_4011_; lean_object* v___x_4012_; lean_object* v___x_4013_; lean_object* v___x_4014_; lean_object* v___x_4015_; lean_object* v___x_4016_; lean_object* v___x_4017_; lean_object* v___x_4018_; 
v___x_4007_ = lean_unsigned_to_nat(0u);
lean_inc(v_arity_3998_);
v___x_4008_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_4008_, 0, v___x_4007_);
lean_ctor_set(v___x_4008_, 1, v_arity_3998_);
lean_ctor_set(v___x_4008_, 2, v___x_3995_);
v___x_4009_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1___redArg(v_width_3975_, v_val_3973_, v___x_4008_, v_exponents_4000_, v___x_4007_);
lean_dec_ref_known(v___x_4008_, 3);
v___x_4010_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v_metadata_4001_, v_degree_3976_);
v___x_4011_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v___x_4010_, v_mask_3977_);
v___x_4012_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_push64(v___x_4011_, v_hash_3978_);
lean_inc(v_count_4002_);
v___x_4013_ = lean_array_push(v_bucket_3979_, v_count_4002_);
v___x_4014_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00Hex_Groebner_MonomialTable_internOwned_spec__2_spec__3___redArg(v_buckets_4004_, v_hash_3978_, v___x_4013_);
v___x_4015_ = lean_nat_add(v_count_4002_, v___x_3995_);
v___x_4016_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_4016_, 0, v_arity_3998_);
lean_ctor_set(v___x_4016_, 1, v___x_4009_);
lean_ctor_set(v___x_4016_, 2, v___x_4012_);
lean_ctor_set(v___x_4016_, 3, v___x_4015_);
lean_ctor_set(v___x_4016_, 4, v_workspace_4003_);
lean_ctor_set(v___x_4016_, 5, v___x_4014_);
lean_ctor_set(v___x_4016_, 6, v_products_4005_);
lean_ctor_set(v___x_4016_, 7, v_hashBits_4006_);
lean_ctor_set(v___x_4016_, 8, v___y_3997_);
lean_ctor_set_uint8(v___x_4016_, sizeof(void*)*9, v_width_3999_);
v___x_4017_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_4017_, 0, v_count_4002_);
v___x_4018_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4018_, 0, v___x_4017_);
lean_ctor_set(v___x_4018_, 1, v___x_4016_);
return v___x_4018_;
}
v___jp_4019_:
{
lean_object* v_work_4022_; uint8_t v___x_4023_; 
v_work_4022_ = lean_nat_add(v___y_4020_, v___y_4021_);
lean_dec(v___y_4021_);
lean_dec(v___y_4020_);
v___x_4023_ = lean_nat_dec_lt(v_maxWork_3983_, v_work_4022_);
if (v___x_4023_ == 0)
{
uint8_t v___x_4024_; 
lean_dec(v_maxWork_3983_);
v___x_4024_ = lp_Hex_Hex_Groebner_instBEqWidth_beq(v_width_3975_, v_width_3985_);
if (v___x_4024_ == 0)
{
lean_object* v___x_4025_; lean_object* v_arity_4026_; uint8_t v_width_4027_; lean_object* v_exponents_4028_; lean_object* v_metadata_4029_; lean_object* v_count_4030_; lean_object* v_workspace_4031_; lean_object* v_buckets_4032_; lean_object* v_products_4033_; lean_object* v_hashBits_4034_; 
v___x_4025_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_widen(v_table_3974_, v_width_3975_);
v_arity_4026_ = lean_ctor_get(v___x_4025_, 0);
lean_inc(v_arity_4026_);
v_width_4027_ = lean_ctor_get_uint8(v___x_4025_, sizeof(void*)*9);
v_exponents_4028_ = lean_ctor_get(v___x_4025_, 1);
lean_inc_ref(v_exponents_4028_);
v_metadata_4029_ = lean_ctor_get(v___x_4025_, 2);
lean_inc_ref(v_metadata_4029_);
v_count_4030_ = lean_ctor_get(v___x_4025_, 3);
lean_inc(v_count_4030_);
v_workspace_4031_ = lean_ctor_get(v___x_4025_, 4);
lean_inc_ref(v_workspace_4031_);
v_buckets_4032_ = lean_ctor_get(v___x_4025_, 5);
lean_inc_ref(v_buckets_4032_);
v_products_4033_ = lean_ctor_get(v___x_4025_, 6);
lean_inc_ref(v_products_4033_);
v_hashBits_4034_ = lean_ctor_get(v___x_4025_, 7);
lean_inc(v_hashBits_4034_);
lean_dec_ref(v___x_4025_);
v___y_3997_ = v_work_4022_;
v_arity_3998_ = v_arity_4026_;
v_width_3999_ = v_width_4027_;
v_exponents_4000_ = v_exponents_4028_;
v_metadata_4001_ = v_metadata_4029_;
v_count_4002_ = v_count_4030_;
v_workspace_4003_ = v_workspace_4031_;
v_buckets_4004_ = v_buckets_4032_;
v_products_4005_ = v_products_4033_;
v_hashBits_4006_ = v_hashBits_4034_;
goto v___jp_3996_;
}
else
{
lean_inc(v_hashBits_3992_);
lean_inc_ref(v_products_3991_);
lean_inc_ref(v_buckets_3990_);
lean_inc_ref(v_workspace_3989_);
lean_inc(v_count_3988_);
lean_inc_ref(v_metadata_3987_);
lean_inc_ref(v_exponents_3986_);
lean_inc(v_arity_3984_);
lean_dec_ref(v_table_3974_);
v___y_3997_ = v_work_4022_;
v_arity_3998_ = v_arity_3984_;
v_width_3999_ = v_width_3985_;
v_exponents_4000_ = v_exponents_3986_;
v_metadata_4001_ = v_metadata_3987_;
v_count_4002_ = v_count_3988_;
v_workspace_4003_ = v_workspace_3989_;
v_buckets_4004_ = v_buckets_3990_;
v_products_4005_ = v_products_3991_;
v_hashBits_4006_ = v_hashBits_3992_;
goto v___jp_3996_;
}
}
else
{
uint8_t v___x_4035_; lean_object* v___x_4036_; lean_object* v___x_4037_; lean_object* v___x_4038_; 
lean_dec(v_work_4022_);
lean_dec_ref(v_bucket_3979_);
v___x_4035_ = 8;
v___x_4036_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4036_, 0, v_maxWork_3983_);
lean_ctor_set_uint8(v___x_4036_, sizeof(void*)*1, v___x_4035_);
v___x_4037_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4037_, 0, v___x_4036_);
v___x_4038_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4038_, 0, v___x_4037_);
lean_ctor_set(v___x_4038_, 1, v_table_3974_);
return v___x_4038_;
}
}
v___jp_4039_:
{
lean_object* v_peak_4043_; uint8_t v___x_4044_; 
v_peak_4043_ = lean_nat_add(v___y_4040_, v___y_4042_);
lean_dec(v___y_4042_);
lean_dec(v___y_4040_);
v___x_4044_ = lean_nat_dec_lt(v_maxBytes_3982_, v_peak_4043_);
if (v___x_4044_ == 0)
{
lean_object* v___x_4045_; uint8_t v___x_4046_; 
v___x_4045_ = lean_obj_once(&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12, &lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12_once, _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12);
v___x_4046_ = lean_nat_dec_le(v___x_4045_, v_peak_4043_);
lean_dec(v_peak_4043_);
if (v___x_4046_ == 0)
{
lean_object* v___x_4047_; 
v___x_4047_ = lean_nat_add(v_work_3980_, v_arity_3984_);
lean_dec(v_work_3980_);
if (v___y_4041_ == 0)
{
lean_object* v___x_4048_; 
v___x_4048_ = lean_unsigned_to_nat(0u);
v___y_4020_ = v___x_4047_;
v___y_4021_ = v___x_4048_;
goto v___jp_4019_;
}
else
{
lean_object* v___x_4049_; 
v___x_4049_ = lean_nat_mul(v_count_3988_, v_arity_3984_);
v___y_4020_ = v___x_4047_;
v___y_4021_ = v___x_4049_;
goto v___jp_4019_;
}
}
else
{
uint8_t v___x_4050_; lean_object* v___x_4051_; lean_object* v___x_4052_; lean_object* v___x_4053_; 
lean_dec(v_maxWork_3983_);
lean_dec_ref(v_bucket_3979_);
v___x_4050_ = 4;
v___x_4051_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4051_, 0, v_work_3980_);
lean_ctor_set_uint8(v___x_4051_, sizeof(void*)*1, v___x_4050_);
v___x_4052_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4052_, 0, v___x_4051_);
v___x_4053_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4053_, 0, v___x_4052_);
lean_ctor_set(v___x_4053_, 1, v_table_3974_);
return v___x_4053_;
}
}
else
{
uint8_t v___x_4054_; lean_object* v___x_4055_; lean_object* v___x_4056_; lean_object* v___x_4057_; 
lean_dec(v_peak_4043_);
lean_dec(v_maxWork_3983_);
lean_dec_ref(v_bucket_3979_);
v___x_4054_ = 7;
v___x_4055_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4055_, 0, v_work_3980_);
lean_ctor_set_uint8(v___x_4055_, sizeof(void*)*1, v___x_4054_);
v___x_4056_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4056_, 0, v___x_4055_);
v___x_4057_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4057_, 0, v___x_4056_);
lean_ctor_set(v___x_4057_, 1, v_table_3974_);
return v___x_4057_;
}
}
v___jp_4058_:
{
lean_object* v___x_4061_; 
v___x_4061_ = lean_byte_array_size(v_exponents_3986_);
v___y_4040_ = v___y_4059_;
v___y_4041_ = v___y_4060_;
v___y_4042_ = v___x_4061_;
goto v___jp_4039_;
}
v___jp_4064_:
{
lean_object* v___x_4067_; uint8_t v___x_4068_; 
v___x_4067_ = lean_nat_add(v___y_4065_, v___y_4066_);
lean_dec(v___y_4066_);
lean_dec(v___y_4065_);
v___x_4068_ = lp_Hex_Hex_Groebner_instBEqWidth_beq(v_width_3975_, v_width_3985_);
if (v___x_4068_ == 0)
{
uint8_t v___x_4069_; 
v___x_4069_ = 1;
v___y_4059_ = v___x_4067_;
v___y_4060_ = v___x_4069_;
goto v___jp_4058_;
}
else
{
if (v___x_4063_ == 0)
{
lean_object* v___x_4070_; 
v___x_4070_ = lean_unsigned_to_nat(0u);
v___y_4040_ = v___x_4067_;
v___y_4041_ = v___x_4063_;
v___y_4042_ = v___x_4070_;
goto v___jp_4039_;
}
else
{
v___y_4059_ = v___x_4067_;
v___y_4060_ = v___x_4063_;
goto v___jp_4058_;
}
}
}
v___jp_4071_:
{
uint8_t v___x_4075_; 
v___x_4075_ = lean_nat_dec_le(v___y_4073_, v___y_4074_);
if (v___x_4075_ == 0)
{
lean_dec(v___y_4074_);
v___y_4065_ = v___y_4072_;
v___y_4066_ = v___y_4073_;
goto v___jp_4064_;
}
else
{
lean_dec(v___y_4073_);
v___y_4065_ = v___y_4072_;
v___y_4066_ = v___y_4074_;
goto v___jp_4064_;
}
}
}
else
{
uint8_t v___x_4102_; lean_object* v___x_4103_; lean_object* v___x_4104_; lean_object* v___x_4105_; 
lean_dec(v_maxWork_3983_);
lean_dec_ref(v_bucket_3979_);
v___x_4102_ = 6;
v___x_4103_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4103_, 0, v_work_3980_);
lean_ctor_set_uint8(v___x_4103_, sizeof(void*)*1, v___x_4102_);
v___x_4104_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4104_, 0, v___x_4103_);
v___x_4105_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4105_, 0, v___x_4104_);
lean_ctor_set(v___x_4105_, 1, v_table_3974_);
return v___x_4105_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1___boxed(lean_object* v_val_4106_, lean_object* v_table_4107_, lean_object* v_width_4108_, lean_object* v_degree_4109_, lean_object* v_mask_4110_, lean_object* v_hash_4111_, lean_object* v_bucket_4112_, lean_object* v_work_4113_, lean_object* v_maxCount_4114_, lean_object* v_maxBytes_4115_, lean_object* v_maxWork_4116_){
_start:
{
uint8_t v_width_boxed_4117_; uint64_t v_degree_boxed_4118_; uint64_t v_mask_boxed_4119_; uint64_t v_hash_boxed_4120_; lean_object* v_res_4121_; 
v_width_boxed_4117_ = lean_unbox(v_width_4108_);
v_degree_boxed_4118_ = lean_unbox_uint64(v_degree_4109_);
lean_dec_ref(v_degree_4109_);
v_mask_boxed_4119_ = lean_unbox_uint64(v_mask_4110_);
lean_dec_ref(v_mask_4110_);
v_hash_boxed_4120_ = lean_unbox_uint64(v_hash_4111_);
lean_dec_ref(v_hash_4111_);
v_res_4121_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1(v_val_4106_, v_table_4107_, v_width_boxed_4117_, v_degree_boxed_4118_, v_mask_boxed_4119_, v_hash_boxed_4120_, v_bucket_4112_, v_work_4113_, v_maxCount_4114_, v_maxBytes_4115_, v_maxWork_4116_);
lean_dec(v_maxBytes_4115_);
lean_dec(v_maxCount_4114_);
lean_dec_ref(v_val_4106_);
return v_res_4121_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__0(lean_object* v___x_4122_, lean_object* v___x_4123_, lean_object* v_val_4124_, uint8_t v___x_4125_, lean_object* v___x_4126_, lean_object* v___x_4127_, lean_object* v___x_4128_, lean_object* v___x_4129_, lean_object* v___x_4130_, lean_object* v_maxWork_4131_, lean_object* v_initialWork_4132_, lean_object* v_as_4133_, size_t v_sz_4134_, size_t v_i_4135_, lean_object* v_b_4136_){
_start:
{
uint8_t v___x_4137_; 
v___x_4137_ = lean_usize_dec_lt(v_i_4135_, v_sz_4134_);
if (v___x_4137_ == 0)
{
lean_dec(v_initialWork_4132_);
lean_dec(v_maxWork_4131_);
lean_dec(v___x_4130_);
lean_dec_ref(v___x_4129_);
lean_dec_ref(v___x_4128_);
lean_dec(v___x_4127_);
lean_dec_ref(v___x_4126_);
lean_dec_ref(v_val_4124_);
lean_dec_ref(v___x_4123_);
lean_dec(v___x_4122_);
return v_b_4136_;
}
else
{
lean_object* v_snd_4138_; lean_object* v___x_4140_; uint8_t v_isShared_4141_; uint8_t v_isSharedCheck_4187_; 
v_snd_4138_ = lean_ctor_get(v_b_4136_, 1);
v_isSharedCheck_4187_ = !lean_is_exclusive(v_b_4136_);
if (v_isSharedCheck_4187_ == 0)
{
lean_object* v_unused_4188_; 
v_unused_4188_ = lean_ctor_get(v_b_4136_, 0);
lean_dec(v_unused_4188_);
v___x_4140_ = v_b_4136_;
v_isShared_4141_ = v_isSharedCheck_4187_;
goto v_resetjp_4139_;
}
else
{
lean_inc(v_snd_4138_);
lean_dec(v_b_4136_);
v___x_4140_ = lean_box(0);
v_isShared_4141_ = v_isSharedCheck_4187_;
goto v_resetjp_4139_;
}
v_resetjp_4139_:
{
lean_object* v___x_4142_; uint8_t v___x_4143_; 
v___x_4142_ = lean_nat_add(v_snd_4138_, v___x_4122_);
lean_dec(v_snd_4138_);
v___x_4143_ = lean_nat_dec_lt(v_maxWork_4131_, v___x_4142_);
if (v___x_4143_ == 0)
{
lean_object* v_a_4144_; uint8_t v___x_4145_; 
v_a_4144_ = lean_array_uget_borrowed(v_as_4133_, v_i_4135_);
v___x_4145_ = lean_nat_dec_le(v___x_4127_, v_a_4144_);
if (v___x_4145_ == 0)
{
lean_object* v___x_4146_; lean_object* v___y_4148_; 
v___x_4146_ = lean_box(0);
switch(v___x_4125_)
{
case 0:
{
lean_object* v___x_4166_; 
v___x_4166_ = lean_unsigned_to_nat(1u);
v___y_4148_ = v___x_4166_;
goto v___jp_4147_;
}
case 1:
{
lean_object* v___x_4167_; 
v___x_4167_ = lean_unsigned_to_nat(2u);
v___y_4148_ = v___x_4167_;
goto v___jp_4147_;
}
default: 
{
lean_object* v___x_4168_; 
v___x_4168_ = lean_unsigned_to_nat(4u);
v___y_4148_ = v___x_4168_;
goto v___jp_4147_;
}
}
v___jp_4147_:
{
uint8_t v___x_4149_; uint64_t v___x_4150_; uint64_t v___x_4151_; uint8_t v___x_4152_; 
v___x_4149_ = lean_uint8_of_nat(v___y_4148_);
v___x_4150_ = lean_uint64_of_nat(v___x_4122_);
v___x_4151_ = lean_uint64_of_nat(v_a_4144_);
v___x_4152_ = lean_hex_groebner_equal_monomial(v___x_4149_, v___x_4150_, v___x_4151_, v___x_4123_, v_val_4124_);
if (v___x_4152_ == 0)
{
lean_object* v___x_4154_; 
if (v_isShared_4141_ == 0)
{
lean_ctor_set(v___x_4140_, 1, v___x_4142_);
lean_ctor_set(v___x_4140_, 0, v___x_4146_);
v___x_4154_ = v___x_4140_;
goto v_reusejp_4153_;
}
else
{
lean_object* v_reuseFailAlloc_4158_; 
v_reuseFailAlloc_4158_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4158_, 0, v___x_4146_);
lean_ctor_set(v_reuseFailAlloc_4158_, 1, v___x_4142_);
v___x_4154_ = v_reuseFailAlloc_4158_;
goto v_reusejp_4153_;
}
v_reusejp_4153_:
{
size_t v___x_4155_; size_t v___x_4156_; 
v___x_4155_ = ((size_t)1ULL);
v___x_4156_ = lean_usize_add(v_i_4135_, v___x_4155_);
v_i_4135_ = v___x_4156_;
v_b_4136_ = v___x_4154_;
goto _start;
}
}
else
{
lean_object* v___x_4159_; lean_object* v___x_4160_; lean_object* v___x_4161_; lean_object* v___x_4162_; lean_object* v___x_4164_; 
lean_dec(v_initialWork_4132_);
lean_dec(v_maxWork_4131_);
lean_inc(v_a_4144_);
v___x_4159_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_4159_, 0, v_a_4144_);
lean_inc(v___x_4142_);
v___x_4160_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_4160_, 0, v___x_4122_);
lean_ctor_set(v___x_4160_, 1, v___x_4123_);
lean_ctor_set(v___x_4160_, 2, v___x_4126_);
lean_ctor_set(v___x_4160_, 3, v___x_4127_);
lean_ctor_set(v___x_4160_, 4, v_val_4124_);
lean_ctor_set(v___x_4160_, 5, v___x_4128_);
lean_ctor_set(v___x_4160_, 6, v___x_4129_);
lean_ctor_set(v___x_4160_, 7, v___x_4130_);
lean_ctor_set(v___x_4160_, 8, v___x_4142_);
lean_ctor_set_uint8(v___x_4160_, sizeof(void*)*9, v___x_4125_);
v___x_4161_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4161_, 0, v___x_4159_);
lean_ctor_set(v___x_4161_, 1, v___x_4160_);
v___x_4162_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_4162_, 0, v___x_4161_);
if (v_isShared_4141_ == 0)
{
lean_ctor_set(v___x_4140_, 1, v___x_4142_);
lean_ctor_set(v___x_4140_, 0, v___x_4162_);
v___x_4164_ = v___x_4140_;
goto v_reusejp_4163_;
}
else
{
lean_object* v_reuseFailAlloc_4165_; 
v_reuseFailAlloc_4165_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4165_, 0, v___x_4162_);
lean_ctor_set(v_reuseFailAlloc_4165_, 1, v___x_4142_);
v___x_4164_ = v_reuseFailAlloc_4165_;
goto v_reusejp_4163_;
}
v_reusejp_4163_:
{
return v___x_4164_;
}
}
}
}
else
{
uint8_t v___x_4169_; lean_object* v___x_4170_; lean_object* v___x_4171_; lean_object* v___x_4172_; lean_object* v___x_4173_; lean_object* v___x_4174_; lean_object* v___x_4176_; 
lean_dec(v_maxWork_4131_);
v___x_4169_ = 5;
lean_inc(v___x_4142_);
v___x_4170_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4170_, 0, v___x_4142_);
lean_ctor_set_uint8(v___x_4170_, sizeof(void*)*1, v___x_4169_);
v___x_4171_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4171_, 0, v___x_4170_);
v___x_4172_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_4172_, 0, v___x_4122_);
lean_ctor_set(v___x_4172_, 1, v___x_4123_);
lean_ctor_set(v___x_4172_, 2, v___x_4126_);
lean_ctor_set(v___x_4172_, 3, v___x_4127_);
lean_ctor_set(v___x_4172_, 4, v_val_4124_);
lean_ctor_set(v___x_4172_, 5, v___x_4128_);
lean_ctor_set(v___x_4172_, 6, v___x_4129_);
lean_ctor_set(v___x_4172_, 7, v___x_4130_);
lean_ctor_set(v___x_4172_, 8, v_initialWork_4132_);
lean_ctor_set_uint8(v___x_4172_, sizeof(void*)*9, v___x_4125_);
v___x_4173_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4173_, 0, v___x_4171_);
lean_ctor_set(v___x_4173_, 1, v___x_4172_);
v___x_4174_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_4174_, 0, v___x_4173_);
if (v_isShared_4141_ == 0)
{
lean_ctor_set(v___x_4140_, 1, v___x_4142_);
lean_ctor_set(v___x_4140_, 0, v___x_4174_);
v___x_4176_ = v___x_4140_;
goto v_reusejp_4175_;
}
else
{
lean_object* v_reuseFailAlloc_4177_; 
v_reuseFailAlloc_4177_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4177_, 0, v___x_4174_);
lean_ctor_set(v_reuseFailAlloc_4177_, 1, v___x_4142_);
v___x_4176_ = v_reuseFailAlloc_4177_;
goto v_reusejp_4175_;
}
v_reusejp_4175_:
{
return v___x_4176_;
}
}
}
else
{
uint8_t v___x_4178_; lean_object* v___x_4179_; lean_object* v___x_4180_; lean_object* v___x_4181_; lean_object* v___x_4182_; lean_object* v___x_4183_; lean_object* v___x_4185_; 
v___x_4178_ = 8;
v___x_4179_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4179_, 0, v_maxWork_4131_);
lean_ctor_set_uint8(v___x_4179_, sizeof(void*)*1, v___x_4178_);
v___x_4180_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4180_, 0, v___x_4179_);
v___x_4181_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_4181_, 0, v___x_4122_);
lean_ctor_set(v___x_4181_, 1, v___x_4123_);
lean_ctor_set(v___x_4181_, 2, v___x_4126_);
lean_ctor_set(v___x_4181_, 3, v___x_4127_);
lean_ctor_set(v___x_4181_, 4, v_val_4124_);
lean_ctor_set(v___x_4181_, 5, v___x_4128_);
lean_ctor_set(v___x_4181_, 6, v___x_4129_);
lean_ctor_set(v___x_4181_, 7, v___x_4130_);
lean_ctor_set(v___x_4181_, 8, v_initialWork_4132_);
lean_ctor_set_uint8(v___x_4181_, sizeof(void*)*9, v___x_4125_);
v___x_4182_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4182_, 0, v___x_4180_);
lean_ctor_set(v___x_4182_, 1, v___x_4181_);
v___x_4183_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_4183_, 0, v___x_4182_);
if (v_isShared_4141_ == 0)
{
lean_ctor_set(v___x_4140_, 1, v___x_4142_);
lean_ctor_set(v___x_4140_, 0, v___x_4183_);
v___x_4185_ = v___x_4140_;
goto v_reusejp_4184_;
}
else
{
lean_object* v_reuseFailAlloc_4186_; 
v_reuseFailAlloc_4186_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4186_, 0, v___x_4183_);
lean_ctor_set(v_reuseFailAlloc_4186_, 1, v___x_4142_);
v___x_4185_ = v_reuseFailAlloc_4186_;
goto v_reusejp_4184_;
}
v_reusejp_4184_:
{
return v___x_4185_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__0___boxed(lean_object* v___x_4189_, lean_object* v___x_4190_, lean_object* v_val_4191_, lean_object* v___x_4192_, lean_object* v___x_4193_, lean_object* v___x_4194_, lean_object* v___x_4195_, lean_object* v___x_4196_, lean_object* v___x_4197_, lean_object* v_maxWork_4198_, lean_object* v_initialWork_4199_, lean_object* v_as_4200_, lean_object* v_sz_4201_, lean_object* v_i_4202_, lean_object* v_b_4203_){
_start:
{
uint8_t v___x_3500__boxed_4204_; size_t v_sz_boxed_4205_; size_t v_i_boxed_4206_; lean_object* v_res_4207_; 
v___x_3500__boxed_4204_ = lean_unbox(v___x_4192_);
v_sz_boxed_4205_ = lean_unbox_usize(v_sz_4201_);
lean_dec(v_sz_4201_);
v_i_boxed_4206_ = lean_unbox_usize(v_i_4202_);
lean_dec(v_i_4202_);
v_res_4207_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__0(v___x_4189_, v___x_4190_, v_val_4191_, v___x_3500__boxed_4204_, v___x_4193_, v___x_4194_, v___x_4195_, v___x_4196_, v___x_4197_, v_maxWork_4198_, v_initialWork_4199_, v_as_4200_, v_sz_boxed_4205_, v_i_boxed_4206_, v_b_4203_);
lean_dec_ref(v_as_4200_);
return v_res_4207_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked(lean_object* v_table_4210_, uint8_t v_operation_4211_, lean_object* v_a_4212_, lean_object* v_b_4213_, lean_object* v_maxCount_4214_, lean_object* v_maxBytes_4215_, lean_object* v_maxWork_4216_, lean_object* v_initialWork_4217_){
_start:
{
lean_object* v_arity_4218_; uint8_t v_width_4219_; lean_object* v_exponents_4220_; lean_object* v_metadata_4221_; lean_object* v_count_4222_; lean_object* v_workspace_4223_; lean_object* v_buckets_4224_; lean_object* v_products_4225_; lean_object* v_hashBits_4226_; lean_object* v_work_4227_; lean_object* v___x_4229_; uint8_t v_isShared_4230_; uint8_t v_isSharedCheck_4475_; 
v_arity_4218_ = lean_ctor_get(v_table_4210_, 0);
v_width_4219_ = lean_ctor_get_uint8(v_table_4210_, sizeof(void*)*9);
v_exponents_4220_ = lean_ctor_get(v_table_4210_, 1);
v_metadata_4221_ = lean_ctor_get(v_table_4210_, 2);
v_count_4222_ = lean_ctor_get(v_table_4210_, 3);
v_workspace_4223_ = lean_ctor_get(v_table_4210_, 4);
v_buckets_4224_ = lean_ctor_get(v_table_4210_, 5);
v_products_4225_ = lean_ctor_get(v_table_4210_, 6);
v_hashBits_4226_ = lean_ctor_get(v_table_4210_, 7);
v_work_4227_ = lean_ctor_get(v_table_4210_, 8);
v_isSharedCheck_4475_ = !lean_is_exclusive(v_table_4210_);
if (v_isSharedCheck_4475_ == 0)
{
v___x_4229_ = v_table_4210_;
v_isShared_4230_ = v_isSharedCheck_4475_;
goto v_resetjp_4228_;
}
else
{
lean_inc(v_work_4227_);
lean_inc(v_hashBits_4226_);
lean_inc(v_products_4225_);
lean_inc(v_buckets_4224_);
lean_inc(v_workspace_4223_);
lean_inc(v_count_4222_);
lean_inc(v_metadata_4221_);
lean_inc(v_exponents_4220_);
lean_inc(v_arity_4218_);
lean_dec(v_table_4210_);
v___x_4229_ = lean_box(0);
v_isShared_4230_ = v_isSharedCheck_4475_;
goto v_resetjp_4228_;
}
v_resetjp_4228_:
{
uint64_t v___y_4232_; uint64_t v___y_4233_; lean_object* v___y_4234_; lean_object* v___y_4235_; uint64_t v___y_4236_; uint8_t v___y_4237_; lean_object* v___y_4238_; uint64_t v___y_4252_; lean_object* v___y_4253_; uint64_t v___y_4254_; lean_object* v___y_4255_; uint8_t v___y_4256_; uint64_t v_hash_4257_; uint64_t v___y_4262_; uint64_t v___y_4263_; lean_object* v___y_4264_; uint64_t v___y_4265_; lean_object* v___y_4266_; uint8_t v___y_4267_; uint64_t v___y_4276_; lean_object* v___y_4277_; uint64_t v___y_4278_; lean_object* v___y_4279_; uint64_t v___y_4280_; uint8_t v___y_4281_; uint64_t v___y_4282_; uint64_t v___y_4291_; uint64_t v___y_4292_; lean_object* v___y_4293_; uint64_t v___y_4294_; lean_object* v___y_4295_; uint64_t v___y_4296_; uint8_t v___y_4297_; uint8_t v___y_4298_; uint8_t v___y_4304_; uint64_t v___y_4305_; lean_object* v___y_4306_; uint64_t v___y_4307_; lean_object* v___y_4308_; uint64_t v___y_4309_; lean_object* v___y_4310_; uint64_t v___y_4311_; uint8_t v___y_4312_; uint8_t v___y_4313_; uint8_t v___y_4326_; uint64_t v___y_4327_; uint64_t v___y_4328_; uint64_t v___y_4329_; lean_object* v___y_4330_; lean_object* v___y_4331_; uint64_t v___y_4332_; lean_object* v___y_4333_; lean_object* v___y_4334_; uint8_t v___y_4335_; uint8_t v___y_4336_; uint8_t v___y_4348_; uint64_t v___y_4349_; lean_object* v___y_4350_; uint64_t v___y_4351_; lean_object* v___y_4352_; lean_object* v___y_4353_; uint64_t v___y_4354_; lean_object* v___y_4355_; uint8_t v___y_4356_; uint8_t v___y_4357_; uint8_t v___y_4367_; uint64_t v___y_4368_; uint64_t v___y_4369_; lean_object* v___y_4370_; lean_object* v___y_4371_; uint64_t v___y_4372_; lean_object* v___y_4373_; lean_object* v___y_4374_; uint8_t v___y_4375_; uint8_t v___y_4376_; lean_object* v___x_4406_; lean_object* v___y_4408_; lean_object* v___y_4409_; uint8_t v___y_4410_; lean_object* v___y_4411_; lean_object* v___y_4457_; lean_object* v___y_4458_; uint8_t v___y_4459_; lean_object* v___y_4463_; lean_object* v___x_4469_; lean_object* v___x_4470_; lean_object* v_size_4471_; lean_object* v___x_4472_; uint8_t v___x_4473_; 
v___x_4406_ = lean_unsigned_to_nat(4u);
v___x_4469_ = lean_nat_mul(v_arity_4218_, v___x_4406_);
v___x_4470_ = lean_unsigned_to_nat(28u);
v_size_4471_ = lean_nat_add(v___x_4469_, v___x_4470_);
lean_dec(v___x_4469_);
v___x_4472_ = lean_byte_array_size(v_workspace_4223_);
v___x_4473_ = lean_nat_dec_eq(v___x_4472_, v_size_4471_);
if (v___x_4473_ == 0)
{
lean_object* v___x_4474_; 
lean_dec_ref(v_workspace_4223_);
v___x_4474_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_zeros(v_size_4471_);
v___y_4463_ = v___x_4474_;
goto v___jp_4462_;
}
else
{
lean_dec(v_size_4471_);
v___y_4463_ = v_workspace_4223_;
goto v___jp_4462_;
}
v___jp_4231_:
{
lean_object* v___x_4239_; lean_object* v___x_4240_; size_t v_sz_4241_; size_t v___x_4242_; lean_object* v___x_4243_; lean_object* v_fst_4244_; 
v___x_4239_ = lean_box(0);
v___x_4240_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4240_, 0, v___x_4239_);
lean_ctor_set(v___x_4240_, 1, v___y_4234_);
v_sz_4241_ = lean_array_size(v___y_4238_);
v___x_4242_ = ((size_t)0ULL);
lean_inc(v_initialWork_4217_);
lean_inc(v_maxWork_4216_);
lean_inc(v_hashBits_4226_);
lean_inc_ref(v_products_4225_);
lean_inc_ref(v_buckets_4224_);
lean_inc(v_count_4222_);
lean_inc_ref(v_metadata_4221_);
lean_inc_ref(v___y_4235_);
lean_inc_ref(v_exponents_4220_);
lean_inc(v_arity_4218_);
v___x_4243_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__0(v_arity_4218_, v_exponents_4220_, v___y_4235_, v_width_4219_, v_metadata_4221_, v_count_4222_, v_buckets_4224_, v_products_4225_, v_hashBits_4226_, v_maxWork_4216_, v_initialWork_4217_, v___y_4238_, v_sz_4241_, v___x_4242_, v___x_4240_);
v_fst_4244_ = lean_ctor_get(v___x_4243_, 0);
lean_inc(v_fst_4244_);
if (lean_obj_tag(v_fst_4244_) == 0)
{
lean_object* v_snd_4245_; lean_object* v___x_4247_; 
v_snd_4245_ = lean_ctor_get(v___x_4243_, 1);
lean_inc(v_snd_4245_);
lean_dec_ref(v___x_4243_);
lean_inc_ref(v___y_4235_);
if (v_isShared_4230_ == 0)
{
lean_ctor_set(v___x_4229_, 8, v_initialWork_4217_);
lean_ctor_set(v___x_4229_, 4, v___y_4235_);
v___x_4247_ = v___x_4229_;
goto v_reusejp_4246_;
}
else
{
lean_object* v_reuseFailAlloc_4249_; 
v_reuseFailAlloc_4249_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_reuseFailAlloc_4249_, 0, v_arity_4218_);
lean_ctor_set(v_reuseFailAlloc_4249_, 1, v_exponents_4220_);
lean_ctor_set(v_reuseFailAlloc_4249_, 2, v_metadata_4221_);
lean_ctor_set(v_reuseFailAlloc_4249_, 3, v_count_4222_);
lean_ctor_set(v_reuseFailAlloc_4249_, 4, v___y_4235_);
lean_ctor_set(v_reuseFailAlloc_4249_, 5, v_buckets_4224_);
lean_ctor_set(v_reuseFailAlloc_4249_, 6, v_products_4225_);
lean_ctor_set(v_reuseFailAlloc_4249_, 7, v_hashBits_4226_);
lean_ctor_set(v_reuseFailAlloc_4249_, 8, v_initialWork_4217_);
lean_ctor_set_uint8(v_reuseFailAlloc_4249_, sizeof(void*)*9, v_width_4219_);
v___x_4247_ = v_reuseFailAlloc_4249_;
goto v_reusejp_4246_;
}
v_reusejp_4246_:
{
lean_object* v___x_4248_; 
v___x_4248_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1(v___y_4235_, v___x_4247_, v___y_4237_, v___y_4232_, v___y_4233_, v___y_4236_, v___y_4238_, v_snd_4245_, v_maxCount_4214_, v_maxBytes_4215_, v_maxWork_4216_);
lean_dec_ref(v___y_4235_);
return v___x_4248_;
}
}
else
{
lean_object* v_val_4250_; 
lean_dec_ref(v___x_4243_);
lean_dec_ref(v___y_4238_);
lean_dec_ref(v___y_4235_);
lean_del_object(v___x_4229_);
lean_dec(v_hashBits_4226_);
lean_dec_ref(v_products_4225_);
lean_dec_ref(v_buckets_4224_);
lean_dec(v_count_4222_);
lean_dec_ref(v_metadata_4221_);
lean_dec_ref(v_exponents_4220_);
lean_dec(v_arity_4218_);
lean_dec(v_initialWork_4217_);
lean_dec(v_maxWork_4216_);
v_val_4250_ = lean_ctor_get(v_fst_4244_, 0);
lean_inc(v_val_4250_);
lean_dec_ref_known(v_fst_4244_, 1);
return v_val_4250_;
}
}
v___jp_4251_:
{
lean_object* v___x_4258_; 
v___x_4258_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_internOwned_spec__3___redArg(v_buckets_4224_, v_hash_4257_);
if (lean_obj_tag(v___x_4258_) == 0)
{
lean_object* v___x_4259_; 
v___x_4259_ = ((lean_object*)(lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked___closed__0));
v___y_4232_ = v___y_4252_;
v___y_4233_ = v___y_4254_;
v___y_4234_ = v___y_4253_;
v___y_4235_ = v___y_4255_;
v___y_4236_ = v_hash_4257_;
v___y_4237_ = v___y_4256_;
v___y_4238_ = v___x_4259_;
goto v___jp_4231_;
}
else
{
lean_object* v_val_4260_; 
v_val_4260_ = lean_ctor_get(v___x_4258_, 0);
lean_inc(v_val_4260_);
lean_dec_ref_known(v___x_4258_, 1);
v___y_4232_ = v___y_4252_;
v___y_4233_ = v___y_4254_;
v___y_4234_ = v___y_4253_;
v___y_4235_ = v___y_4255_;
v___y_4236_ = v_hash_4257_;
v___y_4237_ = v___y_4256_;
v___y_4238_ = v_val_4260_;
goto v___jp_4231_;
}
}
v___jp_4261_:
{
lean_object* v___x_4268_; uint8_t v___x_4269_; 
v___x_4268_ = lean_unsigned_to_nat(64u);
v___x_4269_ = lean_nat_dec_lt(v_hashBits_4226_, v___x_4268_);
if (v___x_4269_ == 0)
{
v___y_4252_ = v___y_4262_;
v___y_4253_ = v___y_4264_;
v___y_4254_ = v___y_4263_;
v___y_4255_ = v___y_4266_;
v___y_4256_ = v___y_4267_;
v_hash_4257_ = v___y_4265_;
goto v___jp_4251_;
}
else
{
uint64_t v___x_4270_; uint64_t v___x_4271_; uint64_t v___x_4272_; uint64_t v___x_4273_; uint64_t v_hash_4274_; 
v___x_4270_ = 1ULL;
v___x_4271_ = lean_uint64_of_nat(v_hashBits_4226_);
v___x_4272_ = lean_uint64_shift_left(v___x_4270_, v___x_4271_);
v___x_4273_ = lean_uint64_sub(v___x_4272_, v___x_4270_);
v_hash_4274_ = lean_uint64_land(v___y_4265_, v___x_4273_);
v___y_4252_ = v___y_4262_;
v___y_4253_ = v___y_4264_;
v___y_4254_ = v___y_4263_;
v___y_4255_ = v___y_4266_;
v___y_4256_ = v___y_4267_;
v_hash_4257_ = v_hash_4274_;
goto v___jp_4251_;
}
}
v___jp_4275_:
{
uint64_t v___x_4283_; uint8_t v___x_4284_; 
v___x_4283_ = 65535ULL;
v___x_4284_ = lean_uint64_dec_lt(v___x_4283_, v___y_4282_);
if (v___x_4284_ == 0)
{
uint64_t v___x_4285_; uint8_t v___x_4286_; 
v___x_4285_ = 255ULL;
v___x_4286_ = lean_uint64_dec_lt(v___x_4285_, v___y_4282_);
if (v___x_4286_ == 0)
{
v___y_4262_ = v___y_4276_;
v___y_4263_ = v___y_4278_;
v___y_4264_ = v___y_4277_;
v___y_4265_ = v___y_4280_;
v___y_4266_ = v___y_4279_;
v___y_4267_ = v_width_4219_;
goto v___jp_4261_;
}
else
{
uint8_t v___x_4287_; uint8_t v___x_4288_; 
v___x_4287_ = 0;
v___x_4288_ = lp_Hex_Hex_Groebner_instBEqWidth_beq(v_width_4219_, v___x_4287_);
if (v___x_4288_ == 0)
{
v___y_4262_ = v___y_4276_;
v___y_4263_ = v___y_4278_;
v___y_4264_ = v___y_4277_;
v___y_4265_ = v___y_4280_;
v___y_4266_ = v___y_4279_;
v___y_4267_ = v_width_4219_;
goto v___jp_4261_;
}
else
{
uint8_t v___x_4289_; 
v___x_4289_ = 1;
v___y_4262_ = v___y_4276_;
v___y_4263_ = v___y_4278_;
v___y_4264_ = v___y_4277_;
v___y_4265_ = v___y_4280_;
v___y_4266_ = v___y_4279_;
v___y_4267_ = v___x_4289_;
goto v___jp_4261_;
}
}
}
else
{
v___y_4262_ = v___y_4276_;
v___y_4263_ = v___y_4278_;
v___y_4264_ = v___y_4277_;
v___y_4265_ = v___y_4280_;
v___y_4266_ = v___y_4279_;
v___y_4267_ = v___y_4281_;
goto v___jp_4261_;
}
}
v___jp_4290_:
{
uint64_t v___x_4299_; uint64_t v___x_4300_; uint64_t v___x_4301_; uint64_t v___x_4302_; 
v___x_4299_ = lean_uint8_to_uint64(v___y_4298_);
v___x_4300_ = 24ULL;
v___x_4301_ = lean_uint64_shift_left(v___x_4299_, v___x_4300_);
v___x_4302_ = lean_uint64_lor(v___y_4296_, v___x_4301_);
v___y_4276_ = v___y_4291_;
v___y_4277_ = v___y_4293_;
v___y_4278_ = v___y_4292_;
v___y_4279_ = v___y_4295_;
v___y_4280_ = v___y_4294_;
v___y_4281_ = v___y_4297_;
v___y_4282_ = v___x_4302_;
goto v___jp_4275_;
}
v___jp_4303_:
{
uint64_t v___x_4314_; uint64_t v___x_4315_; uint64_t v___x_4316_; uint64_t v___x_4317_; lean_object* v___x_4318_; lean_object* v___x_4319_; uint8_t v___x_4320_; 
v___x_4314_ = lean_uint8_to_uint64(v___y_4313_);
v___x_4315_ = 16ULL;
v___x_4316_ = lean_uint64_shift_left(v___x_4314_, v___x_4315_);
v___x_4317_ = lean_uint64_lor(v___y_4309_, v___x_4316_);
v___x_4318_ = lean_unsigned_to_nat(3u);
v___x_4319_ = lean_nat_add(v___y_4308_, v___x_4318_);
lean_dec(v___y_4308_);
v___x_4320_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_4310_, v___x_4319_);
if (v___x_4320_ == 0)
{
lean_object* v___x_4321_; lean_object* v___x_4322_; uint8_t v___x_4323_; 
lean_dec(v___x_4319_);
v___x_4321_ = lean_box(v___y_4304_);
v___x_4322_ = l_outOfBounds___redArg(v___x_4321_);
lean_dec(v___x_4321_);
v___x_4323_ = lean_unbox(v___x_4322_);
lean_dec(v___x_4322_);
v___y_4291_ = v___y_4305_;
v___y_4292_ = v___y_4307_;
v___y_4293_ = v___y_4306_;
v___y_4294_ = v___y_4311_;
v___y_4295_ = v___y_4310_;
v___y_4296_ = v___x_4317_;
v___y_4297_ = v___y_4312_;
v___y_4298_ = v___x_4323_;
goto v___jp_4290_;
}
else
{
uint8_t v___x_4324_; 
v___x_4324_ = lean_byte_array_fget(v___y_4310_, v___x_4319_);
lean_dec(v___x_4319_);
v___y_4291_ = v___y_4305_;
v___y_4292_ = v___y_4307_;
v___y_4293_ = v___y_4306_;
v___y_4294_ = v___y_4311_;
v___y_4295_ = v___y_4310_;
v___y_4296_ = v___x_4317_;
v___y_4297_ = v___y_4312_;
v___y_4298_ = v___x_4324_;
goto v___jp_4290_;
}
}
v___jp_4325_:
{
uint64_t v___x_4337_; uint64_t v___x_4338_; uint64_t v___x_4339_; uint64_t v___x_4340_; lean_object* v___x_4341_; uint8_t v___x_4342_; 
v___x_4337_ = lean_uint8_to_uint64(v___y_4336_);
v___x_4338_ = 8ULL;
v___x_4339_ = lean_uint64_shift_left(v___x_4337_, v___x_4338_);
v___x_4340_ = lean_uint64_lor(v___y_4327_, v___x_4339_);
v___x_4341_ = lean_nat_add(v___y_4331_, v___y_4334_);
v___x_4342_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_4333_, v___x_4341_);
if (v___x_4342_ == 0)
{
lean_object* v___x_4343_; lean_object* v___x_4344_; uint8_t v___x_4345_; 
lean_dec(v___x_4341_);
v___x_4343_ = lean_box(v___y_4326_);
v___x_4344_ = l_outOfBounds___redArg(v___x_4343_);
lean_dec(v___x_4343_);
v___x_4345_ = lean_unbox(v___x_4344_);
lean_dec(v___x_4344_);
v___y_4304_ = v___y_4326_;
v___y_4305_ = v___y_4328_;
v___y_4306_ = v___y_4330_;
v___y_4307_ = v___y_4329_;
v___y_4308_ = v___y_4331_;
v___y_4309_ = v___x_4340_;
v___y_4310_ = v___y_4333_;
v___y_4311_ = v___y_4332_;
v___y_4312_ = v___y_4335_;
v___y_4313_ = v___x_4345_;
goto v___jp_4303_;
}
else
{
uint8_t v___x_4346_; 
v___x_4346_ = lean_byte_array_fget(v___y_4333_, v___x_4341_);
lean_dec(v___x_4341_);
v___y_4304_ = v___y_4326_;
v___y_4305_ = v___y_4328_;
v___y_4306_ = v___y_4330_;
v___y_4307_ = v___y_4329_;
v___y_4308_ = v___y_4331_;
v___y_4309_ = v___x_4340_;
v___y_4310_ = v___y_4333_;
v___y_4311_ = v___y_4332_;
v___y_4312_ = v___y_4335_;
v___y_4313_ = v___x_4346_;
goto v___jp_4303_;
}
}
v___jp_4347_:
{
uint64_t v_a_4358_; lean_object* v___x_4359_; lean_object* v___x_4360_; uint8_t v___x_4361_; 
v_a_4358_ = lean_uint8_to_uint64(v___y_4357_);
v___x_4359_ = lean_unsigned_to_nat(1u);
v___x_4360_ = lean_nat_add(v___y_4352_, v___x_4359_);
v___x_4361_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_4353_, v___x_4360_);
if (v___x_4361_ == 0)
{
lean_object* v___x_4362_; lean_object* v___x_4363_; uint8_t v___x_4364_; 
lean_dec(v___x_4360_);
v___x_4362_ = lean_box(v___y_4348_);
v___x_4363_ = l_outOfBounds___redArg(v___x_4362_);
lean_dec(v___x_4362_);
v___x_4364_ = lean_unbox(v___x_4363_);
lean_dec(v___x_4363_);
v___y_4326_ = v___y_4348_;
v___y_4327_ = v_a_4358_;
v___y_4328_ = v___y_4349_;
v___y_4329_ = v___y_4351_;
v___y_4330_ = v___y_4350_;
v___y_4331_ = v___y_4352_;
v___y_4332_ = v___y_4354_;
v___y_4333_ = v___y_4353_;
v___y_4334_ = v___y_4355_;
v___y_4335_ = v___y_4356_;
v___y_4336_ = v___x_4364_;
goto v___jp_4325_;
}
else
{
uint8_t v___x_4365_; 
v___x_4365_ = lean_byte_array_fget(v___y_4353_, v___x_4360_);
lean_dec(v___x_4360_);
v___y_4326_ = v___y_4348_;
v___y_4327_ = v_a_4358_;
v___y_4328_ = v___y_4349_;
v___y_4329_ = v___y_4351_;
v___y_4330_ = v___y_4350_;
v___y_4331_ = v___y_4352_;
v___y_4332_ = v___y_4354_;
v___y_4333_ = v___y_4353_;
v___y_4334_ = v___y_4355_;
v___y_4335_ = v___y_4356_;
v___y_4336_ = v___x_4365_;
goto v___jp_4325_;
}
}
v___jp_4366_:
{
if (v___y_4376_ == 0)
{
uint8_t v___x_4377_; 
v___x_4377_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v___y_4373_, v___y_4371_);
if (v___x_4377_ == 0)
{
lean_object* v___x_4378_; lean_object* v___x_4379_; uint8_t v___x_4380_; 
v___x_4378_ = lean_box(v___y_4367_);
v___x_4379_ = l_outOfBounds___redArg(v___x_4378_);
lean_dec(v___x_4378_);
v___x_4380_ = lean_unbox(v___x_4379_);
lean_dec(v___x_4379_);
v___y_4348_ = v___y_4367_;
v___y_4349_ = v___y_4368_;
v___y_4350_ = v___y_4370_;
v___y_4351_ = v___y_4369_;
v___y_4352_ = v___y_4371_;
v___y_4353_ = v___y_4373_;
v___y_4354_ = v___y_4372_;
v___y_4355_ = v___y_4374_;
v___y_4356_ = v___y_4375_;
v___y_4357_ = v___x_4380_;
goto v___jp_4347_;
}
else
{
uint8_t v___x_4381_; 
v___x_4381_ = lean_byte_array_fget(v___y_4373_, v___y_4371_);
v___y_4348_ = v___y_4367_;
v___y_4349_ = v___y_4368_;
v___y_4350_ = v___y_4370_;
v___y_4351_ = v___y_4369_;
v___y_4352_ = v___y_4371_;
v___y_4353_ = v___y_4373_;
v___y_4354_ = v___y_4372_;
v___y_4355_ = v___y_4374_;
v___y_4356_ = v___y_4375_;
v___y_4357_ = v___x_4381_;
goto v___jp_4347_;
}
}
else
{
size_t v_pos_4382_; uint8_t v___x_4383_; uint64_t v_a_4384_; size_t v___x_4385_; size_t v___x_4386_; uint8_t v___x_4387_; uint64_t v___x_4388_; uint64_t v___x_4389_; uint64_t v___x_4390_; uint64_t v___x_4391_; size_t v___x_4392_; size_t v___x_4393_; uint8_t v___x_4394_; uint64_t v___x_4395_; uint64_t v___x_4396_; uint64_t v___x_4397_; uint64_t v___x_4398_; size_t v___x_4399_; size_t v___x_4400_; uint8_t v___x_4401_; uint64_t v___x_4402_; uint64_t v___x_4403_; uint64_t v___x_4404_; uint64_t v___x_4405_; 
v_pos_4382_ = lean_usize_of_nat(v___y_4371_);
lean_dec(v___y_4371_);
v___x_4383_ = lean_byte_array_uget(v___y_4373_, v_pos_4382_);
v_a_4384_ = lean_uint8_to_uint64(v___x_4383_);
v___x_4385_ = ((size_t)1ULL);
v___x_4386_ = lean_usize_add(v_pos_4382_, v___x_4385_);
v___x_4387_ = lean_byte_array_uget(v___y_4373_, v___x_4386_);
v___x_4388_ = lean_uint8_to_uint64(v___x_4387_);
v___x_4389_ = 8ULL;
v___x_4390_ = lean_uint64_shift_left(v___x_4388_, v___x_4389_);
v___x_4391_ = lean_uint64_lor(v_a_4384_, v___x_4390_);
v___x_4392_ = ((size_t)2ULL);
v___x_4393_ = lean_usize_add(v_pos_4382_, v___x_4392_);
v___x_4394_ = lean_byte_array_uget(v___y_4373_, v___x_4393_);
v___x_4395_ = lean_uint8_to_uint64(v___x_4394_);
v___x_4396_ = 16ULL;
v___x_4397_ = lean_uint64_shift_left(v___x_4395_, v___x_4396_);
v___x_4398_ = lean_uint64_lor(v___x_4391_, v___x_4397_);
v___x_4399_ = ((size_t)3ULL);
v___x_4400_ = lean_usize_add(v_pos_4382_, v___x_4399_);
v___x_4401_ = lean_byte_array_uget(v___y_4373_, v___x_4400_);
v___x_4402_ = lean_uint8_to_uint64(v___x_4401_);
v___x_4403_ = 24ULL;
v___x_4404_ = lean_uint64_shift_left(v___x_4402_, v___x_4403_);
v___x_4405_ = lean_uint64_lor(v___x_4398_, v___x_4404_);
v___y_4276_ = v___y_4368_;
v___y_4277_ = v___y_4370_;
v___y_4278_ = v___y_4369_;
v___y_4279_ = v___y_4373_;
v___y_4280_ = v___y_4372_;
v___y_4281_ = v___y_4375_;
v___y_4282_ = v___x_4405_;
goto v___jp_4275_;
}
}
v___jp_4407_:
{
uint8_t v___x_4412_; uint64_t v___x_4413_; uint64_t v___x_4414_; uint64_t v___x_4415_; uint64_t v___x_4416_; lean_object* v___x_4417_; 
v___x_4412_ = lean_uint8_of_nat(v___y_4411_);
v___x_4413_ = lean_uint64_of_nat(v_arity_4218_);
v___x_4414_ = lean_uint64_of_nat(v_count_4222_);
v___x_4415_ = lean_uint64_of_nat(v_a_4212_);
v___x_4416_ = lean_uint64_of_nat(v_b_4213_);
v___x_4417_ = lean_hex_groebner_prepare_monomial(v___y_4410_, v___x_4412_, v___x_4413_, v___x_4414_, v___x_4415_, v___x_4416_, v_exponents_4220_, v___y_4409_);
if (lean_obj_tag(v___x_4417_) == 1)
{
lean_object* v_val_4418_; lean_object* v___x_4420_; uint8_t v_isShared_4421_; uint8_t v_isSharedCheck_4451_; 
lean_dec_ref(v___y_4408_);
v_val_4418_ = lean_ctor_get(v___x_4417_, 0);
v_isSharedCheck_4451_ = !lean_is_exclusive(v___x_4417_);
if (v_isSharedCheck_4451_ == 0)
{
v___x_4420_ = v___x_4417_;
v_isShared_4421_ = v_isSharedCheck_4451_;
goto v_resetjp_4419_;
}
else
{
lean_inc(v_val_4418_);
lean_dec(v___x_4417_);
v___x_4420_ = lean_box(0);
v_isShared_4421_ = v_isSharedCheck_4451_;
goto v_resetjp_4419_;
}
v_resetjp_4419_:
{
lean_object* v_work_4422_; uint8_t v___x_4423_; 
v_work_4422_ = lean_nat_add(v_initialWork_4217_, v_arity_4218_);
v___x_4423_ = lean_nat_dec_lt(v_maxWork_4216_, v_work_4422_);
if (v___x_4423_ == 0)
{
lean_object* v___x_4424_; uint64_t v_degree_4425_; lean_object* v___x_4426_; lean_object* v___x_4427_; lean_object* v___x_4428_; uint64_t v_mask_4429_; lean_object* v___x_4430_; lean_object* v___x_4431_; uint64_t v_hash_4432_; uint8_t v___x_4433_; lean_object* v___x_4434_; lean_object* v___x_4435_; uint8_t v___x_4436_; lean_object* v_offset_4437_; lean_object* v___x_4438_; lean_object* v___x_4439_; uint8_t v___x_4440_; 
lean_del_object(v___x_4420_);
v___x_4424_ = lean_nat_mul(v_arity_4218_, v___x_4406_);
v_degree_4425_ = lp_Hex_Hex_Groebner_Packed_read64Fast(v_val_4418_, v___x_4424_);
lean_dec(v___x_4424_);
v___x_4426_ = lean_unsigned_to_nat(2u);
v___x_4427_ = lean_nat_add(v_arity_4218_, v___x_4426_);
v___x_4428_ = lean_nat_mul(v___x_4427_, v___x_4406_);
lean_dec(v___x_4427_);
v_mask_4429_ = lp_Hex_Hex_Groebner_Packed_read64Fast(v_val_4418_, v___x_4428_);
lean_dec(v___x_4428_);
v___x_4430_ = lean_nat_add(v_arity_4218_, v___x_4406_);
v___x_4431_ = lean_nat_mul(v___x_4430_, v___x_4406_);
lean_dec(v___x_4430_);
v_hash_4432_ = lp_Hex_Hex_Groebner_Packed_read64Fast(v_val_4418_, v___x_4431_);
lean_dec(v___x_4431_);
v___x_4433_ = 2;
v___x_4434_ = lean_unsigned_to_nat(6u);
v___x_4435_ = lean_nat_add(v_arity_4218_, v___x_4434_);
v___x_4436_ = 0;
v_offset_4437_ = lean_nat_mul(v___x_4435_, v___x_4406_);
lean_dec(v___x_4435_);
v___x_4438_ = lean_nat_add(v_offset_4437_, v___x_4406_);
v___x_4439_ = lean_byte_array_size(v_val_4418_);
v___x_4440_ = lean_nat_dec_le(v___x_4438_, v___x_4439_);
if (v___x_4440_ == 0)
{
lean_dec(v___x_4438_);
v___y_4367_ = v___x_4436_;
v___y_4368_ = v_degree_4425_;
v___y_4369_ = v_mask_4429_;
v___y_4370_ = v_work_4422_;
v___y_4371_ = v_offset_4437_;
v___y_4372_ = v_hash_4432_;
v___y_4373_ = v_val_4418_;
v___y_4374_ = v___x_4426_;
v___y_4375_ = v___x_4433_;
v___y_4376_ = v___x_4440_;
goto v___jp_4366_;
}
else
{
size_t v___x_4441_; lean_object* v___x_4442_; uint8_t v___x_4443_; 
v___x_4441_ = lean_usize_of_nat(v___x_4438_);
v___x_4442_ = lean_usize_to_nat(v___x_4441_);
v___x_4443_ = lean_nat_dec_eq(v___x_4442_, v___x_4438_);
lean_dec(v___x_4438_);
lean_dec(v___x_4442_);
v___y_4367_ = v___x_4436_;
v___y_4368_ = v_degree_4425_;
v___y_4369_ = v_mask_4429_;
v___y_4370_ = v_work_4422_;
v___y_4371_ = v_offset_4437_;
v___y_4372_ = v_hash_4432_;
v___y_4373_ = v_val_4418_;
v___y_4374_ = v___x_4426_;
v___y_4375_ = v___x_4433_;
v___y_4376_ = v___x_4443_;
goto v___jp_4366_;
}
}
else
{
uint8_t v___x_4444_; lean_object* v___x_4445_; lean_object* v___x_4447_; 
lean_dec(v_work_4422_);
lean_del_object(v___x_4229_);
v___x_4444_ = 8;
v___x_4445_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4445_, 0, v_maxWork_4216_);
lean_ctor_set_uint8(v___x_4445_, sizeof(void*)*1, v___x_4444_);
if (v_isShared_4421_ == 0)
{
lean_ctor_set_tag(v___x_4420_, 0);
lean_ctor_set(v___x_4420_, 0, v___x_4445_);
v___x_4447_ = v___x_4420_;
goto v_reusejp_4446_;
}
else
{
lean_object* v_reuseFailAlloc_4450_; 
v_reuseFailAlloc_4450_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4450_, 0, v___x_4445_);
v___x_4447_ = v_reuseFailAlloc_4450_;
goto v_reusejp_4446_;
}
v_reusejp_4446_:
{
lean_object* v___x_4448_; lean_object* v___x_4449_; 
v___x_4448_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_4448_, 0, v_arity_4218_);
lean_ctor_set(v___x_4448_, 1, v_exponents_4220_);
lean_ctor_set(v___x_4448_, 2, v_metadata_4221_);
lean_ctor_set(v___x_4448_, 3, v_count_4222_);
lean_ctor_set(v___x_4448_, 4, v_val_4418_);
lean_ctor_set(v___x_4448_, 5, v_buckets_4224_);
lean_ctor_set(v___x_4448_, 6, v_products_4225_);
lean_ctor_set(v___x_4448_, 7, v_hashBits_4226_);
lean_ctor_set(v___x_4448_, 8, v_initialWork_4217_);
lean_ctor_set_uint8(v___x_4448_, sizeof(void*)*9, v_width_4219_);
v___x_4449_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4449_, 0, v___x_4447_);
lean_ctor_set(v___x_4449_, 1, v___x_4448_);
return v___x_4449_;
}
}
}
}
else
{
uint8_t v___x_4452_; lean_object* v___x_4453_; lean_object* v___x_4454_; lean_object* v___x_4455_; 
lean_dec(v___x_4417_);
lean_del_object(v___x_4229_);
lean_dec(v_hashBits_4226_);
lean_dec_ref(v_products_4225_);
lean_dec_ref(v_buckets_4224_);
lean_dec(v_count_4222_);
lean_dec_ref(v_metadata_4221_);
lean_dec_ref(v_exponents_4220_);
lean_dec(v_arity_4218_);
lean_dec(v_maxWork_4216_);
v___x_4452_ = 2;
v___x_4453_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4453_, 0, v_initialWork_4217_);
lean_ctor_set_uint8(v___x_4453_, sizeof(void*)*1, v___x_4452_);
v___x_4454_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4454_, 0, v___x_4453_);
v___x_4455_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4455_, 0, v___x_4454_);
lean_ctor_set(v___x_4455_, 1, v___y_4408_);
return v___x_4455_;
}
}
v___jp_4456_:
{
switch(v_width_4219_)
{
case 0:
{
lean_object* v___x_4460_; 
v___x_4460_ = lean_unsigned_to_nat(1u);
v___y_4408_ = v___y_4457_;
v___y_4409_ = v___y_4458_;
v___y_4410_ = v___y_4459_;
v___y_4411_ = v___x_4460_;
goto v___jp_4407_;
}
case 1:
{
lean_object* v___x_4461_; 
v___x_4461_ = lean_unsigned_to_nat(2u);
v___y_4408_ = v___y_4457_;
v___y_4409_ = v___y_4458_;
v___y_4410_ = v___y_4459_;
v___y_4411_ = v___x_4461_;
goto v___jp_4407_;
}
default: 
{
v___y_4408_ = v___y_4457_;
v___y_4409_ = v___y_4458_;
v___y_4410_ = v___y_4459_;
v___y_4411_ = v___x_4406_;
goto v___jp_4407_;
}
}
}
v___jp_4462_:
{
lean_object* v___x_4464_; lean_object* v_table_4465_; 
v___x_4464_ = l_ByteArray_empty;
lean_inc(v_hashBits_4226_);
lean_inc_ref(v_products_4225_);
lean_inc_ref(v_buckets_4224_);
lean_inc(v_count_4222_);
lean_inc_ref(v_metadata_4221_);
lean_inc_ref(v_exponents_4220_);
lean_inc(v_arity_4218_);
v_table_4465_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_table_4465_, 0, v_arity_4218_);
lean_ctor_set(v_table_4465_, 1, v_exponents_4220_);
lean_ctor_set(v_table_4465_, 2, v_metadata_4221_);
lean_ctor_set(v_table_4465_, 3, v_count_4222_);
lean_ctor_set(v_table_4465_, 4, v___x_4464_);
lean_ctor_set(v_table_4465_, 5, v_buckets_4224_);
lean_ctor_set(v_table_4465_, 6, v_products_4225_);
lean_ctor_set(v_table_4465_, 7, v_hashBits_4226_);
lean_ctor_set(v_table_4465_, 8, v_work_4227_);
lean_ctor_set_uint8(v_table_4465_, sizeof(void*)*9, v_width_4219_);
switch(v_operation_4211_)
{
case 0:
{
uint8_t v___x_4466_; 
v___x_4466_ = 0;
v___y_4457_ = v_table_4465_;
v___y_4458_ = v___y_4463_;
v___y_4459_ = v___x_4466_;
goto v___jp_4456_;
}
case 1:
{
uint8_t v___x_4467_; 
v___x_4467_ = 1;
v___y_4457_ = v_table_4465_;
v___y_4458_ = v___y_4463_;
v___y_4459_ = v___x_4467_;
goto v___jp_4456_;
}
default: 
{
uint8_t v___x_4468_; 
v___x_4468_ = 2;
v___y_4457_ = v_table_4465_;
v___y_4458_ = v___y_4463_;
v___y_4459_ = v___x_4468_;
goto v___jp_4456_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked___boxed(lean_object* v_table_4476_, lean_object* v_operation_4477_, lean_object* v_a_4478_, lean_object* v_b_4479_, lean_object* v_maxCount_4480_, lean_object* v_maxBytes_4481_, lean_object* v_maxWork_4482_, lean_object* v_initialWork_4483_){
_start:
{
uint8_t v_operation_boxed_4484_; lean_object* v_res_4485_; 
v_operation_boxed_4484_ = lean_unbox(v_operation_4477_);
v_res_4485_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked(v_table_4476_, v_operation_boxed_4484_, v_a_4478_, v_b_4479_, v_maxCount_4480_, v_maxBytes_4481_, v_maxWork_4482_, v_initialWork_4483_);
lean_dec(v_maxBytes_4481_);
lean_dec(v_maxCount_4480_);
lean_dec(v_b_4479_);
lean_dec(v_a_4478_);
return v_res_4485_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1(uint8_t v_width_4486_, lean_object* v_val_4487_, lean_object* v_range_4488_, lean_object* v_b_4489_, lean_object* v_i_4490_, lean_object* v_hs_4491_, lean_object* v_hl_4492_){
_start:
{
lean_object* v___x_4493_; 
v___x_4493_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1___redArg(v_width_4486_, v_val_4487_, v_range_4488_, v_b_4489_, v_i_4490_);
return v___x_4493_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1___boxed(lean_object* v_width_4494_, lean_object* v_val_4495_, lean_object* v_range_4496_, lean_object* v_b_4497_, lean_object* v_i_4498_, lean_object* v_hs_4499_, lean_object* v_hl_4500_){
_start:
{
uint8_t v_width_boxed_4501_; lean_object* v_res_4502_; 
v_width_boxed_4501_ = lean_unbox(v_width_4494_);
v_res_4502_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked_spec__1_spec__1(v_width_boxed_4501_, v_val_4495_, v_range_4496_, v_b_4497_, v_i_4498_, v_hs_4499_, v_hl_4500_);
lean_dec_ref(v_range_4496_);
lean_dec_ref(v_val_4495_);
return v_res_4502_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(lean_object* v_table_4503_, uint8_t v_operation_4504_, lean_object* v_a_4505_, lean_object* v_b_4506_, lean_object* v_maxCount_4507_, lean_object* v_maxBytes_4508_, lean_object* v_maxWork_4509_, uint8_t v_native_4510_){
_start:
{
lean_object* v_arity_4511_; uint8_t v_width_4512_; lean_object* v_exponents_4513_; lean_object* v_metadata_4514_; lean_object* v_count_4515_; lean_object* v_workspace_4516_; lean_object* v_products_4517_; lean_object* v_work_4518_; lean_object* v___y_4530_; lean_object* v___y_4531_; lean_object* v___y_4532_; lean_object* v___y_4570_; lean_object* v___y_4571_; lean_object* v___y_4572_; lean_object* v___y_4573_; uint8_t v___x_4575_; 
v_arity_4511_ = lean_ctor_get(v_table_4503_, 0);
v_width_4512_ = lean_ctor_get_uint8(v_table_4503_, sizeof(void*)*9);
v_exponents_4513_ = lean_ctor_get(v_table_4503_, 1);
v_metadata_4514_ = lean_ctor_get(v_table_4503_, 2);
v_count_4515_ = lean_ctor_get(v_table_4503_, 3);
v_workspace_4516_ = lean_ctor_get(v_table_4503_, 4);
v_products_4517_ = lean_ctor_get(v_table_4503_, 6);
lean_inc_ref(v_products_4517_);
v_work_4518_ = lean_ctor_get(v_table_4503_, 8);
v___x_4575_ = lean_nat_dec_le(v_count_4515_, v_a_4505_);
if (v___x_4575_ == 0)
{
uint8_t v___x_4576_; 
v___x_4576_ = lean_nat_dec_le(v_count_4515_, v_b_4506_);
if (v___x_4576_ == 0)
{
lean_object* v___x_4577_; lean_object* v___x_4578_; lean_object* v___y_4580_; 
v___x_4577_ = lean_byte_array_size(v_exponents_4513_);
v___x_4578_ = lean_nat_mul(v_count_4515_, v_arity_4511_);
switch(v_width_4512_)
{
case 0:
{
lean_object* v___x_4604_; 
v___x_4604_ = lean_unsigned_to_nat(1u);
v___y_4580_ = v___x_4604_;
goto v___jp_4579_;
}
case 1:
{
lean_object* v___x_4605_; 
v___x_4605_ = lean_unsigned_to_nat(2u);
v___y_4580_ = v___x_4605_;
goto v___jp_4579_;
}
default: 
{
lean_object* v___x_4606_; 
v___x_4606_ = lean_unsigned_to_nat(4u);
v___y_4580_ = v___x_4606_;
goto v___jp_4579_;
}
}
v___jp_4579_:
{
lean_object* v___x_4581_; uint8_t v___x_4582_; 
v___x_4581_ = lean_nat_mul(v___x_4578_, v___y_4580_);
lean_dec(v___x_4578_);
v___x_4582_ = lean_nat_dec_eq(v___x_4577_, v___x_4581_);
lean_dec(v___x_4581_);
if (v___x_4582_ == 0)
{
lean_dec_ref(v_products_4517_);
lean_dec(v_maxWork_4509_);
goto v___jp_4524_;
}
else
{
lean_object* v___x_4583_; lean_object* v___x_4584_; lean_object* v___x_4585_; uint8_t v___x_4586_; 
v___x_4583_ = lean_byte_array_size(v_metadata_4514_);
v___x_4584_ = lean_unsigned_to_nat(24u);
v___x_4585_ = lean_nat_mul(v_count_4515_, v___x_4584_);
v___x_4586_ = lean_nat_dec_eq(v___x_4583_, v___x_4585_);
lean_dec(v___x_4585_);
if (v___x_4586_ == 0)
{
lean_dec_ref(v_products_4517_);
lean_dec(v_maxWork_4509_);
goto v___jp_4524_;
}
else
{
lean_object* v_work_4587_; uint8_t v___x_4588_; 
v_work_4587_ = lean_nat_add(v_work_4518_, v_arity_4511_);
v___x_4588_ = lean_nat_dec_lt(v_maxWork_4509_, v_work_4587_);
if (v___x_4588_ == 0)
{
lean_object* v___x_4589_; lean_object* v___x_4590_; lean_object* v___x_4591_; uint8_t v___x_4592_; 
v___x_4589_ = lean_nat_add(v___x_4577_, v___x_4583_);
v___x_4590_ = lean_byte_array_size(v_workspace_4516_);
v___x_4591_ = lean_unsigned_to_nat(0u);
v___x_4592_ = lean_nat_dec_eq(v_count_4515_, v___x_4591_);
if (v___x_4592_ == 0)
{
uint8_t v___x_4593_; 
v___x_4593_ = lean_nat_dec_lt(v___x_4591_, v_arity_4511_);
if (v___x_4593_ == 0)
{
v___y_4570_ = v_work_4587_;
v___y_4571_ = v___x_4590_;
v___y_4572_ = v___x_4589_;
v___y_4573_ = v___x_4591_;
goto v___jp_4569_;
}
else
{
lean_object* v___x_4594_; uint8_t v___x_4595_; 
v___x_4594_ = lean_unsigned_to_nat(4096u);
v___x_4595_ = lean_nat_dec_le(v_arity_4511_, v___x_4594_);
if (v___x_4595_ == 0)
{
v___y_4570_ = v_work_4587_;
v___y_4571_ = v___x_4590_;
v___y_4572_ = v___x_4589_;
v___y_4573_ = v___x_4591_;
goto v___jp_4569_;
}
else
{
lean_object* v___x_4596_; lean_object* v___x_4597_; lean_object* v___x_4598_; lean_object* v___x_4599_; 
v___x_4596_ = lean_unsigned_to_nat(4u);
v___x_4597_ = lean_nat_mul(v_arity_4511_, v___x_4596_);
v___x_4598_ = lean_unsigned_to_nat(28u);
v___x_4599_ = lean_nat_add(v___x_4597_, v___x_4598_);
lean_dec(v___x_4597_);
v___y_4570_ = v_work_4587_;
v___y_4571_ = v___x_4590_;
v___y_4572_ = v___x_4589_;
v___y_4573_ = v___x_4599_;
goto v___jp_4569_;
}
}
}
else
{
v___y_4570_ = v_work_4587_;
v___y_4571_ = v___x_4590_;
v___y_4572_ = v___x_4589_;
v___y_4573_ = v___x_4591_;
goto v___jp_4569_;
}
}
else
{
uint8_t v___x_4600_; lean_object* v___x_4601_; lean_object* v___x_4602_; lean_object* v___x_4603_; 
lean_dec(v_work_4587_);
lean_dec_ref(v_products_4517_);
v___x_4600_ = 8;
v___x_4601_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4601_, 0, v_maxWork_4509_);
lean_ctor_set_uint8(v___x_4601_, sizeof(void*)*1, v___x_4600_);
v___x_4602_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4602_, 0, v___x_4601_);
v___x_4603_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4603_, 0, v___x_4602_);
lean_ctor_set(v___x_4603_, 1, v_table_4503_);
return v___x_4603_;
}
}
}
}
}
else
{
lean_dec_ref(v_products_4517_);
lean_dec(v_maxWork_4509_);
goto v___jp_4519_;
}
}
else
{
lean_dec_ref(v_products_4517_);
lean_dec(v_maxWork_4509_);
goto v___jp_4519_;
}
v___jp_4519_:
{
uint8_t v___x_4520_; lean_object* v___x_4521_; lean_object* v___x_4522_; lean_object* v___x_4523_; 
v___x_4520_ = 1;
lean_inc(v_work_4518_);
v___x_4521_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4521_, 0, v_work_4518_);
lean_ctor_set_uint8(v___x_4521_, sizeof(void*)*1, v___x_4520_);
v___x_4522_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4522_, 0, v___x_4521_);
v___x_4523_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4523_, 0, v___x_4522_);
lean_ctor_set(v___x_4523_, 1, v_table_4503_);
return v___x_4523_;
}
v___jp_4524_:
{
uint8_t v___x_4525_; lean_object* v___x_4526_; lean_object* v___x_4527_; lean_object* v___x_4528_; 
v___x_4525_ = 5;
lean_inc(v_work_4518_);
v___x_4526_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4526_, 0, v_work_4518_);
lean_ctor_set_uint8(v___x_4526_, sizeof(void*)*1, v___x_4525_);
v___x_4527_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4527_, 0, v___x_4526_);
v___x_4528_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4528_, 0, v___x_4527_);
lean_ctor_set(v___x_4528_, 1, v_table_4503_);
return v___x_4528_;
}
v___jp_4529_:
{
lean_object* v_size_4533_; lean_object* v___x_4535_; uint8_t v_isShared_4536_; uint8_t v_isSharedCheck_4567_; 
v_size_4533_ = lean_ctor_get(v_products_4517_, 0);
v_isSharedCheck_4567_ = !lean_is_exclusive(v_products_4517_);
if (v_isSharedCheck_4567_ == 0)
{
lean_object* v_unused_4568_; 
v_unused_4568_ = lean_ctor_get(v_products_4517_, 1);
lean_dec(v_unused_4568_);
v___x_4535_ = v_products_4517_;
v_isShared_4536_ = v_isSharedCheck_4567_;
goto v_resetjp_4534_;
}
else
{
lean_inc(v_size_4533_);
lean_dec(v_products_4517_);
v___x_4535_ = lean_box(0);
v_isShared_4536_ = v_isSharedCheck_4567_;
goto v_resetjp_4534_;
}
v_resetjp_4534_:
{
lean_object* v___x_4537_; lean_object* v___x_4538_; lean_object* v___x_4539_; lean_object* v___x_4540_; uint8_t v___x_4541_; 
v___x_4537_ = lean_nat_add(v___y_4531_, v___y_4532_);
lean_dec(v___y_4532_);
lean_dec(v___y_4531_);
v___x_4538_ = lean_unsigned_to_nat(12u);
v___x_4539_ = lean_nat_mul(v___x_4538_, v_size_4533_);
lean_dec(v_size_4533_);
v___x_4540_ = lean_nat_add(v___x_4537_, v___x_4539_);
lean_dec(v___x_4539_);
lean_dec(v___x_4537_);
v___x_4541_ = lean_nat_dec_lt(v_maxBytes_4508_, v___x_4540_);
if (v___x_4541_ == 0)
{
lean_object* v___x_4542_; uint8_t v___x_4543_; 
v___x_4542_ = lean_obj_once(&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12, &lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12_once, _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12);
v___x_4543_ = lean_nat_dec_le(v___x_4542_, v___x_4540_);
lean_dec(v___x_4540_);
if (v___x_4543_ == 0)
{
lean_del_object(v___x_4535_);
if (v_native_4510_ == 0)
{
lean_object* v___x_4544_; 
v___x_4544_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable(v_table_4503_, v_operation_4504_, v_a_4505_, v_b_4506_, v_maxCount_4507_, v_maxBytes_4508_, v_maxWork_4509_, v___y_4530_);
return v___x_4544_;
}
else
{
lean_object* v___x_4545_; uint8_t v___x_4546_; 
v___x_4545_ = lean_unsigned_to_nat(0u);
v___x_4546_ = lean_nat_dec_lt(v___x_4545_, v_arity_4511_);
if (v___x_4546_ == 0)
{
lean_object* v___x_4547_; 
v___x_4547_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable(v_table_4503_, v_operation_4504_, v_a_4505_, v_b_4506_, v_maxCount_4507_, v_maxBytes_4508_, v_maxWork_4509_, v___y_4530_);
return v___x_4547_;
}
else
{
lean_object* v___x_4548_; uint8_t v___x_4549_; 
v___x_4548_ = lean_unsigned_to_nat(4096u);
v___x_4549_ = lean_nat_dec_le(v_arity_4511_, v___x_4548_);
if (v___x_4549_ == 0)
{
lean_object* v___x_4550_; 
v___x_4550_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable(v_table_4503_, v_operation_4504_, v_a_4505_, v_b_4506_, v_maxCount_4507_, v_maxBytes_4508_, v_maxWork_4509_, v___y_4530_);
return v___x_4550_;
}
else
{
lean_object* v___x_4551_; uint8_t v___x_4552_; 
v___x_4551_ = lean_unsigned_to_nat(4294967295u);
v___x_4552_ = lean_nat_dec_le(v_count_4515_, v___x_4551_);
if (v___x_4552_ == 0)
{
lean_object* v___x_4553_; 
v___x_4553_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePortable(v_table_4503_, v_operation_4504_, v_a_4505_, v_b_4506_, v_maxCount_4507_, v_maxBytes_4508_, v_maxWork_4509_, v___y_4530_);
return v___x_4553_;
}
else
{
lean_object* v___x_4554_; 
v___x_4554_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combinePacked(v_table_4503_, v_operation_4504_, v_a_4505_, v_b_4506_, v_maxCount_4507_, v_maxBytes_4508_, v_maxWork_4509_, v___y_4530_);
return v___x_4554_;
}
}
}
}
}
else
{
uint8_t v___x_4555_; lean_object* v___x_4556_; lean_object* v___x_4557_; lean_object* v___x_4559_; 
lean_dec(v_maxWork_4509_);
v___x_4555_ = 4;
v___x_4556_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4556_, 0, v___y_4530_);
lean_ctor_set_uint8(v___x_4556_, sizeof(void*)*1, v___x_4555_);
v___x_4557_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4557_, 0, v___x_4556_);
if (v_isShared_4536_ == 0)
{
lean_ctor_set(v___x_4535_, 1, v_table_4503_);
lean_ctor_set(v___x_4535_, 0, v___x_4557_);
v___x_4559_ = v___x_4535_;
goto v_reusejp_4558_;
}
else
{
lean_object* v_reuseFailAlloc_4560_; 
v_reuseFailAlloc_4560_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4560_, 0, v___x_4557_);
lean_ctor_set(v_reuseFailAlloc_4560_, 1, v_table_4503_);
v___x_4559_ = v_reuseFailAlloc_4560_;
goto v_reusejp_4558_;
}
v_reusejp_4558_:
{
return v___x_4559_;
}
}
}
else
{
uint8_t v___x_4561_; lean_object* v___x_4562_; lean_object* v___x_4563_; lean_object* v___x_4565_; 
lean_dec(v___x_4540_);
lean_dec(v_maxWork_4509_);
v___x_4561_ = 7;
v___x_4562_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_4562_, 0, v___y_4530_);
lean_ctor_set_uint8(v___x_4562_, sizeof(void*)*1, v___x_4561_);
v___x_4563_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4563_, 0, v___x_4562_);
if (v_isShared_4536_ == 0)
{
lean_ctor_set(v___x_4535_, 1, v_table_4503_);
lean_ctor_set(v___x_4535_, 0, v___x_4563_);
v___x_4565_ = v___x_4535_;
goto v_reusejp_4564_;
}
else
{
lean_object* v_reuseFailAlloc_4566_; 
v_reuseFailAlloc_4566_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4566_, 0, v___x_4563_);
lean_ctor_set(v_reuseFailAlloc_4566_, 1, v_table_4503_);
v___x_4565_ = v_reuseFailAlloc_4566_;
goto v_reusejp_4564_;
}
v_reusejp_4564_:
{
return v___x_4565_;
}
}
}
}
v___jp_4569_:
{
uint8_t v___x_4574_; 
v___x_4574_ = lean_nat_dec_le(v___y_4571_, v___y_4573_);
if (v___x_4574_ == 0)
{
lean_dec(v___y_4573_);
v___y_4530_ = v___y_4570_;
v___y_4531_ = v___y_4572_;
v___y_4532_ = v___y_4571_;
goto v___jp_4529_;
}
else
{
lean_dec(v___y_4571_);
v___y_4530_ = v___y_4570_;
v___y_4531_ = v___y_4572_;
v___y_4532_ = v___y_4573_;
goto v___jp_4529_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh___boxed(lean_object* v_table_4607_, lean_object* v_operation_4608_, lean_object* v_a_4609_, lean_object* v_b_4610_, lean_object* v_maxCount_4611_, lean_object* v_maxBytes_4612_, lean_object* v_maxWork_4613_, lean_object* v_native_4614_){
_start:
{
uint8_t v_operation_boxed_4615_; uint8_t v_native_boxed_4616_; lean_object* v_res_4617_; 
v_operation_boxed_4615_ = lean_unbox(v_operation_4608_);
v_native_boxed_4616_ = lean_unbox(v_native_4614_);
v_res_4617_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(v_table_4607_, v_operation_boxed_4615_, v_a_4609_, v_b_4610_, v_maxCount_4611_, v_maxBytes_4612_, v_maxWork_4613_, v_native_boxed_4616_);
lean_dec(v_maxBytes_4612_);
lean_dec(v_maxCount_4611_);
lean_dec(v_b_4610_);
lean_dec(v_a_4609_);
return v_res_4617_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0___redArg(uint64_t v_a_4618_, lean_object* v_x_4619_){
_start:
{
if (lean_obj_tag(v_x_4619_) == 0)
{
uint8_t v___x_4620_; 
v___x_4620_ = 0;
return v___x_4620_;
}
else
{
lean_object* v_key_4621_; lean_object* v_tail_4622_; uint64_t v___x_4623_; uint8_t v___x_4624_; 
v_key_4621_ = lean_ctor_get(v_x_4619_, 0);
v_tail_4622_ = lean_ctor_get(v_x_4619_, 2);
v___x_4623_ = lean_unbox_uint64(v_key_4621_);
v___x_4624_ = lean_uint64_dec_eq(v___x_4623_, v_a_4618_);
if (v___x_4624_ == 0)
{
v_x_4619_ = v_tail_4622_;
goto _start;
}
else
{
return v___x_4624_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0___redArg___boxed(lean_object* v_a_4626_, lean_object* v_x_4627_){
_start:
{
uint64_t v_a_boxed_4628_; uint8_t v_res_4629_; lean_object* v_r_4630_; 
v_a_boxed_4628_ = lean_unbox_uint64(v_a_4626_);
lean_dec_ref(v_a_4626_);
v_res_4629_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0___redArg(v_a_boxed_4628_, v_x_4627_);
lean_dec(v_x_4627_);
v_r_4630_ = lean_box(v_res_4629_);
return v_r_4630_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2_spec__3___redArg(lean_object* v_x_4631_, lean_object* v_x_4632_){
_start:
{
if (lean_obj_tag(v_x_4632_) == 0)
{
return v_x_4631_;
}
else
{
lean_object* v_key_4633_; lean_object* v_value_4634_; lean_object* v_tail_4635_; lean_object* v___x_4637_; uint8_t v_isShared_4638_; uint8_t v_isSharedCheck_4672_; 
v_key_4633_ = lean_ctor_get(v_x_4632_, 0);
v_value_4634_ = lean_ctor_get(v_x_4632_, 1);
v_tail_4635_ = lean_ctor_get(v_x_4632_, 2);
v_isSharedCheck_4672_ = !lean_is_exclusive(v_x_4632_);
if (v_isSharedCheck_4672_ == 0)
{
v___x_4637_ = v_x_4632_;
v_isShared_4638_ = v_isSharedCheck_4672_;
goto v_resetjp_4636_;
}
else
{
lean_inc(v_tail_4635_);
lean_inc(v_value_4634_);
lean_inc(v_key_4633_);
lean_dec(v_x_4632_);
v___x_4637_ = lean_box(0);
v_isShared_4638_ = v_isSharedCheck_4672_;
goto v_resetjp_4636_;
}
v_resetjp_4636_:
{
lean_object* v___x_4639_; uint64_t v___x_4640_; uint64_t v___x_4641_; uint64_t v___x_4642_; uint64_t v___x_4643_; uint64_t v___x_4644_; uint64_t v___x_4645_; uint64_t v_x_4646_; uint64_t v___x_4647_; uint64_t v___x_4648_; uint64_t v___x_4649_; uint64_t v___x_4650_; uint64_t v_x_4651_; uint64_t v___x_4652_; uint64_t v___x_4653_; uint64_t v___x_4654_; uint64_t v___x_4655_; uint64_t v___x_4656_; uint64_t v_fold_4657_; uint64_t v___x_4658_; uint64_t v___x_4659_; uint64_t v___x_4660_; size_t v___x_4661_; size_t v___x_4662_; size_t v___x_4663_; size_t v___x_4664_; size_t v___x_4665_; lean_object* v___x_4666_; lean_object* v___x_4668_; 
v___x_4639_ = lean_array_get_size(v_x_4631_);
v___x_4640_ = 30ULL;
v___x_4641_ = lean_unbox_uint64(v_key_4633_);
v___x_4642_ = lean_uint64_shift_right(v___x_4641_, v___x_4640_);
v___x_4643_ = lean_unbox_uint64(v_key_4633_);
v___x_4644_ = lean_uint64_xor(v___x_4643_, v___x_4642_);
v___x_4645_ = 13787848793156543929ULL;
v_x_4646_ = lean_uint64_mul(v___x_4644_, v___x_4645_);
v___x_4647_ = 27ULL;
v___x_4648_ = lean_uint64_shift_right(v_x_4646_, v___x_4647_);
v___x_4649_ = lean_uint64_xor(v_x_4646_, v___x_4648_);
v___x_4650_ = 10723151780598845931ULL;
v_x_4651_ = lean_uint64_mul(v___x_4649_, v___x_4650_);
v___x_4652_ = 31ULL;
v___x_4653_ = lean_uint64_shift_right(v_x_4651_, v___x_4652_);
v___x_4654_ = lean_uint64_xor(v_x_4651_, v___x_4653_);
v___x_4655_ = 32ULL;
v___x_4656_ = lean_uint64_shift_right(v___x_4654_, v___x_4655_);
v_fold_4657_ = lean_uint64_xor(v___x_4654_, v___x_4656_);
v___x_4658_ = 16ULL;
v___x_4659_ = lean_uint64_shift_right(v_fold_4657_, v___x_4658_);
v___x_4660_ = lean_uint64_xor(v_fold_4657_, v___x_4659_);
v___x_4661_ = lean_uint64_to_usize(v___x_4660_);
v___x_4662_ = lean_usize_of_nat(v___x_4639_);
v___x_4663_ = ((size_t)1ULL);
v___x_4664_ = lean_usize_sub(v___x_4662_, v___x_4663_);
v___x_4665_ = lean_usize_land(v___x_4661_, v___x_4664_);
v___x_4666_ = lean_array_uget_borrowed(v_x_4631_, v___x_4665_);
lean_inc(v___x_4666_);
if (v_isShared_4638_ == 0)
{
lean_ctor_set(v___x_4637_, 2, v___x_4666_);
v___x_4668_ = v___x_4637_;
goto v_reusejp_4667_;
}
else
{
lean_object* v_reuseFailAlloc_4671_; 
v_reuseFailAlloc_4671_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_4671_, 0, v_key_4633_);
lean_ctor_set(v_reuseFailAlloc_4671_, 1, v_value_4634_);
lean_ctor_set(v_reuseFailAlloc_4671_, 2, v___x_4666_);
v___x_4668_ = v_reuseFailAlloc_4671_;
goto v_reusejp_4667_;
}
v_reusejp_4667_:
{
lean_object* v___x_4669_; 
v___x_4669_ = lean_array_uset(v_x_4631_, v___x_4665_, v___x_4668_);
v_x_4631_ = v___x_4669_;
v_x_4632_ = v_tail_4635_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2___redArg(lean_object* v_i_4673_, lean_object* v_source_4674_, lean_object* v_target_4675_){
_start:
{
lean_object* v___x_4676_; uint8_t v___x_4677_; 
v___x_4676_ = lean_array_get_size(v_source_4674_);
v___x_4677_ = lean_nat_dec_lt(v_i_4673_, v___x_4676_);
if (v___x_4677_ == 0)
{
lean_dec_ref(v_source_4674_);
lean_dec(v_i_4673_);
return v_target_4675_;
}
else
{
lean_object* v_es_4678_; lean_object* v___x_4679_; lean_object* v_source_4680_; lean_object* v_target_4681_; lean_object* v___x_4682_; lean_object* v___x_4683_; 
v_es_4678_ = lean_array_fget(v_source_4674_, v_i_4673_);
v___x_4679_ = lean_box(0);
v_source_4680_ = lean_array_fset(v_source_4674_, v_i_4673_, v___x_4679_);
v_target_4681_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2_spec__3___redArg(v_target_4675_, v_es_4678_);
v___x_4682_ = lean_unsigned_to_nat(1u);
v___x_4683_ = lean_nat_add(v_i_4673_, v___x_4682_);
lean_dec(v_i_4673_);
v_i_4673_ = v___x_4683_;
v_source_4674_ = v_source_4680_;
v_target_4675_ = v_target_4681_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1___redArg(lean_object* v_data_4685_){
_start:
{
lean_object* v___x_4686_; lean_object* v___x_4687_; lean_object* v_nbuckets_4688_; lean_object* v___x_4689_; lean_object* v___x_4690_; lean_object* v___x_4691_; lean_object* v___x_4692_; lean_object* v___x_4693_; 
v___x_4686_ = lean_array_get_size(v_data_4685_);
v___x_4687_ = lean_unsigned_to_nat(2u);
v_nbuckets_4688_ = lean_nat_mul(v___x_4686_, v___x_4687_);
v___x_4689_ = lean_unsigned_to_nat(0u);
v___x_4690_ = lean_box(0);
v___x_4691_ = lean_mk_array(v_nbuckets_4688_, v___x_4690_);
v___x_4692_ = lean_array_propagate_mark(v_data_4685_, v___x_4691_);
v___x_4693_ = lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2___redArg(v___x_4689_, v_data_4685_, v___x_4692_);
return v___x_4693_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___redArg(uint64_t v_a_4694_, lean_object* v_b_4695_, lean_object* v_x_4696_){
_start:
{
if (lean_obj_tag(v_x_4696_) == 0)
{
lean_dec(v_b_4695_);
return v_x_4696_;
}
else
{
lean_object* v_key_4697_; lean_object* v_value_4698_; lean_object* v_tail_4699_; lean_object* v___x_4701_; uint8_t v_isShared_4702_; uint8_t v_isSharedCheck_4713_; 
v_key_4697_ = lean_ctor_get(v_x_4696_, 0);
v_value_4698_ = lean_ctor_get(v_x_4696_, 1);
v_tail_4699_ = lean_ctor_get(v_x_4696_, 2);
v_isSharedCheck_4713_ = !lean_is_exclusive(v_x_4696_);
if (v_isSharedCheck_4713_ == 0)
{
v___x_4701_ = v_x_4696_;
v_isShared_4702_ = v_isSharedCheck_4713_;
goto v_resetjp_4700_;
}
else
{
lean_inc(v_tail_4699_);
lean_inc(v_value_4698_);
lean_inc(v_key_4697_);
lean_dec(v_x_4696_);
v___x_4701_ = lean_box(0);
v_isShared_4702_ = v_isSharedCheck_4713_;
goto v_resetjp_4700_;
}
v_resetjp_4700_:
{
uint64_t v___x_4703_; uint8_t v___x_4704_; 
v___x_4703_ = lean_unbox_uint64(v_key_4697_);
v___x_4704_ = lean_uint64_dec_eq(v___x_4703_, v_a_4694_);
if (v___x_4704_ == 0)
{
lean_object* v___x_4705_; lean_object* v___x_4707_; 
v___x_4705_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___redArg(v_a_4694_, v_b_4695_, v_tail_4699_);
if (v_isShared_4702_ == 0)
{
lean_ctor_set(v___x_4701_, 2, v___x_4705_);
v___x_4707_ = v___x_4701_;
goto v_reusejp_4706_;
}
else
{
lean_object* v_reuseFailAlloc_4708_; 
v_reuseFailAlloc_4708_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_4708_, 0, v_key_4697_);
lean_ctor_set(v_reuseFailAlloc_4708_, 1, v_value_4698_);
lean_ctor_set(v_reuseFailAlloc_4708_, 2, v___x_4705_);
v___x_4707_ = v_reuseFailAlloc_4708_;
goto v_reusejp_4706_;
}
v_reusejp_4706_:
{
return v___x_4707_;
}
}
else
{
lean_object* v___x_4709_; lean_object* v___x_4711_; 
lean_dec(v_value_4698_);
lean_dec(v_key_4697_);
v___x_4709_ = lean_box_uint64(v_a_4694_);
if (v_isShared_4702_ == 0)
{
lean_ctor_set(v___x_4701_, 1, v_b_4695_);
lean_ctor_set(v___x_4701_, 0, v___x_4709_);
v___x_4711_ = v___x_4701_;
goto v_reusejp_4710_;
}
else
{
lean_object* v_reuseFailAlloc_4712_; 
v_reuseFailAlloc_4712_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v_reuseFailAlloc_4712_, 0, v___x_4709_);
lean_ctor_set(v_reuseFailAlloc_4712_, 1, v_b_4695_);
lean_ctor_set(v_reuseFailAlloc_4712_, 2, v_tail_4699_);
v___x_4711_ = v_reuseFailAlloc_4712_;
goto v_reusejp_4710_;
}
v_reusejp_4710_:
{
return v___x_4711_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___redArg___boxed(lean_object* v_a_4714_, lean_object* v_b_4715_, lean_object* v_x_4716_){
_start:
{
uint64_t v_a_boxed_4717_; lean_object* v_res_4718_; 
v_a_boxed_4717_ = lean_unbox_uint64(v_a_4714_);
lean_dec_ref(v_a_4714_);
v_res_4718_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___redArg(v_a_boxed_4717_, v_b_4715_, v_x_4716_);
return v_res_4718_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0___redArg(lean_object* v_m_4719_, uint64_t v_a_4720_, lean_object* v_b_4721_){
_start:
{
lean_object* v_size_4722_; lean_object* v_buckets_4723_; lean_object* v___x_4725_; uint8_t v_isShared_4726_; uint8_t v_isSharedCheck_4779_; 
v_size_4722_ = lean_ctor_get(v_m_4719_, 0);
v_buckets_4723_ = lean_ctor_get(v_m_4719_, 1);
v_isSharedCheck_4779_ = !lean_is_exclusive(v_m_4719_);
if (v_isSharedCheck_4779_ == 0)
{
v___x_4725_ = v_m_4719_;
v_isShared_4726_ = v_isSharedCheck_4779_;
goto v_resetjp_4724_;
}
else
{
lean_inc(v_buckets_4723_);
lean_inc(v_size_4722_);
lean_dec(v_m_4719_);
v___x_4725_ = lean_box(0);
v_isShared_4726_ = v_isSharedCheck_4779_;
goto v_resetjp_4724_;
}
v_resetjp_4724_:
{
lean_object* v___x_4727_; uint64_t v___x_4728_; uint64_t v___x_4729_; uint64_t v___x_4730_; uint64_t v___x_4731_; uint64_t v_x_4732_; uint64_t v___x_4733_; uint64_t v___x_4734_; uint64_t v___x_4735_; uint64_t v___x_4736_; uint64_t v_x_4737_; uint64_t v___x_4738_; uint64_t v___x_4739_; uint64_t v___x_4740_; uint64_t v___x_4741_; uint64_t v___x_4742_; uint64_t v_fold_4743_; uint64_t v___x_4744_; uint64_t v___x_4745_; uint64_t v___x_4746_; size_t v___x_4747_; size_t v___x_4748_; size_t v___x_4749_; size_t v___x_4750_; size_t v___x_4751_; lean_object* v_bkt_4752_; uint8_t v___x_4753_; 
v___x_4727_ = lean_array_get_size(v_buckets_4723_);
v___x_4728_ = 30ULL;
v___x_4729_ = lean_uint64_shift_right(v_a_4720_, v___x_4728_);
v___x_4730_ = lean_uint64_xor(v_a_4720_, v___x_4729_);
v___x_4731_ = 13787848793156543929ULL;
v_x_4732_ = lean_uint64_mul(v___x_4730_, v___x_4731_);
v___x_4733_ = 27ULL;
v___x_4734_ = lean_uint64_shift_right(v_x_4732_, v___x_4733_);
v___x_4735_ = lean_uint64_xor(v_x_4732_, v___x_4734_);
v___x_4736_ = 10723151780598845931ULL;
v_x_4737_ = lean_uint64_mul(v___x_4735_, v___x_4736_);
v___x_4738_ = 31ULL;
v___x_4739_ = lean_uint64_shift_right(v_x_4737_, v___x_4738_);
v___x_4740_ = lean_uint64_xor(v_x_4737_, v___x_4739_);
v___x_4741_ = 32ULL;
v___x_4742_ = lean_uint64_shift_right(v___x_4740_, v___x_4741_);
v_fold_4743_ = lean_uint64_xor(v___x_4740_, v___x_4742_);
v___x_4744_ = 16ULL;
v___x_4745_ = lean_uint64_shift_right(v_fold_4743_, v___x_4744_);
v___x_4746_ = lean_uint64_xor(v_fold_4743_, v___x_4745_);
v___x_4747_ = lean_uint64_to_usize(v___x_4746_);
v___x_4748_ = lean_usize_of_nat(v___x_4727_);
v___x_4749_ = ((size_t)1ULL);
v___x_4750_ = lean_usize_sub(v___x_4748_, v___x_4749_);
v___x_4751_ = lean_usize_land(v___x_4747_, v___x_4750_);
v_bkt_4752_ = lean_array_uget_borrowed(v_buckets_4723_, v___x_4751_);
v___x_4753_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0___redArg(v_a_4720_, v_bkt_4752_);
if (v___x_4753_ == 0)
{
lean_object* v___x_4754_; lean_object* v_size_x27_4755_; lean_object* v___x_4756_; lean_object* v___x_4757_; lean_object* v_buckets_x27_4758_; lean_object* v___x_4759_; lean_object* v___x_4760_; lean_object* v___x_4761_; lean_object* v___x_4762_; lean_object* v___x_4763_; uint8_t v___x_4764_; 
v___x_4754_ = lean_unsigned_to_nat(1u);
v_size_x27_4755_ = lean_nat_add(v_size_4722_, v___x_4754_);
lean_dec(v_size_4722_);
v___x_4756_ = lean_box_uint64(v_a_4720_);
lean_inc(v_bkt_4752_);
v___x_4757_ = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(v___x_4757_, 0, v___x_4756_);
lean_ctor_set(v___x_4757_, 1, v_b_4721_);
lean_ctor_set(v___x_4757_, 2, v_bkt_4752_);
v_buckets_x27_4758_ = lean_array_uset(v_buckets_4723_, v___x_4751_, v___x_4757_);
v___x_4759_ = lean_unsigned_to_nat(4u);
v___x_4760_ = lean_nat_mul(v_size_x27_4755_, v___x_4759_);
v___x_4761_ = lean_unsigned_to_nat(3u);
v___x_4762_ = lean_nat_div(v___x_4760_, v___x_4761_);
lean_dec(v___x_4760_);
v___x_4763_ = lean_array_get_size(v_buckets_x27_4758_);
v___x_4764_ = lean_nat_dec_le(v___x_4762_, v___x_4763_);
lean_dec(v___x_4762_);
if (v___x_4764_ == 0)
{
lean_object* v_val_4765_; lean_object* v___x_4767_; 
v_val_4765_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1___redArg(v_buckets_x27_4758_);
if (v_isShared_4726_ == 0)
{
lean_ctor_set(v___x_4725_, 1, v_val_4765_);
lean_ctor_set(v___x_4725_, 0, v_size_x27_4755_);
v___x_4767_ = v___x_4725_;
goto v_reusejp_4766_;
}
else
{
lean_object* v_reuseFailAlloc_4768_; 
v_reuseFailAlloc_4768_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4768_, 0, v_size_x27_4755_);
lean_ctor_set(v_reuseFailAlloc_4768_, 1, v_val_4765_);
v___x_4767_ = v_reuseFailAlloc_4768_;
goto v_reusejp_4766_;
}
v_reusejp_4766_:
{
return v___x_4767_;
}
}
else
{
lean_object* v___x_4770_; 
if (v_isShared_4726_ == 0)
{
lean_ctor_set(v___x_4725_, 1, v_buckets_x27_4758_);
lean_ctor_set(v___x_4725_, 0, v_size_x27_4755_);
v___x_4770_ = v___x_4725_;
goto v_reusejp_4769_;
}
else
{
lean_object* v_reuseFailAlloc_4771_; 
v_reuseFailAlloc_4771_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4771_, 0, v_size_x27_4755_);
lean_ctor_set(v_reuseFailAlloc_4771_, 1, v_buckets_x27_4758_);
v___x_4770_ = v_reuseFailAlloc_4771_;
goto v_reusejp_4769_;
}
v_reusejp_4769_:
{
return v___x_4770_;
}
}
}
else
{
lean_object* v___x_4772_; lean_object* v_buckets_x27_4773_; lean_object* v___x_4774_; lean_object* v___x_4775_; lean_object* v___x_4777_; 
lean_inc(v_bkt_4752_);
v___x_4772_ = lean_box(0);
v_buckets_x27_4773_ = lean_array_uset(v_buckets_4723_, v___x_4751_, v___x_4772_);
v___x_4774_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___redArg(v_a_4720_, v_b_4721_, v_bkt_4752_);
v___x_4775_ = lean_array_uset(v_buckets_x27_4773_, v___x_4751_, v___x_4774_);
if (v_isShared_4726_ == 0)
{
lean_ctor_set(v___x_4725_, 1, v___x_4775_);
v___x_4777_ = v___x_4725_;
goto v_reusejp_4776_;
}
else
{
lean_object* v_reuseFailAlloc_4778_; 
v_reuseFailAlloc_4778_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4778_, 0, v_size_4722_);
lean_ctor_set(v_reuseFailAlloc_4778_, 1, v___x_4775_);
v___x_4777_ = v_reuseFailAlloc_4778_;
goto v_reusejp_4776_;
}
v_reusejp_4776_:
{
return v___x_4777_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0___redArg___boxed(lean_object* v_m_4780_, lean_object* v_a_4781_, lean_object* v_b_4782_){
_start:
{
uint64_t v_a_boxed_4783_; lean_object* v_res_4784_; 
v_a_boxed_4783_ = lean_unbox_uint64(v_a_4781_);
lean_dec_ref(v_a_4781_);
v_res_4784_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0___redArg(v_m_4780_, v_a_boxed_4783_, v_b_4782_);
return v_res_4784_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss(lean_object* v_table_4785_, uint64_t v_key_4786_, lean_object* v_a_4787_, lean_object* v_b_4788_, lean_object* v_maxCount_4789_, lean_object* v_maxBytes_4790_, lean_object* v_maxWork_4791_, uint8_t v_native_4792_){
_start:
{
uint8_t v___x_4793_; lean_object* v_outcome_4794_; lean_object* v_result_4795_; 
v___x_4793_ = 1;
v_outcome_4794_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(v_table_4785_, v___x_4793_, v_a_4787_, v_b_4788_, v_maxCount_4789_, v_maxBytes_4790_, v_maxWork_4791_, v_native_4792_);
v_result_4795_ = lean_ctor_get(v_outcome_4794_, 0);
lean_inc_ref(v_result_4795_);
if (lean_obj_tag(v_result_4795_) == 0)
{
lean_dec_ref_known(v_result_4795_, 1);
return v_outcome_4794_;
}
else
{
lean_object* v_table_4796_; lean_object* v_a_4797_; lean_object* v___x_4798_; uint8_t v___x_4799_; 
v_table_4796_ = lean_ctor_get(v_outcome_4794_, 1);
lean_inc_ref(v_table_4796_);
v_a_4797_ = lean_ctor_get(v_result_4795_, 0);
v___x_4798_ = lean_unsigned_to_nat(4294967295u);
v___x_4799_ = lean_nat_dec_le(v_a_4797_, v___x_4798_);
if (v___x_4799_ == 0)
{
lean_dec_ref(v_table_4796_);
lean_dec_ref_known(v_result_4795_, 1);
return v_outcome_4794_;
}
else
{
lean_object* v_products_4800_; lean_object* v_arity_4801_; uint8_t v_width_4802_; lean_object* v_exponents_4803_; lean_object* v_metadata_4804_; lean_object* v_count_4805_; lean_object* v_workspace_4806_; lean_object* v_buckets_4807_; lean_object* v_hashBits_4808_; lean_object* v_work_4809_; lean_object* v___x_4811_; uint8_t v_isShared_4812_; uint8_t v_isSharedCheck_4880_; 
v_products_4800_ = lean_ctor_get(v_table_4796_, 6);
v_arity_4801_ = lean_ctor_get(v_table_4796_, 0);
v_width_4802_ = lean_ctor_get_uint8(v_table_4796_, sizeof(void*)*9);
v_exponents_4803_ = lean_ctor_get(v_table_4796_, 1);
v_metadata_4804_ = lean_ctor_get(v_table_4796_, 2);
v_count_4805_ = lean_ctor_get(v_table_4796_, 3);
v_workspace_4806_ = lean_ctor_get(v_table_4796_, 4);
v_buckets_4807_ = lean_ctor_get(v_table_4796_, 5);
v_hashBits_4808_ = lean_ctor_get(v_table_4796_, 7);
v_work_4809_ = lean_ctor_get(v_table_4796_, 8);
v_isSharedCheck_4880_ = !lean_is_exclusive(v_table_4796_);
if (v_isSharedCheck_4880_ == 0)
{
v___x_4811_ = v_table_4796_;
v_isShared_4812_ = v_isSharedCheck_4880_;
goto v_resetjp_4810_;
}
else
{
lean_inc(v_work_4809_);
lean_inc(v_hashBits_4808_);
lean_inc(v_products_4800_);
lean_inc(v_buckets_4807_);
lean_inc(v_workspace_4806_);
lean_inc(v_count_4805_);
lean_inc(v_metadata_4804_);
lean_inc(v_exponents_4803_);
lean_inc(v_arity_4801_);
lean_dec(v_table_4796_);
v___x_4811_ = lean_box(0);
v_isShared_4812_ = v_isSharedCheck_4880_;
goto v_resetjp_4810_;
}
v_resetjp_4810_:
{
lean_object* v_size_4813_; lean_object* v___x_4814_; uint8_t v___x_4815_; 
v_size_4813_ = lean_ctor_get(v_products_4800_, 0);
v___x_4814_ = lean_unsigned_to_nat(32768u);
v___x_4815_ = lean_nat_dec_lt(v_size_4813_, v___x_4814_);
if (v___x_4815_ == 0)
{
lean_del_object(v___x_4811_);
lean_dec(v_work_4809_);
lean_dec(v_hashBits_4808_);
lean_dec_ref(v_buckets_4807_);
lean_dec_ref(v_workspace_4806_);
lean_dec(v_count_4805_);
lean_dec_ref(v_metadata_4804_);
lean_dec_ref(v_exponents_4803_);
lean_dec(v_arity_4801_);
lean_dec_ref(v_products_4800_);
lean_dec_ref_known(v_result_4795_, 1);
return v_outcome_4794_;
}
else
{
lean_object* v___x_4816_; lean_object* v___x_4817_; lean_object* v___x_4818_; lean_object* v___y_4820_; lean_object* v___y_4821_; lean_object* v___y_4822_; lean_object* v___y_4844_; lean_object* v___y_4845_; lean_object* v___y_4846_; lean_object* v___y_4847_; lean_object* v___y_4850_; lean_object* v___x_4867_; lean_object* v___y_4869_; lean_object* v___x_4871_; uint8_t v___x_4872_; 
v___x_4816_ = lean_byte_array_size(v_exponents_4803_);
v___x_4817_ = lean_byte_array_size(v_metadata_4804_);
v___x_4818_ = lean_nat_add(v___x_4816_, v___x_4817_);
v___x_4867_ = lean_byte_array_size(v_workspace_4806_);
v___x_4871_ = lean_unsigned_to_nat(0u);
v___x_4872_ = lean_nat_dec_eq(v_count_4805_, v___x_4871_);
if (v___x_4872_ == 0)
{
uint8_t v___x_4873_; 
v___x_4873_ = lean_nat_dec_lt(v___x_4871_, v_arity_4801_);
if (v___x_4873_ == 0)
{
v___y_4869_ = v___x_4871_;
goto v___jp_4868_;
}
else
{
lean_object* v___x_4874_; uint8_t v___x_4875_; 
v___x_4874_ = lean_unsigned_to_nat(4096u);
v___x_4875_ = lean_nat_dec_le(v_arity_4801_, v___x_4874_);
if (v___x_4875_ == 0)
{
v___y_4869_ = v___x_4871_;
goto v___jp_4868_;
}
else
{
lean_object* v___x_4876_; lean_object* v___x_4877_; lean_object* v___x_4878_; lean_object* v___x_4879_; 
v___x_4876_ = lean_unsigned_to_nat(4u);
v___x_4877_ = lean_nat_mul(v_arity_4801_, v___x_4876_);
v___x_4878_ = lean_unsigned_to_nat(28u);
v___x_4879_ = lean_nat_add(v___x_4877_, v___x_4878_);
lean_dec(v___x_4877_);
v___y_4869_ = v___x_4879_;
goto v___jp_4868_;
}
}
}
else
{
v___y_4869_ = v___x_4871_;
goto v___jp_4868_;
}
v___jp_4819_:
{
lean_object* v___x_4823_; lean_object* v___x_4824_; lean_object* v___x_4825_; lean_object* v___x_4826_; uint8_t v___x_4827_; 
v___x_4823_ = lean_nat_add(v___x_4818_, v___y_4822_);
lean_dec(v___y_4822_);
lean_dec(v___x_4818_);
v___x_4824_ = lean_nat_add(v___x_4823_, v___y_4820_);
lean_dec(v___y_4820_);
lean_dec(v___x_4823_);
v___x_4825_ = lean_nat_add(v___x_4824_, v___y_4821_);
lean_dec(v___x_4824_);
v___x_4826_ = lean_obj_once(&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12, &lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12_once, _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12);
v___x_4827_ = lean_nat_dec_lt(v___x_4825_, v___x_4826_);
lean_dec(v___x_4825_);
if (v___x_4827_ == 0)
{
lean_del_object(v___x_4811_);
lean_dec(v_work_4809_);
lean_dec(v_hashBits_4808_);
lean_dec_ref(v_buckets_4807_);
lean_dec_ref(v_workspace_4806_);
lean_dec(v_count_4805_);
lean_dec_ref(v_metadata_4804_);
lean_dec_ref(v_exponents_4803_);
lean_dec(v_arity_4801_);
lean_dec_ref(v_products_4800_);
lean_dec_ref_known(v_result_4795_, 1);
return v_outcome_4794_;
}
else
{
lean_object* v___x_4829_; uint8_t v_isShared_4830_; uint8_t v_isSharedCheck_4840_; 
v_isSharedCheck_4840_ = !lean_is_exclusive(v_outcome_4794_);
if (v_isSharedCheck_4840_ == 0)
{
lean_object* v_unused_4841_; lean_object* v_unused_4842_; 
v_unused_4841_ = lean_ctor_get(v_outcome_4794_, 1);
lean_dec(v_unused_4841_);
v_unused_4842_ = lean_ctor_get(v_outcome_4794_, 0);
lean_dec(v_unused_4842_);
v___x_4829_ = v_outcome_4794_;
v_isShared_4830_ = v_isSharedCheck_4840_;
goto v_resetjp_4828_;
}
else
{
lean_dec(v_outcome_4794_);
v___x_4829_ = lean_box(0);
v_isShared_4830_ = v_isSharedCheck_4840_;
goto v_resetjp_4828_;
}
v_resetjp_4828_:
{
uint32_t v___x_4831_; lean_object* v___x_4832_; lean_object* v___x_4833_; lean_object* v___x_4835_; 
v___x_4831_ = lean_uint32_of_nat(v_a_4797_);
v___x_4832_ = lean_box_uint32(v___x_4831_);
v___x_4833_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0___redArg(v_products_4800_, v_key_4786_, v___x_4832_);
if (v_isShared_4812_ == 0)
{
lean_ctor_set(v___x_4811_, 6, v___x_4833_);
v___x_4835_ = v___x_4811_;
goto v_reusejp_4834_;
}
else
{
lean_object* v_reuseFailAlloc_4839_; 
v_reuseFailAlloc_4839_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_reuseFailAlloc_4839_, 0, v_arity_4801_);
lean_ctor_set(v_reuseFailAlloc_4839_, 1, v_exponents_4803_);
lean_ctor_set(v_reuseFailAlloc_4839_, 2, v_metadata_4804_);
lean_ctor_set(v_reuseFailAlloc_4839_, 3, v_count_4805_);
lean_ctor_set(v_reuseFailAlloc_4839_, 4, v_workspace_4806_);
lean_ctor_set(v_reuseFailAlloc_4839_, 5, v_buckets_4807_);
lean_ctor_set(v_reuseFailAlloc_4839_, 6, v___x_4833_);
lean_ctor_set(v_reuseFailAlloc_4839_, 7, v_hashBits_4808_);
lean_ctor_set(v_reuseFailAlloc_4839_, 8, v_work_4809_);
lean_ctor_set_uint8(v_reuseFailAlloc_4839_, sizeof(void*)*9, v_width_4802_);
v___x_4835_ = v_reuseFailAlloc_4839_;
goto v_reusejp_4834_;
}
v_reusejp_4834_:
{
lean_object* v___x_4837_; 
if (v_isShared_4830_ == 0)
{
lean_ctor_set(v___x_4829_, 1, v___x_4835_);
v___x_4837_ = v___x_4829_;
goto v_reusejp_4836_;
}
else
{
lean_object* v_reuseFailAlloc_4838_; 
v_reuseFailAlloc_4838_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4838_, 0, v_result_4795_);
lean_ctor_set(v_reuseFailAlloc_4838_, 1, v___x_4835_);
v___x_4837_ = v_reuseFailAlloc_4838_;
goto v_reusejp_4836_;
}
v_reusejp_4836_:
{
return v___x_4837_;
}
}
}
}
}
v___jp_4843_:
{
uint8_t v___x_4848_; 
v___x_4848_ = lean_nat_dec_le(v___y_4845_, v___y_4847_);
if (v___x_4848_ == 0)
{
lean_dec(v___y_4847_);
v___y_4820_ = v___y_4844_;
v___y_4821_ = v___y_4846_;
v___y_4822_ = v___y_4845_;
goto v___jp_4819_;
}
else
{
lean_dec(v___y_4845_);
v___y_4820_ = v___y_4844_;
v___y_4821_ = v___y_4846_;
v___y_4822_ = v___y_4847_;
goto v___jp_4819_;
}
}
v___jp_4849_:
{
lean_object* v___x_4851_; lean_object* v___x_4852_; lean_object* v___x_4853_; lean_object* v___x_4854_; lean_object* v___x_4855_; uint8_t v___x_4856_; 
v___x_4851_ = lean_nat_add(v___x_4818_, v___y_4850_);
lean_dec(v___y_4850_);
v___x_4852_ = lean_unsigned_to_nat(12u);
v___x_4853_ = lean_nat_mul(v___x_4852_, v_size_4813_);
v___x_4854_ = lean_nat_add(v___x_4851_, v___x_4853_);
lean_dec(v___x_4851_);
v___x_4855_ = lean_nat_add(v___x_4854_, v___x_4852_);
lean_dec(v___x_4854_);
v___x_4856_ = lean_nat_dec_le(v___x_4855_, v_maxBytes_4790_);
lean_dec(v___x_4855_);
if (v___x_4856_ == 0)
{
lean_dec(v___x_4853_);
lean_dec(v___x_4818_);
lean_del_object(v___x_4811_);
lean_dec(v_work_4809_);
lean_dec(v_hashBits_4808_);
lean_dec_ref(v_buckets_4807_);
lean_dec_ref(v_workspace_4806_);
lean_dec(v_count_4805_);
lean_dec_ref(v_metadata_4804_);
lean_dec_ref(v_exponents_4803_);
lean_dec(v_arity_4801_);
lean_dec_ref(v_products_4800_);
lean_dec_ref_known(v_result_4795_, 1);
return v_outcome_4794_;
}
else
{
lean_object* v___x_4857_; lean_object* v___x_4858_; uint8_t v___x_4859_; 
v___x_4857_ = lean_byte_array_size(v_workspace_4806_);
v___x_4858_ = lean_unsigned_to_nat(0u);
v___x_4859_ = lean_nat_dec_eq(v_count_4805_, v___x_4858_);
if (v___x_4859_ == 0)
{
uint8_t v___x_4860_; 
v___x_4860_ = lean_nat_dec_lt(v___x_4858_, v_arity_4801_);
if (v___x_4860_ == 0)
{
v___y_4844_ = v___x_4853_;
v___y_4845_ = v___x_4857_;
v___y_4846_ = v___x_4852_;
v___y_4847_ = v___x_4858_;
goto v___jp_4843_;
}
else
{
lean_object* v___x_4861_; uint8_t v___x_4862_; 
v___x_4861_ = lean_unsigned_to_nat(4096u);
v___x_4862_ = lean_nat_dec_le(v_arity_4801_, v___x_4861_);
if (v___x_4862_ == 0)
{
v___y_4844_ = v___x_4853_;
v___y_4845_ = v___x_4857_;
v___y_4846_ = v___x_4852_;
v___y_4847_ = v___x_4858_;
goto v___jp_4843_;
}
else
{
lean_object* v___x_4863_; lean_object* v___x_4864_; lean_object* v___x_4865_; lean_object* v___x_4866_; 
v___x_4863_ = lean_unsigned_to_nat(4u);
v___x_4864_ = lean_nat_mul(v_arity_4801_, v___x_4863_);
v___x_4865_ = lean_unsigned_to_nat(28u);
v___x_4866_ = lean_nat_add(v___x_4864_, v___x_4865_);
lean_dec(v___x_4864_);
v___y_4844_ = v___x_4853_;
v___y_4845_ = v___x_4857_;
v___y_4846_ = v___x_4852_;
v___y_4847_ = v___x_4866_;
goto v___jp_4843_;
}
}
}
else
{
v___y_4844_ = v___x_4853_;
v___y_4845_ = v___x_4857_;
v___y_4846_ = v___x_4852_;
v___y_4847_ = v___x_4858_;
goto v___jp_4843_;
}
}
}
v___jp_4868_:
{
uint8_t v___x_4870_; 
v___x_4870_ = lean_nat_dec_le(v___x_4867_, v___y_4869_);
if (v___x_4870_ == 0)
{
lean_dec(v___y_4869_);
v___y_4850_ = v___x_4867_;
goto v___jp_4849_;
}
else
{
v___y_4850_ = v___y_4869_;
goto v___jp_4849_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss___boxed(lean_object* v_table_4881_, lean_object* v_key_4882_, lean_object* v_a_4883_, lean_object* v_b_4884_, lean_object* v_maxCount_4885_, lean_object* v_maxBytes_4886_, lean_object* v_maxWork_4887_, lean_object* v_native_4888_){
_start:
{
uint64_t v_key_boxed_4889_; uint8_t v_native_boxed_4890_; lean_object* v_res_4891_; 
v_key_boxed_4889_ = lean_unbox_uint64(v_key_4882_);
lean_dec_ref(v_key_4882_);
v_native_boxed_4890_ = lean_unbox(v_native_4888_);
v_res_4891_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss(v_table_4881_, v_key_boxed_4889_, v_a_4883_, v_b_4884_, v_maxCount_4885_, v_maxBytes_4886_, v_maxWork_4887_, v_native_boxed_4890_);
lean_dec(v_maxBytes_4886_);
lean_dec(v_maxCount_4885_);
lean_dec(v_b_4884_);
lean_dec(v_a_4883_);
return v_res_4891_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0(lean_object* v_00_u03b2_4892_, lean_object* v_m_4893_, uint64_t v_a_4894_, lean_object* v_b_4895_){
_start:
{
lean_object* v___x_4896_; 
v___x_4896_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0___redArg(v_m_4893_, v_a_4894_, v_b_4895_);
return v___x_4896_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0___boxed(lean_object* v_00_u03b2_4897_, lean_object* v_m_4898_, lean_object* v_a_4899_, lean_object* v_b_4900_){
_start:
{
uint64_t v_a_boxed_4901_; lean_object* v_res_4902_; 
v_a_boxed_4901_ = lean_unbox_uint64(v_a_4899_);
lean_dec_ref(v_a_4899_);
v_res_4902_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0(v_00_u03b2_4897_, v_m_4898_, v_a_boxed_4901_, v_b_4900_);
return v_res_4902_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0(lean_object* v_00_u03b2_4903_, uint64_t v_a_4904_, lean_object* v_x_4905_){
_start:
{
uint8_t v___x_4906_; 
v___x_4906_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0___redArg(v_a_4904_, v_x_4905_);
return v___x_4906_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0___boxed(lean_object* v_00_u03b2_4907_, lean_object* v_a_4908_, lean_object* v_x_4909_){
_start:
{
uint64_t v_a_boxed_4910_; uint8_t v_res_4911_; lean_object* v_r_4912_; 
v_a_boxed_4910_ = lean_unbox_uint64(v_a_4908_);
lean_dec_ref(v_a_4908_);
v_res_4911_ = lp_Hex_Std_DHashMap_Internal_AssocList_contains___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__0(v_00_u03b2_4907_, v_a_boxed_4910_, v_x_4909_);
lean_dec(v_x_4909_);
v_r_4912_ = lean_box(v_res_4911_);
return v_r_4912_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1(lean_object* v_00_u03b2_4913_, lean_object* v_data_4914_){
_start:
{
lean_object* v___x_4915_; 
v___x_4915_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1___redArg(v_data_4914_);
return v___x_4915_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2(lean_object* v_00_u03b2_4916_, uint64_t v_a_4917_, lean_object* v_b_4918_, lean_object* v_x_4919_){
_start:
{
lean_object* v___x_4920_; 
v___x_4920_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___redArg(v_a_4917_, v_b_4918_, v_x_4919_);
return v___x_4920_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2___boxed(lean_object* v_00_u03b2_4921_, lean_object* v_a_4922_, lean_object* v_b_4923_, lean_object* v_x_4924_){
_start:
{
uint64_t v_a_boxed_4925_; lean_object* v_res_4926_; 
v_a_boxed_4925_ = lean_unbox_uint64(v_a_4922_);
lean_dec_ref(v_a_4922_);
v_res_4926_ = lp_Hex_Std_DHashMap_Internal_AssocList_replace___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__2(v_00_u03b2_4921_, v_a_boxed_4925_, v_b_4923_, v_x_4924_);
return v_res_4926_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2(lean_object* v_00_u03b2_4927_, lean_object* v_i_4928_, lean_object* v_source_4929_, lean_object* v_target_4930_){
_start:
{
lean_object* v___x_4931_; 
v___x_4931_ = lp_Hex___private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2___redArg(v_i_4928_, v_source_4929_, v_target_4930_);
return v___x_4931_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2_spec__3(lean_object* v_00_u03b2_4932_, lean_object* v_x_4933_, lean_object* v_x_4934_){
_start:
{
lean_object* v___x_4935_; 
v___x_4935_ = lp_Hex_Std_DHashMap_Internal_AssocList_foldlM___at___00__private_Std_Data_DHashMap_Internal_Defs_0__Std_DHashMap_Internal_Raw_u2080_expand_go___at___00Std_DHashMap_Internal_Raw_u2080_expand___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00__private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss_spec__0_spec__1_spec__2_spec__3___redArg(v_x_4933_, v_x_4934_);
return v___x_4935_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0___redArg(uint64_t v_a_4936_, lean_object* v_x_4937_){
_start:
{
if (lean_obj_tag(v_x_4937_) == 0)
{
lean_object* v___x_4938_; 
v___x_4938_ = lean_box(0);
return v___x_4938_;
}
else
{
lean_object* v_key_4939_; lean_object* v_value_4940_; lean_object* v_tail_4941_; uint64_t v___x_4942_; uint8_t v___x_4943_; 
v_key_4939_ = lean_ctor_get(v_x_4937_, 0);
v_value_4940_ = lean_ctor_get(v_x_4937_, 1);
v_tail_4941_ = lean_ctor_get(v_x_4937_, 2);
v___x_4942_ = lean_unbox_uint64(v_key_4939_);
v___x_4943_ = lean_uint64_dec_eq(v___x_4942_, v_a_4936_);
if (v___x_4943_ == 0)
{
v_x_4937_ = v_tail_4941_;
goto _start;
}
else
{
lean_object* v___x_4945_; 
lean_inc(v_value_4940_);
v___x_4945_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_4945_, 0, v_value_4940_);
return v___x_4945_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0___redArg___boxed(lean_object* v_a_4946_, lean_object* v_x_4947_){
_start:
{
uint64_t v_a_boxed_4948_; lean_object* v_res_4949_; 
v_a_boxed_4948_ = lean_unbox_uint64(v_a_4946_);
lean_dec_ref(v_a_4946_);
v_res_4949_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0___redArg(v_a_boxed_4948_, v_x_4947_);
lean_dec(v_x_4947_);
return v_res_4949_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___redArg(lean_object* v_m_4950_, uint64_t v_a_4951_){
_start:
{
lean_object* v_buckets_4952_; lean_object* v___x_4953_; uint64_t v___x_4954_; uint64_t v___x_4955_; uint64_t v___x_4956_; uint64_t v___x_4957_; uint64_t v_x_4958_; uint64_t v___x_4959_; uint64_t v___x_4960_; uint64_t v___x_4961_; uint64_t v___x_4962_; uint64_t v_x_4963_; uint64_t v___x_4964_; uint64_t v___x_4965_; uint64_t v___x_4966_; uint64_t v___x_4967_; uint64_t v___x_4968_; uint64_t v_fold_4969_; uint64_t v___x_4970_; uint64_t v___x_4971_; uint64_t v___x_4972_; size_t v___x_4973_; size_t v___x_4974_; size_t v___x_4975_; size_t v___x_4976_; size_t v___x_4977_; lean_object* v___x_4978_; lean_object* v___x_4979_; 
v_buckets_4952_ = lean_ctor_get(v_m_4950_, 1);
v___x_4953_ = lean_array_get_size(v_buckets_4952_);
v___x_4954_ = 30ULL;
v___x_4955_ = lean_uint64_shift_right(v_a_4951_, v___x_4954_);
v___x_4956_ = lean_uint64_xor(v_a_4951_, v___x_4955_);
v___x_4957_ = 13787848793156543929ULL;
v_x_4958_ = lean_uint64_mul(v___x_4956_, v___x_4957_);
v___x_4959_ = 27ULL;
v___x_4960_ = lean_uint64_shift_right(v_x_4958_, v___x_4959_);
v___x_4961_ = lean_uint64_xor(v_x_4958_, v___x_4960_);
v___x_4962_ = 10723151780598845931ULL;
v_x_4963_ = lean_uint64_mul(v___x_4961_, v___x_4962_);
v___x_4964_ = 31ULL;
v___x_4965_ = lean_uint64_shift_right(v_x_4963_, v___x_4964_);
v___x_4966_ = lean_uint64_xor(v_x_4963_, v___x_4965_);
v___x_4967_ = 32ULL;
v___x_4968_ = lean_uint64_shift_right(v___x_4966_, v___x_4967_);
v_fold_4969_ = lean_uint64_xor(v___x_4966_, v___x_4968_);
v___x_4970_ = 16ULL;
v___x_4971_ = lean_uint64_shift_right(v_fold_4969_, v___x_4970_);
v___x_4972_ = lean_uint64_xor(v_fold_4969_, v___x_4971_);
v___x_4973_ = lean_uint64_to_usize(v___x_4972_);
v___x_4974_ = lean_usize_of_nat(v___x_4953_);
v___x_4975_ = ((size_t)1ULL);
v___x_4976_ = lean_usize_sub(v___x_4974_, v___x_4975_);
v___x_4977_ = lean_usize_land(v___x_4973_, v___x_4976_);
v___x_4978_ = lean_array_uget_borrowed(v_buckets_4952_, v___x_4977_);
v___x_4979_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0___redArg(v_a_4951_, v___x_4978_);
return v___x_4979_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___redArg___boxed(lean_object* v_m_4980_, lean_object* v_a_4981_){
_start:
{
uint64_t v_a_boxed_4982_; lean_object* v_res_4983_; 
v_a_boxed_4982_ = lean_unbox_uint64(v_a_4981_);
lean_dec_ref(v_a_4981_);
v_res_4983_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___redArg(v_m_4980_, v_a_boxed_4982_);
lean_dec_ref(v_m_4980_);
return v_res_4983_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_combineOwned(lean_object* v_table_4984_, uint8_t v_operation_4985_, lean_object* v_a_4986_, lean_object* v_b_4987_, lean_object* v_maxCount_4988_, lean_object* v_maxBytes_4989_, lean_object* v_maxWork_4990_, uint8_t v_native_4991_){
_start:
{
uint8_t v___x_4992_; uint8_t v___x_4993_; 
v___x_4992_ = 1;
v___x_4993_ = lp_Hex_Hex_Groebner_MonomialTable_instBEqOperation_beq(v_operation_4985_, v___x_4992_);
if (v___x_4993_ == 0)
{
lean_object* v___x_4994_; 
v___x_4994_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(v_table_4984_, v_operation_4985_, v_a_4986_, v_b_4987_, v_maxCount_4988_, v_maxBytes_4989_, v_maxWork_4990_, v_native_4991_);
return v___x_4994_;
}
else
{
lean_object* v___x_4995_; uint8_t v___x_4996_; 
v___x_4995_ = lean_unsigned_to_nat(4294967295u);
v___x_4996_ = lean_nat_dec_lt(v___x_4995_, v_a_4986_);
if (v___x_4996_ == 0)
{
uint8_t v___x_4997_; 
v___x_4997_ = lean_nat_dec_lt(v___x_4995_, v_b_4987_);
if (v___x_4997_ == 0)
{
lean_object* v_arity_4998_; uint8_t v_width_4999_; lean_object* v_exponents_5000_; lean_object* v_metadata_5001_; lean_object* v_count_5002_; lean_object* v_workspace_5003_; lean_object* v_buckets_5004_; lean_object* v_products_5005_; lean_object* v_hashBits_5006_; lean_object* v_work_5007_; lean_object* v___y_5009_; lean_object* v___y_5010_; lean_object* v___y_5011_; lean_object* v___y_5070_; lean_object* v___y_5071_; lean_object* v___y_5074_; lean_object* v___y_5075_; lean_object* v___y_5076_; lean_object* v___y_5111_; lean_object* v___y_5112_; lean_object* v___y_5113_; lean_object* v___y_5114_; uint8_t v___x_5116_; 
v_arity_4998_ = lean_ctor_get(v_table_4984_, 0);
v_width_4999_ = lean_ctor_get_uint8(v_table_4984_, sizeof(void*)*9);
v_exponents_5000_ = lean_ctor_get(v_table_4984_, 1);
v_metadata_5001_ = lean_ctor_get(v_table_4984_, 2);
v_count_5002_ = lean_ctor_get(v_table_4984_, 3);
v_workspace_5003_ = lean_ctor_get(v_table_4984_, 4);
v_buckets_5004_ = lean_ctor_get(v_table_4984_, 5);
v_products_5005_ = lean_ctor_get(v_table_4984_, 6);
lean_inc_ref(v_products_5005_);
v_hashBits_5006_ = lean_ctor_get(v_table_4984_, 7);
v_work_5007_ = lean_ctor_get(v_table_4984_, 8);
v___x_5116_ = lean_nat_dec_le(v_count_5002_, v_a_4986_);
if (v___x_5116_ == 0)
{
uint8_t v___x_5117_; 
v___x_5117_ = lean_nat_dec_le(v_count_5002_, v_b_4987_);
if (v___x_5117_ == 0)
{
lean_object* v___x_5118_; lean_object* v___x_5119_; lean_object* v___y_5121_; 
v___x_5118_ = lean_byte_array_size(v_exponents_5000_);
v___x_5119_ = lean_nat_mul(v_count_5002_, v_arity_4998_);
switch(v_width_4999_)
{
case 0:
{
lean_object* v___x_5148_; 
v___x_5148_ = lean_unsigned_to_nat(1u);
v___y_5121_ = v___x_5148_;
goto v___jp_5120_;
}
case 1:
{
lean_object* v___x_5149_; 
v___x_5149_ = lean_unsigned_to_nat(2u);
v___y_5121_ = v___x_5149_;
goto v___jp_5120_;
}
default: 
{
lean_object* v___x_5150_; 
v___x_5150_ = lean_unsigned_to_nat(4u);
v___y_5121_ = v___x_5150_;
goto v___jp_5120_;
}
}
v___jp_5120_:
{
lean_object* v___x_5122_; uint8_t v___x_5123_; 
v___x_5122_ = lean_nat_mul(v___x_5119_, v___y_5121_);
lean_dec(v___x_5119_);
v___x_5123_ = lean_nat_dec_eq(v___x_5118_, v___x_5122_);
lean_dec(v___x_5122_);
if (v___x_5123_ == 0)
{
lean_object* v___x_5124_; 
lean_dec_ref(v_products_5005_);
v___x_5124_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(v_table_4984_, v_operation_4985_, v_a_4986_, v_b_4987_, v_maxCount_4988_, v_maxBytes_4989_, v_maxWork_4990_, v_native_4991_);
return v___x_5124_;
}
else
{
lean_object* v___x_5125_; lean_object* v___x_5126_; lean_object* v___x_5127_; uint8_t v___x_5128_; 
v___x_5125_ = lean_byte_array_size(v_metadata_5001_);
v___x_5126_ = lean_unsigned_to_nat(24u);
v___x_5127_ = lean_nat_mul(v_count_5002_, v___x_5126_);
v___x_5128_ = lean_nat_dec_eq(v___x_5125_, v___x_5127_);
lean_dec(v___x_5127_);
if (v___x_5128_ == 0)
{
lean_object* v___x_5129_; 
lean_dec_ref(v_products_5005_);
v___x_5129_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(v_table_4984_, v_operation_4985_, v_a_4986_, v_b_4987_, v_maxCount_4988_, v_maxBytes_4989_, v_maxWork_4990_, v_native_4991_);
return v___x_5129_;
}
else
{
lean_object* v___x_5130_; lean_object* v_work_5131_; uint8_t v___x_5132_; 
v___x_5130_ = lean_unsigned_to_nat(1u);
v_work_5131_ = lean_nat_add(v_work_5007_, v___x_5130_);
v___x_5132_ = lean_nat_dec_lt(v_maxWork_4990_, v_work_5131_);
if (v___x_5132_ == 0)
{
lean_object* v___x_5133_; lean_object* v___x_5134_; lean_object* v___x_5135_; uint8_t v___x_5136_; 
v___x_5133_ = lean_nat_add(v___x_5118_, v___x_5125_);
v___x_5134_ = lean_byte_array_size(v_workspace_5003_);
v___x_5135_ = lean_unsigned_to_nat(0u);
v___x_5136_ = lean_nat_dec_eq(v_count_5002_, v___x_5135_);
if (v___x_5136_ == 0)
{
uint8_t v___x_5137_; 
v___x_5137_ = lean_nat_dec_lt(v___x_5135_, v_arity_4998_);
if (v___x_5137_ == 0)
{
v___y_5111_ = v___x_5134_;
v___y_5112_ = v_work_5131_;
v___y_5113_ = v___x_5133_;
v___y_5114_ = v___x_5135_;
goto v___jp_5110_;
}
else
{
lean_object* v___x_5138_; uint8_t v___x_5139_; 
v___x_5138_ = lean_unsigned_to_nat(4096u);
v___x_5139_ = lean_nat_dec_le(v_arity_4998_, v___x_5138_);
if (v___x_5139_ == 0)
{
v___y_5111_ = v___x_5134_;
v___y_5112_ = v_work_5131_;
v___y_5113_ = v___x_5133_;
v___y_5114_ = v___x_5135_;
goto v___jp_5110_;
}
else
{
lean_object* v___x_5140_; lean_object* v___x_5141_; lean_object* v___x_5142_; lean_object* v___x_5143_; 
v___x_5140_ = lean_unsigned_to_nat(4u);
v___x_5141_ = lean_nat_mul(v_arity_4998_, v___x_5140_);
v___x_5142_ = lean_unsigned_to_nat(28u);
v___x_5143_ = lean_nat_add(v___x_5141_, v___x_5142_);
lean_dec(v___x_5141_);
v___y_5111_ = v___x_5134_;
v___y_5112_ = v_work_5131_;
v___y_5113_ = v___x_5133_;
v___y_5114_ = v___x_5143_;
goto v___jp_5110_;
}
}
}
else
{
v___y_5111_ = v___x_5134_;
v___y_5112_ = v_work_5131_;
v___y_5113_ = v___x_5133_;
v___y_5114_ = v___x_5135_;
goto v___jp_5110_;
}
}
else
{
uint8_t v___x_5144_; lean_object* v___x_5145_; lean_object* v___x_5146_; lean_object* v___x_5147_; 
lean_dec(v_work_5131_);
lean_dec_ref(v_products_5005_);
v___x_5144_ = 8;
v___x_5145_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5145_, 0, v_maxWork_4990_);
lean_ctor_set_uint8(v___x_5145_, sizeof(void*)*1, v___x_5144_);
v___x_5146_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5146_, 0, v___x_5145_);
v___x_5147_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5147_, 0, v___x_5146_);
lean_ctor_set(v___x_5147_, 1, v_table_4984_);
return v___x_5147_;
}
}
}
}
}
else
{
lean_object* v___x_5151_; 
lean_dec_ref(v_products_5005_);
v___x_5151_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(v_table_4984_, v_operation_4985_, v_a_4986_, v_b_4987_, v_maxCount_4988_, v_maxBytes_4989_, v_maxWork_4990_, v_native_4991_);
return v___x_5151_;
}
}
else
{
lean_object* v___x_5152_; 
lean_dec_ref(v_products_5005_);
v___x_5152_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(v_table_4984_, v_operation_4985_, v_a_4986_, v_b_4987_, v_maxCount_4988_, v_maxBytes_4989_, v_maxWork_4990_, v_native_4991_);
return v___x_5152_;
}
v___jp_5008_:
{
uint64_t v___x_5012_; uint64_t v___x_5013_; uint64_t v___x_5014_; uint64_t v___x_5015_; uint64_t v_key_5016_; lean_object* v___x_5017_; 
v___x_5012_ = lean_uint64_of_nat(v___y_5010_);
v___x_5013_ = 32ULL;
v___x_5014_ = lean_uint64_shift_left(v___x_5012_, v___x_5013_);
v___x_5015_ = lean_uint64_of_nat(v___y_5011_);
v_key_5016_ = lean_uint64_lor(v___x_5014_, v___x_5015_);
v___x_5017_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___redArg(v_products_5005_, v_key_5016_);
if (lean_obj_tag(v___x_5017_) == 1)
{
lean_object* v_val_5018_; lean_object* v___x_5020_; uint8_t v_isShared_5021_; uint8_t v_isSharedCheck_5051_; 
lean_dec(v_maxWork_4990_);
v_val_5018_ = lean_ctor_get(v___x_5017_, 0);
v_isSharedCheck_5051_ = !lean_is_exclusive(v___x_5017_);
if (v_isSharedCheck_5051_ == 0)
{
v___x_5020_ = v___x_5017_;
v_isShared_5021_ = v_isSharedCheck_5051_;
goto v_resetjp_5019_;
}
else
{
lean_inc(v_val_5018_);
lean_dec(v___x_5017_);
v___x_5020_ = lean_box(0);
v_isShared_5021_ = v_isSharedCheck_5051_;
goto v_resetjp_5019_;
}
v_resetjp_5019_:
{
uint32_t v___x_5022_; lean_object* v___x_5023_; uint8_t v___x_5024_; 
v___x_5022_ = lean_unbox_uint32(v_val_5018_);
lean_dec(v_val_5018_);
v___x_5023_ = lean_uint32_to_nat(v___x_5022_);
v___x_5024_ = lean_nat_dec_le(v_count_5002_, v___x_5023_);
if (v___x_5024_ == 0)
{
lean_object* v___x_5026_; uint8_t v_isShared_5027_; uint8_t v_isSharedCheck_5035_; 
lean_inc(v_hashBits_5006_);
lean_inc_ref(v_buckets_5004_);
lean_inc_ref(v_workspace_5003_);
lean_inc(v_count_5002_);
lean_inc_ref(v_metadata_5001_);
lean_inc_ref(v_exponents_5000_);
lean_inc(v_arity_4998_);
v_isSharedCheck_5035_ = !lean_is_exclusive(v_table_4984_);
if (v_isSharedCheck_5035_ == 0)
{
lean_object* v_unused_5036_; lean_object* v_unused_5037_; lean_object* v_unused_5038_; lean_object* v_unused_5039_; lean_object* v_unused_5040_; lean_object* v_unused_5041_; lean_object* v_unused_5042_; lean_object* v_unused_5043_; lean_object* v_unused_5044_; 
v_unused_5036_ = lean_ctor_get(v_table_4984_, 8);
lean_dec(v_unused_5036_);
v_unused_5037_ = lean_ctor_get(v_table_4984_, 7);
lean_dec(v_unused_5037_);
v_unused_5038_ = lean_ctor_get(v_table_4984_, 6);
lean_dec(v_unused_5038_);
v_unused_5039_ = lean_ctor_get(v_table_4984_, 5);
lean_dec(v_unused_5039_);
v_unused_5040_ = lean_ctor_get(v_table_4984_, 4);
lean_dec(v_unused_5040_);
v_unused_5041_ = lean_ctor_get(v_table_4984_, 3);
lean_dec(v_unused_5041_);
v_unused_5042_ = lean_ctor_get(v_table_4984_, 2);
lean_dec(v_unused_5042_);
v_unused_5043_ = lean_ctor_get(v_table_4984_, 1);
lean_dec(v_unused_5043_);
v_unused_5044_ = lean_ctor_get(v_table_4984_, 0);
lean_dec(v_unused_5044_);
v___x_5026_ = v_table_4984_;
v_isShared_5027_ = v_isSharedCheck_5035_;
goto v_resetjp_5025_;
}
else
{
lean_dec(v_table_4984_);
v___x_5026_ = lean_box(0);
v_isShared_5027_ = v_isSharedCheck_5035_;
goto v_resetjp_5025_;
}
v_resetjp_5025_:
{
lean_object* v___x_5029_; 
if (v_isShared_5021_ == 0)
{
lean_ctor_set(v___x_5020_, 0, v___x_5023_);
v___x_5029_ = v___x_5020_;
goto v_reusejp_5028_;
}
else
{
lean_object* v_reuseFailAlloc_5034_; 
v_reuseFailAlloc_5034_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5034_, 0, v___x_5023_);
v___x_5029_ = v_reuseFailAlloc_5034_;
goto v_reusejp_5028_;
}
v_reusejp_5028_:
{
lean_object* v___x_5031_; 
if (v_isShared_5027_ == 0)
{
lean_ctor_set(v___x_5026_, 8, v___y_5009_);
v___x_5031_ = v___x_5026_;
goto v_reusejp_5030_;
}
else
{
lean_object* v_reuseFailAlloc_5033_; 
v_reuseFailAlloc_5033_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_reuseFailAlloc_5033_, 0, v_arity_4998_);
lean_ctor_set(v_reuseFailAlloc_5033_, 1, v_exponents_5000_);
lean_ctor_set(v_reuseFailAlloc_5033_, 2, v_metadata_5001_);
lean_ctor_set(v_reuseFailAlloc_5033_, 3, v_count_5002_);
lean_ctor_set(v_reuseFailAlloc_5033_, 4, v_workspace_5003_);
lean_ctor_set(v_reuseFailAlloc_5033_, 5, v_buckets_5004_);
lean_ctor_set(v_reuseFailAlloc_5033_, 6, v_products_5005_);
lean_ctor_set(v_reuseFailAlloc_5033_, 7, v_hashBits_5006_);
lean_ctor_set(v_reuseFailAlloc_5033_, 8, v___y_5009_);
lean_ctor_set_uint8(v_reuseFailAlloc_5033_, sizeof(void*)*9, v_width_4999_);
v___x_5031_ = v_reuseFailAlloc_5033_;
goto v_reusejp_5030_;
}
v_reusejp_5030_:
{
lean_object* v___x_5032_; 
v___x_5032_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5032_, 0, v___x_5029_);
lean_ctor_set(v___x_5032_, 1, v___x_5031_);
return v___x_5032_;
}
}
}
}
else
{
uint8_t v___x_5045_; lean_object* v___x_5046_; lean_object* v___x_5048_; 
lean_dec(v___x_5023_);
lean_dec_ref(v_products_5005_);
v___x_5045_ = 5;
v___x_5046_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5046_, 0, v___y_5009_);
lean_ctor_set_uint8(v___x_5046_, sizeof(void*)*1, v___x_5045_);
if (v_isShared_5021_ == 0)
{
lean_ctor_set_tag(v___x_5020_, 0);
lean_ctor_set(v___x_5020_, 0, v___x_5046_);
v___x_5048_ = v___x_5020_;
goto v_reusejp_5047_;
}
else
{
lean_object* v_reuseFailAlloc_5050_; 
v_reuseFailAlloc_5050_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5050_, 0, v___x_5046_);
v___x_5048_ = v_reuseFailAlloc_5050_;
goto v_reusejp_5047_;
}
v_reusejp_5047_:
{
lean_object* v___x_5049_; 
v___x_5049_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5049_, 0, v___x_5048_);
lean_ctor_set(v___x_5049_, 1, v_table_4984_);
return v___x_5049_;
}
}
}
}
else
{
lean_object* v___x_5053_; uint8_t v_isShared_5054_; uint8_t v_isSharedCheck_5059_; 
lean_inc(v_hashBits_5006_);
lean_inc_ref(v_buckets_5004_);
lean_inc_ref(v_workspace_5003_);
lean_inc(v_count_5002_);
lean_inc_ref(v_metadata_5001_);
lean_inc_ref(v_exponents_5000_);
lean_inc(v_arity_4998_);
lean_dec(v___x_5017_);
v_isSharedCheck_5059_ = !lean_is_exclusive(v_table_4984_);
if (v_isSharedCheck_5059_ == 0)
{
lean_object* v_unused_5060_; lean_object* v_unused_5061_; lean_object* v_unused_5062_; lean_object* v_unused_5063_; lean_object* v_unused_5064_; lean_object* v_unused_5065_; lean_object* v_unused_5066_; lean_object* v_unused_5067_; lean_object* v_unused_5068_; 
v_unused_5060_ = lean_ctor_get(v_table_4984_, 8);
lean_dec(v_unused_5060_);
v_unused_5061_ = lean_ctor_get(v_table_4984_, 7);
lean_dec(v_unused_5061_);
v_unused_5062_ = lean_ctor_get(v_table_4984_, 6);
lean_dec(v_unused_5062_);
v_unused_5063_ = lean_ctor_get(v_table_4984_, 5);
lean_dec(v_unused_5063_);
v_unused_5064_ = lean_ctor_get(v_table_4984_, 4);
lean_dec(v_unused_5064_);
v_unused_5065_ = lean_ctor_get(v_table_4984_, 3);
lean_dec(v_unused_5065_);
v_unused_5066_ = lean_ctor_get(v_table_4984_, 2);
lean_dec(v_unused_5066_);
v_unused_5067_ = lean_ctor_get(v_table_4984_, 1);
lean_dec(v_unused_5067_);
v_unused_5068_ = lean_ctor_get(v_table_4984_, 0);
lean_dec(v_unused_5068_);
v___x_5053_ = v_table_4984_;
v_isShared_5054_ = v_isSharedCheck_5059_;
goto v_resetjp_5052_;
}
else
{
lean_dec(v_table_4984_);
v___x_5053_ = lean_box(0);
v_isShared_5054_ = v_isSharedCheck_5059_;
goto v_resetjp_5052_;
}
v_resetjp_5052_:
{
lean_object* v___x_5056_; 
if (v_isShared_5054_ == 0)
{
lean_ctor_set(v___x_5053_, 8, v___y_5009_);
v___x_5056_ = v___x_5053_;
goto v_reusejp_5055_;
}
else
{
lean_object* v_reuseFailAlloc_5058_; 
v_reuseFailAlloc_5058_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_reuseFailAlloc_5058_, 0, v_arity_4998_);
lean_ctor_set(v_reuseFailAlloc_5058_, 1, v_exponents_5000_);
lean_ctor_set(v_reuseFailAlloc_5058_, 2, v_metadata_5001_);
lean_ctor_set(v_reuseFailAlloc_5058_, 3, v_count_5002_);
lean_ctor_set(v_reuseFailAlloc_5058_, 4, v_workspace_5003_);
lean_ctor_set(v_reuseFailAlloc_5058_, 5, v_buckets_5004_);
lean_ctor_set(v_reuseFailAlloc_5058_, 6, v_products_5005_);
lean_ctor_set(v_reuseFailAlloc_5058_, 7, v_hashBits_5006_);
lean_ctor_set(v_reuseFailAlloc_5058_, 8, v___y_5009_);
lean_ctor_set_uint8(v_reuseFailAlloc_5058_, sizeof(void*)*9, v_width_4999_);
v___x_5056_ = v_reuseFailAlloc_5058_;
goto v_reusejp_5055_;
}
v_reusejp_5055_:
{
lean_object* v___x_5057_; 
v___x_5057_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss(v___x_5056_, v_key_5016_, v_a_4986_, v_b_4987_, v_maxCount_4988_, v_maxBytes_4989_, v_maxWork_4990_, v_native_4991_);
return v___x_5057_;
}
}
}
}
v___jp_5069_:
{
uint8_t v___x_5072_; 
v___x_5072_ = lean_nat_dec_le(v_a_4986_, v_b_4987_);
if (v___x_5072_ == 0)
{
v___y_5009_ = v___y_5070_;
v___y_5010_ = v___y_5071_;
v___y_5011_ = v_a_4986_;
goto v___jp_5008_;
}
else
{
v___y_5009_ = v___y_5070_;
v___y_5010_ = v___y_5071_;
v___y_5011_ = v_b_4987_;
goto v___jp_5008_;
}
}
v___jp_5073_:
{
lean_object* v_size_5077_; lean_object* v___x_5078_; lean_object* v___x_5079_; lean_object* v___x_5080_; lean_object* v___x_5081_; uint8_t v___x_5082_; 
v_size_5077_ = lean_ctor_get(v_products_5005_, 0);
v___x_5078_ = lean_nat_add(v___y_5075_, v___y_5076_);
lean_dec(v___y_5076_);
lean_dec(v___y_5075_);
v___x_5079_ = lean_unsigned_to_nat(12u);
v___x_5080_ = lean_nat_mul(v___x_5079_, v_size_5077_);
v___x_5081_ = lean_nat_add(v___x_5078_, v___x_5080_);
lean_dec(v___x_5080_);
lean_dec(v___x_5078_);
v___x_5082_ = lean_nat_dec_lt(v_maxBytes_4989_, v___x_5081_);
if (v___x_5082_ == 0)
{
lean_object* v___x_5083_; uint8_t v___x_5084_; 
v___x_5083_ = lean_obj_once(&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12, &lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12_once, _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12);
v___x_5084_ = lean_nat_dec_le(v___x_5083_, v___x_5081_);
lean_dec(v___x_5081_);
if (v___x_5084_ == 0)
{
uint8_t v___x_5085_; 
v___x_5085_ = lean_nat_dec_le(v_a_4986_, v_b_4987_);
if (v___x_5085_ == 0)
{
v___y_5070_ = v___y_5074_;
v___y_5071_ = v_b_4987_;
goto v___jp_5069_;
}
else
{
v___y_5070_ = v___y_5074_;
v___y_5071_ = v_a_4986_;
goto v___jp_5069_;
}
}
else
{
lean_object* v___x_5087_; uint8_t v_isShared_5088_; uint8_t v_isSharedCheck_5095_; 
lean_dec(v_maxWork_4990_);
v_isSharedCheck_5095_ = !lean_is_exclusive(v_products_5005_);
if (v_isSharedCheck_5095_ == 0)
{
lean_object* v_unused_5096_; lean_object* v_unused_5097_; 
v_unused_5096_ = lean_ctor_get(v_products_5005_, 1);
lean_dec(v_unused_5096_);
v_unused_5097_ = lean_ctor_get(v_products_5005_, 0);
lean_dec(v_unused_5097_);
v___x_5087_ = v_products_5005_;
v_isShared_5088_ = v_isSharedCheck_5095_;
goto v_resetjp_5086_;
}
else
{
lean_dec(v_products_5005_);
v___x_5087_ = lean_box(0);
v_isShared_5088_ = v_isSharedCheck_5095_;
goto v_resetjp_5086_;
}
v_resetjp_5086_:
{
uint8_t v___x_5089_; lean_object* v___x_5090_; lean_object* v___x_5091_; lean_object* v___x_5093_; 
v___x_5089_ = 4;
v___x_5090_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5090_, 0, v___y_5074_);
lean_ctor_set_uint8(v___x_5090_, sizeof(void*)*1, v___x_5089_);
v___x_5091_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5091_, 0, v___x_5090_);
if (v_isShared_5088_ == 0)
{
lean_ctor_set(v___x_5087_, 1, v_table_4984_);
lean_ctor_set(v___x_5087_, 0, v___x_5091_);
v___x_5093_ = v___x_5087_;
goto v_reusejp_5092_;
}
else
{
lean_object* v_reuseFailAlloc_5094_; 
v_reuseFailAlloc_5094_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5094_, 0, v___x_5091_);
lean_ctor_set(v_reuseFailAlloc_5094_, 1, v_table_4984_);
v___x_5093_ = v_reuseFailAlloc_5094_;
goto v_reusejp_5092_;
}
v_reusejp_5092_:
{
return v___x_5093_;
}
}
}
}
else
{
lean_object* v___x_5099_; uint8_t v_isShared_5100_; uint8_t v_isSharedCheck_5107_; 
lean_dec(v___x_5081_);
lean_dec(v_maxWork_4990_);
v_isSharedCheck_5107_ = !lean_is_exclusive(v_products_5005_);
if (v_isSharedCheck_5107_ == 0)
{
lean_object* v_unused_5108_; lean_object* v_unused_5109_; 
v_unused_5108_ = lean_ctor_get(v_products_5005_, 1);
lean_dec(v_unused_5108_);
v_unused_5109_ = lean_ctor_get(v_products_5005_, 0);
lean_dec(v_unused_5109_);
v___x_5099_ = v_products_5005_;
v_isShared_5100_ = v_isSharedCheck_5107_;
goto v_resetjp_5098_;
}
else
{
lean_dec(v_products_5005_);
v___x_5099_ = lean_box(0);
v_isShared_5100_ = v_isSharedCheck_5107_;
goto v_resetjp_5098_;
}
v_resetjp_5098_:
{
uint8_t v___x_5101_; lean_object* v___x_5102_; lean_object* v___x_5103_; lean_object* v___x_5105_; 
v___x_5101_ = 7;
v___x_5102_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5102_, 0, v___y_5074_);
lean_ctor_set_uint8(v___x_5102_, sizeof(void*)*1, v___x_5101_);
v___x_5103_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5103_, 0, v___x_5102_);
if (v_isShared_5100_ == 0)
{
lean_ctor_set(v___x_5099_, 1, v_table_4984_);
lean_ctor_set(v___x_5099_, 0, v___x_5103_);
v___x_5105_ = v___x_5099_;
goto v_reusejp_5104_;
}
else
{
lean_object* v_reuseFailAlloc_5106_; 
v_reuseFailAlloc_5106_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5106_, 0, v___x_5103_);
lean_ctor_set(v_reuseFailAlloc_5106_, 1, v_table_4984_);
v___x_5105_ = v_reuseFailAlloc_5106_;
goto v_reusejp_5104_;
}
v_reusejp_5104_:
{
return v___x_5105_;
}
}
}
}
v___jp_5110_:
{
uint8_t v___x_5115_; 
v___x_5115_ = lean_nat_dec_le(v___y_5111_, v___y_5114_);
if (v___x_5115_ == 0)
{
lean_dec(v___y_5114_);
v___y_5074_ = v___y_5112_;
v___y_5075_ = v___y_5113_;
v___y_5076_ = v___y_5111_;
goto v___jp_5073_;
}
else
{
lean_dec(v___y_5111_);
v___y_5074_ = v___y_5112_;
v___y_5075_ = v___y_5113_;
v___y_5076_ = v___y_5114_;
goto v___jp_5073_;
}
}
}
else
{
lean_object* v___x_5153_; 
v___x_5153_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(v_table_4984_, v_operation_4985_, v_a_4986_, v_b_4987_, v_maxCount_4988_, v_maxBytes_4989_, v_maxWork_4990_, v_native_4991_);
return v___x_5153_;
}
}
else
{
lean_object* v___x_5154_; 
v___x_5154_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_combineFresh(v_table_4984_, v_operation_4985_, v_a_4986_, v_b_4987_, v_maxCount_4988_, v_maxBytes_4989_, v_maxWork_4990_, v_native_4991_);
return v___x_5154_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_combineOwned___boxed(lean_object* v_table_5155_, lean_object* v_operation_5156_, lean_object* v_a_5157_, lean_object* v_b_5158_, lean_object* v_maxCount_5159_, lean_object* v_maxBytes_5160_, lean_object* v_maxWork_5161_, lean_object* v_native_5162_){
_start:
{
uint8_t v_operation_boxed_5163_; uint8_t v_native_boxed_5164_; lean_object* v_res_5165_; 
v_operation_boxed_5163_ = lean_unbox(v_operation_5156_);
v_native_boxed_5164_ = lean_unbox(v_native_5162_);
v_res_5165_ = lp_Hex_Hex_Groebner_MonomialTable_combineOwned(v_table_5155_, v_operation_boxed_5163_, v_a_5157_, v_b_5158_, v_maxCount_5159_, v_maxBytes_5160_, v_maxWork_5161_, v_native_boxed_5164_);
lean_dec(v_maxBytes_5160_);
lean_dec(v_maxCount_5159_);
lean_dec(v_b_5158_);
lean_dec(v_a_5157_);
return v_res_5165_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0(lean_object* v_00_u03b2_5166_, lean_object* v_m_5167_, uint64_t v_a_5168_){
_start:
{
lean_object* v___x_5169_; 
v___x_5169_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___redArg(v_m_5167_, v_a_5168_);
return v___x_5169_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___boxed(lean_object* v_00_u03b2_5170_, lean_object* v_m_5171_, lean_object* v_a_5172_){
_start:
{
uint64_t v_a_boxed_5173_; lean_object* v_res_5174_; 
v_a_boxed_5173_ = lean_unbox_uint64(v_a_5172_);
lean_dec_ref(v_a_5172_);
v_res_5174_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0(v_00_u03b2_5170_, v_m_5171_, v_a_boxed_5173_);
lean_dec_ref(v_m_5171_);
return v_res_5174_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0(lean_object* v_00_u03b2_5175_, uint64_t v_a_5176_, lean_object* v_x_5177_){
_start:
{
lean_object* v___x_5178_; 
v___x_5178_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0___redArg(v_a_5176_, v_x_5177_);
return v___x_5178_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0___boxed(lean_object* v_00_u03b2_5179_, lean_object* v_a_5180_, lean_object* v_x_5181_){
_start:
{
uint64_t v_a_boxed_5182_; lean_object* v_res_5183_; 
v_a_boxed_5182_ = lean_unbox_uint64(v_a_5180_);
lean_dec_ref(v_a_5180_);
v_res_5183_ = lp_Hex_Std_DHashMap_Internal_AssocList_get_x3f___at___00Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0_spec__0(v_00_u03b2_5179_, v_a_boxed_5182_, v_x_5181_);
lean_dec(v_x_5181_);
return v_res_5183_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0___redArg(lean_object* v_multiplier_5184_, lean_object* v_maxCount_5185_, lean_object* v_maxBytes_5186_, lean_object* v_maxWork_5187_, uint8_t v_native_5188_, lean_object* v_support_5189_, lean_object* v_range_5190_, lean_object* v_b_5191_, lean_object* v_i_5192_){
_start:
{
lean_object* v_stop_5193_; lean_object* v_step_5194_; lean_object* v_a_5196_; uint8_t v___x_5199_; 
v_stop_5193_ = lean_ctor_get(v_range_5190_, 1);
v_step_5194_ = lean_ctor_get(v_range_5190_, 2);
v___x_5199_ = lean_nat_dec_lt(v_i_5192_, v_stop_5193_);
if (v___x_5199_ == 0)
{
lean_dec(v_i_5192_);
lean_dec(v_maxWork_5187_);
lean_dec(v_multiplier_5184_);
return v_b_5191_;
}
else
{
lean_object* v_snd_5200_; lean_object* v___x_5202_; uint8_t v_isShared_5203_; uint8_t v_isSharedCheck_5477_; 
v_snd_5200_ = lean_ctor_get(v_b_5191_, 1);
v_isSharedCheck_5477_ = !lean_is_exclusive(v_b_5191_);
if (v_isSharedCheck_5477_ == 0)
{
lean_object* v_unused_5478_; 
v_unused_5478_ = lean_ctor_get(v_b_5191_, 0);
lean_dec(v_unused_5478_);
v___x_5202_ = v_b_5191_;
v_isShared_5203_ = v_isSharedCheck_5477_;
goto v_resetjp_5201_;
}
else
{
lean_inc(v_snd_5200_);
lean_dec(v_b_5191_);
v___x_5202_ = lean_box(0);
v_isShared_5203_ = v_isSharedCheck_5477_;
goto v_resetjp_5201_;
}
v_resetjp_5201_:
{
lean_object* v_snd_5204_; lean_object* v_fst_5205_; lean_object* v___x_5207_; uint8_t v_isShared_5208_; uint8_t v_isSharedCheck_5476_; 
v_snd_5204_ = lean_ctor_get(v_snd_5200_, 1);
v_fst_5205_ = lean_ctor_get(v_snd_5200_, 0);
v_isSharedCheck_5476_ = !lean_is_exclusive(v_snd_5200_);
if (v_isSharedCheck_5476_ == 0)
{
v___x_5207_ = v_snd_5200_;
v_isShared_5208_ = v_isSharedCheck_5476_;
goto v_resetjp_5206_;
}
else
{
lean_inc(v_snd_5204_);
lean_inc(v_fst_5205_);
lean_dec(v_snd_5200_);
v___x_5207_ = lean_box(0);
v_isShared_5208_ = v_isSharedCheck_5476_;
goto v_resetjp_5206_;
}
v_resetjp_5206_:
{
lean_object* v_fst_5209_; lean_object* v_snd_5210_; lean_object* v___x_5212_; uint8_t v_isShared_5213_; uint8_t v_isSharedCheck_5475_; 
v_fst_5209_ = lean_ctor_get(v_snd_5204_, 0);
v_snd_5210_ = lean_ctor_get(v_snd_5204_, 1);
v_isSharedCheck_5475_ = !lean_is_exclusive(v_snd_5204_);
if (v_isSharedCheck_5475_ == 0)
{
v___x_5212_ = v_snd_5204_;
v_isShared_5213_ = v_isSharedCheck_5475_;
goto v_resetjp_5211_;
}
else
{
lean_inc(v_snd_5210_);
lean_inc(v_fst_5209_);
lean_dec(v_snd_5204_);
v___x_5212_ = lean_box(0);
v_isShared_5213_ = v_isSharedCheck_5475_;
goto v_resetjp_5211_;
}
v_resetjp_5211_:
{
lean_object* v___x_5214_; lean_object* v___x_5215_; lean_object* v___y_5217_; lean_object* v___y_5218_; lean_object* v___y_5219_; lean_object* v___y_5220_; lean_object* v___y_5221_; lean_object* v___y_5222_; lean_object* v___y_5223_; lean_object* v___y_5224_; lean_object* v___y_5225_; lean_object* v___y_5226_; uint8_t v___y_5227_; lean_object* v___y_5228_; lean_object* v___y_5229_; lean_object* v___y_5344_; lean_object* v___y_5345_; lean_object* v___y_5346_; lean_object* v___y_5347_; lean_object* v___y_5348_; lean_object* v___y_5349_; lean_object* v___y_5350_; lean_object* v___y_5351_; lean_object* v___y_5352_; lean_object* v___y_5353_; uint8_t v___y_5354_; lean_object* v___y_5355_; uint64_t v___y_5358_; uint64_t v___y_5392_; uint8_t v___y_5393_; uint8_t v___x_5398_; lean_object* v___x_5399_; lean_object* v_offset_5400_; uint64_t v___y_5402_; uint8_t v___y_5403_; uint64_t v___y_5416_; uint8_t v___y_5417_; uint8_t v___y_5430_; uint8_t v___y_5439_; lean_object* v___x_5469_; lean_object* v___x_5470_; uint8_t v___x_5471_; 
v___x_5214_ = lean_unsigned_to_nat(1u);
v___x_5215_ = lean_box(0);
v___x_5398_ = 0;
v___x_5399_ = lean_unsigned_to_nat(4u);
v_offset_5400_ = lean_nat_mul(v_i_5192_, v___x_5399_);
v___x_5469_ = lean_nat_add(v_offset_5400_, v___x_5399_);
v___x_5470_ = lean_byte_array_size(v_support_5189_);
v___x_5471_ = lean_nat_dec_le(v___x_5469_, v___x_5470_);
if (v___x_5471_ == 0)
{
lean_dec(v___x_5469_);
v___y_5439_ = v___x_5471_;
goto v___jp_5438_;
}
else
{
size_t v___x_5472_; lean_object* v___x_5473_; uint8_t v___x_5474_; 
v___x_5472_ = lean_usize_of_nat(v___x_5469_);
v___x_5473_ = lean_usize_to_nat(v___x_5472_);
v___x_5474_ = lean_nat_dec_eq(v___x_5473_, v___x_5469_);
lean_dec(v___x_5469_);
lean_dec(v___x_5473_);
v___y_5439_ = v___x_5474_;
goto v___jp_5438_;
}
v___jp_5216_:
{
uint64_t v___x_5230_; uint64_t v___x_5231_; uint64_t v___x_5232_; uint64_t v___x_5233_; uint64_t v___x_5234_; lean_object* v___x_5235_; 
v___x_5230_ = lean_uint64_of_nat(v___y_5228_);
lean_dec(v___y_5228_);
v___x_5231_ = 32ULL;
v___x_5232_ = lean_uint64_shift_left(v___x_5230_, v___x_5231_);
v___x_5233_ = lean_uint64_of_nat(v___y_5229_);
lean_dec(v___y_5229_);
v___x_5234_ = lean_uint64_lor(v___x_5232_, v___x_5233_);
v___x_5235_ = lp_Hex_Std_DHashMap_Internal_Raw_u2080_Const_get_x3f___at___00Hex_Groebner_MonomialTable_combineOwned_spec__0___redArg(v___y_5224_, v___x_5234_);
if (lean_obj_tag(v___x_5235_) == 1)
{
lean_object* v_val_5236_; lean_object* v___x_5238_; uint8_t v_isShared_5239_; uint8_t v_isSharedCheck_5285_; 
lean_dec(v___y_5222_);
v_val_5236_ = lean_ctor_get(v___x_5235_, 0);
v_isSharedCheck_5285_ = !lean_is_exclusive(v___x_5235_);
if (v_isSharedCheck_5285_ == 0)
{
v___x_5238_ = v___x_5235_;
v_isShared_5239_ = v_isSharedCheck_5285_;
goto v_resetjp_5237_;
}
else
{
lean_inc(v_val_5236_);
lean_dec(v___x_5235_);
v___x_5238_ = lean_box(0);
v_isShared_5239_ = v_isSharedCheck_5285_;
goto v_resetjp_5237_;
}
v_resetjp_5237_:
{
uint32_t v___x_5240_; lean_object* v___x_5241_; uint8_t v___x_5242_; 
v___x_5240_ = lean_unbox_uint32(v_val_5236_);
v___x_5241_ = lean_uint32_to_nat(v___x_5240_);
v___x_5242_ = lean_nat_dec_le(v___y_5223_, v___x_5241_);
lean_dec(v___x_5241_);
if (v___x_5242_ == 0)
{
uint32_t v___x_5243_; uint64_t v___x_5244_; uint8_t v___x_5245_; lean_object* v_data_5246_; uint64_t v___x_5247_; uint64_t v___x_5248_; uint8_t v___x_5249_; lean_object* v___x_5250_; uint64_t v___x_5251_; uint64_t v___x_5252_; uint8_t v___x_5253_; lean_object* v___x_5254_; uint64_t v___x_5255_; uint64_t v___x_5256_; uint8_t v___x_5257_; lean_object* v___x_5258_; lean_object* v___x_5260_; 
lean_del_object(v___x_5238_);
lean_dec(v___y_5226_);
lean_dec_ref(v___y_5225_);
lean_dec_ref(v___y_5224_);
lean_dec(v___y_5223_);
lean_dec_ref(v___y_5221_);
lean_dec_ref(v___y_5220_);
lean_dec_ref(v___y_5219_);
lean_dec(v___y_5218_);
lean_dec(v_fst_5209_);
v___x_5243_ = lean_unbox_uint32(v_val_5236_);
lean_dec(v_val_5236_);
v___x_5244_ = lean_uint32_to_uint64(v___x_5243_);
v___x_5245_ = lean_uint64_to_uint8(v___x_5244_);
v_data_5246_ = lean_byte_array_push(v_snd_5210_, v___x_5245_);
v___x_5247_ = 8ULL;
v___x_5248_ = lean_uint64_shift_right(v___x_5244_, v___x_5247_);
v___x_5249_ = lean_uint64_to_uint8(v___x_5248_);
v___x_5250_ = lean_byte_array_push(v_data_5246_, v___x_5249_);
v___x_5251_ = 16ULL;
v___x_5252_ = lean_uint64_shift_right(v___x_5244_, v___x_5251_);
v___x_5253_ = lean_uint64_to_uint8(v___x_5252_);
v___x_5254_ = lean_byte_array_push(v___x_5250_, v___x_5253_);
v___x_5255_ = 24ULL;
v___x_5256_ = lean_uint64_shift_right(v___x_5244_, v___x_5255_);
v___x_5257_ = lean_uint64_to_uint8(v___x_5256_);
v___x_5258_ = lean_byte_array_push(v___x_5254_, v___x_5257_);
if (v_isShared_5213_ == 0)
{
lean_ctor_set(v___x_5212_, 1, v___x_5258_);
lean_ctor_set(v___x_5212_, 0, v___y_5217_);
v___x_5260_ = v___x_5212_;
goto v_reusejp_5259_;
}
else
{
lean_object* v_reuseFailAlloc_5267_; 
v_reuseFailAlloc_5267_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5267_, 0, v___y_5217_);
lean_ctor_set(v_reuseFailAlloc_5267_, 1, v___x_5258_);
v___x_5260_ = v_reuseFailAlloc_5267_;
goto v_reusejp_5259_;
}
v_reusejp_5259_:
{
lean_object* v___x_5262_; 
if (v_isShared_5208_ == 0)
{
lean_ctor_set(v___x_5207_, 1, v___x_5260_);
v___x_5262_ = v___x_5207_;
goto v_reusejp_5261_;
}
else
{
lean_object* v_reuseFailAlloc_5266_; 
v_reuseFailAlloc_5266_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5266_, 0, v_fst_5205_);
lean_ctor_set(v_reuseFailAlloc_5266_, 1, v___x_5260_);
v___x_5262_ = v_reuseFailAlloc_5266_;
goto v_reusejp_5261_;
}
v_reusejp_5261_:
{
lean_object* v___x_5264_; 
if (v_isShared_5203_ == 0)
{
lean_ctor_set(v___x_5202_, 1, v___x_5262_);
lean_ctor_set(v___x_5202_, 0, v___x_5215_);
v___x_5264_ = v___x_5202_;
goto v_reusejp_5263_;
}
else
{
lean_object* v_reuseFailAlloc_5265_; 
v_reuseFailAlloc_5265_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5265_, 0, v___x_5215_);
lean_ctor_set(v_reuseFailAlloc_5265_, 1, v___x_5262_);
v___x_5264_ = v_reuseFailAlloc_5265_;
goto v_reusejp_5263_;
}
v_reusejp_5263_:
{
v_a_5196_ = v___x_5264_;
goto v___jp_5195_;
}
}
}
}
else
{
uint8_t v___x_5268_; lean_object* v___x_5269_; lean_object* v___x_5270_; lean_object* v___x_5271_; lean_object* v___x_5272_; lean_object* v___x_5274_; 
lean_dec(v_val_5236_);
lean_dec(v_i_5192_);
lean_dec(v_maxWork_5187_);
lean_dec(v_multiplier_5184_);
v___x_5268_ = 5;
v___x_5269_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5269_, 0, v___y_5217_);
lean_ctor_set_uint8(v___x_5269_, sizeof(void*)*1, v___x_5268_);
v___x_5270_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5270_, 0, v___x_5269_);
lean_inc(v_fst_5209_);
v___x_5271_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_5271_, 0, v___y_5226_);
lean_ctor_set(v___x_5271_, 1, v___y_5220_);
lean_ctor_set(v___x_5271_, 2, v___y_5219_);
lean_ctor_set(v___x_5271_, 3, v___y_5223_);
lean_ctor_set(v___x_5271_, 4, v___y_5225_);
lean_ctor_set(v___x_5271_, 5, v___y_5221_);
lean_ctor_set(v___x_5271_, 6, v___y_5224_);
lean_ctor_set(v___x_5271_, 7, v___y_5218_);
lean_ctor_set(v___x_5271_, 8, v_fst_5209_);
lean_ctor_set_uint8(v___x_5271_, sizeof(void*)*9, v___y_5227_);
v___x_5272_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5272_, 0, v___x_5270_);
lean_ctor_set(v___x_5272_, 1, v___x_5271_);
if (v_isShared_5239_ == 0)
{
lean_ctor_set(v___x_5238_, 0, v___x_5272_);
v___x_5274_ = v___x_5238_;
goto v_reusejp_5273_;
}
else
{
lean_object* v_reuseFailAlloc_5284_; 
v_reuseFailAlloc_5284_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5284_, 0, v___x_5272_);
v___x_5274_ = v_reuseFailAlloc_5284_;
goto v_reusejp_5273_;
}
v_reusejp_5273_:
{
lean_object* v___x_5276_; 
if (v_isShared_5213_ == 0)
{
v___x_5276_ = v___x_5212_;
goto v_reusejp_5275_;
}
else
{
lean_object* v_reuseFailAlloc_5283_; 
v_reuseFailAlloc_5283_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5283_, 0, v_fst_5209_);
lean_ctor_set(v_reuseFailAlloc_5283_, 1, v_snd_5210_);
v___x_5276_ = v_reuseFailAlloc_5283_;
goto v_reusejp_5275_;
}
v_reusejp_5275_:
{
lean_object* v___x_5278_; 
if (v_isShared_5208_ == 0)
{
lean_ctor_set(v___x_5207_, 1, v___x_5276_);
v___x_5278_ = v___x_5207_;
goto v_reusejp_5277_;
}
else
{
lean_object* v_reuseFailAlloc_5282_; 
v_reuseFailAlloc_5282_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5282_, 0, v_fst_5205_);
lean_ctor_set(v_reuseFailAlloc_5282_, 1, v___x_5276_);
v___x_5278_ = v_reuseFailAlloc_5282_;
goto v_reusejp_5277_;
}
v_reusejp_5277_:
{
lean_object* v___x_5280_; 
if (v_isShared_5203_ == 0)
{
lean_ctor_set(v___x_5202_, 1, v___x_5278_);
lean_ctor_set(v___x_5202_, 0, v___x_5274_);
v___x_5280_ = v___x_5202_;
goto v_reusejp_5279_;
}
else
{
lean_object* v_reuseFailAlloc_5281_; 
v_reuseFailAlloc_5281_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5281_, 0, v___x_5274_);
lean_ctor_set(v_reuseFailAlloc_5281_, 1, v___x_5278_);
v___x_5280_ = v_reuseFailAlloc_5281_;
goto v_reusejp_5279_;
}
v_reusejp_5279_:
{
return v___x_5280_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_5286_; lean_object* v___x_5287_; lean_object* v_result_5288_; 
lean_dec(v___x_5235_);
lean_dec(v_fst_5205_);
v___x_5286_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_5286_, 0, v___y_5226_);
lean_ctor_set(v___x_5286_, 1, v___y_5220_);
lean_ctor_set(v___x_5286_, 2, v___y_5219_);
lean_ctor_set(v___x_5286_, 3, v___y_5223_);
lean_ctor_set(v___x_5286_, 4, v___y_5225_);
lean_ctor_set(v___x_5286_, 5, v___y_5221_);
lean_ctor_set(v___x_5286_, 6, v___y_5224_);
lean_ctor_set(v___x_5286_, 7, v___y_5218_);
lean_ctor_set(v___x_5286_, 8, v___y_5217_);
lean_ctor_set_uint8(v___x_5286_, sizeof(void*)*9, v___y_5227_);
lean_inc(v_maxWork_5187_);
v___x_5287_ = lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_productMiss(v___x_5286_, v___x_5234_, v___y_5222_, v_multiplier_5184_, v_maxCount_5185_, v_maxBytes_5186_, v_maxWork_5187_, v_native_5188_);
lean_dec(v___y_5222_);
v_result_5288_ = lean_ctor_get(v___x_5287_, 0);
lean_inc_ref(v_result_5288_);
if (lean_obj_tag(v_result_5288_) == 0)
{
lean_object* v_table_5289_; lean_object* v___x_5291_; uint8_t v_isShared_5292_; uint8_t v_isSharedCheck_5314_; 
lean_dec(v_i_5192_);
lean_dec(v_maxWork_5187_);
lean_dec(v_multiplier_5184_);
v_table_5289_ = lean_ctor_get(v___x_5287_, 1);
v_isSharedCheck_5314_ = !lean_is_exclusive(v___x_5287_);
if (v_isSharedCheck_5314_ == 0)
{
lean_object* v_unused_5315_; 
v_unused_5315_ = lean_ctor_get(v___x_5287_, 0);
lean_dec(v_unused_5315_);
v___x_5291_ = v___x_5287_;
v_isShared_5292_ = v_isSharedCheck_5314_;
goto v_resetjp_5290_;
}
else
{
lean_inc(v_table_5289_);
lean_dec(v___x_5287_);
v___x_5291_ = lean_box(0);
v_isShared_5292_ = v_isSharedCheck_5314_;
goto v_resetjp_5290_;
}
v_resetjp_5290_:
{
lean_object* v_a_5293_; lean_object* v___x_5295_; uint8_t v_isShared_5296_; uint8_t v_isSharedCheck_5313_; 
v_a_5293_ = lean_ctor_get(v_result_5288_, 0);
v_isSharedCheck_5313_ = !lean_is_exclusive(v_result_5288_);
if (v_isSharedCheck_5313_ == 0)
{
v___x_5295_ = v_result_5288_;
v_isShared_5296_ = v_isSharedCheck_5313_;
goto v_resetjp_5294_;
}
else
{
lean_inc(v_a_5293_);
lean_dec(v_result_5288_);
v___x_5295_ = lean_box(0);
v_isShared_5296_ = v_isSharedCheck_5313_;
goto v_resetjp_5294_;
}
v_resetjp_5294_:
{
lean_object* v___x_5298_; 
if (v_isShared_5296_ == 0)
{
v___x_5298_ = v___x_5295_;
goto v_reusejp_5297_;
}
else
{
lean_object* v_reuseFailAlloc_5312_; 
v_reuseFailAlloc_5312_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5312_, 0, v_a_5293_);
v___x_5298_ = v_reuseFailAlloc_5312_;
goto v_reusejp_5297_;
}
v_reusejp_5297_:
{
lean_object* v___x_5300_; 
lean_inc_ref(v_table_5289_);
if (v_isShared_5292_ == 0)
{
lean_ctor_set(v___x_5291_, 0, v___x_5298_);
v___x_5300_ = v___x_5291_;
goto v_reusejp_5299_;
}
else
{
lean_object* v_reuseFailAlloc_5311_; 
v_reuseFailAlloc_5311_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5311_, 0, v___x_5298_);
lean_ctor_set(v_reuseFailAlloc_5311_, 1, v_table_5289_);
v___x_5300_ = v_reuseFailAlloc_5311_;
goto v_reusejp_5299_;
}
v_reusejp_5299_:
{
lean_object* v___x_5301_; lean_object* v___x_5303_; 
v___x_5301_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_5301_, 0, v___x_5300_);
if (v_isShared_5213_ == 0)
{
v___x_5303_ = v___x_5212_;
goto v_reusejp_5302_;
}
else
{
lean_object* v_reuseFailAlloc_5310_; 
v_reuseFailAlloc_5310_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5310_, 0, v_fst_5209_);
lean_ctor_set(v_reuseFailAlloc_5310_, 1, v_snd_5210_);
v___x_5303_ = v_reuseFailAlloc_5310_;
goto v_reusejp_5302_;
}
v_reusejp_5302_:
{
lean_object* v___x_5305_; 
if (v_isShared_5208_ == 0)
{
lean_ctor_set(v___x_5207_, 1, v___x_5303_);
lean_ctor_set(v___x_5207_, 0, v_table_5289_);
v___x_5305_ = v___x_5207_;
goto v_reusejp_5304_;
}
else
{
lean_object* v_reuseFailAlloc_5309_; 
v_reuseFailAlloc_5309_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5309_, 0, v_table_5289_);
lean_ctor_set(v_reuseFailAlloc_5309_, 1, v___x_5303_);
v___x_5305_ = v_reuseFailAlloc_5309_;
goto v_reusejp_5304_;
}
v_reusejp_5304_:
{
lean_object* v___x_5307_; 
if (v_isShared_5203_ == 0)
{
lean_ctor_set(v___x_5202_, 1, v___x_5305_);
lean_ctor_set(v___x_5202_, 0, v___x_5301_);
v___x_5307_ = v___x_5202_;
goto v_reusejp_5306_;
}
else
{
lean_object* v_reuseFailAlloc_5308_; 
v_reuseFailAlloc_5308_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5308_, 0, v___x_5301_);
lean_ctor_set(v_reuseFailAlloc_5308_, 1, v___x_5305_);
v___x_5307_ = v_reuseFailAlloc_5308_;
goto v_reusejp_5306_;
}
v_reusejp_5306_:
{
return v___x_5307_;
}
}
}
}
}
}
}
}
else
{
lean_object* v_table_5316_; lean_object* v_a_5317_; lean_object* v_work_5318_; uint64_t v___x_5319_; uint8_t v___x_5320_; lean_object* v_data_5321_; uint64_t v___x_5322_; uint64_t v___x_5323_; uint8_t v___x_5324_; lean_object* v___x_5325_; uint64_t v___x_5326_; uint64_t v___x_5327_; uint8_t v___x_5328_; lean_object* v___x_5329_; uint64_t v___x_5330_; uint64_t v___x_5331_; uint8_t v___x_5332_; lean_object* v___x_5333_; lean_object* v___x_5335_; 
lean_dec(v_fst_5209_);
v_table_5316_ = lean_ctor_get(v___x_5287_, 1);
lean_inc_ref(v_table_5316_);
lean_dec_ref(v___x_5287_);
v_a_5317_ = lean_ctor_get(v_result_5288_, 0);
lean_inc(v_a_5317_);
lean_dec_ref_known(v_result_5288_, 1);
v_work_5318_ = lean_ctor_get(v_table_5316_, 8);
v___x_5319_ = lean_uint64_of_nat(v_a_5317_);
lean_dec(v_a_5317_);
v___x_5320_ = lean_uint64_to_uint8(v___x_5319_);
v_data_5321_ = lean_byte_array_push(v_snd_5210_, v___x_5320_);
v___x_5322_ = 8ULL;
v___x_5323_ = lean_uint64_shift_right(v___x_5319_, v___x_5322_);
v___x_5324_ = lean_uint64_to_uint8(v___x_5323_);
v___x_5325_ = lean_byte_array_push(v_data_5321_, v___x_5324_);
v___x_5326_ = 16ULL;
v___x_5327_ = lean_uint64_shift_right(v___x_5319_, v___x_5326_);
v___x_5328_ = lean_uint64_to_uint8(v___x_5327_);
v___x_5329_ = lean_byte_array_push(v___x_5325_, v___x_5328_);
v___x_5330_ = 24ULL;
v___x_5331_ = lean_uint64_shift_right(v___x_5319_, v___x_5330_);
v___x_5332_ = lean_uint64_to_uint8(v___x_5331_);
v___x_5333_ = lean_byte_array_push(v___x_5329_, v___x_5332_);
lean_inc(v_work_5318_);
if (v_isShared_5213_ == 0)
{
lean_ctor_set(v___x_5212_, 1, v___x_5333_);
lean_ctor_set(v___x_5212_, 0, v_work_5318_);
v___x_5335_ = v___x_5212_;
goto v_reusejp_5334_;
}
else
{
lean_object* v_reuseFailAlloc_5342_; 
v_reuseFailAlloc_5342_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5342_, 0, v_work_5318_);
lean_ctor_set(v_reuseFailAlloc_5342_, 1, v___x_5333_);
v___x_5335_ = v_reuseFailAlloc_5342_;
goto v_reusejp_5334_;
}
v_reusejp_5334_:
{
lean_object* v___x_5337_; 
if (v_isShared_5208_ == 0)
{
lean_ctor_set(v___x_5207_, 1, v___x_5335_);
lean_ctor_set(v___x_5207_, 0, v_table_5316_);
v___x_5337_ = v___x_5207_;
goto v_reusejp_5336_;
}
else
{
lean_object* v_reuseFailAlloc_5341_; 
v_reuseFailAlloc_5341_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5341_, 0, v_table_5316_);
lean_ctor_set(v_reuseFailAlloc_5341_, 1, v___x_5335_);
v___x_5337_ = v_reuseFailAlloc_5341_;
goto v_reusejp_5336_;
}
v_reusejp_5336_:
{
lean_object* v___x_5339_; 
if (v_isShared_5203_ == 0)
{
lean_ctor_set(v___x_5202_, 1, v___x_5337_);
lean_ctor_set(v___x_5202_, 0, v___x_5215_);
v___x_5339_ = v___x_5202_;
goto v_reusejp_5338_;
}
else
{
lean_object* v_reuseFailAlloc_5340_; 
v_reuseFailAlloc_5340_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5340_, 0, v___x_5215_);
lean_ctor_set(v_reuseFailAlloc_5340_, 1, v___x_5337_);
v___x_5339_ = v_reuseFailAlloc_5340_;
goto v_reusejp_5338_;
}
v_reusejp_5338_:
{
v_a_5196_ = v___x_5339_;
goto v___jp_5195_;
}
}
}
}
}
}
v___jp_5343_:
{
uint8_t v___x_5356_; 
v___x_5356_ = lean_nat_dec_le(v___y_5349_, v_multiplier_5184_);
if (v___x_5356_ == 0)
{
lean_inc(v___y_5349_);
v___y_5217_ = v___y_5344_;
v___y_5218_ = v___y_5346_;
v___y_5219_ = v___y_5345_;
v___y_5220_ = v___y_5347_;
v___y_5221_ = v___y_5348_;
v___y_5222_ = v___y_5349_;
v___y_5223_ = v___y_5350_;
v___y_5224_ = v___y_5351_;
v___y_5225_ = v___y_5353_;
v___y_5226_ = v___y_5352_;
v___y_5227_ = v___y_5354_;
v___y_5228_ = v___y_5355_;
v___y_5229_ = v___y_5349_;
goto v___jp_5216_;
}
else
{
lean_inc(v_multiplier_5184_);
v___y_5217_ = v___y_5344_;
v___y_5218_ = v___y_5346_;
v___y_5219_ = v___y_5345_;
v___y_5220_ = v___y_5347_;
v___y_5221_ = v___y_5348_;
v___y_5222_ = v___y_5349_;
v___y_5223_ = v___y_5350_;
v___y_5224_ = v___y_5351_;
v___y_5225_ = v___y_5353_;
v___y_5226_ = v___y_5352_;
v___y_5227_ = v___y_5354_;
v___y_5228_ = v___y_5355_;
v___y_5229_ = v_multiplier_5184_;
goto v___jp_5216_;
}
}
v___jp_5357_:
{
lean_object* v_arity_5359_; uint8_t v_width_5360_; lean_object* v_exponents_5361_; lean_object* v_metadata_5362_; lean_object* v_count_5363_; lean_object* v_workspace_5364_; lean_object* v_buckets_5365_; lean_object* v_products_5366_; lean_object* v_hashBits_5367_; lean_object* v___x_5368_; uint8_t v___x_5369_; 
v_arity_5359_ = lean_ctor_get(v_fst_5205_, 0);
v_width_5360_ = lean_ctor_get_uint8(v_fst_5205_, sizeof(void*)*9);
v_exponents_5361_ = lean_ctor_get(v_fst_5205_, 1);
v_metadata_5362_ = lean_ctor_get(v_fst_5205_, 2);
v_count_5363_ = lean_ctor_get(v_fst_5205_, 3);
v_workspace_5364_ = lean_ctor_get(v_fst_5205_, 4);
v_buckets_5365_ = lean_ctor_get(v_fst_5205_, 5);
v_products_5366_ = lean_ctor_get(v_fst_5205_, 6);
v_hashBits_5367_ = lean_ctor_get(v_fst_5205_, 7);
v___x_5368_ = lean_uint64_to_nat(v___y_5358_);
v___x_5369_ = lean_nat_dec_le(v_count_5363_, v___x_5368_);
if (v___x_5369_ == 0)
{
lean_object* v___x_5370_; uint8_t v___x_5371_; 
v___x_5370_ = lean_nat_add(v_fst_5209_, v___x_5214_);
v___x_5371_ = lean_nat_dec_lt(v_maxWork_5187_, v___x_5370_);
if (v___x_5371_ == 0)
{
uint8_t v___x_5372_; 
v___x_5372_ = lean_nat_dec_le(v___x_5368_, v_multiplier_5184_);
if (v___x_5372_ == 0)
{
lean_inc(v_multiplier_5184_);
lean_inc_ref(v_workspace_5364_);
lean_inc(v_arity_5359_);
lean_inc_ref(v_products_5366_);
lean_inc(v_count_5363_);
lean_inc_ref(v_buckets_5365_);
lean_inc_ref(v_exponents_5361_);
lean_inc(v_hashBits_5367_);
lean_inc_ref(v_metadata_5362_);
v___y_5344_ = v___x_5370_;
v___y_5345_ = v_metadata_5362_;
v___y_5346_ = v_hashBits_5367_;
v___y_5347_ = v_exponents_5361_;
v___y_5348_ = v_buckets_5365_;
v___y_5349_ = v___x_5368_;
v___y_5350_ = v_count_5363_;
v___y_5351_ = v_products_5366_;
v___y_5352_ = v_arity_5359_;
v___y_5353_ = v_workspace_5364_;
v___y_5354_ = v_width_5360_;
v___y_5355_ = v_multiplier_5184_;
goto v___jp_5343_;
}
else
{
lean_inc_ref(v_workspace_5364_);
lean_inc(v_arity_5359_);
lean_inc_ref(v_products_5366_);
lean_inc(v_count_5363_);
lean_inc(v___x_5368_);
lean_inc_ref(v_buckets_5365_);
lean_inc_ref(v_exponents_5361_);
lean_inc(v_hashBits_5367_);
lean_inc_ref(v_metadata_5362_);
v___y_5344_ = v___x_5370_;
v___y_5345_ = v_metadata_5362_;
v___y_5346_ = v_hashBits_5367_;
v___y_5347_ = v_exponents_5361_;
v___y_5348_ = v_buckets_5365_;
v___y_5349_ = v___x_5368_;
v___y_5350_ = v_count_5363_;
v___y_5351_ = v_products_5366_;
v___y_5352_ = v_arity_5359_;
v___y_5353_ = v_workspace_5364_;
v___y_5354_ = v_width_5360_;
v___y_5355_ = v___x_5368_;
goto v___jp_5343_;
}
}
else
{
uint8_t v___x_5373_; lean_object* v___x_5374_; lean_object* v___x_5375_; lean_object* v___x_5376_; lean_object* v___x_5377_; lean_object* v___x_5378_; lean_object* v___x_5379_; lean_object* v___x_5380_; lean_object* v___x_5381_; 
lean_dec(v___x_5370_);
lean_dec(v___x_5368_);
lean_del_object(v___x_5212_);
lean_del_object(v___x_5207_);
lean_del_object(v___x_5202_);
lean_dec(v_i_5192_);
lean_dec(v_multiplier_5184_);
v___x_5373_ = 8;
v___x_5374_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5374_, 0, v_maxWork_5187_);
lean_ctor_set_uint8(v___x_5374_, sizeof(void*)*1, v___x_5373_);
v___x_5375_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5375_, 0, v___x_5374_);
lean_inc(v_fst_5209_);
lean_inc(v_hashBits_5367_);
lean_inc_ref(v_products_5366_);
lean_inc_ref(v_buckets_5365_);
lean_inc_ref(v_workspace_5364_);
lean_inc(v_count_5363_);
lean_inc_ref(v_metadata_5362_);
lean_inc_ref(v_exponents_5361_);
lean_inc(v_arity_5359_);
v___x_5376_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_5376_, 0, v_arity_5359_);
lean_ctor_set(v___x_5376_, 1, v_exponents_5361_);
lean_ctor_set(v___x_5376_, 2, v_metadata_5362_);
lean_ctor_set(v___x_5376_, 3, v_count_5363_);
lean_ctor_set(v___x_5376_, 4, v_workspace_5364_);
lean_ctor_set(v___x_5376_, 5, v_buckets_5365_);
lean_ctor_set(v___x_5376_, 6, v_products_5366_);
lean_ctor_set(v___x_5376_, 7, v_hashBits_5367_);
lean_ctor_set(v___x_5376_, 8, v_fst_5209_);
lean_ctor_set_uint8(v___x_5376_, sizeof(void*)*9, v_width_5360_);
v___x_5377_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5377_, 0, v___x_5375_);
lean_ctor_set(v___x_5377_, 1, v___x_5376_);
v___x_5378_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_5378_, 0, v___x_5377_);
v___x_5379_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5379_, 0, v_fst_5209_);
lean_ctor_set(v___x_5379_, 1, v_snd_5210_);
v___x_5380_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5380_, 0, v_fst_5205_);
lean_ctor_set(v___x_5380_, 1, v___x_5379_);
v___x_5381_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5381_, 0, v___x_5378_);
lean_ctor_set(v___x_5381_, 1, v___x_5380_);
return v___x_5381_;
}
}
else
{
uint8_t v___x_5382_; lean_object* v___x_5383_; lean_object* v___x_5384_; lean_object* v___x_5385_; lean_object* v___x_5386_; lean_object* v___x_5387_; lean_object* v___x_5388_; lean_object* v___x_5389_; lean_object* v___x_5390_; 
lean_dec(v___x_5368_);
lean_del_object(v___x_5212_);
lean_del_object(v___x_5207_);
lean_del_object(v___x_5202_);
lean_dec(v_i_5192_);
lean_dec(v_maxWork_5187_);
lean_dec(v_multiplier_5184_);
v___x_5382_ = 1;
lean_inc_n(v_fst_5209_, 2);
v___x_5383_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5383_, 0, v_fst_5209_);
lean_ctor_set_uint8(v___x_5383_, sizeof(void*)*1, v___x_5382_);
v___x_5384_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5384_, 0, v___x_5383_);
lean_inc(v_hashBits_5367_);
lean_inc_ref(v_products_5366_);
lean_inc_ref(v_buckets_5365_);
lean_inc_ref(v_workspace_5364_);
lean_inc(v_count_5363_);
lean_inc_ref(v_metadata_5362_);
lean_inc_ref(v_exponents_5361_);
lean_inc(v_arity_5359_);
v___x_5385_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v___x_5385_, 0, v_arity_5359_);
lean_ctor_set(v___x_5385_, 1, v_exponents_5361_);
lean_ctor_set(v___x_5385_, 2, v_metadata_5362_);
lean_ctor_set(v___x_5385_, 3, v_count_5363_);
lean_ctor_set(v___x_5385_, 4, v_workspace_5364_);
lean_ctor_set(v___x_5385_, 5, v_buckets_5365_);
lean_ctor_set(v___x_5385_, 6, v_products_5366_);
lean_ctor_set(v___x_5385_, 7, v_hashBits_5367_);
lean_ctor_set(v___x_5385_, 8, v_fst_5209_);
lean_ctor_set_uint8(v___x_5385_, sizeof(void*)*9, v_width_5360_);
v___x_5386_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5386_, 0, v___x_5384_);
lean_ctor_set(v___x_5386_, 1, v___x_5385_);
v___x_5387_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_5387_, 0, v___x_5386_);
v___x_5388_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5388_, 0, v_fst_5209_);
lean_ctor_set(v___x_5388_, 1, v_snd_5210_);
v___x_5389_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5389_, 0, v_fst_5205_);
lean_ctor_set(v___x_5389_, 1, v___x_5388_);
v___x_5390_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5390_, 0, v___x_5387_);
lean_ctor_set(v___x_5390_, 1, v___x_5389_);
return v___x_5390_;
}
}
v___jp_5391_:
{
uint64_t v___x_5394_; uint64_t v___x_5395_; uint64_t v___x_5396_; uint64_t v___x_5397_; 
v___x_5394_ = lean_uint8_to_uint64(v___y_5393_);
v___x_5395_ = 24ULL;
v___x_5396_ = lean_uint64_shift_left(v___x_5394_, v___x_5395_);
v___x_5397_ = lean_uint64_lor(v___y_5392_, v___x_5396_);
v___y_5358_ = v___x_5397_;
goto v___jp_5357_;
}
v___jp_5401_:
{
uint64_t v___x_5404_; uint64_t v___x_5405_; uint64_t v___x_5406_; uint64_t v___x_5407_; lean_object* v___x_5408_; lean_object* v___x_5409_; uint8_t v___x_5410_; 
v___x_5404_ = lean_uint8_to_uint64(v___y_5403_);
v___x_5405_ = 16ULL;
v___x_5406_ = lean_uint64_shift_left(v___x_5404_, v___x_5405_);
v___x_5407_ = lean_uint64_lor(v___y_5402_, v___x_5406_);
v___x_5408_ = lean_unsigned_to_nat(3u);
v___x_5409_ = lean_nat_add(v_offset_5400_, v___x_5408_);
lean_dec(v_offset_5400_);
v___x_5410_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_support_5189_, v___x_5409_);
if (v___x_5410_ == 0)
{
lean_object* v___x_5411_; lean_object* v___x_5412_; uint8_t v___x_5413_; 
lean_dec(v___x_5409_);
v___x_5411_ = lean_box(v___x_5398_);
v___x_5412_ = l_outOfBounds___redArg(v___x_5411_);
lean_dec(v___x_5411_);
v___x_5413_ = lean_unbox(v___x_5412_);
lean_dec(v___x_5412_);
v___y_5392_ = v___x_5407_;
v___y_5393_ = v___x_5413_;
goto v___jp_5391_;
}
else
{
uint8_t v___x_5414_; 
v___x_5414_ = lean_byte_array_fget(v_support_5189_, v___x_5409_);
lean_dec(v___x_5409_);
v___y_5392_ = v___x_5407_;
v___y_5393_ = v___x_5414_;
goto v___jp_5391_;
}
}
v___jp_5415_:
{
uint64_t v___x_5418_; uint64_t v___x_5419_; uint64_t v___x_5420_; uint64_t v___x_5421_; lean_object* v___x_5422_; lean_object* v___x_5423_; uint8_t v___x_5424_; 
v___x_5418_ = lean_uint8_to_uint64(v___y_5417_);
v___x_5419_ = 8ULL;
v___x_5420_ = lean_uint64_shift_left(v___x_5418_, v___x_5419_);
v___x_5421_ = lean_uint64_lor(v___y_5416_, v___x_5420_);
v___x_5422_ = lean_unsigned_to_nat(2u);
v___x_5423_ = lean_nat_add(v_offset_5400_, v___x_5422_);
v___x_5424_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_support_5189_, v___x_5423_);
if (v___x_5424_ == 0)
{
lean_object* v___x_5425_; lean_object* v___x_5426_; uint8_t v___x_5427_; 
lean_dec(v___x_5423_);
v___x_5425_ = lean_box(v___x_5398_);
v___x_5426_ = l_outOfBounds___redArg(v___x_5425_);
lean_dec(v___x_5425_);
v___x_5427_ = lean_unbox(v___x_5426_);
lean_dec(v___x_5426_);
v___y_5402_ = v___x_5421_;
v___y_5403_ = v___x_5427_;
goto v___jp_5401_;
}
else
{
uint8_t v___x_5428_; 
v___x_5428_ = lean_byte_array_fget(v_support_5189_, v___x_5423_);
lean_dec(v___x_5423_);
v___y_5402_ = v___x_5421_;
v___y_5403_ = v___x_5428_;
goto v___jp_5401_;
}
}
v___jp_5429_:
{
uint64_t v_a_5431_; lean_object* v___x_5432_; uint8_t v___x_5433_; 
v_a_5431_ = lean_uint8_to_uint64(v___y_5430_);
v___x_5432_ = lean_nat_add(v_offset_5400_, v___x_5214_);
v___x_5433_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_support_5189_, v___x_5432_);
if (v___x_5433_ == 0)
{
lean_object* v___x_5434_; lean_object* v___x_5435_; uint8_t v___x_5436_; 
lean_dec(v___x_5432_);
v___x_5434_ = lean_box(v___x_5398_);
v___x_5435_ = l_outOfBounds___redArg(v___x_5434_);
lean_dec(v___x_5434_);
v___x_5436_ = lean_unbox(v___x_5435_);
lean_dec(v___x_5435_);
v___y_5416_ = v_a_5431_;
v___y_5417_ = v___x_5436_;
goto v___jp_5415_;
}
else
{
uint8_t v___x_5437_; 
v___x_5437_ = lean_byte_array_fget(v_support_5189_, v___x_5432_);
lean_dec(v___x_5432_);
v___y_5416_ = v_a_5431_;
v___y_5417_ = v___x_5437_;
goto v___jp_5415_;
}
}
v___jp_5438_:
{
if (v___y_5439_ == 0)
{
uint8_t v___x_5440_; 
v___x_5440_ = lp_Hex_Hex_Groebner_MonomialTable_exponent___lam__0(v_support_5189_, v_offset_5400_);
if (v___x_5440_ == 0)
{
lean_object* v___x_5441_; lean_object* v___x_5442_; uint8_t v___x_5443_; 
v___x_5441_ = lean_box(v___x_5398_);
v___x_5442_ = l_outOfBounds___redArg(v___x_5441_);
lean_dec(v___x_5441_);
v___x_5443_ = lean_unbox(v___x_5442_);
lean_dec(v___x_5442_);
v___y_5430_ = v___x_5443_;
goto v___jp_5429_;
}
else
{
uint8_t v___x_5444_; 
v___x_5444_ = lean_byte_array_fget(v_support_5189_, v_offset_5400_);
v___y_5430_ = v___x_5444_;
goto v___jp_5429_;
}
}
else
{
size_t v_pos_5445_; uint8_t v___x_5446_; uint64_t v_a_5447_; size_t v___x_5448_; size_t v___x_5449_; uint8_t v___x_5450_; uint64_t v___x_5451_; uint64_t v___x_5452_; uint64_t v___x_5453_; uint64_t v___x_5454_; size_t v___x_5455_; size_t v___x_5456_; uint8_t v___x_5457_; uint64_t v___x_5458_; uint64_t v___x_5459_; uint64_t v___x_5460_; uint64_t v___x_5461_; size_t v___x_5462_; size_t v___x_5463_; uint8_t v___x_5464_; uint64_t v___x_5465_; uint64_t v___x_5466_; uint64_t v___x_5467_; uint64_t v___x_5468_; 
v_pos_5445_ = lean_usize_of_nat(v_offset_5400_);
lean_dec(v_offset_5400_);
v___x_5446_ = lean_byte_array_uget(v_support_5189_, v_pos_5445_);
v_a_5447_ = lean_uint8_to_uint64(v___x_5446_);
v___x_5448_ = ((size_t)1ULL);
v___x_5449_ = lean_usize_add(v_pos_5445_, v___x_5448_);
v___x_5450_ = lean_byte_array_uget(v_support_5189_, v___x_5449_);
v___x_5451_ = lean_uint8_to_uint64(v___x_5450_);
v___x_5452_ = 8ULL;
v___x_5453_ = lean_uint64_shift_left(v___x_5451_, v___x_5452_);
v___x_5454_ = lean_uint64_lor(v_a_5447_, v___x_5453_);
v___x_5455_ = ((size_t)2ULL);
v___x_5456_ = lean_usize_add(v_pos_5445_, v___x_5455_);
v___x_5457_ = lean_byte_array_uget(v_support_5189_, v___x_5456_);
v___x_5458_ = lean_uint8_to_uint64(v___x_5457_);
v___x_5459_ = 16ULL;
v___x_5460_ = lean_uint64_shift_left(v___x_5458_, v___x_5459_);
v___x_5461_ = lean_uint64_lor(v___x_5454_, v___x_5460_);
v___x_5462_ = ((size_t)3ULL);
v___x_5463_ = lean_usize_add(v_pos_5445_, v___x_5462_);
v___x_5464_ = lean_byte_array_uget(v_support_5189_, v___x_5463_);
v___x_5465_ = lean_uint8_to_uint64(v___x_5464_);
v___x_5466_ = 24ULL;
v___x_5467_ = lean_uint64_shift_left(v___x_5465_, v___x_5466_);
v___x_5468_ = lean_uint64_lor(v___x_5461_, v___x_5467_);
v___y_5358_ = v___x_5468_;
goto v___jp_5357_;
}
}
}
}
}
}
v___jp_5195_:
{
lean_object* v___x_5197_; 
v___x_5197_ = lean_nat_add(v_i_5192_, v_step_5194_);
lean_dec(v_i_5192_);
v_b_5191_ = v_a_5196_;
v_i_5192_ = v___x_5197_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0___redArg___boxed(lean_object* v_multiplier_5479_, lean_object* v_maxCount_5480_, lean_object* v_maxBytes_5481_, lean_object* v_maxWork_5482_, lean_object* v_native_5483_, lean_object* v_support_5484_, lean_object* v_range_5485_, lean_object* v_b_5486_, lean_object* v_i_5487_){
_start:
{
uint8_t v_native_boxed_5488_; lean_object* v_res_5489_; 
v_native_boxed_5488_ = lean_unbox(v_native_5483_);
v_res_5489_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0___redArg(v_multiplier_5479_, v_maxCount_5480_, v_maxBytes_5481_, v_maxWork_5482_, v_native_boxed_5488_, v_support_5484_, v_range_5485_, v_b_5486_, v_i_5487_);
lean_dec_ref(v_range_5485_);
lean_dec_ref(v_support_5484_);
lean_dec(v_maxBytes_5481_);
lean_dec(v_maxCount_5480_);
return v_res_5489_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_mapProducts(lean_object* v_initial_5490_, lean_object* v_support_5491_, lean_object* v_multiplier_5492_, lean_object* v_maxCount_5493_, lean_object* v_maxBytes_5494_, lean_object* v_maxWork_5495_, uint8_t v_native_5496_){
_start:
{
lean_object* v_arity_5497_; uint8_t v_width_5498_; lean_object* v_exponents_5499_; lean_object* v_metadata_5500_; lean_object* v_count_5501_; lean_object* v_workspace_5502_; lean_object* v_products_5503_; lean_object* v_work_5504_; lean_object* v___x_5510_; lean_object* v_output_5511_; lean_object* v___y_5513_; lean_object* v___y_5514_; lean_object* v___y_5515_; lean_object* v___y_5585_; lean_object* v___y_5586_; lean_object* v___y_5587_; lean_object* v___y_5588_; lean_object* v___x_5590_; lean_object* v___x_5591_; lean_object* v___y_5593_; 
v_arity_5497_ = lean_ctor_get(v_initial_5490_, 0);
v_width_5498_ = lean_ctor_get_uint8(v_initial_5490_, sizeof(void*)*9);
v_exponents_5499_ = lean_ctor_get(v_initial_5490_, 1);
v_metadata_5500_ = lean_ctor_get(v_initial_5490_, 2);
v_count_5501_ = lean_ctor_get(v_initial_5490_, 3);
v_workspace_5502_ = lean_ctor_get(v_initial_5490_, 4);
v_products_5503_ = lean_ctor_get(v_initial_5490_, 6);
lean_inc_ref(v_products_5503_);
v_work_5504_ = lean_ctor_get(v_initial_5490_, 8);
v___x_5510_ = lean_byte_array_size(v_support_5491_);
v_output_5511_ = lean_mk_empty_byte_array(v___x_5510_);
v___x_5590_ = lean_byte_array_size(v_exponents_5499_);
v___x_5591_ = lean_nat_mul(v_count_5501_, v_arity_5497_);
switch(v_width_5498_)
{
case 0:
{
lean_object* v___x_5618_; 
v___x_5618_ = lean_unsigned_to_nat(1u);
v___y_5593_ = v___x_5618_;
goto v___jp_5592_;
}
case 1:
{
lean_object* v___x_5619_; 
v___x_5619_ = lean_unsigned_to_nat(2u);
v___y_5593_ = v___x_5619_;
goto v___jp_5592_;
}
default: 
{
lean_object* v___x_5620_; 
v___x_5620_ = lean_unsigned_to_nat(4u);
v___y_5593_ = v___x_5620_;
goto v___jp_5592_;
}
}
v___jp_5505_:
{
uint8_t v___x_5506_; lean_object* v___x_5507_; lean_object* v___x_5508_; lean_object* v___x_5509_; 
v___x_5506_ = 5;
lean_inc(v_work_5504_);
v___x_5507_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5507_, 0, v_work_5504_);
lean_ctor_set_uint8(v___x_5507_, sizeof(void*)*1, v___x_5506_);
v___x_5508_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5508_, 0, v___x_5507_);
v___x_5509_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5509_, 0, v___x_5508_);
lean_ctor_set(v___x_5509_, 1, v_initial_5490_);
return v___x_5509_;
}
v___jp_5512_:
{
lean_object* v_size_5516_; lean_object* v___x_5518_; uint8_t v_isShared_5519_; uint8_t v_isSharedCheck_5582_; 
v_size_5516_ = lean_ctor_get(v_products_5503_, 0);
v_isSharedCheck_5582_ = !lean_is_exclusive(v_products_5503_);
if (v_isSharedCheck_5582_ == 0)
{
lean_object* v_unused_5583_; 
v_unused_5583_ = lean_ctor_get(v_products_5503_, 1);
lean_dec(v_unused_5583_);
v___x_5518_ = v_products_5503_;
v_isShared_5519_ = v_isSharedCheck_5582_;
goto v_resetjp_5517_;
}
else
{
lean_inc(v_size_5516_);
lean_dec(v_products_5503_);
v___x_5518_ = lean_box(0);
v_isShared_5519_ = v_isSharedCheck_5582_;
goto v_resetjp_5517_;
}
v_resetjp_5517_:
{
lean_object* v___x_5520_; lean_object* v___x_5521_; lean_object* v___x_5522_; lean_object* v___x_5523_; uint8_t v___x_5524_; 
v___x_5520_ = lean_nat_add(v___y_5513_, v___y_5515_);
lean_dec(v___y_5515_);
lean_dec(v___y_5513_);
v___x_5521_ = lean_unsigned_to_nat(12u);
v___x_5522_ = lean_nat_mul(v___x_5521_, v_size_5516_);
lean_dec(v_size_5516_);
v___x_5523_ = lean_nat_add(v___x_5520_, v___x_5522_);
lean_dec(v___x_5522_);
lean_dec(v___x_5520_);
v___x_5524_ = lean_nat_dec_lt(v_maxBytes_5494_, v___x_5523_);
if (v___x_5524_ == 0)
{
lean_object* v___x_5525_; lean_object* v___x_5526_; uint8_t v___x_5527_; 
v___x_5525_ = lean_unsigned_to_nat(2u);
v___x_5526_ = lean_obj_once(&lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12, &lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12_once, _init_lp_Hex___private_HexGroebner_Monomial_0__Hex_Groebner_MonomialTable_append___closed__12);
v___x_5527_ = lean_nat_dec_le(v___x_5526_, v___x_5523_);
lean_dec(v___x_5523_);
if (v___x_5527_ == 0)
{
lean_object* v___x_5528_; lean_object* v___x_5529_; lean_object* v___x_5530_; lean_object* v___x_5531_; lean_object* v___x_5533_; 
v___x_5528_ = lean_nat_shiftr(v___x_5510_, v___x_5525_);
v___x_5529_ = lean_unsigned_to_nat(1u);
lean_inc(v___y_5514_);
v___x_5530_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_5530_, 0, v___y_5514_);
lean_ctor_set(v___x_5530_, 1, v___x_5528_);
lean_ctor_set(v___x_5530_, 2, v___x_5529_);
v___x_5531_ = lean_box(0);
lean_inc(v_work_5504_);
if (v_isShared_5519_ == 0)
{
lean_ctor_set(v___x_5518_, 1, v_output_5511_);
lean_ctor_set(v___x_5518_, 0, v_work_5504_);
v___x_5533_ = v___x_5518_;
goto v_reusejp_5532_;
}
else
{
lean_object* v_reuseFailAlloc_5569_; 
v_reuseFailAlloc_5569_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5569_, 0, v_work_5504_);
lean_ctor_set(v_reuseFailAlloc_5569_, 1, v_output_5511_);
v___x_5533_ = v_reuseFailAlloc_5569_;
goto v_reusejp_5532_;
}
v_reusejp_5532_:
{
lean_object* v___x_5534_; lean_object* v___x_5535_; lean_object* v___x_5536_; lean_object* v_fst_5537_; 
v___x_5534_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5534_, 0, v_initial_5490_);
lean_ctor_set(v___x_5534_, 1, v___x_5533_);
v___x_5535_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5535_, 0, v___x_5531_);
lean_ctor_set(v___x_5535_, 1, v___x_5534_);
v___x_5536_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0___redArg(v_multiplier_5492_, v_maxCount_5493_, v_maxBytes_5494_, v_maxWork_5495_, v_native_5496_, v_support_5491_, v___x_5530_, v___x_5535_, v___y_5514_);
lean_dec_ref_known(v___x_5530_, 3);
v_fst_5537_ = lean_ctor_get(v___x_5536_, 0);
lean_inc(v_fst_5537_);
if (lean_obj_tag(v_fst_5537_) == 0)
{
lean_object* v_snd_5538_; lean_object* v_snd_5539_; lean_object* v_fst_5540_; lean_object* v_fst_5541_; lean_object* v_snd_5542_; lean_object* v___x_5544_; uint8_t v_isShared_5545_; uint8_t v_isSharedCheck_5567_; 
v_snd_5538_ = lean_ctor_get(v___x_5536_, 1);
lean_inc(v_snd_5538_);
lean_dec_ref(v___x_5536_);
v_snd_5539_ = lean_ctor_get(v_snd_5538_, 1);
lean_inc(v_snd_5539_);
v_fst_5540_ = lean_ctor_get(v_snd_5538_, 0);
lean_inc(v_fst_5540_);
lean_dec(v_snd_5538_);
v_fst_5541_ = lean_ctor_get(v_snd_5539_, 0);
v_snd_5542_ = lean_ctor_get(v_snd_5539_, 1);
v_isSharedCheck_5567_ = !lean_is_exclusive(v_snd_5539_);
if (v_isSharedCheck_5567_ == 0)
{
v___x_5544_ = v_snd_5539_;
v_isShared_5545_ = v_isSharedCheck_5567_;
goto v_resetjp_5543_;
}
else
{
lean_inc(v_snd_5542_);
lean_inc(v_fst_5541_);
lean_dec(v_snd_5539_);
v___x_5544_ = lean_box(0);
v_isShared_5545_ = v_isSharedCheck_5567_;
goto v_resetjp_5543_;
}
v_resetjp_5543_:
{
lean_object* v_arity_5546_; uint8_t v_width_5547_; lean_object* v_exponents_5548_; lean_object* v_metadata_5549_; lean_object* v_count_5550_; lean_object* v_workspace_5551_; lean_object* v_buckets_5552_; lean_object* v_products_5553_; lean_object* v_hashBits_5554_; lean_object* v___x_5556_; uint8_t v_isShared_5557_; uint8_t v_isSharedCheck_5565_; 
v_arity_5546_ = lean_ctor_get(v_fst_5540_, 0);
v_width_5547_ = lean_ctor_get_uint8(v_fst_5540_, sizeof(void*)*9);
v_exponents_5548_ = lean_ctor_get(v_fst_5540_, 1);
v_metadata_5549_ = lean_ctor_get(v_fst_5540_, 2);
v_count_5550_ = lean_ctor_get(v_fst_5540_, 3);
v_workspace_5551_ = lean_ctor_get(v_fst_5540_, 4);
v_buckets_5552_ = lean_ctor_get(v_fst_5540_, 5);
v_products_5553_ = lean_ctor_get(v_fst_5540_, 6);
v_hashBits_5554_ = lean_ctor_get(v_fst_5540_, 7);
v_isSharedCheck_5565_ = !lean_is_exclusive(v_fst_5540_);
if (v_isSharedCheck_5565_ == 0)
{
lean_object* v_unused_5566_; 
v_unused_5566_ = lean_ctor_get(v_fst_5540_, 8);
lean_dec(v_unused_5566_);
v___x_5556_ = v_fst_5540_;
v_isShared_5557_ = v_isSharedCheck_5565_;
goto v_resetjp_5555_;
}
else
{
lean_inc(v_hashBits_5554_);
lean_inc(v_products_5553_);
lean_inc(v_buckets_5552_);
lean_inc(v_workspace_5551_);
lean_inc(v_count_5550_);
lean_inc(v_metadata_5549_);
lean_inc(v_exponents_5548_);
lean_inc(v_arity_5546_);
lean_dec(v_fst_5540_);
v___x_5556_ = lean_box(0);
v_isShared_5557_ = v_isSharedCheck_5565_;
goto v_resetjp_5555_;
}
v_resetjp_5555_:
{
lean_object* v___x_5558_; lean_object* v___x_5560_; 
v___x_5558_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_5558_, 0, v_snd_5542_);
if (v_isShared_5557_ == 0)
{
lean_ctor_set(v___x_5556_, 8, v_fst_5541_);
v___x_5560_ = v___x_5556_;
goto v_reusejp_5559_;
}
else
{
lean_object* v_reuseFailAlloc_5564_; 
v_reuseFailAlloc_5564_ = lean_alloc_ctor(0, 9, 1);
lean_ctor_set(v_reuseFailAlloc_5564_, 0, v_arity_5546_);
lean_ctor_set(v_reuseFailAlloc_5564_, 1, v_exponents_5548_);
lean_ctor_set(v_reuseFailAlloc_5564_, 2, v_metadata_5549_);
lean_ctor_set(v_reuseFailAlloc_5564_, 3, v_count_5550_);
lean_ctor_set(v_reuseFailAlloc_5564_, 4, v_workspace_5551_);
lean_ctor_set(v_reuseFailAlloc_5564_, 5, v_buckets_5552_);
lean_ctor_set(v_reuseFailAlloc_5564_, 6, v_products_5553_);
lean_ctor_set(v_reuseFailAlloc_5564_, 7, v_hashBits_5554_);
lean_ctor_set(v_reuseFailAlloc_5564_, 8, v_fst_5541_);
lean_ctor_set_uint8(v_reuseFailAlloc_5564_, sizeof(void*)*9, v_width_5547_);
v___x_5560_ = v_reuseFailAlloc_5564_;
goto v_reusejp_5559_;
}
v_reusejp_5559_:
{
lean_object* v___x_5562_; 
if (v_isShared_5545_ == 0)
{
lean_ctor_set(v___x_5544_, 1, v___x_5560_);
lean_ctor_set(v___x_5544_, 0, v___x_5558_);
v___x_5562_ = v___x_5544_;
goto v_reusejp_5561_;
}
else
{
lean_object* v_reuseFailAlloc_5563_; 
v_reuseFailAlloc_5563_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5563_, 0, v___x_5558_);
lean_ctor_set(v_reuseFailAlloc_5563_, 1, v___x_5560_);
v___x_5562_ = v_reuseFailAlloc_5563_;
goto v_reusejp_5561_;
}
v_reusejp_5561_:
{
return v___x_5562_;
}
}
}
}
}
else
{
lean_object* v_val_5568_; 
lean_dec_ref(v___x_5536_);
v_val_5568_ = lean_ctor_get(v_fst_5537_, 0);
lean_inc(v_val_5568_);
lean_dec_ref_known(v_fst_5537_, 1);
return v_val_5568_;
}
}
}
else
{
uint8_t v___x_5570_; lean_object* v___x_5571_; lean_object* v___x_5572_; lean_object* v___x_5574_; 
lean_dec(v___y_5514_);
lean_dec_ref(v_output_5511_);
lean_dec(v_maxWork_5495_);
lean_dec(v_multiplier_5492_);
v___x_5570_ = 4;
lean_inc(v_work_5504_);
v___x_5571_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5571_, 0, v_work_5504_);
lean_ctor_set_uint8(v___x_5571_, sizeof(void*)*1, v___x_5570_);
v___x_5572_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5572_, 0, v___x_5571_);
if (v_isShared_5519_ == 0)
{
lean_ctor_set(v___x_5518_, 1, v_initial_5490_);
lean_ctor_set(v___x_5518_, 0, v___x_5572_);
v___x_5574_ = v___x_5518_;
goto v_reusejp_5573_;
}
else
{
lean_object* v_reuseFailAlloc_5575_; 
v_reuseFailAlloc_5575_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5575_, 0, v___x_5572_);
lean_ctor_set(v_reuseFailAlloc_5575_, 1, v_initial_5490_);
v___x_5574_ = v_reuseFailAlloc_5575_;
goto v_reusejp_5573_;
}
v_reusejp_5573_:
{
return v___x_5574_;
}
}
}
else
{
uint8_t v___x_5576_; lean_object* v___x_5577_; lean_object* v___x_5578_; lean_object* v___x_5580_; 
lean_dec(v___x_5523_);
lean_dec(v___y_5514_);
lean_dec_ref(v_output_5511_);
lean_dec(v_maxWork_5495_);
lean_dec(v_multiplier_5492_);
v___x_5576_ = 7;
lean_inc(v_work_5504_);
v___x_5577_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5577_, 0, v_work_5504_);
lean_ctor_set_uint8(v___x_5577_, sizeof(void*)*1, v___x_5576_);
v___x_5578_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5578_, 0, v___x_5577_);
if (v_isShared_5519_ == 0)
{
lean_ctor_set(v___x_5518_, 1, v_initial_5490_);
lean_ctor_set(v___x_5518_, 0, v___x_5578_);
v___x_5580_ = v___x_5518_;
goto v_reusejp_5579_;
}
else
{
lean_object* v_reuseFailAlloc_5581_; 
v_reuseFailAlloc_5581_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5581_, 0, v___x_5578_);
lean_ctor_set(v_reuseFailAlloc_5581_, 1, v_initial_5490_);
v___x_5580_ = v_reuseFailAlloc_5581_;
goto v_reusejp_5579_;
}
v_reusejp_5579_:
{
return v___x_5580_;
}
}
}
}
v___jp_5584_:
{
uint8_t v___x_5589_; 
v___x_5589_ = lean_nat_dec_le(v___y_5587_, v___y_5588_);
if (v___x_5589_ == 0)
{
lean_dec(v___y_5588_);
v___y_5513_ = v___y_5585_;
v___y_5514_ = v___y_5586_;
v___y_5515_ = v___y_5587_;
goto v___jp_5512_;
}
else
{
lean_dec(v___y_5587_);
v___y_5513_ = v___y_5585_;
v___y_5514_ = v___y_5586_;
v___y_5515_ = v___y_5588_;
goto v___jp_5512_;
}
}
v___jp_5592_:
{
lean_object* v___x_5594_; uint8_t v___x_5595_; 
v___x_5594_ = lean_nat_mul(v___x_5591_, v___y_5593_);
lean_dec(v___x_5591_);
v___x_5595_ = lean_nat_dec_eq(v___x_5590_, v___x_5594_);
lean_dec(v___x_5594_);
if (v___x_5595_ == 0)
{
lean_dec_ref(v_output_5511_);
lean_dec_ref(v_products_5503_);
lean_dec(v_maxWork_5495_);
lean_dec(v_multiplier_5492_);
goto v___jp_5505_;
}
else
{
lean_object* v___x_5596_; lean_object* v___x_5597_; lean_object* v___x_5598_; uint8_t v___x_5599_; 
v___x_5596_ = lean_byte_array_size(v_metadata_5500_);
v___x_5597_ = lean_unsigned_to_nat(24u);
v___x_5598_ = lean_nat_mul(v_count_5501_, v___x_5597_);
v___x_5599_ = lean_nat_dec_eq(v___x_5596_, v___x_5598_);
lean_dec(v___x_5598_);
if (v___x_5599_ == 0)
{
lean_dec_ref(v_output_5511_);
lean_dec_ref(v_products_5503_);
lean_dec(v_maxWork_5495_);
lean_dec(v_multiplier_5492_);
goto v___jp_5505_;
}
else
{
lean_object* v___x_5600_; lean_object* v___x_5601_; lean_object* v___x_5602_; uint8_t v___x_5603_; 
v___x_5600_ = lean_unsigned_to_nat(4u);
v___x_5601_ = lean_nat_mod(v___x_5510_, v___x_5600_);
v___x_5602_ = lean_unsigned_to_nat(0u);
v___x_5603_ = lean_nat_dec_eq(v___x_5601_, v___x_5602_);
lean_dec(v___x_5601_);
if (v___x_5603_ == 0)
{
lean_dec_ref(v_output_5511_);
lean_dec_ref(v_products_5503_);
lean_dec(v_maxWork_5495_);
lean_dec(v_multiplier_5492_);
goto v___jp_5505_;
}
else
{
uint8_t v___x_5604_; 
v___x_5604_ = lean_nat_dec_le(v_count_5501_, v_multiplier_5492_);
if (v___x_5604_ == 0)
{
lean_object* v___x_5605_; lean_object* v___x_5606_; uint8_t v___x_5607_; 
v___x_5605_ = lean_nat_add(v___x_5590_, v___x_5596_);
v___x_5606_ = lean_byte_array_size(v_workspace_5502_);
v___x_5607_ = lean_nat_dec_eq(v_count_5501_, v___x_5602_);
if (v___x_5607_ == 0)
{
uint8_t v___x_5608_; 
v___x_5608_ = lean_nat_dec_lt(v___x_5602_, v_arity_5497_);
if (v___x_5608_ == 0)
{
v___y_5585_ = v___x_5605_;
v___y_5586_ = v___x_5602_;
v___y_5587_ = v___x_5606_;
v___y_5588_ = v___x_5602_;
goto v___jp_5584_;
}
else
{
lean_object* v___x_5609_; uint8_t v___x_5610_; 
v___x_5609_ = lean_unsigned_to_nat(4096u);
v___x_5610_ = lean_nat_dec_le(v_arity_5497_, v___x_5609_);
if (v___x_5610_ == 0)
{
v___y_5585_ = v___x_5605_;
v___y_5586_ = v___x_5602_;
v___y_5587_ = v___x_5606_;
v___y_5588_ = v___x_5602_;
goto v___jp_5584_;
}
else
{
lean_object* v___x_5611_; lean_object* v___x_5612_; lean_object* v___x_5613_; 
v___x_5611_ = lean_nat_mul(v_arity_5497_, v___x_5600_);
v___x_5612_ = lean_unsigned_to_nat(28u);
v___x_5613_ = lean_nat_add(v___x_5611_, v___x_5612_);
lean_dec(v___x_5611_);
v___y_5585_ = v___x_5605_;
v___y_5586_ = v___x_5602_;
v___y_5587_ = v___x_5606_;
v___y_5588_ = v___x_5613_;
goto v___jp_5584_;
}
}
}
else
{
v___y_5585_ = v___x_5605_;
v___y_5586_ = v___x_5602_;
v___y_5587_ = v___x_5606_;
v___y_5588_ = v___x_5602_;
goto v___jp_5584_;
}
}
else
{
uint8_t v___x_5614_; lean_object* v___x_5615_; lean_object* v___x_5616_; lean_object* v___x_5617_; 
lean_dec_ref(v_output_5511_);
lean_dec_ref(v_products_5503_);
lean_dec(v_maxWork_5495_);
lean_dec(v_multiplier_5492_);
v___x_5614_ = 1;
lean_inc(v_work_5504_);
v___x_5615_ = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(v___x_5615_, 0, v_work_5504_);
lean_ctor_set_uint8(v___x_5615_, sizeof(void*)*1, v___x_5614_);
v___x_5616_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5616_, 0, v___x_5615_);
v___x_5617_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_5617_, 0, v___x_5616_);
lean_ctor_set(v___x_5617_, 1, v_initial_5490_);
return v___x_5617_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_mapProducts___boxed(lean_object* v_initial_5621_, lean_object* v_support_5622_, lean_object* v_multiplier_5623_, lean_object* v_maxCount_5624_, lean_object* v_maxBytes_5625_, lean_object* v_maxWork_5626_, lean_object* v_native_5627_){
_start:
{
uint8_t v_native_boxed_5628_; lean_object* v_res_5629_; 
v_native_boxed_5628_ = lean_unbox(v_native_5627_);
v_res_5629_ = lp_Hex_Hex_Groebner_MonomialTable_mapProducts(v_initial_5621_, v_support_5622_, v_multiplier_5623_, v_maxCount_5624_, v_maxBytes_5625_, v_maxWork_5626_, v_native_boxed_5628_);
lean_dec(v_maxBytes_5625_);
lean_dec(v_maxCount_5624_);
lean_dec_ref(v_support_5622_);
return v_res_5629_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0(lean_object* v_multiplier_5630_, lean_object* v_maxCount_5631_, lean_object* v_maxBytes_5632_, lean_object* v_maxWork_5633_, uint8_t v_native_5634_, lean_object* v_support_5635_, lean_object* v_range_5636_, lean_object* v_b_5637_, lean_object* v_i_5638_, lean_object* v_hs_5639_, lean_object* v_hl_5640_){
_start:
{
lean_object* v___x_5641_; 
v___x_5641_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0___redArg(v_multiplier_5630_, v_maxCount_5631_, v_maxBytes_5632_, v_maxWork_5633_, v_native_5634_, v_support_5635_, v_range_5636_, v_b_5637_, v_i_5638_);
return v___x_5641_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0___boxed(lean_object* v_multiplier_5642_, lean_object* v_maxCount_5643_, lean_object* v_maxBytes_5644_, lean_object* v_maxWork_5645_, lean_object* v_native_5646_, lean_object* v_support_5647_, lean_object* v_range_5648_, lean_object* v_b_5649_, lean_object* v_i_5650_, lean_object* v_hs_5651_, lean_object* v_hl_5652_){
_start:
{
uint8_t v_native_boxed_5653_; lean_object* v_res_5654_; 
v_native_boxed_5653_ = lean_unbox(v_native_5646_);
v_res_5654_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_MonomialTable_mapProducts_spec__0(v_multiplier_5642_, v_maxCount_5643_, v_maxBytes_5644_, v_maxWork_5645_, v_native_boxed_5653_, v_support_5647_, v_range_5648_, v_b_5649_, v_i_5650_, v_hs_5651_, v_hl_5652_);
lean_dec_ref(v_range_5648_);
lean_dec_ref(v_support_5647_);
lean_dec(v_maxBytes_5644_);
lean_dec(v_maxCount_5643_);
return v_res_5654_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_combine(lean_object* v_table_5655_, uint8_t v_operation_5656_, lean_object* v_a_5657_, lean_object* v_b_5658_, lean_object* v_maxCount_5659_, lean_object* v_maxBytes_5660_, lean_object* v_maxWork_5661_){
_start:
{
uint8_t v___x_5662_; lean_object* v_outcome_5663_; lean_object* v_result_5664_; 
v___x_5662_ = 1;
v_outcome_5663_ = lp_Hex_Hex_Groebner_MonomialTable_combineOwned(v_table_5655_, v_operation_5656_, v_a_5657_, v_b_5658_, v_maxCount_5659_, v_maxBytes_5660_, v_maxWork_5661_, v___x_5662_);
v_result_5664_ = lean_ctor_get(v_outcome_5663_, 0);
lean_inc_ref(v_result_5664_);
if (lean_obj_tag(v_result_5664_) == 0)
{
lean_object* v_a_5665_; lean_object* v___x_5667_; uint8_t v_isShared_5668_; uint8_t v_isSharedCheck_5672_; 
lean_dec_ref(v_outcome_5663_);
v_a_5665_ = lean_ctor_get(v_result_5664_, 0);
v_isSharedCheck_5672_ = !lean_is_exclusive(v_result_5664_);
if (v_isSharedCheck_5672_ == 0)
{
v___x_5667_ = v_result_5664_;
v_isShared_5668_ = v_isSharedCheck_5672_;
goto v_resetjp_5666_;
}
else
{
lean_inc(v_a_5665_);
lean_dec(v_result_5664_);
v___x_5667_ = lean_box(0);
v_isShared_5668_ = v_isSharedCheck_5672_;
goto v_resetjp_5666_;
}
v_resetjp_5666_:
{
lean_object* v___x_5670_; 
if (v_isShared_5668_ == 0)
{
v___x_5670_ = v___x_5667_;
goto v_reusejp_5669_;
}
else
{
lean_object* v_reuseFailAlloc_5671_; 
v_reuseFailAlloc_5671_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5671_, 0, v_a_5665_);
v___x_5670_ = v_reuseFailAlloc_5671_;
goto v_reusejp_5669_;
}
v_reusejp_5669_:
{
return v___x_5670_;
}
}
}
else
{
lean_object* v_table_5673_; lean_object* v___x_5675_; uint8_t v_isShared_5676_; uint8_t v_isSharedCheck_5688_; 
v_table_5673_ = lean_ctor_get(v_outcome_5663_, 1);
v_isSharedCheck_5688_ = !lean_is_exclusive(v_outcome_5663_);
if (v_isSharedCheck_5688_ == 0)
{
lean_object* v_unused_5689_; 
v_unused_5689_ = lean_ctor_get(v_outcome_5663_, 0);
lean_dec(v_unused_5689_);
v___x_5675_ = v_outcome_5663_;
v_isShared_5676_ = v_isSharedCheck_5688_;
goto v_resetjp_5674_;
}
else
{
lean_inc(v_table_5673_);
lean_dec(v_outcome_5663_);
v___x_5675_ = lean_box(0);
v_isShared_5676_ = v_isSharedCheck_5688_;
goto v_resetjp_5674_;
}
v_resetjp_5674_:
{
lean_object* v_a_5677_; lean_object* v___x_5679_; uint8_t v_isShared_5680_; uint8_t v_isSharedCheck_5687_; 
v_a_5677_ = lean_ctor_get(v_result_5664_, 0);
v_isSharedCheck_5687_ = !lean_is_exclusive(v_result_5664_);
if (v_isSharedCheck_5687_ == 0)
{
v___x_5679_ = v_result_5664_;
v_isShared_5680_ = v_isSharedCheck_5687_;
goto v_resetjp_5678_;
}
else
{
lean_inc(v_a_5677_);
lean_dec(v_result_5664_);
v___x_5679_ = lean_box(0);
v_isShared_5680_ = v_isSharedCheck_5687_;
goto v_resetjp_5678_;
}
v_resetjp_5678_:
{
lean_object* v___x_5682_; 
if (v_isShared_5676_ == 0)
{
lean_ctor_set(v___x_5675_, 0, v_a_5677_);
v___x_5682_ = v___x_5675_;
goto v_reusejp_5681_;
}
else
{
lean_object* v_reuseFailAlloc_5686_; 
v_reuseFailAlloc_5686_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5686_, 0, v_a_5677_);
lean_ctor_set(v_reuseFailAlloc_5686_, 1, v_table_5673_);
v___x_5682_ = v_reuseFailAlloc_5686_;
goto v_reusejp_5681_;
}
v_reusejp_5681_:
{
lean_object* v___x_5684_; 
if (v_isShared_5680_ == 0)
{
lean_ctor_set(v___x_5679_, 0, v___x_5682_);
v___x_5684_ = v___x_5679_;
goto v_reusejp_5683_;
}
else
{
lean_object* v_reuseFailAlloc_5685_; 
v_reuseFailAlloc_5685_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_5685_, 0, v___x_5682_);
v___x_5684_ = v_reuseFailAlloc_5685_;
goto v_reusejp_5683_;
}
v_reusejp_5683_:
{
return v___x_5684_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MonomialTable_combine___boxed(lean_object* v_table_5690_, lean_object* v_operation_5691_, lean_object* v_a_5692_, lean_object* v_b_5693_, lean_object* v_maxCount_5694_, lean_object* v_maxBytes_5695_, lean_object* v_maxWork_5696_){
_start:
{
uint8_t v_operation_boxed_5697_; lean_object* v_res_5698_; 
v_operation_boxed_5697_ = lean_unbox(v_operation_5691_);
v_res_5698_ = lp_Hex_Hex_Groebner_MonomialTable_combine(v_table_5690_, v_operation_boxed_5697_, v_a_5692_, v_b_5693_, v_maxCount_5694_, v_maxBytes_5695_, v_maxWork_5696_);
lean_dec(v_maxBytes_5695_);
lean_dec(v_maxCount_5694_);
lean_dec(v_b_5693_);
lean_dec(v_a_5692_);
return v_res_5698_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_PackedWord(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Native(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexMvPoly_Mono(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_IndexPair(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_Monomial(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_PackedWord(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Native(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexMvPoly_Mono(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_IndexPair(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_Groebner_instInhabitedTermOrder_default = _init_lp_Hex_Hex_Groebner_instInhabitedTermOrder_default();
lp_Hex_Hex_Groebner_instInhabitedTermOrder = _init_lp_Hex_Hex_Groebner_instInhabitedTermOrder();
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_Monomial(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_PackedWord(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Native(uint8_t builtin);
lean_object* initialize_Hex_HexMvPoly_Mono(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_IndexPair(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_Monomial(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_PackedWord(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Native(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexMvPoly_Mono(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_IndexPair(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Monomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_Monomial(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_Monomial(builtin);
}
#ifdef __cplusplus
}
#endif
