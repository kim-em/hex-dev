from pathlib import Path
import shutil,subprocess,os,json
root=Path('/tmp/hex-groebner-zero-scan-dev');base=Path('/tmp/hex-groebner-zero-mutations');base.mkdir(exist_ok=False);results=[]
for name,needle in [('reserved','&& charged-col>=8 '),('active','last-col>=7 && ')]:
 p=base/name;p.mkdir();shutil.copytree(root/'HexGroebner/ffi',p/'ffi');f=p/'ffi/matrix_scan_impl.h';s=f.read_text();assert needle in s;s=s.replace(needle,'',1);f.write_text(s)
 script=(root/'scripts/ci/check_groebner_matrix.py').read_text();script=script.replace('ROOT = Path(__file__).resolve().parents[2]',f'ROOT = Path({str(root)!r})');script=script.replace('source = ROOT / "HexGroebner/ffi/matrix_scan.c"',f'source = Path({str(p/"ffi/matrix_scan.c")!r})');driver=p/'check.py';driver.write_text(script)
 env=dict(os.environ,HEX_GROEBNER_NATIVE_LOG_DIR=str(p/'native'),HEX_GROEBNER_REQUIRE_AVX2='1');log=p/'result.log'
 with log.open('w') as out:r=subprocess.run(['python3',str(driver)],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 text=log.read_text();assert r.returncode!=0 and 'compiled zero-scan reservation boundary mismatch' in text,(name,r.returncode,text[-3000:]);results.append({'mutant':name,'returncode':r.returncode,'expected_boundary_failure':True});print(results[-1],flush=True)
(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
