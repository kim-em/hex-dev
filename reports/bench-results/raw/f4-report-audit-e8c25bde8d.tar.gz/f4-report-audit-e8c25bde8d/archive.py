from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');name='f4-report-audit-e8c25bde8d';payload={}
def add(key,data):
 assert key not in payload,key
 payload[key]=data
checks=json.loads((state/'performance-pr19-strict-static-status.json').read_text());negative=json.loads((state/'performance-pr19-strict-negative.json').read_text());assert len(checks)==6 and all(x['exit_code']==0 for x in checks);assert len(negative)==12 and all(x['rejected'] for x in negative)
assert 'Build completed successfully' in (state/'performance-pr19-strict-build.log').read_text();assert (state/'performance-pr19-strict-driver.log').read_text().count('1134 complete corpus outputs/counters')==2
for p in sorted(state.glob('performance-pr19-strict-*')):
 if p.is_file() and p.suffix in ['.py','.json','.log']:add('validation/'+p.name,p.read_bytes())
for rel in ['scripts/bench/groebner_performance_audit.py','scripts/bench/check_groebner_performance_audit.py','scripts/bench/groebner_json.py','scripts/ci/check_groebner_driver.py']:
 add('source/'+rel,(root/rel).read_bytes())
current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();base='c3213aaea7cd182ca778ef117ff51f154a834344';add('source.patch',subprocess.check_output(['git','diff','--binary',base,current,'--','.',':!reports'],cwd=root));add('source-base.txt',(base+'\n').encode())
import sys
sys.path.insert(0,str(root));from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing,fingerprint
fp=fingerprint(tree_listing(FAMILY,current));assert fp=='8f56f7677ce6';add('identity.json',(json.dumps(dict(commit=current,runtime_source_fingerprint=fp,checks=dict(full_project='65884c900e',expanded_native_eight='ec583f66a7',strict_build_static_figure_checks=current,strict_driver_and_negative_checks='Exact scripts committed here were tested on staged content before this commit; complete logs retained.'),scope='Report-specific positive/negative audit and strict duplicate-key driver validation. Original timing samples are unchanged.'),indent=2)+'\n').encode());add('archive.py',Path(__file__).read_bytes());add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest() for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/'performance-pr19-strict-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
