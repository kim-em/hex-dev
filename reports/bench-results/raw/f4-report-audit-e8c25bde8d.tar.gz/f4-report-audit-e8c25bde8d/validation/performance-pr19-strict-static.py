from pathlib import Path
import json,subprocess,time,sys
root=Path.cwd();state=Path('/home/kim/tmp/issue-10987');results=[];commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
sys.path.insert(0,str(root));from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing,fingerprint
fp=fingerprint(tree_listing(FAMILY,commit));assert fp=='8f56f7677ce6'
commands=[('dag',['scripts/check_dag.py']),('phase4',['scripts/check_phase4.py']),('manifest',['scripts/release/check_released_manifest.py']),('headers',['scripts/check_copyright_headers.py']),('lines',['scripts/check_file_line_counts.py']),('report-audit',['scripts/bench/groebner_performance_audit.py','--combined',str(state/'combined-performance-production'),'--scan-cache',str(state/'scan-cache-production'),'--driver-output',str(state/'driver-output-production'),'--report','reports/bench-results/hexgroebner-combined-performance.md'])]
for name,args in commands:
 start=time.monotonic();log=state/('performance-pr19-strict-static-'+name+'.log')
 with log.open('w')as f:r=subprocess.run([str(state/'oracles/bin/python'),*args],stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=args,exit_code=r.returncode,seconds=time.monotonic()-start,source_commit=commit,source_fingerprint=fp,log=str(log)));(state/'performance-pr19-strict-static-status.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
