from pathlib import Path
import hashlib,io,json,lzma,tarfile
state=Path('/home/kim/tmp/issue-10987');root=state/'trie-format-production';payload={}
def add(name,path):
 assert name not in payload
 payload[name]=path.read_bytes()
for path in sorted(root.rglob('*')):
 if path.is_file() and 'binaries' not in path.relative_to(root).parts:
  add('trie-format/'+path.relative_to(root).as_posix(),path)
for name in ['measure-trie-format.py','pack-trie-format-science.py']:
 add('collectors/'+name,state/name)
manifest={k:hashlib.sha256(v).hexdigest()for k,v in sorted(payload.items())}
payload['sha256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
fp=json.loads((root/'manifest.json').read_text())['source_fingerprint'];out=state/f'f4-trie-format-{fp}.tar.xz'
with lzma.open(out,'wb',preset=6)as f,tarfile.open(fileobj=f,mode='w')as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('f4-trie-format/'+name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
print(out,len(manifest),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
