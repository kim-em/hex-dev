import Lake
open Lake DSL
package DigestChecks
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10987-projection-bench-before"
lean_exe check where
  root := `Check
