import HexGroebner.Bench.Projection
open Hex.Groebner.Bench

def main : IO Unit := do
  for n in [64, 65, 128, 129, 256, 257, 512, 513] do
    let input := prepareProjection n
    let actual := binaryProjection input
    if !actual.1 || actual != projectionSparse input then
      throw (IO.userError s!"invalid complete result at {n}")
    IO.println s!"{n},{hash actual}"
