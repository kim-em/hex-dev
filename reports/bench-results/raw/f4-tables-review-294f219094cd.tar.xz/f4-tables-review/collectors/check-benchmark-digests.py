from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path.cwd();kind=sys.argv[1];assert kind in ['projection','insertions'];s=Path('/home/kim/tmp/issue-10987');d=s/(kind+'-digest-checks');d.mkdir(exist_ok=False)
m=json.loads((s/'projection-bench-checks/lake-manifest.json').read_text());m['name']='DigestChecks';m['packagesDir']=str(root/'.lake/packages')
for p in m['packages']:
 if p['name']=='Hex':p['dir']=str(root)
(d/'lake-manifest.json').write_text(json.dumps(m,indent=2)+'\n');(d/'lean-toolchain').write_bytes((root/'lean-toolchain').read_bytes())
(d/'lakefile.lean').write_text('import Lake\nopen Lake DSL\npackage DigestChecks\nrequire Hex from '+json.dumps(str(root))+'\nlean_exe check where\n  root := `Check\n')
module,prep,function,sizes=('Projection','prepareProjection','binaryProjection',[64,65,128,129,256,257,512,513])if kind=='projection'else('Insertions','prepareInsertions','productInsertions',[64,65,256,257,1024,1025,4096,4097])
reference='projectionSparse'if kind=='projection'else'productInsertionsReference'
program=f'''import HexGroebner.Bench.{module}
open Hex.Groebner.Bench

def main : IO Unit := do
  for n in {sizes} do
    let input := {prep} n
    let actual := {function} input
    if !actual.1 || actual != {reference} input then
      throw (IO.userError s!"invalid complete result at {{n}}")
    IO.println s!"{{n}},{{hash actual}}"
'''
(d/'Check.lean').write_text(program)
env=dict(os.environ,LEAN_CC=str(s/'issue-10987-lean-cc'),TMPDIR=str(s),PATH='/nix/store/2msw5nclhpsm80z65dqmjiv8kkras989-clang-wrapper-21.1.8/bin:'+os.environ['PATH'])
with(d/'build.log').open('w')as f:r=subprocess.run(['lake','build','check'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
exe=d/'.lake/build/bin/check'
with(d/'run.stdout').open('w')as out,(d/'run.stderr').open('w')as err:r=subprocess.run([str(exe)],cwd=d,env=env,stdout=out,stderr=err)
assert r.returncode==0
values={int(row.split(',')[0]):int(row.split(',')[1])for row in(d/'run.stdout').read_text().splitlines()};assert list(values)==sizes
(d/'status.json').write_text(json.dumps(dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binary_sha256=hashlib.file_digest(exe.open('rb'),'sha256').hexdigest(),exit_code=r.returncode,kind=kind,sizes=sizes,digests=values),indent=2)+'\n');print(kind,'all complete digests independently validated',flush=True)
