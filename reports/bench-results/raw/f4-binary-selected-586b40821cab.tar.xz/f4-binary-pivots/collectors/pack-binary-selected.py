from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root))
from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();assert identity['source_fingerprint']=='586b40821cab';native=json.loads((s/'binary-selected-verified-native-status.json').read_text());native_identity={k:native[0][k]for k in identity};assert native_identity['source_fingerprint']=='e02434ca3804' and native_identity['checks_fingerprint']==identity['checks_fingerprint'];payload={}
def add(n,p):
 assert n not in payload,n
 payload[n]=p.read_bytes()
def tree(label,base):
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if p.is_file()and'binaries'not in rel.parts and p.suffix!='.data':add(label+'/'+str(rel),p)
tree('pivots',s/'binary-selected-production')
base=s/'binary-pivots-production'
for p in sorted(base.rglob('*')):
 rel=p.relative_to(base)
 if p.is_file()and'binaries'not in rel.parts and (rel.parts[0]in ['root-sources','compiler-inputs']or len(rel.parts)==1 and p.name in ['manifest.json','source.manifest','build.log','groebner_freeze.py']):add('baseline/'+str(rel),p)
text=tree_listing(CHECKS,identity['source_commit']);payload['checks.manifest']=text.encode()
for line in text.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for cc in ['clang','gcc']:
 add('native-'+cc+'.log',s/f'binary-selected-verified-{cc}.log')
 base=s/f'binary-selected-verified-{cc}'
 for p in sorted(base.rglob('*')):
  if p.is_file()and'.lake'not in p.relative_to(base).parts:add('probes/'+cc+'/'+str(p.relative_to(base)),p)
rows=json.loads((s/'binary-selected-verified-native-status.json').read_text());assert len(rows)==2 and all(r['exit_code']==0 and all(r[k]==v for k,v in native_identity.items())for r in rows);add('native-status.json',s/'binary-selected-verified-native-status.json')
for pattern in ['*binary-selected*.py','binary-selected*.log','binary-selected*-status.json','binary-bench*.log','binary-documented*.py','binary-documented*.log','binary-documented*-status.json']:
 for p in sorted(s.glob(pattern)):
  n='collectors/'+p.name
  if n not in payload:add(n,p)
rows=json.loads((s/'binary-documented-full-status.json').read_text());assert len(rows)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in rows);add('full-status.json',s/'binary-documented-full-status.json')
for row in rows:add('full/'+row['name']+'.log',Path(row['log']))
payload['scope.txt']=b'Packed F2 selected kernel: native checks bind e02434ca3804; nine project gates bind586b40821cab. Only the adjacent sparse-benchmark cost comment differs between these source snapshots. Both timed compute executables are byte-identical to a45acb9da3a9. All twelve native variants and all nine project checks pass under those recorded snapshots. This capsule retains both kernel passes and both selected-binary msolve comparisons. F4 before/after samples and their single unchanged repeats are retained in the linked initial, word-cursor and zero-block capsules. No fastest-open-source claim.\n'
from scripts.bench.groebner_measure import FAMILY
current=tree_listing(FAMILY,identity['source_commit']);payload['current.source.manifest']=current.encode()
for line in current.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['current-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
payload['native-identity.json']=(json.dumps(native_identity,indent=2)+'\n').encode()
add('failed-before-cost-comment-status.json',s/'binary-selected-full-status.json')
add('failed-before-cost-comment.log',s/'binary-selected-full-phase4.log')
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode()
payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode()
out=s/('f4-binary-selected-'+identity['source_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-binary-pivots/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
