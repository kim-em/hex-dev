from pathlib import Path
import os,subprocess
state=Path('/home/kim/tmp/issue-10987');base=state/'binary-selected-production';msolve=state/'msolve-current'
command=[str(state/'oracles/bin/python'),'scripts/bench/groebner_cli_measure.py','--manifest',str(base/'manifest.json'),'--suite',str(state/'binary-canonical-suite/suite.json'),'--hex-scheduling','degree','--hex-dense-pivots','false','--hex-binary-pivots','true','--hex',str(base/'binaries/compute'),'--msolve',str(msolve/'.libs/msolve'),'--msolve-source',str(msolve),'--msolve-mode','2','--output',str(base/'msolve-f2')]
env=dict(os.environ,PATH='/nix/store/lil41pyqlrihhl0yzqh4cz9c9ravn4r2-singular-4.4.1/bin:'+str(state/'oracles/bin')+':'+os.environ['PATH'])
result=subprocess.run(command,env=env);(base/'measure-msolve-f2.py').write_bytes(Path(__file__).read_bytes());raise SystemExit(result.returncode)
