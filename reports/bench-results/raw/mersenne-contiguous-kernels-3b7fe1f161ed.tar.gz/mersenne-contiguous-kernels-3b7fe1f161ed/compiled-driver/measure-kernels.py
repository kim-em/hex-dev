import hashlib,json,os,pathlib,resource,subprocess,sys,time
sys.path.insert(0,'/tmp/hex-groebner-mersenne-contiguous-dev')
from scripts.bench.cpu_lease import cpu_lease
base=pathlib.Path('/tmp/hex-groebner-mersenne-contiguous-production');record=json.loads((base/'binaries/manifest.json').read_text());fp=record['source_fingerprint'];out=base/('mersenne-contiguous-kernels-'+fp);out.mkdir(exist_ok=False)
binaries={'A':pathlib.Path('/tmp/hex-groebner-mersenne-production/binaries/hexgroebner-bench-mersenne-baseline'),'B':base/'binaries/hexgroebner-bench-mersenne-contiguous'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
m=dict(source_fingerprint=fp,source_manifest=record['source_manifest'],baseline_source_fingerprint=json.loads((pathlib.Path('/tmp/hex-groebner-mersenne-production/binaries/baseline-manifest.json')).read_text())['source_fingerprint'],baseline_source_manifest=json.loads((pathlib.Path('/tmp/hex-groebner-mersenne-production/binaries/baseline-manifest.json')).read_text())['source_manifest'],cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),binary_sha256={a:sha(p) for a,p in binaries.items()},schedule='per case full declared custom ladder64/128/256/512, adjacent AB then BA, three fixed trial-major outer trials with4sec inner target and32sec call cap',contract='original exact Montgomery accumulation vs exact Mersenne31 folded-product accumulation only for contiguous updates at p2147483647; scattered updates retain exact Montgomery; Cauchy64/128/256/512 dense with eight-lane exact AVX2 updates and even-column strided, full decoded result hashes; preparation excluded, finite-size kernel observations only, no complexity-fit claim; every completed sample retained',script=pathlib.Path(__file__).read_text(),runs=[])
def limits():resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2)
try:
 for block,order in enumerate(['AB','BA']):
  for case in ['cauchy31','cauchy31Strided']:
   for arm in order:
    prefix=f'{case}-b{block}-{arm}';cmd=[str(binaries[arm]),'run','Hex.Groebner.Bench.'+case,'--outer-trials','3','--export-file',str(out/(prefix+'.json'))];print(prefix,flush=True);start=time.monotonic_ns()
    with (out/(prefix+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
    m['runs'].append(dict(case=case,block=block,arm=arm,command=cmd,returncode=r.returncode,wall_nanos=time.monotonic_ns()-start))
finally:
 m['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(m,indent=2)+'\n');lease.close()
