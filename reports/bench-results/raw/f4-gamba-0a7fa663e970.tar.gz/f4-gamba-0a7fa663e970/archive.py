from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-symbolic');payload={};name='f4-gamba-0a7fa663e970'
def add(key,data):
 assert key not in payload,key
 payload[key]=data
for directory in ['gamba-medium-avx2','gamba-medium-avx512']:
 for path in sorted((state/directory).rglob('*')):
  if path.is_file():add(directory+'/'+str(path.relative_to(state/directory)),path.read_bytes())
for relative in ['gamba-measure.py','gamba-binaries.json','gamba-current-release.json','gamba-current-clone.log','gamba-avx2-help.txt','gamba-avx512-help.txt','gamba-avx2-download.log','gamba-avx512-download.log','gamba-smoke-cyclic7-15.basis','gamba-smoke-cyclic7-15.log','gamba-smoke-cyclic7-15.json','issue-10987-lean-cc','issue-10987-lean-cc-flags.json']:
 add('reproduction/'+relative,(state/relative).read_bytes())
for isa in ['avx2','avx512']:add('gamba-'+isa+'/LICENSES.txt',(state/f'gamba-{isa}/gamba-0.3/LICENSES.txt').read_bytes())
base=state/'equivalence-final-production'
for path in sorted(base.rglob('*')):
 if path.is_file()and path.relative_to(base).parts[0]!='binaries':add('hex/'+str(path.relative_to(base)),path.read_bytes())
m=json.loads((base/'manifest.json').read_text());base_commit='1420b84ce3aa2e48781f11244dc51a5b504c090b';add('hex/source.patch',subprocess.check_output(['git','diff','--binary',base_commit,m['source_snapshot'],'--','.',':!reports'],cwd=root));add('hex/source-base.txt',(base_commit+'\n').encode());add('gamba-public-source.tar',subprocess.check_output(['git','archive','HEAD'],cwd=state/'gamba-current'));add('archive.py',Path(__file__).read_bytes())
add('sha256.json',(json.dumps({key:hashlib.sha256(data).hexdigest()for key,data in payload.items()},indent=2,sort_keys=True)+'\n').encode())
out=root/'reports/bench-results/raw'/f'{name}.tar.gz'
with out.open('xb')as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as zipped,tarfile.open(fileobj=zipped,mode='w')as archive:
 for key,data in sorted(payload.items()):
  info=tarfile.TarInfo(name+'/'+key);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out)as archive:
 for key,data in payload.items():assert archive.extractfile(name+'/'+key).read()==data
result=dict(path=str(out),sha256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),payloads=len(payload),bytes=out.stat().st_size);(state/'gamba-archive-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
