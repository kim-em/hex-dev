from pathlib import Path
import ctypes,hashlib,importlib.util,json,math,os,resource,select,signal,subprocess,sys,time
state=Path('/home/kim/tmp/issue-10987');root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987-equivalence');base=state/'equivalence-final-production';isa=sys.argv[1]
assert isa in ['avx2','avx512'];out=state/('gamba-medium-'+isa);out.mkdir(exist_ok=False)
sys.path.insert(0,str(root));from scripts.oracle.groebner_singular import polynomial,canonical,expression
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import tree_listing,fingerprint,index_listing
manifest=json.loads((base/'manifest.json').read_text());assert tree_listing(FAMILY,'921d4d7a2466c12995f2f87faf78eae7dbd593b4')==manifest['source_manifest'];assert index_listing(FAMILY)==manifest['source_manifest']
helper=base/'root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('frozen_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
receipt=next(r for r in json.loads((state/'gamba-binaries.json').read_text())if r['isa']==isa);binary=Path(receipt['binary']);hex=base/'binaries/compute';assert sha(binary)==receipt['binary_sha256'];assert sha(hex)==manifest['binary_sha256']['compute']
inputs=out/'inputs';inputs.mkdir();suite=state/'final-products-production/medium-inputs/suite.json';plan=json.loads(suite.read_text());(inputs/'suite.json').write_bytes(suite.read_bytes())
for case in plan['cases']:
 for extension in ['json','ms']:
  name=case['name']+'.'+extension;(inputs/name).write_bytes((suite.parent/name).read_bytes())
 payload=json.loads((inputs/(case['name']+'.json')).read_text());assert payload['order']=='grevlex'and(payload['p'],payload['variables'])==(case['p'],case['variables'])
 lines=(inputs/(case['name']+'.ms')).read_text().splitlines();assert lines[0].split(',')==[f'x{i}'for i in range(case['variables'])];assert int(lines[1])==case['p']
 observed=[polynomial(t,case['variables'],case['p'])for t in ''.join(lines[2:]).split(',')if t.strip()];expected=[polynomial(expression(f),case['variables'],case['p'])for f in payload['generators']];assert[f for f in observed if f]==[f for f in expected if f]
cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});time_binary=Path('/run/current-system/sw/bin/time');version=subprocess.check_output([str(time_binary),'--version'],text=True);assert'GNU'in version
libc=ctypes.CDLL(None,use_errno=True);libc.pidfd_open.argtypes=[ctypes.c_int,ctypes.c_uint];libc.pidfd_open.restype=ctypes.c_int
metadata=dict(hex_manifest=manifest,gamba_receipt=receipt,gamba_release=json.loads((state/'gamba-current-release.json').read_text()),gamba_public_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=state/'gamba-current',text=True).strip(),gamba_fully_open_source=False,gamba_build='Official opaque vendor binary; public checkout is incomplete and cannot reproduce it. No compiler flags or probability guarantee inferred.',cpu=cpu,threads=1,seed=10987,host=os.uname().nodename,host_cpu=subprocess.check_output(['lscpu','-J'],text=True),load_start=os.getloadavg(),contract='Fixed 14-input development corpus; full unchecked monic reduced bases in native output formats, candidate production through final interreduction/output. Hex deterministic, GamBa Monte Carlo with explicit seed 10987. Both request one thread and run on one leased CPU. Identical GNU-time wrappers and 60-second/16-GiB/64-MiB-per-file resource limits. GamBa uses the recorded dynamic loader/library path. Startup, input and all output are timed; complete basis comparison is outside timing. No certificate generation, independent final certification or kernel checking is included. Adjacent AB then BA per input; all completed samples, variability and failures retained; no filtering or unchanged repeat. GamBa is an overall comparator, not eligible for fastest-fully-open-source acceptance. No held-out or acceptance claim.',schedule=['AB','BA'],protocol=plan['protocol'],input_sha256={p.name:sha(p)for p in sorted(inputs.iterdir())},time_version=version,time_sha256=sha(time_binary.resolve()),cpu_helper_sha256=sha(helper),script=Path(__file__).read_text(),samples=[])
metadata['loader_sha256']=sha(receipt['loader']);metadata['library_files']={str(p):sha(p)for directory in receipt['library_path'].split(':')for name in ['libc.so.6','libm.so.6','libgcc_s.so.1','libpthread.so.0','librt.so.1']if(p:=Path(directory)/name).is_file()}
cliargs=['--work','100000000000','--packed-bytes',str(16*1024**3),'--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000','--scheduling','degree']
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');metadata['child_environment']={k:v for k,v in env.items()if k in ['LD_LIBRARY_PATH','LD_PRELOAD','LANG','LC_ALL','TZ','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']}
def limits():
 os.setsid();resource.setrlimit(resource.RLIMIT_AS,(plan['protocol']['address_space_bytes'],)*2);resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,)*2)
try:
 for block,order in enumerate(['AB','BA']):
  for case in plan['cases']:
   bases={}
   for arm in order:
    prefix=f"{case['name']}-b{block}-{arm}";rss=out/(prefix+'.rss');basisfile=out/(prefix+'.basis')
    program=[str(hex),*cliargs,str(inputs/(case['name']+'.json'))]if arm=='A'else[receipt['loader'],'--library-path',receipt['library_path'],str(binary),'-d','grevlex','-s','10987','-t','1','-v','2','-i',str(inputs/(case['name']+'.ms')),'-o',str(basisfile)]
    command=[str(time_binary),'-f','%M','-o',str(rss),*program];start=time.monotonic_ns();timeout=False
    with(out/(prefix+'.stdout')).open('wb')as stdout,(out/(prefix+'.stderr')).open('wb')as stderr:
     proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env,preexec_fn=limits);fd=libc.pidfd_open(proc.pid,0)
     if fd<0:raise OSError(ctypes.get_errno(),'pidfd_open')
     try:
      ready,_,_=select.select([fd],[],[],plan['protocol']['timeout_seconds'])
      if not ready:timeout=True;os.killpg(proc.pid,signal.SIGKILL)
      _,status,_=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status)
     finally:os.close(fd)
    elapsed=time.monotonic_ns()-start;record=dict(case=case['name'],family=case['family'],p=case['p'],block=block,arm=arm,command=command,wall_nanos=elapsed,status='timeout'if timeout else'ok'if proc.returncode==0 else'failed',returncode=proc.returncode,peak_rss_kib=int(rss.read_text().splitlines()[-1])if rss.exists()and rss.read_text().splitlines()[-1].isdigit()else None)
    if proc.returncode==0:
     try:
      if arm=='A':
       payload=json.loads((out/(prefix+'.stdout')).read_text());assert payload['kind']=='unchecked_candidate'and payload['p']==case['p']and payload['variables']==case['variables']and payload['order']=='grevlex'and payload['scheduling']=='degree';bases[arm]=canonical(payload['basis']);record['statistics']={**payload['statistics'],'candidate_nanos':payload['candidateNanos']}
      else:
       lines=basisfile.read_text().splitlines();assert[x for x in lines[0].split(',')if x]==[f'x{i}'for i in range(case['variables'])];assert int(lines[1])==case['p'];bases[arm]=canonical([polynomial(t,case['variables'],case['p'])for t in ''.join(lines[2:]).split(',')if t.strip()])
     except(ValueError,KeyError,AssertionError,IndexError,OSError)as error:record.update(status='invalid_output',error=str(error));bases.pop(arm,None)
    metadata['samples'].append(record);print(prefix,record['status'],round(elapsed/1e6,3),flush=True)
   equal=len(bases)==2 and bases['A']==bases['B']
   for sample in metadata['samples'][-2:]:sample['complete_basis_equal']=equal
finally:
 metadata.update(load_end=os.getloadavg(),hex_sha256_after=sha(hex),gamba_sha256_after=sha(binary),source_fingerprint_after=fingerprint(index_listing(FAMILY)));assert sha(hex)==manifest['binary_sha256']['compute']and sha(binary)==receipt['binary_sha256'];assert index_listing(FAMILY)==manifest['source_manifest'];(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');lease.close()
samples=metadata['samples'];pairs=[]
for case in plan['cases']:
 for block in range(2):
  rows={s['arm']:s for s in samples if s['case']==case['name']and s['block']==block}
  if all(s['status']=='ok'and s['complete_basis_equal']for s in rows.values())and len(rows)==2:pairs.append(dict(case=case['name'],family=case['family'],ratio=rows['A']['wall_nanos']/rows['B']['wall_nanos']))
families={family:math.exp(sum(math.log(p['ratio'])for p in pairs if p['family']==family)/sum(p['family']==family for p in pairs))for family in sorted({p['family']for p in pairs})};analysis=dict(samples=len(samples),successful_processes=sum(s['status']=='ok'for s in samples),timeouts=sum(s['status']=='timeout'for s in samples),failures=sum(s['status']not in ['ok','timeout']for s in samples),complete_basis_pairs=len(pairs),ratio_direction='Hex/GamBa whole-process',per_family=families,family_balanced_geomean=math.exp(sum(map(math.log,families.values()))/len(families))if families else None,pairs=pairs,peak_rss_kib={arm:max((s['peak_rss_kib']or 0)for s in samples if s['arm']==arm)for arm in 'AB'},coverage_complete=len(pairs)==2*len(plan['cases']))
(out/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n');print(json.dumps(analysis),flush=True)
