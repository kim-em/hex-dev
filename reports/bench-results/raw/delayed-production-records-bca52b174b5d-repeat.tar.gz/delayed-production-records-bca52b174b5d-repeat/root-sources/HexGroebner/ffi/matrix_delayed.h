/* Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
   Released under Apache 2.0 license as described in the file LICENSE.
   Authors: Kim Morrison */
/* Included after the ordinary matrix helpers. Dense slots use exact u64 sums;
   sparse coefficient widths remain 1/2/4 bytes. No alignment is assumed. */
static inline uint64_t delayed_read(const uint8_t *p) {
    return rd(p,4) | (rd(p+4,4)<<32);
}
static inline void delayed_write(uint8_t *p,uint64_t v) {
    wr(p,4,v);wr(p+4,4,v>>32);
}
static inline uint64_t delayed_reduce(uint64_t value,uint64_t p,uint64_t reciprocal) {
    if(value<p) return value;
#if defined(__SIZEOF_INT128__) && !defined(HEX_GROEBNER_NO_UINT128)
    uint64_t q=(uint64_t)(((__uint128_t)value*reciprocal)>>64);
    value-=q*p;
    if(value>=p) value-=p;
    return value;
#else
    (void)reciprocal;
    return value%p;
#endif
}
static inline int delayed_update(uint8_t *data,const uint8_t *cs,const uint8_t *vs,
        unsigned w,uint64_t columns,uint64_t entry,uint64_t p,uint64_t factor,uint64_t reciprocal) {
    uint64_t j=rd(cs+(size_t)entry*4,4),b=rd(vs+(size_t)entry*w,w);
    if(j>=columns || !b || b>=p || (entry && rd(cs+(size_t)(entry-1)*4,4)>=j)) return 0;
    uint64_t a=delayed_read(data+(size_t)j*8);
    uint64_t product=factor*(p-b);
    if(a>UINT64_MAX-product) a=delayed_reduce(a,p,reciprocal);
    delayed_write(data+(size_t)j*8,a+product);
    return 1;
}

LEAN_EXPORT lean_obj_res lean_hex_delayed_scan_transition(uint64_t p,
        b_lean_obj_arg slots,b_lean_obj_arg pivots,lean_obj_arg initial,
        b_lean_obj_arg quantum_arg,b_lean_obj_arg work_arg,b_lean_obj_arg trace_arg,
        uint8_t provenance) {
    unsigned w=p<=256?1:p<=65536?2:4;
    lean_object *dense=lean_ctor_get(initial,0);
    size_t db=lean_sarray_size(dense), count=lean_array_size(pivots);
    uint64_t columns=db/8;
    uint64_t quantum=bounded_nat(quantum_arg,4097);
    uint64_t col=bounded_nat(lean_ctor_get(initial,1),UINT64_C(4294967296));
    uint64_t last=bounded_nat(lean_ctor_get(initial,2),UINT64_C(4294967296));
    uint64_t charged=bounded_nat(lean_ctor_get(initial,3),UINT64_C(4294967296));
    uint64_t leading=bounded_nat(lean_ctor_get(initial,4),UINT64_C(4294967296));
    uint64_t pending=bounded_nat(lean_ctor_get(initial,5),UINT64_C(4294967296));
    uint64_t entry=bounded_nat(lean_ctor_get(initial,6),UINT64_C(4294967296));
    uint64_t factor=lean_ctor_get_uint64(initial,8*sizeof(void*));
    if(p<2 || p>=UINT64_C(2147483648) || quantum>4096 || db%8 ||
       columns>UINT32_MAX || columns>SIZE_MAX/4 || lean_sarray_size(slots)!=columns*4 ||
       col>columns || (columns && last>=columns) || leading>columns ||
       pending>count || count>UINT32_MAX || charged>columns || entry>UINT32_MAX ||
       (!pending && entry) || (pending && col>=columns) || (!columns && last) || factor>=p)
        return result(initial,lean_alloc_array(0,0),0,0,0,4);
    uint64_t work_limit=bounded_nat(work_arg,UINT64_C(1)<<45);
    uint64_t trace_limit=bounded_nat(trace_arg,4096);
    uint64_t event_capacity=quantum<trace_limit?quantum:trace_limit;
    if(event_capacity>8) event_capacity=8;
    lean_object *events=lean_alloc_array(0,provenance?(size_t)event_capacity:0);
    lean_object *sugar=lean_ctor_get(initial,7);
    lean_inc(dense);lean_inc(sugar);
    lean_object *alias=NULL;
    if(dense==slots) {alias=dense;lean_inc(alias);}
    lean_dec(initial);
    dense=lean_sarray_ensure_exclusive(dense);
    uint8_t *data=lean_sarray_cptr(dense);
    const uint8_t *slot_bytes=lean_sarray_cptr(slots);
    uint64_t work=0,reductions=0,traces=0;
    uint8_t status=0;
    uint64_t reciprocal=0;
#if defined(__SIZEOF_INT128__) && !defined(HEX_GROEBNER_NO_UINT128)
    reciprocal=UINT64_MAX/p;if(UINT64_MAX%p==p-1) ++reciprocal;
#endif
    for(uint64_t tick=0;tick<quantum;++tick) {
        if(pending) {
            lean_object *pivot=lean_array_cptr(pivots)[pending-1];
            uint64_t size;
            if(!geometry(pivot,w,&size) || entry>size) {status=4;break;}
            if(entry==size) {
                if(delayed_reduce(delayed_read(data+(size_t)col*8),p,reciprocal)) {status=4;break;}
                ++reductions;
                if(provenance) {
                    if(traces>=trace_limit) {status=3;break;}
                    lean_object *event=lean_alloc_ctor(0,2,0);
                    lean_ctor_set(event,0,lean_uint64_to_nat(pending-1));
                    lean_ctor_set(event,1,lean_box_uint64(factor));
                    events=lean_array_push(events,event);++traces;
                }
                delayed_write(data+(size_t)col*8,0);
                pending=0;entry=0;++col;
            } else {
                const uint8_t *cs=lean_sarray_cptr(lean_ctor_get(pivot,0));
                const uint8_t *vs=lean_sarray_cptr(lean_ctor_get(pivot,1));
                uint64_t updates=size-entry;
                if(updates>quantum-tick) updates=quantum-tick;
                {
                    for(uint64_t k=0;k<updates;++k) {
                        if(!delayed_update(data,cs,vs,w,columns,entry,p,factor,reciprocal)) {status=4;break;}
                        ++entry;
                    }
                }
                if(status==4) break;
                tick+=updates-1;
            }
        } else {
            if(col>=columns || col>last) {status=1;break;}
            if(col>=charged) {
                uint64_t stop=col+64<last+1?col+64:last+1;
                uint64_t charge=stop-col;
                if(work+charge>work_limit) {status=2;break;}
                work+=charge;charged=stop;
            }
            uint64_t a=delayed_reduce(delayed_read(data+(size_t)col*8),p,reciprocal);
            uint64_t slot=rd(slot_bytes+(size_t)col*4,4);
            if(!a || !slot) {
                if(!a) delayed_write(data+(size_t)col*8,0);
                if(a && !leading) leading=col+1;
                ++col;
            }
            else {
                if(slot>count) {status=4;break;}
                lean_object *pivot=lean_array_cptr(pivots)[slot-1];
                uint64_t size;
                if(!geometry(pivot,w,&size)) {status=4;break;}
                const uint8_t *cs=lean_sarray_cptr(lean_ctor_get(pivot,0));
                const uint8_t *vs=lean_sarray_cptr(lean_ctor_get(pivot,1));
                if(rd(cs,4)!=col || rd(vs,w)!=1) {status=4;break;}
                uint64_t end=rd(cs+(size_t)(size-1)*4,4);
                if(end>=columns) {status=4;break;}
                if(end>last) last=end;
                lean_object *label=lean_ctor_get(pivot,2);
                if(lean_nat_dec_lt(sugar,label)) {lean_inc(label);lean_dec(sugar);sugar=label;}
                if(work+size>work_limit) {status=2;break;}
                work+=size;pending=slot;entry=0;factor=a;
            }
        }
    }
    if(alias) lean_dec(alias);
    lean_object *state=lean_alloc_ctor(0,8,8);
    lean_ctor_set(state,0,dense);lean_ctor_set(state,1,lean_uint64_to_nat(col));
    lean_ctor_set(state,2,lean_uint64_to_nat(last));lean_ctor_set(state,3,lean_uint64_to_nat(charged));
    lean_ctor_set(state,4,lean_uint64_to_nat(leading));lean_ctor_set(state,5,lean_uint64_to_nat(pending));
    lean_ctor_set(state,6,lean_uint64_to_nat(entry));lean_ctor_set(state,7,sugar);
    lean_ctor_set_uint64(state,8*sizeof(void*),factor);
    return result(state,events,work,reductions,traces,status);
}

LEAN_EXPORT lean_obj_res lean_hex_delayed_gather(uint64_t p,lean_obj_arg initial,
        b_lean_obj_arg stop_arg,b_lean_obj_arg quantum_arg,b_lean_obj_arg entries_arg,
        b_lean_obj_arg bytes_arg,b_lean_obj_arg work_arg,uint64_t factor) {
    unsigned w=p<=256?1:p<=65536?2:4;
    lean_object *dense=lean_ctor_get(initial,0),*cols=lean_ctor_get(initial,1),*coeff=lean_ctor_get(initial,2);
    size_t db=lean_sarray_size(dense),cb=lean_sarray_size(cols),vb=lean_sarray_size(coeff);
    uint64_t size=db/8,stop=bounded_nat(stop_arg,UINT64_C(4294967296));
    uint64_t cursor=bounded_nat(lean_ctor_get(initial,3),UINT64_C(4294967296));
    uint64_t quantum=bounded_nat(quantum_arg,4097);
    if(p<2 || p>=UINT64_C(2147483648) || !factor || factor>=p || quantum>4096 || db%8 ||
       size>UINT32_MAX || cursor>stop || stop>size || cb%4 || vb!=(cb/4)*w)
        return gather_result(initial,0,0,0,5);
    uint64_t entries_limit=bounded_nat(entries_arg,4096),bytes_limit=bounded_nat(bytes_arg,32768);
    uint64_t work_limit=bounded_nat(work_arg,4096);
    lean_inc(dense);lean_inc(cols);lean_inc(coeff);lean_dec(initial);
    dense=lean_sarray_ensure_exclusive(dense);
    /* Output aliases retain their original data until append_scalar copies. */
    uint8_t *data=lean_sarray_cptr(dense);
    uint64_t entries=0,bytes=0,work=0;uint8_t status=0;
    uint64_t reciprocal=0;
#if defined(__SIZEOF_INT128__) && !defined(HEX_GROEBNER_NO_UINT128)
    reciprocal=UINT64_MAX/p;if(UINT64_MAX%p==p-1) ++reciprocal;
#endif
    for(uint64_t tick=0;tick<quantum;++tick) {
        if(cursor>=stop) {status=1;break;}
        uint64_t a=delayed_reduce(delayed_read(data+(size_t)cursor*8),p,reciprocal);
        if(a) {
            size_t cn=lean_sarray_size(cols),vn=lean_sarray_size(coeff);
            if(cn && rd(lean_sarray_cptr(cols)+cn-4,4)>=cursor) {status=6;break;}
            if(entries>=entries_limit) {status=2;break;}++entries;
            if(bytes+4+w>bytes_limit) {status=3;break;}bytes+=4+w;
            if(cn>SIZE_MAX-4 || vn>SIZE_MAX-w) {status=5;break;}
            if(factor!=1) {if(work>=work_limit) {status=4;break;}++work;}
            uint64_t value=a;
            if(factor!=1) value=delayed_reduce(a*factor,p,reciprocal);
            cols=append_scalar(cols,4,cursor);coeff=append_scalar(coeff,w,value);
            delayed_write(data+(size_t)cursor*8,0);
        } else delayed_write(data+(size_t)cursor*8,0);
        ++cursor;
    }
    lean_object *state=lean_alloc_ctor(0,4,0);
    lean_ctor_set(state,0,dense);lean_ctor_set(state,1,cols);lean_ctor_set(state,2,coeff);
    lean_ctor_set(state,3,lean_uint64_to_nat(cursor));
    return gather_result(state,entries,bytes,work,status);
}
