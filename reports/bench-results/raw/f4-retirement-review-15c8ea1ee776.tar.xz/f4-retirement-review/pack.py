from pathlib import Path
import hashlib,io,json,lzma,subprocess,sys,tarfile
root=Path.cwd();s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(root));from scripts.bench.groebner_checks import CHECKS,source_identity
from scripts.bench.sweep_freshness import tree_listing
identity=source_identity();rows=json.loads((s/'retirement-reviewed-full-status.json').read_text());assert len(rows)==9 and all(r['exit_code']==0 and all(r[k]==v for k,v in identity.items())for r in rows);payload={}
def add(n,p):assert n not in payload;payload[n]=p.read_bytes()
base=s/'retirement-final-production'
for p in sorted(base.rglob('*')):
 if p.is_file()and'binaries'not in p.relative_to(base).parts:add('current/'+str(p.relative_to(base)),p)
text=tree_listing(CHECKS,identity['source_commit']);payload['checks.manifest']=text.encode()
for line in text.splitlines():
 _,oid,rest=line.split(' ',2);_,path=rest.split('\t');payload['checks-sources/'+path]=subprocess.check_output(['git','cat-file','blob',oid])
for row in rows:add('full/'+row['name']+'.log',Path(row['log']))
for p in sorted((s/'retirement-review-audit').iterdir()):
 if p.is_file():add('mutation/'+p.name,p)
for name,path in [('full-status.json',s/'retirement-reviewed-full-status.json'),('full-collector.py',s/'retirement-reviewed-full-checks.py'),('mutation/collector.py',s/'check-retirement-review-mutants.py'),('pack.py',Path(__file__))]:add(name,path)
payload['identity.json']=(json.dumps(identity,indent=2)+'\n').encode();payload['sha256.json']=(json.dumps({n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())},indent=2)+'\n').encode();out=root/'reports/bench-results/raw'/('f4-retirement-review-'+identity['checks_fingerprint']+'.tar.xz');assert not out.exists()
with lzma.open(out,'wb',preset=6)as stream,tarfile.open(fileobj=stream,mode='w')as tar:
 for n,b in sorted(payload.items()):
  e=tarfile.TarInfo('f4-retirement-review/'+n);e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
print(out,len(payload)-1,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
