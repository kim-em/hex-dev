from pathlib import Path
import os,json,subprocess,hashlib,sys,time
root=Path('/tmp/hex-groebner-packed-targets-dev');sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
out=Path(__file__).resolve().parent;cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
binaries={'A':Path('/tmp/hex-groebner-scheduling-strengthened-production/binaries/compute'),'B':Path('/tmp/hex-groebner-packed-targets-reviewed-production/binaries/compute')}
inputs={'eco10-15':Path('/tmp/hex-groebner-packed-targets-reviewed-production/before-after-small/inputs/eco10-15.json'),'eco11-31':Path('/tmp/hex-groebner-packed-targets-reviewed-production/before-after-medium/inputs/eco11-31.json')}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),binary_sha256={k:sha(p) for k,p in binaries.items()},scope='Explanatory allocator/RSS profile of frozen sources0cb80bf73a4a and23688dd217ce, not a scientific timing campaign or unchanged rerun of those timing observations. First adjacentAB/BA per input; retain all completed outputs, errors and allocator statistics. MIMALLOC_SHOW_STATS=1 is set equally. Complete reduced bases must agree. No timing claims or null-control requirement.',runs=[])
try:
 for case,inputfile in inputs.items():
  outputs={}
  for block,order in enumerate(['AB','BA']):
   for arm in order:
    prefix=f'{case}-{block}-{arm}';command=['/run/current-system/sw/bin/time','-f','%M','-o',str(out/(prefix+'.rss')),str(binaries[arm]),'--work','100000000000','--packed-bytes','17179869184','--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000',str(inputfile)]
    with (out/(prefix+'.stdout')).open('w') as stdout,(out/(prefix+'.stderr')).open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,MIMALLOC_SHOW_STATS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
    record=dict(case=case,block=block,arm=arm,command=command,returncode=r.returncode,input_sha256=sha(inputfile),peak_rss_kib=int((out/(prefix+'.rss')).read_text().splitlines()[-1]));meta['runs'].append(record);assert r.returncode==0
    result=json.loads((out/(prefix+'.stdout')).read_text());outputs[(block,arm)]=result['basis'];record['statistics']=result['statistics'];print(prefix,record['peak_rss_kib'],flush=True)
  assert all(x==outputs[(0,'A')] for x in outputs.values())
finally:
 meta['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
