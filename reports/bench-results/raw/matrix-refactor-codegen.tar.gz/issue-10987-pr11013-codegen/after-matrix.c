// Lean compiler output
// Module: HexGroebner.Matrix
// Imports: public import Init public meta import Init public import HexGroebner.Packed public import HexGroebner.Native
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_length(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint64_t lp_Hex_BarrettCtx_mulMod(uint64_t, uint64_t, uint64_t, uint64_t);
uint8_t lean_uint64_to_uint8(uint64_t);
lean_object* lean_byte_array_push(lean_object*, uint8_t);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_byte_array_size(lean_object*);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
uint8_t lean_byte_array_uget(lean_object*, size_t);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_nat_mul(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_usize_to_nat(size_t);
extern lean_object* lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
lean_object* l_Repr_addAppParen(lean_object*, lean_object*);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
uint8_t lean_uint64_dec_le(uint64_t, uint64_t);
uint8_t lp_Hex_Hex_Groebner_PrimeField_width(uint64_t);
lean_object* lp_Hex_Hex_Groebner_SparseRow_size(lean_object*);
lean_object* lean_mk_empty_byte_array(lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_nat_log2(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorIdx(uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorElim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorElim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorElim(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_columns_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_columns_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_columns_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_columns_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_rows_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_rows_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_rows_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_rows_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_inputEntries_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_inputEntries_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_inputEntries_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_inputEntries_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_outputEntries_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_outputEntries_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_outputEntries_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_outputEntries_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_packedBytes_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_packedBytes_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_packedBytes_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_packedBytes_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_work_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_work_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_work_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_work_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_traceNodes_elim___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_traceNodes_elim___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_traceNodes_elim(lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_traceNodes_elim___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqResource_beq(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqResource_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqResource___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqResource_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqResource___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqResource___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqResource = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqResource___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "Hex.Groebner.Resource.columns"};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__1_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "Hex.Groebner.Resource.rows"};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__3_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "Hex.Groebner.Resource.inputEntries"};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__5_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 36, .m_capacity = 36, .m_length = 35, .m_data = "Hex.Groebner.Resource.outputEntries"};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__6_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__6_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__7 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__7_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 34, .m_capacity = 34, .m_length = 33, .m_data = "Hex.Groebner.Resource.packedBytes"};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__8_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__9_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "Hex.Groebner.Resource.work"};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__10 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__10_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__10_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__11 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__11_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "Hex.Groebner.Resource.traceNodes"};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__12 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__12_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprResource_repr___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__12_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__13 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource_repr___closed__13_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__14;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___closed__15;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprResource_repr(uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprResource___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprResource_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprResource___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprResource = (const lean_object*)&lp_Hex_Hex_Groebner_instReprResource___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_dimensions_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_dimensions_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_rowUpdate_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_rowUpdate_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_rowLength_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_rowLength_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_column_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_column_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_coefficient_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_coefficient_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_exhausted_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_exhausted_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqMatrixError_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqMatrixError_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqMatrixError___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqMatrixError_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqMatrixError___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqMatrixError___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqMatrixError = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqMatrixError___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 36, .m_capacity = 36, .m_length = 35, .m_data = "Hex.Groebner.MatrixError.dimensions"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__1_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "Hex.Groebner.MatrixError.rowUpdate"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__3_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "Hex.Groebner.MatrixError.rowLength"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__5_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__5_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__6_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 32, .m_capacity = 32, .m_length = 31, .m_data = "Hex.Groebner.MatrixError.column"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__7 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__7_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__7_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__8_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__9_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 37, .m_capacity = 37, .m_length = 36, .m_data = "Hex.Groebner.MatrixError.coefficient"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__10 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__10_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__10_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__11 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__11_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__11_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__12 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__12_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "Hex.Groebner.MatrixError.exhausted"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__13 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__13_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__13_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__14 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__14_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__14_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__15 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__15_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprMatrixError___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprMatrixError_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprMatrixError = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixError___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instInhabitedMatrixLimits_default___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*7 + 0, .m_other = 7, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1000000) << 1) | 1)),((lean_object*)(((size_t)(100000) << 1) | 1)),((lean_object*)(((size_t)(10000000) << 1) | 1)),((lean_object*)(((size_t)(10000000) << 1) | 1)),((lean_object*)(((size_t)(268435456) << 1) | 1)),((lean_object*)(((size_t)(100000000) << 1) | 1)),((lean_object*)(((size_t)(1000000) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instInhabitedMatrixLimits_default___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedMatrixLimits_default___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedMatrixLimits_default = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedMatrixLimits_default___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedMatrixLimits = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedMatrixLimits_default___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_Groebner_instReprMatrixStats_repr_spec__0(lean_object*);
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "{ "};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__0_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "work"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__2_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__2_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__3_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = " := "};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__4_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__5_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__3_value),((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__5_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__6_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__7;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ","};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__8_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__9 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__9_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "inputEntries"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__10 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__10_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__10_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__11 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__11_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__12;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "outputEntries"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__13 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__13_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__13_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__14 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__14_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__15_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__15;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "packedBytes"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__16 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__16_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__16_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__17 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__17_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__18_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__18;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "traceNodes"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__19 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__19_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__19_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__20 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__20_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__21_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__21;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "processedRows"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__22 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__22_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__22_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__23 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__23_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "reductions"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__24 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__24_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__24_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__25 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__25_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "zeroRows"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__26 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__26_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__26_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__27 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__27_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__28_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__28;
static const lean_string_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__29_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = " }"};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__29 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__29_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__30_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__30;
static lean_once_cell_t lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__31_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__31;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__32 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__32_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__33_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__29_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__33 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__33_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprMatrixStats___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprMatrixStats_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats = (const lean_object*)&lp_Hex_Hex_Groebner_instReprMatrixStats___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqMatrixStats_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqMatrixStats_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqMatrixStats___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqMatrixStats_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqMatrixStats___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqMatrixStats___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqMatrixStats = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqMatrixStats___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instInhabitedMatrixStats_default___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*8 + 0, .m_other = 8, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instInhabitedMatrixStats_default___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedMatrixStats_default___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedMatrixStats_default = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedMatrixStats_default___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instInhabitedMatrixStats = (const lean_object*)&lp_Hex_Hex_Groebner_instInhabitedMatrixStats_default___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorIdx(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_input_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_input_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_addScaled_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_addScaled_elim(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_scale_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_scale_elim(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "Hex.Groebner.RowOp.input"};
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__0_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__1_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__2 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__2_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 29, .m_capacity = 29, .m_length = 28, .m_data = "Hex.Groebner.RowOp.addScaled"};
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__3 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__3_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__3_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__4 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__4_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__5 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__5_value;
static const lean_string_object lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "Hex.Groebner.RowOp.scale"};
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__6 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__6_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 3}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__6_value)}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__7 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__7_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 5}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__7_value),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__8 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__8_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instReprRowOp___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instReprRowOp_repr___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instReprRowOp___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instReprRowOp = (const lean_object*)&lp_Hex_Hex_Groebner_instReprRowOp___closed__0_value;
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqRowOp_beq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqRowOp_beq___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_instBEqRowOp___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_instBEqRowOp_beq___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_instBEqRowOp___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqRowOp___closed__0_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_instBEqRowOp = (const lean_object*)&lp_Hex_Hex_Groebner_instBEqRowOp___closed__0_value;
static lean_once_cell_t lp_Hex_Hex_Groebner_instInhabitedPivot_default___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instInhabitedPivot_default___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedPivot_default;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedPivot;
static lean_once_cell_t lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instInhabitedRemainderRow;
static const lean_ctor_object lp_Hex_Hex_Groebner_Matrix_charge___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_Matrix_charge___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_charge___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_charge(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_charge___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work___lam__1(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_Matrix_work___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_Matrix_work___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Matrix_work___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_work___closed__0_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Matrix_work___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_Matrix_work___lam__1, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Matrix_work___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_work___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___lam__1(lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_Matrix_packedBytes___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_Matrix_packedBytes___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_packedBytes___closed__0_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Matrix_packedBytes___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_Matrix_packedBytes___lam__1, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_packedBytes___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate___lam__1(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate___lam__1___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg(lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_Matrix_validate___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_Matrix_validate___lam__0, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Matrix_validate___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_validate___closed__0_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Matrix_validate___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_Matrix_validate___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Matrix_validate___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_validate___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0(lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_zeros(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0___redArg(lean_object*, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex_Hex_Groebner_Matrix_inverse___closed__0___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
LEAN_EXPORT const lean_object* lp_Hex_Hex_Groebner_Matrix_inverse___closed__0___boxed__const__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_inverse___closed__0___boxed__const__1_value;
static const lean_ctor_object lp_Hex_Hex_Groebner_Matrix_inverse___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex_Hex_Groebner_Matrix_inverse___closed__0___boxed__const__1_value)}};
static const lean_object* lp_Hex_Hex_Groebner_Matrix_inverse___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_inverse___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_inverse(uint64_t, uint64_t, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_inverse___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0(lean_object*, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___lam__1(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___lam__1___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0___redArg(uint64_t, uint64_t, uint64_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_Groebner_Matrix_scaleSparse___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_Matrix_scaleSparse___lam__0, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_scaleSparse___closed__0_value;
static const lean_closure_object lp_Hex_Hex_Groebner_Matrix_scaleSparse___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_Groebner_Matrix_scaleSparse___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___closed__1 = (const lean_object*)&lp_Hex_Hex_Groebner_Matrix_scaleSparse___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse(uint64_t, uint64_t, lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0(uint64_t, uint64_t, uint64_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorIdx(uint8_t v_x_1_){
_start:
{
switch(v_x_1_)
{
case 0:
{
lean_object* v___x_2_; 
v___x_2_ = lean_unsigned_to_nat(0u);
return v___x_2_;
}
case 1:
{
lean_object* v___x_3_; 
v___x_3_ = lean_unsigned_to_nat(1u);
return v___x_3_;
}
case 2:
{
lean_object* v___x_4_; 
v___x_4_ = lean_unsigned_to_nat(2u);
return v___x_4_;
}
case 3:
{
lean_object* v___x_5_; 
v___x_5_ = lean_unsigned_to_nat(3u);
return v___x_5_;
}
case 4:
{
lean_object* v___x_6_; 
v___x_6_ = lean_unsigned_to_nat(4u);
return v___x_6_;
}
case 5:
{
lean_object* v___x_7_; 
v___x_7_ = lean_unsigned_to_nat(5u);
return v___x_7_;
}
default: 
{
lean_object* v___x_8_; 
v___x_8_ = lean_unsigned_to_nat(6u);
return v___x_8_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorIdx___boxed(lean_object* v_x_9_){
_start:
{
uint8_t v_x_boxed_10_; lean_object* v_res_11_; 
v_x_boxed_10_ = lean_unbox(v_x_9_);
v_res_11_ = lp_Hex_Hex_Groebner_Resource_ctorIdx(v_x_boxed_10_);
return v_res_11_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorElim___redArg(lean_object* v_k_12_){
_start:
{
lean_inc(v_k_12_);
return v_k_12_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorElim___redArg___boxed(lean_object* v_k_13_){
_start:
{
lean_object* v_res_14_; 
v_res_14_ = lp_Hex_Hex_Groebner_Resource_ctorElim___redArg(v_k_13_);
lean_dec(v_k_13_);
return v_res_14_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorElim(lean_object* v_motive_15_, lean_object* v_ctorIdx_16_, uint8_t v_t_17_, lean_object* v_h_18_, lean_object* v_k_19_){
_start:
{
lean_inc(v_k_19_);
return v_k_19_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_ctorElim___boxed(lean_object* v_motive_20_, lean_object* v_ctorIdx_21_, lean_object* v_t_22_, lean_object* v_h_23_, lean_object* v_k_24_){
_start:
{
uint8_t v_t_boxed_25_; lean_object* v_res_26_; 
v_t_boxed_25_ = lean_unbox(v_t_22_);
v_res_26_ = lp_Hex_Hex_Groebner_Resource_ctorElim(v_motive_20_, v_ctorIdx_21_, v_t_boxed_25_, v_h_23_, v_k_24_);
lean_dec(v_k_24_);
lean_dec(v_ctorIdx_21_);
return v_res_26_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_columns_elim___redArg(lean_object* v_columns_27_){
_start:
{
lean_inc(v_columns_27_);
return v_columns_27_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_columns_elim___redArg___boxed(lean_object* v_columns_28_){
_start:
{
lean_object* v_res_29_; 
v_res_29_ = lp_Hex_Hex_Groebner_Resource_columns_elim___redArg(v_columns_28_);
lean_dec(v_columns_28_);
return v_res_29_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_columns_elim(lean_object* v_motive_30_, uint8_t v_t_31_, lean_object* v_h_32_, lean_object* v_columns_33_){
_start:
{
lean_inc(v_columns_33_);
return v_columns_33_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_columns_elim___boxed(lean_object* v_motive_34_, lean_object* v_t_35_, lean_object* v_h_36_, lean_object* v_columns_37_){
_start:
{
uint8_t v_t_boxed_38_; lean_object* v_res_39_; 
v_t_boxed_38_ = lean_unbox(v_t_35_);
v_res_39_ = lp_Hex_Hex_Groebner_Resource_columns_elim(v_motive_34_, v_t_boxed_38_, v_h_36_, v_columns_37_);
lean_dec(v_columns_37_);
return v_res_39_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_rows_elim___redArg(lean_object* v_rows_40_){
_start:
{
lean_inc(v_rows_40_);
return v_rows_40_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_rows_elim___redArg___boxed(lean_object* v_rows_41_){
_start:
{
lean_object* v_res_42_; 
v_res_42_ = lp_Hex_Hex_Groebner_Resource_rows_elim___redArg(v_rows_41_);
lean_dec(v_rows_41_);
return v_res_42_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_rows_elim(lean_object* v_motive_43_, uint8_t v_t_44_, lean_object* v_h_45_, lean_object* v_rows_46_){
_start:
{
lean_inc(v_rows_46_);
return v_rows_46_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_rows_elim___boxed(lean_object* v_motive_47_, lean_object* v_t_48_, lean_object* v_h_49_, lean_object* v_rows_50_){
_start:
{
uint8_t v_t_boxed_51_; lean_object* v_res_52_; 
v_t_boxed_51_ = lean_unbox(v_t_48_);
v_res_52_ = lp_Hex_Hex_Groebner_Resource_rows_elim(v_motive_47_, v_t_boxed_51_, v_h_49_, v_rows_50_);
lean_dec(v_rows_50_);
return v_res_52_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_inputEntries_elim___redArg(lean_object* v_inputEntries_53_){
_start:
{
lean_inc(v_inputEntries_53_);
return v_inputEntries_53_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_inputEntries_elim___redArg___boxed(lean_object* v_inputEntries_54_){
_start:
{
lean_object* v_res_55_; 
v_res_55_ = lp_Hex_Hex_Groebner_Resource_inputEntries_elim___redArg(v_inputEntries_54_);
lean_dec(v_inputEntries_54_);
return v_res_55_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_inputEntries_elim(lean_object* v_motive_56_, uint8_t v_t_57_, lean_object* v_h_58_, lean_object* v_inputEntries_59_){
_start:
{
lean_inc(v_inputEntries_59_);
return v_inputEntries_59_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_inputEntries_elim___boxed(lean_object* v_motive_60_, lean_object* v_t_61_, lean_object* v_h_62_, lean_object* v_inputEntries_63_){
_start:
{
uint8_t v_t_boxed_64_; lean_object* v_res_65_; 
v_t_boxed_64_ = lean_unbox(v_t_61_);
v_res_65_ = lp_Hex_Hex_Groebner_Resource_inputEntries_elim(v_motive_60_, v_t_boxed_64_, v_h_62_, v_inputEntries_63_);
lean_dec(v_inputEntries_63_);
return v_res_65_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_outputEntries_elim___redArg(lean_object* v_outputEntries_66_){
_start:
{
lean_inc(v_outputEntries_66_);
return v_outputEntries_66_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_outputEntries_elim___redArg___boxed(lean_object* v_outputEntries_67_){
_start:
{
lean_object* v_res_68_; 
v_res_68_ = lp_Hex_Hex_Groebner_Resource_outputEntries_elim___redArg(v_outputEntries_67_);
lean_dec(v_outputEntries_67_);
return v_res_68_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_outputEntries_elim(lean_object* v_motive_69_, uint8_t v_t_70_, lean_object* v_h_71_, lean_object* v_outputEntries_72_){
_start:
{
lean_inc(v_outputEntries_72_);
return v_outputEntries_72_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_outputEntries_elim___boxed(lean_object* v_motive_73_, lean_object* v_t_74_, lean_object* v_h_75_, lean_object* v_outputEntries_76_){
_start:
{
uint8_t v_t_boxed_77_; lean_object* v_res_78_; 
v_t_boxed_77_ = lean_unbox(v_t_74_);
v_res_78_ = lp_Hex_Hex_Groebner_Resource_outputEntries_elim(v_motive_73_, v_t_boxed_77_, v_h_75_, v_outputEntries_76_);
lean_dec(v_outputEntries_76_);
return v_res_78_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_packedBytes_elim___redArg(lean_object* v_packedBytes_79_){
_start:
{
lean_inc(v_packedBytes_79_);
return v_packedBytes_79_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_packedBytes_elim___redArg___boxed(lean_object* v_packedBytes_80_){
_start:
{
lean_object* v_res_81_; 
v_res_81_ = lp_Hex_Hex_Groebner_Resource_packedBytes_elim___redArg(v_packedBytes_80_);
lean_dec(v_packedBytes_80_);
return v_res_81_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_packedBytes_elim(lean_object* v_motive_82_, uint8_t v_t_83_, lean_object* v_h_84_, lean_object* v_packedBytes_85_){
_start:
{
lean_inc(v_packedBytes_85_);
return v_packedBytes_85_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_packedBytes_elim___boxed(lean_object* v_motive_86_, lean_object* v_t_87_, lean_object* v_h_88_, lean_object* v_packedBytes_89_){
_start:
{
uint8_t v_t_boxed_90_; lean_object* v_res_91_; 
v_t_boxed_90_ = lean_unbox(v_t_87_);
v_res_91_ = lp_Hex_Hex_Groebner_Resource_packedBytes_elim(v_motive_86_, v_t_boxed_90_, v_h_88_, v_packedBytes_89_);
lean_dec(v_packedBytes_89_);
return v_res_91_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_work_elim___redArg(lean_object* v_work_92_){
_start:
{
lean_inc(v_work_92_);
return v_work_92_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_work_elim___redArg___boxed(lean_object* v_work_93_){
_start:
{
lean_object* v_res_94_; 
v_res_94_ = lp_Hex_Hex_Groebner_Resource_work_elim___redArg(v_work_93_);
lean_dec(v_work_93_);
return v_res_94_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_work_elim(lean_object* v_motive_95_, uint8_t v_t_96_, lean_object* v_h_97_, lean_object* v_work_98_){
_start:
{
lean_inc(v_work_98_);
return v_work_98_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_work_elim___boxed(lean_object* v_motive_99_, lean_object* v_t_100_, lean_object* v_h_101_, lean_object* v_work_102_){
_start:
{
uint8_t v_t_boxed_103_; lean_object* v_res_104_; 
v_t_boxed_103_ = lean_unbox(v_t_100_);
v_res_104_ = lp_Hex_Hex_Groebner_Resource_work_elim(v_motive_99_, v_t_boxed_103_, v_h_101_, v_work_102_);
lean_dec(v_work_102_);
return v_res_104_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_traceNodes_elim___redArg(lean_object* v_traceNodes_105_){
_start:
{
lean_inc(v_traceNodes_105_);
return v_traceNodes_105_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_traceNodes_elim___redArg___boxed(lean_object* v_traceNodes_106_){
_start:
{
lean_object* v_res_107_; 
v_res_107_ = lp_Hex_Hex_Groebner_Resource_traceNodes_elim___redArg(v_traceNodes_106_);
lean_dec(v_traceNodes_106_);
return v_res_107_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_traceNodes_elim(lean_object* v_motive_108_, uint8_t v_t_109_, lean_object* v_h_110_, lean_object* v_traceNodes_111_){
_start:
{
lean_inc(v_traceNodes_111_);
return v_traceNodes_111_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Resource_traceNodes_elim___boxed(lean_object* v_motive_112_, lean_object* v_t_113_, lean_object* v_h_114_, lean_object* v_traceNodes_115_){
_start:
{
uint8_t v_t_boxed_116_; lean_object* v_res_117_; 
v_t_boxed_116_ = lean_unbox(v_t_113_);
v_res_117_ = lp_Hex_Hex_Groebner_Resource_traceNodes_elim(v_motive_112_, v_t_boxed_116_, v_h_114_, v_traceNodes_115_);
lean_dec(v_traceNodes_115_);
return v_res_117_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqResource_beq(uint8_t v_x_118_, uint8_t v_y_119_){
_start:
{
lean_object* v___x_120_; lean_object* v___x_121_; uint8_t v___x_122_; 
v___x_120_ = lp_Hex_Hex_Groebner_Resource_ctorIdx(v_x_118_);
v___x_121_ = lp_Hex_Hex_Groebner_Resource_ctorIdx(v_y_119_);
v___x_122_ = lean_nat_dec_eq(v___x_120_, v___x_121_);
lean_dec(v___x_121_);
lean_dec(v___x_120_);
return v___x_122_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqResource_beq___boxed(lean_object* v_x_123_, lean_object* v_y_124_){
_start:
{
uint8_t v_x_21__boxed_125_; uint8_t v_y_22__boxed_126_; uint8_t v_res_127_; lean_object* v_r_128_; 
v_x_21__boxed_125_ = lean_unbox(v_x_123_);
v_y_22__boxed_126_ = lean_unbox(v_y_124_);
v_res_127_ = lp_Hex_Hex_Groebner_instBEqResource_beq(v_x_21__boxed_125_, v_y_22__boxed_126_);
v_r_128_ = lean_box(v_res_127_);
return v_r_128_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14(void){
_start:
{
lean_object* v___x_152_; lean_object* v___x_153_; 
v___x_152_ = lean_unsigned_to_nat(2u);
v___x_153_ = lean_nat_to_int(v___x_152_);
return v___x_153_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15(void){
_start:
{
lean_object* v___x_154_; lean_object* v___x_155_; 
v___x_154_ = lean_unsigned_to_nat(1u);
v___x_155_ = lean_nat_to_int(v___x_154_);
return v___x_155_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprResource_repr(uint8_t v_x_156_, lean_object* v_prec_157_){
_start:
{
lean_object* v___y_159_; lean_object* v___y_166_; lean_object* v___y_173_; lean_object* v___y_180_; lean_object* v___y_187_; lean_object* v___y_194_; lean_object* v___y_201_; 
switch(v_x_156_)
{
case 0:
{
lean_object* v___x_207_; uint8_t v___x_208_; 
v___x_207_ = lean_unsigned_to_nat(1024u);
v___x_208_ = lean_nat_dec_le(v___x_207_, v_prec_157_);
if (v___x_208_ == 0)
{
lean_object* v___x_209_; 
v___x_209_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_159_ = v___x_209_;
goto v___jp_158_;
}
else
{
lean_object* v___x_210_; 
v___x_210_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_159_ = v___x_210_;
goto v___jp_158_;
}
}
case 1:
{
lean_object* v___x_211_; uint8_t v___x_212_; 
v___x_211_ = lean_unsigned_to_nat(1024u);
v___x_212_ = lean_nat_dec_le(v___x_211_, v_prec_157_);
if (v___x_212_ == 0)
{
lean_object* v___x_213_; 
v___x_213_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_166_ = v___x_213_;
goto v___jp_165_;
}
else
{
lean_object* v___x_214_; 
v___x_214_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_166_ = v___x_214_;
goto v___jp_165_;
}
}
case 2:
{
lean_object* v___x_215_; uint8_t v___x_216_; 
v___x_215_ = lean_unsigned_to_nat(1024u);
v___x_216_ = lean_nat_dec_le(v___x_215_, v_prec_157_);
if (v___x_216_ == 0)
{
lean_object* v___x_217_; 
v___x_217_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_173_ = v___x_217_;
goto v___jp_172_;
}
else
{
lean_object* v___x_218_; 
v___x_218_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_173_ = v___x_218_;
goto v___jp_172_;
}
}
case 3:
{
lean_object* v___x_219_; uint8_t v___x_220_; 
v___x_219_ = lean_unsigned_to_nat(1024u);
v___x_220_ = lean_nat_dec_le(v___x_219_, v_prec_157_);
if (v___x_220_ == 0)
{
lean_object* v___x_221_; 
v___x_221_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_180_ = v___x_221_;
goto v___jp_179_;
}
else
{
lean_object* v___x_222_; 
v___x_222_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_180_ = v___x_222_;
goto v___jp_179_;
}
}
case 4:
{
lean_object* v___x_223_; uint8_t v___x_224_; 
v___x_223_ = lean_unsigned_to_nat(1024u);
v___x_224_ = lean_nat_dec_le(v___x_223_, v_prec_157_);
if (v___x_224_ == 0)
{
lean_object* v___x_225_; 
v___x_225_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_187_ = v___x_225_;
goto v___jp_186_;
}
else
{
lean_object* v___x_226_; 
v___x_226_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_187_ = v___x_226_;
goto v___jp_186_;
}
}
case 5:
{
lean_object* v___x_227_; uint8_t v___x_228_; 
v___x_227_ = lean_unsigned_to_nat(1024u);
v___x_228_ = lean_nat_dec_le(v___x_227_, v_prec_157_);
if (v___x_228_ == 0)
{
lean_object* v___x_229_; 
v___x_229_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_194_ = v___x_229_;
goto v___jp_193_;
}
else
{
lean_object* v___x_230_; 
v___x_230_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_194_ = v___x_230_;
goto v___jp_193_;
}
}
default: 
{
lean_object* v___x_231_; uint8_t v___x_232_; 
v___x_231_ = lean_unsigned_to_nat(1024u);
v___x_232_ = lean_nat_dec_le(v___x_231_, v_prec_157_);
if (v___x_232_ == 0)
{
lean_object* v___x_233_; 
v___x_233_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_201_ = v___x_233_;
goto v___jp_200_;
}
else
{
lean_object* v___x_234_; 
v___x_234_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_201_ = v___x_234_;
goto v___jp_200_;
}
}
}
v___jp_158_:
{
lean_object* v___x_160_; lean_object* v___x_161_; uint8_t v___x_162_; lean_object* v___x_163_; lean_object* v___x_164_; 
v___x_160_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprResource_repr___closed__1));
lean_inc(v___y_159_);
v___x_161_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_161_, 0, v___y_159_);
lean_ctor_set(v___x_161_, 1, v___x_160_);
v___x_162_ = 0;
v___x_163_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_163_, 0, v___x_161_);
lean_ctor_set_uint8(v___x_163_, sizeof(void*)*1, v___x_162_);
v___x_164_ = l_Repr_addAppParen(v___x_163_, v_prec_157_);
return v___x_164_;
}
v___jp_165_:
{
lean_object* v___x_167_; lean_object* v___x_168_; uint8_t v___x_169_; lean_object* v___x_170_; lean_object* v___x_171_; 
v___x_167_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprResource_repr___closed__3));
lean_inc(v___y_166_);
v___x_168_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_168_, 0, v___y_166_);
lean_ctor_set(v___x_168_, 1, v___x_167_);
v___x_169_ = 0;
v___x_170_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_170_, 0, v___x_168_);
lean_ctor_set_uint8(v___x_170_, sizeof(void*)*1, v___x_169_);
v___x_171_ = l_Repr_addAppParen(v___x_170_, v_prec_157_);
return v___x_171_;
}
v___jp_172_:
{
lean_object* v___x_174_; lean_object* v___x_175_; uint8_t v___x_176_; lean_object* v___x_177_; lean_object* v___x_178_; 
v___x_174_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprResource_repr___closed__5));
lean_inc(v___y_173_);
v___x_175_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_175_, 0, v___y_173_);
lean_ctor_set(v___x_175_, 1, v___x_174_);
v___x_176_ = 0;
v___x_177_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_177_, 0, v___x_175_);
lean_ctor_set_uint8(v___x_177_, sizeof(void*)*1, v___x_176_);
v___x_178_ = l_Repr_addAppParen(v___x_177_, v_prec_157_);
return v___x_178_;
}
v___jp_179_:
{
lean_object* v___x_181_; lean_object* v___x_182_; uint8_t v___x_183_; lean_object* v___x_184_; lean_object* v___x_185_; 
v___x_181_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprResource_repr___closed__7));
lean_inc(v___y_180_);
v___x_182_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_182_, 0, v___y_180_);
lean_ctor_set(v___x_182_, 1, v___x_181_);
v___x_183_ = 0;
v___x_184_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_184_, 0, v___x_182_);
lean_ctor_set_uint8(v___x_184_, sizeof(void*)*1, v___x_183_);
v___x_185_ = l_Repr_addAppParen(v___x_184_, v_prec_157_);
return v___x_185_;
}
v___jp_186_:
{
lean_object* v___x_188_; lean_object* v___x_189_; uint8_t v___x_190_; lean_object* v___x_191_; lean_object* v___x_192_; 
v___x_188_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprResource_repr___closed__9));
lean_inc(v___y_187_);
v___x_189_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_189_, 0, v___y_187_);
lean_ctor_set(v___x_189_, 1, v___x_188_);
v___x_190_ = 0;
v___x_191_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_191_, 0, v___x_189_);
lean_ctor_set_uint8(v___x_191_, sizeof(void*)*1, v___x_190_);
v___x_192_ = l_Repr_addAppParen(v___x_191_, v_prec_157_);
return v___x_192_;
}
v___jp_193_:
{
lean_object* v___x_195_; lean_object* v___x_196_; uint8_t v___x_197_; lean_object* v___x_198_; lean_object* v___x_199_; 
v___x_195_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprResource_repr___closed__11));
lean_inc(v___y_194_);
v___x_196_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_196_, 0, v___y_194_);
lean_ctor_set(v___x_196_, 1, v___x_195_);
v___x_197_ = 0;
v___x_198_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_198_, 0, v___x_196_);
lean_ctor_set_uint8(v___x_198_, sizeof(void*)*1, v___x_197_);
v___x_199_ = l_Repr_addAppParen(v___x_198_, v_prec_157_);
return v___x_199_;
}
v___jp_200_:
{
lean_object* v___x_202_; lean_object* v___x_203_; uint8_t v___x_204_; lean_object* v___x_205_; lean_object* v___x_206_; 
v___x_202_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprResource_repr___closed__13));
lean_inc(v___y_201_);
v___x_203_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_203_, 0, v___y_201_);
lean_ctor_set(v___x_203_, 1, v___x_202_);
v___x_204_ = 0;
v___x_205_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_205_, 0, v___x_203_);
lean_ctor_set_uint8(v___x_205_, sizeof(void*)*1, v___x_204_);
v___x_206_ = l_Repr_addAppParen(v___x_205_, v_prec_157_);
return v___x_206_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprResource_repr___boxed(lean_object* v_x_235_, lean_object* v_prec_236_){
_start:
{
uint8_t v_x_387__boxed_237_; lean_object* v_res_238_; 
v_x_387__boxed_237_ = lean_unbox(v_x_235_);
v_res_238_ = lp_Hex_Hex_Groebner_instReprResource_repr(v_x_387__boxed_237_, v_prec_236_);
lean_dec(v_prec_236_);
return v_res_238_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorIdx(lean_object* v_x_241_){
_start:
{
switch(lean_obj_tag(v_x_241_))
{
case 0:
{
lean_object* v___x_242_; 
v___x_242_ = lean_unsigned_to_nat(0u);
return v___x_242_;
}
case 1:
{
lean_object* v___x_243_; 
v___x_243_ = lean_unsigned_to_nat(1u);
return v___x_243_;
}
case 2:
{
lean_object* v___x_244_; 
v___x_244_ = lean_unsigned_to_nat(2u);
return v___x_244_;
}
case 3:
{
lean_object* v___x_245_; 
v___x_245_ = lean_unsigned_to_nat(3u);
return v___x_245_;
}
case 4:
{
lean_object* v___x_246_; 
v___x_246_ = lean_unsigned_to_nat(4u);
return v___x_246_;
}
default: 
{
lean_object* v___x_247_; 
v___x_247_ = lean_unsigned_to_nat(5u);
return v___x_247_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorIdx___boxed(lean_object* v_x_248_){
_start:
{
lean_object* v_res_249_; 
v_res_249_ = lp_Hex_Hex_Groebner_MatrixError_ctorIdx(v_x_248_);
lean_dec(v_x_248_);
return v_res_249_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(lean_object* v_t_250_, lean_object* v_k_251_){
_start:
{
switch(lean_obj_tag(v_t_250_))
{
case 2:
{
lean_object* v_row_252_; lean_object* v___x_253_; 
v_row_252_ = lean_ctor_get(v_t_250_, 0);
lean_inc(v_row_252_);
lean_dec_ref_known(v_t_250_, 1);
v___x_253_ = lean_apply_1(v_k_251_, v_row_252_);
return v___x_253_;
}
case 3:
{
lean_object* v_row_254_; lean_object* v_entry_255_; lean_object* v___x_256_; 
v_row_254_ = lean_ctor_get(v_t_250_, 0);
lean_inc(v_row_254_);
v_entry_255_ = lean_ctor_get(v_t_250_, 1);
lean_inc(v_entry_255_);
lean_dec_ref_known(v_t_250_, 2);
v___x_256_ = lean_apply_2(v_k_251_, v_row_254_, v_entry_255_);
return v___x_256_;
}
case 4:
{
lean_object* v_row_257_; lean_object* v_entry_258_; lean_object* v___x_259_; 
v_row_257_ = lean_ctor_get(v_t_250_, 0);
lean_inc(v_row_257_);
v_entry_258_ = lean_ctor_get(v_t_250_, 1);
lean_inc(v_entry_258_);
lean_dec_ref_known(v_t_250_, 2);
v___x_259_ = lean_apply_2(v_k_251_, v_row_257_, v_entry_258_);
return v___x_259_;
}
case 5:
{
uint8_t v_resource_260_; lean_object* v___x_261_; lean_object* v___x_262_; 
v_resource_260_ = lean_ctor_get_uint8(v_t_250_, 0);
lean_dec_ref_known(v_t_250_, 0);
v___x_261_ = lean_box(v_resource_260_);
v___x_262_ = lean_apply_1(v_k_251_, v___x_261_);
return v___x_262_;
}
default: 
{
lean_dec(v_t_250_);
return v_k_251_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorElim(lean_object* v_motive_263_, lean_object* v_ctorIdx_264_, lean_object* v_t_265_, lean_object* v_h_266_, lean_object* v_k_267_){
_start:
{
lean_object* v___x_268_; 
v___x_268_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_265_, v_k_267_);
return v___x_268_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_ctorElim___boxed(lean_object* v_motive_269_, lean_object* v_ctorIdx_270_, lean_object* v_t_271_, lean_object* v_h_272_, lean_object* v_k_273_){
_start:
{
lean_object* v_res_274_; 
v_res_274_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim(v_motive_269_, v_ctorIdx_270_, v_t_271_, v_h_272_, v_k_273_);
lean_dec(v_ctorIdx_270_);
return v_res_274_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_dimensions_elim___redArg(lean_object* v_t_275_, lean_object* v_dimensions_276_){
_start:
{
lean_object* v___x_277_; 
v___x_277_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_275_, v_dimensions_276_);
return v___x_277_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_dimensions_elim(lean_object* v_motive_278_, lean_object* v_t_279_, lean_object* v_h_280_, lean_object* v_dimensions_281_){
_start:
{
lean_object* v___x_282_; 
v___x_282_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_279_, v_dimensions_281_);
return v___x_282_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_rowUpdate_elim___redArg(lean_object* v_t_283_, lean_object* v_rowUpdate_284_){
_start:
{
lean_object* v___x_285_; 
v___x_285_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_283_, v_rowUpdate_284_);
return v___x_285_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_rowUpdate_elim(lean_object* v_motive_286_, lean_object* v_t_287_, lean_object* v_h_288_, lean_object* v_rowUpdate_289_){
_start:
{
lean_object* v___x_290_; 
v___x_290_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_287_, v_rowUpdate_289_);
return v___x_290_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_rowLength_elim___redArg(lean_object* v_t_291_, lean_object* v_rowLength_292_){
_start:
{
lean_object* v___x_293_; 
v___x_293_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_291_, v_rowLength_292_);
return v___x_293_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_rowLength_elim(lean_object* v_motive_294_, lean_object* v_t_295_, lean_object* v_h_296_, lean_object* v_rowLength_297_){
_start:
{
lean_object* v___x_298_; 
v___x_298_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_295_, v_rowLength_297_);
return v___x_298_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_column_elim___redArg(lean_object* v_t_299_, lean_object* v_column_300_){
_start:
{
lean_object* v___x_301_; 
v___x_301_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_299_, v_column_300_);
return v___x_301_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_column_elim(lean_object* v_motive_302_, lean_object* v_t_303_, lean_object* v_h_304_, lean_object* v_column_305_){
_start:
{
lean_object* v___x_306_; 
v___x_306_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_303_, v_column_305_);
return v___x_306_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_coefficient_elim___redArg(lean_object* v_t_307_, lean_object* v_coefficient_308_){
_start:
{
lean_object* v___x_309_; 
v___x_309_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_307_, v_coefficient_308_);
return v___x_309_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_coefficient_elim(lean_object* v_motive_310_, lean_object* v_t_311_, lean_object* v_h_312_, lean_object* v_coefficient_313_){
_start:
{
lean_object* v___x_314_; 
v___x_314_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_311_, v_coefficient_313_);
return v___x_314_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_exhausted_elim___redArg(lean_object* v_t_315_, lean_object* v_exhausted_316_){
_start:
{
lean_object* v___x_317_; 
v___x_317_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_315_, v_exhausted_316_);
return v___x_317_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_MatrixError_exhausted_elim(lean_object* v_motive_318_, lean_object* v_t_319_, lean_object* v_h_320_, lean_object* v_exhausted_321_){
_start:
{
lean_object* v___x_322_; 
v___x_322_ = lp_Hex_Hex_Groebner_MatrixError_ctorElim___redArg(v_t_319_, v_exhausted_321_);
return v___x_322_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqMatrixError_beq(lean_object* v_x_323_, lean_object* v_x_324_){
_start:
{
lean_object* v_a_326_; lean_object* v_a_327_; lean_object* v_b_328_; lean_object* v_b_329_; 
switch(lean_obj_tag(v_x_323_))
{
case 0:
{
if (lean_obj_tag(v_x_324_) == 0)
{
uint8_t v___x_332_; 
v___x_332_ = 1;
return v___x_332_;
}
else
{
uint8_t v___x_333_; 
v___x_333_ = 0;
return v___x_333_;
}
}
case 1:
{
if (lean_obj_tag(v_x_324_) == 1)
{
uint8_t v___x_334_; 
v___x_334_ = 1;
return v___x_334_;
}
else
{
uint8_t v___x_335_; 
v___x_335_ = 0;
return v___x_335_;
}
}
case 2:
{
if (lean_obj_tag(v_x_324_) == 2)
{
lean_object* v_row_336_; lean_object* v_row_337_; uint8_t v___x_338_; 
v_row_336_ = lean_ctor_get(v_x_323_, 0);
v_row_337_ = lean_ctor_get(v_x_324_, 0);
v___x_338_ = lean_nat_dec_eq(v_row_336_, v_row_337_);
return v___x_338_;
}
else
{
uint8_t v___x_339_; 
v___x_339_ = 0;
return v___x_339_;
}
}
case 3:
{
if (lean_obj_tag(v_x_324_) == 3)
{
lean_object* v_row_340_; lean_object* v_entry_341_; lean_object* v_row_342_; lean_object* v_entry_343_; 
v_row_340_ = lean_ctor_get(v_x_323_, 0);
v_entry_341_ = lean_ctor_get(v_x_323_, 1);
v_row_342_ = lean_ctor_get(v_x_324_, 0);
v_entry_343_ = lean_ctor_get(v_x_324_, 1);
v_a_326_ = v_row_340_;
v_a_327_ = v_entry_341_;
v_b_328_ = v_row_342_;
v_b_329_ = v_entry_343_;
goto v___jp_325_;
}
else
{
uint8_t v___x_344_; 
v___x_344_ = 0;
return v___x_344_;
}
}
case 4:
{
if (lean_obj_tag(v_x_324_) == 4)
{
lean_object* v_row_345_; lean_object* v_entry_346_; lean_object* v_row_347_; lean_object* v_entry_348_; 
v_row_345_ = lean_ctor_get(v_x_323_, 0);
v_entry_346_ = lean_ctor_get(v_x_323_, 1);
v_row_347_ = lean_ctor_get(v_x_324_, 0);
v_entry_348_ = lean_ctor_get(v_x_324_, 1);
v_a_326_ = v_row_345_;
v_a_327_ = v_entry_346_;
v_b_328_ = v_row_347_;
v_b_329_ = v_entry_348_;
goto v___jp_325_;
}
else
{
uint8_t v___x_349_; 
v___x_349_ = 0;
return v___x_349_;
}
}
default: 
{
if (lean_obj_tag(v_x_324_) == 5)
{
uint8_t v_resource_350_; uint8_t v_resource_351_; uint8_t v___x_352_; 
v_resource_350_ = lean_ctor_get_uint8(v_x_323_, 0);
v_resource_351_ = lean_ctor_get_uint8(v_x_324_, 0);
v___x_352_ = lp_Hex_Hex_Groebner_instBEqResource_beq(v_resource_350_, v_resource_351_);
return v___x_352_;
}
else
{
uint8_t v___x_353_; 
v___x_353_ = 0;
return v___x_353_;
}
}
}
v___jp_325_:
{
uint8_t v___x_330_; 
v___x_330_ = lean_nat_dec_eq(v_a_326_, v_b_328_);
if (v___x_330_ == 0)
{
return v___x_330_;
}
else
{
uint8_t v___x_331_; 
v___x_331_ = lean_nat_dec_eq(v_a_327_, v_b_329_);
return v___x_331_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqMatrixError_beq___boxed(lean_object* v_x_354_, lean_object* v_x_355_){
_start:
{
uint8_t v_res_356_; lean_object* v_r_357_; 
v_res_356_ = lp_Hex_Hex_Groebner_instBEqMatrixError_beq(v_x_354_, v_x_355_);
lean_dec(v_x_355_);
lean_dec(v_x_354_);
v_r_357_ = lean_box(v_res_356_);
return v_r_357_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr(lean_object* v_x_390_, lean_object* v_prec_391_){
_start:
{
lean_object* v___y_393_; lean_object* v___y_400_; 
switch(lean_obj_tag(v_x_390_))
{
case 0:
{
lean_object* v___x_406_; uint8_t v___x_407_; 
v___x_406_ = lean_unsigned_to_nat(1024u);
v___x_407_ = lean_nat_dec_le(v___x_406_, v_prec_391_);
if (v___x_407_ == 0)
{
lean_object* v___x_408_; 
v___x_408_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_393_ = v___x_408_;
goto v___jp_392_;
}
else
{
lean_object* v___x_409_; 
v___x_409_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_393_ = v___x_409_;
goto v___jp_392_;
}
}
case 1:
{
lean_object* v___x_410_; uint8_t v___x_411_; 
v___x_410_ = lean_unsigned_to_nat(1024u);
v___x_411_ = lean_nat_dec_le(v___x_410_, v_prec_391_);
if (v___x_411_ == 0)
{
lean_object* v___x_412_; 
v___x_412_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_400_ = v___x_412_;
goto v___jp_399_;
}
else
{
lean_object* v___x_413_; 
v___x_413_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_400_ = v___x_413_;
goto v___jp_399_;
}
}
case 2:
{
lean_object* v_row_414_; lean_object* v___x_416_; uint8_t v_isShared_417_; uint8_t v_isSharedCheck_434_; 
v_row_414_ = lean_ctor_get(v_x_390_, 0);
v_isSharedCheck_434_ = !lean_is_exclusive(v_x_390_);
if (v_isSharedCheck_434_ == 0)
{
v___x_416_ = v_x_390_;
v_isShared_417_ = v_isSharedCheck_434_;
goto v_resetjp_415_;
}
else
{
lean_inc(v_row_414_);
lean_dec(v_x_390_);
v___x_416_ = lean_box(0);
v_isShared_417_ = v_isSharedCheck_434_;
goto v_resetjp_415_;
}
v_resetjp_415_:
{
lean_object* v___y_419_; lean_object* v___x_430_; uint8_t v___x_431_; 
v___x_430_ = lean_unsigned_to_nat(1024u);
v___x_431_ = lean_nat_dec_le(v___x_430_, v_prec_391_);
if (v___x_431_ == 0)
{
lean_object* v___x_432_; 
v___x_432_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_419_ = v___x_432_;
goto v___jp_418_;
}
else
{
lean_object* v___x_433_; 
v___x_433_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_419_ = v___x_433_;
goto v___jp_418_;
}
v___jp_418_:
{
lean_object* v___x_420_; lean_object* v___x_421_; lean_object* v___x_423_; 
v___x_420_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__6));
v___x_421_ = l_Nat_reprFast(v_row_414_);
if (v_isShared_417_ == 0)
{
lean_ctor_set_tag(v___x_416_, 3);
lean_ctor_set(v___x_416_, 0, v___x_421_);
v___x_423_ = v___x_416_;
goto v_reusejp_422_;
}
else
{
lean_object* v_reuseFailAlloc_429_; 
v_reuseFailAlloc_429_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_429_, 0, v___x_421_);
v___x_423_ = v_reuseFailAlloc_429_;
goto v_reusejp_422_;
}
v_reusejp_422_:
{
lean_object* v___x_424_; lean_object* v___x_425_; uint8_t v___x_426_; lean_object* v___x_427_; lean_object* v___x_428_; 
v___x_424_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_424_, 0, v___x_420_);
lean_ctor_set(v___x_424_, 1, v___x_423_);
lean_inc(v___y_419_);
v___x_425_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_425_, 0, v___y_419_);
lean_ctor_set(v___x_425_, 1, v___x_424_);
v___x_426_ = 0;
v___x_427_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_427_, 0, v___x_425_);
lean_ctor_set_uint8(v___x_427_, sizeof(void*)*1, v___x_426_);
v___x_428_ = l_Repr_addAppParen(v___x_427_, v_prec_391_);
return v___x_428_;
}
}
}
}
case 3:
{
lean_object* v_row_435_; lean_object* v_entry_436_; lean_object* v___x_438_; uint8_t v_isShared_439_; uint8_t v_isSharedCheck_461_; 
v_row_435_ = lean_ctor_get(v_x_390_, 0);
v_entry_436_ = lean_ctor_get(v_x_390_, 1);
v_isSharedCheck_461_ = !lean_is_exclusive(v_x_390_);
if (v_isSharedCheck_461_ == 0)
{
v___x_438_ = v_x_390_;
v_isShared_439_ = v_isSharedCheck_461_;
goto v_resetjp_437_;
}
else
{
lean_inc(v_entry_436_);
lean_inc(v_row_435_);
lean_dec(v_x_390_);
v___x_438_ = lean_box(0);
v_isShared_439_ = v_isSharedCheck_461_;
goto v_resetjp_437_;
}
v_resetjp_437_:
{
lean_object* v___y_441_; lean_object* v___x_457_; uint8_t v___x_458_; 
v___x_457_ = lean_unsigned_to_nat(1024u);
v___x_458_ = lean_nat_dec_le(v___x_457_, v_prec_391_);
if (v___x_458_ == 0)
{
lean_object* v___x_459_; 
v___x_459_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_441_ = v___x_459_;
goto v___jp_440_;
}
else
{
lean_object* v___x_460_; 
v___x_460_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_441_ = v___x_460_;
goto v___jp_440_;
}
v___jp_440_:
{
lean_object* v___x_442_; lean_object* v___x_443_; lean_object* v___x_444_; lean_object* v___x_445_; lean_object* v___x_447_; 
v___x_442_ = lean_box(1);
v___x_443_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__9));
v___x_444_ = l_Nat_reprFast(v_row_435_);
v___x_445_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_445_, 0, v___x_444_);
if (v_isShared_439_ == 0)
{
lean_ctor_set_tag(v___x_438_, 5);
lean_ctor_set(v___x_438_, 1, v___x_445_);
lean_ctor_set(v___x_438_, 0, v___x_443_);
v___x_447_ = v___x_438_;
goto v_reusejp_446_;
}
else
{
lean_object* v_reuseFailAlloc_456_; 
v_reuseFailAlloc_456_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_456_, 0, v___x_443_);
lean_ctor_set(v_reuseFailAlloc_456_, 1, v___x_445_);
v___x_447_ = v_reuseFailAlloc_456_;
goto v_reusejp_446_;
}
v_reusejp_446_:
{
lean_object* v___x_448_; lean_object* v___x_449_; lean_object* v___x_450_; lean_object* v___x_451_; lean_object* v___x_452_; uint8_t v___x_453_; lean_object* v___x_454_; lean_object* v___x_455_; 
v___x_448_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_448_, 0, v___x_447_);
lean_ctor_set(v___x_448_, 1, v___x_442_);
v___x_449_ = l_Nat_reprFast(v_entry_436_);
v___x_450_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_450_, 0, v___x_449_);
v___x_451_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_451_, 0, v___x_448_);
lean_ctor_set(v___x_451_, 1, v___x_450_);
lean_inc(v___y_441_);
v___x_452_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_452_, 0, v___y_441_);
lean_ctor_set(v___x_452_, 1, v___x_451_);
v___x_453_ = 0;
v___x_454_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_454_, 0, v___x_452_);
lean_ctor_set_uint8(v___x_454_, sizeof(void*)*1, v___x_453_);
v___x_455_ = l_Repr_addAppParen(v___x_454_, v_prec_391_);
return v___x_455_;
}
}
}
}
case 4:
{
lean_object* v_row_462_; lean_object* v_entry_463_; lean_object* v___x_465_; uint8_t v_isShared_466_; uint8_t v_isSharedCheck_488_; 
v_row_462_ = lean_ctor_get(v_x_390_, 0);
v_entry_463_ = lean_ctor_get(v_x_390_, 1);
v_isSharedCheck_488_ = !lean_is_exclusive(v_x_390_);
if (v_isSharedCheck_488_ == 0)
{
v___x_465_ = v_x_390_;
v_isShared_466_ = v_isSharedCheck_488_;
goto v_resetjp_464_;
}
else
{
lean_inc(v_entry_463_);
lean_inc(v_row_462_);
lean_dec(v_x_390_);
v___x_465_ = lean_box(0);
v_isShared_466_ = v_isSharedCheck_488_;
goto v_resetjp_464_;
}
v_resetjp_464_:
{
lean_object* v___y_468_; lean_object* v___x_484_; uint8_t v___x_485_; 
v___x_484_ = lean_unsigned_to_nat(1024u);
v___x_485_ = lean_nat_dec_le(v___x_484_, v_prec_391_);
if (v___x_485_ == 0)
{
lean_object* v___x_486_; 
v___x_486_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_468_ = v___x_486_;
goto v___jp_467_;
}
else
{
lean_object* v___x_487_; 
v___x_487_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_468_ = v___x_487_;
goto v___jp_467_;
}
v___jp_467_:
{
lean_object* v___x_469_; lean_object* v___x_470_; lean_object* v___x_471_; lean_object* v___x_472_; lean_object* v___x_474_; 
v___x_469_ = lean_box(1);
v___x_470_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__12));
v___x_471_ = l_Nat_reprFast(v_row_462_);
v___x_472_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_472_, 0, v___x_471_);
if (v_isShared_466_ == 0)
{
lean_ctor_set_tag(v___x_465_, 5);
lean_ctor_set(v___x_465_, 1, v___x_472_);
lean_ctor_set(v___x_465_, 0, v___x_470_);
v___x_474_ = v___x_465_;
goto v_reusejp_473_;
}
else
{
lean_object* v_reuseFailAlloc_483_; 
v_reuseFailAlloc_483_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v_reuseFailAlloc_483_, 0, v___x_470_);
lean_ctor_set(v_reuseFailAlloc_483_, 1, v___x_472_);
v___x_474_ = v_reuseFailAlloc_483_;
goto v_reusejp_473_;
}
v_reusejp_473_:
{
lean_object* v___x_475_; lean_object* v___x_476_; lean_object* v___x_477_; lean_object* v___x_478_; lean_object* v___x_479_; uint8_t v___x_480_; lean_object* v___x_481_; lean_object* v___x_482_; 
v___x_475_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_475_, 0, v___x_474_);
lean_ctor_set(v___x_475_, 1, v___x_469_);
v___x_476_ = l_Nat_reprFast(v_entry_463_);
v___x_477_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_477_, 0, v___x_476_);
v___x_478_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_478_, 0, v___x_475_);
lean_ctor_set(v___x_478_, 1, v___x_477_);
lean_inc(v___y_468_);
v___x_479_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_479_, 0, v___y_468_);
lean_ctor_set(v___x_479_, 1, v___x_478_);
v___x_480_ = 0;
v___x_481_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_481_, 0, v___x_479_);
lean_ctor_set_uint8(v___x_481_, sizeof(void*)*1, v___x_480_);
v___x_482_ = l_Repr_addAppParen(v___x_481_, v_prec_391_);
return v___x_482_;
}
}
}
}
default: 
{
uint8_t v_resource_489_; lean_object* v___y_491_; lean_object* v___x_500_; uint8_t v___x_501_; 
v_resource_489_ = lean_ctor_get_uint8(v_x_390_, 0);
lean_dec_ref_known(v_x_390_, 0);
v___x_500_ = lean_unsigned_to_nat(1024u);
v___x_501_ = lean_nat_dec_le(v___x_500_, v_prec_391_);
if (v___x_501_ == 0)
{
lean_object* v___x_502_; 
v___x_502_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_491_ = v___x_502_;
goto v___jp_490_;
}
else
{
lean_object* v___x_503_; 
v___x_503_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_491_ = v___x_503_;
goto v___jp_490_;
}
v___jp_490_:
{
lean_object* v___x_492_; lean_object* v___x_493_; lean_object* v___x_494_; lean_object* v___x_495_; lean_object* v___x_496_; uint8_t v___x_497_; lean_object* v___x_498_; lean_object* v___x_499_; 
v___x_492_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__15));
v___x_493_ = lean_unsigned_to_nat(1024u);
v___x_494_ = lp_Hex_Hex_Groebner_instReprResource_repr(v_resource_489_, v___x_493_);
v___x_495_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_495_, 0, v___x_492_);
lean_ctor_set(v___x_495_, 1, v___x_494_);
lean_inc(v___y_491_);
v___x_496_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_496_, 0, v___y_491_);
lean_ctor_set(v___x_496_, 1, v___x_495_);
v___x_497_ = 0;
v___x_498_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_498_, 0, v___x_496_);
lean_ctor_set_uint8(v___x_498_, sizeof(void*)*1, v___x_497_);
v___x_499_ = l_Repr_addAppParen(v___x_498_, v_prec_391_);
return v___x_499_;
}
}
}
v___jp_392_:
{
lean_object* v___x_394_; lean_object* v___x_395_; uint8_t v___x_396_; lean_object* v___x_397_; lean_object* v___x_398_; 
v___x_394_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__1));
lean_inc(v___y_393_);
v___x_395_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_395_, 0, v___y_393_);
lean_ctor_set(v___x_395_, 1, v___x_394_);
v___x_396_ = 0;
v___x_397_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_397_, 0, v___x_395_);
lean_ctor_set_uint8(v___x_397_, sizeof(void*)*1, v___x_396_);
v___x_398_ = l_Repr_addAppParen(v___x_397_, v_prec_391_);
return v___x_398_;
}
v___jp_399_:
{
lean_object* v___x_401_; lean_object* v___x_402_; uint8_t v___x_403_; lean_object* v___x_404_; lean_object* v___x_405_; 
v___x_401_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixError_repr___closed__3));
lean_inc(v___y_400_);
v___x_402_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_402_, 0, v___y_400_);
lean_ctor_set(v___x_402_, 1, v___x_401_);
v___x_403_ = 0;
v___x_404_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_404_, 0, v___x_402_);
lean_ctor_set_uint8(v___x_404_, sizeof(void*)*1, v___x_403_);
v___x_405_ = l_Repr_addAppParen(v___x_404_, v_prec_391_);
return v___x_405_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixError_repr___boxed(lean_object* v_x_504_, lean_object* v_prec_505_){
_start:
{
lean_object* v_res_506_; 
v_res_506_ = lp_Hex_Hex_Groebner_instReprMatrixError_repr(v_x_504_, v_prec_505_);
lean_dec(v_prec_505_);
return v_res_506_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Nat_cast___at___00Hex_Groebner_instReprMatrixStats_repr_spec__0(lean_object* v_a_517_){
_start:
{
lean_object* v___x_518_; 
v___x_518_ = lean_nat_to_int(v_a_517_);
return v___x_518_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__7(void){
_start:
{
lean_object* v___x_532_; lean_object* v___x_533_; 
v___x_532_ = lean_unsigned_to_nat(8u);
v___x_533_ = lean_nat_to_int(v___x_532_);
return v___x_533_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__12(void){
_start:
{
lean_object* v___x_540_; lean_object* v___x_541_; 
v___x_540_ = lean_unsigned_to_nat(16u);
v___x_541_ = lean_nat_to_int(v___x_540_);
return v___x_541_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__15(void){
_start:
{
lean_object* v___x_545_; lean_object* v___x_546_; 
v___x_545_ = lean_unsigned_to_nat(17u);
v___x_546_ = lean_nat_to_int(v___x_545_);
return v___x_546_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__18(void){
_start:
{
lean_object* v___x_550_; lean_object* v___x_551_; 
v___x_550_ = lean_unsigned_to_nat(15u);
v___x_551_ = lean_nat_to_int(v___x_550_);
return v___x_551_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__21(void){
_start:
{
lean_object* v___x_555_; lean_object* v___x_556_; 
v___x_555_ = lean_unsigned_to_nat(14u);
v___x_556_ = lean_nat_to_int(v___x_555_);
return v___x_556_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__28(void){
_start:
{
lean_object* v___x_566_; lean_object* v___x_567_; 
v___x_566_ = lean_unsigned_to_nat(12u);
v___x_567_ = lean_nat_to_int(v___x_566_);
return v___x_567_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__30(void){
_start:
{
lean_object* v___x_569_; lean_object* v___x_570_; 
v___x_569_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__0));
v___x_570_ = lean_string_length(v___x_569_);
return v___x_570_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__31(void){
_start:
{
lean_object* v___x_571_; lean_object* v___x_572_; 
v___x_571_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__30, &lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__30_once, _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__30);
v___x_572_ = lean_nat_to_int(v___x_571_);
return v___x_572_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg(lean_object* v_x_577_){
_start:
{
lean_object* v_work_578_; lean_object* v_inputEntries_579_; lean_object* v_outputEntries_580_; lean_object* v_packedBytes_581_; lean_object* v_traceNodes_582_; lean_object* v_processedRows_583_; lean_object* v_reductions_584_; lean_object* v_zeroRows_585_; lean_object* v___x_586_; lean_object* v___x_587_; lean_object* v___x_588_; lean_object* v___x_589_; lean_object* v___x_590_; lean_object* v___x_591_; uint8_t v___x_592_; lean_object* v___x_593_; lean_object* v___x_594_; lean_object* v___x_595_; lean_object* v___x_596_; lean_object* v___x_597_; lean_object* v___x_598_; lean_object* v___x_599_; lean_object* v___x_600_; lean_object* v___x_601_; lean_object* v___x_602_; lean_object* v___x_603_; lean_object* v___x_604_; lean_object* v___x_605_; lean_object* v___x_606_; lean_object* v___x_607_; lean_object* v___x_608_; lean_object* v___x_609_; lean_object* v___x_610_; lean_object* v___x_611_; lean_object* v___x_612_; lean_object* v___x_613_; lean_object* v___x_614_; lean_object* v___x_615_; lean_object* v___x_616_; lean_object* v___x_617_; lean_object* v___x_618_; lean_object* v___x_619_; lean_object* v___x_620_; lean_object* v___x_621_; lean_object* v___x_622_; lean_object* v___x_623_; lean_object* v___x_624_; lean_object* v___x_625_; lean_object* v___x_626_; lean_object* v___x_627_; lean_object* v___x_628_; lean_object* v___x_629_; lean_object* v___x_630_; lean_object* v___x_631_; lean_object* v___x_632_; lean_object* v___x_633_; lean_object* v___x_634_; lean_object* v___x_635_; lean_object* v___x_636_; lean_object* v___x_637_; lean_object* v___x_638_; lean_object* v___x_639_; lean_object* v___x_640_; lean_object* v___x_641_; lean_object* v___x_642_; lean_object* v___x_643_; lean_object* v___x_644_; lean_object* v___x_645_; lean_object* v___x_646_; lean_object* v___x_647_; lean_object* v___x_648_; lean_object* v___x_649_; lean_object* v___x_650_; lean_object* v___x_651_; lean_object* v___x_652_; lean_object* v___x_653_; lean_object* v___x_654_; lean_object* v___x_655_; lean_object* v___x_656_; lean_object* v___x_657_; lean_object* v___x_658_; lean_object* v___x_659_; lean_object* v___x_660_; lean_object* v___x_661_; lean_object* v___x_662_; lean_object* v___x_663_; lean_object* v___x_664_; lean_object* v___x_665_; lean_object* v___x_666_; lean_object* v___x_667_; lean_object* v___x_668_; lean_object* v___x_669_; lean_object* v___x_670_; lean_object* v___x_671_; lean_object* v___x_672_; lean_object* v___x_673_; lean_object* v___x_674_; lean_object* v___x_675_; lean_object* v___x_676_; lean_object* v___x_677_; lean_object* v___x_678_; 
v_work_578_ = lean_ctor_get(v_x_577_, 0);
lean_inc(v_work_578_);
v_inputEntries_579_ = lean_ctor_get(v_x_577_, 1);
lean_inc(v_inputEntries_579_);
v_outputEntries_580_ = lean_ctor_get(v_x_577_, 2);
lean_inc(v_outputEntries_580_);
v_packedBytes_581_ = lean_ctor_get(v_x_577_, 3);
lean_inc(v_packedBytes_581_);
v_traceNodes_582_ = lean_ctor_get(v_x_577_, 4);
lean_inc(v_traceNodes_582_);
v_processedRows_583_ = lean_ctor_get(v_x_577_, 5);
lean_inc(v_processedRows_583_);
v_reductions_584_ = lean_ctor_get(v_x_577_, 6);
lean_inc(v_reductions_584_);
v_zeroRows_585_ = lean_ctor_get(v_x_577_, 7);
lean_inc(v_zeroRows_585_);
lean_dec_ref(v_x_577_);
v___x_586_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__5));
v___x_587_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__6));
v___x_588_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__7, &lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__7_once, _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__7);
v___x_589_ = l_Nat_reprFast(v_work_578_);
v___x_590_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_590_, 0, v___x_589_);
v___x_591_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_591_, 0, v___x_588_);
lean_ctor_set(v___x_591_, 1, v___x_590_);
v___x_592_ = 0;
v___x_593_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_593_, 0, v___x_591_);
lean_ctor_set_uint8(v___x_593_, sizeof(void*)*1, v___x_592_);
v___x_594_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_594_, 0, v___x_587_);
lean_ctor_set(v___x_594_, 1, v___x_593_);
v___x_595_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__9));
v___x_596_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_596_, 0, v___x_594_);
lean_ctor_set(v___x_596_, 1, v___x_595_);
v___x_597_ = lean_box(1);
v___x_598_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_598_, 0, v___x_596_);
lean_ctor_set(v___x_598_, 1, v___x_597_);
v___x_599_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__11));
v___x_600_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_600_, 0, v___x_598_);
lean_ctor_set(v___x_600_, 1, v___x_599_);
v___x_601_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_601_, 0, v___x_600_);
lean_ctor_set(v___x_601_, 1, v___x_586_);
v___x_602_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__12, &lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__12_once, _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__12);
v___x_603_ = l_Nat_reprFast(v_inputEntries_579_);
v___x_604_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_604_, 0, v___x_603_);
v___x_605_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_605_, 0, v___x_602_);
lean_ctor_set(v___x_605_, 1, v___x_604_);
v___x_606_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_606_, 0, v___x_605_);
lean_ctor_set_uint8(v___x_606_, sizeof(void*)*1, v___x_592_);
v___x_607_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_607_, 0, v___x_601_);
lean_ctor_set(v___x_607_, 1, v___x_606_);
v___x_608_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_608_, 0, v___x_607_);
lean_ctor_set(v___x_608_, 1, v___x_595_);
v___x_609_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_609_, 0, v___x_608_);
lean_ctor_set(v___x_609_, 1, v___x_597_);
v___x_610_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__14));
v___x_611_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_611_, 0, v___x_609_);
lean_ctor_set(v___x_611_, 1, v___x_610_);
v___x_612_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_612_, 0, v___x_611_);
lean_ctor_set(v___x_612_, 1, v___x_586_);
v___x_613_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__15, &lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__15);
v___x_614_ = l_Nat_reprFast(v_outputEntries_580_);
v___x_615_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_615_, 0, v___x_614_);
v___x_616_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_616_, 0, v___x_613_);
lean_ctor_set(v___x_616_, 1, v___x_615_);
v___x_617_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_617_, 0, v___x_616_);
lean_ctor_set_uint8(v___x_617_, sizeof(void*)*1, v___x_592_);
v___x_618_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_618_, 0, v___x_612_);
lean_ctor_set(v___x_618_, 1, v___x_617_);
v___x_619_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_619_, 0, v___x_618_);
lean_ctor_set(v___x_619_, 1, v___x_595_);
v___x_620_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_620_, 0, v___x_619_);
lean_ctor_set(v___x_620_, 1, v___x_597_);
v___x_621_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__17));
v___x_622_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_622_, 0, v___x_620_);
lean_ctor_set(v___x_622_, 1, v___x_621_);
v___x_623_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_623_, 0, v___x_622_);
lean_ctor_set(v___x_623_, 1, v___x_586_);
v___x_624_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__18, &lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__18_once, _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__18);
v___x_625_ = l_Nat_reprFast(v_packedBytes_581_);
v___x_626_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_626_, 0, v___x_625_);
v___x_627_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_627_, 0, v___x_624_);
lean_ctor_set(v___x_627_, 1, v___x_626_);
v___x_628_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_628_, 0, v___x_627_);
lean_ctor_set_uint8(v___x_628_, sizeof(void*)*1, v___x_592_);
v___x_629_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_629_, 0, v___x_623_);
lean_ctor_set(v___x_629_, 1, v___x_628_);
v___x_630_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_630_, 0, v___x_629_);
lean_ctor_set(v___x_630_, 1, v___x_595_);
v___x_631_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_631_, 0, v___x_630_);
lean_ctor_set(v___x_631_, 1, v___x_597_);
v___x_632_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__20));
v___x_633_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_633_, 0, v___x_631_);
lean_ctor_set(v___x_633_, 1, v___x_632_);
v___x_634_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_634_, 0, v___x_633_);
lean_ctor_set(v___x_634_, 1, v___x_586_);
v___x_635_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__21, &lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__21_once, _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__21);
v___x_636_ = l_Nat_reprFast(v_traceNodes_582_);
v___x_637_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_637_, 0, v___x_636_);
v___x_638_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_638_, 0, v___x_635_);
lean_ctor_set(v___x_638_, 1, v___x_637_);
v___x_639_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_639_, 0, v___x_638_);
lean_ctor_set_uint8(v___x_639_, sizeof(void*)*1, v___x_592_);
v___x_640_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_640_, 0, v___x_634_);
lean_ctor_set(v___x_640_, 1, v___x_639_);
v___x_641_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_641_, 0, v___x_640_);
lean_ctor_set(v___x_641_, 1, v___x_595_);
v___x_642_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_642_, 0, v___x_641_);
lean_ctor_set(v___x_642_, 1, v___x_597_);
v___x_643_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__23));
v___x_644_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_644_, 0, v___x_642_);
lean_ctor_set(v___x_644_, 1, v___x_643_);
v___x_645_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_645_, 0, v___x_644_);
lean_ctor_set(v___x_645_, 1, v___x_586_);
v___x_646_ = l_Nat_reprFast(v_processedRows_583_);
v___x_647_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_647_, 0, v___x_646_);
v___x_648_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_648_, 0, v___x_613_);
lean_ctor_set(v___x_648_, 1, v___x_647_);
v___x_649_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_649_, 0, v___x_648_);
lean_ctor_set_uint8(v___x_649_, sizeof(void*)*1, v___x_592_);
v___x_650_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_650_, 0, v___x_645_);
lean_ctor_set(v___x_650_, 1, v___x_649_);
v___x_651_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_651_, 0, v___x_650_);
lean_ctor_set(v___x_651_, 1, v___x_595_);
v___x_652_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_652_, 0, v___x_651_);
lean_ctor_set(v___x_652_, 1, v___x_597_);
v___x_653_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__25));
v___x_654_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_654_, 0, v___x_652_);
lean_ctor_set(v___x_654_, 1, v___x_653_);
v___x_655_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_655_, 0, v___x_654_);
lean_ctor_set(v___x_655_, 1, v___x_586_);
v___x_656_ = l_Nat_reprFast(v_reductions_584_);
v___x_657_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_657_, 0, v___x_656_);
v___x_658_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_658_, 0, v___x_635_);
lean_ctor_set(v___x_658_, 1, v___x_657_);
v___x_659_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_659_, 0, v___x_658_);
lean_ctor_set_uint8(v___x_659_, sizeof(void*)*1, v___x_592_);
v___x_660_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_660_, 0, v___x_655_);
lean_ctor_set(v___x_660_, 1, v___x_659_);
v___x_661_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_661_, 0, v___x_660_);
lean_ctor_set(v___x_661_, 1, v___x_595_);
v___x_662_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_662_, 0, v___x_661_);
lean_ctor_set(v___x_662_, 1, v___x_597_);
v___x_663_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__27));
v___x_664_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_664_, 0, v___x_662_);
lean_ctor_set(v___x_664_, 1, v___x_663_);
v___x_665_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_665_, 0, v___x_664_);
lean_ctor_set(v___x_665_, 1, v___x_586_);
v___x_666_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__28, &lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__28_once, _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__28);
v___x_667_ = l_Nat_reprFast(v_zeroRows_585_);
v___x_668_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_668_, 0, v___x_667_);
v___x_669_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_669_, 0, v___x_666_);
lean_ctor_set(v___x_669_, 1, v___x_668_);
v___x_670_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_670_, 0, v___x_669_);
lean_ctor_set_uint8(v___x_670_, sizeof(void*)*1, v___x_592_);
v___x_671_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_671_, 0, v___x_665_);
lean_ctor_set(v___x_671_, 1, v___x_670_);
v___x_672_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__31, &lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__31_once, _init_lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__31);
v___x_673_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__32));
v___x_674_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_674_, 0, v___x_673_);
lean_ctor_set(v___x_674_, 1, v___x_671_);
v___x_675_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg___closed__33));
v___x_676_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_676_, 0, v___x_674_);
lean_ctor_set(v___x_676_, 1, v___x_675_);
v___x_677_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_677_, 0, v___x_672_);
lean_ctor_set(v___x_677_, 1, v___x_676_);
v___x_678_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_678_, 0, v___x_677_);
lean_ctor_set_uint8(v___x_678_, sizeof(void*)*1, v___x_592_);
return v___x_678_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr(lean_object* v_x_679_, lean_object* v_prec_680_){
_start:
{
lean_object* v___x_681_; 
v___x_681_ = lp_Hex_Hex_Groebner_instReprMatrixStats_repr___redArg(v_x_679_);
return v___x_681_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprMatrixStats_repr___boxed(lean_object* v_x_682_, lean_object* v_prec_683_){
_start:
{
lean_object* v_res_684_; 
v_res_684_ = lp_Hex_Hex_Groebner_instReprMatrixStats_repr(v_x_682_, v_prec_683_);
lean_dec(v_prec_683_);
return v_res_684_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqMatrixStats_beq(lean_object* v_x_687_, lean_object* v_x_688_){
_start:
{
lean_object* v_work_689_; lean_object* v_inputEntries_690_; lean_object* v_outputEntries_691_; lean_object* v_packedBytes_692_; lean_object* v_traceNodes_693_; lean_object* v_processedRows_694_; lean_object* v_reductions_695_; lean_object* v_zeroRows_696_; lean_object* v_work_697_; lean_object* v_inputEntries_698_; lean_object* v_outputEntries_699_; lean_object* v_packedBytes_700_; lean_object* v_traceNodes_701_; lean_object* v_processedRows_702_; lean_object* v_reductions_703_; lean_object* v_zeroRows_704_; uint8_t v___x_705_; 
v_work_689_ = lean_ctor_get(v_x_687_, 0);
v_inputEntries_690_ = lean_ctor_get(v_x_687_, 1);
v_outputEntries_691_ = lean_ctor_get(v_x_687_, 2);
v_packedBytes_692_ = lean_ctor_get(v_x_687_, 3);
v_traceNodes_693_ = lean_ctor_get(v_x_687_, 4);
v_processedRows_694_ = lean_ctor_get(v_x_687_, 5);
v_reductions_695_ = lean_ctor_get(v_x_687_, 6);
v_zeroRows_696_ = lean_ctor_get(v_x_687_, 7);
v_work_697_ = lean_ctor_get(v_x_688_, 0);
v_inputEntries_698_ = lean_ctor_get(v_x_688_, 1);
v_outputEntries_699_ = lean_ctor_get(v_x_688_, 2);
v_packedBytes_700_ = lean_ctor_get(v_x_688_, 3);
v_traceNodes_701_ = lean_ctor_get(v_x_688_, 4);
v_processedRows_702_ = lean_ctor_get(v_x_688_, 5);
v_reductions_703_ = lean_ctor_get(v_x_688_, 6);
v_zeroRows_704_ = lean_ctor_get(v_x_688_, 7);
v___x_705_ = lean_nat_dec_eq(v_work_689_, v_work_697_);
if (v___x_705_ == 0)
{
return v___x_705_;
}
else
{
uint8_t v___x_706_; 
v___x_706_ = lean_nat_dec_eq(v_inputEntries_690_, v_inputEntries_698_);
if (v___x_706_ == 0)
{
return v___x_706_;
}
else
{
uint8_t v___x_707_; 
v___x_707_ = lean_nat_dec_eq(v_outputEntries_691_, v_outputEntries_699_);
if (v___x_707_ == 0)
{
return v___x_707_;
}
else
{
uint8_t v___x_708_; 
v___x_708_ = lean_nat_dec_eq(v_packedBytes_692_, v_packedBytes_700_);
if (v___x_708_ == 0)
{
return v___x_708_;
}
else
{
uint8_t v___x_709_; 
v___x_709_ = lean_nat_dec_eq(v_traceNodes_693_, v_traceNodes_701_);
if (v___x_709_ == 0)
{
return v___x_709_;
}
else
{
uint8_t v___x_710_; 
v___x_710_ = lean_nat_dec_eq(v_processedRows_694_, v_processedRows_702_);
if (v___x_710_ == 0)
{
return v___x_710_;
}
else
{
uint8_t v___x_711_; 
v___x_711_ = lean_nat_dec_eq(v_reductions_695_, v_reductions_703_);
if (v___x_711_ == 0)
{
return v___x_711_;
}
else
{
uint8_t v___x_712_; 
v___x_712_ = lean_nat_dec_eq(v_zeroRows_696_, v_zeroRows_704_);
return v___x_712_;
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqMatrixStats_beq___boxed(lean_object* v_x_713_, lean_object* v_x_714_){
_start:
{
uint8_t v_res_715_; lean_object* v_r_716_; 
v_res_715_ = lp_Hex_Hex_Groebner_instBEqMatrixStats_beq(v_x_713_, v_x_714_);
lean_dec_ref(v_x_714_);
lean_dec_ref(v_x_713_);
v_r_716_ = lean_box(v_res_715_);
return v_r_716_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorIdx(lean_object* v_x_723_){
_start:
{
switch(lean_obj_tag(v_x_723_))
{
case 0:
{
lean_object* v___x_724_; 
v___x_724_ = lean_unsigned_to_nat(0u);
return v___x_724_;
}
case 1:
{
lean_object* v___x_725_; 
v___x_725_ = lean_unsigned_to_nat(1u);
return v___x_725_;
}
default: 
{
lean_object* v___x_726_; 
v___x_726_ = lean_unsigned_to_nat(2u);
return v___x_726_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorIdx___boxed(lean_object* v_x_727_){
_start:
{
lean_object* v_res_728_; 
v_res_728_ = lp_Hex_Hex_Groebner_RowOp_ctorIdx(v_x_727_);
lean_dec_ref(v_x_727_);
return v_res_728_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorElim___redArg(lean_object* v_t_729_, lean_object* v_k_730_){
_start:
{
switch(lean_obj_tag(v_t_729_))
{
case 0:
{
lean_object* v_row_731_; lean_object* v___x_732_; 
v_row_731_ = lean_ctor_get(v_t_729_, 0);
lean_inc(v_row_731_);
lean_dec_ref_known(v_t_729_, 1);
v___x_732_ = lean_apply_1(v_k_730_, v_row_731_);
return v___x_732_;
}
case 1:
{
lean_object* v_left_733_; lean_object* v_right_734_; uint64_t v_coefficient_735_; lean_object* v___x_736_; lean_object* v___x_737_; 
v_left_733_ = lean_ctor_get(v_t_729_, 0);
lean_inc(v_left_733_);
v_right_734_ = lean_ctor_get(v_t_729_, 1);
lean_inc(v_right_734_);
v_coefficient_735_ = lean_ctor_get_uint64(v_t_729_, sizeof(void*)*2);
lean_dec_ref_known(v_t_729_, 2);
v___x_736_ = lean_box_uint64(v_coefficient_735_);
v___x_737_ = lean_apply_3(v_k_730_, v_left_733_, v_right_734_, v___x_736_);
return v___x_737_;
}
default: 
{
lean_object* v_row_738_; uint64_t v_coefficient_739_; lean_object* v___x_740_; lean_object* v___x_741_; 
v_row_738_ = lean_ctor_get(v_t_729_, 0);
lean_inc(v_row_738_);
v_coefficient_739_ = lean_ctor_get_uint64(v_t_729_, sizeof(void*)*1);
lean_dec_ref_known(v_t_729_, 1);
v___x_740_ = lean_box_uint64(v_coefficient_739_);
v___x_741_ = lean_apply_2(v_k_730_, v_row_738_, v___x_740_);
return v___x_741_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorElim(lean_object* v_motive_742_, lean_object* v_ctorIdx_743_, lean_object* v_t_744_, lean_object* v_h_745_, lean_object* v_k_746_){
_start:
{
lean_object* v___x_747_; 
v___x_747_ = lp_Hex_Hex_Groebner_RowOp_ctorElim___redArg(v_t_744_, v_k_746_);
return v___x_747_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_ctorElim___boxed(lean_object* v_motive_748_, lean_object* v_ctorIdx_749_, lean_object* v_t_750_, lean_object* v_h_751_, lean_object* v_k_752_){
_start:
{
lean_object* v_res_753_; 
v_res_753_ = lp_Hex_Hex_Groebner_RowOp_ctorElim(v_motive_748_, v_ctorIdx_749_, v_t_750_, v_h_751_, v_k_752_);
lean_dec(v_ctorIdx_749_);
return v_res_753_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_input_elim___redArg(lean_object* v_t_754_, lean_object* v_input_755_){
_start:
{
lean_object* v___x_756_; 
v___x_756_ = lp_Hex_Hex_Groebner_RowOp_ctorElim___redArg(v_t_754_, v_input_755_);
return v___x_756_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_input_elim(lean_object* v_motive_757_, lean_object* v_t_758_, lean_object* v_h_759_, lean_object* v_input_760_){
_start:
{
lean_object* v___x_761_; 
v___x_761_ = lp_Hex_Hex_Groebner_RowOp_ctorElim___redArg(v_t_758_, v_input_760_);
return v___x_761_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_addScaled_elim___redArg(lean_object* v_t_762_, lean_object* v_addScaled_763_){
_start:
{
lean_object* v___x_764_; 
v___x_764_ = lp_Hex_Hex_Groebner_RowOp_ctorElim___redArg(v_t_762_, v_addScaled_763_);
return v___x_764_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_addScaled_elim(lean_object* v_motive_765_, lean_object* v_t_766_, lean_object* v_h_767_, lean_object* v_addScaled_768_){
_start:
{
lean_object* v___x_769_; 
v___x_769_ = lp_Hex_Hex_Groebner_RowOp_ctorElim___redArg(v_t_766_, v_addScaled_768_);
return v___x_769_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_scale_elim___redArg(lean_object* v_t_770_, lean_object* v_scale_771_){
_start:
{
lean_object* v___x_772_; 
v___x_772_ = lp_Hex_Hex_Groebner_RowOp_ctorElim___redArg(v_t_770_, v_scale_771_);
return v___x_772_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_RowOp_scale_elim(lean_object* v_motive_773_, lean_object* v_t_774_, lean_object* v_h_775_, lean_object* v_scale_776_){
_start:
{
lean_object* v___x_777_; 
v___x_777_ = lp_Hex_Hex_Groebner_RowOp_ctorElim___redArg(v_t_774_, v_scale_776_);
return v___x_777_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr(lean_object* v_x_796_, lean_object* v_prec_797_){
_start:
{
switch(lean_obj_tag(v_x_796_))
{
case 0:
{
lean_object* v_row_798_; lean_object* v___x_800_; uint8_t v_isShared_801_; uint8_t v_isSharedCheck_818_; 
v_row_798_ = lean_ctor_get(v_x_796_, 0);
v_isSharedCheck_818_ = !lean_is_exclusive(v_x_796_);
if (v_isSharedCheck_818_ == 0)
{
v___x_800_ = v_x_796_;
v_isShared_801_ = v_isSharedCheck_818_;
goto v_resetjp_799_;
}
else
{
lean_inc(v_row_798_);
lean_dec(v_x_796_);
v___x_800_ = lean_box(0);
v_isShared_801_ = v_isSharedCheck_818_;
goto v_resetjp_799_;
}
v_resetjp_799_:
{
lean_object* v___y_803_; lean_object* v___x_814_; uint8_t v___x_815_; 
v___x_814_ = lean_unsigned_to_nat(1024u);
v___x_815_ = lean_nat_dec_le(v___x_814_, v_prec_797_);
if (v___x_815_ == 0)
{
lean_object* v___x_816_; 
v___x_816_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_803_ = v___x_816_;
goto v___jp_802_;
}
else
{
lean_object* v___x_817_; 
v___x_817_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_803_ = v___x_817_;
goto v___jp_802_;
}
v___jp_802_:
{
lean_object* v___x_804_; lean_object* v___x_805_; lean_object* v___x_807_; 
v___x_804_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__2));
v___x_805_ = l_Nat_reprFast(v_row_798_);
if (v_isShared_801_ == 0)
{
lean_ctor_set_tag(v___x_800_, 3);
lean_ctor_set(v___x_800_, 0, v___x_805_);
v___x_807_ = v___x_800_;
goto v_reusejp_806_;
}
else
{
lean_object* v_reuseFailAlloc_813_; 
v_reuseFailAlloc_813_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v_reuseFailAlloc_813_, 0, v___x_805_);
v___x_807_ = v_reuseFailAlloc_813_;
goto v_reusejp_806_;
}
v_reusejp_806_:
{
lean_object* v___x_808_; lean_object* v___x_809_; uint8_t v___x_810_; lean_object* v___x_811_; lean_object* v___x_812_; 
v___x_808_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_808_, 0, v___x_804_);
lean_ctor_set(v___x_808_, 1, v___x_807_);
lean_inc(v___y_803_);
v___x_809_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_809_, 0, v___y_803_);
lean_ctor_set(v___x_809_, 1, v___x_808_);
v___x_810_ = 0;
v___x_811_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_811_, 0, v___x_809_);
lean_ctor_set_uint8(v___x_811_, sizeof(void*)*1, v___x_810_);
v___x_812_ = l_Repr_addAppParen(v___x_811_, v_prec_797_);
return v___x_812_;
}
}
}
}
case 1:
{
lean_object* v_left_819_; lean_object* v_right_820_; uint64_t v_coefficient_821_; lean_object* v___y_823_; lean_object* v___x_842_; uint8_t v___x_843_; 
v_left_819_ = lean_ctor_get(v_x_796_, 0);
lean_inc(v_left_819_);
v_right_820_ = lean_ctor_get(v_x_796_, 1);
lean_inc(v_right_820_);
v_coefficient_821_ = lean_ctor_get_uint64(v_x_796_, sizeof(void*)*2);
lean_dec_ref_known(v_x_796_, 2);
v___x_842_ = lean_unsigned_to_nat(1024u);
v___x_843_ = lean_nat_dec_le(v___x_842_, v_prec_797_);
if (v___x_843_ == 0)
{
lean_object* v___x_844_; 
v___x_844_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_823_ = v___x_844_;
goto v___jp_822_;
}
else
{
lean_object* v___x_845_; 
v___x_845_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_823_ = v___x_845_;
goto v___jp_822_;
}
v___jp_822_:
{
lean_object* v___x_824_; lean_object* v___x_825_; lean_object* v___x_826_; lean_object* v___x_827_; lean_object* v___x_828_; lean_object* v___x_829_; lean_object* v___x_830_; lean_object* v___x_831_; lean_object* v___x_832_; lean_object* v___x_833_; lean_object* v___x_834_; lean_object* v___x_835_; lean_object* v___x_836_; lean_object* v___x_837_; lean_object* v___x_838_; uint8_t v___x_839_; lean_object* v___x_840_; lean_object* v___x_841_; 
v___x_824_ = lean_box(1);
v___x_825_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__5));
v___x_826_ = l_Nat_reprFast(v_left_819_);
v___x_827_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_827_, 0, v___x_826_);
v___x_828_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_828_, 0, v___x_825_);
lean_ctor_set(v___x_828_, 1, v___x_827_);
v___x_829_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_829_, 0, v___x_828_);
lean_ctor_set(v___x_829_, 1, v___x_824_);
v___x_830_ = l_Nat_reprFast(v_right_820_);
v___x_831_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_831_, 0, v___x_830_);
v___x_832_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_832_, 0, v___x_829_);
lean_ctor_set(v___x_832_, 1, v___x_831_);
v___x_833_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_833_, 0, v___x_832_);
lean_ctor_set(v___x_833_, 1, v___x_824_);
v___x_834_ = lean_uint64_to_nat(v_coefficient_821_);
v___x_835_ = l_Nat_reprFast(v___x_834_);
v___x_836_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_836_, 0, v___x_835_);
v___x_837_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_837_, 0, v___x_833_);
lean_ctor_set(v___x_837_, 1, v___x_836_);
lean_inc(v___y_823_);
v___x_838_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_838_, 0, v___y_823_);
lean_ctor_set(v___x_838_, 1, v___x_837_);
v___x_839_ = 0;
v___x_840_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_840_, 0, v___x_838_);
lean_ctor_set_uint8(v___x_840_, sizeof(void*)*1, v___x_839_);
v___x_841_ = l_Repr_addAppParen(v___x_840_, v_prec_797_);
return v___x_841_;
}
}
default: 
{
lean_object* v_row_846_; uint64_t v_coefficient_847_; lean_object* v___y_849_; lean_object* v___x_864_; uint8_t v___x_865_; 
v_row_846_ = lean_ctor_get(v_x_796_, 0);
lean_inc(v_row_846_);
v_coefficient_847_ = lean_ctor_get_uint64(v_x_796_, sizeof(void*)*1);
lean_dec_ref_known(v_x_796_, 1);
v___x_864_ = lean_unsigned_to_nat(1024u);
v___x_865_ = lean_nat_dec_le(v___x_864_, v_prec_797_);
if (v___x_865_ == 0)
{
lean_object* v___x_866_; 
v___x_866_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__14, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__14_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__14);
v___y_849_ = v___x_866_;
goto v___jp_848_;
}
else
{
lean_object* v___x_867_; 
v___x_867_ = lean_obj_once(&lp_Hex_Hex_Groebner_instReprResource_repr___closed__15, &lp_Hex_Hex_Groebner_instReprResource_repr___closed__15_once, _init_lp_Hex_Hex_Groebner_instReprResource_repr___closed__15);
v___y_849_ = v___x_867_;
goto v___jp_848_;
}
v___jp_848_:
{
lean_object* v___x_850_; lean_object* v___x_851_; lean_object* v___x_852_; lean_object* v___x_853_; lean_object* v___x_854_; lean_object* v___x_855_; lean_object* v___x_856_; lean_object* v___x_857_; lean_object* v___x_858_; lean_object* v___x_859_; lean_object* v___x_860_; uint8_t v___x_861_; lean_object* v___x_862_; lean_object* v___x_863_; 
v___x_850_ = lean_box(1);
v___x_851_ = ((lean_object*)(lp_Hex_Hex_Groebner_instReprRowOp_repr___closed__8));
v___x_852_ = l_Nat_reprFast(v_row_846_);
v___x_853_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_853_, 0, v___x_852_);
v___x_854_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_854_, 0, v___x_851_);
lean_ctor_set(v___x_854_, 1, v___x_853_);
v___x_855_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_855_, 0, v___x_854_);
lean_ctor_set(v___x_855_, 1, v___x_850_);
v___x_856_ = lean_uint64_to_nat(v_coefficient_847_);
v___x_857_ = l_Nat_reprFast(v___x_856_);
v___x_858_ = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(v___x_858_, 0, v___x_857_);
v___x_859_ = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(v___x_859_, 0, v___x_855_);
lean_ctor_set(v___x_859_, 1, v___x_858_);
lean_inc(v___y_849_);
v___x_860_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_860_, 0, v___y_849_);
lean_ctor_set(v___x_860_, 1, v___x_859_);
v___x_861_ = 0;
v___x_862_ = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(v___x_862_, 0, v___x_860_);
lean_ctor_set_uint8(v___x_862_, sizeof(void*)*1, v___x_861_);
v___x_863_ = l_Repr_addAppParen(v___x_862_, v_prec_797_);
return v___x_863_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instReprRowOp_repr___boxed(lean_object* v_x_868_, lean_object* v_prec_869_){
_start:
{
lean_object* v_res_870_; 
v_res_870_ = lp_Hex_Hex_Groebner_instReprRowOp_repr(v_x_868_, v_prec_869_);
lean_dec(v_prec_869_);
return v_res_870_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_instBEqRowOp_beq(lean_object* v_x_873_, lean_object* v_x_874_){
_start:
{
switch(lean_obj_tag(v_x_873_))
{
case 0:
{
if (lean_obj_tag(v_x_874_) == 0)
{
lean_object* v_row_875_; lean_object* v_row_876_; uint8_t v___x_877_; 
v_row_875_ = lean_ctor_get(v_x_873_, 0);
v_row_876_ = lean_ctor_get(v_x_874_, 0);
v___x_877_ = lean_nat_dec_eq(v_row_875_, v_row_876_);
return v___x_877_;
}
else
{
uint8_t v___x_878_; 
v___x_878_ = 0;
return v___x_878_;
}
}
case 1:
{
if (lean_obj_tag(v_x_874_) == 1)
{
lean_object* v_left_879_; lean_object* v_right_880_; uint64_t v_coefficient_881_; lean_object* v_left_882_; lean_object* v_right_883_; uint64_t v_coefficient_884_; uint8_t v___x_885_; 
v_left_879_ = lean_ctor_get(v_x_873_, 0);
v_right_880_ = lean_ctor_get(v_x_873_, 1);
v_coefficient_881_ = lean_ctor_get_uint64(v_x_873_, sizeof(void*)*2);
v_left_882_ = lean_ctor_get(v_x_874_, 0);
v_right_883_ = lean_ctor_get(v_x_874_, 1);
v_coefficient_884_ = lean_ctor_get_uint64(v_x_874_, sizeof(void*)*2);
v___x_885_ = lean_nat_dec_eq(v_left_879_, v_left_882_);
if (v___x_885_ == 0)
{
return v___x_885_;
}
else
{
uint8_t v___x_886_; 
v___x_886_ = lean_nat_dec_eq(v_right_880_, v_right_883_);
if (v___x_886_ == 0)
{
return v___x_886_;
}
else
{
uint8_t v___x_887_; 
v___x_887_ = lean_uint64_dec_eq(v_coefficient_881_, v_coefficient_884_);
return v___x_887_;
}
}
}
else
{
uint8_t v___x_888_; 
v___x_888_ = 0;
return v___x_888_;
}
}
default: 
{
if (lean_obj_tag(v_x_874_) == 2)
{
lean_object* v_row_889_; uint64_t v_coefficient_890_; lean_object* v_row_891_; uint64_t v_coefficient_892_; uint8_t v___x_893_; 
v_row_889_ = lean_ctor_get(v_x_873_, 0);
v_coefficient_890_ = lean_ctor_get_uint64(v_x_873_, sizeof(void*)*1);
v_row_891_ = lean_ctor_get(v_x_874_, 0);
v_coefficient_892_ = lean_ctor_get_uint64(v_x_874_, sizeof(void*)*1);
v___x_893_ = lean_nat_dec_eq(v_row_889_, v_row_891_);
if (v___x_893_ == 0)
{
return v___x_893_;
}
else
{
uint8_t v___x_894_; 
v___x_894_ = lean_uint64_dec_eq(v_coefficient_890_, v_coefficient_892_);
return v___x_894_;
}
}
else
{
uint8_t v___x_895_; 
v___x_895_ = 0;
return v___x_895_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_instBEqRowOp_beq___boxed(lean_object* v_x_896_, lean_object* v_x_897_){
_start:
{
uint8_t v_res_898_; lean_object* v_r_899_; 
v_res_898_ = lp_Hex_Hex_Groebner_instBEqRowOp_beq(v_x_896_, v_x_897_);
lean_dec_ref(v_x_897_);
lean_dec_ref(v_x_896_);
v_r_899_ = lean_box(v_res_898_);
return v_r_899_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedPivot_default___closed__0(void){
_start:
{
lean_object* v___x_902_; uint64_t v___x_903_; lean_object* v___x_904_; uint8_t v___x_905_; lean_object* v___x_906_; lean_object* v___x_907_; 
v___x_902_ = lean_unsigned_to_nat(0u);
v___x_903_ = 1ULL;
v___x_904_ = lean_box(0);
v___x_905_ = 0;
v___x_906_ = lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
v___x_907_ = lean_alloc_ctor(0, 3, 9);
lean_ctor_set(v___x_907_, 0, v___x_906_);
lean_ctor_set(v___x_907_, 1, v___x_904_);
lean_ctor_set(v___x_907_, 2, v___x_902_);
lean_ctor_set_uint8(v___x_907_, sizeof(void*)*3 + 8, v___x_905_);
lean_ctor_set_uint64(v___x_907_, sizeof(void*)*3, v___x_903_);
return v___x_907_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedPivot_default(void){
_start:
{
lean_object* v___x_908_; 
v___x_908_ = lean_obj_once(&lp_Hex_Hex_Groebner_instInhabitedPivot_default___closed__0, &lp_Hex_Hex_Groebner_instInhabitedPivot_default___closed__0_once, _init_lp_Hex_Hex_Groebner_instInhabitedPivot_default___closed__0);
return v___x_908_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedPivot(void){
_start:
{
lean_object* v___x_909_; 
v___x_909_ = lp_Hex_Hex_Groebner_instInhabitedPivot_default;
return v___x_909_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default___closed__0(void){
_start:
{
lean_object* v___x_910_; lean_object* v___x_911_; lean_object* v___x_912_; lean_object* v___x_913_; 
v___x_910_ = lean_unsigned_to_nat(0u);
v___x_911_ = lean_box(0);
v___x_912_ = lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
v___x_913_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_913_, 0, v___x_912_);
lean_ctor_set(v___x_913_, 1, v___x_911_);
lean_ctor_set(v___x_913_, 2, v___x_910_);
return v___x_913_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default(void){
_start:
{
lean_object* v___x_914_; 
v___x_914_ = lean_obj_once(&lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default___closed__0, &lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default___closed__0_once, _init_lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default___closed__0);
return v___x_914_;
}
}
static lean_object* _init_lp_Hex_Hex_Groebner_instInhabitedRemainderRow(void){
_start:
{
lean_object* v___x_915_; 
v___x_915_ = lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default;
return v___x_915_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_charge(uint8_t v_resource_918_, lean_object* v_amount_919_, lean_object* v_limit_920_, lean_object* v_getCount_921_, lean_object* v_setCount_922_, lean_object* v_a_923_){
_start:
{
lean_object* v___x_924_; lean_object* v_count_925_; uint8_t v___x_926_; 
lean_inc_ref(v_a_923_);
v___x_924_ = lean_apply_1(v_getCount_921_, v_a_923_);
v_count_925_ = lean_nat_add(v___x_924_, v_amount_919_);
lean_dec(v___x_924_);
v___x_926_ = lean_nat_dec_lt(v_limit_920_, v_count_925_);
if (v___x_926_ == 0)
{
lean_object* v___x_927_; lean_object* v___x_928_; lean_object* v___x_929_; 
v___x_927_ = lean_apply_2(v_setCount_922_, v_a_923_, v_count_925_);
v___x_928_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_charge___closed__0));
v___x_929_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_929_, 0, v___x_928_);
lean_ctor_set(v___x_929_, 1, v___x_927_);
return v___x_929_;
}
else
{
lean_object* v___x_930_; lean_object* v___x_931_; lean_object* v___x_932_; 
lean_dec(v_count_925_);
lean_dec_ref(v_setCount_922_);
v___x_930_ = lean_alloc_ctor(5, 0, 1);
lean_ctor_set_uint8(v___x_930_, 0, v_resource_918_);
v___x_931_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_931_, 0, v___x_930_);
v___x_932_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_932_, 0, v___x_931_);
lean_ctor_set(v___x_932_, 1, v_a_923_);
return v___x_932_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_charge___boxed(lean_object* v_resource_933_, lean_object* v_amount_934_, lean_object* v_limit_935_, lean_object* v_getCount_936_, lean_object* v_setCount_937_, lean_object* v_a_938_){
_start:
{
uint8_t v_resource_boxed_939_; lean_object* v_res_940_; 
v_resource_boxed_939_ = lean_unbox(v_resource_933_);
v_res_940_ = lp_Hex_Hex_Groebner_Matrix_charge(v_resource_boxed_939_, v_amount_934_, v_limit_935_, v_getCount_936_, v_setCount_937_, v_a_938_);
lean_dec(v_limit_935_);
lean_dec(v_amount_934_);
return v_res_940_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work___lam__0(lean_object* v_x_941_){
_start:
{
lean_object* v_work_942_; 
v_work_942_ = lean_ctor_get(v_x_941_, 0);
lean_inc(v_work_942_);
return v_work_942_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work___lam__0___boxed(lean_object* v_x_943_){
_start:
{
lean_object* v_res_944_; 
v_res_944_ = lp_Hex_Hex_Groebner_Matrix_work___lam__0(v_x_943_);
lean_dec_ref(v_x_943_);
return v_res_944_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work___lam__1(lean_object* v_s_945_, lean_object* v_n_946_){
_start:
{
lean_object* v_inputEntries_947_; lean_object* v_outputEntries_948_; lean_object* v_packedBytes_949_; lean_object* v_traceNodes_950_; lean_object* v_processedRows_951_; lean_object* v_reductions_952_; lean_object* v_zeroRows_953_; lean_object* v___x_955_; uint8_t v_isShared_956_; uint8_t v_isSharedCheck_960_; 
v_inputEntries_947_ = lean_ctor_get(v_s_945_, 1);
v_outputEntries_948_ = lean_ctor_get(v_s_945_, 2);
v_packedBytes_949_ = lean_ctor_get(v_s_945_, 3);
v_traceNodes_950_ = lean_ctor_get(v_s_945_, 4);
v_processedRows_951_ = lean_ctor_get(v_s_945_, 5);
v_reductions_952_ = lean_ctor_get(v_s_945_, 6);
v_zeroRows_953_ = lean_ctor_get(v_s_945_, 7);
v_isSharedCheck_960_ = !lean_is_exclusive(v_s_945_);
if (v_isSharedCheck_960_ == 0)
{
lean_object* v_unused_961_; 
v_unused_961_ = lean_ctor_get(v_s_945_, 0);
lean_dec(v_unused_961_);
v___x_955_ = v_s_945_;
v_isShared_956_ = v_isSharedCheck_960_;
goto v_resetjp_954_;
}
else
{
lean_inc(v_zeroRows_953_);
lean_inc(v_reductions_952_);
lean_inc(v_processedRows_951_);
lean_inc(v_traceNodes_950_);
lean_inc(v_packedBytes_949_);
lean_inc(v_outputEntries_948_);
lean_inc(v_inputEntries_947_);
lean_dec(v_s_945_);
v___x_955_ = lean_box(0);
v_isShared_956_ = v_isSharedCheck_960_;
goto v_resetjp_954_;
}
v_resetjp_954_:
{
lean_object* v___x_958_; 
if (v_isShared_956_ == 0)
{
lean_ctor_set(v___x_955_, 0, v_n_946_);
v___x_958_ = v___x_955_;
goto v_reusejp_957_;
}
else
{
lean_object* v_reuseFailAlloc_959_; 
v_reuseFailAlloc_959_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_959_, 0, v_n_946_);
lean_ctor_set(v_reuseFailAlloc_959_, 1, v_inputEntries_947_);
lean_ctor_set(v_reuseFailAlloc_959_, 2, v_outputEntries_948_);
lean_ctor_set(v_reuseFailAlloc_959_, 3, v_packedBytes_949_);
lean_ctor_set(v_reuseFailAlloc_959_, 4, v_traceNodes_950_);
lean_ctor_set(v_reuseFailAlloc_959_, 5, v_processedRows_951_);
lean_ctor_set(v_reuseFailAlloc_959_, 6, v_reductions_952_);
lean_ctor_set(v_reuseFailAlloc_959_, 7, v_zeroRows_953_);
v___x_958_ = v_reuseFailAlloc_959_;
goto v_reusejp_957_;
}
v_reusejp_957_:
{
return v___x_958_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work(lean_object* v_limits_964_, lean_object* v_amount_965_, lean_object* v_a_966_){
_start:
{
lean_object* v_work_967_; lean_object* v___f_968_; lean_object* v___f_969_; uint8_t v___x_970_; lean_object* v___x_971_; 
v_work_967_ = lean_ctor_get(v_limits_964_, 5);
v___f_968_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_work___closed__0));
v___f_969_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_work___closed__1));
v___x_970_ = 5;
v___x_971_ = lp_Hex_Hex_Groebner_Matrix_charge(v___x_970_, v_amount_965_, v_work_967_, v___f_968_, v___f_969_, v_a_966_);
return v___x_971_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_work___boxed(lean_object* v_limits_972_, lean_object* v_amount_973_, lean_object* v_a_974_){
_start:
{
lean_object* v_res_975_; 
v_res_975_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_972_, v_amount_973_, v_a_974_);
lean_dec(v_amount_973_);
lean_dec_ref(v_limits_972_);
return v_res_975_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___lam__0(lean_object* v_x_976_){
_start:
{
lean_object* v_packedBytes_977_; 
v_packedBytes_977_ = lean_ctor_get(v_x_976_, 3);
lean_inc(v_packedBytes_977_);
return v_packedBytes_977_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___lam__0___boxed(lean_object* v_x_978_){
_start:
{
lean_object* v_res_979_; 
v_res_979_ = lp_Hex_Hex_Groebner_Matrix_packedBytes___lam__0(v_x_978_);
lean_dec_ref(v_x_978_);
return v_res_979_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___lam__1(lean_object* v_s_980_, lean_object* v_n_981_){
_start:
{
lean_object* v_work_982_; lean_object* v_inputEntries_983_; lean_object* v_outputEntries_984_; lean_object* v_traceNodes_985_; lean_object* v_processedRows_986_; lean_object* v_reductions_987_; lean_object* v_zeroRows_988_; lean_object* v___x_990_; uint8_t v_isShared_991_; uint8_t v_isSharedCheck_995_; 
v_work_982_ = lean_ctor_get(v_s_980_, 0);
v_inputEntries_983_ = lean_ctor_get(v_s_980_, 1);
v_outputEntries_984_ = lean_ctor_get(v_s_980_, 2);
v_traceNodes_985_ = lean_ctor_get(v_s_980_, 4);
v_processedRows_986_ = lean_ctor_get(v_s_980_, 5);
v_reductions_987_ = lean_ctor_get(v_s_980_, 6);
v_zeroRows_988_ = lean_ctor_get(v_s_980_, 7);
v_isSharedCheck_995_ = !lean_is_exclusive(v_s_980_);
if (v_isSharedCheck_995_ == 0)
{
lean_object* v_unused_996_; 
v_unused_996_ = lean_ctor_get(v_s_980_, 3);
lean_dec(v_unused_996_);
v___x_990_ = v_s_980_;
v_isShared_991_ = v_isSharedCheck_995_;
goto v_resetjp_989_;
}
else
{
lean_inc(v_zeroRows_988_);
lean_inc(v_reductions_987_);
lean_inc(v_processedRows_986_);
lean_inc(v_traceNodes_985_);
lean_inc(v_outputEntries_984_);
lean_inc(v_inputEntries_983_);
lean_inc(v_work_982_);
lean_dec(v_s_980_);
v___x_990_ = lean_box(0);
v_isShared_991_ = v_isSharedCheck_995_;
goto v_resetjp_989_;
}
v_resetjp_989_:
{
lean_object* v___x_993_; 
if (v_isShared_991_ == 0)
{
lean_ctor_set(v___x_990_, 3, v_n_981_);
v___x_993_ = v___x_990_;
goto v_reusejp_992_;
}
else
{
lean_object* v_reuseFailAlloc_994_; 
v_reuseFailAlloc_994_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_994_, 0, v_work_982_);
lean_ctor_set(v_reuseFailAlloc_994_, 1, v_inputEntries_983_);
lean_ctor_set(v_reuseFailAlloc_994_, 2, v_outputEntries_984_);
lean_ctor_set(v_reuseFailAlloc_994_, 3, v_n_981_);
lean_ctor_set(v_reuseFailAlloc_994_, 4, v_traceNodes_985_);
lean_ctor_set(v_reuseFailAlloc_994_, 5, v_processedRows_986_);
lean_ctor_set(v_reuseFailAlloc_994_, 6, v_reductions_987_);
lean_ctor_set(v_reuseFailAlloc_994_, 7, v_zeroRows_988_);
v___x_993_ = v_reuseFailAlloc_994_;
goto v_reusejp_992_;
}
v_reusejp_992_:
{
return v___x_993_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes(lean_object* v_limits_999_, lean_object* v_amount_1000_, lean_object* v_a_1001_){
_start:
{
lean_object* v_packedBytes_1002_; lean_object* v___f_1003_; lean_object* v___f_1004_; uint8_t v___x_1005_; lean_object* v___x_1006_; 
v_packedBytes_1002_ = lean_ctor_get(v_limits_999_, 4);
v___f_1003_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_packedBytes___closed__0));
v___f_1004_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_packedBytes___closed__1));
v___x_1005_ = 4;
v___x_1006_ = lp_Hex_Hex_Groebner_Matrix_charge(v___x_1005_, v_amount_1000_, v_packedBytes_1002_, v___f_1003_, v___f_1004_, v_a_1001_);
return v___x_1006_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes___boxed(lean_object* v_limits_1007_, lean_object* v_amount_1008_, lean_object* v_a_1009_){
_start:
{
lean_object* v_res_1010_; 
v_res_1010_ = lp_Hex_Hex_Groebner_Matrix_packedBytes(v_limits_1007_, v_amount_1008_, v_a_1009_);
lean_dec(v_amount_1008_);
lean_dec_ref(v_limits_1007_);
return v_res_1010_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate___lam__0(lean_object* v_s_1011_, lean_object* v_n_1012_){
_start:
{
lean_object* v_work_1013_; lean_object* v_outputEntries_1014_; lean_object* v_packedBytes_1015_; lean_object* v_traceNodes_1016_; lean_object* v_processedRows_1017_; lean_object* v_reductions_1018_; lean_object* v_zeroRows_1019_; lean_object* v___x_1021_; uint8_t v_isShared_1022_; uint8_t v_isSharedCheck_1026_; 
v_work_1013_ = lean_ctor_get(v_s_1011_, 0);
v_outputEntries_1014_ = lean_ctor_get(v_s_1011_, 2);
v_packedBytes_1015_ = lean_ctor_get(v_s_1011_, 3);
v_traceNodes_1016_ = lean_ctor_get(v_s_1011_, 4);
v_processedRows_1017_ = lean_ctor_get(v_s_1011_, 5);
v_reductions_1018_ = lean_ctor_get(v_s_1011_, 6);
v_zeroRows_1019_ = lean_ctor_get(v_s_1011_, 7);
v_isSharedCheck_1026_ = !lean_is_exclusive(v_s_1011_);
if (v_isSharedCheck_1026_ == 0)
{
lean_object* v_unused_1027_; 
v_unused_1027_ = lean_ctor_get(v_s_1011_, 1);
lean_dec(v_unused_1027_);
v___x_1021_ = v_s_1011_;
v_isShared_1022_ = v_isSharedCheck_1026_;
goto v_resetjp_1020_;
}
else
{
lean_inc(v_zeroRows_1019_);
lean_inc(v_reductions_1018_);
lean_inc(v_processedRows_1017_);
lean_inc(v_traceNodes_1016_);
lean_inc(v_packedBytes_1015_);
lean_inc(v_outputEntries_1014_);
lean_inc(v_work_1013_);
lean_dec(v_s_1011_);
v___x_1021_ = lean_box(0);
v_isShared_1022_ = v_isSharedCheck_1026_;
goto v_resetjp_1020_;
}
v_resetjp_1020_:
{
lean_object* v___x_1024_; 
if (v_isShared_1022_ == 0)
{
lean_ctor_set(v___x_1021_, 1, v_n_1012_);
v___x_1024_ = v___x_1021_;
goto v_reusejp_1023_;
}
else
{
lean_object* v_reuseFailAlloc_1025_; 
v_reuseFailAlloc_1025_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_1025_, 0, v_work_1013_);
lean_ctor_set(v_reuseFailAlloc_1025_, 1, v_n_1012_);
lean_ctor_set(v_reuseFailAlloc_1025_, 2, v_outputEntries_1014_);
lean_ctor_set(v_reuseFailAlloc_1025_, 3, v_packedBytes_1015_);
lean_ctor_set(v_reuseFailAlloc_1025_, 4, v_traceNodes_1016_);
lean_ctor_set(v_reuseFailAlloc_1025_, 5, v_processedRows_1017_);
lean_ctor_set(v_reuseFailAlloc_1025_, 6, v_reductions_1018_);
lean_ctor_set(v_reuseFailAlloc_1025_, 7, v_zeroRows_1019_);
v___x_1024_ = v_reuseFailAlloc_1025_;
goto v_reusejp_1023_;
}
v_reusejp_1023_:
{
return v___x_1024_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate___lam__1(lean_object* v_x_1028_){
_start:
{
lean_object* v_inputEntries_1029_; 
v_inputEntries_1029_ = lean_ctor_get(v_x_1028_, 1);
lean_inc(v_inputEntries_1029_);
return v_inputEntries_1029_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate___lam__1___boxed(lean_object* v_x_1030_){
_start:
{
lean_object* v_res_1031_; 
v_res_1031_ = lp_Hex_Hex_Groebner_Matrix_validate___lam__1(v_x_1030_);
lean_dec_ref(v_x_1030_);
return v_res_1031_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(lean_object* v_xs_1032_, lean_object* v_i_1033_){
_start:
{
lean_object* v___x_1034_; uint8_t v___x_1035_; 
v___x_1034_ = lean_byte_array_size(v_xs_1032_);
v___x_1035_ = lean_nat_dec_lt(v_i_1033_, v___x_1034_);
return v___x_1035_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0___boxed(lean_object* v_xs_1036_, lean_object* v_i_1037_){
_start:
{
uint8_t v_res_1038_; lean_object* v_r_1039_; 
v_res_1038_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v_xs_1036_, v_i_1037_);
lean_dec(v_i_1037_);
lean_dec_ref(v_xs_1036_);
v_r_1039_ = lean_box(v_res_1038_);
return v_r_1039_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg(lean_object* v_index_1040_, uint64_t v_field_1041_, lean_object* v___x_1042_, lean_object* v_columns_1043_, lean_object* v___x_1044_, lean_object* v_range_1045_, lean_object* v_b_1046_, lean_object* v_i_1047_, lean_object* v___y_1048_){
_start:
{
lean_object* v_a_1050_; lean_object* v_snd_1051_; lean_object* v___y_1055_; lean_object* v_stop_1057_; lean_object* v_step_1058_; lean_object* v___y_1060_; lean_object* v___y_1061_; uint64_t v___y_1062_; lean_object* v___y_1070_; uint64_t v___y_1071_; lean_object* v___y_1072_; uint8_t v___y_1073_; uint64_t v___y_1079_; lean_object* v___y_1080_; lean_object* v___y_1081_; uint8_t v___y_1082_; uint8_t v___x_1087_; 
v_stop_1057_ = lean_ctor_get(v_range_1045_, 1);
v_step_1058_ = lean_ctor_get(v_range_1045_, 2);
v___x_1087_ = lean_nat_dec_lt(v_i_1047_, v_stop_1057_);
if (v___x_1087_ == 0)
{
lean_object* v___x_1088_; lean_object* v___x_1089_; 
lean_dec(v_i_1047_);
lean_dec(v_index_1040_);
v___x_1088_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1088_, 0, v_b_1046_);
v___x_1089_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1089_, 0, v___x_1088_);
lean_ctor_set(v___x_1089_, 1, v___y_1048_);
return v___x_1089_;
}
else
{
uint8_t v___y_1091_; lean_object* v___y_1092_; lean_object* v___y_1093_; lean_object* v___y_1094_; uint64_t v___y_1095_; uint8_t v___y_1096_; uint8_t v___y_1109_; lean_object* v___y_1110_; uint64_t v___y_1111_; lean_object* v___y_1112_; lean_object* v___y_1113_; uint8_t v___y_1114_; uint8_t v___y_1127_; uint8_t v___y_1128_; lean_object* v___y_1129_; lean_object* v___y_1130_; lean_object* v___y_1131_; uint8_t v___y_1132_; uint8_t v___y_1149_; uint8_t v___y_1150_; lean_object* v___y_1151_; lean_object* v___y_1152_; lean_object* v___y_1153_; uint8_t v___y_1154_; uint8_t v___y_1192_; uint8_t v___y_1193_; lean_object* v___y_1194_; lean_object* v___y_1195_; lean_object* v___y_1196_; lean_object* v___y_1205_; lean_object* v___y_1206_; uint64_t v___y_1213_; uint64_t v___y_1221_; uint8_t v___y_1222_; uint8_t v___x_1227_; lean_object* v___x_1228_; lean_object* v_offset_1229_; uint64_t v___y_1231_; uint8_t v___y_1232_; uint64_t v___y_1245_; uint8_t v___y_1246_; uint8_t v___y_1259_; uint8_t v___y_1269_; lean_object* v___x_1299_; lean_object* v___x_1300_; uint8_t v___x_1301_; 
v___x_1227_ = 0;
v___x_1228_ = lean_unsigned_to_nat(4u);
v_offset_1229_ = lean_nat_mul(v_i_1047_, v___x_1228_);
v___x_1299_ = lean_nat_add(v_offset_1229_, v___x_1228_);
v___x_1300_ = lean_byte_array_size(v___x_1044_);
v___x_1301_ = lean_nat_dec_le(v___x_1299_, v___x_1300_);
if (v___x_1301_ == 0)
{
lean_dec(v___x_1299_);
v___y_1269_ = v___x_1301_;
goto v___jp_1268_;
}
else
{
size_t v___x_1302_; lean_object* v___x_1303_; uint8_t v___x_1304_; 
v___x_1302_ = lean_usize_of_nat(v___x_1299_);
v___x_1303_ = lean_usize_to_nat(v___x_1302_);
v___x_1304_ = lean_nat_dec_eq(v___x_1303_, v___x_1299_);
lean_dec(v___x_1299_);
lean_dec(v___x_1303_);
v___y_1269_ = v___x_1304_;
goto v___jp_1268_;
}
v___jp_1090_:
{
uint64_t v___x_1097_; uint64_t v___x_1098_; uint64_t v___x_1099_; uint64_t v___x_1100_; lean_object* v___x_1101_; lean_object* v___x_1102_; uint8_t v___x_1103_; 
v___x_1097_ = lean_uint8_to_uint64(v___y_1096_);
v___x_1098_ = 16ULL;
v___x_1099_ = lean_uint64_shift_left(v___x_1097_, v___x_1098_);
v___x_1100_ = lean_uint64_lor(v___y_1095_, v___x_1099_);
v___x_1101_ = lean_unsigned_to_nat(3u);
v___x_1102_ = lean_nat_add(v___y_1093_, v___x_1101_);
lean_dec(v___y_1093_);
v___x_1103_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1042_, v___x_1102_);
if (v___x_1103_ == 0)
{
lean_object* v___x_1104_; lean_object* v___x_1105_; uint8_t v___x_1106_; 
lean_dec(v___x_1102_);
v___x_1104_ = lean_box(v___y_1091_);
v___x_1105_ = l_outOfBounds___redArg(v___x_1104_);
lean_dec(v___x_1104_);
v___x_1106_ = lean_unbox(v___x_1105_);
lean_dec(v___x_1105_);
v___y_1079_ = v___x_1100_;
v___y_1080_ = v___y_1092_;
v___y_1081_ = v___y_1094_;
v___y_1082_ = v___x_1106_;
goto v___jp_1078_;
}
else
{
uint8_t v___x_1107_; 
v___x_1107_ = lean_byte_array_fget(v___x_1042_, v___x_1102_);
lean_dec(v___x_1102_);
v___y_1079_ = v___x_1100_;
v___y_1080_ = v___y_1092_;
v___y_1081_ = v___y_1094_;
v___y_1082_ = v___x_1107_;
goto v___jp_1078_;
}
}
v___jp_1108_:
{
uint64_t v___x_1115_; uint64_t v___x_1116_; uint64_t v___x_1117_; uint64_t v___x_1118_; lean_object* v___x_1119_; lean_object* v___x_1120_; uint8_t v___x_1121_; 
v___x_1115_ = lean_uint8_to_uint64(v___y_1114_);
v___x_1116_ = 8ULL;
v___x_1117_ = lean_uint64_shift_left(v___x_1115_, v___x_1116_);
v___x_1118_ = lean_uint64_lor(v___y_1111_, v___x_1117_);
v___x_1119_ = lean_unsigned_to_nat(2u);
v___x_1120_ = lean_nat_add(v___y_1112_, v___x_1119_);
v___x_1121_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1042_, v___x_1120_);
if (v___x_1121_ == 0)
{
lean_object* v___x_1122_; lean_object* v___x_1123_; uint8_t v___x_1124_; 
lean_dec(v___x_1120_);
v___x_1122_ = lean_box(v___y_1109_);
v___x_1123_ = l_outOfBounds___redArg(v___x_1122_);
lean_dec(v___x_1122_);
v___x_1124_ = lean_unbox(v___x_1123_);
lean_dec(v___x_1123_);
v___y_1091_ = v___y_1109_;
v___y_1092_ = v___y_1110_;
v___y_1093_ = v___y_1112_;
v___y_1094_ = v___y_1113_;
v___y_1095_ = v___x_1118_;
v___y_1096_ = v___x_1124_;
goto v___jp_1090_;
}
else
{
uint8_t v___x_1125_; 
v___x_1125_ = lean_byte_array_fget(v___x_1042_, v___x_1120_);
lean_dec(v___x_1120_);
v___y_1091_ = v___y_1109_;
v___y_1092_ = v___y_1110_;
v___y_1093_ = v___y_1112_;
v___y_1094_ = v___y_1113_;
v___y_1095_ = v___x_1118_;
v___y_1096_ = v___x_1125_;
goto v___jp_1090_;
}
}
v___jp_1126_:
{
uint64_t v_a_1133_; 
v_a_1133_ = lean_uint8_to_uint64(v___y_1132_);
switch(v___y_1127_)
{
case 0:
{
lean_dec(v___y_1130_);
v___y_1060_ = v___y_1129_;
v___y_1061_ = v___y_1131_;
v___y_1062_ = v_a_1133_;
goto v___jp_1059_;
}
case 1:
{
lean_object* v___x_1134_; lean_object* v___x_1135_; uint8_t v___x_1136_; 
v___x_1134_ = lean_unsigned_to_nat(1u);
v___x_1135_ = lean_nat_add(v___y_1130_, v___x_1134_);
lean_dec(v___y_1130_);
v___x_1136_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1042_, v___x_1135_);
if (v___x_1136_ == 0)
{
lean_object* v___x_1137_; lean_object* v___x_1138_; uint8_t v___x_1139_; 
lean_dec(v___x_1135_);
v___x_1137_ = lean_box(v___y_1128_);
v___x_1138_ = l_outOfBounds___redArg(v___x_1137_);
lean_dec(v___x_1137_);
v___x_1139_ = lean_unbox(v___x_1138_);
lean_dec(v___x_1138_);
v___y_1070_ = v___y_1129_;
v___y_1071_ = v_a_1133_;
v___y_1072_ = v___y_1131_;
v___y_1073_ = v___x_1139_;
goto v___jp_1069_;
}
else
{
uint8_t v___x_1140_; 
v___x_1140_ = lean_byte_array_fget(v___x_1042_, v___x_1135_);
lean_dec(v___x_1135_);
v___y_1070_ = v___y_1129_;
v___y_1071_ = v_a_1133_;
v___y_1072_ = v___y_1131_;
v___y_1073_ = v___x_1140_;
goto v___jp_1069_;
}
}
default: 
{
lean_object* v___x_1141_; lean_object* v___x_1142_; uint8_t v___x_1143_; 
v___x_1141_ = lean_unsigned_to_nat(1u);
v___x_1142_ = lean_nat_add(v___y_1130_, v___x_1141_);
v___x_1143_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1042_, v___x_1142_);
if (v___x_1143_ == 0)
{
lean_object* v___x_1144_; lean_object* v___x_1145_; uint8_t v___x_1146_; 
lean_dec(v___x_1142_);
v___x_1144_ = lean_box(v___y_1128_);
v___x_1145_ = l_outOfBounds___redArg(v___x_1144_);
lean_dec(v___x_1144_);
v___x_1146_ = lean_unbox(v___x_1145_);
lean_dec(v___x_1145_);
v___y_1109_ = v___y_1128_;
v___y_1110_ = v___y_1129_;
v___y_1111_ = v_a_1133_;
v___y_1112_ = v___y_1130_;
v___y_1113_ = v___y_1131_;
v___y_1114_ = v___x_1146_;
goto v___jp_1108_;
}
else
{
uint8_t v___x_1147_; 
v___x_1147_ = lean_byte_array_fget(v___x_1042_, v___x_1142_);
lean_dec(v___x_1142_);
v___y_1109_ = v___y_1128_;
v___y_1110_ = v___y_1129_;
v___y_1111_ = v_a_1133_;
v___y_1112_ = v___y_1130_;
v___y_1113_ = v___y_1131_;
v___y_1114_ = v___x_1147_;
goto v___jp_1108_;
}
}
}
}
v___jp_1148_:
{
if (v___y_1154_ == 0)
{
uint8_t v___x_1155_; 
v___x_1155_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1042_, v___y_1152_);
if (v___x_1155_ == 0)
{
lean_object* v___x_1156_; lean_object* v___x_1157_; uint8_t v___x_1158_; 
v___x_1156_ = lean_box(v___y_1150_);
v___x_1157_ = l_outOfBounds___redArg(v___x_1156_);
lean_dec(v___x_1156_);
v___x_1158_ = lean_unbox(v___x_1157_);
lean_dec(v___x_1157_);
v___y_1127_ = v___y_1149_;
v___y_1128_ = v___y_1150_;
v___y_1129_ = v___y_1151_;
v___y_1130_ = v___y_1152_;
v___y_1131_ = v___y_1153_;
v___y_1132_ = v___x_1158_;
goto v___jp_1126_;
}
else
{
uint8_t v___x_1159_; 
v___x_1159_ = lean_byte_array_fget(v___x_1042_, v___y_1152_);
v___y_1127_ = v___y_1149_;
v___y_1128_ = v___y_1150_;
v___y_1129_ = v___y_1151_;
v___y_1130_ = v___y_1152_;
v___y_1131_ = v___y_1153_;
v___y_1132_ = v___x_1159_;
goto v___jp_1126_;
}
}
else
{
size_t v_pos_1160_; uint8_t v___x_1161_; uint64_t v_a_1162_; 
v_pos_1160_ = lean_usize_of_nat(v___y_1152_);
lean_dec(v___y_1152_);
v___x_1161_ = lean_byte_array_uget(v___x_1042_, v_pos_1160_);
v_a_1162_ = lean_uint8_to_uint64(v___x_1161_);
switch(v___y_1149_)
{
case 0:
{
v___y_1060_ = v___y_1151_;
v___y_1061_ = v___y_1153_;
v___y_1062_ = v_a_1162_;
goto v___jp_1059_;
}
case 1:
{
size_t v___x_1163_; size_t v___x_1164_; uint8_t v___x_1165_; uint64_t v___x_1166_; uint64_t v___x_1167_; uint64_t v___x_1168_; uint64_t v___x_1169_; 
v___x_1163_ = ((size_t)1ULL);
v___x_1164_ = lean_usize_add(v_pos_1160_, v___x_1163_);
v___x_1165_ = lean_byte_array_uget(v___x_1042_, v___x_1164_);
v___x_1166_ = lean_uint8_to_uint64(v___x_1165_);
v___x_1167_ = 8ULL;
v___x_1168_ = lean_uint64_shift_left(v___x_1166_, v___x_1167_);
v___x_1169_ = lean_uint64_lor(v_a_1162_, v___x_1168_);
v___y_1060_ = v___y_1151_;
v___y_1061_ = v___y_1153_;
v___y_1062_ = v___x_1169_;
goto v___jp_1059_;
}
default: 
{
size_t v___x_1170_; size_t v___x_1171_; uint8_t v___x_1172_; uint64_t v___x_1173_; uint64_t v___x_1174_; uint64_t v___x_1175_; uint64_t v___x_1176_; size_t v___x_1177_; size_t v___x_1178_; uint8_t v___x_1179_; uint64_t v___x_1180_; uint64_t v___x_1181_; uint64_t v___x_1182_; uint64_t v___x_1183_; size_t v___x_1184_; size_t v___x_1185_; uint8_t v___x_1186_; uint64_t v___x_1187_; uint64_t v___x_1188_; uint64_t v___x_1189_; uint64_t v___x_1190_; 
v___x_1170_ = ((size_t)1ULL);
v___x_1171_ = lean_usize_add(v_pos_1160_, v___x_1170_);
v___x_1172_ = lean_byte_array_uget(v___x_1042_, v___x_1171_);
v___x_1173_ = lean_uint8_to_uint64(v___x_1172_);
v___x_1174_ = 8ULL;
v___x_1175_ = lean_uint64_shift_left(v___x_1173_, v___x_1174_);
v___x_1176_ = lean_uint64_lor(v_a_1162_, v___x_1175_);
v___x_1177_ = ((size_t)2ULL);
v___x_1178_ = lean_usize_add(v_pos_1160_, v___x_1177_);
v___x_1179_ = lean_byte_array_uget(v___x_1042_, v___x_1178_);
v___x_1180_ = lean_uint8_to_uint64(v___x_1179_);
v___x_1181_ = 16ULL;
v___x_1182_ = lean_uint64_shift_left(v___x_1180_, v___x_1181_);
v___x_1183_ = lean_uint64_lor(v___x_1176_, v___x_1182_);
v___x_1184_ = ((size_t)3ULL);
v___x_1185_ = lean_usize_add(v_pos_1160_, v___x_1184_);
v___x_1186_ = lean_byte_array_uget(v___x_1042_, v___x_1185_);
v___x_1187_ = lean_uint8_to_uint64(v___x_1186_);
v___x_1188_ = 24ULL;
v___x_1189_ = lean_uint64_shift_left(v___x_1187_, v___x_1188_);
v___x_1190_ = lean_uint64_lor(v___x_1183_, v___x_1189_);
v___y_1060_ = v___y_1151_;
v___y_1061_ = v___y_1153_;
v___y_1062_ = v___x_1190_;
goto v___jp_1059_;
}
}
}
}
v___jp_1191_:
{
lean_object* v_offset_1197_; lean_object* v___x_1198_; lean_object* v___x_1199_; uint8_t v___x_1200_; 
v_offset_1197_ = lean_nat_mul(v_i_1047_, v___y_1196_);
v___x_1198_ = lean_nat_add(v_offset_1197_, v___y_1196_);
v___x_1199_ = lean_byte_array_size(v___x_1042_);
v___x_1200_ = lean_nat_dec_le(v___x_1198_, v___x_1199_);
if (v___x_1200_ == 0)
{
lean_dec(v___x_1198_);
v___y_1149_ = v___y_1192_;
v___y_1150_ = v___y_1193_;
v___y_1151_ = v___y_1194_;
v___y_1152_ = v_offset_1197_;
v___y_1153_ = v___y_1195_;
v___y_1154_ = v___x_1200_;
goto v___jp_1148_;
}
else
{
size_t v___x_1201_; lean_object* v___x_1202_; uint8_t v___x_1203_; 
v___x_1201_ = lean_usize_of_nat(v___x_1198_);
v___x_1202_ = lean_usize_to_nat(v___x_1201_);
v___x_1203_ = lean_nat_dec_eq(v___x_1202_, v___x_1198_);
lean_dec(v___x_1198_);
lean_dec(v___x_1202_);
v___y_1149_ = v___y_1192_;
v___y_1150_ = v___y_1193_;
v___y_1151_ = v___y_1194_;
v___y_1152_ = v_offset_1197_;
v___y_1153_ = v___y_1195_;
v___y_1154_ = v___x_1203_;
goto v___jp_1148_;
}
}
v___jp_1204_:
{
uint8_t v___x_1207_; uint8_t v___x_1208_; 
v___x_1207_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_1041_);
v___x_1208_ = 0;
switch(v___x_1207_)
{
case 0:
{
lean_object* v___x_1209_; 
v___x_1209_ = lean_unsigned_to_nat(1u);
v___y_1192_ = v___x_1207_;
v___y_1193_ = v___x_1208_;
v___y_1194_ = v___y_1206_;
v___y_1195_ = v___y_1205_;
v___y_1196_ = v___x_1209_;
goto v___jp_1191_;
}
case 1:
{
lean_object* v___x_1210_; 
v___x_1210_ = lean_unsigned_to_nat(2u);
v___y_1192_ = v___x_1207_;
v___y_1193_ = v___x_1208_;
v___y_1194_ = v___y_1206_;
v___y_1195_ = v___y_1205_;
v___y_1196_ = v___x_1210_;
goto v___jp_1191_;
}
default: 
{
lean_object* v___x_1211_; 
v___x_1211_ = lean_unsigned_to_nat(4u);
v___y_1192_ = v___x_1207_;
v___y_1193_ = v___x_1208_;
v___y_1194_ = v___y_1206_;
v___y_1195_ = v___y_1205_;
v___y_1196_ = v___x_1211_;
goto v___jp_1191_;
}
}
}
v___jp_1212_:
{
lean_object* v___x_1214_; uint8_t v___x_1215_; 
v___x_1214_ = lean_uint64_to_nat(v___y_1213_);
v___x_1215_ = lean_nat_dec_le(v_columns_1043_, v___x_1214_);
if (v___x_1215_ == 0)
{
if (lean_obj_tag(v_b_1046_) == 1)
{
lean_object* v_val_1216_; uint8_t v___x_1217_; 
v_val_1216_ = lean_ctor_get(v_b_1046_, 0);
lean_inc(v_val_1216_);
lean_dec_ref_known(v_b_1046_, 1);
v___x_1217_ = lean_nat_dec_le(v___x_1214_, v_val_1216_);
lean_dec(v_val_1216_);
if (v___x_1217_ == 0)
{
v___y_1205_ = v___x_1214_;
v___y_1206_ = v___y_1048_;
goto v___jp_1204_;
}
else
{
lean_object* v___x_1218_; 
lean_dec(v___x_1214_);
v___x_1218_ = lean_alloc_ctor(3, 2, 0);
lean_ctor_set(v___x_1218_, 0, v_index_1040_);
lean_ctor_set(v___x_1218_, 1, v_i_1047_);
v_a_1050_ = v___x_1218_;
v_snd_1051_ = v___y_1048_;
goto v___jp_1049_;
}
}
else
{
lean_dec(v_b_1046_);
v___y_1205_ = v___x_1214_;
v___y_1206_ = v___y_1048_;
goto v___jp_1204_;
}
}
else
{
lean_object* v___x_1219_; 
lean_dec(v___x_1214_);
lean_dec(v_b_1046_);
v___x_1219_ = lean_alloc_ctor(3, 2, 0);
lean_ctor_set(v___x_1219_, 0, v_index_1040_);
lean_ctor_set(v___x_1219_, 1, v_i_1047_);
v_a_1050_ = v___x_1219_;
v_snd_1051_ = v___y_1048_;
goto v___jp_1049_;
}
}
v___jp_1220_:
{
uint64_t v___x_1223_; uint64_t v___x_1224_; uint64_t v___x_1225_; uint64_t v___x_1226_; 
v___x_1223_ = lean_uint8_to_uint64(v___y_1222_);
v___x_1224_ = 24ULL;
v___x_1225_ = lean_uint64_shift_left(v___x_1223_, v___x_1224_);
v___x_1226_ = lean_uint64_lor(v___y_1221_, v___x_1225_);
v___y_1213_ = v___x_1226_;
goto v___jp_1212_;
}
v___jp_1230_:
{
uint64_t v___x_1233_; uint64_t v___x_1234_; uint64_t v___x_1235_; uint64_t v___x_1236_; lean_object* v___x_1237_; lean_object* v___x_1238_; uint8_t v___x_1239_; 
v___x_1233_ = lean_uint8_to_uint64(v___y_1232_);
v___x_1234_ = 16ULL;
v___x_1235_ = lean_uint64_shift_left(v___x_1233_, v___x_1234_);
v___x_1236_ = lean_uint64_lor(v___y_1231_, v___x_1235_);
v___x_1237_ = lean_unsigned_to_nat(3u);
v___x_1238_ = lean_nat_add(v_offset_1229_, v___x_1237_);
lean_dec(v_offset_1229_);
v___x_1239_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1044_, v___x_1238_);
if (v___x_1239_ == 0)
{
lean_object* v___x_1240_; lean_object* v___x_1241_; uint8_t v___x_1242_; 
lean_dec(v___x_1238_);
v___x_1240_ = lean_box(v___x_1227_);
v___x_1241_ = l_outOfBounds___redArg(v___x_1240_);
lean_dec(v___x_1240_);
v___x_1242_ = lean_unbox(v___x_1241_);
lean_dec(v___x_1241_);
v___y_1221_ = v___x_1236_;
v___y_1222_ = v___x_1242_;
goto v___jp_1220_;
}
else
{
uint8_t v___x_1243_; 
v___x_1243_ = lean_byte_array_fget(v___x_1044_, v___x_1238_);
lean_dec(v___x_1238_);
v___y_1221_ = v___x_1236_;
v___y_1222_ = v___x_1243_;
goto v___jp_1220_;
}
}
v___jp_1244_:
{
uint64_t v___x_1247_; uint64_t v___x_1248_; uint64_t v___x_1249_; uint64_t v___x_1250_; lean_object* v___x_1251_; lean_object* v___x_1252_; uint8_t v___x_1253_; 
v___x_1247_ = lean_uint8_to_uint64(v___y_1246_);
v___x_1248_ = 8ULL;
v___x_1249_ = lean_uint64_shift_left(v___x_1247_, v___x_1248_);
v___x_1250_ = lean_uint64_lor(v___y_1245_, v___x_1249_);
v___x_1251_ = lean_unsigned_to_nat(2u);
v___x_1252_ = lean_nat_add(v_offset_1229_, v___x_1251_);
v___x_1253_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1044_, v___x_1252_);
if (v___x_1253_ == 0)
{
lean_object* v___x_1254_; lean_object* v___x_1255_; uint8_t v___x_1256_; 
lean_dec(v___x_1252_);
v___x_1254_ = lean_box(v___x_1227_);
v___x_1255_ = l_outOfBounds___redArg(v___x_1254_);
lean_dec(v___x_1254_);
v___x_1256_ = lean_unbox(v___x_1255_);
lean_dec(v___x_1255_);
v___y_1231_ = v___x_1250_;
v___y_1232_ = v___x_1256_;
goto v___jp_1230_;
}
else
{
uint8_t v___x_1257_; 
v___x_1257_ = lean_byte_array_fget(v___x_1044_, v___x_1252_);
lean_dec(v___x_1252_);
v___y_1231_ = v___x_1250_;
v___y_1232_ = v___x_1257_;
goto v___jp_1230_;
}
}
v___jp_1258_:
{
uint64_t v_a_1260_; lean_object* v___x_1261_; lean_object* v___x_1262_; uint8_t v___x_1263_; 
v_a_1260_ = lean_uint8_to_uint64(v___y_1259_);
v___x_1261_ = lean_unsigned_to_nat(1u);
v___x_1262_ = lean_nat_add(v_offset_1229_, v___x_1261_);
v___x_1263_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1044_, v___x_1262_);
if (v___x_1263_ == 0)
{
lean_object* v___x_1264_; lean_object* v___x_1265_; uint8_t v___x_1266_; 
lean_dec(v___x_1262_);
v___x_1264_ = lean_box(v___x_1227_);
v___x_1265_ = l_outOfBounds___redArg(v___x_1264_);
lean_dec(v___x_1264_);
v___x_1266_ = lean_unbox(v___x_1265_);
lean_dec(v___x_1265_);
v___y_1245_ = v_a_1260_;
v___y_1246_ = v___x_1266_;
goto v___jp_1244_;
}
else
{
uint8_t v___x_1267_; 
v___x_1267_ = lean_byte_array_fget(v___x_1044_, v___x_1262_);
lean_dec(v___x_1262_);
v___y_1245_ = v_a_1260_;
v___y_1246_ = v___x_1267_;
goto v___jp_1244_;
}
}
v___jp_1268_:
{
if (v___y_1269_ == 0)
{
uint8_t v___x_1270_; 
v___x_1270_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1044_, v_offset_1229_);
if (v___x_1270_ == 0)
{
lean_object* v___x_1271_; lean_object* v___x_1272_; uint8_t v___x_1273_; 
v___x_1271_ = lean_box(v___x_1227_);
v___x_1272_ = l_outOfBounds___redArg(v___x_1271_);
lean_dec(v___x_1271_);
v___x_1273_ = lean_unbox(v___x_1272_);
lean_dec(v___x_1272_);
v___y_1259_ = v___x_1273_;
goto v___jp_1258_;
}
else
{
uint8_t v___x_1274_; 
v___x_1274_ = lean_byte_array_fget(v___x_1044_, v_offset_1229_);
v___y_1259_ = v___x_1274_;
goto v___jp_1258_;
}
}
else
{
size_t v_pos_1275_; uint8_t v___x_1276_; uint64_t v_a_1277_; size_t v___x_1278_; size_t v___x_1279_; uint8_t v___x_1280_; uint64_t v___x_1281_; uint64_t v___x_1282_; uint64_t v___x_1283_; uint64_t v___x_1284_; size_t v___x_1285_; size_t v___x_1286_; uint8_t v___x_1287_; uint64_t v___x_1288_; uint64_t v___x_1289_; uint64_t v___x_1290_; uint64_t v___x_1291_; size_t v___x_1292_; size_t v___x_1293_; uint8_t v___x_1294_; uint64_t v___x_1295_; uint64_t v___x_1296_; uint64_t v___x_1297_; uint64_t v___x_1298_; 
v_pos_1275_ = lean_usize_of_nat(v_offset_1229_);
lean_dec(v_offset_1229_);
v___x_1276_ = lean_byte_array_uget(v___x_1044_, v_pos_1275_);
v_a_1277_ = lean_uint8_to_uint64(v___x_1276_);
v___x_1278_ = ((size_t)1ULL);
v___x_1279_ = lean_usize_add(v_pos_1275_, v___x_1278_);
v___x_1280_ = lean_byte_array_uget(v___x_1044_, v___x_1279_);
v___x_1281_ = lean_uint8_to_uint64(v___x_1280_);
v___x_1282_ = 8ULL;
v___x_1283_ = lean_uint64_shift_left(v___x_1281_, v___x_1282_);
v___x_1284_ = lean_uint64_lor(v_a_1277_, v___x_1283_);
v___x_1285_ = ((size_t)2ULL);
v___x_1286_ = lean_usize_add(v_pos_1275_, v___x_1285_);
v___x_1287_ = lean_byte_array_uget(v___x_1044_, v___x_1286_);
v___x_1288_ = lean_uint8_to_uint64(v___x_1287_);
v___x_1289_ = 16ULL;
v___x_1290_ = lean_uint64_shift_left(v___x_1288_, v___x_1289_);
v___x_1291_ = lean_uint64_lor(v___x_1284_, v___x_1290_);
v___x_1292_ = ((size_t)3ULL);
v___x_1293_ = lean_usize_add(v_pos_1275_, v___x_1292_);
v___x_1294_ = lean_byte_array_uget(v___x_1044_, v___x_1293_);
v___x_1295_ = lean_uint8_to_uint64(v___x_1294_);
v___x_1296_ = 24ULL;
v___x_1297_ = lean_uint64_shift_left(v___x_1295_, v___x_1296_);
v___x_1298_ = lean_uint64_lor(v___x_1291_, v___x_1297_);
v___y_1213_ = v___x_1298_;
goto v___jp_1212_;
}
}
}
v___jp_1049_:
{
lean_object* v___x_1052_; lean_object* v___x_1053_; 
v___x_1052_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1052_, 0, v_a_1050_);
v___x_1053_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1053_, 0, v___x_1052_);
lean_ctor_set(v___x_1053_, 1, v_snd_1051_);
return v___x_1053_;
}
v___jp_1054_:
{
lean_object* v___x_1056_; 
v___x_1056_ = lean_alloc_ctor(4, 2, 0);
lean_ctor_set(v___x_1056_, 0, v_index_1040_);
lean_ctor_set(v___x_1056_, 1, v_i_1047_);
v_a_1050_ = v___x_1056_;
v_snd_1051_ = v___y_1055_;
goto v___jp_1049_;
}
v___jp_1059_:
{
uint64_t v___x_1063_; uint8_t v___x_1064_; 
v___x_1063_ = 0ULL;
v___x_1064_ = lean_uint64_dec_eq(v___y_1062_, v___x_1063_);
if (v___x_1064_ == 0)
{
uint8_t v___x_1065_; 
v___x_1065_ = lean_uint64_dec_le(v_field_1041_, v___y_1062_);
if (v___x_1065_ == 0)
{
lean_object* v___x_1066_; lean_object* v___x_1067_; 
v___x_1066_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1066_, 0, v___y_1061_);
v___x_1067_ = lean_nat_add(v_i_1047_, v_step_1058_);
lean_dec(v_i_1047_);
v_b_1046_ = v___x_1066_;
v_i_1047_ = v___x_1067_;
v___y_1048_ = v___y_1060_;
goto _start;
}
else
{
lean_dec(v___y_1061_);
v___y_1055_ = v___y_1060_;
goto v___jp_1054_;
}
}
else
{
lean_dec(v___y_1061_);
v___y_1055_ = v___y_1060_;
goto v___jp_1054_;
}
}
v___jp_1069_:
{
uint64_t v___x_1074_; uint64_t v___x_1075_; uint64_t v___x_1076_; uint64_t v___x_1077_; 
v___x_1074_ = lean_uint8_to_uint64(v___y_1073_);
v___x_1075_ = 8ULL;
v___x_1076_ = lean_uint64_shift_left(v___x_1074_, v___x_1075_);
v___x_1077_ = lean_uint64_lor(v___y_1071_, v___x_1076_);
v___y_1060_ = v___y_1070_;
v___y_1061_ = v___y_1072_;
v___y_1062_ = v___x_1077_;
goto v___jp_1059_;
}
v___jp_1078_:
{
uint64_t v___x_1083_; uint64_t v___x_1084_; uint64_t v___x_1085_; uint64_t v___x_1086_; 
v___x_1083_ = lean_uint8_to_uint64(v___y_1082_);
v___x_1084_ = 24ULL;
v___x_1085_ = lean_uint64_shift_left(v___x_1083_, v___x_1084_);
v___x_1086_ = lean_uint64_lor(v___y_1079_, v___x_1085_);
v___y_1060_ = v___y_1080_;
v___y_1061_ = v___y_1081_;
v___y_1062_ = v___x_1086_;
goto v___jp_1059_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___boxed(lean_object* v_index_1305_, lean_object* v_field_1306_, lean_object* v___x_1307_, lean_object* v_columns_1308_, lean_object* v___x_1309_, lean_object* v_range_1310_, lean_object* v_b_1311_, lean_object* v_i_1312_, lean_object* v___y_1313_){
_start:
{
uint64_t v_field_boxed_1314_; lean_object* v_res_1315_; 
v_field_boxed_1314_ = lean_unbox_uint64(v_field_1306_);
lean_dec_ref(v_field_1306_);
v_res_1315_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg(v_index_1305_, v_field_boxed_1314_, v___x_1307_, v_columns_1308_, v___x_1309_, v_range_1310_, v_b_1311_, v_i_1312_, v___y_1313_);
lean_dec_ref(v_range_1310_);
lean_dec_ref(v___x_1309_);
lean_dec(v_columns_1308_);
lean_dec_ref(v___x_1307_);
return v_res_1315_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate(uint64_t v_field_1318_, lean_object* v_limits_1319_, lean_object* v_columns_1320_, lean_object* v_index_1321_, lean_object* v_row_1322_, lean_object* v_a_1323_){
_start:
{
lean_object* v___x_1324_; lean_object* v___x_1325_; lean_object* v_fst_1326_; lean_object* v_snd_1327_; 
v___x_1324_ = lean_unsigned_to_nat(1u);
v___x_1325_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_1319_, v___x_1324_, v_a_1323_);
v_fst_1326_ = lean_ctor_get(v___x_1325_, 0);
lean_inc(v_fst_1326_);
v_snd_1327_ = lean_ctor_get(v___x_1325_, 1);
lean_inc(v_snd_1327_);
if (lean_obj_tag(v_fst_1326_) == 0)
{
lean_dec_ref_known(v_fst_1326_, 1);
lean_dec(v_snd_1327_);
lean_dec(v_index_1321_);
return v___x_1325_;
}
else
{
lean_object* v_columns_1332_; lean_object* v_coefficients_1333_; lean_object* v___x_1334_; lean_object* v___x_1335_; lean_object* v___x_1336_; lean_object* v___x_1337_; uint8_t v___x_1338_; 
lean_dec_ref_known(v_fst_1326_, 1);
lean_dec_ref(v___x_1325_);
v_columns_1332_ = lean_ctor_get(v_row_1322_, 0);
v_coefficients_1333_ = lean_ctor_get(v_row_1322_, 1);
v___x_1334_ = lean_byte_array_size(v_columns_1332_);
v___x_1335_ = lean_unsigned_to_nat(4u);
v___x_1336_ = lean_nat_mod(v___x_1334_, v___x_1335_);
v___x_1337_ = lean_unsigned_to_nat(0u);
v___x_1338_ = lean_nat_dec_eq(v___x_1336_, v___x_1337_);
lean_dec(v___x_1336_);
if (v___x_1338_ == 0)
{
goto v___jp_1328_;
}
else
{
lean_object* v___f_1339_; lean_object* v___f_1340_; lean_object* v___x_1341_; lean_object* v___x_1342_; lean_object* v___y_1344_; uint8_t v___x_1390_; 
v___f_1339_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_validate___closed__0));
v___f_1340_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_validate___closed__1));
v___x_1341_ = lean_byte_array_size(v_coefficients_1333_);
v___x_1342_ = lp_Hex_Hex_Groebner_SparseRow_size(v_row_1322_);
v___x_1390_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_1318_);
switch(v___x_1390_)
{
case 0:
{
v___y_1344_ = v___x_1324_;
goto v___jp_1343_;
}
case 1:
{
lean_object* v___x_1391_; 
v___x_1391_ = lean_unsigned_to_nat(2u);
v___y_1344_ = v___x_1391_;
goto v___jp_1343_;
}
default: 
{
v___y_1344_ = v___x_1335_;
goto v___jp_1343_;
}
}
v___jp_1343_:
{
lean_object* v___x_1345_; uint8_t v___x_1346_; 
v___x_1345_ = lean_nat_mul(v___x_1342_, v___y_1344_);
v___x_1346_ = lean_nat_dec_eq(v___x_1341_, v___x_1345_);
lean_dec(v___x_1345_);
if (v___x_1346_ == 0)
{
lean_dec(v___x_1342_);
goto v___jp_1328_;
}
else
{
lean_object* v_inputEntries_1347_; uint8_t v___x_1348_; lean_object* v___x_1349_; lean_object* v_fst_1350_; 
v_inputEntries_1347_ = lean_ctor_get(v_limits_1319_, 2);
v___x_1348_ = 2;
v___x_1349_ = lp_Hex_Hex_Groebner_Matrix_charge(v___x_1348_, v___x_1342_, v_inputEntries_1347_, v___f_1340_, v___f_1339_, v_snd_1327_);
v_fst_1350_ = lean_ctor_get(v___x_1349_, 0);
lean_inc(v_fst_1350_);
if (lean_obj_tag(v_fst_1350_) == 0)
{
lean_dec_ref_known(v_fst_1350_, 1);
lean_dec(v___x_1342_);
lean_dec(v_index_1321_);
return v___x_1349_;
}
else
{
lean_object* v_snd_1351_; lean_object* v___x_1352_; lean_object* v___x_1353_; lean_object* v_fst_1354_; 
lean_dec_ref_known(v_fst_1350_, 1);
v_snd_1351_ = lean_ctor_get(v___x_1349_, 1);
lean_inc(v_snd_1351_);
lean_dec_ref(v___x_1349_);
v___x_1352_ = lean_nat_add(v___x_1334_, v___x_1341_);
v___x_1353_ = lp_Hex_Hex_Groebner_Matrix_packedBytes(v_limits_1319_, v___x_1352_, v_snd_1351_);
lean_dec(v___x_1352_);
v_fst_1354_ = lean_ctor_get(v___x_1353_, 0);
lean_inc(v_fst_1354_);
if (lean_obj_tag(v_fst_1354_) == 0)
{
lean_dec_ref_known(v_fst_1354_, 1);
lean_dec(v___x_1342_);
lean_dec(v_index_1321_);
return v___x_1353_;
}
else
{
lean_object* v_snd_1355_; lean_object* v___x_1356_; lean_object* v_fst_1357_; 
lean_dec_ref_known(v_fst_1354_, 1);
v_snd_1355_ = lean_ctor_get(v___x_1353_, 1);
lean_inc(v_snd_1355_);
lean_dec_ref(v___x_1353_);
v___x_1356_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_1319_, v___x_1342_, v_snd_1355_);
v_fst_1357_ = lean_ctor_get(v___x_1356_, 0);
lean_inc(v_fst_1357_);
if (lean_obj_tag(v_fst_1357_) == 0)
{
lean_dec_ref_known(v_fst_1357_, 1);
lean_dec(v___x_1342_);
lean_dec(v_index_1321_);
return v___x_1356_;
}
else
{
lean_object* v_snd_1358_; lean_object* v_previous_1359_; lean_object* v___x_1360_; lean_object* v___x_1361_; lean_object* v_fst_1362_; 
lean_dec_ref_known(v_fst_1357_, 1);
v_snd_1358_ = lean_ctor_get(v___x_1356_, 1);
lean_inc(v_snd_1358_);
lean_dec_ref(v___x_1356_);
v_previous_1359_ = lean_box(0);
v___x_1360_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1360_, 0, v___x_1337_);
lean_ctor_set(v___x_1360_, 1, v___x_1342_);
lean_ctor_set(v___x_1360_, 2, v___x_1324_);
v___x_1361_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg(v_index_1321_, v_field_1318_, v_coefficients_1333_, v_columns_1320_, v_columns_1332_, v___x_1360_, v_previous_1359_, v___x_1337_, v_snd_1358_);
lean_dec_ref_known(v___x_1360_, 3);
v_fst_1362_ = lean_ctor_get(v___x_1361_, 0);
lean_inc(v_fst_1362_);
if (lean_obj_tag(v_fst_1362_) == 0)
{
lean_object* v_snd_1363_; lean_object* v___x_1365_; uint8_t v_isShared_1366_; uint8_t v_isSharedCheck_1378_; 
v_snd_1363_ = lean_ctor_get(v___x_1361_, 1);
v_isSharedCheck_1378_ = !lean_is_exclusive(v___x_1361_);
if (v_isSharedCheck_1378_ == 0)
{
lean_object* v_unused_1379_; 
v_unused_1379_ = lean_ctor_get(v___x_1361_, 0);
lean_dec(v_unused_1379_);
v___x_1365_ = v___x_1361_;
v_isShared_1366_ = v_isSharedCheck_1378_;
goto v_resetjp_1364_;
}
else
{
lean_inc(v_snd_1363_);
lean_dec(v___x_1361_);
v___x_1365_ = lean_box(0);
v_isShared_1366_ = v_isSharedCheck_1378_;
goto v_resetjp_1364_;
}
v_resetjp_1364_:
{
lean_object* v_a_1367_; lean_object* v___x_1369_; uint8_t v_isShared_1370_; uint8_t v_isSharedCheck_1377_; 
v_a_1367_ = lean_ctor_get(v_fst_1362_, 0);
v_isSharedCheck_1377_ = !lean_is_exclusive(v_fst_1362_);
if (v_isSharedCheck_1377_ == 0)
{
v___x_1369_ = v_fst_1362_;
v_isShared_1370_ = v_isSharedCheck_1377_;
goto v_resetjp_1368_;
}
else
{
lean_inc(v_a_1367_);
lean_dec(v_fst_1362_);
v___x_1369_ = lean_box(0);
v_isShared_1370_ = v_isSharedCheck_1377_;
goto v_resetjp_1368_;
}
v_resetjp_1368_:
{
lean_object* v___x_1372_; 
if (v_isShared_1370_ == 0)
{
v___x_1372_ = v___x_1369_;
goto v_reusejp_1371_;
}
else
{
lean_object* v_reuseFailAlloc_1376_; 
v_reuseFailAlloc_1376_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1376_, 0, v_a_1367_);
v___x_1372_ = v_reuseFailAlloc_1376_;
goto v_reusejp_1371_;
}
v_reusejp_1371_:
{
lean_object* v___x_1374_; 
if (v_isShared_1366_ == 0)
{
lean_ctor_set(v___x_1365_, 0, v___x_1372_);
v___x_1374_ = v___x_1365_;
goto v_reusejp_1373_;
}
else
{
lean_object* v_reuseFailAlloc_1375_; 
v_reuseFailAlloc_1375_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1375_, 0, v___x_1372_);
lean_ctor_set(v_reuseFailAlloc_1375_, 1, v_snd_1363_);
v___x_1374_ = v_reuseFailAlloc_1375_;
goto v_reusejp_1373_;
}
v_reusejp_1373_:
{
return v___x_1374_;
}
}
}
}
}
else
{
lean_object* v_snd_1380_; lean_object* v___x_1382_; uint8_t v_isShared_1383_; uint8_t v_isSharedCheck_1388_; 
lean_dec_ref_known(v_fst_1362_, 1);
v_snd_1380_ = lean_ctor_get(v___x_1361_, 1);
v_isSharedCheck_1388_ = !lean_is_exclusive(v___x_1361_);
if (v_isSharedCheck_1388_ == 0)
{
lean_object* v_unused_1389_; 
v_unused_1389_ = lean_ctor_get(v___x_1361_, 0);
lean_dec(v_unused_1389_);
v___x_1382_ = v___x_1361_;
v_isShared_1383_ = v_isSharedCheck_1388_;
goto v_resetjp_1381_;
}
else
{
lean_inc(v_snd_1380_);
lean_dec(v___x_1361_);
v___x_1382_ = lean_box(0);
v_isShared_1383_ = v_isSharedCheck_1388_;
goto v_resetjp_1381_;
}
v_resetjp_1381_:
{
lean_object* v___x_1384_; lean_object* v___x_1386_; 
v___x_1384_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_charge___closed__0));
if (v_isShared_1383_ == 0)
{
lean_ctor_set(v___x_1382_, 0, v___x_1384_);
v___x_1386_ = v___x_1382_;
goto v_reusejp_1385_;
}
else
{
lean_object* v_reuseFailAlloc_1387_; 
v_reuseFailAlloc_1387_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1387_, 0, v___x_1384_);
lean_ctor_set(v_reuseFailAlloc_1387_, 1, v_snd_1380_);
v___x_1386_ = v_reuseFailAlloc_1387_;
goto v_reusejp_1385_;
}
v_reusejp_1385_:
{
return v___x_1386_;
}
}
}
}
}
}
}
}
}
}
v___jp_1328_:
{
lean_object* v___x_1329_; lean_object* v___x_1330_; lean_object* v___x_1331_; 
v___x_1329_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_1329_, 0, v_index_1321_);
v___x_1330_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1330_, 0, v___x_1329_);
v___x_1331_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1331_, 0, v___x_1330_);
lean_ctor_set(v___x_1331_, 1, v_snd_1327_);
return v___x_1331_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_validate___boxed(lean_object* v_field_1392_, lean_object* v_limits_1393_, lean_object* v_columns_1394_, lean_object* v_index_1395_, lean_object* v_row_1396_, lean_object* v_a_1397_){
_start:
{
uint64_t v_field_boxed_1398_; lean_object* v_res_1399_; 
v_field_boxed_1398_ = lean_unbox_uint64(v_field_1392_);
lean_dec_ref(v_field_1392_);
v_res_1399_ = lp_Hex_Hex_Groebner_Matrix_validate(v_field_boxed_1398_, v_limits_1393_, v_columns_1394_, v_index_1395_, v_row_1396_, v_a_1397_);
lean_dec_ref(v_row_1396_);
lean_dec(v_columns_1394_);
lean_dec_ref(v_limits_1393_);
return v_res_1399_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0(lean_object* v_index_1400_, uint64_t v_field_1401_, lean_object* v___x_1402_, lean_object* v_columns_1403_, lean_object* v___x_1404_, lean_object* v_range_1405_, lean_object* v_b_1406_, lean_object* v_i_1407_, lean_object* v_hs_1408_, lean_object* v_hl_1409_, lean_object* v___y_1410_){
_start:
{
lean_object* v___x_1411_; 
v___x_1411_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg(v_index_1400_, v_field_1401_, v___x_1402_, v_columns_1403_, v___x_1404_, v_range_1405_, v_b_1406_, v_i_1407_, v___y_1410_);
return v___x_1411_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___boxed(lean_object* v_index_1412_, lean_object* v_field_1413_, lean_object* v___x_1414_, lean_object* v_columns_1415_, lean_object* v___x_1416_, lean_object* v_range_1417_, lean_object* v_b_1418_, lean_object* v_i_1419_, lean_object* v_hs_1420_, lean_object* v_hl_1421_, lean_object* v___y_1422_){
_start:
{
uint64_t v_field_boxed_1423_; lean_object* v_res_1424_; 
v_field_boxed_1423_ = lean_unbox_uint64(v_field_1413_);
lean_dec_ref(v_field_1413_);
v_res_1424_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0(v_index_1412_, v_field_boxed_1423_, v___x_1414_, v_columns_1415_, v___x_1416_, v_range_1417_, v_b_1418_, v_i_1419_, v_hs_1420_, v_hl_1421_, v___y_1422_);
lean_dec_ref(v_range_1417_);
lean_dec_ref(v___x_1416_);
lean_dec(v_columns_1415_);
lean_dec_ref(v___x_1414_);
return v_res_1424_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0___redArg(lean_object* v_range_1425_, lean_object* v_b_1426_, lean_object* v_i_1427_){
_start:
{
lean_object* v_stop_1428_; lean_object* v_step_1429_; uint8_t v___x_1430_; 
v_stop_1428_ = lean_ctor_get(v_range_1425_, 1);
v_step_1429_ = lean_ctor_get(v_range_1425_, 2);
v___x_1430_ = lean_nat_dec_lt(v_i_1427_, v_stop_1428_);
if (v___x_1430_ == 0)
{
lean_dec(v_i_1427_);
return v_b_1426_;
}
else
{
uint8_t v___x_1431_; lean_object* v___x_1432_; lean_object* v___x_1433_; 
v___x_1431_ = 0;
v___x_1432_ = lean_byte_array_push(v_b_1426_, v___x_1431_);
v___x_1433_ = lean_nat_add(v_i_1427_, v_step_1429_);
lean_dec(v_i_1427_);
v_b_1426_ = v___x_1432_;
v_i_1427_ = v___x_1433_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0___redArg___boxed(lean_object* v_range_1435_, lean_object* v_b_1436_, lean_object* v_i_1437_){
_start:
{
lean_object* v_res_1438_; 
v_res_1438_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0___redArg(v_range_1435_, v_b_1436_, v_i_1437_);
lean_dec_ref(v_range_1435_);
return v_res_1438_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_zeros(lean_object* v_size_1439_){
_start:
{
lean_object* v_data_1440_; lean_object* v___x_1441_; lean_object* v___x_1442_; lean_object* v___x_1443_; lean_object* v___x_1444_; 
v_data_1440_ = lean_mk_empty_byte_array(v_size_1439_);
v___x_1441_ = lean_unsigned_to_nat(0u);
v___x_1442_ = lean_unsigned_to_nat(1u);
v___x_1443_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1443_, 0, v___x_1441_);
lean_ctor_set(v___x_1443_, 1, v_size_1439_);
lean_ctor_set(v___x_1443_, 2, v___x_1442_);
v___x_1444_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0___redArg(v___x_1443_, v_data_1440_, v___x_1441_);
lean_dec_ref_known(v___x_1443_, 3);
return v___x_1444_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0(lean_object* v_range_1445_, lean_object* v_b_1446_, lean_object* v_i_1447_, lean_object* v_hs_1448_, lean_object* v_hl_1449_){
_start:
{
lean_object* v___x_1450_; 
v___x_1450_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0___redArg(v_range_1445_, v_b_1446_, v_i_1447_);
return v___x_1450_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0___boxed(lean_object* v_range_1451_, lean_object* v_b_1452_, lean_object* v_i_1453_, lean_object* v_hs_1454_, lean_object* v_hl_1455_){
_start:
{
lean_object* v_res_1456_; 
v_res_1456_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_zeros_spec__0(v_range_1451_, v_b_1452_, v_i_1453_, v_hs_1454_, v_hl_1455_);
lean_dec_ref(v_range_1451_);
return v_res_1456_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0___redArg(lean_object* v_limits_1457_, uint64_t v___x_1458_, uint64_t v_ctx_1459_, lean_object* v_range_1460_, lean_object* v_b_1461_, lean_object* v_i_1462_, lean_object* v___y_1463_){
_start:
{
lean_object* v_a_1465_; lean_object* v_snd_1466_; lean_object* v_stop_1469_; lean_object* v_step_1470_; lean_object* v_a_1472_; lean_object* v_snd_1473_; uint8_t v___x_1476_; 
v_stop_1469_ = lean_ctor_get(v_range_1460_, 1);
v_step_1470_ = lean_ctor_get(v_range_1460_, 2);
v___x_1476_ = lean_nat_dec_lt(v_i_1462_, v_stop_1469_);
if (v___x_1476_ == 0)
{
lean_object* v___x_1477_; lean_object* v___x_1478_; 
lean_dec(v_i_1462_);
v___x_1477_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1477_, 0, v_b_1461_);
v___x_1478_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1478_, 0, v___x_1477_);
lean_ctor_set(v___x_1478_, 1, v___y_1463_);
return v___x_1478_;
}
else
{
lean_object* v_snd_1479_; lean_object* v_fst_1480_; lean_object* v___x_1482_; uint8_t v_isShared_1483_; uint8_t v_isSharedCheck_1546_; 
v_snd_1479_ = lean_ctor_get(v_b_1461_, 1);
v_fst_1480_ = lean_ctor_get(v_b_1461_, 0);
v_isSharedCheck_1546_ = !lean_is_exclusive(v_b_1461_);
if (v_isSharedCheck_1546_ == 0)
{
v___x_1482_ = v_b_1461_;
v_isShared_1483_ = v_isSharedCheck_1546_;
goto v_resetjp_1481_;
}
else
{
lean_inc(v_snd_1479_);
lean_inc(v_fst_1480_);
lean_dec(v_b_1461_);
v___x_1482_ = lean_box(0);
v_isShared_1483_ = v_isSharedCheck_1546_;
goto v_resetjp_1481_;
}
v_resetjp_1481_:
{
lean_object* v_fst_1484_; lean_object* v_snd_1485_; lean_object* v___x_1487_; uint8_t v_isShared_1488_; uint8_t v_isSharedCheck_1545_; 
v_fst_1484_ = lean_ctor_get(v_snd_1479_, 0);
v_snd_1485_ = lean_ctor_get(v_snd_1479_, 1);
v_isSharedCheck_1545_ = !lean_is_exclusive(v_snd_1479_);
if (v_isSharedCheck_1545_ == 0)
{
v___x_1487_ = v_snd_1479_;
v_isShared_1488_ = v_isSharedCheck_1545_;
goto v_resetjp_1486_;
}
else
{
lean_inc(v_snd_1485_);
lean_inc(v_fst_1484_);
lean_dec(v_snd_1479_);
v___x_1487_ = lean_box(0);
v_isShared_1488_ = v_isSharedCheck_1545_;
goto v_resetjp_1486_;
}
v_resetjp_1486_:
{
lean_object* v___x_1489_; uint8_t v___x_1490_; 
v___x_1489_ = lean_unsigned_to_nat(0u);
v___x_1490_ = lean_nat_dec_eq(v_fst_1480_, v___x_1489_);
if (v___x_1490_ == 0)
{
lean_object* v___x_1491_; uint64_t v_value_1493_; lean_object* v___y_1494_; lean_object* v___x_1525_; lean_object* v___x_1526_; uint8_t v___x_1527_; 
v___x_1491_ = lean_unsigned_to_nat(1u);
v___x_1525_ = lean_unsigned_to_nat(2u);
v___x_1526_ = lean_nat_mod(v_fst_1480_, v___x_1525_);
v___x_1527_ = lean_nat_dec_eq(v___x_1526_, v___x_1491_);
lean_dec(v___x_1526_);
if (v___x_1527_ == 0)
{
uint64_t v___x_1528_; 
v___x_1528_ = lean_unbox_uint64(v_snd_1485_);
lean_dec(v_snd_1485_);
v_value_1493_ = v___x_1528_;
v___y_1494_ = v___y_1463_;
goto v___jp_1492_;
}
else
{
lean_object* v___x_1529_; lean_object* v_fst_1530_; 
v___x_1529_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_1457_, v___x_1491_, v___y_1463_);
v_fst_1530_ = lean_ctor_get(v___x_1529_, 0);
lean_inc(v_fst_1530_);
if (lean_obj_tag(v_fst_1530_) == 0)
{
lean_object* v_snd_1531_; lean_object* v_a_1532_; 
lean_del_object(v___x_1487_);
lean_dec(v_snd_1485_);
lean_dec(v_fst_1484_);
lean_del_object(v___x_1482_);
lean_dec(v_fst_1480_);
lean_dec(v_i_1462_);
v_snd_1531_ = lean_ctor_get(v___x_1529_, 1);
lean_inc(v_snd_1531_);
lean_dec_ref(v___x_1529_);
v_a_1532_ = lean_ctor_get(v_fst_1530_, 0);
lean_inc(v_a_1532_);
lean_dec_ref_known(v_fst_1530_, 1);
v_a_1465_ = v_a_1532_;
v_snd_1466_ = v_snd_1531_;
goto v___jp_1464_;
}
else
{
lean_object* v_snd_1533_; uint64_t v___x_1534_; uint64_t v___x_1535_; uint64_t v___x_1536_; 
lean_dec_ref_known(v_fst_1530_, 1);
v_snd_1533_ = lean_ctor_get(v___x_1529_, 1);
lean_inc(v_snd_1533_);
lean_dec_ref(v___x_1529_);
v___x_1534_ = lean_unbox_uint64(v_snd_1485_);
lean_dec(v_snd_1485_);
v___x_1535_ = lean_unbox_uint64(v_fst_1484_);
v___x_1536_ = lp_Hex_BarrettCtx_mulMod(v___x_1458_, v_ctx_1459_, v___x_1534_, v___x_1535_);
v_value_1493_ = v___x_1536_;
v___y_1494_ = v_snd_1533_;
goto v___jp_1492_;
}
}
v___jp_1492_:
{
lean_object* v___x_1495_; uint8_t v___x_1496_; 
v___x_1495_ = lean_nat_shiftr(v_fst_1480_, v___x_1491_);
lean_dec(v_fst_1480_);
v___x_1496_ = lean_nat_dec_lt(v___x_1489_, v___x_1495_);
if (v___x_1496_ == 0)
{
lean_object* v___x_1497_; lean_object* v___x_1499_; 
v___x_1497_ = lean_box_uint64(v_value_1493_);
if (v_isShared_1488_ == 0)
{
lean_ctor_set(v___x_1487_, 1, v___x_1497_);
v___x_1499_ = v___x_1487_;
goto v_reusejp_1498_;
}
else
{
lean_object* v_reuseFailAlloc_1503_; 
v_reuseFailAlloc_1503_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1503_, 0, v_fst_1484_);
lean_ctor_set(v_reuseFailAlloc_1503_, 1, v___x_1497_);
v___x_1499_ = v_reuseFailAlloc_1503_;
goto v_reusejp_1498_;
}
v_reusejp_1498_:
{
lean_object* v___x_1501_; 
if (v_isShared_1483_ == 0)
{
lean_ctor_set(v___x_1482_, 1, v___x_1499_);
lean_ctor_set(v___x_1482_, 0, v___x_1495_);
v___x_1501_ = v___x_1482_;
goto v_reusejp_1500_;
}
else
{
lean_object* v_reuseFailAlloc_1502_; 
v_reuseFailAlloc_1502_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1502_, 0, v___x_1495_);
lean_ctor_set(v_reuseFailAlloc_1502_, 1, v___x_1499_);
v___x_1501_ = v_reuseFailAlloc_1502_;
goto v_reusejp_1500_;
}
v_reusejp_1500_:
{
v_a_1472_ = v___x_1501_;
v_snd_1473_ = v___y_1494_;
goto v___jp_1471_;
}
}
}
else
{
lean_object* v___x_1504_; lean_object* v_fst_1505_; 
lean_del_object(v___x_1482_);
v___x_1504_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_1457_, v___x_1491_, v___y_1494_);
v_fst_1505_ = lean_ctor_get(v___x_1504_, 0);
lean_inc(v_fst_1505_);
if (lean_obj_tag(v_fst_1505_) == 0)
{
lean_object* v_snd_1506_; lean_object* v_a_1507_; 
lean_dec(v___x_1495_);
lean_del_object(v___x_1487_);
lean_dec(v_fst_1484_);
lean_dec(v_i_1462_);
v_snd_1506_ = lean_ctor_get(v___x_1504_, 1);
lean_inc(v_snd_1506_);
lean_dec_ref(v___x_1504_);
v_a_1507_ = lean_ctor_get(v_fst_1505_, 0);
lean_inc(v_a_1507_);
lean_dec_ref_known(v_fst_1505_, 1);
v_a_1465_ = v_a_1507_;
v_snd_1466_ = v_snd_1506_;
goto v___jp_1464_;
}
else
{
lean_object* v_snd_1508_; lean_object* v___x_1510_; uint8_t v_isShared_1511_; uint8_t v_isSharedCheck_1523_; 
lean_dec_ref_known(v_fst_1505_, 1);
v_snd_1508_ = lean_ctor_get(v___x_1504_, 1);
v_isSharedCheck_1523_ = !lean_is_exclusive(v___x_1504_);
if (v_isSharedCheck_1523_ == 0)
{
lean_object* v_unused_1524_; 
v_unused_1524_ = lean_ctor_get(v___x_1504_, 0);
lean_dec(v_unused_1524_);
v___x_1510_ = v___x_1504_;
v_isShared_1511_ = v_isSharedCheck_1523_;
goto v_resetjp_1509_;
}
else
{
lean_inc(v_snd_1508_);
lean_dec(v___x_1504_);
v___x_1510_ = lean_box(0);
v_isShared_1511_ = v_isSharedCheck_1523_;
goto v_resetjp_1509_;
}
v_resetjp_1509_:
{
uint64_t v___x_1512_; uint64_t v___x_1513_; uint64_t v___x_1514_; lean_object* v___x_1515_; lean_object* v___x_1516_; lean_object* v___x_1518_; 
v___x_1512_ = lean_unbox_uint64(v_fst_1484_);
v___x_1513_ = lean_unbox_uint64(v_fst_1484_);
lean_dec(v_fst_1484_);
v___x_1514_ = lp_Hex_BarrettCtx_mulMod(v___x_1458_, v_ctx_1459_, v___x_1512_, v___x_1513_);
v___x_1515_ = lean_box_uint64(v___x_1514_);
v___x_1516_ = lean_box_uint64(v_value_1493_);
if (v_isShared_1511_ == 0)
{
lean_ctor_set(v___x_1510_, 1, v___x_1516_);
lean_ctor_set(v___x_1510_, 0, v___x_1515_);
v___x_1518_ = v___x_1510_;
goto v_reusejp_1517_;
}
else
{
lean_object* v_reuseFailAlloc_1522_; 
v_reuseFailAlloc_1522_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1522_, 0, v___x_1515_);
lean_ctor_set(v_reuseFailAlloc_1522_, 1, v___x_1516_);
v___x_1518_ = v_reuseFailAlloc_1522_;
goto v_reusejp_1517_;
}
v_reusejp_1517_:
{
lean_object* v___x_1520_; 
if (v_isShared_1488_ == 0)
{
lean_ctor_set(v___x_1487_, 1, v___x_1518_);
lean_ctor_set(v___x_1487_, 0, v___x_1495_);
v___x_1520_ = v___x_1487_;
goto v_reusejp_1519_;
}
else
{
lean_object* v_reuseFailAlloc_1521_; 
v_reuseFailAlloc_1521_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1521_, 0, v___x_1495_);
lean_ctor_set(v_reuseFailAlloc_1521_, 1, v___x_1518_);
v___x_1520_ = v_reuseFailAlloc_1521_;
goto v_reusejp_1519_;
}
v_reusejp_1519_:
{
v_a_1472_ = v___x_1520_;
v_snd_1473_ = v_snd_1508_;
goto v___jp_1471_;
}
}
}
}
}
}
}
else
{
lean_object* v___x_1538_; 
lean_dec(v_i_1462_);
if (v_isShared_1488_ == 0)
{
v___x_1538_ = v___x_1487_;
goto v_reusejp_1537_;
}
else
{
lean_object* v_reuseFailAlloc_1544_; 
v_reuseFailAlloc_1544_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1544_, 0, v_fst_1484_);
lean_ctor_set(v_reuseFailAlloc_1544_, 1, v_snd_1485_);
v___x_1538_ = v_reuseFailAlloc_1544_;
goto v_reusejp_1537_;
}
v_reusejp_1537_:
{
lean_object* v___x_1540_; 
if (v_isShared_1483_ == 0)
{
lean_ctor_set(v___x_1482_, 1, v___x_1538_);
v___x_1540_ = v___x_1482_;
goto v_reusejp_1539_;
}
else
{
lean_object* v_reuseFailAlloc_1543_; 
v_reuseFailAlloc_1543_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1543_, 0, v_fst_1480_);
lean_ctor_set(v_reuseFailAlloc_1543_, 1, v___x_1538_);
v___x_1540_ = v_reuseFailAlloc_1543_;
goto v_reusejp_1539_;
}
v_reusejp_1539_:
{
lean_object* v___x_1541_; lean_object* v___x_1542_; 
v___x_1541_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1541_, 0, v___x_1540_);
v___x_1542_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1542_, 0, v___x_1541_);
lean_ctor_set(v___x_1542_, 1, v___y_1463_);
return v___x_1542_;
}
}
}
}
}
}
v___jp_1464_:
{
lean_object* v___x_1467_; lean_object* v___x_1468_; 
v___x_1467_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1467_, 0, v_a_1465_);
v___x_1468_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1468_, 0, v___x_1467_);
lean_ctor_set(v___x_1468_, 1, v_snd_1466_);
return v___x_1468_;
}
v___jp_1471_:
{
lean_object* v___x_1474_; 
v___x_1474_ = lean_nat_add(v_i_1462_, v_step_1470_);
lean_dec(v_i_1462_);
v_b_1461_ = v_a_1472_;
v_i_1462_ = v___x_1474_;
v___y_1463_ = v_snd_1473_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0___redArg___boxed(lean_object* v_limits_1547_, lean_object* v___x_1548_, lean_object* v_ctx_1549_, lean_object* v_range_1550_, lean_object* v_b_1551_, lean_object* v_i_1552_, lean_object* v___y_1553_){
_start:
{
uint64_t v___x_3799__boxed_1554_; uint64_t v_ctx_boxed_1555_; lean_object* v_res_1556_; 
v___x_3799__boxed_1554_ = lean_unbox_uint64(v___x_1548_);
lean_dec_ref(v___x_1548_);
v_ctx_boxed_1555_ = lean_unbox_uint64(v_ctx_1549_);
lean_dec_ref(v_ctx_1549_);
v_res_1556_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0___redArg(v_limits_1547_, v___x_3799__boxed_1554_, v_ctx_boxed_1555_, v_range_1550_, v_b_1551_, v_i_1552_, v___y_1553_);
lean_dec_ref(v_range_1550_);
lean_dec_ref(v_limits_1547_);
return v_res_1556_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_inverse(uint64_t v_field_1561_, uint64_t v_ctx_1562_, lean_object* v_limits_1563_, uint64_t v_a_1564_, lean_object* v_a_1565_){
_start:
{
uint64_t v_value_1566_; uint8_t v___x_1567_; 
v_value_1566_ = 1ULL;
v___x_1567_ = lean_uint64_dec_eq(v_a_1564_, v_value_1566_);
if (v___x_1567_ == 0)
{
lean_object* v___x_1568_; lean_object* v___x_1569_; lean_object* v___x_1570_; lean_object* v_exponent_1571_; lean_object* v___x_1572_; lean_object* v___x_1573_; lean_object* v___x_1574_; lean_object* v___x_1575_; lean_object* v___x_1576_; lean_object* v___x_1577_; lean_object* v___x_1578_; lean_object* v___x_1579_; lean_object* v___x_1580_; lean_object* v_fst_1581_; 
v___x_1568_ = lean_unsigned_to_nat(1u);
v___x_1569_ = lean_uint64_to_nat(v_field_1561_);
v___x_1570_ = lean_unsigned_to_nat(2u);
v_exponent_1571_ = lean_nat_sub(v___x_1569_, v___x_1570_);
v___x_1572_ = lean_unsigned_to_nat(0u);
v___x_1573_ = lean_nat_log2(v___x_1569_);
lean_dec(v___x_1569_);
v___x_1574_ = lean_nat_add(v___x_1573_, v___x_1568_);
lean_dec(v___x_1573_);
v___x_1575_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1575_, 0, v___x_1572_);
lean_ctor_set(v___x_1575_, 1, v___x_1574_);
lean_ctor_set(v___x_1575_, 2, v___x_1568_);
v___x_1576_ = lean_box_uint64(v_a_1564_);
v___x_1577_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_inverse___closed__0___boxed__const__1));
v___x_1578_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1578_, 0, v___x_1576_);
lean_ctor_set(v___x_1578_, 1, v___x_1577_);
v___x_1579_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1579_, 0, v_exponent_1571_);
lean_ctor_set(v___x_1579_, 1, v___x_1578_);
v___x_1580_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0___redArg(v_limits_1563_, v_field_1561_, v_ctx_1562_, v___x_1575_, v___x_1579_, v___x_1572_, v_a_1565_);
lean_dec_ref_known(v___x_1575_, 3);
v_fst_1581_ = lean_ctor_get(v___x_1580_, 0);
lean_inc(v_fst_1581_);
if (lean_obj_tag(v_fst_1581_) == 0)
{
lean_object* v_snd_1582_; lean_object* v___x_1584_; uint8_t v_isShared_1585_; uint8_t v_isSharedCheck_1597_; 
v_snd_1582_ = lean_ctor_get(v___x_1580_, 1);
v_isSharedCheck_1597_ = !lean_is_exclusive(v___x_1580_);
if (v_isSharedCheck_1597_ == 0)
{
lean_object* v_unused_1598_; 
v_unused_1598_ = lean_ctor_get(v___x_1580_, 0);
lean_dec(v_unused_1598_);
v___x_1584_ = v___x_1580_;
v_isShared_1585_ = v_isSharedCheck_1597_;
goto v_resetjp_1583_;
}
else
{
lean_inc(v_snd_1582_);
lean_dec(v___x_1580_);
v___x_1584_ = lean_box(0);
v_isShared_1585_ = v_isSharedCheck_1597_;
goto v_resetjp_1583_;
}
v_resetjp_1583_:
{
lean_object* v_a_1586_; lean_object* v___x_1588_; uint8_t v_isShared_1589_; uint8_t v_isSharedCheck_1596_; 
v_a_1586_ = lean_ctor_get(v_fst_1581_, 0);
v_isSharedCheck_1596_ = !lean_is_exclusive(v_fst_1581_);
if (v_isSharedCheck_1596_ == 0)
{
v___x_1588_ = v_fst_1581_;
v_isShared_1589_ = v_isSharedCheck_1596_;
goto v_resetjp_1587_;
}
else
{
lean_inc(v_a_1586_);
lean_dec(v_fst_1581_);
v___x_1588_ = lean_box(0);
v_isShared_1589_ = v_isSharedCheck_1596_;
goto v_resetjp_1587_;
}
v_resetjp_1587_:
{
lean_object* v___x_1591_; 
if (v_isShared_1589_ == 0)
{
v___x_1591_ = v___x_1588_;
goto v_reusejp_1590_;
}
else
{
lean_object* v_reuseFailAlloc_1595_; 
v_reuseFailAlloc_1595_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1595_, 0, v_a_1586_);
v___x_1591_ = v_reuseFailAlloc_1595_;
goto v_reusejp_1590_;
}
v_reusejp_1590_:
{
lean_object* v___x_1593_; 
if (v_isShared_1585_ == 0)
{
lean_ctor_set(v___x_1584_, 0, v___x_1591_);
v___x_1593_ = v___x_1584_;
goto v_reusejp_1592_;
}
else
{
lean_object* v_reuseFailAlloc_1594_; 
v_reuseFailAlloc_1594_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1594_, 0, v___x_1591_);
lean_ctor_set(v_reuseFailAlloc_1594_, 1, v_snd_1582_);
v___x_1593_ = v_reuseFailAlloc_1594_;
goto v_reusejp_1592_;
}
v_reusejp_1592_:
{
return v___x_1593_;
}
}
}
}
}
else
{
lean_object* v_a_1599_; lean_object* v___x_1601_; uint8_t v_isShared_1602_; uint8_t v_isSharedCheck_1617_; 
v_a_1599_ = lean_ctor_get(v_fst_1581_, 0);
v_isSharedCheck_1617_ = !lean_is_exclusive(v_fst_1581_);
if (v_isSharedCheck_1617_ == 0)
{
v___x_1601_ = v_fst_1581_;
v_isShared_1602_ = v_isSharedCheck_1617_;
goto v_resetjp_1600_;
}
else
{
lean_inc(v_a_1599_);
lean_dec(v_fst_1581_);
v___x_1601_ = lean_box(0);
v_isShared_1602_ = v_isSharedCheck_1617_;
goto v_resetjp_1600_;
}
v_resetjp_1600_:
{
lean_object* v_snd_1603_; lean_object* v_snd_1604_; lean_object* v_snd_1605_; lean_object* v___x_1607_; uint8_t v_isShared_1608_; uint8_t v_isSharedCheck_1615_; 
v_snd_1603_ = lean_ctor_get(v_a_1599_, 1);
lean_inc(v_snd_1603_);
lean_dec(v_a_1599_);
v_snd_1604_ = lean_ctor_get(v___x_1580_, 1);
lean_inc(v_snd_1604_);
lean_dec_ref(v___x_1580_);
v_snd_1605_ = lean_ctor_get(v_snd_1603_, 1);
v_isSharedCheck_1615_ = !lean_is_exclusive(v_snd_1603_);
if (v_isSharedCheck_1615_ == 0)
{
lean_object* v_unused_1616_; 
v_unused_1616_ = lean_ctor_get(v_snd_1603_, 0);
lean_dec(v_unused_1616_);
v___x_1607_ = v_snd_1603_;
v_isShared_1608_ = v_isSharedCheck_1615_;
goto v_resetjp_1606_;
}
else
{
lean_inc(v_snd_1605_);
lean_dec(v_snd_1603_);
v___x_1607_ = lean_box(0);
v_isShared_1608_ = v_isSharedCheck_1615_;
goto v_resetjp_1606_;
}
v_resetjp_1606_:
{
lean_object* v___x_1610_; 
if (v_isShared_1602_ == 0)
{
lean_ctor_set(v___x_1601_, 0, v_snd_1605_);
v___x_1610_ = v___x_1601_;
goto v_reusejp_1609_;
}
else
{
lean_object* v_reuseFailAlloc_1614_; 
v_reuseFailAlloc_1614_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1614_, 0, v_snd_1605_);
v___x_1610_ = v_reuseFailAlloc_1614_;
goto v_reusejp_1609_;
}
v_reusejp_1609_:
{
lean_object* v___x_1612_; 
if (v_isShared_1608_ == 0)
{
lean_ctor_set(v___x_1607_, 1, v_snd_1604_);
lean_ctor_set(v___x_1607_, 0, v___x_1610_);
v___x_1612_ = v___x_1607_;
goto v_reusejp_1611_;
}
else
{
lean_object* v_reuseFailAlloc_1613_; 
v_reuseFailAlloc_1613_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1613_, 0, v___x_1610_);
lean_ctor_set(v_reuseFailAlloc_1613_, 1, v_snd_1604_);
v___x_1612_ = v_reuseFailAlloc_1613_;
goto v_reusejp_1611_;
}
v_reusejp_1611_:
{
return v___x_1612_;
}
}
}
}
}
}
else
{
lean_object* v___x_1618_; lean_object* v___x_1619_; 
v___x_1618_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_inverse___closed__0));
v___x_1619_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1619_, 0, v___x_1618_);
lean_ctor_set(v___x_1619_, 1, v_a_1565_);
return v___x_1619_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_inverse___boxed(lean_object* v_field_1620_, lean_object* v_ctx_1621_, lean_object* v_limits_1622_, lean_object* v_a_1623_, lean_object* v_a_1624_){
_start:
{
uint64_t v_field_boxed_1625_; uint64_t v_ctx_boxed_1626_; uint64_t v_a_boxed_1627_; lean_object* v_res_1628_; 
v_field_boxed_1625_ = lean_unbox_uint64(v_field_1620_);
lean_dec_ref(v_field_1620_);
v_ctx_boxed_1626_ = lean_unbox_uint64(v_ctx_1621_);
lean_dec_ref(v_ctx_1621_);
v_a_boxed_1627_ = lean_unbox_uint64(v_a_1623_);
lean_dec_ref(v_a_1623_);
v_res_1628_ = lp_Hex_Hex_Groebner_Matrix_inverse(v_field_boxed_1625_, v_ctx_boxed_1626_, v_limits_1622_, v_a_boxed_1627_, v_a_1624_);
lean_dec_ref(v_limits_1622_);
return v_res_1628_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0(lean_object* v_limits_1629_, uint64_t v___x_1630_, uint64_t v_ctx_1631_, lean_object* v_range_1632_, lean_object* v_b_1633_, lean_object* v_i_1634_, lean_object* v_hs_1635_, lean_object* v_hl_1636_, lean_object* v___y_1637_){
_start:
{
lean_object* v___x_1638_; 
v___x_1638_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0___redArg(v_limits_1629_, v___x_1630_, v_ctx_1631_, v_range_1632_, v_b_1633_, v_i_1634_, v___y_1637_);
return v___x_1638_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0___boxed(lean_object* v_limits_1639_, lean_object* v___x_1640_, lean_object* v_ctx_1641_, lean_object* v_range_1642_, lean_object* v_b_1643_, lean_object* v_i_1644_, lean_object* v_hs_1645_, lean_object* v_hl_1646_, lean_object* v___y_1647_){
_start:
{
uint64_t v___x_4073__boxed_1648_; uint64_t v_ctx_boxed_1649_; lean_object* v_res_1650_; 
v___x_4073__boxed_1648_ = lean_unbox_uint64(v___x_1640_);
lean_dec_ref(v___x_1640_);
v_ctx_boxed_1649_ = lean_unbox_uint64(v_ctx_1641_);
lean_dec_ref(v_ctx_1641_);
v_res_1650_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_inverse_spec__0(v_limits_1639_, v___x_4073__boxed_1648_, v_ctx_boxed_1649_, v_range_1642_, v_b_1643_, v_i_1644_, v_hs_1645_, v_hl_1646_, v___y_1647_);
lean_dec_ref(v_range_1642_);
lean_dec_ref(v_limits_1639_);
return v_res_1650_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___lam__0(lean_object* v_s_1651_, lean_object* v_n_1652_){
_start:
{
lean_object* v_work_1653_; lean_object* v_inputEntries_1654_; lean_object* v_packedBytes_1655_; lean_object* v_traceNodes_1656_; lean_object* v_processedRows_1657_; lean_object* v_reductions_1658_; lean_object* v_zeroRows_1659_; lean_object* v___x_1661_; uint8_t v_isShared_1662_; uint8_t v_isSharedCheck_1666_; 
v_work_1653_ = lean_ctor_get(v_s_1651_, 0);
v_inputEntries_1654_ = lean_ctor_get(v_s_1651_, 1);
v_packedBytes_1655_ = lean_ctor_get(v_s_1651_, 3);
v_traceNodes_1656_ = lean_ctor_get(v_s_1651_, 4);
v_processedRows_1657_ = lean_ctor_get(v_s_1651_, 5);
v_reductions_1658_ = lean_ctor_get(v_s_1651_, 6);
v_zeroRows_1659_ = lean_ctor_get(v_s_1651_, 7);
v_isSharedCheck_1666_ = !lean_is_exclusive(v_s_1651_);
if (v_isSharedCheck_1666_ == 0)
{
lean_object* v_unused_1667_; 
v_unused_1667_ = lean_ctor_get(v_s_1651_, 2);
lean_dec(v_unused_1667_);
v___x_1661_ = v_s_1651_;
v_isShared_1662_ = v_isSharedCheck_1666_;
goto v_resetjp_1660_;
}
else
{
lean_inc(v_zeroRows_1659_);
lean_inc(v_reductions_1658_);
lean_inc(v_processedRows_1657_);
lean_inc(v_traceNodes_1656_);
lean_inc(v_packedBytes_1655_);
lean_inc(v_inputEntries_1654_);
lean_inc(v_work_1653_);
lean_dec(v_s_1651_);
v___x_1661_ = lean_box(0);
v_isShared_1662_ = v_isSharedCheck_1666_;
goto v_resetjp_1660_;
}
v_resetjp_1660_:
{
lean_object* v___x_1664_; 
if (v_isShared_1662_ == 0)
{
lean_ctor_set(v___x_1661_, 2, v_n_1652_);
v___x_1664_ = v___x_1661_;
goto v_reusejp_1663_;
}
else
{
lean_object* v_reuseFailAlloc_1665_; 
v_reuseFailAlloc_1665_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_1665_, 0, v_work_1653_);
lean_ctor_set(v_reuseFailAlloc_1665_, 1, v_inputEntries_1654_);
lean_ctor_set(v_reuseFailAlloc_1665_, 2, v_n_1652_);
lean_ctor_set(v_reuseFailAlloc_1665_, 3, v_packedBytes_1655_);
lean_ctor_set(v_reuseFailAlloc_1665_, 4, v_traceNodes_1656_);
lean_ctor_set(v_reuseFailAlloc_1665_, 5, v_processedRows_1657_);
lean_ctor_set(v_reuseFailAlloc_1665_, 6, v_reductions_1658_);
lean_ctor_set(v_reuseFailAlloc_1665_, 7, v_zeroRows_1659_);
v___x_1664_ = v_reuseFailAlloc_1665_;
goto v_reusejp_1663_;
}
v_reusejp_1663_:
{
return v___x_1664_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___lam__1(lean_object* v_x_1668_){
_start:
{
lean_object* v_outputEntries_1669_; 
v_outputEntries_1669_ = lean_ctor_get(v_x_1668_, 2);
lean_inc(v_outputEntries_1669_);
return v_outputEntries_1669_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___lam__1___boxed(lean_object* v_x_1670_){
_start:
{
lean_object* v_res_1671_; 
v_res_1671_ = lp_Hex_Hex_Groebner_Matrix_scaleSparse___lam__1(v_x_1670_);
lean_dec_ref(v_x_1670_);
return v_res_1671_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0___redArg(uint64_t v_field_1672_, uint64_t v_ctx_1673_, uint64_t v_inverse_1674_, uint8_t v_width_1675_, lean_object* v___x_1676_, lean_object* v_range_1677_, lean_object* v_b_1678_, lean_object* v_i_1679_, lean_object* v___y_1680_){
_start:
{
lean_object* v_stop_1681_; lean_object* v_step_1682_; lean_object* v_a_1684_; lean_object* v_snd_1685_; uint64_t v___y_1689_; uint64_t v___y_1710_; uint8_t v___y_1711_; uint64_t v___y_1717_; uint8_t v___y_1718_; uint8_t v___x_1723_; 
v_stop_1681_ = lean_ctor_get(v_range_1677_, 1);
v_step_1682_ = lean_ctor_get(v_range_1677_, 2);
v___x_1723_ = lean_nat_dec_lt(v_i_1679_, v_stop_1681_);
if (v___x_1723_ == 0)
{
lean_object* v___x_1724_; lean_object* v___x_1725_; 
lean_dec(v_i_1679_);
v___x_1724_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1724_, 0, v_b_1678_);
v___x_1725_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1725_, 0, v___x_1724_);
lean_ctor_set(v___x_1725_, 1, v___y_1680_);
return v___x_1725_;
}
else
{
uint8_t v___x_1726_; uint64_t v___y_1728_; lean_object* v___y_1729_; uint8_t v___y_1730_; uint64_t v___y_1743_; lean_object* v___y_1744_; uint8_t v___y_1745_; lean_object* v___y_1758_; uint8_t v___y_1759_; lean_object* v___y_1776_; uint8_t v___y_1777_; lean_object* v___y_1815_; 
v___x_1726_ = 0;
switch(v_width_1675_)
{
case 0:
{
lean_object* v___x_1823_; 
v___x_1823_ = lean_unsigned_to_nat(1u);
v___y_1815_ = v___x_1823_;
goto v___jp_1814_;
}
case 1:
{
lean_object* v___x_1824_; 
v___x_1824_ = lean_unsigned_to_nat(2u);
v___y_1815_ = v___x_1824_;
goto v___jp_1814_;
}
default: 
{
lean_object* v___x_1825_; 
v___x_1825_ = lean_unsigned_to_nat(4u);
v___y_1815_ = v___x_1825_;
goto v___jp_1814_;
}
}
v___jp_1727_:
{
uint64_t v___x_1731_; uint64_t v___x_1732_; uint64_t v___x_1733_; uint64_t v___x_1734_; lean_object* v___x_1735_; lean_object* v___x_1736_; uint8_t v___x_1737_; 
v___x_1731_ = lean_uint8_to_uint64(v___y_1730_);
v___x_1732_ = 16ULL;
v___x_1733_ = lean_uint64_shift_left(v___x_1731_, v___x_1732_);
v___x_1734_ = lean_uint64_lor(v___y_1728_, v___x_1733_);
v___x_1735_ = lean_unsigned_to_nat(3u);
v___x_1736_ = lean_nat_add(v___y_1729_, v___x_1735_);
lean_dec(v___y_1729_);
v___x_1737_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1676_, v___x_1736_);
if (v___x_1737_ == 0)
{
lean_object* v___x_1738_; lean_object* v___x_1739_; uint8_t v___x_1740_; 
lean_dec(v___x_1736_);
v___x_1738_ = lean_box(v___x_1726_);
v___x_1739_ = l_outOfBounds___redArg(v___x_1738_);
lean_dec(v___x_1738_);
v___x_1740_ = lean_unbox(v___x_1739_);
lean_dec(v___x_1739_);
v___y_1710_ = v___x_1734_;
v___y_1711_ = v___x_1740_;
goto v___jp_1709_;
}
else
{
uint8_t v___x_1741_; 
v___x_1741_ = lean_byte_array_fget(v___x_1676_, v___x_1736_);
lean_dec(v___x_1736_);
v___y_1710_ = v___x_1734_;
v___y_1711_ = v___x_1741_;
goto v___jp_1709_;
}
}
v___jp_1742_:
{
uint64_t v___x_1746_; uint64_t v___x_1747_; uint64_t v___x_1748_; uint64_t v___x_1749_; lean_object* v___x_1750_; lean_object* v___x_1751_; uint8_t v___x_1752_; 
v___x_1746_ = lean_uint8_to_uint64(v___y_1745_);
v___x_1747_ = 8ULL;
v___x_1748_ = lean_uint64_shift_left(v___x_1746_, v___x_1747_);
v___x_1749_ = lean_uint64_lor(v___y_1743_, v___x_1748_);
v___x_1750_ = lean_unsigned_to_nat(2u);
v___x_1751_ = lean_nat_add(v___y_1744_, v___x_1750_);
v___x_1752_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1676_, v___x_1751_);
if (v___x_1752_ == 0)
{
lean_object* v___x_1753_; lean_object* v___x_1754_; uint8_t v___x_1755_; 
lean_dec(v___x_1751_);
v___x_1753_ = lean_box(v___x_1726_);
v___x_1754_ = l_outOfBounds___redArg(v___x_1753_);
lean_dec(v___x_1753_);
v___x_1755_ = lean_unbox(v___x_1754_);
lean_dec(v___x_1754_);
v___y_1728_ = v___x_1749_;
v___y_1729_ = v___y_1744_;
v___y_1730_ = v___x_1755_;
goto v___jp_1727_;
}
else
{
uint8_t v___x_1756_; 
v___x_1756_ = lean_byte_array_fget(v___x_1676_, v___x_1751_);
lean_dec(v___x_1751_);
v___y_1728_ = v___x_1749_;
v___y_1729_ = v___y_1744_;
v___y_1730_ = v___x_1756_;
goto v___jp_1727_;
}
}
v___jp_1757_:
{
uint64_t v_a_1760_; 
v_a_1760_ = lean_uint8_to_uint64(v___y_1759_);
switch(v_width_1675_)
{
case 0:
{
lean_dec(v___y_1758_);
v___y_1689_ = v_a_1760_;
goto v___jp_1688_;
}
case 1:
{
lean_object* v___x_1761_; lean_object* v___x_1762_; uint8_t v___x_1763_; 
v___x_1761_ = lean_unsigned_to_nat(1u);
v___x_1762_ = lean_nat_add(v___y_1758_, v___x_1761_);
lean_dec(v___y_1758_);
v___x_1763_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1676_, v___x_1762_);
if (v___x_1763_ == 0)
{
lean_object* v___x_1764_; lean_object* v___x_1765_; uint8_t v___x_1766_; 
lean_dec(v___x_1762_);
v___x_1764_ = lean_box(v___x_1726_);
v___x_1765_ = l_outOfBounds___redArg(v___x_1764_);
lean_dec(v___x_1764_);
v___x_1766_ = lean_unbox(v___x_1765_);
lean_dec(v___x_1765_);
v___y_1717_ = v_a_1760_;
v___y_1718_ = v___x_1766_;
goto v___jp_1716_;
}
else
{
uint8_t v___x_1767_; 
v___x_1767_ = lean_byte_array_fget(v___x_1676_, v___x_1762_);
lean_dec(v___x_1762_);
v___y_1717_ = v_a_1760_;
v___y_1718_ = v___x_1767_;
goto v___jp_1716_;
}
}
default: 
{
lean_object* v___x_1768_; lean_object* v___x_1769_; uint8_t v___x_1770_; 
v___x_1768_ = lean_unsigned_to_nat(1u);
v___x_1769_ = lean_nat_add(v___y_1758_, v___x_1768_);
v___x_1770_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1676_, v___x_1769_);
if (v___x_1770_ == 0)
{
lean_object* v___x_1771_; lean_object* v___x_1772_; uint8_t v___x_1773_; 
lean_dec(v___x_1769_);
v___x_1771_ = lean_box(v___x_1726_);
v___x_1772_ = l_outOfBounds___redArg(v___x_1771_);
lean_dec(v___x_1771_);
v___x_1773_ = lean_unbox(v___x_1772_);
lean_dec(v___x_1772_);
v___y_1743_ = v_a_1760_;
v___y_1744_ = v___y_1758_;
v___y_1745_ = v___x_1773_;
goto v___jp_1742_;
}
else
{
uint8_t v___x_1774_; 
v___x_1774_ = lean_byte_array_fget(v___x_1676_, v___x_1769_);
lean_dec(v___x_1769_);
v___y_1743_ = v_a_1760_;
v___y_1744_ = v___y_1758_;
v___y_1745_ = v___x_1774_;
goto v___jp_1742_;
}
}
}
}
v___jp_1775_:
{
if (v___y_1777_ == 0)
{
uint8_t v___x_1778_; 
v___x_1778_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_validate_spec__0___redArg___lam__0(v___x_1676_, v___y_1776_);
if (v___x_1778_ == 0)
{
lean_object* v___x_1779_; lean_object* v___x_1780_; uint8_t v___x_1781_; 
v___x_1779_ = lean_box(v___x_1726_);
v___x_1780_ = l_outOfBounds___redArg(v___x_1779_);
lean_dec(v___x_1779_);
v___x_1781_ = lean_unbox(v___x_1780_);
lean_dec(v___x_1780_);
v___y_1758_ = v___y_1776_;
v___y_1759_ = v___x_1781_;
goto v___jp_1757_;
}
else
{
uint8_t v___x_1782_; 
v___x_1782_ = lean_byte_array_fget(v___x_1676_, v___y_1776_);
v___y_1758_ = v___y_1776_;
v___y_1759_ = v___x_1782_;
goto v___jp_1757_;
}
}
else
{
size_t v_pos_1783_; uint8_t v___x_1784_; uint64_t v_a_1785_; 
v_pos_1783_ = lean_usize_of_nat(v___y_1776_);
lean_dec(v___y_1776_);
v___x_1784_ = lean_byte_array_uget(v___x_1676_, v_pos_1783_);
v_a_1785_ = lean_uint8_to_uint64(v___x_1784_);
switch(v_width_1675_)
{
case 0:
{
v___y_1689_ = v_a_1785_;
goto v___jp_1688_;
}
case 1:
{
size_t v___x_1786_; size_t v___x_1787_; uint8_t v___x_1788_; uint64_t v___x_1789_; uint64_t v___x_1790_; uint64_t v___x_1791_; uint64_t v___x_1792_; 
v___x_1786_ = ((size_t)1ULL);
v___x_1787_ = lean_usize_add(v_pos_1783_, v___x_1786_);
v___x_1788_ = lean_byte_array_uget(v___x_1676_, v___x_1787_);
v___x_1789_ = lean_uint8_to_uint64(v___x_1788_);
v___x_1790_ = 8ULL;
v___x_1791_ = lean_uint64_shift_left(v___x_1789_, v___x_1790_);
v___x_1792_ = lean_uint64_lor(v_a_1785_, v___x_1791_);
v___y_1689_ = v___x_1792_;
goto v___jp_1688_;
}
default: 
{
size_t v___x_1793_; size_t v___x_1794_; uint8_t v___x_1795_; uint64_t v___x_1796_; uint64_t v___x_1797_; uint64_t v___x_1798_; uint64_t v___x_1799_; size_t v___x_1800_; size_t v___x_1801_; uint8_t v___x_1802_; uint64_t v___x_1803_; uint64_t v___x_1804_; uint64_t v___x_1805_; uint64_t v___x_1806_; size_t v___x_1807_; size_t v___x_1808_; uint8_t v___x_1809_; uint64_t v___x_1810_; uint64_t v___x_1811_; uint64_t v___x_1812_; uint64_t v___x_1813_; 
v___x_1793_ = ((size_t)1ULL);
v___x_1794_ = lean_usize_add(v_pos_1783_, v___x_1793_);
v___x_1795_ = lean_byte_array_uget(v___x_1676_, v___x_1794_);
v___x_1796_ = lean_uint8_to_uint64(v___x_1795_);
v___x_1797_ = 8ULL;
v___x_1798_ = lean_uint64_shift_left(v___x_1796_, v___x_1797_);
v___x_1799_ = lean_uint64_lor(v_a_1785_, v___x_1798_);
v___x_1800_ = ((size_t)2ULL);
v___x_1801_ = lean_usize_add(v_pos_1783_, v___x_1800_);
v___x_1802_ = lean_byte_array_uget(v___x_1676_, v___x_1801_);
v___x_1803_ = lean_uint8_to_uint64(v___x_1802_);
v___x_1804_ = 16ULL;
v___x_1805_ = lean_uint64_shift_left(v___x_1803_, v___x_1804_);
v___x_1806_ = lean_uint64_lor(v___x_1799_, v___x_1805_);
v___x_1807_ = ((size_t)3ULL);
v___x_1808_ = lean_usize_add(v_pos_1783_, v___x_1807_);
v___x_1809_ = lean_byte_array_uget(v___x_1676_, v___x_1808_);
v___x_1810_ = lean_uint8_to_uint64(v___x_1809_);
v___x_1811_ = 24ULL;
v___x_1812_ = lean_uint64_shift_left(v___x_1810_, v___x_1811_);
v___x_1813_ = lean_uint64_lor(v___x_1806_, v___x_1812_);
v___y_1689_ = v___x_1813_;
goto v___jp_1688_;
}
}
}
}
v___jp_1814_:
{
lean_object* v_offset_1816_; lean_object* v___x_1817_; lean_object* v___x_1818_; uint8_t v___x_1819_; 
v_offset_1816_ = lean_nat_mul(v_i_1679_, v___y_1815_);
v___x_1817_ = lean_nat_add(v_offset_1816_, v___y_1815_);
v___x_1818_ = lean_byte_array_size(v___x_1676_);
v___x_1819_ = lean_nat_dec_le(v___x_1817_, v___x_1818_);
if (v___x_1819_ == 0)
{
lean_dec(v___x_1817_);
v___y_1776_ = v_offset_1816_;
v___y_1777_ = v___x_1819_;
goto v___jp_1775_;
}
else
{
size_t v___x_1820_; lean_object* v___x_1821_; uint8_t v___x_1822_; 
v___x_1820_ = lean_usize_of_nat(v___x_1817_);
v___x_1821_ = lean_usize_to_nat(v___x_1820_);
v___x_1822_ = lean_nat_dec_eq(v___x_1821_, v___x_1817_);
lean_dec(v___x_1817_);
lean_dec(v___x_1821_);
v___y_1776_ = v_offset_1816_;
v___y_1777_ = v___x_1822_;
goto v___jp_1775_;
}
}
}
v___jp_1683_:
{
lean_object* v___x_1686_; 
v___x_1686_ = lean_nat_add(v_i_1679_, v_step_1682_);
lean_dec(v_i_1679_);
v_b_1678_ = v_a_1684_;
v_i_1679_ = v___x_1686_;
v___y_1680_ = v_snd_1685_;
goto _start;
}
v___jp_1688_:
{
uint64_t v___x_1690_; uint8_t v___x_1691_; lean_object* v_data_1692_; 
v___x_1690_ = lp_Hex_BarrettCtx_mulMod(v_field_1672_, v_ctx_1673_, v___y_1689_, v_inverse_1674_);
v___x_1691_ = lean_uint64_to_uint8(v___x_1690_);
v_data_1692_ = lean_byte_array_push(v_b_1678_, v___x_1691_);
switch(v_width_1675_)
{
case 0:
{
v_a_1684_ = v_data_1692_;
v_snd_1685_ = v___y_1680_;
goto v___jp_1683_;
}
case 1:
{
uint64_t v___x_1693_; uint64_t v___x_1694_; uint8_t v___x_1695_; lean_object* v___x_1696_; 
v___x_1693_ = 8ULL;
v___x_1694_ = lean_uint64_shift_right(v___x_1690_, v___x_1693_);
v___x_1695_ = lean_uint64_to_uint8(v___x_1694_);
v___x_1696_ = lean_byte_array_push(v_data_1692_, v___x_1695_);
v_a_1684_ = v___x_1696_;
v_snd_1685_ = v___y_1680_;
goto v___jp_1683_;
}
default: 
{
uint64_t v___x_1697_; uint64_t v___x_1698_; uint8_t v___x_1699_; lean_object* v___x_1700_; uint64_t v___x_1701_; uint64_t v___x_1702_; uint8_t v___x_1703_; lean_object* v___x_1704_; uint64_t v___x_1705_; uint64_t v___x_1706_; uint8_t v___x_1707_; lean_object* v___x_1708_; 
v___x_1697_ = 8ULL;
v___x_1698_ = lean_uint64_shift_right(v___x_1690_, v___x_1697_);
v___x_1699_ = lean_uint64_to_uint8(v___x_1698_);
v___x_1700_ = lean_byte_array_push(v_data_1692_, v___x_1699_);
v___x_1701_ = 16ULL;
v___x_1702_ = lean_uint64_shift_right(v___x_1690_, v___x_1701_);
v___x_1703_ = lean_uint64_to_uint8(v___x_1702_);
v___x_1704_ = lean_byte_array_push(v___x_1700_, v___x_1703_);
v___x_1705_ = 24ULL;
v___x_1706_ = lean_uint64_shift_right(v___x_1690_, v___x_1705_);
v___x_1707_ = lean_uint64_to_uint8(v___x_1706_);
v___x_1708_ = lean_byte_array_push(v___x_1704_, v___x_1707_);
v_a_1684_ = v___x_1708_;
v_snd_1685_ = v___y_1680_;
goto v___jp_1683_;
}
}
}
v___jp_1709_:
{
uint64_t v___x_1712_; uint64_t v___x_1713_; uint64_t v___x_1714_; uint64_t v___x_1715_; 
v___x_1712_ = lean_uint8_to_uint64(v___y_1711_);
v___x_1713_ = 24ULL;
v___x_1714_ = lean_uint64_shift_left(v___x_1712_, v___x_1713_);
v___x_1715_ = lean_uint64_lor(v___y_1710_, v___x_1714_);
v___y_1689_ = v___x_1715_;
goto v___jp_1688_;
}
v___jp_1716_:
{
uint64_t v___x_1719_; uint64_t v___x_1720_; uint64_t v___x_1721_; uint64_t v___x_1722_; 
v___x_1719_ = lean_uint8_to_uint64(v___y_1718_);
v___x_1720_ = 8ULL;
v___x_1721_ = lean_uint64_shift_left(v___x_1719_, v___x_1720_);
v___x_1722_ = lean_uint64_lor(v___y_1717_, v___x_1721_);
v___y_1689_ = v___x_1722_;
goto v___jp_1688_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0___redArg___boxed(lean_object* v_field_1826_, lean_object* v_ctx_1827_, lean_object* v_inverse_1828_, lean_object* v_width_1829_, lean_object* v___x_1830_, lean_object* v_range_1831_, lean_object* v_b_1832_, lean_object* v_i_1833_, lean_object* v___y_1834_){
_start:
{
uint64_t v_field_boxed_1835_; uint64_t v_ctx_boxed_1836_; uint64_t v_inverse_boxed_1837_; uint8_t v_width_boxed_1838_; lean_object* v_res_1839_; 
v_field_boxed_1835_ = lean_unbox_uint64(v_field_1826_);
lean_dec_ref(v_field_1826_);
v_ctx_boxed_1836_ = lean_unbox_uint64(v_ctx_1827_);
lean_dec_ref(v_ctx_1827_);
v_inverse_boxed_1837_ = lean_unbox_uint64(v_inverse_1828_);
lean_dec_ref(v_inverse_1828_);
v_width_boxed_1838_ = lean_unbox(v_width_1829_);
v_res_1839_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0___redArg(v_field_boxed_1835_, v_ctx_boxed_1836_, v_inverse_boxed_1837_, v_width_boxed_1838_, v___x_1830_, v_range_1831_, v_b_1832_, v_i_1833_, v___y_1834_);
lean_dec_ref(v_range_1831_);
lean_dec_ref(v___x_1830_);
return v_res_1839_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse(uint64_t v_field_1842_, uint64_t v_ctx_1843_, lean_object* v_limits_1844_, lean_object* v_row_1845_, uint64_t v_inverse_1846_, lean_object* v_a_1847_){
_start:
{
lean_object* v_outputEntries_1848_; lean_object* v___f_1849_; lean_object* v___f_1850_; uint8_t v___x_1851_; lean_object* v___x_1852_; lean_object* v___x_1853_; lean_object* v_fst_1854_; 
v_outputEntries_1848_ = lean_ctor_get(v_limits_1844_, 3);
v___f_1849_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_scaleSparse___closed__0));
v___f_1850_ = ((lean_object*)(lp_Hex_Hex_Groebner_Matrix_scaleSparse___closed__1));
v___x_1851_ = 3;
v___x_1852_ = lp_Hex_Hex_Groebner_SparseRow_size(v_row_1845_);
v___x_1853_ = lp_Hex_Hex_Groebner_Matrix_charge(v___x_1851_, v___x_1852_, v_outputEntries_1848_, v___f_1850_, v___f_1849_, v_a_1847_);
v_fst_1854_ = lean_ctor_get(v___x_1853_, 0);
lean_inc(v_fst_1854_);
if (lean_obj_tag(v_fst_1854_) == 0)
{
lean_object* v_snd_1855_; lean_object* v___x_1857_; uint8_t v_isShared_1858_; uint8_t v_isSharedCheck_1870_; 
lean_dec(v___x_1852_);
lean_dec_ref(v_row_1845_);
v_snd_1855_ = lean_ctor_get(v___x_1853_, 1);
v_isSharedCheck_1870_ = !lean_is_exclusive(v___x_1853_);
if (v_isSharedCheck_1870_ == 0)
{
lean_object* v_unused_1871_; 
v_unused_1871_ = lean_ctor_get(v___x_1853_, 0);
lean_dec(v_unused_1871_);
v___x_1857_ = v___x_1853_;
v_isShared_1858_ = v_isSharedCheck_1870_;
goto v_resetjp_1856_;
}
else
{
lean_inc(v_snd_1855_);
lean_dec(v___x_1853_);
v___x_1857_ = lean_box(0);
v_isShared_1858_ = v_isSharedCheck_1870_;
goto v_resetjp_1856_;
}
v_resetjp_1856_:
{
lean_object* v_a_1859_; lean_object* v___x_1861_; uint8_t v_isShared_1862_; uint8_t v_isSharedCheck_1869_; 
v_a_1859_ = lean_ctor_get(v_fst_1854_, 0);
v_isSharedCheck_1869_ = !lean_is_exclusive(v_fst_1854_);
if (v_isSharedCheck_1869_ == 0)
{
v___x_1861_ = v_fst_1854_;
v_isShared_1862_ = v_isSharedCheck_1869_;
goto v_resetjp_1860_;
}
else
{
lean_inc(v_a_1859_);
lean_dec(v_fst_1854_);
v___x_1861_ = lean_box(0);
v_isShared_1862_ = v_isSharedCheck_1869_;
goto v_resetjp_1860_;
}
v_resetjp_1860_:
{
lean_object* v___x_1864_; 
if (v_isShared_1862_ == 0)
{
v___x_1864_ = v___x_1861_;
goto v_reusejp_1863_;
}
else
{
lean_object* v_reuseFailAlloc_1868_; 
v_reuseFailAlloc_1868_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1868_, 0, v_a_1859_);
v___x_1864_ = v_reuseFailAlloc_1868_;
goto v_reusejp_1863_;
}
v_reusejp_1863_:
{
lean_object* v___x_1866_; 
if (v_isShared_1858_ == 0)
{
lean_ctor_set(v___x_1857_, 0, v___x_1864_);
v___x_1866_ = v___x_1857_;
goto v_reusejp_1865_;
}
else
{
lean_object* v_reuseFailAlloc_1867_; 
v_reuseFailAlloc_1867_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1867_, 0, v___x_1864_);
lean_ctor_set(v_reuseFailAlloc_1867_, 1, v_snd_1855_);
v___x_1866_ = v_reuseFailAlloc_1867_;
goto v_reusejp_1865_;
}
v_reusejp_1865_:
{
return v___x_1866_;
}
}
}
}
}
else
{
lean_object* v_snd_1872_; lean_object* v_columns_1873_; lean_object* v_coefficients_1874_; lean_object* v___x_1875_; lean_object* v___x_1876_; lean_object* v___x_1877_; lean_object* v___x_1878_; lean_object* v_fst_1879_; 
lean_dec_ref_known(v_fst_1854_, 1);
v_snd_1872_ = lean_ctor_get(v___x_1853_, 1);
lean_inc(v_snd_1872_);
lean_dec_ref(v___x_1853_);
v_columns_1873_ = lean_ctor_get(v_row_1845_, 0);
v_coefficients_1874_ = lean_ctor_get(v_row_1845_, 1);
v___x_1875_ = lean_byte_array_size(v_columns_1873_);
v___x_1876_ = lean_byte_array_size(v_coefficients_1874_);
v___x_1877_ = lean_nat_add(v___x_1875_, v___x_1876_);
v___x_1878_ = lp_Hex_Hex_Groebner_Matrix_packedBytes(v_limits_1844_, v___x_1877_, v_snd_1872_);
lean_dec(v___x_1877_);
v_fst_1879_ = lean_ctor_get(v___x_1878_, 0);
lean_inc(v_fst_1879_);
if (lean_obj_tag(v_fst_1879_) == 0)
{
lean_object* v_snd_1880_; lean_object* v___x_1882_; uint8_t v_isShared_1883_; uint8_t v_isSharedCheck_1895_; 
lean_dec(v___x_1852_);
lean_dec_ref(v_row_1845_);
v_snd_1880_ = lean_ctor_get(v___x_1878_, 1);
v_isSharedCheck_1895_ = !lean_is_exclusive(v___x_1878_);
if (v_isSharedCheck_1895_ == 0)
{
lean_object* v_unused_1896_; 
v_unused_1896_ = lean_ctor_get(v___x_1878_, 0);
lean_dec(v_unused_1896_);
v___x_1882_ = v___x_1878_;
v_isShared_1883_ = v_isSharedCheck_1895_;
goto v_resetjp_1881_;
}
else
{
lean_inc(v_snd_1880_);
lean_dec(v___x_1878_);
v___x_1882_ = lean_box(0);
v_isShared_1883_ = v_isSharedCheck_1895_;
goto v_resetjp_1881_;
}
v_resetjp_1881_:
{
lean_object* v_a_1884_; lean_object* v___x_1886_; uint8_t v_isShared_1887_; uint8_t v_isSharedCheck_1894_; 
v_a_1884_ = lean_ctor_get(v_fst_1879_, 0);
v_isSharedCheck_1894_ = !lean_is_exclusive(v_fst_1879_);
if (v_isSharedCheck_1894_ == 0)
{
v___x_1886_ = v_fst_1879_;
v_isShared_1887_ = v_isSharedCheck_1894_;
goto v_resetjp_1885_;
}
else
{
lean_inc(v_a_1884_);
lean_dec(v_fst_1879_);
v___x_1886_ = lean_box(0);
v_isShared_1887_ = v_isSharedCheck_1894_;
goto v_resetjp_1885_;
}
v_resetjp_1885_:
{
lean_object* v___x_1889_; 
if (v_isShared_1887_ == 0)
{
v___x_1889_ = v___x_1886_;
goto v_reusejp_1888_;
}
else
{
lean_object* v_reuseFailAlloc_1893_; 
v_reuseFailAlloc_1893_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1893_, 0, v_a_1884_);
v___x_1889_ = v_reuseFailAlloc_1893_;
goto v_reusejp_1888_;
}
v_reusejp_1888_:
{
lean_object* v___x_1891_; 
if (v_isShared_1883_ == 0)
{
lean_ctor_set(v___x_1882_, 0, v___x_1889_);
v___x_1891_ = v___x_1882_;
goto v_reusejp_1890_;
}
else
{
lean_object* v_reuseFailAlloc_1892_; 
v_reuseFailAlloc_1892_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1892_, 0, v___x_1889_);
lean_ctor_set(v_reuseFailAlloc_1892_, 1, v_snd_1880_);
v___x_1891_ = v_reuseFailAlloc_1892_;
goto v_reusejp_1890_;
}
v_reusejp_1890_:
{
return v___x_1891_;
}
}
}
}
}
else
{
lean_object* v_snd_1897_; lean_object* v___x_1899_; uint8_t v_isShared_1900_; uint8_t v_isSharedCheck_1966_; 
v_snd_1897_ = lean_ctor_get(v___x_1878_, 1);
v_isSharedCheck_1966_ = !lean_is_exclusive(v___x_1878_);
if (v_isSharedCheck_1966_ == 0)
{
lean_object* v_unused_1967_; 
v_unused_1967_ = lean_ctor_get(v___x_1878_, 0);
lean_dec(v_unused_1967_);
v___x_1899_ = v___x_1878_;
v_isShared_1900_ = v_isSharedCheck_1966_;
goto v_resetjp_1898_;
}
else
{
lean_inc(v_snd_1897_);
lean_dec(v___x_1878_);
v___x_1899_ = lean_box(0);
v_isShared_1900_ = v_isSharedCheck_1966_;
goto v_resetjp_1898_;
}
v_resetjp_1898_:
{
lean_object* v___x_1902_; uint8_t v_isShared_1903_; uint8_t v_isSharedCheck_1964_; 
v_isSharedCheck_1964_ = !lean_is_exclusive(v_fst_1879_);
if (v_isSharedCheck_1964_ == 0)
{
lean_object* v_unused_1965_; 
v_unused_1965_ = lean_ctor_get(v_fst_1879_, 0);
lean_dec(v_unused_1965_);
v___x_1902_ = v_fst_1879_;
v_isShared_1903_ = v_isSharedCheck_1964_;
goto v_resetjp_1901_;
}
else
{
lean_dec(v_fst_1879_);
v___x_1902_ = lean_box(0);
v_isShared_1903_ = v_isSharedCheck_1964_;
goto v_resetjp_1901_;
}
v_resetjp_1901_:
{
uint64_t v___x_1904_; uint8_t v___x_1905_; 
v___x_1904_ = 1ULL;
v___x_1905_ = lean_uint64_dec_eq(v_inverse_1846_, v___x_1904_);
if (v___x_1905_ == 0)
{
lean_object* v___x_1907_; uint8_t v_isShared_1908_; uint8_t v_isSharedCheck_1955_; 
lean_inc_ref(v_coefficients_1874_);
lean_inc_ref(v_columns_1873_);
lean_del_object(v___x_1902_);
lean_del_object(v___x_1899_);
v_isSharedCheck_1955_ = !lean_is_exclusive(v_row_1845_);
if (v_isSharedCheck_1955_ == 0)
{
lean_object* v_unused_1956_; lean_object* v_unused_1957_; 
v_unused_1956_ = lean_ctor_get(v_row_1845_, 1);
lean_dec(v_unused_1956_);
v_unused_1957_ = lean_ctor_get(v_row_1845_, 0);
lean_dec(v_unused_1957_);
v___x_1907_ = v_row_1845_;
v_isShared_1908_ = v_isSharedCheck_1955_;
goto v_resetjp_1906_;
}
else
{
lean_dec(v_row_1845_);
v___x_1907_ = lean_box(0);
v_isShared_1908_ = v_isSharedCheck_1955_;
goto v_resetjp_1906_;
}
v_resetjp_1906_:
{
lean_object* v___x_1909_; lean_object* v_fst_1910_; 
v___x_1909_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_1844_, v___x_1852_, v_snd_1897_);
v_fst_1910_ = lean_ctor_get(v___x_1909_, 0);
lean_inc(v_fst_1910_);
if (lean_obj_tag(v_fst_1910_) == 0)
{
lean_object* v_snd_1911_; lean_object* v___x_1913_; uint8_t v_isShared_1914_; uint8_t v_isSharedCheck_1926_; 
lean_del_object(v___x_1907_);
lean_dec_ref(v_coefficients_1874_);
lean_dec_ref(v_columns_1873_);
lean_dec(v___x_1852_);
v_snd_1911_ = lean_ctor_get(v___x_1909_, 1);
v_isSharedCheck_1926_ = !lean_is_exclusive(v___x_1909_);
if (v_isSharedCheck_1926_ == 0)
{
lean_object* v_unused_1927_; 
v_unused_1927_ = lean_ctor_get(v___x_1909_, 0);
lean_dec(v_unused_1927_);
v___x_1913_ = v___x_1909_;
v_isShared_1914_ = v_isSharedCheck_1926_;
goto v_resetjp_1912_;
}
else
{
lean_inc(v_snd_1911_);
lean_dec(v___x_1909_);
v___x_1913_ = lean_box(0);
v_isShared_1914_ = v_isSharedCheck_1926_;
goto v_resetjp_1912_;
}
v_resetjp_1912_:
{
lean_object* v_a_1915_; lean_object* v___x_1917_; uint8_t v_isShared_1918_; uint8_t v_isSharedCheck_1925_; 
v_a_1915_ = lean_ctor_get(v_fst_1910_, 0);
v_isSharedCheck_1925_ = !lean_is_exclusive(v_fst_1910_);
if (v_isSharedCheck_1925_ == 0)
{
v___x_1917_ = v_fst_1910_;
v_isShared_1918_ = v_isSharedCheck_1925_;
goto v_resetjp_1916_;
}
else
{
lean_inc(v_a_1915_);
lean_dec(v_fst_1910_);
v___x_1917_ = lean_box(0);
v_isShared_1918_ = v_isSharedCheck_1925_;
goto v_resetjp_1916_;
}
v_resetjp_1916_:
{
lean_object* v___x_1920_; 
if (v_isShared_1918_ == 0)
{
v___x_1920_ = v___x_1917_;
goto v_reusejp_1919_;
}
else
{
lean_object* v_reuseFailAlloc_1924_; 
v_reuseFailAlloc_1924_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1924_, 0, v_a_1915_);
v___x_1920_ = v_reuseFailAlloc_1924_;
goto v_reusejp_1919_;
}
v_reusejp_1919_:
{
lean_object* v___x_1922_; 
if (v_isShared_1914_ == 0)
{
lean_ctor_set(v___x_1913_, 0, v___x_1920_);
v___x_1922_ = v___x_1913_;
goto v_reusejp_1921_;
}
else
{
lean_object* v_reuseFailAlloc_1923_; 
v_reuseFailAlloc_1923_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1923_, 0, v___x_1920_);
lean_ctor_set(v_reuseFailAlloc_1923_, 1, v_snd_1911_);
v___x_1922_ = v_reuseFailAlloc_1923_;
goto v_reusejp_1921_;
}
v_reusejp_1921_:
{
return v___x_1922_;
}
}
}
}
}
else
{
lean_object* v_snd_1928_; lean_object* v___x_1929_; uint8_t v_width_1930_; lean_object* v_coefficients_1931_; lean_object* v___x_1932_; lean_object* v___x_1933_; lean_object* v___x_1934_; lean_object* v_fst_1935_; lean_object* v_snd_1936_; lean_object* v___x_1938_; uint8_t v_isShared_1939_; uint8_t v_isSharedCheck_1954_; 
lean_dec_ref_known(v_fst_1910_, 1);
v_snd_1928_ = lean_ctor_get(v___x_1909_, 1);
lean_inc(v_snd_1928_);
lean_dec_ref(v___x_1909_);
v___x_1929_ = lean_unsigned_to_nat(1u);
v_width_1930_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_1842_);
v_coefficients_1931_ = lean_mk_empty_byte_array(v___x_1876_);
v___x_1932_ = lean_unsigned_to_nat(0u);
v___x_1933_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1933_, 0, v___x_1932_);
lean_ctor_set(v___x_1933_, 1, v___x_1852_);
lean_ctor_set(v___x_1933_, 2, v___x_1929_);
v___x_1934_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0___redArg(v_field_1842_, v_ctx_1843_, v_inverse_1846_, v_width_1930_, v_coefficients_1874_, v___x_1933_, v_coefficients_1931_, v___x_1932_, v_snd_1928_);
lean_dec_ref_known(v___x_1933_, 3);
lean_dec_ref(v_coefficients_1874_);
v_fst_1935_ = lean_ctor_get(v___x_1934_, 0);
v_snd_1936_ = lean_ctor_get(v___x_1934_, 1);
v_isSharedCheck_1954_ = !lean_is_exclusive(v___x_1934_);
if (v_isSharedCheck_1954_ == 0)
{
v___x_1938_ = v___x_1934_;
v_isShared_1939_ = v_isSharedCheck_1954_;
goto v_resetjp_1937_;
}
else
{
lean_inc(v_snd_1936_);
lean_inc(v_fst_1935_);
lean_dec(v___x_1934_);
v___x_1938_ = lean_box(0);
v_isShared_1939_ = v_isSharedCheck_1954_;
goto v_resetjp_1937_;
}
v_resetjp_1937_:
{
lean_object* v_a_1940_; lean_object* v___x_1942_; uint8_t v_isShared_1943_; uint8_t v_isSharedCheck_1953_; 
v_a_1940_ = lean_ctor_get(v_fst_1935_, 0);
v_isSharedCheck_1953_ = !lean_is_exclusive(v_fst_1935_);
if (v_isSharedCheck_1953_ == 0)
{
v___x_1942_ = v_fst_1935_;
v_isShared_1943_ = v_isSharedCheck_1953_;
goto v_resetjp_1941_;
}
else
{
lean_inc(v_a_1940_);
lean_dec(v_fst_1935_);
v___x_1942_ = lean_box(0);
v_isShared_1943_ = v_isSharedCheck_1953_;
goto v_resetjp_1941_;
}
v_resetjp_1941_:
{
lean_object* v___x_1945_; 
if (v_isShared_1908_ == 0)
{
lean_ctor_set(v___x_1907_, 1, v_a_1940_);
v___x_1945_ = v___x_1907_;
goto v_reusejp_1944_;
}
else
{
lean_object* v_reuseFailAlloc_1952_; 
v_reuseFailAlloc_1952_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1952_, 0, v_columns_1873_);
lean_ctor_set(v_reuseFailAlloc_1952_, 1, v_a_1940_);
v___x_1945_ = v_reuseFailAlloc_1952_;
goto v_reusejp_1944_;
}
v_reusejp_1944_:
{
lean_object* v___x_1947_; 
if (v_isShared_1943_ == 0)
{
lean_ctor_set(v___x_1942_, 0, v___x_1945_);
v___x_1947_ = v___x_1942_;
goto v_reusejp_1946_;
}
else
{
lean_object* v_reuseFailAlloc_1951_; 
v_reuseFailAlloc_1951_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1951_, 0, v___x_1945_);
v___x_1947_ = v_reuseFailAlloc_1951_;
goto v_reusejp_1946_;
}
v_reusejp_1946_:
{
lean_object* v___x_1949_; 
if (v_isShared_1939_ == 0)
{
lean_ctor_set(v___x_1938_, 0, v___x_1947_);
v___x_1949_ = v___x_1938_;
goto v_reusejp_1948_;
}
else
{
lean_object* v_reuseFailAlloc_1950_; 
v_reuseFailAlloc_1950_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1950_, 0, v___x_1947_);
lean_ctor_set(v_reuseFailAlloc_1950_, 1, v_snd_1936_);
v___x_1949_ = v_reuseFailAlloc_1950_;
goto v_reusejp_1948_;
}
v_reusejp_1948_:
{
return v___x_1949_;
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_1959_; 
lean_dec(v___x_1852_);
if (v_isShared_1903_ == 0)
{
lean_ctor_set(v___x_1902_, 0, v_row_1845_);
v___x_1959_ = v___x_1902_;
goto v_reusejp_1958_;
}
else
{
lean_object* v_reuseFailAlloc_1963_; 
v_reuseFailAlloc_1963_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1963_, 0, v_row_1845_);
v___x_1959_ = v_reuseFailAlloc_1963_;
goto v_reusejp_1958_;
}
v_reusejp_1958_:
{
lean_object* v___x_1961_; 
if (v_isShared_1900_ == 0)
{
lean_ctor_set(v___x_1899_, 0, v___x_1959_);
v___x_1961_ = v___x_1899_;
goto v_reusejp_1960_;
}
else
{
lean_object* v_reuseFailAlloc_1962_; 
v_reuseFailAlloc_1962_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1962_, 0, v___x_1959_);
lean_ctor_set(v_reuseFailAlloc_1962_, 1, v_snd_1897_);
v___x_1961_ = v_reuseFailAlloc_1962_;
goto v_reusejp_1960_;
}
v_reusejp_1960_:
{
return v___x_1961_;
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse___boxed(lean_object* v_field_1968_, lean_object* v_ctx_1969_, lean_object* v_limits_1970_, lean_object* v_row_1971_, lean_object* v_inverse_1972_, lean_object* v_a_1973_){
_start:
{
uint64_t v_field_boxed_1974_; uint64_t v_ctx_boxed_1975_; uint64_t v_inverse_boxed_1976_; lean_object* v_res_1977_; 
v_field_boxed_1974_ = lean_unbox_uint64(v_field_1968_);
lean_dec_ref(v_field_1968_);
v_ctx_boxed_1975_ = lean_unbox_uint64(v_ctx_1969_);
lean_dec_ref(v_ctx_1969_);
v_inverse_boxed_1976_ = lean_unbox_uint64(v_inverse_1972_);
lean_dec_ref(v_inverse_1972_);
v_res_1977_ = lp_Hex_Hex_Groebner_Matrix_scaleSparse(v_field_boxed_1974_, v_ctx_boxed_1975_, v_limits_1970_, v_row_1971_, v_inverse_boxed_1976_, v_a_1973_);
lean_dec_ref(v_limits_1970_);
return v_res_1977_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0(uint64_t v_field_1978_, uint64_t v_ctx_1979_, uint64_t v_inverse_1980_, uint8_t v_width_1981_, lean_object* v___x_1982_, lean_object* v_range_1983_, lean_object* v_b_1984_, lean_object* v_i_1985_, lean_object* v_hs_1986_, lean_object* v_hl_1987_, lean_object* v___y_1988_){
_start:
{
lean_object* v___x_1989_; 
v___x_1989_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0___redArg(v_field_1978_, v_ctx_1979_, v_inverse_1980_, v_width_1981_, v___x_1982_, v_range_1983_, v_b_1984_, v_i_1985_, v___y_1988_);
return v___x_1989_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0___boxed(lean_object* v_field_1990_, lean_object* v_ctx_1991_, lean_object* v_inverse_1992_, lean_object* v_width_1993_, lean_object* v___x_1994_, lean_object* v_range_1995_, lean_object* v_b_1996_, lean_object* v_i_1997_, lean_object* v_hs_1998_, lean_object* v_hl_1999_, lean_object* v___y_2000_){
_start:
{
uint64_t v_field_boxed_2001_; uint64_t v_ctx_boxed_2002_; uint64_t v_inverse_boxed_2003_; uint8_t v_width_boxed_2004_; lean_object* v_res_2005_; 
v_field_boxed_2001_ = lean_unbox_uint64(v_field_1990_);
lean_dec_ref(v_field_1990_);
v_ctx_boxed_2002_ = lean_unbox_uint64(v_ctx_1991_);
lean_dec_ref(v_ctx_1991_);
v_inverse_boxed_2003_ = lean_unbox_uint64(v_inverse_1992_);
lean_dec_ref(v_inverse_1992_);
v_width_boxed_2004_ = lean_unbox(v_width_1993_);
v_res_2005_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00Hex_Groebner_Matrix_scaleSparse_spec__0(v_field_boxed_2001_, v_ctx_boxed_2002_, v_inverse_boxed_2003_, v_width_boxed_2004_, v___x_1994_, v_range_1995_, v_b_1996_, v_i_1997_, v_hs_1998_, v_hl_1999_, v___y_2000_);
lean_dec_ref(v_range_1995_);
lean_dec_ref(v___x_1994_);
return v_res_2005_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Packed(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Native(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_Matrix(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Packed(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Native(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_Groebner_instInhabitedPivot_default = _init_lp_Hex_Hex_Groebner_instInhabitedPivot_default();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedPivot_default);
lp_Hex_Hex_Groebner_instInhabitedPivot = _init_lp_Hex_Hex_Groebner_instInhabitedPivot();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedPivot);
lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default = _init_lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedRemainderRow_default);
lp_Hex_Hex_Groebner_instInhabitedRemainderRow = _init_lp_Hex_Hex_Groebner_instInhabitedRemainderRow();
lean_mark_persistent(lp_Hex_Hex_Groebner_instInhabitedRemainderRow);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_Matrix(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Packed(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Native(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_Matrix(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Packed(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Native(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Matrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_Matrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_Matrix(builtin);
}
#ifdef __cplusplus
}
#endif
