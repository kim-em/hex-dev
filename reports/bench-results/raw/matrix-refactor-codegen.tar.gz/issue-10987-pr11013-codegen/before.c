LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate(uint64_t v0, lean_object* v1, lean_object* v2, lean_object* v3, lean_object* v4, uint8_t v5, lean_object* v6, uint8_t v7, uint8_t v8, lean_object* v9){
_start:
{
uint8_t v10; lean_object* v11; lean_object* v12; lean_object* v13; lean_object* v14; lean_object* v15; lean_object* v16; lean_object* v17; uint8_t v18; 
v17 = lean_unsigned_to_nat(4294967295u);
v18 = lean_nat_dec_lt(v17, v2);
if (v18 == 0)
{
lean_object* v19; lean_object* v20; lean_object* v21; uint8_t v22; 
v19 = lean_array_get_size(v3);
v20 = lean_array_get_size(v4);
v21 = lean_nat_add(v19, v20);
v22 = lean_nat_dec_lt(v17, v21);
if (v22 == 0)
{
lean_object* v23; lean_object* v24; uint8_t v25; 
v23 = lean_ctor_get(v1, 0);
v24 = lean_ctor_get(v1, 1);
v25 = lean_nat_dec_lt(v23, v2);
if (v25 == 0)
{
uint8_t v26; 
v26 = lean_nat_dec_lt(v24, v21);
if (v26 == 0)
{
lean_object* v27; lean_object* v28; uint8_t v29; 
v27 = lean_array_get_size(v6);
v28 = lean_unsigned_to_nat(0u);
v29 = lean_nat_dec_eq(v27, v28);
if (v29 == 0)
{
uint8_t v30; 
v30 = lean_nat_dec_eq(v27, v21);
lean_dec(v21);
if (v30 == 0)
{
lean_object* v31; lean_object* v32; 
lean_dec(v2);
v31 = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__0));
v32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v32, 0, v31);
lean_ctor_set(v32, 1, v9);
return v32;
}
else
{
goto v33;
}
}
else
{
lean_dec(v21);
goto v33;
}
}
else
{
lean_object* v34; lean_object* v35; 
lean_dec(v21);
lean_dec(v2);
v34 = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__2));
v35 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v35, 0, v34);
lean_ctor_set(v35, 1, v9);
return v35;
}
}
else
{
lean_object* v36; lean_object* v37; 
lean_dec(v21);
lean_dec(v2);
v36 = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__4));
v37 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v37, 0, v36);
lean_ctor_set(v37, 1, v9);
return v37;
}
}
else
{
lean_dec(v21);
lean_dec(v2);
goto v38;
}
}
else
{
lean_dec(v2);
goto v38;
}
v38:
{
lean_object* v39; lean_object* v40; 
v39 = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__0));
v40 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v40, 0, v39);
lean_ctor_set(v40, 1, v9);
return v40;
}
v41:
{
lean_object* v42; lean_object* v43; lean_object* v44; lean_object* v45; uint8_t v46; 
v42 = lean_unsigned_to_nat(4u);
v43 = lean_nat_add(v16, v42);
v44 = lean_nat_mul(v2, v43);
lean_dec(v43);
v45 = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0);
v46 = lean_nat_dec_le(v45, v44);
if (v46 == 0)
{
lean_object* v47; lean_object* v48; 
v47 = lp_Hex_Hex_Groebner_Matrix_packedBytes(v1, v44, v15);
v48 = lean_ctor_get(v47, 0);
lean_inc(v48);
if (lean_obj_tag(v48) == 0)
{
lean_object* v49; lean_object* v50; uint8_t v51; uint8_t v52; 
lean_dec(v44);
lean_dec(v16);
lean_dec(v14);
lean_dec(v13);
lean_dec(v12);
lean_dec(v11);
lean_dec(v2);
v49 = lean_ctor_get(v47, 1);
v52 = !lean_is_exclusive(v47);
if (v52 == 0)
{
lean_object* v53; 
v53 = lean_ctor_get(v47, 0);
lean_dec(v53);
v50 = v47;
v51 = v52;
goto v54;
}
else
{
lean_inc(v49);
lean_dec(v47);
v50 = lean_box(0);
v51 = v52;
goto v54;
}
v54:
{
lean_object* v55; lean_object* v56; uint8_t v57; uint8_t v58; 
v55 = lean_ctor_get(v48, 0);
v58 = !lean_is_exclusive(v48);
if (v58 == 0)
{
v56 = v48;
v57 = v58;
goto v59;
}
else
{
lean_inc(v55);
lean_dec(v48);
v56 = lean_box(0);
v57 = v58;
goto v59;
}
v59:
{
lean_object* v60; 
if (v57 == 0)
{
v60 = v56;
goto v61;
}
else
{
lean_object* v62; 
v62 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v62, 0, v55);
v60 = v62;
goto v61;
}
v61:
{
lean_object* v63; 
if (v51 == 0)
{
lean_ctor_set(v50, 0, v60);
v63 = v50;
goto v64;
}
else
{
lean_object* v65; 
v65 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v65, 0, v60);
lean_ctor_set(v65, 1, v49);
v63 = v65;
goto v64;
}
v64:
{
return v63;
}
}
}
}
}
else
{
lean_object* v66; lean_object* v67; uint8_t v68; uint8_t v69; 
lean_dec_ref_known(v48, 1);
v66 = lean_ctor_get(v47, 1);
v69 = !lean_is_exclusive(v47);
if (v69 == 0)
{
lean_object* v70; 
v70 = lean_ctor_get(v47, 0);
lean_dec(v70);
v67 = v47;
v68 = v69;
goto v71;
}
else
{
lean_inc(v66);
lean_dec(v47);
v67 = lean_box(0);
v68 = v69;
goto v71;
}
v71:
{
lean_object* v72; lean_object* v73; 
v72 = lp_Hex_Hex_Groebner_Matrix_work(v1, v44, v66);
lean_dec(v44);
v73 = lean_ctor_get(v72, 0);
lean_inc(v73);
if (lean_obj_tag(v73) == 0)
{
lean_object* v74; lean_object* v75; uint8_t v76; uint8_t v77; 
lean_del_object(v67);
lean_dec(v16);
lean_dec(v14);
lean_dec(v13);
lean_dec(v12);
lean_dec(v11);
lean_dec(v2);
v74 = lean_ctor_get(v72, 1);
v77 = !lean_is_exclusive(v72);
if (v77 == 0)
{
lean_object* v78; 
v78 = lean_ctor_get(v72, 0);
lean_dec(v78);
v75 = v72;
v76 = v77;
goto v79;
}
else
{
lean_inc(v74);
lean_dec(v72);
v75 = lean_box(0);
v76 = v77;
goto v79;
}
v79:
{
lean_object* v80; lean_object* v81; uint8_t v82; uint8_t v83; 
v80 = lean_ctor_get(v73, 0);
v83 = !lean_is_exclusive(v73);
if (v83 == 0)
{
v81 = v73;
v82 = v83;
goto v84;
}
else
{
lean_inc(v80);
lean_dec(v73);
v81 = lean_box(0);
v82 = v83;
goto v84;
}
v84:
{
lean_object* v85; 
if (v82 == 0)
{
v85 = v81;
goto v86;
}
else
{
lean_object* v87; 
v87 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v87, 0, v80);
v85 = v87;
goto v86;
}
v86:
{
lean_object* v88; 
if (v76 == 0)
{
lean_ctor_set(v75, 0, v85);
v88 = v75;
goto v89;
}
else
{
lean_object* v90; 
v90 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v90, 0, v85);
lean_ctor_set(v90, 1, v74);
v88 = v90;
goto v89;
}
v89:
{
return v88;
}
}
}
}
}
else
{
lean_object* v91; lean_object* v92; uint8_t v93; uint8_t v94; 
lean_dec_ref_known(v73, 1);
v91 = lean_ctor_get(v72, 1);
v94 = !lean_is_exclusive(v72);
if (v94 == 0)
{
lean_object* v95; 
v95 = lean_ctor_get(v72, 0);
lean_dec(v95);
v92 = v72;
v93 = v94;
goto v96;
}
else
{
lean_inc(v91);
lean_dec(v72);
v92 = lean_box(0);
v93 = v94;
goto v96;
}
v96:
{
lean_object* v97; lean_object* v98; lean_object* v99; lean_object* v100; lean_object* v101; uint64_t v102; lean_object* v103; lean_object* v104; lean_object* v105; 
v97 = lean_nat_mul(v2, v16);
v98 = lp_Hex_Hex_Groebner_Matrix_zeros(v97);
v99 = lean_nat_mul(v2, v42);
v100 = lp_Hex_Hex_Groebner_Matrix_zeros(v99);
v101 = lean_mk_empty_array_with_capacity(v14);
v102 = lp_Hex_BarrettCtx_mk___redArg(v0);
v103 = lean_nat_add(v13, v12);
lean_dec(v12);
lean_inc(v11);
lean_inc_n(v14, 2);
v104 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v104, 0, v14);
lean_ctor_set(v104, 1, v103);
lean_ctor_set(v104, 2, v11);
lean_inc_ref(v101);
if (v93 == 0)
{
lean_ctor_set(v92, 1, v14);
lean_ctor_set(v92, 0, v101);
v105 = v92;
goto v106;
}
else
{
lean_object* v107; 
v107 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v107, 0, v101);
lean_ctor_set(v107, 1, v14);
v105 = v107;
goto v106;
}
v106:
{
lean_object* v108; 
lean_inc_ref(v101);
if (v68 == 0)
{
lean_ctor_set(v67, 1, v105);
lean_ctor_set(v67, 0, v101);
v108 = v67;
goto v109;
}
else
{
lean_object* v110; 
v110 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v110, 0, v101);
lean_ctor_set(v110, 1, v105);
v108 = v110;
goto v109;
}
v109:
{
lean_object* v111; lean_object* v112; lean_object* v113; lean_object* v114; lean_object* v115; lean_object* v116; 
lean_inc_ref_n(v101, 2);
v111 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v111, 0, v101);
lean_ctor_set(v111, 1, v108);
v112 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v112, 0, v101);
lean_ctor_set(v112, 1, v111);
v113 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v113, 0, v100);
lean_ctor_set(v113, 1, v112);
v114 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v114, 0, v98);
lean_ctor_set(v114, 1, v113);
lean_inc(v14);
lean_inc(v2);
v115 = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg(v1, v0, v102, v10, v5, v13, v7, v16, v8, v2, v6, v3, v4, v104, v114, v14, v91);
lean_dec_ref_known(v104, 3);
lean_dec(v16);
lean_dec(v13);
v116 = lean_ctor_get(v115, 0);
lean_inc(v116);
if (lean_obj_tag(v116) == 0)
{
lean_object* v117; lean_object* v118; uint8_t v119; uint8_t v120; 
lean_dec_ref(v101);
lean_dec(v14);
lean_dec(v11);
lean_dec(v2);
v117 = lean_ctor_get(v115, 1);
v120 = !lean_is_exclusive(v115);
if (v120 == 0)
{
lean_object* v121; 
v121 = lean_ctor_get(v115, 0);
lean_dec(v121);
v118 = v115;
v119 = v120;
goto v122;
}
else
{
lean_inc(v117);
lean_dec(v115);
v118 = lean_box(0);
v119 = v120;
goto v122;
}
v122:
{
lean_object* v123; lean_object* v124; uint8_t v125; uint8_t v126; 
v123 = lean_ctor_get(v116, 0);
v126 = !lean_is_exclusive(v116);
if (v126 == 0)
{
v124 = v116;
v125 = v126;
goto v127;
}
else
{
lean_inc(v123);
lean_dec(v116);
v124 = lean_box(0);
v125 = v126;
goto v127;
}
v127:
{
lean_object* v128; 
if (v125 == 0)
{
v128 = v124;
goto v129;
}
else
{
lean_object* v130; 
v130 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v130, 0, v123);
v128 = v130;
goto v129;
}
v129:
{
lean_object* v131; 
if (v119 == 0)
{
lean_ctor_set(v118, 0, v128);
v131 = v118;
goto v132;
}
else
{
lean_object* v133; 
v133 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v133, 0, v128);
lean_ctor_set(v133, 1, v117);
v131 = v133;
goto v132;
}
v132:
{
return v131;
}
}
}
}
}
else
{
lean_object* v134; lean_object* v135; uint8_t v136; uint8_t v137; 
v134 = lean_ctor_get(v116, 0);
v137 = !lean_is_exclusive(v116);
if (v137 == 0)
{
v135 = v116;
v136 = v137;
goto v138;
}
else
{
lean_inc(v134);
lean_dec(v116);
v135 = lean_box(0);
v136 = v137;
goto v138;
}
v138:
{
lean_object* v139; lean_object* v140; lean_object* v141; lean_object* v142; lean_object* v143; 
v139 = lean_ctor_get(v134, 1);
lean_inc(v139);
lean_dec(v134);
v140 = lean_ctor_get(v139, 1);
lean_inc(v140);
v141 = lean_ctor_get(v140, 1);
v142 = lean_ctor_get(v141, 1);
lean_inc(v142);
v143 = lean_ctor_get(v142, 1);
lean_inc(v143);
if (v8 == 0)
{
lean_object* v144; lean_object* v145; lean_object* v146; lean_object* v147; lean_object* v148; lean_object* v149; lean_object* v150; lean_object* v151; 
lean_del_object(v135);
v144 = lean_ctor_get(v115, 1);
lean_inc(v144);
lean_dec_ref(v115);
v145 = lean_ctor_get(v139, 0);
lean_inc(v145);
lean_dec(v139);
v146 = lean_ctor_get(v140, 0);
lean_inc(v146);
lean_dec(v140);
v147 = lean_ctor_get(v142, 0);
lean_inc(v147);
lean_dec(v142);
v148 = lean_ctor_get(v143, 0);
lean_inc(v148);
v149 = lean_ctor_get(v143, 1);
lean_inc(v149);
lean_dec(v143);
v150 = lp_Hex_Hex_Groebner_Matrix_work(v1, v2, v144);
v151 = lean_ctor_get(v150, 0);
lean_inc(v151);
if (lean_obj_tag(v151) == 0)
{
lean_object* v152; lean_object* v153; uint8_t v154; uint8_t v155; 
lean_dec(v149);
lean_dec(v148);
lean_dec(v147);
lean_dec(v146);
lean_dec(v145);
lean_dec_ref(v101);
lean_dec(v14);
lean_dec(v11);
lean_dec(v2);
v152 = lean_ctor_get(v150, 1);
v155 = !lean_is_exclusive(v150);
if (v155 == 0)
{
lean_object* v156; 
v156 = lean_ctor_get(v150, 0);
lean_dec(v156);
v153 = v150;
v154 = v155;
goto v157;
}
else
{
lean_inc(v152);
lean_dec(v150);
v153 = lean_box(0);
v154 = v155;
goto v157;
}
v157:
{
lean_object* v158; lean_object* v159; uint8_t v160; uint8_t v161; 
v158 = lean_ctor_get(v151, 0);
v161 = !lean_is_exclusive(v151);
if (v161 == 0)
{
v159 = v151;
v160 = v161;
goto v162;
}
else
{
lean_inc(v158);
lean_dec(v151);
v159 = lean_box(0);
v160 = v161;
goto v162;
}
v162:
{
lean_object* v163; 
if (v160 == 0)
{
v163 = v159;
goto v164;
}
else
{
lean_object* v165; 
v165 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v165, 0, v158);
v163 = v165;
goto v164;
}
v164:
{
lean_object* v166; 
if (v154 == 0)
{
lean_ctor_set(v153, 0, v163);
v166 = v153;
goto v167;
}
else
{
lean_object* v168; 
v168 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v168, 0, v163);
lean_ctor_set(v168, 1, v152);
v166 = v168;
goto v167;
}
v167:
{
return v166;
}
}
}
}
}
else
{
lean_object* v169; lean_object* v170; uint8_t v171; uint8_t v172; 
lean_dec_ref_known(v151, 1);
v169 = lean_ctor_get(v150, 1);
v172 = !lean_is_exclusive(v150);
if (v172 == 0)
{
lean_object* v173; 
v173 = lean_ctor_get(v150, 0);
lean_dec(v173);
v170 = v150;
v171 = v172;
goto v174;
}
else
{
lean_inc(v169);
lean_dec(v150);
v170 = lean_box(0);
v171 = v172;
goto v174;
}
v174:
{
lean_object* v175; lean_object* v176; lean_object* v177; lean_object* v178; lean_object* v179; uint8_t v180; uint8_t v181; 
lean_inc(v14);
v175 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v175, 0, v14);
lean_ctor_set(v175, 1, v2);
lean_ctor_set(v175, 2, v11);
v176 = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___redArg(v146, v145, v175, v101, v14, v169);
lean_dec_ref_known(v175, 3);
lean_dec(v145);
lean_dec(v146);
v177 = lean_ctor_get(v176, 0);
v178 = lean_ctor_get(v176, 1);
v181 = !lean_is_exclusive(v176);
if (v181 == 0)
{
v179 = v176;
v180 = v181;
goto v182;
}
else
{
lean_inc(v178);
lean_inc(v177);
lean_dec(v176);
v179 = lean_box(0);
v180 = v181;
goto v182;
}
v182:
{
lean_object* v183; lean_object* v184; uint8_t v185; uint8_t v186; 
v183 = lean_ctor_get(v177, 0);
v186 = !lean_is_exclusive(v177);
if (v186 == 0)
{
v184 = v177;
v185 = v186;
goto v187;
}
else
{
lean_inc(v183);
lean_dec(v177);
v184 = lean_box(0);
v185 = v186;
goto v187;
}
v187:
{
lean_object* v188; lean_object* v189; 
v188 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v188, 0, v183);
lean_ctor_set(v188, 1, v149);
lean_ctor_set(v188, 2, v147);
if (v180 == 0)
{
lean_ctor_set(v179, 1, v148);
lean_ctor_set(v179, 0, v188);
v189 = v179;
goto v190;
}
else
{
lean_object* v191; 
v191 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v191, 0, v188);
lean_ctor_set(v191, 1, v148);
v189 = v191;
goto v190;
}
v190:
{
lean_object* v192; 
if (v185 == 0)
{
lean_ctor_set(v184, 0, v189);
v192 = v184;
goto v193;
}
else
{
lean_object* v194; 
v194 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v194, 0, v189);
v192 = v194;
goto v193;
}
v193:
{
lean_object* v195; 
if (v171 == 0)
{
lean_ctor_set(v170, 1, v178);
lean_ctor_set(v170, 0, v192);
v195 = v170;
goto v196;
}
else
{
lean_object* v197; 
v197 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v197, 0, v192);
lean_ctor_set(v197, 1, v178);
v195 = v197;
goto v196;
}
v196:
{
return v195;
}
}
}
}
}
}
}
}
else
{
lean_object* v198; lean_object* v199; lean_object* v200; uint8_t v201; uint8_t v202; 
lean_dec(v140);
lean_dec(v139);
lean_dec(v14);
lean_dec(v11);
lean_dec(v2);
v198 = lean_ctor_get(v115, 1);
lean_inc(v198);
lean_dec_ref(v115);
v199 = lean_ctor_get(v142, 0);
v202 = !lean_is_exclusive(v142);
if (v202 == 0)
{
lean_object* v203; 
v203 = lean_ctor_get(v142, 1);
lean_dec(v203);
v200 = v142;
v201 = v202;
goto v204;
}
else
{
lean_inc(v199);
lean_dec(v142);
v200 = lean_box(0);
v201 = v202;
goto v204;
}
v204:
{
lean_object* v205; lean_object* v206; lean_object* v207; uint8_t v208; uint8_t v209; 
v205 = lean_ctor_get(v143, 0);
v206 = lean_ctor_get(v143, 1);
v209 = !lean_is_exclusive(v143);
if (v209 == 0)
{
v207 = v143;
v208 = v209;
goto v210;
}
else
{
lean_inc(v206);
lean_inc(v205);
lean_dec(v143);
v207 = lean_box(0);
v208 = v209;
goto v210;
}
v210:
{
lean_object* v211; lean_object* v212; 
v211 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v211, 0, v101);
lean_ctor_set(v211, 1, v206);
lean_ctor_set(v211, 2, v199);
if (v208 == 0)
{
lean_ctor_set(v207, 1, v205);
lean_ctor_set(v207, 0, v211);
v212 = v207;
goto v213;
}
else
{
lean_object* v214; 
v214 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v214, 0, v211);
lean_ctor_set(v214, 1, v205);
v212 = v214;
goto v213;
}
v213:
{
lean_object* v215; 
if (v136 == 0)
{
lean_ctor_set(v135, 0, v212);
v215 = v135;
goto v216;
}
else
{
lean_object* v217; 
v217 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v217, 0, v212);
v215 = v217;
goto v216;
}
v216:
{
lean_object* v218; 
if (v201 == 0)
{
lean_ctor_set(v200, 1, v198);
lean_ctor_set(v200, 0, v215);
v218 = v200;
goto v219;
}
else
{
lean_object* v220; 
v220 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v220, 0, v215);
lean_ctor_set(v220, 1, v198);
v218 = v220;
goto v219;
}
v219:
{
return v218;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v221; lean_object* v222; 
lean_dec(v44);
lean_dec(v16);
lean_dec(v14);
lean_dec(v13);
lean_dec(v12);
lean_dec(v11);
lean_dec(v2);
v221 = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__0));
v222 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v222, 0, v221);
lean_ctor_set(v222, 1, v15);
return v222;
}
}
v33:
{
lean_object* v223; lean_object* v224; lean_object* v225; lean_object* v226; lean_object* v227; lean_object* v228; lean_object* v229; 
v223 = lean_unsigned_to_nat(0u);
v224 = lean_array_get_size(v3);
v225 = lean_unsigned_to_nat(1u);
v226 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v226, 0, v223);
lean_ctor_set(v226, 1, v224);
lean_ctor_set(v226, 2, v225);
v227 = lean_box(0);
v228 = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___redArg(v3, v0, v1, v2, v226, v227, v223, v9);
lean_dec_ref_known(v226, 3);
v229 = lean_ctor_get(v228, 0);
lean_inc(v229);
if (lean_obj_tag(v229) == 0)
{
lean_object* v230; lean_object* v231; uint8_t v232; uint8_t v233; 
lean_dec(v2);
v230 = lean_ctor_get(v228, 1);
v233 = !lean_is_exclusive(v228);
if (v233 == 0)
{
lean_object* v234; 
v234 = lean_ctor_get(v228, 0);
lean_dec(v234);
v231 = v228;
v232 = v233;
goto v235;
}
else
{
lean_inc(v230);
lean_dec(v228);
v231 = lean_box(0);
v232 = v233;
goto v235;
}
v235:
{
lean_object* v236; lean_object* v237; uint8_t v238; uint8_t v239; 
v236 = lean_ctor_get(v229, 0);
v239 = !lean_is_exclusive(v229);
if (v239 == 0)
{
v237 = v229;
v238 = v239;
goto v240;
}
else
{
lean_inc(v236);
lean_dec(v229);
v237 = lean_box(0);
v238 = v239;
goto v240;
}
v240:
{
lean_object* v241; 
if (v238 == 0)
{
v241 = v237;
goto v242;
}
else
{
lean_object* v243; 
v243 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v243, 0, v236);
v241 = v243;
goto v242;
}
v242:
{
lean_object* v244; 
if (v232 == 0)
{
lean_ctor_set(v231, 0, v241);
v244 = v231;
goto v245;
}
else
{
lean_object* v246; 
v246 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v246, 0, v241);
lean_ctor_set(v246, 1, v230);
v244 = v246;
goto v245;
}
v245:
{
return v244;
}
}
}
}
}
else
{
lean_object* v247; lean_object* v248; lean_object* v249; lean_object* v250; lean_object* v251; 
lean_dec_ref_known(v229, 1);
v247 = lean_ctor_get(v228, 1);
lean_inc(v247);
lean_dec_ref(v228);
v248 = lean_array_get_size(v4);
v249 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v249, 0, v223);
lean_ctor_set(v249, 1, v248);
lean_ctor_set(v249, 2, v225);
v250 = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___redArg(v224, v4, v0, v1, v2, v249, v227, v223, v247);
lean_dec_ref_known(v249, 3);
v251 = lean_ctor_get(v250, 0);
lean_inc(v251);
if (lean_obj_tag(v251) == 0)
{
lean_object* v252; lean_object* v253; uint8_t v254; uint8_t v255; 
lean_dec(v2);
v252 = lean_ctor_get(v250, 1);
v255 = !lean_is_exclusive(v250);
if (v255 == 0)
{
lean_object* v256; 
v256 = lean_ctor_get(v250, 0);
lean_dec(v256);
v253 = v250;
v254 = v255;
goto v257;
}
else
{
lean_inc(v252);
lean_dec(v250);
v253 = lean_box(0);
v254 = v255;
goto v257;
}
v257:
{
lean_object* v258; lean_object* v259; uint8_t v260; uint8_t v261; 
v258 = lean_ctor_get(v251, 0);
v261 = !lean_is_exclusive(v251);
if (v261 == 0)
{
v259 = v251;
v260 = v261;
goto v262;
}
else
{
lean_inc(v258);
lean_dec(v251);
v259 = lean_box(0);
v260 = v261;
goto v262;
}
v262:
{
lean_object* v263; 
if (v260 == 0)
{
v263 = v259;
goto v264;
}
else
{
lean_object* v265; 
v265 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v265, 0, v258);
v263 = v265;
goto v264;
}
v264:
{
lean_object* v266; 
if (v254 == 0)
{
lean_ctor_set(v253, 0, v263);
v266 = v253;
goto v267;
}
else
{
lean_object* v268; 
v268 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v268, 0, v263);
lean_ctor_set(v268, 1, v252);
v266 = v268;
goto v267;
}
v267:
{
return v266;
}
}
}
}
}
else
{
lean_object* v269; uint8_t v270; 
lean_dec_ref_known(v251, 1);
v269 = lean_ctor_get(v250, 1);
lean_inc(v269);
lean_dec_ref(v250);
v270 = lp_Hex_Hex_Groebner_PrimeField_width(v0);
switch(v270)
{
case 0:
{
v10 = v270;
v11 = v225;
v12 = v248;
v13 = v224;
v14 = v223;
v15 = v269;
v16 = v225;
goto v41;
}
case 1:
{
lean_object* v271; 
v271 = lean_unsigned_to_nat(2u);
v10 = v270;
v11 = v225;
v12 = v248;
v13 = v224;
v14 = v223;
v15 = v269;
v16 = v271;
goto v41;
}
default: 
{
lean_object* v272; 
v272 = lean_unsigned_to_nat(4u);
v10 = v270;
v11 = v225;
v12 = v248;
v13 = v224;
v14 = v223;
v15 = v269;
v16 = v272;
goto v41;
}
}
}
}
}
}
}