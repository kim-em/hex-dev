// Lean compiler output
// Module: HexGroebner.Elimination
// Imports: public import Init public meta import Init public import HexGroebner.Matrix public import HexGroebner.Native public import HexGroebner.NativeScan public import HexGroebner.NativeGather
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_hex_scan_transition(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* lp_Hex_Hex_Groebner_Matrix_work(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
extern lean_object* lp_Hex_Hex_Groebner_instInhabitedPivot_default;
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
uint64_t lean_uint64_sub(uint64_t, uint64_t);
lean_object* lp_Hex_Hex_Groebner_Matrix_charge(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Matrix_packedBytes(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
uint8_t lean_uint8_dec_eq(uint8_t, uint8_t);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* lean_nat_shiftr(lean_object*, lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* lean_byte_array_size(lean_object*);
lean_object* lp_Hex_Hex_Groebner_SparseRow_size(lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lean_hex_gather(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint64_t);
extern lean_object* l_System_Platform_numBits;
lean_object* lean_nat_pow(lean_object*, lean_object*);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* lean_array_get(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_set(lean_object*, lean_object*, lean_object*);
uint64_t lean_uint8_to_uint64(uint8_t);
uint64_t lean_uint64_shift_left(uint64_t, uint64_t);
uint64_t lean_uint64_lor(uint64_t, uint64_t);
uint8_t lean_byte_array_uget(lean_object*, size_t);
lean_object* l_outOfBounds___redArg(lean_object*);
uint8_t lean_byte_array_fget(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Matrix_zeros(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
uint64_t lp_Hex_BarrettCtx_mk___redArg(uint64_t);
uint64_t lean_uint64_of_nat(lean_object*);
uint8_t lean_uint64_to_uint8(uint64_t);
lean_object* lean_byte_array_set(lean_object*, lean_object*, uint8_t);
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
lean_object* lp_Hex_Hex_Groebner_Matrix_inverse(uint64_t, uint64_t, lean_object*, uint64_t, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Matrix_scaleSparse(uint64_t, uint64_t, lean_object*, lean_object*, uint64_t, lean_object*);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
size_t lean_usize_of_nat(lean_object*);
lean_object* lean_usize_to_nat(size_t);
extern lean_object* lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
extern lean_object* l_ByteArray_empty;
lean_object* lean_byte_array_push(lean_object*, uint8_t);
uint64_t lp_Hex_BarrettCtx_mulMod(uint64_t, uint64_t, uint64_t, uint64_t);
uint64_t lean_uint64_add(uint64_t, uint64_t);
uint8_t lean_uint64_dec_le(uint64_t, uint64_t);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_Groebner_Matrix_validate(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lp_Hex_Hex_Groebner_PrimeField_width(uint64_t);
lean_object* lean_mk_array(lean_object*, lean_object*);
uint8_t lean_usize_dec_eq(size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___lam__1(lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___closed__0 = (const lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___closed__0_value;
static const lean_closure_object lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___lam__1, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___closed__1 = (const lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___closed__1_value;
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_takeDense(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__0(lean_object*, uint64_t, lean_object*, uint8_t, lean_object*, size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 5}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(6, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__0_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__1 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__1_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 5}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(5, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__2 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__2_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg(lean_object*, uint64_t, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1___redArg(lean_object*, uint64_t, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan___closed__0 = (const lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1(lean_object*, uint64_t, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1(lean_object*, uint64_t, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___lam__0___boxed(lean_object*);
static const lean_closure_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__0_value;
static const lean_closure_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___lam__1, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__1 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__1_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 5}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(4, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__2 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__2_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 5}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(3, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__3 = (const lean_object*)&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__3_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg(uint64_t, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather___closed__0 = (const lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0(uint64_t, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___redArg(lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___redArg(lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg(uint8_t, lean_object*, lean_object*, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg(uint64_t, uint64_t, uint64_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5___redArg(lean_object*, lean_object*, uint64_t, uint64_t, uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___redArg(lean_object*, uint64_t, uint64_t, uint8_t, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg(lean_object*, lean_object*, uint8_t, uint64_t, uint64_t, uint8_t, uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg(lean_object*, uint64_t, uint64_t, uint8_t, uint8_t, lean_object*, uint8_t, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___boxed(lean_object**);
static const lean_ctor_object lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__0 = (const lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__0_value;
static const lean_ctor_object lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 5}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(1, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__1 = (const lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__1_value;
static const lean_ctor_object lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__1_value)}};
static const lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__2 = (const lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__2_value;
static const lean_ctor_object lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 5}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
static const lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__3 = (const lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__3_value;
static const lean_ctor_object lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__3_value)}};
static const lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__4 = (const lean_object*)&lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__4_value;
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, uint8_t, uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0(lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1(lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2(uint64_t, uint64_t, uint64_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4(uint8_t, lean_object*, lean_object*, uint64_t, uint64_t, uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5(lean_object*, uint64_t, uint64_t, uint8_t, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6(lean_object*, uint64_t, uint64_t, uint8_t, uint8_t, lean_object*, uint8_t, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___boxed(lean_object**);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5(lean_object*, lean_object*, uint64_t, uint64_t, uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7(lean_object*, lean_object*, uint8_t, uint64_t, uint64_t, uint8_t, uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___boxed(lean_object**);
static const lean_ctor_object lp_Hex_Hex_Groebner_Elimination_reference___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*8 + 0, .m_other = 8, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_Groebner_Elimination_reference___closed__0 = (const lean_object*)&lp_Hex_Hex_Groebner_Elimination_reference___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_reference(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_reference___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___lam__0___boxed(lean_object*, lean_object*);
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__0;
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3___closed__0;
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3(uint8_t, lean_object*, size_t, size_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__0(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1___redArg(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Elimination_fits(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_fits___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_attemptPortable(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_attemptPortable___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_hex_groebner_eliminate_matrix(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_attempt___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_run(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_run___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_eliminateWith(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_eliminateWith___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_reduceRowsWith(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, uint8_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_reduceRowsWith___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___lam__0(lean_object* v_x_1_){
_start:
{
lean_object* v_traceNodes_2_; 
v_traceNodes_2_ = lean_ctor_get(v_x_1_, 4);
lean_inc(v_traceNodes_2_);
return v_traceNodes_2_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___lam__0___boxed(lean_object* v_x_3_){
_start:
{
lean_object* v_res_4_; 
v_res_4_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___lam__0(v_x_3_);
lean_dec_ref(v_x_3_);
return v_res_4_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___lam__1(lean_object* v_s_5_, lean_object* v_n_6_){
_start:
{
lean_object* v_work_7_; lean_object* v_inputEntries_8_; lean_object* v_outputEntries_9_; lean_object* v_packedBytes_10_; lean_object* v_processedRows_11_; lean_object* v_reductions_12_; lean_object* v_zeroRows_13_; lean_object* v___x_15_; uint8_t v_isShared_16_; uint8_t v_isSharedCheck_20_; 
v_work_7_ = lean_ctor_get(v_s_5_, 0);
v_inputEntries_8_ = lean_ctor_get(v_s_5_, 1);
v_outputEntries_9_ = lean_ctor_get(v_s_5_, 2);
v_packedBytes_10_ = lean_ctor_get(v_s_5_, 3);
v_processedRows_11_ = lean_ctor_get(v_s_5_, 5);
v_reductions_12_ = lean_ctor_get(v_s_5_, 6);
v_zeroRows_13_ = lean_ctor_get(v_s_5_, 7);
v_isSharedCheck_20_ = !lean_is_exclusive(v_s_5_);
if (v_isSharedCheck_20_ == 0)
{
lean_object* v_unused_21_; 
v_unused_21_ = lean_ctor_get(v_s_5_, 4);
lean_dec(v_unused_21_);
v___x_15_ = v_s_5_;
v_isShared_16_ = v_isSharedCheck_20_;
goto v_resetjp_14_;
}
else
{
lean_inc(v_zeroRows_13_);
lean_inc(v_reductions_12_);
lean_inc(v_processedRows_11_);
lean_inc(v_packedBytes_10_);
lean_inc(v_outputEntries_9_);
lean_inc(v_inputEntries_8_);
lean_inc(v_work_7_);
lean_dec(v_s_5_);
v___x_15_ = lean_box(0);
v_isShared_16_ = v_isSharedCheck_20_;
goto v_resetjp_14_;
}
v_resetjp_14_:
{
lean_object* v___x_18_; 
if (v_isShared_16_ == 0)
{
lean_ctor_set(v___x_15_, 4, v_n_6_);
v___x_18_ = v___x_15_;
goto v_reusejp_17_;
}
else
{
lean_object* v_reuseFailAlloc_19_; 
v_reuseFailAlloc_19_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_19_, 0, v_work_7_);
lean_ctor_set(v_reuseFailAlloc_19_, 1, v_inputEntries_8_);
lean_ctor_set(v_reuseFailAlloc_19_, 2, v_outputEntries_9_);
lean_ctor_set(v_reuseFailAlloc_19_, 3, v_packedBytes_10_);
lean_ctor_set(v_reuseFailAlloc_19_, 4, v_n_6_);
lean_ctor_set(v_reuseFailAlloc_19_, 5, v_processedRows_11_);
lean_ctor_set(v_reuseFailAlloc_19_, 6, v_reductions_12_);
lean_ctor_set(v_reuseFailAlloc_19_, 7, v_zeroRows_13_);
v___x_18_ = v_reuseFailAlloc_19_;
goto v_reusejp_17_;
}
v_reusejp_17_:
{
return v___x_18_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(lean_object* v_limits_24_, uint8_t v_enabled_25_, lean_object* v_trace_26_, lean_object* v_op_27_, lean_object* v_a_28_){
_start:
{
if (v_enabled_25_ == 0)
{
lean_object* v___x_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; 
lean_dec_ref(v_op_27_);
v___x_29_ = lean_box(0);
v___x_30_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_30_, 0, v_trace_26_);
lean_ctor_set(v___x_30_, 1, v___x_29_);
v___x_31_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_31_, 0, v___x_30_);
v___x_32_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_32_, 0, v___x_31_);
lean_ctor_set(v___x_32_, 1, v_a_28_);
return v___x_32_;
}
else
{
lean_object* v_traceNodes_33_; lean_object* v___f_34_; lean_object* v___f_35_; uint8_t v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v_fst_39_; 
v_traceNodes_33_ = lean_ctor_get(v_limits_24_, 6);
v___f_34_ = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___closed__0));
v___f_35_ = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___closed__1));
v___x_36_ = 6;
v___x_37_ = lean_unsigned_to_nat(1u);
v___x_38_ = lp_Hex_Hex_Groebner_Matrix_charge(v___x_36_, v___x_37_, v_traceNodes_33_, v___f_34_, v___f_35_, v_a_28_);
v_fst_39_ = lean_ctor_get(v___x_38_, 0);
lean_inc(v_fst_39_);
if (lean_obj_tag(v_fst_39_) == 0)
{
lean_object* v_snd_40_; lean_object* v___x_42_; uint8_t v_isShared_43_; uint8_t v_isSharedCheck_55_; 
lean_dec_ref(v_op_27_);
lean_dec_ref(v_trace_26_);
v_snd_40_ = lean_ctor_get(v___x_38_, 1);
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_38_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_38_, 0);
lean_dec(v_unused_56_);
v___x_42_ = v___x_38_;
v_isShared_43_ = v_isSharedCheck_55_;
goto v_resetjp_41_;
}
else
{
lean_inc(v_snd_40_);
lean_dec(v___x_38_);
v___x_42_ = lean_box(0);
v_isShared_43_ = v_isSharedCheck_55_;
goto v_resetjp_41_;
}
v_resetjp_41_:
{
lean_object* v_a_44_; lean_object* v___x_46_; uint8_t v_isShared_47_; uint8_t v_isSharedCheck_54_; 
v_a_44_ = lean_ctor_get(v_fst_39_, 0);
v_isSharedCheck_54_ = !lean_is_exclusive(v_fst_39_);
if (v_isSharedCheck_54_ == 0)
{
v___x_46_ = v_fst_39_;
v_isShared_47_ = v_isSharedCheck_54_;
goto v_resetjp_45_;
}
else
{
lean_inc(v_a_44_);
lean_dec(v_fst_39_);
v___x_46_ = lean_box(0);
v_isShared_47_ = v_isSharedCheck_54_;
goto v_resetjp_45_;
}
v_resetjp_45_:
{
lean_object* v___x_49_; 
if (v_isShared_47_ == 0)
{
v___x_49_ = v___x_46_;
goto v_reusejp_48_;
}
else
{
lean_object* v_reuseFailAlloc_53_; 
v_reuseFailAlloc_53_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_53_, 0, v_a_44_);
v___x_49_ = v_reuseFailAlloc_53_;
goto v_reusejp_48_;
}
v_reusejp_48_:
{
lean_object* v___x_51_; 
if (v_isShared_43_ == 0)
{
lean_ctor_set(v___x_42_, 0, v___x_49_);
v___x_51_ = v___x_42_;
goto v_reusejp_50_;
}
else
{
lean_object* v_reuseFailAlloc_52_; 
v_reuseFailAlloc_52_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_52_, 0, v___x_49_);
lean_ctor_set(v_reuseFailAlloc_52_, 1, v_snd_40_);
v___x_51_ = v_reuseFailAlloc_52_;
goto v_reusejp_50_;
}
v_reusejp_50_:
{
return v___x_51_;
}
}
}
}
}
else
{
lean_object* v_snd_57_; lean_object* v___x_59_; uint8_t v_isShared_60_; uint8_t v_isSharedCheck_104_; 
lean_dec_ref_known(v_fst_39_, 1);
v_snd_57_ = lean_ctor_get(v___x_38_, 1);
v_isSharedCheck_104_ = !lean_is_exclusive(v___x_38_);
if (v_isSharedCheck_104_ == 0)
{
lean_object* v_unused_105_; 
v_unused_105_ = lean_ctor_get(v___x_38_, 0);
lean_dec(v_unused_105_);
v___x_59_ = v___x_38_;
v_isShared_60_ = v_isSharedCheck_104_;
goto v_resetjp_58_;
}
else
{
lean_inc(v_snd_57_);
lean_dec(v___x_38_);
v___x_59_ = lean_box(0);
v_isShared_60_ = v_isSharedCheck_104_;
goto v_resetjp_58_;
}
v_resetjp_58_:
{
lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v_fst_63_; 
v___x_61_ = lean_unsigned_to_nat(64u);
v___x_62_ = lp_Hex_Hex_Groebner_Matrix_packedBytes(v_limits_24_, v___x_61_, v_snd_57_);
v_fst_63_ = lean_ctor_get(v___x_62_, 0);
lean_inc(v_fst_63_);
if (lean_obj_tag(v_fst_63_) == 0)
{
lean_object* v_snd_64_; lean_object* v___x_66_; uint8_t v_isShared_67_; uint8_t v_isSharedCheck_79_; 
lean_del_object(v___x_59_);
lean_dec_ref(v_op_27_);
lean_dec_ref(v_trace_26_);
v_snd_64_ = lean_ctor_get(v___x_62_, 1);
v_isSharedCheck_79_ = !lean_is_exclusive(v___x_62_);
if (v_isSharedCheck_79_ == 0)
{
lean_object* v_unused_80_; 
v_unused_80_ = lean_ctor_get(v___x_62_, 0);
lean_dec(v_unused_80_);
v___x_66_ = v___x_62_;
v_isShared_67_ = v_isSharedCheck_79_;
goto v_resetjp_65_;
}
else
{
lean_inc(v_snd_64_);
lean_dec(v___x_62_);
v___x_66_ = lean_box(0);
v_isShared_67_ = v_isSharedCheck_79_;
goto v_resetjp_65_;
}
v_resetjp_65_:
{
lean_object* v_a_68_; lean_object* v___x_70_; uint8_t v_isShared_71_; uint8_t v_isSharedCheck_78_; 
v_a_68_ = lean_ctor_get(v_fst_63_, 0);
v_isSharedCheck_78_ = !lean_is_exclusive(v_fst_63_);
if (v_isSharedCheck_78_ == 0)
{
v___x_70_ = v_fst_63_;
v_isShared_71_ = v_isSharedCheck_78_;
goto v_resetjp_69_;
}
else
{
lean_inc(v_a_68_);
lean_dec(v_fst_63_);
v___x_70_ = lean_box(0);
v_isShared_71_ = v_isSharedCheck_78_;
goto v_resetjp_69_;
}
v_resetjp_69_:
{
lean_object* v___x_73_; 
if (v_isShared_71_ == 0)
{
v___x_73_ = v___x_70_;
goto v_reusejp_72_;
}
else
{
lean_object* v_reuseFailAlloc_77_; 
v_reuseFailAlloc_77_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_77_, 0, v_a_68_);
v___x_73_ = v_reuseFailAlloc_77_;
goto v_reusejp_72_;
}
v_reusejp_72_:
{
lean_object* v___x_75_; 
if (v_isShared_67_ == 0)
{
lean_ctor_set(v___x_66_, 0, v___x_73_);
v___x_75_ = v___x_66_;
goto v_reusejp_74_;
}
else
{
lean_object* v_reuseFailAlloc_76_; 
v_reuseFailAlloc_76_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_76_, 0, v___x_73_);
lean_ctor_set(v_reuseFailAlloc_76_, 1, v_snd_64_);
v___x_75_ = v_reuseFailAlloc_76_;
goto v_reusejp_74_;
}
v_reusejp_74_:
{
return v___x_75_;
}
}
}
}
}
else
{
lean_object* v_snd_81_; lean_object* v___x_83_; uint8_t v_isShared_84_; uint8_t v_isSharedCheck_102_; 
v_snd_81_ = lean_ctor_get(v___x_62_, 1);
v_isSharedCheck_102_ = !lean_is_exclusive(v___x_62_);
if (v_isSharedCheck_102_ == 0)
{
lean_object* v_unused_103_; 
v_unused_103_ = lean_ctor_get(v___x_62_, 0);
lean_dec(v_unused_103_);
v___x_83_ = v___x_62_;
v_isShared_84_ = v_isSharedCheck_102_;
goto v_resetjp_82_;
}
else
{
lean_inc(v_snd_81_);
lean_dec(v___x_62_);
v___x_83_ = lean_box(0);
v_isShared_84_ = v_isSharedCheck_102_;
goto v_resetjp_82_;
}
v_resetjp_82_:
{
lean_object* v___x_86_; uint8_t v_isShared_87_; uint8_t v_isSharedCheck_100_; 
v_isSharedCheck_100_ = !lean_is_exclusive(v_fst_63_);
if (v_isSharedCheck_100_ == 0)
{
lean_object* v_unused_101_; 
v_unused_101_ = lean_ctor_get(v_fst_63_, 0);
lean_dec(v_unused_101_);
v___x_86_ = v_fst_63_;
v_isShared_87_ = v_isSharedCheck_100_;
goto v_resetjp_85_;
}
else
{
lean_dec(v_fst_63_);
v___x_86_ = lean_box(0);
v_isShared_87_ = v_isSharedCheck_100_;
goto v_resetjp_85_;
}
v_resetjp_85_:
{
lean_object* v_index_88_; lean_object* v___x_89_; lean_object* v___x_90_; lean_object* v___x_92_; 
v_index_88_ = lean_array_get_size(v_trace_26_);
v___x_89_ = lean_array_push(v_trace_26_, v_op_27_);
v___x_90_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_90_, 0, v_index_88_);
if (v_isShared_84_ == 0)
{
lean_ctor_set(v___x_83_, 1, v___x_90_);
lean_ctor_set(v___x_83_, 0, v___x_89_);
v___x_92_ = v___x_83_;
goto v_reusejp_91_;
}
else
{
lean_object* v_reuseFailAlloc_99_; 
v_reuseFailAlloc_99_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_99_, 0, v___x_89_);
lean_ctor_set(v_reuseFailAlloc_99_, 1, v___x_90_);
v___x_92_ = v_reuseFailAlloc_99_;
goto v_reusejp_91_;
}
v_reusejp_91_:
{
lean_object* v___x_94_; 
if (v_isShared_87_ == 0)
{
lean_ctor_set(v___x_86_, 0, v___x_92_);
v___x_94_ = v___x_86_;
goto v_reusejp_93_;
}
else
{
lean_object* v_reuseFailAlloc_98_; 
v_reuseFailAlloc_98_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_98_, 0, v___x_92_);
v___x_94_ = v_reuseFailAlloc_98_;
goto v_reusejp_93_;
}
v_reusejp_93_:
{
lean_object* v___x_96_; 
if (v_isShared_60_ == 0)
{
lean_ctor_set(v___x_59_, 1, v_snd_81_);
lean_ctor_set(v___x_59_, 0, v___x_94_);
v___x_96_ = v___x_59_;
goto v_reusejp_95_;
}
else
{
lean_object* v_reuseFailAlloc_97_; 
v_reuseFailAlloc_97_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_97_, 0, v___x_94_);
lean_ctor_set(v_reuseFailAlloc_97_, 1, v_snd_81_);
v___x_96_ = v_reuseFailAlloc_97_;
goto v_reusejp_95_;
}
v_reusejp_95_:
{
return v___x_96_;
}
}
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record___boxed(lean_object* v_limits_106_, lean_object* v_enabled_107_, lean_object* v_trace_108_, lean_object* v_op_109_, lean_object* v_a_110_){
_start:
{
uint8_t v_enabled_boxed_111_; lean_object* v_res_112_; 
v_enabled_boxed_111_ = lean_unbox(v_enabled_107_);
v_res_112_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_106_, v_enabled_boxed_111_, v_trace_108_, v_op_109_, v_a_110_);
lean_dec_ref(v_limits_106_);
return v_res_112_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_takeDense(lean_object* v_scan_113_){
_start:
{
lean_object* v_dense_114_; lean_object* v_last_115_; lean_object* v_chargedUntil_116_; lean_object* v_leading_117_; lean_object* v_trace_118_; lean_object* v_node_119_; lean_object* v_sugar_120_; lean_object* v___x_122_; uint8_t v_isShared_123_; uint8_t v_isSharedCheck_129_; 
v_dense_114_ = lean_ctor_get(v_scan_113_, 0);
v_last_115_ = lean_ctor_get(v_scan_113_, 1);
v_chargedUntil_116_ = lean_ctor_get(v_scan_113_, 2);
v_leading_117_ = lean_ctor_get(v_scan_113_, 3);
v_trace_118_ = lean_ctor_get(v_scan_113_, 4);
v_node_119_ = lean_ctor_get(v_scan_113_, 5);
v_sugar_120_ = lean_ctor_get(v_scan_113_, 6);
v_isSharedCheck_129_ = !lean_is_exclusive(v_scan_113_);
if (v_isSharedCheck_129_ == 0)
{
v___x_122_ = v_scan_113_;
v_isShared_123_ = v_isSharedCheck_129_;
goto v_resetjp_121_;
}
else
{
lean_inc(v_sugar_120_);
lean_inc(v_node_119_);
lean_inc(v_trace_118_);
lean_inc(v_leading_117_);
lean_inc(v_chargedUntil_116_);
lean_inc(v_last_115_);
lean_inc(v_dense_114_);
lean_dec(v_scan_113_);
v___x_122_ = lean_box(0);
v_isShared_123_ = v_isSharedCheck_129_;
goto v_resetjp_121_;
}
v_resetjp_121_:
{
lean_object* v___x_124_; lean_object* v___x_126_; 
v___x_124_ = l_ByteArray_empty;
if (v_isShared_123_ == 0)
{
lean_ctor_set(v___x_122_, 0, v___x_124_);
v___x_126_ = v___x_122_;
goto v_reusejp_125_;
}
else
{
lean_object* v_reuseFailAlloc_128_; 
v_reuseFailAlloc_128_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_128_, 0, v___x_124_);
lean_ctor_set(v_reuseFailAlloc_128_, 1, v_last_115_);
lean_ctor_set(v_reuseFailAlloc_128_, 2, v_chargedUntil_116_);
lean_ctor_set(v_reuseFailAlloc_128_, 3, v_leading_117_);
lean_ctor_set(v_reuseFailAlloc_128_, 4, v_trace_118_);
lean_ctor_set(v_reuseFailAlloc_128_, 5, v_node_119_);
lean_ctor_set(v_reuseFailAlloc_128_, 6, v_sugar_120_);
v___x_126_ = v_reuseFailAlloc_128_;
goto v_reusejp_125_;
}
v_reusejp_125_:
{
lean_object* v___x_127_; 
v___x_127_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_127_, 0, v_dense_114_);
lean_ctor_set(v___x_127_, 1, v___x_126_);
return v___x_127_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__0(lean_object* v_pivots_130_, uint64_t v___x_131_, lean_object* v_limits_132_, uint8_t v_provenance_133_, lean_object* v_as_134_, size_t v_sz_135_, size_t v_i_136_, lean_object* v_b_137_, lean_object* v___y_138_){
_start:
{
lean_object* v_a_140_; lean_object* v_snd_141_; lean_object* v___y_145_; uint8_t v___x_147_; 
v___x_147_ = lean_usize_dec_lt(v_i_136_, v_sz_135_);
if (v___x_147_ == 0)
{
lean_object* v___x_148_; lean_object* v___x_149_; 
v___x_148_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_148_, 0, v_b_137_);
v___x_149_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_149_, 0, v___x_148_);
lean_ctor_set(v___x_149_, 1, v___y_138_);
return v___x_149_;
}
else
{
lean_object* v_fst_150_; lean_object* v_snd_151_; lean_object* v_a_152_; lean_object* v_fst_153_; lean_object* v_snd_154_; lean_object* v___x_155_; lean_object* v___x_156_; 
v_fst_150_ = lean_ctor_get(v_b_137_, 0);
lean_inc(v_fst_150_);
v_snd_151_ = lean_ctor_get(v_b_137_, 1);
lean_inc(v_snd_151_);
lean_dec_ref(v_b_137_);
v_a_152_ = lean_array_uget_borrowed(v_as_134_, v_i_136_);
v_fst_153_ = lean_ctor_get(v_a_152_, 0);
v_snd_154_ = lean_ctor_get(v_a_152_, 1);
v___x_155_ = lp_Hex_Hex_Groebner_instInhabitedPivot_default;
v___x_156_ = lean_array_get_borrowed(v___x_155_, v_pivots_130_, v_fst_153_);
if (lean_obj_tag(v_snd_151_) == 1)
{
lean_object* v_derivation_157_; 
v_derivation_157_ = lean_ctor_get(v___x_156_, 1);
if (lean_obj_tag(v_derivation_157_) == 1)
{
lean_object* v_val_158_; lean_object* v_val_159_; uint64_t v___x_160_; uint64_t v___x_161_; lean_object* v___x_162_; lean_object* v___x_163_; lean_object* v_fst_164_; 
v_val_158_ = lean_ctor_get(v_snd_151_, 0);
lean_inc(v_val_158_);
lean_dec_ref_known(v_snd_151_, 1);
v_val_159_ = lean_ctor_get(v_derivation_157_, 0);
v___x_160_ = lean_unbox_uint64(v_snd_154_);
v___x_161_ = lean_uint64_sub(v___x_131_, v___x_160_);
lean_inc(v_val_159_);
v___x_162_ = lean_alloc_ctor(1, 2, 8);
lean_ctor_set(v___x_162_, 0, v_val_158_);
lean_ctor_set(v___x_162_, 1, v_val_159_);
lean_ctor_set_uint64(v___x_162_, sizeof(void*)*2, v___x_161_);
v___x_163_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_132_, v_provenance_133_, v_fst_150_, v___x_162_, v___y_138_);
v_fst_164_ = lean_ctor_get(v___x_163_, 0);
lean_inc(v_fst_164_);
if (lean_obj_tag(v_fst_164_) == 0)
{
lean_object* v_snd_165_; lean_object* v_a_166_; 
v_snd_165_ = lean_ctor_get(v___x_163_, 1);
lean_inc(v_snd_165_);
lean_dec_ref(v___x_163_);
v_a_166_ = lean_ctor_get(v_fst_164_, 0);
lean_inc(v_a_166_);
lean_dec_ref_known(v_fst_164_, 1);
v_a_140_ = v_a_166_;
v_snd_141_ = v_snd_165_;
goto v___jp_139_;
}
else
{
lean_object* v_snd_167_; lean_object* v_a_168_; size_t v___x_169_; size_t v___x_170_; 
v_snd_167_ = lean_ctor_get(v___x_163_, 1);
lean_inc(v_snd_167_);
lean_dec_ref(v___x_163_);
v_a_168_ = lean_ctor_get(v_fst_164_, 0);
lean_inc(v_a_168_);
lean_dec_ref_known(v_fst_164_, 1);
v___x_169_ = ((size_t)1ULL);
v___x_170_ = lean_usize_add(v_i_136_, v___x_169_);
v_i_136_ = v___x_170_;
v_b_137_ = v_a_168_;
v___y_138_ = v_snd_167_;
goto _start;
}
}
else
{
lean_dec_ref_known(v_snd_151_, 1);
lean_dec(v_fst_150_);
v___y_145_ = v___y_138_;
goto v___jp_144_;
}
}
else
{
lean_dec(v_snd_151_);
lean_dec(v_fst_150_);
v___y_145_ = v___y_138_;
goto v___jp_144_;
}
}
v___jp_139_:
{
lean_object* v___x_142_; lean_object* v___x_143_; 
v___x_142_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_142_, 0, v_a_140_);
v___x_143_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_143_, 0, v___x_142_);
lean_ctor_set(v___x_143_, 1, v_snd_141_);
return v___x_143_;
}
v___jp_144_:
{
lean_object* v___x_146_; 
v___x_146_ = lean_box(1);
v_a_140_ = v___x_146_;
v_snd_141_ = v___y_145_;
goto v___jp_139_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__0___boxed(lean_object* v_pivots_172_, lean_object* v___x_173_, lean_object* v_limits_174_, lean_object* v_provenance_175_, lean_object* v_as_176_, lean_object* v_sz_177_, lean_object* v_i_178_, lean_object* v_b_179_, lean_object* v___y_180_){
_start:
{
uint64_t v___x_12708__boxed_181_; uint8_t v_provenance_boxed_182_; size_t v_sz_boxed_183_; size_t v_i_boxed_184_; lean_object* v_res_185_; 
v___x_12708__boxed_181_ = lean_unbox_uint64(v___x_173_);
lean_dec_ref(v___x_173_);
v_provenance_boxed_182_ = lean_unbox(v_provenance_175_);
v_sz_boxed_183_ = lean_unbox_usize(v_sz_177_);
lean_dec(v_sz_177_);
v_i_boxed_184_ = lean_unbox_usize(v_i_178_);
lean_dec(v_i_178_);
v_res_185_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__0(v_pivots_172_, v___x_12708__boxed_181_, v_limits_174_, v_provenance_boxed_182_, v_as_176_, v_sz_boxed_183_, v_i_boxed_184_, v_b_179_, v___y_180_);
lean_dec_ref(v_as_176_);
lean_dec_ref(v_limits_174_);
lean_dec_ref(v_pivots_172_);
return v_res_185_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg(lean_object* v_limits_192_, uint64_t v_field_193_, lean_object* v_slots_194_, lean_object* v_nativePivots_195_, uint8_t v_provenance_196_, lean_object* v_pivots_197_, lean_object* v_range_198_, lean_object* v_b_199_, lean_object* v_i_200_, lean_object* v___y_201_){
_start:
{
lean_object* v_a_203_; lean_object* v_snd_204_; lean_object* v___y_208_; lean_object* v___y_211_; lean_object* v___y_212_; lean_object* v___y_213_; lean_object* v___y_214_; lean_object* v___y_215_; lean_object* v___y_216_; lean_object* v___y_217_; lean_object* v___y_218_; lean_object* v___y_219_; lean_object* v_stop_227_; lean_object* v_step_228_; uint8_t v___x_229_; 
v_stop_227_ = lean_ctor_get(v_range_198_, 1);
v_step_228_ = lean_ctor_get(v_range_198_, 2);
v___x_229_ = lean_nat_dec_lt(v_i_200_, v_stop_227_);
if (v___x_229_ == 0)
{
lean_object* v___x_230_; lean_object* v___x_231_; 
lean_dec(v_i_200_);
v___x_230_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_230_, 0, v_b_199_);
v___x_231_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_231_, 0, v___x_230_);
lean_ctor_set(v___x_231_, 1, v___y_201_);
return v___x_231_;
}
else
{
lean_object* v_snd_232_; lean_object* v_snd_233_; lean_object* v_fst_234_; lean_object* v_fst_235_; lean_object* v_snd_236_; lean_object* v___x_238_; uint8_t v_isShared_239_; uint8_t v_isSharedCheck_359_; 
v_snd_232_ = lean_ctor_get(v_b_199_, 1);
lean_inc(v_snd_232_);
lean_dec_ref(v_b_199_);
v_snd_233_ = lean_ctor_get(v_snd_232_, 1);
lean_inc(v_snd_233_);
v_fst_234_ = lean_ctor_get(v_snd_232_, 0);
lean_inc(v_fst_234_);
lean_dec(v_snd_232_);
v_fst_235_ = lean_ctor_get(v_snd_233_, 0);
v_snd_236_ = lean_ctor_get(v_snd_233_, 1);
v_isSharedCheck_359_ = !lean_is_exclusive(v_snd_233_);
if (v_isSharedCheck_359_ == 0)
{
v___x_238_ = v_snd_233_;
v_isShared_239_ = v_isSharedCheck_359_;
goto v_resetjp_237_;
}
else
{
lean_inc(v_snd_236_);
lean_inc(v_fst_235_);
lean_dec(v_snd_233_);
v___x_238_ = lean_box(0);
v_isShared_239_ = v_isSharedCheck_359_;
goto v_resetjp_237_;
}
v_resetjp_237_:
{
lean_object* v_packedBytes_240_; lean_object* v_work_241_; lean_object* v_traceNodes_242_; lean_object* v_work_243_; lean_object* v_packedBytes_244_; lean_object* v_traceNodes_245_; lean_object* v___x_246_; lean_object* v___x_247_; lean_object* v___x_248_; lean_object* v___x_249_; lean_object* v___x_250_; lean_object* v___y_252_; lean_object* v___y_253_; lean_object* v___y_254_; lean_object* v___y_353_; 
v_packedBytes_240_ = lean_ctor_get(v_limits_192_, 4);
v_work_241_ = lean_ctor_get(v_limits_192_, 5);
v_traceNodes_242_ = lean_ctor_get(v_limits_192_, 6);
v_work_243_ = lean_ctor_get(v___y_201_, 0);
v_packedBytes_244_ = lean_ctor_get(v___y_201_, 3);
v_traceNodes_245_ = lean_ctor_get(v___y_201_, 4);
v___x_246_ = lean_unsigned_to_nat(4096u);
v___x_247_ = lean_box(0);
v___x_248_ = lean_unsigned_to_nat(0u);
v___x_249_ = lean_unsigned_to_nat(1u);
v___x_250_ = lean_nat_sub(v_traceNodes_242_, v_traceNodes_245_);
if (v_provenance_196_ == 0)
{
lean_inc(v___x_250_);
v___y_353_ = v___x_250_;
goto v___jp_352_;
}
else
{
lean_object* v___x_356_; lean_object* v___x_357_; lean_object* v___x_358_; 
v___x_356_ = lean_nat_sub(v_packedBytes_240_, v_packedBytes_244_);
v___x_357_ = lean_unsigned_to_nat(6u);
v___x_358_ = lean_nat_shiftr(v___x_356_, v___x_357_);
lean_dec(v___x_356_);
v___y_353_ = v___x_358_;
goto v___jp_352_;
}
v___jp_251_:
{
lean_object* v___x_255_; lean_object* v_state_256_; lean_object* v_events_257_; lean_object* v_work_258_; lean_object* v_reductions_259_; uint8_t v_status_260_; lean_object* v___x_261_; lean_object* v_fst_262_; 
v___x_255_ = lean_hex_scan_transition(v_field_193_, v_slots_194_, v_nativePivots_195_, v_fst_234_, v___x_246_, v___y_252_, v___y_254_, v_provenance_196_);
lean_dec(v___y_254_);
lean_dec(v___y_252_);
v_state_256_ = lean_ctor_get(v___x_255_, 0);
lean_inc_ref(v_state_256_);
v_events_257_ = lean_ctor_get(v___x_255_, 1);
lean_inc_ref(v_events_257_);
v_work_258_ = lean_ctor_get(v___x_255_, 2);
lean_inc(v_work_258_);
v_reductions_259_ = lean_ctor_get(v___x_255_, 3);
lean_inc(v_reductions_259_);
v_status_260_ = lean_ctor_get_uint8(v___x_255_, sizeof(void*)*5);
lean_dec_ref(v___x_255_);
v___x_261_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_192_, v_work_258_, v___y_201_);
lean_dec(v_work_258_);
v_fst_262_ = lean_ctor_get(v___x_261_, 0);
lean_inc(v_fst_262_);
if (lean_obj_tag(v_fst_262_) == 0)
{
lean_object* v_snd_263_; lean_object* v_a_264_; 
lean_dec(v_reductions_259_);
lean_dec_ref(v_events_257_);
lean_dec_ref(v_state_256_);
lean_dec(v___y_253_);
lean_dec(v___x_250_);
lean_del_object(v___x_238_);
lean_dec(v_snd_236_);
lean_dec(v_fst_235_);
lean_dec(v_i_200_);
v_snd_263_ = lean_ctor_get(v___x_261_, 1);
lean_inc(v_snd_263_);
lean_dec_ref(v___x_261_);
v_a_264_ = lean_ctor_get(v_fst_262_, 0);
lean_inc(v_a_264_);
lean_dec_ref_known(v_fst_262_, 1);
v_a_203_ = v_a_264_;
v_snd_204_ = v_snd_263_;
goto v___jp_202_;
}
else
{
lean_object* v_snd_265_; lean_object* v___x_267_; uint8_t v_isShared_268_; uint8_t v_isSharedCheck_350_; 
lean_dec_ref_known(v_fst_262_, 1);
v_snd_265_ = lean_ctor_get(v___x_261_, 1);
v_isSharedCheck_350_ = !lean_is_exclusive(v___x_261_);
if (v_isSharedCheck_350_ == 0)
{
lean_object* v_unused_351_; 
v_unused_351_ = lean_ctor_get(v___x_261_, 0);
lean_dec(v_unused_351_);
v___x_267_ = v___x_261_;
v_isShared_268_ = v_isSharedCheck_350_;
goto v_resetjp_266_;
}
else
{
lean_inc(v_snd_265_);
lean_dec(v___x_261_);
v___x_267_ = lean_box(0);
v_isShared_268_ = v_isSharedCheck_350_;
goto v_resetjp_266_;
}
v_resetjp_266_:
{
lean_object* v_work_269_; lean_object* v_inputEntries_270_; lean_object* v_outputEntries_271_; lean_object* v_packedBytes_272_; lean_object* v_traceNodes_273_; lean_object* v_processedRows_274_; lean_object* v_reductions_275_; lean_object* v_zeroRows_276_; lean_object* v___x_278_; uint8_t v_isShared_279_; uint8_t v_isSharedCheck_349_; 
v_work_269_ = lean_ctor_get(v_snd_265_, 0);
v_inputEntries_270_ = lean_ctor_get(v_snd_265_, 1);
v_outputEntries_271_ = lean_ctor_get(v_snd_265_, 2);
v_packedBytes_272_ = lean_ctor_get(v_snd_265_, 3);
v_traceNodes_273_ = lean_ctor_get(v_snd_265_, 4);
v_processedRows_274_ = lean_ctor_get(v_snd_265_, 5);
v_reductions_275_ = lean_ctor_get(v_snd_265_, 6);
v_zeroRows_276_ = lean_ctor_get(v_snd_265_, 7);
v_isSharedCheck_349_ = !lean_is_exclusive(v_snd_265_);
if (v_isSharedCheck_349_ == 0)
{
v___x_278_ = v_snd_265_;
v_isShared_279_ = v_isSharedCheck_349_;
goto v_resetjp_277_;
}
else
{
lean_inc(v_zeroRows_276_);
lean_inc(v_reductions_275_);
lean_inc(v_processedRows_274_);
lean_inc(v_traceNodes_273_);
lean_inc(v_packedBytes_272_);
lean_inc(v_outputEntries_271_);
lean_inc(v_inputEntries_270_);
lean_inc(v_work_269_);
lean_dec(v_snd_265_);
v___x_278_ = lean_box(0);
v_isShared_279_ = v_isSharedCheck_349_;
goto v_resetjp_277_;
}
v_resetjp_277_:
{
lean_object* v___x_280_; lean_object* v___x_282_; 
v___x_280_ = lean_nat_add(v_reductions_275_, v_reductions_259_);
lean_dec(v_reductions_259_);
lean_dec(v_reductions_275_);
if (v_isShared_279_ == 0)
{
lean_ctor_set(v___x_278_, 6, v___x_280_);
v___x_282_ = v___x_278_;
goto v_reusejp_281_;
}
else
{
lean_object* v_reuseFailAlloc_348_; 
v_reuseFailAlloc_348_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_348_, 0, v_work_269_);
lean_ctor_set(v_reuseFailAlloc_348_, 1, v_inputEntries_270_);
lean_ctor_set(v_reuseFailAlloc_348_, 2, v_outputEntries_271_);
lean_ctor_set(v_reuseFailAlloc_348_, 3, v_packedBytes_272_);
lean_ctor_set(v_reuseFailAlloc_348_, 4, v_traceNodes_273_);
lean_ctor_set(v_reuseFailAlloc_348_, 5, v_processedRows_274_);
lean_ctor_set(v_reuseFailAlloc_348_, 6, v___x_280_);
lean_ctor_set(v_reuseFailAlloc_348_, 7, v_zeroRows_276_);
v___x_282_ = v_reuseFailAlloc_348_;
goto v_reusejp_281_;
}
v_reusejp_281_:
{
lean_object* v___x_284_; 
if (v_isShared_268_ == 0)
{
lean_ctor_set(v___x_267_, 1, v_snd_236_);
lean_ctor_set(v___x_267_, 0, v_fst_235_);
v___x_284_ = v___x_267_;
goto v_reusejp_283_;
}
else
{
lean_object* v_reuseFailAlloc_347_; 
v_reuseFailAlloc_347_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_347_, 0, v_fst_235_);
lean_ctor_set(v_reuseFailAlloc_347_, 1, v_snd_236_);
v___x_284_ = v_reuseFailAlloc_347_;
goto v_reusejp_283_;
}
v_reusejp_283_:
{
size_t v_sz_285_; size_t v___x_286_; lean_object* v___x_287_; lean_object* v_fst_288_; 
v_sz_285_ = lean_array_size(v_events_257_);
v___x_286_ = ((size_t)0ULL);
v___x_287_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__0(v_pivots_197_, v_field_193_, v_limits_192_, v_provenance_196_, v_events_257_, v_sz_285_, v___x_286_, v___x_284_, v___x_282_);
lean_dec_ref(v_events_257_);
v_fst_288_ = lean_ctor_get(v___x_287_, 0);
lean_inc(v_fst_288_);
if (lean_obj_tag(v_fst_288_) == 0)
{
lean_object* v_snd_289_; lean_object* v_a_290_; 
lean_dec_ref(v_state_256_);
lean_dec(v___y_253_);
lean_dec(v___x_250_);
lean_del_object(v___x_238_);
lean_dec(v_i_200_);
v_snd_289_ = lean_ctor_get(v___x_287_, 1);
lean_inc(v_snd_289_);
lean_dec_ref(v___x_287_);
v_a_290_ = lean_ctor_get(v_fst_288_, 0);
lean_inc(v_a_290_);
lean_dec_ref_known(v_fst_288_, 1);
v_a_203_ = v_a_290_;
v_snd_204_ = v_snd_289_;
goto v___jp_202_;
}
else
{
lean_object* v_a_291_; lean_object* v___x_293_; uint8_t v_isShared_294_; uint8_t v_isSharedCheck_346_; 
v_a_291_ = lean_ctor_get(v_fst_288_, 0);
v_isSharedCheck_346_ = !lean_is_exclusive(v_fst_288_);
if (v_isSharedCheck_346_ == 0)
{
v___x_293_ = v_fst_288_;
v_isShared_294_ = v_isSharedCheck_346_;
goto v_resetjp_292_;
}
else
{
lean_inc(v_a_291_);
lean_dec(v_fst_288_);
v___x_293_ = lean_box(0);
v_isShared_294_ = v_isSharedCheck_346_;
goto v_resetjp_292_;
}
v_resetjp_292_:
{
lean_object* v_snd_295_; lean_object* v___x_297_; uint8_t v_isShared_298_; uint8_t v_isSharedCheck_344_; 
v_snd_295_ = lean_ctor_get(v___x_287_, 1);
v_isSharedCheck_344_ = !lean_is_exclusive(v___x_287_);
if (v_isSharedCheck_344_ == 0)
{
lean_object* v_unused_345_; 
v_unused_345_ = lean_ctor_get(v___x_287_, 0);
lean_dec(v_unused_345_);
v___x_297_ = v___x_287_;
v_isShared_298_ = v_isSharedCheck_344_;
goto v_resetjp_296_;
}
else
{
lean_inc(v_snd_295_);
lean_dec(v___x_287_);
v___x_297_ = lean_box(0);
v_isShared_298_ = v_isSharedCheck_344_;
goto v_resetjp_296_;
}
v_resetjp_296_:
{
lean_object* v_fst_299_; lean_object* v_snd_300_; lean_object* v___x_302_; uint8_t v_isShared_303_; uint8_t v_isSharedCheck_343_; 
v_fst_299_ = lean_ctor_get(v_a_291_, 0);
v_snd_300_ = lean_ctor_get(v_a_291_, 1);
v_isSharedCheck_343_ = !lean_is_exclusive(v_a_291_);
if (v_isSharedCheck_343_ == 0)
{
v___x_302_ = v_a_291_;
v_isShared_303_ = v_isSharedCheck_343_;
goto v_resetjp_301_;
}
else
{
lean_inc(v_snd_300_);
lean_inc(v_fst_299_);
lean_dec(v_a_291_);
v___x_302_ = lean_box(0);
v_isShared_303_ = v_isSharedCheck_343_;
goto v_resetjp_301_;
}
v_resetjp_301_:
{
uint8_t v___x_304_; uint8_t v___x_305_; 
v___x_304_ = 1;
v___x_305_ = lean_uint8_dec_eq(v_status_260_, v___x_304_);
if (v___x_305_ == 0)
{
uint8_t v___x_306_; uint8_t v___x_307_; 
lean_del_object(v___x_293_);
v___x_306_ = 2;
v___x_307_ = lean_uint8_dec_eq(v_status_260_, v___x_306_);
if (v___x_307_ == 0)
{
uint8_t v___x_308_; uint8_t v___x_309_; 
v___x_308_ = 3;
v___x_309_ = lean_uint8_dec_eq(v_status_260_, v___x_308_);
if (v___x_309_ == 0)
{
uint8_t v___x_310_; uint8_t v___x_311_; 
lean_dec(v___y_253_);
lean_dec(v___x_250_);
v___x_310_ = 0;
v___x_311_ = lean_uint8_dec_eq(v_status_260_, v___x_310_);
if (v___x_311_ == 0)
{
lean_object* v___x_312_; 
lean_del_object(v___x_302_);
lean_dec(v_snd_300_);
lean_dec(v_fst_299_);
lean_del_object(v___x_297_);
lean_dec_ref(v_state_256_);
lean_del_object(v___x_238_);
lean_dec(v_i_200_);
v___x_312_ = lean_box(1);
v_a_203_ = v___x_312_;
v_snd_204_ = v_snd_295_;
goto v___jp_202_;
}
else
{
lean_object* v___x_314_; 
if (v_isShared_303_ == 0)
{
v___x_314_ = v___x_302_;
goto v_reusejp_313_;
}
else
{
lean_object* v_reuseFailAlloc_323_; 
v_reuseFailAlloc_323_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_323_, 0, v_fst_299_);
lean_ctor_set(v_reuseFailAlloc_323_, 1, v_snd_300_);
v___x_314_ = v_reuseFailAlloc_323_;
goto v_reusejp_313_;
}
v_reusejp_313_:
{
lean_object* v___x_316_; 
if (v_isShared_298_ == 0)
{
lean_ctor_set(v___x_297_, 1, v___x_314_);
lean_ctor_set(v___x_297_, 0, v_state_256_);
v___x_316_ = v___x_297_;
goto v_reusejp_315_;
}
else
{
lean_object* v_reuseFailAlloc_322_; 
v_reuseFailAlloc_322_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_322_, 0, v_state_256_);
lean_ctor_set(v_reuseFailAlloc_322_, 1, v___x_314_);
v___x_316_ = v_reuseFailAlloc_322_;
goto v_reusejp_315_;
}
v_reusejp_315_:
{
lean_object* v___x_318_; 
if (v_isShared_239_ == 0)
{
lean_ctor_set(v___x_238_, 1, v___x_316_);
lean_ctor_set(v___x_238_, 0, v___x_247_);
v___x_318_ = v___x_238_;
goto v_reusejp_317_;
}
else
{
lean_object* v_reuseFailAlloc_321_; 
v_reuseFailAlloc_321_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_321_, 0, v___x_247_);
lean_ctor_set(v_reuseFailAlloc_321_, 1, v___x_316_);
v___x_318_ = v_reuseFailAlloc_321_;
goto v_reusejp_317_;
}
v_reusejp_317_:
{
lean_object* v___x_319_; 
v___x_319_ = lean_nat_add(v_i_200_, v_step_228_);
lean_dec(v_i_200_);
v_b_199_ = v___x_318_;
v_i_200_ = v___x_319_;
v___y_201_ = v_snd_295_;
goto _start;
}
}
}
}
}
else
{
lean_del_object(v___x_302_);
lean_dec(v_snd_300_);
lean_del_object(v___x_297_);
lean_dec_ref(v_state_256_);
lean_del_object(v___x_238_);
lean_dec(v_i_200_);
if (v_provenance_196_ == 0)
{
lean_dec(v_fst_299_);
lean_dec(v___y_253_);
lean_dec(v___x_250_);
v___y_208_ = v_snd_295_;
goto v___jp_207_;
}
else
{
uint8_t v___x_324_; 
v___x_324_ = lean_nat_dec_lt(v___y_253_, v___x_250_);
lean_dec(v___x_250_);
lean_dec(v___y_253_);
if (v___x_324_ == 0)
{
lean_dec(v_fst_299_);
v___y_208_ = v_snd_295_;
goto v___jp_207_;
}
else
{
lean_object* v___x_325_; lean_object* v___x_326_; lean_object* v_fst_327_; 
v___x_325_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__1));
v___x_326_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_192_, v_provenance_196_, v_fst_299_, v___x_325_, v_snd_295_);
v_fst_327_ = lean_ctor_get(v___x_326_, 0);
lean_inc(v_fst_327_);
if (lean_obj_tag(v_fst_327_) == 0)
{
lean_object* v_snd_328_; lean_object* v_a_329_; 
v_snd_328_ = lean_ctor_get(v___x_326_, 1);
lean_inc(v_snd_328_);
lean_dec_ref(v___x_326_);
v_a_329_ = lean_ctor_get(v_fst_327_, 0);
lean_inc(v_a_329_);
lean_dec_ref_known(v_fst_327_, 1);
v_a_203_ = v_a_329_;
v_snd_204_ = v_snd_328_;
goto v___jp_202_;
}
else
{
lean_object* v_snd_330_; lean_object* v___x_331_; 
lean_dec_ref_known(v_fst_327_, 1);
v_snd_330_ = lean_ctor_get(v___x_326_, 1);
lean_inc(v_snd_330_);
lean_dec_ref(v___x_326_);
v___x_331_ = lean_box(1);
v_a_203_ = v___x_331_;
v_snd_204_ = v_snd_330_;
goto v___jp_202_;
}
}
}
}
}
else
{
lean_object* v___x_332_; 
lean_del_object(v___x_302_);
lean_dec(v_snd_300_);
lean_dec(v_fst_299_);
lean_del_object(v___x_297_);
lean_dec_ref(v_state_256_);
lean_dec(v___y_253_);
lean_dec(v___x_250_);
lean_del_object(v___x_238_);
lean_dec(v_i_200_);
v___x_332_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__2));
v_a_203_ = v___x_332_;
v_snd_204_ = v_snd_295_;
goto v___jp_202_;
}
}
else
{
lean_object* v_dense_333_; lean_object* v_last_334_; lean_object* v_chargedUntil_335_; lean_object* v_leading_336_; lean_object* v_sugar_337_; uint8_t v___x_338_; 
lean_del_object(v___x_302_);
lean_del_object(v___x_297_);
lean_dec(v___y_253_);
lean_dec(v___x_250_);
lean_del_object(v___x_238_);
lean_dec(v_i_200_);
v_dense_333_ = lean_ctor_get(v_state_256_, 0);
lean_inc_ref(v_dense_333_);
v_last_334_ = lean_ctor_get(v_state_256_, 2);
lean_inc(v_last_334_);
v_chargedUntil_335_ = lean_ctor_get(v_state_256_, 3);
lean_inc(v_chargedUntil_335_);
v_leading_336_ = lean_ctor_get(v_state_256_, 4);
v_sugar_337_ = lean_ctor_get(v_state_256_, 7);
lean_inc(v_sugar_337_);
v___x_338_ = lean_nat_dec_eq(v_leading_336_, v___x_248_);
if (v___x_338_ == 0)
{
lean_object* v___x_339_; lean_object* v___x_341_; 
v___x_339_ = lean_nat_sub(v_leading_336_, v___x_249_);
if (v_isShared_294_ == 0)
{
lean_ctor_set(v___x_293_, 0, v___x_339_);
v___x_341_ = v___x_293_;
goto v_reusejp_340_;
}
else
{
lean_object* v_reuseFailAlloc_342_; 
v_reuseFailAlloc_342_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_342_, 0, v___x_339_);
v___x_341_ = v_reuseFailAlloc_342_;
goto v_reusejp_340_;
}
v_reusejp_340_:
{
v___y_211_ = v_snd_295_;
v___y_212_ = v_state_256_;
v___y_213_ = v_snd_300_;
v___y_214_ = v_chargedUntil_335_;
v___y_215_ = v_sugar_337_;
v___y_216_ = v_last_334_;
v___y_217_ = v_fst_299_;
v___y_218_ = v_dense_333_;
v___y_219_ = v___x_341_;
goto v___jp_210_;
}
}
else
{
lean_del_object(v___x_293_);
v___y_211_ = v_snd_295_;
v___y_212_ = v_state_256_;
v___y_213_ = v_snd_300_;
v___y_214_ = v_chargedUntil_335_;
v___y_215_ = v_sugar_337_;
v___y_216_ = v_last_334_;
v___y_217_ = v_fst_299_;
v___y_218_ = v_dense_333_;
v___y_219_ = v___x_247_;
goto v___jp_210_;
}
}
}
}
}
}
}
}
}
}
}
}
v___jp_352_:
{
lean_object* v___x_354_; uint8_t v___x_355_; 
v___x_354_ = lean_nat_sub(v_work_241_, v_work_243_);
v___x_355_ = lean_nat_dec_le(v___x_250_, v___y_353_);
if (v___x_355_ == 0)
{
lean_inc(v___y_353_);
v___y_252_ = v___x_354_;
v___y_253_ = v___y_353_;
v___y_254_ = v___y_353_;
goto v___jp_251_;
}
else
{
lean_inc(v___x_250_);
v___y_252_ = v___x_354_;
v___y_253_ = v___y_353_;
v___y_254_ = v___x_250_;
goto v___jp_251_;
}
}
}
}
v___jp_202_:
{
lean_object* v___x_205_; lean_object* v___x_206_; 
v___x_205_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_205_, 0, v_a_203_);
v___x_206_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_206_, 0, v___x_205_);
lean_ctor_set(v___x_206_, 1, v_snd_204_);
return v___x_206_;
}
v___jp_207_:
{
lean_object* v___x_209_; 
v___x_209_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__0));
v_a_203_ = v___x_209_;
v_snd_204_ = v___y_208_;
goto v___jp_202_;
}
v___jp_210_:
{
lean_object* v___x_220_; lean_object* v___x_221_; lean_object* v___x_222_; lean_object* v___x_223_; lean_object* v___x_224_; lean_object* v___x_225_; lean_object* v___x_226_; 
lean_inc(v___y_213_);
lean_inc(v___y_217_);
v___x_220_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_220_, 0, v___y_218_);
lean_ctor_set(v___x_220_, 1, v___y_216_);
lean_ctor_set(v___x_220_, 2, v___y_214_);
lean_ctor_set(v___x_220_, 3, v___y_219_);
lean_ctor_set(v___x_220_, 4, v___y_217_);
lean_ctor_set(v___x_220_, 5, v___y_213_);
lean_ctor_set(v___x_220_, 6, v___y_215_);
v___x_221_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_221_, 0, v___x_220_);
v___x_222_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_222_, 0, v___y_217_);
lean_ctor_set(v___x_222_, 1, v___y_213_);
v___x_223_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_223_, 0, v___y_212_);
lean_ctor_set(v___x_223_, 1, v___x_222_);
v___x_224_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_224_, 0, v___x_221_);
lean_ctor_set(v___x_224_, 1, v___x_223_);
v___x_225_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_225_, 0, v___x_224_);
v___x_226_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_226_, 0, v___x_225_);
lean_ctor_set(v___x_226_, 1, v___y_211_);
return v___x_226_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___boxed(lean_object* v_limits_360_, lean_object* v_field_361_, lean_object* v_slots_362_, lean_object* v_nativePivots_363_, lean_object* v_provenance_364_, lean_object* v_pivots_365_, lean_object* v_range_366_, lean_object* v_b_367_, lean_object* v_i_368_, lean_object* v___y_369_){
_start:
{
uint64_t v_field_boxed_370_; uint8_t v_provenance_boxed_371_; lean_object* v_res_372_; 
v_field_boxed_370_ = lean_unbox_uint64(v_field_361_);
lean_dec_ref(v_field_361_);
v_provenance_boxed_371_ = lean_unbox(v_provenance_364_);
v_res_372_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg(v_limits_360_, v_field_boxed_370_, v_slots_362_, v_nativePivots_363_, v_provenance_boxed_371_, v_pivots_365_, v_range_366_, v_b_367_, v_i_368_, v___y_369_);
lean_dec_ref(v_range_366_);
lean_dec_ref(v_pivots_365_);
lean_dec_ref(v_nativePivots_363_);
lean_dec_ref(v_slots_362_);
lean_dec_ref(v_limits_360_);
return v_res_372_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1___redArg(lean_object* v_limits_373_, uint64_t v_field_374_, lean_object* v_pivots_375_, uint8_t v_provenance_376_, lean_object* v_slots_377_, lean_object* v_nativePivots_378_, lean_object* v_range_379_, lean_object* v_b_380_, lean_object* v_i_381_, lean_object* v___y_382_){
_start:
{
lean_object* v_a_384_; lean_object* v_snd_385_; lean_object* v___y_389_; lean_object* v___y_392_; lean_object* v___y_393_; lean_object* v___y_394_; lean_object* v___y_395_; lean_object* v___y_396_; lean_object* v___y_397_; lean_object* v___y_398_; lean_object* v___y_399_; lean_object* v___y_400_; lean_object* v_stop_408_; lean_object* v_step_409_; uint8_t v___x_410_; 
v_stop_408_ = lean_ctor_get(v_range_379_, 1);
v_step_409_ = lean_ctor_get(v_range_379_, 2);
v___x_410_ = lean_nat_dec_lt(v_i_381_, v_stop_408_);
if (v___x_410_ == 0)
{
lean_object* v___x_411_; lean_object* v___x_412_; 
v___x_411_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_411_, 0, v_b_380_);
v___x_412_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_412_, 0, v___x_411_);
lean_ctor_set(v___x_412_, 1, v___y_382_);
return v___x_412_;
}
else
{
lean_object* v_snd_413_; lean_object* v_snd_414_; lean_object* v_fst_415_; lean_object* v_fst_416_; lean_object* v_snd_417_; lean_object* v___x_419_; uint8_t v_isShared_420_; uint8_t v_isSharedCheck_540_; 
v_snd_413_ = lean_ctor_get(v_b_380_, 1);
lean_inc(v_snd_413_);
lean_dec_ref(v_b_380_);
v_snd_414_ = lean_ctor_get(v_snd_413_, 1);
lean_inc(v_snd_414_);
v_fst_415_ = lean_ctor_get(v_snd_413_, 0);
lean_inc(v_fst_415_);
lean_dec(v_snd_413_);
v_fst_416_ = lean_ctor_get(v_snd_414_, 0);
v_snd_417_ = lean_ctor_get(v_snd_414_, 1);
v_isSharedCheck_540_ = !lean_is_exclusive(v_snd_414_);
if (v_isSharedCheck_540_ == 0)
{
v___x_419_ = v_snd_414_;
v_isShared_420_ = v_isSharedCheck_540_;
goto v_resetjp_418_;
}
else
{
lean_inc(v_snd_417_);
lean_inc(v_fst_416_);
lean_dec(v_snd_414_);
v___x_419_ = lean_box(0);
v_isShared_420_ = v_isSharedCheck_540_;
goto v_resetjp_418_;
}
v_resetjp_418_:
{
lean_object* v_packedBytes_421_; lean_object* v_work_422_; lean_object* v_traceNodes_423_; lean_object* v_work_424_; lean_object* v_packedBytes_425_; lean_object* v_traceNodes_426_; lean_object* v___x_427_; lean_object* v___x_428_; lean_object* v___x_429_; lean_object* v___x_430_; lean_object* v___x_431_; lean_object* v___y_433_; lean_object* v___y_434_; lean_object* v___y_435_; lean_object* v___y_534_; 
v_packedBytes_421_ = lean_ctor_get(v_limits_373_, 4);
v_work_422_ = lean_ctor_get(v_limits_373_, 5);
v_traceNodes_423_ = lean_ctor_get(v_limits_373_, 6);
v_work_424_ = lean_ctor_get(v___y_382_, 0);
v_packedBytes_425_ = lean_ctor_get(v___y_382_, 3);
v_traceNodes_426_ = lean_ctor_get(v___y_382_, 4);
v___x_427_ = lean_unsigned_to_nat(4096u);
v___x_428_ = lean_box(0);
v___x_429_ = lean_unsigned_to_nat(0u);
v___x_430_ = lean_unsigned_to_nat(1u);
v___x_431_ = lean_nat_sub(v_traceNodes_423_, v_traceNodes_426_);
if (v_provenance_376_ == 0)
{
lean_inc(v___x_431_);
v___y_534_ = v___x_431_;
goto v___jp_533_;
}
else
{
lean_object* v___x_537_; lean_object* v___x_538_; lean_object* v___x_539_; 
v___x_537_ = lean_nat_sub(v_packedBytes_421_, v_packedBytes_425_);
v___x_538_ = lean_unsigned_to_nat(6u);
v___x_539_ = lean_nat_shiftr(v___x_537_, v___x_538_);
lean_dec(v___x_537_);
v___y_534_ = v___x_539_;
goto v___jp_533_;
}
v___jp_432_:
{
lean_object* v___x_436_; lean_object* v_state_437_; lean_object* v_events_438_; lean_object* v_work_439_; lean_object* v_reductions_440_; uint8_t v_status_441_; lean_object* v___x_442_; lean_object* v_fst_443_; 
v___x_436_ = lean_hex_scan_transition(v_field_374_, v_slots_377_, v_nativePivots_378_, v_fst_415_, v___x_427_, v___y_433_, v___y_435_, v_provenance_376_);
lean_dec(v___y_435_);
lean_dec(v___y_433_);
v_state_437_ = lean_ctor_get(v___x_436_, 0);
lean_inc_ref(v_state_437_);
v_events_438_ = lean_ctor_get(v___x_436_, 1);
lean_inc_ref(v_events_438_);
v_work_439_ = lean_ctor_get(v___x_436_, 2);
lean_inc(v_work_439_);
v_reductions_440_ = lean_ctor_get(v___x_436_, 3);
lean_inc(v_reductions_440_);
v_status_441_ = lean_ctor_get_uint8(v___x_436_, sizeof(void*)*5);
lean_dec_ref(v___x_436_);
v___x_442_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_373_, v_work_439_, v___y_382_);
lean_dec(v_work_439_);
v_fst_443_ = lean_ctor_get(v___x_442_, 0);
lean_inc(v_fst_443_);
if (lean_obj_tag(v_fst_443_) == 0)
{
lean_object* v_snd_444_; lean_object* v_a_445_; 
lean_dec(v_reductions_440_);
lean_dec_ref(v_events_438_);
lean_dec_ref(v_state_437_);
lean_dec(v___y_434_);
lean_dec(v___x_431_);
lean_del_object(v___x_419_);
lean_dec(v_snd_417_);
lean_dec(v_fst_416_);
v_snd_444_ = lean_ctor_get(v___x_442_, 1);
lean_inc(v_snd_444_);
lean_dec_ref(v___x_442_);
v_a_445_ = lean_ctor_get(v_fst_443_, 0);
lean_inc(v_a_445_);
lean_dec_ref_known(v_fst_443_, 1);
v_a_384_ = v_a_445_;
v_snd_385_ = v_snd_444_;
goto v___jp_383_;
}
else
{
lean_object* v_snd_446_; lean_object* v___x_448_; uint8_t v_isShared_449_; uint8_t v_isSharedCheck_531_; 
lean_dec_ref_known(v_fst_443_, 1);
v_snd_446_ = lean_ctor_get(v___x_442_, 1);
v_isSharedCheck_531_ = !lean_is_exclusive(v___x_442_);
if (v_isSharedCheck_531_ == 0)
{
lean_object* v_unused_532_; 
v_unused_532_ = lean_ctor_get(v___x_442_, 0);
lean_dec(v_unused_532_);
v___x_448_ = v___x_442_;
v_isShared_449_ = v_isSharedCheck_531_;
goto v_resetjp_447_;
}
else
{
lean_inc(v_snd_446_);
lean_dec(v___x_442_);
v___x_448_ = lean_box(0);
v_isShared_449_ = v_isSharedCheck_531_;
goto v_resetjp_447_;
}
v_resetjp_447_:
{
lean_object* v_work_450_; lean_object* v_inputEntries_451_; lean_object* v_outputEntries_452_; lean_object* v_packedBytes_453_; lean_object* v_traceNodes_454_; lean_object* v_processedRows_455_; lean_object* v_reductions_456_; lean_object* v_zeroRows_457_; lean_object* v___x_459_; uint8_t v_isShared_460_; uint8_t v_isSharedCheck_530_; 
v_work_450_ = lean_ctor_get(v_snd_446_, 0);
v_inputEntries_451_ = lean_ctor_get(v_snd_446_, 1);
v_outputEntries_452_ = lean_ctor_get(v_snd_446_, 2);
v_packedBytes_453_ = lean_ctor_get(v_snd_446_, 3);
v_traceNodes_454_ = lean_ctor_get(v_snd_446_, 4);
v_processedRows_455_ = lean_ctor_get(v_snd_446_, 5);
v_reductions_456_ = lean_ctor_get(v_snd_446_, 6);
v_zeroRows_457_ = lean_ctor_get(v_snd_446_, 7);
v_isSharedCheck_530_ = !lean_is_exclusive(v_snd_446_);
if (v_isSharedCheck_530_ == 0)
{
v___x_459_ = v_snd_446_;
v_isShared_460_ = v_isSharedCheck_530_;
goto v_resetjp_458_;
}
else
{
lean_inc(v_zeroRows_457_);
lean_inc(v_reductions_456_);
lean_inc(v_processedRows_455_);
lean_inc(v_traceNodes_454_);
lean_inc(v_packedBytes_453_);
lean_inc(v_outputEntries_452_);
lean_inc(v_inputEntries_451_);
lean_inc(v_work_450_);
lean_dec(v_snd_446_);
v___x_459_ = lean_box(0);
v_isShared_460_ = v_isSharedCheck_530_;
goto v_resetjp_458_;
}
v_resetjp_458_:
{
lean_object* v___x_461_; lean_object* v___x_463_; 
v___x_461_ = lean_nat_add(v_reductions_456_, v_reductions_440_);
lean_dec(v_reductions_440_);
lean_dec(v_reductions_456_);
if (v_isShared_460_ == 0)
{
lean_ctor_set(v___x_459_, 6, v___x_461_);
v___x_463_ = v___x_459_;
goto v_reusejp_462_;
}
else
{
lean_object* v_reuseFailAlloc_529_; 
v_reuseFailAlloc_529_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_529_, 0, v_work_450_);
lean_ctor_set(v_reuseFailAlloc_529_, 1, v_inputEntries_451_);
lean_ctor_set(v_reuseFailAlloc_529_, 2, v_outputEntries_452_);
lean_ctor_set(v_reuseFailAlloc_529_, 3, v_packedBytes_453_);
lean_ctor_set(v_reuseFailAlloc_529_, 4, v_traceNodes_454_);
lean_ctor_set(v_reuseFailAlloc_529_, 5, v_processedRows_455_);
lean_ctor_set(v_reuseFailAlloc_529_, 6, v___x_461_);
lean_ctor_set(v_reuseFailAlloc_529_, 7, v_zeroRows_457_);
v___x_463_ = v_reuseFailAlloc_529_;
goto v_reusejp_462_;
}
v_reusejp_462_:
{
lean_object* v___x_465_; 
if (v_isShared_449_ == 0)
{
lean_ctor_set(v___x_448_, 1, v_snd_417_);
lean_ctor_set(v___x_448_, 0, v_fst_416_);
v___x_465_ = v___x_448_;
goto v_reusejp_464_;
}
else
{
lean_object* v_reuseFailAlloc_528_; 
v_reuseFailAlloc_528_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_528_, 0, v_fst_416_);
lean_ctor_set(v_reuseFailAlloc_528_, 1, v_snd_417_);
v___x_465_ = v_reuseFailAlloc_528_;
goto v_reusejp_464_;
}
v_reusejp_464_:
{
size_t v_sz_466_; size_t v___x_467_; lean_object* v___x_468_; lean_object* v_fst_469_; 
v_sz_466_ = lean_array_size(v_events_438_);
v___x_467_ = ((size_t)0ULL);
v___x_468_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__0(v_pivots_375_, v_field_374_, v_limits_373_, v_provenance_376_, v_events_438_, v_sz_466_, v___x_467_, v___x_465_, v___x_463_);
lean_dec_ref(v_events_438_);
v_fst_469_ = lean_ctor_get(v___x_468_, 0);
lean_inc(v_fst_469_);
if (lean_obj_tag(v_fst_469_) == 0)
{
lean_object* v_snd_470_; lean_object* v_a_471_; 
lean_dec_ref(v_state_437_);
lean_dec(v___y_434_);
lean_dec(v___x_431_);
lean_del_object(v___x_419_);
v_snd_470_ = lean_ctor_get(v___x_468_, 1);
lean_inc(v_snd_470_);
lean_dec_ref(v___x_468_);
v_a_471_ = lean_ctor_get(v_fst_469_, 0);
lean_inc(v_a_471_);
lean_dec_ref_known(v_fst_469_, 1);
v_a_384_ = v_a_471_;
v_snd_385_ = v_snd_470_;
goto v___jp_383_;
}
else
{
lean_object* v_a_472_; lean_object* v___x_474_; uint8_t v_isShared_475_; uint8_t v_isSharedCheck_527_; 
v_a_472_ = lean_ctor_get(v_fst_469_, 0);
v_isSharedCheck_527_ = !lean_is_exclusive(v_fst_469_);
if (v_isSharedCheck_527_ == 0)
{
v___x_474_ = v_fst_469_;
v_isShared_475_ = v_isSharedCheck_527_;
goto v_resetjp_473_;
}
else
{
lean_inc(v_a_472_);
lean_dec(v_fst_469_);
v___x_474_ = lean_box(0);
v_isShared_475_ = v_isSharedCheck_527_;
goto v_resetjp_473_;
}
v_resetjp_473_:
{
lean_object* v_snd_476_; lean_object* v___x_478_; uint8_t v_isShared_479_; uint8_t v_isSharedCheck_525_; 
v_snd_476_ = lean_ctor_get(v___x_468_, 1);
v_isSharedCheck_525_ = !lean_is_exclusive(v___x_468_);
if (v_isSharedCheck_525_ == 0)
{
lean_object* v_unused_526_; 
v_unused_526_ = lean_ctor_get(v___x_468_, 0);
lean_dec(v_unused_526_);
v___x_478_ = v___x_468_;
v_isShared_479_ = v_isSharedCheck_525_;
goto v_resetjp_477_;
}
else
{
lean_inc(v_snd_476_);
lean_dec(v___x_468_);
v___x_478_ = lean_box(0);
v_isShared_479_ = v_isSharedCheck_525_;
goto v_resetjp_477_;
}
v_resetjp_477_:
{
lean_object* v_fst_480_; lean_object* v_snd_481_; lean_object* v___x_483_; uint8_t v_isShared_484_; uint8_t v_isSharedCheck_524_; 
v_fst_480_ = lean_ctor_get(v_a_472_, 0);
v_snd_481_ = lean_ctor_get(v_a_472_, 1);
v_isSharedCheck_524_ = !lean_is_exclusive(v_a_472_);
if (v_isSharedCheck_524_ == 0)
{
v___x_483_ = v_a_472_;
v_isShared_484_ = v_isSharedCheck_524_;
goto v_resetjp_482_;
}
else
{
lean_inc(v_snd_481_);
lean_inc(v_fst_480_);
lean_dec(v_a_472_);
v___x_483_ = lean_box(0);
v_isShared_484_ = v_isSharedCheck_524_;
goto v_resetjp_482_;
}
v_resetjp_482_:
{
uint8_t v___x_485_; uint8_t v___x_486_; 
v___x_485_ = 1;
v___x_486_ = lean_uint8_dec_eq(v_status_441_, v___x_485_);
if (v___x_486_ == 0)
{
uint8_t v___x_487_; uint8_t v___x_488_; 
lean_del_object(v___x_474_);
v___x_487_ = 2;
v___x_488_ = lean_uint8_dec_eq(v_status_441_, v___x_487_);
if (v___x_488_ == 0)
{
uint8_t v___x_489_; uint8_t v___x_490_; 
v___x_489_ = 3;
v___x_490_ = lean_uint8_dec_eq(v_status_441_, v___x_489_);
if (v___x_490_ == 0)
{
uint8_t v___x_491_; uint8_t v___x_492_; 
lean_dec(v___y_434_);
lean_dec(v___x_431_);
v___x_491_ = 0;
v___x_492_ = lean_uint8_dec_eq(v_status_441_, v___x_491_);
if (v___x_492_ == 0)
{
lean_object* v___x_493_; 
lean_del_object(v___x_483_);
lean_dec(v_snd_481_);
lean_dec(v_fst_480_);
lean_del_object(v___x_478_);
lean_dec_ref(v_state_437_);
lean_del_object(v___x_419_);
v___x_493_ = lean_box(1);
v_a_384_ = v___x_493_;
v_snd_385_ = v_snd_476_;
goto v___jp_383_;
}
else
{
lean_object* v___x_495_; 
if (v_isShared_484_ == 0)
{
v___x_495_ = v___x_483_;
goto v_reusejp_494_;
}
else
{
lean_object* v_reuseFailAlloc_504_; 
v_reuseFailAlloc_504_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_504_, 0, v_fst_480_);
lean_ctor_set(v_reuseFailAlloc_504_, 1, v_snd_481_);
v___x_495_ = v_reuseFailAlloc_504_;
goto v_reusejp_494_;
}
v_reusejp_494_:
{
lean_object* v___x_497_; 
if (v_isShared_479_ == 0)
{
lean_ctor_set(v___x_478_, 1, v___x_495_);
lean_ctor_set(v___x_478_, 0, v_state_437_);
v___x_497_ = v___x_478_;
goto v_reusejp_496_;
}
else
{
lean_object* v_reuseFailAlloc_503_; 
v_reuseFailAlloc_503_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_503_, 0, v_state_437_);
lean_ctor_set(v_reuseFailAlloc_503_, 1, v___x_495_);
v___x_497_ = v_reuseFailAlloc_503_;
goto v_reusejp_496_;
}
v_reusejp_496_:
{
lean_object* v___x_499_; 
if (v_isShared_420_ == 0)
{
lean_ctor_set(v___x_419_, 1, v___x_497_);
lean_ctor_set(v___x_419_, 0, v___x_428_);
v___x_499_ = v___x_419_;
goto v_reusejp_498_;
}
else
{
lean_object* v_reuseFailAlloc_502_; 
v_reuseFailAlloc_502_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_502_, 0, v___x_428_);
lean_ctor_set(v_reuseFailAlloc_502_, 1, v___x_497_);
v___x_499_ = v_reuseFailAlloc_502_;
goto v_reusejp_498_;
}
v_reusejp_498_:
{
lean_object* v___x_500_; lean_object* v___x_501_; 
v___x_500_ = lean_nat_add(v_i_381_, v_step_409_);
v___x_501_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg(v_limits_373_, v_field_374_, v_slots_377_, v_nativePivots_378_, v_provenance_376_, v_pivots_375_, v_range_379_, v___x_499_, v___x_500_, v_snd_476_);
return v___x_501_;
}
}
}
}
}
else
{
lean_del_object(v___x_483_);
lean_dec(v_snd_481_);
lean_del_object(v___x_478_);
lean_dec_ref(v_state_437_);
lean_del_object(v___x_419_);
if (v_provenance_376_ == 0)
{
lean_dec(v_fst_480_);
lean_dec(v___y_434_);
lean_dec(v___x_431_);
v___y_389_ = v_snd_476_;
goto v___jp_388_;
}
else
{
uint8_t v___x_505_; 
v___x_505_ = lean_nat_dec_lt(v___y_434_, v___x_431_);
lean_dec(v___x_431_);
lean_dec(v___y_434_);
if (v___x_505_ == 0)
{
lean_dec(v_fst_480_);
v___y_389_ = v_snd_476_;
goto v___jp_388_;
}
else
{
lean_object* v___x_506_; lean_object* v___x_507_; lean_object* v_fst_508_; 
v___x_506_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__1));
v___x_507_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_373_, v_provenance_376_, v_fst_480_, v___x_506_, v_snd_476_);
v_fst_508_ = lean_ctor_get(v___x_507_, 0);
lean_inc(v_fst_508_);
if (lean_obj_tag(v_fst_508_) == 0)
{
lean_object* v_snd_509_; lean_object* v_a_510_; 
v_snd_509_ = lean_ctor_get(v___x_507_, 1);
lean_inc(v_snd_509_);
lean_dec_ref(v___x_507_);
v_a_510_ = lean_ctor_get(v_fst_508_, 0);
lean_inc(v_a_510_);
lean_dec_ref_known(v_fst_508_, 1);
v_a_384_ = v_a_510_;
v_snd_385_ = v_snd_509_;
goto v___jp_383_;
}
else
{
lean_object* v_snd_511_; lean_object* v___x_512_; 
lean_dec_ref_known(v_fst_508_, 1);
v_snd_511_ = lean_ctor_get(v___x_507_, 1);
lean_inc(v_snd_511_);
lean_dec_ref(v___x_507_);
v___x_512_ = lean_box(1);
v_a_384_ = v___x_512_;
v_snd_385_ = v_snd_511_;
goto v___jp_383_;
}
}
}
}
}
else
{
lean_object* v___x_513_; 
lean_del_object(v___x_483_);
lean_dec(v_snd_481_);
lean_dec(v_fst_480_);
lean_del_object(v___x_478_);
lean_dec_ref(v_state_437_);
lean_dec(v___y_434_);
lean_dec(v___x_431_);
lean_del_object(v___x_419_);
v___x_513_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__2));
v_a_384_ = v___x_513_;
v_snd_385_ = v_snd_476_;
goto v___jp_383_;
}
}
else
{
lean_object* v_dense_514_; lean_object* v_last_515_; lean_object* v_chargedUntil_516_; lean_object* v_leading_517_; lean_object* v_sugar_518_; uint8_t v___x_519_; 
lean_del_object(v___x_483_);
lean_del_object(v___x_478_);
lean_dec(v___y_434_);
lean_dec(v___x_431_);
lean_del_object(v___x_419_);
v_dense_514_ = lean_ctor_get(v_state_437_, 0);
lean_inc_ref(v_dense_514_);
v_last_515_ = lean_ctor_get(v_state_437_, 2);
lean_inc(v_last_515_);
v_chargedUntil_516_ = lean_ctor_get(v_state_437_, 3);
lean_inc(v_chargedUntil_516_);
v_leading_517_ = lean_ctor_get(v_state_437_, 4);
v_sugar_518_ = lean_ctor_get(v_state_437_, 7);
lean_inc(v_sugar_518_);
v___x_519_ = lean_nat_dec_eq(v_leading_517_, v___x_429_);
if (v___x_519_ == 0)
{
lean_object* v___x_520_; lean_object* v___x_522_; 
v___x_520_ = lean_nat_sub(v_leading_517_, v___x_430_);
if (v_isShared_475_ == 0)
{
lean_ctor_set(v___x_474_, 0, v___x_520_);
v___x_522_ = v___x_474_;
goto v_reusejp_521_;
}
else
{
lean_object* v_reuseFailAlloc_523_; 
v_reuseFailAlloc_523_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_523_, 0, v___x_520_);
v___x_522_ = v_reuseFailAlloc_523_;
goto v_reusejp_521_;
}
v_reusejp_521_:
{
v___y_392_ = v_last_515_;
v___y_393_ = v_fst_480_;
v___y_394_ = v_chargedUntil_516_;
v___y_395_ = v_snd_476_;
v___y_396_ = v_sugar_518_;
v___y_397_ = v_snd_481_;
v___y_398_ = v_dense_514_;
v___y_399_ = v_state_437_;
v___y_400_ = v___x_522_;
goto v___jp_391_;
}
}
else
{
lean_del_object(v___x_474_);
v___y_392_ = v_last_515_;
v___y_393_ = v_fst_480_;
v___y_394_ = v_chargedUntil_516_;
v___y_395_ = v_snd_476_;
v___y_396_ = v_sugar_518_;
v___y_397_ = v_snd_481_;
v___y_398_ = v_dense_514_;
v___y_399_ = v_state_437_;
v___y_400_ = v___x_428_;
goto v___jp_391_;
}
}
}
}
}
}
}
}
}
}
}
}
v___jp_533_:
{
lean_object* v___x_535_; uint8_t v___x_536_; 
v___x_535_ = lean_nat_sub(v_work_422_, v_work_424_);
v___x_536_ = lean_nat_dec_le(v___x_431_, v___y_534_);
if (v___x_536_ == 0)
{
lean_inc(v___y_534_);
v___y_433_ = v___x_535_;
v___y_434_ = v___y_534_;
v___y_435_ = v___y_534_;
goto v___jp_432_;
}
else
{
lean_inc(v___x_431_);
v___y_433_ = v___x_535_;
v___y_434_ = v___y_534_;
v___y_435_ = v___x_431_;
goto v___jp_432_;
}
}
}
}
v___jp_383_:
{
lean_object* v___x_386_; lean_object* v___x_387_; 
v___x_386_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_386_, 0, v_a_384_);
v___x_387_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_387_, 0, v___x_386_);
lean_ctor_set(v___x_387_, 1, v_snd_385_);
return v___x_387_;
}
v___jp_388_:
{
lean_object* v___x_390_; 
v___x_390_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__0));
v_a_384_ = v___x_390_;
v_snd_385_ = v___y_389_;
goto v___jp_383_;
}
v___jp_391_:
{
lean_object* v___x_401_; lean_object* v___x_402_; lean_object* v___x_403_; lean_object* v___x_404_; lean_object* v___x_405_; lean_object* v___x_406_; lean_object* v___x_407_; 
lean_inc(v___y_397_);
lean_inc(v___y_393_);
v___x_401_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_401_, 0, v___y_398_);
lean_ctor_set(v___x_401_, 1, v___y_392_);
lean_ctor_set(v___x_401_, 2, v___y_394_);
lean_ctor_set(v___x_401_, 3, v___y_400_);
lean_ctor_set(v___x_401_, 4, v___y_393_);
lean_ctor_set(v___x_401_, 5, v___y_397_);
lean_ctor_set(v___x_401_, 6, v___y_396_);
v___x_402_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_402_, 0, v___x_401_);
v___x_403_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_403_, 0, v___y_393_);
lean_ctor_set(v___x_403_, 1, v___y_397_);
v___x_404_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_404_, 0, v___y_399_);
lean_ctor_set(v___x_404_, 1, v___x_403_);
v___x_405_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_405_, 0, v___x_402_);
lean_ctor_set(v___x_405_, 1, v___x_404_);
v___x_406_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_406_, 0, v___x_405_);
v___x_407_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_407_, 0, v___x_406_);
lean_ctor_set(v___x_407_, 1, v___y_395_);
return v___x_407_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1___redArg___boxed(lean_object* v_limits_541_, lean_object* v_field_542_, lean_object* v_pivots_543_, lean_object* v_provenance_544_, lean_object* v_slots_545_, lean_object* v_nativePivots_546_, lean_object* v_range_547_, lean_object* v_b_548_, lean_object* v_i_549_, lean_object* v___y_550_){
_start:
{
uint64_t v_field_boxed_551_; uint8_t v_provenance_boxed_552_; lean_object* v_res_553_; 
v_field_boxed_551_ = lean_unbox_uint64(v_field_542_);
lean_dec_ref(v_field_542_);
v_provenance_boxed_552_ = lean_unbox(v_provenance_544_);
v_res_553_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1___redArg(v_limits_541_, v_field_boxed_551_, v_pivots_543_, v_provenance_boxed_552_, v_slots_545_, v_nativePivots_546_, v_range_547_, v_b_548_, v_i_549_, v___y_550_);
lean_dec(v_i_549_);
lean_dec_ref(v_range_547_);
lean_dec_ref(v_nativePivots_546_);
lean_dec_ref(v_slots_545_);
lean_dec_ref(v_pivots_543_);
lean_dec_ref(v_limits_541_);
return v_res_553_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan(uint64_t v_field_556_, lean_object* v_limits_557_, lean_object* v_columns_558_, lean_object* v_slots_559_, lean_object* v_pivots_560_, lean_object* v_nativePivots_561_, lean_object* v_first_562_, lean_object* v_scan_563_, uint8_t v_provenance_564_, lean_object* v_a_565_){
_start:
{
lean_object* v___x_566_; lean_object* v_snd_567_; lean_object* v_fst_568_; lean_object* v___x_570_; uint8_t v_isShared_571_; uint8_t v_isSharedCheck_639_; 
v___x_566_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_takeDense(v_scan_563_);
v_snd_567_ = lean_ctor_get(v___x_566_, 1);
v_fst_568_ = lean_ctor_get(v___x_566_, 0);
v_isSharedCheck_639_ = !lean_is_exclusive(v___x_566_);
if (v_isSharedCheck_639_ == 0)
{
v___x_570_ = v___x_566_;
v_isShared_571_ = v_isSharedCheck_639_;
goto v_resetjp_569_;
}
else
{
lean_inc(v_snd_567_);
lean_inc(v_fst_568_);
lean_dec(v___x_566_);
v___x_570_ = lean_box(0);
v_isShared_571_ = v_isSharedCheck_639_;
goto v_resetjp_569_;
}
v_resetjp_569_:
{
lean_object* v_last_572_; lean_object* v_chargedUntil_573_; lean_object* v_trace_574_; lean_object* v_node_575_; lean_object* v_sugar_576_; lean_object* v___x_577_; uint64_t v___x_578_; lean_object* v_state_579_; lean_object* v___x_580_; lean_object* v___x_581_; lean_object* v___x_582_; lean_object* v___x_583_; lean_object* v___x_584_; lean_object* v___x_585_; lean_object* v___x_586_; lean_object* v___x_587_; lean_object* v___x_588_; lean_object* v___x_589_; lean_object* v___x_590_; lean_object* v___x_592_; 
v_last_572_ = lean_ctor_get(v_snd_567_, 1);
lean_inc(v_last_572_);
v_chargedUntil_573_ = lean_ctor_get(v_snd_567_, 2);
lean_inc(v_chargedUntil_573_);
v_trace_574_ = lean_ctor_get(v_snd_567_, 4);
lean_inc_ref(v_trace_574_);
v_node_575_ = lean_ctor_get(v_snd_567_, 5);
lean_inc(v_node_575_);
v_sugar_576_ = lean_ctor_get(v_snd_567_, 6);
lean_inc(v_sugar_576_);
lean_dec(v_snd_567_);
v___x_577_ = lean_unsigned_to_nat(0u);
v___x_578_ = 0ULL;
v_state_579_ = lean_alloc_ctor(0, 8, 8);
lean_ctor_set(v_state_579_, 0, v_fst_568_);
lean_ctor_set(v_state_579_, 1, v_first_562_);
lean_ctor_set(v_state_579_, 2, v_last_572_);
lean_ctor_set(v_state_579_, 3, v_chargedUntil_573_);
lean_ctor_set(v_state_579_, 4, v___x_577_);
lean_ctor_set(v_state_579_, 5, v___x_577_);
lean_ctor_set(v_state_579_, 6, v___x_577_);
lean_ctor_set(v_state_579_, 7, v_sugar_576_);
lean_ctor_set_uint64(v_state_579_, sizeof(void*)*8, v___x_578_);
v___x_580_ = lean_unsigned_to_nat(2u);
v___x_581_ = lean_nat_add(v_columns_558_, v___x_580_);
v___x_582_ = lean_nat_mul(v_columns_558_, v___x_581_);
lean_dec(v___x_581_);
v___x_583_ = lean_unsigned_to_nat(4095u);
v___x_584_ = lean_nat_add(v___x_582_, v___x_583_);
lean_dec(v___x_582_);
v___x_585_ = lean_unsigned_to_nat(12u);
v___x_586_ = lean_nat_shiftr(v___x_584_, v___x_585_);
lean_dec(v___x_584_);
v___x_587_ = lean_unsigned_to_nat(1u);
v___x_588_ = lean_nat_add(v___x_586_, v___x_587_);
lean_dec(v___x_586_);
v___x_589_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_589_, 0, v___x_577_);
lean_ctor_set(v___x_589_, 1, v___x_588_);
lean_ctor_set(v___x_589_, 2, v___x_587_);
v___x_590_ = lean_box(0);
if (v_isShared_571_ == 0)
{
lean_ctor_set(v___x_570_, 1, v_node_575_);
lean_ctor_set(v___x_570_, 0, v_trace_574_);
v___x_592_ = v___x_570_;
goto v_reusejp_591_;
}
else
{
lean_object* v_reuseFailAlloc_638_; 
v_reuseFailAlloc_638_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_638_, 0, v_trace_574_);
lean_ctor_set(v_reuseFailAlloc_638_, 1, v_node_575_);
v___x_592_ = v_reuseFailAlloc_638_;
goto v_reusejp_591_;
}
v_reusejp_591_:
{
lean_object* v___x_593_; lean_object* v___x_594_; lean_object* v___x_595_; lean_object* v_fst_596_; 
v___x_593_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_593_, 0, v_state_579_);
lean_ctor_set(v___x_593_, 1, v___x_592_);
v___x_594_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_594_, 0, v___x_590_);
lean_ctor_set(v___x_594_, 1, v___x_593_);
v___x_595_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1___redArg(v_limits_557_, v_field_556_, v_pivots_560_, v_provenance_564_, v_slots_559_, v_nativePivots_561_, v___x_589_, v___x_594_, v___x_577_, v_a_565_);
lean_dec_ref_known(v___x_589_, 3);
v_fst_596_ = lean_ctor_get(v___x_595_, 0);
lean_inc(v_fst_596_);
if (lean_obj_tag(v_fst_596_) == 0)
{
lean_object* v_snd_597_; lean_object* v___x_599_; uint8_t v_isShared_600_; uint8_t v_isSharedCheck_612_; 
v_snd_597_ = lean_ctor_get(v___x_595_, 1);
v_isSharedCheck_612_ = !lean_is_exclusive(v___x_595_);
if (v_isSharedCheck_612_ == 0)
{
lean_object* v_unused_613_; 
v_unused_613_ = lean_ctor_get(v___x_595_, 0);
lean_dec(v_unused_613_);
v___x_599_ = v___x_595_;
v_isShared_600_ = v_isSharedCheck_612_;
goto v_resetjp_598_;
}
else
{
lean_inc(v_snd_597_);
lean_dec(v___x_595_);
v___x_599_ = lean_box(0);
v_isShared_600_ = v_isSharedCheck_612_;
goto v_resetjp_598_;
}
v_resetjp_598_:
{
lean_object* v_a_601_; lean_object* v___x_603_; uint8_t v_isShared_604_; uint8_t v_isSharedCheck_611_; 
v_a_601_ = lean_ctor_get(v_fst_596_, 0);
v_isSharedCheck_611_ = !lean_is_exclusive(v_fst_596_);
if (v_isSharedCheck_611_ == 0)
{
v___x_603_ = v_fst_596_;
v_isShared_604_ = v_isSharedCheck_611_;
goto v_resetjp_602_;
}
else
{
lean_inc(v_a_601_);
lean_dec(v_fst_596_);
v___x_603_ = lean_box(0);
v_isShared_604_ = v_isSharedCheck_611_;
goto v_resetjp_602_;
}
v_resetjp_602_:
{
lean_object* v___x_606_; 
if (v_isShared_604_ == 0)
{
v___x_606_ = v___x_603_;
goto v_reusejp_605_;
}
else
{
lean_object* v_reuseFailAlloc_610_; 
v_reuseFailAlloc_610_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_610_, 0, v_a_601_);
v___x_606_ = v_reuseFailAlloc_610_;
goto v_reusejp_605_;
}
v_reusejp_605_:
{
lean_object* v___x_608_; 
if (v_isShared_600_ == 0)
{
lean_ctor_set(v___x_599_, 0, v___x_606_);
v___x_608_ = v___x_599_;
goto v_reusejp_607_;
}
else
{
lean_object* v_reuseFailAlloc_609_; 
v_reuseFailAlloc_609_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_609_, 0, v___x_606_);
lean_ctor_set(v_reuseFailAlloc_609_, 1, v_snd_597_);
v___x_608_ = v_reuseFailAlloc_609_;
goto v_reusejp_607_;
}
v_reusejp_607_:
{
return v___x_608_;
}
}
}
}
}
else
{
lean_object* v_a_614_; lean_object* v___x_616_; uint8_t v_isShared_617_; uint8_t v_isSharedCheck_637_; 
v_a_614_ = lean_ctor_get(v_fst_596_, 0);
v_isSharedCheck_637_ = !lean_is_exclusive(v_fst_596_);
if (v_isSharedCheck_637_ == 0)
{
v___x_616_ = v_fst_596_;
v_isShared_617_ = v_isSharedCheck_637_;
goto v_resetjp_615_;
}
else
{
lean_inc(v_a_614_);
lean_dec(v_fst_596_);
v___x_616_ = lean_box(0);
v_isShared_617_ = v_isSharedCheck_637_;
goto v_resetjp_615_;
}
v_resetjp_615_:
{
lean_object* v_fst_618_; lean_object* v___x_620_; uint8_t v_isShared_621_; uint8_t v_isSharedCheck_635_; 
v_fst_618_ = lean_ctor_get(v_a_614_, 0);
v_isSharedCheck_635_ = !lean_is_exclusive(v_a_614_);
if (v_isSharedCheck_635_ == 0)
{
lean_object* v_unused_636_; 
v_unused_636_ = lean_ctor_get(v_a_614_, 1);
lean_dec(v_unused_636_);
v___x_620_ = v_a_614_;
v_isShared_621_ = v_isSharedCheck_635_;
goto v_resetjp_619_;
}
else
{
lean_inc(v_fst_618_);
lean_dec(v_a_614_);
v___x_620_ = lean_box(0);
v_isShared_621_ = v_isSharedCheck_635_;
goto v_resetjp_619_;
}
v_resetjp_619_:
{
if (lean_obj_tag(v_fst_618_) == 0)
{
lean_object* v_snd_622_; lean_object* v___x_623_; lean_object* v___x_625_; 
lean_del_object(v___x_616_);
v_snd_622_ = lean_ctor_get(v___x_595_, 1);
lean_inc(v_snd_622_);
lean_dec_ref(v___x_595_);
v___x_623_ = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan___closed__0));
if (v_isShared_621_ == 0)
{
lean_ctor_set(v___x_620_, 1, v_snd_622_);
lean_ctor_set(v___x_620_, 0, v___x_623_);
v___x_625_ = v___x_620_;
goto v_reusejp_624_;
}
else
{
lean_object* v_reuseFailAlloc_626_; 
v_reuseFailAlloc_626_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_626_, 0, v___x_623_);
lean_ctor_set(v_reuseFailAlloc_626_, 1, v_snd_622_);
v___x_625_ = v_reuseFailAlloc_626_;
goto v_reusejp_624_;
}
v_reusejp_624_:
{
return v___x_625_;
}
}
else
{
lean_object* v_snd_627_; lean_object* v_val_628_; lean_object* v___x_630_; 
v_snd_627_ = lean_ctor_get(v___x_595_, 1);
lean_inc(v_snd_627_);
lean_dec_ref(v___x_595_);
v_val_628_ = lean_ctor_get(v_fst_618_, 0);
lean_inc(v_val_628_);
lean_dec_ref_known(v_fst_618_, 1);
if (v_isShared_617_ == 0)
{
lean_ctor_set(v___x_616_, 0, v_val_628_);
v___x_630_ = v___x_616_;
goto v_reusejp_629_;
}
else
{
lean_object* v_reuseFailAlloc_634_; 
v_reuseFailAlloc_634_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_634_, 0, v_val_628_);
v___x_630_ = v_reuseFailAlloc_634_;
goto v_reusejp_629_;
}
v_reusejp_629_:
{
lean_object* v___x_632_; 
if (v_isShared_621_ == 0)
{
lean_ctor_set(v___x_620_, 1, v_snd_627_);
lean_ctor_set(v___x_620_, 0, v___x_630_);
v___x_632_ = v___x_620_;
goto v_reusejp_631_;
}
else
{
lean_object* v_reuseFailAlloc_633_; 
v_reuseFailAlloc_633_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_633_, 0, v___x_630_);
lean_ctor_set(v_reuseFailAlloc_633_, 1, v_snd_627_);
v___x_632_ = v_reuseFailAlloc_633_;
goto v_reusejp_631_;
}
v_reusejp_631_:
{
return v___x_632_;
}
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan___boxed(lean_object* v_field_640_, lean_object* v_limits_641_, lean_object* v_columns_642_, lean_object* v_slots_643_, lean_object* v_pivots_644_, lean_object* v_nativePivots_645_, lean_object* v_first_646_, lean_object* v_scan_647_, lean_object* v_provenance_648_, lean_object* v_a_649_){
_start:
{
uint64_t v_field_boxed_650_; uint8_t v_provenance_boxed_651_; lean_object* v_res_652_; 
v_field_boxed_650_ = lean_unbox_uint64(v_field_640_);
lean_dec_ref(v_field_640_);
v_provenance_boxed_651_ = lean_unbox(v_provenance_648_);
v_res_652_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan(v_field_boxed_650_, v_limits_641_, v_columns_642_, v_slots_643_, v_pivots_644_, v_nativePivots_645_, v_first_646_, v_scan_647_, v_provenance_boxed_651_, v_a_649_);
lean_dec_ref(v_nativePivots_645_);
lean_dec_ref(v_pivots_644_);
lean_dec_ref(v_slots_643_);
lean_dec(v_columns_642_);
lean_dec_ref(v_limits_641_);
return v_res_652_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1(lean_object* v_limits_653_, uint64_t v_field_654_, lean_object* v_pivots_655_, uint8_t v_provenance_656_, lean_object* v_slots_657_, lean_object* v_nativePivots_658_, lean_object* v_range_659_, lean_object* v_b_660_, lean_object* v_i_661_, lean_object* v_hs_662_, lean_object* v_hl_663_, lean_object* v___y_664_){
_start:
{
lean_object* v___x_665_; 
v___x_665_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1___redArg(v_limits_653_, v_field_654_, v_pivots_655_, v_provenance_656_, v_slots_657_, v_nativePivots_658_, v_range_659_, v_b_660_, v_i_661_, v___y_664_);
return v___x_665_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1___boxed(lean_object* v_limits_666_, lean_object* v_field_667_, lean_object* v_pivots_668_, lean_object* v_provenance_669_, lean_object* v_slots_670_, lean_object* v_nativePivots_671_, lean_object* v_range_672_, lean_object* v_b_673_, lean_object* v_i_674_, lean_object* v_hs_675_, lean_object* v_hl_676_, lean_object* v___y_677_){
_start:
{
uint64_t v_field_boxed_678_; uint8_t v_provenance_boxed_679_; lean_object* v_res_680_; 
v_field_boxed_678_ = lean_unbox_uint64(v_field_667_);
lean_dec_ref(v_field_667_);
v_provenance_boxed_679_ = lean_unbox(v_provenance_669_);
v_res_680_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1(v_limits_666_, v_field_boxed_678_, v_pivots_668_, v_provenance_boxed_679_, v_slots_670_, v_nativePivots_671_, v_range_672_, v_b_673_, v_i_674_, v_hs_675_, v_hl_676_, v___y_677_);
lean_dec(v_i_674_);
lean_dec_ref(v_range_672_);
lean_dec_ref(v_nativePivots_671_);
lean_dec_ref(v_slots_670_);
lean_dec_ref(v_pivots_668_);
lean_dec_ref(v_limits_666_);
return v_res_680_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1(lean_object* v_limits_681_, uint64_t v_field_682_, lean_object* v_slots_683_, lean_object* v_nativePivots_684_, uint8_t v_provenance_685_, lean_object* v_pivots_686_, lean_object* v_range_687_, lean_object* v_b_688_, lean_object* v_i_689_, lean_object* v_hs_690_, lean_object* v_hl_691_, lean_object* v___y_692_){
_start:
{
lean_object* v___x_693_; 
v___x_693_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg(v_limits_681_, v_field_682_, v_slots_683_, v_nativePivots_684_, v_provenance_685_, v_pivots_686_, v_range_687_, v_b_688_, v_i_689_, v___y_692_);
return v___x_693_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___boxed(lean_object* v_limits_694_, lean_object* v_field_695_, lean_object* v_slots_696_, lean_object* v_nativePivots_697_, lean_object* v_provenance_698_, lean_object* v_pivots_699_, lean_object* v_range_700_, lean_object* v_b_701_, lean_object* v_i_702_, lean_object* v_hs_703_, lean_object* v_hl_704_, lean_object* v___y_705_){
_start:
{
uint64_t v_field_boxed_706_; uint8_t v_provenance_boxed_707_; lean_object* v_res_708_; 
v_field_boxed_706_ = lean_unbox_uint64(v_field_695_);
lean_dec_ref(v_field_695_);
v_provenance_boxed_707_ = lean_unbox(v_provenance_698_);
v_res_708_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1(v_limits_694_, v_field_boxed_706_, v_slots_696_, v_nativePivots_697_, v_provenance_boxed_707_, v_pivots_699_, v_range_700_, v_b_701_, v_i_702_, v_hs_703_, v_hl_704_, v___y_705_);
lean_dec_ref(v_range_700_);
lean_dec_ref(v_pivots_699_);
lean_dec_ref(v_nativePivots_697_);
lean_dec_ref(v_slots_696_);
lean_dec_ref(v_limits_694_);
return v_res_708_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___lam__1(lean_object* v_s_709_, lean_object* v_n_710_){
_start:
{
lean_object* v_work_711_; lean_object* v_inputEntries_712_; lean_object* v_packedBytes_713_; lean_object* v_traceNodes_714_; lean_object* v_processedRows_715_; lean_object* v_reductions_716_; lean_object* v_zeroRows_717_; lean_object* v___x_719_; uint8_t v_isShared_720_; uint8_t v_isSharedCheck_724_; 
v_work_711_ = lean_ctor_get(v_s_709_, 0);
v_inputEntries_712_ = lean_ctor_get(v_s_709_, 1);
v_packedBytes_713_ = lean_ctor_get(v_s_709_, 3);
v_traceNodes_714_ = lean_ctor_get(v_s_709_, 4);
v_processedRows_715_ = lean_ctor_get(v_s_709_, 5);
v_reductions_716_ = lean_ctor_get(v_s_709_, 6);
v_zeroRows_717_ = lean_ctor_get(v_s_709_, 7);
v_isSharedCheck_724_ = !lean_is_exclusive(v_s_709_);
if (v_isSharedCheck_724_ == 0)
{
lean_object* v_unused_725_; 
v_unused_725_ = lean_ctor_get(v_s_709_, 2);
lean_dec(v_unused_725_);
v___x_719_ = v_s_709_;
v_isShared_720_ = v_isSharedCheck_724_;
goto v_resetjp_718_;
}
else
{
lean_inc(v_zeroRows_717_);
lean_inc(v_reductions_716_);
lean_inc(v_processedRows_715_);
lean_inc(v_traceNodes_714_);
lean_inc(v_packedBytes_713_);
lean_inc(v_inputEntries_712_);
lean_inc(v_work_711_);
lean_dec(v_s_709_);
v___x_719_ = lean_box(0);
v_isShared_720_ = v_isSharedCheck_724_;
goto v_resetjp_718_;
}
v_resetjp_718_:
{
lean_object* v___x_722_; 
if (v_isShared_720_ == 0)
{
lean_ctor_set(v___x_719_, 2, v_n_710_);
v___x_722_ = v___x_719_;
goto v_reusejp_721_;
}
else
{
lean_object* v_reuseFailAlloc_723_; 
v_reuseFailAlloc_723_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_723_, 0, v_work_711_);
lean_ctor_set(v_reuseFailAlloc_723_, 1, v_inputEntries_712_);
lean_ctor_set(v_reuseFailAlloc_723_, 2, v_n_710_);
lean_ctor_set(v_reuseFailAlloc_723_, 3, v_packedBytes_713_);
lean_ctor_set(v_reuseFailAlloc_723_, 4, v_traceNodes_714_);
lean_ctor_set(v_reuseFailAlloc_723_, 5, v_processedRows_715_);
lean_ctor_set(v_reuseFailAlloc_723_, 6, v_reductions_716_);
lean_ctor_set(v_reuseFailAlloc_723_, 7, v_zeroRows_717_);
v___x_722_ = v_reuseFailAlloc_723_;
goto v_reusejp_721_;
}
v_reusejp_721_:
{
return v___x_722_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___lam__0(lean_object* v_x_726_){
_start:
{
lean_object* v_outputEntries_727_; 
v_outputEntries_727_ = lean_ctor_get(v_x_726_, 2);
lean_inc(v_outputEntries_727_);
return v_outputEntries_727_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___lam__0___boxed(lean_object* v_x_728_){
_start:
{
lean_object* v_res_729_; 
v_res_729_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___lam__0(v_x_728_);
lean_dec_ref(v_x_728_);
return v_res_729_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg(uint64_t v_field_736_, lean_object* v_limits_737_, lean_object* v___x_738_, uint64_t v_factor_739_, lean_object* v_range_740_, lean_object* v_b_741_, lean_object* v_i_742_, lean_object* v___y_743_){
_start:
{
lean_object* v_a_745_; lean_object* v_snd_746_; lean_object* v_stop_749_; lean_object* v_step_750_; uint8_t v___x_751_; 
v_stop_749_ = lean_ctor_get(v_range_740_, 1);
v_step_750_ = lean_ctor_get(v_range_740_, 2);
v___x_751_ = lean_nat_dec_lt(v_i_742_, v_stop_749_);
if (v___x_751_ == 0)
{
lean_object* v___x_752_; lean_object* v___x_753_; 
lean_dec(v_i_742_);
v___x_752_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_752_, 0, v_b_741_);
v___x_753_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_753_, 0, v___x_752_);
lean_ctor_set(v___x_753_, 1, v___y_743_);
return v___x_753_;
}
else
{
lean_object* v_snd_754_; lean_object* v___x_756_; uint8_t v_isShared_757_; uint8_t v_isSharedCheck_861_; 
v_snd_754_ = lean_ctor_get(v_b_741_, 1);
v_isSharedCheck_861_ = !lean_is_exclusive(v_b_741_);
if (v_isSharedCheck_861_ == 0)
{
lean_object* v_unused_862_; 
v_unused_862_ = lean_ctor_get(v_b_741_, 0);
lean_dec(v_unused_862_);
v___x_756_ = v_b_741_;
v_isShared_757_ = v_isSharedCheck_861_;
goto v_resetjp_755_;
}
else
{
lean_inc(v_snd_754_);
lean_dec(v_b_741_);
v___x_756_ = lean_box(0);
v_isShared_757_ = v_isSharedCheck_861_;
goto v_resetjp_755_;
}
v_resetjp_755_:
{
lean_object* v_outputEntries_758_; lean_object* v_packedBytes_759_; lean_object* v_work_760_; lean_object* v_work_761_; lean_object* v_outputEntries_762_; lean_object* v_packedBytes_763_; lean_object* v___x_764_; lean_object* v___x_765_; lean_object* v___x_766_; lean_object* v___x_767_; lean_object* v___x_768_; lean_object* v_state_769_; lean_object* v_entries_770_; lean_object* v_bytes_771_; lean_object* v_work_772_; uint8_t v_status_773_; lean_object* v___f_774_; lean_object* v___f_775_; uint8_t v___x_776_; lean_object* v___x_777_; lean_object* v_fst_778_; 
v_outputEntries_758_ = lean_ctor_get(v_limits_737_, 3);
v_packedBytes_759_ = lean_ctor_get(v_limits_737_, 4);
v_work_760_ = lean_ctor_get(v_limits_737_, 5);
v_work_761_ = lean_ctor_get(v___y_743_, 0);
v_outputEntries_762_ = lean_ctor_get(v___y_743_, 2);
v_packedBytes_763_ = lean_ctor_get(v___y_743_, 3);
v___x_764_ = lean_unsigned_to_nat(4096u);
v___x_765_ = lean_nat_sub(v_outputEntries_758_, v_outputEntries_762_);
v___x_766_ = lean_nat_sub(v_packedBytes_759_, v_packedBytes_763_);
v___x_767_ = lean_nat_sub(v_work_760_, v_work_761_);
v___x_768_ = lean_hex_gather(v_field_736_, v_snd_754_, v___x_738_, v___x_764_, v___x_765_, v___x_766_, v___x_767_, v_factor_739_);
lean_dec(v___x_767_);
lean_dec(v___x_766_);
lean_dec(v___x_765_);
v_state_769_ = lean_ctor_get(v___x_768_, 0);
lean_inc_ref(v_state_769_);
v_entries_770_ = lean_ctor_get(v___x_768_, 1);
lean_inc(v_entries_770_);
v_bytes_771_ = lean_ctor_get(v___x_768_, 2);
lean_inc(v_bytes_771_);
v_work_772_ = lean_ctor_get(v___x_768_, 3);
lean_inc(v_work_772_);
v_status_773_ = lean_ctor_get_uint8(v___x_768_, sizeof(void*)*4);
lean_dec_ref(v___x_768_);
v___f_774_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__0));
v___f_775_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__1));
v___x_776_ = 3;
v___x_777_ = lp_Hex_Hex_Groebner_Matrix_charge(v___x_776_, v_entries_770_, v_outputEntries_758_, v___f_774_, v___f_775_, v___y_743_);
lean_dec(v_entries_770_);
v_fst_778_ = lean_ctor_get(v___x_777_, 0);
lean_inc(v_fst_778_);
if (lean_obj_tag(v_fst_778_) == 0)
{
lean_object* v_snd_779_; lean_object* v_a_780_; 
lean_dec(v_work_772_);
lean_dec(v_bytes_771_);
lean_dec_ref(v_state_769_);
lean_del_object(v___x_756_);
lean_dec(v_i_742_);
v_snd_779_ = lean_ctor_get(v___x_777_, 1);
lean_inc(v_snd_779_);
lean_dec_ref(v___x_777_);
v_a_780_ = lean_ctor_get(v_fst_778_, 0);
lean_inc(v_a_780_);
lean_dec_ref_known(v_fst_778_, 1);
v_a_745_ = v_a_780_;
v_snd_746_ = v_snd_779_;
goto v___jp_744_;
}
else
{
lean_object* v_snd_781_; lean_object* v___x_783_; uint8_t v_isShared_784_; uint8_t v_isSharedCheck_859_; 
lean_dec_ref_known(v_fst_778_, 1);
v_snd_781_ = lean_ctor_get(v___x_777_, 1);
v_isSharedCheck_859_ = !lean_is_exclusive(v___x_777_);
if (v_isSharedCheck_859_ == 0)
{
lean_object* v_unused_860_; 
v_unused_860_ = lean_ctor_get(v___x_777_, 0);
lean_dec(v_unused_860_);
v___x_783_ = v___x_777_;
v_isShared_784_ = v_isSharedCheck_859_;
goto v_resetjp_782_;
}
else
{
lean_inc(v_snd_781_);
lean_dec(v___x_777_);
v___x_783_ = lean_box(0);
v_isShared_784_ = v_isSharedCheck_859_;
goto v_resetjp_782_;
}
v_resetjp_782_:
{
lean_object* v___x_785_; lean_object* v_fst_786_; 
v___x_785_ = lp_Hex_Hex_Groebner_Matrix_packedBytes(v_limits_737_, v_bytes_771_, v_snd_781_);
lean_dec(v_bytes_771_);
v_fst_786_ = lean_ctor_get(v___x_785_, 0);
lean_inc(v_fst_786_);
if (lean_obj_tag(v_fst_786_) == 0)
{
lean_object* v_snd_787_; lean_object* v_a_788_; 
lean_del_object(v___x_783_);
lean_dec(v_work_772_);
lean_dec_ref(v_state_769_);
lean_del_object(v___x_756_);
lean_dec(v_i_742_);
v_snd_787_ = lean_ctor_get(v___x_785_, 1);
lean_inc(v_snd_787_);
lean_dec_ref(v___x_785_);
v_a_788_ = lean_ctor_get(v_fst_786_, 0);
lean_inc(v_a_788_);
lean_dec_ref_known(v_fst_786_, 1);
v_a_745_ = v_a_788_;
v_snd_746_ = v_snd_787_;
goto v___jp_744_;
}
else
{
lean_object* v_snd_789_; lean_object* v___x_791_; uint8_t v_isShared_792_; uint8_t v_isSharedCheck_857_; 
v_snd_789_ = lean_ctor_get(v___x_785_, 1);
v_isSharedCheck_857_ = !lean_is_exclusive(v___x_785_);
if (v_isSharedCheck_857_ == 0)
{
lean_object* v_unused_858_; 
v_unused_858_ = lean_ctor_get(v___x_785_, 0);
lean_dec(v_unused_858_);
v___x_791_ = v___x_785_;
v_isShared_792_ = v_isSharedCheck_857_;
goto v_resetjp_790_;
}
else
{
lean_inc(v_snd_789_);
lean_dec(v___x_785_);
v___x_791_ = lean_box(0);
v_isShared_792_ = v_isSharedCheck_857_;
goto v_resetjp_790_;
}
v_resetjp_790_:
{
lean_object* v___x_794_; uint8_t v_isShared_795_; uint8_t v_isSharedCheck_855_; 
v_isSharedCheck_855_ = !lean_is_exclusive(v_fst_786_);
if (v_isSharedCheck_855_ == 0)
{
lean_object* v_unused_856_; 
v_unused_856_ = lean_ctor_get(v_fst_786_, 0);
lean_dec(v_unused_856_);
v___x_794_ = v_fst_786_;
v_isShared_795_ = v_isSharedCheck_855_;
goto v_resetjp_793_;
}
else
{
lean_dec(v_fst_786_);
v___x_794_ = lean_box(0);
v_isShared_795_ = v_isSharedCheck_855_;
goto v_resetjp_793_;
}
v_resetjp_793_:
{
lean_object* v___x_796_; lean_object* v_fst_797_; 
v___x_796_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_737_, v_work_772_, v_snd_789_);
lean_dec(v_work_772_);
v_fst_797_ = lean_ctor_get(v___x_796_, 0);
lean_inc(v_fst_797_);
if (lean_obj_tag(v_fst_797_) == 0)
{
lean_object* v_snd_798_; lean_object* v_a_799_; 
lean_del_object(v___x_794_);
lean_del_object(v___x_791_);
lean_del_object(v___x_783_);
lean_dec_ref(v_state_769_);
lean_del_object(v___x_756_);
lean_dec(v_i_742_);
v_snd_798_ = lean_ctor_get(v___x_796_, 1);
lean_inc(v_snd_798_);
lean_dec_ref(v___x_796_);
v_a_799_ = lean_ctor_get(v_fst_797_, 0);
lean_inc(v_a_799_);
lean_dec_ref_known(v_fst_797_, 1);
v_a_745_ = v_a_799_;
v_snd_746_ = v_snd_798_;
goto v___jp_744_;
}
else
{
lean_object* v_snd_800_; lean_object* v___x_802_; uint8_t v_isShared_803_; uint8_t v_isSharedCheck_853_; 
v_snd_800_ = lean_ctor_get(v___x_796_, 1);
v_isSharedCheck_853_ = !lean_is_exclusive(v___x_796_);
if (v_isSharedCheck_853_ == 0)
{
lean_object* v_unused_854_; 
v_unused_854_ = lean_ctor_get(v___x_796_, 0);
lean_dec(v_unused_854_);
v___x_802_ = v___x_796_;
v_isShared_803_ = v_isSharedCheck_853_;
goto v_resetjp_801_;
}
else
{
lean_inc(v_snd_800_);
lean_dec(v___x_796_);
v___x_802_ = lean_box(0);
v_isShared_803_ = v_isSharedCheck_853_;
goto v_resetjp_801_;
}
v_resetjp_801_:
{
lean_object* v___x_805_; uint8_t v_isShared_806_; uint8_t v_isSharedCheck_851_; 
v_isSharedCheck_851_ = !lean_is_exclusive(v_fst_797_);
if (v_isSharedCheck_851_ == 0)
{
lean_object* v_unused_852_; 
v_unused_852_ = lean_ctor_get(v_fst_797_, 0);
lean_dec(v_unused_852_);
v___x_805_ = v_fst_797_;
v_isShared_806_ = v_isSharedCheck_851_;
goto v_resetjp_804_;
}
else
{
lean_dec(v_fst_797_);
v___x_805_ = lean_box(0);
v_isShared_806_ = v_isSharedCheck_851_;
goto v_resetjp_804_;
}
v_resetjp_804_:
{
uint8_t v___x_807_; uint8_t v___x_808_; 
v___x_807_ = 1;
v___x_808_ = lean_uint8_dec_eq(v_status_773_, v___x_807_);
if (v___x_808_ == 0)
{
uint8_t v___x_809_; uint8_t v___x_810_; 
lean_del_object(v___x_805_);
lean_del_object(v___x_794_);
lean_del_object(v___x_791_);
lean_del_object(v___x_783_);
lean_del_object(v___x_756_);
v___x_809_ = 2;
v___x_810_ = lean_uint8_dec_eq(v_status_773_, v___x_809_);
if (v___x_810_ == 0)
{
uint8_t v___x_811_; uint8_t v___x_812_; 
v___x_811_ = 3;
v___x_812_ = lean_uint8_dec_eq(v_status_773_, v___x_811_);
if (v___x_812_ == 0)
{
uint8_t v___x_813_; uint8_t v___x_814_; 
v___x_813_ = 4;
v___x_814_ = lean_uint8_dec_eq(v_status_773_, v___x_813_);
if (v___x_814_ == 0)
{
uint8_t v___x_815_; uint8_t v___x_816_; 
v___x_815_ = 5;
v___x_816_ = lean_uint8_dec_eq(v_status_773_, v___x_815_);
if (v___x_816_ == 0)
{
uint8_t v___x_817_; uint8_t v___x_818_; 
v___x_817_ = 0;
v___x_818_ = lean_uint8_dec_eq(v_status_773_, v___x_817_);
if (v___x_818_ == 0)
{
lean_object* v___x_819_; 
lean_del_object(v___x_802_);
lean_dec_ref(v_state_769_);
lean_dec(v_i_742_);
v___x_819_ = lean_box(1);
v_a_745_ = v___x_819_;
v_snd_746_ = v_snd_800_;
goto v___jp_744_;
}
else
{
lean_object* v___x_820_; lean_object* v___x_822_; 
v___x_820_ = lean_box(0);
if (v_isShared_803_ == 0)
{
lean_ctor_set(v___x_802_, 1, v_state_769_);
lean_ctor_set(v___x_802_, 0, v___x_820_);
v___x_822_ = v___x_802_;
goto v_reusejp_821_;
}
else
{
lean_object* v_reuseFailAlloc_825_; 
v_reuseFailAlloc_825_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_825_, 0, v___x_820_);
lean_ctor_set(v_reuseFailAlloc_825_, 1, v_state_769_);
v___x_822_ = v_reuseFailAlloc_825_;
goto v_reusejp_821_;
}
v_reusejp_821_:
{
lean_object* v___x_823_; 
v___x_823_ = lean_nat_add(v_i_742_, v_step_750_);
lean_dec(v_i_742_);
v_b_741_ = v___x_822_;
v_i_742_ = v___x_823_;
v___y_743_ = v_snd_800_;
goto _start;
}
}
}
else
{
lean_object* v___x_826_; 
lean_del_object(v___x_802_);
lean_dec_ref(v_state_769_);
lean_dec(v_i_742_);
v___x_826_ = lean_box(0);
v_a_745_ = v___x_826_;
v_snd_746_ = v_snd_800_;
goto v___jp_744_;
}
}
else
{
lean_object* v___x_827_; 
lean_del_object(v___x_802_);
lean_dec_ref(v_state_769_);
lean_dec(v_i_742_);
v___x_827_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan_spec__1_spec__1___redArg___closed__2));
v_a_745_ = v___x_827_;
v_snd_746_ = v_snd_800_;
goto v___jp_744_;
}
}
else
{
lean_object* v___x_828_; 
lean_del_object(v___x_802_);
lean_dec_ref(v_state_769_);
lean_dec(v_i_742_);
v___x_828_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__2));
v_a_745_ = v___x_828_;
v_snd_746_ = v_snd_800_;
goto v___jp_744_;
}
}
else
{
lean_object* v___x_829_; 
lean_del_object(v___x_802_);
lean_dec_ref(v_state_769_);
lean_dec(v_i_742_);
v___x_829_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__3));
v_a_745_ = v___x_829_;
v_snd_746_ = v_snd_800_;
goto v___jp_744_;
}
}
else
{
lean_object* v_dense_830_; lean_object* v_columns_831_; lean_object* v_coefficients_832_; lean_object* v___x_834_; 
lean_dec(v_i_742_);
v_dense_830_ = lean_ctor_get(v_state_769_, 0);
v_columns_831_ = lean_ctor_get(v_state_769_, 1);
v_coefficients_832_ = lean_ctor_get(v_state_769_, 2);
lean_inc_ref(v_coefficients_832_);
lean_inc_ref(v_columns_831_);
if (v_isShared_757_ == 0)
{
lean_ctor_set(v___x_756_, 1, v_coefficients_832_);
lean_ctor_set(v___x_756_, 0, v_columns_831_);
v___x_834_ = v___x_756_;
goto v_reusejp_833_;
}
else
{
lean_object* v_reuseFailAlloc_850_; 
v_reuseFailAlloc_850_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_850_, 0, v_columns_831_);
lean_ctor_set(v_reuseFailAlloc_850_, 1, v_coefficients_832_);
v___x_834_ = v_reuseFailAlloc_850_;
goto v_reusejp_833_;
}
v_reusejp_833_:
{
lean_object* v___x_836_; 
lean_inc_ref(v_dense_830_);
if (v_isShared_803_ == 0)
{
lean_ctor_set(v___x_802_, 1, v_dense_830_);
lean_ctor_set(v___x_802_, 0, v___x_834_);
v___x_836_ = v___x_802_;
goto v_reusejp_835_;
}
else
{
lean_object* v_reuseFailAlloc_849_; 
v_reuseFailAlloc_849_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_849_, 0, v___x_834_);
lean_ctor_set(v_reuseFailAlloc_849_, 1, v_dense_830_);
v___x_836_ = v_reuseFailAlloc_849_;
goto v_reusejp_835_;
}
v_reusejp_835_:
{
lean_object* v___x_838_; 
if (v_isShared_795_ == 0)
{
lean_ctor_set(v___x_794_, 0, v___x_836_);
v___x_838_ = v___x_794_;
goto v_reusejp_837_;
}
else
{
lean_object* v_reuseFailAlloc_848_; 
v_reuseFailAlloc_848_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_848_, 0, v___x_836_);
v___x_838_ = v_reuseFailAlloc_848_;
goto v_reusejp_837_;
}
v_reusejp_837_:
{
lean_object* v___x_840_; 
if (v_isShared_792_ == 0)
{
lean_ctor_set(v___x_791_, 1, v_state_769_);
lean_ctor_set(v___x_791_, 0, v___x_838_);
v___x_840_ = v___x_791_;
goto v_reusejp_839_;
}
else
{
lean_object* v_reuseFailAlloc_847_; 
v_reuseFailAlloc_847_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_847_, 0, v___x_838_);
lean_ctor_set(v_reuseFailAlloc_847_, 1, v_state_769_);
v___x_840_ = v_reuseFailAlloc_847_;
goto v_reusejp_839_;
}
v_reusejp_839_:
{
lean_object* v___x_842_; 
if (v_isShared_806_ == 0)
{
lean_ctor_set(v___x_805_, 0, v___x_840_);
v___x_842_ = v___x_805_;
goto v_reusejp_841_;
}
else
{
lean_object* v_reuseFailAlloc_846_; 
v_reuseFailAlloc_846_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_846_, 0, v___x_840_);
v___x_842_ = v_reuseFailAlloc_846_;
goto v_reusejp_841_;
}
v_reusejp_841_:
{
lean_object* v___x_844_; 
if (v_isShared_784_ == 0)
{
lean_ctor_set(v___x_783_, 1, v_snd_800_);
lean_ctor_set(v___x_783_, 0, v___x_842_);
v___x_844_ = v___x_783_;
goto v_reusejp_843_;
}
else
{
lean_object* v_reuseFailAlloc_845_; 
v_reuseFailAlloc_845_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_845_, 0, v___x_842_);
lean_ctor_set(v_reuseFailAlloc_845_, 1, v_snd_800_);
v___x_844_ = v_reuseFailAlloc_845_;
goto v_reusejp_843_;
}
v_reusejp_843_:
{
return v___x_844_;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
v___jp_744_:
{
lean_object* v___x_747_; lean_object* v___x_748_; 
v___x_747_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_747_, 0, v_a_745_);
v___x_748_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_748_, 0, v___x_747_);
lean_ctor_set(v___x_748_, 1, v_snd_746_);
return v___x_748_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___boxed(lean_object* v_field_863_, lean_object* v_limits_864_, lean_object* v___x_865_, lean_object* v_factor_866_, lean_object* v_range_867_, lean_object* v_b_868_, lean_object* v_i_869_, lean_object* v___y_870_){
_start:
{
uint64_t v_field_boxed_871_; uint64_t v_factor_boxed_872_; lean_object* v_res_873_; 
v_field_boxed_871_ = lean_unbox_uint64(v_field_863_);
lean_dec_ref(v_field_863_);
v_factor_boxed_872_ = lean_unbox_uint64(v_factor_866_);
lean_dec_ref(v_factor_866_);
v_res_873_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg(v_field_boxed_871_, v_limits_864_, v___x_865_, v_factor_boxed_872_, v_range_867_, v_b_868_, v_i_869_, v___y_870_);
lean_dec_ref(v_range_867_);
lean_dec(v___x_865_);
lean_dec_ref(v_limits_864_);
return v_res_873_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather(uint64_t v_field_876_, lean_object* v_limits_877_, lean_object* v_dense_878_, lean_object* v_column_879_, lean_object* v_last_880_, uint64_t v_factor_881_, lean_object* v_a_882_){
_start:
{
lean_object* v___x_883_; lean_object* v_state_884_; lean_object* v___x_885_; lean_object* v___x_886_; lean_object* v___x_887_; lean_object* v___x_888_; lean_object* v___x_889_; lean_object* v___x_890_; lean_object* v___x_891_; lean_object* v___x_892_; lean_object* v___x_893_; lean_object* v___x_894_; lean_object* v___x_895_; lean_object* v___x_896_; lean_object* v___x_897_; lean_object* v_fst_898_; 
v___x_883_ = l_ByteArray_empty;
lean_inc(v_column_879_);
v_state_884_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v_state_884_, 0, v_dense_878_);
lean_ctor_set(v_state_884_, 1, v___x_883_);
lean_ctor_set(v_state_884_, 2, v___x_883_);
lean_ctor_set(v_state_884_, 3, v_column_879_);
v___x_885_ = lean_unsigned_to_nat(0u);
v___x_886_ = lean_unsigned_to_nat(1u);
v___x_887_ = lean_nat_add(v_last_880_, v___x_886_);
v___x_888_ = lean_nat_sub(v___x_887_, v_column_879_);
lean_dec(v_column_879_);
v___x_889_ = lean_unsigned_to_nat(4095u);
v___x_890_ = lean_nat_add(v___x_888_, v___x_889_);
lean_dec(v___x_888_);
v___x_891_ = lean_unsigned_to_nat(12u);
v___x_892_ = lean_nat_shiftr(v___x_890_, v___x_891_);
lean_dec(v___x_890_);
v___x_893_ = lean_nat_add(v___x_892_, v___x_886_);
lean_dec(v___x_892_);
v___x_894_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_894_, 0, v___x_885_);
lean_ctor_set(v___x_894_, 1, v___x_893_);
lean_ctor_set(v___x_894_, 2, v___x_886_);
v___x_895_ = lean_box(0);
v___x_896_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_896_, 0, v___x_895_);
lean_ctor_set(v___x_896_, 1, v_state_884_);
v___x_897_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg(v_field_876_, v_limits_877_, v___x_887_, v_factor_881_, v___x_894_, v___x_896_, v___x_885_, v_a_882_);
lean_dec_ref_known(v___x_894_, 3);
lean_dec(v___x_887_);
v_fst_898_ = lean_ctor_get(v___x_897_, 0);
lean_inc(v_fst_898_);
if (lean_obj_tag(v_fst_898_) == 0)
{
lean_object* v_snd_899_; lean_object* v___x_901_; uint8_t v_isShared_902_; uint8_t v_isSharedCheck_914_; 
v_snd_899_ = lean_ctor_get(v___x_897_, 1);
v_isSharedCheck_914_ = !lean_is_exclusive(v___x_897_);
if (v_isSharedCheck_914_ == 0)
{
lean_object* v_unused_915_; 
v_unused_915_ = lean_ctor_get(v___x_897_, 0);
lean_dec(v_unused_915_);
v___x_901_ = v___x_897_;
v_isShared_902_ = v_isSharedCheck_914_;
goto v_resetjp_900_;
}
else
{
lean_inc(v_snd_899_);
lean_dec(v___x_897_);
v___x_901_ = lean_box(0);
v_isShared_902_ = v_isSharedCheck_914_;
goto v_resetjp_900_;
}
v_resetjp_900_:
{
lean_object* v_a_903_; lean_object* v___x_905_; uint8_t v_isShared_906_; uint8_t v_isSharedCheck_913_; 
v_a_903_ = lean_ctor_get(v_fst_898_, 0);
v_isSharedCheck_913_ = !lean_is_exclusive(v_fst_898_);
if (v_isSharedCheck_913_ == 0)
{
v___x_905_ = v_fst_898_;
v_isShared_906_ = v_isSharedCheck_913_;
goto v_resetjp_904_;
}
else
{
lean_inc(v_a_903_);
lean_dec(v_fst_898_);
v___x_905_ = lean_box(0);
v_isShared_906_ = v_isSharedCheck_913_;
goto v_resetjp_904_;
}
v_resetjp_904_:
{
lean_object* v___x_908_; 
if (v_isShared_906_ == 0)
{
v___x_908_ = v___x_905_;
goto v_reusejp_907_;
}
else
{
lean_object* v_reuseFailAlloc_912_; 
v_reuseFailAlloc_912_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_912_, 0, v_a_903_);
v___x_908_ = v_reuseFailAlloc_912_;
goto v_reusejp_907_;
}
v_reusejp_907_:
{
lean_object* v___x_910_; 
if (v_isShared_902_ == 0)
{
lean_ctor_set(v___x_901_, 0, v___x_908_);
v___x_910_ = v___x_901_;
goto v_reusejp_909_;
}
else
{
lean_object* v_reuseFailAlloc_911_; 
v_reuseFailAlloc_911_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_911_, 0, v___x_908_);
lean_ctor_set(v_reuseFailAlloc_911_, 1, v_snd_899_);
v___x_910_ = v_reuseFailAlloc_911_;
goto v_reusejp_909_;
}
v_reusejp_909_:
{
return v___x_910_;
}
}
}
}
}
else
{
lean_object* v_a_916_; lean_object* v___x_918_; uint8_t v_isShared_919_; uint8_t v_isSharedCheck_939_; 
v_a_916_ = lean_ctor_get(v_fst_898_, 0);
v_isSharedCheck_939_ = !lean_is_exclusive(v_fst_898_);
if (v_isSharedCheck_939_ == 0)
{
v___x_918_ = v_fst_898_;
v_isShared_919_ = v_isSharedCheck_939_;
goto v_resetjp_917_;
}
else
{
lean_inc(v_a_916_);
lean_dec(v_fst_898_);
v___x_918_ = lean_box(0);
v_isShared_919_ = v_isSharedCheck_939_;
goto v_resetjp_917_;
}
v_resetjp_917_:
{
lean_object* v_fst_920_; lean_object* v___x_922_; uint8_t v_isShared_923_; uint8_t v_isSharedCheck_937_; 
v_fst_920_ = lean_ctor_get(v_a_916_, 0);
v_isSharedCheck_937_ = !lean_is_exclusive(v_a_916_);
if (v_isSharedCheck_937_ == 0)
{
lean_object* v_unused_938_; 
v_unused_938_ = lean_ctor_get(v_a_916_, 1);
lean_dec(v_unused_938_);
v___x_922_ = v_a_916_;
v_isShared_923_ = v_isSharedCheck_937_;
goto v_resetjp_921_;
}
else
{
lean_inc(v_fst_920_);
lean_dec(v_a_916_);
v___x_922_ = lean_box(0);
v_isShared_923_ = v_isSharedCheck_937_;
goto v_resetjp_921_;
}
v_resetjp_921_:
{
if (lean_obj_tag(v_fst_920_) == 0)
{
lean_object* v_snd_924_; lean_object* v___x_925_; lean_object* v___x_927_; 
lean_del_object(v___x_918_);
v_snd_924_ = lean_ctor_get(v___x_897_, 1);
lean_inc(v_snd_924_);
lean_dec_ref(v___x_897_);
v___x_925_ = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather___closed__0));
if (v_isShared_923_ == 0)
{
lean_ctor_set(v___x_922_, 1, v_snd_924_);
lean_ctor_set(v___x_922_, 0, v___x_925_);
v___x_927_ = v___x_922_;
goto v_reusejp_926_;
}
else
{
lean_object* v_reuseFailAlloc_928_; 
v_reuseFailAlloc_928_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_928_, 0, v___x_925_);
lean_ctor_set(v_reuseFailAlloc_928_, 1, v_snd_924_);
v___x_927_ = v_reuseFailAlloc_928_;
goto v_reusejp_926_;
}
v_reusejp_926_:
{
return v___x_927_;
}
}
else
{
lean_object* v_snd_929_; lean_object* v_val_930_; lean_object* v___x_932_; 
v_snd_929_ = lean_ctor_get(v___x_897_, 1);
lean_inc(v_snd_929_);
lean_dec_ref(v___x_897_);
v_val_930_ = lean_ctor_get(v_fst_920_, 0);
lean_inc(v_val_930_);
lean_dec_ref_known(v_fst_920_, 1);
if (v_isShared_919_ == 0)
{
lean_ctor_set(v___x_918_, 0, v_val_930_);
v___x_932_ = v___x_918_;
goto v_reusejp_931_;
}
else
{
lean_object* v_reuseFailAlloc_936_; 
v_reuseFailAlloc_936_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_936_, 0, v_val_930_);
v___x_932_ = v_reuseFailAlloc_936_;
goto v_reusejp_931_;
}
v_reusejp_931_:
{
lean_object* v___x_934_; 
if (v_isShared_923_ == 0)
{
lean_ctor_set(v___x_922_, 1, v_snd_929_);
lean_ctor_set(v___x_922_, 0, v___x_932_);
v___x_934_ = v___x_922_;
goto v_reusejp_933_;
}
else
{
lean_object* v_reuseFailAlloc_935_; 
v_reuseFailAlloc_935_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_935_, 0, v___x_932_);
lean_ctor_set(v_reuseFailAlloc_935_, 1, v_snd_929_);
v___x_934_ = v_reuseFailAlloc_935_;
goto v_reusejp_933_;
}
v_reusejp_933_:
{
return v___x_934_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather___boxed(lean_object* v_field_940_, lean_object* v_limits_941_, lean_object* v_dense_942_, lean_object* v_column_943_, lean_object* v_last_944_, lean_object* v_factor_945_, lean_object* v_a_946_){
_start:
{
uint64_t v_field_boxed_947_; uint64_t v_factor_boxed_948_; lean_object* v_res_949_; 
v_field_boxed_947_ = lean_unbox_uint64(v_field_940_);
lean_dec_ref(v_field_940_);
v_factor_boxed_948_ = lean_unbox_uint64(v_factor_945_);
lean_dec_ref(v_factor_945_);
v_res_949_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather(v_field_boxed_947_, v_limits_941_, v_dense_942_, v_column_943_, v_last_944_, v_factor_boxed_948_, v_a_946_);
lean_dec(v_last_944_);
lean_dec_ref(v_limits_941_);
return v_res_949_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0(uint64_t v_field_950_, lean_object* v_limits_951_, lean_object* v___x_952_, uint64_t v_factor_953_, lean_object* v_range_954_, lean_object* v_b_955_, lean_object* v_i_956_, lean_object* v_hs_957_, lean_object* v_hl_958_, lean_object* v___y_959_){
_start:
{
lean_object* v___x_960_; 
v___x_960_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg(v_field_950_, v_limits_951_, v___x_952_, v_factor_953_, v_range_954_, v_b_955_, v_i_956_, v___y_959_);
return v___x_960_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___boxed(lean_object* v_field_961_, lean_object* v_limits_962_, lean_object* v___x_963_, lean_object* v_factor_964_, lean_object* v_range_965_, lean_object* v_b_966_, lean_object* v_i_967_, lean_object* v_hs_968_, lean_object* v_hl_969_, lean_object* v___y_970_){
_start:
{
uint64_t v_field_boxed_971_; uint64_t v_factor_boxed_972_; lean_object* v_res_973_; 
v_field_boxed_971_ = lean_unbox_uint64(v_field_961_);
lean_dec_ref(v_field_961_);
v_factor_boxed_972_ = lean_unbox_uint64(v_factor_964_);
lean_dec_ref(v_factor_964_);
v_res_973_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0(v_field_boxed_971_, v_limits_962_, v___x_963_, v_factor_boxed_972_, v_range_965_, v_b_966_, v_i_967_, v_hs_968_, v_hl_969_, v___y_970_);
lean_dec_ref(v_range_965_);
lean_dec(v___x_963_);
lean_dec_ref(v_limits_962_);
return v_res_973_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___redArg(lean_object* v___x_974_, lean_object* v_targets_975_, uint64_t v_field_976_, lean_object* v_limits_977_, lean_object* v_columns_978_, lean_object* v_range_979_, lean_object* v_b_980_, lean_object* v_i_981_, lean_object* v___y_982_){
_start:
{
lean_object* v_stop_983_; lean_object* v_step_984_; uint8_t v___x_985_; 
v_stop_983_ = lean_ctor_get(v_range_979_, 1);
v_step_984_ = lean_ctor_get(v_range_979_, 2);
v___x_985_ = lean_nat_dec_lt(v_i_981_, v_stop_983_);
if (v___x_985_ == 0)
{
lean_object* v___x_986_; lean_object* v___x_987_; 
lean_dec(v_i_981_);
v___x_986_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_986_, 0, v_b_980_);
v___x_987_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_987_, 0, v___x_986_);
lean_ctor_set(v___x_987_, 1, v___y_982_);
return v___x_987_;
}
else
{
lean_object* v___x_988_; lean_object* v___x_989_; lean_object* v___x_990_; lean_object* v___x_991_; lean_object* v_fst_992_; 
v___x_988_ = lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
v___x_989_ = lean_nat_add(v___x_974_, v_i_981_);
v___x_990_ = lean_array_get_borrowed(v___x_988_, v_targets_975_, v_i_981_);
v___x_991_ = lp_Hex_Hex_Groebner_Matrix_validate(v_field_976_, v_limits_977_, v_columns_978_, v___x_989_, v___x_990_, v___y_982_);
v_fst_992_ = lean_ctor_get(v___x_991_, 0);
lean_inc(v_fst_992_);
if (lean_obj_tag(v_fst_992_) == 0)
{
lean_dec_ref_known(v_fst_992_, 1);
lean_dec(v_i_981_);
return v___x_991_;
}
else
{
lean_object* v_snd_993_; lean_object* v___x_994_; lean_object* v___x_995_; 
lean_dec_ref_known(v_fst_992_, 1);
v_snd_993_ = lean_ctor_get(v___x_991_, 1);
lean_inc(v_snd_993_);
lean_dec_ref(v___x_991_);
v___x_994_ = lean_box(0);
v___x_995_ = lean_nat_add(v_i_981_, v_step_984_);
lean_dec(v_i_981_);
v_b_980_ = v___x_994_;
v_i_981_ = v___x_995_;
v___y_982_ = v_snd_993_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___redArg___boxed(lean_object* v___x_997_, lean_object* v_targets_998_, lean_object* v_field_999_, lean_object* v_limits_1000_, lean_object* v_columns_1001_, lean_object* v_range_1002_, lean_object* v_b_1003_, lean_object* v_i_1004_, lean_object* v___y_1005_){
_start:
{
uint64_t v_field_boxed_1006_; lean_object* v_res_1007_; 
v_field_boxed_1006_ = lean_unbox_uint64(v_field_999_);
lean_dec_ref(v_field_999_);
v_res_1007_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___redArg(v___x_997_, v_targets_998_, v_field_boxed_1006_, v_limits_1000_, v_columns_1001_, v_range_1002_, v_b_1003_, v_i_1004_, v___y_1005_);
lean_dec_ref(v_range_1002_);
lean_dec(v_columns_1001_);
lean_dec_ref(v_limits_1000_);
lean_dec_ref(v_targets_998_);
lean_dec(v___x_997_);
return v_res_1007_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(lean_object* v_xs_1008_, lean_object* v_i_1009_){
_start:
{
lean_object* v___x_1010_; uint8_t v___x_1011_; 
v___x_1010_ = lean_byte_array_size(v_xs_1008_);
v___x_1011_ = lean_nat_dec_lt(v_i_1009_, v___x_1010_);
return v___x_1011_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0___boxed(lean_object* v_xs_1012_, lean_object* v_i_1013_){
_start:
{
uint8_t v_res_1014_; lean_object* v_r_1015_; 
v_res_1014_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_xs_1012_, v_i_1013_);
lean_dec(v_i_1013_);
lean_dec_ref(v_xs_1012_);
v_r_1015_ = lean_box(v_res_1014_);
return v_r_1015_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___redArg(lean_object* v_pivots_1016_, lean_object* v_slots_1017_, lean_object* v_range_1018_, lean_object* v_b_1019_, lean_object* v_i_1020_, lean_object* v___y_1021_){
_start:
{
lean_object* v_stop_1022_; lean_object* v_step_1023_; lean_object* v_a_1025_; lean_object* v_snd_1026_; uint8_t v___x_1029_; 
v_stop_1022_ = lean_ctor_get(v_range_1018_, 1);
v_step_1023_ = lean_ctor_get(v_range_1018_, 2);
v___x_1029_ = lean_nat_dec_lt(v_i_1020_, v_stop_1022_);
if (v___x_1029_ == 0)
{
lean_object* v___x_1030_; lean_object* v___x_1031_; 
lean_dec(v_i_1020_);
v___x_1030_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1030_, 0, v_b_1019_);
v___x_1031_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1031_, 0, v___x_1030_);
lean_ctor_set(v___x_1031_, 1, v___y_1021_);
return v___x_1031_;
}
else
{
lean_object* v_reducerRank_1032_; lean_object* v___x_1033_; lean_object* v___x_1034_; uint64_t v___y_1036_; uint64_t v___y_1043_; uint8_t v___y_1044_; uint8_t v___x_1049_; lean_object* v___x_1050_; lean_object* v_offset_1051_; uint64_t v___y_1053_; uint8_t v___y_1054_; uint64_t v___y_1067_; uint8_t v___y_1068_; uint8_t v___y_1081_; uint8_t v___y_1090_; lean_object* v___x_1120_; lean_object* v___x_1121_; uint8_t v___x_1122_; 
v_reducerRank_1032_ = lean_unsigned_to_nat(0u);
v___x_1033_ = lean_unsigned_to_nat(1u);
v___x_1034_ = lp_Hex_Hex_Groebner_instInhabitedPivot_default;
v___x_1049_ = 0;
v___x_1050_ = lean_unsigned_to_nat(4u);
v_offset_1051_ = lean_nat_mul(v_i_1020_, v___x_1050_);
v___x_1120_ = lean_nat_add(v_offset_1051_, v___x_1050_);
v___x_1121_ = lean_byte_array_size(v_slots_1017_);
v___x_1122_ = lean_nat_dec_le(v___x_1120_, v___x_1121_);
if (v___x_1122_ == 0)
{
lean_dec(v___x_1120_);
v___y_1090_ = v___x_1122_;
goto v___jp_1089_;
}
else
{
size_t v___x_1123_; lean_object* v___x_1124_; uint8_t v___x_1125_; 
v___x_1123_ = lean_usize_of_nat(v___x_1120_);
v___x_1124_ = lean_usize_to_nat(v___x_1123_);
v___x_1125_ = lean_nat_dec_eq(v___x_1124_, v___x_1120_);
lean_dec(v___x_1120_);
lean_dec(v___x_1124_);
v___y_1090_ = v___x_1125_;
goto v___jp_1089_;
}
v___jp_1035_:
{
lean_object* v___x_1037_; uint8_t v___x_1038_; 
v___x_1037_ = lean_uint64_to_nat(v___y_1036_);
v___x_1038_ = lean_nat_dec_eq(v___x_1037_, v_reducerRank_1032_);
if (v___x_1038_ == 0)
{
lean_object* v___x_1039_; lean_object* v___x_1040_; lean_object* v___x_1041_; 
v___x_1039_ = lean_nat_sub(v___x_1037_, v___x_1033_);
lean_dec(v___x_1037_);
v___x_1040_ = lean_array_get_borrowed(v___x_1034_, v_pivots_1016_, v___x_1039_);
lean_dec(v___x_1039_);
lean_inc(v___x_1040_);
v___x_1041_ = lean_array_push(v_b_1019_, v___x_1040_);
v_a_1025_ = v___x_1041_;
v_snd_1026_ = v___y_1021_;
goto v___jp_1024_;
}
else
{
lean_dec(v___x_1037_);
v_a_1025_ = v_b_1019_;
v_snd_1026_ = v___y_1021_;
goto v___jp_1024_;
}
}
v___jp_1042_:
{
uint64_t v___x_1045_; uint64_t v___x_1046_; uint64_t v___x_1047_; uint64_t v___x_1048_; 
v___x_1045_ = lean_uint8_to_uint64(v___y_1044_);
v___x_1046_ = 24ULL;
v___x_1047_ = lean_uint64_shift_left(v___x_1045_, v___x_1046_);
v___x_1048_ = lean_uint64_lor(v___y_1043_, v___x_1047_);
v___y_1036_ = v___x_1048_;
goto v___jp_1035_;
}
v___jp_1052_:
{
uint64_t v___x_1055_; uint64_t v___x_1056_; uint64_t v___x_1057_; uint64_t v___x_1058_; lean_object* v___x_1059_; lean_object* v___x_1060_; uint8_t v___x_1061_; 
v___x_1055_ = lean_uint8_to_uint64(v___y_1054_);
v___x_1056_ = 16ULL;
v___x_1057_ = lean_uint64_shift_left(v___x_1055_, v___x_1056_);
v___x_1058_ = lean_uint64_lor(v___y_1053_, v___x_1057_);
v___x_1059_ = lean_unsigned_to_nat(3u);
v___x_1060_ = lean_nat_add(v_offset_1051_, v___x_1059_);
lean_dec(v_offset_1051_);
v___x_1061_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_slots_1017_, v___x_1060_);
if (v___x_1061_ == 0)
{
lean_object* v___x_1062_; lean_object* v___x_1063_; uint8_t v___x_1064_; 
lean_dec(v___x_1060_);
v___x_1062_ = lean_box(v___x_1049_);
v___x_1063_ = l_outOfBounds___redArg(v___x_1062_);
lean_dec(v___x_1062_);
v___x_1064_ = lean_unbox(v___x_1063_);
lean_dec(v___x_1063_);
v___y_1043_ = v___x_1058_;
v___y_1044_ = v___x_1064_;
goto v___jp_1042_;
}
else
{
uint8_t v___x_1065_; 
v___x_1065_ = lean_byte_array_fget(v_slots_1017_, v___x_1060_);
lean_dec(v___x_1060_);
v___y_1043_ = v___x_1058_;
v___y_1044_ = v___x_1065_;
goto v___jp_1042_;
}
}
v___jp_1066_:
{
uint64_t v___x_1069_; uint64_t v___x_1070_; uint64_t v___x_1071_; uint64_t v___x_1072_; lean_object* v___x_1073_; lean_object* v___x_1074_; uint8_t v___x_1075_; 
v___x_1069_ = lean_uint8_to_uint64(v___y_1068_);
v___x_1070_ = 8ULL;
v___x_1071_ = lean_uint64_shift_left(v___x_1069_, v___x_1070_);
v___x_1072_ = lean_uint64_lor(v___y_1067_, v___x_1071_);
v___x_1073_ = lean_unsigned_to_nat(2u);
v___x_1074_ = lean_nat_add(v_offset_1051_, v___x_1073_);
v___x_1075_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_slots_1017_, v___x_1074_);
if (v___x_1075_ == 0)
{
lean_object* v___x_1076_; lean_object* v___x_1077_; uint8_t v___x_1078_; 
lean_dec(v___x_1074_);
v___x_1076_ = lean_box(v___x_1049_);
v___x_1077_ = l_outOfBounds___redArg(v___x_1076_);
lean_dec(v___x_1076_);
v___x_1078_ = lean_unbox(v___x_1077_);
lean_dec(v___x_1077_);
v___y_1053_ = v___x_1072_;
v___y_1054_ = v___x_1078_;
goto v___jp_1052_;
}
else
{
uint8_t v___x_1079_; 
v___x_1079_ = lean_byte_array_fget(v_slots_1017_, v___x_1074_);
lean_dec(v___x_1074_);
v___y_1053_ = v___x_1072_;
v___y_1054_ = v___x_1079_;
goto v___jp_1052_;
}
}
v___jp_1080_:
{
uint64_t v_a_1082_; lean_object* v___x_1083_; uint8_t v___x_1084_; 
v_a_1082_ = lean_uint8_to_uint64(v___y_1081_);
v___x_1083_ = lean_nat_add(v_offset_1051_, v___x_1033_);
v___x_1084_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_slots_1017_, v___x_1083_);
if (v___x_1084_ == 0)
{
lean_object* v___x_1085_; lean_object* v___x_1086_; uint8_t v___x_1087_; 
lean_dec(v___x_1083_);
v___x_1085_ = lean_box(v___x_1049_);
v___x_1086_ = l_outOfBounds___redArg(v___x_1085_);
lean_dec(v___x_1085_);
v___x_1087_ = lean_unbox(v___x_1086_);
lean_dec(v___x_1086_);
v___y_1067_ = v_a_1082_;
v___y_1068_ = v___x_1087_;
goto v___jp_1066_;
}
else
{
uint8_t v___x_1088_; 
v___x_1088_ = lean_byte_array_fget(v_slots_1017_, v___x_1083_);
lean_dec(v___x_1083_);
v___y_1067_ = v_a_1082_;
v___y_1068_ = v___x_1088_;
goto v___jp_1066_;
}
}
v___jp_1089_:
{
if (v___y_1090_ == 0)
{
uint8_t v___x_1091_; 
v___x_1091_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_slots_1017_, v_offset_1051_);
if (v___x_1091_ == 0)
{
lean_object* v___x_1092_; lean_object* v___x_1093_; uint8_t v___x_1094_; 
v___x_1092_ = lean_box(v___x_1049_);
v___x_1093_ = l_outOfBounds___redArg(v___x_1092_);
lean_dec(v___x_1092_);
v___x_1094_ = lean_unbox(v___x_1093_);
lean_dec(v___x_1093_);
v___y_1081_ = v___x_1094_;
goto v___jp_1080_;
}
else
{
uint8_t v___x_1095_; 
v___x_1095_ = lean_byte_array_fget(v_slots_1017_, v_offset_1051_);
v___y_1081_ = v___x_1095_;
goto v___jp_1080_;
}
}
else
{
size_t v_pos_1096_; uint8_t v___x_1097_; uint64_t v_a_1098_; size_t v___x_1099_; size_t v___x_1100_; uint8_t v___x_1101_; uint64_t v___x_1102_; uint64_t v___x_1103_; uint64_t v___x_1104_; uint64_t v___x_1105_; size_t v___x_1106_; size_t v___x_1107_; uint8_t v___x_1108_; uint64_t v___x_1109_; uint64_t v___x_1110_; uint64_t v___x_1111_; uint64_t v___x_1112_; size_t v___x_1113_; size_t v___x_1114_; uint8_t v___x_1115_; uint64_t v___x_1116_; uint64_t v___x_1117_; uint64_t v___x_1118_; uint64_t v___x_1119_; 
v_pos_1096_ = lean_usize_of_nat(v_offset_1051_);
lean_dec(v_offset_1051_);
v___x_1097_ = lean_byte_array_uget(v_slots_1017_, v_pos_1096_);
v_a_1098_ = lean_uint8_to_uint64(v___x_1097_);
v___x_1099_ = ((size_t)1ULL);
v___x_1100_ = lean_usize_add(v_pos_1096_, v___x_1099_);
v___x_1101_ = lean_byte_array_uget(v_slots_1017_, v___x_1100_);
v___x_1102_ = lean_uint8_to_uint64(v___x_1101_);
v___x_1103_ = 8ULL;
v___x_1104_ = lean_uint64_shift_left(v___x_1102_, v___x_1103_);
v___x_1105_ = lean_uint64_lor(v_a_1098_, v___x_1104_);
v___x_1106_ = ((size_t)2ULL);
v___x_1107_ = lean_usize_add(v_pos_1096_, v___x_1106_);
v___x_1108_ = lean_byte_array_uget(v_slots_1017_, v___x_1107_);
v___x_1109_ = lean_uint8_to_uint64(v___x_1108_);
v___x_1110_ = 16ULL;
v___x_1111_ = lean_uint64_shift_left(v___x_1109_, v___x_1110_);
v___x_1112_ = lean_uint64_lor(v___x_1105_, v___x_1111_);
v___x_1113_ = ((size_t)3ULL);
v___x_1114_ = lean_usize_add(v_pos_1096_, v___x_1113_);
v___x_1115_ = lean_byte_array_uget(v_slots_1017_, v___x_1114_);
v___x_1116_ = lean_uint8_to_uint64(v___x_1115_);
v___x_1117_ = 24ULL;
v___x_1118_ = lean_uint64_shift_left(v___x_1116_, v___x_1117_);
v___x_1119_ = lean_uint64_lor(v___x_1112_, v___x_1118_);
v___y_1036_ = v___x_1119_;
goto v___jp_1035_;
}
}
}
v___jp_1024_:
{
lean_object* v___x_1027_; 
v___x_1027_ = lean_nat_add(v_i_1020_, v_step_1023_);
lean_dec(v_i_1020_);
v_b_1019_ = v_a_1025_;
v_i_1020_ = v___x_1027_;
v___y_1021_ = v_snd_1026_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___redArg___boxed(lean_object* v_pivots_1126_, lean_object* v_slots_1127_, lean_object* v_range_1128_, lean_object* v_b_1129_, lean_object* v_i_1130_, lean_object* v___y_1131_){
_start:
{
lean_object* v_res_1132_; 
v_res_1132_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___redArg(v_pivots_1126_, v_slots_1127_, v_range_1128_, v_b_1129_, v_i_1130_, v___y_1131_);
lean_dec_ref(v_range_1128_);
lean_dec_ref(v_slots_1127_);
lean_dec_ref(v_pivots_1126_);
return v_res_1132_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___redArg(lean_object* v_reducers_1133_, uint64_t v_field_1134_, lean_object* v_limits_1135_, lean_object* v_columns_1136_, lean_object* v_range_1137_, lean_object* v_b_1138_, lean_object* v_i_1139_, lean_object* v___y_1140_){
_start:
{
lean_object* v_stop_1141_; lean_object* v_step_1142_; uint8_t v___x_1143_; 
v_stop_1141_ = lean_ctor_get(v_range_1137_, 1);
v_step_1142_ = lean_ctor_get(v_range_1137_, 2);
v___x_1143_ = lean_nat_dec_lt(v_i_1139_, v_stop_1141_);
if (v___x_1143_ == 0)
{
lean_object* v___x_1144_; lean_object* v___x_1145_; 
lean_dec(v_i_1139_);
v___x_1144_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1144_, 0, v_b_1138_);
v___x_1145_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1145_, 0, v___x_1144_);
lean_ctor_set(v___x_1145_, 1, v___y_1140_);
return v___x_1145_;
}
else
{
lean_object* v___x_1146_; lean_object* v___x_1147_; lean_object* v___x_1148_; lean_object* v_fst_1149_; 
v___x_1146_ = lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
v___x_1147_ = lean_array_get_borrowed(v___x_1146_, v_reducers_1133_, v_i_1139_);
lean_inc(v_i_1139_);
v___x_1148_ = lp_Hex_Hex_Groebner_Matrix_validate(v_field_1134_, v_limits_1135_, v_columns_1136_, v_i_1139_, v___x_1147_, v___y_1140_);
v_fst_1149_ = lean_ctor_get(v___x_1148_, 0);
lean_inc(v_fst_1149_);
if (lean_obj_tag(v_fst_1149_) == 0)
{
lean_dec_ref_known(v_fst_1149_, 1);
lean_dec(v_i_1139_);
return v___x_1148_;
}
else
{
lean_object* v_snd_1150_; lean_object* v___x_1151_; lean_object* v___x_1152_; 
lean_dec_ref_known(v_fst_1149_, 1);
v_snd_1150_ = lean_ctor_get(v___x_1148_, 1);
lean_inc(v_snd_1150_);
lean_dec_ref(v___x_1148_);
v___x_1151_ = lean_box(0);
v___x_1152_ = lean_nat_add(v_i_1139_, v_step_1142_);
lean_dec(v_i_1139_);
v_b_1138_ = v___x_1151_;
v_i_1139_ = v___x_1152_;
v___y_1140_ = v_snd_1150_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___redArg___boxed(lean_object* v_reducers_1154_, lean_object* v_field_1155_, lean_object* v_limits_1156_, lean_object* v_columns_1157_, lean_object* v_range_1158_, lean_object* v_b_1159_, lean_object* v_i_1160_, lean_object* v___y_1161_){
_start:
{
uint64_t v_field_boxed_1162_; lean_object* v_res_1163_; 
v_field_boxed_1162_ = lean_unbox_uint64(v_field_1155_);
lean_dec_ref(v_field_1155_);
v_res_1163_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___redArg(v_reducers_1154_, v_field_boxed_1162_, v_limits_1156_, v_columns_1157_, v_range_1158_, v_b_1159_, v_i_1160_, v___y_1161_);
lean_dec_ref(v_range_1158_);
lean_dec(v_columns_1157_);
lean_dec_ref(v_limits_1156_);
lean_dec_ref(v_reducers_1154_);
return v_res_1163_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0(void){
_start:
{
lean_object* v___x_1164_; lean_object* v___x_1165_; lean_object* v___x_1166_; 
v___x_1164_ = l_System_Platform_numBits;
v___x_1165_ = lean_unsigned_to_nat(2u);
v___x_1166_ = lean_nat_pow(v___x_1165_, v___x_1164_);
return v___x_1166_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg(uint8_t v_width_1167_, lean_object* v_limits_1168_, lean_object* v___y_1169_, uint64_t v_inv_1170_, uint64_t v_field_1171_, uint64_t v_ctx_1172_, lean_object* v_range_1173_, lean_object* v_b_1174_, lean_object* v_i_1175_, lean_object* v___y_1176_){
_start:
{
lean_object* v_a_1178_; lean_object* v_snd_1179_; lean_object* v___y_1183_; lean_object* v_stop_1185_; lean_object* v_step_1186_; lean_object* v_a_1188_; lean_object* v_snd_1189_; lean_object* v___y_1193_; lean_object* v___y_1194_; lean_object* v___y_1195_; uint8_t v___x_1197_; 
v_stop_1185_ = lean_ctor_get(v_range_1173_, 1);
v_step_1186_ = lean_ctor_get(v_range_1173_, 2);
v___x_1197_ = lean_nat_dec_lt(v_i_1175_, v_stop_1185_);
if (v___x_1197_ == 0)
{
lean_object* v___x_1198_; lean_object* v___x_1199_; 
lean_dec(v_i_1175_);
v___x_1198_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1198_, 0, v_b_1174_);
v___x_1199_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1199_, 0, v___x_1198_);
lean_ctor_set(v___x_1199_, 1, v___y_1176_);
return v___x_1199_;
}
else
{
lean_object* v_fst_1200_; lean_object* v_snd_1201_; lean_object* v___x_1203_; uint8_t v_isShared_1204_; uint8_t v_isSharedCheck_1416_; 
v_fst_1200_ = lean_ctor_get(v_b_1174_, 0);
v_snd_1201_ = lean_ctor_get(v_b_1174_, 1);
v_isSharedCheck_1416_ = !lean_is_exclusive(v_b_1174_);
if (v_isSharedCheck_1416_ == 0)
{
v___x_1203_ = v_b_1174_;
v_isShared_1204_ = v_isSharedCheck_1416_;
goto v_resetjp_1202_;
}
else
{
lean_inc(v_snd_1201_);
lean_inc(v_fst_1200_);
lean_dec(v_b_1174_);
v___x_1203_ = lean_box(0);
v_isShared_1204_ = v_isSharedCheck_1416_;
goto v_resetjp_1202_;
}
v_resetjp_1202_:
{
lean_object* v___f_1205_; lean_object* v___f_1206_; lean_object* v___x_1207_; uint64_t v___y_1209_; lean_object* v___y_1210_; lean_object* v___y_1211_; lean_object* v___y_1212_; lean_object* v___x_1226_; uint64_t v___y_1228_; lean_object* v___y_1229_; lean_object* v___y_1230_; lean_object* v___y_1231_; uint64_t v___y_1235_; uint64_t v_value_1236_; lean_object* v___y_1237_; uint64_t v___y_1270_; uint64_t v___y_1307_; uint8_t v___y_1308_; uint64_t v___y_1314_; uint8_t v___y_1315_; uint8_t v___x_1320_; uint64_t v___y_1322_; lean_object* v___y_1323_; uint8_t v___y_1324_; lean_object* v___y_1337_; uint64_t v___y_1338_; uint8_t v___y_1339_; lean_object* v___y_1352_; uint8_t v___y_1353_; lean_object* v___y_1368_; uint8_t v___y_1369_; lean_object* v___y_1407_; 
v___f_1205_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__0));
v___f_1206_ = ((lean_object*)(lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather_spec__0___redArg___closed__1));
v___x_1207_ = lean_unsigned_to_nat(1u);
v___x_1226_ = lean_unsigned_to_nat(4u);
v___x_1320_ = 0;
switch(v_width_1167_)
{
case 0:
{
v___y_1407_ = v___x_1207_;
goto v___jp_1406_;
}
case 1:
{
lean_object* v___x_1415_; 
v___x_1415_ = lean_unsigned_to_nat(2u);
v___y_1407_ = v___x_1415_;
goto v___jp_1406_;
}
default: 
{
v___y_1407_ = v___x_1226_;
goto v___jp_1406_;
}
}
v___jp_1208_:
{
lean_object* v_offset_1213_; uint8_t v___x_1214_; lean_object* v_data_1215_; 
v_offset_1213_ = lean_nat_mul(v_i_1175_, v___y_1212_);
v___x_1214_ = lean_uint64_to_uint8(v___y_1209_);
v_data_1215_ = lean_byte_array_set(v_fst_1200_, v_offset_1213_, v___x_1214_);
switch(v_width_1167_)
{
case 0:
{
lean_dec(v_offset_1213_);
v___y_1193_ = v___y_1211_;
v___y_1194_ = v___y_1210_;
v___y_1195_ = v_data_1215_;
goto v___jp_1192_;
}
case 1:
{
lean_object* v___x_1216_; lean_object* v___x_1217_; 
v___x_1216_ = lean_nat_add(v_offset_1213_, v___x_1207_);
lean_dec(v_offset_1213_);
v___x_1217_ = lean_byte_array_set(v_data_1215_, v___x_1216_, v___x_1214_);
lean_dec(v___x_1216_);
v___y_1193_ = v___y_1211_;
v___y_1194_ = v___y_1210_;
v___y_1195_ = v___x_1217_;
goto v___jp_1192_;
}
default: 
{
lean_object* v___x_1218_; lean_object* v___x_1219_; lean_object* v___x_1220_; lean_object* v___x_1221_; lean_object* v___x_1222_; lean_object* v___x_1223_; lean_object* v___x_1224_; lean_object* v___x_1225_; 
v___x_1218_ = lean_nat_add(v_offset_1213_, v___x_1207_);
v___x_1219_ = lean_byte_array_set(v_data_1215_, v___x_1218_, v___x_1214_);
lean_dec(v___x_1218_);
v___x_1220_ = lean_unsigned_to_nat(2u);
v___x_1221_ = lean_nat_add(v_offset_1213_, v___x_1220_);
v___x_1222_ = lean_byte_array_set(v___x_1219_, v___x_1221_, v___x_1214_);
lean_dec(v___x_1221_);
v___x_1223_ = lean_unsigned_to_nat(3u);
v___x_1224_ = lean_nat_add(v_offset_1213_, v___x_1223_);
lean_dec(v_offset_1213_);
v___x_1225_ = lean_byte_array_set(v___x_1222_, v___x_1224_, v___x_1214_);
lean_dec(v___x_1224_);
v___y_1193_ = v___y_1211_;
v___y_1194_ = v___y_1210_;
v___y_1195_ = v___x_1225_;
goto v___jp_1192_;
}
}
}
v___jp_1227_:
{
lean_object* v___x_1232_; 
v___x_1232_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1232_, 0, v___y_1229_);
lean_ctor_set(v___x_1232_, 1, v___y_1231_);
switch(v_width_1167_)
{
case 0:
{
v___y_1209_ = v___y_1228_;
v___y_1210_ = v___x_1232_;
v___y_1211_ = v___y_1230_;
v___y_1212_ = v___x_1207_;
goto v___jp_1208_;
}
case 1:
{
lean_object* v___x_1233_; 
v___x_1233_ = lean_unsigned_to_nat(2u);
v___y_1209_ = v___y_1228_;
v___y_1210_ = v___x_1232_;
v___y_1211_ = v___y_1230_;
v___y_1212_ = v___x_1233_;
goto v___jp_1208_;
}
default: 
{
v___y_1209_ = v___y_1228_;
v___y_1210_ = v___x_1232_;
v___y_1211_ = v___y_1230_;
v___y_1212_ = v___x_1226_;
goto v___jp_1208_;
}
}
}
v___jp_1234_:
{
lean_object* v_columns_1238_; lean_object* v_coefficients_1239_; uint64_t v___x_1240_; uint8_t v___x_1241_; lean_object* v_data_1242_; uint64_t v___x_1243_; uint64_t v___x_1244_; uint8_t v___x_1245_; lean_object* v___x_1246_; uint64_t v___x_1247_; uint64_t v___x_1248_; uint8_t v___x_1249_; lean_object* v___x_1250_; uint64_t v___x_1251_; uint64_t v___x_1252_; uint8_t v___x_1253_; lean_object* v___x_1254_; uint8_t v___x_1255_; lean_object* v_data_1256_; 
v_columns_1238_ = lean_ctor_get(v_snd_1201_, 0);
lean_inc_ref(v_columns_1238_);
v_coefficients_1239_ = lean_ctor_get(v_snd_1201_, 1);
lean_inc_ref(v_coefficients_1239_);
lean_dec(v_snd_1201_);
v___x_1240_ = lean_uint64_of_nat(v_i_1175_);
v___x_1241_ = lean_uint64_to_uint8(v___x_1240_);
v_data_1242_ = lean_byte_array_push(v_columns_1238_, v___x_1241_);
v___x_1243_ = 8ULL;
v___x_1244_ = lean_uint64_shift_right(v___x_1240_, v___x_1243_);
v___x_1245_ = lean_uint64_to_uint8(v___x_1244_);
v___x_1246_ = lean_byte_array_push(v_data_1242_, v___x_1245_);
v___x_1247_ = 16ULL;
v___x_1248_ = lean_uint64_shift_right(v___x_1240_, v___x_1247_);
v___x_1249_ = lean_uint64_to_uint8(v___x_1248_);
v___x_1250_ = lean_byte_array_push(v___x_1246_, v___x_1249_);
v___x_1251_ = 24ULL;
v___x_1252_ = lean_uint64_shift_right(v___x_1240_, v___x_1251_);
v___x_1253_ = lean_uint64_to_uint8(v___x_1252_);
v___x_1254_ = lean_byte_array_push(v___x_1250_, v___x_1253_);
v___x_1255_ = lean_uint64_to_uint8(v_value_1236_);
v_data_1256_ = lean_byte_array_push(v_coefficients_1239_, v___x_1255_);
switch(v_width_1167_)
{
case 0:
{
v___y_1228_ = v___y_1235_;
v___y_1229_ = v___x_1254_;
v___y_1230_ = v___y_1237_;
v___y_1231_ = v_data_1256_;
goto v___jp_1227_;
}
case 1:
{
uint64_t v___x_1257_; uint8_t v___x_1258_; lean_object* v___x_1259_; 
v___x_1257_ = lean_uint64_shift_right(v_value_1236_, v___x_1243_);
v___x_1258_ = lean_uint64_to_uint8(v___x_1257_);
v___x_1259_ = lean_byte_array_push(v_data_1256_, v___x_1258_);
v___y_1228_ = v___y_1235_;
v___y_1229_ = v___x_1254_;
v___y_1230_ = v___y_1237_;
v___y_1231_ = v___x_1259_;
goto v___jp_1227_;
}
default: 
{
uint64_t v___x_1260_; uint8_t v___x_1261_; lean_object* v___x_1262_; uint64_t v___x_1263_; uint8_t v___x_1264_; lean_object* v___x_1265_; uint64_t v___x_1266_; uint8_t v___x_1267_; lean_object* v___x_1268_; 
v___x_1260_ = lean_uint64_shift_right(v_value_1236_, v___x_1243_);
v___x_1261_ = lean_uint64_to_uint8(v___x_1260_);
v___x_1262_ = lean_byte_array_push(v_data_1256_, v___x_1261_);
v___x_1263_ = lean_uint64_shift_right(v_value_1236_, v___x_1247_);
v___x_1264_ = lean_uint64_to_uint8(v___x_1263_);
v___x_1265_ = lean_byte_array_push(v___x_1262_, v___x_1264_);
v___x_1266_ = lean_uint64_shift_right(v_value_1236_, v___x_1251_);
v___x_1267_ = lean_uint64_to_uint8(v___x_1266_);
v___x_1268_ = lean_byte_array_push(v___x_1265_, v___x_1267_);
v___y_1228_ = v___y_1235_;
v___y_1229_ = v___x_1254_;
v___y_1230_ = v___y_1237_;
v___y_1231_ = v___x_1268_;
goto v___jp_1227_;
}
}
}
v___jp_1269_:
{
uint64_t v___x_1271_; uint8_t v___x_1272_; 
v___x_1271_ = 0ULL;
v___x_1272_ = lean_uint64_dec_eq(v___y_1270_, v___x_1271_);
if (v___x_1272_ == 0)
{
lean_object* v_outputEntries_1273_; uint8_t v___x_1274_; lean_object* v___x_1275_; lean_object* v_fst_1276_; 
lean_del_object(v___x_1203_);
v_outputEntries_1273_ = lean_ctor_get(v_limits_1168_, 3);
v___x_1274_ = 3;
v___x_1275_ = lp_Hex_Hex_Groebner_Matrix_charge(v___x_1274_, v___x_1207_, v_outputEntries_1273_, v___f_1205_, v___f_1206_, v___y_1176_);
v_fst_1276_ = lean_ctor_get(v___x_1275_, 0);
lean_inc(v_fst_1276_);
if (lean_obj_tag(v_fst_1276_) == 0)
{
lean_object* v_snd_1277_; lean_object* v_a_1278_; 
lean_dec(v_snd_1201_);
lean_dec(v_fst_1200_);
lean_dec(v_i_1175_);
v_snd_1277_ = lean_ctor_get(v___x_1275_, 1);
lean_inc(v_snd_1277_);
lean_dec_ref(v___x_1275_);
v_a_1278_ = lean_ctor_get(v_fst_1276_, 0);
lean_inc(v_a_1278_);
lean_dec_ref_known(v_fst_1276_, 1);
v_a_1178_ = v_a_1278_;
v_snd_1179_ = v_snd_1277_;
goto v___jp_1177_;
}
else
{
lean_object* v_snd_1279_; lean_object* v___x_1280_; lean_object* v___x_1281_; lean_object* v_fst_1282_; 
lean_dec_ref_known(v_fst_1276_, 1);
v_snd_1279_ = lean_ctor_get(v___x_1275_, 1);
lean_inc(v_snd_1279_);
lean_dec_ref(v___x_1275_);
v___x_1280_ = lean_nat_add(v___x_1226_, v___y_1169_);
v___x_1281_ = lp_Hex_Hex_Groebner_Matrix_packedBytes(v_limits_1168_, v___x_1280_, v_snd_1279_);
lean_dec(v___x_1280_);
v_fst_1282_ = lean_ctor_get(v___x_1281_, 0);
lean_inc(v_fst_1282_);
if (lean_obj_tag(v_fst_1282_) == 0)
{
lean_object* v_snd_1283_; lean_object* v_a_1284_; 
lean_dec(v_snd_1201_);
lean_dec(v_fst_1200_);
lean_dec(v_i_1175_);
v_snd_1283_ = lean_ctor_get(v___x_1281_, 1);
lean_inc(v_snd_1283_);
lean_dec_ref(v___x_1281_);
v_a_1284_ = lean_ctor_get(v_fst_1282_, 0);
lean_inc(v_a_1284_);
lean_dec_ref_known(v_fst_1282_, 1);
v_a_1178_ = v_a_1284_;
v_snd_1179_ = v_snd_1283_;
goto v___jp_1177_;
}
else
{
lean_object* v_snd_1285_; lean_object* v_columns_1286_; lean_object* v_coefficients_1287_; lean_object* v___x_1288_; lean_object* v___x_1289_; lean_object* v___x_1290_; uint8_t v___x_1291_; 
lean_dec_ref_known(v_fst_1282_, 1);
v_snd_1285_ = lean_ctor_get(v___x_1281_, 1);
lean_inc(v_snd_1285_);
lean_dec_ref(v___x_1281_);
v_columns_1286_ = lean_ctor_get(v_snd_1201_, 0);
v_coefficients_1287_ = lean_ctor_get(v_snd_1201_, 1);
v___x_1288_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0);
v___x_1289_ = lean_byte_array_size(v_columns_1286_);
v___x_1290_ = lean_nat_add(v___x_1289_, v___x_1226_);
v___x_1291_ = lean_nat_dec_le(v___x_1288_, v___x_1290_);
lean_dec(v___x_1290_);
if (v___x_1291_ == 0)
{
lean_object* v___x_1292_; lean_object* v___x_1293_; uint8_t v___x_1294_; 
v___x_1292_ = lean_byte_array_size(v_coefficients_1287_);
v___x_1293_ = lean_nat_add(v___x_1292_, v___y_1169_);
v___x_1294_ = lean_nat_dec_le(v___x_1288_, v___x_1293_);
lean_dec(v___x_1293_);
if (v___x_1294_ == 0)
{
uint64_t v___x_1295_; uint8_t v___x_1296_; 
v___x_1295_ = 1ULL;
v___x_1296_ = lean_uint64_dec_eq(v_inv_1170_, v___x_1295_);
if (v___x_1296_ == 0)
{
lean_object* v___x_1297_; lean_object* v_fst_1298_; 
v___x_1297_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_1168_, v___x_1207_, v_snd_1285_);
v_fst_1298_ = lean_ctor_get(v___x_1297_, 0);
lean_inc(v_fst_1298_);
if (lean_obj_tag(v_fst_1298_) == 0)
{
lean_object* v_snd_1299_; lean_object* v_a_1300_; 
lean_dec(v_snd_1201_);
lean_dec(v_fst_1200_);
lean_dec(v_i_1175_);
v_snd_1299_ = lean_ctor_get(v___x_1297_, 1);
lean_inc(v_snd_1299_);
lean_dec_ref(v___x_1297_);
v_a_1300_ = lean_ctor_get(v_fst_1298_, 0);
lean_inc(v_a_1300_);
lean_dec_ref_known(v_fst_1298_, 1);
v_a_1178_ = v_a_1300_;
v_snd_1179_ = v_snd_1299_;
goto v___jp_1177_;
}
else
{
lean_object* v_snd_1301_; uint64_t v___x_1302_; 
lean_dec_ref_known(v_fst_1298_, 1);
v_snd_1301_ = lean_ctor_get(v___x_1297_, 1);
lean_inc(v_snd_1301_);
lean_dec_ref(v___x_1297_);
v___x_1302_ = lp_Hex_BarrettCtx_mulMod(v_field_1171_, v_ctx_1172_, v___y_1270_, v_inv_1170_);
v___y_1235_ = v___x_1271_;
v_value_1236_ = v___x_1302_;
v___y_1237_ = v_snd_1301_;
goto v___jp_1234_;
}
}
else
{
v___y_1235_ = v___x_1271_;
v_value_1236_ = v___y_1270_;
v___y_1237_ = v_snd_1285_;
goto v___jp_1234_;
}
}
else
{
lean_dec(v_snd_1201_);
lean_dec(v_fst_1200_);
lean_dec(v_i_1175_);
v___y_1183_ = v_snd_1285_;
goto v___jp_1182_;
}
}
else
{
lean_dec(v_snd_1201_);
lean_dec(v_fst_1200_);
lean_dec(v_i_1175_);
v___y_1183_ = v_snd_1285_;
goto v___jp_1182_;
}
}
}
}
else
{
lean_object* v___x_1304_; 
if (v_isShared_1204_ == 0)
{
v___x_1304_ = v___x_1203_;
goto v_reusejp_1303_;
}
else
{
lean_object* v_reuseFailAlloc_1305_; 
v_reuseFailAlloc_1305_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_1305_, 0, v_fst_1200_);
lean_ctor_set(v_reuseFailAlloc_1305_, 1, v_snd_1201_);
v___x_1304_ = v_reuseFailAlloc_1305_;
goto v_reusejp_1303_;
}
v_reusejp_1303_:
{
v_a_1188_ = v___x_1304_;
v_snd_1189_ = v___y_1176_;
goto v___jp_1187_;
}
}
}
v___jp_1306_:
{
uint64_t v___x_1309_; uint64_t v___x_1310_; uint64_t v___x_1311_; uint64_t v___x_1312_; 
v___x_1309_ = lean_uint8_to_uint64(v___y_1308_);
v___x_1310_ = 8ULL;
v___x_1311_ = lean_uint64_shift_left(v___x_1309_, v___x_1310_);
v___x_1312_ = lean_uint64_lor(v___y_1307_, v___x_1311_);
v___y_1270_ = v___x_1312_;
goto v___jp_1269_;
}
v___jp_1313_:
{
uint64_t v___x_1316_; uint64_t v___x_1317_; uint64_t v___x_1318_; uint64_t v___x_1319_; 
v___x_1316_ = lean_uint8_to_uint64(v___y_1315_);
v___x_1317_ = 24ULL;
v___x_1318_ = lean_uint64_shift_left(v___x_1316_, v___x_1317_);
v___x_1319_ = lean_uint64_lor(v___y_1314_, v___x_1318_);
v___y_1270_ = v___x_1319_;
goto v___jp_1269_;
}
v___jp_1321_:
{
uint64_t v___x_1325_; uint64_t v___x_1326_; uint64_t v___x_1327_; uint64_t v___x_1328_; lean_object* v___x_1329_; lean_object* v___x_1330_; uint8_t v___x_1331_; 
v___x_1325_ = lean_uint8_to_uint64(v___y_1324_);
v___x_1326_ = 16ULL;
v___x_1327_ = lean_uint64_shift_left(v___x_1325_, v___x_1326_);
v___x_1328_ = lean_uint64_lor(v___y_1322_, v___x_1327_);
v___x_1329_ = lean_unsigned_to_nat(3u);
v___x_1330_ = lean_nat_add(v___y_1323_, v___x_1329_);
lean_dec(v___y_1323_);
v___x_1331_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_1200_, v___x_1330_);
if (v___x_1331_ == 0)
{
lean_object* v___x_1332_; lean_object* v___x_1333_; uint8_t v___x_1334_; 
lean_dec(v___x_1330_);
v___x_1332_ = lean_box(v___x_1320_);
v___x_1333_ = l_outOfBounds___redArg(v___x_1332_);
lean_dec(v___x_1332_);
v___x_1334_ = lean_unbox(v___x_1333_);
lean_dec(v___x_1333_);
v___y_1314_ = v___x_1328_;
v___y_1315_ = v___x_1334_;
goto v___jp_1313_;
}
else
{
uint8_t v___x_1335_; 
v___x_1335_ = lean_byte_array_fget(v_fst_1200_, v___x_1330_);
lean_dec(v___x_1330_);
v___y_1314_ = v___x_1328_;
v___y_1315_ = v___x_1335_;
goto v___jp_1313_;
}
}
v___jp_1336_:
{
uint64_t v___x_1340_; uint64_t v___x_1341_; uint64_t v___x_1342_; uint64_t v___x_1343_; lean_object* v___x_1344_; lean_object* v___x_1345_; uint8_t v___x_1346_; 
v___x_1340_ = lean_uint8_to_uint64(v___y_1339_);
v___x_1341_ = 8ULL;
v___x_1342_ = lean_uint64_shift_left(v___x_1340_, v___x_1341_);
v___x_1343_ = lean_uint64_lor(v___y_1338_, v___x_1342_);
v___x_1344_ = lean_unsigned_to_nat(2u);
v___x_1345_ = lean_nat_add(v___y_1337_, v___x_1344_);
v___x_1346_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_1200_, v___x_1345_);
if (v___x_1346_ == 0)
{
lean_object* v___x_1347_; lean_object* v___x_1348_; uint8_t v___x_1349_; 
lean_dec(v___x_1345_);
v___x_1347_ = lean_box(v___x_1320_);
v___x_1348_ = l_outOfBounds___redArg(v___x_1347_);
lean_dec(v___x_1347_);
v___x_1349_ = lean_unbox(v___x_1348_);
lean_dec(v___x_1348_);
v___y_1322_ = v___x_1343_;
v___y_1323_ = v___y_1337_;
v___y_1324_ = v___x_1349_;
goto v___jp_1321_;
}
else
{
uint8_t v___x_1350_; 
v___x_1350_ = lean_byte_array_fget(v_fst_1200_, v___x_1345_);
lean_dec(v___x_1345_);
v___y_1322_ = v___x_1343_;
v___y_1323_ = v___y_1337_;
v___y_1324_ = v___x_1350_;
goto v___jp_1321_;
}
}
v___jp_1351_:
{
uint64_t v_a_1354_; 
v_a_1354_ = lean_uint8_to_uint64(v___y_1353_);
switch(v_width_1167_)
{
case 0:
{
lean_dec(v___y_1352_);
v___y_1270_ = v_a_1354_;
goto v___jp_1269_;
}
case 1:
{
lean_object* v___x_1355_; uint8_t v___x_1356_; 
v___x_1355_ = lean_nat_add(v___y_1352_, v___x_1207_);
lean_dec(v___y_1352_);
v___x_1356_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_1200_, v___x_1355_);
if (v___x_1356_ == 0)
{
lean_object* v___x_1357_; lean_object* v___x_1358_; uint8_t v___x_1359_; 
lean_dec(v___x_1355_);
v___x_1357_ = lean_box(v___x_1320_);
v___x_1358_ = l_outOfBounds___redArg(v___x_1357_);
lean_dec(v___x_1357_);
v___x_1359_ = lean_unbox(v___x_1358_);
lean_dec(v___x_1358_);
v___y_1307_ = v_a_1354_;
v___y_1308_ = v___x_1359_;
goto v___jp_1306_;
}
else
{
uint8_t v___x_1360_; 
v___x_1360_ = lean_byte_array_fget(v_fst_1200_, v___x_1355_);
lean_dec(v___x_1355_);
v___y_1307_ = v_a_1354_;
v___y_1308_ = v___x_1360_;
goto v___jp_1306_;
}
}
default: 
{
lean_object* v___x_1361_; uint8_t v___x_1362_; 
v___x_1361_ = lean_nat_add(v___y_1352_, v___x_1207_);
v___x_1362_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_1200_, v___x_1361_);
if (v___x_1362_ == 0)
{
lean_object* v___x_1363_; lean_object* v___x_1364_; uint8_t v___x_1365_; 
lean_dec(v___x_1361_);
v___x_1363_ = lean_box(v___x_1320_);
v___x_1364_ = l_outOfBounds___redArg(v___x_1363_);
lean_dec(v___x_1363_);
v___x_1365_ = lean_unbox(v___x_1364_);
lean_dec(v___x_1364_);
v___y_1337_ = v___y_1352_;
v___y_1338_ = v_a_1354_;
v___y_1339_ = v___x_1365_;
goto v___jp_1336_;
}
else
{
uint8_t v___x_1366_; 
v___x_1366_ = lean_byte_array_fget(v_fst_1200_, v___x_1361_);
lean_dec(v___x_1361_);
v___y_1337_ = v___y_1352_;
v___y_1338_ = v_a_1354_;
v___y_1339_ = v___x_1366_;
goto v___jp_1336_;
}
}
}
}
v___jp_1367_:
{
if (v___y_1369_ == 0)
{
uint8_t v___x_1370_; 
v___x_1370_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_1200_, v___y_1368_);
if (v___x_1370_ == 0)
{
lean_object* v___x_1371_; lean_object* v___x_1372_; uint8_t v___x_1373_; 
v___x_1371_ = lean_box(v___x_1320_);
v___x_1372_ = l_outOfBounds___redArg(v___x_1371_);
lean_dec(v___x_1371_);
v___x_1373_ = lean_unbox(v___x_1372_);
lean_dec(v___x_1372_);
v___y_1352_ = v___y_1368_;
v___y_1353_ = v___x_1373_;
goto v___jp_1351_;
}
else
{
uint8_t v___x_1374_; 
v___x_1374_ = lean_byte_array_fget(v_fst_1200_, v___y_1368_);
v___y_1352_ = v___y_1368_;
v___y_1353_ = v___x_1374_;
goto v___jp_1351_;
}
}
else
{
size_t v_pos_1375_; uint8_t v___x_1376_; uint64_t v_a_1377_; 
v_pos_1375_ = lean_usize_of_nat(v___y_1368_);
lean_dec(v___y_1368_);
v___x_1376_ = lean_byte_array_uget(v_fst_1200_, v_pos_1375_);
v_a_1377_ = lean_uint8_to_uint64(v___x_1376_);
switch(v_width_1167_)
{
case 0:
{
v___y_1270_ = v_a_1377_;
goto v___jp_1269_;
}
case 1:
{
size_t v___x_1378_; size_t v___x_1379_; uint8_t v___x_1380_; uint64_t v___x_1381_; uint64_t v___x_1382_; uint64_t v___x_1383_; uint64_t v___x_1384_; 
v___x_1378_ = ((size_t)1ULL);
v___x_1379_ = lean_usize_add(v_pos_1375_, v___x_1378_);
v___x_1380_ = lean_byte_array_uget(v_fst_1200_, v___x_1379_);
v___x_1381_ = lean_uint8_to_uint64(v___x_1380_);
v___x_1382_ = 8ULL;
v___x_1383_ = lean_uint64_shift_left(v___x_1381_, v___x_1382_);
v___x_1384_ = lean_uint64_lor(v_a_1377_, v___x_1383_);
v___y_1270_ = v___x_1384_;
goto v___jp_1269_;
}
default: 
{
size_t v___x_1385_; size_t v___x_1386_; uint8_t v___x_1387_; uint64_t v___x_1388_; uint64_t v___x_1389_; uint64_t v___x_1390_; uint64_t v___x_1391_; size_t v___x_1392_; size_t v___x_1393_; uint8_t v___x_1394_; uint64_t v___x_1395_; uint64_t v___x_1396_; uint64_t v___x_1397_; uint64_t v___x_1398_; size_t v___x_1399_; size_t v___x_1400_; uint8_t v___x_1401_; uint64_t v___x_1402_; uint64_t v___x_1403_; uint64_t v___x_1404_; uint64_t v___x_1405_; 
v___x_1385_ = ((size_t)1ULL);
v___x_1386_ = lean_usize_add(v_pos_1375_, v___x_1385_);
v___x_1387_ = lean_byte_array_uget(v_fst_1200_, v___x_1386_);
v___x_1388_ = lean_uint8_to_uint64(v___x_1387_);
v___x_1389_ = 8ULL;
v___x_1390_ = lean_uint64_shift_left(v___x_1388_, v___x_1389_);
v___x_1391_ = lean_uint64_lor(v_a_1377_, v___x_1390_);
v___x_1392_ = ((size_t)2ULL);
v___x_1393_ = lean_usize_add(v_pos_1375_, v___x_1392_);
v___x_1394_ = lean_byte_array_uget(v_fst_1200_, v___x_1393_);
v___x_1395_ = lean_uint8_to_uint64(v___x_1394_);
v___x_1396_ = 16ULL;
v___x_1397_ = lean_uint64_shift_left(v___x_1395_, v___x_1396_);
v___x_1398_ = lean_uint64_lor(v___x_1391_, v___x_1397_);
v___x_1399_ = ((size_t)3ULL);
v___x_1400_ = lean_usize_add(v_pos_1375_, v___x_1399_);
v___x_1401_ = lean_byte_array_uget(v_fst_1200_, v___x_1400_);
v___x_1402_ = lean_uint8_to_uint64(v___x_1401_);
v___x_1403_ = 24ULL;
v___x_1404_ = lean_uint64_shift_left(v___x_1402_, v___x_1403_);
v___x_1405_ = lean_uint64_lor(v___x_1398_, v___x_1404_);
v___y_1270_ = v___x_1405_;
goto v___jp_1269_;
}
}
}
}
v___jp_1406_:
{
lean_object* v_offset_1408_; lean_object* v___x_1409_; lean_object* v___x_1410_; uint8_t v___x_1411_; 
v_offset_1408_ = lean_nat_mul(v_i_1175_, v___y_1407_);
v___x_1409_ = lean_nat_add(v_offset_1408_, v___y_1407_);
v___x_1410_ = lean_byte_array_size(v_fst_1200_);
v___x_1411_ = lean_nat_dec_le(v___x_1409_, v___x_1410_);
if (v___x_1411_ == 0)
{
lean_dec(v___x_1409_);
v___y_1368_ = v_offset_1408_;
v___y_1369_ = v___x_1411_;
goto v___jp_1367_;
}
else
{
size_t v___x_1412_; lean_object* v___x_1413_; uint8_t v___x_1414_; 
v___x_1412_ = lean_usize_of_nat(v___x_1409_);
v___x_1413_ = lean_usize_to_nat(v___x_1412_);
v___x_1414_ = lean_nat_dec_eq(v___x_1413_, v___x_1409_);
lean_dec(v___x_1409_);
lean_dec(v___x_1413_);
v___y_1368_ = v_offset_1408_;
v___y_1369_ = v___x_1414_;
goto v___jp_1367_;
}
}
}
}
v___jp_1177_:
{
lean_object* v___x_1180_; lean_object* v___x_1181_; 
v___x_1180_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1180_, 0, v_a_1178_);
v___x_1181_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1181_, 0, v___x_1180_);
lean_ctor_set(v___x_1181_, 1, v_snd_1179_);
return v___x_1181_;
}
v___jp_1182_:
{
lean_object* v___x_1184_; 
v___x_1184_ = lean_box(0);
v_a_1178_ = v___x_1184_;
v_snd_1179_ = v___y_1183_;
goto v___jp_1177_;
}
v___jp_1187_:
{
lean_object* v___x_1190_; 
v___x_1190_ = lean_nat_add(v_i_1175_, v_step_1186_);
lean_dec(v_i_1175_);
v_b_1174_ = v_a_1188_;
v_i_1175_ = v___x_1190_;
v___y_1176_ = v_snd_1189_;
goto _start;
}
v___jp_1192_:
{
lean_object* v___x_1196_; 
v___x_1196_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1196_, 0, v___y_1195_);
lean_ctor_set(v___x_1196_, 1, v___y_1194_);
v_a_1188_ = v___x_1196_;
v_snd_1189_ = v___y_1193_;
goto v___jp_1187_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___boxed(lean_object* v_width_1417_, lean_object* v_limits_1418_, lean_object* v___y_1419_, lean_object* v_inv_1420_, lean_object* v_field_1421_, lean_object* v_ctx_1422_, lean_object* v_range_1423_, lean_object* v_b_1424_, lean_object* v_i_1425_, lean_object* v___y_1426_){
_start:
{
uint8_t v_width_boxed_1427_; uint64_t v_inv_boxed_1428_; uint64_t v_field_boxed_1429_; uint64_t v_ctx_boxed_1430_; lean_object* v_res_1431_; 
v_width_boxed_1427_ = lean_unbox(v_width_1417_);
v_inv_boxed_1428_ = lean_unbox_uint64(v_inv_1420_);
lean_dec_ref(v_inv_1420_);
v_field_boxed_1429_ = lean_unbox_uint64(v_field_1421_);
lean_dec_ref(v_field_1421_);
v_ctx_boxed_1430_ = lean_unbox_uint64(v_ctx_1422_);
lean_dec_ref(v_ctx_1422_);
v_res_1431_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg(v_width_boxed_1427_, v_limits_1418_, v___y_1419_, v_inv_boxed_1428_, v_field_boxed_1429_, v_ctx_boxed_1430_, v_range_1423_, v_b_1424_, v_i_1425_, v___y_1426_);
lean_dec_ref(v_range_1423_);
lean_dec(v___y_1419_);
lean_dec_ref(v_limits_1418_);
return v_res_1431_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg(uint64_t v_field_1432_, uint64_t v_ctx_1433_, uint64_t v___y_1434_, uint8_t v_width_1435_, lean_object* v___x_1436_, lean_object* v___x_1437_, lean_object* v_range_1438_, lean_object* v_b_1439_, lean_object* v_i_1440_, lean_object* v___y_1441_){
_start:
{
lean_object* v_stop_1442_; lean_object* v_step_1443_; lean_object* v___y_1445_; uint64_t v___y_1463_; lean_object* v___y_1464_; lean_object* v___y_1465_; lean_object* v___y_1466_; lean_object* v___y_1495_; lean_object* v___y_1496_; uint64_t v___y_1497_; uint64_t v___y_1502_; lean_object* v___y_1503_; lean_object* v___y_1504_; uint64_t v___y_1505_; uint64_t v___y_1511_; uint64_t v___y_1512_; lean_object* v___y_1513_; lean_object* v___y_1514_; uint8_t v___y_1515_; uint64_t v___y_1521_; uint64_t v___y_1522_; lean_object* v___y_1523_; lean_object* v___y_1524_; uint8_t v___y_1525_; uint8_t v___x_1530_; 
v_stop_1442_ = lean_ctor_get(v_range_1438_, 1);
v_step_1443_ = lean_ctor_get(v_range_1438_, 2);
v___x_1530_ = lean_nat_dec_lt(v_i_1440_, v_stop_1442_);
if (v___x_1530_ == 0)
{
lean_object* v___x_1531_; lean_object* v___x_1532_; 
lean_dec(v_i_1440_);
v___x_1531_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1531_, 0, v_b_1439_);
v___x_1532_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1532_, 0, v___x_1531_);
lean_ctor_set(v___x_1532_, 1, v___y_1441_);
return v___x_1532_;
}
else
{
uint8_t v___y_1534_; lean_object* v___y_1535_; uint64_t v___y_1536_; uint64_t v___y_1537_; lean_object* v___y_1538_; lean_object* v___y_1539_; uint8_t v___y_1540_; uint8_t v___y_1553_; uint64_t v___y_1554_; lean_object* v___y_1555_; uint64_t v___y_1556_; lean_object* v___y_1557_; lean_object* v___y_1558_; uint8_t v___y_1559_; uint8_t v___y_1572_; lean_object* v___y_1573_; uint64_t v___y_1574_; lean_object* v___y_1575_; lean_object* v___y_1576_; uint8_t v___y_1577_; uint8_t v___y_1594_; uint64_t v___y_1595_; lean_object* v___y_1596_; lean_object* v___y_1597_; lean_object* v___y_1598_; uint8_t v___y_1599_; uint8_t v___y_1637_; uint64_t v___y_1638_; lean_object* v___y_1639_; lean_object* v___y_1640_; lean_object* v___y_1641_; lean_object* v___y_1650_; uint64_t v___y_1651_; uint64_t v___y_1659_; lean_object* v___y_1660_; uint8_t v___y_1661_; uint64_t v___y_1667_; lean_object* v___y_1668_; uint8_t v___y_1669_; uint64_t v___y_1675_; lean_object* v___y_1676_; lean_object* v___y_1677_; uint8_t v___y_1678_; lean_object* v___y_1679_; uint8_t v___y_1680_; uint64_t v___y_1693_; lean_object* v___y_1694_; lean_object* v___y_1695_; lean_object* v___y_1696_; uint8_t v___y_1697_; uint8_t v___y_1698_; lean_object* v___y_1711_; lean_object* v___y_1712_; uint8_t v___y_1713_; lean_object* v___y_1714_; uint8_t v___y_1715_; lean_object* v___y_1732_; lean_object* v___y_1733_; uint8_t v___y_1734_; lean_object* v___y_1735_; uint8_t v___y_1736_; lean_object* v___y_1774_; lean_object* v___y_1775_; uint8_t v___y_1776_; lean_object* v___y_1777_; uint64_t v___y_1786_; uint64_t v___y_1794_; uint8_t v___y_1795_; uint8_t v___x_1800_; lean_object* v___x_1801_; lean_object* v_offset_1802_; uint64_t v___y_1804_; uint8_t v___y_1805_; uint64_t v___y_1818_; uint8_t v___y_1819_; uint8_t v___y_1832_; uint8_t v___y_1842_; lean_object* v___x_1872_; lean_object* v___x_1873_; uint8_t v___x_1874_; 
v___x_1800_ = 0;
v___x_1801_ = lean_unsigned_to_nat(4u);
v_offset_1802_ = lean_nat_mul(v_i_1440_, v___x_1801_);
v___x_1872_ = lean_nat_add(v_offset_1802_, v___x_1801_);
v___x_1873_ = lean_byte_array_size(v___x_1437_);
v___x_1874_ = lean_nat_dec_le(v___x_1872_, v___x_1873_);
if (v___x_1874_ == 0)
{
lean_dec(v___x_1872_);
v___y_1842_ = v___x_1874_;
goto v___jp_1841_;
}
else
{
size_t v___x_1875_; lean_object* v___x_1876_; uint8_t v___x_1877_; 
v___x_1875_ = lean_usize_of_nat(v___x_1872_);
v___x_1876_ = lean_usize_to_nat(v___x_1875_);
v___x_1877_ = lean_nat_dec_eq(v___x_1876_, v___x_1872_);
lean_dec(v___x_1872_);
lean_dec(v___x_1876_);
v___y_1842_ = v___x_1877_;
goto v___jp_1841_;
}
v___jp_1533_:
{
uint64_t v___x_1541_; uint64_t v___x_1542_; uint64_t v___x_1543_; uint64_t v___x_1544_; lean_object* v___x_1545_; lean_object* v___x_1546_; uint8_t v___x_1547_; 
v___x_1541_ = lean_uint8_to_uint64(v___y_1540_);
v___x_1542_ = 16ULL;
v___x_1543_ = lean_uint64_shift_left(v___x_1541_, v___x_1542_);
v___x_1544_ = lean_uint64_lor(v___y_1537_, v___x_1543_);
v___x_1545_ = lean_unsigned_to_nat(3u);
v___x_1546_ = lean_nat_add(v___y_1535_, v___x_1545_);
lean_dec(v___y_1535_);
v___x_1547_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1538_, v___x_1546_);
if (v___x_1547_ == 0)
{
lean_object* v___x_1548_; lean_object* v___x_1549_; uint8_t v___x_1550_; 
lean_dec(v___x_1546_);
v___x_1548_ = lean_box(v___y_1534_);
v___x_1549_ = l_outOfBounds___redArg(v___x_1548_);
lean_dec(v___x_1548_);
v___x_1550_ = lean_unbox(v___x_1549_);
lean_dec(v___x_1549_);
v___y_1511_ = v___y_1536_;
v___y_1512_ = v___x_1544_;
v___y_1513_ = v___y_1538_;
v___y_1514_ = v___y_1539_;
v___y_1515_ = v___x_1550_;
goto v___jp_1510_;
}
else
{
uint8_t v___x_1551_; 
v___x_1551_ = lean_byte_array_fget(v___y_1538_, v___x_1546_);
lean_dec(v___x_1546_);
v___y_1511_ = v___y_1536_;
v___y_1512_ = v___x_1544_;
v___y_1513_ = v___y_1538_;
v___y_1514_ = v___y_1539_;
v___y_1515_ = v___x_1551_;
goto v___jp_1510_;
}
}
v___jp_1552_:
{
uint64_t v___x_1560_; uint64_t v___x_1561_; uint64_t v___x_1562_; uint64_t v___x_1563_; lean_object* v___x_1564_; lean_object* v___x_1565_; uint8_t v___x_1566_; 
v___x_1560_ = lean_uint8_to_uint64(v___y_1559_);
v___x_1561_ = 8ULL;
v___x_1562_ = lean_uint64_shift_left(v___x_1560_, v___x_1561_);
v___x_1563_ = lean_uint64_lor(v___y_1556_, v___x_1562_);
v___x_1564_ = lean_unsigned_to_nat(2u);
v___x_1565_ = lean_nat_add(v___y_1555_, v___x_1564_);
v___x_1566_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1557_, v___x_1565_);
if (v___x_1566_ == 0)
{
lean_object* v___x_1567_; lean_object* v___x_1568_; uint8_t v___x_1569_; 
lean_dec(v___x_1565_);
v___x_1567_ = lean_box(v___y_1553_);
v___x_1568_ = l_outOfBounds___redArg(v___x_1567_);
lean_dec(v___x_1567_);
v___x_1569_ = lean_unbox(v___x_1568_);
lean_dec(v___x_1568_);
v___y_1534_ = v___y_1553_;
v___y_1535_ = v___y_1555_;
v___y_1536_ = v___y_1554_;
v___y_1537_ = v___x_1563_;
v___y_1538_ = v___y_1557_;
v___y_1539_ = v___y_1558_;
v___y_1540_ = v___x_1569_;
goto v___jp_1533_;
}
else
{
uint8_t v___x_1570_; 
v___x_1570_ = lean_byte_array_fget(v___y_1557_, v___x_1565_);
lean_dec(v___x_1565_);
v___y_1534_ = v___y_1553_;
v___y_1535_ = v___y_1555_;
v___y_1536_ = v___y_1554_;
v___y_1537_ = v___x_1563_;
v___y_1538_ = v___y_1557_;
v___y_1539_ = v___y_1558_;
v___y_1540_ = v___x_1570_;
goto v___jp_1533_;
}
}
v___jp_1571_:
{
uint64_t v_a_1578_; 
v_a_1578_ = lean_uint8_to_uint64(v___y_1577_);
switch(v_width_1435_)
{
case 0:
{
lean_dec(v___y_1573_);
v___y_1502_ = v___y_1574_;
v___y_1503_ = v___y_1575_;
v___y_1504_ = v___y_1576_;
v___y_1505_ = v_a_1578_;
goto v___jp_1501_;
}
case 1:
{
lean_object* v___x_1579_; lean_object* v___x_1580_; uint8_t v___x_1581_; 
v___x_1579_ = lean_unsigned_to_nat(1u);
v___x_1580_ = lean_nat_add(v___y_1573_, v___x_1579_);
lean_dec(v___y_1573_);
v___x_1581_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1575_, v___x_1580_);
if (v___x_1581_ == 0)
{
lean_object* v___x_1582_; lean_object* v___x_1583_; uint8_t v___x_1584_; 
lean_dec(v___x_1580_);
v___x_1582_ = lean_box(v___y_1572_);
v___x_1583_ = l_outOfBounds___redArg(v___x_1582_);
lean_dec(v___x_1582_);
v___x_1584_ = lean_unbox(v___x_1583_);
lean_dec(v___x_1583_);
v___y_1521_ = v___y_1574_;
v___y_1522_ = v_a_1578_;
v___y_1523_ = v___y_1575_;
v___y_1524_ = v___y_1576_;
v___y_1525_ = v___x_1584_;
goto v___jp_1520_;
}
else
{
uint8_t v___x_1585_; 
v___x_1585_ = lean_byte_array_fget(v___y_1575_, v___x_1580_);
lean_dec(v___x_1580_);
v___y_1521_ = v___y_1574_;
v___y_1522_ = v_a_1578_;
v___y_1523_ = v___y_1575_;
v___y_1524_ = v___y_1576_;
v___y_1525_ = v___x_1585_;
goto v___jp_1520_;
}
}
default: 
{
lean_object* v___x_1586_; lean_object* v___x_1587_; uint8_t v___x_1588_; 
v___x_1586_ = lean_unsigned_to_nat(1u);
v___x_1587_ = lean_nat_add(v___y_1573_, v___x_1586_);
v___x_1588_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1575_, v___x_1587_);
if (v___x_1588_ == 0)
{
lean_object* v___x_1589_; lean_object* v___x_1590_; uint8_t v___x_1591_; 
lean_dec(v___x_1587_);
v___x_1589_ = lean_box(v___y_1572_);
v___x_1590_ = l_outOfBounds___redArg(v___x_1589_);
lean_dec(v___x_1589_);
v___x_1591_ = lean_unbox(v___x_1590_);
lean_dec(v___x_1590_);
v___y_1553_ = v___y_1572_;
v___y_1554_ = v___y_1574_;
v___y_1555_ = v___y_1573_;
v___y_1556_ = v_a_1578_;
v___y_1557_ = v___y_1575_;
v___y_1558_ = v___y_1576_;
v___y_1559_ = v___x_1591_;
goto v___jp_1552_;
}
else
{
uint8_t v___x_1592_; 
v___x_1592_ = lean_byte_array_fget(v___y_1575_, v___x_1587_);
lean_dec(v___x_1587_);
v___y_1553_ = v___y_1572_;
v___y_1554_ = v___y_1574_;
v___y_1555_ = v___y_1573_;
v___y_1556_ = v_a_1578_;
v___y_1557_ = v___y_1575_;
v___y_1558_ = v___y_1576_;
v___y_1559_ = v___x_1592_;
goto v___jp_1552_;
}
}
}
}
v___jp_1593_:
{
if (v___y_1599_ == 0)
{
uint8_t v___x_1600_; 
v___x_1600_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1597_, v___y_1596_);
if (v___x_1600_ == 0)
{
lean_object* v___x_1601_; lean_object* v___x_1602_; uint8_t v___x_1603_; 
v___x_1601_ = lean_box(v___y_1594_);
v___x_1602_ = l_outOfBounds___redArg(v___x_1601_);
lean_dec(v___x_1601_);
v___x_1603_ = lean_unbox(v___x_1602_);
lean_dec(v___x_1602_);
v___y_1572_ = v___y_1594_;
v___y_1573_ = v___y_1596_;
v___y_1574_ = v___y_1595_;
v___y_1575_ = v___y_1597_;
v___y_1576_ = v___y_1598_;
v___y_1577_ = v___x_1603_;
goto v___jp_1571_;
}
else
{
uint8_t v___x_1604_; 
v___x_1604_ = lean_byte_array_fget(v___y_1597_, v___y_1596_);
v___y_1572_ = v___y_1594_;
v___y_1573_ = v___y_1596_;
v___y_1574_ = v___y_1595_;
v___y_1575_ = v___y_1597_;
v___y_1576_ = v___y_1598_;
v___y_1577_ = v___x_1604_;
goto v___jp_1571_;
}
}
else
{
size_t v_pos_1605_; uint8_t v___x_1606_; uint64_t v_a_1607_; 
v_pos_1605_ = lean_usize_of_nat(v___y_1596_);
lean_dec(v___y_1596_);
v___x_1606_ = lean_byte_array_uget(v___y_1597_, v_pos_1605_);
v_a_1607_ = lean_uint8_to_uint64(v___x_1606_);
switch(v_width_1435_)
{
case 0:
{
v___y_1502_ = v___y_1595_;
v___y_1503_ = v___y_1597_;
v___y_1504_ = v___y_1598_;
v___y_1505_ = v_a_1607_;
goto v___jp_1501_;
}
case 1:
{
size_t v___x_1608_; size_t v___x_1609_; uint8_t v___x_1610_; uint64_t v___x_1611_; uint64_t v___x_1612_; uint64_t v___x_1613_; uint64_t v___x_1614_; 
v___x_1608_ = ((size_t)1ULL);
v___x_1609_ = lean_usize_add(v_pos_1605_, v___x_1608_);
v___x_1610_ = lean_byte_array_uget(v___y_1597_, v___x_1609_);
v___x_1611_ = lean_uint8_to_uint64(v___x_1610_);
v___x_1612_ = 8ULL;
v___x_1613_ = lean_uint64_shift_left(v___x_1611_, v___x_1612_);
v___x_1614_ = lean_uint64_lor(v_a_1607_, v___x_1613_);
v___y_1502_ = v___y_1595_;
v___y_1503_ = v___y_1597_;
v___y_1504_ = v___y_1598_;
v___y_1505_ = v___x_1614_;
goto v___jp_1501_;
}
default: 
{
size_t v___x_1615_; size_t v___x_1616_; uint8_t v___x_1617_; uint64_t v___x_1618_; uint64_t v___x_1619_; uint64_t v___x_1620_; uint64_t v___x_1621_; size_t v___x_1622_; size_t v___x_1623_; uint8_t v___x_1624_; uint64_t v___x_1625_; uint64_t v___x_1626_; uint64_t v___x_1627_; uint64_t v___x_1628_; size_t v___x_1629_; size_t v___x_1630_; uint8_t v___x_1631_; uint64_t v___x_1632_; uint64_t v___x_1633_; uint64_t v___x_1634_; uint64_t v___x_1635_; 
v___x_1615_ = ((size_t)1ULL);
v___x_1616_ = lean_usize_add(v_pos_1605_, v___x_1615_);
v___x_1617_ = lean_byte_array_uget(v___y_1597_, v___x_1616_);
v___x_1618_ = lean_uint8_to_uint64(v___x_1617_);
v___x_1619_ = 8ULL;
v___x_1620_ = lean_uint64_shift_left(v___x_1618_, v___x_1619_);
v___x_1621_ = lean_uint64_lor(v_a_1607_, v___x_1620_);
v___x_1622_ = ((size_t)2ULL);
v___x_1623_ = lean_usize_add(v_pos_1605_, v___x_1622_);
v___x_1624_ = lean_byte_array_uget(v___y_1597_, v___x_1623_);
v___x_1625_ = lean_uint8_to_uint64(v___x_1624_);
v___x_1626_ = 16ULL;
v___x_1627_ = lean_uint64_shift_left(v___x_1625_, v___x_1626_);
v___x_1628_ = lean_uint64_lor(v___x_1621_, v___x_1627_);
v___x_1629_ = ((size_t)3ULL);
v___x_1630_ = lean_usize_add(v_pos_1605_, v___x_1629_);
v___x_1631_ = lean_byte_array_uget(v___y_1597_, v___x_1630_);
v___x_1632_ = lean_uint8_to_uint64(v___x_1631_);
v___x_1633_ = 24ULL;
v___x_1634_ = lean_uint64_shift_left(v___x_1632_, v___x_1633_);
v___x_1635_ = lean_uint64_lor(v___x_1628_, v___x_1634_);
v___y_1502_ = v___y_1595_;
v___y_1503_ = v___y_1597_;
v___y_1504_ = v___y_1598_;
v___y_1505_ = v___x_1635_;
goto v___jp_1501_;
}
}
}
}
v___jp_1636_:
{
lean_object* v_offset_1642_; lean_object* v___x_1643_; lean_object* v___x_1644_; uint8_t v___x_1645_; 
v_offset_1642_ = lean_nat_mul(v___y_1640_, v___y_1641_);
v___x_1643_ = lean_nat_add(v_offset_1642_, v___y_1641_);
v___x_1644_ = lean_byte_array_size(v___y_1639_);
v___x_1645_ = lean_nat_dec_le(v___x_1643_, v___x_1644_);
if (v___x_1645_ == 0)
{
lean_dec(v___x_1643_);
v___y_1594_ = v___y_1637_;
v___y_1595_ = v___y_1638_;
v___y_1596_ = v_offset_1642_;
v___y_1597_ = v___y_1639_;
v___y_1598_ = v___y_1640_;
v___y_1599_ = v___x_1645_;
goto v___jp_1593_;
}
else
{
size_t v___x_1646_; lean_object* v___x_1647_; uint8_t v___x_1648_; 
v___x_1646_ = lean_usize_of_nat(v___x_1643_);
v___x_1647_ = lean_usize_to_nat(v___x_1646_);
v___x_1648_ = lean_nat_dec_eq(v___x_1647_, v___x_1643_);
lean_dec(v___x_1643_);
lean_dec(v___x_1647_);
v___y_1594_ = v___y_1637_;
v___y_1595_ = v___y_1638_;
v___y_1596_ = v_offset_1642_;
v___y_1597_ = v___y_1639_;
v___y_1598_ = v___y_1640_;
v___y_1599_ = v___x_1648_;
goto v___jp_1593_;
}
}
v___jp_1649_:
{
lean_object* v_dense_1652_; uint64_t v___x_1653_; uint8_t v___x_1654_; 
v_dense_1652_ = lean_ctor_get(v_b_1439_, 0);
v___x_1653_ = lp_Hex_BarrettCtx_mulMod(v_field_1432_, v_ctx_1433_, v___y_1434_, v___y_1651_);
v___x_1654_ = 0;
switch(v_width_1435_)
{
case 0:
{
lean_object* v___x_1655_; 
v___x_1655_ = lean_unsigned_to_nat(1u);
lean_inc_ref(v_dense_1652_);
v___y_1637_ = v___x_1654_;
v___y_1638_ = v___x_1653_;
v___y_1639_ = v_dense_1652_;
v___y_1640_ = v___y_1650_;
v___y_1641_ = v___x_1655_;
goto v___jp_1636_;
}
case 1:
{
lean_object* v___x_1656_; 
v___x_1656_ = lean_unsigned_to_nat(2u);
lean_inc_ref(v_dense_1652_);
v___y_1637_ = v___x_1654_;
v___y_1638_ = v___x_1653_;
v___y_1639_ = v_dense_1652_;
v___y_1640_ = v___y_1650_;
v___y_1641_ = v___x_1656_;
goto v___jp_1636_;
}
default: 
{
lean_object* v___x_1657_; 
v___x_1657_ = lean_unsigned_to_nat(4u);
lean_inc_ref(v_dense_1652_);
v___y_1637_ = v___x_1654_;
v___y_1638_ = v___x_1653_;
v___y_1639_ = v_dense_1652_;
v___y_1640_ = v___y_1650_;
v___y_1641_ = v___x_1657_;
goto v___jp_1636_;
}
}
}
v___jp_1658_:
{
uint64_t v___x_1662_; uint64_t v___x_1663_; uint64_t v___x_1664_; uint64_t v___x_1665_; 
v___x_1662_ = lean_uint8_to_uint64(v___y_1661_);
v___x_1663_ = 24ULL;
v___x_1664_ = lean_uint64_shift_left(v___x_1662_, v___x_1663_);
v___x_1665_ = lean_uint64_lor(v___y_1659_, v___x_1664_);
v___y_1650_ = v___y_1660_;
v___y_1651_ = v___x_1665_;
goto v___jp_1649_;
}
v___jp_1666_:
{
uint64_t v___x_1670_; uint64_t v___x_1671_; uint64_t v___x_1672_; uint64_t v___x_1673_; 
v___x_1670_ = lean_uint8_to_uint64(v___y_1669_);
v___x_1671_ = 8ULL;
v___x_1672_ = lean_uint64_shift_left(v___x_1670_, v___x_1671_);
v___x_1673_ = lean_uint64_lor(v___y_1667_, v___x_1672_);
v___y_1650_ = v___y_1668_;
v___y_1651_ = v___x_1673_;
goto v___jp_1649_;
}
v___jp_1674_:
{
uint64_t v___x_1681_; uint64_t v___x_1682_; uint64_t v___x_1683_; uint64_t v___x_1684_; lean_object* v___x_1685_; lean_object* v___x_1686_; uint8_t v___x_1687_; 
v___x_1681_ = lean_uint8_to_uint64(v___y_1680_);
v___x_1682_ = 16ULL;
v___x_1683_ = lean_uint64_shift_left(v___x_1681_, v___x_1682_);
v___x_1684_ = lean_uint64_lor(v___y_1675_, v___x_1683_);
v___x_1685_ = lean_unsigned_to_nat(3u);
v___x_1686_ = lean_nat_add(v___y_1676_, v___x_1685_);
lean_dec(v___y_1676_);
v___x_1687_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1679_, v___x_1686_);
if (v___x_1687_ == 0)
{
lean_object* v___x_1688_; lean_object* v___x_1689_; uint8_t v___x_1690_; 
lean_dec(v___x_1686_);
v___x_1688_ = lean_box(v___y_1678_);
v___x_1689_ = l_outOfBounds___redArg(v___x_1688_);
lean_dec(v___x_1688_);
v___x_1690_ = lean_unbox(v___x_1689_);
lean_dec(v___x_1689_);
v___y_1659_ = v___x_1684_;
v___y_1660_ = v___y_1677_;
v___y_1661_ = v___x_1690_;
goto v___jp_1658_;
}
else
{
uint8_t v___x_1691_; 
v___x_1691_ = lean_byte_array_fget(v___y_1679_, v___x_1686_);
lean_dec(v___x_1686_);
v___y_1659_ = v___x_1684_;
v___y_1660_ = v___y_1677_;
v___y_1661_ = v___x_1691_;
goto v___jp_1658_;
}
}
v___jp_1692_:
{
uint64_t v___x_1699_; uint64_t v___x_1700_; uint64_t v___x_1701_; uint64_t v___x_1702_; lean_object* v___x_1703_; lean_object* v___x_1704_; uint8_t v___x_1705_; 
v___x_1699_ = lean_uint8_to_uint64(v___y_1698_);
v___x_1700_ = 8ULL;
v___x_1701_ = lean_uint64_shift_left(v___x_1699_, v___x_1700_);
v___x_1702_ = lean_uint64_lor(v___y_1693_, v___x_1701_);
v___x_1703_ = lean_unsigned_to_nat(2u);
v___x_1704_ = lean_nat_add(v___y_1694_, v___x_1703_);
v___x_1705_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1696_, v___x_1704_);
if (v___x_1705_ == 0)
{
lean_object* v___x_1706_; lean_object* v___x_1707_; uint8_t v___x_1708_; 
lean_dec(v___x_1704_);
v___x_1706_ = lean_box(v___y_1697_);
v___x_1707_ = l_outOfBounds___redArg(v___x_1706_);
lean_dec(v___x_1706_);
v___x_1708_ = lean_unbox(v___x_1707_);
lean_dec(v___x_1707_);
v___y_1675_ = v___x_1702_;
v___y_1676_ = v___y_1694_;
v___y_1677_ = v___y_1695_;
v___y_1678_ = v___y_1697_;
v___y_1679_ = v___y_1696_;
v___y_1680_ = v___x_1708_;
goto v___jp_1674_;
}
else
{
uint8_t v___x_1709_; 
v___x_1709_ = lean_byte_array_fget(v___y_1696_, v___x_1704_);
lean_dec(v___x_1704_);
v___y_1675_ = v___x_1702_;
v___y_1676_ = v___y_1694_;
v___y_1677_ = v___y_1695_;
v___y_1678_ = v___y_1697_;
v___y_1679_ = v___y_1696_;
v___y_1680_ = v___x_1709_;
goto v___jp_1674_;
}
}
v___jp_1710_:
{
uint64_t v_a_1716_; 
v_a_1716_ = lean_uint8_to_uint64(v___y_1715_);
switch(v_width_1435_)
{
case 0:
{
lean_dec(v___y_1711_);
v___y_1650_ = v___y_1712_;
v___y_1651_ = v_a_1716_;
goto v___jp_1649_;
}
case 1:
{
lean_object* v___x_1717_; lean_object* v___x_1718_; uint8_t v___x_1719_; 
v___x_1717_ = lean_unsigned_to_nat(1u);
v___x_1718_ = lean_nat_add(v___y_1711_, v___x_1717_);
lean_dec(v___y_1711_);
v___x_1719_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1714_, v___x_1718_);
if (v___x_1719_ == 0)
{
lean_object* v___x_1720_; lean_object* v___x_1721_; uint8_t v___x_1722_; 
lean_dec(v___x_1718_);
v___x_1720_ = lean_box(v___y_1713_);
v___x_1721_ = l_outOfBounds___redArg(v___x_1720_);
lean_dec(v___x_1720_);
v___x_1722_ = lean_unbox(v___x_1721_);
lean_dec(v___x_1721_);
v___y_1667_ = v_a_1716_;
v___y_1668_ = v___y_1712_;
v___y_1669_ = v___x_1722_;
goto v___jp_1666_;
}
else
{
uint8_t v___x_1723_; 
v___x_1723_ = lean_byte_array_fget(v___y_1714_, v___x_1718_);
lean_dec(v___x_1718_);
v___y_1667_ = v_a_1716_;
v___y_1668_ = v___y_1712_;
v___y_1669_ = v___x_1723_;
goto v___jp_1666_;
}
}
default: 
{
lean_object* v___x_1724_; lean_object* v___x_1725_; uint8_t v___x_1726_; 
v___x_1724_ = lean_unsigned_to_nat(1u);
v___x_1725_ = lean_nat_add(v___y_1711_, v___x_1724_);
v___x_1726_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1714_, v___x_1725_);
if (v___x_1726_ == 0)
{
lean_object* v___x_1727_; lean_object* v___x_1728_; uint8_t v___x_1729_; 
lean_dec(v___x_1725_);
v___x_1727_ = lean_box(v___y_1713_);
v___x_1728_ = l_outOfBounds___redArg(v___x_1727_);
lean_dec(v___x_1727_);
v___x_1729_ = lean_unbox(v___x_1728_);
lean_dec(v___x_1728_);
v___y_1693_ = v_a_1716_;
v___y_1694_ = v___y_1711_;
v___y_1695_ = v___y_1712_;
v___y_1696_ = v___y_1714_;
v___y_1697_ = v___y_1713_;
v___y_1698_ = v___x_1729_;
goto v___jp_1692_;
}
else
{
uint8_t v___x_1730_; 
v___x_1730_ = lean_byte_array_fget(v___y_1714_, v___x_1725_);
lean_dec(v___x_1725_);
v___y_1693_ = v_a_1716_;
v___y_1694_ = v___y_1711_;
v___y_1695_ = v___y_1712_;
v___y_1696_ = v___y_1714_;
v___y_1697_ = v___y_1713_;
v___y_1698_ = v___x_1730_;
goto v___jp_1692_;
}
}
}
}
v___jp_1731_:
{
if (v___y_1736_ == 0)
{
uint8_t v___x_1737_; 
v___x_1737_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_1735_, v___y_1732_);
if (v___x_1737_ == 0)
{
lean_object* v___x_1738_; lean_object* v___x_1739_; uint8_t v___x_1740_; 
v___x_1738_ = lean_box(v___y_1734_);
v___x_1739_ = l_outOfBounds___redArg(v___x_1738_);
lean_dec(v___x_1738_);
v___x_1740_ = lean_unbox(v___x_1739_);
lean_dec(v___x_1739_);
v___y_1711_ = v___y_1732_;
v___y_1712_ = v___y_1733_;
v___y_1713_ = v___y_1734_;
v___y_1714_ = v___y_1735_;
v___y_1715_ = v___x_1740_;
goto v___jp_1710_;
}
else
{
uint8_t v___x_1741_; 
v___x_1741_ = lean_byte_array_fget(v___y_1735_, v___y_1732_);
v___y_1711_ = v___y_1732_;
v___y_1712_ = v___y_1733_;
v___y_1713_ = v___y_1734_;
v___y_1714_ = v___y_1735_;
v___y_1715_ = v___x_1741_;
goto v___jp_1710_;
}
}
else
{
size_t v_pos_1742_; uint8_t v___x_1743_; uint64_t v_a_1744_; 
v_pos_1742_ = lean_usize_of_nat(v___y_1732_);
lean_dec(v___y_1732_);
v___x_1743_ = lean_byte_array_uget(v___y_1735_, v_pos_1742_);
v_a_1744_ = lean_uint8_to_uint64(v___x_1743_);
switch(v_width_1435_)
{
case 0:
{
v___y_1650_ = v___y_1733_;
v___y_1651_ = v_a_1744_;
goto v___jp_1649_;
}
case 1:
{
size_t v___x_1745_; size_t v___x_1746_; uint8_t v___x_1747_; uint64_t v___x_1748_; uint64_t v___x_1749_; uint64_t v___x_1750_; uint64_t v___x_1751_; 
v___x_1745_ = ((size_t)1ULL);
v___x_1746_ = lean_usize_add(v_pos_1742_, v___x_1745_);
v___x_1747_ = lean_byte_array_uget(v___y_1735_, v___x_1746_);
v___x_1748_ = lean_uint8_to_uint64(v___x_1747_);
v___x_1749_ = 8ULL;
v___x_1750_ = lean_uint64_shift_left(v___x_1748_, v___x_1749_);
v___x_1751_ = lean_uint64_lor(v_a_1744_, v___x_1750_);
v___y_1650_ = v___y_1733_;
v___y_1651_ = v___x_1751_;
goto v___jp_1649_;
}
default: 
{
size_t v___x_1752_; size_t v___x_1753_; uint8_t v___x_1754_; uint64_t v___x_1755_; uint64_t v___x_1756_; uint64_t v___x_1757_; uint64_t v___x_1758_; size_t v___x_1759_; size_t v___x_1760_; uint8_t v___x_1761_; uint64_t v___x_1762_; uint64_t v___x_1763_; uint64_t v___x_1764_; uint64_t v___x_1765_; size_t v___x_1766_; size_t v___x_1767_; uint8_t v___x_1768_; uint64_t v___x_1769_; uint64_t v___x_1770_; uint64_t v___x_1771_; uint64_t v___x_1772_; 
v___x_1752_ = ((size_t)1ULL);
v___x_1753_ = lean_usize_add(v_pos_1742_, v___x_1752_);
v___x_1754_ = lean_byte_array_uget(v___y_1735_, v___x_1753_);
v___x_1755_ = lean_uint8_to_uint64(v___x_1754_);
v___x_1756_ = 8ULL;
v___x_1757_ = lean_uint64_shift_left(v___x_1755_, v___x_1756_);
v___x_1758_ = lean_uint64_lor(v_a_1744_, v___x_1757_);
v___x_1759_ = ((size_t)2ULL);
v___x_1760_ = lean_usize_add(v_pos_1742_, v___x_1759_);
v___x_1761_ = lean_byte_array_uget(v___y_1735_, v___x_1760_);
v___x_1762_ = lean_uint8_to_uint64(v___x_1761_);
v___x_1763_ = 16ULL;
v___x_1764_ = lean_uint64_shift_left(v___x_1762_, v___x_1763_);
v___x_1765_ = lean_uint64_lor(v___x_1758_, v___x_1764_);
v___x_1766_ = ((size_t)3ULL);
v___x_1767_ = lean_usize_add(v_pos_1742_, v___x_1766_);
v___x_1768_ = lean_byte_array_uget(v___y_1735_, v___x_1767_);
v___x_1769_ = lean_uint8_to_uint64(v___x_1768_);
v___x_1770_ = 24ULL;
v___x_1771_ = lean_uint64_shift_left(v___x_1769_, v___x_1770_);
v___x_1772_ = lean_uint64_lor(v___x_1765_, v___x_1771_);
v___y_1650_ = v___y_1733_;
v___y_1651_ = v___x_1772_;
goto v___jp_1649_;
}
}
}
}
v___jp_1773_:
{
lean_object* v_offset_1778_; lean_object* v___x_1779_; lean_object* v___x_1780_; uint8_t v___x_1781_; 
v_offset_1778_ = lean_nat_mul(v_i_1440_, v___y_1777_);
v___x_1779_ = lean_nat_add(v_offset_1778_, v___y_1777_);
v___x_1780_ = lean_byte_array_size(v___y_1775_);
v___x_1781_ = lean_nat_dec_le(v___x_1779_, v___x_1780_);
if (v___x_1781_ == 0)
{
lean_dec(v___x_1779_);
v___y_1732_ = v_offset_1778_;
v___y_1733_ = v___y_1774_;
v___y_1734_ = v___y_1776_;
v___y_1735_ = v___y_1775_;
v___y_1736_ = v___x_1781_;
goto v___jp_1731_;
}
else
{
size_t v___x_1782_; lean_object* v___x_1783_; uint8_t v___x_1784_; 
v___x_1782_ = lean_usize_of_nat(v___x_1779_);
v___x_1783_ = lean_usize_to_nat(v___x_1782_);
v___x_1784_ = lean_nat_dec_eq(v___x_1783_, v___x_1779_);
lean_dec(v___x_1779_);
lean_dec(v___x_1783_);
v___y_1732_ = v_offset_1778_;
v___y_1733_ = v___y_1774_;
v___y_1734_ = v___y_1776_;
v___y_1735_ = v___y_1775_;
v___y_1736_ = v___x_1784_;
goto v___jp_1731_;
}
}
v___jp_1785_:
{
lean_object* v_coefficients_1787_; lean_object* v___x_1788_; uint8_t v___x_1789_; 
v_coefficients_1787_ = lean_ctor_get(v___x_1436_, 1);
v___x_1788_ = lean_uint64_to_nat(v___y_1786_);
v___x_1789_ = 0;
switch(v_width_1435_)
{
case 0:
{
lean_object* v___x_1790_; 
v___x_1790_ = lean_unsigned_to_nat(1u);
v___y_1774_ = v___x_1788_;
v___y_1775_ = v_coefficients_1787_;
v___y_1776_ = v___x_1789_;
v___y_1777_ = v___x_1790_;
goto v___jp_1773_;
}
case 1:
{
lean_object* v___x_1791_; 
v___x_1791_ = lean_unsigned_to_nat(2u);
v___y_1774_ = v___x_1788_;
v___y_1775_ = v_coefficients_1787_;
v___y_1776_ = v___x_1789_;
v___y_1777_ = v___x_1791_;
goto v___jp_1773_;
}
default: 
{
lean_object* v___x_1792_; 
v___x_1792_ = lean_unsigned_to_nat(4u);
v___y_1774_ = v___x_1788_;
v___y_1775_ = v_coefficients_1787_;
v___y_1776_ = v___x_1789_;
v___y_1777_ = v___x_1792_;
goto v___jp_1773_;
}
}
}
v___jp_1793_:
{
uint64_t v___x_1796_; uint64_t v___x_1797_; uint64_t v___x_1798_; uint64_t v___x_1799_; 
v___x_1796_ = lean_uint8_to_uint64(v___y_1795_);
v___x_1797_ = 24ULL;
v___x_1798_ = lean_uint64_shift_left(v___x_1796_, v___x_1797_);
v___x_1799_ = lean_uint64_lor(v___y_1794_, v___x_1798_);
v___y_1786_ = v___x_1799_;
goto v___jp_1785_;
}
v___jp_1803_:
{
uint64_t v___x_1806_; uint64_t v___x_1807_; uint64_t v___x_1808_; uint64_t v___x_1809_; lean_object* v___x_1810_; lean_object* v___x_1811_; uint8_t v___x_1812_; 
v___x_1806_ = lean_uint8_to_uint64(v___y_1805_);
v___x_1807_ = 16ULL;
v___x_1808_ = lean_uint64_shift_left(v___x_1806_, v___x_1807_);
v___x_1809_ = lean_uint64_lor(v___y_1804_, v___x_1808_);
v___x_1810_ = lean_unsigned_to_nat(3u);
v___x_1811_ = lean_nat_add(v_offset_1802_, v___x_1810_);
lean_dec(v_offset_1802_);
v___x_1812_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_1437_, v___x_1811_);
if (v___x_1812_ == 0)
{
lean_object* v___x_1813_; lean_object* v___x_1814_; uint8_t v___x_1815_; 
lean_dec(v___x_1811_);
v___x_1813_ = lean_box(v___x_1800_);
v___x_1814_ = l_outOfBounds___redArg(v___x_1813_);
lean_dec(v___x_1813_);
v___x_1815_ = lean_unbox(v___x_1814_);
lean_dec(v___x_1814_);
v___y_1794_ = v___x_1809_;
v___y_1795_ = v___x_1815_;
goto v___jp_1793_;
}
else
{
uint8_t v___x_1816_; 
v___x_1816_ = lean_byte_array_fget(v___x_1437_, v___x_1811_);
lean_dec(v___x_1811_);
v___y_1794_ = v___x_1809_;
v___y_1795_ = v___x_1816_;
goto v___jp_1793_;
}
}
v___jp_1817_:
{
uint64_t v___x_1820_; uint64_t v___x_1821_; uint64_t v___x_1822_; uint64_t v___x_1823_; lean_object* v___x_1824_; lean_object* v___x_1825_; uint8_t v___x_1826_; 
v___x_1820_ = lean_uint8_to_uint64(v___y_1819_);
v___x_1821_ = 8ULL;
v___x_1822_ = lean_uint64_shift_left(v___x_1820_, v___x_1821_);
v___x_1823_ = lean_uint64_lor(v___y_1818_, v___x_1822_);
v___x_1824_ = lean_unsigned_to_nat(2u);
v___x_1825_ = lean_nat_add(v_offset_1802_, v___x_1824_);
v___x_1826_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_1437_, v___x_1825_);
if (v___x_1826_ == 0)
{
lean_object* v___x_1827_; lean_object* v___x_1828_; uint8_t v___x_1829_; 
lean_dec(v___x_1825_);
v___x_1827_ = lean_box(v___x_1800_);
v___x_1828_ = l_outOfBounds___redArg(v___x_1827_);
lean_dec(v___x_1827_);
v___x_1829_ = lean_unbox(v___x_1828_);
lean_dec(v___x_1828_);
v___y_1804_ = v___x_1823_;
v___y_1805_ = v___x_1829_;
goto v___jp_1803_;
}
else
{
uint8_t v___x_1830_; 
v___x_1830_ = lean_byte_array_fget(v___x_1437_, v___x_1825_);
lean_dec(v___x_1825_);
v___y_1804_ = v___x_1823_;
v___y_1805_ = v___x_1830_;
goto v___jp_1803_;
}
}
v___jp_1831_:
{
uint64_t v_a_1833_; lean_object* v___x_1834_; lean_object* v___x_1835_; uint8_t v___x_1836_; 
v_a_1833_ = lean_uint8_to_uint64(v___y_1832_);
v___x_1834_ = lean_unsigned_to_nat(1u);
v___x_1835_ = lean_nat_add(v_offset_1802_, v___x_1834_);
v___x_1836_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_1437_, v___x_1835_);
if (v___x_1836_ == 0)
{
lean_object* v___x_1837_; lean_object* v___x_1838_; uint8_t v___x_1839_; 
lean_dec(v___x_1835_);
v___x_1837_ = lean_box(v___x_1800_);
v___x_1838_ = l_outOfBounds___redArg(v___x_1837_);
lean_dec(v___x_1837_);
v___x_1839_ = lean_unbox(v___x_1838_);
lean_dec(v___x_1838_);
v___y_1818_ = v_a_1833_;
v___y_1819_ = v___x_1839_;
goto v___jp_1817_;
}
else
{
uint8_t v___x_1840_; 
v___x_1840_ = lean_byte_array_fget(v___x_1437_, v___x_1835_);
lean_dec(v___x_1835_);
v___y_1818_ = v_a_1833_;
v___y_1819_ = v___x_1840_;
goto v___jp_1817_;
}
}
v___jp_1841_:
{
if (v___y_1842_ == 0)
{
uint8_t v___x_1843_; 
v___x_1843_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_1437_, v_offset_1802_);
if (v___x_1843_ == 0)
{
lean_object* v___x_1844_; lean_object* v___x_1845_; uint8_t v___x_1846_; 
v___x_1844_ = lean_box(v___x_1800_);
v___x_1845_ = l_outOfBounds___redArg(v___x_1844_);
lean_dec(v___x_1844_);
v___x_1846_ = lean_unbox(v___x_1845_);
lean_dec(v___x_1845_);
v___y_1832_ = v___x_1846_;
goto v___jp_1831_;
}
else
{
uint8_t v___x_1847_; 
v___x_1847_ = lean_byte_array_fget(v___x_1437_, v_offset_1802_);
v___y_1832_ = v___x_1847_;
goto v___jp_1831_;
}
}
else
{
size_t v_pos_1848_; uint8_t v___x_1849_; uint64_t v_a_1850_; size_t v___x_1851_; size_t v___x_1852_; uint8_t v___x_1853_; uint64_t v___x_1854_; uint64_t v___x_1855_; uint64_t v___x_1856_; uint64_t v___x_1857_; size_t v___x_1858_; size_t v___x_1859_; uint8_t v___x_1860_; uint64_t v___x_1861_; uint64_t v___x_1862_; uint64_t v___x_1863_; uint64_t v___x_1864_; size_t v___x_1865_; size_t v___x_1866_; uint8_t v___x_1867_; uint64_t v___x_1868_; uint64_t v___x_1869_; uint64_t v___x_1870_; uint64_t v___x_1871_; 
v_pos_1848_ = lean_usize_of_nat(v_offset_1802_);
lean_dec(v_offset_1802_);
v___x_1849_ = lean_byte_array_uget(v___x_1437_, v_pos_1848_);
v_a_1850_ = lean_uint8_to_uint64(v___x_1849_);
v___x_1851_ = ((size_t)1ULL);
v___x_1852_ = lean_usize_add(v_pos_1848_, v___x_1851_);
v___x_1853_ = lean_byte_array_uget(v___x_1437_, v___x_1852_);
v___x_1854_ = lean_uint8_to_uint64(v___x_1853_);
v___x_1855_ = 8ULL;
v___x_1856_ = lean_uint64_shift_left(v___x_1854_, v___x_1855_);
v___x_1857_ = lean_uint64_lor(v_a_1850_, v___x_1856_);
v___x_1858_ = ((size_t)2ULL);
v___x_1859_ = lean_usize_add(v_pos_1848_, v___x_1858_);
v___x_1860_ = lean_byte_array_uget(v___x_1437_, v___x_1859_);
v___x_1861_ = lean_uint8_to_uint64(v___x_1860_);
v___x_1862_ = 16ULL;
v___x_1863_ = lean_uint64_shift_left(v___x_1861_, v___x_1862_);
v___x_1864_ = lean_uint64_lor(v___x_1857_, v___x_1863_);
v___x_1865_ = ((size_t)3ULL);
v___x_1866_ = lean_usize_add(v_pos_1848_, v___x_1865_);
v___x_1867_ = lean_byte_array_uget(v___x_1437_, v___x_1866_);
v___x_1868_ = lean_uint8_to_uint64(v___x_1867_);
v___x_1869_ = 24ULL;
v___x_1870_ = lean_uint64_shift_left(v___x_1868_, v___x_1869_);
v___x_1871_ = lean_uint64_lor(v___x_1864_, v___x_1870_);
v___y_1786_ = v___x_1871_;
goto v___jp_1785_;
}
}
}
v___jp_1444_:
{
lean_object* v_last_1446_; lean_object* v_chargedUntil_1447_; lean_object* v_leading_1448_; lean_object* v_trace_1449_; lean_object* v_node_1450_; lean_object* v_sugar_1451_; lean_object* v___x_1453_; uint8_t v_isShared_1454_; uint8_t v_isSharedCheck_1460_; 
v_last_1446_ = lean_ctor_get(v_b_1439_, 1);
v_chargedUntil_1447_ = lean_ctor_get(v_b_1439_, 2);
v_leading_1448_ = lean_ctor_get(v_b_1439_, 3);
v_trace_1449_ = lean_ctor_get(v_b_1439_, 4);
v_node_1450_ = lean_ctor_get(v_b_1439_, 5);
v_sugar_1451_ = lean_ctor_get(v_b_1439_, 6);
v_isSharedCheck_1460_ = !lean_is_exclusive(v_b_1439_);
if (v_isSharedCheck_1460_ == 0)
{
lean_object* v_unused_1461_; 
v_unused_1461_ = lean_ctor_get(v_b_1439_, 0);
lean_dec(v_unused_1461_);
v___x_1453_ = v_b_1439_;
v_isShared_1454_ = v_isSharedCheck_1460_;
goto v_resetjp_1452_;
}
else
{
lean_inc(v_sugar_1451_);
lean_inc(v_node_1450_);
lean_inc(v_trace_1449_);
lean_inc(v_leading_1448_);
lean_inc(v_chargedUntil_1447_);
lean_inc(v_last_1446_);
lean_dec(v_b_1439_);
v___x_1453_ = lean_box(0);
v_isShared_1454_ = v_isSharedCheck_1460_;
goto v_resetjp_1452_;
}
v_resetjp_1452_:
{
lean_object* v___x_1456_; 
if (v_isShared_1454_ == 0)
{
lean_ctor_set(v___x_1453_, 0, v___y_1445_);
v___x_1456_ = v___x_1453_;
goto v_reusejp_1455_;
}
else
{
lean_object* v_reuseFailAlloc_1459_; 
v_reuseFailAlloc_1459_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_1459_, 0, v___y_1445_);
lean_ctor_set(v_reuseFailAlloc_1459_, 1, v_last_1446_);
lean_ctor_set(v_reuseFailAlloc_1459_, 2, v_chargedUntil_1447_);
lean_ctor_set(v_reuseFailAlloc_1459_, 3, v_leading_1448_);
lean_ctor_set(v_reuseFailAlloc_1459_, 4, v_trace_1449_);
lean_ctor_set(v_reuseFailAlloc_1459_, 5, v_node_1450_);
lean_ctor_set(v_reuseFailAlloc_1459_, 6, v_sugar_1451_);
v___x_1456_ = v_reuseFailAlloc_1459_;
goto v_reusejp_1455_;
}
v_reusejp_1455_:
{
lean_object* v___x_1457_; 
v___x_1457_ = lean_nat_add(v_i_1440_, v_step_1443_);
lean_dec(v_i_1440_);
v_b_1439_ = v___x_1456_;
v_i_1440_ = v___x_1457_;
goto _start;
}
}
}
v___jp_1462_:
{
lean_object* v_offset_1467_; uint8_t v___x_1468_; lean_object* v_data_1469_; 
v_offset_1467_ = lean_nat_mul(v___y_1465_, v___y_1466_);
lean_dec(v___y_1465_);
v___x_1468_ = lean_uint64_to_uint8(v___y_1463_);
v_data_1469_ = lean_byte_array_set(v___y_1464_, v_offset_1467_, v___x_1468_);
switch(v_width_1435_)
{
case 0:
{
lean_dec(v_offset_1467_);
v___y_1445_ = v_data_1469_;
goto v___jp_1444_;
}
case 1:
{
lean_object* v___x_1470_; lean_object* v___x_1471_; uint64_t v___x_1472_; uint64_t v___x_1473_; uint8_t v___x_1474_; lean_object* v___x_1475_; 
v___x_1470_ = lean_unsigned_to_nat(1u);
v___x_1471_ = lean_nat_add(v_offset_1467_, v___x_1470_);
lean_dec(v_offset_1467_);
v___x_1472_ = 8ULL;
v___x_1473_ = lean_uint64_shift_right(v___y_1463_, v___x_1472_);
v___x_1474_ = lean_uint64_to_uint8(v___x_1473_);
v___x_1475_ = lean_byte_array_set(v_data_1469_, v___x_1471_, v___x_1474_);
lean_dec(v___x_1471_);
v___y_1445_ = v___x_1475_;
goto v___jp_1444_;
}
default: 
{
lean_object* v___x_1476_; lean_object* v___x_1477_; uint64_t v___x_1478_; uint64_t v___x_1479_; uint8_t v___x_1480_; lean_object* v___x_1481_; lean_object* v___x_1482_; lean_object* v___x_1483_; uint64_t v___x_1484_; uint64_t v___x_1485_; uint8_t v___x_1486_; lean_object* v___x_1487_; lean_object* v___x_1488_; lean_object* v___x_1489_; uint64_t v___x_1490_; uint64_t v___x_1491_; uint8_t v___x_1492_; lean_object* v___x_1493_; 
v___x_1476_ = lean_unsigned_to_nat(1u);
v___x_1477_ = lean_nat_add(v_offset_1467_, v___x_1476_);
v___x_1478_ = 8ULL;
v___x_1479_ = lean_uint64_shift_right(v___y_1463_, v___x_1478_);
v___x_1480_ = lean_uint64_to_uint8(v___x_1479_);
v___x_1481_ = lean_byte_array_set(v_data_1469_, v___x_1477_, v___x_1480_);
lean_dec(v___x_1477_);
v___x_1482_ = lean_unsigned_to_nat(2u);
v___x_1483_ = lean_nat_add(v_offset_1467_, v___x_1482_);
v___x_1484_ = 16ULL;
v___x_1485_ = lean_uint64_shift_right(v___y_1463_, v___x_1484_);
v___x_1486_ = lean_uint64_to_uint8(v___x_1485_);
v___x_1487_ = lean_byte_array_set(v___x_1481_, v___x_1483_, v___x_1486_);
lean_dec(v___x_1483_);
v___x_1488_ = lean_unsigned_to_nat(3u);
v___x_1489_ = lean_nat_add(v_offset_1467_, v___x_1488_);
lean_dec(v_offset_1467_);
v___x_1490_ = 24ULL;
v___x_1491_ = lean_uint64_shift_right(v___y_1463_, v___x_1490_);
v___x_1492_ = lean_uint64_to_uint8(v___x_1491_);
v___x_1493_ = lean_byte_array_set(v___x_1487_, v___x_1489_, v___x_1492_);
lean_dec(v___x_1489_);
v___y_1445_ = v___x_1493_;
goto v___jp_1444_;
}
}
}
v___jp_1494_:
{
switch(v_width_1435_)
{
case 0:
{
lean_object* v___x_1498_; 
v___x_1498_ = lean_unsigned_to_nat(1u);
v___y_1463_ = v___y_1497_;
v___y_1464_ = v___y_1495_;
v___y_1465_ = v___y_1496_;
v___y_1466_ = v___x_1498_;
goto v___jp_1462_;
}
case 1:
{
lean_object* v___x_1499_; 
v___x_1499_ = lean_unsigned_to_nat(2u);
v___y_1463_ = v___y_1497_;
v___y_1464_ = v___y_1495_;
v___y_1465_ = v___y_1496_;
v___y_1466_ = v___x_1499_;
goto v___jp_1462_;
}
default: 
{
lean_object* v___x_1500_; 
v___x_1500_ = lean_unsigned_to_nat(4u);
v___y_1463_ = v___y_1497_;
v___y_1464_ = v___y_1495_;
v___y_1465_ = v___y_1496_;
v___y_1466_ = v___x_1500_;
goto v___jp_1462_;
}
}
}
v___jp_1501_:
{
uint64_t v___x_1506_; uint64_t v___x_1507_; uint8_t v___x_1508_; 
v___x_1506_ = lean_uint64_add(v___y_1505_, v_field_1432_);
v___x_1507_ = lean_uint64_sub(v___x_1506_, v___y_1502_);
v___x_1508_ = lean_uint64_dec_le(v_field_1432_, v___x_1507_);
if (v___x_1508_ == 0)
{
v___y_1495_ = v___y_1503_;
v___y_1496_ = v___y_1504_;
v___y_1497_ = v___x_1507_;
goto v___jp_1494_;
}
else
{
uint64_t v___x_1509_; 
v___x_1509_ = lean_uint64_sub(v___x_1507_, v_field_1432_);
v___y_1495_ = v___y_1503_;
v___y_1496_ = v___y_1504_;
v___y_1497_ = v___x_1509_;
goto v___jp_1494_;
}
}
v___jp_1510_:
{
uint64_t v___x_1516_; uint64_t v___x_1517_; uint64_t v___x_1518_; uint64_t v___x_1519_; 
v___x_1516_ = lean_uint8_to_uint64(v___y_1515_);
v___x_1517_ = 24ULL;
v___x_1518_ = lean_uint64_shift_left(v___x_1516_, v___x_1517_);
v___x_1519_ = lean_uint64_lor(v___y_1512_, v___x_1518_);
v___y_1502_ = v___y_1511_;
v___y_1503_ = v___y_1513_;
v___y_1504_ = v___y_1514_;
v___y_1505_ = v___x_1519_;
goto v___jp_1501_;
}
v___jp_1520_:
{
uint64_t v___x_1526_; uint64_t v___x_1527_; uint64_t v___x_1528_; uint64_t v___x_1529_; 
v___x_1526_ = lean_uint8_to_uint64(v___y_1525_);
v___x_1527_ = 8ULL;
v___x_1528_ = lean_uint64_shift_left(v___x_1526_, v___x_1527_);
v___x_1529_ = lean_uint64_lor(v___y_1522_, v___x_1528_);
v___y_1502_ = v___y_1521_;
v___y_1503_ = v___y_1523_;
v___y_1504_ = v___y_1524_;
v___y_1505_ = v___x_1529_;
goto v___jp_1501_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___boxed(lean_object* v_field_1878_, lean_object* v_ctx_1879_, lean_object* v___y_1880_, lean_object* v_width_1881_, lean_object* v___x_1882_, lean_object* v___x_1883_, lean_object* v_range_1884_, lean_object* v_b_1885_, lean_object* v_i_1886_, lean_object* v___y_1887_){
_start:
{
uint64_t v_field_boxed_1888_; uint64_t v_ctx_boxed_1889_; uint64_t v___y_95293__boxed_1890_; uint8_t v_width_boxed_1891_; lean_object* v_res_1892_; 
v_field_boxed_1888_ = lean_unbox_uint64(v_field_1878_);
lean_dec_ref(v_field_1878_);
v_ctx_boxed_1889_ = lean_unbox_uint64(v_ctx_1879_);
lean_dec_ref(v_ctx_1879_);
v___y_95293__boxed_1890_ = lean_unbox_uint64(v___y_1880_);
lean_dec_ref(v___y_1880_);
v_width_boxed_1891_ = lean_unbox(v_width_1881_);
v_res_1892_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg(v_field_boxed_1888_, v_ctx_boxed_1889_, v___y_95293__boxed_1890_, v_width_boxed_1891_, v___x_1882_, v___x_1883_, v_range_1884_, v_b_1885_, v_i_1886_, v___y_1887_);
lean_dec_ref(v_range_1884_);
lean_dec_ref(v___x_1883_);
lean_dec_ref(v___x_1882_);
return v_res_1892_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5___redArg(lean_object* v___x_1893_, lean_object* v_limits_1894_, uint64_t v_field_1895_, uint64_t v_ctx_1896_, uint8_t v_width_1897_, uint8_t v_provenance_1898_, lean_object* v___x_1899_, lean_object* v_range_1900_, lean_object* v_b_1901_, lean_object* v_i_1902_, lean_object* v___y_1903_){
_start:
{
lean_object* v_a_1905_; lean_object* v_snd_1906_; lean_object* v_stop_1909_; lean_object* v_step_1910_; lean_object* v_a_1912_; lean_object* v_snd_1913_; uint8_t v___x_1916_; 
v_stop_1909_ = lean_ctor_get(v_range_1900_, 1);
v_step_1910_ = lean_ctor_get(v_range_1900_, 2);
v___x_1916_ = lean_nat_dec_lt(v_i_1902_, v_stop_1909_);
if (v___x_1916_ == 0)
{
lean_object* v___x_1917_; lean_object* v___x_1918_; 
lean_dec(v_i_1902_);
v___x_1917_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1917_, 0, v_b_1901_);
v___x_1918_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1918_, 0, v___x_1917_);
lean_ctor_set(v___x_1918_, 1, v___y_1903_);
return v___x_1918_;
}
else
{
lean_object* v_dense_1919_; lean_object* v_last_1920_; lean_object* v_chargedUntil_1921_; lean_object* v_leading_1922_; lean_object* v_trace_1923_; lean_object* v_node_1924_; lean_object* v_sugar_1925_; uint8_t v___x_1926_; 
v_dense_1919_ = lean_ctor_get(v_b_1901_, 0);
v_last_1920_ = lean_ctor_get(v_b_1901_, 1);
v_chargedUntil_1921_ = lean_ctor_get(v_b_1901_, 2);
v_leading_1922_ = lean_ctor_get(v_b_1901_, 3);
v_trace_1923_ = lean_ctor_get(v_b_1901_, 4);
v_node_1924_ = lean_ctor_get(v_b_1901_, 5);
v_sugar_1925_ = lean_ctor_get(v_b_1901_, 6);
v___x_1926_ = lean_nat_dec_lt(v_last_1920_, v_i_1902_);
if (v___x_1926_ == 0)
{
lean_object* v_reducerRank_1927_; lean_object* v___x_1928_; lean_object* v___y_1930_; lean_object* v___y_1931_; lean_object* v___y_1932_; lean_object* v___y_1933_; lean_object* v___y_1934_; lean_object* v___y_1935_; lean_object* v___y_1936_; lean_object* v___y_1937_; lean_object* v___y_1938_; lean_object* v___y_1939_; lean_object* v___y_1940_; uint64_t v___y_1941_; lean_object* v___y_1942_; lean_object* v___y_2004_; lean_object* v___y_2005_; lean_object* v___y_2006_; lean_object* v___y_2007_; lean_object* v___y_2008_; lean_object* v___y_2009_; lean_object* v___y_2010_; lean_object* v___y_2011_; lean_object* v___y_2012_; lean_object* v___y_2013_; lean_object* v___y_2014_; lean_object* v___y_2015_; uint64_t v___y_2016_; lean_object* v___y_2017_; lean_object* v___y_2020_; lean_object* v___y_2021_; lean_object* v___y_2022_; lean_object* v___y_2023_; lean_object* v___y_2024_; lean_object* v___y_2025_; lean_object* v___y_2026_; lean_object* v___y_2027_; lean_object* v___y_2028_; lean_object* v___y_2029_; lean_object* v___y_2030_; lean_object* v___y_2031_; uint64_t v___y_2032_; lean_object* v___y_2033_; uint64_t v___y_2034_; lean_object* v___y_2038_; lean_object* v___y_2039_; lean_object* v___y_2040_; lean_object* v___y_2041_; lean_object* v___y_2042_; lean_object* v___y_2043_; lean_object* v___y_2044_; lean_object* v___y_2045_; lean_object* v___y_2046_; uint64_t v___y_2047_; lean_object* v___y_2048_; lean_object* v___y_2049_; lean_object* v___y_2050_; lean_object* v___y_2051_; uint64_t v___y_2052_; uint8_t v___y_2053_; lean_object* v___y_2059_; lean_object* v___y_2060_; lean_object* v___y_2061_; lean_object* v___y_2062_; lean_object* v___y_2063_; uint8_t v___y_2064_; lean_object* v___y_2065_; lean_object* v___y_2066_; lean_object* v___y_2067_; lean_object* v___y_2068_; lean_object* v___y_2069_; lean_object* v___y_2070_; lean_object* v___y_2071_; uint64_t v___y_2072_; lean_object* v___y_2073_; uint64_t v___y_2074_; lean_object* v___y_2075_; uint8_t v___y_2076_; lean_object* v___y_2089_; uint64_t v___y_2090_; lean_object* v___y_2091_; lean_object* v___y_2092_; lean_object* v___y_2093_; lean_object* v___y_2094_; uint8_t v___y_2095_; lean_object* v___y_2096_; lean_object* v___y_2097_; lean_object* v___y_2098_; lean_object* v___y_2099_; lean_object* v___y_2100_; lean_object* v___y_2101_; lean_object* v___y_2102_; lean_object* v___y_2103_; lean_object* v___y_2104_; uint64_t v___y_2105_; uint8_t v___y_2106_; lean_object* v___y_2119_; lean_object* v___y_2120_; lean_object* v___y_2121_; lean_object* v___y_2122_; lean_object* v___y_2123_; uint8_t v___y_2124_; lean_object* v___y_2125_; lean_object* v___y_2126_; lean_object* v___y_2127_; lean_object* v___y_2128_; lean_object* v___y_2129_; lean_object* v___y_2130_; lean_object* v___y_2131_; lean_object* v___y_2132_; uint64_t v___y_2133_; lean_object* v___y_2134_; uint8_t v___y_2135_; lean_object* v___y_2144_; lean_object* v___y_2145_; lean_object* v___y_2146_; lean_object* v___y_2147_; lean_object* v___y_2148_; uint8_t v___y_2149_; lean_object* v___y_2150_; lean_object* v___y_2151_; lean_object* v___y_2152_; lean_object* v___y_2153_; lean_object* v___y_2154_; lean_object* v___y_2155_; lean_object* v___y_2156_; lean_object* v___y_2157_; lean_object* v___y_2158_; uint64_t v___y_2159_; uint8_t v___y_2160_; lean_object* v___x_2190_; lean_object* v___y_2192_; lean_object* v___y_2193_; lean_object* v___y_2194_; lean_object* v___y_2195_; lean_object* v___y_2196_; lean_object* v___y_2197_; lean_object* v___y_2198_; lean_object* v___y_2199_; lean_object* v___y_2200_; uint64_t v___y_2201_; uint64_t v___y_2202_; lean_object* v___y_2225_; lean_object* v___y_2226_; lean_object* v___y_2227_; lean_object* v___y_2228_; uint64_t v___y_2229_; lean_object* v___y_2230_; lean_object* v___y_2231_; lean_object* v___y_2232_; lean_object* v___y_2233_; lean_object* v___y_2234_; uint64_t v___y_2235_; uint8_t v___y_2236_; lean_object* v___y_2242_; uint64_t v___y_2243_; lean_object* v___y_2244_; lean_object* v___y_2245_; uint8_t v___y_2246_; lean_object* v___y_2247_; lean_object* v___y_2248_; lean_object* v___y_2249_; lean_object* v___y_2250_; lean_object* v___y_2251_; lean_object* v___y_2252_; lean_object* v___y_2253_; uint64_t v___y_2254_; uint8_t v___y_2255_; lean_object* v___y_2268_; lean_object* v___y_2269_; lean_object* v___y_2270_; uint8_t v___y_2271_; lean_object* v___y_2272_; lean_object* v___y_2273_; lean_object* v___y_2274_; uint64_t v___y_2275_; lean_object* v___y_2276_; lean_object* v___y_2277_; lean_object* v___y_2278_; lean_object* v___y_2279_; uint64_t v___y_2280_; uint8_t v___y_2281_; lean_object* v___y_2294_; lean_object* v___y_2295_; lean_object* v___y_2296_; lean_object* v___y_2297_; lean_object* v___y_2298_; uint8_t v___y_2299_; lean_object* v___y_2300_; lean_object* v___y_2301_; lean_object* v___y_2302_; lean_object* v___y_2303_; lean_object* v___y_2304_; uint64_t v___y_2305_; uint8_t v___y_2306_; lean_object* v___y_2315_; lean_object* v___y_2316_; lean_object* v___y_2317_; lean_object* v___y_2318_; lean_object* v___y_2319_; uint8_t v___y_2320_; lean_object* v___y_2321_; lean_object* v___y_2322_; lean_object* v___y_2323_; lean_object* v___y_2324_; lean_object* v___y_2325_; uint64_t v___y_2326_; uint8_t v___y_2327_; lean_object* v___y_2358_; lean_object* v___y_2359_; lean_object* v___y_2360_; lean_object* v___y_2361_; lean_object* v___y_2362_; lean_object* v___y_2363_; lean_object* v___y_2364_; lean_object* v___y_2365_; lean_object* v___y_2366_; uint64_t v___y_2367_; lean_object* v___y_2380_; lean_object* v___y_2381_; lean_object* v___y_2382_; lean_object* v___y_2383_; lean_object* v___y_2384_; lean_object* v___y_2385_; lean_object* v___y_2386_; lean_object* v___y_2387_; lean_object* v___y_2388_; uint64_t v___y_2389_; uint8_t v___y_2390_; lean_object* v___y_2396_; lean_object* v___y_2397_; uint8_t v___y_2398_; lean_object* v___y_2399_; lean_object* v___y_2400_; lean_object* v___y_2401_; uint64_t v___y_2402_; lean_object* v___y_2403_; lean_object* v___y_2404_; lean_object* v___y_2405_; lean_object* v___y_2406_; lean_object* v___y_2407_; uint8_t v___y_2408_; lean_object* v___y_2421_; lean_object* v___y_2422_; uint8_t v___y_2423_; uint64_t v___y_2424_; lean_object* v___y_2425_; lean_object* v___y_2426_; lean_object* v___y_2427_; lean_object* v___y_2428_; lean_object* v___y_2429_; lean_object* v___y_2430_; lean_object* v___y_2431_; lean_object* v___y_2432_; uint8_t v___y_2433_; lean_object* v___y_2446_; lean_object* v___y_2447_; uint64_t v___y_2448_; lean_object* v___y_2449_; lean_object* v___y_2450_; lean_object* v___y_2451_; lean_object* v___y_2452_; lean_object* v___y_2453_; lean_object* v___y_2454_; lean_object* v___y_2455_; uint8_t v___y_2456_; lean_object* v___y_2462_; lean_object* v___y_2463_; uint8_t v___y_2464_; lean_object* v___y_2465_; lean_object* v___y_2466_; lean_object* v___y_2467_; lean_object* v___y_2468_; lean_object* v___y_2469_; lean_object* v___y_2470_; lean_object* v___y_2471_; lean_object* v___y_2472_; uint8_t v___y_2473_; lean_object* v___y_2488_; lean_object* v___y_2489_; uint8_t v___y_2490_; lean_object* v___y_2491_; lean_object* v___y_2492_; lean_object* v___y_2493_; lean_object* v___y_2494_; lean_object* v___y_2495_; lean_object* v___y_2496_; lean_object* v___y_2497_; lean_object* v___y_2498_; uint8_t v___y_2499_; lean_object* v___y_2537_; lean_object* v___y_2538_; uint8_t v___y_2539_; lean_object* v___y_2540_; lean_object* v___y_2541_; lean_object* v___y_2542_; lean_object* v___y_2543_; lean_object* v___y_2544_; lean_object* v___y_2545_; lean_object* v___y_2546_; lean_object* v___y_2547_; lean_object* v_scan_2556_; lean_object* v_dense_2557_; lean_object* v_last_2558_; lean_object* v_chargedUntil_2559_; lean_object* v_leading_2560_; lean_object* v_trace_2561_; lean_object* v_node_2562_; lean_object* v_sugar_2563_; lean_object* v___y_2564_; lean_object* v___y_2569_; uint8_t v___x_2577_; 
lean_inc(v_sugar_1925_);
lean_inc(v_node_1924_);
lean_inc_ref(v_trace_1923_);
lean_inc(v_leading_1922_);
lean_inc(v_chargedUntil_1921_);
lean_inc(v_last_1920_);
lean_inc_ref(v_dense_1919_);
v_reducerRank_1927_ = lean_unsigned_to_nat(0u);
v___x_1928_ = lean_unsigned_to_nat(1u);
v___x_2190_ = lp_Hex_Hex_Groebner_instInhabitedPivot_default;
v___x_2577_ = lean_nat_dec_le(v_chargedUntil_1921_, v_i_1902_);
if (v___x_2577_ == 0)
{
v_scan_2556_ = v_b_1901_;
v_dense_2557_ = v_dense_1919_;
v_last_2558_ = v_last_1920_;
v_chargedUntil_2559_ = v_chargedUntil_1921_;
v_leading_2560_ = v_leading_1922_;
v_trace_2561_ = v_trace_1923_;
v_node_2562_ = v_node_1924_;
v_sugar_2563_ = v_sugar_1925_;
v___y_2564_ = v___y_1903_;
goto v___jp_2555_;
}
else
{
lean_object* v___x_2578_; lean_object* v___x_2579_; lean_object* v___x_2580_; uint8_t v___x_2581_; 
lean_dec(v_chargedUntil_1921_);
lean_dec_ref(v_b_1901_);
v___x_2578_ = lean_unsigned_to_nat(64u);
v___x_2579_ = lean_nat_add(v_i_1902_, v___x_2578_);
v___x_2580_ = lean_nat_add(v_last_1920_, v___x_1928_);
v___x_2581_ = lean_nat_dec_le(v___x_2579_, v___x_2580_);
if (v___x_2581_ == 0)
{
lean_dec(v___x_2579_);
v___y_2569_ = v___x_2580_;
goto v___jp_2568_;
}
else
{
lean_dec(v___x_2580_);
v___y_2569_ = v___x_2579_;
goto v___jp_2568_;
}
}
v___jp_1929_:
{
lean_object* v___x_1943_; lean_object* v_fst_1944_; 
v___x_1943_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_1894_, v___y_1938_, v___y_1936_);
v_fst_1944_ = lean_ctor_get(v___x_1943_, 0);
lean_inc(v_fst_1944_);
if (lean_obj_tag(v_fst_1944_) == 0)
{
lean_object* v_snd_1945_; lean_object* v_a_1946_; 
lean_dec(v___y_1942_);
lean_dec_ref(v___y_1940_);
lean_dec(v___y_1939_);
lean_dec(v___y_1938_);
lean_dec_ref(v___y_1937_);
lean_dec(v___y_1935_);
lean_dec_ref(v___y_1934_);
lean_dec_ref(v___y_1933_);
lean_dec(v___y_1932_);
lean_dec(v___y_1931_);
lean_dec(v___y_1930_);
lean_dec(v_i_1902_);
v_snd_1945_ = lean_ctor_get(v___x_1943_, 1);
lean_inc(v_snd_1945_);
lean_dec_ref(v___x_1943_);
v_a_1946_ = lean_ctor_get(v_fst_1944_, 0);
lean_inc(v_a_1946_);
lean_dec_ref_known(v_fst_1944_, 1);
v_a_1905_ = v_a_1946_;
v_snd_1906_ = v_snd_1945_;
goto v___jp_1904_;
}
else
{
lean_object* v_snd_1947_; lean_object* v___x_1948_; lean_object* v___x_1949_; lean_object* v___x_1950_; lean_object* v_fst_1951_; lean_object* v_snd_1952_; lean_object* v_a_1953_; lean_object* v_work_1954_; lean_object* v_inputEntries_1955_; lean_object* v_outputEntries_1956_; lean_object* v_packedBytes_1957_; lean_object* v_traceNodes_1958_; lean_object* v_processedRows_1959_; lean_object* v_reductions_1960_; lean_object* v_zeroRows_1961_; lean_object* v___x_1963_; uint8_t v_isShared_1964_; uint8_t v_isSharedCheck_2002_; 
lean_dec_ref_known(v_fst_1944_, 1);
v_snd_1947_ = lean_ctor_get(v___x_1943_, 1);
lean_inc(v_snd_1947_);
lean_dec_ref(v___x_1943_);
v___x_1948_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_1948_, 0, v___y_1937_);
lean_ctor_set(v___x_1948_, 1, v___y_1932_);
lean_ctor_set(v___x_1948_, 2, v___y_1930_);
lean_ctor_set(v___x_1948_, 3, v___y_1939_);
lean_ctor_set(v___x_1948_, 4, v___y_1934_);
lean_ctor_set(v___x_1948_, 5, v___y_1931_);
lean_ctor_set(v___x_1948_, 6, v___y_1942_);
v___x_1949_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1949_, 0, v_reducerRank_1927_);
lean_ctor_set(v___x_1949_, 1, v___y_1938_);
lean_ctor_set(v___x_1949_, 2, v___x_1928_);
v___x_1950_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg(v_field_1895_, v_ctx_1896_, v___y_1941_, v_width_1897_, v___y_1940_, v___y_1933_, v___x_1949_, v___x_1948_, v_reducerRank_1927_, v_snd_1947_);
lean_dec_ref_known(v___x_1949_, 3);
lean_dec_ref(v___y_1933_);
lean_dec_ref(v___y_1940_);
v_fst_1951_ = lean_ctor_get(v___x_1950_, 0);
lean_inc(v_fst_1951_);
v_snd_1952_ = lean_ctor_get(v___x_1950_, 1);
lean_inc(v_snd_1952_);
lean_dec_ref(v___x_1950_);
v_a_1953_ = lean_ctor_get(v_fst_1951_, 0);
lean_inc(v_a_1953_);
lean_dec(v_fst_1951_);
v_work_1954_ = lean_ctor_get(v_snd_1952_, 0);
v_inputEntries_1955_ = lean_ctor_get(v_snd_1952_, 1);
v_outputEntries_1956_ = lean_ctor_get(v_snd_1952_, 2);
v_packedBytes_1957_ = lean_ctor_get(v_snd_1952_, 3);
v_traceNodes_1958_ = lean_ctor_get(v_snd_1952_, 4);
v_processedRows_1959_ = lean_ctor_get(v_snd_1952_, 5);
v_reductions_1960_ = lean_ctor_get(v_snd_1952_, 6);
v_zeroRows_1961_ = lean_ctor_get(v_snd_1952_, 7);
v_isSharedCheck_2002_ = !lean_is_exclusive(v_snd_1952_);
if (v_isSharedCheck_2002_ == 0)
{
v___x_1963_ = v_snd_1952_;
v_isShared_1964_ = v_isSharedCheck_2002_;
goto v_resetjp_1962_;
}
else
{
lean_inc(v_zeroRows_1961_);
lean_inc(v_reductions_1960_);
lean_inc(v_processedRows_1959_);
lean_inc(v_traceNodes_1958_);
lean_inc(v_packedBytes_1957_);
lean_inc(v_outputEntries_1956_);
lean_inc(v_inputEntries_1955_);
lean_inc(v_work_1954_);
lean_dec(v_snd_1952_);
v___x_1963_ = lean_box(0);
v_isShared_1964_ = v_isSharedCheck_2002_;
goto v_resetjp_1962_;
}
v_resetjp_1962_:
{
lean_object* v_dense_1965_; lean_object* v_last_1966_; lean_object* v_chargedUntil_1967_; lean_object* v_leading_1968_; lean_object* v_trace_1969_; lean_object* v_node_1970_; lean_object* v_sugar_1971_; lean_object* v___x_1972_; lean_object* v___x_1974_; 
v_dense_1965_ = lean_ctor_get(v_a_1953_, 0);
v_last_1966_ = lean_ctor_get(v_a_1953_, 1);
v_chargedUntil_1967_ = lean_ctor_get(v_a_1953_, 2);
v_leading_1968_ = lean_ctor_get(v_a_1953_, 3);
v_trace_1969_ = lean_ctor_get(v_a_1953_, 4);
v_node_1970_ = lean_ctor_get(v_a_1953_, 5);
v_sugar_1971_ = lean_ctor_get(v_a_1953_, 6);
v___x_1972_ = lean_nat_add(v_reductions_1960_, v___x_1928_);
lean_dec(v_reductions_1960_);
if (v_isShared_1964_ == 0)
{
lean_ctor_set(v___x_1963_, 6, v___x_1972_);
v___x_1974_ = v___x_1963_;
goto v_reusejp_1973_;
}
else
{
lean_object* v_reuseFailAlloc_2001_; 
v_reuseFailAlloc_2001_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_2001_, 0, v_work_1954_);
lean_ctor_set(v_reuseFailAlloc_2001_, 1, v_inputEntries_1955_);
lean_ctor_set(v_reuseFailAlloc_2001_, 2, v_outputEntries_1956_);
lean_ctor_set(v_reuseFailAlloc_2001_, 3, v_packedBytes_1957_);
lean_ctor_set(v_reuseFailAlloc_2001_, 4, v_traceNodes_1958_);
lean_ctor_set(v_reuseFailAlloc_2001_, 5, v_processedRows_1959_);
lean_ctor_set(v_reuseFailAlloc_2001_, 6, v___x_1972_);
lean_ctor_set(v_reuseFailAlloc_2001_, 7, v_zeroRows_1961_);
v___x_1974_ = v_reuseFailAlloc_2001_;
goto v_reusejp_1973_;
}
v_reusejp_1973_:
{
if (lean_obj_tag(v_node_1970_) == 1)
{
if (lean_obj_tag(v___y_1935_) == 1)
{
lean_object* v___x_1976_; uint8_t v_isShared_1977_; uint8_t v_isSharedCheck_1993_; 
lean_inc_ref(v_node_1970_);
lean_inc(v_sugar_1971_);
lean_inc_ref(v_trace_1969_);
lean_inc(v_leading_1968_);
lean_inc(v_chargedUntil_1967_);
lean_inc(v_last_1966_);
lean_inc_ref(v_dense_1965_);
v_isSharedCheck_1993_ = !lean_is_exclusive(v_a_1953_);
if (v_isSharedCheck_1993_ == 0)
{
lean_object* v_unused_1994_; lean_object* v_unused_1995_; lean_object* v_unused_1996_; lean_object* v_unused_1997_; lean_object* v_unused_1998_; lean_object* v_unused_1999_; lean_object* v_unused_2000_; 
v_unused_1994_ = lean_ctor_get(v_a_1953_, 6);
lean_dec(v_unused_1994_);
v_unused_1995_ = lean_ctor_get(v_a_1953_, 5);
lean_dec(v_unused_1995_);
v_unused_1996_ = lean_ctor_get(v_a_1953_, 4);
lean_dec(v_unused_1996_);
v_unused_1997_ = lean_ctor_get(v_a_1953_, 3);
lean_dec(v_unused_1997_);
v_unused_1998_ = lean_ctor_get(v_a_1953_, 2);
lean_dec(v_unused_1998_);
v_unused_1999_ = lean_ctor_get(v_a_1953_, 1);
lean_dec(v_unused_1999_);
v_unused_2000_ = lean_ctor_get(v_a_1953_, 0);
lean_dec(v_unused_2000_);
v___x_1976_ = v_a_1953_;
v_isShared_1977_ = v_isSharedCheck_1993_;
goto v_resetjp_1975_;
}
else
{
lean_dec(v_a_1953_);
v___x_1976_ = lean_box(0);
v_isShared_1977_ = v_isSharedCheck_1993_;
goto v_resetjp_1975_;
}
v_resetjp_1975_:
{
lean_object* v_val_1978_; lean_object* v_val_1979_; uint64_t v___x_1980_; lean_object* v___x_1981_; lean_object* v___x_1982_; lean_object* v_fst_1983_; 
v_val_1978_ = lean_ctor_get(v_node_1970_, 0);
lean_inc(v_val_1978_);
lean_dec_ref_known(v_node_1970_, 1);
v_val_1979_ = lean_ctor_get(v___y_1935_, 0);
lean_inc(v_val_1979_);
lean_dec_ref_known(v___y_1935_, 1);
v___x_1980_ = lean_uint64_sub(v_field_1895_, v___y_1941_);
v___x_1981_ = lean_alloc_ctor(1, 2, 8);
lean_ctor_set(v___x_1981_, 0, v_val_1978_);
lean_ctor_set(v___x_1981_, 1, v_val_1979_);
lean_ctor_set_uint64(v___x_1981_, sizeof(void*)*2, v___x_1980_);
v___x_1982_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_1894_, v_provenance_1898_, v_trace_1969_, v___x_1981_, v___x_1974_);
v_fst_1983_ = lean_ctor_get(v___x_1982_, 0);
lean_inc(v_fst_1983_);
if (lean_obj_tag(v_fst_1983_) == 0)
{
lean_object* v_snd_1984_; lean_object* v_a_1985_; 
lean_del_object(v___x_1976_);
lean_dec(v_sugar_1971_);
lean_dec(v_leading_1968_);
lean_dec(v_chargedUntil_1967_);
lean_dec(v_last_1966_);
lean_dec_ref(v_dense_1965_);
lean_dec(v_i_1902_);
v_snd_1984_ = lean_ctor_get(v___x_1982_, 1);
lean_inc(v_snd_1984_);
lean_dec_ref(v___x_1982_);
v_a_1985_ = lean_ctor_get(v_fst_1983_, 0);
lean_inc(v_a_1985_);
lean_dec_ref_known(v_fst_1983_, 1);
v_a_1905_ = v_a_1985_;
v_snd_1906_ = v_snd_1984_;
goto v___jp_1904_;
}
else
{
lean_object* v_a_1986_; lean_object* v_snd_1987_; lean_object* v_fst_1988_; lean_object* v_snd_1989_; lean_object* v___x_1991_; 
v_a_1986_ = lean_ctor_get(v_fst_1983_, 0);
lean_inc(v_a_1986_);
lean_dec_ref_known(v_fst_1983_, 1);
v_snd_1987_ = lean_ctor_get(v___x_1982_, 1);
lean_inc(v_snd_1987_);
lean_dec_ref(v___x_1982_);
v_fst_1988_ = lean_ctor_get(v_a_1986_, 0);
lean_inc(v_fst_1988_);
v_snd_1989_ = lean_ctor_get(v_a_1986_, 1);
lean_inc(v_snd_1989_);
lean_dec(v_a_1986_);
if (v_isShared_1977_ == 0)
{
lean_ctor_set(v___x_1976_, 5, v_snd_1989_);
lean_ctor_set(v___x_1976_, 4, v_fst_1988_);
v___x_1991_ = v___x_1976_;
goto v_reusejp_1990_;
}
else
{
lean_object* v_reuseFailAlloc_1992_; 
v_reuseFailAlloc_1992_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_1992_, 0, v_dense_1965_);
lean_ctor_set(v_reuseFailAlloc_1992_, 1, v_last_1966_);
lean_ctor_set(v_reuseFailAlloc_1992_, 2, v_chargedUntil_1967_);
lean_ctor_set(v_reuseFailAlloc_1992_, 3, v_leading_1968_);
lean_ctor_set(v_reuseFailAlloc_1992_, 4, v_fst_1988_);
lean_ctor_set(v_reuseFailAlloc_1992_, 5, v_snd_1989_);
lean_ctor_set(v_reuseFailAlloc_1992_, 6, v_sugar_1971_);
v___x_1991_ = v_reuseFailAlloc_1992_;
goto v_reusejp_1990_;
}
v_reusejp_1990_:
{
v_a_1912_ = v___x_1991_;
v_snd_1913_ = v_snd_1987_;
goto v___jp_1911_;
}
}
}
}
else
{
lean_dec(v___y_1935_);
v_a_1912_ = v_a_1953_;
v_snd_1913_ = v___x_1974_;
goto v___jp_1911_;
}
}
else
{
lean_dec(v___y_1935_);
v_a_1912_ = v_a_1953_;
v_snd_1913_ = v___x_1974_;
goto v___jp_1911_;
}
}
}
}
}
v___jp_2003_:
{
uint8_t v___x_2018_; 
v___x_2018_ = lean_nat_dec_le(v___y_2004_, v___y_2013_);
if (v___x_2018_ == 0)
{
lean_dec(v___y_2013_);
v___y_1930_ = v___y_2011_;
v___y_1931_ = v___y_2012_;
v___y_1932_ = v___y_2017_;
v___y_1933_ = v___y_2005_;
v___y_1934_ = v___y_2006_;
v___y_1935_ = v___y_2007_;
v___y_1936_ = v___y_2008_;
v___y_1937_ = v___y_2009_;
v___y_1938_ = v___y_2014_;
v___y_1939_ = v___y_2010_;
v___y_1940_ = v___y_2015_;
v___y_1941_ = v___y_2016_;
v___y_1942_ = v___y_2004_;
goto v___jp_1929_;
}
else
{
lean_dec(v___y_2004_);
v___y_1930_ = v___y_2011_;
v___y_1931_ = v___y_2012_;
v___y_1932_ = v___y_2017_;
v___y_1933_ = v___y_2005_;
v___y_1934_ = v___y_2006_;
v___y_1935_ = v___y_2007_;
v___y_1936_ = v___y_2008_;
v___y_1937_ = v___y_2009_;
v___y_1938_ = v___y_2014_;
v___y_1939_ = v___y_2010_;
v___y_1940_ = v___y_2015_;
v___y_1941_ = v___y_2016_;
v___y_1942_ = v___y_2013_;
goto v___jp_1929_;
}
}
v___jp_2019_:
{
lean_object* v___x_2035_; uint8_t v___x_2036_; 
v___x_2035_ = lean_uint64_to_nat(v___y_2034_);
v___x_2036_ = lean_nat_dec_le(v___y_2031_, v___x_2035_);
if (v___x_2036_ == 0)
{
lean_dec(v___x_2035_);
v___y_2004_ = v___y_2020_;
v___y_2005_ = v___y_2021_;
v___y_2006_ = v___y_2022_;
v___y_2007_ = v___y_2023_;
v___y_2008_ = v___y_2024_;
v___y_2009_ = v___y_2025_;
v___y_2010_ = v___y_2026_;
v___y_2011_ = v___y_2027_;
v___y_2012_ = v___y_2028_;
v___y_2013_ = v___y_2029_;
v___y_2014_ = v___y_2030_;
v___y_2015_ = v___y_2033_;
v___y_2016_ = v___y_2032_;
v___y_2017_ = v___y_2031_;
goto v___jp_2003_;
}
else
{
lean_dec(v___y_2031_);
v___y_2004_ = v___y_2020_;
v___y_2005_ = v___y_2021_;
v___y_2006_ = v___y_2022_;
v___y_2007_ = v___y_2023_;
v___y_2008_ = v___y_2024_;
v___y_2009_ = v___y_2025_;
v___y_2010_ = v___y_2026_;
v___y_2011_ = v___y_2027_;
v___y_2012_ = v___y_2028_;
v___y_2013_ = v___y_2029_;
v___y_2014_ = v___y_2030_;
v___y_2015_ = v___y_2033_;
v___y_2016_ = v___y_2032_;
v___y_2017_ = v___x_2035_;
goto v___jp_2003_;
}
}
v___jp_2037_:
{
uint64_t v___x_2054_; uint64_t v___x_2055_; uint64_t v___x_2056_; uint64_t v___x_2057_; 
v___x_2054_ = lean_uint8_to_uint64(v___y_2053_);
v___x_2055_ = 24ULL;
v___x_2056_ = lean_uint64_shift_left(v___x_2054_, v___x_2055_);
v___x_2057_ = lean_uint64_lor(v___y_2047_, v___x_2056_);
v___y_2020_ = v___y_2038_;
v___y_2021_ = v___y_2039_;
v___y_2022_ = v___y_2040_;
v___y_2023_ = v___y_2041_;
v___y_2024_ = v___y_2042_;
v___y_2025_ = v___y_2043_;
v___y_2026_ = v___y_2044_;
v___y_2027_ = v___y_2045_;
v___y_2028_ = v___y_2046_;
v___y_2029_ = v___y_2048_;
v___y_2030_ = v___y_2049_;
v___y_2031_ = v___y_2050_;
v___y_2032_ = v___y_2052_;
v___y_2033_ = v___y_2051_;
v___y_2034_ = v___x_2057_;
goto v___jp_2019_;
}
v___jp_2058_:
{
uint64_t v___x_2077_; uint64_t v___x_2078_; uint64_t v___x_2079_; uint64_t v___x_2080_; lean_object* v___x_2081_; lean_object* v___x_2082_; uint8_t v___x_2083_; 
v___x_2077_ = lean_uint8_to_uint64(v___y_2076_);
v___x_2078_ = 16ULL;
v___x_2079_ = lean_uint64_shift_left(v___x_2077_, v___x_2078_);
v___x_2080_ = lean_uint64_lor(v___y_2072_, v___x_2079_);
v___x_2081_ = lean_unsigned_to_nat(3u);
v___x_2082_ = lean_nat_add(v___y_2067_, v___x_2081_);
lean_dec(v___y_2067_);
v___x_2083_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2060_, v___x_2082_);
if (v___x_2083_ == 0)
{
lean_object* v___x_2084_; lean_object* v___x_2085_; uint8_t v___x_2086_; 
lean_dec(v___x_2082_);
v___x_2084_ = lean_box(v___y_2064_);
v___x_2085_ = l_outOfBounds___redArg(v___x_2084_);
lean_dec(v___x_2084_);
v___x_2086_ = lean_unbox(v___x_2085_);
lean_dec(v___x_2085_);
v___y_2038_ = v___y_2059_;
v___y_2039_ = v___y_2060_;
v___y_2040_ = v___y_2061_;
v___y_2041_ = v___y_2062_;
v___y_2042_ = v___y_2063_;
v___y_2043_ = v___y_2065_;
v___y_2044_ = v___y_2066_;
v___y_2045_ = v___y_2068_;
v___y_2046_ = v___y_2069_;
v___y_2047_ = v___x_2080_;
v___y_2048_ = v___y_2070_;
v___y_2049_ = v___y_2071_;
v___y_2050_ = v___y_2073_;
v___y_2051_ = v___y_2075_;
v___y_2052_ = v___y_2074_;
v___y_2053_ = v___x_2086_;
goto v___jp_2037_;
}
else
{
uint8_t v___x_2087_; 
v___x_2087_ = lean_byte_array_fget(v___y_2060_, v___x_2082_);
lean_dec(v___x_2082_);
v___y_2038_ = v___y_2059_;
v___y_2039_ = v___y_2060_;
v___y_2040_ = v___y_2061_;
v___y_2041_ = v___y_2062_;
v___y_2042_ = v___y_2063_;
v___y_2043_ = v___y_2065_;
v___y_2044_ = v___y_2066_;
v___y_2045_ = v___y_2068_;
v___y_2046_ = v___y_2069_;
v___y_2047_ = v___x_2080_;
v___y_2048_ = v___y_2070_;
v___y_2049_ = v___y_2071_;
v___y_2050_ = v___y_2073_;
v___y_2051_ = v___y_2075_;
v___y_2052_ = v___y_2074_;
v___y_2053_ = v___x_2087_;
goto v___jp_2037_;
}
}
v___jp_2088_:
{
uint64_t v___x_2107_; uint64_t v___x_2108_; uint64_t v___x_2109_; uint64_t v___x_2110_; lean_object* v___x_2111_; lean_object* v___x_2112_; uint8_t v___x_2113_; 
v___x_2107_ = lean_uint8_to_uint64(v___y_2106_);
v___x_2108_ = 8ULL;
v___x_2109_ = lean_uint64_shift_left(v___x_2107_, v___x_2108_);
v___x_2110_ = lean_uint64_lor(v___y_2090_, v___x_2109_);
v___x_2111_ = lean_unsigned_to_nat(2u);
v___x_2112_ = lean_nat_add(v___y_2098_, v___x_2111_);
v___x_2113_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2091_, v___x_2112_);
if (v___x_2113_ == 0)
{
lean_object* v___x_2114_; lean_object* v___x_2115_; uint8_t v___x_2116_; 
lean_dec(v___x_2112_);
v___x_2114_ = lean_box(v___y_2095_);
v___x_2115_ = l_outOfBounds___redArg(v___x_2114_);
lean_dec(v___x_2114_);
v___x_2116_ = lean_unbox(v___x_2115_);
lean_dec(v___x_2115_);
v___y_2059_ = v___y_2089_;
v___y_2060_ = v___y_2091_;
v___y_2061_ = v___y_2092_;
v___y_2062_ = v___y_2093_;
v___y_2063_ = v___y_2094_;
v___y_2064_ = v___y_2095_;
v___y_2065_ = v___y_2096_;
v___y_2066_ = v___y_2097_;
v___y_2067_ = v___y_2098_;
v___y_2068_ = v___y_2099_;
v___y_2069_ = v___y_2100_;
v___y_2070_ = v___y_2101_;
v___y_2071_ = v___y_2102_;
v___y_2072_ = v___x_2110_;
v___y_2073_ = v___y_2103_;
v___y_2074_ = v___y_2105_;
v___y_2075_ = v___y_2104_;
v___y_2076_ = v___x_2116_;
goto v___jp_2058_;
}
else
{
uint8_t v___x_2117_; 
v___x_2117_ = lean_byte_array_fget(v___y_2091_, v___x_2112_);
lean_dec(v___x_2112_);
v___y_2059_ = v___y_2089_;
v___y_2060_ = v___y_2091_;
v___y_2061_ = v___y_2092_;
v___y_2062_ = v___y_2093_;
v___y_2063_ = v___y_2094_;
v___y_2064_ = v___y_2095_;
v___y_2065_ = v___y_2096_;
v___y_2066_ = v___y_2097_;
v___y_2067_ = v___y_2098_;
v___y_2068_ = v___y_2099_;
v___y_2069_ = v___y_2100_;
v___y_2070_ = v___y_2101_;
v___y_2071_ = v___y_2102_;
v___y_2072_ = v___x_2110_;
v___y_2073_ = v___y_2103_;
v___y_2074_ = v___y_2105_;
v___y_2075_ = v___y_2104_;
v___y_2076_ = v___x_2117_;
goto v___jp_2058_;
}
}
v___jp_2118_:
{
uint64_t v_a_2136_; lean_object* v___x_2137_; uint8_t v___x_2138_; 
v_a_2136_ = lean_uint8_to_uint64(v___y_2135_);
v___x_2137_ = lean_nat_add(v___y_2127_, v___x_1928_);
v___x_2138_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2120_, v___x_2137_);
if (v___x_2138_ == 0)
{
lean_object* v___x_2139_; lean_object* v___x_2140_; uint8_t v___x_2141_; 
lean_dec(v___x_2137_);
v___x_2139_ = lean_box(v___y_2124_);
v___x_2140_ = l_outOfBounds___redArg(v___x_2139_);
lean_dec(v___x_2139_);
v___x_2141_ = lean_unbox(v___x_2140_);
lean_dec(v___x_2140_);
v___y_2089_ = v___y_2119_;
v___y_2090_ = v_a_2136_;
v___y_2091_ = v___y_2120_;
v___y_2092_ = v___y_2121_;
v___y_2093_ = v___y_2122_;
v___y_2094_ = v___y_2123_;
v___y_2095_ = v___y_2124_;
v___y_2096_ = v___y_2125_;
v___y_2097_ = v___y_2126_;
v___y_2098_ = v___y_2127_;
v___y_2099_ = v___y_2128_;
v___y_2100_ = v___y_2129_;
v___y_2101_ = v___y_2130_;
v___y_2102_ = v___y_2131_;
v___y_2103_ = v___y_2132_;
v___y_2104_ = v___y_2134_;
v___y_2105_ = v___y_2133_;
v___y_2106_ = v___x_2141_;
goto v___jp_2088_;
}
else
{
uint8_t v___x_2142_; 
v___x_2142_ = lean_byte_array_fget(v___y_2120_, v___x_2137_);
lean_dec(v___x_2137_);
v___y_2089_ = v___y_2119_;
v___y_2090_ = v_a_2136_;
v___y_2091_ = v___y_2120_;
v___y_2092_ = v___y_2121_;
v___y_2093_ = v___y_2122_;
v___y_2094_ = v___y_2123_;
v___y_2095_ = v___y_2124_;
v___y_2096_ = v___y_2125_;
v___y_2097_ = v___y_2126_;
v___y_2098_ = v___y_2127_;
v___y_2099_ = v___y_2128_;
v___y_2100_ = v___y_2129_;
v___y_2101_ = v___y_2130_;
v___y_2102_ = v___y_2131_;
v___y_2103_ = v___y_2132_;
v___y_2104_ = v___y_2134_;
v___y_2105_ = v___y_2133_;
v___y_2106_ = v___x_2142_;
goto v___jp_2088_;
}
}
v___jp_2143_:
{
if (v___y_2160_ == 0)
{
uint8_t v___x_2161_; 
v___x_2161_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2145_, v___y_2152_);
if (v___x_2161_ == 0)
{
lean_object* v___x_2162_; lean_object* v___x_2163_; uint8_t v___x_2164_; 
v___x_2162_ = lean_box(v___y_2149_);
v___x_2163_ = l_outOfBounds___redArg(v___x_2162_);
lean_dec(v___x_2162_);
v___x_2164_ = lean_unbox(v___x_2163_);
lean_dec(v___x_2163_);
v___y_2119_ = v___y_2144_;
v___y_2120_ = v___y_2145_;
v___y_2121_ = v___y_2146_;
v___y_2122_ = v___y_2147_;
v___y_2123_ = v___y_2148_;
v___y_2124_ = v___y_2149_;
v___y_2125_ = v___y_2150_;
v___y_2126_ = v___y_2151_;
v___y_2127_ = v___y_2152_;
v___y_2128_ = v___y_2153_;
v___y_2129_ = v___y_2154_;
v___y_2130_ = v___y_2155_;
v___y_2131_ = v___y_2156_;
v___y_2132_ = v___y_2157_;
v___y_2133_ = v___y_2159_;
v___y_2134_ = v___y_2158_;
v___y_2135_ = v___x_2164_;
goto v___jp_2118_;
}
else
{
uint8_t v___x_2165_; 
v___x_2165_ = lean_byte_array_fget(v___y_2145_, v___y_2152_);
v___y_2119_ = v___y_2144_;
v___y_2120_ = v___y_2145_;
v___y_2121_ = v___y_2146_;
v___y_2122_ = v___y_2147_;
v___y_2123_ = v___y_2148_;
v___y_2124_ = v___y_2149_;
v___y_2125_ = v___y_2150_;
v___y_2126_ = v___y_2151_;
v___y_2127_ = v___y_2152_;
v___y_2128_ = v___y_2153_;
v___y_2129_ = v___y_2154_;
v___y_2130_ = v___y_2155_;
v___y_2131_ = v___y_2156_;
v___y_2132_ = v___y_2157_;
v___y_2133_ = v___y_2159_;
v___y_2134_ = v___y_2158_;
v___y_2135_ = v___x_2165_;
goto v___jp_2118_;
}
}
else
{
size_t v_pos_2166_; uint8_t v___x_2167_; uint64_t v_a_2168_; size_t v___x_2169_; size_t v___x_2170_; uint8_t v___x_2171_; uint64_t v___x_2172_; uint64_t v___x_2173_; uint64_t v___x_2174_; uint64_t v___x_2175_; size_t v___x_2176_; size_t v___x_2177_; uint8_t v___x_2178_; uint64_t v___x_2179_; uint64_t v___x_2180_; uint64_t v___x_2181_; uint64_t v___x_2182_; size_t v___x_2183_; size_t v___x_2184_; uint8_t v___x_2185_; uint64_t v___x_2186_; uint64_t v___x_2187_; uint64_t v___x_2188_; uint64_t v___x_2189_; 
v_pos_2166_ = lean_usize_of_nat(v___y_2152_);
lean_dec(v___y_2152_);
v___x_2167_ = lean_byte_array_uget(v___y_2145_, v_pos_2166_);
v_a_2168_ = lean_uint8_to_uint64(v___x_2167_);
v___x_2169_ = ((size_t)1ULL);
v___x_2170_ = lean_usize_add(v_pos_2166_, v___x_2169_);
v___x_2171_ = lean_byte_array_uget(v___y_2145_, v___x_2170_);
v___x_2172_ = lean_uint8_to_uint64(v___x_2171_);
v___x_2173_ = 8ULL;
v___x_2174_ = lean_uint64_shift_left(v___x_2172_, v___x_2173_);
v___x_2175_ = lean_uint64_lor(v_a_2168_, v___x_2174_);
v___x_2176_ = ((size_t)2ULL);
v___x_2177_ = lean_usize_add(v_pos_2166_, v___x_2176_);
v___x_2178_ = lean_byte_array_uget(v___y_2145_, v___x_2177_);
v___x_2179_ = lean_uint8_to_uint64(v___x_2178_);
v___x_2180_ = 16ULL;
v___x_2181_ = lean_uint64_shift_left(v___x_2179_, v___x_2180_);
v___x_2182_ = lean_uint64_lor(v___x_2175_, v___x_2181_);
v___x_2183_ = ((size_t)3ULL);
v___x_2184_ = lean_usize_add(v_pos_2166_, v___x_2183_);
v___x_2185_ = lean_byte_array_uget(v___y_2145_, v___x_2184_);
v___x_2186_ = lean_uint8_to_uint64(v___x_2185_);
v___x_2187_ = 24ULL;
v___x_2188_ = lean_uint64_shift_left(v___x_2186_, v___x_2187_);
v___x_2189_ = lean_uint64_lor(v___x_2182_, v___x_2188_);
v___y_2020_ = v___y_2144_;
v___y_2021_ = v___y_2145_;
v___y_2022_ = v___y_2146_;
v___y_2023_ = v___y_2147_;
v___y_2024_ = v___y_2148_;
v___y_2025_ = v___y_2150_;
v___y_2026_ = v___y_2151_;
v___y_2027_ = v___y_2153_;
v___y_2028_ = v___y_2154_;
v___y_2029_ = v___y_2155_;
v___y_2030_ = v___y_2156_;
v___y_2031_ = v___y_2157_;
v___y_2032_ = v___y_2159_;
v___y_2033_ = v___y_2158_;
v___y_2034_ = v___x_2189_;
goto v___jp_2019_;
}
}
v___jp_2191_:
{
lean_object* v___x_2203_; uint8_t v___x_2204_; 
v___x_2203_ = lean_uint64_to_nat(v___y_2202_);
v___x_2204_ = lean_nat_dec_eq(v___x_2203_, v_reducerRank_1927_);
if (v___x_2204_ == 0)
{
lean_object* v___x_2205_; lean_object* v___x_2206_; lean_object* v_row_2207_; lean_object* v_derivation_2208_; lean_object* v_sugar_2209_; lean_object* v_columns_2210_; lean_object* v___x_2211_; lean_object* v___x_2212_; uint8_t v___x_2213_; lean_object* v___x_2214_; lean_object* v_offset_2215_; lean_object* v___x_2216_; lean_object* v___x_2217_; uint8_t v___x_2218_; 
lean_dec_ref(v___y_2199_);
v___x_2205_ = lean_nat_sub(v___x_2203_, v___x_1928_);
lean_dec(v___x_2203_);
v___x_2206_ = lean_array_get_borrowed(v___x_2190_, v___x_1893_, v___x_2205_);
lean_dec(v___x_2205_);
v_row_2207_ = lean_ctor_get(v___x_2206_, 0);
v_derivation_2208_ = lean_ctor_get(v___x_2206_, 1);
v_sugar_2209_ = lean_ctor_get(v___x_2206_, 2);
v_columns_2210_ = lean_ctor_get(v_row_2207_, 0);
v___x_2211_ = lp_Hex_Hex_Groebner_SparseRow_size(v_row_2207_);
v___x_2212_ = lean_nat_sub(v___x_2211_, v___x_1928_);
v___x_2213_ = 0;
v___x_2214_ = lean_unsigned_to_nat(4u);
v_offset_2215_ = lean_nat_mul(v___x_2212_, v___x_2214_);
lean_dec(v___x_2212_);
v___x_2216_ = lean_nat_add(v_offset_2215_, v___x_2214_);
v___x_2217_ = lean_byte_array_size(v_columns_2210_);
v___x_2218_ = lean_nat_dec_le(v___x_2216_, v___x_2217_);
if (v___x_2218_ == 0)
{
lean_dec(v___x_2216_);
lean_inc_ref(v_row_2207_);
lean_inc(v_sugar_2209_);
lean_inc(v_derivation_2208_);
lean_inc_ref(v_columns_2210_);
v___y_2144_ = v___y_2193_;
v___y_2145_ = v_columns_2210_;
v___y_2146_ = v___y_2195_;
v___y_2147_ = v_derivation_2208_;
v___y_2148_ = v___y_2196_;
v___y_2149_ = v___x_2213_;
v___y_2150_ = v___y_2197_;
v___y_2151_ = v___y_2198_;
v___y_2152_ = v_offset_2215_;
v___y_2153_ = v___y_2192_;
v___y_2154_ = v___y_2194_;
v___y_2155_ = v_sugar_2209_;
v___y_2156_ = v___x_2211_;
v___y_2157_ = v___y_2200_;
v___y_2158_ = v_row_2207_;
v___y_2159_ = v___y_2201_;
v___y_2160_ = v___x_2218_;
goto v___jp_2143_;
}
else
{
size_t v___x_2219_; lean_object* v___x_2220_; uint8_t v___x_2221_; 
v___x_2219_ = lean_usize_of_nat(v___x_2216_);
v___x_2220_ = lean_usize_to_nat(v___x_2219_);
v___x_2221_ = lean_nat_dec_eq(v___x_2220_, v___x_2216_);
lean_dec(v___x_2216_);
lean_dec(v___x_2220_);
lean_inc_ref(v_row_2207_);
lean_inc(v_sugar_2209_);
lean_inc(v_derivation_2208_);
lean_inc_ref(v_columns_2210_);
v___y_2144_ = v___y_2193_;
v___y_2145_ = v_columns_2210_;
v___y_2146_ = v___y_2195_;
v___y_2147_ = v_derivation_2208_;
v___y_2148_ = v___y_2196_;
v___y_2149_ = v___x_2213_;
v___y_2150_ = v___y_2197_;
v___y_2151_ = v___y_2198_;
v___y_2152_ = v_offset_2215_;
v___y_2153_ = v___y_2192_;
v___y_2154_ = v___y_2194_;
v___y_2155_ = v_sugar_2209_;
v___y_2156_ = v___x_2211_;
v___y_2157_ = v___y_2200_;
v___y_2158_ = v_row_2207_;
v___y_2159_ = v___y_2201_;
v___y_2160_ = v___x_2221_;
goto v___jp_2143_;
}
}
else
{
lean_dec(v___x_2203_);
if (lean_obj_tag(v___y_2198_) == 0)
{
lean_object* v___x_2222_; lean_object* v___x_2223_; 
lean_dec_ref(v___y_2199_);
lean_inc(v_i_1902_);
v___x_2222_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2222_, 0, v_i_1902_);
v___x_2223_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_2223_, 0, v___y_2197_);
lean_ctor_set(v___x_2223_, 1, v___y_2200_);
lean_ctor_set(v___x_2223_, 2, v___y_2192_);
lean_ctor_set(v___x_2223_, 3, v___x_2222_);
lean_ctor_set(v___x_2223_, 4, v___y_2195_);
lean_ctor_set(v___x_2223_, 5, v___y_2194_);
lean_ctor_set(v___x_2223_, 6, v___y_2193_);
v_a_1912_ = v___x_2223_;
v_snd_1913_ = v___y_2196_;
goto v___jp_1911_;
}
else
{
lean_dec_ref_known(v___y_2198_, 1);
lean_dec(v___y_2200_);
lean_dec_ref(v___y_2197_);
lean_dec_ref(v___y_2195_);
lean_dec(v___y_2194_);
lean_dec(v___y_2193_);
lean_dec(v___y_2192_);
v_a_1912_ = v___y_2199_;
v_snd_1913_ = v___y_2196_;
goto v___jp_1911_;
}
}
}
v___jp_2224_:
{
uint64_t v___x_2237_; uint64_t v___x_2238_; uint64_t v___x_2239_; uint64_t v___x_2240_; 
v___x_2237_ = lean_uint8_to_uint64(v___y_2236_);
v___x_2238_ = 24ULL;
v___x_2239_ = lean_uint64_shift_left(v___x_2237_, v___x_2238_);
v___x_2240_ = lean_uint64_lor(v___y_2229_, v___x_2239_);
v___y_2192_ = v___y_2226_;
v___y_2193_ = v___y_2225_;
v___y_2194_ = v___y_2227_;
v___y_2195_ = v___y_2228_;
v___y_2196_ = v___y_2230_;
v___y_2197_ = v___y_2231_;
v___y_2198_ = v___y_2232_;
v___y_2199_ = v___y_2234_;
v___y_2200_ = v___y_2233_;
v___y_2201_ = v___y_2235_;
v___y_2202_ = v___x_2240_;
goto v___jp_2191_;
}
v___jp_2241_:
{
uint64_t v___x_2256_; uint64_t v___x_2257_; uint64_t v___x_2258_; uint64_t v___x_2259_; lean_object* v___x_2260_; lean_object* v___x_2261_; uint8_t v___x_2262_; 
v___x_2256_ = lean_uint8_to_uint64(v___y_2255_);
v___x_2257_ = 16ULL;
v___x_2258_ = lean_uint64_shift_left(v___x_2256_, v___x_2257_);
v___x_2259_ = lean_uint64_lor(v___y_2243_, v___x_2258_);
v___x_2260_ = lean_unsigned_to_nat(3u);
v___x_2261_ = lean_nat_add(v___y_2244_, v___x_2260_);
lean_dec(v___y_2244_);
v___x_2262_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_1899_, v___x_2261_);
if (v___x_2262_ == 0)
{
lean_object* v___x_2263_; lean_object* v___x_2264_; uint8_t v___x_2265_; 
lean_dec(v___x_2261_);
v___x_2263_ = lean_box(v___y_2246_);
v___x_2264_ = l_outOfBounds___redArg(v___x_2263_);
lean_dec(v___x_2263_);
v___x_2265_ = lean_unbox(v___x_2264_);
lean_dec(v___x_2264_);
v___y_2225_ = v___y_2242_;
v___y_2226_ = v___y_2251_;
v___y_2227_ = v___y_2252_;
v___y_2228_ = v___y_2245_;
v___y_2229_ = v___x_2259_;
v___y_2230_ = v___y_2247_;
v___y_2231_ = v___y_2248_;
v___y_2232_ = v___y_2249_;
v___y_2233_ = v___y_2253_;
v___y_2234_ = v___y_2250_;
v___y_2235_ = v___y_2254_;
v___y_2236_ = v___x_2265_;
goto v___jp_2224_;
}
else
{
uint8_t v___x_2266_; 
v___x_2266_ = lean_byte_array_fget(v___x_1899_, v___x_2261_);
lean_dec(v___x_2261_);
v___y_2225_ = v___y_2242_;
v___y_2226_ = v___y_2251_;
v___y_2227_ = v___y_2252_;
v___y_2228_ = v___y_2245_;
v___y_2229_ = v___x_2259_;
v___y_2230_ = v___y_2247_;
v___y_2231_ = v___y_2248_;
v___y_2232_ = v___y_2249_;
v___y_2233_ = v___y_2253_;
v___y_2234_ = v___y_2250_;
v___y_2235_ = v___y_2254_;
v___y_2236_ = v___x_2266_;
goto v___jp_2224_;
}
}
v___jp_2267_:
{
uint64_t v___x_2282_; uint64_t v___x_2283_; uint64_t v___x_2284_; uint64_t v___x_2285_; lean_object* v___x_2286_; lean_object* v___x_2287_; uint8_t v___x_2288_; 
v___x_2282_ = lean_uint8_to_uint64(v___y_2281_);
v___x_2283_ = 8ULL;
v___x_2284_ = lean_uint64_shift_left(v___x_2282_, v___x_2283_);
v___x_2285_ = lean_uint64_lor(v___y_2275_, v___x_2284_);
v___x_2286_ = lean_unsigned_to_nat(2u);
v___x_2287_ = lean_nat_add(v___y_2269_, v___x_2286_);
v___x_2288_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_1899_, v___x_2287_);
if (v___x_2288_ == 0)
{
lean_object* v___x_2289_; lean_object* v___x_2290_; uint8_t v___x_2291_; 
lean_dec(v___x_2287_);
v___x_2289_ = lean_box(v___y_2271_);
v___x_2290_ = l_outOfBounds___redArg(v___x_2289_);
lean_dec(v___x_2289_);
v___x_2291_ = lean_unbox(v___x_2290_);
lean_dec(v___x_2290_);
v___y_2242_ = v___y_2268_;
v___y_2243_ = v___x_2285_;
v___y_2244_ = v___y_2269_;
v___y_2245_ = v___y_2270_;
v___y_2246_ = v___y_2271_;
v___y_2247_ = v___y_2272_;
v___y_2248_ = v___y_2273_;
v___y_2249_ = v___y_2274_;
v___y_2250_ = v___y_2276_;
v___y_2251_ = v___y_2277_;
v___y_2252_ = v___y_2278_;
v___y_2253_ = v___y_2279_;
v___y_2254_ = v___y_2280_;
v___y_2255_ = v___x_2291_;
goto v___jp_2241_;
}
else
{
uint8_t v___x_2292_; 
v___x_2292_ = lean_byte_array_fget(v___x_1899_, v___x_2287_);
lean_dec(v___x_2287_);
v___y_2242_ = v___y_2268_;
v___y_2243_ = v___x_2285_;
v___y_2244_ = v___y_2269_;
v___y_2245_ = v___y_2270_;
v___y_2246_ = v___y_2271_;
v___y_2247_ = v___y_2272_;
v___y_2248_ = v___y_2273_;
v___y_2249_ = v___y_2274_;
v___y_2250_ = v___y_2276_;
v___y_2251_ = v___y_2277_;
v___y_2252_ = v___y_2278_;
v___y_2253_ = v___y_2279_;
v___y_2254_ = v___y_2280_;
v___y_2255_ = v___x_2292_;
goto v___jp_2241_;
}
}
v___jp_2293_:
{
uint64_t v_a_2307_; lean_object* v___x_2308_; uint8_t v___x_2309_; 
v_a_2307_ = lean_uint8_to_uint64(v___y_2306_);
v___x_2308_ = lean_nat_add(v___y_2296_, v___x_1928_);
v___x_2309_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_1899_, v___x_2308_);
if (v___x_2309_ == 0)
{
lean_object* v___x_2310_; lean_object* v___x_2311_; uint8_t v___x_2312_; 
lean_dec(v___x_2308_);
v___x_2310_ = lean_box(v___y_2299_);
v___x_2311_ = l_outOfBounds___redArg(v___x_2310_);
lean_dec(v___x_2310_);
v___x_2312_ = lean_unbox(v___x_2311_);
lean_dec(v___x_2311_);
v___y_2268_ = v___y_2295_;
v___y_2269_ = v___y_2296_;
v___y_2270_ = v___y_2298_;
v___y_2271_ = v___y_2299_;
v___y_2272_ = v___y_2300_;
v___y_2273_ = v___y_2301_;
v___y_2274_ = v___y_2302_;
v___y_2275_ = v_a_2307_;
v___y_2276_ = v___y_2304_;
v___y_2277_ = v___y_2294_;
v___y_2278_ = v___y_2297_;
v___y_2279_ = v___y_2303_;
v___y_2280_ = v___y_2305_;
v___y_2281_ = v___x_2312_;
goto v___jp_2267_;
}
else
{
uint8_t v___x_2313_; 
v___x_2313_ = lean_byte_array_fget(v___x_1899_, v___x_2308_);
lean_dec(v___x_2308_);
v___y_2268_ = v___y_2295_;
v___y_2269_ = v___y_2296_;
v___y_2270_ = v___y_2298_;
v___y_2271_ = v___y_2299_;
v___y_2272_ = v___y_2300_;
v___y_2273_ = v___y_2301_;
v___y_2274_ = v___y_2302_;
v___y_2275_ = v_a_2307_;
v___y_2276_ = v___y_2304_;
v___y_2277_ = v___y_2294_;
v___y_2278_ = v___y_2297_;
v___y_2279_ = v___y_2303_;
v___y_2280_ = v___y_2305_;
v___y_2281_ = v___x_2313_;
goto v___jp_2267_;
}
}
v___jp_2314_:
{
if (v___y_2327_ == 0)
{
uint8_t v___x_2328_; 
v___x_2328_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_1899_, v___y_2317_);
if (v___x_2328_ == 0)
{
lean_object* v___x_2329_; lean_object* v___x_2330_; uint8_t v___x_2331_; 
v___x_2329_ = lean_box(v___y_2320_);
v___x_2330_ = l_outOfBounds___redArg(v___x_2329_);
lean_dec(v___x_2329_);
v___x_2331_ = lean_unbox(v___x_2330_);
lean_dec(v___x_2330_);
v___y_2294_ = v___y_2316_;
v___y_2295_ = v___y_2315_;
v___y_2296_ = v___y_2317_;
v___y_2297_ = v___y_2318_;
v___y_2298_ = v___y_2319_;
v___y_2299_ = v___y_2320_;
v___y_2300_ = v___y_2321_;
v___y_2301_ = v___y_2322_;
v___y_2302_ = v___y_2323_;
v___y_2303_ = v___y_2325_;
v___y_2304_ = v___y_2324_;
v___y_2305_ = v___y_2326_;
v___y_2306_ = v___x_2331_;
goto v___jp_2293_;
}
else
{
uint8_t v___x_2332_; 
v___x_2332_ = lean_byte_array_fget(v___x_1899_, v___y_2317_);
v___y_2294_ = v___y_2316_;
v___y_2295_ = v___y_2315_;
v___y_2296_ = v___y_2317_;
v___y_2297_ = v___y_2318_;
v___y_2298_ = v___y_2319_;
v___y_2299_ = v___y_2320_;
v___y_2300_ = v___y_2321_;
v___y_2301_ = v___y_2322_;
v___y_2302_ = v___y_2323_;
v___y_2303_ = v___y_2325_;
v___y_2304_ = v___y_2324_;
v___y_2305_ = v___y_2326_;
v___y_2306_ = v___x_2332_;
goto v___jp_2293_;
}
}
else
{
size_t v_pos_2333_; uint8_t v___x_2334_; uint64_t v_a_2335_; size_t v___x_2336_; size_t v___x_2337_; uint8_t v___x_2338_; uint64_t v___x_2339_; uint64_t v___x_2340_; uint64_t v___x_2341_; uint64_t v___x_2342_; size_t v___x_2343_; size_t v___x_2344_; uint8_t v___x_2345_; uint64_t v___x_2346_; uint64_t v___x_2347_; uint64_t v___x_2348_; uint64_t v___x_2349_; size_t v___x_2350_; size_t v___x_2351_; uint8_t v___x_2352_; uint64_t v___x_2353_; uint64_t v___x_2354_; uint64_t v___x_2355_; uint64_t v___x_2356_; 
v_pos_2333_ = lean_usize_of_nat(v___y_2317_);
lean_dec(v___y_2317_);
v___x_2334_ = lean_byte_array_uget(v___x_1899_, v_pos_2333_);
v_a_2335_ = lean_uint8_to_uint64(v___x_2334_);
v___x_2336_ = ((size_t)1ULL);
v___x_2337_ = lean_usize_add(v_pos_2333_, v___x_2336_);
v___x_2338_ = lean_byte_array_uget(v___x_1899_, v___x_2337_);
v___x_2339_ = lean_uint8_to_uint64(v___x_2338_);
v___x_2340_ = 8ULL;
v___x_2341_ = lean_uint64_shift_left(v___x_2339_, v___x_2340_);
v___x_2342_ = lean_uint64_lor(v_a_2335_, v___x_2341_);
v___x_2343_ = ((size_t)2ULL);
v___x_2344_ = lean_usize_add(v_pos_2333_, v___x_2343_);
v___x_2345_ = lean_byte_array_uget(v___x_1899_, v___x_2344_);
v___x_2346_ = lean_uint8_to_uint64(v___x_2345_);
v___x_2347_ = 16ULL;
v___x_2348_ = lean_uint64_shift_left(v___x_2346_, v___x_2347_);
v___x_2349_ = lean_uint64_lor(v___x_2342_, v___x_2348_);
v___x_2350_ = ((size_t)3ULL);
v___x_2351_ = lean_usize_add(v_pos_2333_, v___x_2350_);
v___x_2352_ = lean_byte_array_uget(v___x_1899_, v___x_2351_);
v___x_2353_ = lean_uint8_to_uint64(v___x_2352_);
v___x_2354_ = 24ULL;
v___x_2355_ = lean_uint64_shift_left(v___x_2353_, v___x_2354_);
v___x_2356_ = lean_uint64_lor(v___x_2349_, v___x_2355_);
v___y_2192_ = v___y_2316_;
v___y_2193_ = v___y_2315_;
v___y_2194_ = v___y_2318_;
v___y_2195_ = v___y_2319_;
v___y_2196_ = v___y_2321_;
v___y_2197_ = v___y_2322_;
v___y_2198_ = v___y_2323_;
v___y_2199_ = v___y_2324_;
v___y_2200_ = v___y_2325_;
v___y_2201_ = v___y_2326_;
v___y_2202_ = v___x_2356_;
goto v___jp_2191_;
}
}
v___jp_2357_:
{
uint64_t v___x_2368_; uint8_t v___x_2369_; 
v___x_2368_ = 0ULL;
v___x_2369_ = lean_uint64_dec_eq(v___y_2367_, v___x_2368_);
if (v___x_2369_ == 0)
{
uint8_t v___x_2370_; lean_object* v___x_2371_; lean_object* v_offset_2372_; lean_object* v___x_2373_; lean_object* v___x_2374_; uint8_t v___x_2375_; 
v___x_2370_ = 0;
v___x_2371_ = lean_unsigned_to_nat(4u);
v_offset_2372_ = lean_nat_mul(v_i_1902_, v___x_2371_);
v___x_2373_ = lean_nat_add(v_offset_2372_, v___x_2371_);
v___x_2374_ = lean_byte_array_size(v___x_1899_);
v___x_2375_ = lean_nat_dec_le(v___x_2373_, v___x_2374_);
if (v___x_2375_ == 0)
{
lean_dec(v___x_2373_);
v___y_2315_ = v___y_2358_;
v___y_2316_ = v___y_2359_;
v___y_2317_ = v_offset_2372_;
v___y_2318_ = v___y_2360_;
v___y_2319_ = v___y_2361_;
v___y_2320_ = v___x_2370_;
v___y_2321_ = v___y_2362_;
v___y_2322_ = v___y_2363_;
v___y_2323_ = v___y_2364_;
v___y_2324_ = v___y_2366_;
v___y_2325_ = v___y_2365_;
v___y_2326_ = v___y_2367_;
v___y_2327_ = v___x_2375_;
goto v___jp_2314_;
}
else
{
size_t v___x_2376_; lean_object* v___x_2377_; uint8_t v___x_2378_; 
v___x_2376_ = lean_usize_of_nat(v___x_2373_);
v___x_2377_ = lean_usize_to_nat(v___x_2376_);
v___x_2378_ = lean_nat_dec_eq(v___x_2377_, v___x_2373_);
lean_dec(v___x_2373_);
lean_dec(v___x_2377_);
v___y_2315_ = v___y_2358_;
v___y_2316_ = v___y_2359_;
v___y_2317_ = v_offset_2372_;
v___y_2318_ = v___y_2360_;
v___y_2319_ = v___y_2361_;
v___y_2320_ = v___x_2370_;
v___y_2321_ = v___y_2362_;
v___y_2322_ = v___y_2363_;
v___y_2323_ = v___y_2364_;
v___y_2324_ = v___y_2366_;
v___y_2325_ = v___y_2365_;
v___y_2326_ = v___y_2367_;
v___y_2327_ = v___x_2378_;
goto v___jp_2314_;
}
}
else
{
lean_dec(v___y_2365_);
lean_dec(v___y_2364_);
lean_dec_ref(v___y_2363_);
lean_dec_ref(v___y_2361_);
lean_dec(v___y_2360_);
lean_dec(v___y_2359_);
lean_dec(v___y_2358_);
v_a_1912_ = v___y_2366_;
v_snd_1913_ = v___y_2362_;
goto v___jp_1911_;
}
}
v___jp_2379_:
{
uint64_t v___x_2391_; uint64_t v___x_2392_; uint64_t v___x_2393_; uint64_t v___x_2394_; 
v___x_2391_ = lean_uint8_to_uint64(v___y_2390_);
v___x_2392_ = 24ULL;
v___x_2393_ = lean_uint64_shift_left(v___x_2391_, v___x_2392_);
v___x_2394_ = lean_uint64_lor(v___y_2389_, v___x_2393_);
v___y_2358_ = v___y_2381_;
v___y_2359_ = v___y_2380_;
v___y_2360_ = v___y_2382_;
v___y_2361_ = v___y_2383_;
v___y_2362_ = v___y_2384_;
v___y_2363_ = v___y_2385_;
v___y_2364_ = v___y_2386_;
v___y_2365_ = v___y_2388_;
v___y_2366_ = v___y_2387_;
v___y_2367_ = v___x_2394_;
goto v___jp_2357_;
}
v___jp_2395_:
{
uint64_t v___x_2409_; uint64_t v___x_2410_; uint64_t v___x_2411_; uint64_t v___x_2412_; lean_object* v___x_2413_; lean_object* v___x_2414_; uint8_t v___x_2415_; 
v___x_2409_ = lean_uint8_to_uint64(v___y_2408_);
v___x_2410_ = 16ULL;
v___x_2411_ = lean_uint64_shift_left(v___x_2409_, v___x_2410_);
v___x_2412_ = lean_uint64_lor(v___y_2402_, v___x_2411_);
v___x_2413_ = lean_unsigned_to_nat(3u);
v___x_2414_ = lean_nat_add(v___y_2404_, v___x_2413_);
lean_dec(v___y_2404_);
v___x_2415_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2403_, v___x_2414_);
if (v___x_2415_ == 0)
{
lean_object* v___x_2416_; lean_object* v___x_2417_; uint8_t v___x_2418_; 
lean_dec(v___x_2414_);
v___x_2416_ = lean_box(v___y_2398_);
v___x_2417_ = l_outOfBounds___redArg(v___x_2416_);
lean_dec(v___x_2416_);
v___x_2418_ = lean_unbox(v___x_2417_);
lean_dec(v___x_2417_);
v___y_2380_ = v___y_2397_;
v___y_2381_ = v___y_2396_;
v___y_2382_ = v___y_2399_;
v___y_2383_ = v___y_2400_;
v___y_2384_ = v___y_2401_;
v___y_2385_ = v___y_2403_;
v___y_2386_ = v___y_2405_;
v___y_2387_ = v___y_2407_;
v___y_2388_ = v___y_2406_;
v___y_2389_ = v___x_2412_;
v___y_2390_ = v___x_2418_;
goto v___jp_2379_;
}
else
{
uint8_t v___x_2419_; 
v___x_2419_ = lean_byte_array_fget(v___y_2403_, v___x_2414_);
lean_dec(v___x_2414_);
v___y_2380_ = v___y_2397_;
v___y_2381_ = v___y_2396_;
v___y_2382_ = v___y_2399_;
v___y_2383_ = v___y_2400_;
v___y_2384_ = v___y_2401_;
v___y_2385_ = v___y_2403_;
v___y_2386_ = v___y_2405_;
v___y_2387_ = v___y_2407_;
v___y_2388_ = v___y_2406_;
v___y_2389_ = v___x_2412_;
v___y_2390_ = v___x_2419_;
goto v___jp_2379_;
}
}
v___jp_2420_:
{
uint64_t v___x_2434_; uint64_t v___x_2435_; uint64_t v___x_2436_; uint64_t v___x_2437_; lean_object* v___x_2438_; lean_object* v___x_2439_; uint8_t v___x_2440_; 
v___x_2434_ = lean_uint8_to_uint64(v___y_2433_);
v___x_2435_ = 8ULL;
v___x_2436_ = lean_uint64_shift_left(v___x_2434_, v___x_2435_);
v___x_2437_ = lean_uint64_lor(v___y_2424_, v___x_2436_);
v___x_2438_ = lean_unsigned_to_nat(2u);
v___x_2439_ = lean_nat_add(v___y_2429_, v___x_2438_);
v___x_2440_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2428_, v___x_2439_);
if (v___x_2440_ == 0)
{
lean_object* v___x_2441_; lean_object* v___x_2442_; uint8_t v___x_2443_; 
lean_dec(v___x_2439_);
v___x_2441_ = lean_box(v___y_2423_);
v___x_2442_ = l_outOfBounds___redArg(v___x_2441_);
lean_dec(v___x_2441_);
v___x_2443_ = lean_unbox(v___x_2442_);
lean_dec(v___x_2442_);
v___y_2396_ = v___y_2422_;
v___y_2397_ = v___y_2421_;
v___y_2398_ = v___y_2423_;
v___y_2399_ = v___y_2425_;
v___y_2400_ = v___y_2426_;
v___y_2401_ = v___y_2427_;
v___y_2402_ = v___x_2437_;
v___y_2403_ = v___y_2428_;
v___y_2404_ = v___y_2429_;
v___y_2405_ = v___y_2430_;
v___y_2406_ = v___y_2432_;
v___y_2407_ = v___y_2431_;
v___y_2408_ = v___x_2443_;
goto v___jp_2395_;
}
else
{
uint8_t v___x_2444_; 
v___x_2444_ = lean_byte_array_fget(v___y_2428_, v___x_2439_);
lean_dec(v___x_2439_);
v___y_2396_ = v___y_2422_;
v___y_2397_ = v___y_2421_;
v___y_2398_ = v___y_2423_;
v___y_2399_ = v___y_2425_;
v___y_2400_ = v___y_2426_;
v___y_2401_ = v___y_2427_;
v___y_2402_ = v___x_2437_;
v___y_2403_ = v___y_2428_;
v___y_2404_ = v___y_2429_;
v___y_2405_ = v___y_2430_;
v___y_2406_ = v___y_2432_;
v___y_2407_ = v___y_2431_;
v___y_2408_ = v___x_2444_;
goto v___jp_2395_;
}
}
v___jp_2445_:
{
uint64_t v___x_2457_; uint64_t v___x_2458_; uint64_t v___x_2459_; uint64_t v___x_2460_; 
v___x_2457_ = lean_uint8_to_uint64(v___y_2456_);
v___x_2458_ = 8ULL;
v___x_2459_ = lean_uint64_shift_left(v___x_2457_, v___x_2458_);
v___x_2460_ = lean_uint64_lor(v___y_2448_, v___x_2459_);
v___y_2358_ = v___y_2447_;
v___y_2359_ = v___y_2446_;
v___y_2360_ = v___y_2449_;
v___y_2361_ = v___y_2450_;
v___y_2362_ = v___y_2451_;
v___y_2363_ = v___y_2452_;
v___y_2364_ = v___y_2453_;
v___y_2365_ = v___y_2455_;
v___y_2366_ = v___y_2454_;
v___y_2367_ = v___x_2460_;
goto v___jp_2357_;
}
v___jp_2461_:
{
uint64_t v_a_2474_; 
v_a_2474_ = lean_uint8_to_uint64(v___y_2473_);
switch(v_width_1897_)
{
case 0:
{
lean_dec(v___y_2469_);
v___y_2358_ = v___y_2462_;
v___y_2359_ = v___y_2463_;
v___y_2360_ = v___y_2465_;
v___y_2361_ = v___y_2466_;
v___y_2362_ = v___y_2467_;
v___y_2363_ = v___y_2468_;
v___y_2364_ = v___y_2470_;
v___y_2365_ = v___y_2471_;
v___y_2366_ = v___y_2472_;
v___y_2367_ = v_a_2474_;
goto v___jp_2357_;
}
case 1:
{
lean_object* v___x_2475_; uint8_t v___x_2476_; 
v___x_2475_ = lean_nat_add(v___y_2469_, v___x_1928_);
lean_dec(v___y_2469_);
v___x_2476_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2468_, v___x_2475_);
if (v___x_2476_ == 0)
{
lean_object* v___x_2477_; lean_object* v___x_2478_; uint8_t v___x_2479_; 
lean_dec(v___x_2475_);
v___x_2477_ = lean_box(v___y_2464_);
v___x_2478_ = l_outOfBounds___redArg(v___x_2477_);
lean_dec(v___x_2477_);
v___x_2479_ = lean_unbox(v___x_2478_);
lean_dec(v___x_2478_);
v___y_2446_ = v___y_2463_;
v___y_2447_ = v___y_2462_;
v___y_2448_ = v_a_2474_;
v___y_2449_ = v___y_2465_;
v___y_2450_ = v___y_2466_;
v___y_2451_ = v___y_2467_;
v___y_2452_ = v___y_2468_;
v___y_2453_ = v___y_2470_;
v___y_2454_ = v___y_2472_;
v___y_2455_ = v___y_2471_;
v___y_2456_ = v___x_2479_;
goto v___jp_2445_;
}
else
{
uint8_t v___x_2480_; 
v___x_2480_ = lean_byte_array_fget(v___y_2468_, v___x_2475_);
lean_dec(v___x_2475_);
v___y_2446_ = v___y_2463_;
v___y_2447_ = v___y_2462_;
v___y_2448_ = v_a_2474_;
v___y_2449_ = v___y_2465_;
v___y_2450_ = v___y_2466_;
v___y_2451_ = v___y_2467_;
v___y_2452_ = v___y_2468_;
v___y_2453_ = v___y_2470_;
v___y_2454_ = v___y_2472_;
v___y_2455_ = v___y_2471_;
v___y_2456_ = v___x_2480_;
goto v___jp_2445_;
}
}
default: 
{
lean_object* v___x_2481_; uint8_t v___x_2482_; 
v___x_2481_ = lean_nat_add(v___y_2469_, v___x_1928_);
v___x_2482_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2468_, v___x_2481_);
if (v___x_2482_ == 0)
{
lean_object* v___x_2483_; lean_object* v___x_2484_; uint8_t v___x_2485_; 
lean_dec(v___x_2481_);
v___x_2483_ = lean_box(v___y_2464_);
v___x_2484_ = l_outOfBounds___redArg(v___x_2483_);
lean_dec(v___x_2483_);
v___x_2485_ = lean_unbox(v___x_2484_);
lean_dec(v___x_2484_);
v___y_2421_ = v___y_2463_;
v___y_2422_ = v___y_2462_;
v___y_2423_ = v___y_2464_;
v___y_2424_ = v_a_2474_;
v___y_2425_ = v___y_2465_;
v___y_2426_ = v___y_2466_;
v___y_2427_ = v___y_2467_;
v___y_2428_ = v___y_2468_;
v___y_2429_ = v___y_2469_;
v___y_2430_ = v___y_2470_;
v___y_2431_ = v___y_2472_;
v___y_2432_ = v___y_2471_;
v___y_2433_ = v___x_2485_;
goto v___jp_2420_;
}
else
{
uint8_t v___x_2486_; 
v___x_2486_ = lean_byte_array_fget(v___y_2468_, v___x_2481_);
lean_dec(v___x_2481_);
v___y_2421_ = v___y_2463_;
v___y_2422_ = v___y_2462_;
v___y_2423_ = v___y_2464_;
v___y_2424_ = v_a_2474_;
v___y_2425_ = v___y_2465_;
v___y_2426_ = v___y_2466_;
v___y_2427_ = v___y_2467_;
v___y_2428_ = v___y_2468_;
v___y_2429_ = v___y_2469_;
v___y_2430_ = v___y_2470_;
v___y_2431_ = v___y_2472_;
v___y_2432_ = v___y_2471_;
v___y_2433_ = v___x_2486_;
goto v___jp_2420_;
}
}
}
}
v___jp_2487_:
{
if (v___y_2499_ == 0)
{
uint8_t v___x_2500_; 
v___x_2500_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2494_, v___y_2495_);
if (v___x_2500_ == 0)
{
lean_object* v___x_2501_; lean_object* v___x_2502_; uint8_t v___x_2503_; 
v___x_2501_ = lean_box(v___y_2490_);
v___x_2502_ = l_outOfBounds___redArg(v___x_2501_);
lean_dec(v___x_2501_);
v___x_2503_ = lean_unbox(v___x_2502_);
lean_dec(v___x_2502_);
v___y_2462_ = v___y_2489_;
v___y_2463_ = v___y_2488_;
v___y_2464_ = v___y_2490_;
v___y_2465_ = v___y_2491_;
v___y_2466_ = v___y_2492_;
v___y_2467_ = v___y_2493_;
v___y_2468_ = v___y_2494_;
v___y_2469_ = v___y_2495_;
v___y_2470_ = v___y_2496_;
v___y_2471_ = v___y_2498_;
v___y_2472_ = v___y_2497_;
v___y_2473_ = v___x_2503_;
goto v___jp_2461_;
}
else
{
uint8_t v___x_2504_; 
v___x_2504_ = lean_byte_array_fget(v___y_2494_, v___y_2495_);
v___y_2462_ = v___y_2489_;
v___y_2463_ = v___y_2488_;
v___y_2464_ = v___y_2490_;
v___y_2465_ = v___y_2491_;
v___y_2466_ = v___y_2492_;
v___y_2467_ = v___y_2493_;
v___y_2468_ = v___y_2494_;
v___y_2469_ = v___y_2495_;
v___y_2470_ = v___y_2496_;
v___y_2471_ = v___y_2498_;
v___y_2472_ = v___y_2497_;
v___y_2473_ = v___x_2504_;
goto v___jp_2461_;
}
}
else
{
size_t v_pos_2505_; uint8_t v___x_2506_; uint64_t v_a_2507_; 
v_pos_2505_ = lean_usize_of_nat(v___y_2495_);
lean_dec(v___y_2495_);
v___x_2506_ = lean_byte_array_uget(v___y_2494_, v_pos_2505_);
v_a_2507_ = lean_uint8_to_uint64(v___x_2506_);
switch(v_width_1897_)
{
case 0:
{
v___y_2358_ = v___y_2489_;
v___y_2359_ = v___y_2488_;
v___y_2360_ = v___y_2491_;
v___y_2361_ = v___y_2492_;
v___y_2362_ = v___y_2493_;
v___y_2363_ = v___y_2494_;
v___y_2364_ = v___y_2496_;
v___y_2365_ = v___y_2498_;
v___y_2366_ = v___y_2497_;
v___y_2367_ = v_a_2507_;
goto v___jp_2357_;
}
case 1:
{
size_t v___x_2508_; size_t v___x_2509_; uint8_t v___x_2510_; uint64_t v___x_2511_; uint64_t v___x_2512_; uint64_t v___x_2513_; uint64_t v___x_2514_; 
v___x_2508_ = ((size_t)1ULL);
v___x_2509_ = lean_usize_add(v_pos_2505_, v___x_2508_);
v___x_2510_ = lean_byte_array_uget(v___y_2494_, v___x_2509_);
v___x_2511_ = lean_uint8_to_uint64(v___x_2510_);
v___x_2512_ = 8ULL;
v___x_2513_ = lean_uint64_shift_left(v___x_2511_, v___x_2512_);
v___x_2514_ = lean_uint64_lor(v_a_2507_, v___x_2513_);
v___y_2358_ = v___y_2489_;
v___y_2359_ = v___y_2488_;
v___y_2360_ = v___y_2491_;
v___y_2361_ = v___y_2492_;
v___y_2362_ = v___y_2493_;
v___y_2363_ = v___y_2494_;
v___y_2364_ = v___y_2496_;
v___y_2365_ = v___y_2498_;
v___y_2366_ = v___y_2497_;
v___y_2367_ = v___x_2514_;
goto v___jp_2357_;
}
default: 
{
size_t v___x_2515_; size_t v___x_2516_; uint8_t v___x_2517_; uint64_t v___x_2518_; uint64_t v___x_2519_; uint64_t v___x_2520_; uint64_t v___x_2521_; size_t v___x_2522_; size_t v___x_2523_; uint8_t v___x_2524_; uint64_t v___x_2525_; uint64_t v___x_2526_; uint64_t v___x_2527_; uint64_t v___x_2528_; size_t v___x_2529_; size_t v___x_2530_; uint8_t v___x_2531_; uint64_t v___x_2532_; uint64_t v___x_2533_; uint64_t v___x_2534_; uint64_t v___x_2535_; 
v___x_2515_ = ((size_t)1ULL);
v___x_2516_ = lean_usize_add(v_pos_2505_, v___x_2515_);
v___x_2517_ = lean_byte_array_uget(v___y_2494_, v___x_2516_);
v___x_2518_ = lean_uint8_to_uint64(v___x_2517_);
v___x_2519_ = 8ULL;
v___x_2520_ = lean_uint64_shift_left(v___x_2518_, v___x_2519_);
v___x_2521_ = lean_uint64_lor(v_a_2507_, v___x_2520_);
v___x_2522_ = ((size_t)2ULL);
v___x_2523_ = lean_usize_add(v_pos_2505_, v___x_2522_);
v___x_2524_ = lean_byte_array_uget(v___y_2494_, v___x_2523_);
v___x_2525_ = lean_uint8_to_uint64(v___x_2524_);
v___x_2526_ = 16ULL;
v___x_2527_ = lean_uint64_shift_left(v___x_2525_, v___x_2526_);
v___x_2528_ = lean_uint64_lor(v___x_2521_, v___x_2527_);
v___x_2529_ = ((size_t)3ULL);
v___x_2530_ = lean_usize_add(v_pos_2505_, v___x_2529_);
v___x_2531_ = lean_byte_array_uget(v___y_2494_, v___x_2530_);
v___x_2532_ = lean_uint8_to_uint64(v___x_2531_);
v___x_2533_ = 24ULL;
v___x_2534_ = lean_uint64_shift_left(v___x_2532_, v___x_2533_);
v___x_2535_ = lean_uint64_lor(v___x_2528_, v___x_2534_);
v___y_2358_ = v___y_2489_;
v___y_2359_ = v___y_2488_;
v___y_2360_ = v___y_2491_;
v___y_2361_ = v___y_2492_;
v___y_2362_ = v___y_2493_;
v___y_2363_ = v___y_2494_;
v___y_2364_ = v___y_2496_;
v___y_2365_ = v___y_2498_;
v___y_2366_ = v___y_2497_;
v___y_2367_ = v___x_2535_;
goto v___jp_2357_;
}
}
}
}
v___jp_2536_:
{
lean_object* v_offset_2548_; lean_object* v___x_2549_; lean_object* v___x_2550_; uint8_t v___x_2551_; 
v_offset_2548_ = lean_nat_mul(v_i_1902_, v___y_2547_);
v___x_2549_ = lean_nat_add(v_offset_2548_, v___y_2547_);
v___x_2550_ = lean_byte_array_size(v___y_2543_);
v___x_2551_ = lean_nat_dec_le(v___x_2549_, v___x_2550_);
if (v___x_2551_ == 0)
{
lean_dec(v___x_2549_);
v___y_2488_ = v___y_2537_;
v___y_2489_ = v___y_2538_;
v___y_2490_ = v___y_2539_;
v___y_2491_ = v___y_2540_;
v___y_2492_ = v___y_2541_;
v___y_2493_ = v___y_2542_;
v___y_2494_ = v___y_2543_;
v___y_2495_ = v_offset_2548_;
v___y_2496_ = v___y_2544_;
v___y_2497_ = v___y_2545_;
v___y_2498_ = v___y_2546_;
v___y_2499_ = v___x_2551_;
goto v___jp_2487_;
}
else
{
size_t v___x_2552_; lean_object* v___x_2553_; uint8_t v___x_2554_; 
v___x_2552_ = lean_usize_of_nat(v___x_2549_);
v___x_2553_ = lean_usize_to_nat(v___x_2552_);
v___x_2554_ = lean_nat_dec_eq(v___x_2553_, v___x_2549_);
lean_dec(v___x_2549_);
lean_dec(v___x_2553_);
v___y_2488_ = v___y_2537_;
v___y_2489_ = v___y_2538_;
v___y_2490_ = v___y_2539_;
v___y_2491_ = v___y_2540_;
v___y_2492_ = v___y_2541_;
v___y_2493_ = v___y_2542_;
v___y_2494_ = v___y_2543_;
v___y_2495_ = v_offset_2548_;
v___y_2496_ = v___y_2544_;
v___y_2497_ = v___y_2545_;
v___y_2498_ = v___y_2546_;
v___y_2499_ = v___x_2554_;
goto v___jp_2487_;
}
}
v___jp_2555_:
{
uint8_t v___x_2565_; 
v___x_2565_ = 0;
switch(v_width_1897_)
{
case 0:
{
v___y_2537_ = v_chargedUntil_2559_;
v___y_2538_ = v_sugar_2563_;
v___y_2539_ = v___x_2565_;
v___y_2540_ = v_node_2562_;
v___y_2541_ = v_trace_2561_;
v___y_2542_ = v___y_2564_;
v___y_2543_ = v_dense_2557_;
v___y_2544_ = v_leading_2560_;
v___y_2545_ = v_scan_2556_;
v___y_2546_ = v_last_2558_;
v___y_2547_ = v___x_1928_;
goto v___jp_2536_;
}
case 1:
{
lean_object* v___x_2566_; 
v___x_2566_ = lean_unsigned_to_nat(2u);
v___y_2537_ = v_chargedUntil_2559_;
v___y_2538_ = v_sugar_2563_;
v___y_2539_ = v___x_2565_;
v___y_2540_ = v_node_2562_;
v___y_2541_ = v_trace_2561_;
v___y_2542_ = v___y_2564_;
v___y_2543_ = v_dense_2557_;
v___y_2544_ = v_leading_2560_;
v___y_2545_ = v_scan_2556_;
v___y_2546_ = v_last_2558_;
v___y_2547_ = v___x_2566_;
goto v___jp_2536_;
}
default: 
{
lean_object* v___x_2567_; 
v___x_2567_ = lean_unsigned_to_nat(4u);
v___y_2537_ = v_chargedUntil_2559_;
v___y_2538_ = v_sugar_2563_;
v___y_2539_ = v___x_2565_;
v___y_2540_ = v_node_2562_;
v___y_2541_ = v_trace_2561_;
v___y_2542_ = v___y_2564_;
v___y_2543_ = v_dense_2557_;
v___y_2544_ = v_leading_2560_;
v___y_2545_ = v_scan_2556_;
v___y_2546_ = v_last_2558_;
v___y_2547_ = v___x_2567_;
goto v___jp_2536_;
}
}
}
v___jp_2568_:
{
lean_object* v___x_2570_; lean_object* v___x_2571_; lean_object* v_fst_2572_; 
v___x_2570_ = lean_nat_sub(v___y_2569_, v_i_1902_);
v___x_2571_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_1894_, v___x_2570_, v___y_1903_);
lean_dec(v___x_2570_);
v_fst_2572_ = lean_ctor_get(v___x_2571_, 0);
lean_inc(v_fst_2572_);
if (lean_obj_tag(v_fst_2572_) == 0)
{
lean_object* v_snd_2573_; lean_object* v_a_2574_; 
lean_dec(v___y_2569_);
lean_dec(v_sugar_1925_);
lean_dec(v_node_1924_);
lean_dec_ref(v_trace_1923_);
lean_dec(v_leading_1922_);
lean_dec(v_last_1920_);
lean_dec_ref(v_dense_1919_);
lean_dec(v_i_1902_);
v_snd_2573_ = lean_ctor_get(v___x_2571_, 1);
lean_inc(v_snd_2573_);
lean_dec_ref(v___x_2571_);
v_a_2574_ = lean_ctor_get(v_fst_2572_, 0);
lean_inc(v_a_2574_);
lean_dec_ref_known(v_fst_2572_, 1);
v_a_1905_ = v_a_2574_;
v_snd_1906_ = v_snd_2573_;
goto v___jp_1904_;
}
else
{
lean_object* v_snd_2575_; lean_object* v___x_2576_; 
lean_dec_ref_known(v_fst_2572_, 1);
v_snd_2575_ = lean_ctor_get(v___x_2571_, 1);
lean_inc(v_snd_2575_);
lean_dec_ref(v___x_2571_);
lean_inc(v_sugar_1925_);
lean_inc(v_node_1924_);
lean_inc_ref(v_trace_1923_);
lean_inc(v_leading_1922_);
lean_inc(v___y_2569_);
lean_inc(v_last_1920_);
lean_inc_ref(v_dense_1919_);
v___x_2576_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_2576_, 0, v_dense_1919_);
lean_ctor_set(v___x_2576_, 1, v_last_1920_);
lean_ctor_set(v___x_2576_, 2, v___y_2569_);
lean_ctor_set(v___x_2576_, 3, v_leading_1922_);
lean_ctor_set(v___x_2576_, 4, v_trace_1923_);
lean_ctor_set(v___x_2576_, 5, v_node_1924_);
lean_ctor_set(v___x_2576_, 6, v_sugar_1925_);
v_scan_2556_ = v___x_2576_;
v_dense_2557_ = v_dense_1919_;
v_last_2558_ = v_last_1920_;
v_chargedUntil_2559_ = v___y_2569_;
v_leading_2560_ = v_leading_1922_;
v_trace_2561_ = v_trace_1923_;
v_node_2562_ = v_node_1924_;
v_sugar_2563_ = v_sugar_1925_;
v___y_2564_ = v_snd_2575_;
goto v___jp_2555_;
}
}
}
else
{
lean_object* v___x_2582_; lean_object* v___x_2583_; 
lean_dec(v_i_1902_);
v___x_2582_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2582_, 0, v_b_1901_);
v___x_2583_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2583_, 0, v___x_2582_);
lean_ctor_set(v___x_2583_, 1, v___y_1903_);
return v___x_2583_;
}
}
v___jp_1904_:
{
lean_object* v___x_1907_; lean_object* v___x_1908_; 
v___x_1907_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1907_, 0, v_a_1905_);
v___x_1908_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1908_, 0, v___x_1907_);
lean_ctor_set(v___x_1908_, 1, v_snd_1906_);
return v___x_1908_;
}
v___jp_1911_:
{
lean_object* v___x_1914_; 
v___x_1914_ = lean_nat_add(v_i_1902_, v_step_1910_);
lean_dec(v_i_1902_);
v_b_1901_ = v_a_1912_;
v_i_1902_ = v___x_1914_;
v___y_1903_ = v_snd_1913_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5___redArg___boxed(lean_object* v___x_2584_, lean_object* v_limits_2585_, lean_object* v_field_2586_, lean_object* v_ctx_2587_, lean_object* v_width_2588_, lean_object* v_provenance_2589_, lean_object* v___x_2590_, lean_object* v_range_2591_, lean_object* v_b_2592_, lean_object* v_i_2593_, lean_object* v___y_2594_){
_start:
{
uint64_t v_field_boxed_2595_; uint64_t v_ctx_boxed_2596_; uint8_t v_width_boxed_2597_; uint8_t v_provenance_boxed_2598_; lean_object* v_res_2599_; 
v_field_boxed_2595_ = lean_unbox_uint64(v_field_2586_);
lean_dec_ref(v_field_2586_);
v_ctx_boxed_2596_ = lean_unbox_uint64(v_ctx_2587_);
lean_dec_ref(v_ctx_2587_);
v_width_boxed_2597_ = lean_unbox(v_width_2588_);
v_provenance_boxed_2598_ = lean_unbox(v_provenance_2589_);
v_res_2599_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5___redArg(v___x_2584_, v_limits_2585_, v_field_boxed_2595_, v_ctx_boxed_2596_, v_width_boxed_2597_, v_provenance_boxed_2598_, v___x_2590_, v_range_2591_, v_b_2592_, v_i_2593_, v___y_2594_);
lean_dec_ref(v_range_2591_);
lean_dec_ref(v___x_2590_);
lean_dec_ref(v_limits_2585_);
lean_dec_ref(v___x_2584_);
return v_res_2599_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___redArg(lean_object* v___x_2600_, uint64_t v_field_2601_, uint64_t v_ctx_2602_, uint8_t v_width_2603_, lean_object* v_limits_2604_, uint8_t v_provenance_2605_, lean_object* v___x_2606_, lean_object* v_range_2607_, lean_object* v_b_2608_, lean_object* v_i_2609_, lean_object* v___y_2610_){
_start:
{
lean_object* v_a_2612_; lean_object* v_snd_2613_; lean_object* v_stop_2616_; lean_object* v_step_2617_; lean_object* v_a_2619_; lean_object* v_snd_2620_; uint8_t v___x_2623_; 
v_stop_2616_ = lean_ctor_get(v_range_2607_, 1);
v_step_2617_ = lean_ctor_get(v_range_2607_, 2);
v___x_2623_ = lean_nat_dec_lt(v_i_2609_, v_stop_2616_);
if (v___x_2623_ == 0)
{
lean_object* v___x_2624_; lean_object* v___x_2625_; 
lean_dec(v_i_2609_);
v___x_2624_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2624_, 0, v_b_2608_);
v___x_2625_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2625_, 0, v___x_2624_);
lean_ctor_set(v___x_2625_, 1, v___y_2610_);
return v___x_2625_;
}
else
{
lean_object* v_dense_2626_; lean_object* v_last_2627_; lean_object* v_chargedUntil_2628_; lean_object* v_leading_2629_; lean_object* v_trace_2630_; lean_object* v_node_2631_; lean_object* v_sugar_2632_; uint8_t v___x_2633_; 
v_dense_2626_ = lean_ctor_get(v_b_2608_, 0);
v_last_2627_ = lean_ctor_get(v_b_2608_, 1);
v_chargedUntil_2628_ = lean_ctor_get(v_b_2608_, 2);
v_leading_2629_ = lean_ctor_get(v_b_2608_, 3);
v_trace_2630_ = lean_ctor_get(v_b_2608_, 4);
v_node_2631_ = lean_ctor_get(v_b_2608_, 5);
v_sugar_2632_ = lean_ctor_get(v_b_2608_, 6);
v___x_2633_ = lean_nat_dec_lt(v_last_2627_, v_i_2609_);
if (v___x_2633_ == 0)
{
lean_object* v_reducerRank_2634_; lean_object* v___x_2635_; lean_object* v___y_2637_; lean_object* v___y_2638_; lean_object* v___y_2639_; lean_object* v___y_2640_; lean_object* v___y_2641_; lean_object* v___y_2642_; lean_object* v___y_2643_; lean_object* v___y_2644_; lean_object* v___y_2645_; lean_object* v___y_2646_; lean_object* v___y_2647_; uint64_t v___y_2648_; lean_object* v___y_2649_; lean_object* v___y_2711_; lean_object* v___y_2712_; lean_object* v___y_2713_; lean_object* v___y_2714_; lean_object* v___y_2715_; lean_object* v___y_2716_; lean_object* v___y_2717_; lean_object* v___y_2718_; lean_object* v___y_2719_; lean_object* v___y_2720_; lean_object* v___y_2721_; lean_object* v___y_2722_; uint64_t v___y_2723_; lean_object* v___y_2724_; lean_object* v___y_2727_; lean_object* v___y_2728_; lean_object* v___y_2729_; lean_object* v___y_2730_; lean_object* v___y_2731_; lean_object* v___y_2732_; lean_object* v___y_2733_; lean_object* v___y_2734_; lean_object* v___y_2735_; lean_object* v___y_2736_; lean_object* v___y_2737_; uint64_t v___y_2738_; lean_object* v___y_2739_; lean_object* v___y_2740_; uint64_t v___y_2741_; lean_object* v___y_2745_; lean_object* v___y_2746_; lean_object* v___y_2747_; lean_object* v___y_2748_; uint64_t v___y_2749_; lean_object* v___y_2750_; lean_object* v___y_2751_; lean_object* v___y_2752_; lean_object* v___y_2753_; lean_object* v___y_2754_; lean_object* v___y_2755_; lean_object* v___y_2756_; lean_object* v___y_2757_; lean_object* v___y_2758_; uint64_t v___y_2759_; uint8_t v___y_2760_; lean_object* v___y_2766_; lean_object* v___y_2767_; lean_object* v___y_2768_; lean_object* v___y_2769_; lean_object* v___y_2770_; lean_object* v___y_2771_; uint8_t v___y_2772_; lean_object* v___y_2773_; lean_object* v___y_2774_; lean_object* v___y_2775_; uint64_t v___y_2776_; lean_object* v___y_2777_; lean_object* v___y_2778_; lean_object* v___y_2779_; uint64_t v___y_2780_; lean_object* v___y_2781_; lean_object* v___y_2782_; uint8_t v___y_2783_; lean_object* v___y_2796_; lean_object* v___y_2797_; lean_object* v___y_2798_; lean_object* v___y_2799_; lean_object* v___y_2800_; uint64_t v___y_2801_; lean_object* v___y_2802_; uint8_t v___y_2803_; lean_object* v___y_2804_; lean_object* v___y_2805_; lean_object* v___y_2806_; lean_object* v___y_2807_; lean_object* v___y_2808_; lean_object* v___y_2809_; lean_object* v___y_2810_; lean_object* v___y_2811_; uint64_t v___y_2812_; uint8_t v___y_2813_; lean_object* v___y_2826_; lean_object* v___y_2827_; lean_object* v___y_2828_; lean_object* v___y_2829_; lean_object* v___y_2830_; lean_object* v___y_2831_; uint8_t v___y_2832_; lean_object* v___y_2833_; lean_object* v___y_2834_; lean_object* v___y_2835_; lean_object* v___y_2836_; lean_object* v___y_2837_; lean_object* v___y_2838_; uint64_t v___y_2839_; lean_object* v___y_2840_; lean_object* v___y_2841_; uint8_t v___y_2842_; lean_object* v___y_2851_; lean_object* v___y_2852_; lean_object* v___y_2853_; lean_object* v___y_2854_; lean_object* v___y_2855_; lean_object* v___y_2856_; uint8_t v___y_2857_; lean_object* v___y_2858_; lean_object* v___y_2859_; lean_object* v___y_2860_; lean_object* v___y_2861_; lean_object* v___y_2862_; lean_object* v___y_2863_; lean_object* v___y_2864_; uint64_t v___y_2865_; lean_object* v___y_2866_; uint8_t v___y_2867_; lean_object* v___x_2897_; lean_object* v___y_2899_; lean_object* v___y_2900_; lean_object* v___y_2901_; lean_object* v___y_2902_; lean_object* v___y_2903_; lean_object* v___y_2904_; lean_object* v___y_2905_; lean_object* v___y_2906_; lean_object* v___y_2907_; uint64_t v___y_2908_; uint64_t v___y_2909_; lean_object* v___y_2932_; lean_object* v___y_2933_; lean_object* v___y_2934_; lean_object* v___y_2935_; lean_object* v___y_2936_; uint64_t v___y_2937_; lean_object* v___y_2938_; lean_object* v___y_2939_; uint64_t v___y_2940_; lean_object* v___y_2941_; lean_object* v___y_2942_; uint8_t v___y_2943_; lean_object* v___y_2949_; lean_object* v___y_2950_; lean_object* v___y_2951_; uint8_t v___y_2952_; lean_object* v___y_2953_; lean_object* v___y_2954_; lean_object* v___y_2955_; lean_object* v___y_2956_; uint64_t v___y_2957_; lean_object* v___y_2958_; uint64_t v___y_2959_; lean_object* v___y_2960_; lean_object* v___y_2961_; uint8_t v___y_2962_; lean_object* v___y_2975_; lean_object* v___y_2976_; lean_object* v___y_2977_; uint8_t v___y_2978_; lean_object* v___y_2979_; lean_object* v___y_2980_; lean_object* v___y_2981_; lean_object* v___y_2982_; uint64_t v___y_2983_; lean_object* v___y_2984_; uint64_t v___y_2985_; lean_object* v___y_2986_; lean_object* v___y_2987_; uint8_t v___y_2988_; lean_object* v___y_3001_; lean_object* v___y_3002_; lean_object* v___y_3003_; lean_object* v___y_3004_; lean_object* v___y_3005_; lean_object* v___y_3006_; uint8_t v___y_3007_; lean_object* v___y_3008_; lean_object* v___y_3009_; lean_object* v___y_3010_; lean_object* v___y_3011_; uint64_t v___y_3012_; uint8_t v___y_3013_; lean_object* v___y_3022_; lean_object* v___y_3023_; lean_object* v___y_3024_; lean_object* v___y_3025_; lean_object* v___y_3026_; lean_object* v___y_3027_; uint8_t v___y_3028_; lean_object* v___y_3029_; lean_object* v___y_3030_; uint64_t v___y_3031_; lean_object* v___y_3032_; lean_object* v___y_3033_; uint8_t v___y_3034_; lean_object* v___y_3065_; lean_object* v___y_3066_; lean_object* v___y_3067_; lean_object* v___y_3068_; lean_object* v___y_3069_; lean_object* v___y_3070_; lean_object* v___y_3071_; lean_object* v___y_3072_; lean_object* v___y_3073_; uint64_t v___y_3074_; lean_object* v___y_3087_; lean_object* v___y_3088_; lean_object* v___y_3089_; lean_object* v___y_3090_; lean_object* v___y_3091_; lean_object* v___y_3092_; uint64_t v___y_3093_; lean_object* v___y_3094_; lean_object* v___y_3095_; lean_object* v___y_3096_; uint8_t v___y_3097_; lean_object* v___y_3103_; lean_object* v___y_3104_; lean_object* v___y_3105_; lean_object* v___y_3106_; lean_object* v___y_3107_; uint64_t v___y_3108_; lean_object* v___y_3109_; uint8_t v___y_3110_; lean_object* v___y_3111_; lean_object* v___y_3112_; lean_object* v___y_3113_; lean_object* v___y_3114_; uint8_t v___y_3115_; lean_object* v___y_3128_; lean_object* v___y_3129_; lean_object* v___y_3130_; lean_object* v___y_3131_; lean_object* v___y_3132_; uint64_t v___y_3133_; lean_object* v___y_3134_; uint8_t v___y_3135_; lean_object* v___y_3136_; lean_object* v___y_3137_; lean_object* v___y_3138_; lean_object* v___y_3139_; uint8_t v___y_3140_; lean_object* v___y_3153_; lean_object* v___y_3154_; lean_object* v___y_3155_; lean_object* v___y_3156_; lean_object* v___y_3157_; uint64_t v___y_3158_; lean_object* v___y_3159_; lean_object* v___y_3160_; lean_object* v___y_3161_; lean_object* v___y_3162_; uint8_t v___y_3163_; lean_object* v___y_3169_; lean_object* v___y_3170_; lean_object* v___y_3171_; lean_object* v___y_3172_; lean_object* v___y_3173_; lean_object* v___y_3174_; uint8_t v___y_3175_; lean_object* v___y_3176_; lean_object* v___y_3177_; lean_object* v___y_3178_; lean_object* v___y_3179_; uint8_t v___y_3180_; lean_object* v___y_3195_; lean_object* v___y_3196_; lean_object* v___y_3197_; lean_object* v___y_3198_; lean_object* v___y_3199_; lean_object* v___y_3200_; uint8_t v___y_3201_; lean_object* v___y_3202_; lean_object* v___y_3203_; lean_object* v___y_3204_; lean_object* v___y_3205_; uint8_t v___y_3206_; lean_object* v___y_3244_; lean_object* v___y_3245_; lean_object* v___y_3246_; lean_object* v___y_3247_; lean_object* v___y_3248_; lean_object* v___y_3249_; uint8_t v___y_3250_; lean_object* v___y_3251_; lean_object* v___y_3252_; lean_object* v___y_3253_; lean_object* v___y_3254_; lean_object* v_scan_3263_; lean_object* v_dense_3264_; lean_object* v_last_3265_; lean_object* v_chargedUntil_3266_; lean_object* v_leading_3267_; lean_object* v_trace_3268_; lean_object* v_node_3269_; lean_object* v_sugar_3270_; lean_object* v___y_3271_; lean_object* v___y_3276_; uint8_t v___x_3284_; 
lean_inc(v_sugar_2632_);
lean_inc(v_node_2631_);
lean_inc_ref(v_trace_2630_);
lean_inc(v_leading_2629_);
lean_inc(v_chargedUntil_2628_);
lean_inc(v_last_2627_);
lean_inc_ref(v_dense_2626_);
v_reducerRank_2634_ = lean_unsigned_to_nat(0u);
v___x_2635_ = lean_unsigned_to_nat(1u);
v___x_2897_ = lp_Hex_Hex_Groebner_instInhabitedPivot_default;
v___x_3284_ = lean_nat_dec_le(v_chargedUntil_2628_, v_i_2609_);
if (v___x_3284_ == 0)
{
v_scan_3263_ = v_b_2608_;
v_dense_3264_ = v_dense_2626_;
v_last_3265_ = v_last_2627_;
v_chargedUntil_3266_ = v_chargedUntil_2628_;
v_leading_3267_ = v_leading_2629_;
v_trace_3268_ = v_trace_2630_;
v_node_3269_ = v_node_2631_;
v_sugar_3270_ = v_sugar_2632_;
v___y_3271_ = v___y_2610_;
goto v___jp_3262_;
}
else
{
lean_object* v___x_3285_; lean_object* v___x_3286_; lean_object* v___x_3287_; uint8_t v___x_3288_; 
lean_dec(v_chargedUntil_2628_);
lean_dec_ref(v_b_2608_);
v___x_3285_ = lean_unsigned_to_nat(64u);
v___x_3286_ = lean_nat_add(v_i_2609_, v___x_3285_);
v___x_3287_ = lean_nat_add(v_last_2627_, v___x_2635_);
v___x_3288_ = lean_nat_dec_le(v___x_3286_, v___x_3287_);
if (v___x_3288_ == 0)
{
lean_dec(v___x_3286_);
v___y_3276_ = v___x_3287_;
goto v___jp_3275_;
}
else
{
lean_dec(v___x_3287_);
v___y_3276_ = v___x_3286_;
goto v___jp_3275_;
}
}
v___jp_2636_:
{
lean_object* v___x_2650_; lean_object* v_fst_2651_; 
v___x_2650_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_2604_, v___y_2646_, v___y_2640_);
v_fst_2651_ = lean_ctor_get(v___x_2650_, 0);
lean_inc(v_fst_2651_);
if (lean_obj_tag(v_fst_2651_) == 0)
{
lean_object* v_snd_2652_; lean_object* v_a_2653_; 
lean_dec(v___y_2649_);
lean_dec_ref(v___y_2647_);
lean_dec(v___y_2646_);
lean_dec_ref(v___y_2645_);
lean_dec(v___y_2644_);
lean_dec(v___y_2643_);
lean_dec_ref(v___y_2642_);
lean_dec(v___y_2641_);
lean_dec_ref(v___y_2639_);
lean_dec(v___y_2638_);
lean_dec(v___y_2637_);
lean_dec(v_i_2609_);
v_snd_2652_ = lean_ctor_get(v___x_2650_, 1);
lean_inc(v_snd_2652_);
lean_dec_ref(v___x_2650_);
v_a_2653_ = lean_ctor_get(v_fst_2651_, 0);
lean_inc(v_a_2653_);
lean_dec_ref_known(v_fst_2651_, 1);
v_a_2612_ = v_a_2653_;
v_snd_2613_ = v_snd_2652_;
goto v___jp_2611_;
}
else
{
lean_object* v_snd_2654_; lean_object* v___x_2655_; lean_object* v___x_2656_; lean_object* v___x_2657_; lean_object* v_fst_2658_; lean_object* v_snd_2659_; lean_object* v_a_2660_; lean_object* v_work_2661_; lean_object* v_inputEntries_2662_; lean_object* v_outputEntries_2663_; lean_object* v_packedBytes_2664_; lean_object* v_traceNodes_2665_; lean_object* v_processedRows_2666_; lean_object* v_reductions_2667_; lean_object* v_zeroRows_2668_; lean_object* v___x_2670_; uint8_t v_isShared_2671_; uint8_t v_isSharedCheck_2709_; 
lean_dec_ref_known(v_fst_2651_, 1);
v_snd_2654_ = lean_ctor_get(v___x_2650_, 1);
lean_inc(v_snd_2654_);
lean_dec_ref(v___x_2650_);
v___x_2655_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_2655_, 0, v___y_2639_);
lean_ctor_set(v___x_2655_, 1, v___y_2643_);
lean_ctor_set(v___x_2655_, 2, v___y_2644_);
lean_ctor_set(v___x_2655_, 3, v___y_2638_);
lean_ctor_set(v___x_2655_, 4, v___y_2645_);
lean_ctor_set(v___x_2655_, 5, v___y_2637_);
lean_ctor_set(v___x_2655_, 6, v___y_2649_);
v___x_2656_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2656_, 0, v_reducerRank_2634_);
lean_ctor_set(v___x_2656_, 1, v___y_2646_);
lean_ctor_set(v___x_2656_, 2, v___x_2635_);
v___x_2657_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg(v_field_2601_, v_ctx_2602_, v___y_2648_, v_width_2603_, v___y_2642_, v___y_2647_, v___x_2656_, v___x_2655_, v_reducerRank_2634_, v_snd_2654_);
lean_dec_ref_known(v___x_2656_, 3);
lean_dec_ref(v___y_2647_);
lean_dec_ref(v___y_2642_);
v_fst_2658_ = lean_ctor_get(v___x_2657_, 0);
lean_inc(v_fst_2658_);
v_snd_2659_ = lean_ctor_get(v___x_2657_, 1);
lean_inc(v_snd_2659_);
lean_dec_ref(v___x_2657_);
v_a_2660_ = lean_ctor_get(v_fst_2658_, 0);
lean_inc(v_a_2660_);
lean_dec(v_fst_2658_);
v_work_2661_ = lean_ctor_get(v_snd_2659_, 0);
v_inputEntries_2662_ = lean_ctor_get(v_snd_2659_, 1);
v_outputEntries_2663_ = lean_ctor_get(v_snd_2659_, 2);
v_packedBytes_2664_ = lean_ctor_get(v_snd_2659_, 3);
v_traceNodes_2665_ = lean_ctor_get(v_snd_2659_, 4);
v_processedRows_2666_ = lean_ctor_get(v_snd_2659_, 5);
v_reductions_2667_ = lean_ctor_get(v_snd_2659_, 6);
v_zeroRows_2668_ = lean_ctor_get(v_snd_2659_, 7);
v_isSharedCheck_2709_ = !lean_is_exclusive(v_snd_2659_);
if (v_isSharedCheck_2709_ == 0)
{
v___x_2670_ = v_snd_2659_;
v_isShared_2671_ = v_isSharedCheck_2709_;
goto v_resetjp_2669_;
}
else
{
lean_inc(v_zeroRows_2668_);
lean_inc(v_reductions_2667_);
lean_inc(v_processedRows_2666_);
lean_inc(v_traceNodes_2665_);
lean_inc(v_packedBytes_2664_);
lean_inc(v_outputEntries_2663_);
lean_inc(v_inputEntries_2662_);
lean_inc(v_work_2661_);
lean_dec(v_snd_2659_);
v___x_2670_ = lean_box(0);
v_isShared_2671_ = v_isSharedCheck_2709_;
goto v_resetjp_2669_;
}
v_resetjp_2669_:
{
lean_object* v_dense_2672_; lean_object* v_last_2673_; lean_object* v_chargedUntil_2674_; lean_object* v_leading_2675_; lean_object* v_trace_2676_; lean_object* v_node_2677_; lean_object* v_sugar_2678_; lean_object* v___x_2679_; lean_object* v___x_2681_; 
v_dense_2672_ = lean_ctor_get(v_a_2660_, 0);
v_last_2673_ = lean_ctor_get(v_a_2660_, 1);
v_chargedUntil_2674_ = lean_ctor_get(v_a_2660_, 2);
v_leading_2675_ = lean_ctor_get(v_a_2660_, 3);
v_trace_2676_ = lean_ctor_get(v_a_2660_, 4);
v_node_2677_ = lean_ctor_get(v_a_2660_, 5);
v_sugar_2678_ = lean_ctor_get(v_a_2660_, 6);
v___x_2679_ = lean_nat_add(v_reductions_2667_, v___x_2635_);
lean_dec(v_reductions_2667_);
if (v_isShared_2671_ == 0)
{
lean_ctor_set(v___x_2670_, 6, v___x_2679_);
v___x_2681_ = v___x_2670_;
goto v_reusejp_2680_;
}
else
{
lean_object* v_reuseFailAlloc_2708_; 
v_reuseFailAlloc_2708_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_2708_, 0, v_work_2661_);
lean_ctor_set(v_reuseFailAlloc_2708_, 1, v_inputEntries_2662_);
lean_ctor_set(v_reuseFailAlloc_2708_, 2, v_outputEntries_2663_);
lean_ctor_set(v_reuseFailAlloc_2708_, 3, v_packedBytes_2664_);
lean_ctor_set(v_reuseFailAlloc_2708_, 4, v_traceNodes_2665_);
lean_ctor_set(v_reuseFailAlloc_2708_, 5, v_processedRows_2666_);
lean_ctor_set(v_reuseFailAlloc_2708_, 6, v___x_2679_);
lean_ctor_set(v_reuseFailAlloc_2708_, 7, v_zeroRows_2668_);
v___x_2681_ = v_reuseFailAlloc_2708_;
goto v_reusejp_2680_;
}
v_reusejp_2680_:
{
if (lean_obj_tag(v_node_2677_) == 1)
{
if (lean_obj_tag(v___y_2641_) == 1)
{
lean_object* v___x_2683_; uint8_t v_isShared_2684_; uint8_t v_isSharedCheck_2700_; 
lean_inc_ref(v_node_2677_);
lean_inc(v_sugar_2678_);
lean_inc_ref(v_trace_2676_);
lean_inc(v_leading_2675_);
lean_inc(v_chargedUntil_2674_);
lean_inc(v_last_2673_);
lean_inc_ref(v_dense_2672_);
v_isSharedCheck_2700_ = !lean_is_exclusive(v_a_2660_);
if (v_isSharedCheck_2700_ == 0)
{
lean_object* v_unused_2701_; lean_object* v_unused_2702_; lean_object* v_unused_2703_; lean_object* v_unused_2704_; lean_object* v_unused_2705_; lean_object* v_unused_2706_; lean_object* v_unused_2707_; 
v_unused_2701_ = lean_ctor_get(v_a_2660_, 6);
lean_dec(v_unused_2701_);
v_unused_2702_ = lean_ctor_get(v_a_2660_, 5);
lean_dec(v_unused_2702_);
v_unused_2703_ = lean_ctor_get(v_a_2660_, 4);
lean_dec(v_unused_2703_);
v_unused_2704_ = lean_ctor_get(v_a_2660_, 3);
lean_dec(v_unused_2704_);
v_unused_2705_ = lean_ctor_get(v_a_2660_, 2);
lean_dec(v_unused_2705_);
v_unused_2706_ = lean_ctor_get(v_a_2660_, 1);
lean_dec(v_unused_2706_);
v_unused_2707_ = lean_ctor_get(v_a_2660_, 0);
lean_dec(v_unused_2707_);
v___x_2683_ = v_a_2660_;
v_isShared_2684_ = v_isSharedCheck_2700_;
goto v_resetjp_2682_;
}
else
{
lean_dec(v_a_2660_);
v___x_2683_ = lean_box(0);
v_isShared_2684_ = v_isSharedCheck_2700_;
goto v_resetjp_2682_;
}
v_resetjp_2682_:
{
lean_object* v_val_2685_; lean_object* v_val_2686_; uint64_t v___x_2687_; lean_object* v___x_2688_; lean_object* v___x_2689_; lean_object* v_fst_2690_; 
v_val_2685_ = lean_ctor_get(v_node_2677_, 0);
lean_inc(v_val_2685_);
lean_dec_ref_known(v_node_2677_, 1);
v_val_2686_ = lean_ctor_get(v___y_2641_, 0);
lean_inc(v_val_2686_);
lean_dec_ref_known(v___y_2641_, 1);
v___x_2687_ = lean_uint64_sub(v_field_2601_, v___y_2648_);
v___x_2688_ = lean_alloc_ctor(1, 2, 8);
lean_ctor_set(v___x_2688_, 0, v_val_2685_);
lean_ctor_set(v___x_2688_, 1, v_val_2686_);
lean_ctor_set_uint64(v___x_2688_, sizeof(void*)*2, v___x_2687_);
v___x_2689_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_2604_, v_provenance_2605_, v_trace_2676_, v___x_2688_, v___x_2681_);
v_fst_2690_ = lean_ctor_get(v___x_2689_, 0);
lean_inc(v_fst_2690_);
if (lean_obj_tag(v_fst_2690_) == 0)
{
lean_object* v_snd_2691_; lean_object* v_a_2692_; 
lean_del_object(v___x_2683_);
lean_dec(v_sugar_2678_);
lean_dec(v_leading_2675_);
lean_dec(v_chargedUntil_2674_);
lean_dec(v_last_2673_);
lean_dec_ref(v_dense_2672_);
lean_dec(v_i_2609_);
v_snd_2691_ = lean_ctor_get(v___x_2689_, 1);
lean_inc(v_snd_2691_);
lean_dec_ref(v___x_2689_);
v_a_2692_ = lean_ctor_get(v_fst_2690_, 0);
lean_inc(v_a_2692_);
lean_dec_ref_known(v_fst_2690_, 1);
v_a_2612_ = v_a_2692_;
v_snd_2613_ = v_snd_2691_;
goto v___jp_2611_;
}
else
{
lean_object* v_a_2693_; lean_object* v_snd_2694_; lean_object* v_fst_2695_; lean_object* v_snd_2696_; lean_object* v___x_2698_; 
v_a_2693_ = lean_ctor_get(v_fst_2690_, 0);
lean_inc(v_a_2693_);
lean_dec_ref_known(v_fst_2690_, 1);
v_snd_2694_ = lean_ctor_get(v___x_2689_, 1);
lean_inc(v_snd_2694_);
lean_dec_ref(v___x_2689_);
v_fst_2695_ = lean_ctor_get(v_a_2693_, 0);
lean_inc(v_fst_2695_);
v_snd_2696_ = lean_ctor_get(v_a_2693_, 1);
lean_inc(v_snd_2696_);
lean_dec(v_a_2693_);
if (v_isShared_2684_ == 0)
{
lean_ctor_set(v___x_2683_, 5, v_snd_2696_);
lean_ctor_set(v___x_2683_, 4, v_fst_2695_);
v___x_2698_ = v___x_2683_;
goto v_reusejp_2697_;
}
else
{
lean_object* v_reuseFailAlloc_2699_; 
v_reuseFailAlloc_2699_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v_reuseFailAlloc_2699_, 0, v_dense_2672_);
lean_ctor_set(v_reuseFailAlloc_2699_, 1, v_last_2673_);
lean_ctor_set(v_reuseFailAlloc_2699_, 2, v_chargedUntil_2674_);
lean_ctor_set(v_reuseFailAlloc_2699_, 3, v_leading_2675_);
lean_ctor_set(v_reuseFailAlloc_2699_, 4, v_fst_2695_);
lean_ctor_set(v_reuseFailAlloc_2699_, 5, v_snd_2696_);
lean_ctor_set(v_reuseFailAlloc_2699_, 6, v_sugar_2678_);
v___x_2698_ = v_reuseFailAlloc_2699_;
goto v_reusejp_2697_;
}
v_reusejp_2697_:
{
v_a_2619_ = v___x_2698_;
v_snd_2620_ = v_snd_2694_;
goto v___jp_2618_;
}
}
}
}
else
{
lean_dec(v___y_2641_);
v_a_2619_ = v_a_2660_;
v_snd_2620_ = v___x_2681_;
goto v___jp_2618_;
}
}
else
{
lean_dec(v___y_2641_);
v_a_2619_ = v_a_2660_;
v_snd_2620_ = v___x_2681_;
goto v___jp_2618_;
}
}
}
}
}
v___jp_2710_:
{
uint8_t v___x_2725_; 
v___x_2725_ = lean_nat_dec_le(v___y_2717_, v___y_2719_);
if (v___x_2725_ == 0)
{
lean_dec(v___y_2719_);
v___y_2637_ = v___y_2716_;
v___y_2638_ = v___y_2711_;
v___y_2639_ = v___y_2712_;
v___y_2640_ = v___y_2713_;
v___y_2641_ = v___y_2718_;
v___y_2642_ = v___y_2714_;
v___y_2643_ = v___y_2724_;
v___y_2644_ = v___y_2715_;
v___y_2645_ = v___y_2720_;
v___y_2646_ = v___y_2721_;
v___y_2647_ = v___y_2722_;
v___y_2648_ = v___y_2723_;
v___y_2649_ = v___y_2717_;
goto v___jp_2636_;
}
else
{
lean_dec(v___y_2717_);
v___y_2637_ = v___y_2716_;
v___y_2638_ = v___y_2711_;
v___y_2639_ = v___y_2712_;
v___y_2640_ = v___y_2713_;
v___y_2641_ = v___y_2718_;
v___y_2642_ = v___y_2714_;
v___y_2643_ = v___y_2724_;
v___y_2644_ = v___y_2715_;
v___y_2645_ = v___y_2720_;
v___y_2646_ = v___y_2721_;
v___y_2647_ = v___y_2722_;
v___y_2648_ = v___y_2723_;
v___y_2649_ = v___y_2719_;
goto v___jp_2636_;
}
}
v___jp_2726_:
{
lean_object* v___x_2742_; uint8_t v___x_2743_; 
v___x_2742_ = lean_uint64_to_nat(v___y_2741_);
v___x_2743_ = lean_nat_dec_le(v___y_2739_, v___x_2742_);
if (v___x_2743_ == 0)
{
lean_dec(v___x_2742_);
v___y_2711_ = v___y_2727_;
v___y_2712_ = v___y_2728_;
v___y_2713_ = v___y_2729_;
v___y_2714_ = v___y_2730_;
v___y_2715_ = v___y_2731_;
v___y_2716_ = v___y_2732_;
v___y_2717_ = v___y_2733_;
v___y_2718_ = v___y_2734_;
v___y_2719_ = v___y_2735_;
v___y_2720_ = v___y_2736_;
v___y_2721_ = v___y_2737_;
v___y_2722_ = v___y_2740_;
v___y_2723_ = v___y_2738_;
v___y_2724_ = v___y_2739_;
goto v___jp_2710_;
}
else
{
lean_dec(v___y_2739_);
v___y_2711_ = v___y_2727_;
v___y_2712_ = v___y_2728_;
v___y_2713_ = v___y_2729_;
v___y_2714_ = v___y_2730_;
v___y_2715_ = v___y_2731_;
v___y_2716_ = v___y_2732_;
v___y_2717_ = v___y_2733_;
v___y_2718_ = v___y_2734_;
v___y_2719_ = v___y_2735_;
v___y_2720_ = v___y_2736_;
v___y_2721_ = v___y_2737_;
v___y_2722_ = v___y_2740_;
v___y_2723_ = v___y_2738_;
v___y_2724_ = v___x_2742_;
goto v___jp_2710_;
}
}
v___jp_2744_:
{
uint64_t v___x_2761_; uint64_t v___x_2762_; uint64_t v___x_2763_; uint64_t v___x_2764_; 
v___x_2761_ = lean_uint8_to_uint64(v___y_2760_);
v___x_2762_ = 24ULL;
v___x_2763_ = lean_uint64_shift_left(v___x_2761_, v___x_2762_);
v___x_2764_ = lean_uint64_lor(v___y_2749_, v___x_2763_);
v___y_2727_ = v___y_2745_;
v___y_2728_ = v___y_2746_;
v___y_2729_ = v___y_2747_;
v___y_2730_ = v___y_2748_;
v___y_2731_ = v___y_2750_;
v___y_2732_ = v___y_2751_;
v___y_2733_ = v___y_2752_;
v___y_2734_ = v___y_2753_;
v___y_2735_ = v___y_2754_;
v___y_2736_ = v___y_2755_;
v___y_2737_ = v___y_2756_;
v___y_2738_ = v___y_2759_;
v___y_2739_ = v___y_2758_;
v___y_2740_ = v___y_2757_;
v___y_2741_ = v___x_2764_;
goto v___jp_2726_;
}
v___jp_2765_:
{
uint64_t v___x_2784_; uint64_t v___x_2785_; uint64_t v___x_2786_; uint64_t v___x_2787_; lean_object* v___x_2788_; lean_object* v___x_2789_; uint8_t v___x_2790_; 
v___x_2784_ = lean_uint8_to_uint64(v___y_2783_);
v___x_2785_ = 16ULL;
v___x_2786_ = lean_uint64_shift_left(v___x_2784_, v___x_2785_);
v___x_2787_ = lean_uint64_lor(v___y_2776_, v___x_2786_);
v___x_2788_ = lean_unsigned_to_nat(3u);
v___x_2789_ = lean_nat_add(v___y_2774_, v___x_2788_);
lean_dec(v___y_2774_);
v___x_2790_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2782_, v___x_2789_);
if (v___x_2790_ == 0)
{
lean_object* v___x_2791_; lean_object* v___x_2792_; uint8_t v___x_2793_; 
lean_dec(v___x_2789_);
v___x_2791_ = lean_box(v___y_2772_);
v___x_2792_ = l_outOfBounds___redArg(v___x_2791_);
lean_dec(v___x_2791_);
v___x_2793_ = lean_unbox(v___x_2792_);
lean_dec(v___x_2792_);
v___y_2745_ = v___y_2766_;
v___y_2746_ = v___y_2767_;
v___y_2747_ = v___y_2768_;
v___y_2748_ = v___y_2769_;
v___y_2749_ = v___x_2787_;
v___y_2750_ = v___y_2770_;
v___y_2751_ = v___y_2771_;
v___y_2752_ = v___y_2773_;
v___y_2753_ = v___y_2775_;
v___y_2754_ = v___y_2777_;
v___y_2755_ = v___y_2778_;
v___y_2756_ = v___y_2779_;
v___y_2757_ = v___y_2782_;
v___y_2758_ = v___y_2781_;
v___y_2759_ = v___y_2780_;
v___y_2760_ = v___x_2793_;
goto v___jp_2744_;
}
else
{
uint8_t v___x_2794_; 
v___x_2794_ = lean_byte_array_fget(v___y_2782_, v___x_2789_);
lean_dec(v___x_2789_);
v___y_2745_ = v___y_2766_;
v___y_2746_ = v___y_2767_;
v___y_2747_ = v___y_2768_;
v___y_2748_ = v___y_2769_;
v___y_2749_ = v___x_2787_;
v___y_2750_ = v___y_2770_;
v___y_2751_ = v___y_2771_;
v___y_2752_ = v___y_2773_;
v___y_2753_ = v___y_2775_;
v___y_2754_ = v___y_2777_;
v___y_2755_ = v___y_2778_;
v___y_2756_ = v___y_2779_;
v___y_2757_ = v___y_2782_;
v___y_2758_ = v___y_2781_;
v___y_2759_ = v___y_2780_;
v___y_2760_ = v___x_2794_;
goto v___jp_2744_;
}
}
v___jp_2795_:
{
uint64_t v___x_2814_; uint64_t v___x_2815_; uint64_t v___x_2816_; uint64_t v___x_2817_; lean_object* v___x_2818_; lean_object* v___x_2819_; uint8_t v___x_2820_; 
v___x_2814_ = lean_uint8_to_uint64(v___y_2813_);
v___x_2815_ = 8ULL;
v___x_2816_ = lean_uint64_shift_left(v___x_2814_, v___x_2815_);
v___x_2817_ = lean_uint64_lor(v___y_2801_, v___x_2816_);
v___x_2818_ = lean_unsigned_to_nat(2u);
v___x_2819_ = lean_nat_add(v___y_2805_, v___x_2818_);
v___x_2820_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2810_, v___x_2819_);
if (v___x_2820_ == 0)
{
lean_object* v___x_2821_; lean_object* v___x_2822_; uint8_t v___x_2823_; 
lean_dec(v___x_2819_);
v___x_2821_ = lean_box(v___y_2803_);
v___x_2822_ = l_outOfBounds___redArg(v___x_2821_);
lean_dec(v___x_2821_);
v___x_2823_ = lean_unbox(v___x_2822_);
lean_dec(v___x_2822_);
v___y_2766_ = v___y_2796_;
v___y_2767_ = v___y_2797_;
v___y_2768_ = v___y_2798_;
v___y_2769_ = v___y_2799_;
v___y_2770_ = v___y_2800_;
v___y_2771_ = v___y_2802_;
v___y_2772_ = v___y_2803_;
v___y_2773_ = v___y_2804_;
v___y_2774_ = v___y_2805_;
v___y_2775_ = v___y_2806_;
v___y_2776_ = v___x_2817_;
v___y_2777_ = v___y_2807_;
v___y_2778_ = v___y_2808_;
v___y_2779_ = v___y_2809_;
v___y_2780_ = v___y_2812_;
v___y_2781_ = v___y_2811_;
v___y_2782_ = v___y_2810_;
v___y_2783_ = v___x_2823_;
goto v___jp_2765_;
}
else
{
uint8_t v___x_2824_; 
v___x_2824_ = lean_byte_array_fget(v___y_2810_, v___x_2819_);
lean_dec(v___x_2819_);
v___y_2766_ = v___y_2796_;
v___y_2767_ = v___y_2797_;
v___y_2768_ = v___y_2798_;
v___y_2769_ = v___y_2799_;
v___y_2770_ = v___y_2800_;
v___y_2771_ = v___y_2802_;
v___y_2772_ = v___y_2803_;
v___y_2773_ = v___y_2804_;
v___y_2774_ = v___y_2805_;
v___y_2775_ = v___y_2806_;
v___y_2776_ = v___x_2817_;
v___y_2777_ = v___y_2807_;
v___y_2778_ = v___y_2808_;
v___y_2779_ = v___y_2809_;
v___y_2780_ = v___y_2812_;
v___y_2781_ = v___y_2811_;
v___y_2782_ = v___y_2810_;
v___y_2783_ = v___x_2824_;
goto v___jp_2765_;
}
}
v___jp_2825_:
{
uint64_t v_a_2843_; lean_object* v___x_2844_; uint8_t v___x_2845_; 
v_a_2843_ = lean_uint8_to_uint64(v___y_2842_);
v___x_2844_ = lean_nat_add(v___y_2834_, v___x_2635_);
v___x_2845_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2841_, v___x_2844_);
if (v___x_2845_ == 0)
{
lean_object* v___x_2846_; lean_object* v___x_2847_; uint8_t v___x_2848_; 
lean_dec(v___x_2844_);
v___x_2846_ = lean_box(v___y_2832_);
v___x_2847_ = l_outOfBounds___redArg(v___x_2846_);
lean_dec(v___x_2846_);
v___x_2848_ = lean_unbox(v___x_2847_);
lean_dec(v___x_2847_);
v___y_2796_ = v___y_2826_;
v___y_2797_ = v___y_2827_;
v___y_2798_ = v___y_2828_;
v___y_2799_ = v___y_2829_;
v___y_2800_ = v___y_2830_;
v___y_2801_ = v_a_2843_;
v___y_2802_ = v___y_2831_;
v___y_2803_ = v___y_2832_;
v___y_2804_ = v___y_2833_;
v___y_2805_ = v___y_2834_;
v___y_2806_ = v___y_2835_;
v___y_2807_ = v___y_2836_;
v___y_2808_ = v___y_2837_;
v___y_2809_ = v___y_2838_;
v___y_2810_ = v___y_2841_;
v___y_2811_ = v___y_2840_;
v___y_2812_ = v___y_2839_;
v___y_2813_ = v___x_2848_;
goto v___jp_2795_;
}
else
{
uint8_t v___x_2849_; 
v___x_2849_ = lean_byte_array_fget(v___y_2841_, v___x_2844_);
lean_dec(v___x_2844_);
v___y_2796_ = v___y_2826_;
v___y_2797_ = v___y_2827_;
v___y_2798_ = v___y_2828_;
v___y_2799_ = v___y_2829_;
v___y_2800_ = v___y_2830_;
v___y_2801_ = v_a_2843_;
v___y_2802_ = v___y_2831_;
v___y_2803_ = v___y_2832_;
v___y_2804_ = v___y_2833_;
v___y_2805_ = v___y_2834_;
v___y_2806_ = v___y_2835_;
v___y_2807_ = v___y_2836_;
v___y_2808_ = v___y_2837_;
v___y_2809_ = v___y_2838_;
v___y_2810_ = v___y_2841_;
v___y_2811_ = v___y_2840_;
v___y_2812_ = v___y_2839_;
v___y_2813_ = v___x_2849_;
goto v___jp_2795_;
}
}
v___jp_2850_:
{
if (v___y_2867_ == 0)
{
uint8_t v___x_2868_; 
v___x_2868_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_2866_, v___y_2859_);
if (v___x_2868_ == 0)
{
lean_object* v___x_2869_; lean_object* v___x_2870_; uint8_t v___x_2871_; 
v___x_2869_ = lean_box(v___y_2857_);
v___x_2870_ = l_outOfBounds___redArg(v___x_2869_);
lean_dec(v___x_2869_);
v___x_2871_ = lean_unbox(v___x_2870_);
lean_dec(v___x_2870_);
v___y_2826_ = v___y_2851_;
v___y_2827_ = v___y_2852_;
v___y_2828_ = v___y_2853_;
v___y_2829_ = v___y_2854_;
v___y_2830_ = v___y_2855_;
v___y_2831_ = v___y_2856_;
v___y_2832_ = v___y_2857_;
v___y_2833_ = v___y_2858_;
v___y_2834_ = v___y_2859_;
v___y_2835_ = v___y_2860_;
v___y_2836_ = v___y_2861_;
v___y_2837_ = v___y_2862_;
v___y_2838_ = v___y_2863_;
v___y_2839_ = v___y_2865_;
v___y_2840_ = v___y_2864_;
v___y_2841_ = v___y_2866_;
v___y_2842_ = v___x_2871_;
goto v___jp_2825_;
}
else
{
uint8_t v___x_2872_; 
v___x_2872_ = lean_byte_array_fget(v___y_2866_, v___y_2859_);
v___y_2826_ = v___y_2851_;
v___y_2827_ = v___y_2852_;
v___y_2828_ = v___y_2853_;
v___y_2829_ = v___y_2854_;
v___y_2830_ = v___y_2855_;
v___y_2831_ = v___y_2856_;
v___y_2832_ = v___y_2857_;
v___y_2833_ = v___y_2858_;
v___y_2834_ = v___y_2859_;
v___y_2835_ = v___y_2860_;
v___y_2836_ = v___y_2861_;
v___y_2837_ = v___y_2862_;
v___y_2838_ = v___y_2863_;
v___y_2839_ = v___y_2865_;
v___y_2840_ = v___y_2864_;
v___y_2841_ = v___y_2866_;
v___y_2842_ = v___x_2872_;
goto v___jp_2825_;
}
}
else
{
size_t v_pos_2873_; uint8_t v___x_2874_; uint64_t v_a_2875_; size_t v___x_2876_; size_t v___x_2877_; uint8_t v___x_2878_; uint64_t v___x_2879_; uint64_t v___x_2880_; uint64_t v___x_2881_; uint64_t v___x_2882_; size_t v___x_2883_; size_t v___x_2884_; uint8_t v___x_2885_; uint64_t v___x_2886_; uint64_t v___x_2887_; uint64_t v___x_2888_; uint64_t v___x_2889_; size_t v___x_2890_; size_t v___x_2891_; uint8_t v___x_2892_; uint64_t v___x_2893_; uint64_t v___x_2894_; uint64_t v___x_2895_; uint64_t v___x_2896_; 
v_pos_2873_ = lean_usize_of_nat(v___y_2859_);
lean_dec(v___y_2859_);
v___x_2874_ = lean_byte_array_uget(v___y_2866_, v_pos_2873_);
v_a_2875_ = lean_uint8_to_uint64(v___x_2874_);
v___x_2876_ = ((size_t)1ULL);
v___x_2877_ = lean_usize_add(v_pos_2873_, v___x_2876_);
v___x_2878_ = lean_byte_array_uget(v___y_2866_, v___x_2877_);
v___x_2879_ = lean_uint8_to_uint64(v___x_2878_);
v___x_2880_ = 8ULL;
v___x_2881_ = lean_uint64_shift_left(v___x_2879_, v___x_2880_);
v___x_2882_ = lean_uint64_lor(v_a_2875_, v___x_2881_);
v___x_2883_ = ((size_t)2ULL);
v___x_2884_ = lean_usize_add(v_pos_2873_, v___x_2883_);
v___x_2885_ = lean_byte_array_uget(v___y_2866_, v___x_2884_);
v___x_2886_ = lean_uint8_to_uint64(v___x_2885_);
v___x_2887_ = 16ULL;
v___x_2888_ = lean_uint64_shift_left(v___x_2886_, v___x_2887_);
v___x_2889_ = lean_uint64_lor(v___x_2882_, v___x_2888_);
v___x_2890_ = ((size_t)3ULL);
v___x_2891_ = lean_usize_add(v_pos_2873_, v___x_2890_);
v___x_2892_ = lean_byte_array_uget(v___y_2866_, v___x_2891_);
v___x_2893_ = lean_uint8_to_uint64(v___x_2892_);
v___x_2894_ = 24ULL;
v___x_2895_ = lean_uint64_shift_left(v___x_2893_, v___x_2894_);
v___x_2896_ = lean_uint64_lor(v___x_2889_, v___x_2895_);
v___y_2727_ = v___y_2851_;
v___y_2728_ = v___y_2852_;
v___y_2729_ = v___y_2853_;
v___y_2730_ = v___y_2854_;
v___y_2731_ = v___y_2855_;
v___y_2732_ = v___y_2856_;
v___y_2733_ = v___y_2858_;
v___y_2734_ = v___y_2860_;
v___y_2735_ = v___y_2861_;
v___y_2736_ = v___y_2862_;
v___y_2737_ = v___y_2863_;
v___y_2738_ = v___y_2865_;
v___y_2739_ = v___y_2864_;
v___y_2740_ = v___y_2866_;
v___y_2741_ = v___x_2896_;
goto v___jp_2726_;
}
}
v___jp_2898_:
{
lean_object* v___x_2910_; uint8_t v___x_2911_; 
v___x_2910_ = lean_uint64_to_nat(v___y_2909_);
v___x_2911_ = lean_nat_dec_eq(v___x_2910_, v_reducerRank_2634_);
if (v___x_2911_ == 0)
{
lean_object* v___x_2912_; lean_object* v___x_2913_; lean_object* v_row_2914_; lean_object* v_derivation_2915_; lean_object* v_sugar_2916_; lean_object* v_columns_2917_; lean_object* v___x_2918_; lean_object* v___x_2919_; uint8_t v___x_2920_; lean_object* v___x_2921_; lean_object* v_offset_2922_; lean_object* v___x_2923_; lean_object* v___x_2924_; uint8_t v___x_2925_; 
lean_dec_ref(v___y_2906_);
v___x_2912_ = lean_nat_sub(v___x_2910_, v___x_2635_);
lean_dec(v___x_2910_);
v___x_2913_ = lean_array_get_borrowed(v___x_2897_, v___x_2600_, v___x_2912_);
lean_dec(v___x_2912_);
v_row_2914_ = lean_ctor_get(v___x_2913_, 0);
v_derivation_2915_ = lean_ctor_get(v___x_2913_, 1);
v_sugar_2916_ = lean_ctor_get(v___x_2913_, 2);
v_columns_2917_ = lean_ctor_get(v_row_2914_, 0);
v___x_2918_ = lp_Hex_Hex_Groebner_SparseRow_size(v_row_2914_);
v___x_2919_ = lean_nat_sub(v___x_2918_, v___x_2635_);
v___x_2920_ = 0;
v___x_2921_ = lean_unsigned_to_nat(4u);
v_offset_2922_ = lean_nat_mul(v___x_2919_, v___x_2921_);
lean_dec(v___x_2919_);
v___x_2923_ = lean_nat_add(v_offset_2922_, v___x_2921_);
v___x_2924_ = lean_byte_array_size(v_columns_2917_);
v___x_2925_ = lean_nat_dec_le(v___x_2923_, v___x_2924_);
if (v___x_2925_ == 0)
{
lean_dec(v___x_2923_);
lean_inc_ref(v_columns_2917_);
lean_inc(v_sugar_2916_);
lean_inc(v_derivation_2915_);
lean_inc_ref(v_row_2914_);
v___y_2851_ = v___y_2900_;
v___y_2852_ = v___y_2903_;
v___y_2853_ = v___y_2902_;
v___y_2854_ = v_row_2914_;
v___y_2855_ = v___y_2904_;
v___y_2856_ = v___y_2899_;
v___y_2857_ = v___x_2920_;
v___y_2858_ = v___y_2901_;
v___y_2859_ = v_offset_2922_;
v___y_2860_ = v_derivation_2915_;
v___y_2861_ = v_sugar_2916_;
v___y_2862_ = v___y_2905_;
v___y_2863_ = v___x_2918_;
v___y_2864_ = v___y_2907_;
v___y_2865_ = v___y_2908_;
v___y_2866_ = v_columns_2917_;
v___y_2867_ = v___x_2925_;
goto v___jp_2850_;
}
else
{
size_t v___x_2926_; lean_object* v___x_2927_; uint8_t v___x_2928_; 
v___x_2926_ = lean_usize_of_nat(v___x_2923_);
v___x_2927_ = lean_usize_to_nat(v___x_2926_);
v___x_2928_ = lean_nat_dec_eq(v___x_2927_, v___x_2923_);
lean_dec(v___x_2923_);
lean_dec(v___x_2927_);
lean_inc_ref(v_columns_2917_);
lean_inc(v_sugar_2916_);
lean_inc(v_derivation_2915_);
lean_inc_ref(v_row_2914_);
v___y_2851_ = v___y_2900_;
v___y_2852_ = v___y_2903_;
v___y_2853_ = v___y_2902_;
v___y_2854_ = v_row_2914_;
v___y_2855_ = v___y_2904_;
v___y_2856_ = v___y_2899_;
v___y_2857_ = v___x_2920_;
v___y_2858_ = v___y_2901_;
v___y_2859_ = v_offset_2922_;
v___y_2860_ = v_derivation_2915_;
v___y_2861_ = v_sugar_2916_;
v___y_2862_ = v___y_2905_;
v___y_2863_ = v___x_2918_;
v___y_2864_ = v___y_2907_;
v___y_2865_ = v___y_2908_;
v___y_2866_ = v_columns_2917_;
v___y_2867_ = v___x_2928_;
goto v___jp_2850_;
}
}
else
{
lean_dec(v___x_2910_);
if (lean_obj_tag(v___y_2900_) == 0)
{
lean_object* v___x_2929_; lean_object* v___x_2930_; 
lean_dec_ref(v___y_2906_);
lean_inc(v_i_2609_);
v___x_2929_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2929_, 0, v_i_2609_);
v___x_2930_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_2930_, 0, v___y_2903_);
lean_ctor_set(v___x_2930_, 1, v___y_2907_);
lean_ctor_set(v___x_2930_, 2, v___y_2904_);
lean_ctor_set(v___x_2930_, 3, v___x_2929_);
lean_ctor_set(v___x_2930_, 4, v___y_2905_);
lean_ctor_set(v___x_2930_, 5, v___y_2899_);
lean_ctor_set(v___x_2930_, 6, v___y_2901_);
v_a_2619_ = v___x_2930_;
v_snd_2620_ = v___y_2902_;
goto v___jp_2618_;
}
else
{
lean_dec_ref_known(v___y_2900_, 1);
lean_dec(v___y_2907_);
lean_dec_ref(v___y_2905_);
lean_dec(v___y_2904_);
lean_dec_ref(v___y_2903_);
lean_dec(v___y_2901_);
lean_dec(v___y_2899_);
v_a_2619_ = v___y_2906_;
v_snd_2620_ = v___y_2902_;
goto v___jp_2618_;
}
}
}
v___jp_2931_:
{
uint64_t v___x_2944_; uint64_t v___x_2945_; uint64_t v___x_2946_; uint64_t v___x_2947_; 
v___x_2944_ = lean_uint8_to_uint64(v___y_2943_);
v___x_2945_ = 24ULL;
v___x_2946_ = lean_uint64_shift_left(v___x_2944_, v___x_2945_);
v___x_2947_ = lean_uint64_lor(v___y_2937_, v___x_2946_);
v___y_2899_ = v___y_2933_;
v___y_2900_ = v___y_2932_;
v___y_2901_ = v___y_2936_;
v___y_2902_ = v___y_2935_;
v___y_2903_ = v___y_2934_;
v___y_2904_ = v___y_2938_;
v___y_2905_ = v___y_2939_;
v___y_2906_ = v___y_2942_;
v___y_2907_ = v___y_2941_;
v___y_2908_ = v___y_2940_;
v___y_2909_ = v___x_2947_;
goto v___jp_2898_;
}
v___jp_2948_:
{
uint64_t v___x_2963_; uint64_t v___x_2964_; uint64_t v___x_2965_; uint64_t v___x_2966_; lean_object* v___x_2967_; lean_object* v___x_2968_; uint8_t v___x_2969_; 
v___x_2963_ = lean_uint8_to_uint64(v___y_2962_);
v___x_2964_ = 16ULL;
v___x_2965_ = lean_uint64_shift_left(v___x_2963_, v___x_2964_);
v___x_2966_ = lean_uint64_lor(v___y_2957_, v___x_2965_);
v___x_2967_ = lean_unsigned_to_nat(3u);
v___x_2968_ = lean_nat_add(v___y_2956_, v___x_2967_);
lean_dec(v___y_2956_);
v___x_2969_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_2606_, v___x_2968_);
if (v___x_2969_ == 0)
{
lean_object* v___x_2970_; lean_object* v___x_2971_; uint8_t v___x_2972_; 
lean_dec(v___x_2968_);
v___x_2970_ = lean_box(v___y_2952_);
v___x_2971_ = l_outOfBounds___redArg(v___x_2970_);
lean_dec(v___x_2970_);
v___x_2972_ = lean_unbox(v___x_2971_);
lean_dec(v___x_2971_);
v___y_2932_ = v___y_2949_;
v___y_2933_ = v___y_2954_;
v___y_2934_ = v___y_2950_;
v___y_2935_ = v___y_2951_;
v___y_2936_ = v___y_2955_;
v___y_2937_ = v___x_2966_;
v___y_2938_ = v___y_2953_;
v___y_2939_ = v___y_2958_;
v___y_2940_ = v___y_2959_;
v___y_2941_ = v___y_2960_;
v___y_2942_ = v___y_2961_;
v___y_2943_ = v___x_2972_;
goto v___jp_2931_;
}
else
{
uint8_t v___x_2973_; 
v___x_2973_ = lean_byte_array_fget(v___x_2606_, v___x_2968_);
lean_dec(v___x_2968_);
v___y_2932_ = v___y_2949_;
v___y_2933_ = v___y_2954_;
v___y_2934_ = v___y_2950_;
v___y_2935_ = v___y_2951_;
v___y_2936_ = v___y_2955_;
v___y_2937_ = v___x_2966_;
v___y_2938_ = v___y_2953_;
v___y_2939_ = v___y_2958_;
v___y_2940_ = v___y_2959_;
v___y_2941_ = v___y_2960_;
v___y_2942_ = v___y_2961_;
v___y_2943_ = v___x_2973_;
goto v___jp_2931_;
}
}
v___jp_2974_:
{
uint64_t v___x_2989_; uint64_t v___x_2990_; uint64_t v___x_2991_; uint64_t v___x_2992_; lean_object* v___x_2993_; lean_object* v___x_2994_; uint8_t v___x_2995_; 
v___x_2989_ = lean_uint8_to_uint64(v___y_2988_);
v___x_2990_ = 8ULL;
v___x_2991_ = lean_uint64_shift_left(v___x_2989_, v___x_2990_);
v___x_2992_ = lean_uint64_lor(v___y_2983_, v___x_2991_);
v___x_2993_ = lean_unsigned_to_nat(2u);
v___x_2994_ = lean_nat_add(v___y_2982_, v___x_2993_);
v___x_2995_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_2606_, v___x_2994_);
if (v___x_2995_ == 0)
{
lean_object* v___x_2996_; lean_object* v___x_2997_; uint8_t v___x_2998_; 
lean_dec(v___x_2994_);
v___x_2996_ = lean_box(v___y_2978_);
v___x_2997_ = l_outOfBounds___redArg(v___x_2996_);
lean_dec(v___x_2996_);
v___x_2998_ = lean_unbox(v___x_2997_);
lean_dec(v___x_2997_);
v___y_2949_ = v___y_2975_;
v___y_2950_ = v___y_2976_;
v___y_2951_ = v___y_2977_;
v___y_2952_ = v___y_2978_;
v___y_2953_ = v___y_2979_;
v___y_2954_ = v___y_2980_;
v___y_2955_ = v___y_2981_;
v___y_2956_ = v___y_2982_;
v___y_2957_ = v___x_2992_;
v___y_2958_ = v___y_2984_;
v___y_2959_ = v___y_2985_;
v___y_2960_ = v___y_2986_;
v___y_2961_ = v___y_2987_;
v___y_2962_ = v___x_2998_;
goto v___jp_2948_;
}
else
{
uint8_t v___x_2999_; 
v___x_2999_ = lean_byte_array_fget(v___x_2606_, v___x_2994_);
lean_dec(v___x_2994_);
v___y_2949_ = v___y_2975_;
v___y_2950_ = v___y_2976_;
v___y_2951_ = v___y_2977_;
v___y_2952_ = v___y_2978_;
v___y_2953_ = v___y_2979_;
v___y_2954_ = v___y_2980_;
v___y_2955_ = v___y_2981_;
v___y_2956_ = v___y_2982_;
v___y_2957_ = v___x_2992_;
v___y_2958_ = v___y_2984_;
v___y_2959_ = v___y_2985_;
v___y_2960_ = v___y_2986_;
v___y_2961_ = v___y_2987_;
v___y_2962_ = v___x_2999_;
goto v___jp_2948_;
}
}
v___jp_3000_:
{
uint64_t v_a_3014_; lean_object* v___x_3015_; uint8_t v___x_3016_; 
v_a_3014_ = lean_uint8_to_uint64(v___y_3013_);
v___x_3015_ = lean_nat_add(v___y_3003_, v___x_2635_);
v___x_3016_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_2606_, v___x_3015_);
if (v___x_3016_ == 0)
{
lean_object* v___x_3017_; lean_object* v___x_3018_; uint8_t v___x_3019_; 
lean_dec(v___x_3015_);
v___x_3017_ = lean_box(v___y_3007_);
v___x_3018_ = l_outOfBounds___redArg(v___x_3017_);
lean_dec(v___x_3017_);
v___x_3019_ = lean_unbox(v___x_3018_);
lean_dec(v___x_3018_);
v___y_2975_ = v___y_3002_;
v___y_2976_ = v___y_3006_;
v___y_2977_ = v___y_3005_;
v___y_2978_ = v___y_3007_;
v___y_2979_ = v___y_3008_;
v___y_2980_ = v___y_3001_;
v___y_2981_ = v___y_3004_;
v___y_2982_ = v___y_3003_;
v___y_2983_ = v_a_3014_;
v___y_2984_ = v___y_3009_;
v___y_2985_ = v___y_3012_;
v___y_2986_ = v___y_3011_;
v___y_2987_ = v___y_3010_;
v___y_2988_ = v___x_3019_;
goto v___jp_2974_;
}
else
{
uint8_t v___x_3020_; 
v___x_3020_ = lean_byte_array_fget(v___x_2606_, v___x_3015_);
lean_dec(v___x_3015_);
v___y_2975_ = v___y_3002_;
v___y_2976_ = v___y_3006_;
v___y_2977_ = v___y_3005_;
v___y_2978_ = v___y_3007_;
v___y_2979_ = v___y_3008_;
v___y_2980_ = v___y_3001_;
v___y_2981_ = v___y_3004_;
v___y_2982_ = v___y_3003_;
v___y_2983_ = v_a_3014_;
v___y_2984_ = v___y_3009_;
v___y_2985_ = v___y_3012_;
v___y_2986_ = v___y_3011_;
v___y_2987_ = v___y_3010_;
v___y_2988_ = v___x_3020_;
goto v___jp_2974_;
}
}
v___jp_3021_:
{
if (v___y_3034_ == 0)
{
uint8_t v___x_3035_; 
v___x_3035_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_2606_, v___y_3027_);
if (v___x_3035_ == 0)
{
lean_object* v___x_3036_; lean_object* v___x_3037_; uint8_t v___x_3038_; 
v___x_3036_ = lean_box(v___y_3028_);
v___x_3037_ = l_outOfBounds___redArg(v___x_3036_);
lean_dec(v___x_3036_);
v___x_3038_ = lean_unbox(v___x_3037_);
lean_dec(v___x_3037_);
v___y_3001_ = v___y_3023_;
v___y_3002_ = v___y_3022_;
v___y_3003_ = v___y_3027_;
v___y_3004_ = v___y_3026_;
v___y_3005_ = v___y_3025_;
v___y_3006_ = v___y_3024_;
v___y_3007_ = v___y_3028_;
v___y_3008_ = v___y_3029_;
v___y_3009_ = v___y_3030_;
v___y_3010_ = v___y_3033_;
v___y_3011_ = v___y_3032_;
v___y_3012_ = v___y_3031_;
v___y_3013_ = v___x_3038_;
goto v___jp_3000_;
}
else
{
uint8_t v___x_3039_; 
v___x_3039_ = lean_byte_array_fget(v___x_2606_, v___y_3027_);
v___y_3001_ = v___y_3023_;
v___y_3002_ = v___y_3022_;
v___y_3003_ = v___y_3027_;
v___y_3004_ = v___y_3026_;
v___y_3005_ = v___y_3025_;
v___y_3006_ = v___y_3024_;
v___y_3007_ = v___y_3028_;
v___y_3008_ = v___y_3029_;
v___y_3009_ = v___y_3030_;
v___y_3010_ = v___y_3033_;
v___y_3011_ = v___y_3032_;
v___y_3012_ = v___y_3031_;
v___y_3013_ = v___x_3039_;
goto v___jp_3000_;
}
}
else
{
size_t v_pos_3040_; uint8_t v___x_3041_; uint64_t v_a_3042_; size_t v___x_3043_; size_t v___x_3044_; uint8_t v___x_3045_; uint64_t v___x_3046_; uint64_t v___x_3047_; uint64_t v___x_3048_; uint64_t v___x_3049_; size_t v___x_3050_; size_t v___x_3051_; uint8_t v___x_3052_; uint64_t v___x_3053_; uint64_t v___x_3054_; uint64_t v___x_3055_; uint64_t v___x_3056_; size_t v___x_3057_; size_t v___x_3058_; uint8_t v___x_3059_; uint64_t v___x_3060_; uint64_t v___x_3061_; uint64_t v___x_3062_; uint64_t v___x_3063_; 
v_pos_3040_ = lean_usize_of_nat(v___y_3027_);
lean_dec(v___y_3027_);
v___x_3041_ = lean_byte_array_uget(v___x_2606_, v_pos_3040_);
v_a_3042_ = lean_uint8_to_uint64(v___x_3041_);
v___x_3043_ = ((size_t)1ULL);
v___x_3044_ = lean_usize_add(v_pos_3040_, v___x_3043_);
v___x_3045_ = lean_byte_array_uget(v___x_2606_, v___x_3044_);
v___x_3046_ = lean_uint8_to_uint64(v___x_3045_);
v___x_3047_ = 8ULL;
v___x_3048_ = lean_uint64_shift_left(v___x_3046_, v___x_3047_);
v___x_3049_ = lean_uint64_lor(v_a_3042_, v___x_3048_);
v___x_3050_ = ((size_t)2ULL);
v___x_3051_ = lean_usize_add(v_pos_3040_, v___x_3050_);
v___x_3052_ = lean_byte_array_uget(v___x_2606_, v___x_3051_);
v___x_3053_ = lean_uint8_to_uint64(v___x_3052_);
v___x_3054_ = 16ULL;
v___x_3055_ = lean_uint64_shift_left(v___x_3053_, v___x_3054_);
v___x_3056_ = lean_uint64_lor(v___x_3049_, v___x_3055_);
v___x_3057_ = ((size_t)3ULL);
v___x_3058_ = lean_usize_add(v_pos_3040_, v___x_3057_);
v___x_3059_ = lean_byte_array_uget(v___x_2606_, v___x_3058_);
v___x_3060_ = lean_uint8_to_uint64(v___x_3059_);
v___x_3061_ = 24ULL;
v___x_3062_ = lean_uint64_shift_left(v___x_3060_, v___x_3061_);
v___x_3063_ = lean_uint64_lor(v___x_3056_, v___x_3062_);
v___y_2899_ = v___y_3023_;
v___y_2900_ = v___y_3022_;
v___y_2901_ = v___y_3026_;
v___y_2902_ = v___y_3025_;
v___y_2903_ = v___y_3024_;
v___y_2904_ = v___y_3029_;
v___y_2905_ = v___y_3030_;
v___y_2906_ = v___y_3033_;
v___y_2907_ = v___y_3032_;
v___y_2908_ = v___y_3031_;
v___y_2909_ = v___x_3063_;
goto v___jp_2898_;
}
}
v___jp_3064_:
{
uint64_t v___x_3075_; uint8_t v___x_3076_; 
v___x_3075_ = 0ULL;
v___x_3076_ = lean_uint64_dec_eq(v___y_3074_, v___x_3075_);
if (v___x_3076_ == 0)
{
uint8_t v___x_3077_; lean_object* v___x_3078_; lean_object* v_offset_3079_; lean_object* v___x_3080_; lean_object* v___x_3081_; uint8_t v___x_3082_; 
v___x_3077_ = 0;
v___x_3078_ = lean_unsigned_to_nat(4u);
v_offset_3079_ = lean_nat_mul(v_i_2609_, v___x_3078_);
v___x_3080_ = lean_nat_add(v_offset_3079_, v___x_3078_);
v___x_3081_ = lean_byte_array_size(v___x_2606_);
v___x_3082_ = lean_nat_dec_le(v___x_3080_, v___x_3081_);
if (v___x_3082_ == 0)
{
lean_dec(v___x_3080_);
v___y_3022_ = v___y_3065_;
v___y_3023_ = v___y_3066_;
v___y_3024_ = v___y_3067_;
v___y_3025_ = v___y_3068_;
v___y_3026_ = v___y_3069_;
v___y_3027_ = v_offset_3079_;
v___y_3028_ = v___x_3077_;
v___y_3029_ = v___y_3070_;
v___y_3030_ = v___y_3071_;
v___y_3031_ = v___y_3074_;
v___y_3032_ = v___y_3072_;
v___y_3033_ = v___y_3073_;
v___y_3034_ = v___x_3082_;
goto v___jp_3021_;
}
else
{
size_t v___x_3083_; lean_object* v___x_3084_; uint8_t v___x_3085_; 
v___x_3083_ = lean_usize_of_nat(v___x_3080_);
v___x_3084_ = lean_usize_to_nat(v___x_3083_);
v___x_3085_ = lean_nat_dec_eq(v___x_3084_, v___x_3080_);
lean_dec(v___x_3080_);
lean_dec(v___x_3084_);
v___y_3022_ = v___y_3065_;
v___y_3023_ = v___y_3066_;
v___y_3024_ = v___y_3067_;
v___y_3025_ = v___y_3068_;
v___y_3026_ = v___y_3069_;
v___y_3027_ = v_offset_3079_;
v___y_3028_ = v___x_3077_;
v___y_3029_ = v___y_3070_;
v___y_3030_ = v___y_3071_;
v___y_3031_ = v___y_3074_;
v___y_3032_ = v___y_3072_;
v___y_3033_ = v___y_3073_;
v___y_3034_ = v___x_3085_;
goto v___jp_3021_;
}
}
else
{
lean_dec(v___y_3072_);
lean_dec_ref(v___y_3071_);
lean_dec(v___y_3070_);
lean_dec(v___y_3069_);
lean_dec_ref(v___y_3067_);
lean_dec(v___y_3066_);
lean_dec(v___y_3065_);
v_a_2619_ = v___y_3073_;
v_snd_2620_ = v___y_3068_;
goto v___jp_2618_;
}
}
v___jp_3086_:
{
uint64_t v___x_3098_; uint64_t v___x_3099_; uint64_t v___x_3100_; uint64_t v___x_3101_; 
v___x_3098_ = lean_uint8_to_uint64(v___y_3097_);
v___x_3099_ = 24ULL;
v___x_3100_ = lean_uint64_shift_left(v___x_3098_, v___x_3099_);
v___x_3101_ = lean_uint64_lor(v___y_3093_, v___x_3100_);
v___y_3065_ = v___y_3088_;
v___y_3066_ = v___y_3087_;
v___y_3067_ = v___y_3091_;
v___y_3068_ = v___y_3090_;
v___y_3069_ = v___y_3089_;
v___y_3070_ = v___y_3092_;
v___y_3071_ = v___y_3094_;
v___y_3072_ = v___y_3096_;
v___y_3073_ = v___y_3095_;
v___y_3074_ = v___x_3101_;
goto v___jp_3064_;
}
v___jp_3102_:
{
uint64_t v___x_3116_; uint64_t v___x_3117_; uint64_t v___x_3118_; uint64_t v___x_3119_; lean_object* v___x_3120_; lean_object* v___x_3121_; uint8_t v___x_3122_; 
v___x_3116_ = lean_uint8_to_uint64(v___y_3115_);
v___x_3117_ = 16ULL;
v___x_3118_ = lean_uint64_shift_left(v___x_3116_, v___x_3117_);
v___x_3119_ = lean_uint64_lor(v___y_3108_, v___x_3118_);
v___x_3120_ = lean_unsigned_to_nat(3u);
v___x_3121_ = lean_nat_add(v___y_3114_, v___x_3120_);
lean_dec(v___y_3114_);
v___x_3122_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3105_, v___x_3121_);
if (v___x_3122_ == 0)
{
lean_object* v___x_3123_; lean_object* v___x_3124_; uint8_t v___x_3125_; 
lean_dec(v___x_3121_);
v___x_3123_ = lean_box(v___y_3110_);
v___x_3124_ = l_outOfBounds___redArg(v___x_3123_);
lean_dec(v___x_3123_);
v___x_3125_ = lean_unbox(v___x_3124_);
lean_dec(v___x_3124_);
v___y_3087_ = v___y_3104_;
v___y_3088_ = v___y_3103_;
v___y_3089_ = v___y_3107_;
v___y_3090_ = v___y_3106_;
v___y_3091_ = v___y_3105_;
v___y_3092_ = v___y_3109_;
v___y_3093_ = v___x_3119_;
v___y_3094_ = v___y_3111_;
v___y_3095_ = v___y_3113_;
v___y_3096_ = v___y_3112_;
v___y_3097_ = v___x_3125_;
goto v___jp_3086_;
}
else
{
uint8_t v___x_3126_; 
v___x_3126_ = lean_byte_array_fget(v___y_3105_, v___x_3121_);
lean_dec(v___x_3121_);
v___y_3087_ = v___y_3104_;
v___y_3088_ = v___y_3103_;
v___y_3089_ = v___y_3107_;
v___y_3090_ = v___y_3106_;
v___y_3091_ = v___y_3105_;
v___y_3092_ = v___y_3109_;
v___y_3093_ = v___x_3119_;
v___y_3094_ = v___y_3111_;
v___y_3095_ = v___y_3113_;
v___y_3096_ = v___y_3112_;
v___y_3097_ = v___x_3126_;
goto v___jp_3086_;
}
}
v___jp_3127_:
{
uint64_t v___x_3141_; uint64_t v___x_3142_; uint64_t v___x_3143_; uint64_t v___x_3144_; lean_object* v___x_3145_; lean_object* v___x_3146_; uint8_t v___x_3147_; 
v___x_3141_ = lean_uint8_to_uint64(v___y_3140_);
v___x_3142_ = 8ULL;
v___x_3143_ = lean_uint64_shift_left(v___x_3141_, v___x_3142_);
v___x_3144_ = lean_uint64_lor(v___y_3133_, v___x_3143_);
v___x_3145_ = lean_unsigned_to_nat(2u);
v___x_3146_ = lean_nat_add(v___y_3139_, v___x_3145_);
v___x_3147_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3132_, v___x_3146_);
if (v___x_3147_ == 0)
{
lean_object* v___x_3148_; lean_object* v___x_3149_; uint8_t v___x_3150_; 
lean_dec(v___x_3146_);
v___x_3148_ = lean_box(v___y_3135_);
v___x_3149_ = l_outOfBounds___redArg(v___x_3148_);
lean_dec(v___x_3148_);
v___x_3150_ = lean_unbox(v___x_3149_);
lean_dec(v___x_3149_);
v___y_3103_ = v___y_3129_;
v___y_3104_ = v___y_3128_;
v___y_3105_ = v___y_3132_;
v___y_3106_ = v___y_3131_;
v___y_3107_ = v___y_3130_;
v___y_3108_ = v___x_3144_;
v___y_3109_ = v___y_3134_;
v___y_3110_ = v___y_3135_;
v___y_3111_ = v___y_3136_;
v___y_3112_ = v___y_3138_;
v___y_3113_ = v___y_3137_;
v___y_3114_ = v___y_3139_;
v___y_3115_ = v___x_3150_;
goto v___jp_3102_;
}
else
{
uint8_t v___x_3151_; 
v___x_3151_ = lean_byte_array_fget(v___y_3132_, v___x_3146_);
lean_dec(v___x_3146_);
v___y_3103_ = v___y_3129_;
v___y_3104_ = v___y_3128_;
v___y_3105_ = v___y_3132_;
v___y_3106_ = v___y_3131_;
v___y_3107_ = v___y_3130_;
v___y_3108_ = v___x_3144_;
v___y_3109_ = v___y_3134_;
v___y_3110_ = v___y_3135_;
v___y_3111_ = v___y_3136_;
v___y_3112_ = v___y_3138_;
v___y_3113_ = v___y_3137_;
v___y_3114_ = v___y_3139_;
v___y_3115_ = v___x_3151_;
goto v___jp_3102_;
}
}
v___jp_3152_:
{
uint64_t v___x_3164_; uint64_t v___x_3165_; uint64_t v___x_3166_; uint64_t v___x_3167_; 
v___x_3164_ = lean_uint8_to_uint64(v___y_3163_);
v___x_3165_ = 8ULL;
v___x_3166_ = lean_uint64_shift_left(v___x_3164_, v___x_3165_);
v___x_3167_ = lean_uint64_lor(v___y_3158_, v___x_3166_);
v___y_3065_ = v___y_3154_;
v___y_3066_ = v___y_3153_;
v___y_3067_ = v___y_3157_;
v___y_3068_ = v___y_3156_;
v___y_3069_ = v___y_3155_;
v___y_3070_ = v___y_3159_;
v___y_3071_ = v___y_3160_;
v___y_3072_ = v___y_3162_;
v___y_3073_ = v___y_3161_;
v___y_3074_ = v___x_3167_;
goto v___jp_3064_;
}
v___jp_3168_:
{
uint64_t v_a_3181_; 
v_a_3181_ = lean_uint8_to_uint64(v___y_3180_);
switch(v_width_2603_)
{
case 0:
{
lean_dec(v___y_3179_);
v___y_3065_ = v___y_3169_;
v___y_3066_ = v___y_3170_;
v___y_3067_ = v___y_3171_;
v___y_3068_ = v___y_3172_;
v___y_3069_ = v___y_3173_;
v___y_3070_ = v___y_3174_;
v___y_3071_ = v___y_3176_;
v___y_3072_ = v___y_3177_;
v___y_3073_ = v___y_3178_;
v___y_3074_ = v_a_3181_;
goto v___jp_3064_;
}
case 1:
{
lean_object* v___x_3182_; uint8_t v___x_3183_; 
v___x_3182_ = lean_nat_add(v___y_3179_, v___x_2635_);
lean_dec(v___y_3179_);
v___x_3183_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3171_, v___x_3182_);
if (v___x_3183_ == 0)
{
lean_object* v___x_3184_; lean_object* v___x_3185_; uint8_t v___x_3186_; 
lean_dec(v___x_3182_);
v___x_3184_ = lean_box(v___y_3175_);
v___x_3185_ = l_outOfBounds___redArg(v___x_3184_);
lean_dec(v___x_3184_);
v___x_3186_ = lean_unbox(v___x_3185_);
lean_dec(v___x_3185_);
v___y_3153_ = v___y_3170_;
v___y_3154_ = v___y_3169_;
v___y_3155_ = v___y_3173_;
v___y_3156_ = v___y_3172_;
v___y_3157_ = v___y_3171_;
v___y_3158_ = v_a_3181_;
v___y_3159_ = v___y_3174_;
v___y_3160_ = v___y_3176_;
v___y_3161_ = v___y_3178_;
v___y_3162_ = v___y_3177_;
v___y_3163_ = v___x_3186_;
goto v___jp_3152_;
}
else
{
uint8_t v___x_3187_; 
v___x_3187_ = lean_byte_array_fget(v___y_3171_, v___x_3182_);
lean_dec(v___x_3182_);
v___y_3153_ = v___y_3170_;
v___y_3154_ = v___y_3169_;
v___y_3155_ = v___y_3173_;
v___y_3156_ = v___y_3172_;
v___y_3157_ = v___y_3171_;
v___y_3158_ = v_a_3181_;
v___y_3159_ = v___y_3174_;
v___y_3160_ = v___y_3176_;
v___y_3161_ = v___y_3178_;
v___y_3162_ = v___y_3177_;
v___y_3163_ = v___x_3187_;
goto v___jp_3152_;
}
}
default: 
{
lean_object* v___x_3188_; uint8_t v___x_3189_; 
v___x_3188_ = lean_nat_add(v___y_3179_, v___x_2635_);
v___x_3189_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3171_, v___x_3188_);
if (v___x_3189_ == 0)
{
lean_object* v___x_3190_; lean_object* v___x_3191_; uint8_t v___x_3192_; 
lean_dec(v___x_3188_);
v___x_3190_ = lean_box(v___y_3175_);
v___x_3191_ = l_outOfBounds___redArg(v___x_3190_);
lean_dec(v___x_3190_);
v___x_3192_ = lean_unbox(v___x_3191_);
lean_dec(v___x_3191_);
v___y_3128_ = v___y_3170_;
v___y_3129_ = v___y_3169_;
v___y_3130_ = v___y_3173_;
v___y_3131_ = v___y_3172_;
v___y_3132_ = v___y_3171_;
v___y_3133_ = v_a_3181_;
v___y_3134_ = v___y_3174_;
v___y_3135_ = v___y_3175_;
v___y_3136_ = v___y_3176_;
v___y_3137_ = v___y_3178_;
v___y_3138_ = v___y_3177_;
v___y_3139_ = v___y_3179_;
v___y_3140_ = v___x_3192_;
goto v___jp_3127_;
}
else
{
uint8_t v___x_3193_; 
v___x_3193_ = lean_byte_array_fget(v___y_3171_, v___x_3188_);
lean_dec(v___x_3188_);
v___y_3128_ = v___y_3170_;
v___y_3129_ = v___y_3169_;
v___y_3130_ = v___y_3173_;
v___y_3131_ = v___y_3172_;
v___y_3132_ = v___y_3171_;
v___y_3133_ = v_a_3181_;
v___y_3134_ = v___y_3174_;
v___y_3135_ = v___y_3175_;
v___y_3136_ = v___y_3176_;
v___y_3137_ = v___y_3178_;
v___y_3138_ = v___y_3177_;
v___y_3139_ = v___y_3179_;
v___y_3140_ = v___x_3193_;
goto v___jp_3127_;
}
}
}
}
v___jp_3194_:
{
if (v___y_3206_ == 0)
{
uint8_t v___x_3207_; 
v___x_3207_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3199_, v___y_3205_);
if (v___x_3207_ == 0)
{
lean_object* v___x_3208_; lean_object* v___x_3209_; uint8_t v___x_3210_; 
v___x_3208_ = lean_box(v___y_3201_);
v___x_3209_ = l_outOfBounds___redArg(v___x_3208_);
lean_dec(v___x_3208_);
v___x_3210_ = lean_unbox(v___x_3209_);
lean_dec(v___x_3209_);
v___y_3169_ = v___y_3196_;
v___y_3170_ = v___y_3195_;
v___y_3171_ = v___y_3199_;
v___y_3172_ = v___y_3198_;
v___y_3173_ = v___y_3197_;
v___y_3174_ = v___y_3200_;
v___y_3175_ = v___y_3201_;
v___y_3176_ = v___y_3202_;
v___y_3177_ = v___y_3204_;
v___y_3178_ = v___y_3203_;
v___y_3179_ = v___y_3205_;
v___y_3180_ = v___x_3210_;
goto v___jp_3168_;
}
else
{
uint8_t v___x_3211_; 
v___x_3211_ = lean_byte_array_fget(v___y_3199_, v___y_3205_);
v___y_3169_ = v___y_3196_;
v___y_3170_ = v___y_3195_;
v___y_3171_ = v___y_3199_;
v___y_3172_ = v___y_3198_;
v___y_3173_ = v___y_3197_;
v___y_3174_ = v___y_3200_;
v___y_3175_ = v___y_3201_;
v___y_3176_ = v___y_3202_;
v___y_3177_ = v___y_3204_;
v___y_3178_ = v___y_3203_;
v___y_3179_ = v___y_3205_;
v___y_3180_ = v___x_3211_;
goto v___jp_3168_;
}
}
else
{
size_t v_pos_3212_; uint8_t v___x_3213_; uint64_t v_a_3214_; 
v_pos_3212_ = lean_usize_of_nat(v___y_3205_);
lean_dec(v___y_3205_);
v___x_3213_ = lean_byte_array_uget(v___y_3199_, v_pos_3212_);
v_a_3214_ = lean_uint8_to_uint64(v___x_3213_);
switch(v_width_2603_)
{
case 0:
{
v___y_3065_ = v___y_3196_;
v___y_3066_ = v___y_3195_;
v___y_3067_ = v___y_3199_;
v___y_3068_ = v___y_3198_;
v___y_3069_ = v___y_3197_;
v___y_3070_ = v___y_3200_;
v___y_3071_ = v___y_3202_;
v___y_3072_ = v___y_3204_;
v___y_3073_ = v___y_3203_;
v___y_3074_ = v_a_3214_;
goto v___jp_3064_;
}
case 1:
{
size_t v___x_3215_; size_t v___x_3216_; uint8_t v___x_3217_; uint64_t v___x_3218_; uint64_t v___x_3219_; uint64_t v___x_3220_; uint64_t v___x_3221_; 
v___x_3215_ = ((size_t)1ULL);
v___x_3216_ = lean_usize_add(v_pos_3212_, v___x_3215_);
v___x_3217_ = lean_byte_array_uget(v___y_3199_, v___x_3216_);
v___x_3218_ = lean_uint8_to_uint64(v___x_3217_);
v___x_3219_ = 8ULL;
v___x_3220_ = lean_uint64_shift_left(v___x_3218_, v___x_3219_);
v___x_3221_ = lean_uint64_lor(v_a_3214_, v___x_3220_);
v___y_3065_ = v___y_3196_;
v___y_3066_ = v___y_3195_;
v___y_3067_ = v___y_3199_;
v___y_3068_ = v___y_3198_;
v___y_3069_ = v___y_3197_;
v___y_3070_ = v___y_3200_;
v___y_3071_ = v___y_3202_;
v___y_3072_ = v___y_3204_;
v___y_3073_ = v___y_3203_;
v___y_3074_ = v___x_3221_;
goto v___jp_3064_;
}
default: 
{
size_t v___x_3222_; size_t v___x_3223_; uint8_t v___x_3224_; uint64_t v___x_3225_; uint64_t v___x_3226_; uint64_t v___x_3227_; uint64_t v___x_3228_; size_t v___x_3229_; size_t v___x_3230_; uint8_t v___x_3231_; uint64_t v___x_3232_; uint64_t v___x_3233_; uint64_t v___x_3234_; uint64_t v___x_3235_; size_t v___x_3236_; size_t v___x_3237_; uint8_t v___x_3238_; uint64_t v___x_3239_; uint64_t v___x_3240_; uint64_t v___x_3241_; uint64_t v___x_3242_; 
v___x_3222_ = ((size_t)1ULL);
v___x_3223_ = lean_usize_add(v_pos_3212_, v___x_3222_);
v___x_3224_ = lean_byte_array_uget(v___y_3199_, v___x_3223_);
v___x_3225_ = lean_uint8_to_uint64(v___x_3224_);
v___x_3226_ = 8ULL;
v___x_3227_ = lean_uint64_shift_left(v___x_3225_, v___x_3226_);
v___x_3228_ = lean_uint64_lor(v_a_3214_, v___x_3227_);
v___x_3229_ = ((size_t)2ULL);
v___x_3230_ = lean_usize_add(v_pos_3212_, v___x_3229_);
v___x_3231_ = lean_byte_array_uget(v___y_3199_, v___x_3230_);
v___x_3232_ = lean_uint8_to_uint64(v___x_3231_);
v___x_3233_ = 16ULL;
v___x_3234_ = lean_uint64_shift_left(v___x_3232_, v___x_3233_);
v___x_3235_ = lean_uint64_lor(v___x_3228_, v___x_3234_);
v___x_3236_ = ((size_t)3ULL);
v___x_3237_ = lean_usize_add(v_pos_3212_, v___x_3236_);
v___x_3238_ = lean_byte_array_uget(v___y_3199_, v___x_3237_);
v___x_3239_ = lean_uint8_to_uint64(v___x_3238_);
v___x_3240_ = 24ULL;
v___x_3241_ = lean_uint64_shift_left(v___x_3239_, v___x_3240_);
v___x_3242_ = lean_uint64_lor(v___x_3235_, v___x_3241_);
v___y_3065_ = v___y_3196_;
v___y_3066_ = v___y_3195_;
v___y_3067_ = v___y_3199_;
v___y_3068_ = v___y_3198_;
v___y_3069_ = v___y_3197_;
v___y_3070_ = v___y_3200_;
v___y_3071_ = v___y_3202_;
v___y_3072_ = v___y_3204_;
v___y_3073_ = v___y_3203_;
v___y_3074_ = v___x_3242_;
goto v___jp_3064_;
}
}
}
}
v___jp_3243_:
{
lean_object* v_offset_3255_; lean_object* v___x_3256_; lean_object* v___x_3257_; uint8_t v___x_3258_; 
v_offset_3255_ = lean_nat_mul(v_i_2609_, v___y_3254_);
v___x_3256_ = lean_nat_add(v_offset_3255_, v___y_3254_);
v___x_3257_ = lean_byte_array_size(v___y_3248_);
v___x_3258_ = lean_nat_dec_le(v___x_3256_, v___x_3257_);
if (v___x_3258_ == 0)
{
lean_dec(v___x_3256_);
v___y_3195_ = v___y_3244_;
v___y_3196_ = v___y_3245_;
v___y_3197_ = v___y_3246_;
v___y_3198_ = v___y_3247_;
v___y_3199_ = v___y_3248_;
v___y_3200_ = v___y_3249_;
v___y_3201_ = v___y_3250_;
v___y_3202_ = v___y_3251_;
v___y_3203_ = v___y_3252_;
v___y_3204_ = v___y_3253_;
v___y_3205_ = v_offset_3255_;
v___y_3206_ = v___x_3258_;
goto v___jp_3194_;
}
else
{
size_t v___x_3259_; lean_object* v___x_3260_; uint8_t v___x_3261_; 
v___x_3259_ = lean_usize_of_nat(v___x_3256_);
v___x_3260_ = lean_usize_to_nat(v___x_3259_);
v___x_3261_ = lean_nat_dec_eq(v___x_3260_, v___x_3256_);
lean_dec(v___x_3256_);
lean_dec(v___x_3260_);
v___y_3195_ = v___y_3244_;
v___y_3196_ = v___y_3245_;
v___y_3197_ = v___y_3246_;
v___y_3198_ = v___y_3247_;
v___y_3199_ = v___y_3248_;
v___y_3200_ = v___y_3249_;
v___y_3201_ = v___y_3250_;
v___y_3202_ = v___y_3251_;
v___y_3203_ = v___y_3252_;
v___y_3204_ = v___y_3253_;
v___y_3205_ = v_offset_3255_;
v___y_3206_ = v___x_3261_;
goto v___jp_3194_;
}
}
v___jp_3262_:
{
uint8_t v___x_3272_; 
v___x_3272_ = 0;
switch(v_width_2603_)
{
case 0:
{
v___y_3244_ = v_node_3269_;
v___y_3245_ = v_leading_3267_;
v___y_3246_ = v_sugar_3270_;
v___y_3247_ = v___y_3271_;
v___y_3248_ = v_dense_3264_;
v___y_3249_ = v_chargedUntil_3266_;
v___y_3250_ = v___x_3272_;
v___y_3251_ = v_trace_3268_;
v___y_3252_ = v_scan_3263_;
v___y_3253_ = v_last_3265_;
v___y_3254_ = v___x_2635_;
goto v___jp_3243_;
}
case 1:
{
lean_object* v___x_3273_; 
v___x_3273_ = lean_unsigned_to_nat(2u);
v___y_3244_ = v_node_3269_;
v___y_3245_ = v_leading_3267_;
v___y_3246_ = v_sugar_3270_;
v___y_3247_ = v___y_3271_;
v___y_3248_ = v_dense_3264_;
v___y_3249_ = v_chargedUntil_3266_;
v___y_3250_ = v___x_3272_;
v___y_3251_ = v_trace_3268_;
v___y_3252_ = v_scan_3263_;
v___y_3253_ = v_last_3265_;
v___y_3254_ = v___x_3273_;
goto v___jp_3243_;
}
default: 
{
lean_object* v___x_3274_; 
v___x_3274_ = lean_unsigned_to_nat(4u);
v___y_3244_ = v_node_3269_;
v___y_3245_ = v_leading_3267_;
v___y_3246_ = v_sugar_3270_;
v___y_3247_ = v___y_3271_;
v___y_3248_ = v_dense_3264_;
v___y_3249_ = v_chargedUntil_3266_;
v___y_3250_ = v___x_3272_;
v___y_3251_ = v_trace_3268_;
v___y_3252_ = v_scan_3263_;
v___y_3253_ = v_last_3265_;
v___y_3254_ = v___x_3274_;
goto v___jp_3243_;
}
}
}
v___jp_3275_:
{
lean_object* v___x_3277_; lean_object* v___x_3278_; lean_object* v_fst_3279_; 
v___x_3277_ = lean_nat_sub(v___y_3276_, v_i_2609_);
v___x_3278_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_2604_, v___x_3277_, v___y_2610_);
lean_dec(v___x_3277_);
v_fst_3279_ = lean_ctor_get(v___x_3278_, 0);
lean_inc(v_fst_3279_);
if (lean_obj_tag(v_fst_3279_) == 0)
{
lean_object* v_snd_3280_; lean_object* v_a_3281_; 
lean_dec(v___y_3276_);
lean_dec(v_sugar_2632_);
lean_dec(v_node_2631_);
lean_dec_ref(v_trace_2630_);
lean_dec(v_leading_2629_);
lean_dec(v_last_2627_);
lean_dec_ref(v_dense_2626_);
lean_dec(v_i_2609_);
v_snd_3280_ = lean_ctor_get(v___x_3278_, 1);
lean_inc(v_snd_3280_);
lean_dec_ref(v___x_3278_);
v_a_3281_ = lean_ctor_get(v_fst_3279_, 0);
lean_inc(v_a_3281_);
lean_dec_ref_known(v_fst_3279_, 1);
v_a_2612_ = v_a_3281_;
v_snd_2613_ = v_snd_3280_;
goto v___jp_2611_;
}
else
{
lean_object* v_snd_3282_; lean_object* v___x_3283_; 
lean_dec_ref_known(v_fst_3279_, 1);
v_snd_3282_ = lean_ctor_get(v___x_3278_, 1);
lean_inc(v_snd_3282_);
lean_dec_ref(v___x_3278_);
lean_inc(v_sugar_2632_);
lean_inc(v_node_2631_);
lean_inc_ref(v_trace_2630_);
lean_inc(v_leading_2629_);
lean_inc(v___y_3276_);
lean_inc(v_last_2627_);
lean_inc_ref(v_dense_2626_);
v___x_3283_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_3283_, 0, v_dense_2626_);
lean_ctor_set(v___x_3283_, 1, v_last_2627_);
lean_ctor_set(v___x_3283_, 2, v___y_3276_);
lean_ctor_set(v___x_3283_, 3, v_leading_2629_);
lean_ctor_set(v___x_3283_, 4, v_trace_2630_);
lean_ctor_set(v___x_3283_, 5, v_node_2631_);
lean_ctor_set(v___x_3283_, 6, v_sugar_2632_);
v_scan_3263_ = v___x_3283_;
v_dense_3264_ = v_dense_2626_;
v_last_3265_ = v_last_2627_;
v_chargedUntil_3266_ = v___y_3276_;
v_leading_3267_ = v_leading_2629_;
v_trace_3268_ = v_trace_2630_;
v_node_3269_ = v_node_2631_;
v_sugar_3270_ = v_sugar_2632_;
v___y_3271_ = v_snd_3282_;
goto v___jp_3262_;
}
}
}
else
{
lean_object* v___x_3289_; lean_object* v___x_3290_; 
lean_dec(v_i_2609_);
v___x_3289_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3289_, 0, v_b_2608_);
v___x_3290_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3290_, 0, v___x_3289_);
lean_ctor_set(v___x_3290_, 1, v___y_2610_);
return v___x_3290_;
}
}
v___jp_2611_:
{
lean_object* v___x_2614_; lean_object* v___x_2615_; 
v___x_2614_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2614_, 0, v_a_2612_);
v___x_2615_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2615_, 0, v___x_2614_);
lean_ctor_set(v___x_2615_, 1, v_snd_2613_);
return v___x_2615_;
}
v___jp_2618_:
{
lean_object* v___x_2621_; lean_object* v___x_2622_; 
v___x_2621_ = lean_nat_add(v_i_2609_, v_step_2617_);
lean_dec(v_i_2609_);
v___x_2622_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5___redArg(v___x_2600_, v_limits_2604_, v_field_2601_, v_ctx_2602_, v_width_2603_, v_provenance_2605_, v___x_2606_, v_range_2607_, v_a_2619_, v___x_2621_, v_snd_2620_);
return v___x_2622_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___redArg___boxed(lean_object* v___x_3291_, lean_object* v_field_3292_, lean_object* v_ctx_3293_, lean_object* v_width_3294_, lean_object* v_limits_3295_, lean_object* v_provenance_3296_, lean_object* v___x_3297_, lean_object* v_range_3298_, lean_object* v_b_3299_, lean_object* v_i_3300_, lean_object* v___y_3301_){
_start:
{
uint64_t v_field_boxed_3302_; uint64_t v_ctx_boxed_3303_; uint8_t v_width_boxed_3304_; uint8_t v_provenance_boxed_3305_; lean_object* v_res_3306_; 
v_field_boxed_3302_ = lean_unbox_uint64(v_field_3292_);
lean_dec_ref(v_field_3292_);
v_ctx_boxed_3303_ = lean_unbox_uint64(v_ctx_3293_);
lean_dec_ref(v_ctx_3293_);
v_width_boxed_3304_ = lean_unbox(v_width_3294_);
v_provenance_boxed_3305_ = lean_unbox(v_provenance_3296_);
v_res_3306_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___redArg(v___x_3291_, v_field_boxed_3302_, v_ctx_boxed_3303_, v_width_boxed_3304_, v_limits_3295_, v_provenance_boxed_3305_, v___x_3297_, v_range_3298_, v_b_3299_, v_i_3300_, v___y_3301_);
lean_dec_ref(v_range_3298_);
lean_dec_ref(v___x_3297_);
lean_dec_ref(v_limits_3295_);
lean_dec_ref(v___x_3291_);
return v_res_3306_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___redArg(uint8_t v_width_3307_, lean_object* v___y_3308_, lean_object* v___x_3309_, lean_object* v_range_3310_, lean_object* v_b_3311_, lean_object* v_i_3312_, lean_object* v___y_3313_){
_start:
{
lean_object* v_stop_3314_; lean_object* v_step_3315_; lean_object* v_a_3317_; lean_object* v_snd_3318_; uint64_t v___y_3322_; lean_object* v___y_3323_; lean_object* v___y_3324_; lean_object* v___y_3353_; uint64_t v___y_3354_; lean_object* v___y_3359_; uint64_t v___y_3360_; uint8_t v___y_3361_; lean_object* v___y_3367_; uint64_t v___y_3368_; uint8_t v___y_3369_; uint8_t v___x_3374_; 
v_stop_3314_ = lean_ctor_get(v_range_3310_, 1);
v_step_3315_ = lean_ctor_get(v_range_3310_, 2);
v___x_3374_ = lean_nat_dec_lt(v_i_3312_, v_stop_3314_);
if (v___x_3374_ == 0)
{
lean_object* v___x_3375_; lean_object* v___x_3376_; 
lean_dec(v_i_3312_);
v___x_3375_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3375_, 0, v_b_3311_);
v___x_3376_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3376_, 0, v___x_3375_);
lean_ctor_set(v___x_3376_, 1, v___y_3313_);
return v___x_3376_;
}
else
{
uint8_t v___y_3378_; lean_object* v___y_3379_; lean_object* v___y_3380_; lean_object* v___y_3381_; uint64_t v___y_3382_; uint8_t v___y_3383_; lean_object* v___y_3396_; uint8_t v___y_3397_; lean_object* v___y_3398_; lean_object* v___y_3399_; uint64_t v___y_3400_; uint8_t v___y_3401_; uint8_t v___y_3414_; lean_object* v___y_3415_; lean_object* v___y_3416_; lean_object* v___y_3417_; uint8_t v___y_3418_; uint8_t v___y_3435_; lean_object* v___y_3436_; lean_object* v___y_3437_; lean_object* v___y_3438_; uint8_t v___y_3439_; uint8_t v___y_3477_; lean_object* v___y_3478_; lean_object* v___y_3479_; lean_object* v___y_3480_; uint64_t v___y_3489_; uint64_t v___y_3497_; uint8_t v___y_3498_; uint8_t v___x_3503_; lean_object* v___x_3504_; lean_object* v_offset_3505_; uint64_t v___y_3507_; uint8_t v___y_3508_; uint64_t v___y_3521_; uint8_t v___y_3522_; uint8_t v___y_3535_; uint8_t v___y_3545_; lean_object* v___x_3575_; lean_object* v___x_3576_; uint8_t v___x_3577_; 
v___x_3503_ = 0;
v___x_3504_ = lean_unsigned_to_nat(4u);
v_offset_3505_ = lean_nat_mul(v_i_3312_, v___x_3504_);
v___x_3575_ = lean_nat_add(v_offset_3505_, v___x_3504_);
v___x_3576_ = lean_byte_array_size(v___x_3309_);
v___x_3577_ = lean_nat_dec_le(v___x_3575_, v___x_3576_);
if (v___x_3577_ == 0)
{
lean_dec(v___x_3575_);
v___y_3545_ = v___x_3577_;
goto v___jp_3544_;
}
else
{
size_t v___x_3578_; lean_object* v___x_3579_; uint8_t v___x_3580_; 
v___x_3578_ = lean_usize_of_nat(v___x_3575_);
v___x_3579_ = lean_usize_to_nat(v___x_3578_);
v___x_3580_ = lean_nat_dec_eq(v___x_3579_, v___x_3575_);
lean_dec(v___x_3575_);
lean_dec(v___x_3579_);
v___y_3545_ = v___x_3580_;
goto v___jp_3544_;
}
v___jp_3377_:
{
uint64_t v___x_3384_; uint64_t v___x_3385_; uint64_t v___x_3386_; uint64_t v___x_3387_; lean_object* v___x_3388_; lean_object* v___x_3389_; uint8_t v___x_3390_; 
v___x_3384_ = lean_uint8_to_uint64(v___y_3383_);
v___x_3385_ = 16ULL;
v___x_3386_ = lean_uint64_shift_left(v___x_3384_, v___x_3385_);
v___x_3387_ = lean_uint64_lor(v___y_3382_, v___x_3386_);
v___x_3388_ = lean_unsigned_to_nat(3u);
v___x_3389_ = lean_nat_add(v___y_3379_, v___x_3388_);
lean_dec(v___y_3379_);
v___x_3390_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3381_, v___x_3389_);
if (v___x_3390_ == 0)
{
lean_object* v___x_3391_; lean_object* v___x_3392_; uint8_t v___x_3393_; 
lean_dec(v___x_3389_);
v___x_3391_ = lean_box(v___y_3378_);
v___x_3392_ = l_outOfBounds___redArg(v___x_3391_);
lean_dec(v___x_3391_);
v___x_3393_ = lean_unbox(v___x_3392_);
lean_dec(v___x_3392_);
v___y_3359_ = v___y_3380_;
v___y_3360_ = v___x_3387_;
v___y_3361_ = v___x_3393_;
goto v___jp_3358_;
}
else
{
uint8_t v___x_3394_; 
v___x_3394_ = lean_byte_array_fget(v___y_3381_, v___x_3389_);
lean_dec(v___x_3389_);
v___y_3359_ = v___y_3380_;
v___y_3360_ = v___x_3387_;
v___y_3361_ = v___x_3394_;
goto v___jp_3358_;
}
}
v___jp_3395_:
{
uint64_t v___x_3402_; uint64_t v___x_3403_; uint64_t v___x_3404_; uint64_t v___x_3405_; lean_object* v___x_3406_; lean_object* v___x_3407_; uint8_t v___x_3408_; 
v___x_3402_ = lean_uint8_to_uint64(v___y_3401_);
v___x_3403_ = 8ULL;
v___x_3404_ = lean_uint64_shift_left(v___x_3402_, v___x_3403_);
v___x_3405_ = lean_uint64_lor(v___y_3400_, v___x_3404_);
v___x_3406_ = lean_unsigned_to_nat(2u);
v___x_3407_ = lean_nat_add(v___y_3396_, v___x_3406_);
v___x_3408_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3399_, v___x_3407_);
if (v___x_3408_ == 0)
{
lean_object* v___x_3409_; lean_object* v___x_3410_; uint8_t v___x_3411_; 
lean_dec(v___x_3407_);
v___x_3409_ = lean_box(v___y_3397_);
v___x_3410_ = l_outOfBounds___redArg(v___x_3409_);
lean_dec(v___x_3409_);
v___x_3411_ = lean_unbox(v___x_3410_);
lean_dec(v___x_3410_);
v___y_3378_ = v___y_3397_;
v___y_3379_ = v___y_3396_;
v___y_3380_ = v___y_3398_;
v___y_3381_ = v___y_3399_;
v___y_3382_ = v___x_3405_;
v___y_3383_ = v___x_3411_;
goto v___jp_3377_;
}
else
{
uint8_t v___x_3412_; 
v___x_3412_ = lean_byte_array_fget(v___y_3399_, v___x_3407_);
lean_dec(v___x_3407_);
v___y_3378_ = v___y_3397_;
v___y_3379_ = v___y_3396_;
v___y_3380_ = v___y_3398_;
v___y_3381_ = v___y_3399_;
v___y_3382_ = v___x_3405_;
v___y_3383_ = v___x_3412_;
goto v___jp_3377_;
}
}
v___jp_3413_:
{
uint64_t v_a_3419_; 
v_a_3419_ = lean_uint8_to_uint64(v___y_3418_);
switch(v_width_3307_)
{
case 0:
{
lean_dec(v___y_3415_);
v___y_3353_ = v___y_3416_;
v___y_3354_ = v_a_3419_;
goto v___jp_3352_;
}
case 1:
{
lean_object* v___x_3420_; lean_object* v___x_3421_; uint8_t v___x_3422_; 
v___x_3420_ = lean_unsigned_to_nat(1u);
v___x_3421_ = lean_nat_add(v___y_3415_, v___x_3420_);
lean_dec(v___y_3415_);
v___x_3422_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3417_, v___x_3421_);
if (v___x_3422_ == 0)
{
lean_object* v___x_3423_; lean_object* v___x_3424_; uint8_t v___x_3425_; 
lean_dec(v___x_3421_);
v___x_3423_ = lean_box(v___y_3414_);
v___x_3424_ = l_outOfBounds___redArg(v___x_3423_);
lean_dec(v___x_3423_);
v___x_3425_ = lean_unbox(v___x_3424_);
lean_dec(v___x_3424_);
v___y_3367_ = v___y_3416_;
v___y_3368_ = v_a_3419_;
v___y_3369_ = v___x_3425_;
goto v___jp_3366_;
}
else
{
uint8_t v___x_3426_; 
v___x_3426_ = lean_byte_array_fget(v___y_3417_, v___x_3421_);
lean_dec(v___x_3421_);
v___y_3367_ = v___y_3416_;
v___y_3368_ = v_a_3419_;
v___y_3369_ = v___x_3426_;
goto v___jp_3366_;
}
}
default: 
{
lean_object* v___x_3427_; lean_object* v___x_3428_; uint8_t v___x_3429_; 
v___x_3427_ = lean_unsigned_to_nat(1u);
v___x_3428_ = lean_nat_add(v___y_3415_, v___x_3427_);
v___x_3429_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3417_, v___x_3428_);
if (v___x_3429_ == 0)
{
lean_object* v___x_3430_; lean_object* v___x_3431_; uint8_t v___x_3432_; 
lean_dec(v___x_3428_);
v___x_3430_ = lean_box(v___y_3414_);
v___x_3431_ = l_outOfBounds___redArg(v___x_3430_);
lean_dec(v___x_3430_);
v___x_3432_ = lean_unbox(v___x_3431_);
lean_dec(v___x_3431_);
v___y_3396_ = v___y_3415_;
v___y_3397_ = v___y_3414_;
v___y_3398_ = v___y_3416_;
v___y_3399_ = v___y_3417_;
v___y_3400_ = v_a_3419_;
v___y_3401_ = v___x_3432_;
goto v___jp_3395_;
}
else
{
uint8_t v___x_3433_; 
v___x_3433_ = lean_byte_array_fget(v___y_3417_, v___x_3428_);
lean_dec(v___x_3428_);
v___y_3396_ = v___y_3415_;
v___y_3397_ = v___y_3414_;
v___y_3398_ = v___y_3416_;
v___y_3399_ = v___y_3417_;
v___y_3400_ = v_a_3419_;
v___y_3401_ = v___x_3433_;
goto v___jp_3395_;
}
}
}
}
v___jp_3434_:
{
if (v___y_3439_ == 0)
{
uint8_t v___x_3440_; 
v___x_3440_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3438_, v___y_3436_);
if (v___x_3440_ == 0)
{
lean_object* v___x_3441_; lean_object* v___x_3442_; uint8_t v___x_3443_; 
v___x_3441_ = lean_box(v___y_3435_);
v___x_3442_ = l_outOfBounds___redArg(v___x_3441_);
lean_dec(v___x_3441_);
v___x_3443_ = lean_unbox(v___x_3442_);
lean_dec(v___x_3442_);
v___y_3414_ = v___y_3435_;
v___y_3415_ = v___y_3436_;
v___y_3416_ = v___y_3437_;
v___y_3417_ = v___y_3438_;
v___y_3418_ = v___x_3443_;
goto v___jp_3413_;
}
else
{
uint8_t v___x_3444_; 
v___x_3444_ = lean_byte_array_fget(v___y_3438_, v___y_3436_);
v___y_3414_ = v___y_3435_;
v___y_3415_ = v___y_3436_;
v___y_3416_ = v___y_3437_;
v___y_3417_ = v___y_3438_;
v___y_3418_ = v___x_3444_;
goto v___jp_3413_;
}
}
else
{
size_t v_pos_3445_; uint8_t v___x_3446_; uint64_t v_a_3447_; 
v_pos_3445_ = lean_usize_of_nat(v___y_3436_);
lean_dec(v___y_3436_);
v___x_3446_ = lean_byte_array_uget(v___y_3438_, v_pos_3445_);
v_a_3447_ = lean_uint8_to_uint64(v___x_3446_);
switch(v_width_3307_)
{
case 0:
{
v___y_3353_ = v___y_3437_;
v___y_3354_ = v_a_3447_;
goto v___jp_3352_;
}
case 1:
{
size_t v___x_3448_; size_t v___x_3449_; uint8_t v___x_3450_; uint64_t v___x_3451_; uint64_t v___x_3452_; uint64_t v___x_3453_; uint64_t v___x_3454_; 
v___x_3448_ = ((size_t)1ULL);
v___x_3449_ = lean_usize_add(v_pos_3445_, v___x_3448_);
v___x_3450_ = lean_byte_array_uget(v___y_3438_, v___x_3449_);
v___x_3451_ = lean_uint8_to_uint64(v___x_3450_);
v___x_3452_ = 8ULL;
v___x_3453_ = lean_uint64_shift_left(v___x_3451_, v___x_3452_);
v___x_3454_ = lean_uint64_lor(v_a_3447_, v___x_3453_);
v___y_3353_ = v___y_3437_;
v___y_3354_ = v___x_3454_;
goto v___jp_3352_;
}
default: 
{
size_t v___x_3455_; size_t v___x_3456_; uint8_t v___x_3457_; uint64_t v___x_3458_; uint64_t v___x_3459_; uint64_t v___x_3460_; uint64_t v___x_3461_; size_t v___x_3462_; size_t v___x_3463_; uint8_t v___x_3464_; uint64_t v___x_3465_; uint64_t v___x_3466_; uint64_t v___x_3467_; uint64_t v___x_3468_; size_t v___x_3469_; size_t v___x_3470_; uint8_t v___x_3471_; uint64_t v___x_3472_; uint64_t v___x_3473_; uint64_t v___x_3474_; uint64_t v___x_3475_; 
v___x_3455_ = ((size_t)1ULL);
v___x_3456_ = lean_usize_add(v_pos_3445_, v___x_3455_);
v___x_3457_ = lean_byte_array_uget(v___y_3438_, v___x_3456_);
v___x_3458_ = lean_uint8_to_uint64(v___x_3457_);
v___x_3459_ = 8ULL;
v___x_3460_ = lean_uint64_shift_left(v___x_3458_, v___x_3459_);
v___x_3461_ = lean_uint64_lor(v_a_3447_, v___x_3460_);
v___x_3462_ = ((size_t)2ULL);
v___x_3463_ = lean_usize_add(v_pos_3445_, v___x_3462_);
v___x_3464_ = lean_byte_array_uget(v___y_3438_, v___x_3463_);
v___x_3465_ = lean_uint8_to_uint64(v___x_3464_);
v___x_3466_ = 16ULL;
v___x_3467_ = lean_uint64_shift_left(v___x_3465_, v___x_3466_);
v___x_3468_ = lean_uint64_lor(v___x_3461_, v___x_3467_);
v___x_3469_ = ((size_t)3ULL);
v___x_3470_ = lean_usize_add(v_pos_3445_, v___x_3469_);
v___x_3471_ = lean_byte_array_uget(v___y_3438_, v___x_3470_);
v___x_3472_ = lean_uint8_to_uint64(v___x_3471_);
v___x_3473_ = 24ULL;
v___x_3474_ = lean_uint64_shift_left(v___x_3472_, v___x_3473_);
v___x_3475_ = lean_uint64_lor(v___x_3468_, v___x_3474_);
v___y_3353_ = v___y_3437_;
v___y_3354_ = v___x_3475_;
goto v___jp_3352_;
}
}
}
}
v___jp_3476_:
{
lean_object* v_offset_3481_; lean_object* v___x_3482_; lean_object* v___x_3483_; uint8_t v___x_3484_; 
v_offset_3481_ = lean_nat_mul(v_i_3312_, v___y_3480_);
v___x_3482_ = lean_nat_add(v_offset_3481_, v___y_3480_);
v___x_3483_ = lean_byte_array_size(v___y_3479_);
v___x_3484_ = lean_nat_dec_le(v___x_3482_, v___x_3483_);
if (v___x_3484_ == 0)
{
lean_dec(v___x_3482_);
v___y_3435_ = v___y_3477_;
v___y_3436_ = v_offset_3481_;
v___y_3437_ = v___y_3478_;
v___y_3438_ = v___y_3479_;
v___y_3439_ = v___x_3484_;
goto v___jp_3434_;
}
else
{
size_t v___x_3485_; lean_object* v___x_3486_; uint8_t v___x_3487_; 
v___x_3485_ = lean_usize_of_nat(v___x_3482_);
v___x_3486_ = lean_usize_to_nat(v___x_3485_);
v___x_3487_ = lean_nat_dec_eq(v___x_3486_, v___x_3482_);
lean_dec(v___x_3482_);
lean_dec(v___x_3486_);
v___y_3435_ = v___y_3477_;
v___y_3436_ = v_offset_3481_;
v___y_3437_ = v___y_3478_;
v___y_3438_ = v___y_3479_;
v___y_3439_ = v___x_3487_;
goto v___jp_3434_;
}
}
v___jp_3488_:
{
lean_object* v_coefficients_3490_; lean_object* v___x_3491_; uint8_t v___x_3492_; 
v_coefficients_3490_ = lean_ctor_get(v___y_3308_, 1);
v___x_3491_ = lean_uint64_to_nat(v___y_3489_);
v___x_3492_ = 0;
switch(v_width_3307_)
{
case 0:
{
lean_object* v___x_3493_; 
v___x_3493_ = lean_unsigned_to_nat(1u);
v___y_3477_ = v___x_3492_;
v___y_3478_ = v___x_3491_;
v___y_3479_ = v_coefficients_3490_;
v___y_3480_ = v___x_3493_;
goto v___jp_3476_;
}
case 1:
{
lean_object* v___x_3494_; 
v___x_3494_ = lean_unsigned_to_nat(2u);
v___y_3477_ = v___x_3492_;
v___y_3478_ = v___x_3491_;
v___y_3479_ = v_coefficients_3490_;
v___y_3480_ = v___x_3494_;
goto v___jp_3476_;
}
default: 
{
lean_object* v___x_3495_; 
v___x_3495_ = lean_unsigned_to_nat(4u);
v___y_3477_ = v___x_3492_;
v___y_3478_ = v___x_3491_;
v___y_3479_ = v_coefficients_3490_;
v___y_3480_ = v___x_3495_;
goto v___jp_3476_;
}
}
}
v___jp_3496_:
{
uint64_t v___x_3499_; uint64_t v___x_3500_; uint64_t v___x_3501_; uint64_t v___x_3502_; 
v___x_3499_ = lean_uint8_to_uint64(v___y_3498_);
v___x_3500_ = 24ULL;
v___x_3501_ = lean_uint64_shift_left(v___x_3499_, v___x_3500_);
v___x_3502_ = lean_uint64_lor(v___y_3497_, v___x_3501_);
v___y_3489_ = v___x_3502_;
goto v___jp_3488_;
}
v___jp_3506_:
{
uint64_t v___x_3509_; uint64_t v___x_3510_; uint64_t v___x_3511_; uint64_t v___x_3512_; lean_object* v___x_3513_; lean_object* v___x_3514_; uint8_t v___x_3515_; 
v___x_3509_ = lean_uint8_to_uint64(v___y_3508_);
v___x_3510_ = 16ULL;
v___x_3511_ = lean_uint64_shift_left(v___x_3509_, v___x_3510_);
v___x_3512_ = lean_uint64_lor(v___y_3507_, v___x_3511_);
v___x_3513_ = lean_unsigned_to_nat(3u);
v___x_3514_ = lean_nat_add(v_offset_3505_, v___x_3513_);
lean_dec(v_offset_3505_);
v___x_3515_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_3309_, v___x_3514_);
if (v___x_3515_ == 0)
{
lean_object* v___x_3516_; lean_object* v___x_3517_; uint8_t v___x_3518_; 
lean_dec(v___x_3514_);
v___x_3516_ = lean_box(v___x_3503_);
v___x_3517_ = l_outOfBounds___redArg(v___x_3516_);
lean_dec(v___x_3516_);
v___x_3518_ = lean_unbox(v___x_3517_);
lean_dec(v___x_3517_);
v___y_3497_ = v___x_3512_;
v___y_3498_ = v___x_3518_;
goto v___jp_3496_;
}
else
{
uint8_t v___x_3519_; 
v___x_3519_ = lean_byte_array_fget(v___x_3309_, v___x_3514_);
lean_dec(v___x_3514_);
v___y_3497_ = v___x_3512_;
v___y_3498_ = v___x_3519_;
goto v___jp_3496_;
}
}
v___jp_3520_:
{
uint64_t v___x_3523_; uint64_t v___x_3524_; uint64_t v___x_3525_; uint64_t v___x_3526_; lean_object* v___x_3527_; lean_object* v___x_3528_; uint8_t v___x_3529_; 
v___x_3523_ = lean_uint8_to_uint64(v___y_3522_);
v___x_3524_ = 8ULL;
v___x_3525_ = lean_uint64_shift_left(v___x_3523_, v___x_3524_);
v___x_3526_ = lean_uint64_lor(v___y_3521_, v___x_3525_);
v___x_3527_ = lean_unsigned_to_nat(2u);
v___x_3528_ = lean_nat_add(v_offset_3505_, v___x_3527_);
v___x_3529_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_3309_, v___x_3528_);
if (v___x_3529_ == 0)
{
lean_object* v___x_3530_; lean_object* v___x_3531_; uint8_t v___x_3532_; 
lean_dec(v___x_3528_);
v___x_3530_ = lean_box(v___x_3503_);
v___x_3531_ = l_outOfBounds___redArg(v___x_3530_);
lean_dec(v___x_3530_);
v___x_3532_ = lean_unbox(v___x_3531_);
lean_dec(v___x_3531_);
v___y_3507_ = v___x_3526_;
v___y_3508_ = v___x_3532_;
goto v___jp_3506_;
}
else
{
uint8_t v___x_3533_; 
v___x_3533_ = lean_byte_array_fget(v___x_3309_, v___x_3528_);
lean_dec(v___x_3528_);
v___y_3507_ = v___x_3526_;
v___y_3508_ = v___x_3533_;
goto v___jp_3506_;
}
}
v___jp_3534_:
{
uint64_t v_a_3536_; lean_object* v___x_3537_; lean_object* v___x_3538_; uint8_t v___x_3539_; 
v_a_3536_ = lean_uint8_to_uint64(v___y_3535_);
v___x_3537_ = lean_unsigned_to_nat(1u);
v___x_3538_ = lean_nat_add(v_offset_3505_, v___x_3537_);
v___x_3539_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_3309_, v___x_3538_);
if (v___x_3539_ == 0)
{
lean_object* v___x_3540_; lean_object* v___x_3541_; uint8_t v___x_3542_; 
lean_dec(v___x_3538_);
v___x_3540_ = lean_box(v___x_3503_);
v___x_3541_ = l_outOfBounds___redArg(v___x_3540_);
lean_dec(v___x_3540_);
v___x_3542_ = lean_unbox(v___x_3541_);
lean_dec(v___x_3541_);
v___y_3521_ = v_a_3536_;
v___y_3522_ = v___x_3542_;
goto v___jp_3520_;
}
else
{
uint8_t v___x_3543_; 
v___x_3543_ = lean_byte_array_fget(v___x_3309_, v___x_3538_);
lean_dec(v___x_3538_);
v___y_3521_ = v_a_3536_;
v___y_3522_ = v___x_3543_;
goto v___jp_3520_;
}
}
v___jp_3544_:
{
if (v___y_3545_ == 0)
{
uint8_t v___x_3546_; 
v___x_3546_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___x_3309_, v_offset_3505_);
if (v___x_3546_ == 0)
{
lean_object* v___x_3547_; lean_object* v___x_3548_; uint8_t v___x_3549_; 
v___x_3547_ = lean_box(v___x_3503_);
v___x_3548_ = l_outOfBounds___redArg(v___x_3547_);
lean_dec(v___x_3547_);
v___x_3549_ = lean_unbox(v___x_3548_);
lean_dec(v___x_3548_);
v___y_3535_ = v___x_3549_;
goto v___jp_3534_;
}
else
{
uint8_t v___x_3550_; 
v___x_3550_ = lean_byte_array_fget(v___x_3309_, v_offset_3505_);
v___y_3535_ = v___x_3550_;
goto v___jp_3534_;
}
}
else
{
size_t v_pos_3551_; uint8_t v___x_3552_; uint64_t v_a_3553_; size_t v___x_3554_; size_t v___x_3555_; uint8_t v___x_3556_; uint64_t v___x_3557_; uint64_t v___x_3558_; uint64_t v___x_3559_; uint64_t v___x_3560_; size_t v___x_3561_; size_t v___x_3562_; uint8_t v___x_3563_; uint64_t v___x_3564_; uint64_t v___x_3565_; uint64_t v___x_3566_; uint64_t v___x_3567_; size_t v___x_3568_; size_t v___x_3569_; uint8_t v___x_3570_; uint64_t v___x_3571_; uint64_t v___x_3572_; uint64_t v___x_3573_; uint64_t v___x_3574_; 
v_pos_3551_ = lean_usize_of_nat(v_offset_3505_);
lean_dec(v_offset_3505_);
v___x_3552_ = lean_byte_array_uget(v___x_3309_, v_pos_3551_);
v_a_3553_ = lean_uint8_to_uint64(v___x_3552_);
v___x_3554_ = ((size_t)1ULL);
v___x_3555_ = lean_usize_add(v_pos_3551_, v___x_3554_);
v___x_3556_ = lean_byte_array_uget(v___x_3309_, v___x_3555_);
v___x_3557_ = lean_uint8_to_uint64(v___x_3556_);
v___x_3558_ = 8ULL;
v___x_3559_ = lean_uint64_shift_left(v___x_3557_, v___x_3558_);
v___x_3560_ = lean_uint64_lor(v_a_3553_, v___x_3559_);
v___x_3561_ = ((size_t)2ULL);
v___x_3562_ = lean_usize_add(v_pos_3551_, v___x_3561_);
v___x_3563_ = lean_byte_array_uget(v___x_3309_, v___x_3562_);
v___x_3564_ = lean_uint8_to_uint64(v___x_3563_);
v___x_3565_ = 16ULL;
v___x_3566_ = lean_uint64_shift_left(v___x_3564_, v___x_3565_);
v___x_3567_ = lean_uint64_lor(v___x_3560_, v___x_3566_);
v___x_3568_ = ((size_t)3ULL);
v___x_3569_ = lean_usize_add(v_pos_3551_, v___x_3568_);
v___x_3570_ = lean_byte_array_uget(v___x_3309_, v___x_3569_);
v___x_3571_ = lean_uint8_to_uint64(v___x_3570_);
v___x_3572_ = 24ULL;
v___x_3573_ = lean_uint64_shift_left(v___x_3571_, v___x_3572_);
v___x_3574_ = lean_uint64_lor(v___x_3567_, v___x_3573_);
v___y_3489_ = v___x_3574_;
goto v___jp_3488_;
}
}
}
v___jp_3316_:
{
lean_object* v___x_3319_; 
v___x_3319_ = lean_nat_add(v_i_3312_, v_step_3315_);
lean_dec(v_i_3312_);
v_b_3311_ = v_a_3317_;
v_i_3312_ = v___x_3319_;
v___y_3313_ = v_snd_3318_;
goto _start;
}
v___jp_3321_:
{
lean_object* v_offset_3325_; uint8_t v___x_3326_; lean_object* v_data_3327_; 
v_offset_3325_ = lean_nat_mul(v___y_3323_, v___y_3324_);
lean_dec(v___y_3323_);
v___x_3326_ = lean_uint64_to_uint8(v___y_3322_);
v_data_3327_ = lean_byte_array_set(v_b_3311_, v_offset_3325_, v___x_3326_);
switch(v_width_3307_)
{
case 0:
{
lean_dec(v_offset_3325_);
v_a_3317_ = v_data_3327_;
v_snd_3318_ = v___y_3313_;
goto v___jp_3316_;
}
case 1:
{
lean_object* v___x_3328_; lean_object* v___x_3329_; uint64_t v___x_3330_; uint64_t v___x_3331_; uint8_t v___x_3332_; lean_object* v___x_3333_; 
v___x_3328_ = lean_unsigned_to_nat(1u);
v___x_3329_ = lean_nat_add(v_offset_3325_, v___x_3328_);
lean_dec(v_offset_3325_);
v___x_3330_ = 8ULL;
v___x_3331_ = lean_uint64_shift_right(v___y_3322_, v___x_3330_);
v___x_3332_ = lean_uint64_to_uint8(v___x_3331_);
v___x_3333_ = lean_byte_array_set(v_data_3327_, v___x_3329_, v___x_3332_);
lean_dec(v___x_3329_);
v_a_3317_ = v___x_3333_;
v_snd_3318_ = v___y_3313_;
goto v___jp_3316_;
}
default: 
{
lean_object* v___x_3334_; lean_object* v___x_3335_; uint64_t v___x_3336_; uint64_t v___x_3337_; uint8_t v___x_3338_; lean_object* v___x_3339_; lean_object* v___x_3340_; lean_object* v___x_3341_; uint64_t v___x_3342_; uint64_t v___x_3343_; uint8_t v___x_3344_; lean_object* v___x_3345_; lean_object* v___x_3346_; lean_object* v___x_3347_; uint64_t v___x_3348_; uint64_t v___x_3349_; uint8_t v___x_3350_; lean_object* v___x_3351_; 
v___x_3334_ = lean_unsigned_to_nat(1u);
v___x_3335_ = lean_nat_add(v_offset_3325_, v___x_3334_);
v___x_3336_ = 8ULL;
v___x_3337_ = lean_uint64_shift_right(v___y_3322_, v___x_3336_);
v___x_3338_ = lean_uint64_to_uint8(v___x_3337_);
v___x_3339_ = lean_byte_array_set(v_data_3327_, v___x_3335_, v___x_3338_);
lean_dec(v___x_3335_);
v___x_3340_ = lean_unsigned_to_nat(2u);
v___x_3341_ = lean_nat_add(v_offset_3325_, v___x_3340_);
v___x_3342_ = 16ULL;
v___x_3343_ = lean_uint64_shift_right(v___y_3322_, v___x_3342_);
v___x_3344_ = lean_uint64_to_uint8(v___x_3343_);
v___x_3345_ = lean_byte_array_set(v___x_3339_, v___x_3341_, v___x_3344_);
lean_dec(v___x_3341_);
v___x_3346_ = lean_unsigned_to_nat(3u);
v___x_3347_ = lean_nat_add(v_offset_3325_, v___x_3346_);
lean_dec(v_offset_3325_);
v___x_3348_ = 24ULL;
v___x_3349_ = lean_uint64_shift_right(v___y_3322_, v___x_3348_);
v___x_3350_ = lean_uint64_to_uint8(v___x_3349_);
v___x_3351_ = lean_byte_array_set(v___x_3345_, v___x_3347_, v___x_3350_);
lean_dec(v___x_3347_);
v_a_3317_ = v___x_3351_;
v_snd_3318_ = v___y_3313_;
goto v___jp_3316_;
}
}
}
v___jp_3352_:
{
switch(v_width_3307_)
{
case 0:
{
lean_object* v___x_3355_; 
v___x_3355_ = lean_unsigned_to_nat(1u);
v___y_3322_ = v___y_3354_;
v___y_3323_ = v___y_3353_;
v___y_3324_ = v___x_3355_;
goto v___jp_3321_;
}
case 1:
{
lean_object* v___x_3356_; 
v___x_3356_ = lean_unsigned_to_nat(2u);
v___y_3322_ = v___y_3354_;
v___y_3323_ = v___y_3353_;
v___y_3324_ = v___x_3356_;
goto v___jp_3321_;
}
default: 
{
lean_object* v___x_3357_; 
v___x_3357_ = lean_unsigned_to_nat(4u);
v___y_3322_ = v___y_3354_;
v___y_3323_ = v___y_3353_;
v___y_3324_ = v___x_3357_;
goto v___jp_3321_;
}
}
}
v___jp_3358_:
{
uint64_t v___x_3362_; uint64_t v___x_3363_; uint64_t v___x_3364_; uint64_t v___x_3365_; 
v___x_3362_ = lean_uint8_to_uint64(v___y_3361_);
v___x_3363_ = 24ULL;
v___x_3364_ = lean_uint64_shift_left(v___x_3362_, v___x_3363_);
v___x_3365_ = lean_uint64_lor(v___y_3360_, v___x_3364_);
v___y_3353_ = v___y_3359_;
v___y_3354_ = v___x_3365_;
goto v___jp_3352_;
}
v___jp_3366_:
{
uint64_t v___x_3370_; uint64_t v___x_3371_; uint64_t v___x_3372_; uint64_t v___x_3373_; 
v___x_3370_ = lean_uint8_to_uint64(v___y_3369_);
v___x_3371_ = 8ULL;
v___x_3372_ = lean_uint64_shift_left(v___x_3370_, v___x_3371_);
v___x_3373_ = lean_uint64_lor(v___y_3368_, v___x_3372_);
v___y_3353_ = v___y_3367_;
v___y_3354_ = v___x_3373_;
goto v___jp_3352_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___redArg___boxed(lean_object* v_width_3581_, lean_object* v___y_3582_, lean_object* v___x_3583_, lean_object* v_range_3584_, lean_object* v_b_3585_, lean_object* v_i_3586_, lean_object* v___y_3587_){
_start:
{
uint8_t v_width_boxed_3588_; lean_object* v_res_3589_; 
v_width_boxed_3588_ = lean_unbox(v_width_3581_);
v_res_3589_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___redArg(v_width_boxed_3588_, v___y_3582_, v___x_3583_, v_range_3584_, v_b_3585_, v_i_3586_, v___y_3587_);
lean_dec_ref(v_range_3584_);
lean_dec_ref(v___x_3583_);
lean_dec_ref(v___y_3582_);
return v_res_3589_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(lean_object* v___x_3590_, lean_object* v_____r_3591_, lean_object* v_dense_3592_, lean_object* v_slots_3593_, lean_object* v_pivots_3594_, lean_object* v_nativePivots_3595_, lean_object* v_trace_3596_, lean_object* v_remainders_3597_, lean_object* v_reducerRank_3598_, lean_object* v_node_3599_, lean_object* v_sugar_3600_, lean_object* v___y_3601_){
_start:
{
lean_object* v_work_3602_; lean_object* v_inputEntries_3603_; lean_object* v_outputEntries_3604_; lean_object* v_packedBytes_3605_; lean_object* v_traceNodes_3606_; lean_object* v_processedRows_3607_; lean_object* v_reductions_3608_; lean_object* v_zeroRows_3609_; lean_object* v___x_3611_; uint8_t v_isShared_3612_; uint8_t v_isSharedCheck_3626_; 
v_work_3602_ = lean_ctor_get(v___y_3601_, 0);
v_inputEntries_3603_ = lean_ctor_get(v___y_3601_, 1);
v_outputEntries_3604_ = lean_ctor_get(v___y_3601_, 2);
v_packedBytes_3605_ = lean_ctor_get(v___y_3601_, 3);
v_traceNodes_3606_ = lean_ctor_get(v___y_3601_, 4);
v_processedRows_3607_ = lean_ctor_get(v___y_3601_, 5);
v_reductions_3608_ = lean_ctor_get(v___y_3601_, 6);
v_zeroRows_3609_ = lean_ctor_get(v___y_3601_, 7);
v_isSharedCheck_3626_ = !lean_is_exclusive(v___y_3601_);
if (v_isSharedCheck_3626_ == 0)
{
v___x_3611_ = v___y_3601_;
v_isShared_3612_ = v_isSharedCheck_3626_;
goto v_resetjp_3610_;
}
else
{
lean_inc(v_zeroRows_3609_);
lean_inc(v_reductions_3608_);
lean_inc(v_processedRows_3607_);
lean_inc(v_traceNodes_3606_);
lean_inc(v_packedBytes_3605_);
lean_inc(v_outputEntries_3604_);
lean_inc(v_inputEntries_3603_);
lean_inc(v_work_3602_);
lean_dec(v___y_3601_);
v___x_3611_ = lean_box(0);
v_isShared_3612_ = v_isSharedCheck_3626_;
goto v_resetjp_3610_;
}
v_resetjp_3610_:
{
lean_object* v___x_3613_; lean_object* v___x_3615_; 
v___x_3613_ = lean_nat_add(v_processedRows_3607_, v___x_3590_);
lean_dec(v_processedRows_3607_);
if (v_isShared_3612_ == 0)
{
lean_ctor_set(v___x_3611_, 5, v___x_3613_);
v___x_3615_ = v___x_3611_;
goto v_reusejp_3614_;
}
else
{
lean_object* v_reuseFailAlloc_3625_; 
v_reuseFailAlloc_3625_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_3625_, 0, v_work_3602_);
lean_ctor_set(v_reuseFailAlloc_3625_, 1, v_inputEntries_3603_);
lean_ctor_set(v_reuseFailAlloc_3625_, 2, v_outputEntries_3604_);
lean_ctor_set(v_reuseFailAlloc_3625_, 3, v_packedBytes_3605_);
lean_ctor_set(v_reuseFailAlloc_3625_, 4, v_traceNodes_3606_);
lean_ctor_set(v_reuseFailAlloc_3625_, 5, v___x_3613_);
lean_ctor_set(v_reuseFailAlloc_3625_, 6, v_reductions_3608_);
lean_ctor_set(v_reuseFailAlloc_3625_, 7, v_zeroRows_3609_);
v___x_3615_ = v_reuseFailAlloc_3625_;
goto v_reusejp_3614_;
}
v_reusejp_3614_:
{
lean_object* v___x_3616_; lean_object* v___x_3617_; lean_object* v___x_3618_; lean_object* v___x_3619_; lean_object* v___x_3620_; lean_object* v___x_3621_; lean_object* v___x_3622_; lean_object* v___x_3623_; lean_object* v___x_3624_; 
v___x_3616_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3616_, 0, v_remainders_3597_);
lean_ctor_set(v___x_3616_, 1, v_reducerRank_3598_);
v___x_3617_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3617_, 0, v_trace_3596_);
lean_ctor_set(v___x_3617_, 1, v___x_3616_);
v___x_3618_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3618_, 0, v_nativePivots_3595_);
lean_ctor_set(v___x_3618_, 1, v___x_3617_);
v___x_3619_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3619_, 0, v_pivots_3594_);
lean_ctor_set(v___x_3619_, 1, v___x_3618_);
v___x_3620_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3620_, 0, v_slots_3593_);
lean_ctor_set(v___x_3620_, 1, v___x_3619_);
v___x_3621_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3621_, 0, v_dense_3592_);
lean_ctor_set(v___x_3621_, 1, v___x_3620_);
v___x_3622_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3622_, 0, v___x_3621_);
v___x_3623_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3623_, 0, v___x_3622_);
v___x_3624_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3624_, 0, v___x_3623_);
lean_ctor_set(v___x_3624_, 1, v___x_3615_);
return v___x_3624_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5___boxed(lean_object* v___x_3627_, lean_object* v_____r_3628_, lean_object* v_dense_3629_, lean_object* v_slots_3630_, lean_object* v_pivots_3631_, lean_object* v_nativePivots_3632_, lean_object* v_trace_3633_, lean_object* v_remainders_3634_, lean_object* v_reducerRank_3635_, lean_object* v_node_3636_, lean_object* v_sugar_3637_, lean_object* v___y_3638_){
_start:
{
lean_object* v_res_3639_; 
v_res_3639_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_3627_, v_____r_3628_, v_dense_3629_, v_slots_3630_, v_pivots_3631_, v_nativePivots_3632_, v_trace_3633_, v_remainders_3634_, v_reducerRank_3635_, v_node_3636_, v_sugar_3637_, v___y_3638_);
lean_dec(v_sugar_3637_);
lean_dec(v_node_3636_);
lean_dec(v___x_3627_);
return v_res_3639_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0(void){
_start:
{
lean_object* v___x_3640_; lean_object* v___x_3641_; 
v___x_3640_ = l_ByteArray_empty;
v___x_3641_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3641_, 0, v___x_3640_);
lean_ctor_set(v___x_3641_, 1, v___x_3640_);
return v___x_3641_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg(lean_object* v_limits_3642_, lean_object* v___x_3643_, uint8_t v_provenance_3644_, uint64_t v_field_3645_, uint64_t v_ctx_3646_, uint8_t v_native_3647_, uint8_t v_width_3648_, uint8_t v_independent_3649_, lean_object* v___y_3650_, lean_object* v_columns_3651_, lean_object* v_sugars_3652_, lean_object* v_reducers_3653_, lean_object* v_targets_3654_, lean_object* v_range_3655_, lean_object* v_b_3656_, lean_object* v_i_3657_, lean_object* v___y_3658_){
_start:
{
lean_object* v_a_3660_; lean_object* v_snd_3661_; lean_object* v_stop_3664_; lean_object* v_step_3665_; lean_object* v___y_3667_; uint8_t v___x_3693_; 
v_stop_3664_ = lean_ctor_get(v_range_3655_, 1);
v_step_3665_ = lean_ctor_get(v_range_3655_, 2);
v___x_3693_ = lean_nat_dec_lt(v_i_3657_, v_stop_3664_);
if (v___x_3693_ == 0)
{
lean_object* v___x_3694_; lean_object* v___x_3695_; 
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v___x_3694_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3694_, 0, v_b_3656_);
v___x_3695_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3695_, 0, v___x_3694_);
lean_ctor_set(v___x_3695_, 1, v___y_3658_);
return v___x_3695_;
}
else
{
lean_object* v___x_3696_; lean_object* v___x_3697_; lean_object* v_fst_3698_; 
v___x_3696_ = lean_unsigned_to_nat(1u);
v___x_3697_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_3642_, v___x_3696_, v___y_3658_);
v_fst_3698_ = lean_ctor_get(v___x_3697_, 0);
lean_inc(v_fst_3698_);
if (lean_obj_tag(v_fst_3698_) == 0)
{
lean_object* v_snd_3699_; lean_object* v_a_3700_; 
lean_dec(v_i_3657_);
lean_dec_ref(v_b_3656_);
lean_dec(v_columns_3651_);
v_snd_3699_ = lean_ctor_get(v___x_3697_, 1);
lean_inc(v_snd_3699_);
lean_dec_ref(v___x_3697_);
v_a_3700_ = lean_ctor_get(v_fst_3698_, 0);
lean_inc(v_a_3700_);
lean_dec_ref_known(v_fst_3698_, 1);
v_a_3660_ = v_a_3700_;
v_snd_3661_ = v_snd_3699_;
goto v___jp_3659_;
}
else
{
lean_object* v___x_3702_; uint8_t v_isShared_3703_; uint8_t v_isSharedCheck_4905_; 
v_isSharedCheck_4905_ = !lean_is_exclusive(v_fst_3698_);
if (v_isSharedCheck_4905_ == 0)
{
lean_object* v_unused_4906_; 
v_unused_4906_ = lean_ctor_get(v_fst_3698_, 0);
lean_dec(v_unused_4906_);
v___x_3702_ = v_fst_3698_;
v_isShared_3703_ = v_isSharedCheck_4905_;
goto v_resetjp_3701_;
}
else
{
lean_dec(v_fst_3698_);
v___x_3702_ = lean_box(0);
v_isShared_3703_ = v_isSharedCheck_4905_;
goto v_resetjp_3701_;
}
v_resetjp_3701_:
{
lean_object* v_snd_3704_; lean_object* v_snd_3705_; lean_object* v_snd_3706_; lean_object* v_snd_3707_; lean_object* v_snd_3708_; lean_object* v_snd_3709_; lean_object* v_fst_3710_; lean_object* v_fst_3711_; lean_object* v_fst_3712_; lean_object* v_fst_3713_; lean_object* v_fst_3714_; lean_object* v_fst_3715_; lean_object* v_snd_3716_; lean_object* v___y_3718_; lean_object* v___y_3719_; lean_object* v___y_3720_; lean_object* v___y_3721_; lean_object* v___y_3722_; lean_object* v_nativePivots_3723_; lean_object* v___y_3724_; lean_object* v___y_3729_; lean_object* v___y_3730_; uint8_t v___y_3731_; lean_object* v___y_3732_; uint64_t v___y_3733_; lean_object* v___y_3734_; lean_object* v_fst_3735_; lean_object* v_snd_3736_; lean_object* v___y_3737_; lean_object* v___y_3769_; uint8_t v___y_3770_; lean_object* v___y_3771_; lean_object* v___y_3772_; lean_object* v___y_3773_; lean_object* v___y_3774_; lean_object* v___y_3775_; uint64_t v___y_3776_; lean_object* v___y_3808_; uint8_t v___y_3809_; lean_object* v___y_3810_; uint64_t v___y_3811_; lean_object* v___y_3812_; lean_object* v___y_3813_; lean_object* v___y_3814_; lean_object* v___y_3815_; uint8_t v___y_3816_; lean_object* v___y_3822_; lean_object* v___y_3823_; uint8_t v___y_3824_; lean_object* v___y_3825_; lean_object* v___y_3826_; lean_object* v___y_3827_; lean_object* v___y_3828_; uint64_t v___y_3829_; uint8_t v___y_3830_; lean_object* v___y_3831_; uint8_t v___y_3832_; uint64_t v___y_3844_; lean_object* v___y_3845_; uint8_t v___y_3846_; lean_object* v___y_3847_; lean_object* v___y_3848_; lean_object* v___y_3849_; lean_object* v___y_3850_; lean_object* v___y_3851_; lean_object* v___y_3852_; uint8_t v___y_3853_; uint8_t v___y_3854_; uint64_t v___y_3866_; lean_object* v___y_3867_; uint8_t v___y_3868_; lean_object* v___y_3869_; lean_object* v___y_3870_; lean_object* v___y_3871_; lean_object* v___y_3872_; lean_object* v___y_3873_; uint8_t v___y_3874_; lean_object* v___y_3880_; lean_object* v___y_3881_; uint8_t v___y_3882_; lean_object* v___y_3883_; lean_object* v___y_3884_; lean_object* v___y_3885_; lean_object* v___y_3886_; uint8_t v___y_3887_; lean_object* v___y_3888_; uint8_t v___y_3889_; uint8_t v___y_3902_; lean_object* v___y_3903_; lean_object* v___y_3904_; lean_object* v___y_3905_; lean_object* v___y_3906_; lean_object* v___y_3907_; lean_object* v___y_3908_; lean_object* v_nativePivots_3909_; lean_object* v___y_3910_; lean_object* v___y_3917_; lean_object* v___y_3918_; lean_object* v___y_3919_; lean_object* v___y_3920_; lean_object* v_remainders_3921_; lean_object* v___y_3922_; lean_object* v___y_3942_; lean_object* v___y_3943_; lean_object* v___y_3944_; lean_object* v_remainders_3945_; lean_object* v___y_3946_; lean_object* v_reducerRank_3965_; lean_object* v___y_3967_; uint8_t v___y_3968_; lean_object* v___y_3969_; lean_object* v___y_3970_; lean_object* v___y_3971_; lean_object* v___y_3972_; lean_object* v___y_3973_; lean_object* v___y_3974_; uint8_t v___y_3975_; uint8_t v___y_3976_; lean_object* v___y_4010_; uint8_t v___y_4011_; lean_object* v___y_4012_; lean_object* v___y_4013_; lean_object* v___y_4014_; lean_object* v___y_4015_; lean_object* v___y_4016_; uint8_t v___y_4017_; lean_object* v___y_4018_; lean_object* v___y_4019_; lean_object* v___x_4025_; uint8_t v___x_4026_; uint8_t v___y_4028_; lean_object* v___y_4029_; lean_object* v___y_4030_; lean_object* v___y_4031_; lean_object* v___y_4032_; lean_object* v___y_4033_; lean_object* v___y_4034_; uint64_t v___y_4035_; lean_object* v___y_4036_; lean_object* v___y_4037_; uint8_t v___y_4069_; lean_object* v___y_4070_; lean_object* v___y_4071_; uint64_t v___y_4072_; lean_object* v___y_4073_; lean_object* v___y_4074_; lean_object* v___y_4075_; lean_object* v_dense_4076_; lean_object* v_output_4077_; lean_object* v___y_4078_; lean_object* v___y_4084_; uint8_t v___y_4085_; lean_object* v___y_4086_; uint64_t v___y_4087_; lean_object* v___y_4088_; lean_object* v___y_4089_; lean_object* v___y_4090_; lean_object* v_fst_4091_; lean_object* v_snd_4092_; lean_object* v___y_4093_; uint8_t v___y_4129_; lean_object* v___y_4130_; lean_object* v___y_4131_; lean_object* v___y_4132_; lean_object* v___y_4133_; lean_object* v___y_4134_; lean_object* v___y_4135_; lean_object* v___y_4136_; uint64_t v_inv_4137_; lean_object* v___y_4138_; lean_object* v___y_4152_; uint8_t v___y_4153_; lean_object* v___y_4154_; uint64_t v___y_4155_; lean_object* v___y_4156_; lean_object* v___y_4157_; lean_object* v___y_4158_; lean_object* v___y_4159_; lean_object* v___y_4160_; lean_object* v___y_4161_; uint8_t v___y_4170_; lean_object* v___y_4171_; lean_object* v___y_4172_; lean_object* v___y_4173_; lean_object* v___y_4174_; lean_object* v___y_4175_; lean_object* v___y_4176_; lean_object* v___y_4177_; lean_object* v___y_4178_; uint64_t v___y_4179_; lean_object* v___y_4182_; uint8_t v___y_4183_; uint64_t v___y_4184_; lean_object* v___y_4185_; lean_object* v___y_4186_; lean_object* v___y_4187_; lean_object* v___y_4188_; lean_object* v___y_4189_; lean_object* v___y_4190_; lean_object* v___y_4191_; uint8_t v___y_4192_; uint8_t v___y_4198_; lean_object* v___y_4199_; lean_object* v___y_4200_; lean_object* v___y_4201_; lean_object* v___y_4202_; uint8_t v___y_4203_; lean_object* v___y_4204_; uint64_t v___y_4205_; lean_object* v___y_4206_; lean_object* v___y_4207_; lean_object* v___y_4208_; lean_object* v___y_4209_; uint8_t v___y_4210_; lean_object* v___y_4223_; uint8_t v___y_4224_; uint64_t v___y_4225_; lean_object* v___y_4226_; lean_object* v___y_4227_; lean_object* v___y_4228_; uint8_t v___y_4229_; lean_object* v___y_4230_; lean_object* v___y_4231_; lean_object* v___y_4232_; lean_object* v___y_4233_; lean_object* v___y_4234_; uint8_t v___y_4235_; lean_object* v___y_4248_; uint8_t v___y_4249_; uint64_t v___y_4250_; lean_object* v___y_4251_; lean_object* v___y_4252_; lean_object* v___y_4253_; lean_object* v___y_4254_; lean_object* v___y_4255_; lean_object* v___y_4256_; lean_object* v___y_4257_; uint8_t v___y_4258_; uint8_t v___y_4264_; lean_object* v___y_4265_; lean_object* v___y_4266_; lean_object* v___y_4267_; lean_object* v___y_4268_; uint8_t v___y_4269_; lean_object* v___y_4270_; lean_object* v___y_4271_; lean_object* v___y_4272_; lean_object* v___y_4273_; lean_object* v___y_4274_; uint8_t v___y_4275_; uint8_t v___y_4290_; lean_object* v___y_4291_; lean_object* v___y_4292_; lean_object* v___y_4293_; lean_object* v___y_4294_; uint8_t v___y_4295_; lean_object* v___y_4296_; lean_object* v___y_4297_; lean_object* v___y_4298_; lean_object* v___y_4299_; lean_object* v___y_4300_; uint8_t v___y_4301_; lean_object* v___y_4339_; uint8_t v___y_4340_; lean_object* v___y_4341_; lean_object* v___y_4342_; lean_object* v___y_4343_; uint8_t v___y_4344_; lean_object* v___y_4345_; lean_object* v___y_4346_; lean_object* v___y_4347_; lean_object* v___y_4348_; lean_object* v___y_4349_; uint8_t v___y_4358_; lean_object* v___y_4359_; lean_object* v_scan_4360_; lean_object* v___y_4361_; uint8_t v___y_4388_; lean_object* v___y_4389_; lean_object* v___y_4390_; lean_object* v___y_4391_; lean_object* v___y_4392_; lean_object* v___y_4393_; lean_object* v___y_4394_; uint64_t v___y_4395_; uint8_t v___y_4413_; lean_object* v___y_4414_; uint64_t v___y_4415_; lean_object* v___y_4416_; lean_object* v___y_4417_; lean_object* v___y_4418_; lean_object* v___y_4419_; lean_object* v___y_4420_; uint8_t v___y_4421_; lean_object* v___y_4427_; uint8_t v___y_4428_; uint8_t v___y_4429_; lean_object* v___y_4430_; lean_object* v___y_4431_; uint64_t v___y_4432_; lean_object* v___y_4433_; lean_object* v___y_4434_; lean_object* v___y_4435_; lean_object* v___y_4436_; lean_object* v___y_4437_; uint8_t v___y_4438_; uint8_t v___y_4451_; lean_object* v___y_4452_; uint8_t v___y_4453_; lean_object* v___y_4454_; lean_object* v___y_4455_; uint64_t v___y_4456_; lean_object* v___y_4457_; lean_object* v___y_4458_; lean_object* v___y_4459_; lean_object* v___y_4460_; lean_object* v___y_4461_; uint8_t v___y_4462_; lean_object* v___y_4475_; uint8_t v___y_4476_; uint8_t v___y_4477_; lean_object* v___y_4478_; lean_object* v___y_4479_; lean_object* v___y_4480_; lean_object* v___y_4481_; lean_object* v___y_4482_; lean_object* v___y_4483_; lean_object* v___y_4484_; uint8_t v___y_4485_; uint8_t v___y_4494_; lean_object* v___y_4495_; uint8_t v___y_4496_; lean_object* v___y_4497_; lean_object* v___y_4498_; lean_object* v___y_4499_; lean_object* v___y_4500_; lean_object* v___y_4501_; lean_object* v___y_4502_; lean_object* v___y_4503_; uint8_t v___y_4504_; uint8_t v___y_4535_; lean_object* v___y_4536_; lean_object* v___y_4537_; lean_object* v___y_4538_; lean_object* v___y_4539_; lean_object* v___y_4540_; lean_object* v___y_4541_; lean_object* v___y_4542_; lean_object* v___y_4543_; lean_object* v___y_4565_; uint8_t v___y_4566_; lean_object* v___y_4567_; uint8_t v___y_4568_; lean_object* v___y_4569_; lean_object* v___y_4570_; lean_object* v___y_4571_; lean_object* v___y_4572_; lean_object* v___y_4573_; lean_object* v___y_4574_; lean_object* v___y_4575_; uint64_t v___y_4576_; uint8_t v___y_4583_; lean_object* v___y_4584_; uint64_t v___y_4585_; lean_object* v___y_4586_; lean_object* v___y_4587_; uint8_t v___y_4588_; lean_object* v___y_4589_; lean_object* v___y_4590_; lean_object* v___y_4591_; lean_object* v___y_4592_; lean_object* v___y_4593_; lean_object* v___y_4594_; uint8_t v___y_4595_; lean_object* v___y_4601_; lean_object* v___y_4602_; lean_object* v___y_4603_; lean_object* v___y_4604_; lean_object* v___y_4605_; lean_object* v___y_4606_; lean_object* v___y_4607_; uint8_t v___y_4608_; uint8_t v___y_4609_; uint8_t v___y_4610_; lean_object* v___y_4611_; lean_object* v___y_4612_; lean_object* v___y_4613_; uint64_t v___y_4614_; uint8_t v___y_4615_; lean_object* v___y_4628_; lean_object* v___y_4629_; lean_object* v___y_4630_; lean_object* v___y_4631_; lean_object* v___y_4632_; lean_object* v___y_4633_; lean_object* v___y_4634_; uint8_t v___y_4635_; uint64_t v___y_4636_; uint8_t v___y_4637_; uint8_t v___y_4638_; lean_object* v___y_4639_; lean_object* v___y_4640_; lean_object* v___y_4641_; uint8_t v___y_4642_; lean_object* v___y_4655_; lean_object* v___y_4656_; lean_object* v___y_4657_; lean_object* v___y_4658_; lean_object* v___y_4659_; lean_object* v___y_4660_; lean_object* v___y_4661_; uint8_t v___y_4662_; uint8_t v___y_4663_; uint8_t v___y_4664_; lean_object* v___y_4665_; lean_object* v___y_4666_; lean_object* v___y_4667_; uint8_t v___y_4668_; lean_object* v___y_4677_; lean_object* v___y_4678_; lean_object* v___y_4679_; lean_object* v___y_4680_; lean_object* v___y_4681_; lean_object* v___y_4682_; lean_object* v___y_4683_; uint8_t v___y_4684_; uint8_t v___y_4685_; uint8_t v___y_4686_; lean_object* v___y_4687_; lean_object* v___y_4688_; lean_object* v___y_4689_; uint8_t v___y_4690_; lean_object* v___y_4721_; lean_object* v___y_4722_; lean_object* v___y_4723_; uint8_t v___y_4724_; lean_object* v___y_4725_; lean_object* v___y_4726_; lean_object* v___y_4727_; lean_object* v___y_4728_; lean_object* v___y_4729_; lean_object* v___y_4730_; uint8_t v___y_4731_; lean_object* v___y_4742_; lean_object* v___y_4743_; uint8_t v___y_4744_; lean_object* v___y_4745_; lean_object* v___y_4746_; lean_object* v___y_4747_; lean_object* v___y_4748_; lean_object* v___y_4749_; lean_object* v___y_4750_; uint64_t v___y_4751_; lean_object* v___y_4754_; uint64_t v___y_4755_; uint8_t v___y_4756_; lean_object* v___y_4757_; lean_object* v___y_4758_; lean_object* v___y_4759_; lean_object* v___y_4760_; lean_object* v___y_4761_; lean_object* v___y_4762_; lean_object* v___y_4763_; uint8_t v___y_4764_; lean_object* v___y_4770_; uint8_t v___y_4771_; uint64_t v___y_4772_; lean_object* v___y_4773_; uint8_t v___y_4774_; lean_object* v___y_4775_; lean_object* v___y_4776_; lean_object* v___y_4777_; lean_object* v___y_4778_; lean_object* v___y_4779_; lean_object* v___y_4780_; uint8_t v___y_4781_; lean_object* v___y_4793_; uint8_t v___y_4794_; uint8_t v___y_4795_; lean_object* v___y_4796_; lean_object* v___y_4797_; lean_object* v___y_4798_; lean_object* v___y_4799_; lean_object* v___y_4800_; uint64_t v___y_4801_; lean_object* v___y_4802_; lean_object* v___y_4803_; uint8_t v___y_4804_; lean_object* v___y_4816_; uint8_t v___y_4817_; lean_object* v___y_4818_; uint8_t v___y_4819_; lean_object* v___y_4820_; lean_object* v___y_4821_; lean_object* v___y_4822_; lean_object* v___y_4823_; lean_object* v___y_4824_; lean_object* v___y_4825_; uint8_t v___y_4826_; lean_object* v___y_4834_; uint8_t v___y_4835_; lean_object* v___y_4836_; lean_object* v___y_4837_; lean_object* v___y_4838_; lean_object* v___y_4839_; lean_object* v___y_4840_; lean_object* v___y_4841_; lean_object* v___y_4842_; lean_object* v___y_4865_; lean_object* v___y_4866_; lean_object* v___y_4867_; lean_object* v___y_4868_; lean_object* v___y_4869_; lean_object* v___y_4887_; 
v_snd_3704_ = lean_ctor_get(v_b_3656_, 1);
lean_inc(v_snd_3704_);
v_snd_3705_ = lean_ctor_get(v_snd_3704_, 1);
lean_inc(v_snd_3705_);
v_snd_3706_ = lean_ctor_get(v_snd_3705_, 1);
lean_inc(v_snd_3706_);
v_snd_3707_ = lean_ctor_get(v_snd_3706_, 1);
lean_inc(v_snd_3707_);
v_snd_3708_ = lean_ctor_get(v_snd_3707_, 1);
lean_inc(v_snd_3708_);
v_snd_3709_ = lean_ctor_get(v___x_3697_, 1);
lean_inc(v_snd_3709_);
lean_dec_ref(v___x_3697_);
v_fst_3710_ = lean_ctor_get(v_b_3656_, 0);
lean_inc(v_fst_3710_);
lean_dec_ref(v_b_3656_);
v_fst_3711_ = lean_ctor_get(v_snd_3704_, 0);
lean_inc(v_fst_3711_);
lean_dec(v_snd_3704_);
v_fst_3712_ = lean_ctor_get(v_snd_3705_, 0);
lean_inc(v_fst_3712_);
lean_dec(v_snd_3705_);
v_fst_3713_ = lean_ctor_get(v_snd_3706_, 0);
lean_inc(v_fst_3713_);
lean_dec(v_snd_3706_);
v_fst_3714_ = lean_ctor_get(v_snd_3707_, 0);
lean_inc(v_fst_3714_);
lean_dec(v_snd_3707_);
v_fst_3715_ = lean_ctor_get(v_snd_3708_, 0);
lean_inc(v_fst_3715_);
v_snd_3716_ = lean_ctor_get(v_snd_3708_, 1);
lean_inc(v_snd_3716_);
lean_dec(v_snd_3708_);
v_reducerRank_3965_ = lean_unsigned_to_nat(0u);
v___x_4025_ = lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
v___x_4026_ = lean_nat_dec_le(v___x_3643_, v_i_3657_);
if (v___x_4026_ == 0)
{
lean_object* v___x_4902_; 
v___x_4902_ = lean_array_get_borrowed(v___x_4025_, v_reducers_3653_, v_i_3657_);
lean_inc(v___x_4902_);
v___y_4887_ = v___x_4902_;
goto v___jp_4886_;
}
else
{
lean_object* v___x_4903_; lean_object* v___x_4904_; 
v___x_4903_ = lean_nat_sub(v_i_3657_, v___x_3643_);
v___x_4904_ = lean_array_get_borrowed(v___x_4025_, v_targets_3654_, v___x_4903_);
lean_dec(v___x_4903_);
lean_inc(v___x_4904_);
v___y_4887_ = v___x_4904_;
goto v___jp_4886_;
}
v___jp_3717_:
{
lean_object* v___x_3725_; lean_object* v___x_3726_; lean_object* v___x_3727_; 
v___x_3725_ = lean_nat_add(v_snd_3716_, v___x_3696_);
lean_dec(v_snd_3716_);
v___x_3726_ = lean_box(0);
v___x_3727_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_3696_, v___x_3726_, v_fst_3710_, v___y_3722_, v___y_3720_, v_nativePivots_3723_, v___y_3719_, v_fst_3715_, v___x_3725_, v___y_3718_, v___y_3721_, v___y_3724_);
lean_dec(v___y_3721_);
lean_dec(v___y_3718_);
v___y_3667_ = v___x_3727_;
goto v___jp_3666_;
}
v___jp_3728_:
{
lean_object* v___x_3738_; lean_object* v___x_3739_; uint64_t v___x_3740_; lean_object* v___x_3741_; lean_object* v_offset_3742_; uint8_t v___x_3743_; lean_object* v_data_3744_; lean_object* v___x_3745_; uint64_t v___x_3746_; uint64_t v___x_3747_; uint8_t v___x_3748_; lean_object* v___x_3749_; lean_object* v___x_3750_; lean_object* v___x_3751_; uint64_t v___x_3752_; uint64_t v___x_3753_; uint8_t v___x_3754_; lean_object* v___x_3755_; lean_object* v___x_3756_; lean_object* v___x_3757_; uint64_t v___x_3758_; uint64_t v___x_3759_; uint8_t v___x_3760_; lean_object* v___x_3761_; lean_object* v___x_3762_; lean_object* v___x_3763_; 
v___x_3738_ = lean_array_get_size(v_fst_3712_);
v___x_3739_ = lean_nat_add(v___x_3738_, v___x_3696_);
v___x_3740_ = lean_uint64_of_nat(v___x_3739_);
lean_dec(v___x_3739_);
v___x_3741_ = lean_unsigned_to_nat(4u);
v_offset_3742_ = lean_nat_mul(v___y_3730_, v___x_3741_);
lean_dec(v___y_3730_);
v___x_3743_ = lean_uint64_to_uint8(v___x_3740_);
v_data_3744_ = lean_byte_array_set(v_fst_3711_, v_offset_3742_, v___x_3743_);
v___x_3745_ = lean_nat_add(v_offset_3742_, v___x_3696_);
v___x_3746_ = 8ULL;
v___x_3747_ = lean_uint64_shift_right(v___x_3740_, v___x_3746_);
v___x_3748_ = lean_uint64_to_uint8(v___x_3747_);
v___x_3749_ = lean_byte_array_set(v_data_3744_, v___x_3745_, v___x_3748_);
lean_dec(v___x_3745_);
v___x_3750_ = lean_unsigned_to_nat(2u);
v___x_3751_ = lean_nat_add(v_offset_3742_, v___x_3750_);
v___x_3752_ = 16ULL;
v___x_3753_ = lean_uint64_shift_right(v___x_3740_, v___x_3752_);
v___x_3754_ = lean_uint64_to_uint8(v___x_3753_);
v___x_3755_ = lean_byte_array_set(v___x_3749_, v___x_3751_, v___x_3754_);
lean_dec(v___x_3751_);
v___x_3756_ = lean_unsigned_to_nat(3u);
v___x_3757_ = lean_nat_add(v_offset_3742_, v___x_3756_);
lean_dec(v_offset_3742_);
v___x_3758_ = 24ULL;
v___x_3759_ = lean_uint64_shift_right(v___x_3740_, v___x_3758_);
v___x_3760_ = lean_uint64_to_uint8(v___x_3759_);
v___x_3761_ = lean_byte_array_set(v___x_3755_, v___x_3757_, v___x_3760_);
lean_dec(v___x_3757_);
lean_inc(v___y_3734_);
lean_inc_ref(v___y_3729_);
v___x_3762_ = lean_alloc_ctor(0, 3, 9);
lean_ctor_set(v___x_3762_, 0, v___y_3729_);
lean_ctor_set(v___x_3762_, 1, v_snd_3736_);
lean_ctor_set(v___x_3762_, 2, v___y_3734_);
lean_ctor_set_uint8(v___x_3762_, sizeof(void*)*3 + 8, v___y_3731_);
lean_ctor_set_uint64(v___x_3762_, sizeof(void*)*3, v___y_3733_);
v___x_3763_ = lean_array_push(v_fst_3712_, v___x_3762_);
if (v_native_3647_ == 0)
{
lean_dec_ref(v___y_3729_);
v___y_3718_ = v___y_3732_;
v___y_3719_ = v_fst_3735_;
v___y_3720_ = v___x_3763_;
v___y_3721_ = v___y_3734_;
v___y_3722_ = v___x_3761_;
v_nativePivots_3723_ = v_fst_3713_;
v___y_3724_ = v___y_3737_;
goto v___jp_3717_;
}
else
{
lean_object* v_columns_3764_; lean_object* v_coefficients_3765_; lean_object* v___x_3766_; lean_object* v___x_3767_; 
v_columns_3764_ = lean_ctor_get(v___y_3729_, 0);
lean_inc_ref(v_columns_3764_);
v_coefficients_3765_ = lean_ctor_get(v___y_3729_, 1);
lean_inc_ref(v_coefficients_3765_);
lean_dec_ref(v___y_3729_);
lean_inc(v___y_3734_);
v___x_3766_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_3766_, 0, v_columns_3764_);
lean_ctor_set(v___x_3766_, 1, v_coefficients_3765_);
lean_ctor_set(v___x_3766_, 2, v___y_3734_);
v___x_3767_ = lean_array_push(v_fst_3713_, v___x_3766_);
v___y_3718_ = v___y_3732_;
v___y_3719_ = v_fst_3735_;
v___y_3720_ = v___x_3763_;
v___y_3721_ = v___y_3734_;
v___y_3722_ = v___x_3761_;
v_nativePivots_3723_ = v___x_3767_;
v___y_3724_ = v___y_3737_;
goto v___jp_3717_;
}
}
v___jp_3768_:
{
lean_object* v___x_3777_; lean_object* v_fst_3778_; 
v___x_3777_ = lp_Hex_Hex_Groebner_Matrix_inverse(v_field_3645_, v_ctx_3646_, v_limits_3642_, v___y_3776_, v___y_3774_);
v_fst_3778_ = lean_ctor_get(v___x_3777_, 0);
lean_inc(v_fst_3778_);
if (lean_obj_tag(v_fst_3778_) == 0)
{
lean_object* v_snd_3779_; lean_object* v_a_3780_; 
lean_dec_ref(v___y_3775_);
lean_dec_ref(v___y_3773_);
lean_dec(v___y_3772_);
lean_dec(v___y_3771_);
lean_dec(v___y_3769_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_fst_3710_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_3779_ = lean_ctor_get(v___x_3777_, 1);
lean_inc(v_snd_3779_);
lean_dec_ref(v___x_3777_);
v_a_3780_ = lean_ctor_get(v_fst_3778_, 0);
lean_inc(v_a_3780_);
lean_dec_ref_known(v_fst_3778_, 1);
v_a_3660_ = v_a_3780_;
v_snd_3661_ = v_snd_3779_;
goto v___jp_3659_;
}
else
{
lean_object* v_snd_3781_; lean_object* v_a_3782_; uint64_t v___x_3783_; lean_object* v___x_3784_; lean_object* v_fst_3785_; 
v_snd_3781_ = lean_ctor_get(v___x_3777_, 1);
lean_inc(v_snd_3781_);
lean_dec_ref(v___x_3777_);
v_a_3782_ = lean_ctor_get(v_fst_3778_, 0);
lean_inc(v_a_3782_);
lean_dec_ref_known(v_fst_3778_, 1);
v___x_3783_ = lean_unbox_uint64(v_a_3782_);
v___x_3784_ = lp_Hex_Hex_Groebner_Matrix_scaleSparse(v_field_3645_, v_ctx_3646_, v_limits_3642_, v___y_3775_, v___x_3783_, v_snd_3781_);
v_fst_3785_ = lean_ctor_get(v___x_3784_, 0);
lean_inc(v_fst_3785_);
if (lean_obj_tag(v_fst_3785_) == 0)
{
lean_object* v_snd_3786_; lean_object* v_a_3787_; 
lean_dec(v_a_3782_);
lean_dec_ref(v___y_3773_);
lean_dec(v___y_3772_);
lean_dec(v___y_3771_);
lean_dec(v___y_3769_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_fst_3710_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_3786_ = lean_ctor_get(v___x_3784_, 1);
lean_inc(v_snd_3786_);
lean_dec_ref(v___x_3784_);
v_a_3787_ = lean_ctor_get(v_fst_3785_, 0);
lean_inc(v_a_3787_);
lean_dec_ref_known(v_fst_3785_, 1);
v_a_3660_ = v_a_3787_;
v_snd_3661_ = v_snd_3786_;
goto v___jp_3659_;
}
else
{
lean_object* v_snd_3788_; lean_object* v_a_3789_; uint64_t v___x_3790_; uint64_t v___x_3791_; uint8_t v___x_3792_; 
v_snd_3788_ = lean_ctor_get(v___x_3784_, 1);
lean_inc(v_snd_3788_);
lean_dec_ref(v___x_3784_);
v_a_3789_ = lean_ctor_get(v_fst_3785_, 0);
lean_inc(v_a_3789_);
lean_dec_ref_known(v_fst_3785_, 1);
v___x_3790_ = 1ULL;
v___x_3791_ = lean_unbox_uint64(v_a_3782_);
v___x_3792_ = lean_uint64_dec_eq(v___x_3791_, v___x_3790_);
if (v___x_3792_ == 0)
{
if (lean_obj_tag(v___y_3771_) == 0)
{
uint64_t v___x_3793_; 
v___x_3793_ = lean_unbox_uint64(v_a_3782_);
lean_dec(v_a_3782_);
v___y_3729_ = v_a_3789_;
v___y_3730_ = v___y_3769_;
v___y_3731_ = v___y_3770_;
v___y_3732_ = v___y_3771_;
v___y_3733_ = v___x_3793_;
v___y_3734_ = v___y_3772_;
v_fst_3735_ = v___y_3773_;
v_snd_3736_ = v___y_3771_;
v___y_3737_ = v_snd_3788_;
goto v___jp_3728_;
}
else
{
lean_object* v_val_3794_; lean_object* v___x_3795_; uint64_t v___x_3796_; lean_object* v___x_3797_; lean_object* v_fst_3798_; 
v_val_3794_ = lean_ctor_get(v___y_3771_, 0);
lean_inc(v_val_3794_);
v___x_3795_ = lean_alloc_ctor(2, 1, 8);
lean_ctor_set(v___x_3795_, 0, v_val_3794_);
v___x_3796_ = lean_unbox_uint64(v_a_3782_);
lean_ctor_set_uint64(v___x_3795_, sizeof(void*)*1, v___x_3796_);
v___x_3797_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_3642_, v_provenance_3644_, v___y_3773_, v___x_3795_, v_snd_3788_);
v_fst_3798_ = lean_ctor_get(v___x_3797_, 0);
lean_inc(v_fst_3798_);
if (lean_obj_tag(v_fst_3798_) == 0)
{
lean_object* v_snd_3799_; lean_object* v_a_3800_; 
lean_dec_ref_known(v___y_3771_, 1);
lean_dec(v_a_3789_);
lean_dec(v_a_3782_);
lean_dec(v___y_3772_);
lean_dec(v___y_3769_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_fst_3710_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_3799_ = lean_ctor_get(v___x_3797_, 1);
lean_inc(v_snd_3799_);
lean_dec_ref(v___x_3797_);
v_a_3800_ = lean_ctor_get(v_fst_3798_, 0);
lean_inc(v_a_3800_);
lean_dec_ref_known(v_fst_3798_, 1);
v_a_3660_ = v_a_3800_;
v_snd_3661_ = v_snd_3799_;
goto v___jp_3659_;
}
else
{
lean_object* v_a_3801_; lean_object* v_snd_3802_; lean_object* v_fst_3803_; lean_object* v_snd_3804_; uint64_t v___x_3805_; 
v_a_3801_ = lean_ctor_get(v_fst_3798_, 0);
lean_inc(v_a_3801_);
lean_dec_ref_known(v_fst_3798_, 1);
v_snd_3802_ = lean_ctor_get(v___x_3797_, 1);
lean_inc(v_snd_3802_);
lean_dec_ref(v___x_3797_);
v_fst_3803_ = lean_ctor_get(v_a_3801_, 0);
lean_inc(v_fst_3803_);
v_snd_3804_ = lean_ctor_get(v_a_3801_, 1);
lean_inc(v_snd_3804_);
lean_dec(v_a_3801_);
v___x_3805_ = lean_unbox_uint64(v_a_3782_);
lean_dec(v_a_3782_);
v___y_3729_ = v_a_3789_;
v___y_3730_ = v___y_3769_;
v___y_3731_ = v___y_3770_;
v___y_3732_ = v___y_3771_;
v___y_3733_ = v___x_3805_;
v___y_3734_ = v___y_3772_;
v_fst_3735_ = v_fst_3803_;
v_snd_3736_ = v_snd_3804_;
v___y_3737_ = v_snd_3802_;
goto v___jp_3728_;
}
}
}
else
{
uint64_t v___x_3806_; 
v___x_3806_ = lean_unbox_uint64(v_a_3782_);
lean_dec(v_a_3782_);
lean_inc(v___y_3771_);
v___y_3729_ = v_a_3789_;
v___y_3730_ = v___y_3769_;
v___y_3731_ = v___y_3770_;
v___y_3732_ = v___y_3771_;
v___y_3733_ = v___x_3806_;
v___y_3734_ = v___y_3772_;
v_fst_3735_ = v___y_3773_;
v_snd_3736_ = v___y_3771_;
v___y_3737_ = v_snd_3788_;
goto v___jp_3728_;
}
}
}
}
v___jp_3807_:
{
uint64_t v___x_3817_; uint64_t v___x_3818_; uint64_t v___x_3819_; uint64_t v___x_3820_; 
v___x_3817_ = lean_uint8_to_uint64(v___y_3816_);
v___x_3818_ = 24ULL;
v___x_3819_ = lean_uint64_shift_left(v___x_3817_, v___x_3818_);
v___x_3820_ = lean_uint64_lor(v___y_3811_, v___x_3819_);
v___y_3769_ = v___y_3808_;
v___y_3770_ = v___y_3809_;
v___y_3771_ = v___y_3810_;
v___y_3772_ = v___y_3812_;
v___y_3773_ = v___y_3813_;
v___y_3774_ = v___y_3814_;
v___y_3775_ = v___y_3815_;
v___y_3776_ = v___x_3820_;
goto v___jp_3768_;
}
v___jp_3821_:
{
uint64_t v___x_3833_; uint64_t v___x_3834_; uint64_t v___x_3835_; uint64_t v___x_3836_; lean_object* v___x_3837_; uint8_t v___x_3838_; 
v___x_3833_ = lean_uint8_to_uint64(v___y_3832_);
v___x_3834_ = 16ULL;
v___x_3835_ = lean_uint64_shift_left(v___x_3833_, v___x_3834_);
v___x_3836_ = lean_uint64_lor(v___y_3829_, v___x_3835_);
v___x_3837_ = lean_unsigned_to_nat(3u);
v___x_3838_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3823_, v___x_3837_);
if (v___x_3838_ == 0)
{
lean_object* v___x_3839_; lean_object* v___x_3840_; uint8_t v___x_3841_; 
lean_dec_ref(v___y_3823_);
v___x_3839_ = lean_box(v___y_3830_);
v___x_3840_ = l_outOfBounds___redArg(v___x_3839_);
lean_dec(v___x_3839_);
v___x_3841_ = lean_unbox(v___x_3840_);
lean_dec(v___x_3840_);
v___y_3808_ = v___y_3822_;
v___y_3809_ = v___y_3824_;
v___y_3810_ = v___y_3825_;
v___y_3811_ = v___x_3836_;
v___y_3812_ = v___y_3826_;
v___y_3813_ = v___y_3827_;
v___y_3814_ = v___y_3828_;
v___y_3815_ = v___y_3831_;
v___y_3816_ = v___x_3841_;
goto v___jp_3807_;
}
else
{
uint8_t v___x_3842_; 
v___x_3842_ = lean_byte_array_fget(v___y_3823_, v___x_3837_);
lean_dec_ref(v___y_3823_);
v___y_3808_ = v___y_3822_;
v___y_3809_ = v___y_3824_;
v___y_3810_ = v___y_3825_;
v___y_3811_ = v___x_3836_;
v___y_3812_ = v___y_3826_;
v___y_3813_ = v___y_3827_;
v___y_3814_ = v___y_3828_;
v___y_3815_ = v___y_3831_;
v___y_3816_ = v___x_3842_;
goto v___jp_3807_;
}
}
v___jp_3843_:
{
uint64_t v___x_3855_; uint64_t v___x_3856_; uint64_t v___x_3857_; uint64_t v___x_3858_; lean_object* v___x_3859_; uint8_t v___x_3860_; 
v___x_3855_ = lean_uint8_to_uint64(v___y_3854_);
v___x_3856_ = 8ULL;
v___x_3857_ = lean_uint64_shift_left(v___x_3855_, v___x_3856_);
v___x_3858_ = lean_uint64_lor(v___y_3844_, v___x_3857_);
v___x_3859_ = lean_unsigned_to_nat(2u);
v___x_3860_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3847_, v___x_3859_);
if (v___x_3860_ == 0)
{
lean_object* v___x_3861_; lean_object* v___x_3862_; uint8_t v___x_3863_; 
v___x_3861_ = lean_box(v___y_3853_);
v___x_3862_ = l_outOfBounds___redArg(v___x_3861_);
lean_dec(v___x_3861_);
v___x_3863_ = lean_unbox(v___x_3862_);
lean_dec(v___x_3862_);
v___y_3822_ = v___y_3845_;
v___y_3823_ = v___y_3847_;
v___y_3824_ = v___y_3846_;
v___y_3825_ = v___y_3848_;
v___y_3826_ = v___y_3849_;
v___y_3827_ = v___y_3850_;
v___y_3828_ = v___y_3851_;
v___y_3829_ = v___x_3858_;
v___y_3830_ = v___y_3853_;
v___y_3831_ = v___y_3852_;
v___y_3832_ = v___x_3863_;
goto v___jp_3821_;
}
else
{
uint8_t v___x_3864_; 
v___x_3864_ = lean_byte_array_fget(v___y_3847_, v___x_3859_);
v___y_3822_ = v___y_3845_;
v___y_3823_ = v___y_3847_;
v___y_3824_ = v___y_3846_;
v___y_3825_ = v___y_3848_;
v___y_3826_ = v___y_3849_;
v___y_3827_ = v___y_3850_;
v___y_3828_ = v___y_3851_;
v___y_3829_ = v___x_3858_;
v___y_3830_ = v___y_3853_;
v___y_3831_ = v___y_3852_;
v___y_3832_ = v___x_3864_;
goto v___jp_3821_;
}
}
v___jp_3865_:
{
uint64_t v___x_3875_; uint64_t v___x_3876_; uint64_t v___x_3877_; uint64_t v___x_3878_; 
v___x_3875_ = lean_uint8_to_uint64(v___y_3874_);
v___x_3876_ = 8ULL;
v___x_3877_ = lean_uint64_shift_left(v___x_3875_, v___x_3876_);
v___x_3878_ = lean_uint64_lor(v___y_3866_, v___x_3877_);
v___y_3769_ = v___y_3867_;
v___y_3770_ = v___y_3868_;
v___y_3771_ = v___y_3869_;
v___y_3772_ = v___y_3870_;
v___y_3773_ = v___y_3871_;
v___y_3774_ = v___y_3872_;
v___y_3775_ = v___y_3873_;
v___y_3776_ = v___x_3878_;
goto v___jp_3768_;
}
v___jp_3879_:
{
uint64_t v_a_3890_; 
v_a_3890_ = lean_uint8_to_uint64(v___y_3889_);
switch(v_width_3648_)
{
case 0:
{
lean_dec_ref(v___y_3881_);
v___y_3769_ = v___y_3880_;
v___y_3770_ = v___y_3882_;
v___y_3771_ = v___y_3883_;
v___y_3772_ = v___y_3884_;
v___y_3773_ = v___y_3885_;
v___y_3774_ = v___y_3886_;
v___y_3775_ = v___y_3888_;
v___y_3776_ = v_a_3890_;
goto v___jp_3768_;
}
case 1:
{
uint8_t v___x_3891_; 
v___x_3891_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3881_, v___x_3696_);
if (v___x_3891_ == 0)
{
lean_object* v___x_3892_; lean_object* v___x_3893_; uint8_t v___x_3894_; 
lean_dec_ref(v___y_3881_);
v___x_3892_ = lean_box(v___y_3887_);
v___x_3893_ = l_outOfBounds___redArg(v___x_3892_);
lean_dec(v___x_3892_);
v___x_3894_ = lean_unbox(v___x_3893_);
lean_dec(v___x_3893_);
v___y_3866_ = v_a_3890_;
v___y_3867_ = v___y_3880_;
v___y_3868_ = v___y_3882_;
v___y_3869_ = v___y_3883_;
v___y_3870_ = v___y_3884_;
v___y_3871_ = v___y_3885_;
v___y_3872_ = v___y_3886_;
v___y_3873_ = v___y_3888_;
v___y_3874_ = v___x_3894_;
goto v___jp_3865_;
}
else
{
uint8_t v___x_3895_; 
v___x_3895_ = lean_byte_array_fget(v___y_3881_, v___x_3696_);
lean_dec_ref(v___y_3881_);
v___y_3866_ = v_a_3890_;
v___y_3867_ = v___y_3880_;
v___y_3868_ = v___y_3882_;
v___y_3869_ = v___y_3883_;
v___y_3870_ = v___y_3884_;
v___y_3871_ = v___y_3885_;
v___y_3872_ = v___y_3886_;
v___y_3873_ = v___y_3888_;
v___y_3874_ = v___x_3895_;
goto v___jp_3865_;
}
}
default: 
{
uint8_t v___x_3896_; 
v___x_3896_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3881_, v___x_3696_);
if (v___x_3896_ == 0)
{
lean_object* v___x_3897_; lean_object* v___x_3898_; uint8_t v___x_3899_; 
v___x_3897_ = lean_box(v___y_3887_);
v___x_3898_ = l_outOfBounds___redArg(v___x_3897_);
lean_dec(v___x_3897_);
v___x_3899_ = lean_unbox(v___x_3898_);
lean_dec(v___x_3898_);
v___y_3844_ = v_a_3890_;
v___y_3845_ = v___y_3880_;
v___y_3846_ = v___y_3882_;
v___y_3847_ = v___y_3881_;
v___y_3848_ = v___y_3883_;
v___y_3849_ = v___y_3884_;
v___y_3850_ = v___y_3885_;
v___y_3851_ = v___y_3886_;
v___y_3852_ = v___y_3888_;
v___y_3853_ = v___y_3887_;
v___y_3854_ = v___x_3899_;
goto v___jp_3843_;
}
else
{
uint8_t v___x_3900_; 
v___x_3900_ = lean_byte_array_fget(v___y_3881_, v___x_3696_);
v___y_3844_ = v_a_3890_;
v___y_3845_ = v___y_3880_;
v___y_3846_ = v___y_3882_;
v___y_3847_ = v___y_3881_;
v___y_3848_ = v___y_3883_;
v___y_3849_ = v___y_3884_;
v___y_3850_ = v___y_3885_;
v___y_3851_ = v___y_3886_;
v___y_3852_ = v___y_3888_;
v___y_3853_ = v___y_3887_;
v___y_3854_ = v___x_3900_;
goto v___jp_3843_;
}
}
}
}
v___jp_3901_:
{
if (v___y_3902_ == 0)
{
lean_object* v___x_3911_; lean_object* v___x_3912_; 
v___x_3911_ = lean_box(0);
v___x_3912_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_3696_, v___x_3911_, v___y_3903_, v___y_3904_, v___y_3908_, v_nativePivots_3909_, v___y_3906_, v_fst_3715_, v_snd_3716_, v___y_3907_, v___y_3905_, v___y_3910_);
lean_dec(v___y_3905_);
lean_dec(v___y_3907_);
v___y_3667_ = v___x_3912_;
goto v___jp_3666_;
}
else
{
lean_object* v___x_3913_; lean_object* v___x_3914_; lean_object* v___x_3915_; 
v___x_3913_ = lean_nat_add(v_snd_3716_, v___x_3696_);
lean_dec(v_snd_3716_);
v___x_3914_ = lean_box(0);
v___x_3915_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_3696_, v___x_3914_, v___y_3903_, v___y_3904_, v___y_3908_, v_nativePivots_3909_, v___y_3906_, v_fst_3715_, v___x_3913_, v___y_3907_, v___y_3905_, v___y_3910_);
lean_dec(v___y_3905_);
lean_dec(v___y_3907_);
v___y_3667_ = v___x_3915_;
goto v___jp_3666_;
}
}
v___jp_3916_:
{
lean_object* v_work_3923_; lean_object* v_inputEntries_3924_; lean_object* v_outputEntries_3925_; lean_object* v_packedBytes_3926_; lean_object* v_traceNodes_3927_; lean_object* v_processedRows_3928_; lean_object* v_reductions_3929_; lean_object* v_zeroRows_3930_; lean_object* v___x_3932_; uint8_t v_isShared_3933_; uint8_t v_isSharedCheck_3940_; 
v_work_3923_ = lean_ctor_get(v___y_3922_, 0);
v_inputEntries_3924_ = lean_ctor_get(v___y_3922_, 1);
v_outputEntries_3925_ = lean_ctor_get(v___y_3922_, 2);
v_packedBytes_3926_ = lean_ctor_get(v___y_3922_, 3);
v_traceNodes_3927_ = lean_ctor_get(v___y_3922_, 4);
v_processedRows_3928_ = lean_ctor_get(v___y_3922_, 5);
v_reductions_3929_ = lean_ctor_get(v___y_3922_, 6);
v_zeroRows_3930_ = lean_ctor_get(v___y_3922_, 7);
v_isSharedCheck_3940_ = !lean_is_exclusive(v___y_3922_);
if (v_isSharedCheck_3940_ == 0)
{
v___x_3932_ = v___y_3922_;
v_isShared_3933_ = v_isSharedCheck_3940_;
goto v_resetjp_3931_;
}
else
{
lean_inc(v_zeroRows_3930_);
lean_inc(v_reductions_3929_);
lean_inc(v_processedRows_3928_);
lean_inc(v_traceNodes_3927_);
lean_inc(v_packedBytes_3926_);
lean_inc(v_outputEntries_3925_);
lean_inc(v_inputEntries_3924_);
lean_inc(v_work_3923_);
lean_dec(v___y_3922_);
v___x_3932_ = lean_box(0);
v_isShared_3933_ = v_isSharedCheck_3940_;
goto v_resetjp_3931_;
}
v_resetjp_3931_:
{
lean_object* v___x_3934_; lean_object* v___x_3935_; lean_object* v___x_3937_; 
v___x_3934_ = lean_box(0);
v___x_3935_ = lean_nat_add(v_zeroRows_3930_, v___x_3696_);
lean_dec(v_zeroRows_3930_);
if (v_isShared_3933_ == 0)
{
lean_ctor_set(v___x_3932_, 7, v___x_3935_);
v___x_3937_ = v___x_3932_;
goto v_reusejp_3936_;
}
else
{
lean_object* v_reuseFailAlloc_3939_; 
v_reuseFailAlloc_3939_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_3939_, 0, v_work_3923_);
lean_ctor_set(v_reuseFailAlloc_3939_, 1, v_inputEntries_3924_);
lean_ctor_set(v_reuseFailAlloc_3939_, 2, v_outputEntries_3925_);
lean_ctor_set(v_reuseFailAlloc_3939_, 3, v_packedBytes_3926_);
lean_ctor_set(v_reuseFailAlloc_3939_, 4, v_traceNodes_3927_);
lean_ctor_set(v_reuseFailAlloc_3939_, 5, v_processedRows_3928_);
lean_ctor_set(v_reuseFailAlloc_3939_, 6, v_reductions_3929_);
lean_ctor_set(v_reuseFailAlloc_3939_, 7, v___x_3935_);
v___x_3937_ = v_reuseFailAlloc_3939_;
goto v_reusejp_3936_;
}
v_reusejp_3936_:
{
lean_object* v___x_3938_; 
v___x_3938_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_3696_, v___x_3934_, v___y_3917_, v_fst_3711_, v_fst_3712_, v_fst_3713_, v___y_3918_, v_remainders_3921_, v_snd_3716_, v___y_3920_, v___y_3919_, v___x_3937_);
lean_dec(v___y_3919_);
lean_dec(v___y_3920_);
v___y_3667_ = v___x_3938_;
goto v___jp_3666_;
}
}
}
v___jp_3941_:
{
lean_object* v_work_3947_; lean_object* v_inputEntries_3948_; lean_object* v_outputEntries_3949_; lean_object* v_packedBytes_3950_; lean_object* v_traceNodes_3951_; lean_object* v_processedRows_3952_; lean_object* v_reductions_3953_; lean_object* v_zeroRows_3954_; lean_object* v___x_3956_; uint8_t v_isShared_3957_; uint8_t v_isSharedCheck_3964_; 
v_work_3947_ = lean_ctor_get(v___y_3946_, 0);
v_inputEntries_3948_ = lean_ctor_get(v___y_3946_, 1);
v_outputEntries_3949_ = lean_ctor_get(v___y_3946_, 2);
v_packedBytes_3950_ = lean_ctor_get(v___y_3946_, 3);
v_traceNodes_3951_ = lean_ctor_get(v___y_3946_, 4);
v_processedRows_3952_ = lean_ctor_get(v___y_3946_, 5);
v_reductions_3953_ = lean_ctor_get(v___y_3946_, 6);
v_zeroRows_3954_ = lean_ctor_get(v___y_3946_, 7);
v_isSharedCheck_3964_ = !lean_is_exclusive(v___y_3946_);
if (v_isSharedCheck_3964_ == 0)
{
v___x_3956_ = v___y_3946_;
v_isShared_3957_ = v_isSharedCheck_3964_;
goto v_resetjp_3955_;
}
else
{
lean_inc(v_zeroRows_3954_);
lean_inc(v_reductions_3953_);
lean_inc(v_processedRows_3952_);
lean_inc(v_traceNodes_3951_);
lean_inc(v_packedBytes_3950_);
lean_inc(v_outputEntries_3949_);
lean_inc(v_inputEntries_3948_);
lean_inc(v_work_3947_);
lean_dec(v___y_3946_);
v___x_3956_ = lean_box(0);
v_isShared_3957_ = v_isSharedCheck_3964_;
goto v_resetjp_3955_;
}
v_resetjp_3955_:
{
lean_object* v___x_3958_; lean_object* v___x_3959_; lean_object* v___x_3961_; 
v___x_3958_ = lean_box(0);
v___x_3959_ = lean_nat_add(v_zeroRows_3954_, v___x_3696_);
lean_dec(v_zeroRows_3954_);
if (v_isShared_3957_ == 0)
{
lean_ctor_set(v___x_3956_, 7, v___x_3959_);
v___x_3961_ = v___x_3956_;
goto v_reusejp_3960_;
}
else
{
lean_object* v_reuseFailAlloc_3963_; 
v_reuseFailAlloc_3963_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_3963_, 0, v_work_3947_);
lean_ctor_set(v_reuseFailAlloc_3963_, 1, v_inputEntries_3948_);
lean_ctor_set(v_reuseFailAlloc_3963_, 2, v_outputEntries_3949_);
lean_ctor_set(v_reuseFailAlloc_3963_, 3, v_packedBytes_3950_);
lean_ctor_set(v_reuseFailAlloc_3963_, 4, v_traceNodes_3951_);
lean_ctor_set(v_reuseFailAlloc_3963_, 5, v_processedRows_3952_);
lean_ctor_set(v_reuseFailAlloc_3963_, 6, v_reductions_3953_);
lean_ctor_set(v_reuseFailAlloc_3963_, 7, v___x_3959_);
v___x_3961_ = v_reuseFailAlloc_3963_;
goto v_reusejp_3960_;
}
v_reusejp_3960_:
{
lean_object* v___x_3962_; 
v___x_3962_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_3696_, v___x_3958_, v_fst_3710_, v_fst_3711_, v_fst_3712_, v_fst_3713_, v___y_3944_, v_remainders_3945_, v_snd_3716_, v___y_3942_, v___y_3943_, v___x_3961_);
lean_dec(v___y_3943_);
lean_dec(v___y_3942_);
v___y_3667_ = v___x_3962_;
goto v___jp_3666_;
}
}
}
v___jp_3966_:
{
if (v___y_3976_ == 0)
{
uint8_t v___x_3977_; 
v___x_3977_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_3969_, v_reducerRank_3965_);
if (v___x_3977_ == 0)
{
lean_object* v___x_3978_; lean_object* v___x_3979_; uint8_t v___x_3980_; 
v___x_3978_ = lean_box(v___y_3975_);
v___x_3979_ = l_outOfBounds___redArg(v___x_3978_);
lean_dec(v___x_3978_);
v___x_3980_ = lean_unbox(v___x_3979_);
lean_dec(v___x_3979_);
v___y_3880_ = v___y_3967_;
v___y_3881_ = v___y_3969_;
v___y_3882_ = v___y_3968_;
v___y_3883_ = v___y_3970_;
v___y_3884_ = v___y_3971_;
v___y_3885_ = v___y_3972_;
v___y_3886_ = v___y_3973_;
v___y_3887_ = v___y_3975_;
v___y_3888_ = v___y_3974_;
v___y_3889_ = v___x_3980_;
goto v___jp_3879_;
}
else
{
uint8_t v___x_3981_; 
v___x_3981_ = lean_byte_array_fget(v___y_3969_, v_reducerRank_3965_);
v___y_3880_ = v___y_3967_;
v___y_3881_ = v___y_3969_;
v___y_3882_ = v___y_3968_;
v___y_3883_ = v___y_3970_;
v___y_3884_ = v___y_3971_;
v___y_3885_ = v___y_3972_;
v___y_3886_ = v___y_3973_;
v___y_3887_ = v___y_3975_;
v___y_3888_ = v___y_3974_;
v___y_3889_ = v___x_3981_;
goto v___jp_3879_;
}
}
else
{
size_t v_pos_3982_; uint8_t v___x_3983_; uint64_t v_a_3984_; 
v_pos_3982_ = ((size_t)0ULL);
v___x_3983_ = lean_byte_array_uget(v___y_3969_, v_pos_3982_);
v_a_3984_ = lean_uint8_to_uint64(v___x_3983_);
switch(v_width_3648_)
{
case 0:
{
lean_dec_ref(v___y_3969_);
v___y_3769_ = v___y_3967_;
v___y_3770_ = v___y_3968_;
v___y_3771_ = v___y_3970_;
v___y_3772_ = v___y_3971_;
v___y_3773_ = v___y_3972_;
v___y_3774_ = v___y_3973_;
v___y_3775_ = v___y_3974_;
v___y_3776_ = v_a_3984_;
goto v___jp_3768_;
}
case 1:
{
size_t v___x_3985_; uint8_t v___x_3986_; uint64_t v___x_3987_; uint64_t v___x_3988_; uint64_t v___x_3989_; uint64_t v___x_3990_; 
v___x_3985_ = ((size_t)1ULL);
v___x_3986_ = lean_byte_array_uget(v___y_3969_, v___x_3985_);
lean_dec_ref(v___y_3969_);
v___x_3987_ = lean_uint8_to_uint64(v___x_3986_);
v___x_3988_ = 8ULL;
v___x_3989_ = lean_uint64_shift_left(v___x_3987_, v___x_3988_);
v___x_3990_ = lean_uint64_lor(v_a_3984_, v___x_3989_);
v___y_3769_ = v___y_3967_;
v___y_3770_ = v___y_3968_;
v___y_3771_ = v___y_3970_;
v___y_3772_ = v___y_3971_;
v___y_3773_ = v___y_3972_;
v___y_3774_ = v___y_3973_;
v___y_3775_ = v___y_3974_;
v___y_3776_ = v___x_3990_;
goto v___jp_3768_;
}
default: 
{
size_t v___x_3991_; uint8_t v___x_3992_; uint64_t v___x_3993_; uint64_t v___x_3994_; uint64_t v___x_3995_; uint64_t v___x_3996_; size_t v___x_3997_; uint8_t v___x_3998_; uint64_t v___x_3999_; uint64_t v___x_4000_; uint64_t v___x_4001_; uint64_t v___x_4002_; size_t v___x_4003_; uint8_t v___x_4004_; uint64_t v___x_4005_; uint64_t v___x_4006_; uint64_t v___x_4007_; uint64_t v___x_4008_; 
v___x_3991_ = ((size_t)1ULL);
v___x_3992_ = lean_byte_array_uget(v___y_3969_, v___x_3991_);
v___x_3993_ = lean_uint8_to_uint64(v___x_3992_);
v___x_3994_ = 8ULL;
v___x_3995_ = lean_uint64_shift_left(v___x_3993_, v___x_3994_);
v___x_3996_ = lean_uint64_lor(v_a_3984_, v___x_3995_);
v___x_3997_ = ((size_t)2ULL);
v___x_3998_ = lean_byte_array_uget(v___y_3969_, v___x_3997_);
v___x_3999_ = lean_uint8_to_uint64(v___x_3998_);
v___x_4000_ = 16ULL;
v___x_4001_ = lean_uint64_shift_left(v___x_3999_, v___x_4000_);
v___x_4002_ = lean_uint64_lor(v___x_3996_, v___x_4001_);
v___x_4003_ = ((size_t)3ULL);
v___x_4004_ = lean_byte_array_uget(v___y_3969_, v___x_4003_);
lean_dec_ref(v___y_3969_);
v___x_4005_ = lean_uint8_to_uint64(v___x_4004_);
v___x_4006_ = 24ULL;
v___x_4007_ = lean_uint64_shift_left(v___x_4005_, v___x_4006_);
v___x_4008_ = lean_uint64_lor(v___x_4002_, v___x_4007_);
v___y_3769_ = v___y_3967_;
v___y_3770_ = v___y_3968_;
v___y_3771_ = v___y_3970_;
v___y_3772_ = v___y_3971_;
v___y_3773_ = v___y_3972_;
v___y_3774_ = v___y_3973_;
v___y_3775_ = v___y_3974_;
v___y_3776_ = v___x_4008_;
goto v___jp_3768_;
}
}
}
}
v___jp_4009_:
{
lean_object* v___x_4020_; uint8_t v___x_4021_; 
v___x_4020_ = lean_byte_array_size(v___y_4012_);
v___x_4021_ = lean_nat_dec_le(v___y_4019_, v___x_4020_);
if (v___x_4021_ == 0)
{
v___y_3967_ = v___y_4010_;
v___y_3968_ = v___y_4011_;
v___y_3969_ = v___y_4012_;
v___y_3970_ = v___y_4013_;
v___y_3971_ = v___y_4014_;
v___y_3972_ = v___y_4015_;
v___y_3973_ = v___y_4016_;
v___y_3974_ = v___y_4018_;
v___y_3975_ = v___y_4017_;
v___y_3976_ = v___x_4021_;
goto v___jp_3966_;
}
else
{
size_t v___x_4022_; lean_object* v___x_4023_; uint8_t v___x_4024_; 
v___x_4022_ = lean_usize_of_nat(v___y_4019_);
v___x_4023_ = lean_usize_to_nat(v___x_4022_);
v___x_4024_ = lean_nat_dec_eq(v___x_4023_, v___y_4019_);
lean_dec(v___x_4023_);
v___y_3967_ = v___y_4010_;
v___y_3968_ = v___y_4011_;
v___y_3969_ = v___y_4012_;
v___y_3970_ = v___y_4013_;
v___y_3971_ = v___y_4014_;
v___y_3972_ = v___y_4015_;
v___y_3973_ = v___y_4016_;
v___y_3974_ = v___y_4018_;
v___y_3975_ = v___y_4017_;
v___y_3976_ = v___x_4024_;
goto v___jp_3966_;
}
}
v___jp_4027_:
{
lean_object* v___x_4038_; lean_object* v___x_4039_; uint64_t v___x_4040_; lean_object* v___x_4041_; lean_object* v_offset_4042_; uint8_t v___x_4043_; lean_object* v_data_4044_; lean_object* v___x_4045_; uint64_t v___x_4046_; uint64_t v___x_4047_; uint8_t v___x_4048_; lean_object* v___x_4049_; lean_object* v___x_4050_; lean_object* v___x_4051_; uint64_t v___x_4052_; uint64_t v___x_4053_; uint8_t v___x_4054_; lean_object* v___x_4055_; lean_object* v___x_4056_; lean_object* v___x_4057_; uint64_t v___x_4058_; uint64_t v___x_4059_; uint8_t v___x_4060_; lean_object* v___x_4061_; lean_object* v___x_4062_; lean_object* v___x_4063_; 
v___x_4038_ = lean_array_get_size(v_fst_3712_);
v___x_4039_ = lean_nat_add(v___x_4038_, v___x_3696_);
v___x_4040_ = lean_uint64_of_nat(v___x_4039_);
lean_dec(v___x_4039_);
v___x_4041_ = lean_unsigned_to_nat(4u);
v_offset_4042_ = lean_nat_mul(v___y_4037_, v___x_4041_);
lean_dec(v___y_4037_);
v___x_4043_ = lean_uint64_to_uint8(v___x_4040_);
v_data_4044_ = lean_byte_array_set(v_fst_3711_, v_offset_4042_, v___x_4043_);
v___x_4045_ = lean_nat_add(v_offset_4042_, v___x_3696_);
v___x_4046_ = 8ULL;
v___x_4047_ = lean_uint64_shift_right(v___x_4040_, v___x_4046_);
v___x_4048_ = lean_uint64_to_uint8(v___x_4047_);
v___x_4049_ = lean_byte_array_set(v_data_4044_, v___x_4045_, v___x_4048_);
lean_dec(v___x_4045_);
v___x_4050_ = lean_unsigned_to_nat(2u);
v___x_4051_ = lean_nat_add(v_offset_4042_, v___x_4050_);
v___x_4052_ = 16ULL;
v___x_4053_ = lean_uint64_shift_right(v___x_4040_, v___x_4052_);
v___x_4054_ = lean_uint64_to_uint8(v___x_4053_);
v___x_4055_ = lean_byte_array_set(v___x_4049_, v___x_4051_, v___x_4054_);
lean_dec(v___x_4051_);
v___x_4056_ = lean_unsigned_to_nat(3u);
v___x_4057_ = lean_nat_add(v_offset_4042_, v___x_4056_);
lean_dec(v_offset_4042_);
v___x_4058_ = 24ULL;
v___x_4059_ = lean_uint64_shift_right(v___x_4040_, v___x_4058_);
v___x_4060_ = lean_uint64_to_uint8(v___x_4059_);
v___x_4061_ = lean_byte_array_set(v___x_4055_, v___x_4057_, v___x_4060_);
lean_dec(v___x_4057_);
lean_inc(v___y_4032_);
lean_inc_ref(v___y_4033_);
v___x_4062_ = lean_alloc_ctor(0, 3, 9);
lean_ctor_set(v___x_4062_, 0, v___y_4033_);
lean_ctor_set(v___x_4062_, 1, v___y_4030_);
lean_ctor_set(v___x_4062_, 2, v___y_4032_);
lean_ctor_set_uint8(v___x_4062_, sizeof(void*)*3 + 8, v___x_4026_);
lean_ctor_set_uint64(v___x_4062_, sizeof(void*)*3, v___y_4035_);
v___x_4063_ = lean_array_push(v_fst_3712_, v___x_4062_);
if (v_native_3647_ == 0)
{
lean_dec_ref(v___y_4033_);
v___y_3902_ = v___y_4028_;
v___y_3903_ = v___y_4029_;
v___y_3904_ = v___x_4061_;
v___y_3905_ = v___y_4032_;
v___y_3906_ = v___y_4034_;
v___y_3907_ = v___y_4036_;
v___y_3908_ = v___x_4063_;
v_nativePivots_3909_ = v_fst_3713_;
v___y_3910_ = v___y_4031_;
goto v___jp_3901_;
}
else
{
lean_object* v_columns_4064_; lean_object* v_coefficients_4065_; lean_object* v___x_4066_; lean_object* v___x_4067_; 
v_columns_4064_ = lean_ctor_get(v___y_4033_, 0);
lean_inc_ref(v_columns_4064_);
v_coefficients_4065_ = lean_ctor_get(v___y_4033_, 1);
lean_inc_ref(v_coefficients_4065_);
lean_dec_ref(v___y_4033_);
lean_inc(v___y_4032_);
v___x_4066_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_4066_, 0, v_columns_4064_);
lean_ctor_set(v___x_4066_, 1, v_coefficients_4065_);
lean_ctor_set(v___x_4066_, 2, v___y_4032_);
v___x_4067_ = lean_array_push(v_fst_3713_, v___x_4066_);
v___y_3902_ = v___y_4028_;
v___y_3903_ = v___y_4029_;
v___y_3904_ = v___x_4061_;
v___y_3905_ = v___y_4032_;
v___y_3906_ = v___y_4034_;
v___y_3907_ = v___y_4036_;
v___y_3908_ = v___x_4063_;
v_nativePivots_3909_ = v___x_4067_;
v___y_3910_ = v___y_4031_;
goto v___jp_3901_;
}
}
v___jp_4068_:
{
if (v_independent_3649_ == 0)
{
v___y_4028_ = v___y_4069_;
v___y_4029_ = v_dense_4076_;
v___y_4030_ = v___y_4070_;
v___y_4031_ = v___y_4078_;
v___y_4032_ = v___y_4071_;
v___y_4033_ = v_output_4077_;
v___y_4034_ = v___y_4073_;
v___y_4035_ = v___y_4072_;
v___y_4036_ = v___y_4074_;
v___y_4037_ = v___y_4075_;
goto v___jp_4027_;
}
else
{
if (v___x_4026_ == 0)
{
v___y_4028_ = v___y_4069_;
v___y_4029_ = v_dense_4076_;
v___y_4030_ = v___y_4070_;
v___y_4031_ = v___y_4078_;
v___y_4032_ = v___y_4071_;
v___y_4033_ = v_output_4077_;
v___y_4034_ = v___y_4073_;
v___y_4035_ = v___y_4072_;
v___y_4036_ = v___y_4074_;
v___y_4037_ = v___y_4075_;
goto v___jp_4027_;
}
else
{
lean_object* v___x_4079_; lean_object* v___x_4080_; lean_object* v___x_4081_; lean_object* v___x_4082_; 
lean_dec(v___y_4075_);
lean_inc(v___y_4071_);
v___x_4079_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_4079_, 0, v_output_4077_);
lean_ctor_set(v___x_4079_, 1, v___y_4070_);
lean_ctor_set(v___x_4079_, 2, v___y_4071_);
v___x_4080_ = lean_array_push(v_fst_3715_, v___x_4079_);
v___x_4081_ = lean_box(0);
v___x_4082_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_3696_, v___x_4081_, v_dense_4076_, v_fst_3711_, v_fst_3712_, v_fst_3713_, v___y_4073_, v___x_4080_, v_snd_3716_, v___y_4074_, v___y_4071_, v___y_4078_);
lean_dec(v___y_4071_);
lean_dec(v___y_4074_);
v___y_3667_ = v___x_4082_;
goto v___jp_3666_;
}
}
}
v___jp_4083_:
{
lean_object* v___x_4094_; lean_object* v___x_4095_; lean_object* v___x_4096_; lean_object* v___x_4097_; lean_object* v_fst_4098_; 
v___x_4094_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0);
v___x_4095_ = lean_nat_add(v___y_4089_, v___x_3696_);
v___x_4096_ = lean_nat_sub(v___x_4095_, v___y_4090_);
v___x_4097_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_3642_, v___x_4096_, v___y_4093_);
lean_dec(v___x_4096_);
v_fst_4098_ = lean_ctor_get(v___x_4097_, 0);
lean_inc(v_fst_4098_);
if (lean_obj_tag(v_fst_4098_) == 0)
{
lean_object* v_snd_4099_; lean_object* v_a_4100_; 
lean_dec(v___x_4095_);
lean_dec(v_snd_4092_);
lean_dec_ref(v_fst_4091_);
lean_dec(v___y_4090_);
lean_dec(v___y_4089_);
lean_dec(v___y_4088_);
lean_dec(v___y_4086_);
lean_dec_ref(v___y_4084_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_4099_ = lean_ctor_get(v___x_4097_, 1);
lean_inc(v_snd_4099_);
lean_dec_ref(v___x_4097_);
v_a_4100_ = lean_ctor_get(v_fst_4098_, 0);
lean_inc(v_a_4100_);
lean_dec_ref_known(v_fst_4098_, 1);
v_a_3660_ = v_a_4100_;
v_snd_3661_ = v_snd_4099_;
goto v___jp_3659_;
}
else
{
lean_dec_ref_known(v_fst_4098_, 1);
if (v_native_3647_ == 0)
{
lean_object* v_snd_4101_; lean_object* v___x_4103_; uint8_t v_isShared_4104_; uint8_t v_isSharedCheck_4117_; 
lean_dec(v___y_4089_);
v_snd_4101_ = lean_ctor_get(v___x_4097_, 1);
v_isSharedCheck_4117_ = !lean_is_exclusive(v___x_4097_);
if (v_isSharedCheck_4117_ == 0)
{
lean_object* v_unused_4118_; 
v_unused_4118_ = lean_ctor_get(v___x_4097_, 0);
lean_dec(v_unused_4118_);
v___x_4103_ = v___x_4097_;
v_isShared_4104_ = v_isSharedCheck_4117_;
goto v_resetjp_4102_;
}
else
{
lean_inc(v_snd_4101_);
lean_dec(v___x_4097_);
v___x_4103_ = lean_box(0);
v_isShared_4104_ = v_isSharedCheck_4117_;
goto v_resetjp_4102_;
}
v_resetjp_4102_:
{
lean_object* v___x_4105_; lean_object* v___x_4107_; 
lean_inc(v___y_4090_);
v___x_4105_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_4105_, 0, v___y_4090_);
lean_ctor_set(v___x_4105_, 1, v___x_4095_);
lean_ctor_set(v___x_4105_, 2, v___x_3696_);
if (v_isShared_4104_ == 0)
{
lean_ctor_set(v___x_4103_, 1, v___x_4094_);
lean_ctor_set(v___x_4103_, 0, v___y_4084_);
v___x_4107_ = v___x_4103_;
goto v_reusejp_4106_;
}
else
{
lean_object* v_reuseFailAlloc_4116_; 
v_reuseFailAlloc_4116_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4116_, 0, v___y_4084_);
lean_ctor_set(v_reuseFailAlloc_4116_, 1, v___x_4094_);
v___x_4107_ = v_reuseFailAlloc_4116_;
goto v_reusejp_4106_;
}
v_reusejp_4106_:
{
lean_object* v___x_4108_; lean_object* v_fst_4109_; 
lean_inc(v___y_4090_);
v___x_4108_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg(v_width_3648_, v_limits_3642_, v___y_3650_, v___y_4087_, v_field_3645_, v_ctx_3646_, v___x_4105_, v___x_4107_, v___y_4090_, v_snd_4101_);
lean_dec_ref_known(v___x_4105_, 3);
v_fst_4109_ = lean_ctor_get(v___x_4108_, 0);
lean_inc(v_fst_4109_);
if (lean_obj_tag(v_fst_4109_) == 0)
{
lean_object* v_snd_4110_; lean_object* v_a_4111_; 
lean_dec(v_snd_4092_);
lean_dec_ref(v_fst_4091_);
lean_dec(v___y_4090_);
lean_dec(v___y_4088_);
lean_dec(v___y_4086_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_4110_ = lean_ctor_get(v___x_4108_, 1);
lean_inc(v_snd_4110_);
lean_dec_ref(v___x_4108_);
v_a_4111_ = lean_ctor_get(v_fst_4109_, 0);
lean_inc(v_a_4111_);
lean_dec_ref_known(v_fst_4109_, 1);
v_a_3660_ = v_a_4111_;
v_snd_3661_ = v_snd_4110_;
goto v___jp_3659_;
}
else
{
lean_object* v_a_4112_; lean_object* v_snd_4113_; lean_object* v_fst_4114_; lean_object* v_snd_4115_; 
v_a_4112_ = lean_ctor_get(v_fst_4109_, 0);
lean_inc(v_a_4112_);
lean_dec_ref_known(v_fst_4109_, 1);
v_snd_4113_ = lean_ctor_get(v___x_4108_, 1);
lean_inc(v_snd_4113_);
lean_dec_ref(v___x_4108_);
v_fst_4114_ = lean_ctor_get(v_a_4112_, 0);
lean_inc(v_fst_4114_);
v_snd_4115_ = lean_ctor_get(v_a_4112_, 1);
lean_inc(v_snd_4115_);
lean_dec(v_a_4112_);
v___y_4069_ = v___y_4085_;
v___y_4070_ = v_snd_4092_;
v___y_4071_ = v___y_4086_;
v___y_4072_ = v___y_4087_;
v___y_4073_ = v_fst_4091_;
v___y_4074_ = v___y_4088_;
v___y_4075_ = v___y_4090_;
v_dense_4076_ = v_fst_4114_;
v_output_4077_ = v_snd_4115_;
v___y_4078_ = v_snd_4113_;
goto v___jp_4068_;
}
}
}
}
else
{
lean_object* v_snd_4119_; lean_object* v___x_4120_; lean_object* v_fst_4121_; 
lean_dec(v___x_4095_);
v_snd_4119_ = lean_ctor_get(v___x_4097_, 1);
lean_inc(v_snd_4119_);
lean_dec_ref(v___x_4097_);
lean_inc(v___y_4090_);
v___x_4120_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather(v_field_3645_, v_limits_3642_, v___y_4084_, v___y_4090_, v___y_4089_, v___y_4087_, v_snd_4119_);
lean_dec(v___y_4089_);
v_fst_4121_ = lean_ctor_get(v___x_4120_, 0);
lean_inc(v_fst_4121_);
if (lean_obj_tag(v_fst_4121_) == 0)
{
lean_object* v_snd_4122_; lean_object* v_a_4123_; 
lean_dec(v_snd_4092_);
lean_dec_ref(v_fst_4091_);
lean_dec(v___y_4090_);
lean_dec(v___y_4088_);
lean_dec(v___y_4086_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_4122_ = lean_ctor_get(v___x_4120_, 1);
lean_inc(v_snd_4122_);
lean_dec_ref(v___x_4120_);
v_a_4123_ = lean_ctor_get(v_fst_4121_, 0);
lean_inc(v_a_4123_);
lean_dec_ref_known(v_fst_4121_, 1);
v_a_3660_ = v_a_4123_;
v_snd_3661_ = v_snd_4122_;
goto v___jp_3659_;
}
else
{
lean_object* v_a_4124_; lean_object* v_snd_4125_; lean_object* v_fst_4126_; lean_object* v_snd_4127_; 
v_a_4124_ = lean_ctor_get(v_fst_4121_, 0);
lean_inc(v_a_4124_);
lean_dec_ref_known(v_fst_4121_, 1);
v_snd_4125_ = lean_ctor_get(v___x_4120_, 1);
lean_inc(v_snd_4125_);
lean_dec_ref(v___x_4120_);
v_fst_4126_ = lean_ctor_get(v_a_4124_, 0);
lean_inc(v_fst_4126_);
v_snd_4127_ = lean_ctor_get(v_a_4124_, 1);
lean_inc(v_snd_4127_);
lean_dec(v_a_4124_);
v___y_4069_ = v___y_4085_;
v___y_4070_ = v_snd_4092_;
v___y_4071_ = v___y_4086_;
v___y_4072_ = v___y_4087_;
v___y_4073_ = v_fst_4091_;
v___y_4074_ = v___y_4088_;
v___y_4075_ = v___y_4090_;
v_dense_4076_ = v_snd_4127_;
v_output_4077_ = v_fst_4126_;
v___y_4078_ = v_snd_4125_;
goto v___jp_4068_;
}
}
}
}
v___jp_4128_:
{
uint64_t v___x_4139_; uint8_t v___x_4140_; 
v___x_4139_ = 1ULL;
v___x_4140_ = lean_uint64_dec_eq(v_inv_4137_, v___x_4139_);
if (v___x_4140_ == 0)
{
if (lean_obj_tag(v___y_4133_) == 0)
{
lean_inc(v___y_4135_);
v___y_4084_ = v___y_4130_;
v___y_4085_ = v___y_4129_;
v___y_4086_ = v___y_4132_;
v___y_4087_ = v_inv_4137_;
v___y_4088_ = v___y_4133_;
v___y_4089_ = v___y_4134_;
v___y_4090_ = v___y_4136_;
v_fst_4091_ = v___y_4131_;
v_snd_4092_ = v___y_4135_;
v___y_4093_ = v___y_4138_;
goto v___jp_4083_;
}
else
{
lean_object* v_val_4141_; lean_object* v___x_4142_; lean_object* v___x_4143_; lean_object* v_fst_4144_; 
v_val_4141_ = lean_ctor_get(v___y_4133_, 0);
lean_inc(v_val_4141_);
v___x_4142_ = lean_alloc_ctor(2, 1, 8);
lean_ctor_set(v___x_4142_, 0, v_val_4141_);
lean_ctor_set_uint64(v___x_4142_, sizeof(void*)*1, v_inv_4137_);
v___x_4143_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_3642_, v_provenance_3644_, v___y_4131_, v___x_4142_, v___y_4138_);
v_fst_4144_ = lean_ctor_get(v___x_4143_, 0);
lean_inc(v_fst_4144_);
if (lean_obj_tag(v_fst_4144_) == 0)
{
lean_object* v_snd_4145_; lean_object* v_a_4146_; 
lean_dec_ref_known(v___y_4133_, 1);
lean_dec(v___y_4136_);
lean_dec(v___y_4134_);
lean_dec(v___y_4132_);
lean_dec_ref(v___y_4130_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_4145_ = lean_ctor_get(v___x_4143_, 1);
lean_inc(v_snd_4145_);
lean_dec_ref(v___x_4143_);
v_a_4146_ = lean_ctor_get(v_fst_4144_, 0);
lean_inc(v_a_4146_);
lean_dec_ref_known(v_fst_4144_, 1);
v_a_3660_ = v_a_4146_;
v_snd_3661_ = v_snd_4145_;
goto v___jp_3659_;
}
else
{
lean_object* v_a_4147_; lean_object* v_snd_4148_; lean_object* v_fst_4149_; lean_object* v_snd_4150_; 
v_a_4147_ = lean_ctor_get(v_fst_4144_, 0);
lean_inc(v_a_4147_);
lean_dec_ref_known(v_fst_4144_, 1);
v_snd_4148_ = lean_ctor_get(v___x_4143_, 1);
lean_inc(v_snd_4148_);
lean_dec_ref(v___x_4143_);
v_fst_4149_ = lean_ctor_get(v_a_4147_, 0);
lean_inc(v_fst_4149_);
v_snd_4150_ = lean_ctor_get(v_a_4147_, 1);
lean_inc(v_snd_4150_);
lean_dec(v_a_4147_);
v___y_4084_ = v___y_4130_;
v___y_4085_ = v___y_4129_;
v___y_4086_ = v___y_4132_;
v___y_4087_ = v_inv_4137_;
v___y_4088_ = v___y_4133_;
v___y_4089_ = v___y_4134_;
v___y_4090_ = v___y_4136_;
v_fst_4091_ = v_fst_4149_;
v_snd_4092_ = v_snd_4150_;
v___y_4093_ = v_snd_4148_;
goto v___jp_4083_;
}
}
}
else
{
lean_inc(v___y_4133_);
v___y_4084_ = v___y_4130_;
v___y_4085_ = v___y_4129_;
v___y_4086_ = v___y_4132_;
v___y_4087_ = v_inv_4137_;
v___y_4088_ = v___y_4133_;
v___y_4089_ = v___y_4134_;
v___y_4090_ = v___y_4136_;
v_fst_4091_ = v___y_4131_;
v_snd_4092_ = v___y_4133_;
v___y_4093_ = v___y_4138_;
goto v___jp_4083_;
}
}
v___jp_4151_:
{
lean_object* v___x_4162_; lean_object* v_fst_4163_; 
v___x_4162_ = lp_Hex_Hex_Groebner_Matrix_inverse(v_field_3645_, v_ctx_3646_, v_limits_3642_, v___y_4155_, v___y_4157_);
v_fst_4163_ = lean_ctor_get(v___x_4162_, 0);
lean_inc(v_fst_4163_);
if (lean_obj_tag(v_fst_4163_) == 0)
{
lean_object* v_snd_4164_; lean_object* v_a_4165_; 
lean_dec(v___y_4160_);
lean_dec(v___y_4159_);
lean_dec(v___y_4158_);
lean_dec(v___y_4156_);
lean_dec_ref(v___y_4154_);
lean_dec_ref(v___y_4152_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_4164_ = lean_ctor_get(v___x_4162_, 1);
lean_inc(v_snd_4164_);
lean_dec_ref(v___x_4162_);
v_a_4165_ = lean_ctor_get(v_fst_4163_, 0);
lean_inc(v_a_4165_);
lean_dec_ref_known(v_fst_4163_, 1);
v_a_3660_ = v_a_4165_;
v_snd_3661_ = v_snd_4164_;
goto v___jp_3659_;
}
else
{
lean_object* v_snd_4166_; lean_object* v_a_4167_; uint64_t v___x_4168_; 
v_snd_4166_ = lean_ctor_get(v___x_4162_, 1);
lean_inc(v_snd_4166_);
lean_dec_ref(v___x_4162_);
v_a_4167_ = lean_ctor_get(v_fst_4163_, 0);
lean_inc(v_a_4167_);
lean_dec_ref_known(v_fst_4163_, 1);
v___x_4168_ = lean_unbox_uint64(v_a_4167_);
lean_dec(v_a_4167_);
v___y_4129_ = v___y_4153_;
v___y_4130_ = v___y_4152_;
v___y_4131_ = v___y_4154_;
v___y_4132_ = v___y_4156_;
v___y_4133_ = v___y_4158_;
v___y_4134_ = v___y_4159_;
v___y_4135_ = v___y_4161_;
v___y_4136_ = v___y_4160_;
v_inv_4137_ = v___x_4168_;
v___y_4138_ = v_snd_4166_;
goto v___jp_4128_;
}
}
v___jp_4169_:
{
if (v_independent_3649_ == 0)
{
v___y_4152_ = v___y_4171_;
v___y_4153_ = v___y_4170_;
v___y_4154_ = v___y_4172_;
v___y_4155_ = v___y_4179_;
v___y_4156_ = v___y_4173_;
v___y_4157_ = v___y_4174_;
v___y_4158_ = v___y_4175_;
v___y_4159_ = v___y_4176_;
v___y_4160_ = v___y_4178_;
v___y_4161_ = v___y_4177_;
goto v___jp_4151_;
}
else
{
if (v___x_4026_ == 0)
{
v___y_4152_ = v___y_4171_;
v___y_4153_ = v___y_4170_;
v___y_4154_ = v___y_4172_;
v___y_4155_ = v___y_4179_;
v___y_4156_ = v___y_4173_;
v___y_4157_ = v___y_4174_;
v___y_4158_ = v___y_4175_;
v___y_4159_ = v___y_4176_;
v___y_4160_ = v___y_4178_;
v___y_4161_ = v___y_4177_;
goto v___jp_4151_;
}
else
{
uint64_t v___x_4180_; 
v___x_4180_ = 1ULL;
v___y_4129_ = v___y_4170_;
v___y_4130_ = v___y_4171_;
v___y_4131_ = v___y_4172_;
v___y_4132_ = v___y_4173_;
v___y_4133_ = v___y_4175_;
v___y_4134_ = v___y_4176_;
v___y_4135_ = v___y_4177_;
v___y_4136_ = v___y_4178_;
v_inv_4137_ = v___x_4180_;
v___y_4138_ = v___y_4174_;
goto v___jp_4128_;
}
}
}
v___jp_4181_:
{
uint64_t v___x_4193_; uint64_t v___x_4194_; uint64_t v___x_4195_; uint64_t v___x_4196_; 
v___x_4193_ = lean_uint8_to_uint64(v___y_4192_);
v___x_4194_ = 24ULL;
v___x_4195_ = lean_uint64_shift_left(v___x_4193_, v___x_4194_);
v___x_4196_ = lean_uint64_lor(v___y_4184_, v___x_4195_);
v___y_4170_ = v___y_4183_;
v___y_4171_ = v___y_4182_;
v___y_4172_ = v___y_4185_;
v___y_4173_ = v___y_4186_;
v___y_4174_ = v___y_4187_;
v___y_4175_ = v___y_4188_;
v___y_4176_ = v___y_4189_;
v___y_4177_ = v___y_4191_;
v___y_4178_ = v___y_4190_;
v___y_4179_ = v___x_4196_;
goto v___jp_4169_;
}
v___jp_4197_:
{
uint64_t v___x_4211_; uint64_t v___x_4212_; uint64_t v___x_4213_; uint64_t v___x_4214_; lean_object* v___x_4215_; lean_object* v___x_4216_; uint8_t v___x_4217_; 
v___x_4211_ = lean_uint8_to_uint64(v___y_4210_);
v___x_4212_ = 16ULL;
v___x_4213_ = lean_uint64_shift_left(v___x_4211_, v___x_4212_);
v___x_4214_ = lean_uint64_lor(v___y_4205_, v___x_4213_);
v___x_4215_ = lean_unsigned_to_nat(3u);
v___x_4216_ = lean_nat_add(v___y_4207_, v___x_4215_);
lean_dec(v___y_4207_);
v___x_4217_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4199_, v___x_4216_);
if (v___x_4217_ == 0)
{
lean_object* v___x_4218_; lean_object* v___x_4219_; uint8_t v___x_4220_; 
lean_dec(v___x_4216_);
v___x_4218_ = lean_box(v___y_4203_);
v___x_4219_ = l_outOfBounds___redArg(v___x_4218_);
lean_dec(v___x_4218_);
v___x_4220_ = lean_unbox(v___x_4219_);
lean_dec(v___x_4219_);
v___y_4182_ = v___y_4199_;
v___y_4183_ = v___y_4198_;
v___y_4184_ = v___x_4214_;
v___y_4185_ = v___y_4200_;
v___y_4186_ = v___y_4201_;
v___y_4187_ = v___y_4202_;
v___y_4188_ = v___y_4204_;
v___y_4189_ = v___y_4206_;
v___y_4190_ = v___y_4209_;
v___y_4191_ = v___y_4208_;
v___y_4192_ = v___x_4220_;
goto v___jp_4181_;
}
else
{
uint8_t v___x_4221_; 
v___x_4221_ = lean_byte_array_fget(v___y_4199_, v___x_4216_);
lean_dec(v___x_4216_);
v___y_4182_ = v___y_4199_;
v___y_4183_ = v___y_4198_;
v___y_4184_ = v___x_4214_;
v___y_4185_ = v___y_4200_;
v___y_4186_ = v___y_4201_;
v___y_4187_ = v___y_4202_;
v___y_4188_ = v___y_4204_;
v___y_4189_ = v___y_4206_;
v___y_4190_ = v___y_4209_;
v___y_4191_ = v___y_4208_;
v___y_4192_ = v___x_4221_;
goto v___jp_4181_;
}
}
v___jp_4222_:
{
uint64_t v___x_4236_; uint64_t v___x_4237_; uint64_t v___x_4238_; uint64_t v___x_4239_; lean_object* v___x_4240_; lean_object* v___x_4241_; uint8_t v___x_4242_; 
v___x_4236_ = lean_uint8_to_uint64(v___y_4235_);
v___x_4237_ = 8ULL;
v___x_4238_ = lean_uint64_shift_left(v___x_4236_, v___x_4237_);
v___x_4239_ = lean_uint64_lor(v___y_4225_, v___x_4238_);
v___x_4240_ = lean_unsigned_to_nat(2u);
v___x_4241_ = lean_nat_add(v___y_4234_, v___x_4240_);
v___x_4242_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4223_, v___x_4241_);
if (v___x_4242_ == 0)
{
lean_object* v___x_4243_; lean_object* v___x_4244_; uint8_t v___x_4245_; 
lean_dec(v___x_4241_);
v___x_4243_ = lean_box(v___y_4229_);
v___x_4244_ = l_outOfBounds___redArg(v___x_4243_);
lean_dec(v___x_4243_);
v___x_4245_ = lean_unbox(v___x_4244_);
lean_dec(v___x_4244_);
v___y_4198_ = v___y_4224_;
v___y_4199_ = v___y_4223_;
v___y_4200_ = v___y_4226_;
v___y_4201_ = v___y_4227_;
v___y_4202_ = v___y_4228_;
v___y_4203_ = v___y_4229_;
v___y_4204_ = v___y_4230_;
v___y_4205_ = v___x_4239_;
v___y_4206_ = v___y_4231_;
v___y_4207_ = v___y_4234_;
v___y_4208_ = v___y_4233_;
v___y_4209_ = v___y_4232_;
v___y_4210_ = v___x_4245_;
goto v___jp_4197_;
}
else
{
uint8_t v___x_4246_; 
v___x_4246_ = lean_byte_array_fget(v___y_4223_, v___x_4241_);
lean_dec(v___x_4241_);
v___y_4198_ = v___y_4224_;
v___y_4199_ = v___y_4223_;
v___y_4200_ = v___y_4226_;
v___y_4201_ = v___y_4227_;
v___y_4202_ = v___y_4228_;
v___y_4203_ = v___y_4229_;
v___y_4204_ = v___y_4230_;
v___y_4205_ = v___x_4239_;
v___y_4206_ = v___y_4231_;
v___y_4207_ = v___y_4234_;
v___y_4208_ = v___y_4233_;
v___y_4209_ = v___y_4232_;
v___y_4210_ = v___x_4246_;
goto v___jp_4197_;
}
}
v___jp_4247_:
{
uint64_t v___x_4259_; uint64_t v___x_4260_; uint64_t v___x_4261_; uint64_t v___x_4262_; 
v___x_4259_ = lean_uint8_to_uint64(v___y_4258_);
v___x_4260_ = 8ULL;
v___x_4261_ = lean_uint64_shift_left(v___x_4259_, v___x_4260_);
v___x_4262_ = lean_uint64_lor(v___y_4250_, v___x_4261_);
v___y_4170_ = v___y_4249_;
v___y_4171_ = v___y_4248_;
v___y_4172_ = v___y_4251_;
v___y_4173_ = v___y_4252_;
v___y_4174_ = v___y_4253_;
v___y_4175_ = v___y_4254_;
v___y_4176_ = v___y_4255_;
v___y_4177_ = v___y_4257_;
v___y_4178_ = v___y_4256_;
v___y_4179_ = v___x_4262_;
goto v___jp_4169_;
}
v___jp_4263_:
{
uint64_t v_a_4276_; 
v_a_4276_ = lean_uint8_to_uint64(v___y_4275_);
switch(v_width_3648_)
{
case 0:
{
lean_dec(v___y_4272_);
v___y_4170_ = v___y_4264_;
v___y_4171_ = v___y_4265_;
v___y_4172_ = v___y_4266_;
v___y_4173_ = v___y_4267_;
v___y_4174_ = v___y_4268_;
v___y_4175_ = v___y_4270_;
v___y_4176_ = v___y_4271_;
v___y_4177_ = v___y_4273_;
v___y_4178_ = v___y_4274_;
v___y_4179_ = v_a_4276_;
goto v___jp_4169_;
}
case 1:
{
lean_object* v___x_4277_; uint8_t v___x_4278_; 
v___x_4277_ = lean_nat_add(v___y_4272_, v___x_3696_);
lean_dec(v___y_4272_);
v___x_4278_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4265_, v___x_4277_);
if (v___x_4278_ == 0)
{
lean_object* v___x_4279_; lean_object* v___x_4280_; uint8_t v___x_4281_; 
lean_dec(v___x_4277_);
v___x_4279_ = lean_box(v___y_4269_);
v___x_4280_ = l_outOfBounds___redArg(v___x_4279_);
lean_dec(v___x_4279_);
v___x_4281_ = lean_unbox(v___x_4280_);
lean_dec(v___x_4280_);
v___y_4248_ = v___y_4265_;
v___y_4249_ = v___y_4264_;
v___y_4250_ = v_a_4276_;
v___y_4251_ = v___y_4266_;
v___y_4252_ = v___y_4267_;
v___y_4253_ = v___y_4268_;
v___y_4254_ = v___y_4270_;
v___y_4255_ = v___y_4271_;
v___y_4256_ = v___y_4274_;
v___y_4257_ = v___y_4273_;
v___y_4258_ = v___x_4281_;
goto v___jp_4247_;
}
else
{
uint8_t v___x_4282_; 
v___x_4282_ = lean_byte_array_fget(v___y_4265_, v___x_4277_);
lean_dec(v___x_4277_);
v___y_4248_ = v___y_4265_;
v___y_4249_ = v___y_4264_;
v___y_4250_ = v_a_4276_;
v___y_4251_ = v___y_4266_;
v___y_4252_ = v___y_4267_;
v___y_4253_ = v___y_4268_;
v___y_4254_ = v___y_4270_;
v___y_4255_ = v___y_4271_;
v___y_4256_ = v___y_4274_;
v___y_4257_ = v___y_4273_;
v___y_4258_ = v___x_4282_;
goto v___jp_4247_;
}
}
default: 
{
lean_object* v___x_4283_; uint8_t v___x_4284_; 
v___x_4283_ = lean_nat_add(v___y_4272_, v___x_3696_);
v___x_4284_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4265_, v___x_4283_);
if (v___x_4284_ == 0)
{
lean_object* v___x_4285_; lean_object* v___x_4286_; uint8_t v___x_4287_; 
lean_dec(v___x_4283_);
v___x_4285_ = lean_box(v___y_4269_);
v___x_4286_ = l_outOfBounds___redArg(v___x_4285_);
lean_dec(v___x_4285_);
v___x_4287_ = lean_unbox(v___x_4286_);
lean_dec(v___x_4286_);
v___y_4223_ = v___y_4265_;
v___y_4224_ = v___y_4264_;
v___y_4225_ = v_a_4276_;
v___y_4226_ = v___y_4266_;
v___y_4227_ = v___y_4267_;
v___y_4228_ = v___y_4268_;
v___y_4229_ = v___y_4269_;
v___y_4230_ = v___y_4270_;
v___y_4231_ = v___y_4271_;
v___y_4232_ = v___y_4274_;
v___y_4233_ = v___y_4273_;
v___y_4234_ = v___y_4272_;
v___y_4235_ = v___x_4287_;
goto v___jp_4222_;
}
else
{
uint8_t v___x_4288_; 
v___x_4288_ = lean_byte_array_fget(v___y_4265_, v___x_4283_);
lean_dec(v___x_4283_);
v___y_4223_ = v___y_4265_;
v___y_4224_ = v___y_4264_;
v___y_4225_ = v_a_4276_;
v___y_4226_ = v___y_4266_;
v___y_4227_ = v___y_4267_;
v___y_4228_ = v___y_4268_;
v___y_4229_ = v___y_4269_;
v___y_4230_ = v___y_4270_;
v___y_4231_ = v___y_4271_;
v___y_4232_ = v___y_4274_;
v___y_4233_ = v___y_4273_;
v___y_4234_ = v___y_4272_;
v___y_4235_ = v___x_4288_;
goto v___jp_4222_;
}
}
}
}
v___jp_4289_:
{
if (v___y_4301_ == 0)
{
uint8_t v___x_4302_; 
v___x_4302_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4291_, v___y_4300_);
if (v___x_4302_ == 0)
{
lean_object* v___x_4303_; lean_object* v___x_4304_; uint8_t v___x_4305_; 
v___x_4303_ = lean_box(v___y_4295_);
v___x_4304_ = l_outOfBounds___redArg(v___x_4303_);
lean_dec(v___x_4303_);
v___x_4305_ = lean_unbox(v___x_4304_);
lean_dec(v___x_4304_);
v___y_4264_ = v___y_4290_;
v___y_4265_ = v___y_4291_;
v___y_4266_ = v___y_4292_;
v___y_4267_ = v___y_4293_;
v___y_4268_ = v___y_4294_;
v___y_4269_ = v___y_4295_;
v___y_4270_ = v___y_4296_;
v___y_4271_ = v___y_4297_;
v___y_4272_ = v___y_4300_;
v___y_4273_ = v___y_4299_;
v___y_4274_ = v___y_4298_;
v___y_4275_ = v___x_4305_;
goto v___jp_4263_;
}
else
{
uint8_t v___x_4306_; 
v___x_4306_ = lean_byte_array_fget(v___y_4291_, v___y_4300_);
v___y_4264_ = v___y_4290_;
v___y_4265_ = v___y_4291_;
v___y_4266_ = v___y_4292_;
v___y_4267_ = v___y_4293_;
v___y_4268_ = v___y_4294_;
v___y_4269_ = v___y_4295_;
v___y_4270_ = v___y_4296_;
v___y_4271_ = v___y_4297_;
v___y_4272_ = v___y_4300_;
v___y_4273_ = v___y_4299_;
v___y_4274_ = v___y_4298_;
v___y_4275_ = v___x_4306_;
goto v___jp_4263_;
}
}
else
{
size_t v_pos_4307_; uint8_t v___x_4308_; uint64_t v_a_4309_; 
v_pos_4307_ = lean_usize_of_nat(v___y_4300_);
lean_dec(v___y_4300_);
v___x_4308_ = lean_byte_array_uget(v___y_4291_, v_pos_4307_);
v_a_4309_ = lean_uint8_to_uint64(v___x_4308_);
switch(v_width_3648_)
{
case 0:
{
v___y_4170_ = v___y_4290_;
v___y_4171_ = v___y_4291_;
v___y_4172_ = v___y_4292_;
v___y_4173_ = v___y_4293_;
v___y_4174_ = v___y_4294_;
v___y_4175_ = v___y_4296_;
v___y_4176_ = v___y_4297_;
v___y_4177_ = v___y_4299_;
v___y_4178_ = v___y_4298_;
v___y_4179_ = v_a_4309_;
goto v___jp_4169_;
}
case 1:
{
size_t v___x_4310_; size_t v___x_4311_; uint8_t v___x_4312_; uint64_t v___x_4313_; uint64_t v___x_4314_; uint64_t v___x_4315_; uint64_t v___x_4316_; 
v___x_4310_ = ((size_t)1ULL);
v___x_4311_ = lean_usize_add(v_pos_4307_, v___x_4310_);
v___x_4312_ = lean_byte_array_uget(v___y_4291_, v___x_4311_);
v___x_4313_ = lean_uint8_to_uint64(v___x_4312_);
v___x_4314_ = 8ULL;
v___x_4315_ = lean_uint64_shift_left(v___x_4313_, v___x_4314_);
v___x_4316_ = lean_uint64_lor(v_a_4309_, v___x_4315_);
v___y_4170_ = v___y_4290_;
v___y_4171_ = v___y_4291_;
v___y_4172_ = v___y_4292_;
v___y_4173_ = v___y_4293_;
v___y_4174_ = v___y_4294_;
v___y_4175_ = v___y_4296_;
v___y_4176_ = v___y_4297_;
v___y_4177_ = v___y_4299_;
v___y_4178_ = v___y_4298_;
v___y_4179_ = v___x_4316_;
goto v___jp_4169_;
}
default: 
{
size_t v___x_4317_; size_t v___x_4318_; uint8_t v___x_4319_; uint64_t v___x_4320_; uint64_t v___x_4321_; uint64_t v___x_4322_; uint64_t v___x_4323_; size_t v___x_4324_; size_t v___x_4325_; uint8_t v___x_4326_; uint64_t v___x_4327_; uint64_t v___x_4328_; uint64_t v___x_4329_; uint64_t v___x_4330_; size_t v___x_4331_; size_t v___x_4332_; uint8_t v___x_4333_; uint64_t v___x_4334_; uint64_t v___x_4335_; uint64_t v___x_4336_; uint64_t v___x_4337_; 
v___x_4317_ = ((size_t)1ULL);
v___x_4318_ = lean_usize_add(v_pos_4307_, v___x_4317_);
v___x_4319_ = lean_byte_array_uget(v___y_4291_, v___x_4318_);
v___x_4320_ = lean_uint8_to_uint64(v___x_4319_);
v___x_4321_ = 8ULL;
v___x_4322_ = lean_uint64_shift_left(v___x_4320_, v___x_4321_);
v___x_4323_ = lean_uint64_lor(v_a_4309_, v___x_4322_);
v___x_4324_ = ((size_t)2ULL);
v___x_4325_ = lean_usize_add(v_pos_4307_, v___x_4324_);
v___x_4326_ = lean_byte_array_uget(v___y_4291_, v___x_4325_);
v___x_4327_ = lean_uint8_to_uint64(v___x_4326_);
v___x_4328_ = 16ULL;
v___x_4329_ = lean_uint64_shift_left(v___x_4327_, v___x_4328_);
v___x_4330_ = lean_uint64_lor(v___x_4323_, v___x_4329_);
v___x_4331_ = ((size_t)3ULL);
v___x_4332_ = lean_usize_add(v_pos_4307_, v___x_4331_);
v___x_4333_ = lean_byte_array_uget(v___y_4291_, v___x_4332_);
v___x_4334_ = lean_uint8_to_uint64(v___x_4333_);
v___x_4335_ = 24ULL;
v___x_4336_ = lean_uint64_shift_left(v___x_4334_, v___x_4335_);
v___x_4337_ = lean_uint64_lor(v___x_4330_, v___x_4336_);
v___y_4170_ = v___y_4290_;
v___y_4171_ = v___y_4291_;
v___y_4172_ = v___y_4292_;
v___y_4173_ = v___y_4293_;
v___y_4174_ = v___y_4294_;
v___y_4175_ = v___y_4296_;
v___y_4176_ = v___y_4297_;
v___y_4177_ = v___y_4299_;
v___y_4178_ = v___y_4298_;
v___y_4179_ = v___x_4337_;
goto v___jp_4169_;
}
}
}
}
v___jp_4338_:
{
lean_object* v_offset_4350_; lean_object* v___x_4351_; lean_object* v___x_4352_; uint8_t v___x_4353_; 
v_offset_4350_ = lean_nat_mul(v___y_4348_, v___y_4349_);
v___x_4351_ = lean_nat_add(v_offset_4350_, v___y_4349_);
v___x_4352_ = lean_byte_array_size(v___y_4339_);
v___x_4353_ = lean_nat_dec_le(v___x_4351_, v___x_4352_);
if (v___x_4353_ == 0)
{
lean_dec(v___x_4351_);
v___y_4290_ = v___y_4340_;
v___y_4291_ = v___y_4339_;
v___y_4292_ = v___y_4341_;
v___y_4293_ = v___y_4342_;
v___y_4294_ = v___y_4343_;
v___y_4295_ = v___y_4344_;
v___y_4296_ = v___y_4345_;
v___y_4297_ = v___y_4346_;
v___y_4298_ = v___y_4348_;
v___y_4299_ = v___y_4347_;
v___y_4300_ = v_offset_4350_;
v___y_4301_ = v___x_4353_;
goto v___jp_4289_;
}
else
{
size_t v___x_4354_; lean_object* v___x_4355_; uint8_t v___x_4356_; 
v___x_4354_ = lean_usize_of_nat(v___x_4351_);
v___x_4355_ = lean_usize_to_nat(v___x_4354_);
v___x_4356_ = lean_nat_dec_eq(v___x_4355_, v___x_4351_);
lean_dec(v___x_4351_);
lean_dec(v___x_4355_);
v___y_4290_ = v___y_4340_;
v___y_4291_ = v___y_4339_;
v___y_4292_ = v___y_4341_;
v___y_4293_ = v___y_4342_;
v___y_4294_ = v___y_4343_;
v___y_4295_ = v___y_4344_;
v___y_4296_ = v___y_4345_;
v___y_4297_ = v___y_4346_;
v___y_4298_ = v___y_4348_;
v___y_4299_ = v___y_4347_;
v___y_4300_ = v_offset_4350_;
v___y_4301_ = v___x_4356_;
goto v___jp_4289_;
}
}
v___jp_4357_:
{
lean_object* v_leading_4362_; 
v_leading_4362_ = lean_ctor_get(v_scan_4360_, 3);
if (lean_obj_tag(v_leading_4362_) == 1)
{
lean_object* v_dense_4363_; lean_object* v_last_4364_; lean_object* v_trace_4365_; lean_object* v_node_4366_; lean_object* v_sugar_4367_; lean_object* v_val_4368_; uint8_t v___x_4369_; 
lean_inc_ref(v_leading_4362_);
v_dense_4363_ = lean_ctor_get(v_scan_4360_, 0);
lean_inc_ref(v_dense_4363_);
v_last_4364_ = lean_ctor_get(v_scan_4360_, 1);
lean_inc(v_last_4364_);
v_trace_4365_ = lean_ctor_get(v_scan_4360_, 4);
lean_inc_ref(v_trace_4365_);
v_node_4366_ = lean_ctor_get(v_scan_4360_, 5);
lean_inc(v_node_4366_);
v_sugar_4367_ = lean_ctor_get(v_scan_4360_, 6);
lean_inc(v_sugar_4367_);
lean_dec_ref(v_scan_4360_);
v_val_4368_ = lean_ctor_get(v_leading_4362_, 0);
lean_inc(v_val_4368_);
lean_dec_ref_known(v_leading_4362_, 1);
v___x_4369_ = 0;
switch(v_width_3648_)
{
case 0:
{
v___y_4339_ = v_dense_4363_;
v___y_4340_ = v___y_4358_;
v___y_4341_ = v_trace_4365_;
v___y_4342_ = v_sugar_4367_;
v___y_4343_ = v___y_4361_;
v___y_4344_ = v___x_4369_;
v___y_4345_ = v_node_4366_;
v___y_4346_ = v_last_4364_;
v___y_4347_ = v___y_4359_;
v___y_4348_ = v_val_4368_;
v___y_4349_ = v___x_3696_;
goto v___jp_4338_;
}
case 1:
{
lean_object* v___x_4370_; 
v___x_4370_ = lean_unsigned_to_nat(2u);
v___y_4339_ = v_dense_4363_;
v___y_4340_ = v___y_4358_;
v___y_4341_ = v_trace_4365_;
v___y_4342_ = v_sugar_4367_;
v___y_4343_ = v___y_4361_;
v___y_4344_ = v___x_4369_;
v___y_4345_ = v_node_4366_;
v___y_4346_ = v_last_4364_;
v___y_4347_ = v___y_4359_;
v___y_4348_ = v_val_4368_;
v___y_4349_ = v___x_4370_;
goto v___jp_4338_;
}
default: 
{
lean_object* v___x_4371_; 
v___x_4371_ = lean_unsigned_to_nat(4u);
v___y_4339_ = v_dense_4363_;
v___y_4340_ = v___y_4358_;
v___y_4341_ = v_trace_4365_;
v___y_4342_ = v_sugar_4367_;
v___y_4343_ = v___y_4361_;
v___y_4344_ = v___x_4369_;
v___y_4345_ = v_node_4366_;
v___y_4346_ = v_last_4364_;
v___y_4347_ = v___y_4359_;
v___y_4348_ = v_val_4368_;
v___y_4349_ = v___x_4371_;
goto v___jp_4338_;
}
}
}
else
{
if (v_independent_3649_ == 0)
{
lean_object* v_dense_4372_; lean_object* v_trace_4373_; lean_object* v_node_4374_; lean_object* v_sugar_4375_; 
v_dense_4372_ = lean_ctor_get(v_scan_4360_, 0);
lean_inc_ref(v_dense_4372_);
v_trace_4373_ = lean_ctor_get(v_scan_4360_, 4);
lean_inc_ref(v_trace_4373_);
v_node_4374_ = lean_ctor_get(v_scan_4360_, 5);
lean_inc(v_node_4374_);
v_sugar_4375_ = lean_ctor_get(v_scan_4360_, 6);
lean_inc(v_sugar_4375_);
lean_dec_ref(v_scan_4360_);
v___y_3917_ = v_dense_4372_;
v___y_3918_ = v_trace_4373_;
v___y_3919_ = v_sugar_4375_;
v___y_3920_ = v_node_4374_;
v_remainders_3921_ = v_fst_3715_;
v___y_3922_ = v___y_4361_;
goto v___jp_3916_;
}
else
{
if (v___x_4026_ == 0)
{
lean_object* v_dense_4376_; lean_object* v_trace_4377_; lean_object* v_node_4378_; lean_object* v_sugar_4379_; 
v_dense_4376_ = lean_ctor_get(v_scan_4360_, 0);
lean_inc_ref(v_dense_4376_);
v_trace_4377_ = lean_ctor_get(v_scan_4360_, 4);
lean_inc_ref(v_trace_4377_);
v_node_4378_ = lean_ctor_get(v_scan_4360_, 5);
lean_inc(v_node_4378_);
v_sugar_4379_ = lean_ctor_get(v_scan_4360_, 6);
lean_inc(v_sugar_4379_);
lean_dec_ref(v_scan_4360_);
v___y_3917_ = v_dense_4376_;
v___y_3918_ = v_trace_4377_;
v___y_3919_ = v_sugar_4379_;
v___y_3920_ = v_node_4378_;
v_remainders_3921_ = v_fst_3715_;
v___y_3922_ = v___y_4361_;
goto v___jp_3916_;
}
else
{
lean_object* v_dense_4380_; lean_object* v_trace_4381_; lean_object* v_node_4382_; lean_object* v_sugar_4383_; lean_object* v___x_4384_; lean_object* v___x_4385_; lean_object* v___x_4386_; 
v_dense_4380_ = lean_ctor_get(v_scan_4360_, 0);
lean_inc_ref(v_dense_4380_);
v_trace_4381_ = lean_ctor_get(v_scan_4360_, 4);
lean_inc_ref(v_trace_4381_);
v_node_4382_ = lean_ctor_get(v_scan_4360_, 5);
lean_inc_n(v_node_4382_, 2);
v_sugar_4383_ = lean_ctor_get(v_scan_4360_, 6);
lean_inc_n(v_sugar_4383_, 2);
lean_dec_ref(v_scan_4360_);
v___x_4384_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0);
v___x_4385_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_4385_, 0, v___x_4384_);
lean_ctor_set(v___x_4385_, 1, v_node_4382_);
lean_ctor_set(v___x_4385_, 2, v_sugar_4383_);
v___x_4386_ = lean_array_push(v_fst_3715_, v___x_4385_);
v___y_3917_ = v_dense_4380_;
v___y_3918_ = v_trace_4381_;
v___y_3919_ = v_sugar_4383_;
v___y_3920_ = v_node_4382_;
v_remainders_3921_ = v___x_4386_;
v___y_3922_ = v___y_4361_;
goto v___jp_3916_;
}
}
}
}
v___jp_4387_:
{
lean_object* v___x_4396_; lean_object* v___x_4397_; lean_object* v___x_4398_; 
v___x_4396_ = lean_uint64_to_nat(v___y_4395_);
v___x_4397_ = lean_box(0);
lean_inc(v___y_4389_);
v___x_4398_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_4398_, 0, v___y_4391_);
lean_ctor_set(v___x_4398_, 1, v___x_4396_);
lean_ctor_set(v___x_4398_, 2, v___y_4389_);
lean_ctor_set(v___x_4398_, 3, v___x_4397_);
lean_ctor_set(v___x_4398_, 4, v___y_4394_);
lean_ctor_set(v___x_4398_, 5, v___y_4392_);
lean_ctor_set(v___x_4398_, 6, v___y_4393_);
if (v_native_3647_ == 0)
{
lean_object* v___x_4399_; lean_object* v___x_4400_; lean_object* v_fst_4401_; 
lean_inc(v_columns_3651_);
lean_inc(v___y_4389_);
v___x_4399_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_4399_, 0, v___y_4389_);
lean_ctor_set(v___x_4399_, 1, v_columns_3651_);
lean_ctor_set(v___x_4399_, 2, v___x_3696_);
v___x_4400_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___redArg(v_fst_3712_, v_field_3645_, v_ctx_3646_, v_width_3648_, v_limits_3642_, v_provenance_3644_, v_fst_3711_, v___x_4399_, v___x_4398_, v___y_4389_, v___y_4390_);
lean_dec_ref_known(v___x_4399_, 3);
v_fst_4401_ = lean_ctor_get(v___x_4400_, 0);
lean_inc(v_fst_4401_);
if (lean_obj_tag(v_fst_4401_) == 0)
{
lean_object* v_snd_4402_; lean_object* v_a_4403_; 
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_4402_ = lean_ctor_get(v___x_4400_, 1);
lean_inc(v_snd_4402_);
lean_dec_ref(v___x_4400_);
v_a_4403_ = lean_ctor_get(v_fst_4401_, 0);
lean_inc(v_a_4403_);
lean_dec_ref_known(v_fst_4401_, 1);
v_a_3660_ = v_a_4403_;
v_snd_3661_ = v_snd_4402_;
goto v___jp_3659_;
}
else
{
lean_object* v_snd_4404_; lean_object* v_a_4405_; 
v_snd_4404_ = lean_ctor_get(v___x_4400_, 1);
lean_inc(v_snd_4404_);
lean_dec_ref(v___x_4400_);
v_a_4405_ = lean_ctor_get(v_fst_4401_, 0);
lean_inc(v_a_4405_);
lean_dec_ref_known(v_fst_4401_, 1);
v___y_4358_ = v___y_4388_;
v___y_4359_ = v___x_4397_;
v_scan_4360_ = v_a_4405_;
v___y_4361_ = v_snd_4404_;
goto v___jp_4357_;
}
}
else
{
lean_object* v___x_4406_; lean_object* v_fst_4407_; 
v___x_4406_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan(v_field_3645_, v_limits_3642_, v_columns_3651_, v_fst_3711_, v_fst_3712_, v_fst_3713_, v___y_4389_, v___x_4398_, v_provenance_3644_, v___y_4390_);
v_fst_4407_ = lean_ctor_get(v___x_4406_, 0);
lean_inc(v_fst_4407_);
if (lean_obj_tag(v_fst_4407_) == 0)
{
lean_object* v_snd_4408_; lean_object* v_a_4409_; 
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_4408_ = lean_ctor_get(v___x_4406_, 1);
lean_inc(v_snd_4408_);
lean_dec_ref(v___x_4406_);
v_a_4409_ = lean_ctor_get(v_fst_4407_, 0);
lean_inc(v_a_4409_);
lean_dec_ref_known(v_fst_4407_, 1);
v_a_3660_ = v_a_4409_;
v_snd_3661_ = v_snd_4408_;
goto v___jp_3659_;
}
else
{
lean_object* v_snd_4410_; lean_object* v_a_4411_; 
v_snd_4410_ = lean_ctor_get(v___x_4406_, 1);
lean_inc(v_snd_4410_);
lean_dec_ref(v___x_4406_);
v_a_4411_ = lean_ctor_get(v_fst_4407_, 0);
lean_inc(v_a_4411_);
lean_dec_ref_known(v_fst_4407_, 1);
v___y_4358_ = v___y_4388_;
v___y_4359_ = v___x_4397_;
v_scan_4360_ = v_a_4411_;
v___y_4361_ = v_snd_4410_;
goto v___jp_4357_;
}
}
}
v___jp_4412_:
{
uint64_t v___x_4422_; uint64_t v___x_4423_; uint64_t v___x_4424_; uint64_t v___x_4425_; 
v___x_4422_ = lean_uint8_to_uint64(v___y_4421_);
v___x_4423_ = 24ULL;
v___x_4424_ = lean_uint64_shift_left(v___x_4422_, v___x_4423_);
v___x_4425_ = lean_uint64_lor(v___y_4415_, v___x_4424_);
v___y_4388_ = v___y_4413_;
v___y_4389_ = v___y_4414_;
v___y_4390_ = v___y_4416_;
v___y_4391_ = v___y_4417_;
v___y_4392_ = v___y_4418_;
v___y_4393_ = v___y_4419_;
v___y_4394_ = v___y_4420_;
v___y_4395_ = v___x_4425_;
goto v___jp_4387_;
}
v___jp_4426_:
{
uint64_t v___x_4439_; uint64_t v___x_4440_; uint64_t v___x_4441_; uint64_t v___x_4442_; lean_object* v___x_4443_; lean_object* v___x_4444_; uint8_t v___x_4445_; 
v___x_4439_ = lean_uint8_to_uint64(v___y_4438_);
v___x_4440_ = 16ULL;
v___x_4441_ = lean_uint64_shift_left(v___x_4439_, v___x_4440_);
v___x_4442_ = lean_uint64_lor(v___y_4432_, v___x_4441_);
v___x_4443_ = lean_unsigned_to_nat(3u);
v___x_4444_ = lean_nat_add(v___y_4435_, v___x_4443_);
lean_dec(v___y_4435_);
v___x_4445_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4427_, v___x_4444_);
if (v___x_4445_ == 0)
{
lean_object* v___x_4446_; lean_object* v___x_4447_; uint8_t v___x_4448_; 
lean_dec(v___x_4444_);
lean_dec_ref(v___y_4427_);
v___x_4446_ = lean_box(v___y_4429_);
v___x_4447_ = l_outOfBounds___redArg(v___x_4446_);
lean_dec(v___x_4446_);
v___x_4448_ = lean_unbox(v___x_4447_);
lean_dec(v___x_4447_);
v___y_4413_ = v___y_4428_;
v___y_4414_ = v___y_4430_;
v___y_4415_ = v___x_4442_;
v___y_4416_ = v___y_4431_;
v___y_4417_ = v___y_4433_;
v___y_4418_ = v___y_4434_;
v___y_4419_ = v___y_4436_;
v___y_4420_ = v___y_4437_;
v___y_4421_ = v___x_4448_;
goto v___jp_4412_;
}
else
{
uint8_t v___x_4449_; 
v___x_4449_ = lean_byte_array_fget(v___y_4427_, v___x_4444_);
lean_dec(v___x_4444_);
lean_dec_ref(v___y_4427_);
v___y_4413_ = v___y_4428_;
v___y_4414_ = v___y_4430_;
v___y_4415_ = v___x_4442_;
v___y_4416_ = v___y_4431_;
v___y_4417_ = v___y_4433_;
v___y_4418_ = v___y_4434_;
v___y_4419_ = v___y_4436_;
v___y_4420_ = v___y_4437_;
v___y_4421_ = v___x_4449_;
goto v___jp_4412_;
}
}
v___jp_4450_:
{
uint64_t v___x_4463_; uint64_t v___x_4464_; uint64_t v___x_4465_; uint64_t v___x_4466_; lean_object* v___x_4467_; lean_object* v___x_4468_; uint8_t v___x_4469_; 
v___x_4463_ = lean_uint8_to_uint64(v___y_4462_);
v___x_4464_ = 8ULL;
v___x_4465_ = lean_uint64_shift_left(v___x_4463_, v___x_4464_);
v___x_4466_ = lean_uint64_lor(v___y_4456_, v___x_4465_);
v___x_4467_ = lean_unsigned_to_nat(2u);
v___x_4468_ = lean_nat_add(v___y_4460_, v___x_4467_);
v___x_4469_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4452_, v___x_4468_);
if (v___x_4469_ == 0)
{
lean_object* v___x_4470_; lean_object* v___x_4471_; uint8_t v___x_4472_; 
lean_dec(v___x_4468_);
v___x_4470_ = lean_box(v___y_4453_);
v___x_4471_ = l_outOfBounds___redArg(v___x_4470_);
lean_dec(v___x_4470_);
v___x_4472_ = lean_unbox(v___x_4471_);
lean_dec(v___x_4471_);
v___y_4427_ = v___y_4452_;
v___y_4428_ = v___y_4451_;
v___y_4429_ = v___y_4453_;
v___y_4430_ = v___y_4454_;
v___y_4431_ = v___y_4455_;
v___y_4432_ = v___x_4466_;
v___y_4433_ = v___y_4457_;
v___y_4434_ = v___y_4458_;
v___y_4435_ = v___y_4460_;
v___y_4436_ = v___y_4459_;
v___y_4437_ = v___y_4461_;
v___y_4438_ = v___x_4472_;
goto v___jp_4426_;
}
else
{
uint8_t v___x_4473_; 
v___x_4473_ = lean_byte_array_fget(v___y_4452_, v___x_4468_);
lean_dec(v___x_4468_);
v___y_4427_ = v___y_4452_;
v___y_4428_ = v___y_4451_;
v___y_4429_ = v___y_4453_;
v___y_4430_ = v___y_4454_;
v___y_4431_ = v___y_4455_;
v___y_4432_ = v___x_4466_;
v___y_4433_ = v___y_4457_;
v___y_4434_ = v___y_4458_;
v___y_4435_ = v___y_4460_;
v___y_4436_ = v___y_4459_;
v___y_4437_ = v___y_4461_;
v___y_4438_ = v___x_4473_;
goto v___jp_4426_;
}
}
v___jp_4474_:
{
uint64_t v_a_4486_; lean_object* v___x_4487_; uint8_t v___x_4488_; 
v_a_4486_ = lean_uint8_to_uint64(v___y_4485_);
v___x_4487_ = lean_nat_add(v___y_4482_, v___x_3696_);
v___x_4488_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4475_, v___x_4487_);
if (v___x_4488_ == 0)
{
lean_object* v___x_4489_; lean_object* v___x_4490_; uint8_t v___x_4491_; 
lean_dec(v___x_4487_);
v___x_4489_ = lean_box(v___y_4477_);
v___x_4490_ = l_outOfBounds___redArg(v___x_4489_);
lean_dec(v___x_4489_);
v___x_4491_ = lean_unbox(v___x_4490_);
lean_dec(v___x_4490_);
v___y_4451_ = v___y_4476_;
v___y_4452_ = v___y_4475_;
v___y_4453_ = v___y_4477_;
v___y_4454_ = v___y_4478_;
v___y_4455_ = v___y_4479_;
v___y_4456_ = v_a_4486_;
v___y_4457_ = v___y_4480_;
v___y_4458_ = v___y_4481_;
v___y_4459_ = v___y_4483_;
v___y_4460_ = v___y_4482_;
v___y_4461_ = v___y_4484_;
v___y_4462_ = v___x_4491_;
goto v___jp_4450_;
}
else
{
uint8_t v___x_4492_; 
v___x_4492_ = lean_byte_array_fget(v___y_4475_, v___x_4487_);
lean_dec(v___x_4487_);
v___y_4451_ = v___y_4476_;
v___y_4452_ = v___y_4475_;
v___y_4453_ = v___y_4477_;
v___y_4454_ = v___y_4478_;
v___y_4455_ = v___y_4479_;
v___y_4456_ = v_a_4486_;
v___y_4457_ = v___y_4480_;
v___y_4458_ = v___y_4481_;
v___y_4459_ = v___y_4483_;
v___y_4460_ = v___y_4482_;
v___y_4461_ = v___y_4484_;
v___y_4462_ = v___x_4492_;
goto v___jp_4450_;
}
}
v___jp_4493_:
{
if (v___y_4504_ == 0)
{
uint8_t v___x_4505_; 
v___x_4505_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4495_, v___y_4502_);
if (v___x_4505_ == 0)
{
lean_object* v___x_4506_; lean_object* v___x_4507_; uint8_t v___x_4508_; 
v___x_4506_ = lean_box(v___y_4496_);
v___x_4507_ = l_outOfBounds___redArg(v___x_4506_);
lean_dec(v___x_4506_);
v___x_4508_ = lean_unbox(v___x_4507_);
lean_dec(v___x_4507_);
v___y_4475_ = v___y_4495_;
v___y_4476_ = v___y_4494_;
v___y_4477_ = v___y_4496_;
v___y_4478_ = v___y_4497_;
v___y_4479_ = v___y_4498_;
v___y_4480_ = v___y_4499_;
v___y_4481_ = v___y_4500_;
v___y_4482_ = v___y_4502_;
v___y_4483_ = v___y_4501_;
v___y_4484_ = v___y_4503_;
v___y_4485_ = v___x_4508_;
goto v___jp_4474_;
}
else
{
uint8_t v___x_4509_; 
v___x_4509_ = lean_byte_array_fget(v___y_4495_, v___y_4502_);
v___y_4475_ = v___y_4495_;
v___y_4476_ = v___y_4494_;
v___y_4477_ = v___y_4496_;
v___y_4478_ = v___y_4497_;
v___y_4479_ = v___y_4498_;
v___y_4480_ = v___y_4499_;
v___y_4481_ = v___y_4500_;
v___y_4482_ = v___y_4502_;
v___y_4483_ = v___y_4501_;
v___y_4484_ = v___y_4503_;
v___y_4485_ = v___x_4509_;
goto v___jp_4474_;
}
}
else
{
size_t v_pos_4510_; uint8_t v___x_4511_; uint64_t v_a_4512_; size_t v___x_4513_; size_t v___x_4514_; uint8_t v___x_4515_; uint64_t v___x_4516_; uint64_t v___x_4517_; uint64_t v___x_4518_; uint64_t v___x_4519_; size_t v___x_4520_; size_t v___x_4521_; uint8_t v___x_4522_; uint64_t v___x_4523_; uint64_t v___x_4524_; uint64_t v___x_4525_; uint64_t v___x_4526_; size_t v___x_4527_; size_t v___x_4528_; uint8_t v___x_4529_; uint64_t v___x_4530_; uint64_t v___x_4531_; uint64_t v___x_4532_; uint64_t v___x_4533_; 
v_pos_4510_ = lean_usize_of_nat(v___y_4502_);
lean_dec(v___y_4502_);
v___x_4511_ = lean_byte_array_uget(v___y_4495_, v_pos_4510_);
v_a_4512_ = lean_uint8_to_uint64(v___x_4511_);
v___x_4513_ = ((size_t)1ULL);
v___x_4514_ = lean_usize_add(v_pos_4510_, v___x_4513_);
v___x_4515_ = lean_byte_array_uget(v___y_4495_, v___x_4514_);
v___x_4516_ = lean_uint8_to_uint64(v___x_4515_);
v___x_4517_ = 8ULL;
v___x_4518_ = lean_uint64_shift_left(v___x_4516_, v___x_4517_);
v___x_4519_ = lean_uint64_lor(v_a_4512_, v___x_4518_);
v___x_4520_ = ((size_t)2ULL);
v___x_4521_ = lean_usize_add(v_pos_4510_, v___x_4520_);
v___x_4522_ = lean_byte_array_uget(v___y_4495_, v___x_4521_);
v___x_4523_ = lean_uint8_to_uint64(v___x_4522_);
v___x_4524_ = 16ULL;
v___x_4525_ = lean_uint64_shift_left(v___x_4523_, v___x_4524_);
v___x_4526_ = lean_uint64_lor(v___x_4519_, v___x_4525_);
v___x_4527_ = ((size_t)3ULL);
v___x_4528_ = lean_usize_add(v_pos_4510_, v___x_4527_);
v___x_4529_ = lean_byte_array_uget(v___y_4495_, v___x_4528_);
lean_dec_ref(v___y_4495_);
v___x_4530_ = lean_uint8_to_uint64(v___x_4529_);
v___x_4531_ = 24ULL;
v___x_4532_ = lean_uint64_shift_left(v___x_4530_, v___x_4531_);
v___x_4533_ = lean_uint64_lor(v___x_4526_, v___x_4532_);
v___y_4388_ = v___y_4494_;
v___y_4389_ = v___y_4497_;
v___y_4390_ = v___y_4498_;
v___y_4391_ = v___y_4499_;
v___y_4392_ = v___y_4500_;
v___y_4393_ = v___y_4501_;
v___y_4394_ = v___y_4503_;
v___y_4395_ = v___x_4533_;
goto v___jp_4387_;
}
}
v___jp_4534_:
{
lean_object* v___x_4544_; lean_object* v_fst_4545_; 
v___x_4544_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_3642_, v___y_4539_, v___y_4542_);
v_fst_4545_ = lean_ctor_get(v___x_4544_, 0);
lean_inc(v_fst_4545_);
if (lean_obj_tag(v_fst_4545_) == 0)
{
lean_object* v_snd_4546_; lean_object* v_a_4547_; 
lean_dec_ref(v___y_4543_);
lean_dec_ref(v___y_4541_);
lean_dec(v___y_4540_);
lean_dec(v___y_4539_);
lean_dec(v___y_4538_);
lean_dec(v___y_4537_);
lean_dec_ref(v___y_4536_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_fst_3710_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_4546_ = lean_ctor_get(v___x_4544_, 1);
lean_inc(v_snd_4546_);
lean_dec_ref(v___x_4544_);
v_a_4547_ = lean_ctor_get(v_fst_4545_, 0);
lean_inc(v_a_4547_);
lean_dec_ref_known(v_fst_4545_, 1);
v_a_3660_ = v_a_4547_;
v_snd_3661_ = v_snd_4546_;
goto v___jp_3659_;
}
else
{
lean_object* v_snd_4548_; lean_object* v___x_4549_; lean_object* v___x_4550_; lean_object* v_fst_4551_; lean_object* v_snd_4552_; lean_object* v_a_4553_; lean_object* v___x_4554_; uint8_t v___x_4555_; lean_object* v___x_4556_; lean_object* v_offset_4557_; lean_object* v___x_4558_; lean_object* v___x_4559_; uint8_t v___x_4560_; 
lean_dec_ref_known(v_fst_4545_, 1);
v_snd_4548_ = lean_ctor_get(v___x_4544_, 1);
lean_inc(v_snd_4548_);
lean_dec_ref(v___x_4544_);
lean_inc(v___y_4539_);
v___x_4549_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_4549_, 0, v_reducerRank_3965_);
lean_ctor_set(v___x_4549_, 1, v___y_4539_);
lean_ctor_set(v___x_4549_, 2, v___x_3696_);
v___x_4550_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___redArg(v_width_3648_, v___y_4543_, v___y_4536_, v___x_4549_, v_fst_3710_, v_reducerRank_3965_, v_snd_4548_);
lean_dec_ref_known(v___x_4549_, 3);
lean_dec_ref(v___y_4543_);
v_fst_4551_ = lean_ctor_get(v___x_4550_, 0);
lean_inc(v_fst_4551_);
v_snd_4552_ = lean_ctor_get(v___x_4550_, 1);
lean_inc(v_snd_4552_);
lean_dec_ref(v___x_4550_);
v_a_4553_ = lean_ctor_get(v_fst_4551_, 0);
lean_inc(v_a_4553_);
lean_dec(v_fst_4551_);
v___x_4554_ = lean_nat_sub(v___y_4539_, v___x_3696_);
lean_dec(v___y_4539_);
v___x_4555_ = 0;
v___x_4556_ = lean_unsigned_to_nat(4u);
v_offset_4557_ = lean_nat_mul(v___x_4554_, v___x_4556_);
lean_dec(v___x_4554_);
v___x_4558_ = lean_nat_add(v_offset_4557_, v___x_4556_);
v___x_4559_ = lean_byte_array_size(v___y_4536_);
v___x_4560_ = lean_nat_dec_le(v___x_4558_, v___x_4559_);
if (v___x_4560_ == 0)
{
lean_dec(v___x_4558_);
v___y_4494_ = v___y_4535_;
v___y_4495_ = v___y_4536_;
v___y_4496_ = v___x_4555_;
v___y_4497_ = v___y_4537_;
v___y_4498_ = v_snd_4552_;
v___y_4499_ = v_a_4553_;
v___y_4500_ = v___y_4538_;
v___y_4501_ = v___y_4540_;
v___y_4502_ = v_offset_4557_;
v___y_4503_ = v___y_4541_;
v___y_4504_ = v___x_4560_;
goto v___jp_4493_;
}
else
{
size_t v___x_4561_; lean_object* v___x_4562_; uint8_t v___x_4563_; 
v___x_4561_ = lean_usize_of_nat(v___x_4558_);
v___x_4562_ = lean_usize_to_nat(v___x_4561_);
v___x_4563_ = lean_nat_dec_eq(v___x_4562_, v___x_4558_);
lean_dec(v___x_4558_);
lean_dec(v___x_4562_);
v___y_4494_ = v___y_4535_;
v___y_4495_ = v___y_4536_;
v___y_4496_ = v___x_4555_;
v___y_4497_ = v___y_4537_;
v___y_4498_ = v_snd_4552_;
v___y_4499_ = v_a_4553_;
v___y_4500_ = v___y_4538_;
v___y_4501_ = v___y_4540_;
v___y_4502_ = v_offset_4557_;
v___y_4503_ = v___y_4541_;
v___y_4504_ = v___x_4563_;
goto v___jp_4493_;
}
}
}
v___jp_4564_:
{
uint64_t v___x_4577_; uint8_t v___x_4578_; 
v___x_4577_ = 0ULL;
v___x_4578_ = lean_uint64_dec_eq(v___y_4576_, v___x_4577_);
if (v___x_4578_ == 0)
{
lean_dec_ref(v___y_4569_);
v___y_4535_ = v___y_4566_;
v___y_4536_ = v___y_4565_;
v___y_4537_ = v___y_4567_;
v___y_4538_ = v___y_4571_;
v___y_4539_ = v___y_4570_;
v___y_4540_ = v___y_4572_;
v___y_4541_ = v___y_4573_;
v___y_4542_ = v___y_4574_;
v___y_4543_ = v___y_4575_;
goto v___jp_4534_;
}
else
{
uint8_t v___x_4579_; 
lean_dec(v___y_4570_);
lean_dec_ref(v___y_4565_);
v___x_4579_ = 0;
switch(v_width_3648_)
{
case 0:
{
v___y_4010_ = v___y_4567_;
v___y_4011_ = v___y_4568_;
v___y_4012_ = v___y_4569_;
v___y_4013_ = v___y_4571_;
v___y_4014_ = v___y_4572_;
v___y_4015_ = v___y_4573_;
v___y_4016_ = v___y_4574_;
v___y_4017_ = v___x_4579_;
v___y_4018_ = v___y_4575_;
v___y_4019_ = v___x_3696_;
goto v___jp_4009_;
}
case 1:
{
lean_object* v___x_4580_; 
v___x_4580_ = lean_unsigned_to_nat(2u);
v___y_4010_ = v___y_4567_;
v___y_4011_ = v___y_4568_;
v___y_4012_ = v___y_4569_;
v___y_4013_ = v___y_4571_;
v___y_4014_ = v___y_4572_;
v___y_4015_ = v___y_4573_;
v___y_4016_ = v___y_4574_;
v___y_4017_ = v___x_4579_;
v___y_4018_ = v___y_4575_;
v___y_4019_ = v___x_4580_;
goto v___jp_4009_;
}
default: 
{
lean_object* v___x_4581_; 
v___x_4581_ = lean_unsigned_to_nat(4u);
v___y_4010_ = v___y_4567_;
v___y_4011_ = v___y_4568_;
v___y_4012_ = v___y_4569_;
v___y_4013_ = v___y_4571_;
v___y_4014_ = v___y_4572_;
v___y_4015_ = v___y_4573_;
v___y_4016_ = v___y_4574_;
v___y_4017_ = v___x_4579_;
v___y_4018_ = v___y_4575_;
v___y_4019_ = v___x_4581_;
goto v___jp_4009_;
}
}
}
}
v___jp_4582_:
{
uint64_t v___x_4596_; uint64_t v___x_4597_; uint64_t v___x_4598_; uint64_t v___x_4599_; 
v___x_4596_ = lean_uint8_to_uint64(v___y_4595_);
v___x_4597_ = 24ULL;
v___x_4598_ = lean_uint64_shift_left(v___x_4596_, v___x_4597_);
v___x_4599_ = lean_uint64_lor(v___y_4585_, v___x_4598_);
v___y_4565_ = v___y_4584_;
v___y_4566_ = v___y_4583_;
v___y_4567_ = v___y_4586_;
v___y_4568_ = v___y_4588_;
v___y_4569_ = v___y_4587_;
v___y_4570_ = v___y_4590_;
v___y_4571_ = v___y_4589_;
v___y_4572_ = v___y_4591_;
v___y_4573_ = v___y_4592_;
v___y_4574_ = v___y_4593_;
v___y_4575_ = v___y_4594_;
v___y_4576_ = v___x_4599_;
goto v___jp_4564_;
}
v___jp_4600_:
{
uint64_t v___x_4616_; uint64_t v___x_4617_; uint64_t v___x_4618_; uint64_t v___x_4619_; lean_object* v___x_4620_; lean_object* v___x_4621_; uint8_t v___x_4622_; 
v___x_4616_ = lean_uint8_to_uint64(v___y_4615_);
v___x_4617_ = 16ULL;
v___x_4618_ = lean_uint64_shift_left(v___x_4616_, v___x_4617_);
v___x_4619_ = lean_uint64_lor(v___y_4614_, v___x_4618_);
v___x_4620_ = lean_unsigned_to_nat(3u);
v___x_4621_ = lean_nat_add(v___y_4602_, v___x_4620_);
lean_dec(v___y_4602_);
v___x_4622_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_3711_, v___x_4621_);
if (v___x_4622_ == 0)
{
lean_object* v___x_4623_; lean_object* v___x_4624_; uint8_t v___x_4625_; 
lean_dec(v___x_4621_);
v___x_4623_ = lean_box(v___y_4609_);
v___x_4624_ = l_outOfBounds___redArg(v___x_4623_);
lean_dec(v___x_4623_);
v___x_4625_ = lean_unbox(v___x_4624_);
lean_dec(v___x_4624_);
v___y_4583_ = v___y_4608_;
v___y_4584_ = v___y_4601_;
v___y_4585_ = v___x_4619_;
v___y_4586_ = v___y_4603_;
v___y_4587_ = v___y_4604_;
v___y_4588_ = v___y_4610_;
v___y_4589_ = v___y_4605_;
v___y_4590_ = v___y_4611_;
v___y_4591_ = v___y_4612_;
v___y_4592_ = v___y_4613_;
v___y_4593_ = v___y_4606_;
v___y_4594_ = v___y_4607_;
v___y_4595_ = v___x_4625_;
goto v___jp_4582_;
}
else
{
uint8_t v___x_4626_; 
v___x_4626_ = lean_byte_array_fget(v_fst_3711_, v___x_4621_);
lean_dec(v___x_4621_);
v___y_4583_ = v___y_4608_;
v___y_4584_ = v___y_4601_;
v___y_4585_ = v___x_4619_;
v___y_4586_ = v___y_4603_;
v___y_4587_ = v___y_4604_;
v___y_4588_ = v___y_4610_;
v___y_4589_ = v___y_4605_;
v___y_4590_ = v___y_4611_;
v___y_4591_ = v___y_4612_;
v___y_4592_ = v___y_4613_;
v___y_4593_ = v___y_4606_;
v___y_4594_ = v___y_4607_;
v___y_4595_ = v___x_4626_;
goto v___jp_4582_;
}
}
v___jp_4627_:
{
uint64_t v___x_4643_; uint64_t v___x_4644_; uint64_t v___x_4645_; uint64_t v___x_4646_; lean_object* v___x_4647_; lean_object* v___x_4648_; uint8_t v___x_4649_; 
v___x_4643_ = lean_uint8_to_uint64(v___y_4642_);
v___x_4644_ = 8ULL;
v___x_4645_ = lean_uint64_shift_left(v___x_4643_, v___x_4644_);
v___x_4646_ = lean_uint64_lor(v___y_4636_, v___x_4645_);
v___x_4647_ = lean_unsigned_to_nat(2u);
v___x_4648_ = lean_nat_add(v___y_4629_, v___x_4647_);
v___x_4649_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_3711_, v___x_4648_);
if (v___x_4649_ == 0)
{
lean_object* v___x_4650_; lean_object* v___x_4651_; uint8_t v___x_4652_; 
lean_dec(v___x_4648_);
v___x_4650_ = lean_box(v___y_4637_);
v___x_4651_ = l_outOfBounds___redArg(v___x_4650_);
lean_dec(v___x_4650_);
v___x_4652_ = lean_unbox(v___x_4651_);
lean_dec(v___x_4651_);
v___y_4601_ = v___y_4628_;
v___y_4602_ = v___y_4629_;
v___y_4603_ = v___y_4630_;
v___y_4604_ = v___y_4631_;
v___y_4605_ = v___y_4632_;
v___y_4606_ = v___y_4633_;
v___y_4607_ = v___y_4634_;
v___y_4608_ = v___y_4635_;
v___y_4609_ = v___y_4637_;
v___y_4610_ = v___y_4638_;
v___y_4611_ = v___y_4639_;
v___y_4612_ = v___y_4640_;
v___y_4613_ = v___y_4641_;
v___y_4614_ = v___x_4646_;
v___y_4615_ = v___x_4652_;
goto v___jp_4600_;
}
else
{
uint8_t v___x_4653_; 
v___x_4653_ = lean_byte_array_fget(v_fst_3711_, v___x_4648_);
lean_dec(v___x_4648_);
v___y_4601_ = v___y_4628_;
v___y_4602_ = v___y_4629_;
v___y_4603_ = v___y_4630_;
v___y_4604_ = v___y_4631_;
v___y_4605_ = v___y_4632_;
v___y_4606_ = v___y_4633_;
v___y_4607_ = v___y_4634_;
v___y_4608_ = v___y_4635_;
v___y_4609_ = v___y_4637_;
v___y_4610_ = v___y_4638_;
v___y_4611_ = v___y_4639_;
v___y_4612_ = v___y_4640_;
v___y_4613_ = v___y_4641_;
v___y_4614_ = v___x_4646_;
v___y_4615_ = v___x_4653_;
goto v___jp_4600_;
}
}
v___jp_4654_:
{
uint64_t v_a_4669_; lean_object* v___x_4670_; uint8_t v___x_4671_; 
v_a_4669_ = lean_uint8_to_uint64(v___y_4668_);
v___x_4670_ = lean_nat_add(v___y_4656_, v___x_3696_);
v___x_4671_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_3711_, v___x_4670_);
if (v___x_4671_ == 0)
{
lean_object* v___x_4672_; lean_object* v___x_4673_; uint8_t v___x_4674_; 
lean_dec(v___x_4670_);
v___x_4672_ = lean_box(v___y_4663_);
v___x_4673_ = l_outOfBounds___redArg(v___x_4672_);
lean_dec(v___x_4672_);
v___x_4674_ = lean_unbox(v___x_4673_);
lean_dec(v___x_4673_);
v___y_4628_ = v___y_4655_;
v___y_4629_ = v___y_4656_;
v___y_4630_ = v___y_4657_;
v___y_4631_ = v___y_4658_;
v___y_4632_ = v___y_4659_;
v___y_4633_ = v___y_4660_;
v___y_4634_ = v___y_4661_;
v___y_4635_ = v___y_4662_;
v___y_4636_ = v_a_4669_;
v___y_4637_ = v___y_4663_;
v___y_4638_ = v___y_4664_;
v___y_4639_ = v___y_4665_;
v___y_4640_ = v___y_4666_;
v___y_4641_ = v___y_4667_;
v___y_4642_ = v___x_4674_;
goto v___jp_4627_;
}
else
{
uint8_t v___x_4675_; 
v___x_4675_ = lean_byte_array_fget(v_fst_3711_, v___x_4670_);
lean_dec(v___x_4670_);
v___y_4628_ = v___y_4655_;
v___y_4629_ = v___y_4656_;
v___y_4630_ = v___y_4657_;
v___y_4631_ = v___y_4658_;
v___y_4632_ = v___y_4659_;
v___y_4633_ = v___y_4660_;
v___y_4634_ = v___y_4661_;
v___y_4635_ = v___y_4662_;
v___y_4636_ = v_a_4669_;
v___y_4637_ = v___y_4663_;
v___y_4638_ = v___y_4664_;
v___y_4639_ = v___y_4665_;
v___y_4640_ = v___y_4666_;
v___y_4641_ = v___y_4667_;
v___y_4642_ = v___x_4675_;
goto v___jp_4627_;
}
}
v___jp_4676_:
{
if (v___y_4690_ == 0)
{
uint8_t v___x_4691_; 
v___x_4691_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_3711_, v___y_4678_);
if (v___x_4691_ == 0)
{
lean_object* v___x_4692_; lean_object* v___x_4693_; uint8_t v___x_4694_; 
v___x_4692_ = lean_box(v___y_4685_);
v___x_4693_ = l_outOfBounds___redArg(v___x_4692_);
lean_dec(v___x_4692_);
v___x_4694_ = lean_unbox(v___x_4693_);
lean_dec(v___x_4693_);
v___y_4655_ = v___y_4677_;
v___y_4656_ = v___y_4678_;
v___y_4657_ = v___y_4679_;
v___y_4658_ = v___y_4680_;
v___y_4659_ = v___y_4681_;
v___y_4660_ = v___y_4682_;
v___y_4661_ = v___y_4683_;
v___y_4662_ = v___y_4684_;
v___y_4663_ = v___y_4685_;
v___y_4664_ = v___y_4686_;
v___y_4665_ = v___y_4687_;
v___y_4666_ = v___y_4688_;
v___y_4667_ = v___y_4689_;
v___y_4668_ = v___x_4694_;
goto v___jp_4654_;
}
else
{
uint8_t v___x_4695_; 
v___x_4695_ = lean_byte_array_fget(v_fst_3711_, v___y_4678_);
v___y_4655_ = v___y_4677_;
v___y_4656_ = v___y_4678_;
v___y_4657_ = v___y_4679_;
v___y_4658_ = v___y_4680_;
v___y_4659_ = v___y_4681_;
v___y_4660_ = v___y_4682_;
v___y_4661_ = v___y_4683_;
v___y_4662_ = v___y_4684_;
v___y_4663_ = v___y_4685_;
v___y_4664_ = v___y_4686_;
v___y_4665_ = v___y_4687_;
v___y_4666_ = v___y_4688_;
v___y_4667_ = v___y_4689_;
v___y_4668_ = v___x_4695_;
goto v___jp_4654_;
}
}
else
{
size_t v_pos_4696_; uint8_t v___x_4697_; uint64_t v_a_4698_; size_t v___x_4699_; size_t v___x_4700_; uint8_t v___x_4701_; uint64_t v___x_4702_; uint64_t v___x_4703_; uint64_t v___x_4704_; uint64_t v___x_4705_; size_t v___x_4706_; size_t v___x_4707_; uint8_t v___x_4708_; uint64_t v___x_4709_; uint64_t v___x_4710_; uint64_t v___x_4711_; uint64_t v___x_4712_; size_t v___x_4713_; size_t v___x_4714_; uint8_t v___x_4715_; uint64_t v___x_4716_; uint64_t v___x_4717_; uint64_t v___x_4718_; uint64_t v___x_4719_; 
v_pos_4696_ = lean_usize_of_nat(v___y_4678_);
lean_dec(v___y_4678_);
v___x_4697_ = lean_byte_array_uget(v_fst_3711_, v_pos_4696_);
v_a_4698_ = lean_uint8_to_uint64(v___x_4697_);
v___x_4699_ = ((size_t)1ULL);
v___x_4700_ = lean_usize_add(v_pos_4696_, v___x_4699_);
v___x_4701_ = lean_byte_array_uget(v_fst_3711_, v___x_4700_);
v___x_4702_ = lean_uint8_to_uint64(v___x_4701_);
v___x_4703_ = 8ULL;
v___x_4704_ = lean_uint64_shift_left(v___x_4702_, v___x_4703_);
v___x_4705_ = lean_uint64_lor(v_a_4698_, v___x_4704_);
v___x_4706_ = ((size_t)2ULL);
v___x_4707_ = lean_usize_add(v_pos_4696_, v___x_4706_);
v___x_4708_ = lean_byte_array_uget(v_fst_3711_, v___x_4707_);
v___x_4709_ = lean_uint8_to_uint64(v___x_4708_);
v___x_4710_ = 16ULL;
v___x_4711_ = lean_uint64_shift_left(v___x_4709_, v___x_4710_);
v___x_4712_ = lean_uint64_lor(v___x_4705_, v___x_4711_);
v___x_4713_ = ((size_t)3ULL);
v___x_4714_ = lean_usize_add(v_pos_4696_, v___x_4713_);
v___x_4715_ = lean_byte_array_uget(v_fst_3711_, v___x_4714_);
v___x_4716_ = lean_uint8_to_uint64(v___x_4715_);
v___x_4717_ = 24ULL;
v___x_4718_ = lean_uint64_shift_left(v___x_4716_, v___x_4717_);
v___x_4719_ = lean_uint64_lor(v___x_4712_, v___x_4718_);
v___y_4565_ = v___y_4677_;
v___y_4566_ = v___y_4684_;
v___y_4567_ = v___y_4679_;
v___y_4568_ = v___y_4686_;
v___y_4569_ = v___y_4680_;
v___y_4570_ = v___y_4687_;
v___y_4571_ = v___y_4681_;
v___y_4572_ = v___y_4688_;
v___y_4573_ = v___y_4689_;
v___y_4574_ = v___y_4682_;
v___y_4575_ = v___y_4683_;
v___y_4576_ = v___x_4719_;
goto v___jp_4564_;
}
}
v___jp_4720_:
{
if (v___y_4731_ == 0)
{
lean_dec_ref(v___y_4723_);
v___y_4535_ = v___y_4731_;
v___y_4536_ = v___y_4721_;
v___y_4537_ = v___y_4722_;
v___y_4538_ = v___y_4726_;
v___y_4539_ = v___y_4725_;
v___y_4540_ = v___y_4727_;
v___y_4541_ = v___y_4728_;
v___y_4542_ = v___y_4729_;
v___y_4543_ = v___y_4730_;
goto v___jp_4534_;
}
else
{
uint8_t v___x_4732_; lean_object* v___x_4733_; lean_object* v_offset_4734_; lean_object* v___x_4735_; lean_object* v___x_4736_; uint8_t v___x_4737_; 
v___x_4732_ = 0;
v___x_4733_ = lean_unsigned_to_nat(4u);
v_offset_4734_ = lean_nat_mul(v___y_4722_, v___x_4733_);
v___x_4735_ = lean_nat_add(v_offset_4734_, v___x_4733_);
v___x_4736_ = lean_byte_array_size(v_fst_3711_);
v___x_4737_ = lean_nat_dec_le(v___x_4735_, v___x_4736_);
if (v___x_4737_ == 0)
{
lean_dec(v___x_4735_);
v___y_4677_ = v___y_4721_;
v___y_4678_ = v_offset_4734_;
v___y_4679_ = v___y_4722_;
v___y_4680_ = v___y_4723_;
v___y_4681_ = v___y_4726_;
v___y_4682_ = v___y_4729_;
v___y_4683_ = v___y_4730_;
v___y_4684_ = v___y_4731_;
v___y_4685_ = v___x_4732_;
v___y_4686_ = v___y_4724_;
v___y_4687_ = v___y_4725_;
v___y_4688_ = v___y_4727_;
v___y_4689_ = v___y_4728_;
v___y_4690_ = v___x_4737_;
goto v___jp_4676_;
}
else
{
size_t v___x_4738_; lean_object* v___x_4739_; uint8_t v___x_4740_; 
v___x_4738_ = lean_usize_of_nat(v___x_4735_);
v___x_4739_ = lean_usize_to_nat(v___x_4738_);
v___x_4740_ = lean_nat_dec_eq(v___x_4739_, v___x_4735_);
lean_dec(v___x_4735_);
lean_dec(v___x_4739_);
v___y_4677_ = v___y_4721_;
v___y_4678_ = v_offset_4734_;
v___y_4679_ = v___y_4722_;
v___y_4680_ = v___y_4723_;
v___y_4681_ = v___y_4726_;
v___y_4682_ = v___y_4729_;
v___y_4683_ = v___y_4730_;
v___y_4684_ = v___y_4731_;
v___y_4685_ = v___x_4732_;
v___y_4686_ = v___y_4724_;
v___y_4687_ = v___y_4725_;
v___y_4688_ = v___y_4727_;
v___y_4689_ = v___y_4728_;
v___y_4690_ = v___x_4740_;
goto v___jp_4676_;
}
}
}
v___jp_4741_:
{
lean_object* v___x_4752_; 
v___x_4752_ = lean_uint64_to_nat(v___y_4751_);
if (v___x_4026_ == 0)
{
v___y_4721_ = v___y_4742_;
v___y_4722_ = v___x_4752_;
v___y_4723_ = v___y_4743_;
v___y_4724_ = v___y_4744_;
v___y_4725_ = v___y_4745_;
v___y_4726_ = v___y_4746_;
v___y_4727_ = v___y_4747_;
v___y_4728_ = v___y_4748_;
v___y_4729_ = v___y_4749_;
v___y_4730_ = v___y_4750_;
v___y_4731_ = v___x_3693_;
goto v___jp_4720_;
}
else
{
v___y_4721_ = v___y_4742_;
v___y_4722_ = v___x_4752_;
v___y_4723_ = v___y_4743_;
v___y_4724_ = v___y_4744_;
v___y_4725_ = v___y_4745_;
v___y_4726_ = v___y_4746_;
v___y_4727_ = v___y_4747_;
v___y_4728_ = v___y_4748_;
v___y_4729_ = v___y_4749_;
v___y_4730_ = v___y_4750_;
v___y_4731_ = v___y_4744_;
goto v___jp_4720_;
}
}
v___jp_4753_:
{
uint64_t v___x_4765_; uint64_t v___x_4766_; uint64_t v___x_4767_; uint64_t v___x_4768_; 
v___x_4765_ = lean_uint8_to_uint64(v___y_4764_);
v___x_4766_ = 24ULL;
v___x_4767_ = lean_uint64_shift_left(v___x_4765_, v___x_4766_);
v___x_4768_ = lean_uint64_lor(v___y_4755_, v___x_4767_);
v___y_4742_ = v___y_4754_;
v___y_4743_ = v___y_4757_;
v___y_4744_ = v___y_4756_;
v___y_4745_ = v___y_4759_;
v___y_4746_ = v___y_4758_;
v___y_4747_ = v___y_4760_;
v___y_4748_ = v___y_4761_;
v___y_4749_ = v___y_4762_;
v___y_4750_ = v___y_4763_;
v___y_4751_ = v___x_4768_;
goto v___jp_4741_;
}
v___jp_4769_:
{
uint64_t v___x_4782_; uint64_t v___x_4783_; uint64_t v___x_4784_; uint64_t v___x_4785_; lean_object* v___x_4786_; uint8_t v___x_4787_; 
v___x_4782_ = lean_uint8_to_uint64(v___y_4781_);
v___x_4783_ = 16ULL;
v___x_4784_ = lean_uint64_shift_left(v___x_4782_, v___x_4783_);
v___x_4785_ = lean_uint64_lor(v___y_4772_, v___x_4784_);
v___x_4786_ = lean_unsigned_to_nat(3u);
v___x_4787_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4770_, v___x_4786_);
if (v___x_4787_ == 0)
{
lean_object* v___x_4788_; lean_object* v___x_4789_; uint8_t v___x_4790_; 
v___x_4788_ = lean_box(v___y_4771_);
v___x_4789_ = l_outOfBounds___redArg(v___x_4788_);
lean_dec(v___x_4788_);
v___x_4790_ = lean_unbox(v___x_4789_);
lean_dec(v___x_4789_);
v___y_4754_ = v___y_4770_;
v___y_4755_ = v___x_4785_;
v___y_4756_ = v___y_4774_;
v___y_4757_ = v___y_4773_;
v___y_4758_ = v___y_4776_;
v___y_4759_ = v___y_4775_;
v___y_4760_ = v___y_4777_;
v___y_4761_ = v___y_4778_;
v___y_4762_ = v___y_4779_;
v___y_4763_ = v___y_4780_;
v___y_4764_ = v___x_4790_;
goto v___jp_4753_;
}
else
{
uint8_t v___x_4791_; 
v___x_4791_ = lean_byte_array_fget(v___y_4770_, v___x_4786_);
v___y_4754_ = v___y_4770_;
v___y_4755_ = v___x_4785_;
v___y_4756_ = v___y_4774_;
v___y_4757_ = v___y_4773_;
v___y_4758_ = v___y_4776_;
v___y_4759_ = v___y_4775_;
v___y_4760_ = v___y_4777_;
v___y_4761_ = v___y_4778_;
v___y_4762_ = v___y_4779_;
v___y_4763_ = v___y_4780_;
v___y_4764_ = v___x_4791_;
goto v___jp_4753_;
}
}
v___jp_4792_:
{
uint64_t v___x_4805_; uint64_t v___x_4806_; uint64_t v___x_4807_; uint64_t v___x_4808_; lean_object* v___x_4809_; uint8_t v___x_4810_; 
v___x_4805_ = lean_uint8_to_uint64(v___y_4804_);
v___x_4806_ = 8ULL;
v___x_4807_ = lean_uint64_shift_left(v___x_4805_, v___x_4806_);
v___x_4808_ = lean_uint64_lor(v___y_4801_, v___x_4807_);
v___x_4809_ = lean_unsigned_to_nat(2u);
v___x_4810_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4793_, v___x_4809_);
if (v___x_4810_ == 0)
{
lean_object* v___x_4811_; lean_object* v___x_4812_; uint8_t v___x_4813_; 
v___x_4811_ = lean_box(v___y_4794_);
v___x_4812_ = l_outOfBounds___redArg(v___x_4811_);
lean_dec(v___x_4811_);
v___x_4813_ = lean_unbox(v___x_4812_);
lean_dec(v___x_4812_);
v___y_4770_ = v___y_4793_;
v___y_4771_ = v___y_4794_;
v___y_4772_ = v___x_4808_;
v___y_4773_ = v___y_4796_;
v___y_4774_ = v___y_4795_;
v___y_4775_ = v___y_4798_;
v___y_4776_ = v___y_4797_;
v___y_4777_ = v___y_4799_;
v___y_4778_ = v___y_4800_;
v___y_4779_ = v___y_4802_;
v___y_4780_ = v___y_4803_;
v___y_4781_ = v___x_4813_;
goto v___jp_4769_;
}
else
{
uint8_t v___x_4814_; 
v___x_4814_ = lean_byte_array_fget(v___y_4793_, v___x_4809_);
v___y_4770_ = v___y_4793_;
v___y_4771_ = v___y_4794_;
v___y_4772_ = v___x_4808_;
v___y_4773_ = v___y_4796_;
v___y_4774_ = v___y_4795_;
v___y_4775_ = v___y_4798_;
v___y_4776_ = v___y_4797_;
v___y_4777_ = v___y_4799_;
v___y_4778_ = v___y_4800_;
v___y_4779_ = v___y_4802_;
v___y_4780_ = v___y_4803_;
v___y_4781_ = v___x_4814_;
goto v___jp_4769_;
}
}
v___jp_4815_:
{
uint64_t v_a_4827_; uint8_t v___x_4828_; 
v_a_4827_ = lean_uint8_to_uint64(v___y_4826_);
v___x_4828_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_4816_, v___x_3696_);
if (v___x_4828_ == 0)
{
lean_object* v___x_4829_; lean_object* v___x_4830_; uint8_t v___x_4831_; 
v___x_4829_ = lean_box(v___y_4817_);
v___x_4830_ = l_outOfBounds___redArg(v___x_4829_);
lean_dec(v___x_4829_);
v___x_4831_ = lean_unbox(v___x_4830_);
lean_dec(v___x_4830_);
v___y_4793_ = v___y_4816_;
v___y_4794_ = v___y_4817_;
v___y_4795_ = v___y_4819_;
v___y_4796_ = v___y_4818_;
v___y_4797_ = v___y_4821_;
v___y_4798_ = v___y_4820_;
v___y_4799_ = v___y_4822_;
v___y_4800_ = v___y_4823_;
v___y_4801_ = v_a_4827_;
v___y_4802_ = v___y_4824_;
v___y_4803_ = v___y_4825_;
v___y_4804_ = v___x_4831_;
goto v___jp_4792_;
}
else
{
uint8_t v___x_4832_; 
v___x_4832_ = lean_byte_array_fget(v___y_4816_, v___x_3696_);
v___y_4793_ = v___y_4816_;
v___y_4794_ = v___y_4817_;
v___y_4795_ = v___y_4819_;
v___y_4796_ = v___y_4818_;
v___y_4797_ = v___y_4821_;
v___y_4798_ = v___y_4820_;
v___y_4799_ = v___y_4822_;
v___y_4800_ = v___y_4823_;
v___y_4801_ = v_a_4827_;
v___y_4802_ = v___y_4824_;
v___y_4803_ = v___y_4825_;
v___y_4804_ = v___x_4832_;
goto v___jp_4792_;
}
}
v___jp_4833_:
{
size_t v_pos_4843_; uint8_t v___x_4844_; uint64_t v_a_4845_; size_t v___x_4846_; uint8_t v___x_4847_; uint64_t v___x_4848_; uint64_t v___x_4849_; uint64_t v___x_4850_; uint64_t v___x_4851_; size_t v___x_4852_; uint8_t v___x_4853_; uint64_t v___x_4854_; uint64_t v___x_4855_; uint64_t v___x_4856_; uint64_t v___x_4857_; size_t v___x_4858_; uint8_t v___x_4859_; uint64_t v___x_4860_; uint64_t v___x_4861_; uint64_t v___x_4862_; uint64_t v___x_4863_; 
v_pos_4843_ = ((size_t)0ULL);
v___x_4844_ = lean_byte_array_uget(v___y_4834_, v_pos_4843_);
v_a_4845_ = lean_uint8_to_uint64(v___x_4844_);
v___x_4846_ = ((size_t)1ULL);
v___x_4847_ = lean_byte_array_uget(v___y_4834_, v___x_4846_);
v___x_4848_ = lean_uint8_to_uint64(v___x_4847_);
v___x_4849_ = 8ULL;
v___x_4850_ = lean_uint64_shift_left(v___x_4848_, v___x_4849_);
v___x_4851_ = lean_uint64_lor(v_a_4845_, v___x_4850_);
v___x_4852_ = ((size_t)2ULL);
v___x_4853_ = lean_byte_array_uget(v___y_4834_, v___x_4852_);
v___x_4854_ = lean_uint8_to_uint64(v___x_4853_);
v___x_4855_ = 16ULL;
v___x_4856_ = lean_uint64_shift_left(v___x_4854_, v___x_4855_);
v___x_4857_ = lean_uint64_lor(v___x_4851_, v___x_4856_);
v___x_4858_ = ((size_t)3ULL);
v___x_4859_ = lean_byte_array_uget(v___y_4834_, v___x_4858_);
v___x_4860_ = lean_uint8_to_uint64(v___x_4859_);
v___x_4861_ = 24ULL;
v___x_4862_ = lean_uint64_shift_left(v___x_4860_, v___x_4861_);
v___x_4863_ = lean_uint64_lor(v___x_4857_, v___x_4862_);
v___y_4742_ = v___y_4834_;
v___y_4743_ = v___y_4836_;
v___y_4744_ = v___y_4835_;
v___y_4745_ = v___y_4838_;
v___y_4746_ = v___y_4837_;
v___y_4747_ = v___y_4839_;
v___y_4748_ = v___y_4840_;
v___y_4749_ = v___y_4841_;
v___y_4750_ = v___y_4842_;
v___y_4751_ = v___x_4863_;
goto v___jp_4741_;
}
v___jp_4864_:
{
lean_object* v___x_4870_; uint8_t v___x_4871_; 
v___x_4870_ = lp_Hex_Hex_Groebner_SparseRow_size(v___y_4868_);
v___x_4871_ = lean_nat_dec_eq(v___x_4870_, v_reducerRank_3965_);
if (v___x_4871_ == 0)
{
lean_object* v_columns_4872_; lean_object* v_coefficients_4873_; lean_object* v___x_4874_; lean_object* v___x_4875_; uint8_t v___x_4876_; 
v_columns_4872_ = lean_ctor_get(v___y_4868_, 0);
lean_inc_ref(v_columns_4872_);
v_coefficients_4873_ = lean_ctor_get(v___y_4868_, 1);
lean_inc_ref(v_coefficients_4873_);
v___x_4874_ = lean_unsigned_to_nat(4u);
v___x_4875_ = lean_byte_array_size(v_columns_4872_);
v___x_4876_ = lean_nat_dec_le(v___x_4874_, v___x_4875_);
if (v___x_4876_ == 0)
{
if (v___x_4876_ == 0)
{
uint8_t v___x_4877_; uint8_t v___x_4878_; 
v___x_4877_ = 0;
v___x_4878_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_columns_4872_, v_reducerRank_3965_);
if (v___x_4878_ == 0)
{
lean_object* v___x_4879_; lean_object* v___x_4880_; uint8_t v___x_4881_; 
v___x_4879_ = lean_box(v___x_4877_);
v___x_4880_ = l_outOfBounds___redArg(v___x_4879_);
lean_dec(v___x_4879_);
v___x_4881_ = lean_unbox(v___x_4880_);
lean_dec(v___x_4880_);
v___y_4816_ = v_columns_4872_;
v___y_4817_ = v___x_4877_;
v___y_4818_ = v_coefficients_4873_;
v___y_4819_ = v___x_4871_;
v___y_4820_ = v___x_4870_;
v___y_4821_ = v___y_4865_;
v___y_4822_ = v___y_4869_;
v___y_4823_ = v___y_4866_;
v___y_4824_ = v___y_4867_;
v___y_4825_ = v___y_4868_;
v___y_4826_ = v___x_4881_;
goto v___jp_4815_;
}
else
{
uint8_t v___x_4882_; 
v___x_4882_ = lean_byte_array_fget(v_columns_4872_, v_reducerRank_3965_);
v___y_4816_ = v_columns_4872_;
v___y_4817_ = v___x_4877_;
v___y_4818_ = v_coefficients_4873_;
v___y_4819_ = v___x_4871_;
v___y_4820_ = v___x_4870_;
v___y_4821_ = v___y_4865_;
v___y_4822_ = v___y_4869_;
v___y_4823_ = v___y_4866_;
v___y_4824_ = v___y_4867_;
v___y_4825_ = v___y_4868_;
v___y_4826_ = v___x_4882_;
goto v___jp_4815_;
}
}
else
{
v___y_4834_ = v_columns_4872_;
v___y_4835_ = v___x_4871_;
v___y_4836_ = v_coefficients_4873_;
v___y_4837_ = v___y_4865_;
v___y_4838_ = v___x_4870_;
v___y_4839_ = v___y_4869_;
v___y_4840_ = v___y_4866_;
v___y_4841_ = v___y_4867_;
v___y_4842_ = v___y_4868_;
goto v___jp_4833_;
}
}
else
{
v___y_4834_ = v_columns_4872_;
v___y_4835_ = v___x_4871_;
v___y_4836_ = v_coefficients_4873_;
v___y_4837_ = v___y_4865_;
v___y_4838_ = v___x_4870_;
v___y_4839_ = v___y_4869_;
v___y_4840_ = v___y_4866_;
v___y_4841_ = v___y_4867_;
v___y_4842_ = v___y_4868_;
goto v___jp_4833_;
}
}
else
{
lean_dec(v___x_4870_);
lean_dec_ref(v___y_4868_);
if (v_independent_3649_ == 0)
{
v___y_3942_ = v___y_4865_;
v___y_3943_ = v___y_4869_;
v___y_3944_ = v___y_4866_;
v_remainders_3945_ = v_fst_3715_;
v___y_3946_ = v___y_4867_;
goto v___jp_3941_;
}
else
{
if (v___x_4026_ == 0)
{
v___y_3942_ = v___y_4865_;
v___y_3943_ = v___y_4869_;
v___y_3944_ = v___y_4866_;
v_remainders_3945_ = v_fst_3715_;
v___y_3946_ = v___y_4867_;
goto v___jp_3941_;
}
else
{
lean_object* v___x_4883_; lean_object* v___x_4884_; lean_object* v___x_4885_; 
v___x_4883_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0);
lean_inc(v___y_4869_);
lean_inc(v___y_4865_);
v___x_4884_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_4884_, 0, v___x_4883_);
lean_ctor_set(v___x_4884_, 1, v___y_4865_);
lean_ctor_set(v___x_4884_, 2, v___y_4869_);
v___x_4885_ = lean_array_push(v_fst_3715_, v___x_4884_);
v___y_3942_ = v___y_4865_;
v___y_3943_ = v___y_4869_;
v___y_3944_ = v___y_4866_;
v_remainders_3945_ = v___x_4885_;
v___y_3946_ = v___y_4867_;
goto v___jp_3941_;
}
}
}
}
v___jp_4886_:
{
lean_object* v___x_4889_; 
lean_inc(v_i_3657_);
if (v_isShared_3703_ == 0)
{
lean_ctor_set_tag(v___x_3702_, 0);
lean_ctor_set(v___x_3702_, 0, v_i_3657_);
v___x_4889_ = v___x_3702_;
goto v_reusejp_4888_;
}
else
{
lean_object* v_reuseFailAlloc_4901_; 
v_reuseFailAlloc_4901_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4901_, 0, v_i_3657_);
v___x_4889_ = v_reuseFailAlloc_4901_;
goto v_reusejp_4888_;
}
v_reusejp_4888_:
{
lean_object* v___x_4890_; lean_object* v_fst_4891_; 
v___x_4890_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_3642_, v_provenance_3644_, v_fst_3714_, v___x_4889_, v_snd_3709_);
v_fst_4891_ = lean_ctor_get(v___x_4890_, 0);
lean_inc(v_fst_4891_);
if (lean_obj_tag(v_fst_4891_) == 0)
{
lean_object* v_snd_4892_; lean_object* v_a_4893_; 
lean_dec_ref(v___y_4887_);
lean_dec(v_snd_3716_);
lean_dec(v_fst_3715_);
lean_dec(v_fst_3713_);
lean_dec(v_fst_3712_);
lean_dec(v_fst_3711_);
lean_dec(v_fst_3710_);
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_4892_ = lean_ctor_get(v___x_4890_, 1);
lean_inc(v_snd_4892_);
lean_dec_ref(v___x_4890_);
v_a_4893_ = lean_ctor_get(v_fst_4891_, 0);
lean_inc(v_a_4893_);
lean_dec_ref_known(v_fst_4891_, 1);
v_a_3660_ = v_a_4893_;
v_snd_3661_ = v_snd_4892_;
goto v___jp_3659_;
}
else
{
lean_object* v_a_4894_; lean_object* v_snd_4895_; lean_object* v_fst_4896_; lean_object* v_snd_4897_; lean_object* v___x_4898_; uint8_t v___x_4899_; 
v_a_4894_ = lean_ctor_get(v_fst_4891_, 0);
lean_inc(v_a_4894_);
lean_dec_ref_known(v_fst_4891_, 1);
v_snd_4895_ = lean_ctor_get(v___x_4890_, 1);
lean_inc(v_snd_4895_);
lean_dec_ref(v___x_4890_);
v_fst_4896_ = lean_ctor_get(v_a_4894_, 0);
lean_inc(v_fst_4896_);
v_snd_4897_ = lean_ctor_get(v_a_4894_, 1);
lean_inc(v_snd_4897_);
lean_dec(v_a_4894_);
v___x_4898_ = lean_array_get_size(v_sugars_3652_);
v___x_4899_ = lean_nat_dec_lt(v_i_3657_, v___x_4898_);
if (v___x_4899_ == 0)
{
v___y_4865_ = v_snd_4897_;
v___y_4866_ = v_fst_4896_;
v___y_4867_ = v_snd_4895_;
v___y_4868_ = v___y_4887_;
v___y_4869_ = v_reducerRank_3965_;
goto v___jp_4864_;
}
else
{
lean_object* v___x_4900_; 
v___x_4900_ = lean_array_fget_borrowed(v_sugars_3652_, v_i_3657_);
lean_inc(v___x_4900_);
v___y_4865_ = v_snd_4897_;
v___y_4866_ = v_fst_4896_;
v___y_4867_ = v_snd_4895_;
v___y_4868_ = v___y_4887_;
v___y_4869_ = v___x_4900_;
goto v___jp_4864_;
}
}
}
}
}
}
}
v___jp_3659_:
{
lean_object* v___x_3662_; lean_object* v___x_3663_; 
v___x_3662_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3662_, 0, v_a_3660_);
v___x_3663_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_3663_, 0, v___x_3662_);
lean_ctor_set(v___x_3663_, 1, v_snd_3661_);
return v___x_3663_;
}
v___jp_3666_:
{
lean_object* v_fst_3668_; 
v_fst_3668_ = lean_ctor_get(v___y_3667_, 0);
lean_inc(v_fst_3668_);
if (lean_obj_tag(v_fst_3668_) == 0)
{
lean_object* v_snd_3669_; lean_object* v_a_3670_; 
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_3669_ = lean_ctor_get(v___y_3667_, 1);
lean_inc(v_snd_3669_);
lean_dec_ref(v___y_3667_);
v_a_3670_ = lean_ctor_get(v_fst_3668_, 0);
lean_inc(v_a_3670_);
lean_dec_ref_known(v_fst_3668_, 1);
v_a_3660_ = v_a_3670_;
v_snd_3661_ = v_snd_3669_;
goto v___jp_3659_;
}
else
{
lean_object* v_a_3671_; lean_object* v___x_3673_; uint8_t v_isShared_3674_; uint8_t v_isSharedCheck_3692_; 
v_a_3671_ = lean_ctor_get(v_fst_3668_, 0);
v_isSharedCheck_3692_ = !lean_is_exclusive(v_fst_3668_);
if (v_isSharedCheck_3692_ == 0)
{
v___x_3673_ = v_fst_3668_;
v_isShared_3674_ = v_isSharedCheck_3692_;
goto v_resetjp_3672_;
}
else
{
lean_inc(v_a_3671_);
lean_dec(v_fst_3668_);
v___x_3673_ = lean_box(0);
v_isShared_3674_ = v_isSharedCheck_3692_;
goto v_resetjp_3672_;
}
v_resetjp_3672_:
{
if (lean_obj_tag(v_a_3671_) == 0)
{
lean_object* v_snd_3675_; lean_object* v___x_3677_; uint8_t v_isShared_3678_; uint8_t v_isSharedCheck_3686_; 
lean_dec(v_i_3657_);
lean_dec(v_columns_3651_);
v_snd_3675_ = lean_ctor_get(v___y_3667_, 1);
v_isSharedCheck_3686_ = !lean_is_exclusive(v___y_3667_);
if (v_isSharedCheck_3686_ == 0)
{
lean_object* v_unused_3687_; 
v_unused_3687_ = lean_ctor_get(v___y_3667_, 0);
lean_dec(v_unused_3687_);
v___x_3677_ = v___y_3667_;
v_isShared_3678_ = v_isSharedCheck_3686_;
goto v_resetjp_3676_;
}
else
{
lean_inc(v_snd_3675_);
lean_dec(v___y_3667_);
v___x_3677_ = lean_box(0);
v_isShared_3678_ = v_isSharedCheck_3686_;
goto v_resetjp_3676_;
}
v_resetjp_3676_:
{
lean_object* v_a_3679_; lean_object* v___x_3681_; 
v_a_3679_ = lean_ctor_get(v_a_3671_, 0);
lean_inc(v_a_3679_);
lean_dec_ref_known(v_a_3671_, 1);
if (v_isShared_3674_ == 0)
{
lean_ctor_set(v___x_3673_, 0, v_a_3679_);
v___x_3681_ = v___x_3673_;
goto v_reusejp_3680_;
}
else
{
lean_object* v_reuseFailAlloc_3685_; 
v_reuseFailAlloc_3685_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3685_, 0, v_a_3679_);
v___x_3681_ = v_reuseFailAlloc_3685_;
goto v_reusejp_3680_;
}
v_reusejp_3680_:
{
lean_object* v___x_3683_; 
if (v_isShared_3678_ == 0)
{
lean_ctor_set(v___x_3677_, 0, v___x_3681_);
v___x_3683_ = v___x_3677_;
goto v_reusejp_3682_;
}
else
{
lean_object* v_reuseFailAlloc_3684_; 
v_reuseFailAlloc_3684_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_3684_, 0, v___x_3681_);
lean_ctor_set(v_reuseFailAlloc_3684_, 1, v_snd_3675_);
v___x_3683_ = v_reuseFailAlloc_3684_;
goto v_reusejp_3682_;
}
v_reusejp_3682_:
{
return v___x_3683_;
}
}
}
}
else
{
lean_object* v_snd_3688_; lean_object* v_a_3689_; lean_object* v___x_3690_; 
lean_del_object(v___x_3673_);
v_snd_3688_ = lean_ctor_get(v___y_3667_, 1);
lean_inc(v_snd_3688_);
lean_dec_ref(v___y_3667_);
v_a_3689_ = lean_ctor_get(v_a_3671_, 0);
lean_inc(v_a_3689_);
lean_dec_ref_known(v_a_3671_, 1);
v___x_3690_ = lean_nat_add(v_i_3657_, v_step_3665_);
lean_dec(v_i_3657_);
v_b_3656_ = v_a_3689_;
v_i_3657_ = v___x_3690_;
v___y_3658_ = v_snd_3688_;
goto _start;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___boxed(lean_object** _args){
lean_object* v_limits_4907_ = _args[0];
lean_object* v___x_4908_ = _args[1];
lean_object* v_provenance_4909_ = _args[2];
lean_object* v_field_4910_ = _args[3];
lean_object* v_ctx_4911_ = _args[4];
lean_object* v_native_4912_ = _args[5];
lean_object* v_width_4913_ = _args[6];
lean_object* v_independent_4914_ = _args[7];
lean_object* v___y_4915_ = _args[8];
lean_object* v_columns_4916_ = _args[9];
lean_object* v_sugars_4917_ = _args[10];
lean_object* v_reducers_4918_ = _args[11];
lean_object* v_targets_4919_ = _args[12];
lean_object* v_range_4920_ = _args[13];
lean_object* v_b_4921_ = _args[14];
lean_object* v_i_4922_ = _args[15];
lean_object* v___y_4923_ = _args[16];
_start:
{
uint8_t v_provenance_boxed_4924_; uint64_t v_field_boxed_4925_; uint64_t v_ctx_boxed_4926_; uint8_t v_native_boxed_4927_; uint8_t v_width_boxed_4928_; uint8_t v_independent_boxed_4929_; lean_object* v_res_4930_; 
v_provenance_boxed_4924_ = lean_unbox(v_provenance_4909_);
v_field_boxed_4925_ = lean_unbox_uint64(v_field_4910_);
lean_dec_ref(v_field_4910_);
v_ctx_boxed_4926_ = lean_unbox_uint64(v_ctx_4911_);
lean_dec_ref(v_ctx_4911_);
v_native_boxed_4927_ = lean_unbox(v_native_4912_);
v_width_boxed_4928_ = lean_unbox(v_width_4913_);
v_independent_boxed_4929_ = lean_unbox(v_independent_4914_);
v_res_4930_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg(v_limits_4907_, v___x_4908_, v_provenance_boxed_4924_, v_field_boxed_4925_, v_ctx_boxed_4926_, v_native_boxed_4927_, v_width_boxed_4928_, v_independent_boxed_4929_, v___y_4915_, v_columns_4916_, v_sugars_4917_, v_reducers_4918_, v_targets_4919_, v_range_4920_, v_b_4921_, v_i_4922_, v___y_4923_);
lean_dec_ref(v_range_4920_);
lean_dec_ref(v_targets_4919_);
lean_dec_ref(v_reducers_4918_);
lean_dec_ref(v_sugars_4917_);
lean_dec(v___y_4915_);
lean_dec(v___x_4908_);
lean_dec_ref(v_limits_4907_);
return v_res_4930_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg(lean_object* v_limits_4931_, uint64_t v_field_4932_, uint64_t v_ctx_4933_, uint8_t v_width_4934_, uint8_t v_provenance_4935_, lean_object* v___x_4936_, uint8_t v_native_4937_, lean_object* v___y_4938_, uint8_t v_independent_4939_, lean_object* v_columns_4940_, lean_object* v_sugars_4941_, lean_object* v_reducers_4942_, lean_object* v_targets_4943_, lean_object* v_range_4944_, lean_object* v_b_4945_, lean_object* v_i_4946_, lean_object* v___y_4947_){
_start:
{
lean_object* v_a_4949_; lean_object* v_snd_4950_; lean_object* v_stop_4953_; lean_object* v_step_4954_; lean_object* v___y_4956_; uint8_t v___x_4982_; 
v_stop_4953_ = lean_ctor_get(v_range_4944_, 1);
v_step_4954_ = lean_ctor_get(v_range_4944_, 2);
v___x_4982_ = lean_nat_dec_lt(v_i_4946_, v_stop_4953_);
if (v___x_4982_ == 0)
{
lean_object* v___x_4983_; lean_object* v___x_4984_; 
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v___x_4983_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_4983_, 0, v_b_4945_);
v___x_4984_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4984_, 0, v___x_4983_);
lean_ctor_set(v___x_4984_, 1, v___y_4947_);
return v___x_4984_;
}
else
{
lean_object* v___x_4985_; lean_object* v___x_4986_; lean_object* v_fst_4987_; 
v___x_4985_ = lean_unsigned_to_nat(1u);
v___x_4986_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_4931_, v___x_4985_, v___y_4947_);
v_fst_4987_ = lean_ctor_get(v___x_4986_, 0);
lean_inc(v_fst_4987_);
if (lean_obj_tag(v_fst_4987_) == 0)
{
lean_object* v_snd_4988_; lean_object* v_a_4989_; 
lean_dec(v_i_4946_);
lean_dec_ref(v_b_4945_);
lean_dec(v_columns_4940_);
v_snd_4988_ = lean_ctor_get(v___x_4986_, 1);
lean_inc(v_snd_4988_);
lean_dec_ref(v___x_4986_);
v_a_4989_ = lean_ctor_get(v_fst_4987_, 0);
lean_inc(v_a_4989_);
lean_dec_ref_known(v_fst_4987_, 1);
v_a_4949_ = v_a_4989_;
v_snd_4950_ = v_snd_4988_;
goto v___jp_4948_;
}
else
{
lean_object* v___x_4991_; uint8_t v_isShared_4992_; uint8_t v_isSharedCheck_6194_; 
v_isSharedCheck_6194_ = !lean_is_exclusive(v_fst_4987_);
if (v_isSharedCheck_6194_ == 0)
{
lean_object* v_unused_6195_; 
v_unused_6195_ = lean_ctor_get(v_fst_4987_, 0);
lean_dec(v_unused_6195_);
v___x_4991_ = v_fst_4987_;
v_isShared_4992_ = v_isSharedCheck_6194_;
goto v_resetjp_4990_;
}
else
{
lean_dec(v_fst_4987_);
v___x_4991_ = lean_box(0);
v_isShared_4992_ = v_isSharedCheck_6194_;
goto v_resetjp_4990_;
}
v_resetjp_4990_:
{
lean_object* v_snd_4993_; lean_object* v_snd_4994_; lean_object* v_snd_4995_; lean_object* v_snd_4996_; lean_object* v_snd_4997_; lean_object* v_snd_4998_; lean_object* v_fst_4999_; lean_object* v_fst_5000_; lean_object* v_fst_5001_; lean_object* v_fst_5002_; lean_object* v_fst_5003_; lean_object* v_fst_5004_; lean_object* v_snd_5005_; lean_object* v___y_5007_; lean_object* v___y_5008_; lean_object* v___y_5009_; lean_object* v___y_5010_; lean_object* v___y_5011_; lean_object* v_nativePivots_5012_; lean_object* v___y_5013_; uint8_t v___y_5018_; lean_object* v___y_5019_; uint64_t v___y_5020_; lean_object* v___y_5021_; lean_object* v___y_5022_; lean_object* v___y_5023_; lean_object* v_fst_5024_; lean_object* v_snd_5025_; lean_object* v___y_5026_; uint8_t v___y_5058_; lean_object* v___y_5059_; lean_object* v___y_5060_; lean_object* v___y_5061_; lean_object* v___y_5062_; lean_object* v___y_5063_; lean_object* v___y_5064_; uint64_t v___y_5065_; uint8_t v___y_5097_; lean_object* v___y_5098_; lean_object* v___y_5099_; lean_object* v___y_5100_; lean_object* v___y_5101_; lean_object* v___y_5102_; lean_object* v___y_5103_; uint64_t v___y_5104_; uint8_t v___y_5105_; uint8_t v___y_5111_; lean_object* v___y_5112_; uint64_t v___y_5113_; lean_object* v___y_5114_; lean_object* v___y_5115_; lean_object* v___y_5116_; lean_object* v___y_5117_; uint8_t v___y_5118_; lean_object* v___y_5119_; lean_object* v___y_5120_; uint8_t v___y_5121_; uint8_t v___y_5133_; lean_object* v___y_5134_; uint64_t v___y_5135_; lean_object* v___y_5136_; lean_object* v___y_5137_; lean_object* v___y_5138_; lean_object* v___y_5139_; uint8_t v___y_5140_; lean_object* v___y_5141_; lean_object* v___y_5142_; uint8_t v___y_5143_; uint8_t v___y_5155_; lean_object* v___y_5156_; uint64_t v___y_5157_; lean_object* v___y_5158_; lean_object* v___y_5159_; lean_object* v___y_5160_; lean_object* v___y_5161_; lean_object* v___y_5162_; uint8_t v___y_5163_; uint8_t v___y_5169_; lean_object* v___y_5170_; lean_object* v___y_5171_; lean_object* v___y_5172_; lean_object* v___y_5173_; lean_object* v___y_5174_; uint8_t v___y_5175_; lean_object* v___y_5176_; lean_object* v___y_5177_; uint8_t v___y_5178_; uint8_t v___y_5191_; lean_object* v___y_5192_; lean_object* v___y_5193_; lean_object* v___y_5194_; lean_object* v___y_5195_; lean_object* v___y_5196_; lean_object* v___y_5197_; lean_object* v_nativePivots_5198_; lean_object* v___y_5199_; lean_object* v___y_5206_; lean_object* v___y_5207_; lean_object* v___y_5208_; lean_object* v___y_5209_; lean_object* v_remainders_5210_; lean_object* v___y_5211_; lean_object* v___y_5231_; lean_object* v___y_5232_; lean_object* v___y_5233_; lean_object* v_remainders_5234_; lean_object* v___y_5235_; lean_object* v_reducerRank_5254_; uint8_t v___y_5256_; lean_object* v___y_5257_; lean_object* v___y_5258_; lean_object* v___y_5259_; lean_object* v___y_5260_; lean_object* v___y_5261_; uint8_t v___y_5262_; lean_object* v___y_5263_; lean_object* v___y_5264_; uint8_t v___y_5265_; uint8_t v___y_5299_; lean_object* v___y_5300_; lean_object* v___y_5301_; lean_object* v___y_5302_; lean_object* v___y_5303_; lean_object* v___y_5304_; uint8_t v___y_5305_; lean_object* v___y_5306_; lean_object* v___y_5307_; lean_object* v___y_5308_; lean_object* v___x_5314_; uint8_t v___x_5315_; uint8_t v___y_5317_; lean_object* v___y_5318_; lean_object* v___y_5319_; lean_object* v___y_5320_; lean_object* v___y_5321_; lean_object* v___y_5322_; lean_object* v___y_5323_; uint64_t v___y_5324_; lean_object* v___y_5325_; lean_object* v___y_5326_; uint8_t v___y_5358_; lean_object* v___y_5359_; lean_object* v___y_5360_; lean_object* v___y_5361_; uint64_t v___y_5362_; lean_object* v___y_5363_; lean_object* v___y_5364_; lean_object* v_dense_5365_; lean_object* v_output_5366_; lean_object* v___y_5367_; lean_object* v___y_5373_; uint8_t v___y_5374_; lean_object* v___y_5375_; lean_object* v___y_5376_; lean_object* v___y_5377_; uint64_t v___y_5378_; lean_object* v___y_5379_; lean_object* v_fst_5380_; lean_object* v_snd_5381_; lean_object* v___y_5382_; uint8_t v___y_5418_; lean_object* v___y_5419_; lean_object* v___y_5420_; lean_object* v___y_5421_; lean_object* v___y_5422_; lean_object* v___y_5423_; lean_object* v___y_5424_; lean_object* v___y_5425_; uint64_t v_inv_5426_; lean_object* v___y_5427_; lean_object* v___y_5441_; uint8_t v___y_5442_; lean_object* v___y_5443_; lean_object* v___y_5444_; lean_object* v___y_5445_; lean_object* v___y_5446_; lean_object* v___y_5447_; uint64_t v___y_5448_; lean_object* v___y_5449_; lean_object* v___y_5450_; uint8_t v___y_5459_; lean_object* v___y_5460_; lean_object* v___y_5461_; lean_object* v___y_5462_; lean_object* v___y_5463_; lean_object* v___y_5464_; lean_object* v___y_5465_; lean_object* v___y_5466_; lean_object* v___y_5467_; uint64_t v___y_5468_; lean_object* v___y_5471_; uint8_t v___y_5472_; lean_object* v___y_5473_; lean_object* v___y_5474_; lean_object* v___y_5475_; lean_object* v___y_5476_; lean_object* v___y_5477_; uint64_t v___y_5478_; lean_object* v___y_5479_; lean_object* v___y_5480_; uint8_t v___y_5481_; uint8_t v___y_5487_; lean_object* v___y_5488_; uint8_t v___y_5489_; lean_object* v___y_5490_; lean_object* v___y_5491_; lean_object* v___y_5492_; uint64_t v___y_5493_; lean_object* v___y_5494_; lean_object* v___y_5495_; lean_object* v___y_5496_; lean_object* v___y_5497_; lean_object* v___y_5498_; uint8_t v___y_5499_; lean_object* v___y_5512_; uint8_t v___y_5513_; uint64_t v___y_5514_; lean_object* v___y_5515_; uint8_t v___y_5516_; lean_object* v___y_5517_; lean_object* v___y_5518_; lean_object* v___y_5519_; lean_object* v___y_5520_; lean_object* v___y_5521_; lean_object* v___y_5522_; lean_object* v___y_5523_; uint8_t v___y_5524_; lean_object* v___y_5537_; uint8_t v___y_5538_; uint64_t v___y_5539_; lean_object* v___y_5540_; lean_object* v___y_5541_; lean_object* v___y_5542_; lean_object* v___y_5543_; lean_object* v___y_5544_; lean_object* v___y_5545_; lean_object* v___y_5546_; uint8_t v___y_5547_; uint8_t v___y_5553_; lean_object* v___y_5554_; uint8_t v___y_5555_; lean_object* v___y_5556_; lean_object* v___y_5557_; lean_object* v___y_5558_; lean_object* v___y_5559_; lean_object* v___y_5560_; lean_object* v___y_5561_; lean_object* v___y_5562_; lean_object* v___y_5563_; uint8_t v___y_5564_; lean_object* v___y_5579_; uint8_t v___y_5580_; lean_object* v___y_5581_; uint8_t v___y_5582_; lean_object* v___y_5583_; lean_object* v___y_5584_; lean_object* v___y_5585_; lean_object* v___y_5586_; lean_object* v___y_5587_; lean_object* v___y_5588_; lean_object* v___y_5589_; uint8_t v___y_5590_; lean_object* v___y_5628_; uint8_t v___y_5629_; lean_object* v___y_5630_; uint8_t v___y_5631_; lean_object* v___y_5632_; lean_object* v___y_5633_; lean_object* v___y_5634_; lean_object* v___y_5635_; lean_object* v___y_5636_; lean_object* v___y_5637_; lean_object* v___y_5638_; uint8_t v___y_5647_; lean_object* v___y_5648_; lean_object* v_scan_5649_; lean_object* v___y_5650_; lean_object* v___y_5677_; lean_object* v___y_5678_; uint8_t v___y_5679_; lean_object* v___y_5680_; lean_object* v___y_5681_; lean_object* v___y_5682_; lean_object* v___y_5683_; uint64_t v___y_5684_; lean_object* v___y_5702_; uint8_t v___y_5703_; lean_object* v___y_5704_; lean_object* v___y_5705_; lean_object* v___y_5706_; lean_object* v___y_5707_; lean_object* v___y_5708_; uint64_t v___y_5709_; uint8_t v___y_5710_; lean_object* v___y_5716_; lean_object* v___y_5717_; uint8_t v___y_5718_; lean_object* v___y_5719_; lean_object* v___y_5720_; lean_object* v___y_5721_; lean_object* v___y_5722_; uint8_t v___y_5723_; lean_object* v___y_5724_; lean_object* v___y_5725_; uint64_t v___y_5726_; uint8_t v___y_5727_; lean_object* v___y_5740_; uint8_t v___y_5741_; lean_object* v___y_5742_; lean_object* v___y_5743_; lean_object* v___y_5744_; lean_object* v___y_5745_; lean_object* v___y_5746_; uint8_t v___y_5747_; lean_object* v___y_5748_; lean_object* v___y_5749_; uint64_t v___y_5750_; uint8_t v___y_5751_; lean_object* v___y_5764_; lean_object* v___y_5765_; uint8_t v___y_5766_; lean_object* v___y_5767_; lean_object* v___y_5768_; lean_object* v___y_5769_; lean_object* v___y_5770_; uint8_t v___y_5771_; lean_object* v___y_5772_; lean_object* v___y_5773_; uint8_t v___y_5774_; lean_object* v___y_5783_; uint8_t v___y_5784_; lean_object* v___y_5785_; lean_object* v___y_5786_; lean_object* v___y_5787_; lean_object* v___y_5788_; lean_object* v___y_5789_; uint8_t v___y_5790_; lean_object* v___y_5791_; lean_object* v___y_5792_; uint8_t v___y_5793_; uint8_t v___y_5824_; lean_object* v___y_5825_; lean_object* v___y_5826_; lean_object* v___y_5827_; lean_object* v___y_5828_; lean_object* v___y_5829_; lean_object* v___y_5830_; lean_object* v___y_5831_; lean_object* v___y_5832_; uint8_t v___y_5854_; lean_object* v___y_5855_; uint8_t v___y_5856_; lean_object* v___y_5857_; lean_object* v___y_5858_; lean_object* v___y_5859_; lean_object* v___y_5860_; lean_object* v___y_5861_; lean_object* v___y_5862_; lean_object* v___y_5863_; lean_object* v___y_5864_; uint64_t v___y_5865_; uint8_t v___y_5872_; uint8_t v___y_5873_; lean_object* v___y_5874_; lean_object* v___y_5875_; lean_object* v___y_5876_; lean_object* v___y_5877_; lean_object* v___y_5878_; lean_object* v___y_5879_; lean_object* v___y_5880_; lean_object* v___y_5881_; lean_object* v___y_5882_; uint64_t v___y_5883_; uint8_t v___y_5884_; uint64_t v___y_5890_; lean_object* v___y_5891_; lean_object* v___y_5892_; lean_object* v___y_5893_; uint8_t v___y_5894_; lean_object* v___y_5895_; lean_object* v___y_5896_; uint8_t v___y_5897_; uint8_t v___y_5898_; lean_object* v___y_5899_; lean_object* v___y_5900_; lean_object* v___y_5901_; lean_object* v___y_5902_; lean_object* v___y_5903_; uint8_t v___y_5904_; lean_object* v___y_5917_; lean_object* v___y_5918_; lean_object* v___y_5919_; uint8_t v___y_5920_; lean_object* v___y_5921_; lean_object* v___y_5922_; uint64_t v___y_5923_; uint8_t v___y_5924_; uint8_t v___y_5925_; lean_object* v___y_5926_; lean_object* v___y_5927_; lean_object* v___y_5928_; lean_object* v___y_5929_; lean_object* v___y_5930_; uint8_t v___y_5931_; lean_object* v___y_5944_; lean_object* v___y_5945_; lean_object* v___y_5946_; uint8_t v___y_5947_; lean_object* v___y_5948_; lean_object* v___y_5949_; uint8_t v___y_5950_; uint8_t v___y_5951_; lean_object* v___y_5952_; lean_object* v___y_5953_; lean_object* v___y_5954_; lean_object* v___y_5955_; lean_object* v___y_5956_; uint8_t v___y_5957_; lean_object* v___y_5966_; lean_object* v___y_5967_; lean_object* v___y_5968_; uint8_t v___y_5969_; lean_object* v___y_5970_; lean_object* v___y_5971_; uint8_t v___y_5972_; uint8_t v___y_5973_; lean_object* v___y_5974_; lean_object* v___y_5975_; lean_object* v___y_5976_; lean_object* v___y_5977_; lean_object* v___y_5978_; uint8_t v___y_5979_; uint8_t v___y_6010_; lean_object* v___y_6011_; lean_object* v___y_6012_; lean_object* v___y_6013_; lean_object* v___y_6014_; lean_object* v___y_6015_; lean_object* v___y_6016_; lean_object* v___y_6017_; lean_object* v___y_6018_; lean_object* v___y_6019_; uint8_t v___y_6020_; uint8_t v___y_6031_; lean_object* v___y_6032_; lean_object* v___y_6033_; lean_object* v___y_6034_; lean_object* v___y_6035_; lean_object* v___y_6036_; lean_object* v___y_6037_; lean_object* v___y_6038_; lean_object* v___y_6039_; uint64_t v___y_6040_; uint8_t v___y_6043_; lean_object* v___y_6044_; lean_object* v___y_6045_; lean_object* v___y_6046_; lean_object* v___y_6047_; lean_object* v___y_6048_; uint64_t v___y_6049_; lean_object* v___y_6050_; lean_object* v___y_6051_; lean_object* v___y_6052_; uint8_t v___y_6053_; uint8_t v___y_6059_; lean_object* v___y_6060_; lean_object* v___y_6061_; lean_object* v___y_6062_; lean_object* v___y_6063_; lean_object* v___y_6064_; lean_object* v___y_6065_; lean_object* v___y_6066_; uint8_t v___y_6067_; lean_object* v___y_6068_; uint64_t v___y_6069_; uint8_t v___y_6070_; uint8_t v___y_6082_; lean_object* v___y_6083_; lean_object* v___y_6084_; lean_object* v___y_6085_; lean_object* v___y_6086_; lean_object* v___y_6087_; uint64_t v___y_6088_; lean_object* v___y_6089_; lean_object* v___y_6090_; lean_object* v___y_6091_; uint8_t v___y_6092_; uint8_t v___y_6093_; uint8_t v___y_6105_; lean_object* v___y_6106_; lean_object* v___y_6107_; lean_object* v___y_6108_; lean_object* v___y_6109_; lean_object* v___y_6110_; lean_object* v___y_6111_; lean_object* v___y_6112_; uint8_t v___y_6113_; lean_object* v___y_6114_; uint8_t v___y_6115_; uint8_t v___y_6123_; lean_object* v___y_6124_; lean_object* v___y_6125_; lean_object* v___y_6126_; lean_object* v___y_6127_; lean_object* v___y_6128_; lean_object* v___y_6129_; lean_object* v___y_6130_; lean_object* v___y_6131_; lean_object* v___y_6154_; lean_object* v___y_6155_; lean_object* v___y_6156_; lean_object* v___y_6157_; lean_object* v___y_6158_; lean_object* v___y_6176_; 
v_snd_4993_ = lean_ctor_get(v_b_4945_, 1);
lean_inc(v_snd_4993_);
v_snd_4994_ = lean_ctor_get(v_snd_4993_, 1);
lean_inc(v_snd_4994_);
v_snd_4995_ = lean_ctor_get(v_snd_4994_, 1);
lean_inc(v_snd_4995_);
v_snd_4996_ = lean_ctor_get(v_snd_4995_, 1);
lean_inc(v_snd_4996_);
v_snd_4997_ = lean_ctor_get(v_snd_4996_, 1);
lean_inc(v_snd_4997_);
v_snd_4998_ = lean_ctor_get(v___x_4986_, 1);
lean_inc(v_snd_4998_);
lean_dec_ref(v___x_4986_);
v_fst_4999_ = lean_ctor_get(v_b_4945_, 0);
lean_inc(v_fst_4999_);
lean_dec_ref(v_b_4945_);
v_fst_5000_ = lean_ctor_get(v_snd_4993_, 0);
lean_inc(v_fst_5000_);
lean_dec(v_snd_4993_);
v_fst_5001_ = lean_ctor_get(v_snd_4994_, 0);
lean_inc(v_fst_5001_);
lean_dec(v_snd_4994_);
v_fst_5002_ = lean_ctor_get(v_snd_4995_, 0);
lean_inc(v_fst_5002_);
lean_dec(v_snd_4995_);
v_fst_5003_ = lean_ctor_get(v_snd_4996_, 0);
lean_inc(v_fst_5003_);
lean_dec(v_snd_4996_);
v_fst_5004_ = lean_ctor_get(v_snd_4997_, 0);
lean_inc(v_fst_5004_);
v_snd_5005_ = lean_ctor_get(v_snd_4997_, 1);
lean_inc(v_snd_5005_);
lean_dec(v_snd_4997_);
v_reducerRank_5254_ = lean_unsigned_to_nat(0u);
v___x_5314_ = lp_Hex_Hex_Groebner_instInhabitedSparseRow_default;
v___x_5315_ = lean_nat_dec_le(v___x_4936_, v_i_4946_);
if (v___x_5315_ == 0)
{
lean_object* v___x_6191_; 
v___x_6191_ = lean_array_get_borrowed(v___x_5314_, v_reducers_4942_, v_i_4946_);
lean_inc(v___x_6191_);
v___y_6176_ = v___x_6191_;
goto v___jp_6175_;
}
else
{
lean_object* v___x_6192_; lean_object* v___x_6193_; 
v___x_6192_ = lean_nat_sub(v_i_4946_, v___x_4936_);
v___x_6193_ = lean_array_get_borrowed(v___x_5314_, v_targets_4943_, v___x_6192_);
lean_dec(v___x_6192_);
lean_inc(v___x_6193_);
v___y_6176_ = v___x_6193_;
goto v___jp_6175_;
}
v___jp_5006_:
{
lean_object* v___x_5014_; lean_object* v___x_5015_; lean_object* v___x_5016_; 
v___x_5014_ = lean_nat_add(v_snd_5005_, v___x_4985_);
lean_dec(v_snd_5005_);
v___x_5015_ = lean_box(0);
v___x_5016_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_4985_, v___x_5015_, v_fst_4999_, v___y_5011_, v___y_5008_, v_nativePivots_5012_, v___y_5007_, v_fst_5004_, v___x_5014_, v___y_5009_, v___y_5010_, v___y_5013_);
lean_dec(v___y_5010_);
lean_dec(v___y_5009_);
v___y_4956_ = v___x_5016_;
goto v___jp_4955_;
}
v___jp_5017_:
{
lean_object* v___x_5027_; lean_object* v___x_5028_; uint64_t v___x_5029_; lean_object* v___x_5030_; lean_object* v_offset_5031_; uint8_t v___x_5032_; lean_object* v_data_5033_; lean_object* v___x_5034_; uint64_t v___x_5035_; uint64_t v___x_5036_; uint8_t v___x_5037_; lean_object* v___x_5038_; lean_object* v___x_5039_; lean_object* v___x_5040_; uint64_t v___x_5041_; uint64_t v___x_5042_; uint8_t v___x_5043_; lean_object* v___x_5044_; lean_object* v___x_5045_; lean_object* v___x_5046_; uint64_t v___x_5047_; uint64_t v___x_5048_; uint8_t v___x_5049_; lean_object* v___x_5050_; lean_object* v___x_5051_; lean_object* v___x_5052_; 
v___x_5027_ = lean_array_get_size(v_fst_5001_);
v___x_5028_ = lean_nat_add(v___x_5027_, v___x_4985_);
v___x_5029_ = lean_uint64_of_nat(v___x_5028_);
lean_dec(v___x_5028_);
v___x_5030_ = lean_unsigned_to_nat(4u);
v_offset_5031_ = lean_nat_mul(v___y_5023_, v___x_5030_);
lean_dec(v___y_5023_);
v___x_5032_ = lean_uint64_to_uint8(v___x_5029_);
v_data_5033_ = lean_byte_array_set(v_fst_5000_, v_offset_5031_, v___x_5032_);
v___x_5034_ = lean_nat_add(v_offset_5031_, v___x_4985_);
v___x_5035_ = 8ULL;
v___x_5036_ = lean_uint64_shift_right(v___x_5029_, v___x_5035_);
v___x_5037_ = lean_uint64_to_uint8(v___x_5036_);
v___x_5038_ = lean_byte_array_set(v_data_5033_, v___x_5034_, v___x_5037_);
lean_dec(v___x_5034_);
v___x_5039_ = lean_unsigned_to_nat(2u);
v___x_5040_ = lean_nat_add(v_offset_5031_, v___x_5039_);
v___x_5041_ = 16ULL;
v___x_5042_ = lean_uint64_shift_right(v___x_5029_, v___x_5041_);
v___x_5043_ = lean_uint64_to_uint8(v___x_5042_);
v___x_5044_ = lean_byte_array_set(v___x_5038_, v___x_5040_, v___x_5043_);
lean_dec(v___x_5040_);
v___x_5045_ = lean_unsigned_to_nat(3u);
v___x_5046_ = lean_nat_add(v_offset_5031_, v___x_5045_);
lean_dec(v_offset_5031_);
v___x_5047_ = 24ULL;
v___x_5048_ = lean_uint64_shift_right(v___x_5029_, v___x_5047_);
v___x_5049_ = lean_uint64_to_uint8(v___x_5048_);
v___x_5050_ = lean_byte_array_set(v___x_5044_, v___x_5046_, v___x_5049_);
lean_dec(v___x_5046_);
lean_inc(v___y_5021_);
lean_inc_ref(v___y_5022_);
v___x_5051_ = lean_alloc_ctor(0, 3, 9);
lean_ctor_set(v___x_5051_, 0, v___y_5022_);
lean_ctor_set(v___x_5051_, 1, v_snd_5025_);
lean_ctor_set(v___x_5051_, 2, v___y_5021_);
lean_ctor_set_uint8(v___x_5051_, sizeof(void*)*3 + 8, v___y_5018_);
lean_ctor_set_uint64(v___x_5051_, sizeof(void*)*3, v___y_5020_);
v___x_5052_ = lean_array_push(v_fst_5001_, v___x_5051_);
if (v_native_4937_ == 0)
{
lean_dec_ref(v___y_5022_);
v___y_5007_ = v_fst_5024_;
v___y_5008_ = v___x_5052_;
v___y_5009_ = v___y_5019_;
v___y_5010_ = v___y_5021_;
v___y_5011_ = v___x_5050_;
v_nativePivots_5012_ = v_fst_5002_;
v___y_5013_ = v___y_5026_;
goto v___jp_5006_;
}
else
{
lean_object* v_columns_5053_; lean_object* v_coefficients_5054_; lean_object* v___x_5055_; lean_object* v___x_5056_; 
v_columns_5053_ = lean_ctor_get(v___y_5022_, 0);
lean_inc_ref(v_columns_5053_);
v_coefficients_5054_ = lean_ctor_get(v___y_5022_, 1);
lean_inc_ref(v_coefficients_5054_);
lean_dec_ref(v___y_5022_);
lean_inc(v___y_5021_);
v___x_5055_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_5055_, 0, v_columns_5053_);
lean_ctor_set(v___x_5055_, 1, v_coefficients_5054_);
lean_ctor_set(v___x_5055_, 2, v___y_5021_);
v___x_5056_ = lean_array_push(v_fst_5002_, v___x_5055_);
v___y_5007_ = v_fst_5024_;
v___y_5008_ = v___x_5052_;
v___y_5009_ = v___y_5019_;
v___y_5010_ = v___y_5021_;
v___y_5011_ = v___x_5050_;
v_nativePivots_5012_ = v___x_5056_;
v___y_5013_ = v___y_5026_;
goto v___jp_5006_;
}
}
v___jp_5057_:
{
lean_object* v___x_5066_; lean_object* v_fst_5067_; 
v___x_5066_ = lp_Hex_Hex_Groebner_Matrix_inverse(v_field_4932_, v_ctx_4933_, v_limits_4931_, v___y_5065_, v___y_5060_);
v_fst_5067_ = lean_ctor_get(v___x_5066_, 0);
lean_inc(v_fst_5067_);
if (lean_obj_tag(v_fst_5067_) == 0)
{
lean_object* v_snd_5068_; lean_object* v_a_5069_; 
lean_dec_ref(v___y_5064_);
lean_dec(v___y_5063_);
lean_dec_ref(v___y_5062_);
lean_dec(v___y_5061_);
lean_dec(v___y_5059_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_fst_4999_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5068_ = lean_ctor_get(v___x_5066_, 1);
lean_inc(v_snd_5068_);
lean_dec_ref(v___x_5066_);
v_a_5069_ = lean_ctor_get(v_fst_5067_, 0);
lean_inc(v_a_5069_);
lean_dec_ref_known(v_fst_5067_, 1);
v_a_4949_ = v_a_5069_;
v_snd_4950_ = v_snd_5068_;
goto v___jp_4948_;
}
else
{
lean_object* v_snd_5070_; lean_object* v_a_5071_; uint64_t v___x_5072_; lean_object* v___x_5073_; lean_object* v_fst_5074_; 
v_snd_5070_ = lean_ctor_get(v___x_5066_, 1);
lean_inc(v_snd_5070_);
lean_dec_ref(v___x_5066_);
v_a_5071_ = lean_ctor_get(v_fst_5067_, 0);
lean_inc(v_a_5071_);
lean_dec_ref_known(v_fst_5067_, 1);
v___x_5072_ = lean_unbox_uint64(v_a_5071_);
v___x_5073_ = lp_Hex_Hex_Groebner_Matrix_scaleSparse(v_field_4932_, v_ctx_4933_, v_limits_4931_, v___y_5064_, v___x_5072_, v_snd_5070_);
v_fst_5074_ = lean_ctor_get(v___x_5073_, 0);
lean_inc(v_fst_5074_);
if (lean_obj_tag(v_fst_5074_) == 0)
{
lean_object* v_snd_5075_; lean_object* v_a_5076_; 
lean_dec(v_a_5071_);
lean_dec(v___y_5063_);
lean_dec_ref(v___y_5062_);
lean_dec(v___y_5061_);
lean_dec(v___y_5059_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_fst_4999_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5075_ = lean_ctor_get(v___x_5073_, 1);
lean_inc(v_snd_5075_);
lean_dec_ref(v___x_5073_);
v_a_5076_ = lean_ctor_get(v_fst_5074_, 0);
lean_inc(v_a_5076_);
lean_dec_ref_known(v_fst_5074_, 1);
v_a_4949_ = v_a_5076_;
v_snd_4950_ = v_snd_5075_;
goto v___jp_4948_;
}
else
{
lean_object* v_snd_5077_; lean_object* v_a_5078_; uint64_t v___x_5079_; uint64_t v___x_5080_; uint8_t v___x_5081_; 
v_snd_5077_ = lean_ctor_get(v___x_5073_, 1);
lean_inc(v_snd_5077_);
lean_dec_ref(v___x_5073_);
v_a_5078_ = lean_ctor_get(v_fst_5074_, 0);
lean_inc(v_a_5078_);
lean_dec_ref_known(v_fst_5074_, 1);
v___x_5079_ = 1ULL;
v___x_5080_ = lean_unbox_uint64(v_a_5071_);
v___x_5081_ = lean_uint64_dec_eq(v___x_5080_, v___x_5079_);
if (v___x_5081_ == 0)
{
if (lean_obj_tag(v___y_5059_) == 0)
{
uint64_t v___x_5082_; 
v___x_5082_ = lean_unbox_uint64(v_a_5071_);
lean_dec(v_a_5071_);
v___y_5018_ = v___y_5058_;
v___y_5019_ = v___y_5059_;
v___y_5020_ = v___x_5082_;
v___y_5021_ = v___y_5061_;
v___y_5022_ = v_a_5078_;
v___y_5023_ = v___y_5063_;
v_fst_5024_ = v___y_5062_;
v_snd_5025_ = v___y_5059_;
v___y_5026_ = v_snd_5077_;
goto v___jp_5017_;
}
else
{
lean_object* v_val_5083_; lean_object* v___x_5084_; uint64_t v___x_5085_; lean_object* v___x_5086_; lean_object* v_fst_5087_; 
v_val_5083_ = lean_ctor_get(v___y_5059_, 0);
lean_inc(v_val_5083_);
v___x_5084_ = lean_alloc_ctor(2, 1, 8);
lean_ctor_set(v___x_5084_, 0, v_val_5083_);
v___x_5085_ = lean_unbox_uint64(v_a_5071_);
lean_ctor_set_uint64(v___x_5084_, sizeof(void*)*1, v___x_5085_);
v___x_5086_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_4931_, v_provenance_4935_, v___y_5062_, v___x_5084_, v_snd_5077_);
v_fst_5087_ = lean_ctor_get(v___x_5086_, 0);
lean_inc(v_fst_5087_);
if (lean_obj_tag(v_fst_5087_) == 0)
{
lean_object* v_snd_5088_; lean_object* v_a_5089_; 
lean_dec_ref_known(v___y_5059_, 1);
lean_dec(v_a_5078_);
lean_dec(v_a_5071_);
lean_dec(v___y_5063_);
lean_dec(v___y_5061_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_fst_4999_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5088_ = lean_ctor_get(v___x_5086_, 1);
lean_inc(v_snd_5088_);
lean_dec_ref(v___x_5086_);
v_a_5089_ = lean_ctor_get(v_fst_5087_, 0);
lean_inc(v_a_5089_);
lean_dec_ref_known(v_fst_5087_, 1);
v_a_4949_ = v_a_5089_;
v_snd_4950_ = v_snd_5088_;
goto v___jp_4948_;
}
else
{
lean_object* v_a_5090_; lean_object* v_snd_5091_; lean_object* v_fst_5092_; lean_object* v_snd_5093_; uint64_t v___x_5094_; 
v_a_5090_ = lean_ctor_get(v_fst_5087_, 0);
lean_inc(v_a_5090_);
lean_dec_ref_known(v_fst_5087_, 1);
v_snd_5091_ = lean_ctor_get(v___x_5086_, 1);
lean_inc(v_snd_5091_);
lean_dec_ref(v___x_5086_);
v_fst_5092_ = lean_ctor_get(v_a_5090_, 0);
lean_inc(v_fst_5092_);
v_snd_5093_ = lean_ctor_get(v_a_5090_, 1);
lean_inc(v_snd_5093_);
lean_dec(v_a_5090_);
v___x_5094_ = lean_unbox_uint64(v_a_5071_);
lean_dec(v_a_5071_);
v___y_5018_ = v___y_5058_;
v___y_5019_ = v___y_5059_;
v___y_5020_ = v___x_5094_;
v___y_5021_ = v___y_5061_;
v___y_5022_ = v_a_5078_;
v___y_5023_ = v___y_5063_;
v_fst_5024_ = v_fst_5092_;
v_snd_5025_ = v_snd_5093_;
v___y_5026_ = v_snd_5091_;
goto v___jp_5017_;
}
}
}
else
{
uint64_t v___x_5095_; 
v___x_5095_ = lean_unbox_uint64(v_a_5071_);
lean_dec(v_a_5071_);
lean_inc(v___y_5059_);
v___y_5018_ = v___y_5058_;
v___y_5019_ = v___y_5059_;
v___y_5020_ = v___x_5095_;
v___y_5021_ = v___y_5061_;
v___y_5022_ = v_a_5078_;
v___y_5023_ = v___y_5063_;
v_fst_5024_ = v___y_5062_;
v_snd_5025_ = v___y_5059_;
v___y_5026_ = v_snd_5077_;
goto v___jp_5017_;
}
}
}
}
v___jp_5096_:
{
uint64_t v___x_5106_; uint64_t v___x_5107_; uint64_t v___x_5108_; uint64_t v___x_5109_; 
v___x_5106_ = lean_uint8_to_uint64(v___y_5105_);
v___x_5107_ = 24ULL;
v___x_5108_ = lean_uint64_shift_left(v___x_5106_, v___x_5107_);
v___x_5109_ = lean_uint64_lor(v___y_5104_, v___x_5108_);
v___y_5058_ = v___y_5097_;
v___y_5059_ = v___y_5098_;
v___y_5060_ = v___y_5099_;
v___y_5061_ = v___y_5100_;
v___y_5062_ = v___y_5101_;
v___y_5063_ = v___y_5103_;
v___y_5064_ = v___y_5102_;
v___y_5065_ = v___x_5109_;
goto v___jp_5057_;
}
v___jp_5110_:
{
uint64_t v___x_5122_; uint64_t v___x_5123_; uint64_t v___x_5124_; uint64_t v___x_5125_; lean_object* v___x_5126_; uint8_t v___x_5127_; 
v___x_5122_ = lean_uint8_to_uint64(v___y_5121_);
v___x_5123_ = 16ULL;
v___x_5124_ = lean_uint64_shift_left(v___x_5122_, v___x_5123_);
v___x_5125_ = lean_uint64_lor(v___y_5113_, v___x_5124_);
v___x_5126_ = lean_unsigned_to_nat(3u);
v___x_5127_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5114_, v___x_5126_);
if (v___x_5127_ == 0)
{
lean_object* v___x_5128_; lean_object* v___x_5129_; uint8_t v___x_5130_; 
lean_dec_ref(v___y_5114_);
v___x_5128_ = lean_box(v___y_5118_);
v___x_5129_ = l_outOfBounds___redArg(v___x_5128_);
lean_dec(v___x_5128_);
v___x_5130_ = lean_unbox(v___x_5129_);
lean_dec(v___x_5129_);
v___y_5097_ = v___y_5111_;
v___y_5098_ = v___y_5112_;
v___y_5099_ = v___y_5115_;
v___y_5100_ = v___y_5116_;
v___y_5101_ = v___y_5117_;
v___y_5102_ = v___y_5120_;
v___y_5103_ = v___y_5119_;
v___y_5104_ = v___x_5125_;
v___y_5105_ = v___x_5130_;
goto v___jp_5096_;
}
else
{
uint8_t v___x_5131_; 
v___x_5131_ = lean_byte_array_fget(v___y_5114_, v___x_5126_);
lean_dec_ref(v___y_5114_);
v___y_5097_ = v___y_5111_;
v___y_5098_ = v___y_5112_;
v___y_5099_ = v___y_5115_;
v___y_5100_ = v___y_5116_;
v___y_5101_ = v___y_5117_;
v___y_5102_ = v___y_5120_;
v___y_5103_ = v___y_5119_;
v___y_5104_ = v___x_5125_;
v___y_5105_ = v___x_5131_;
goto v___jp_5096_;
}
}
v___jp_5132_:
{
uint64_t v___x_5144_; uint64_t v___x_5145_; uint64_t v___x_5146_; uint64_t v___x_5147_; lean_object* v___x_5148_; uint8_t v___x_5149_; 
v___x_5144_ = lean_uint8_to_uint64(v___y_5143_);
v___x_5145_ = 8ULL;
v___x_5146_ = lean_uint64_shift_left(v___x_5144_, v___x_5145_);
v___x_5147_ = lean_uint64_lor(v___y_5135_, v___x_5146_);
v___x_5148_ = lean_unsigned_to_nat(2u);
v___x_5149_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5137_, v___x_5148_);
if (v___x_5149_ == 0)
{
lean_object* v___x_5150_; lean_object* v___x_5151_; uint8_t v___x_5152_; 
v___x_5150_ = lean_box(v___y_5140_);
v___x_5151_ = l_outOfBounds___redArg(v___x_5150_);
lean_dec(v___x_5150_);
v___x_5152_ = lean_unbox(v___x_5151_);
lean_dec(v___x_5151_);
v___y_5111_ = v___y_5133_;
v___y_5112_ = v___y_5134_;
v___y_5113_ = v___x_5147_;
v___y_5114_ = v___y_5137_;
v___y_5115_ = v___y_5136_;
v___y_5116_ = v___y_5138_;
v___y_5117_ = v___y_5139_;
v___y_5118_ = v___y_5140_;
v___y_5119_ = v___y_5142_;
v___y_5120_ = v___y_5141_;
v___y_5121_ = v___x_5152_;
goto v___jp_5110_;
}
else
{
uint8_t v___x_5153_; 
v___x_5153_ = lean_byte_array_fget(v___y_5137_, v___x_5148_);
v___y_5111_ = v___y_5133_;
v___y_5112_ = v___y_5134_;
v___y_5113_ = v___x_5147_;
v___y_5114_ = v___y_5137_;
v___y_5115_ = v___y_5136_;
v___y_5116_ = v___y_5138_;
v___y_5117_ = v___y_5139_;
v___y_5118_ = v___y_5140_;
v___y_5119_ = v___y_5142_;
v___y_5120_ = v___y_5141_;
v___y_5121_ = v___x_5153_;
goto v___jp_5110_;
}
}
v___jp_5154_:
{
uint64_t v___x_5164_; uint64_t v___x_5165_; uint64_t v___x_5166_; uint64_t v___x_5167_; 
v___x_5164_ = lean_uint8_to_uint64(v___y_5163_);
v___x_5165_ = 8ULL;
v___x_5166_ = lean_uint64_shift_left(v___x_5164_, v___x_5165_);
v___x_5167_ = lean_uint64_lor(v___y_5157_, v___x_5166_);
v___y_5058_ = v___y_5155_;
v___y_5059_ = v___y_5156_;
v___y_5060_ = v___y_5158_;
v___y_5061_ = v___y_5159_;
v___y_5062_ = v___y_5160_;
v___y_5063_ = v___y_5162_;
v___y_5064_ = v___y_5161_;
v___y_5065_ = v___x_5167_;
goto v___jp_5057_;
}
v___jp_5168_:
{
uint64_t v_a_5179_; 
v_a_5179_ = lean_uint8_to_uint64(v___y_5178_);
switch(v_width_4934_)
{
case 0:
{
lean_dec_ref(v___y_5171_);
v___y_5058_ = v___y_5169_;
v___y_5059_ = v___y_5170_;
v___y_5060_ = v___y_5172_;
v___y_5061_ = v___y_5173_;
v___y_5062_ = v___y_5174_;
v___y_5063_ = v___y_5176_;
v___y_5064_ = v___y_5177_;
v___y_5065_ = v_a_5179_;
goto v___jp_5057_;
}
case 1:
{
uint8_t v___x_5180_; 
v___x_5180_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5171_, v___x_4985_);
if (v___x_5180_ == 0)
{
lean_object* v___x_5181_; lean_object* v___x_5182_; uint8_t v___x_5183_; 
lean_dec_ref(v___y_5171_);
v___x_5181_ = lean_box(v___y_5175_);
v___x_5182_ = l_outOfBounds___redArg(v___x_5181_);
lean_dec(v___x_5181_);
v___x_5183_ = lean_unbox(v___x_5182_);
lean_dec(v___x_5182_);
v___y_5155_ = v___y_5169_;
v___y_5156_ = v___y_5170_;
v___y_5157_ = v_a_5179_;
v___y_5158_ = v___y_5172_;
v___y_5159_ = v___y_5173_;
v___y_5160_ = v___y_5174_;
v___y_5161_ = v___y_5177_;
v___y_5162_ = v___y_5176_;
v___y_5163_ = v___x_5183_;
goto v___jp_5154_;
}
else
{
uint8_t v___x_5184_; 
v___x_5184_ = lean_byte_array_fget(v___y_5171_, v___x_4985_);
lean_dec_ref(v___y_5171_);
v___y_5155_ = v___y_5169_;
v___y_5156_ = v___y_5170_;
v___y_5157_ = v_a_5179_;
v___y_5158_ = v___y_5172_;
v___y_5159_ = v___y_5173_;
v___y_5160_ = v___y_5174_;
v___y_5161_ = v___y_5177_;
v___y_5162_ = v___y_5176_;
v___y_5163_ = v___x_5184_;
goto v___jp_5154_;
}
}
default: 
{
uint8_t v___x_5185_; 
v___x_5185_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5171_, v___x_4985_);
if (v___x_5185_ == 0)
{
lean_object* v___x_5186_; lean_object* v___x_5187_; uint8_t v___x_5188_; 
v___x_5186_ = lean_box(v___y_5175_);
v___x_5187_ = l_outOfBounds___redArg(v___x_5186_);
lean_dec(v___x_5186_);
v___x_5188_ = lean_unbox(v___x_5187_);
lean_dec(v___x_5187_);
v___y_5133_ = v___y_5169_;
v___y_5134_ = v___y_5170_;
v___y_5135_ = v_a_5179_;
v___y_5136_ = v___y_5172_;
v___y_5137_ = v___y_5171_;
v___y_5138_ = v___y_5173_;
v___y_5139_ = v___y_5174_;
v___y_5140_ = v___y_5175_;
v___y_5141_ = v___y_5177_;
v___y_5142_ = v___y_5176_;
v___y_5143_ = v___x_5188_;
goto v___jp_5132_;
}
else
{
uint8_t v___x_5189_; 
v___x_5189_ = lean_byte_array_fget(v___y_5171_, v___x_4985_);
v___y_5133_ = v___y_5169_;
v___y_5134_ = v___y_5170_;
v___y_5135_ = v_a_5179_;
v___y_5136_ = v___y_5172_;
v___y_5137_ = v___y_5171_;
v___y_5138_ = v___y_5173_;
v___y_5139_ = v___y_5174_;
v___y_5140_ = v___y_5175_;
v___y_5141_ = v___y_5177_;
v___y_5142_ = v___y_5176_;
v___y_5143_ = v___x_5189_;
goto v___jp_5132_;
}
}
}
}
v___jp_5190_:
{
if (v___y_5191_ == 0)
{
lean_object* v___x_5200_; lean_object* v___x_5201_; 
v___x_5200_ = lean_box(0);
v___x_5201_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_4985_, v___x_5200_, v___y_5194_, v___y_5195_, v___y_5197_, v_nativePivots_5198_, v___y_5193_, v_fst_5004_, v_snd_5005_, v___y_5192_, v___y_5196_, v___y_5199_);
lean_dec(v___y_5196_);
lean_dec(v___y_5192_);
v___y_4956_ = v___x_5201_;
goto v___jp_4955_;
}
else
{
lean_object* v___x_5202_; lean_object* v___x_5203_; lean_object* v___x_5204_; 
v___x_5202_ = lean_nat_add(v_snd_5005_, v___x_4985_);
lean_dec(v_snd_5005_);
v___x_5203_ = lean_box(0);
v___x_5204_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_4985_, v___x_5203_, v___y_5194_, v___y_5195_, v___y_5197_, v_nativePivots_5198_, v___y_5193_, v_fst_5004_, v___x_5202_, v___y_5192_, v___y_5196_, v___y_5199_);
lean_dec(v___y_5196_);
lean_dec(v___y_5192_);
v___y_4956_ = v___x_5204_;
goto v___jp_4955_;
}
}
v___jp_5205_:
{
lean_object* v_work_5212_; lean_object* v_inputEntries_5213_; lean_object* v_outputEntries_5214_; lean_object* v_packedBytes_5215_; lean_object* v_traceNodes_5216_; lean_object* v_processedRows_5217_; lean_object* v_reductions_5218_; lean_object* v_zeroRows_5219_; lean_object* v___x_5221_; uint8_t v_isShared_5222_; uint8_t v_isSharedCheck_5229_; 
v_work_5212_ = lean_ctor_get(v___y_5211_, 0);
v_inputEntries_5213_ = lean_ctor_get(v___y_5211_, 1);
v_outputEntries_5214_ = lean_ctor_get(v___y_5211_, 2);
v_packedBytes_5215_ = lean_ctor_get(v___y_5211_, 3);
v_traceNodes_5216_ = lean_ctor_get(v___y_5211_, 4);
v_processedRows_5217_ = lean_ctor_get(v___y_5211_, 5);
v_reductions_5218_ = lean_ctor_get(v___y_5211_, 6);
v_zeroRows_5219_ = lean_ctor_get(v___y_5211_, 7);
v_isSharedCheck_5229_ = !lean_is_exclusive(v___y_5211_);
if (v_isSharedCheck_5229_ == 0)
{
v___x_5221_ = v___y_5211_;
v_isShared_5222_ = v_isSharedCheck_5229_;
goto v_resetjp_5220_;
}
else
{
lean_inc(v_zeroRows_5219_);
lean_inc(v_reductions_5218_);
lean_inc(v_processedRows_5217_);
lean_inc(v_traceNodes_5216_);
lean_inc(v_packedBytes_5215_);
lean_inc(v_outputEntries_5214_);
lean_inc(v_inputEntries_5213_);
lean_inc(v_work_5212_);
lean_dec(v___y_5211_);
v___x_5221_ = lean_box(0);
v_isShared_5222_ = v_isSharedCheck_5229_;
goto v_resetjp_5220_;
}
v_resetjp_5220_:
{
lean_object* v___x_5223_; lean_object* v___x_5224_; lean_object* v___x_5226_; 
v___x_5223_ = lean_box(0);
v___x_5224_ = lean_nat_add(v_zeroRows_5219_, v___x_4985_);
lean_dec(v_zeroRows_5219_);
if (v_isShared_5222_ == 0)
{
lean_ctor_set(v___x_5221_, 7, v___x_5224_);
v___x_5226_ = v___x_5221_;
goto v_reusejp_5225_;
}
else
{
lean_object* v_reuseFailAlloc_5228_; 
v_reuseFailAlloc_5228_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_5228_, 0, v_work_5212_);
lean_ctor_set(v_reuseFailAlloc_5228_, 1, v_inputEntries_5213_);
lean_ctor_set(v_reuseFailAlloc_5228_, 2, v_outputEntries_5214_);
lean_ctor_set(v_reuseFailAlloc_5228_, 3, v_packedBytes_5215_);
lean_ctor_set(v_reuseFailAlloc_5228_, 4, v_traceNodes_5216_);
lean_ctor_set(v_reuseFailAlloc_5228_, 5, v_processedRows_5217_);
lean_ctor_set(v_reuseFailAlloc_5228_, 6, v_reductions_5218_);
lean_ctor_set(v_reuseFailAlloc_5228_, 7, v___x_5224_);
v___x_5226_ = v_reuseFailAlloc_5228_;
goto v_reusejp_5225_;
}
v_reusejp_5225_:
{
lean_object* v___x_5227_; 
v___x_5227_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_4985_, v___x_5223_, v___y_5207_, v_fst_5000_, v_fst_5001_, v_fst_5002_, v___y_5209_, v_remainders_5210_, v_snd_5005_, v___y_5206_, v___y_5208_, v___x_5226_);
lean_dec(v___y_5208_);
lean_dec(v___y_5206_);
v___y_4956_ = v___x_5227_;
goto v___jp_4955_;
}
}
}
v___jp_5230_:
{
lean_object* v_work_5236_; lean_object* v_inputEntries_5237_; lean_object* v_outputEntries_5238_; lean_object* v_packedBytes_5239_; lean_object* v_traceNodes_5240_; lean_object* v_processedRows_5241_; lean_object* v_reductions_5242_; lean_object* v_zeroRows_5243_; lean_object* v___x_5245_; uint8_t v_isShared_5246_; uint8_t v_isSharedCheck_5253_; 
v_work_5236_ = lean_ctor_get(v___y_5235_, 0);
v_inputEntries_5237_ = lean_ctor_get(v___y_5235_, 1);
v_outputEntries_5238_ = lean_ctor_get(v___y_5235_, 2);
v_packedBytes_5239_ = lean_ctor_get(v___y_5235_, 3);
v_traceNodes_5240_ = lean_ctor_get(v___y_5235_, 4);
v_processedRows_5241_ = lean_ctor_get(v___y_5235_, 5);
v_reductions_5242_ = lean_ctor_get(v___y_5235_, 6);
v_zeroRows_5243_ = lean_ctor_get(v___y_5235_, 7);
v_isSharedCheck_5253_ = !lean_is_exclusive(v___y_5235_);
if (v_isSharedCheck_5253_ == 0)
{
v___x_5245_ = v___y_5235_;
v_isShared_5246_ = v_isSharedCheck_5253_;
goto v_resetjp_5244_;
}
else
{
lean_inc(v_zeroRows_5243_);
lean_inc(v_reductions_5242_);
lean_inc(v_processedRows_5241_);
lean_inc(v_traceNodes_5240_);
lean_inc(v_packedBytes_5239_);
lean_inc(v_outputEntries_5238_);
lean_inc(v_inputEntries_5237_);
lean_inc(v_work_5236_);
lean_dec(v___y_5235_);
v___x_5245_ = lean_box(0);
v_isShared_5246_ = v_isSharedCheck_5253_;
goto v_resetjp_5244_;
}
v_resetjp_5244_:
{
lean_object* v___x_5247_; lean_object* v___x_5248_; lean_object* v___x_5250_; 
v___x_5247_ = lean_box(0);
v___x_5248_ = lean_nat_add(v_zeroRows_5243_, v___x_4985_);
lean_dec(v_zeroRows_5243_);
if (v_isShared_5246_ == 0)
{
lean_ctor_set(v___x_5245_, 7, v___x_5248_);
v___x_5250_ = v___x_5245_;
goto v_reusejp_5249_;
}
else
{
lean_object* v_reuseFailAlloc_5252_; 
v_reuseFailAlloc_5252_ = lean_alloc_ctor(0, 8, 0);
lean_ctor_set(v_reuseFailAlloc_5252_, 0, v_work_5236_);
lean_ctor_set(v_reuseFailAlloc_5252_, 1, v_inputEntries_5237_);
lean_ctor_set(v_reuseFailAlloc_5252_, 2, v_outputEntries_5238_);
lean_ctor_set(v_reuseFailAlloc_5252_, 3, v_packedBytes_5239_);
lean_ctor_set(v_reuseFailAlloc_5252_, 4, v_traceNodes_5240_);
lean_ctor_set(v_reuseFailAlloc_5252_, 5, v_processedRows_5241_);
lean_ctor_set(v_reuseFailAlloc_5252_, 6, v_reductions_5242_);
lean_ctor_set(v_reuseFailAlloc_5252_, 7, v___x_5248_);
v___x_5250_ = v_reuseFailAlloc_5252_;
goto v_reusejp_5249_;
}
v_reusejp_5249_:
{
lean_object* v___x_5251_; 
v___x_5251_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_4985_, v___x_5247_, v_fst_4999_, v_fst_5000_, v_fst_5001_, v_fst_5002_, v___y_5233_, v_remainders_5234_, v_snd_5005_, v___y_5231_, v___y_5232_, v___x_5250_);
lean_dec(v___y_5232_);
lean_dec(v___y_5231_);
v___y_4956_ = v___x_5251_;
goto v___jp_4955_;
}
}
}
v___jp_5255_:
{
if (v___y_5265_ == 0)
{
uint8_t v___x_5266_; 
v___x_5266_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5259_, v_reducerRank_5254_);
if (v___x_5266_ == 0)
{
lean_object* v___x_5267_; lean_object* v___x_5268_; uint8_t v___x_5269_; 
v___x_5267_ = lean_box(v___y_5262_);
v___x_5268_ = l_outOfBounds___redArg(v___x_5267_);
lean_dec(v___x_5267_);
v___x_5269_ = lean_unbox(v___x_5268_);
lean_dec(v___x_5268_);
v___y_5169_ = v___y_5256_;
v___y_5170_ = v___y_5257_;
v___y_5171_ = v___y_5259_;
v___y_5172_ = v___y_5258_;
v___y_5173_ = v___y_5260_;
v___y_5174_ = v___y_5261_;
v___y_5175_ = v___y_5262_;
v___y_5176_ = v___y_5264_;
v___y_5177_ = v___y_5263_;
v___y_5178_ = v___x_5269_;
goto v___jp_5168_;
}
else
{
uint8_t v___x_5270_; 
v___x_5270_ = lean_byte_array_fget(v___y_5259_, v_reducerRank_5254_);
v___y_5169_ = v___y_5256_;
v___y_5170_ = v___y_5257_;
v___y_5171_ = v___y_5259_;
v___y_5172_ = v___y_5258_;
v___y_5173_ = v___y_5260_;
v___y_5174_ = v___y_5261_;
v___y_5175_ = v___y_5262_;
v___y_5176_ = v___y_5264_;
v___y_5177_ = v___y_5263_;
v___y_5178_ = v___x_5270_;
goto v___jp_5168_;
}
}
else
{
size_t v_pos_5271_; uint8_t v___x_5272_; uint64_t v_a_5273_; 
v_pos_5271_ = ((size_t)0ULL);
v___x_5272_ = lean_byte_array_uget(v___y_5259_, v_pos_5271_);
v_a_5273_ = lean_uint8_to_uint64(v___x_5272_);
switch(v_width_4934_)
{
case 0:
{
lean_dec_ref(v___y_5259_);
v___y_5058_ = v___y_5256_;
v___y_5059_ = v___y_5257_;
v___y_5060_ = v___y_5258_;
v___y_5061_ = v___y_5260_;
v___y_5062_ = v___y_5261_;
v___y_5063_ = v___y_5264_;
v___y_5064_ = v___y_5263_;
v___y_5065_ = v_a_5273_;
goto v___jp_5057_;
}
case 1:
{
size_t v___x_5274_; uint8_t v___x_5275_; uint64_t v___x_5276_; uint64_t v___x_5277_; uint64_t v___x_5278_; uint64_t v___x_5279_; 
v___x_5274_ = ((size_t)1ULL);
v___x_5275_ = lean_byte_array_uget(v___y_5259_, v___x_5274_);
lean_dec_ref(v___y_5259_);
v___x_5276_ = lean_uint8_to_uint64(v___x_5275_);
v___x_5277_ = 8ULL;
v___x_5278_ = lean_uint64_shift_left(v___x_5276_, v___x_5277_);
v___x_5279_ = lean_uint64_lor(v_a_5273_, v___x_5278_);
v___y_5058_ = v___y_5256_;
v___y_5059_ = v___y_5257_;
v___y_5060_ = v___y_5258_;
v___y_5061_ = v___y_5260_;
v___y_5062_ = v___y_5261_;
v___y_5063_ = v___y_5264_;
v___y_5064_ = v___y_5263_;
v___y_5065_ = v___x_5279_;
goto v___jp_5057_;
}
default: 
{
size_t v___x_5280_; uint8_t v___x_5281_; uint64_t v___x_5282_; uint64_t v___x_5283_; uint64_t v___x_5284_; uint64_t v___x_5285_; size_t v___x_5286_; uint8_t v___x_5287_; uint64_t v___x_5288_; uint64_t v___x_5289_; uint64_t v___x_5290_; uint64_t v___x_5291_; size_t v___x_5292_; uint8_t v___x_5293_; uint64_t v___x_5294_; uint64_t v___x_5295_; uint64_t v___x_5296_; uint64_t v___x_5297_; 
v___x_5280_ = ((size_t)1ULL);
v___x_5281_ = lean_byte_array_uget(v___y_5259_, v___x_5280_);
v___x_5282_ = lean_uint8_to_uint64(v___x_5281_);
v___x_5283_ = 8ULL;
v___x_5284_ = lean_uint64_shift_left(v___x_5282_, v___x_5283_);
v___x_5285_ = lean_uint64_lor(v_a_5273_, v___x_5284_);
v___x_5286_ = ((size_t)2ULL);
v___x_5287_ = lean_byte_array_uget(v___y_5259_, v___x_5286_);
v___x_5288_ = lean_uint8_to_uint64(v___x_5287_);
v___x_5289_ = 16ULL;
v___x_5290_ = lean_uint64_shift_left(v___x_5288_, v___x_5289_);
v___x_5291_ = lean_uint64_lor(v___x_5285_, v___x_5290_);
v___x_5292_ = ((size_t)3ULL);
v___x_5293_ = lean_byte_array_uget(v___y_5259_, v___x_5292_);
lean_dec_ref(v___y_5259_);
v___x_5294_ = lean_uint8_to_uint64(v___x_5293_);
v___x_5295_ = 24ULL;
v___x_5296_ = lean_uint64_shift_left(v___x_5294_, v___x_5295_);
v___x_5297_ = lean_uint64_lor(v___x_5291_, v___x_5296_);
v___y_5058_ = v___y_5256_;
v___y_5059_ = v___y_5257_;
v___y_5060_ = v___y_5258_;
v___y_5061_ = v___y_5260_;
v___y_5062_ = v___y_5261_;
v___y_5063_ = v___y_5264_;
v___y_5064_ = v___y_5263_;
v___y_5065_ = v___x_5297_;
goto v___jp_5057_;
}
}
}
}
v___jp_5298_:
{
lean_object* v___x_5309_; uint8_t v___x_5310_; 
v___x_5309_ = lean_byte_array_size(v___y_5302_);
v___x_5310_ = lean_nat_dec_le(v___y_5308_, v___x_5309_);
if (v___x_5310_ == 0)
{
v___y_5256_ = v___y_5299_;
v___y_5257_ = v___y_5300_;
v___y_5258_ = v___y_5301_;
v___y_5259_ = v___y_5302_;
v___y_5260_ = v___y_5303_;
v___y_5261_ = v___y_5304_;
v___y_5262_ = v___y_5305_;
v___y_5263_ = v___y_5307_;
v___y_5264_ = v___y_5306_;
v___y_5265_ = v___x_5310_;
goto v___jp_5255_;
}
else
{
size_t v___x_5311_; lean_object* v___x_5312_; uint8_t v___x_5313_; 
v___x_5311_ = lean_usize_of_nat(v___y_5308_);
v___x_5312_ = lean_usize_to_nat(v___x_5311_);
v___x_5313_ = lean_nat_dec_eq(v___x_5312_, v___y_5308_);
lean_dec(v___x_5312_);
v___y_5256_ = v___y_5299_;
v___y_5257_ = v___y_5300_;
v___y_5258_ = v___y_5301_;
v___y_5259_ = v___y_5302_;
v___y_5260_ = v___y_5303_;
v___y_5261_ = v___y_5304_;
v___y_5262_ = v___y_5305_;
v___y_5263_ = v___y_5307_;
v___y_5264_ = v___y_5306_;
v___y_5265_ = v___x_5313_;
goto v___jp_5255_;
}
}
v___jp_5316_:
{
lean_object* v___x_5327_; lean_object* v___x_5328_; uint64_t v___x_5329_; lean_object* v___x_5330_; lean_object* v_offset_5331_; uint8_t v___x_5332_; lean_object* v_data_5333_; lean_object* v___x_5334_; uint64_t v___x_5335_; uint64_t v___x_5336_; uint8_t v___x_5337_; lean_object* v___x_5338_; lean_object* v___x_5339_; lean_object* v___x_5340_; uint64_t v___x_5341_; uint64_t v___x_5342_; uint8_t v___x_5343_; lean_object* v___x_5344_; lean_object* v___x_5345_; lean_object* v___x_5346_; uint64_t v___x_5347_; uint64_t v___x_5348_; uint8_t v___x_5349_; lean_object* v___x_5350_; lean_object* v___x_5351_; lean_object* v___x_5352_; 
v___x_5327_ = lean_array_get_size(v_fst_5001_);
v___x_5328_ = lean_nat_add(v___x_5327_, v___x_4985_);
v___x_5329_ = lean_uint64_of_nat(v___x_5328_);
lean_dec(v___x_5328_);
v___x_5330_ = lean_unsigned_to_nat(4u);
v_offset_5331_ = lean_nat_mul(v___y_5321_, v___x_5330_);
lean_dec(v___y_5321_);
v___x_5332_ = lean_uint64_to_uint8(v___x_5329_);
v_data_5333_ = lean_byte_array_set(v_fst_5000_, v_offset_5331_, v___x_5332_);
v___x_5334_ = lean_nat_add(v_offset_5331_, v___x_4985_);
v___x_5335_ = 8ULL;
v___x_5336_ = lean_uint64_shift_right(v___x_5329_, v___x_5335_);
v___x_5337_ = lean_uint64_to_uint8(v___x_5336_);
v___x_5338_ = lean_byte_array_set(v_data_5333_, v___x_5334_, v___x_5337_);
lean_dec(v___x_5334_);
v___x_5339_ = lean_unsigned_to_nat(2u);
v___x_5340_ = lean_nat_add(v_offset_5331_, v___x_5339_);
v___x_5341_ = 16ULL;
v___x_5342_ = lean_uint64_shift_right(v___x_5329_, v___x_5341_);
v___x_5343_ = lean_uint64_to_uint8(v___x_5342_);
v___x_5344_ = lean_byte_array_set(v___x_5338_, v___x_5340_, v___x_5343_);
lean_dec(v___x_5340_);
v___x_5345_ = lean_unsigned_to_nat(3u);
v___x_5346_ = lean_nat_add(v_offset_5331_, v___x_5345_);
lean_dec(v_offset_5331_);
v___x_5347_ = 24ULL;
v___x_5348_ = lean_uint64_shift_right(v___x_5329_, v___x_5347_);
v___x_5349_ = lean_uint64_to_uint8(v___x_5348_);
v___x_5350_ = lean_byte_array_set(v___x_5344_, v___x_5346_, v___x_5349_);
lean_dec(v___x_5346_);
lean_inc(v___y_5326_);
lean_inc_ref(v___y_5323_);
v___x_5351_ = lean_alloc_ctor(0, 3, 9);
lean_ctor_set(v___x_5351_, 0, v___y_5323_);
lean_ctor_set(v___x_5351_, 1, v___y_5325_);
lean_ctor_set(v___x_5351_, 2, v___y_5326_);
lean_ctor_set_uint8(v___x_5351_, sizeof(void*)*3 + 8, v___x_5315_);
lean_ctor_set_uint64(v___x_5351_, sizeof(void*)*3, v___y_5324_);
v___x_5352_ = lean_array_push(v_fst_5001_, v___x_5351_);
if (v_native_4937_ == 0)
{
lean_dec_ref(v___y_5323_);
v___y_5191_ = v___y_5317_;
v___y_5192_ = v___y_5319_;
v___y_5193_ = v___y_5320_;
v___y_5194_ = v___y_5322_;
v___y_5195_ = v___x_5350_;
v___y_5196_ = v___y_5326_;
v___y_5197_ = v___x_5352_;
v_nativePivots_5198_ = v_fst_5002_;
v___y_5199_ = v___y_5318_;
goto v___jp_5190_;
}
else
{
lean_object* v_columns_5353_; lean_object* v_coefficients_5354_; lean_object* v___x_5355_; lean_object* v___x_5356_; 
v_columns_5353_ = lean_ctor_get(v___y_5323_, 0);
lean_inc_ref(v_columns_5353_);
v_coefficients_5354_ = lean_ctor_get(v___y_5323_, 1);
lean_inc_ref(v_coefficients_5354_);
lean_dec_ref(v___y_5323_);
lean_inc(v___y_5326_);
v___x_5355_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_5355_, 0, v_columns_5353_);
lean_ctor_set(v___x_5355_, 1, v_coefficients_5354_);
lean_ctor_set(v___x_5355_, 2, v___y_5326_);
v___x_5356_ = lean_array_push(v_fst_5002_, v___x_5355_);
v___y_5191_ = v___y_5317_;
v___y_5192_ = v___y_5319_;
v___y_5193_ = v___y_5320_;
v___y_5194_ = v___y_5322_;
v___y_5195_ = v___x_5350_;
v___y_5196_ = v___y_5326_;
v___y_5197_ = v___x_5352_;
v_nativePivots_5198_ = v___x_5356_;
v___y_5199_ = v___y_5318_;
goto v___jp_5190_;
}
}
v___jp_5357_:
{
if (v_independent_4939_ == 0)
{
v___y_5317_ = v___y_5358_;
v___y_5318_ = v___y_5367_;
v___y_5319_ = v___y_5359_;
v___y_5320_ = v___y_5360_;
v___y_5321_ = v___y_5361_;
v___y_5322_ = v_dense_5365_;
v___y_5323_ = v_output_5366_;
v___y_5324_ = v___y_5362_;
v___y_5325_ = v___y_5363_;
v___y_5326_ = v___y_5364_;
goto v___jp_5316_;
}
else
{
if (v___x_5315_ == 0)
{
v___y_5317_ = v___y_5358_;
v___y_5318_ = v___y_5367_;
v___y_5319_ = v___y_5359_;
v___y_5320_ = v___y_5360_;
v___y_5321_ = v___y_5361_;
v___y_5322_ = v_dense_5365_;
v___y_5323_ = v_output_5366_;
v___y_5324_ = v___y_5362_;
v___y_5325_ = v___y_5363_;
v___y_5326_ = v___y_5364_;
goto v___jp_5316_;
}
else
{
lean_object* v___x_5368_; lean_object* v___x_5369_; lean_object* v___x_5370_; lean_object* v___x_5371_; 
lean_dec(v___y_5361_);
lean_inc(v___y_5364_);
v___x_5368_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_5368_, 0, v_output_5366_);
lean_ctor_set(v___x_5368_, 1, v___y_5363_);
lean_ctor_set(v___x_5368_, 2, v___y_5364_);
v___x_5369_ = lean_array_push(v_fst_5004_, v___x_5368_);
v___x_5370_ = lean_box(0);
v___x_5371_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___lam__5(v___x_4985_, v___x_5370_, v_dense_5365_, v_fst_5000_, v_fst_5001_, v_fst_5002_, v___y_5360_, v___x_5369_, v_snd_5005_, v___y_5359_, v___y_5364_, v___y_5367_);
lean_dec(v___y_5364_);
lean_dec(v___y_5359_);
v___y_4956_ = v___x_5371_;
goto v___jp_4955_;
}
}
}
v___jp_5372_:
{
lean_object* v___x_5383_; lean_object* v___x_5384_; lean_object* v___x_5385_; lean_object* v___x_5386_; lean_object* v_fst_5387_; 
v___x_5383_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0);
v___x_5384_ = lean_nat_add(v___y_5373_, v___x_4985_);
v___x_5385_ = lean_nat_sub(v___x_5384_, v___y_5376_);
v___x_5386_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_4931_, v___x_5385_, v___y_5382_);
lean_dec(v___x_5385_);
v_fst_5387_ = lean_ctor_get(v___x_5386_, 0);
lean_inc(v_fst_5387_);
if (lean_obj_tag(v_fst_5387_) == 0)
{
lean_object* v_snd_5388_; lean_object* v_a_5389_; 
lean_dec(v___x_5384_);
lean_dec(v_snd_5381_);
lean_dec_ref(v_fst_5380_);
lean_dec(v___y_5379_);
lean_dec_ref(v___y_5377_);
lean_dec(v___y_5376_);
lean_dec(v___y_5375_);
lean_dec(v___y_5373_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5388_ = lean_ctor_get(v___x_5386_, 1);
lean_inc(v_snd_5388_);
lean_dec_ref(v___x_5386_);
v_a_5389_ = lean_ctor_get(v_fst_5387_, 0);
lean_inc(v_a_5389_);
lean_dec_ref_known(v_fst_5387_, 1);
v_a_4949_ = v_a_5389_;
v_snd_4950_ = v_snd_5388_;
goto v___jp_4948_;
}
else
{
lean_dec_ref_known(v_fst_5387_, 1);
if (v_native_4937_ == 0)
{
lean_object* v_snd_5390_; lean_object* v___x_5392_; uint8_t v_isShared_5393_; uint8_t v_isSharedCheck_5406_; 
lean_dec(v___y_5373_);
v_snd_5390_ = lean_ctor_get(v___x_5386_, 1);
v_isSharedCheck_5406_ = !lean_is_exclusive(v___x_5386_);
if (v_isSharedCheck_5406_ == 0)
{
lean_object* v_unused_5407_; 
v_unused_5407_ = lean_ctor_get(v___x_5386_, 0);
lean_dec(v_unused_5407_);
v___x_5392_ = v___x_5386_;
v_isShared_5393_ = v_isSharedCheck_5406_;
goto v_resetjp_5391_;
}
else
{
lean_inc(v_snd_5390_);
lean_dec(v___x_5386_);
v___x_5392_ = lean_box(0);
v_isShared_5393_ = v_isSharedCheck_5406_;
goto v_resetjp_5391_;
}
v_resetjp_5391_:
{
lean_object* v___x_5394_; lean_object* v___x_5396_; 
lean_inc(v___y_5376_);
v___x_5394_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_5394_, 0, v___y_5376_);
lean_ctor_set(v___x_5394_, 1, v___x_5384_);
lean_ctor_set(v___x_5394_, 2, v___x_4985_);
if (v_isShared_5393_ == 0)
{
lean_ctor_set(v___x_5392_, 1, v___x_5383_);
lean_ctor_set(v___x_5392_, 0, v___y_5377_);
v___x_5396_ = v___x_5392_;
goto v_reusejp_5395_;
}
else
{
lean_object* v_reuseFailAlloc_5405_; 
v_reuseFailAlloc_5405_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_5405_, 0, v___y_5377_);
lean_ctor_set(v_reuseFailAlloc_5405_, 1, v___x_5383_);
v___x_5396_ = v_reuseFailAlloc_5405_;
goto v_reusejp_5395_;
}
v_reusejp_5395_:
{
lean_object* v___x_5397_; lean_object* v_fst_5398_; 
lean_inc(v___y_5376_);
v___x_5397_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg(v_width_4934_, v_limits_4931_, v___y_4938_, v___y_5378_, v_field_4932_, v_ctx_4933_, v___x_5394_, v___x_5396_, v___y_5376_, v_snd_5390_);
lean_dec_ref_known(v___x_5394_, 3);
v_fst_5398_ = lean_ctor_get(v___x_5397_, 0);
lean_inc(v_fst_5398_);
if (lean_obj_tag(v_fst_5398_) == 0)
{
lean_object* v_snd_5399_; lean_object* v_a_5400_; 
lean_dec(v_snd_5381_);
lean_dec_ref(v_fst_5380_);
lean_dec(v___y_5379_);
lean_dec(v___y_5376_);
lean_dec(v___y_5375_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5399_ = lean_ctor_get(v___x_5397_, 1);
lean_inc(v_snd_5399_);
lean_dec_ref(v___x_5397_);
v_a_5400_ = lean_ctor_get(v_fst_5398_, 0);
lean_inc(v_a_5400_);
lean_dec_ref_known(v_fst_5398_, 1);
v_a_4949_ = v_a_5400_;
v_snd_4950_ = v_snd_5399_;
goto v___jp_4948_;
}
else
{
lean_object* v_a_5401_; lean_object* v_snd_5402_; lean_object* v_fst_5403_; lean_object* v_snd_5404_; 
v_a_5401_ = lean_ctor_get(v_fst_5398_, 0);
lean_inc(v_a_5401_);
lean_dec_ref_known(v_fst_5398_, 1);
v_snd_5402_ = lean_ctor_get(v___x_5397_, 1);
lean_inc(v_snd_5402_);
lean_dec_ref(v___x_5397_);
v_fst_5403_ = lean_ctor_get(v_a_5401_, 0);
lean_inc(v_fst_5403_);
v_snd_5404_ = lean_ctor_get(v_a_5401_, 1);
lean_inc(v_snd_5404_);
lean_dec(v_a_5401_);
v___y_5358_ = v___y_5374_;
v___y_5359_ = v___y_5375_;
v___y_5360_ = v_fst_5380_;
v___y_5361_ = v___y_5376_;
v___y_5362_ = v___y_5378_;
v___y_5363_ = v_snd_5381_;
v___y_5364_ = v___y_5379_;
v_dense_5365_ = v_fst_5403_;
v_output_5366_ = v_snd_5404_;
v___y_5367_ = v_snd_5402_;
goto v___jp_5357_;
}
}
}
}
else
{
lean_object* v_snd_5408_; lean_object* v___x_5409_; lean_object* v_fst_5410_; 
lean_dec(v___x_5384_);
v_snd_5408_ = lean_ctor_get(v___x_5386_, 1);
lean_inc(v_snd_5408_);
lean_dec_ref(v___x_5386_);
lean_inc(v___y_5376_);
v___x_5409_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeGather(v_field_4932_, v_limits_4931_, v___y_5377_, v___y_5376_, v___y_5373_, v___y_5378_, v_snd_5408_);
lean_dec(v___y_5373_);
v_fst_5410_ = lean_ctor_get(v___x_5409_, 0);
lean_inc(v_fst_5410_);
if (lean_obj_tag(v_fst_5410_) == 0)
{
lean_object* v_snd_5411_; lean_object* v_a_5412_; 
lean_dec(v_snd_5381_);
lean_dec_ref(v_fst_5380_);
lean_dec(v___y_5379_);
lean_dec(v___y_5376_);
lean_dec(v___y_5375_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5411_ = lean_ctor_get(v___x_5409_, 1);
lean_inc(v_snd_5411_);
lean_dec_ref(v___x_5409_);
v_a_5412_ = lean_ctor_get(v_fst_5410_, 0);
lean_inc(v_a_5412_);
lean_dec_ref_known(v_fst_5410_, 1);
v_a_4949_ = v_a_5412_;
v_snd_4950_ = v_snd_5411_;
goto v___jp_4948_;
}
else
{
lean_object* v_a_5413_; lean_object* v_snd_5414_; lean_object* v_fst_5415_; lean_object* v_snd_5416_; 
v_a_5413_ = lean_ctor_get(v_fst_5410_, 0);
lean_inc(v_a_5413_);
lean_dec_ref_known(v_fst_5410_, 1);
v_snd_5414_ = lean_ctor_get(v___x_5409_, 1);
lean_inc(v_snd_5414_);
lean_dec_ref(v___x_5409_);
v_fst_5415_ = lean_ctor_get(v_a_5413_, 0);
lean_inc(v_fst_5415_);
v_snd_5416_ = lean_ctor_get(v_a_5413_, 1);
lean_inc(v_snd_5416_);
lean_dec(v_a_5413_);
v___y_5358_ = v___y_5374_;
v___y_5359_ = v___y_5375_;
v___y_5360_ = v_fst_5380_;
v___y_5361_ = v___y_5376_;
v___y_5362_ = v___y_5378_;
v___y_5363_ = v_snd_5381_;
v___y_5364_ = v___y_5379_;
v_dense_5365_ = v_snd_5416_;
v_output_5366_ = v_fst_5415_;
v___y_5367_ = v_snd_5414_;
goto v___jp_5357_;
}
}
}
}
v___jp_5417_:
{
uint64_t v___x_5428_; uint8_t v___x_5429_; 
v___x_5428_ = 1ULL;
v___x_5429_ = lean_uint64_dec_eq(v_inv_5426_, v___x_5428_);
if (v___x_5429_ == 0)
{
if (lean_obj_tag(v___y_5420_) == 0)
{
lean_inc(v___y_5423_);
v___y_5373_ = v___y_5419_;
v___y_5374_ = v___y_5418_;
v___y_5375_ = v___y_5420_;
v___y_5376_ = v___y_5421_;
v___y_5377_ = v___y_5422_;
v___y_5378_ = v_inv_5426_;
v___y_5379_ = v___y_5424_;
v_fst_5380_ = v___y_5425_;
v_snd_5381_ = v___y_5423_;
v___y_5382_ = v___y_5427_;
goto v___jp_5372_;
}
else
{
lean_object* v_val_5430_; lean_object* v___x_5431_; lean_object* v___x_5432_; lean_object* v_fst_5433_; 
v_val_5430_ = lean_ctor_get(v___y_5420_, 0);
lean_inc(v_val_5430_);
v___x_5431_ = lean_alloc_ctor(2, 1, 8);
lean_ctor_set(v___x_5431_, 0, v_val_5430_);
lean_ctor_set_uint64(v___x_5431_, sizeof(void*)*1, v_inv_5426_);
v___x_5432_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_4931_, v_provenance_4935_, v___y_5425_, v___x_5431_, v___y_5427_);
v_fst_5433_ = lean_ctor_get(v___x_5432_, 0);
lean_inc(v_fst_5433_);
if (lean_obj_tag(v_fst_5433_) == 0)
{
lean_object* v_snd_5434_; lean_object* v_a_5435_; 
lean_dec_ref_known(v___y_5420_, 1);
lean_dec(v___y_5424_);
lean_dec_ref(v___y_5422_);
lean_dec(v___y_5421_);
lean_dec(v___y_5419_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5434_ = lean_ctor_get(v___x_5432_, 1);
lean_inc(v_snd_5434_);
lean_dec_ref(v___x_5432_);
v_a_5435_ = lean_ctor_get(v_fst_5433_, 0);
lean_inc(v_a_5435_);
lean_dec_ref_known(v_fst_5433_, 1);
v_a_4949_ = v_a_5435_;
v_snd_4950_ = v_snd_5434_;
goto v___jp_4948_;
}
else
{
lean_object* v_a_5436_; lean_object* v_snd_5437_; lean_object* v_fst_5438_; lean_object* v_snd_5439_; 
v_a_5436_ = lean_ctor_get(v_fst_5433_, 0);
lean_inc(v_a_5436_);
lean_dec_ref_known(v_fst_5433_, 1);
v_snd_5437_ = lean_ctor_get(v___x_5432_, 1);
lean_inc(v_snd_5437_);
lean_dec_ref(v___x_5432_);
v_fst_5438_ = lean_ctor_get(v_a_5436_, 0);
lean_inc(v_fst_5438_);
v_snd_5439_ = lean_ctor_get(v_a_5436_, 1);
lean_inc(v_snd_5439_);
lean_dec(v_a_5436_);
v___y_5373_ = v___y_5419_;
v___y_5374_ = v___y_5418_;
v___y_5375_ = v___y_5420_;
v___y_5376_ = v___y_5421_;
v___y_5377_ = v___y_5422_;
v___y_5378_ = v_inv_5426_;
v___y_5379_ = v___y_5424_;
v_fst_5380_ = v_fst_5438_;
v_snd_5381_ = v_snd_5439_;
v___y_5382_ = v_snd_5437_;
goto v___jp_5372_;
}
}
}
else
{
lean_inc(v___y_5420_);
v___y_5373_ = v___y_5419_;
v___y_5374_ = v___y_5418_;
v___y_5375_ = v___y_5420_;
v___y_5376_ = v___y_5421_;
v___y_5377_ = v___y_5422_;
v___y_5378_ = v_inv_5426_;
v___y_5379_ = v___y_5424_;
v_fst_5380_ = v___y_5425_;
v_snd_5381_ = v___y_5420_;
v___y_5382_ = v___y_5427_;
goto v___jp_5372_;
}
}
v___jp_5440_:
{
lean_object* v___x_5451_; lean_object* v_fst_5452_; 
v___x_5451_ = lp_Hex_Hex_Groebner_Matrix_inverse(v_field_4932_, v_ctx_4933_, v_limits_4931_, v___y_5448_, v___y_5443_);
v_fst_5452_ = lean_ctor_get(v___x_5451_, 0);
lean_inc(v_fst_5452_);
if (lean_obj_tag(v_fst_5452_) == 0)
{
lean_object* v_snd_5453_; lean_object* v_a_5454_; 
lean_dec_ref(v___y_5450_);
lean_dec(v___y_5449_);
lean_dec_ref(v___y_5446_);
lean_dec(v___y_5445_);
lean_dec(v___y_5444_);
lean_dec(v___y_5441_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5453_ = lean_ctor_get(v___x_5451_, 1);
lean_inc(v_snd_5453_);
lean_dec_ref(v___x_5451_);
v_a_5454_ = lean_ctor_get(v_fst_5452_, 0);
lean_inc(v_a_5454_);
lean_dec_ref_known(v_fst_5452_, 1);
v_a_4949_ = v_a_5454_;
v_snd_4950_ = v_snd_5453_;
goto v___jp_4948_;
}
else
{
lean_object* v_snd_5455_; lean_object* v_a_5456_; uint64_t v___x_5457_; 
v_snd_5455_ = lean_ctor_get(v___x_5451_, 1);
lean_inc(v_snd_5455_);
lean_dec_ref(v___x_5451_);
v_a_5456_ = lean_ctor_get(v_fst_5452_, 0);
lean_inc(v_a_5456_);
lean_dec_ref_known(v_fst_5452_, 1);
v___x_5457_ = lean_unbox_uint64(v_a_5456_);
lean_dec(v_a_5456_);
v___y_5418_ = v___y_5442_;
v___y_5419_ = v___y_5441_;
v___y_5420_ = v___y_5444_;
v___y_5421_ = v___y_5445_;
v___y_5422_ = v___y_5446_;
v___y_5423_ = v___y_5447_;
v___y_5424_ = v___y_5449_;
v___y_5425_ = v___y_5450_;
v_inv_5426_ = v___x_5457_;
v___y_5427_ = v_snd_5455_;
goto v___jp_5417_;
}
}
v___jp_5458_:
{
if (v_independent_4939_ == 0)
{
v___y_5441_ = v___y_5460_;
v___y_5442_ = v___y_5459_;
v___y_5443_ = v___y_5461_;
v___y_5444_ = v___y_5462_;
v___y_5445_ = v___y_5463_;
v___y_5446_ = v___y_5464_;
v___y_5447_ = v___y_5465_;
v___y_5448_ = v___y_5468_;
v___y_5449_ = v___y_5466_;
v___y_5450_ = v___y_5467_;
goto v___jp_5440_;
}
else
{
if (v___x_5315_ == 0)
{
v___y_5441_ = v___y_5460_;
v___y_5442_ = v___y_5459_;
v___y_5443_ = v___y_5461_;
v___y_5444_ = v___y_5462_;
v___y_5445_ = v___y_5463_;
v___y_5446_ = v___y_5464_;
v___y_5447_ = v___y_5465_;
v___y_5448_ = v___y_5468_;
v___y_5449_ = v___y_5466_;
v___y_5450_ = v___y_5467_;
goto v___jp_5440_;
}
else
{
uint64_t v___x_5469_; 
v___x_5469_ = 1ULL;
v___y_5418_ = v___y_5459_;
v___y_5419_ = v___y_5460_;
v___y_5420_ = v___y_5462_;
v___y_5421_ = v___y_5463_;
v___y_5422_ = v___y_5464_;
v___y_5423_ = v___y_5465_;
v___y_5424_ = v___y_5466_;
v___y_5425_ = v___y_5467_;
v_inv_5426_ = v___x_5469_;
v___y_5427_ = v___y_5461_;
goto v___jp_5417_;
}
}
}
v___jp_5470_:
{
uint64_t v___x_5482_; uint64_t v___x_5483_; uint64_t v___x_5484_; uint64_t v___x_5485_; 
v___x_5482_ = lean_uint8_to_uint64(v___y_5481_);
v___x_5483_ = 24ULL;
v___x_5484_ = lean_uint64_shift_left(v___x_5482_, v___x_5483_);
v___x_5485_ = lean_uint64_lor(v___y_5478_, v___x_5484_);
v___y_5459_ = v___y_5472_;
v___y_5460_ = v___y_5471_;
v___y_5461_ = v___y_5473_;
v___y_5462_ = v___y_5474_;
v___y_5463_ = v___y_5475_;
v___y_5464_ = v___y_5476_;
v___y_5465_ = v___y_5477_;
v___y_5466_ = v___y_5479_;
v___y_5467_ = v___y_5480_;
v___y_5468_ = v___x_5485_;
goto v___jp_5458_;
}
v___jp_5486_:
{
uint64_t v___x_5500_; uint64_t v___x_5501_; uint64_t v___x_5502_; uint64_t v___x_5503_; lean_object* v___x_5504_; lean_object* v___x_5505_; uint8_t v___x_5506_; 
v___x_5500_ = lean_uint8_to_uint64(v___y_5499_);
v___x_5501_ = 16ULL;
v___x_5502_ = lean_uint64_shift_left(v___x_5500_, v___x_5501_);
v___x_5503_ = lean_uint64_lor(v___y_5493_, v___x_5502_);
v___x_5504_ = lean_unsigned_to_nat(3u);
v___x_5505_ = lean_nat_add(v___y_5496_, v___x_5504_);
lean_dec(v___y_5496_);
v___x_5506_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5494_, v___x_5505_);
if (v___x_5506_ == 0)
{
lean_object* v___x_5507_; lean_object* v___x_5508_; uint8_t v___x_5509_; 
lean_dec(v___x_5505_);
v___x_5507_ = lean_box(v___y_5489_);
v___x_5508_ = l_outOfBounds___redArg(v___x_5507_);
lean_dec(v___x_5507_);
v___x_5509_ = lean_unbox(v___x_5508_);
lean_dec(v___x_5508_);
v___y_5471_ = v___y_5488_;
v___y_5472_ = v___y_5487_;
v___y_5473_ = v___y_5490_;
v___y_5474_ = v___y_5491_;
v___y_5475_ = v___y_5492_;
v___y_5476_ = v___y_5494_;
v___y_5477_ = v___y_5495_;
v___y_5478_ = v___x_5503_;
v___y_5479_ = v___y_5497_;
v___y_5480_ = v___y_5498_;
v___y_5481_ = v___x_5509_;
goto v___jp_5470_;
}
else
{
uint8_t v___x_5510_; 
v___x_5510_ = lean_byte_array_fget(v___y_5494_, v___x_5505_);
lean_dec(v___x_5505_);
v___y_5471_ = v___y_5488_;
v___y_5472_ = v___y_5487_;
v___y_5473_ = v___y_5490_;
v___y_5474_ = v___y_5491_;
v___y_5475_ = v___y_5492_;
v___y_5476_ = v___y_5494_;
v___y_5477_ = v___y_5495_;
v___y_5478_ = v___x_5503_;
v___y_5479_ = v___y_5497_;
v___y_5480_ = v___y_5498_;
v___y_5481_ = v___x_5510_;
goto v___jp_5470_;
}
}
v___jp_5511_:
{
uint64_t v___x_5525_; uint64_t v___x_5526_; uint64_t v___x_5527_; uint64_t v___x_5528_; lean_object* v___x_5529_; lean_object* v___x_5530_; uint8_t v___x_5531_; 
v___x_5525_ = lean_uint8_to_uint64(v___y_5524_);
v___x_5526_ = 8ULL;
v___x_5527_ = lean_uint64_shift_left(v___x_5525_, v___x_5526_);
v___x_5528_ = lean_uint64_lor(v___y_5514_, v___x_5527_);
v___x_5529_ = lean_unsigned_to_nat(2u);
v___x_5530_ = lean_nat_add(v___y_5521_, v___x_5529_);
v___x_5531_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5519_, v___x_5530_);
if (v___x_5531_ == 0)
{
lean_object* v___x_5532_; lean_object* v___x_5533_; uint8_t v___x_5534_; 
lean_dec(v___x_5530_);
v___x_5532_ = lean_box(v___y_5516_);
v___x_5533_ = l_outOfBounds___redArg(v___x_5532_);
lean_dec(v___x_5532_);
v___x_5534_ = lean_unbox(v___x_5533_);
lean_dec(v___x_5533_);
v___y_5487_ = v___y_5513_;
v___y_5488_ = v___y_5512_;
v___y_5489_ = v___y_5516_;
v___y_5490_ = v___y_5515_;
v___y_5491_ = v___y_5517_;
v___y_5492_ = v___y_5518_;
v___y_5493_ = v___x_5528_;
v___y_5494_ = v___y_5519_;
v___y_5495_ = v___y_5520_;
v___y_5496_ = v___y_5521_;
v___y_5497_ = v___y_5522_;
v___y_5498_ = v___y_5523_;
v___y_5499_ = v___x_5534_;
goto v___jp_5486_;
}
else
{
uint8_t v___x_5535_; 
v___x_5535_ = lean_byte_array_fget(v___y_5519_, v___x_5530_);
lean_dec(v___x_5530_);
v___y_5487_ = v___y_5513_;
v___y_5488_ = v___y_5512_;
v___y_5489_ = v___y_5516_;
v___y_5490_ = v___y_5515_;
v___y_5491_ = v___y_5517_;
v___y_5492_ = v___y_5518_;
v___y_5493_ = v___x_5528_;
v___y_5494_ = v___y_5519_;
v___y_5495_ = v___y_5520_;
v___y_5496_ = v___y_5521_;
v___y_5497_ = v___y_5522_;
v___y_5498_ = v___y_5523_;
v___y_5499_ = v___x_5535_;
goto v___jp_5486_;
}
}
v___jp_5536_:
{
uint64_t v___x_5548_; uint64_t v___x_5549_; uint64_t v___x_5550_; uint64_t v___x_5551_; 
v___x_5548_ = lean_uint8_to_uint64(v___y_5547_);
v___x_5549_ = 8ULL;
v___x_5550_ = lean_uint64_shift_left(v___x_5548_, v___x_5549_);
v___x_5551_ = lean_uint64_lor(v___y_5539_, v___x_5550_);
v___y_5459_ = v___y_5538_;
v___y_5460_ = v___y_5537_;
v___y_5461_ = v___y_5540_;
v___y_5462_ = v___y_5541_;
v___y_5463_ = v___y_5542_;
v___y_5464_ = v___y_5543_;
v___y_5465_ = v___y_5544_;
v___y_5466_ = v___y_5545_;
v___y_5467_ = v___y_5546_;
v___y_5468_ = v___x_5551_;
goto v___jp_5458_;
}
v___jp_5552_:
{
uint64_t v_a_5565_; 
v_a_5565_ = lean_uint8_to_uint64(v___y_5564_);
switch(v_width_4934_)
{
case 0:
{
lean_dec(v___y_5561_);
v___y_5459_ = v___y_5553_;
v___y_5460_ = v___y_5554_;
v___y_5461_ = v___y_5556_;
v___y_5462_ = v___y_5557_;
v___y_5463_ = v___y_5558_;
v___y_5464_ = v___y_5559_;
v___y_5465_ = v___y_5560_;
v___y_5466_ = v___y_5562_;
v___y_5467_ = v___y_5563_;
v___y_5468_ = v_a_5565_;
goto v___jp_5458_;
}
case 1:
{
lean_object* v___x_5566_; uint8_t v___x_5567_; 
v___x_5566_ = lean_nat_add(v___y_5561_, v___x_4985_);
lean_dec(v___y_5561_);
v___x_5567_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5559_, v___x_5566_);
if (v___x_5567_ == 0)
{
lean_object* v___x_5568_; lean_object* v___x_5569_; uint8_t v___x_5570_; 
lean_dec(v___x_5566_);
v___x_5568_ = lean_box(v___y_5555_);
v___x_5569_ = l_outOfBounds___redArg(v___x_5568_);
lean_dec(v___x_5568_);
v___x_5570_ = lean_unbox(v___x_5569_);
lean_dec(v___x_5569_);
v___y_5537_ = v___y_5554_;
v___y_5538_ = v___y_5553_;
v___y_5539_ = v_a_5565_;
v___y_5540_ = v___y_5556_;
v___y_5541_ = v___y_5557_;
v___y_5542_ = v___y_5558_;
v___y_5543_ = v___y_5559_;
v___y_5544_ = v___y_5560_;
v___y_5545_ = v___y_5562_;
v___y_5546_ = v___y_5563_;
v___y_5547_ = v___x_5570_;
goto v___jp_5536_;
}
else
{
uint8_t v___x_5571_; 
v___x_5571_ = lean_byte_array_fget(v___y_5559_, v___x_5566_);
lean_dec(v___x_5566_);
v___y_5537_ = v___y_5554_;
v___y_5538_ = v___y_5553_;
v___y_5539_ = v_a_5565_;
v___y_5540_ = v___y_5556_;
v___y_5541_ = v___y_5557_;
v___y_5542_ = v___y_5558_;
v___y_5543_ = v___y_5559_;
v___y_5544_ = v___y_5560_;
v___y_5545_ = v___y_5562_;
v___y_5546_ = v___y_5563_;
v___y_5547_ = v___x_5571_;
goto v___jp_5536_;
}
}
default: 
{
lean_object* v___x_5572_; uint8_t v___x_5573_; 
v___x_5572_ = lean_nat_add(v___y_5561_, v___x_4985_);
v___x_5573_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5559_, v___x_5572_);
if (v___x_5573_ == 0)
{
lean_object* v___x_5574_; lean_object* v___x_5575_; uint8_t v___x_5576_; 
lean_dec(v___x_5572_);
v___x_5574_ = lean_box(v___y_5555_);
v___x_5575_ = l_outOfBounds___redArg(v___x_5574_);
lean_dec(v___x_5574_);
v___x_5576_ = lean_unbox(v___x_5575_);
lean_dec(v___x_5575_);
v___y_5512_ = v___y_5554_;
v___y_5513_ = v___y_5553_;
v___y_5514_ = v_a_5565_;
v___y_5515_ = v___y_5556_;
v___y_5516_ = v___y_5555_;
v___y_5517_ = v___y_5557_;
v___y_5518_ = v___y_5558_;
v___y_5519_ = v___y_5559_;
v___y_5520_ = v___y_5560_;
v___y_5521_ = v___y_5561_;
v___y_5522_ = v___y_5562_;
v___y_5523_ = v___y_5563_;
v___y_5524_ = v___x_5576_;
goto v___jp_5511_;
}
else
{
uint8_t v___x_5577_; 
v___x_5577_ = lean_byte_array_fget(v___y_5559_, v___x_5572_);
lean_dec(v___x_5572_);
v___y_5512_ = v___y_5554_;
v___y_5513_ = v___y_5553_;
v___y_5514_ = v_a_5565_;
v___y_5515_ = v___y_5556_;
v___y_5516_ = v___y_5555_;
v___y_5517_ = v___y_5557_;
v___y_5518_ = v___y_5558_;
v___y_5519_ = v___y_5559_;
v___y_5520_ = v___y_5560_;
v___y_5521_ = v___y_5561_;
v___y_5522_ = v___y_5562_;
v___y_5523_ = v___y_5563_;
v___y_5524_ = v___x_5577_;
goto v___jp_5511_;
}
}
}
}
v___jp_5578_:
{
if (v___y_5590_ == 0)
{
uint8_t v___x_5591_; 
v___x_5591_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5585_, v___y_5587_);
if (v___x_5591_ == 0)
{
lean_object* v___x_5592_; lean_object* v___x_5593_; uint8_t v___x_5594_; 
v___x_5592_ = lean_box(v___y_5582_);
v___x_5593_ = l_outOfBounds___redArg(v___x_5592_);
lean_dec(v___x_5592_);
v___x_5594_ = lean_unbox(v___x_5593_);
lean_dec(v___x_5593_);
v___y_5553_ = v___y_5580_;
v___y_5554_ = v___y_5579_;
v___y_5555_ = v___y_5582_;
v___y_5556_ = v___y_5581_;
v___y_5557_ = v___y_5583_;
v___y_5558_ = v___y_5584_;
v___y_5559_ = v___y_5585_;
v___y_5560_ = v___y_5586_;
v___y_5561_ = v___y_5587_;
v___y_5562_ = v___y_5588_;
v___y_5563_ = v___y_5589_;
v___y_5564_ = v___x_5594_;
goto v___jp_5552_;
}
else
{
uint8_t v___x_5595_; 
v___x_5595_ = lean_byte_array_fget(v___y_5585_, v___y_5587_);
v___y_5553_ = v___y_5580_;
v___y_5554_ = v___y_5579_;
v___y_5555_ = v___y_5582_;
v___y_5556_ = v___y_5581_;
v___y_5557_ = v___y_5583_;
v___y_5558_ = v___y_5584_;
v___y_5559_ = v___y_5585_;
v___y_5560_ = v___y_5586_;
v___y_5561_ = v___y_5587_;
v___y_5562_ = v___y_5588_;
v___y_5563_ = v___y_5589_;
v___y_5564_ = v___x_5595_;
goto v___jp_5552_;
}
}
else
{
size_t v_pos_5596_; uint8_t v___x_5597_; uint64_t v_a_5598_; 
v_pos_5596_ = lean_usize_of_nat(v___y_5587_);
lean_dec(v___y_5587_);
v___x_5597_ = lean_byte_array_uget(v___y_5585_, v_pos_5596_);
v_a_5598_ = lean_uint8_to_uint64(v___x_5597_);
switch(v_width_4934_)
{
case 0:
{
v___y_5459_ = v___y_5580_;
v___y_5460_ = v___y_5579_;
v___y_5461_ = v___y_5581_;
v___y_5462_ = v___y_5583_;
v___y_5463_ = v___y_5584_;
v___y_5464_ = v___y_5585_;
v___y_5465_ = v___y_5586_;
v___y_5466_ = v___y_5588_;
v___y_5467_ = v___y_5589_;
v___y_5468_ = v_a_5598_;
goto v___jp_5458_;
}
case 1:
{
size_t v___x_5599_; size_t v___x_5600_; uint8_t v___x_5601_; uint64_t v___x_5602_; uint64_t v___x_5603_; uint64_t v___x_5604_; uint64_t v___x_5605_; 
v___x_5599_ = ((size_t)1ULL);
v___x_5600_ = lean_usize_add(v_pos_5596_, v___x_5599_);
v___x_5601_ = lean_byte_array_uget(v___y_5585_, v___x_5600_);
v___x_5602_ = lean_uint8_to_uint64(v___x_5601_);
v___x_5603_ = 8ULL;
v___x_5604_ = lean_uint64_shift_left(v___x_5602_, v___x_5603_);
v___x_5605_ = lean_uint64_lor(v_a_5598_, v___x_5604_);
v___y_5459_ = v___y_5580_;
v___y_5460_ = v___y_5579_;
v___y_5461_ = v___y_5581_;
v___y_5462_ = v___y_5583_;
v___y_5463_ = v___y_5584_;
v___y_5464_ = v___y_5585_;
v___y_5465_ = v___y_5586_;
v___y_5466_ = v___y_5588_;
v___y_5467_ = v___y_5589_;
v___y_5468_ = v___x_5605_;
goto v___jp_5458_;
}
default: 
{
size_t v___x_5606_; size_t v___x_5607_; uint8_t v___x_5608_; uint64_t v___x_5609_; uint64_t v___x_5610_; uint64_t v___x_5611_; uint64_t v___x_5612_; size_t v___x_5613_; size_t v___x_5614_; uint8_t v___x_5615_; uint64_t v___x_5616_; uint64_t v___x_5617_; uint64_t v___x_5618_; uint64_t v___x_5619_; size_t v___x_5620_; size_t v___x_5621_; uint8_t v___x_5622_; uint64_t v___x_5623_; uint64_t v___x_5624_; uint64_t v___x_5625_; uint64_t v___x_5626_; 
v___x_5606_ = ((size_t)1ULL);
v___x_5607_ = lean_usize_add(v_pos_5596_, v___x_5606_);
v___x_5608_ = lean_byte_array_uget(v___y_5585_, v___x_5607_);
v___x_5609_ = lean_uint8_to_uint64(v___x_5608_);
v___x_5610_ = 8ULL;
v___x_5611_ = lean_uint64_shift_left(v___x_5609_, v___x_5610_);
v___x_5612_ = lean_uint64_lor(v_a_5598_, v___x_5611_);
v___x_5613_ = ((size_t)2ULL);
v___x_5614_ = lean_usize_add(v_pos_5596_, v___x_5613_);
v___x_5615_ = lean_byte_array_uget(v___y_5585_, v___x_5614_);
v___x_5616_ = lean_uint8_to_uint64(v___x_5615_);
v___x_5617_ = 16ULL;
v___x_5618_ = lean_uint64_shift_left(v___x_5616_, v___x_5617_);
v___x_5619_ = lean_uint64_lor(v___x_5612_, v___x_5618_);
v___x_5620_ = ((size_t)3ULL);
v___x_5621_ = lean_usize_add(v_pos_5596_, v___x_5620_);
v___x_5622_ = lean_byte_array_uget(v___y_5585_, v___x_5621_);
v___x_5623_ = lean_uint8_to_uint64(v___x_5622_);
v___x_5624_ = 24ULL;
v___x_5625_ = lean_uint64_shift_left(v___x_5623_, v___x_5624_);
v___x_5626_ = lean_uint64_lor(v___x_5619_, v___x_5625_);
v___y_5459_ = v___y_5580_;
v___y_5460_ = v___y_5579_;
v___y_5461_ = v___y_5581_;
v___y_5462_ = v___y_5583_;
v___y_5463_ = v___y_5584_;
v___y_5464_ = v___y_5585_;
v___y_5465_ = v___y_5586_;
v___y_5466_ = v___y_5588_;
v___y_5467_ = v___y_5589_;
v___y_5468_ = v___x_5626_;
goto v___jp_5458_;
}
}
}
}
v___jp_5627_:
{
lean_object* v_offset_5639_; lean_object* v___x_5640_; lean_object* v___x_5641_; uint8_t v___x_5642_; 
v_offset_5639_ = lean_nat_mul(v___y_5633_, v___y_5638_);
v___x_5640_ = lean_nat_add(v_offset_5639_, v___y_5638_);
v___x_5641_ = lean_byte_array_size(v___y_5634_);
v___x_5642_ = lean_nat_dec_le(v___x_5640_, v___x_5641_);
if (v___x_5642_ == 0)
{
lean_dec(v___x_5640_);
v___y_5579_ = v___y_5628_;
v___y_5580_ = v___y_5629_;
v___y_5581_ = v___y_5630_;
v___y_5582_ = v___y_5631_;
v___y_5583_ = v___y_5632_;
v___y_5584_ = v___y_5633_;
v___y_5585_ = v___y_5634_;
v___y_5586_ = v___y_5635_;
v___y_5587_ = v_offset_5639_;
v___y_5588_ = v___y_5636_;
v___y_5589_ = v___y_5637_;
v___y_5590_ = v___x_5642_;
goto v___jp_5578_;
}
else
{
size_t v___x_5643_; lean_object* v___x_5644_; uint8_t v___x_5645_; 
v___x_5643_ = lean_usize_of_nat(v___x_5640_);
v___x_5644_ = lean_usize_to_nat(v___x_5643_);
v___x_5645_ = lean_nat_dec_eq(v___x_5644_, v___x_5640_);
lean_dec(v___x_5640_);
lean_dec(v___x_5644_);
v___y_5579_ = v___y_5628_;
v___y_5580_ = v___y_5629_;
v___y_5581_ = v___y_5630_;
v___y_5582_ = v___y_5631_;
v___y_5583_ = v___y_5632_;
v___y_5584_ = v___y_5633_;
v___y_5585_ = v___y_5634_;
v___y_5586_ = v___y_5635_;
v___y_5587_ = v_offset_5639_;
v___y_5588_ = v___y_5636_;
v___y_5589_ = v___y_5637_;
v___y_5590_ = v___x_5645_;
goto v___jp_5578_;
}
}
v___jp_5646_:
{
lean_object* v_leading_5651_; 
v_leading_5651_ = lean_ctor_get(v_scan_5649_, 3);
if (lean_obj_tag(v_leading_5651_) == 1)
{
lean_object* v_dense_5652_; lean_object* v_last_5653_; lean_object* v_trace_5654_; lean_object* v_node_5655_; lean_object* v_sugar_5656_; lean_object* v_val_5657_; uint8_t v___x_5658_; 
lean_inc_ref(v_leading_5651_);
v_dense_5652_ = lean_ctor_get(v_scan_5649_, 0);
lean_inc_ref(v_dense_5652_);
v_last_5653_ = lean_ctor_get(v_scan_5649_, 1);
lean_inc(v_last_5653_);
v_trace_5654_ = lean_ctor_get(v_scan_5649_, 4);
lean_inc_ref(v_trace_5654_);
v_node_5655_ = lean_ctor_get(v_scan_5649_, 5);
lean_inc(v_node_5655_);
v_sugar_5656_ = lean_ctor_get(v_scan_5649_, 6);
lean_inc(v_sugar_5656_);
lean_dec_ref(v_scan_5649_);
v_val_5657_ = lean_ctor_get(v_leading_5651_, 0);
lean_inc(v_val_5657_);
lean_dec_ref_known(v_leading_5651_, 1);
v___x_5658_ = 0;
switch(v_width_4934_)
{
case 0:
{
v___y_5628_ = v_last_5653_;
v___y_5629_ = v___y_5647_;
v___y_5630_ = v___y_5650_;
v___y_5631_ = v___x_5658_;
v___y_5632_ = v_node_5655_;
v___y_5633_ = v_val_5657_;
v___y_5634_ = v_dense_5652_;
v___y_5635_ = v___y_5648_;
v___y_5636_ = v_sugar_5656_;
v___y_5637_ = v_trace_5654_;
v___y_5638_ = v___x_4985_;
goto v___jp_5627_;
}
case 1:
{
lean_object* v___x_5659_; 
v___x_5659_ = lean_unsigned_to_nat(2u);
v___y_5628_ = v_last_5653_;
v___y_5629_ = v___y_5647_;
v___y_5630_ = v___y_5650_;
v___y_5631_ = v___x_5658_;
v___y_5632_ = v_node_5655_;
v___y_5633_ = v_val_5657_;
v___y_5634_ = v_dense_5652_;
v___y_5635_ = v___y_5648_;
v___y_5636_ = v_sugar_5656_;
v___y_5637_ = v_trace_5654_;
v___y_5638_ = v___x_5659_;
goto v___jp_5627_;
}
default: 
{
lean_object* v___x_5660_; 
v___x_5660_ = lean_unsigned_to_nat(4u);
v___y_5628_ = v_last_5653_;
v___y_5629_ = v___y_5647_;
v___y_5630_ = v___y_5650_;
v___y_5631_ = v___x_5658_;
v___y_5632_ = v_node_5655_;
v___y_5633_ = v_val_5657_;
v___y_5634_ = v_dense_5652_;
v___y_5635_ = v___y_5648_;
v___y_5636_ = v_sugar_5656_;
v___y_5637_ = v_trace_5654_;
v___y_5638_ = v___x_5660_;
goto v___jp_5627_;
}
}
}
else
{
if (v_independent_4939_ == 0)
{
lean_object* v_dense_5661_; lean_object* v_trace_5662_; lean_object* v_node_5663_; lean_object* v_sugar_5664_; 
v_dense_5661_ = lean_ctor_get(v_scan_5649_, 0);
lean_inc_ref(v_dense_5661_);
v_trace_5662_ = lean_ctor_get(v_scan_5649_, 4);
lean_inc_ref(v_trace_5662_);
v_node_5663_ = lean_ctor_get(v_scan_5649_, 5);
lean_inc(v_node_5663_);
v_sugar_5664_ = lean_ctor_get(v_scan_5649_, 6);
lean_inc(v_sugar_5664_);
lean_dec_ref(v_scan_5649_);
v___y_5206_ = v_node_5663_;
v___y_5207_ = v_dense_5661_;
v___y_5208_ = v_sugar_5664_;
v___y_5209_ = v_trace_5662_;
v_remainders_5210_ = v_fst_5004_;
v___y_5211_ = v___y_5650_;
goto v___jp_5205_;
}
else
{
if (v___x_5315_ == 0)
{
lean_object* v_dense_5665_; lean_object* v_trace_5666_; lean_object* v_node_5667_; lean_object* v_sugar_5668_; 
v_dense_5665_ = lean_ctor_get(v_scan_5649_, 0);
lean_inc_ref(v_dense_5665_);
v_trace_5666_ = lean_ctor_get(v_scan_5649_, 4);
lean_inc_ref(v_trace_5666_);
v_node_5667_ = lean_ctor_get(v_scan_5649_, 5);
lean_inc(v_node_5667_);
v_sugar_5668_ = lean_ctor_get(v_scan_5649_, 6);
lean_inc(v_sugar_5668_);
lean_dec_ref(v_scan_5649_);
v___y_5206_ = v_node_5667_;
v___y_5207_ = v_dense_5665_;
v___y_5208_ = v_sugar_5668_;
v___y_5209_ = v_trace_5666_;
v_remainders_5210_ = v_fst_5004_;
v___y_5211_ = v___y_5650_;
goto v___jp_5205_;
}
else
{
lean_object* v_dense_5669_; lean_object* v_trace_5670_; lean_object* v_node_5671_; lean_object* v_sugar_5672_; lean_object* v___x_5673_; lean_object* v___x_5674_; lean_object* v___x_5675_; 
v_dense_5669_ = lean_ctor_get(v_scan_5649_, 0);
lean_inc_ref(v_dense_5669_);
v_trace_5670_ = lean_ctor_get(v_scan_5649_, 4);
lean_inc_ref(v_trace_5670_);
v_node_5671_ = lean_ctor_get(v_scan_5649_, 5);
lean_inc_n(v_node_5671_, 2);
v_sugar_5672_ = lean_ctor_get(v_scan_5649_, 6);
lean_inc_n(v_sugar_5672_, 2);
lean_dec_ref(v_scan_5649_);
v___x_5673_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0);
v___x_5674_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_5674_, 0, v___x_5673_);
lean_ctor_set(v___x_5674_, 1, v_node_5671_);
lean_ctor_set(v___x_5674_, 2, v_sugar_5672_);
v___x_5675_ = lean_array_push(v_fst_5004_, v___x_5674_);
v___y_5206_ = v_node_5671_;
v___y_5207_ = v_dense_5669_;
v___y_5208_ = v_sugar_5672_;
v___y_5209_ = v_trace_5670_;
v_remainders_5210_ = v___x_5675_;
v___y_5211_ = v___y_5650_;
goto v___jp_5205_;
}
}
}
}
v___jp_5676_:
{
lean_object* v___x_5685_; lean_object* v___x_5686_; lean_object* v___x_5687_; 
v___x_5685_ = lean_uint64_to_nat(v___y_5684_);
v___x_5686_ = lean_box(0);
lean_inc(v___y_5683_);
v___x_5687_ = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(v___x_5687_, 0, v___y_5677_);
lean_ctor_set(v___x_5687_, 1, v___x_5685_);
lean_ctor_set(v___x_5687_, 2, v___y_5683_);
lean_ctor_set(v___x_5687_, 3, v___x_5686_);
lean_ctor_set(v___x_5687_, 4, v___y_5682_);
lean_ctor_set(v___x_5687_, 5, v___y_5678_);
lean_ctor_set(v___x_5687_, 6, v___y_5681_);
if (v_native_4937_ == 0)
{
lean_object* v___x_5688_; lean_object* v___x_5689_; lean_object* v_fst_5690_; 
lean_inc(v_columns_4940_);
lean_inc(v___y_5683_);
v___x_5688_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_5688_, 0, v___y_5683_);
lean_ctor_set(v___x_5688_, 1, v_columns_4940_);
lean_ctor_set(v___x_5688_, 2, v___x_4985_);
v___x_5689_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___redArg(v_fst_5001_, v_field_4932_, v_ctx_4933_, v_width_4934_, v_limits_4931_, v_provenance_4935_, v_fst_5000_, v___x_5688_, v___x_5687_, v___y_5683_, v___y_5680_);
lean_dec_ref_known(v___x_5688_, 3);
v_fst_5690_ = lean_ctor_get(v___x_5689_, 0);
lean_inc(v_fst_5690_);
if (lean_obj_tag(v_fst_5690_) == 0)
{
lean_object* v_snd_5691_; lean_object* v_a_5692_; 
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5691_ = lean_ctor_get(v___x_5689_, 1);
lean_inc(v_snd_5691_);
lean_dec_ref(v___x_5689_);
v_a_5692_ = lean_ctor_get(v_fst_5690_, 0);
lean_inc(v_a_5692_);
lean_dec_ref_known(v_fst_5690_, 1);
v_a_4949_ = v_a_5692_;
v_snd_4950_ = v_snd_5691_;
goto v___jp_4948_;
}
else
{
lean_object* v_snd_5693_; lean_object* v_a_5694_; 
v_snd_5693_ = lean_ctor_get(v___x_5689_, 1);
lean_inc(v_snd_5693_);
lean_dec_ref(v___x_5689_);
v_a_5694_ = lean_ctor_get(v_fst_5690_, 0);
lean_inc(v_a_5694_);
lean_dec_ref_known(v_fst_5690_, 1);
v___y_5647_ = v___y_5679_;
v___y_5648_ = v___x_5686_;
v_scan_5649_ = v_a_5694_;
v___y_5650_ = v_snd_5693_;
goto v___jp_5646_;
}
}
else
{
lean_object* v___x_5695_; lean_object* v_fst_5696_; 
v___x_5695_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_nativeScan(v_field_4932_, v_limits_4931_, v_columns_4940_, v_fst_5000_, v_fst_5001_, v_fst_5002_, v___y_5683_, v___x_5687_, v_provenance_4935_, v___y_5680_);
v_fst_5696_ = lean_ctor_get(v___x_5695_, 0);
lean_inc(v_fst_5696_);
if (lean_obj_tag(v_fst_5696_) == 0)
{
lean_object* v_snd_5697_; lean_object* v_a_5698_; 
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5697_ = lean_ctor_get(v___x_5695_, 1);
lean_inc(v_snd_5697_);
lean_dec_ref(v___x_5695_);
v_a_5698_ = lean_ctor_get(v_fst_5696_, 0);
lean_inc(v_a_5698_);
lean_dec_ref_known(v_fst_5696_, 1);
v_a_4949_ = v_a_5698_;
v_snd_4950_ = v_snd_5697_;
goto v___jp_4948_;
}
else
{
lean_object* v_snd_5699_; lean_object* v_a_5700_; 
v_snd_5699_ = lean_ctor_get(v___x_5695_, 1);
lean_inc(v_snd_5699_);
lean_dec_ref(v___x_5695_);
v_a_5700_ = lean_ctor_get(v_fst_5696_, 0);
lean_inc(v_a_5700_);
lean_dec_ref_known(v_fst_5696_, 1);
v___y_5647_ = v___y_5679_;
v___y_5648_ = v___x_5686_;
v_scan_5649_ = v_a_5700_;
v___y_5650_ = v_snd_5699_;
goto v___jp_5646_;
}
}
}
v___jp_5701_:
{
uint64_t v___x_5711_; uint64_t v___x_5712_; uint64_t v___x_5713_; uint64_t v___x_5714_; 
v___x_5711_ = lean_uint8_to_uint64(v___y_5710_);
v___x_5712_ = 24ULL;
v___x_5713_ = lean_uint64_shift_left(v___x_5711_, v___x_5712_);
v___x_5714_ = lean_uint64_lor(v___y_5709_, v___x_5713_);
v___y_5677_ = v___y_5702_;
v___y_5678_ = v___y_5704_;
v___y_5679_ = v___y_5703_;
v___y_5680_ = v___y_5705_;
v___y_5681_ = v___y_5706_;
v___y_5682_ = v___y_5707_;
v___y_5683_ = v___y_5708_;
v___y_5684_ = v___x_5714_;
goto v___jp_5676_;
}
v___jp_5715_:
{
uint64_t v___x_5728_; uint64_t v___x_5729_; uint64_t v___x_5730_; uint64_t v___x_5731_; lean_object* v___x_5732_; lean_object* v___x_5733_; uint8_t v___x_5734_; 
v___x_5728_ = lean_uint8_to_uint64(v___y_5727_);
v___x_5729_ = 16ULL;
v___x_5730_ = lean_uint64_shift_left(v___x_5728_, v___x_5729_);
v___x_5731_ = lean_uint64_lor(v___y_5726_, v___x_5730_);
v___x_5732_ = lean_unsigned_to_nat(3u);
v___x_5733_ = lean_nat_add(v___y_5721_, v___x_5732_);
lean_dec(v___y_5721_);
v___x_5734_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5720_, v___x_5733_);
if (v___x_5734_ == 0)
{
lean_object* v___x_5735_; lean_object* v___x_5736_; uint8_t v___x_5737_; 
lean_dec(v___x_5733_);
lean_dec_ref(v___y_5720_);
v___x_5735_ = lean_box(v___y_5723_);
v___x_5736_ = l_outOfBounds___redArg(v___x_5735_);
lean_dec(v___x_5735_);
v___x_5737_ = lean_unbox(v___x_5736_);
lean_dec(v___x_5736_);
v___y_5702_ = v___y_5716_;
v___y_5703_ = v___y_5718_;
v___y_5704_ = v___y_5717_;
v___y_5705_ = v___y_5719_;
v___y_5706_ = v___y_5722_;
v___y_5707_ = v___y_5724_;
v___y_5708_ = v___y_5725_;
v___y_5709_ = v___x_5731_;
v___y_5710_ = v___x_5737_;
goto v___jp_5701_;
}
else
{
uint8_t v___x_5738_; 
v___x_5738_ = lean_byte_array_fget(v___y_5720_, v___x_5733_);
lean_dec(v___x_5733_);
lean_dec_ref(v___y_5720_);
v___y_5702_ = v___y_5716_;
v___y_5703_ = v___y_5718_;
v___y_5704_ = v___y_5717_;
v___y_5705_ = v___y_5719_;
v___y_5706_ = v___y_5722_;
v___y_5707_ = v___y_5724_;
v___y_5708_ = v___y_5725_;
v___y_5709_ = v___x_5731_;
v___y_5710_ = v___x_5738_;
goto v___jp_5701_;
}
}
v___jp_5739_:
{
uint64_t v___x_5752_; uint64_t v___x_5753_; uint64_t v___x_5754_; uint64_t v___x_5755_; lean_object* v___x_5756_; lean_object* v___x_5757_; uint8_t v___x_5758_; 
v___x_5752_ = lean_uint8_to_uint64(v___y_5751_);
v___x_5753_ = 8ULL;
v___x_5754_ = lean_uint64_shift_left(v___x_5752_, v___x_5753_);
v___x_5755_ = lean_uint64_lor(v___y_5750_, v___x_5754_);
v___x_5756_ = lean_unsigned_to_nat(2u);
v___x_5757_ = lean_nat_add(v___y_5745_, v___x_5756_);
v___x_5758_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5744_, v___x_5757_);
if (v___x_5758_ == 0)
{
lean_object* v___x_5759_; lean_object* v___x_5760_; uint8_t v___x_5761_; 
lean_dec(v___x_5757_);
v___x_5759_ = lean_box(v___y_5747_);
v___x_5760_ = l_outOfBounds___redArg(v___x_5759_);
lean_dec(v___x_5759_);
v___x_5761_ = lean_unbox(v___x_5760_);
lean_dec(v___x_5760_);
v___y_5716_ = v___y_5740_;
v___y_5717_ = v___y_5742_;
v___y_5718_ = v___y_5741_;
v___y_5719_ = v___y_5743_;
v___y_5720_ = v___y_5744_;
v___y_5721_ = v___y_5745_;
v___y_5722_ = v___y_5746_;
v___y_5723_ = v___y_5747_;
v___y_5724_ = v___y_5748_;
v___y_5725_ = v___y_5749_;
v___y_5726_ = v___x_5755_;
v___y_5727_ = v___x_5761_;
goto v___jp_5715_;
}
else
{
uint8_t v___x_5762_; 
v___x_5762_ = lean_byte_array_fget(v___y_5744_, v___x_5757_);
lean_dec(v___x_5757_);
v___y_5716_ = v___y_5740_;
v___y_5717_ = v___y_5742_;
v___y_5718_ = v___y_5741_;
v___y_5719_ = v___y_5743_;
v___y_5720_ = v___y_5744_;
v___y_5721_ = v___y_5745_;
v___y_5722_ = v___y_5746_;
v___y_5723_ = v___y_5747_;
v___y_5724_ = v___y_5748_;
v___y_5725_ = v___y_5749_;
v___y_5726_ = v___x_5755_;
v___y_5727_ = v___x_5762_;
goto v___jp_5715_;
}
}
v___jp_5763_:
{
uint64_t v_a_5775_; lean_object* v___x_5776_; uint8_t v___x_5777_; 
v_a_5775_ = lean_uint8_to_uint64(v___y_5774_);
v___x_5776_ = lean_nat_add(v___y_5769_, v___x_4985_);
v___x_5777_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5768_, v___x_5776_);
if (v___x_5777_ == 0)
{
lean_object* v___x_5778_; lean_object* v___x_5779_; uint8_t v___x_5780_; 
lean_dec(v___x_5776_);
v___x_5778_ = lean_box(v___y_5771_);
v___x_5779_ = l_outOfBounds___redArg(v___x_5778_);
lean_dec(v___x_5778_);
v___x_5780_ = lean_unbox(v___x_5779_);
lean_dec(v___x_5779_);
v___y_5740_ = v___y_5764_;
v___y_5741_ = v___y_5766_;
v___y_5742_ = v___y_5765_;
v___y_5743_ = v___y_5767_;
v___y_5744_ = v___y_5768_;
v___y_5745_ = v___y_5769_;
v___y_5746_ = v___y_5770_;
v___y_5747_ = v___y_5771_;
v___y_5748_ = v___y_5772_;
v___y_5749_ = v___y_5773_;
v___y_5750_ = v_a_5775_;
v___y_5751_ = v___x_5780_;
goto v___jp_5739_;
}
else
{
uint8_t v___x_5781_; 
v___x_5781_ = lean_byte_array_fget(v___y_5768_, v___x_5776_);
lean_dec(v___x_5776_);
v___y_5740_ = v___y_5764_;
v___y_5741_ = v___y_5766_;
v___y_5742_ = v___y_5765_;
v___y_5743_ = v___y_5767_;
v___y_5744_ = v___y_5768_;
v___y_5745_ = v___y_5769_;
v___y_5746_ = v___y_5770_;
v___y_5747_ = v___y_5771_;
v___y_5748_ = v___y_5772_;
v___y_5749_ = v___y_5773_;
v___y_5750_ = v_a_5775_;
v___y_5751_ = v___x_5781_;
goto v___jp_5739_;
}
}
v___jp_5782_:
{
if (v___y_5793_ == 0)
{
uint8_t v___x_5794_; 
v___x_5794_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_5787_, v___y_5788_);
if (v___x_5794_ == 0)
{
lean_object* v___x_5795_; lean_object* v___x_5796_; uint8_t v___x_5797_; 
v___x_5795_ = lean_box(v___y_5790_);
v___x_5796_ = l_outOfBounds___redArg(v___x_5795_);
lean_dec(v___x_5795_);
v___x_5797_ = lean_unbox(v___x_5796_);
lean_dec(v___x_5796_);
v___y_5764_ = v___y_5783_;
v___y_5765_ = v___y_5785_;
v___y_5766_ = v___y_5784_;
v___y_5767_ = v___y_5786_;
v___y_5768_ = v___y_5787_;
v___y_5769_ = v___y_5788_;
v___y_5770_ = v___y_5789_;
v___y_5771_ = v___y_5790_;
v___y_5772_ = v___y_5791_;
v___y_5773_ = v___y_5792_;
v___y_5774_ = v___x_5797_;
goto v___jp_5763_;
}
else
{
uint8_t v___x_5798_; 
v___x_5798_ = lean_byte_array_fget(v___y_5787_, v___y_5788_);
v___y_5764_ = v___y_5783_;
v___y_5765_ = v___y_5785_;
v___y_5766_ = v___y_5784_;
v___y_5767_ = v___y_5786_;
v___y_5768_ = v___y_5787_;
v___y_5769_ = v___y_5788_;
v___y_5770_ = v___y_5789_;
v___y_5771_ = v___y_5790_;
v___y_5772_ = v___y_5791_;
v___y_5773_ = v___y_5792_;
v___y_5774_ = v___x_5798_;
goto v___jp_5763_;
}
}
else
{
size_t v_pos_5799_; uint8_t v___x_5800_; uint64_t v_a_5801_; size_t v___x_5802_; size_t v___x_5803_; uint8_t v___x_5804_; uint64_t v___x_5805_; uint64_t v___x_5806_; uint64_t v___x_5807_; uint64_t v___x_5808_; size_t v___x_5809_; size_t v___x_5810_; uint8_t v___x_5811_; uint64_t v___x_5812_; uint64_t v___x_5813_; uint64_t v___x_5814_; uint64_t v___x_5815_; size_t v___x_5816_; size_t v___x_5817_; uint8_t v___x_5818_; uint64_t v___x_5819_; uint64_t v___x_5820_; uint64_t v___x_5821_; uint64_t v___x_5822_; 
v_pos_5799_ = lean_usize_of_nat(v___y_5788_);
lean_dec(v___y_5788_);
v___x_5800_ = lean_byte_array_uget(v___y_5787_, v_pos_5799_);
v_a_5801_ = lean_uint8_to_uint64(v___x_5800_);
v___x_5802_ = ((size_t)1ULL);
v___x_5803_ = lean_usize_add(v_pos_5799_, v___x_5802_);
v___x_5804_ = lean_byte_array_uget(v___y_5787_, v___x_5803_);
v___x_5805_ = lean_uint8_to_uint64(v___x_5804_);
v___x_5806_ = 8ULL;
v___x_5807_ = lean_uint64_shift_left(v___x_5805_, v___x_5806_);
v___x_5808_ = lean_uint64_lor(v_a_5801_, v___x_5807_);
v___x_5809_ = ((size_t)2ULL);
v___x_5810_ = lean_usize_add(v_pos_5799_, v___x_5809_);
v___x_5811_ = lean_byte_array_uget(v___y_5787_, v___x_5810_);
v___x_5812_ = lean_uint8_to_uint64(v___x_5811_);
v___x_5813_ = 16ULL;
v___x_5814_ = lean_uint64_shift_left(v___x_5812_, v___x_5813_);
v___x_5815_ = lean_uint64_lor(v___x_5808_, v___x_5814_);
v___x_5816_ = ((size_t)3ULL);
v___x_5817_ = lean_usize_add(v_pos_5799_, v___x_5816_);
v___x_5818_ = lean_byte_array_uget(v___y_5787_, v___x_5817_);
lean_dec_ref(v___y_5787_);
v___x_5819_ = lean_uint8_to_uint64(v___x_5818_);
v___x_5820_ = 24ULL;
v___x_5821_ = lean_uint64_shift_left(v___x_5819_, v___x_5820_);
v___x_5822_ = lean_uint64_lor(v___x_5815_, v___x_5821_);
v___y_5677_ = v___y_5783_;
v___y_5678_ = v___y_5785_;
v___y_5679_ = v___y_5784_;
v___y_5680_ = v___y_5786_;
v___y_5681_ = v___y_5789_;
v___y_5682_ = v___y_5791_;
v___y_5683_ = v___y_5792_;
v___y_5684_ = v___x_5822_;
goto v___jp_5676_;
}
}
v___jp_5823_:
{
lean_object* v___x_5833_; lean_object* v_fst_5834_; 
v___x_5833_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_4931_, v___y_5830_, v___y_5827_);
v_fst_5834_ = lean_ctor_get(v___x_5833_, 0);
lean_inc(v_fst_5834_);
if (lean_obj_tag(v_fst_5834_) == 0)
{
lean_object* v_snd_5835_; lean_object* v_a_5836_; 
lean_dec_ref(v___y_5832_);
lean_dec(v___y_5831_);
lean_dec(v___y_5830_);
lean_dec_ref(v___y_5829_);
lean_dec(v___y_5828_);
lean_dec_ref(v___y_5826_);
lean_dec(v___y_5825_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_fst_4999_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_5835_ = lean_ctor_get(v___x_5833_, 1);
lean_inc(v_snd_5835_);
lean_dec_ref(v___x_5833_);
v_a_5836_ = lean_ctor_get(v_fst_5834_, 0);
lean_inc(v_a_5836_);
lean_dec_ref_known(v_fst_5834_, 1);
v_a_4949_ = v_a_5836_;
v_snd_4950_ = v_snd_5835_;
goto v___jp_4948_;
}
else
{
lean_object* v_snd_5837_; lean_object* v___x_5838_; lean_object* v___x_5839_; lean_object* v_fst_5840_; lean_object* v_snd_5841_; lean_object* v_a_5842_; lean_object* v___x_5843_; uint8_t v___x_5844_; lean_object* v___x_5845_; lean_object* v_offset_5846_; lean_object* v___x_5847_; lean_object* v___x_5848_; uint8_t v___x_5849_; 
lean_dec_ref_known(v_fst_5834_, 1);
v_snd_5837_ = lean_ctor_get(v___x_5833_, 1);
lean_inc(v_snd_5837_);
lean_dec_ref(v___x_5833_);
lean_inc(v___y_5830_);
v___x_5838_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_5838_, 0, v_reducerRank_5254_);
lean_ctor_set(v___x_5838_, 1, v___y_5830_);
lean_ctor_set(v___x_5838_, 2, v___x_4985_);
v___x_5839_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___redArg(v_width_4934_, v___y_5832_, v___y_5826_, v___x_5838_, v_fst_4999_, v_reducerRank_5254_, v_snd_5837_);
lean_dec_ref_known(v___x_5838_, 3);
lean_dec_ref(v___y_5832_);
v_fst_5840_ = lean_ctor_get(v___x_5839_, 0);
lean_inc(v_fst_5840_);
v_snd_5841_ = lean_ctor_get(v___x_5839_, 1);
lean_inc(v_snd_5841_);
lean_dec_ref(v___x_5839_);
v_a_5842_ = lean_ctor_get(v_fst_5840_, 0);
lean_inc(v_a_5842_);
lean_dec(v_fst_5840_);
v___x_5843_ = lean_nat_sub(v___y_5830_, v___x_4985_);
lean_dec(v___y_5830_);
v___x_5844_ = 0;
v___x_5845_ = lean_unsigned_to_nat(4u);
v_offset_5846_ = lean_nat_mul(v___x_5843_, v___x_5845_);
lean_dec(v___x_5843_);
v___x_5847_ = lean_nat_add(v_offset_5846_, v___x_5845_);
v___x_5848_ = lean_byte_array_size(v___y_5826_);
v___x_5849_ = lean_nat_dec_le(v___x_5847_, v___x_5848_);
if (v___x_5849_ == 0)
{
lean_dec(v___x_5847_);
v___y_5783_ = v_a_5842_;
v___y_5784_ = v___y_5824_;
v___y_5785_ = v___y_5825_;
v___y_5786_ = v_snd_5841_;
v___y_5787_ = v___y_5826_;
v___y_5788_ = v_offset_5846_;
v___y_5789_ = v___y_5828_;
v___y_5790_ = v___x_5844_;
v___y_5791_ = v___y_5829_;
v___y_5792_ = v___y_5831_;
v___y_5793_ = v___x_5849_;
goto v___jp_5782_;
}
else
{
size_t v___x_5850_; lean_object* v___x_5851_; uint8_t v___x_5852_; 
v___x_5850_ = lean_usize_of_nat(v___x_5847_);
v___x_5851_ = lean_usize_to_nat(v___x_5850_);
v___x_5852_ = lean_nat_dec_eq(v___x_5851_, v___x_5847_);
lean_dec(v___x_5847_);
lean_dec(v___x_5851_);
v___y_5783_ = v_a_5842_;
v___y_5784_ = v___y_5824_;
v___y_5785_ = v___y_5825_;
v___y_5786_ = v_snd_5841_;
v___y_5787_ = v___y_5826_;
v___y_5788_ = v_offset_5846_;
v___y_5789_ = v___y_5828_;
v___y_5790_ = v___x_5844_;
v___y_5791_ = v___y_5829_;
v___y_5792_ = v___y_5831_;
v___y_5793_ = v___x_5852_;
goto v___jp_5782_;
}
}
}
v___jp_5853_:
{
uint64_t v___x_5866_; uint8_t v___x_5867_; 
v___x_5866_ = 0ULL;
v___x_5867_ = lean_uint64_dec_eq(v___y_5865_, v___x_5866_);
if (v___x_5867_ == 0)
{
lean_dec_ref(v___y_5858_);
v___y_5824_ = v___y_5856_;
v___y_5825_ = v___y_5855_;
v___y_5826_ = v___y_5857_;
v___y_5827_ = v___y_5859_;
v___y_5828_ = v___y_5860_;
v___y_5829_ = v___y_5862_;
v___y_5830_ = v___y_5861_;
v___y_5831_ = v___y_5864_;
v___y_5832_ = v___y_5863_;
goto v___jp_5823_;
}
else
{
uint8_t v___x_5868_; 
lean_dec(v___y_5861_);
lean_dec_ref(v___y_5857_);
v___x_5868_ = 0;
switch(v_width_4934_)
{
case 0:
{
v___y_5299_ = v___y_5854_;
v___y_5300_ = v___y_5855_;
v___y_5301_ = v___y_5859_;
v___y_5302_ = v___y_5858_;
v___y_5303_ = v___y_5860_;
v___y_5304_ = v___y_5862_;
v___y_5305_ = v___x_5868_;
v___y_5306_ = v___y_5864_;
v___y_5307_ = v___y_5863_;
v___y_5308_ = v___x_4985_;
goto v___jp_5298_;
}
case 1:
{
lean_object* v___x_5869_; 
v___x_5869_ = lean_unsigned_to_nat(2u);
v___y_5299_ = v___y_5854_;
v___y_5300_ = v___y_5855_;
v___y_5301_ = v___y_5859_;
v___y_5302_ = v___y_5858_;
v___y_5303_ = v___y_5860_;
v___y_5304_ = v___y_5862_;
v___y_5305_ = v___x_5868_;
v___y_5306_ = v___y_5864_;
v___y_5307_ = v___y_5863_;
v___y_5308_ = v___x_5869_;
goto v___jp_5298_;
}
default: 
{
lean_object* v___x_5870_; 
v___x_5870_ = lean_unsigned_to_nat(4u);
v___y_5299_ = v___y_5854_;
v___y_5300_ = v___y_5855_;
v___y_5301_ = v___y_5859_;
v___y_5302_ = v___y_5858_;
v___y_5303_ = v___y_5860_;
v___y_5304_ = v___y_5862_;
v___y_5305_ = v___x_5868_;
v___y_5306_ = v___y_5864_;
v___y_5307_ = v___y_5863_;
v___y_5308_ = v___x_5870_;
goto v___jp_5298_;
}
}
}
}
v___jp_5871_:
{
uint64_t v___x_5885_; uint64_t v___x_5886_; uint64_t v___x_5887_; uint64_t v___x_5888_; 
v___x_5885_ = lean_uint8_to_uint64(v___y_5884_);
v___x_5886_ = 24ULL;
v___x_5887_ = lean_uint64_shift_left(v___x_5885_, v___x_5886_);
v___x_5888_ = lean_uint64_lor(v___y_5883_, v___x_5887_);
v___y_5854_ = v___y_5872_;
v___y_5855_ = v___y_5874_;
v___y_5856_ = v___y_5873_;
v___y_5857_ = v___y_5875_;
v___y_5858_ = v___y_5877_;
v___y_5859_ = v___y_5876_;
v___y_5860_ = v___y_5878_;
v___y_5861_ = v___y_5880_;
v___y_5862_ = v___y_5879_;
v___y_5863_ = v___y_5882_;
v___y_5864_ = v___y_5881_;
v___y_5865_ = v___x_5888_;
goto v___jp_5853_;
}
v___jp_5889_:
{
uint64_t v___x_5905_; uint64_t v___x_5906_; uint64_t v___x_5907_; uint64_t v___x_5908_; lean_object* v___x_5909_; lean_object* v___x_5910_; uint8_t v___x_5911_; 
v___x_5905_ = lean_uint8_to_uint64(v___y_5904_);
v___x_5906_ = 16ULL;
v___x_5907_ = lean_uint64_shift_left(v___x_5905_, v___x_5906_);
v___x_5908_ = lean_uint64_lor(v___y_5890_, v___x_5907_);
v___x_5909_ = lean_unsigned_to_nat(3u);
v___x_5910_ = lean_nat_add(v___y_5903_, v___x_5909_);
lean_dec(v___y_5903_);
v___x_5911_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_5000_, v___x_5910_);
if (v___x_5911_ == 0)
{
lean_object* v___x_5912_; lean_object* v___x_5913_; uint8_t v___x_5914_; 
lean_dec(v___x_5910_);
v___x_5912_ = lean_box(v___y_5894_);
v___x_5913_ = l_outOfBounds___redArg(v___x_5912_);
lean_dec(v___x_5912_);
v___x_5914_ = lean_unbox(v___x_5913_);
lean_dec(v___x_5913_);
v___y_5872_ = v___y_5897_;
v___y_5873_ = v___y_5898_;
v___y_5874_ = v___y_5891_;
v___y_5875_ = v___y_5892_;
v___y_5876_ = v___y_5899_;
v___y_5877_ = v___y_5893_;
v___y_5878_ = v___y_5895_;
v___y_5879_ = v___y_5896_;
v___y_5880_ = v___y_5900_;
v___y_5881_ = v___y_5901_;
v___y_5882_ = v___y_5902_;
v___y_5883_ = v___x_5908_;
v___y_5884_ = v___x_5914_;
goto v___jp_5871_;
}
else
{
uint8_t v___x_5915_; 
v___x_5915_ = lean_byte_array_fget(v_fst_5000_, v___x_5910_);
lean_dec(v___x_5910_);
v___y_5872_ = v___y_5897_;
v___y_5873_ = v___y_5898_;
v___y_5874_ = v___y_5891_;
v___y_5875_ = v___y_5892_;
v___y_5876_ = v___y_5899_;
v___y_5877_ = v___y_5893_;
v___y_5878_ = v___y_5895_;
v___y_5879_ = v___y_5896_;
v___y_5880_ = v___y_5900_;
v___y_5881_ = v___y_5901_;
v___y_5882_ = v___y_5902_;
v___y_5883_ = v___x_5908_;
v___y_5884_ = v___x_5915_;
goto v___jp_5871_;
}
}
v___jp_5916_:
{
uint64_t v___x_5932_; uint64_t v___x_5933_; uint64_t v___x_5934_; uint64_t v___x_5935_; lean_object* v___x_5936_; lean_object* v___x_5937_; uint8_t v___x_5938_; 
v___x_5932_ = lean_uint8_to_uint64(v___y_5931_);
v___x_5933_ = 8ULL;
v___x_5934_ = lean_uint64_shift_left(v___x_5932_, v___x_5933_);
v___x_5935_ = lean_uint64_lor(v___y_5923_, v___x_5934_);
v___x_5936_ = lean_unsigned_to_nat(2u);
v___x_5937_ = lean_nat_add(v___y_5928_, v___x_5936_);
v___x_5938_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_5000_, v___x_5937_);
if (v___x_5938_ == 0)
{
lean_object* v___x_5939_; lean_object* v___x_5940_; uint8_t v___x_5941_; 
lean_dec(v___x_5937_);
v___x_5939_ = lean_box(v___y_5920_);
v___x_5940_ = l_outOfBounds___redArg(v___x_5939_);
lean_dec(v___x_5939_);
v___x_5941_ = lean_unbox(v___x_5940_);
lean_dec(v___x_5940_);
v___y_5890_ = v___x_5935_;
v___y_5891_ = v___y_5917_;
v___y_5892_ = v___y_5918_;
v___y_5893_ = v___y_5919_;
v___y_5894_ = v___y_5920_;
v___y_5895_ = v___y_5921_;
v___y_5896_ = v___y_5922_;
v___y_5897_ = v___y_5924_;
v___y_5898_ = v___y_5925_;
v___y_5899_ = v___y_5926_;
v___y_5900_ = v___y_5927_;
v___y_5901_ = v___y_5929_;
v___y_5902_ = v___y_5930_;
v___y_5903_ = v___y_5928_;
v___y_5904_ = v___x_5941_;
goto v___jp_5889_;
}
else
{
uint8_t v___x_5942_; 
v___x_5942_ = lean_byte_array_fget(v_fst_5000_, v___x_5937_);
lean_dec(v___x_5937_);
v___y_5890_ = v___x_5935_;
v___y_5891_ = v___y_5917_;
v___y_5892_ = v___y_5918_;
v___y_5893_ = v___y_5919_;
v___y_5894_ = v___y_5920_;
v___y_5895_ = v___y_5921_;
v___y_5896_ = v___y_5922_;
v___y_5897_ = v___y_5924_;
v___y_5898_ = v___y_5925_;
v___y_5899_ = v___y_5926_;
v___y_5900_ = v___y_5927_;
v___y_5901_ = v___y_5929_;
v___y_5902_ = v___y_5930_;
v___y_5903_ = v___y_5928_;
v___y_5904_ = v___x_5942_;
goto v___jp_5889_;
}
}
v___jp_5943_:
{
uint64_t v_a_5958_; lean_object* v___x_5959_; uint8_t v___x_5960_; 
v_a_5958_ = lean_uint8_to_uint64(v___y_5957_);
v___x_5959_ = lean_nat_add(v___y_5954_, v___x_4985_);
v___x_5960_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_5000_, v___x_5959_);
if (v___x_5960_ == 0)
{
lean_object* v___x_5961_; lean_object* v___x_5962_; uint8_t v___x_5963_; 
lean_dec(v___x_5959_);
v___x_5961_ = lean_box(v___y_5947_);
v___x_5962_ = l_outOfBounds___redArg(v___x_5961_);
lean_dec(v___x_5961_);
v___x_5963_ = lean_unbox(v___x_5962_);
lean_dec(v___x_5962_);
v___y_5917_ = v___y_5944_;
v___y_5918_ = v___y_5945_;
v___y_5919_ = v___y_5946_;
v___y_5920_ = v___y_5947_;
v___y_5921_ = v___y_5948_;
v___y_5922_ = v___y_5949_;
v___y_5923_ = v_a_5958_;
v___y_5924_ = v___y_5950_;
v___y_5925_ = v___y_5951_;
v___y_5926_ = v___y_5952_;
v___y_5927_ = v___y_5953_;
v___y_5928_ = v___y_5954_;
v___y_5929_ = v___y_5955_;
v___y_5930_ = v___y_5956_;
v___y_5931_ = v___x_5963_;
goto v___jp_5916_;
}
else
{
uint8_t v___x_5964_; 
v___x_5964_ = lean_byte_array_fget(v_fst_5000_, v___x_5959_);
lean_dec(v___x_5959_);
v___y_5917_ = v___y_5944_;
v___y_5918_ = v___y_5945_;
v___y_5919_ = v___y_5946_;
v___y_5920_ = v___y_5947_;
v___y_5921_ = v___y_5948_;
v___y_5922_ = v___y_5949_;
v___y_5923_ = v_a_5958_;
v___y_5924_ = v___y_5950_;
v___y_5925_ = v___y_5951_;
v___y_5926_ = v___y_5952_;
v___y_5927_ = v___y_5953_;
v___y_5928_ = v___y_5954_;
v___y_5929_ = v___y_5955_;
v___y_5930_ = v___y_5956_;
v___y_5931_ = v___x_5964_;
goto v___jp_5916_;
}
}
v___jp_5965_:
{
if (v___y_5979_ == 0)
{
uint8_t v___x_5980_; 
v___x_5980_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_fst_5000_, v___y_5976_);
if (v___x_5980_ == 0)
{
lean_object* v___x_5981_; lean_object* v___x_5982_; uint8_t v___x_5983_; 
v___x_5981_ = lean_box(v___y_5969_);
v___x_5982_ = l_outOfBounds___redArg(v___x_5981_);
lean_dec(v___x_5981_);
v___x_5983_ = lean_unbox(v___x_5982_);
lean_dec(v___x_5982_);
v___y_5944_ = v___y_5966_;
v___y_5945_ = v___y_5967_;
v___y_5946_ = v___y_5968_;
v___y_5947_ = v___y_5969_;
v___y_5948_ = v___y_5970_;
v___y_5949_ = v___y_5971_;
v___y_5950_ = v___y_5972_;
v___y_5951_ = v___y_5973_;
v___y_5952_ = v___y_5974_;
v___y_5953_ = v___y_5975_;
v___y_5954_ = v___y_5976_;
v___y_5955_ = v___y_5977_;
v___y_5956_ = v___y_5978_;
v___y_5957_ = v___x_5983_;
goto v___jp_5943_;
}
else
{
uint8_t v___x_5984_; 
v___x_5984_ = lean_byte_array_fget(v_fst_5000_, v___y_5976_);
v___y_5944_ = v___y_5966_;
v___y_5945_ = v___y_5967_;
v___y_5946_ = v___y_5968_;
v___y_5947_ = v___y_5969_;
v___y_5948_ = v___y_5970_;
v___y_5949_ = v___y_5971_;
v___y_5950_ = v___y_5972_;
v___y_5951_ = v___y_5973_;
v___y_5952_ = v___y_5974_;
v___y_5953_ = v___y_5975_;
v___y_5954_ = v___y_5976_;
v___y_5955_ = v___y_5977_;
v___y_5956_ = v___y_5978_;
v___y_5957_ = v___x_5984_;
goto v___jp_5943_;
}
}
else
{
size_t v_pos_5985_; uint8_t v___x_5986_; uint64_t v_a_5987_; size_t v___x_5988_; size_t v___x_5989_; uint8_t v___x_5990_; uint64_t v___x_5991_; uint64_t v___x_5992_; uint64_t v___x_5993_; uint64_t v___x_5994_; size_t v___x_5995_; size_t v___x_5996_; uint8_t v___x_5997_; uint64_t v___x_5998_; uint64_t v___x_5999_; uint64_t v___x_6000_; uint64_t v___x_6001_; size_t v___x_6002_; size_t v___x_6003_; uint8_t v___x_6004_; uint64_t v___x_6005_; uint64_t v___x_6006_; uint64_t v___x_6007_; uint64_t v___x_6008_; 
v_pos_5985_ = lean_usize_of_nat(v___y_5976_);
lean_dec(v___y_5976_);
v___x_5986_ = lean_byte_array_uget(v_fst_5000_, v_pos_5985_);
v_a_5987_ = lean_uint8_to_uint64(v___x_5986_);
v___x_5988_ = ((size_t)1ULL);
v___x_5989_ = lean_usize_add(v_pos_5985_, v___x_5988_);
v___x_5990_ = lean_byte_array_uget(v_fst_5000_, v___x_5989_);
v___x_5991_ = lean_uint8_to_uint64(v___x_5990_);
v___x_5992_ = 8ULL;
v___x_5993_ = lean_uint64_shift_left(v___x_5991_, v___x_5992_);
v___x_5994_ = lean_uint64_lor(v_a_5987_, v___x_5993_);
v___x_5995_ = ((size_t)2ULL);
v___x_5996_ = lean_usize_add(v_pos_5985_, v___x_5995_);
v___x_5997_ = lean_byte_array_uget(v_fst_5000_, v___x_5996_);
v___x_5998_ = lean_uint8_to_uint64(v___x_5997_);
v___x_5999_ = 16ULL;
v___x_6000_ = lean_uint64_shift_left(v___x_5998_, v___x_5999_);
v___x_6001_ = lean_uint64_lor(v___x_5994_, v___x_6000_);
v___x_6002_ = ((size_t)3ULL);
v___x_6003_ = lean_usize_add(v_pos_5985_, v___x_6002_);
v___x_6004_ = lean_byte_array_uget(v_fst_5000_, v___x_6003_);
v___x_6005_ = lean_uint8_to_uint64(v___x_6004_);
v___x_6006_ = 24ULL;
v___x_6007_ = lean_uint64_shift_left(v___x_6005_, v___x_6006_);
v___x_6008_ = lean_uint64_lor(v___x_6001_, v___x_6007_);
v___y_5854_ = v___y_5972_;
v___y_5855_ = v___y_5966_;
v___y_5856_ = v___y_5973_;
v___y_5857_ = v___y_5967_;
v___y_5858_ = v___y_5968_;
v___y_5859_ = v___y_5974_;
v___y_5860_ = v___y_5970_;
v___y_5861_ = v___y_5975_;
v___y_5862_ = v___y_5971_;
v___y_5863_ = v___y_5978_;
v___y_5864_ = v___y_5977_;
v___y_5865_ = v___x_6008_;
goto v___jp_5853_;
}
}
v___jp_6009_:
{
if (v___y_6020_ == 0)
{
lean_dec_ref(v___y_6013_);
v___y_5824_ = v___y_6020_;
v___y_5825_ = v___y_6011_;
v___y_5826_ = v___y_6012_;
v___y_5827_ = v___y_6014_;
v___y_5828_ = v___y_6015_;
v___y_5829_ = v___y_6017_;
v___y_5830_ = v___y_6016_;
v___y_5831_ = v___y_6019_;
v___y_5832_ = v___y_6018_;
goto v___jp_5823_;
}
else
{
uint8_t v___x_6021_; lean_object* v___x_6022_; lean_object* v_offset_6023_; lean_object* v___x_6024_; lean_object* v___x_6025_; uint8_t v___x_6026_; 
v___x_6021_ = 0;
v___x_6022_ = lean_unsigned_to_nat(4u);
v_offset_6023_ = lean_nat_mul(v___y_6019_, v___x_6022_);
v___x_6024_ = lean_nat_add(v_offset_6023_, v___x_6022_);
v___x_6025_ = lean_byte_array_size(v_fst_5000_);
v___x_6026_ = lean_nat_dec_le(v___x_6024_, v___x_6025_);
if (v___x_6026_ == 0)
{
lean_dec(v___x_6024_);
v___y_5966_ = v___y_6011_;
v___y_5967_ = v___y_6012_;
v___y_5968_ = v___y_6013_;
v___y_5969_ = v___x_6021_;
v___y_5970_ = v___y_6015_;
v___y_5971_ = v___y_6017_;
v___y_5972_ = v___y_6010_;
v___y_5973_ = v___y_6020_;
v___y_5974_ = v___y_6014_;
v___y_5975_ = v___y_6016_;
v___y_5976_ = v_offset_6023_;
v___y_5977_ = v___y_6019_;
v___y_5978_ = v___y_6018_;
v___y_5979_ = v___x_6026_;
goto v___jp_5965_;
}
else
{
size_t v___x_6027_; lean_object* v___x_6028_; uint8_t v___x_6029_; 
v___x_6027_ = lean_usize_of_nat(v___x_6024_);
v___x_6028_ = lean_usize_to_nat(v___x_6027_);
v___x_6029_ = lean_nat_dec_eq(v___x_6028_, v___x_6024_);
lean_dec(v___x_6024_);
lean_dec(v___x_6028_);
v___y_5966_ = v___y_6011_;
v___y_5967_ = v___y_6012_;
v___y_5968_ = v___y_6013_;
v___y_5969_ = v___x_6021_;
v___y_5970_ = v___y_6015_;
v___y_5971_ = v___y_6017_;
v___y_5972_ = v___y_6010_;
v___y_5973_ = v___y_6020_;
v___y_5974_ = v___y_6014_;
v___y_5975_ = v___y_6016_;
v___y_5976_ = v_offset_6023_;
v___y_5977_ = v___y_6019_;
v___y_5978_ = v___y_6018_;
v___y_5979_ = v___x_6029_;
goto v___jp_5965_;
}
}
}
v___jp_6030_:
{
lean_object* v___x_6041_; 
v___x_6041_ = lean_uint64_to_nat(v___y_6040_);
if (v___x_5315_ == 0)
{
v___y_6010_ = v___y_6031_;
v___y_6011_ = v___y_6032_;
v___y_6012_ = v___y_6033_;
v___y_6013_ = v___y_6034_;
v___y_6014_ = v___y_6035_;
v___y_6015_ = v___y_6036_;
v___y_6016_ = v___y_6037_;
v___y_6017_ = v___y_6038_;
v___y_6018_ = v___y_6039_;
v___y_6019_ = v___x_6041_;
v___y_6020_ = v___x_4982_;
goto v___jp_6009_;
}
else
{
v___y_6010_ = v___y_6031_;
v___y_6011_ = v___y_6032_;
v___y_6012_ = v___y_6033_;
v___y_6013_ = v___y_6034_;
v___y_6014_ = v___y_6035_;
v___y_6015_ = v___y_6036_;
v___y_6016_ = v___y_6037_;
v___y_6017_ = v___y_6038_;
v___y_6018_ = v___y_6039_;
v___y_6019_ = v___x_6041_;
v___y_6020_ = v___y_6031_;
goto v___jp_6009_;
}
}
v___jp_6042_:
{
uint64_t v___x_6054_; uint64_t v___x_6055_; uint64_t v___x_6056_; uint64_t v___x_6057_; 
v___x_6054_ = lean_uint8_to_uint64(v___y_6053_);
v___x_6055_ = 24ULL;
v___x_6056_ = lean_uint64_shift_left(v___x_6054_, v___x_6055_);
v___x_6057_ = lean_uint64_lor(v___y_6049_, v___x_6056_);
v___y_6031_ = v___y_6043_;
v___y_6032_ = v___y_6044_;
v___y_6033_ = v___y_6045_;
v___y_6034_ = v___y_6047_;
v___y_6035_ = v___y_6046_;
v___y_6036_ = v___y_6048_;
v___y_6037_ = v___y_6051_;
v___y_6038_ = v___y_6050_;
v___y_6039_ = v___y_6052_;
v___y_6040_ = v___x_6057_;
goto v___jp_6030_;
}
v___jp_6058_:
{
uint64_t v___x_6071_; uint64_t v___x_6072_; uint64_t v___x_6073_; uint64_t v___x_6074_; lean_object* v___x_6075_; uint8_t v___x_6076_; 
v___x_6071_ = lean_uint8_to_uint64(v___y_6070_);
v___x_6072_ = 16ULL;
v___x_6073_ = lean_uint64_shift_left(v___x_6071_, v___x_6072_);
v___x_6074_ = lean_uint64_lor(v___y_6069_, v___x_6073_);
v___x_6075_ = lean_unsigned_to_nat(3u);
v___x_6076_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_6061_, v___x_6075_);
if (v___x_6076_ == 0)
{
lean_object* v___x_6077_; lean_object* v___x_6078_; uint8_t v___x_6079_; 
v___x_6077_ = lean_box(v___y_6067_);
v___x_6078_ = l_outOfBounds___redArg(v___x_6077_);
lean_dec(v___x_6077_);
v___x_6079_ = lean_unbox(v___x_6078_);
lean_dec(v___x_6078_);
v___y_6043_ = v___y_6059_;
v___y_6044_ = v___y_6060_;
v___y_6045_ = v___y_6061_;
v___y_6046_ = v___y_6063_;
v___y_6047_ = v___y_6062_;
v___y_6048_ = v___y_6064_;
v___y_6049_ = v___x_6074_;
v___y_6050_ = v___y_6066_;
v___y_6051_ = v___y_6065_;
v___y_6052_ = v___y_6068_;
v___y_6053_ = v___x_6079_;
goto v___jp_6042_;
}
else
{
uint8_t v___x_6080_; 
v___x_6080_ = lean_byte_array_fget(v___y_6061_, v___x_6075_);
v___y_6043_ = v___y_6059_;
v___y_6044_ = v___y_6060_;
v___y_6045_ = v___y_6061_;
v___y_6046_ = v___y_6063_;
v___y_6047_ = v___y_6062_;
v___y_6048_ = v___y_6064_;
v___y_6049_ = v___x_6074_;
v___y_6050_ = v___y_6066_;
v___y_6051_ = v___y_6065_;
v___y_6052_ = v___y_6068_;
v___y_6053_ = v___x_6080_;
goto v___jp_6042_;
}
}
v___jp_6081_:
{
uint64_t v___x_6094_; uint64_t v___x_6095_; uint64_t v___x_6096_; uint64_t v___x_6097_; lean_object* v___x_6098_; uint8_t v___x_6099_; 
v___x_6094_ = lean_uint8_to_uint64(v___y_6093_);
v___x_6095_ = 8ULL;
v___x_6096_ = lean_uint64_shift_left(v___x_6094_, v___x_6095_);
v___x_6097_ = lean_uint64_lor(v___y_6088_, v___x_6096_);
v___x_6098_ = lean_unsigned_to_nat(2u);
v___x_6099_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_6084_, v___x_6098_);
if (v___x_6099_ == 0)
{
lean_object* v___x_6100_; lean_object* v___x_6101_; uint8_t v___x_6102_; 
v___x_6100_ = lean_box(v___y_6092_);
v___x_6101_ = l_outOfBounds___redArg(v___x_6100_);
lean_dec(v___x_6100_);
v___x_6102_ = lean_unbox(v___x_6101_);
lean_dec(v___x_6101_);
v___y_6059_ = v___y_6082_;
v___y_6060_ = v___y_6083_;
v___y_6061_ = v___y_6084_;
v___y_6062_ = v___y_6086_;
v___y_6063_ = v___y_6085_;
v___y_6064_ = v___y_6087_;
v___y_6065_ = v___y_6090_;
v___y_6066_ = v___y_6089_;
v___y_6067_ = v___y_6092_;
v___y_6068_ = v___y_6091_;
v___y_6069_ = v___x_6097_;
v___y_6070_ = v___x_6102_;
goto v___jp_6058_;
}
else
{
uint8_t v___x_6103_; 
v___x_6103_ = lean_byte_array_fget(v___y_6084_, v___x_6098_);
v___y_6059_ = v___y_6082_;
v___y_6060_ = v___y_6083_;
v___y_6061_ = v___y_6084_;
v___y_6062_ = v___y_6086_;
v___y_6063_ = v___y_6085_;
v___y_6064_ = v___y_6087_;
v___y_6065_ = v___y_6090_;
v___y_6066_ = v___y_6089_;
v___y_6067_ = v___y_6092_;
v___y_6068_ = v___y_6091_;
v___y_6069_ = v___x_6097_;
v___y_6070_ = v___x_6103_;
goto v___jp_6058_;
}
}
v___jp_6104_:
{
uint64_t v_a_6116_; uint8_t v___x_6117_; 
v_a_6116_ = lean_uint8_to_uint64(v___y_6115_);
v___x_6117_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v___y_6107_, v___x_4985_);
if (v___x_6117_ == 0)
{
lean_object* v___x_6118_; lean_object* v___x_6119_; uint8_t v___x_6120_; 
v___x_6118_ = lean_box(v___y_6113_);
v___x_6119_ = l_outOfBounds___redArg(v___x_6118_);
lean_dec(v___x_6118_);
v___x_6120_ = lean_unbox(v___x_6119_);
lean_dec(v___x_6119_);
v___y_6082_ = v___y_6105_;
v___y_6083_ = v___y_6106_;
v___y_6084_ = v___y_6107_;
v___y_6085_ = v___y_6109_;
v___y_6086_ = v___y_6108_;
v___y_6087_ = v___y_6110_;
v___y_6088_ = v_a_6116_;
v___y_6089_ = v___y_6112_;
v___y_6090_ = v___y_6111_;
v___y_6091_ = v___y_6114_;
v___y_6092_ = v___y_6113_;
v___y_6093_ = v___x_6120_;
goto v___jp_6081_;
}
else
{
uint8_t v___x_6121_; 
v___x_6121_ = lean_byte_array_fget(v___y_6107_, v___x_4985_);
v___y_6082_ = v___y_6105_;
v___y_6083_ = v___y_6106_;
v___y_6084_ = v___y_6107_;
v___y_6085_ = v___y_6109_;
v___y_6086_ = v___y_6108_;
v___y_6087_ = v___y_6110_;
v___y_6088_ = v_a_6116_;
v___y_6089_ = v___y_6112_;
v___y_6090_ = v___y_6111_;
v___y_6091_ = v___y_6114_;
v___y_6092_ = v___y_6113_;
v___y_6093_ = v___x_6121_;
goto v___jp_6081_;
}
}
v___jp_6122_:
{
size_t v_pos_6132_; uint8_t v___x_6133_; uint64_t v_a_6134_; size_t v___x_6135_; uint8_t v___x_6136_; uint64_t v___x_6137_; uint64_t v___x_6138_; uint64_t v___x_6139_; uint64_t v___x_6140_; size_t v___x_6141_; uint8_t v___x_6142_; uint64_t v___x_6143_; uint64_t v___x_6144_; uint64_t v___x_6145_; uint64_t v___x_6146_; size_t v___x_6147_; uint8_t v___x_6148_; uint64_t v___x_6149_; uint64_t v___x_6150_; uint64_t v___x_6151_; uint64_t v___x_6152_; 
v_pos_6132_ = ((size_t)0ULL);
v___x_6133_ = lean_byte_array_uget(v___y_6125_, v_pos_6132_);
v_a_6134_ = lean_uint8_to_uint64(v___x_6133_);
v___x_6135_ = ((size_t)1ULL);
v___x_6136_ = lean_byte_array_uget(v___y_6125_, v___x_6135_);
v___x_6137_ = lean_uint8_to_uint64(v___x_6136_);
v___x_6138_ = 8ULL;
v___x_6139_ = lean_uint64_shift_left(v___x_6137_, v___x_6138_);
v___x_6140_ = lean_uint64_lor(v_a_6134_, v___x_6139_);
v___x_6141_ = ((size_t)2ULL);
v___x_6142_ = lean_byte_array_uget(v___y_6125_, v___x_6141_);
v___x_6143_ = lean_uint8_to_uint64(v___x_6142_);
v___x_6144_ = 16ULL;
v___x_6145_ = lean_uint64_shift_left(v___x_6143_, v___x_6144_);
v___x_6146_ = lean_uint64_lor(v___x_6140_, v___x_6145_);
v___x_6147_ = ((size_t)3ULL);
v___x_6148_ = lean_byte_array_uget(v___y_6125_, v___x_6147_);
v___x_6149_ = lean_uint8_to_uint64(v___x_6148_);
v___x_6150_ = 24ULL;
v___x_6151_ = lean_uint64_shift_left(v___x_6149_, v___x_6150_);
v___x_6152_ = lean_uint64_lor(v___x_6146_, v___x_6151_);
v___y_6031_ = v___y_6123_;
v___y_6032_ = v___y_6124_;
v___y_6033_ = v___y_6125_;
v___y_6034_ = v___y_6127_;
v___y_6035_ = v___y_6126_;
v___y_6036_ = v___y_6128_;
v___y_6037_ = v___y_6130_;
v___y_6038_ = v___y_6129_;
v___y_6039_ = v___y_6131_;
v___y_6040_ = v___x_6152_;
goto v___jp_6030_;
}
v___jp_6153_:
{
lean_object* v___x_6159_; uint8_t v___x_6160_; 
v___x_6159_ = lp_Hex_Hex_Groebner_SparseRow_size(v___y_6157_);
v___x_6160_ = lean_nat_dec_eq(v___x_6159_, v_reducerRank_5254_);
if (v___x_6160_ == 0)
{
lean_object* v_columns_6161_; lean_object* v_coefficients_6162_; lean_object* v___x_6163_; lean_object* v___x_6164_; uint8_t v___x_6165_; 
v_columns_6161_ = lean_ctor_get(v___y_6157_, 0);
lean_inc_ref(v_columns_6161_);
v_coefficients_6162_ = lean_ctor_get(v___y_6157_, 1);
lean_inc_ref(v_coefficients_6162_);
v___x_6163_ = lean_unsigned_to_nat(4u);
v___x_6164_ = lean_byte_array_size(v_columns_6161_);
v___x_6165_ = lean_nat_dec_le(v___x_6163_, v___x_6164_);
if (v___x_6165_ == 0)
{
if (v___x_6165_ == 0)
{
uint8_t v___x_6166_; uint8_t v___x_6167_; 
v___x_6166_ = 0;
v___x_6167_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg___lam__0(v_columns_6161_, v_reducerRank_5254_);
if (v___x_6167_ == 0)
{
lean_object* v___x_6168_; lean_object* v___x_6169_; uint8_t v___x_6170_; 
v___x_6168_ = lean_box(v___x_6166_);
v___x_6169_ = l_outOfBounds___redArg(v___x_6168_);
lean_dec(v___x_6168_);
v___x_6170_ = lean_unbox(v___x_6169_);
lean_dec(v___x_6169_);
v___y_6105_ = v___x_6160_;
v___y_6106_ = v___y_6154_;
v___y_6107_ = v_columns_6161_;
v___y_6108_ = v_coefficients_6162_;
v___y_6109_ = v___y_6155_;
v___y_6110_ = v___y_6158_;
v___y_6111_ = v___x_6159_;
v___y_6112_ = v___y_6156_;
v___y_6113_ = v___x_6166_;
v___y_6114_ = v___y_6157_;
v___y_6115_ = v___x_6170_;
goto v___jp_6104_;
}
else
{
uint8_t v___x_6171_; 
v___x_6171_ = lean_byte_array_fget(v_columns_6161_, v_reducerRank_5254_);
v___y_6105_ = v___x_6160_;
v___y_6106_ = v___y_6154_;
v___y_6107_ = v_columns_6161_;
v___y_6108_ = v_coefficients_6162_;
v___y_6109_ = v___y_6155_;
v___y_6110_ = v___y_6158_;
v___y_6111_ = v___x_6159_;
v___y_6112_ = v___y_6156_;
v___y_6113_ = v___x_6166_;
v___y_6114_ = v___y_6157_;
v___y_6115_ = v___x_6171_;
goto v___jp_6104_;
}
}
else
{
v___y_6123_ = v___x_6160_;
v___y_6124_ = v___y_6154_;
v___y_6125_ = v_columns_6161_;
v___y_6126_ = v___y_6155_;
v___y_6127_ = v_coefficients_6162_;
v___y_6128_ = v___y_6158_;
v___y_6129_ = v___y_6156_;
v___y_6130_ = v___x_6159_;
v___y_6131_ = v___y_6157_;
goto v___jp_6122_;
}
}
else
{
v___y_6123_ = v___x_6160_;
v___y_6124_ = v___y_6154_;
v___y_6125_ = v_columns_6161_;
v___y_6126_ = v___y_6155_;
v___y_6127_ = v_coefficients_6162_;
v___y_6128_ = v___y_6158_;
v___y_6129_ = v___y_6156_;
v___y_6130_ = v___x_6159_;
v___y_6131_ = v___y_6157_;
goto v___jp_6122_;
}
}
else
{
lean_dec(v___x_6159_);
lean_dec_ref(v___y_6157_);
if (v_independent_4939_ == 0)
{
v___y_5231_ = v___y_6154_;
v___y_5232_ = v___y_6158_;
v___y_5233_ = v___y_6156_;
v_remainders_5234_ = v_fst_5004_;
v___y_5235_ = v___y_6155_;
goto v___jp_5230_;
}
else
{
if (v___x_5315_ == 0)
{
v___y_5231_ = v___y_6154_;
v___y_5232_ = v___y_6158_;
v___y_5233_ = v___y_6156_;
v_remainders_5234_ = v_fst_5004_;
v___y_5235_ = v___y_6155_;
goto v___jp_5230_;
}
else
{
lean_object* v___x_6172_; lean_object* v___x_6173_; lean_object* v___x_6174_; 
v___x_6172_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg___closed__0);
lean_inc(v___y_6158_);
lean_inc(v___y_6154_);
v___x_6173_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_6173_, 0, v___x_6172_);
lean_ctor_set(v___x_6173_, 1, v___y_6154_);
lean_ctor_set(v___x_6173_, 2, v___y_6158_);
v___x_6174_ = lean_array_push(v_fst_5004_, v___x_6173_);
v___y_5231_ = v___y_6154_;
v___y_5232_ = v___y_6158_;
v___y_5233_ = v___y_6156_;
v_remainders_5234_ = v___x_6174_;
v___y_5235_ = v___y_6155_;
goto v___jp_5230_;
}
}
}
}
v___jp_6175_:
{
lean_object* v___x_6178_; 
lean_inc(v_i_4946_);
if (v_isShared_4992_ == 0)
{
lean_ctor_set_tag(v___x_4991_, 0);
lean_ctor_set(v___x_4991_, 0, v_i_4946_);
v___x_6178_ = v___x_4991_;
goto v_reusejp_6177_;
}
else
{
lean_object* v_reuseFailAlloc_6190_; 
v_reuseFailAlloc_6190_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_6190_, 0, v_i_4946_);
v___x_6178_ = v_reuseFailAlloc_6190_;
goto v_reusejp_6177_;
}
v_reusejp_6177_:
{
lean_object* v___x_6179_; lean_object* v_fst_6180_; 
v___x_6179_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_record(v_limits_4931_, v_provenance_4935_, v_fst_5003_, v___x_6178_, v_snd_4998_);
v_fst_6180_ = lean_ctor_get(v___x_6179_, 0);
lean_inc(v_fst_6180_);
if (lean_obj_tag(v_fst_6180_) == 0)
{
lean_object* v_snd_6181_; lean_object* v_a_6182_; 
lean_dec_ref(v___y_6176_);
lean_dec(v_snd_5005_);
lean_dec(v_fst_5004_);
lean_dec(v_fst_5002_);
lean_dec(v_fst_5001_);
lean_dec(v_fst_5000_);
lean_dec(v_fst_4999_);
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_6181_ = lean_ctor_get(v___x_6179_, 1);
lean_inc(v_snd_6181_);
lean_dec_ref(v___x_6179_);
v_a_6182_ = lean_ctor_get(v_fst_6180_, 0);
lean_inc(v_a_6182_);
lean_dec_ref_known(v_fst_6180_, 1);
v_a_4949_ = v_a_6182_;
v_snd_4950_ = v_snd_6181_;
goto v___jp_4948_;
}
else
{
lean_object* v_a_6183_; lean_object* v_snd_6184_; lean_object* v_fst_6185_; lean_object* v_snd_6186_; lean_object* v___x_6187_; uint8_t v___x_6188_; 
v_a_6183_ = lean_ctor_get(v_fst_6180_, 0);
lean_inc(v_a_6183_);
lean_dec_ref_known(v_fst_6180_, 1);
v_snd_6184_ = lean_ctor_get(v___x_6179_, 1);
lean_inc(v_snd_6184_);
lean_dec_ref(v___x_6179_);
v_fst_6185_ = lean_ctor_get(v_a_6183_, 0);
lean_inc(v_fst_6185_);
v_snd_6186_ = lean_ctor_get(v_a_6183_, 1);
lean_inc(v_snd_6186_);
lean_dec(v_a_6183_);
v___x_6187_ = lean_array_get_size(v_sugars_4941_);
v___x_6188_ = lean_nat_dec_lt(v_i_4946_, v___x_6187_);
if (v___x_6188_ == 0)
{
v___y_6154_ = v_snd_6186_;
v___y_6155_ = v_snd_6184_;
v___y_6156_ = v_fst_6185_;
v___y_6157_ = v___y_6176_;
v___y_6158_ = v_reducerRank_5254_;
goto v___jp_6153_;
}
else
{
lean_object* v___x_6189_; 
v___x_6189_ = lean_array_fget_borrowed(v_sugars_4941_, v_i_4946_);
lean_inc(v___x_6189_);
v___y_6154_ = v_snd_6186_;
v___y_6155_ = v_snd_6184_;
v___y_6156_ = v_fst_6185_;
v___y_6157_ = v___y_6176_;
v___y_6158_ = v___x_6189_;
goto v___jp_6153_;
}
}
}
}
}
}
}
v___jp_4948_:
{
lean_object* v___x_4951_; lean_object* v___x_4952_; 
v___x_4951_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_4951_, 0, v_a_4949_);
v___x_4952_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_4952_, 0, v___x_4951_);
lean_ctor_set(v___x_4952_, 1, v_snd_4950_);
return v___x_4952_;
}
v___jp_4955_:
{
lean_object* v_fst_4957_; 
v_fst_4957_ = lean_ctor_get(v___y_4956_, 0);
lean_inc(v_fst_4957_);
if (lean_obj_tag(v_fst_4957_) == 0)
{
lean_object* v_snd_4958_; lean_object* v_a_4959_; 
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_4958_ = lean_ctor_get(v___y_4956_, 1);
lean_inc(v_snd_4958_);
lean_dec_ref(v___y_4956_);
v_a_4959_ = lean_ctor_get(v_fst_4957_, 0);
lean_inc(v_a_4959_);
lean_dec_ref_known(v_fst_4957_, 1);
v_a_4949_ = v_a_4959_;
v_snd_4950_ = v_snd_4958_;
goto v___jp_4948_;
}
else
{
lean_object* v_a_4960_; lean_object* v___x_4962_; uint8_t v_isShared_4963_; uint8_t v_isSharedCheck_4981_; 
v_a_4960_ = lean_ctor_get(v_fst_4957_, 0);
v_isSharedCheck_4981_ = !lean_is_exclusive(v_fst_4957_);
if (v_isSharedCheck_4981_ == 0)
{
v___x_4962_ = v_fst_4957_;
v_isShared_4963_ = v_isSharedCheck_4981_;
goto v_resetjp_4961_;
}
else
{
lean_inc(v_a_4960_);
lean_dec(v_fst_4957_);
v___x_4962_ = lean_box(0);
v_isShared_4963_ = v_isSharedCheck_4981_;
goto v_resetjp_4961_;
}
v_resetjp_4961_:
{
if (lean_obj_tag(v_a_4960_) == 0)
{
lean_object* v_snd_4964_; lean_object* v___x_4966_; uint8_t v_isShared_4967_; uint8_t v_isSharedCheck_4975_; 
lean_dec(v_i_4946_);
lean_dec(v_columns_4940_);
v_snd_4964_ = lean_ctor_get(v___y_4956_, 1);
v_isSharedCheck_4975_ = !lean_is_exclusive(v___y_4956_);
if (v_isSharedCheck_4975_ == 0)
{
lean_object* v_unused_4976_; 
v_unused_4976_ = lean_ctor_get(v___y_4956_, 0);
lean_dec(v_unused_4976_);
v___x_4966_ = v___y_4956_;
v_isShared_4967_ = v_isSharedCheck_4975_;
goto v_resetjp_4965_;
}
else
{
lean_inc(v_snd_4964_);
lean_dec(v___y_4956_);
v___x_4966_ = lean_box(0);
v_isShared_4967_ = v_isSharedCheck_4975_;
goto v_resetjp_4965_;
}
v_resetjp_4965_:
{
lean_object* v_a_4968_; lean_object* v___x_4970_; 
v_a_4968_ = lean_ctor_get(v_a_4960_, 0);
lean_inc(v_a_4968_);
lean_dec_ref_known(v_a_4960_, 1);
if (v_isShared_4963_ == 0)
{
lean_ctor_set(v___x_4962_, 0, v_a_4968_);
v___x_4970_ = v___x_4962_;
goto v_reusejp_4969_;
}
else
{
lean_object* v_reuseFailAlloc_4974_; 
v_reuseFailAlloc_4974_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_4974_, 0, v_a_4968_);
v___x_4970_ = v_reuseFailAlloc_4974_;
goto v_reusejp_4969_;
}
v_reusejp_4969_:
{
lean_object* v___x_4972_; 
if (v_isShared_4967_ == 0)
{
lean_ctor_set(v___x_4966_, 0, v___x_4970_);
v___x_4972_ = v___x_4966_;
goto v_reusejp_4971_;
}
else
{
lean_object* v_reuseFailAlloc_4973_; 
v_reuseFailAlloc_4973_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_4973_, 0, v___x_4970_);
lean_ctor_set(v_reuseFailAlloc_4973_, 1, v_snd_4964_);
v___x_4972_ = v_reuseFailAlloc_4973_;
goto v_reusejp_4971_;
}
v_reusejp_4971_:
{
return v___x_4972_;
}
}
}
}
else
{
lean_object* v_snd_4977_; lean_object* v_a_4978_; lean_object* v___x_4979_; lean_object* v___x_4980_; 
lean_del_object(v___x_4962_);
v_snd_4977_ = lean_ctor_get(v___y_4956_, 1);
lean_inc(v_snd_4977_);
lean_dec_ref(v___y_4956_);
v_a_4978_ = lean_ctor_get(v_a_4960_, 0);
lean_inc(v_a_4978_);
lean_dec_ref_known(v_a_4960_, 1);
v___x_4979_ = lean_nat_add(v_i_4946_, v_step_4954_);
lean_dec(v_i_4946_);
v___x_4980_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg(v_limits_4931_, v___x_4936_, v_provenance_4935_, v_field_4932_, v_ctx_4933_, v_native_4937_, v_width_4934_, v_independent_4939_, v___y_4938_, v_columns_4940_, v_sugars_4941_, v_reducers_4942_, v_targets_4943_, v_range_4944_, v_a_4978_, v___x_4979_, v_snd_4977_);
return v___x_4980_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg___boxed(lean_object** _args){
lean_object* v_limits_6196_ = _args[0];
lean_object* v_field_6197_ = _args[1];
lean_object* v_ctx_6198_ = _args[2];
lean_object* v_width_6199_ = _args[3];
lean_object* v_provenance_6200_ = _args[4];
lean_object* v___x_6201_ = _args[5];
lean_object* v_native_6202_ = _args[6];
lean_object* v___y_6203_ = _args[7];
lean_object* v_independent_6204_ = _args[8];
lean_object* v_columns_6205_ = _args[9];
lean_object* v_sugars_6206_ = _args[10];
lean_object* v_reducers_6207_ = _args[11];
lean_object* v_targets_6208_ = _args[12];
lean_object* v_range_6209_ = _args[13];
lean_object* v_b_6210_ = _args[14];
lean_object* v_i_6211_ = _args[15];
lean_object* v___y_6212_ = _args[16];
_start:
{
uint64_t v_field_boxed_6213_; uint64_t v_ctx_boxed_6214_; uint8_t v_width_boxed_6215_; uint8_t v_provenance_boxed_6216_; uint8_t v_native_boxed_6217_; uint8_t v_independent_boxed_6218_; lean_object* v_res_6219_; 
v_field_boxed_6213_ = lean_unbox_uint64(v_field_6197_);
lean_dec_ref(v_field_6197_);
v_ctx_boxed_6214_ = lean_unbox_uint64(v_ctx_6198_);
lean_dec_ref(v_ctx_6198_);
v_width_boxed_6215_ = lean_unbox(v_width_6199_);
v_provenance_boxed_6216_ = lean_unbox(v_provenance_6200_);
v_native_boxed_6217_ = lean_unbox(v_native_6202_);
v_independent_boxed_6218_ = lean_unbox(v_independent_6204_);
v_res_6219_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg(v_limits_6196_, v_field_boxed_6213_, v_ctx_boxed_6214_, v_width_boxed_6215_, v_provenance_boxed_6216_, v___x_6201_, v_native_boxed_6217_, v___y_6203_, v_independent_boxed_6218_, v_columns_6205_, v_sugars_6206_, v_reducers_6207_, v_targets_6208_, v_range_6209_, v_b_6210_, v_i_6211_, v___y_6212_);
lean_dec_ref(v_range_6209_);
lean_dec_ref(v_targets_6208_);
lean_dec_ref(v_reducers_6207_);
lean_dec_ref(v_sugars_6206_);
lean_dec(v___y_6203_);
lean_dec(v___x_6201_);
lean_dec_ref(v_limits_6196_);
return v_res_6219_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate(uint64_t v_field_6230_, lean_object* v_limits_6231_, lean_object* v_columns_6232_, lean_object* v_reducers_6233_, lean_object* v_targets_6234_, uint8_t v_provenance_6235_, lean_object* v_sugars_6236_, uint8_t v_native_6237_, uint8_t v_independent_6238_, lean_object* v_a_6239_){
_start:
{
uint8_t v___y_6244_; lean_object* v___y_6245_; lean_object* v___y_6246_; lean_object* v___y_6247_; lean_object* v___y_6248_; lean_object* v___y_6249_; lean_object* v___y_6250_; lean_object* v___x_6483_; uint8_t v___x_6484_; 
v___x_6483_ = lean_unsigned_to_nat(4294967295u);
v___x_6484_ = lean_nat_dec_lt(v___x_6483_, v_columns_6232_);
if (v___x_6484_ == 0)
{
lean_object* v___x_6485_; lean_object* v___x_6486_; lean_object* v___x_6487_; uint8_t v___x_6488_; 
v___x_6485_ = lean_array_get_size(v_reducers_6233_);
v___x_6486_ = lean_array_get_size(v_targets_6234_);
v___x_6487_ = lean_nat_add(v___x_6485_, v___x_6486_);
v___x_6488_ = lean_nat_dec_lt(v___x_6483_, v___x_6487_);
if (v___x_6488_ == 0)
{
lean_object* v_columns_6489_; lean_object* v_rows_6490_; uint8_t v___x_6491_; 
v_columns_6489_ = lean_ctor_get(v_limits_6231_, 0);
v_rows_6490_ = lean_ctor_get(v_limits_6231_, 1);
v___x_6491_ = lean_nat_dec_lt(v_columns_6489_, v_columns_6232_);
if (v___x_6491_ == 0)
{
uint8_t v___x_6492_; 
v___x_6492_ = lean_nat_dec_lt(v_rows_6490_, v___x_6487_);
if (v___x_6492_ == 0)
{
lean_object* v___x_6493_; lean_object* v___x_6494_; uint8_t v___x_6495_; 
v___x_6493_ = lean_array_get_size(v_sugars_6236_);
v___x_6494_ = lean_unsigned_to_nat(0u);
v___x_6495_ = lean_nat_dec_eq(v___x_6493_, v___x_6494_);
if (v___x_6495_ == 0)
{
uint8_t v___x_6496_; 
v___x_6496_ = lean_nat_dec_eq(v___x_6493_, v___x_6487_);
lean_dec(v___x_6487_);
if (v___x_6496_ == 0)
{
lean_object* v___x_6497_; lean_object* v___x_6498_; 
lean_dec(v_columns_6232_);
v___x_6497_ = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__0));
v___x_6498_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6498_, 0, v___x_6497_);
lean_ctor_set(v___x_6498_, 1, v_a_6239_);
return v___x_6498_;
}
else
{
goto v___jp_6432_;
}
}
else
{
lean_dec(v___x_6487_);
goto v___jp_6432_;
}
}
else
{
lean_object* v___x_6499_; lean_object* v___x_6500_; 
lean_dec(v___x_6487_);
lean_dec(v_columns_6232_);
v___x_6499_ = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__2));
v___x_6500_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6500_, 0, v___x_6499_);
lean_ctor_set(v___x_6500_, 1, v_a_6239_);
return v___x_6500_;
}
}
else
{
lean_object* v___x_6501_; lean_object* v___x_6502_; 
lean_dec(v___x_6487_);
lean_dec(v_columns_6232_);
v___x_6501_ = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__4));
v___x_6502_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6502_, 0, v___x_6501_);
lean_ctor_set(v___x_6502_, 1, v_a_6239_);
return v___x_6502_;
}
}
else
{
lean_dec(v___x_6487_);
lean_dec(v_columns_6232_);
goto v___jp_6240_;
}
}
else
{
lean_dec(v_columns_6232_);
goto v___jp_6240_;
}
v___jp_6240_:
{
lean_object* v___x_6241_; lean_object* v___x_6242_; 
v___x_6241_ = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__0));
v___x_6242_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6242_, 0, v___x_6241_);
lean_ctor_set(v___x_6242_, 1, v_a_6239_);
return v___x_6242_;
}
v___jp_6243_:
{
lean_object* v___x_6251_; lean_object* v___x_6252_; lean_object* v_workspaceBytes_6253_; lean_object* v___x_6254_; uint8_t v___x_6255_; 
v___x_6251_ = lean_unsigned_to_nat(4u);
v___x_6252_ = lean_nat_add(v___y_6250_, v___x_6251_);
v_workspaceBytes_6253_ = lean_nat_mul(v_columns_6232_, v___x_6252_);
lean_dec(v___x_6252_);
v___x_6254_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0);
v___x_6255_ = lean_nat_dec_le(v___x_6254_, v_workspaceBytes_6253_);
if (v___x_6255_ == 0)
{
lean_object* v___x_6256_; lean_object* v_fst_6257_; 
v___x_6256_ = lp_Hex_Hex_Groebner_Matrix_packedBytes(v_limits_6231_, v_workspaceBytes_6253_, v___y_6246_);
v_fst_6257_ = lean_ctor_get(v___x_6256_, 0);
lean_inc(v_fst_6257_);
if (lean_obj_tag(v_fst_6257_) == 0)
{
lean_object* v_snd_6258_; lean_object* v___x_6260_; uint8_t v_isShared_6261_; uint8_t v_isSharedCheck_6273_; 
lean_dec(v_workspaceBytes_6253_);
lean_dec(v___y_6250_);
lean_dec(v___y_6249_);
lean_dec(v___y_6248_);
lean_dec(v___y_6247_);
lean_dec(v___y_6245_);
lean_dec(v_columns_6232_);
v_snd_6258_ = lean_ctor_get(v___x_6256_, 1);
v_isSharedCheck_6273_ = !lean_is_exclusive(v___x_6256_);
if (v_isSharedCheck_6273_ == 0)
{
lean_object* v_unused_6274_; 
v_unused_6274_ = lean_ctor_get(v___x_6256_, 0);
lean_dec(v_unused_6274_);
v___x_6260_ = v___x_6256_;
v_isShared_6261_ = v_isSharedCheck_6273_;
goto v_resetjp_6259_;
}
else
{
lean_inc(v_snd_6258_);
lean_dec(v___x_6256_);
v___x_6260_ = lean_box(0);
v_isShared_6261_ = v_isSharedCheck_6273_;
goto v_resetjp_6259_;
}
v_resetjp_6259_:
{
lean_object* v_a_6262_; lean_object* v___x_6264_; uint8_t v_isShared_6265_; uint8_t v_isSharedCheck_6272_; 
v_a_6262_ = lean_ctor_get(v_fst_6257_, 0);
v_isSharedCheck_6272_ = !lean_is_exclusive(v_fst_6257_);
if (v_isSharedCheck_6272_ == 0)
{
v___x_6264_ = v_fst_6257_;
v_isShared_6265_ = v_isSharedCheck_6272_;
goto v_resetjp_6263_;
}
else
{
lean_inc(v_a_6262_);
lean_dec(v_fst_6257_);
v___x_6264_ = lean_box(0);
v_isShared_6265_ = v_isSharedCheck_6272_;
goto v_resetjp_6263_;
}
v_resetjp_6263_:
{
lean_object* v___x_6267_; 
if (v_isShared_6265_ == 0)
{
v___x_6267_ = v___x_6264_;
goto v_reusejp_6266_;
}
else
{
lean_object* v_reuseFailAlloc_6271_; 
v_reuseFailAlloc_6271_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_6271_, 0, v_a_6262_);
v___x_6267_ = v_reuseFailAlloc_6271_;
goto v_reusejp_6266_;
}
v_reusejp_6266_:
{
lean_object* v___x_6269_; 
if (v_isShared_6261_ == 0)
{
lean_ctor_set(v___x_6260_, 0, v___x_6267_);
v___x_6269_ = v___x_6260_;
goto v_reusejp_6268_;
}
else
{
lean_object* v_reuseFailAlloc_6270_; 
v_reuseFailAlloc_6270_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6270_, 0, v___x_6267_);
lean_ctor_set(v_reuseFailAlloc_6270_, 1, v_snd_6258_);
v___x_6269_ = v_reuseFailAlloc_6270_;
goto v_reusejp_6268_;
}
v_reusejp_6268_:
{
return v___x_6269_;
}
}
}
}
}
else
{
lean_object* v_snd_6275_; lean_object* v___x_6277_; uint8_t v_isShared_6278_; uint8_t v_isSharedCheck_6428_; 
lean_dec_ref_known(v_fst_6257_, 1);
v_snd_6275_ = lean_ctor_get(v___x_6256_, 1);
v_isSharedCheck_6428_ = !lean_is_exclusive(v___x_6256_);
if (v_isSharedCheck_6428_ == 0)
{
lean_object* v_unused_6429_; 
v_unused_6429_ = lean_ctor_get(v___x_6256_, 0);
lean_dec(v_unused_6429_);
v___x_6277_ = v___x_6256_;
v_isShared_6278_ = v_isSharedCheck_6428_;
goto v_resetjp_6276_;
}
else
{
lean_inc(v_snd_6275_);
lean_dec(v___x_6256_);
v___x_6277_ = lean_box(0);
v_isShared_6278_ = v_isSharedCheck_6428_;
goto v_resetjp_6276_;
}
v_resetjp_6276_:
{
lean_object* v___x_6279_; lean_object* v_fst_6280_; 
v___x_6279_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_6231_, v_workspaceBytes_6253_, v_snd_6275_);
lean_dec(v_workspaceBytes_6253_);
v_fst_6280_ = lean_ctor_get(v___x_6279_, 0);
lean_inc(v_fst_6280_);
if (lean_obj_tag(v_fst_6280_) == 0)
{
lean_object* v_snd_6281_; lean_object* v___x_6283_; uint8_t v_isShared_6284_; uint8_t v_isSharedCheck_6296_; 
lean_del_object(v___x_6277_);
lean_dec(v___y_6250_);
lean_dec(v___y_6249_);
lean_dec(v___y_6248_);
lean_dec(v___y_6247_);
lean_dec(v___y_6245_);
lean_dec(v_columns_6232_);
v_snd_6281_ = lean_ctor_get(v___x_6279_, 1);
v_isSharedCheck_6296_ = !lean_is_exclusive(v___x_6279_);
if (v_isSharedCheck_6296_ == 0)
{
lean_object* v_unused_6297_; 
v_unused_6297_ = lean_ctor_get(v___x_6279_, 0);
lean_dec(v_unused_6297_);
v___x_6283_ = v___x_6279_;
v_isShared_6284_ = v_isSharedCheck_6296_;
goto v_resetjp_6282_;
}
else
{
lean_inc(v_snd_6281_);
lean_dec(v___x_6279_);
v___x_6283_ = lean_box(0);
v_isShared_6284_ = v_isSharedCheck_6296_;
goto v_resetjp_6282_;
}
v_resetjp_6282_:
{
lean_object* v_a_6285_; lean_object* v___x_6287_; uint8_t v_isShared_6288_; uint8_t v_isSharedCheck_6295_; 
v_a_6285_ = lean_ctor_get(v_fst_6280_, 0);
v_isSharedCheck_6295_ = !lean_is_exclusive(v_fst_6280_);
if (v_isSharedCheck_6295_ == 0)
{
v___x_6287_ = v_fst_6280_;
v_isShared_6288_ = v_isSharedCheck_6295_;
goto v_resetjp_6286_;
}
else
{
lean_inc(v_a_6285_);
lean_dec(v_fst_6280_);
v___x_6287_ = lean_box(0);
v_isShared_6288_ = v_isSharedCheck_6295_;
goto v_resetjp_6286_;
}
v_resetjp_6286_:
{
lean_object* v___x_6290_; 
if (v_isShared_6288_ == 0)
{
v___x_6290_ = v___x_6287_;
goto v_reusejp_6289_;
}
else
{
lean_object* v_reuseFailAlloc_6294_; 
v_reuseFailAlloc_6294_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_6294_, 0, v_a_6285_);
v___x_6290_ = v_reuseFailAlloc_6294_;
goto v_reusejp_6289_;
}
v_reusejp_6289_:
{
lean_object* v___x_6292_; 
if (v_isShared_6284_ == 0)
{
lean_ctor_set(v___x_6283_, 0, v___x_6290_);
v___x_6292_ = v___x_6283_;
goto v_reusejp_6291_;
}
else
{
lean_object* v_reuseFailAlloc_6293_; 
v_reuseFailAlloc_6293_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6293_, 0, v___x_6290_);
lean_ctor_set(v_reuseFailAlloc_6293_, 1, v_snd_6281_);
v___x_6292_ = v_reuseFailAlloc_6293_;
goto v_reusejp_6291_;
}
v_reusejp_6291_:
{
return v___x_6292_;
}
}
}
}
}
else
{
lean_object* v_snd_6298_; lean_object* v___x_6300_; uint8_t v_isShared_6301_; uint8_t v_isSharedCheck_6426_; 
lean_dec_ref_known(v_fst_6280_, 1);
v_snd_6298_ = lean_ctor_get(v___x_6279_, 1);
v_isSharedCheck_6426_ = !lean_is_exclusive(v___x_6279_);
if (v_isSharedCheck_6426_ == 0)
{
lean_object* v_unused_6427_; 
v_unused_6427_ = lean_ctor_get(v___x_6279_, 0);
lean_dec(v_unused_6427_);
v___x_6300_ = v___x_6279_;
v_isShared_6301_ = v_isSharedCheck_6426_;
goto v_resetjp_6299_;
}
else
{
lean_inc(v_snd_6298_);
lean_dec(v___x_6279_);
v___x_6300_ = lean_box(0);
v_isShared_6301_ = v_isSharedCheck_6426_;
goto v_resetjp_6299_;
}
v_resetjp_6299_:
{
lean_object* v___x_6302_; lean_object* v_dense_6303_; lean_object* v___x_6304_; lean_object* v_slots_6305_; lean_object* v_pivots_6306_; uint64_t v_ctx_6307_; lean_object* v___x_6308_; lean_object* v___x_6309_; lean_object* v___x_6311_; 
v___x_6302_ = lean_nat_mul(v_columns_6232_, v___y_6250_);
v_dense_6303_ = lp_Hex_Hex_Groebner_Matrix_zeros(v___x_6302_);
v___x_6304_ = lean_nat_mul(v_columns_6232_, v___x_6251_);
v_slots_6305_ = lp_Hex_Hex_Groebner_Matrix_zeros(v___x_6304_);
v_pivots_6306_ = lean_mk_empty_array_with_capacity(v___y_6245_);
v_ctx_6307_ = lp_Hex_BarrettCtx_mk___redArg(v_field_6230_);
v___x_6308_ = lean_nat_add(v___y_6248_, v___y_6247_);
lean_dec(v___y_6247_);
lean_inc(v___y_6249_);
lean_inc_n(v___y_6245_, 2);
v___x_6309_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_6309_, 0, v___y_6245_);
lean_ctor_set(v___x_6309_, 1, v___x_6308_);
lean_ctor_set(v___x_6309_, 2, v___y_6249_);
lean_inc_ref(v_pivots_6306_);
if (v_isShared_6301_ == 0)
{
lean_ctor_set(v___x_6300_, 1, v___y_6245_);
lean_ctor_set(v___x_6300_, 0, v_pivots_6306_);
v___x_6311_ = v___x_6300_;
goto v_reusejp_6310_;
}
else
{
lean_object* v_reuseFailAlloc_6425_; 
v_reuseFailAlloc_6425_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6425_, 0, v_pivots_6306_);
lean_ctor_set(v_reuseFailAlloc_6425_, 1, v___y_6245_);
v___x_6311_ = v_reuseFailAlloc_6425_;
goto v_reusejp_6310_;
}
v_reusejp_6310_:
{
lean_object* v___x_6313_; 
lean_inc_ref(v_pivots_6306_);
if (v_isShared_6278_ == 0)
{
lean_ctor_set(v___x_6277_, 1, v___x_6311_);
lean_ctor_set(v___x_6277_, 0, v_pivots_6306_);
v___x_6313_ = v___x_6277_;
goto v_reusejp_6312_;
}
else
{
lean_object* v_reuseFailAlloc_6424_; 
v_reuseFailAlloc_6424_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6424_, 0, v_pivots_6306_);
lean_ctor_set(v_reuseFailAlloc_6424_, 1, v___x_6311_);
v___x_6313_ = v_reuseFailAlloc_6424_;
goto v_reusejp_6312_;
}
v_reusejp_6312_:
{
lean_object* v___x_6314_; lean_object* v___x_6315_; lean_object* v___x_6316_; lean_object* v___x_6317_; lean_object* v___x_6318_; lean_object* v_fst_6319_; 
lean_inc_ref_n(v_pivots_6306_, 2);
v___x_6314_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6314_, 0, v_pivots_6306_);
lean_ctor_set(v___x_6314_, 1, v___x_6313_);
v___x_6315_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6315_, 0, v_pivots_6306_);
lean_ctor_set(v___x_6315_, 1, v___x_6314_);
v___x_6316_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6316_, 0, v_slots_6305_);
lean_ctor_set(v___x_6316_, 1, v___x_6315_);
v___x_6317_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6317_, 0, v_dense_6303_);
lean_ctor_set(v___x_6317_, 1, v___x_6316_);
lean_inc(v___y_6245_);
lean_inc(v_columns_6232_);
v___x_6318_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg(v_limits_6231_, v_field_6230_, v_ctx_6307_, v___y_6244_, v_provenance_6235_, v___y_6248_, v_native_6237_, v___y_6250_, v_independent_6238_, v_columns_6232_, v_sugars_6236_, v_reducers_6233_, v_targets_6234_, v___x_6309_, v___x_6317_, v___y_6245_, v_snd_6298_);
lean_dec_ref_known(v___x_6309_, 3);
lean_dec(v___y_6250_);
lean_dec(v___y_6248_);
v_fst_6319_ = lean_ctor_get(v___x_6318_, 0);
lean_inc(v_fst_6319_);
if (lean_obj_tag(v_fst_6319_) == 0)
{
lean_object* v_snd_6320_; lean_object* v___x_6322_; uint8_t v_isShared_6323_; uint8_t v_isSharedCheck_6335_; 
lean_dec_ref(v_pivots_6306_);
lean_dec(v___y_6249_);
lean_dec(v___y_6245_);
lean_dec(v_columns_6232_);
v_snd_6320_ = lean_ctor_get(v___x_6318_, 1);
v_isSharedCheck_6335_ = !lean_is_exclusive(v___x_6318_);
if (v_isSharedCheck_6335_ == 0)
{
lean_object* v_unused_6336_; 
v_unused_6336_ = lean_ctor_get(v___x_6318_, 0);
lean_dec(v_unused_6336_);
v___x_6322_ = v___x_6318_;
v_isShared_6323_ = v_isSharedCheck_6335_;
goto v_resetjp_6321_;
}
else
{
lean_inc(v_snd_6320_);
lean_dec(v___x_6318_);
v___x_6322_ = lean_box(0);
v_isShared_6323_ = v_isSharedCheck_6335_;
goto v_resetjp_6321_;
}
v_resetjp_6321_:
{
lean_object* v_a_6324_; lean_object* v___x_6326_; uint8_t v_isShared_6327_; uint8_t v_isSharedCheck_6334_; 
v_a_6324_ = lean_ctor_get(v_fst_6319_, 0);
v_isSharedCheck_6334_ = !lean_is_exclusive(v_fst_6319_);
if (v_isSharedCheck_6334_ == 0)
{
v___x_6326_ = v_fst_6319_;
v_isShared_6327_ = v_isSharedCheck_6334_;
goto v_resetjp_6325_;
}
else
{
lean_inc(v_a_6324_);
lean_dec(v_fst_6319_);
v___x_6326_ = lean_box(0);
v_isShared_6327_ = v_isSharedCheck_6334_;
goto v_resetjp_6325_;
}
v_resetjp_6325_:
{
lean_object* v___x_6329_; 
if (v_isShared_6327_ == 0)
{
v___x_6329_ = v___x_6326_;
goto v_reusejp_6328_;
}
else
{
lean_object* v_reuseFailAlloc_6333_; 
v_reuseFailAlloc_6333_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_6333_, 0, v_a_6324_);
v___x_6329_ = v_reuseFailAlloc_6333_;
goto v_reusejp_6328_;
}
v_reusejp_6328_:
{
lean_object* v___x_6331_; 
if (v_isShared_6323_ == 0)
{
lean_ctor_set(v___x_6322_, 0, v___x_6329_);
v___x_6331_ = v___x_6322_;
goto v_reusejp_6330_;
}
else
{
lean_object* v_reuseFailAlloc_6332_; 
v_reuseFailAlloc_6332_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6332_, 0, v___x_6329_);
lean_ctor_set(v_reuseFailAlloc_6332_, 1, v_snd_6320_);
v___x_6331_ = v_reuseFailAlloc_6332_;
goto v_reusejp_6330_;
}
v_reusejp_6330_:
{
return v___x_6331_;
}
}
}
}
}
else
{
lean_object* v_a_6337_; lean_object* v___x_6339_; uint8_t v_isShared_6340_; uint8_t v_isSharedCheck_6423_; 
v_a_6337_ = lean_ctor_get(v_fst_6319_, 0);
v_isSharedCheck_6423_ = !lean_is_exclusive(v_fst_6319_);
if (v_isSharedCheck_6423_ == 0)
{
v___x_6339_ = v_fst_6319_;
v_isShared_6340_ = v_isSharedCheck_6423_;
goto v_resetjp_6338_;
}
else
{
lean_inc(v_a_6337_);
lean_dec(v_fst_6319_);
v___x_6339_ = lean_box(0);
v_isShared_6340_ = v_isSharedCheck_6423_;
goto v_resetjp_6338_;
}
v_resetjp_6338_:
{
lean_object* v_snd_6341_; lean_object* v_snd_6342_; lean_object* v_snd_6343_; lean_object* v_snd_6344_; lean_object* v_snd_6345_; 
v_snd_6341_ = lean_ctor_get(v_a_6337_, 1);
lean_inc(v_snd_6341_);
lean_dec(v_a_6337_);
v_snd_6342_ = lean_ctor_get(v_snd_6341_, 1);
lean_inc(v_snd_6342_);
v_snd_6343_ = lean_ctor_get(v_snd_6342_, 1);
v_snd_6344_ = lean_ctor_get(v_snd_6343_, 1);
lean_inc(v_snd_6344_);
v_snd_6345_ = lean_ctor_get(v_snd_6344_, 1);
lean_inc(v_snd_6345_);
if (v_independent_6238_ == 0)
{
lean_object* v_snd_6346_; lean_object* v_fst_6347_; lean_object* v_fst_6348_; lean_object* v_fst_6349_; lean_object* v_fst_6350_; lean_object* v_snd_6351_; lean_object* v___x_6352_; lean_object* v_fst_6353_; 
lean_del_object(v___x_6339_);
v_snd_6346_ = lean_ctor_get(v___x_6318_, 1);
lean_inc(v_snd_6346_);
lean_dec_ref(v___x_6318_);
v_fst_6347_ = lean_ctor_get(v_snd_6341_, 0);
lean_inc(v_fst_6347_);
lean_dec(v_snd_6341_);
v_fst_6348_ = lean_ctor_get(v_snd_6342_, 0);
lean_inc(v_fst_6348_);
lean_dec(v_snd_6342_);
v_fst_6349_ = lean_ctor_get(v_snd_6344_, 0);
lean_inc(v_fst_6349_);
lean_dec(v_snd_6344_);
v_fst_6350_ = lean_ctor_get(v_snd_6345_, 0);
lean_inc(v_fst_6350_);
v_snd_6351_ = lean_ctor_get(v_snd_6345_, 1);
lean_inc(v_snd_6351_);
lean_dec(v_snd_6345_);
v___x_6352_ = lp_Hex_Hex_Groebner_Matrix_work(v_limits_6231_, v_columns_6232_, v_snd_6346_);
v_fst_6353_ = lean_ctor_get(v___x_6352_, 0);
lean_inc(v_fst_6353_);
if (lean_obj_tag(v_fst_6353_) == 0)
{
lean_object* v_snd_6354_; lean_object* v___x_6356_; uint8_t v_isShared_6357_; uint8_t v_isSharedCheck_6369_; 
lean_dec(v_snd_6351_);
lean_dec(v_fst_6350_);
lean_dec(v_fst_6349_);
lean_dec(v_fst_6348_);
lean_dec(v_fst_6347_);
lean_dec_ref(v_pivots_6306_);
lean_dec(v___y_6249_);
lean_dec(v___y_6245_);
lean_dec(v_columns_6232_);
v_snd_6354_ = lean_ctor_get(v___x_6352_, 1);
v_isSharedCheck_6369_ = !lean_is_exclusive(v___x_6352_);
if (v_isSharedCheck_6369_ == 0)
{
lean_object* v_unused_6370_; 
v_unused_6370_ = lean_ctor_get(v___x_6352_, 0);
lean_dec(v_unused_6370_);
v___x_6356_ = v___x_6352_;
v_isShared_6357_ = v_isSharedCheck_6369_;
goto v_resetjp_6355_;
}
else
{
lean_inc(v_snd_6354_);
lean_dec(v___x_6352_);
v___x_6356_ = lean_box(0);
v_isShared_6357_ = v_isSharedCheck_6369_;
goto v_resetjp_6355_;
}
v_resetjp_6355_:
{
lean_object* v_a_6358_; lean_object* v___x_6360_; uint8_t v_isShared_6361_; uint8_t v_isSharedCheck_6368_; 
v_a_6358_ = lean_ctor_get(v_fst_6353_, 0);
v_isSharedCheck_6368_ = !lean_is_exclusive(v_fst_6353_);
if (v_isSharedCheck_6368_ == 0)
{
v___x_6360_ = v_fst_6353_;
v_isShared_6361_ = v_isSharedCheck_6368_;
goto v_resetjp_6359_;
}
else
{
lean_inc(v_a_6358_);
lean_dec(v_fst_6353_);
v___x_6360_ = lean_box(0);
v_isShared_6361_ = v_isSharedCheck_6368_;
goto v_resetjp_6359_;
}
v_resetjp_6359_:
{
lean_object* v___x_6363_; 
if (v_isShared_6361_ == 0)
{
v___x_6363_ = v___x_6360_;
goto v_reusejp_6362_;
}
else
{
lean_object* v_reuseFailAlloc_6367_; 
v_reuseFailAlloc_6367_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_6367_, 0, v_a_6358_);
v___x_6363_ = v_reuseFailAlloc_6367_;
goto v_reusejp_6362_;
}
v_reusejp_6362_:
{
lean_object* v___x_6365_; 
if (v_isShared_6357_ == 0)
{
lean_ctor_set(v___x_6356_, 0, v___x_6363_);
v___x_6365_ = v___x_6356_;
goto v_reusejp_6364_;
}
else
{
lean_object* v_reuseFailAlloc_6366_; 
v_reuseFailAlloc_6366_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6366_, 0, v___x_6363_);
lean_ctor_set(v_reuseFailAlloc_6366_, 1, v_snd_6354_);
v___x_6365_ = v_reuseFailAlloc_6366_;
goto v_reusejp_6364_;
}
v_reusejp_6364_:
{
return v___x_6365_;
}
}
}
}
}
else
{
lean_object* v_snd_6371_; lean_object* v___x_6373_; uint8_t v_isShared_6374_; uint8_t v_isSharedCheck_6398_; 
lean_dec_ref_known(v_fst_6353_, 1);
v_snd_6371_ = lean_ctor_get(v___x_6352_, 1);
v_isSharedCheck_6398_ = !lean_is_exclusive(v___x_6352_);
if (v_isSharedCheck_6398_ == 0)
{
lean_object* v_unused_6399_; 
v_unused_6399_ = lean_ctor_get(v___x_6352_, 0);
lean_dec(v_unused_6399_);
v___x_6373_ = v___x_6352_;
v_isShared_6374_ = v_isSharedCheck_6398_;
goto v_resetjp_6372_;
}
else
{
lean_inc(v_snd_6371_);
lean_dec(v___x_6352_);
v___x_6373_ = lean_box(0);
v_isShared_6374_ = v_isSharedCheck_6398_;
goto v_resetjp_6372_;
}
v_resetjp_6372_:
{
lean_object* v___x_6375_; lean_object* v___x_6376_; lean_object* v_fst_6377_; lean_object* v_snd_6378_; lean_object* v___x_6380_; uint8_t v_isShared_6381_; uint8_t v_isSharedCheck_6397_; 
lean_inc(v___y_6245_);
v___x_6375_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_6375_, 0, v___y_6245_);
lean_ctor_set(v___x_6375_, 1, v_columns_6232_);
lean_ctor_set(v___x_6375_, 2, v___y_6249_);
v___x_6376_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___redArg(v_fst_6348_, v_fst_6347_, v___x_6375_, v_pivots_6306_, v___y_6245_, v_snd_6371_);
lean_dec_ref_known(v___x_6375_, 3);
lean_dec(v_fst_6347_);
lean_dec(v_fst_6348_);
v_fst_6377_ = lean_ctor_get(v___x_6376_, 0);
v_snd_6378_ = lean_ctor_get(v___x_6376_, 1);
v_isSharedCheck_6397_ = !lean_is_exclusive(v___x_6376_);
if (v_isSharedCheck_6397_ == 0)
{
v___x_6380_ = v___x_6376_;
v_isShared_6381_ = v_isSharedCheck_6397_;
goto v_resetjp_6379_;
}
else
{
lean_inc(v_snd_6378_);
lean_inc(v_fst_6377_);
lean_dec(v___x_6376_);
v___x_6380_ = lean_box(0);
v_isShared_6381_ = v_isSharedCheck_6397_;
goto v_resetjp_6379_;
}
v_resetjp_6379_:
{
lean_object* v_a_6382_; lean_object* v___x_6384_; uint8_t v_isShared_6385_; uint8_t v_isSharedCheck_6396_; 
v_a_6382_ = lean_ctor_get(v_fst_6377_, 0);
v_isSharedCheck_6396_ = !lean_is_exclusive(v_fst_6377_);
if (v_isSharedCheck_6396_ == 0)
{
v___x_6384_ = v_fst_6377_;
v_isShared_6385_ = v_isSharedCheck_6396_;
goto v_resetjp_6383_;
}
else
{
lean_inc(v_a_6382_);
lean_dec(v_fst_6377_);
v___x_6384_ = lean_box(0);
v_isShared_6385_ = v_isSharedCheck_6396_;
goto v_resetjp_6383_;
}
v_resetjp_6383_:
{
lean_object* v___x_6386_; lean_object* v___x_6388_; 
v___x_6386_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_6386_, 0, v_a_6382_);
lean_ctor_set(v___x_6386_, 1, v_snd_6351_);
lean_ctor_set(v___x_6386_, 2, v_fst_6349_);
if (v_isShared_6381_ == 0)
{
lean_ctor_set(v___x_6380_, 1, v_fst_6350_);
lean_ctor_set(v___x_6380_, 0, v___x_6386_);
v___x_6388_ = v___x_6380_;
goto v_reusejp_6387_;
}
else
{
lean_object* v_reuseFailAlloc_6395_; 
v_reuseFailAlloc_6395_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6395_, 0, v___x_6386_);
lean_ctor_set(v_reuseFailAlloc_6395_, 1, v_fst_6350_);
v___x_6388_ = v_reuseFailAlloc_6395_;
goto v_reusejp_6387_;
}
v_reusejp_6387_:
{
lean_object* v___x_6390_; 
if (v_isShared_6385_ == 0)
{
lean_ctor_set(v___x_6384_, 0, v___x_6388_);
v___x_6390_ = v___x_6384_;
goto v_reusejp_6389_;
}
else
{
lean_object* v_reuseFailAlloc_6394_; 
v_reuseFailAlloc_6394_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_6394_, 0, v___x_6388_);
v___x_6390_ = v_reuseFailAlloc_6394_;
goto v_reusejp_6389_;
}
v_reusejp_6389_:
{
lean_object* v___x_6392_; 
if (v_isShared_6374_ == 0)
{
lean_ctor_set(v___x_6373_, 1, v_snd_6378_);
lean_ctor_set(v___x_6373_, 0, v___x_6390_);
v___x_6392_ = v___x_6373_;
goto v_reusejp_6391_;
}
else
{
lean_object* v_reuseFailAlloc_6393_; 
v_reuseFailAlloc_6393_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6393_, 0, v___x_6390_);
lean_ctor_set(v_reuseFailAlloc_6393_, 1, v_snd_6378_);
v___x_6392_ = v_reuseFailAlloc_6393_;
goto v_reusejp_6391_;
}
v_reusejp_6391_:
{
return v___x_6392_;
}
}
}
}
}
}
}
}
else
{
lean_object* v_snd_6400_; lean_object* v_fst_6401_; lean_object* v___x_6403_; uint8_t v_isShared_6404_; uint8_t v_isSharedCheck_6421_; 
lean_dec(v_snd_6342_);
lean_dec(v_snd_6341_);
lean_dec(v___y_6249_);
lean_dec(v___y_6245_);
lean_dec(v_columns_6232_);
v_snd_6400_ = lean_ctor_get(v___x_6318_, 1);
lean_inc(v_snd_6400_);
lean_dec_ref(v___x_6318_);
v_fst_6401_ = lean_ctor_get(v_snd_6344_, 0);
v_isSharedCheck_6421_ = !lean_is_exclusive(v_snd_6344_);
if (v_isSharedCheck_6421_ == 0)
{
lean_object* v_unused_6422_; 
v_unused_6422_ = lean_ctor_get(v_snd_6344_, 1);
lean_dec(v_unused_6422_);
v___x_6403_ = v_snd_6344_;
v_isShared_6404_ = v_isSharedCheck_6421_;
goto v_resetjp_6402_;
}
else
{
lean_inc(v_fst_6401_);
lean_dec(v_snd_6344_);
v___x_6403_ = lean_box(0);
v_isShared_6404_ = v_isSharedCheck_6421_;
goto v_resetjp_6402_;
}
v_resetjp_6402_:
{
lean_object* v_fst_6405_; lean_object* v_snd_6406_; lean_object* v___x_6408_; uint8_t v_isShared_6409_; uint8_t v_isSharedCheck_6420_; 
v_fst_6405_ = lean_ctor_get(v_snd_6345_, 0);
v_snd_6406_ = lean_ctor_get(v_snd_6345_, 1);
v_isSharedCheck_6420_ = !lean_is_exclusive(v_snd_6345_);
if (v_isSharedCheck_6420_ == 0)
{
v___x_6408_ = v_snd_6345_;
v_isShared_6409_ = v_isSharedCheck_6420_;
goto v_resetjp_6407_;
}
else
{
lean_inc(v_snd_6406_);
lean_inc(v_fst_6405_);
lean_dec(v_snd_6345_);
v___x_6408_ = lean_box(0);
v_isShared_6409_ = v_isSharedCheck_6420_;
goto v_resetjp_6407_;
}
v_resetjp_6407_:
{
lean_object* v___x_6410_; lean_object* v___x_6412_; 
v___x_6410_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_6410_, 0, v_pivots_6306_);
lean_ctor_set(v___x_6410_, 1, v_snd_6406_);
lean_ctor_set(v___x_6410_, 2, v_fst_6401_);
if (v_isShared_6409_ == 0)
{
lean_ctor_set(v___x_6408_, 1, v_fst_6405_);
lean_ctor_set(v___x_6408_, 0, v___x_6410_);
v___x_6412_ = v___x_6408_;
goto v_reusejp_6411_;
}
else
{
lean_object* v_reuseFailAlloc_6419_; 
v_reuseFailAlloc_6419_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6419_, 0, v___x_6410_);
lean_ctor_set(v_reuseFailAlloc_6419_, 1, v_fst_6405_);
v___x_6412_ = v_reuseFailAlloc_6419_;
goto v_reusejp_6411_;
}
v_reusejp_6411_:
{
lean_object* v___x_6414_; 
if (v_isShared_6340_ == 0)
{
lean_ctor_set(v___x_6339_, 0, v___x_6412_);
v___x_6414_ = v___x_6339_;
goto v_reusejp_6413_;
}
else
{
lean_object* v_reuseFailAlloc_6418_; 
v_reuseFailAlloc_6418_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_6418_, 0, v___x_6412_);
v___x_6414_ = v_reuseFailAlloc_6418_;
goto v_reusejp_6413_;
}
v_reusejp_6413_:
{
lean_object* v___x_6416_; 
if (v_isShared_6404_ == 0)
{
lean_ctor_set(v___x_6403_, 1, v_snd_6400_);
lean_ctor_set(v___x_6403_, 0, v___x_6414_);
v___x_6416_ = v___x_6403_;
goto v_reusejp_6415_;
}
else
{
lean_object* v_reuseFailAlloc_6417_; 
v_reuseFailAlloc_6417_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6417_, 0, v___x_6414_);
lean_ctor_set(v_reuseFailAlloc_6417_, 1, v_snd_6400_);
v___x_6416_ = v_reuseFailAlloc_6417_;
goto v_reusejp_6415_;
}
v_reusejp_6415_:
{
return v___x_6416_;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
else
{
lean_object* v___x_6430_; lean_object* v___x_6431_; 
lean_dec(v_workspaceBytes_6253_);
lean_dec(v___y_6250_);
lean_dec(v___y_6249_);
lean_dec(v___y_6248_);
lean_dec(v___y_6247_);
lean_dec(v___y_6245_);
lean_dec(v_columns_6232_);
v___x_6430_ = ((lean_object*)(lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___closed__0));
v___x_6431_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_6431_, 0, v___x_6430_);
lean_ctor_set(v___x_6431_, 1, v___y_6246_);
return v___x_6431_;
}
}
v___jp_6432_:
{
lean_object* v_reducerRank_6433_; lean_object* v___x_6434_; lean_object* v___x_6435_; lean_object* v___x_6436_; lean_object* v___x_6437_; lean_object* v___x_6438_; lean_object* v_fst_6439_; 
v_reducerRank_6433_ = lean_unsigned_to_nat(0u);
v___x_6434_ = lean_array_get_size(v_reducers_6233_);
v___x_6435_ = lean_unsigned_to_nat(1u);
v___x_6436_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_6436_, 0, v_reducerRank_6433_);
lean_ctor_set(v___x_6436_, 1, v___x_6434_);
lean_ctor_set(v___x_6436_, 2, v___x_6435_);
v___x_6437_ = lean_box(0);
v___x_6438_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___redArg(v_reducers_6233_, v_field_6230_, v_limits_6231_, v_columns_6232_, v___x_6436_, v___x_6437_, v_reducerRank_6433_, v_a_6239_);
lean_dec_ref_known(v___x_6436_, 3);
v_fst_6439_ = lean_ctor_get(v___x_6438_, 0);
lean_inc(v_fst_6439_);
if (lean_obj_tag(v_fst_6439_) == 0)
{
lean_object* v_snd_6440_; lean_object* v___x_6442_; uint8_t v_isShared_6443_; uint8_t v_isSharedCheck_6455_; 
lean_dec(v_columns_6232_);
v_snd_6440_ = lean_ctor_get(v___x_6438_, 1);
v_isSharedCheck_6455_ = !lean_is_exclusive(v___x_6438_);
if (v_isSharedCheck_6455_ == 0)
{
lean_object* v_unused_6456_; 
v_unused_6456_ = lean_ctor_get(v___x_6438_, 0);
lean_dec(v_unused_6456_);
v___x_6442_ = v___x_6438_;
v_isShared_6443_ = v_isSharedCheck_6455_;
goto v_resetjp_6441_;
}
else
{
lean_inc(v_snd_6440_);
lean_dec(v___x_6438_);
v___x_6442_ = lean_box(0);
v_isShared_6443_ = v_isSharedCheck_6455_;
goto v_resetjp_6441_;
}
v_resetjp_6441_:
{
lean_object* v_a_6444_; lean_object* v___x_6446_; uint8_t v_isShared_6447_; uint8_t v_isSharedCheck_6454_; 
v_a_6444_ = lean_ctor_get(v_fst_6439_, 0);
v_isSharedCheck_6454_ = !lean_is_exclusive(v_fst_6439_);
if (v_isSharedCheck_6454_ == 0)
{
v___x_6446_ = v_fst_6439_;
v_isShared_6447_ = v_isSharedCheck_6454_;
goto v_resetjp_6445_;
}
else
{
lean_inc(v_a_6444_);
lean_dec(v_fst_6439_);
v___x_6446_ = lean_box(0);
v_isShared_6447_ = v_isSharedCheck_6454_;
goto v_resetjp_6445_;
}
v_resetjp_6445_:
{
lean_object* v___x_6449_; 
if (v_isShared_6447_ == 0)
{
v___x_6449_ = v___x_6446_;
goto v_reusejp_6448_;
}
else
{
lean_object* v_reuseFailAlloc_6453_; 
v_reuseFailAlloc_6453_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_6453_, 0, v_a_6444_);
v___x_6449_ = v_reuseFailAlloc_6453_;
goto v_reusejp_6448_;
}
v_reusejp_6448_:
{
lean_object* v___x_6451_; 
if (v_isShared_6443_ == 0)
{
lean_ctor_set(v___x_6442_, 0, v___x_6449_);
v___x_6451_ = v___x_6442_;
goto v_reusejp_6450_;
}
else
{
lean_object* v_reuseFailAlloc_6452_; 
v_reuseFailAlloc_6452_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6452_, 0, v___x_6449_);
lean_ctor_set(v_reuseFailAlloc_6452_, 1, v_snd_6440_);
v___x_6451_ = v_reuseFailAlloc_6452_;
goto v_reusejp_6450_;
}
v_reusejp_6450_:
{
return v___x_6451_;
}
}
}
}
}
else
{
lean_object* v_snd_6457_; lean_object* v___x_6458_; lean_object* v___x_6459_; lean_object* v___x_6460_; lean_object* v_fst_6461_; 
lean_dec_ref_known(v_fst_6439_, 1);
v_snd_6457_ = lean_ctor_get(v___x_6438_, 1);
lean_inc(v_snd_6457_);
lean_dec_ref(v___x_6438_);
v___x_6458_ = lean_array_get_size(v_targets_6234_);
v___x_6459_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_6459_, 0, v_reducerRank_6433_);
lean_ctor_set(v___x_6459_, 1, v___x_6458_);
lean_ctor_set(v___x_6459_, 2, v___x_6435_);
v___x_6460_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___redArg(v___x_6434_, v_targets_6234_, v_field_6230_, v_limits_6231_, v_columns_6232_, v___x_6459_, v___x_6437_, v_reducerRank_6433_, v_snd_6457_);
lean_dec_ref_known(v___x_6459_, 3);
v_fst_6461_ = lean_ctor_get(v___x_6460_, 0);
lean_inc(v_fst_6461_);
if (lean_obj_tag(v_fst_6461_) == 0)
{
lean_object* v_snd_6462_; lean_object* v___x_6464_; uint8_t v_isShared_6465_; uint8_t v_isSharedCheck_6477_; 
lean_dec(v_columns_6232_);
v_snd_6462_ = lean_ctor_get(v___x_6460_, 1);
v_isSharedCheck_6477_ = !lean_is_exclusive(v___x_6460_);
if (v_isSharedCheck_6477_ == 0)
{
lean_object* v_unused_6478_; 
v_unused_6478_ = lean_ctor_get(v___x_6460_, 0);
lean_dec(v_unused_6478_);
v___x_6464_ = v___x_6460_;
v_isShared_6465_ = v_isSharedCheck_6477_;
goto v_resetjp_6463_;
}
else
{
lean_inc(v_snd_6462_);
lean_dec(v___x_6460_);
v___x_6464_ = lean_box(0);
v_isShared_6465_ = v_isSharedCheck_6477_;
goto v_resetjp_6463_;
}
v_resetjp_6463_:
{
lean_object* v_a_6466_; lean_object* v___x_6468_; uint8_t v_isShared_6469_; uint8_t v_isSharedCheck_6476_; 
v_a_6466_ = lean_ctor_get(v_fst_6461_, 0);
v_isSharedCheck_6476_ = !lean_is_exclusive(v_fst_6461_);
if (v_isSharedCheck_6476_ == 0)
{
v___x_6468_ = v_fst_6461_;
v_isShared_6469_ = v_isSharedCheck_6476_;
goto v_resetjp_6467_;
}
else
{
lean_inc(v_a_6466_);
lean_dec(v_fst_6461_);
v___x_6468_ = lean_box(0);
v_isShared_6469_ = v_isSharedCheck_6476_;
goto v_resetjp_6467_;
}
v_resetjp_6467_:
{
lean_object* v___x_6471_; 
if (v_isShared_6469_ == 0)
{
v___x_6471_ = v___x_6468_;
goto v_reusejp_6470_;
}
else
{
lean_object* v_reuseFailAlloc_6475_; 
v_reuseFailAlloc_6475_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_6475_, 0, v_a_6466_);
v___x_6471_ = v_reuseFailAlloc_6475_;
goto v_reusejp_6470_;
}
v_reusejp_6470_:
{
lean_object* v___x_6473_; 
if (v_isShared_6465_ == 0)
{
lean_ctor_set(v___x_6464_, 0, v___x_6471_);
v___x_6473_ = v___x_6464_;
goto v_reusejp_6472_;
}
else
{
lean_object* v_reuseFailAlloc_6474_; 
v_reuseFailAlloc_6474_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6474_, 0, v___x_6471_);
lean_ctor_set(v_reuseFailAlloc_6474_, 1, v_snd_6462_);
v___x_6473_ = v_reuseFailAlloc_6474_;
goto v_reusejp_6472_;
}
v_reusejp_6472_:
{
return v___x_6473_;
}
}
}
}
}
else
{
lean_object* v_snd_6479_; uint8_t v_width_6480_; 
lean_dec_ref_known(v_fst_6461_, 1);
v_snd_6479_ = lean_ctor_get(v___x_6460_, 1);
lean_inc(v_snd_6479_);
lean_dec_ref(v___x_6460_);
v_width_6480_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_6230_);
switch(v_width_6480_)
{
case 0:
{
v___y_6244_ = v_width_6480_;
v___y_6245_ = v_reducerRank_6433_;
v___y_6246_ = v_snd_6479_;
v___y_6247_ = v___x_6458_;
v___y_6248_ = v___x_6434_;
v___y_6249_ = v___x_6435_;
v___y_6250_ = v___x_6435_;
goto v___jp_6243_;
}
case 1:
{
lean_object* v___x_6481_; 
v___x_6481_ = lean_unsigned_to_nat(2u);
v___y_6244_ = v_width_6480_;
v___y_6245_ = v_reducerRank_6433_;
v___y_6246_ = v_snd_6479_;
v___y_6247_ = v___x_6458_;
v___y_6248_ = v___x_6434_;
v___y_6249_ = v___x_6435_;
v___y_6250_ = v___x_6481_;
goto v___jp_6243_;
}
default: 
{
lean_object* v___x_6482_; 
v___x_6482_ = lean_unsigned_to_nat(4u);
v___y_6244_ = v_width_6480_;
v___y_6245_ = v_reducerRank_6433_;
v___y_6246_ = v_snd_6479_;
v___y_6247_ = v___x_6458_;
v___y_6248_ = v___x_6434_;
v___y_6249_ = v___x_6435_;
v___y_6250_ = v___x_6482_;
goto v___jp_6243_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate___boxed(lean_object* v_field_6503_, lean_object* v_limits_6504_, lean_object* v_columns_6505_, lean_object* v_reducers_6506_, lean_object* v_targets_6507_, lean_object* v_provenance_6508_, lean_object* v_sugars_6509_, lean_object* v_native_6510_, lean_object* v_independent_6511_, lean_object* v_a_6512_){
_start:
{
uint64_t v_field_boxed_6513_; uint8_t v_provenance_boxed_6514_; uint8_t v_native_boxed_6515_; uint8_t v_independent_boxed_6516_; lean_object* v_res_6517_; 
v_field_boxed_6513_ = lean_unbox_uint64(v_field_6503_);
lean_dec_ref(v_field_6503_);
v_provenance_boxed_6514_ = lean_unbox(v_provenance_6508_);
v_native_boxed_6515_ = lean_unbox(v_native_6510_);
v_independent_boxed_6516_ = lean_unbox(v_independent_6511_);
v_res_6517_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate(v_field_boxed_6513_, v_limits_6504_, v_columns_6505_, v_reducers_6506_, v_targets_6507_, v_provenance_boxed_6514_, v_sugars_6509_, v_native_boxed_6515_, v_independent_boxed_6516_, v_a_6512_);
lean_dec_ref(v_sugars_6509_);
lean_dec_ref(v_targets_6507_);
lean_dec_ref(v_reducers_6506_);
lean_dec_ref(v_limits_6504_);
return v_res_6517_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0(lean_object* v_reducers_6518_, uint64_t v_field_6519_, lean_object* v_limits_6520_, lean_object* v_columns_6521_, lean_object* v_range_6522_, lean_object* v_b_6523_, lean_object* v_i_6524_, lean_object* v_hs_6525_, lean_object* v_hl_6526_, lean_object* v___y_6527_){
_start:
{
lean_object* v___x_6528_; 
v___x_6528_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___redArg(v_reducers_6518_, v_field_6519_, v_limits_6520_, v_columns_6521_, v_range_6522_, v_b_6523_, v_i_6524_, v___y_6527_);
return v___x_6528_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0___boxed(lean_object* v_reducers_6529_, lean_object* v_field_6530_, lean_object* v_limits_6531_, lean_object* v_columns_6532_, lean_object* v_range_6533_, lean_object* v_b_6534_, lean_object* v_i_6535_, lean_object* v_hs_6536_, lean_object* v_hl_6537_, lean_object* v___y_6538_){
_start:
{
uint64_t v_field_boxed_6539_; lean_object* v_res_6540_; 
v_field_boxed_6539_ = lean_unbox_uint64(v_field_6530_);
lean_dec_ref(v_field_6530_);
v_res_6540_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__0(v_reducers_6529_, v_field_boxed_6539_, v_limits_6531_, v_columns_6532_, v_range_6533_, v_b_6534_, v_i_6535_, v_hs_6536_, v_hl_6537_, v___y_6538_);
lean_dec_ref(v_range_6533_);
lean_dec(v_columns_6532_);
lean_dec_ref(v_limits_6531_);
lean_dec_ref(v_reducers_6529_);
return v_res_6540_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1(lean_object* v___x_6541_, lean_object* v_targets_6542_, uint64_t v_field_6543_, lean_object* v_limits_6544_, lean_object* v_columns_6545_, lean_object* v_range_6546_, lean_object* v_b_6547_, lean_object* v_i_6548_, lean_object* v_hs_6549_, lean_object* v_hl_6550_, lean_object* v___y_6551_){
_start:
{
lean_object* v___x_6552_; 
v___x_6552_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___redArg(v___x_6541_, v_targets_6542_, v_field_6543_, v_limits_6544_, v_columns_6545_, v_range_6546_, v_b_6547_, v_i_6548_, v___y_6551_);
return v___x_6552_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1___boxed(lean_object* v___x_6553_, lean_object* v_targets_6554_, lean_object* v_field_6555_, lean_object* v_limits_6556_, lean_object* v_columns_6557_, lean_object* v_range_6558_, lean_object* v_b_6559_, lean_object* v_i_6560_, lean_object* v_hs_6561_, lean_object* v_hl_6562_, lean_object* v___y_6563_){
_start:
{
uint64_t v_field_boxed_6564_; lean_object* v_res_6565_; 
v_field_boxed_6564_ = lean_unbox_uint64(v_field_6555_);
lean_dec_ref(v_field_6555_);
v_res_6565_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__1(v___x_6553_, v_targets_6554_, v_field_boxed_6564_, v_limits_6556_, v_columns_6557_, v_range_6558_, v_b_6559_, v_i_6560_, v_hs_6561_, v_hl_6562_, v___y_6563_);
lean_dec_ref(v_range_6558_);
lean_dec(v_columns_6557_);
lean_dec_ref(v_limits_6556_);
lean_dec_ref(v_targets_6554_);
lean_dec(v___x_6553_);
return v_res_6565_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2(uint64_t v_field_6566_, uint64_t v_ctx_6567_, uint64_t v___y_6568_, uint8_t v_width_6569_, lean_object* v___x_6570_, lean_object* v___x_6571_, lean_object* v_range_6572_, lean_object* v_b_6573_, lean_object* v_i_6574_, lean_object* v_hs_6575_, lean_object* v_hl_6576_, lean_object* v___y_6577_){
_start:
{
lean_object* v___x_6578_; 
v___x_6578_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___redArg(v_field_6566_, v_ctx_6567_, v___y_6568_, v_width_6569_, v___x_6570_, v___x_6571_, v_range_6572_, v_b_6573_, v_i_6574_, v___y_6577_);
return v___x_6578_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2___boxed(lean_object* v_field_6579_, lean_object* v_ctx_6580_, lean_object* v___y_6581_, lean_object* v_width_6582_, lean_object* v___x_6583_, lean_object* v___x_6584_, lean_object* v_range_6585_, lean_object* v_b_6586_, lean_object* v_i_6587_, lean_object* v_hs_6588_, lean_object* v_hl_6589_, lean_object* v___y_6590_){
_start:
{
uint64_t v_field_boxed_6591_; uint64_t v_ctx_boxed_6592_; uint64_t v___y_104472__boxed_6593_; uint8_t v_width_boxed_6594_; lean_object* v_res_6595_; 
v_field_boxed_6591_ = lean_unbox_uint64(v_field_6579_);
lean_dec_ref(v_field_6579_);
v_ctx_boxed_6592_ = lean_unbox_uint64(v_ctx_6580_);
lean_dec_ref(v_ctx_6580_);
v___y_104472__boxed_6593_ = lean_unbox_uint64(v___y_6581_);
lean_dec_ref(v___y_6581_);
v_width_boxed_6594_ = lean_unbox(v_width_6582_);
v_res_6595_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__2(v_field_boxed_6591_, v_ctx_boxed_6592_, v___y_104472__boxed_6593_, v_width_boxed_6594_, v___x_6583_, v___x_6584_, v_range_6585_, v_b_6586_, v_i_6587_, v_hs_6588_, v_hl_6589_, v___y_6590_);
lean_dec_ref(v_range_6585_);
lean_dec_ref(v___x_6584_);
lean_dec_ref(v___x_6583_);
return v_res_6595_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3(uint8_t v_width_6596_, lean_object* v___y_6597_, lean_object* v___x_6598_, lean_object* v_range_6599_, lean_object* v_b_6600_, lean_object* v_i_6601_, lean_object* v_hs_6602_, lean_object* v_hl_6603_, lean_object* v___y_6604_){
_start:
{
lean_object* v___x_6605_; 
v___x_6605_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___redArg(v_width_6596_, v___y_6597_, v___x_6598_, v_range_6599_, v_b_6600_, v_i_6601_, v___y_6604_);
return v___x_6605_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3___boxed(lean_object* v_width_6606_, lean_object* v___y_6607_, lean_object* v___x_6608_, lean_object* v_range_6609_, lean_object* v_b_6610_, lean_object* v_i_6611_, lean_object* v_hs_6612_, lean_object* v_hl_6613_, lean_object* v___y_6614_){
_start:
{
uint8_t v_width_boxed_6615_; lean_object* v_res_6616_; 
v_width_boxed_6615_ = lean_unbox(v_width_6606_);
v_res_6616_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__3(v_width_boxed_6615_, v___y_6607_, v___x_6608_, v_range_6609_, v_b_6610_, v_i_6611_, v_hs_6612_, v_hl_6613_, v___y_6614_);
lean_dec_ref(v_range_6609_);
lean_dec_ref(v___x_6608_);
lean_dec_ref(v___y_6607_);
return v_res_6616_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4(uint8_t v_width_6617_, lean_object* v_limits_6618_, lean_object* v___y_6619_, uint64_t v_inv_6620_, uint64_t v_field_6621_, uint64_t v_ctx_6622_, lean_object* v_range_6623_, lean_object* v_b_6624_, lean_object* v_i_6625_, lean_object* v_hs_6626_, lean_object* v_hl_6627_, lean_object* v___y_6628_){
_start:
{
lean_object* v___x_6629_; 
v___x_6629_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg(v_width_6617_, v_limits_6618_, v___y_6619_, v_inv_6620_, v_field_6621_, v_ctx_6622_, v_range_6623_, v_b_6624_, v_i_6625_, v___y_6628_);
return v___x_6629_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___boxed(lean_object* v_width_6630_, lean_object* v_limits_6631_, lean_object* v___y_6632_, lean_object* v_inv_6633_, lean_object* v_field_6634_, lean_object* v_ctx_6635_, lean_object* v_range_6636_, lean_object* v_b_6637_, lean_object* v_i_6638_, lean_object* v_hs_6639_, lean_object* v_hl_6640_, lean_object* v___y_6641_){
_start:
{
uint8_t v_width_boxed_6642_; uint64_t v_inv_boxed_6643_; uint64_t v_field_boxed_6644_; uint64_t v_ctx_boxed_6645_; lean_object* v_res_6646_; 
v_width_boxed_6642_ = lean_unbox(v_width_6630_);
v_inv_boxed_6643_ = lean_unbox_uint64(v_inv_6633_);
lean_dec_ref(v_inv_6633_);
v_field_boxed_6644_ = lean_unbox_uint64(v_field_6634_);
lean_dec_ref(v_field_6634_);
v_ctx_boxed_6645_ = lean_unbox_uint64(v_ctx_6635_);
lean_dec_ref(v_ctx_6635_);
v_res_6646_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4(v_width_boxed_6642_, v_limits_6631_, v___y_6632_, v_inv_boxed_6643_, v_field_boxed_6644_, v_ctx_boxed_6645_, v_range_6636_, v_b_6637_, v_i_6638_, v_hs_6639_, v_hl_6640_, v___y_6641_);
lean_dec_ref(v_range_6636_);
lean_dec(v___y_6632_);
lean_dec_ref(v_limits_6631_);
return v_res_6646_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5(lean_object* v___x_6647_, uint64_t v_field_6648_, uint64_t v_ctx_6649_, uint8_t v_width_6650_, lean_object* v_limits_6651_, uint8_t v_provenance_6652_, lean_object* v___x_6653_, lean_object* v_range_6654_, lean_object* v_b_6655_, lean_object* v_i_6656_, lean_object* v_hs_6657_, lean_object* v_hl_6658_, lean_object* v___y_6659_){
_start:
{
lean_object* v___x_6660_; 
v___x_6660_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___redArg(v___x_6647_, v_field_6648_, v_ctx_6649_, v_width_6650_, v_limits_6651_, v_provenance_6652_, v___x_6653_, v_range_6654_, v_b_6655_, v_i_6656_, v___y_6659_);
return v___x_6660_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5___boxed(lean_object* v___x_6661_, lean_object* v_field_6662_, lean_object* v_ctx_6663_, lean_object* v_width_6664_, lean_object* v_limits_6665_, lean_object* v_provenance_6666_, lean_object* v___x_6667_, lean_object* v_range_6668_, lean_object* v_b_6669_, lean_object* v_i_6670_, lean_object* v_hs_6671_, lean_object* v_hl_6672_, lean_object* v___y_6673_){
_start:
{
uint64_t v_field_boxed_6674_; uint64_t v_ctx_boxed_6675_; uint8_t v_width_boxed_6676_; uint8_t v_provenance_boxed_6677_; lean_object* v_res_6678_; 
v_field_boxed_6674_ = lean_unbox_uint64(v_field_6662_);
lean_dec_ref(v_field_6662_);
v_ctx_boxed_6675_ = lean_unbox_uint64(v_ctx_6663_);
lean_dec_ref(v_ctx_6663_);
v_width_boxed_6676_ = lean_unbox(v_width_6664_);
v_provenance_boxed_6677_ = lean_unbox(v_provenance_6666_);
v_res_6678_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5(v___x_6661_, v_field_boxed_6674_, v_ctx_boxed_6675_, v_width_boxed_6676_, v_limits_6665_, v_provenance_boxed_6677_, v___x_6667_, v_range_6668_, v_b_6669_, v_i_6670_, v_hs_6671_, v_hl_6672_, v___y_6673_);
lean_dec_ref(v_range_6668_);
lean_dec_ref(v___x_6667_);
lean_dec_ref(v_limits_6665_);
lean_dec_ref(v___x_6661_);
return v_res_6678_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6(lean_object* v_limits_6679_, uint64_t v_field_6680_, uint64_t v_ctx_6681_, uint8_t v_width_6682_, uint8_t v_provenance_6683_, lean_object* v___x_6684_, uint8_t v_native_6685_, lean_object* v___y_6686_, uint8_t v_independent_6687_, lean_object* v_columns_6688_, lean_object* v_sugars_6689_, lean_object* v_reducers_6690_, lean_object* v_targets_6691_, lean_object* v_range_6692_, lean_object* v_b_6693_, lean_object* v_i_6694_, lean_object* v_hs_6695_, lean_object* v_hl_6696_, lean_object* v___y_6697_){
_start:
{
lean_object* v___x_6698_; 
v___x_6698_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___redArg(v_limits_6679_, v_field_6680_, v_ctx_6681_, v_width_6682_, v_provenance_6683_, v___x_6684_, v_native_6685_, v___y_6686_, v_independent_6687_, v_columns_6688_, v_sugars_6689_, v_reducers_6690_, v_targets_6691_, v_range_6692_, v_b_6693_, v_i_6694_, v___y_6697_);
return v___x_6698_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6___boxed(lean_object** _args){
lean_object* v_limits_6699_ = _args[0];
lean_object* v_field_6700_ = _args[1];
lean_object* v_ctx_6701_ = _args[2];
lean_object* v_width_6702_ = _args[3];
lean_object* v_provenance_6703_ = _args[4];
lean_object* v___x_6704_ = _args[5];
lean_object* v_native_6705_ = _args[6];
lean_object* v___y_6706_ = _args[7];
lean_object* v_independent_6707_ = _args[8];
lean_object* v_columns_6708_ = _args[9];
lean_object* v_sugars_6709_ = _args[10];
lean_object* v_reducers_6710_ = _args[11];
lean_object* v_targets_6711_ = _args[12];
lean_object* v_range_6712_ = _args[13];
lean_object* v_b_6713_ = _args[14];
lean_object* v_i_6714_ = _args[15];
lean_object* v_hs_6715_ = _args[16];
lean_object* v_hl_6716_ = _args[17];
lean_object* v___y_6717_ = _args[18];
_start:
{
uint64_t v_field_boxed_6718_; uint64_t v_ctx_boxed_6719_; uint8_t v_width_boxed_6720_; uint8_t v_provenance_boxed_6721_; uint8_t v_native_boxed_6722_; uint8_t v_independent_boxed_6723_; lean_object* v_res_6724_; 
v_field_boxed_6718_ = lean_unbox_uint64(v_field_6700_);
lean_dec_ref(v_field_6700_);
v_ctx_boxed_6719_ = lean_unbox_uint64(v_ctx_6701_);
lean_dec_ref(v_ctx_6701_);
v_width_boxed_6720_ = lean_unbox(v_width_6702_);
v_provenance_boxed_6721_ = lean_unbox(v_provenance_6703_);
v_native_boxed_6722_ = lean_unbox(v_native_6705_);
v_independent_boxed_6723_ = lean_unbox(v_independent_6707_);
v_res_6724_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6(v_limits_6699_, v_field_boxed_6718_, v_ctx_boxed_6719_, v_width_boxed_6720_, v_provenance_boxed_6721_, v___x_6704_, v_native_boxed_6722_, v___y_6706_, v_independent_boxed_6723_, v_columns_6708_, v_sugars_6709_, v_reducers_6710_, v_targets_6711_, v_range_6712_, v_b_6713_, v_i_6714_, v_hs_6715_, v_hl_6716_, v___y_6717_);
lean_dec_ref(v_range_6712_);
lean_dec_ref(v_targets_6711_);
lean_dec_ref(v_reducers_6710_);
lean_dec_ref(v_sugars_6709_);
lean_dec(v___y_6706_);
lean_dec(v___x_6704_);
lean_dec_ref(v_limits_6699_);
return v_res_6724_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7(lean_object* v_pivots_6725_, lean_object* v_slots_6726_, lean_object* v_range_6727_, lean_object* v_b_6728_, lean_object* v_i_6729_, lean_object* v_hs_6730_, lean_object* v_hl_6731_, lean_object* v___y_6732_){
_start:
{
lean_object* v___x_6733_; 
v___x_6733_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___redArg(v_pivots_6725_, v_slots_6726_, v_range_6727_, v_b_6728_, v_i_6729_, v___y_6732_);
return v___x_6733_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7___boxed(lean_object* v_pivots_6734_, lean_object* v_slots_6735_, lean_object* v_range_6736_, lean_object* v_b_6737_, lean_object* v_i_6738_, lean_object* v_hs_6739_, lean_object* v_hl_6740_, lean_object* v___y_6741_){
_start:
{
lean_object* v_res_6742_; 
v_res_6742_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__7(v_pivots_6734_, v_slots_6735_, v_range_6736_, v_b_6737_, v_i_6738_, v_hs_6739_, v_hl_6740_, v___y_6741_);
lean_dec_ref(v_range_6736_);
lean_dec_ref(v_slots_6735_);
lean_dec_ref(v_pivots_6734_);
return v_res_6742_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5(lean_object* v___x_6743_, lean_object* v_limits_6744_, uint64_t v_field_6745_, uint64_t v_ctx_6746_, uint8_t v_width_6747_, uint8_t v_provenance_6748_, lean_object* v___x_6749_, lean_object* v_range_6750_, lean_object* v_b_6751_, lean_object* v_i_6752_, lean_object* v_hs_6753_, lean_object* v_hl_6754_, lean_object* v___y_6755_){
_start:
{
lean_object* v___x_6756_; 
v___x_6756_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5___redArg(v___x_6743_, v_limits_6744_, v_field_6745_, v_ctx_6746_, v_width_6747_, v_provenance_6748_, v___x_6749_, v_range_6750_, v_b_6751_, v_i_6752_, v___y_6755_);
return v___x_6756_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5___boxed(lean_object* v___x_6757_, lean_object* v_limits_6758_, lean_object* v_field_6759_, lean_object* v_ctx_6760_, lean_object* v_width_6761_, lean_object* v_provenance_6762_, lean_object* v___x_6763_, lean_object* v_range_6764_, lean_object* v_b_6765_, lean_object* v_i_6766_, lean_object* v_hs_6767_, lean_object* v_hl_6768_, lean_object* v___y_6769_){
_start:
{
uint64_t v_field_boxed_6770_; uint64_t v_ctx_boxed_6771_; uint8_t v_width_boxed_6772_; uint8_t v_provenance_boxed_6773_; lean_object* v_res_6774_; 
v_field_boxed_6770_ = lean_unbox_uint64(v_field_6759_);
lean_dec_ref(v_field_6759_);
v_ctx_boxed_6771_ = lean_unbox_uint64(v_ctx_6760_);
lean_dec_ref(v_ctx_6760_);
v_width_boxed_6772_ = lean_unbox(v_width_6761_);
v_provenance_boxed_6773_ = lean_unbox(v_provenance_6762_);
v_res_6774_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__5_spec__5(v___x_6757_, v_limits_6758_, v_field_boxed_6770_, v_ctx_boxed_6771_, v_width_boxed_6772_, v_provenance_boxed_6773_, v___x_6763_, v_range_6764_, v_b_6765_, v_i_6766_, v_hs_6767_, v_hl_6768_, v___y_6769_);
lean_dec_ref(v_range_6764_);
lean_dec_ref(v___x_6763_);
lean_dec_ref(v_limits_6758_);
lean_dec_ref(v___x_6757_);
return v_res_6774_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7(lean_object* v_limits_6775_, lean_object* v___x_6776_, uint8_t v_provenance_6777_, uint64_t v_field_6778_, uint64_t v_ctx_6779_, uint8_t v_native_6780_, uint8_t v_width_6781_, uint8_t v_independent_6782_, lean_object* v___y_6783_, lean_object* v_columns_6784_, lean_object* v_sugars_6785_, lean_object* v_reducers_6786_, lean_object* v_targets_6787_, lean_object* v_range_6788_, lean_object* v_b_6789_, lean_object* v_i_6790_, lean_object* v_hs_6791_, lean_object* v_hl_6792_, lean_object* v___y_6793_){
_start:
{
lean_object* v___x_6794_; 
v___x_6794_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___redArg(v_limits_6775_, v___x_6776_, v_provenance_6777_, v_field_6778_, v_ctx_6779_, v_native_6780_, v_width_6781_, v_independent_6782_, v___y_6783_, v_columns_6784_, v_sugars_6785_, v_reducers_6786_, v_targets_6787_, v_range_6788_, v_b_6789_, v_i_6790_, v___y_6793_);
return v___x_6794_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7___boxed(lean_object** _args){
lean_object* v_limits_6795_ = _args[0];
lean_object* v___x_6796_ = _args[1];
lean_object* v_provenance_6797_ = _args[2];
lean_object* v_field_6798_ = _args[3];
lean_object* v_ctx_6799_ = _args[4];
lean_object* v_native_6800_ = _args[5];
lean_object* v_width_6801_ = _args[6];
lean_object* v_independent_6802_ = _args[7];
lean_object* v___y_6803_ = _args[8];
lean_object* v_columns_6804_ = _args[9];
lean_object* v_sugars_6805_ = _args[10];
lean_object* v_reducers_6806_ = _args[11];
lean_object* v_targets_6807_ = _args[12];
lean_object* v_range_6808_ = _args[13];
lean_object* v_b_6809_ = _args[14];
lean_object* v_i_6810_ = _args[15];
lean_object* v_hs_6811_ = _args[16];
lean_object* v_hl_6812_ = _args[17];
lean_object* v___y_6813_ = _args[18];
_start:
{
uint8_t v_provenance_boxed_6814_; uint64_t v_field_boxed_6815_; uint64_t v_ctx_boxed_6816_; uint8_t v_native_boxed_6817_; uint8_t v_width_boxed_6818_; uint8_t v_independent_boxed_6819_; lean_object* v_res_6820_; 
v_provenance_boxed_6814_ = lean_unbox(v_provenance_6797_);
v_field_boxed_6815_ = lean_unbox_uint64(v_field_6798_);
lean_dec_ref(v_field_6798_);
v_ctx_boxed_6816_ = lean_unbox_uint64(v_ctx_6799_);
lean_dec_ref(v_ctx_6799_);
v_native_boxed_6817_ = lean_unbox(v_native_6800_);
v_width_boxed_6818_ = lean_unbox(v_width_6801_);
v_independent_boxed_6819_ = lean_unbox(v_independent_6802_);
v_res_6820_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__6_spec__7(v_limits_6795_, v___x_6796_, v_provenance_boxed_6814_, v_field_boxed_6815_, v_ctx_boxed_6816_, v_native_boxed_6817_, v_width_boxed_6818_, v_independent_boxed_6819_, v___y_6803_, v_columns_6804_, v_sugars_6805_, v_reducers_6806_, v_targets_6807_, v_range_6808_, v_b_6809_, v_i_6810_, v_hs_6811_, v_hl_6812_, v___y_6813_);
lean_dec_ref(v_range_6808_);
lean_dec_ref(v_targets_6807_);
lean_dec_ref(v_reducers_6806_);
lean_dec_ref(v_sugars_6805_);
lean_dec(v___y_6803_);
lean_dec(v___x_6796_);
lean_dec_ref(v_limits_6795_);
return v_res_6820_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_reference(uint64_t v_field_6823_, lean_object* v_limits_6824_, lean_object* v_columns_6825_, lean_object* v_reducers_6826_, lean_object* v_targets_6827_, lean_object* v_sugars_6828_, uint8_t v_independent_6829_){
_start:
{
uint8_t v___x_6830_; uint8_t v___x_6831_; lean_object* v___x_6832_; lean_object* v___x_6833_; lean_object* v_fst_6834_; lean_object* v_snd_6835_; lean_object* v___x_6837_; uint8_t v_isShared_6838_; uint8_t v_isSharedCheck_6842_; 
v___x_6830_ = 0;
v___x_6831_ = 1;
v___x_6832_ = ((lean_object*)(lp_Hex_Hex_Groebner_Elimination_reference___closed__0));
v___x_6833_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate(v_field_6823_, v_limits_6824_, v_columns_6825_, v_reducers_6826_, v_targets_6827_, v___x_6830_, v_sugars_6828_, v___x_6831_, v_independent_6829_, v___x_6832_);
v_fst_6834_ = lean_ctor_get(v___x_6833_, 0);
v_snd_6835_ = lean_ctor_get(v___x_6833_, 1);
v_isSharedCheck_6842_ = !lean_is_exclusive(v___x_6833_);
if (v_isSharedCheck_6842_ == 0)
{
v___x_6837_ = v___x_6833_;
v_isShared_6838_ = v_isSharedCheck_6842_;
goto v_resetjp_6836_;
}
else
{
lean_inc(v_snd_6835_);
lean_inc(v_fst_6834_);
lean_dec(v___x_6833_);
v___x_6837_ = lean_box(0);
v_isShared_6838_ = v_isSharedCheck_6842_;
goto v_resetjp_6836_;
}
v_resetjp_6836_:
{
lean_object* v___x_6840_; 
if (v_isShared_6838_ == 0)
{
v___x_6840_ = v___x_6837_;
goto v_reusejp_6839_;
}
else
{
lean_object* v_reuseFailAlloc_6841_; 
v_reuseFailAlloc_6841_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6841_, 0, v_fst_6834_);
lean_ctor_set(v_reuseFailAlloc_6841_, 1, v_snd_6835_);
v___x_6840_ = v_reuseFailAlloc_6841_;
goto v_reusejp_6839_;
}
v_reusejp_6839_:
{
return v___x_6840_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_reference___boxed(lean_object* v_field_6843_, lean_object* v_limits_6844_, lean_object* v_columns_6845_, lean_object* v_reducers_6846_, lean_object* v_targets_6847_, lean_object* v_sugars_6848_, lean_object* v_independent_6849_){
_start:
{
uint64_t v_field_boxed_6850_; uint8_t v_independent_boxed_6851_; lean_object* v_res_6852_; 
v_field_boxed_6850_ = lean_unbox_uint64(v_field_6843_);
lean_dec_ref(v_field_6843_);
v_independent_boxed_6851_ = lean_unbox(v_independent_6849_);
v_res_6852_ = lp_Hex_Hex_Groebner_Elimination_reference(v_field_boxed_6850_, v_limits_6844_, v_columns_6845_, v_reducers_6846_, v_targets_6847_, v_sugars_6848_, v_independent_boxed_6851_);
lean_dec_ref(v_sugars_6848_);
lean_dec_ref(v_targets_6847_);
lean_dec_ref(v_reducers_6846_);
lean_dec_ref(v_limits_6844_);
return v_res_6852_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___lam__0(lean_object* v_xs_6853_, lean_object* v_i_6854_){
_start:
{
lean_object* v___x_6855_; uint8_t v___x_6856_; 
v___x_6855_ = lean_byte_array_size(v_xs_6853_);
v___x_6856_ = lean_nat_dec_lt(v_i_6854_, v___x_6855_);
return v___x_6856_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___lam__0___boxed(lean_object* v_xs_6857_, lean_object* v_i_6858_){
_start:
{
uint8_t v_res_6859_; lean_object* v_r_6860_; 
v_res_6859_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___lam__0(v_xs_6857_, v_i_6858_);
lean_dec(v_i_6858_);
lean_dec_ref(v_xs_6857_);
v_r_6860_ = lean_box(v_res_6859_);
return v_r_6860_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__0(void){
_start:
{
lean_object* v___x_6861_; 
v___x_6861_ = lean_cstr_to_nat("18446744073709551616");
return v___x_6861_;
}
}
static uint8_t _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1(void){
_start:
{
lean_object* v___x_6862_; lean_object* v___x_6863_; uint8_t v___x_6864_; 
v___x_6862_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__0, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__0_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__0);
v___x_6863_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0);
v___x_6864_ = lean_nat_dec_eq(v___x_6863_, v___x_6862_);
return v___x_6864_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2(lean_object* v___x_6865_, lean_object* v_columns_6866_, lean_object* v_as_6867_, size_t v_sz_6868_, size_t v_i_6869_, lean_object* v_b_6870_){
_start:
{
lean_object* v_a_6872_; uint8_t v___x_6876_; 
v___x_6876_ = lean_usize_dec_lt(v_i_6869_, v_sz_6868_);
if (v___x_6876_ == 0)
{
return v_b_6870_;
}
else
{
lean_object* v_snd_6877_; lean_object* v___x_6879_; uint8_t v_isShared_6880_; uint8_t v_isSharedCheck_6989_; 
v_snd_6877_ = lean_ctor_get(v_b_6870_, 1);
v_isSharedCheck_6989_ = !lean_is_exclusive(v_b_6870_);
if (v_isSharedCheck_6989_ == 0)
{
lean_object* v_unused_6990_; 
v_unused_6990_ = lean_ctor_get(v_b_6870_, 0);
lean_dec(v_unused_6990_);
v___x_6879_ = v_b_6870_;
v_isShared_6880_ = v_isSharedCheck_6989_;
goto v_resetjp_6878_;
}
else
{
lean_inc(v_snd_6877_);
lean_dec(v_b_6870_);
v___x_6879_ = lean_box(0);
v_isShared_6880_ = v_isSharedCheck_6989_;
goto v_resetjp_6878_;
}
v_resetjp_6878_:
{
lean_object* v___x_6881_; lean_object* v_entries_6882_; lean_object* v_a_6883_; lean_object* v___x_6884_; uint8_t v___x_6885_; 
v___x_6881_ = lean_box(0);
v_entries_6882_ = lean_unsigned_to_nat(0u);
v_a_6883_ = lean_array_uget(v_as_6867_, v_i_6869_);
v___x_6884_ = lp_Hex_Hex_Groebner_SparseRow_size(v_a_6883_);
v___x_6885_ = lean_nat_dec_eq(v___x_6884_, v_entries_6882_);
lean_dec(v___x_6884_);
if (v___x_6885_ == 0)
{
lean_object* v_columns_6886_; lean_object* v___x_6888_; uint8_t v_isShared_6889_; uint8_t v_isSharedCheck_6984_; 
v_columns_6886_ = lean_ctor_get(v_a_6883_, 0);
v_isSharedCheck_6984_ = !lean_is_exclusive(v_a_6883_);
if (v_isSharedCheck_6984_ == 0)
{
lean_object* v_unused_6985_; 
v_unused_6985_ = lean_ctor_get(v_a_6883_, 1);
lean_dec(v_unused_6985_);
v___x_6888_ = v_a_6883_;
v_isShared_6889_ = v_isSharedCheck_6984_;
goto v_resetjp_6887_;
}
else
{
lean_inc(v_columns_6886_);
lean_dec(v_a_6883_);
v___x_6888_ = lean_box(0);
v_isShared_6889_ = v_isSharedCheck_6984_;
goto v_resetjp_6887_;
}
v_resetjp_6887_:
{
lean_object* v___x_6890_; uint8_t v___x_6891_; lean_object* v___x_6898_; uint8_t v___x_6899_; uint64_t v___y_6901_; uint64_t v___y_6913_; uint8_t v___y_6914_; lean_object* v___x_6941_; lean_object* v___x_6942_; uint8_t v___x_6943_; 
v___x_6890_ = lean_unsigned_to_nat(1048576u);
v___x_6891_ = lean_nat_dec_lt(v___x_6890_, v___x_6865_);
v___x_6898_ = lean_unsigned_to_nat(2u);
v___x_6899_ = lean_uint8_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1);
v___x_6941_ = lean_unsigned_to_nat(4u);
v___x_6942_ = lean_byte_array_size(v_columns_6886_);
v___x_6943_ = lean_nat_dec_le(v___x_6941_, v___x_6942_);
if (v___x_6943_ == 0)
{
if (v___x_6943_ == 0)
{
uint8_t v___x_6944_; uint64_t v___y_6946_; uint8_t v___y_6947_; uint64_t v___y_6959_; uint8_t v___y_6960_; uint8_t v___y_6971_; uint8_t v___x_6979_; 
v___x_6944_ = 0;
v___x_6979_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___lam__0(v_columns_6886_, v_entries_6882_);
if (v___x_6979_ == 0)
{
lean_object* v___x_6980_; lean_object* v___x_6981_; uint8_t v___x_6982_; 
v___x_6980_ = lean_box(v___x_6944_);
v___x_6981_ = l_outOfBounds___redArg(v___x_6980_);
lean_dec(v___x_6980_);
v___x_6982_ = lean_unbox(v___x_6981_);
lean_dec(v___x_6981_);
v___y_6971_ = v___x_6982_;
goto v___jp_6970_;
}
else
{
uint8_t v___x_6983_; 
v___x_6983_ = lean_byte_array_fget(v_columns_6886_, v_entries_6882_);
v___y_6971_ = v___x_6983_;
goto v___jp_6970_;
}
v___jp_6945_:
{
uint64_t v___x_6948_; uint64_t v___x_6949_; uint64_t v___x_6950_; uint64_t v___x_6951_; lean_object* v___x_6952_; uint8_t v___x_6953_; 
v___x_6948_ = lean_uint8_to_uint64(v___y_6947_);
v___x_6949_ = 16ULL;
v___x_6950_ = lean_uint64_shift_left(v___x_6948_, v___x_6949_);
v___x_6951_ = lean_uint64_lor(v___y_6946_, v___x_6950_);
v___x_6952_ = lean_unsigned_to_nat(3u);
v___x_6953_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___lam__0(v_columns_6886_, v___x_6952_);
if (v___x_6953_ == 0)
{
lean_object* v___x_6954_; lean_object* v___x_6955_; uint8_t v___x_6956_; 
lean_dec_ref(v_columns_6886_);
v___x_6954_ = lean_box(v___x_6944_);
v___x_6955_ = l_outOfBounds___redArg(v___x_6954_);
lean_dec(v___x_6954_);
v___x_6956_ = lean_unbox(v___x_6955_);
lean_dec(v___x_6955_);
v___y_6913_ = v___x_6951_;
v___y_6914_ = v___x_6956_;
goto v___jp_6912_;
}
else
{
uint8_t v___x_6957_; 
v___x_6957_ = lean_byte_array_fget(v_columns_6886_, v___x_6952_);
lean_dec_ref(v_columns_6886_);
v___y_6913_ = v___x_6951_;
v___y_6914_ = v___x_6957_;
goto v___jp_6912_;
}
}
v___jp_6958_:
{
uint64_t v___x_6961_; uint64_t v___x_6962_; uint64_t v___x_6963_; uint64_t v___x_6964_; uint8_t v___x_6965_; 
v___x_6961_ = lean_uint8_to_uint64(v___y_6960_);
v___x_6962_ = 8ULL;
v___x_6963_ = lean_uint64_shift_left(v___x_6961_, v___x_6962_);
v___x_6964_ = lean_uint64_lor(v___y_6959_, v___x_6963_);
v___x_6965_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___lam__0(v_columns_6886_, v___x_6898_);
if (v___x_6965_ == 0)
{
lean_object* v___x_6966_; lean_object* v___x_6967_; uint8_t v___x_6968_; 
v___x_6966_ = lean_box(v___x_6944_);
v___x_6967_ = l_outOfBounds___redArg(v___x_6966_);
lean_dec(v___x_6966_);
v___x_6968_ = lean_unbox(v___x_6967_);
lean_dec(v___x_6967_);
v___y_6946_ = v___x_6964_;
v___y_6947_ = v___x_6968_;
goto v___jp_6945_;
}
else
{
uint8_t v___x_6969_; 
v___x_6969_ = lean_byte_array_fget(v_columns_6886_, v___x_6898_);
v___y_6946_ = v___x_6964_;
v___y_6947_ = v___x_6969_;
goto v___jp_6945_;
}
}
v___jp_6970_:
{
uint64_t v_a_6972_; lean_object* v___x_6973_; uint8_t v___x_6974_; 
v_a_6972_ = lean_uint8_to_uint64(v___y_6971_);
v___x_6973_ = lean_unsigned_to_nat(1u);
v___x_6974_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___lam__0(v_columns_6886_, v___x_6973_);
if (v___x_6974_ == 0)
{
lean_object* v___x_6975_; lean_object* v___x_6976_; uint8_t v___x_6977_; 
v___x_6975_ = lean_box(v___x_6944_);
v___x_6976_ = l_outOfBounds___redArg(v___x_6975_);
lean_dec(v___x_6975_);
v___x_6977_ = lean_unbox(v___x_6976_);
lean_dec(v___x_6976_);
v___y_6959_ = v_a_6972_;
v___y_6960_ = v___x_6977_;
goto v___jp_6958_;
}
else
{
uint8_t v___x_6978_; 
v___x_6978_ = lean_byte_array_fget(v_columns_6886_, v___x_6973_);
v___y_6959_ = v_a_6972_;
v___y_6960_ = v___x_6978_;
goto v___jp_6958_;
}
}
}
else
{
goto v___jp_6919_;
}
}
else
{
goto v___jp_6919_;
}
v___jp_6892_:
{
lean_object* v___x_6893_; lean_object* v___x_6894_; lean_object* v___x_6896_; 
v___x_6893_ = lean_box(v___x_6891_);
v___x_6894_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_6894_, 0, v___x_6893_);
if (v_isShared_6880_ == 0)
{
lean_ctor_set(v___x_6879_, 0, v___x_6894_);
v___x_6896_ = v___x_6879_;
goto v_reusejp_6895_;
}
else
{
lean_object* v_reuseFailAlloc_6897_; 
v_reuseFailAlloc_6897_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6897_, 0, v___x_6894_);
lean_ctor_set(v_reuseFailAlloc_6897_, 1, v_snd_6877_);
v___x_6896_ = v_reuseFailAlloc_6897_;
goto v_reusejp_6895_;
}
v_reusejp_6895_:
{
return v___x_6896_;
}
}
v___jp_6900_:
{
lean_object* v___x_6902_; uint8_t v___x_6903_; 
v___x_6902_ = lean_uint64_to_nat(v___y_6901_);
v___x_6903_ = lean_nat_dec_le(v_columns_6866_, v___x_6902_);
if (v___x_6903_ == 0)
{
lean_object* v___x_6904_; lean_object* v___x_6905_; uint8_t v___x_6906_; 
v___x_6904_ = lean_box(v___x_6885_);
v___x_6905_ = lean_array_get(v___x_6904_, v_snd_6877_, v___x_6902_);
lean_dec(v___x_6904_);
v___x_6906_ = lean_unbox(v___x_6905_);
lean_dec(v___x_6905_);
if (v___x_6906_ == 0)
{
lean_object* v___x_6907_; lean_object* v___x_6908_; lean_object* v___x_6910_; 
lean_del_object(v___x_6879_);
v___x_6907_ = lean_box(v___x_6899_);
v___x_6908_ = lean_array_set(v_snd_6877_, v___x_6902_, v___x_6907_);
lean_dec(v___x_6902_);
if (v_isShared_6889_ == 0)
{
lean_ctor_set(v___x_6888_, 1, v___x_6908_);
lean_ctor_set(v___x_6888_, 0, v___x_6881_);
v___x_6910_ = v___x_6888_;
goto v_reusejp_6909_;
}
else
{
lean_object* v_reuseFailAlloc_6911_; 
v_reuseFailAlloc_6911_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6911_, 0, v___x_6881_);
lean_ctor_set(v_reuseFailAlloc_6911_, 1, v___x_6908_);
v___x_6910_ = v_reuseFailAlloc_6911_;
goto v_reusejp_6909_;
}
v_reusejp_6909_:
{
v_a_6872_ = v___x_6910_;
goto v___jp_6871_;
}
}
else
{
lean_dec(v___x_6902_);
lean_del_object(v___x_6888_);
goto v___jp_6892_;
}
}
else
{
lean_dec(v___x_6902_);
lean_del_object(v___x_6888_);
goto v___jp_6892_;
}
}
v___jp_6912_:
{
uint64_t v___x_6915_; uint64_t v___x_6916_; uint64_t v___x_6917_; uint64_t v___x_6918_; 
v___x_6915_ = lean_uint8_to_uint64(v___y_6914_);
v___x_6916_ = 24ULL;
v___x_6917_ = lean_uint64_shift_left(v___x_6915_, v___x_6916_);
v___x_6918_ = lean_uint64_lor(v___y_6913_, v___x_6917_);
v___y_6901_ = v___x_6918_;
goto v___jp_6900_;
}
v___jp_6919_:
{
size_t v_pos_6920_; uint8_t v___x_6921_; uint64_t v_a_6922_; size_t v___x_6923_; uint8_t v___x_6924_; uint64_t v___x_6925_; uint64_t v___x_6926_; uint64_t v___x_6927_; uint64_t v___x_6928_; size_t v___x_6929_; uint8_t v___x_6930_; uint64_t v___x_6931_; uint64_t v___x_6932_; uint64_t v___x_6933_; uint64_t v___x_6934_; size_t v___x_6935_; uint8_t v___x_6936_; uint64_t v___x_6937_; uint64_t v___x_6938_; uint64_t v___x_6939_; uint64_t v___x_6940_; 
v_pos_6920_ = ((size_t)0ULL);
v___x_6921_ = lean_byte_array_uget(v_columns_6886_, v_pos_6920_);
v_a_6922_ = lean_uint8_to_uint64(v___x_6921_);
v___x_6923_ = ((size_t)1ULL);
v___x_6924_ = lean_byte_array_uget(v_columns_6886_, v___x_6923_);
v___x_6925_ = lean_uint8_to_uint64(v___x_6924_);
v___x_6926_ = 8ULL;
v___x_6927_ = lean_uint64_shift_left(v___x_6925_, v___x_6926_);
v___x_6928_ = lean_uint64_lor(v_a_6922_, v___x_6927_);
v___x_6929_ = ((size_t)2ULL);
v___x_6930_ = lean_byte_array_uget(v_columns_6886_, v___x_6929_);
v___x_6931_ = lean_uint8_to_uint64(v___x_6930_);
v___x_6932_ = 16ULL;
v___x_6933_ = lean_uint64_shift_left(v___x_6931_, v___x_6932_);
v___x_6934_ = lean_uint64_lor(v___x_6928_, v___x_6933_);
v___x_6935_ = ((size_t)3ULL);
v___x_6936_ = lean_byte_array_uget(v_columns_6886_, v___x_6935_);
lean_dec_ref(v_columns_6886_);
v___x_6937_ = lean_uint8_to_uint64(v___x_6936_);
v___x_6938_ = 24ULL;
v___x_6939_ = lean_uint64_shift_left(v___x_6937_, v___x_6938_);
v___x_6940_ = lean_uint64_lor(v___x_6934_, v___x_6939_);
v___y_6901_ = v___x_6940_;
goto v___jp_6900_;
}
}
}
else
{
lean_object* v___x_6987_; 
lean_dec(v_a_6883_);
if (v_isShared_6880_ == 0)
{
lean_ctor_set(v___x_6879_, 0, v___x_6881_);
v___x_6987_ = v___x_6879_;
goto v_reusejp_6986_;
}
else
{
lean_object* v_reuseFailAlloc_6988_; 
v_reuseFailAlloc_6988_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_6988_, 0, v___x_6881_);
lean_ctor_set(v_reuseFailAlloc_6988_, 1, v_snd_6877_);
v___x_6987_ = v_reuseFailAlloc_6988_;
goto v_reusejp_6986_;
}
v_reusejp_6986_:
{
v_a_6872_ = v___x_6987_;
goto v___jp_6871_;
}
}
}
}
v___jp_6871_:
{
size_t v___x_6873_; size_t v___x_6874_; 
v___x_6873_ = ((size_t)1ULL);
v___x_6874_ = lean_usize_add(v_i_6869_, v___x_6873_);
v_i_6869_ = v___x_6874_;
v_b_6870_ = v_a_6872_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___boxed(lean_object* v___x_6991_, lean_object* v_columns_6992_, lean_object* v_as_6993_, lean_object* v_sz_6994_, lean_object* v_i_6995_, lean_object* v_b_6996_){
_start:
{
size_t v_sz_boxed_6997_; size_t v_i_boxed_6998_; lean_object* v_res_6999_; 
v_sz_boxed_6997_ = lean_unbox_usize(v_sz_6994_);
lean_dec(v_sz_6994_);
v_i_boxed_6998_ = lean_unbox_usize(v_i_6995_);
lean_dec(v_i_6995_);
v_res_6999_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2(v___x_6991_, v_columns_6992_, v_as_6993_, v_sz_boxed_6997_, v_i_boxed_6998_, v_b_6996_);
lean_dec_ref(v_as_6993_);
lean_dec(v_columns_6992_);
lean_dec(v___x_6991_);
return v_res_6999_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3___closed__0(void){
_start:
{
lean_object* v___x_7000_; lean_object* v___x_7001_; lean_object* v___x_7002_; 
v___x_7000_ = lean_unsigned_to_nat(1u);
v___x_7001_ = lean_obj_once(&lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0, &lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0_once, _init_lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexGroebner_Elimination_0__Hex_Groebner_eliminate_spec__4___redArg___closed__0);
v___x_7002_ = lean_nat_shiftr(v___x_7001_, v___x_7000_);
return v___x_7002_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3(uint8_t v___y_7003_, lean_object* v_as_7004_, size_t v_i_7005_, size_t v_stop_7006_){
_start:
{
uint8_t v___x_7007_; 
v___x_7007_ = lean_usize_dec_eq(v_i_7005_, v_stop_7006_);
if (v___x_7007_ == 0)
{
uint8_t v___x_7008_; uint8_t v___y_7010_; lean_object* v___x_7014_; lean_object* v___x_7015_; uint8_t v___x_7016_; 
v___x_7008_ = 1;
v___x_7014_ = lean_array_uget_borrowed(v_as_7004_, v_i_7005_);
v___x_7015_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3___closed__0, &lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3___closed__0_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3___closed__0);
v___x_7016_ = lean_nat_dec_lt(v___x_7014_, v___x_7015_);
if (v___x_7016_ == 0)
{
uint8_t v___x_7017_; 
v___x_7017_ = lean_uint8_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1);
v___y_7010_ = v___x_7017_;
goto v___jp_7009_;
}
else
{
v___y_7010_ = v___y_7003_;
goto v___jp_7009_;
}
v___jp_7009_:
{
if (v___y_7010_ == 0)
{
size_t v___x_7011_; size_t v___x_7012_; 
v___x_7011_ = ((size_t)1ULL);
v___x_7012_ = lean_usize_add(v_i_7005_, v___x_7011_);
v_i_7005_ = v___x_7012_;
goto _start;
}
else
{
return v___x_7008_;
}
}
}
else
{
uint8_t v___x_7018_; 
v___x_7018_ = 0;
return v___x_7018_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3___boxed(lean_object* v___y_7019_, lean_object* v_as_7020_, lean_object* v_i_7021_, lean_object* v_stop_7022_){
_start:
{
uint8_t v___y_6296__boxed_7023_; size_t v_i_boxed_7024_; size_t v_stop_boxed_7025_; uint8_t v_res_7026_; lean_object* v_r_7027_; 
v___y_6296__boxed_7023_ = lean_unbox(v___y_7019_);
v_i_boxed_7024_ = lean_unbox_usize(v_i_7021_);
lean_dec(v_i_7021_);
v_stop_boxed_7025_ = lean_unbox_usize(v_stop_7022_);
lean_dec(v_stop_7022_);
v_res_7026_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3(v___y_6296__boxed_7023_, v_as_7020_, v_i_boxed_7024_, v_stop_boxed_7025_);
lean_dec_ref(v_as_7020_);
v_r_7027_ = lean_box(v_res_7026_);
return v_r_7027_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__0(lean_object* v___x_7028_, lean_object* v_workspace_7029_, lean_object* v___y_7030_, uint8_t v___y_7031_, lean_object* v_as_7032_, size_t v_sz_7033_, size_t v_i_7034_, lean_object* v_b_7035_){
_start:
{
uint8_t v___x_7036_; 
v___x_7036_ = lean_usize_dec_lt(v_i_7034_, v_sz_7033_);
if (v___x_7036_ == 0)
{
return v_b_7035_;
}
else
{
lean_object* v_snd_7037_; lean_object* v___x_7039_; uint8_t v_isShared_7040_; uint8_t v_isSharedCheck_7075_; 
v_snd_7037_ = lean_ctor_get(v_b_7035_, 1);
v_isSharedCheck_7075_ = !lean_is_exclusive(v_b_7035_);
if (v_isSharedCheck_7075_ == 0)
{
lean_object* v_unused_7076_; 
v_unused_7076_ = lean_ctor_get(v_b_7035_, 0);
lean_dec(v_unused_7076_);
v___x_7039_ = v_b_7035_;
v_isShared_7040_ = v_isSharedCheck_7075_;
goto v_resetjp_7038_;
}
else
{
lean_inc(v_snd_7037_);
lean_dec(v_b_7035_);
v___x_7039_ = lean_box(0);
v_isShared_7040_ = v_isSharedCheck_7075_;
goto v_resetjp_7038_;
}
v_resetjp_7038_:
{
lean_object* v_a_7041_; lean_object* v_columns_7042_; uint8_t v___x_7043_; lean_object* v___x_7050_; lean_object* v___x_7070_; lean_object* v_entries_7071_; lean_object* v___x_7072_; lean_object* v___x_7073_; uint8_t v___x_7074_; 
v_a_7041_ = lean_array_uget(v_as_7032_, v_i_7034_);
v_columns_7042_ = lean_ctor_get(v_a_7041_, 0);
v___x_7043_ = lean_nat_dec_lt(v___x_7028_, v_workspace_7029_);
v___x_7050_ = lean_box(0);
v___x_7070_ = lean_unsigned_to_nat(4u);
v_entries_7071_ = lean_unsigned_to_nat(0u);
v___x_7072_ = lean_byte_array_size(v_columns_7042_);
v___x_7073_ = lean_nat_mod(v___x_7072_, v___x_7070_);
v___x_7074_ = lean_nat_dec_eq(v___x_7073_, v_entries_7071_);
lean_dec(v___x_7073_);
if (v___x_7074_ == 0)
{
if (v___y_7031_ == 0)
{
goto v___jp_7051_;
}
else
{
lean_dec(v_a_7041_);
goto v___jp_7044_;
}
}
else
{
goto v___jp_7051_;
}
v___jp_7044_:
{
lean_object* v___x_7045_; lean_object* v___x_7046_; lean_object* v___x_7048_; 
v___x_7045_ = lean_box(v___x_7043_);
v___x_7046_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_7046_, 0, v___x_7045_);
if (v_isShared_7040_ == 0)
{
lean_ctor_set(v___x_7039_, 0, v___x_7046_);
v___x_7048_ = v___x_7039_;
goto v_reusejp_7047_;
}
else
{
lean_object* v_reuseFailAlloc_7049_; 
v_reuseFailAlloc_7049_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7049_, 0, v___x_7046_);
lean_ctor_set(v_reuseFailAlloc_7049_, 1, v_snd_7037_);
v___x_7048_ = v_reuseFailAlloc_7049_;
goto v_reusejp_7047_;
}
v_reusejp_7047_:
{
return v___x_7048_;
}
}
v___jp_7051_:
{
lean_object* v_coefficients_7052_; lean_object* v___x_7053_; lean_object* v___x_7054_; lean_object* v___x_7056_; uint8_t v_isShared_7057_; uint8_t v_isSharedCheck_7067_; 
v_coefficients_7052_ = lean_ctor_get(v_a_7041_, 1);
v___x_7053_ = lean_byte_array_size(v_coefficients_7052_);
v___x_7054_ = lp_Hex_Hex_Groebner_SparseRow_size(v_a_7041_);
v_isSharedCheck_7067_ = !lean_is_exclusive(v_a_7041_);
if (v_isSharedCheck_7067_ == 0)
{
lean_object* v_unused_7068_; lean_object* v_unused_7069_; 
v_unused_7068_ = lean_ctor_get(v_a_7041_, 1);
lean_dec(v_unused_7068_);
v_unused_7069_ = lean_ctor_get(v_a_7041_, 0);
lean_dec(v_unused_7069_);
v___x_7056_ = v_a_7041_;
v_isShared_7057_ = v_isSharedCheck_7067_;
goto v_resetjp_7055_;
}
else
{
lean_dec(v_a_7041_);
v___x_7056_ = lean_box(0);
v_isShared_7057_ = v_isSharedCheck_7067_;
goto v_resetjp_7055_;
}
v_resetjp_7055_:
{
lean_object* v___x_7058_; uint8_t v___x_7059_; 
v___x_7058_ = lean_nat_mul(v___x_7054_, v___y_7030_);
v___x_7059_ = lean_nat_dec_eq(v___x_7053_, v___x_7058_);
lean_dec(v___x_7058_);
if (v___x_7059_ == 0)
{
lean_del_object(v___x_7056_);
lean_dec(v___x_7054_);
goto v___jp_7044_;
}
else
{
lean_object* v___x_7060_; lean_object* v___x_7062_; 
lean_del_object(v___x_7039_);
v___x_7060_ = lean_nat_add(v_snd_7037_, v___x_7054_);
lean_dec(v___x_7054_);
lean_dec(v_snd_7037_);
if (v_isShared_7057_ == 0)
{
lean_ctor_set(v___x_7056_, 1, v___x_7060_);
lean_ctor_set(v___x_7056_, 0, v___x_7050_);
v___x_7062_ = v___x_7056_;
goto v_reusejp_7061_;
}
else
{
lean_object* v_reuseFailAlloc_7066_; 
v_reuseFailAlloc_7066_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7066_, 0, v___x_7050_);
lean_ctor_set(v_reuseFailAlloc_7066_, 1, v___x_7060_);
v___x_7062_ = v_reuseFailAlloc_7066_;
goto v_reusejp_7061_;
}
v_reusejp_7061_:
{
size_t v___x_7063_; size_t v___x_7064_; 
v___x_7063_ = ((size_t)1ULL);
v___x_7064_ = lean_usize_add(v_i_7034_, v___x_7063_);
v_i_7034_ = v___x_7064_;
v_b_7035_ = v___x_7062_;
goto _start;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__0___boxed(lean_object* v___x_7077_, lean_object* v_workspace_7078_, lean_object* v___y_7079_, lean_object* v___y_7080_, lean_object* v_as_7081_, lean_object* v_sz_7082_, lean_object* v_i_7083_, lean_object* v_b_7084_){
_start:
{
uint8_t v___y_6328__boxed_7085_; size_t v_sz_boxed_7086_; size_t v_i_boxed_7087_; lean_object* v_res_7088_; 
v___y_6328__boxed_7085_ = lean_unbox(v___y_7080_);
v_sz_boxed_7086_ = lean_unbox_usize(v_sz_7082_);
lean_dec(v_sz_7082_);
v_i_boxed_7087_ = lean_unbox_usize(v_i_7083_);
lean_dec(v_i_7083_);
v_res_7088_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__0(v___x_7077_, v_workspace_7078_, v___y_7079_, v___y_6328__boxed_7085_, v_as_7081_, v_sz_boxed_7086_, v_i_boxed_7087_, v_b_7084_);
lean_dec_ref(v_as_7081_);
lean_dec(v___y_7079_);
lean_dec(v_workspace_7078_);
lean_dec(v___x_7077_);
return v_res_7088_;
}
}
LEAN_EXPORT lean_object* lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1___redArg(lean_object* v___x_7089_, lean_object* v_workspace_7090_, lean_object* v___y_7091_, uint8_t v___y_7092_, lean_object* v_as_x27_7093_, lean_object* v_b_7094_){
_start:
{
if (lean_obj_tag(v_as_x27_7093_) == 0)
{
return v_b_7094_;
}
else
{
lean_object* v_head_7095_; lean_object* v_tail_7096_; lean_object* v_snd_7097_; lean_object* v___x_7099_; uint8_t v_isShared_7100_; uint8_t v_isSharedCheck_7128_; 
v_head_7095_ = lean_ctor_get(v_as_x27_7093_, 0);
v_tail_7096_ = lean_ctor_get(v_as_x27_7093_, 1);
v_snd_7097_ = lean_ctor_get(v_b_7094_, 1);
v_isSharedCheck_7128_ = !lean_is_exclusive(v_b_7094_);
if (v_isSharedCheck_7128_ == 0)
{
lean_object* v_unused_7129_; 
v_unused_7129_ = lean_ctor_get(v_b_7094_, 0);
lean_dec(v_unused_7129_);
v___x_7099_ = v_b_7094_;
v_isShared_7100_ = v_isSharedCheck_7128_;
goto v_resetjp_7098_;
}
else
{
lean_inc(v_snd_7097_);
lean_dec(v_b_7094_);
v___x_7099_ = lean_box(0);
v_isShared_7100_ = v_isSharedCheck_7128_;
goto v_resetjp_7098_;
}
v_resetjp_7098_:
{
lean_object* v___x_7101_; lean_object* v___x_7103_; 
v___x_7101_ = lean_box(0);
if (v_isShared_7100_ == 0)
{
lean_ctor_set(v___x_7099_, 0, v___x_7101_);
v___x_7103_ = v___x_7099_;
goto v_reusejp_7102_;
}
else
{
lean_object* v_reuseFailAlloc_7127_; 
v_reuseFailAlloc_7127_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7127_, 0, v___x_7101_);
lean_ctor_set(v_reuseFailAlloc_7127_, 1, v_snd_7097_);
v___x_7103_ = v_reuseFailAlloc_7127_;
goto v_reusejp_7102_;
}
v_reusejp_7102_:
{
size_t v_sz_7104_; size_t v___x_7105_; lean_object* v___x_7106_; lean_object* v_fst_7107_; 
v_sz_7104_ = lean_array_size(v_head_7095_);
v___x_7105_ = ((size_t)0ULL);
v___x_7106_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__0(v___x_7089_, v_workspace_7090_, v___y_7091_, v___y_7092_, v_head_7095_, v_sz_7104_, v___x_7105_, v___x_7103_);
v_fst_7107_ = lean_ctor_get(v___x_7106_, 0);
lean_inc(v_fst_7107_);
if (lean_obj_tag(v_fst_7107_) == 0)
{
lean_object* v_snd_7108_; lean_object* v___x_7110_; uint8_t v_isShared_7111_; uint8_t v_isSharedCheck_7116_; 
v_snd_7108_ = lean_ctor_get(v___x_7106_, 1);
v_isSharedCheck_7116_ = !lean_is_exclusive(v___x_7106_);
if (v_isSharedCheck_7116_ == 0)
{
lean_object* v_unused_7117_; 
v_unused_7117_ = lean_ctor_get(v___x_7106_, 0);
lean_dec(v_unused_7117_);
v___x_7110_ = v___x_7106_;
v_isShared_7111_ = v_isSharedCheck_7116_;
goto v_resetjp_7109_;
}
else
{
lean_inc(v_snd_7108_);
lean_dec(v___x_7106_);
v___x_7110_ = lean_box(0);
v_isShared_7111_ = v_isSharedCheck_7116_;
goto v_resetjp_7109_;
}
v_resetjp_7109_:
{
lean_object* v___x_7113_; 
if (v_isShared_7111_ == 0)
{
lean_ctor_set(v___x_7110_, 0, v___x_7101_);
v___x_7113_ = v___x_7110_;
goto v_reusejp_7112_;
}
else
{
lean_object* v_reuseFailAlloc_7115_; 
v_reuseFailAlloc_7115_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7115_, 0, v___x_7101_);
lean_ctor_set(v_reuseFailAlloc_7115_, 1, v_snd_7108_);
v___x_7113_ = v_reuseFailAlloc_7115_;
goto v_reusejp_7112_;
}
v_reusejp_7112_:
{
v_as_x27_7093_ = v_tail_7096_;
v_b_7094_ = v___x_7113_;
goto _start;
}
}
}
else
{
lean_object* v_snd_7118_; lean_object* v___x_7120_; uint8_t v_isShared_7121_; uint8_t v_isSharedCheck_7125_; 
v_snd_7118_ = lean_ctor_get(v___x_7106_, 1);
v_isSharedCheck_7125_ = !lean_is_exclusive(v___x_7106_);
if (v_isSharedCheck_7125_ == 0)
{
lean_object* v_unused_7126_; 
v_unused_7126_ = lean_ctor_get(v___x_7106_, 0);
lean_dec(v_unused_7126_);
v___x_7120_ = v___x_7106_;
v_isShared_7121_ = v_isSharedCheck_7125_;
goto v_resetjp_7119_;
}
else
{
lean_inc(v_snd_7118_);
lean_dec(v___x_7106_);
v___x_7120_ = lean_box(0);
v_isShared_7121_ = v_isSharedCheck_7125_;
goto v_resetjp_7119_;
}
v_resetjp_7119_:
{
lean_object* v___x_7123_; 
if (v_isShared_7121_ == 0)
{
v___x_7123_ = v___x_7120_;
goto v_reusejp_7122_;
}
else
{
lean_object* v_reuseFailAlloc_7124_; 
v_reuseFailAlloc_7124_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7124_, 0, v_fst_7107_);
lean_ctor_set(v_reuseFailAlloc_7124_, 1, v_snd_7118_);
v___x_7123_ = v_reuseFailAlloc_7124_;
goto v_reusejp_7122_;
}
v_reusejp_7122_:
{
return v___x_7123_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1___redArg___boxed(lean_object* v___x_7130_, lean_object* v_workspace_7131_, lean_object* v___y_7132_, lean_object* v___y_7133_, lean_object* v_as_x27_7134_, lean_object* v_b_7135_){
_start:
{
uint8_t v___y_6409__boxed_7136_; lean_object* v_res_7137_; 
v___y_6409__boxed_7136_ = lean_unbox(v___y_7133_);
v_res_7137_ = lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1___redArg(v___x_7130_, v_workspace_7131_, v___y_7132_, v___y_6409__boxed_7136_, v_as_x27_7134_, v_b_7135_);
lean_dec(v_as_x27_7134_);
lean_dec(v___y_7132_);
lean_dec(v_workspace_7131_);
lean_dec(v___x_7130_);
return v_res_7137_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_Groebner_Elimination_fits(uint64_t v_field_7138_, lean_object* v_limits_7139_, lean_object* v_columns_7140_, lean_object* v_reducers_7141_, lean_object* v_targets_7142_, lean_object* v_sugars_7143_){
_start:
{
lean_object* v___x_7144_; uint8_t v___x_7145_; 
v___x_7144_ = lean_unsigned_to_nat(2u);
v___x_7145_ = lean_uint8_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2___closed__1);
if (v___x_7145_ == 0)
{
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___x_7145_;
}
else
{
uint8_t v___x_7146_; lean_object* v___x_7147_; uint8_t v___x_7148_; 
v___x_7146_ = 0;
v___x_7147_ = lean_unsigned_to_nat(4096u);
v___x_7148_ = lean_nat_dec_lt(v___x_7147_, v_columns_7140_);
if (v___x_7148_ == 0)
{
lean_object* v___x_7149_; lean_object* v___x_7150_; uint8_t v___x_7151_; 
v___x_7149_ = lean_array_get_size(v_reducers_7141_);
v___x_7150_ = lean_unsigned_to_nat(1024u);
v___x_7151_ = lean_nat_dec_lt(v___x_7150_, v___x_7149_);
if (v___x_7151_ == 0)
{
lean_object* v___x_7152_; lean_object* v___x_7153_; uint8_t v___x_7154_; 
v___x_7152_ = lean_array_get_size(v_targets_7142_);
v___x_7153_ = lean_unsigned_to_nat(64u);
v___x_7154_ = lean_nat_dec_lt(v___x_7153_, v___x_7152_);
if (v___x_7154_ == 0)
{
lean_object* v_columns_7155_; lean_object* v_rows_7156_; lean_object* v_packedBytes_7157_; lean_object* v_work_7158_; uint8_t v___x_7159_; 
v_columns_7155_ = lean_ctor_get(v_limits_7139_, 0);
v_rows_7156_ = lean_ctor_get(v_limits_7139_, 1);
v_packedBytes_7157_ = lean_ctor_get(v_limits_7139_, 4);
v_work_7158_ = lean_ctor_get(v_limits_7139_, 5);
v___x_7159_ = lean_nat_dec_lt(v_columns_7155_, v_columns_7140_);
if (v___x_7159_ == 0)
{
lean_object* v_rows_7160_; uint8_t v___y_7162_; lean_object* v___y_7163_; uint8_t v___y_7164_; lean_object* v___y_7165_; lean_object* v___y_7215_; uint8_t v___y_7216_; uint8_t v___y_7217_; uint8_t v___y_7222_; uint8_t v___x_7229_; 
v_rows_7160_ = lean_nat_add(v___x_7149_, v___x_7152_);
v___x_7229_ = lean_nat_dec_lt(v_rows_7156_, v_rows_7160_);
if (v___x_7229_ == 0)
{
lean_object* v___x_7230_; lean_object* v___x_7231_; uint8_t v___x_7232_; 
v___x_7230_ = lean_array_get_size(v_sugars_7143_);
v___x_7231_ = lean_unsigned_to_nat(0u);
v___x_7232_ = lean_nat_dec_eq(v___x_7230_, v___x_7231_);
if (v___x_7232_ == 0)
{
uint8_t v___x_7233_; 
v___x_7233_ = lean_nat_dec_eq(v___x_7230_, v_rows_7160_);
if (v___x_7233_ == 0)
{
lean_dec(v_rows_7160_);
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___x_7146_;
}
else
{
v___y_7222_ = v___x_7146_;
goto v___jp_7221_;
}
}
else
{
v___y_7222_ = v___x_7146_;
goto v___jp_7221_;
}
}
else
{
lean_dec(v_rows_7160_);
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___x_7146_;
}
v___jp_7161_:
{
lean_object* v___x_7166_; lean_object* v___x_7167_; lean_object* v_workspace_7168_; lean_object* v___x_7169_; lean_object* v___x_7170_; uint8_t v___x_7171_; 
v___x_7166_ = lean_unsigned_to_nat(4u);
v___x_7167_ = lean_nat_add(v___y_7165_, v___x_7166_);
v_workspace_7168_ = lean_nat_mul(v_columns_7140_, v___x_7167_);
lean_dec(v___x_7167_);
v___x_7169_ = lean_nat_mul(v___x_7144_, v_rows_7160_);
v___x_7170_ = lean_nat_add(v___x_7169_, v_workspace_7168_);
lean_dec(v___x_7169_);
v___x_7171_ = lean_nat_dec_lt(v_work_7158_, v___x_7170_);
lean_dec(v___x_7170_);
if (v___x_7171_ == 0)
{
uint8_t v___x_7172_; 
v___x_7172_ = lean_nat_dec_lt(v_packedBytes_7157_, v_workspace_7168_);
if (v___x_7172_ == 0)
{
lean_object* v___x_7173_; lean_object* v___x_7174_; lean_object* v___x_7175_; lean_object* v___x_7176_; lean_object* v___x_7177_; lean_object* v___x_7178_; lean_object* v_fst_7179_; 
v___x_7173_ = lean_box(0);
v___x_7174_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_7174_, 0, v_targets_7142_);
lean_ctor_set(v___x_7174_, 1, v___x_7173_);
lean_inc_ref(v_reducers_7141_);
v___x_7175_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_7175_, 0, v_reducers_7141_);
lean_ctor_set(v___x_7175_, 1, v___x_7174_);
v___x_7176_ = lean_box(0);
v___x_7177_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_7177_, 0, v___x_7176_);
lean_ctor_set(v___x_7177_, 1, v___y_7163_);
v___x_7178_ = lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1___redArg(v_packedBytes_7157_, v_workspace_7168_, v___y_7165_, v___y_7162_, v___x_7175_, v___x_7177_);
lean_dec_ref_known(v___x_7175_, 2);
v_fst_7179_ = lean_ctor_get(v___x_7178_, 0);
lean_inc(v_fst_7179_);
if (lean_obj_tag(v_fst_7179_) == 0)
{
lean_object* v_snd_7180_; lean_object* v___x_7182_; uint8_t v_isShared_7183_; uint8_t v_isSharedCheck_7210_; 
v_snd_7180_ = lean_ctor_get(v___x_7178_, 1);
v_isSharedCheck_7210_ = !lean_is_exclusive(v___x_7178_);
if (v_isSharedCheck_7210_ == 0)
{
lean_object* v_unused_7211_; 
v_unused_7211_ = lean_ctor_get(v___x_7178_, 0);
lean_dec(v_unused_7211_);
v___x_7182_ = v___x_7178_;
v_isShared_7183_ = v_isSharedCheck_7210_;
goto v_resetjp_7181_;
}
else
{
lean_inc(v_snd_7180_);
lean_dec(v___x_7178_);
v___x_7182_ = lean_box(0);
v_isShared_7183_ = v_isSharedCheck_7210_;
goto v_resetjp_7181_;
}
v_resetjp_7181_:
{
lean_object* v___x_7184_; lean_object* v___x_7185_; lean_object* v___x_7186_; lean_object* v___x_7187_; lean_object* v___x_7188_; lean_object* v___x_7189_; lean_object* v___x_7190_; lean_object* v___x_7191_; lean_object* v___x_7192_; lean_object* v___x_7193_; lean_object* v___x_7194_; lean_object* v___x_7195_; lean_object* v___x_7196_; lean_object* v___x_7197_; uint8_t v___x_7198_; 
v___x_7184_ = lean_unsigned_to_nat(65u);
v___x_7185_ = lean_nat_mul(v_rows_7160_, v___x_7184_);
lean_dec(v_rows_7160_);
v___x_7186_ = lean_nat_mul(v___x_7144_, v_snd_7180_);
v___x_7187_ = lean_nat_add(v___x_7185_, v___x_7186_);
lean_dec(v___x_7186_);
lean_dec(v___x_7185_);
v___x_7188_ = lean_nat_add(v___x_7187_, v_workspace_7168_);
lean_dec(v_workspace_7168_);
lean_dec(v___x_7187_);
v___x_7189_ = lean_unsigned_to_nat(3u);
v___x_7190_ = lean_nat_add(v___x_7152_, v___x_7189_);
v___x_7191_ = lean_nat_mul(v___x_7190_, v_columns_7140_);
lean_dec(v___x_7190_);
v___x_7192_ = lean_nat_add(v_snd_7180_, v___x_7191_);
lean_dec(v___x_7191_);
lean_dec(v_snd_7180_);
v___x_7193_ = lean_nat_add(v___x_7192_, v___x_7153_);
lean_dec(v___x_7192_);
v___x_7194_ = lean_nat_mul(v___x_7152_, v___x_7193_);
lean_dec(v___x_7193_);
v___x_7195_ = lean_nat_add(v___x_7188_, v___x_7194_);
lean_dec(v___x_7194_);
lean_dec(v___x_7188_);
v___x_7196_ = lean_nat_add(v___x_7195_, v_columns_7140_);
lean_dec(v___x_7195_);
v___x_7197_ = lean_unsigned_to_nat(1048576u);
v___x_7198_ = lean_nat_dec_lt(v___x_7197_, v___x_7196_);
if (v___x_7198_ == 0)
{
lean_object* v___x_7199_; lean_object* v___x_7200_; lean_object* v___x_7202_; 
v___x_7199_ = lean_box(v___x_7198_);
lean_inc(v_columns_7140_);
v___x_7200_ = lean_mk_array(v_columns_7140_, v___x_7199_);
if (v_isShared_7183_ == 0)
{
lean_ctor_set(v___x_7182_, 1, v___x_7200_);
lean_ctor_set(v___x_7182_, 0, v___x_7176_);
v___x_7202_ = v___x_7182_;
goto v_reusejp_7201_;
}
else
{
lean_object* v_reuseFailAlloc_7209_; 
v_reuseFailAlloc_7209_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7209_, 0, v___x_7176_);
lean_ctor_set(v_reuseFailAlloc_7209_, 1, v___x_7200_);
v___x_7202_ = v_reuseFailAlloc_7209_;
goto v_reusejp_7201_;
}
v_reusejp_7201_:
{
size_t v_sz_7203_; size_t v___x_7204_; lean_object* v___x_7205_; lean_object* v_fst_7206_; 
v_sz_7203_ = lean_array_size(v_reducers_7141_);
v___x_7204_ = ((size_t)0ULL);
v___x_7205_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_Groebner_Elimination_fits_spec__2(v___x_7196_, v_columns_7140_, v_reducers_7141_, v_sz_7203_, v___x_7204_, v___x_7202_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
lean_dec(v___x_7196_);
v_fst_7206_ = lean_ctor_get(v___x_7205_, 0);
lean_inc(v_fst_7206_);
lean_dec_ref(v___x_7205_);
if (lean_obj_tag(v_fst_7206_) == 0)
{
return v___x_7145_;
}
else
{
lean_object* v_val_7207_; uint8_t v___x_7208_; 
v_val_7207_ = lean_ctor_get(v_fst_7206_, 0);
lean_inc(v_val_7207_);
lean_dec_ref_known(v_fst_7206_, 1);
v___x_7208_ = lean_unbox(v_val_7207_);
lean_dec(v_val_7207_);
return v___x_7208_;
}
}
}
else
{
lean_dec(v___x_7196_);
lean_del_object(v___x_7182_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___x_7172_;
}
}
}
else
{
lean_object* v_val_7212_; uint8_t v___x_7213_; 
lean_dec_ref(v___x_7178_);
lean_dec(v_workspace_7168_);
lean_dec(v_rows_7160_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
v_val_7212_ = lean_ctor_get(v_fst_7179_, 0);
lean_inc(v_val_7212_);
lean_dec_ref_known(v_fst_7179_, 1);
v___x_7213_ = lean_unbox(v_val_7212_);
lean_dec(v_val_7212_);
return v___x_7213_;
}
}
else
{
lean_dec(v_workspace_7168_);
lean_dec(v___y_7163_);
lean_dec(v_rows_7160_);
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___y_7164_;
}
}
else
{
lean_dec(v_workspace_7168_);
lean_dec(v___y_7163_);
lean_dec(v_rows_7160_);
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___y_7164_;
}
}
v___jp_7214_:
{
uint8_t v___x_7218_; 
v___x_7218_ = lp_Hex_Hex_Groebner_PrimeField_width(v_field_7138_);
switch(v___x_7218_)
{
case 0:
{
lean_object* v___x_7219_; 
v___x_7219_ = lean_unsigned_to_nat(1u);
v___y_7162_ = v___y_7217_;
v___y_7163_ = v___y_7215_;
v___y_7164_ = v___y_7216_;
v___y_7165_ = v___x_7219_;
goto v___jp_7161_;
}
case 1:
{
v___y_7162_ = v___y_7217_;
v___y_7163_ = v___y_7215_;
v___y_7164_ = v___y_7216_;
v___y_7165_ = v___x_7144_;
goto v___jp_7161_;
}
default: 
{
lean_object* v___x_7220_; 
v___x_7220_ = lean_unsigned_to_nat(4u);
v___y_7162_ = v___y_7217_;
v___y_7163_ = v___y_7215_;
v___y_7164_ = v___y_7216_;
v___y_7165_ = v___x_7220_;
goto v___jp_7161_;
}
}
}
v___jp_7221_:
{
lean_object* v_entries_7223_; lean_object* v___x_7224_; uint8_t v___x_7225_; 
v_entries_7223_ = lean_unsigned_to_nat(0u);
v___x_7224_ = lean_array_get_size(v_sugars_7143_);
v___x_7225_ = lean_nat_dec_lt(v_entries_7223_, v___x_7224_);
if (v___x_7225_ == 0)
{
v___y_7215_ = v_entries_7223_;
v___y_7216_ = v___y_7222_;
v___y_7217_ = v___x_7145_;
goto v___jp_7214_;
}
else
{
if (v___x_7225_ == 0)
{
v___y_7215_ = v_entries_7223_;
v___y_7216_ = v___y_7222_;
v___y_7217_ = v___x_7145_;
goto v___jp_7214_;
}
else
{
size_t v___x_7226_; size_t v___x_7227_; uint8_t v___x_7228_; 
v___x_7226_ = ((size_t)0ULL);
v___x_7227_ = lean_usize_of_nat(v___x_7224_);
v___x_7228_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_anyMUnsafe_any___at___00Hex_Groebner_Elimination_fits_spec__3(v___y_7222_, v_sugars_7143_, v___x_7226_, v___x_7227_);
if (v___x_7228_ == 0)
{
v___y_7215_ = v_entries_7223_;
v___y_7216_ = v___y_7222_;
v___y_7217_ = v___x_7225_;
goto v___jp_7214_;
}
else
{
lean_dec(v_rows_7160_);
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___y_7222_;
}
}
}
}
}
else
{
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___x_7146_;
}
}
else
{
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___x_7146_;
}
}
else
{
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___x_7146_;
}
}
else
{
lean_dec_ref(v_targets_7142_);
lean_dec_ref(v_reducers_7141_);
lean_dec(v_columns_7140_);
return v___x_7146_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_fits___boxed(lean_object* v_field_7234_, lean_object* v_limits_7235_, lean_object* v_columns_7236_, lean_object* v_reducers_7237_, lean_object* v_targets_7238_, lean_object* v_sugars_7239_){
_start:
{
uint64_t v_field_boxed_7240_; uint8_t v_res_7241_; lean_object* v_r_7242_; 
v_field_boxed_7240_ = lean_unbox_uint64(v_field_7234_);
lean_dec_ref(v_field_7234_);
v_res_7241_ = lp_Hex_Hex_Groebner_Elimination_fits(v_field_boxed_7240_, v_limits_7235_, v_columns_7236_, v_reducers_7237_, v_targets_7238_, v_sugars_7239_);
lean_dec_ref(v_sugars_7239_);
lean_dec_ref(v_limits_7235_);
v_r_7242_ = lean_box(v_res_7241_);
return v_r_7242_;
}
}
LEAN_EXPORT lean_object* lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1(lean_object* v___x_7243_, lean_object* v_workspace_7244_, lean_object* v___y_7245_, uint8_t v___y_7246_, lean_object* v_as_7247_, lean_object* v_as_x27_7248_, lean_object* v_b_7249_, lean_object* v_a_7250_){
_start:
{
lean_object* v___x_7251_; 
v___x_7251_ = lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1___redArg(v___x_7243_, v_workspace_7244_, v___y_7245_, v___y_7246_, v_as_x27_7248_, v_b_7249_);
return v___x_7251_;
}
}
LEAN_EXPORT lean_object* lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1___boxed(lean_object* v___x_7252_, lean_object* v_workspace_7253_, lean_object* v___y_7254_, lean_object* v___y_7255_, lean_object* v_as_7256_, lean_object* v_as_x27_7257_, lean_object* v_b_7258_, lean_object* v_a_7259_){
_start:
{
uint8_t v___y_6647__boxed_7260_; lean_object* v_res_7261_; 
v___y_6647__boxed_7260_ = lean_unbox(v___y_7255_);
v_res_7261_ = lp_Hex_List_forIn_x27_loop___at___00Hex_Groebner_Elimination_fits_spec__1(v___x_7252_, v_workspace_7253_, v___y_7254_, v___y_6647__boxed_7260_, v_as_7256_, v_as_x27_7257_, v_b_7258_, v_a_7259_);
lean_dec(v_as_x27_7257_);
lean_dec(v_as_7256_);
lean_dec(v___y_7254_);
lean_dec(v_workspace_7253_);
lean_dec(v___x_7252_);
return v_res_7261_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_attemptPortable(uint64_t v_field_7262_, lean_object* v_limits_7263_, lean_object* v_columns_7264_, lean_object* v_reducers_7265_, lean_object* v_targets_7266_, lean_object* v_sugars_7267_, uint8_t v_independent_7268_){
_start:
{
uint8_t v___x_7269_; 
lean_inc_ref(v_targets_7266_);
lean_inc_ref(v_reducers_7265_);
lean_inc(v_columns_7264_);
v___x_7269_ = lp_Hex_Hex_Groebner_Elimination_fits(v_field_7262_, v_limits_7263_, v_columns_7264_, v_reducers_7265_, v_targets_7266_, v_sugars_7267_);
if (v___x_7269_ == 0)
{
lean_object* v___x_7270_; 
lean_dec_ref(v_targets_7266_);
lean_dec_ref(v_reducers_7265_);
lean_dec(v_columns_7264_);
v___x_7270_ = lean_box(0);
return v___x_7270_;
}
else
{
lean_object* v_result_7271_; lean_object* v_result_7272_; 
v_result_7271_ = lp_Hex_Hex_Groebner_Elimination_reference(v_field_7262_, v_limits_7263_, v_columns_7264_, v_reducers_7265_, v_targets_7266_, v_sugars_7267_, v_independent_7268_);
lean_dec_ref(v_targets_7266_);
lean_dec_ref(v_reducers_7265_);
v_result_7272_ = lean_ctor_get(v_result_7271_, 0);
lean_inc_ref(v_result_7272_);
if (lean_obj_tag(v_result_7272_) == 0)
{
lean_object* v___x_7273_; 
lean_dec_ref_known(v_result_7272_, 1);
lean_dec_ref(v_result_7271_);
v___x_7273_ = lean_box(0);
return v___x_7273_;
}
else
{
lean_object* v___x_7275_; uint8_t v_isShared_7276_; uint8_t v_isSharedCheck_7285_; 
v_isSharedCheck_7285_ = !lean_is_exclusive(v_result_7272_);
if (v_isSharedCheck_7285_ == 0)
{
lean_object* v_unused_7286_; 
v_unused_7286_ = lean_ctor_get(v_result_7272_, 0);
lean_dec(v_unused_7286_);
v___x_7275_ = v_result_7272_;
v_isShared_7276_ = v_isSharedCheck_7285_;
goto v_resetjp_7274_;
}
else
{
lean_dec(v_result_7272_);
v___x_7275_ = lean_box(0);
v_isShared_7276_ = v_isSharedCheck_7285_;
goto v_resetjp_7274_;
}
v_resetjp_7274_:
{
lean_object* v_stats_7277_; lean_object* v_work_7278_; lean_object* v___x_7279_; uint8_t v___x_7280_; 
v_stats_7277_ = lean_ctor_get(v_result_7271_, 1);
lean_inc_ref(v_stats_7277_);
v_work_7278_ = lean_ctor_get(v_stats_7277_, 0);
lean_inc(v_work_7278_);
lean_dec_ref(v_stats_7277_);
v___x_7279_ = lean_unsigned_to_nat(1048576u);
v___x_7280_ = lean_nat_dec_le(v_work_7278_, v___x_7279_);
lean_dec(v_work_7278_);
if (v___x_7280_ == 0)
{
lean_object* v___x_7281_; 
lean_del_object(v___x_7275_);
lean_dec_ref(v_result_7271_);
v___x_7281_ = lean_box(0);
return v___x_7281_;
}
else
{
lean_object* v___x_7283_; 
if (v_isShared_7276_ == 0)
{
lean_ctor_set(v___x_7275_, 0, v_result_7271_);
v___x_7283_ = v___x_7275_;
goto v_reusejp_7282_;
}
else
{
lean_object* v_reuseFailAlloc_7284_; 
v_reuseFailAlloc_7284_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_7284_, 0, v_result_7271_);
v___x_7283_ = v_reuseFailAlloc_7284_;
goto v_reusejp_7282_;
}
v_reusejp_7282_:
{
return v___x_7283_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_attemptPortable___boxed(lean_object* v_field_7287_, lean_object* v_limits_7288_, lean_object* v_columns_7289_, lean_object* v_reducers_7290_, lean_object* v_targets_7291_, lean_object* v_sugars_7292_, lean_object* v_independent_7293_){
_start:
{
uint64_t v_field_boxed_7294_; uint8_t v_independent_boxed_7295_; lean_object* v_res_7296_; 
v_field_boxed_7294_ = lean_unbox_uint64(v_field_7287_);
lean_dec_ref(v_field_7287_);
v_independent_boxed_7295_ = lean_unbox(v_independent_7293_);
v_res_7296_ = lp_Hex_Hex_Groebner_Elimination_attemptPortable(v_field_boxed_7294_, v_limits_7288_, v_columns_7289_, v_reducers_7290_, v_targets_7291_, v_sugars_7292_, v_independent_boxed_7295_);
lean_dec_ref(v_sugars_7292_);
lean_dec_ref(v_limits_7288_);
return v_res_7296_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_attempt___boxed(lean_object* v_field_7304_, lean_object* v_limits_7305_, lean_object* v_columns_7306_, lean_object* v_reducers_7307_, lean_object* v_targets_7308_, lean_object* v_sugars_7309_, lean_object* v_independent_7310_){
_start:
{
uint64_t v_field_boxed_7311_; uint8_t v_independent_boxed_7312_; lean_object* v_res_7313_; 
v_field_boxed_7311_ = lean_unbox_uint64(v_field_7304_);
lean_dec_ref(v_field_7304_);
v_independent_boxed_7312_ = lean_unbox(v_independent_7310_);
v_res_7313_ = lean_hex_groebner_eliminate_matrix(v_field_boxed_7311_, v_limits_7305_, v_columns_7306_, v_reducers_7307_, v_targets_7308_, v_sugars_7309_, v_independent_boxed_7312_);
lean_dec_ref(v_sugars_7309_);
lean_dec_ref(v_targets_7308_);
lean_dec_ref(v_reducers_7307_);
lean_dec(v_columns_7306_);
lean_dec_ref(v_limits_7305_);
return v_res_7313_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_run(uint64_t v_field_7314_, lean_object* v_limits_7315_, lean_object* v_columns_7316_, lean_object* v_reducers_7317_, lean_object* v_targets_7318_, uint8_t v_provenance_7319_, lean_object* v_sugars_7320_, uint8_t v_native_7321_, uint8_t v_independent_7322_){
_start:
{
if (v_native_7321_ == 0)
{
goto v___jp_7323_;
}
else
{
if (v_provenance_7319_ == 0)
{
lean_object* v___x_7335_; 
v___x_7335_ = lean_hex_groebner_eliminate_matrix(v_field_7314_, v_limits_7315_, v_columns_7316_, v_reducers_7317_, v_targets_7318_, v_sugars_7320_, v_independent_7322_);
if (lean_obj_tag(v___x_7335_) == 0)
{
lean_object* v___x_7336_; 
v___x_7336_ = lp_Hex_Hex_Groebner_Elimination_reference(v_field_7314_, v_limits_7315_, v_columns_7316_, v_reducers_7317_, v_targets_7318_, v_sugars_7320_, v_independent_7322_);
return v___x_7336_;
}
else
{
lean_object* v_val_7337_; 
lean_dec(v_columns_7316_);
v_val_7337_ = lean_ctor_get(v___x_7335_, 0);
lean_inc(v_val_7337_);
lean_dec_ref_known(v___x_7335_, 1);
return v_val_7337_;
}
}
else
{
goto v___jp_7323_;
}
}
v___jp_7323_:
{
lean_object* v___x_7324_; lean_object* v___x_7325_; lean_object* v_fst_7326_; lean_object* v_snd_7327_; lean_object* v___x_7329_; uint8_t v_isShared_7330_; uint8_t v_isSharedCheck_7334_; 
v___x_7324_ = ((lean_object*)(lp_Hex_Hex_Groebner_Elimination_reference___closed__0));
v___x_7325_ = lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate(v_field_7314_, v_limits_7315_, v_columns_7316_, v_reducers_7317_, v_targets_7318_, v_provenance_7319_, v_sugars_7320_, v_native_7321_, v_independent_7322_, v___x_7324_);
v_fst_7326_ = lean_ctor_get(v___x_7325_, 0);
v_snd_7327_ = lean_ctor_get(v___x_7325_, 1);
v_isSharedCheck_7334_ = !lean_is_exclusive(v___x_7325_);
if (v_isSharedCheck_7334_ == 0)
{
v___x_7329_ = v___x_7325_;
v_isShared_7330_ = v_isSharedCheck_7334_;
goto v_resetjp_7328_;
}
else
{
lean_inc(v_snd_7327_);
lean_inc(v_fst_7326_);
lean_dec(v___x_7325_);
v___x_7329_ = lean_box(0);
v_isShared_7330_ = v_isSharedCheck_7334_;
goto v_resetjp_7328_;
}
v_resetjp_7328_:
{
lean_object* v___x_7332_; 
if (v_isShared_7330_ == 0)
{
v___x_7332_ = v___x_7329_;
goto v_reusejp_7331_;
}
else
{
lean_object* v_reuseFailAlloc_7333_; 
v_reuseFailAlloc_7333_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7333_, 0, v_fst_7326_);
lean_ctor_set(v_reuseFailAlloc_7333_, 1, v_snd_7327_);
v___x_7332_ = v_reuseFailAlloc_7333_;
goto v_reusejp_7331_;
}
v_reusejp_7331_:
{
return v___x_7332_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_Elimination_run___boxed(lean_object* v_field_7338_, lean_object* v_limits_7339_, lean_object* v_columns_7340_, lean_object* v_reducers_7341_, lean_object* v_targets_7342_, lean_object* v_provenance_7343_, lean_object* v_sugars_7344_, lean_object* v_native_7345_, lean_object* v_independent_7346_){
_start:
{
uint64_t v_field_boxed_7347_; uint8_t v_provenance_boxed_7348_; uint8_t v_native_boxed_7349_; uint8_t v_independent_boxed_7350_; lean_object* v_res_7351_; 
v_field_boxed_7347_ = lean_unbox_uint64(v_field_7338_);
lean_dec_ref(v_field_7338_);
v_provenance_boxed_7348_ = lean_unbox(v_provenance_7343_);
v_native_boxed_7349_ = lean_unbox(v_native_7345_);
v_independent_boxed_7350_ = lean_unbox(v_independent_7346_);
v_res_7351_ = lp_Hex_Hex_Groebner_Elimination_run(v_field_boxed_7347_, v_limits_7339_, v_columns_7340_, v_reducers_7341_, v_targets_7342_, v_provenance_boxed_7348_, v_sugars_7344_, v_native_boxed_7349_, v_independent_boxed_7350_);
lean_dec_ref(v_sugars_7344_);
lean_dec_ref(v_targets_7342_);
lean_dec_ref(v_reducers_7341_);
lean_dec_ref(v_limits_7339_);
return v_res_7351_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_eliminateWith(uint64_t v_field_7352_, lean_object* v_limits_7353_, lean_object* v_columns_7354_, lean_object* v_reducers_7355_, lean_object* v_targets_7356_, uint8_t v_provenance_7357_, lean_object* v_sugars_7358_, uint8_t v_native_7359_){
_start:
{
uint8_t v___x_7360_; lean_object* v_output_7361_; lean_object* v___y_7363_; lean_object* v_result_7373_; 
v___x_7360_ = 0;
v_output_7361_ = lp_Hex_Hex_Groebner_Elimination_run(v_field_7352_, v_limits_7353_, v_columns_7354_, v_reducers_7355_, v_targets_7356_, v_provenance_7357_, v_sugars_7358_, v_native_7359_, v___x_7360_);
v_result_7373_ = lean_ctor_get(v_output_7361_, 0);
lean_inc_ref(v_result_7373_);
if (lean_obj_tag(v_result_7373_) == 0)
{
lean_object* v_a_7374_; lean_object* v___x_7376_; uint8_t v_isShared_7377_; uint8_t v_isSharedCheck_7381_; 
v_a_7374_ = lean_ctor_get(v_result_7373_, 0);
v_isSharedCheck_7381_ = !lean_is_exclusive(v_result_7373_);
if (v_isSharedCheck_7381_ == 0)
{
v___x_7376_ = v_result_7373_;
v_isShared_7377_ = v_isSharedCheck_7381_;
goto v_resetjp_7375_;
}
else
{
lean_inc(v_a_7374_);
lean_dec(v_result_7373_);
v___x_7376_ = lean_box(0);
v_isShared_7377_ = v_isSharedCheck_7381_;
goto v_resetjp_7375_;
}
v_resetjp_7375_:
{
lean_object* v___x_7379_; 
if (v_isShared_7377_ == 0)
{
v___x_7379_ = v___x_7376_;
goto v_reusejp_7378_;
}
else
{
lean_object* v_reuseFailAlloc_7380_; 
v_reuseFailAlloc_7380_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_7380_, 0, v_a_7374_);
v___x_7379_ = v_reuseFailAlloc_7380_;
goto v_reusejp_7378_;
}
v_reusejp_7378_:
{
v___y_7363_ = v___x_7379_;
goto v___jp_7362_;
}
}
}
else
{
lean_object* v_a_7382_; lean_object* v___x_7384_; uint8_t v_isShared_7385_; uint8_t v_isSharedCheck_7390_; 
v_a_7382_ = lean_ctor_get(v_result_7373_, 0);
v_isSharedCheck_7390_ = !lean_is_exclusive(v_result_7373_);
if (v_isSharedCheck_7390_ == 0)
{
v___x_7384_ = v_result_7373_;
v_isShared_7385_ = v_isSharedCheck_7390_;
goto v_resetjp_7383_;
}
else
{
lean_inc(v_a_7382_);
lean_dec(v_result_7373_);
v___x_7384_ = lean_box(0);
v_isShared_7385_ = v_isSharedCheck_7390_;
goto v_resetjp_7383_;
}
v_resetjp_7383_:
{
lean_object* v_fst_7386_; lean_object* v___x_7388_; 
v_fst_7386_ = lean_ctor_get(v_a_7382_, 0);
lean_inc(v_fst_7386_);
lean_dec(v_a_7382_);
if (v_isShared_7385_ == 0)
{
lean_ctor_set(v___x_7384_, 0, v_fst_7386_);
v___x_7388_ = v___x_7384_;
goto v_reusejp_7387_;
}
else
{
lean_object* v_reuseFailAlloc_7389_; 
v_reuseFailAlloc_7389_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_7389_, 0, v_fst_7386_);
v___x_7388_ = v_reuseFailAlloc_7389_;
goto v_reusejp_7387_;
}
v_reusejp_7387_:
{
v___y_7363_ = v___x_7388_;
goto v___jp_7362_;
}
}
}
v___jp_7362_:
{
lean_object* v_stats_7364_; lean_object* v___x_7366_; uint8_t v_isShared_7367_; uint8_t v_isSharedCheck_7371_; 
v_stats_7364_ = lean_ctor_get(v_output_7361_, 1);
v_isSharedCheck_7371_ = !lean_is_exclusive(v_output_7361_);
if (v_isSharedCheck_7371_ == 0)
{
lean_object* v_unused_7372_; 
v_unused_7372_ = lean_ctor_get(v_output_7361_, 0);
lean_dec(v_unused_7372_);
v___x_7366_ = v_output_7361_;
v_isShared_7367_ = v_isSharedCheck_7371_;
goto v_resetjp_7365_;
}
else
{
lean_inc(v_stats_7364_);
lean_dec(v_output_7361_);
v___x_7366_ = lean_box(0);
v_isShared_7367_ = v_isSharedCheck_7371_;
goto v_resetjp_7365_;
}
v_resetjp_7365_:
{
lean_object* v___x_7369_; 
if (v_isShared_7367_ == 0)
{
lean_ctor_set(v___x_7366_, 0, v___y_7363_);
v___x_7369_ = v___x_7366_;
goto v_reusejp_7368_;
}
else
{
lean_object* v_reuseFailAlloc_7370_; 
v_reuseFailAlloc_7370_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7370_, 0, v___y_7363_);
lean_ctor_set(v_reuseFailAlloc_7370_, 1, v_stats_7364_);
v___x_7369_ = v_reuseFailAlloc_7370_;
goto v_reusejp_7368_;
}
v_reusejp_7368_:
{
return v___x_7369_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_eliminateWith___boxed(lean_object* v_field_7391_, lean_object* v_limits_7392_, lean_object* v_columns_7393_, lean_object* v_reducers_7394_, lean_object* v_targets_7395_, lean_object* v_provenance_7396_, lean_object* v_sugars_7397_, lean_object* v_native_7398_){
_start:
{
uint64_t v_field_boxed_7399_; uint8_t v_provenance_boxed_7400_; uint8_t v_native_boxed_7401_; lean_object* v_res_7402_; 
v_field_boxed_7399_ = lean_unbox_uint64(v_field_7391_);
lean_dec_ref(v_field_7391_);
v_provenance_boxed_7400_ = lean_unbox(v_provenance_7396_);
v_native_boxed_7401_ = lean_unbox(v_native_7398_);
v_res_7402_ = lp_Hex_Hex_Groebner_eliminateWith(v_field_boxed_7399_, v_limits_7392_, v_columns_7393_, v_reducers_7394_, v_targets_7395_, v_provenance_boxed_7400_, v_sugars_7397_, v_native_boxed_7401_);
lean_dec_ref(v_sugars_7397_);
lean_dec_ref(v_targets_7395_);
lean_dec_ref(v_reducers_7394_);
lean_dec_ref(v_limits_7392_);
return v_res_7402_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_reduceRowsWith(uint64_t v_field_7403_, lean_object* v_limits_7404_, lean_object* v_columns_7405_, lean_object* v_reducers_7406_, lean_object* v_targets_7407_, uint8_t v_provenance_7408_, lean_object* v_sugars_7409_, uint8_t v_native_7410_){
_start:
{
uint8_t v___x_7411_; lean_object* v_output_7412_; lean_object* v___y_7414_; lean_object* v_result_7424_; 
v___x_7411_ = 1;
v_output_7412_ = lp_Hex_Hex_Groebner_Elimination_run(v_field_7403_, v_limits_7404_, v_columns_7405_, v_reducers_7406_, v_targets_7407_, v_provenance_7408_, v_sugars_7409_, v_native_7410_, v___x_7411_);
v_result_7424_ = lean_ctor_get(v_output_7412_, 0);
lean_inc_ref(v_result_7424_);
if (lean_obj_tag(v_result_7424_) == 0)
{
lean_object* v_a_7425_; lean_object* v___x_7427_; uint8_t v_isShared_7428_; uint8_t v_isSharedCheck_7432_; 
v_a_7425_ = lean_ctor_get(v_result_7424_, 0);
v_isSharedCheck_7432_ = !lean_is_exclusive(v_result_7424_);
if (v_isSharedCheck_7432_ == 0)
{
v___x_7427_ = v_result_7424_;
v_isShared_7428_ = v_isSharedCheck_7432_;
goto v_resetjp_7426_;
}
else
{
lean_inc(v_a_7425_);
lean_dec(v_result_7424_);
v___x_7427_ = lean_box(0);
v_isShared_7428_ = v_isSharedCheck_7432_;
goto v_resetjp_7426_;
}
v_resetjp_7426_:
{
lean_object* v___x_7430_; 
if (v_isShared_7428_ == 0)
{
v___x_7430_ = v___x_7427_;
goto v_reusejp_7429_;
}
else
{
lean_object* v_reuseFailAlloc_7431_; 
v_reuseFailAlloc_7431_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_7431_, 0, v_a_7425_);
v___x_7430_ = v_reuseFailAlloc_7431_;
goto v_reusejp_7429_;
}
v_reusejp_7429_:
{
v___y_7414_ = v___x_7430_;
goto v___jp_7413_;
}
}
}
else
{
lean_object* v_a_7433_; lean_object* v___x_7435_; uint8_t v_isShared_7436_; uint8_t v_isSharedCheck_7450_; 
v_a_7433_ = lean_ctor_get(v_result_7424_, 0);
v_isSharedCheck_7450_ = !lean_is_exclusive(v_result_7424_);
if (v_isSharedCheck_7450_ == 0)
{
v___x_7435_ = v_result_7424_;
v_isShared_7436_ = v_isSharedCheck_7450_;
goto v_resetjp_7434_;
}
else
{
lean_inc(v_a_7433_);
lean_dec(v_result_7424_);
v___x_7435_ = lean_box(0);
v_isShared_7436_ = v_isSharedCheck_7450_;
goto v_resetjp_7434_;
}
v_resetjp_7434_:
{
lean_object* v_fst_7437_; lean_object* v_snd_7438_; lean_object* v___x_7440_; uint8_t v_isShared_7441_; uint8_t v_isSharedCheck_7449_; 
v_fst_7437_ = lean_ctor_get(v_a_7433_, 0);
v_snd_7438_ = lean_ctor_get(v_a_7433_, 1);
v_isSharedCheck_7449_ = !lean_is_exclusive(v_a_7433_);
if (v_isSharedCheck_7449_ == 0)
{
v___x_7440_ = v_a_7433_;
v_isShared_7441_ = v_isSharedCheck_7449_;
goto v_resetjp_7439_;
}
else
{
lean_inc(v_snd_7438_);
lean_inc(v_fst_7437_);
lean_dec(v_a_7433_);
v___x_7440_ = lean_box(0);
v_isShared_7441_ = v_isSharedCheck_7449_;
goto v_resetjp_7439_;
}
v_resetjp_7439_:
{
lean_object* v_trace_7442_; lean_object* v___x_7444_; 
v_trace_7442_ = lean_ctor_get(v_fst_7437_, 2);
lean_inc_ref(v_trace_7442_);
lean_dec(v_fst_7437_);
if (v_isShared_7441_ == 0)
{
lean_ctor_set(v___x_7440_, 1, v_trace_7442_);
lean_ctor_set(v___x_7440_, 0, v_snd_7438_);
v___x_7444_ = v___x_7440_;
goto v_reusejp_7443_;
}
else
{
lean_object* v_reuseFailAlloc_7448_; 
v_reuseFailAlloc_7448_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7448_, 0, v_snd_7438_);
lean_ctor_set(v_reuseFailAlloc_7448_, 1, v_trace_7442_);
v___x_7444_ = v_reuseFailAlloc_7448_;
goto v_reusejp_7443_;
}
v_reusejp_7443_:
{
lean_object* v___x_7446_; 
if (v_isShared_7436_ == 0)
{
lean_ctor_set(v___x_7435_, 0, v___x_7444_);
v___x_7446_ = v___x_7435_;
goto v_reusejp_7445_;
}
else
{
lean_object* v_reuseFailAlloc_7447_; 
v_reuseFailAlloc_7447_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_7447_, 0, v___x_7444_);
v___x_7446_ = v_reuseFailAlloc_7447_;
goto v_reusejp_7445_;
}
v_reusejp_7445_:
{
v___y_7414_ = v___x_7446_;
goto v___jp_7413_;
}
}
}
}
}
v___jp_7413_:
{
lean_object* v_stats_7415_; lean_object* v___x_7417_; uint8_t v_isShared_7418_; uint8_t v_isSharedCheck_7422_; 
v_stats_7415_ = lean_ctor_get(v_output_7412_, 1);
v_isSharedCheck_7422_ = !lean_is_exclusive(v_output_7412_);
if (v_isSharedCheck_7422_ == 0)
{
lean_object* v_unused_7423_; 
v_unused_7423_ = lean_ctor_get(v_output_7412_, 0);
lean_dec(v_unused_7423_);
v___x_7417_ = v_output_7412_;
v_isShared_7418_ = v_isSharedCheck_7422_;
goto v_resetjp_7416_;
}
else
{
lean_inc(v_stats_7415_);
lean_dec(v_output_7412_);
v___x_7417_ = lean_box(0);
v_isShared_7418_ = v_isSharedCheck_7422_;
goto v_resetjp_7416_;
}
v_resetjp_7416_:
{
lean_object* v___x_7420_; 
if (v_isShared_7418_ == 0)
{
lean_ctor_set(v___x_7417_, 0, v___y_7414_);
v___x_7420_ = v___x_7417_;
goto v_reusejp_7419_;
}
else
{
lean_object* v_reuseFailAlloc_7421_; 
v_reuseFailAlloc_7421_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_7421_, 0, v___y_7414_);
lean_ctor_set(v_reuseFailAlloc_7421_, 1, v_stats_7415_);
v___x_7420_ = v_reuseFailAlloc_7421_;
goto v_reusejp_7419_;
}
v_reusejp_7419_:
{
return v___x_7420_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_Groebner_reduceRowsWith___boxed(lean_object* v_field_7451_, lean_object* v_limits_7452_, lean_object* v_columns_7453_, lean_object* v_reducers_7454_, lean_object* v_targets_7455_, lean_object* v_provenance_7456_, lean_object* v_sugars_7457_, lean_object* v_native_7458_){
_start:
{
uint64_t v_field_boxed_7459_; uint8_t v_provenance_boxed_7460_; uint8_t v_native_boxed_7461_; lean_object* v_res_7462_; 
v_field_boxed_7459_ = lean_unbox_uint64(v_field_7451_);
lean_dec_ref(v_field_7451_);
v_provenance_boxed_7460_ = lean_unbox(v_provenance_7456_);
v_native_boxed_7461_ = lean_unbox(v_native_7458_);
v_res_7462_ = lp_Hex_Hex_Groebner_reduceRowsWith(v_field_boxed_7459_, v_limits_7452_, v_columns_7453_, v_reducers_7454_, v_targets_7455_, v_provenance_boxed_7460_, v_sugars_7457_, v_native_boxed_7461_);
lean_dec_ref(v_sugars_7457_);
lean_dec_ref(v_targets_7455_);
lean_dec_ref(v_reducers_7454_);
lean_dec_ref(v_limits_7452_);
return v_res_7462_;
}
}
lean_object* runtime_initialize_Init(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Matrix(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_Native(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_NativeScan(uint8_t builtin);
lean_object* runtime_initialize_Hex_HexGroebner_NativeGather(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Hex_HexGroebner_Elimination(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Matrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Native(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_NativeScan(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_NativeGather(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* runtime_initialize_Init(uint8_t builtin);
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Hex_HexGroebner_Elimination(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
res = runtime_initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Matrix(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_Native(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_NativeScan(uint8_t builtin);
lean_object* initialize_Hex_HexGroebner_NativeGather(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexGroebner_Elimination(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Matrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_Native(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_NativeScan(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexGroebner_NativeGather(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Hex_HexGroebner_Elimination(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Hex_HexGroebner_Elimination(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Hex_HexGroebner_Elimination(builtin);
}
#ifdef __cplusplus
}
#endif
