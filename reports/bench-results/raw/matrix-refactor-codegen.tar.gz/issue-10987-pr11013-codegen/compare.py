from pathlib import Path
import re,difflib,json,hashlib
old=Path('/tmp/hex-groebner-evidence-review/.lake/build/ir/HexGroebner/Elimination.c');new=Path('/tmp/hex-groebner-matrix-state-dev/.lake/build/ir/HexGroebner/Elimination.c');out=Path('/tmp/issue-10987-pr11013-codegen');out.mkdir(exist_ok=True)
name='lp_Hex___private_HexGroebner_Elimination_0__Hex_Groebner_eliminate'
def body(text,name):
 p=re.search(r'^LEAN_EXPORT [^\n]*\b'+re.escape(name)+r'\([^;\n]*\)\{',text,re.M);assert p
 i=p.start();j=p.end();depth=1
 # Generated elimination body has no brace-bearing string literals.
 for k in range(j,len(text)):
  if text[k]=='{':depth+=1
  elif text[k]=='}':
   depth-=1
   if not depth:return text[i:k+1]
 raise AssertionError('unclosed function')
def normalize(text):
 names={}
 text=re.sub(r'\bv_[A-Za-z0-9_]+',lambda m:names.setdefault(m[0],f'v{len(names)}'),text)
 for helper in ['charge','work','packedBytes','validate','zeros','inverse','scaleSparse']:
  text=text.replace('___private_HexGroebner_Elimination_0__Hex_Groebner_'+helper,'_Hex_Groebner_Matrix_'+helper)
 return text
values=[]
for key,p in [('before',old),('after',new)]:
 raw=p.read_text();value=normalize(body(raw,name));(out/(key+'.c')).write_text(value);values.append(value)
result=dict(scope='Direct generated C body of eliminate only; alpha-renamed local variables and mapped extracted helper symbols. Closed-constant definitions, callees, compiler/linker optimization and runtime scheduling are not covered.',before_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),after_sha256=hashlib.sha256(new.read_bytes()).hexdigest(),normalized_equal=values[0]==values[1])
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');(out/'diff.txt').write_text(''.join(difflib.unified_diff(values[0].splitlines(True),values[1].splitlines(True),fromfile='before',tofile='after')));print(result)
