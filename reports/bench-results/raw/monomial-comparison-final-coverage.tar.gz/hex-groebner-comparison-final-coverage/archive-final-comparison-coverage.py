from pathlib import Path
import shutil,json,hashlib,tarfile
root=Path('/tmp/hex-groebner-compare-monomials-dev');stage=Path('/tmp/hex-groebner-comparison-final-coverage');stage.mkdir(exist_ok=False)
for file in ['conformance/HexGroebner/MonomialCompareConformance.lean','conformance/HexGroebner/MonomialConformance.lean','conformance/HexGroebner/NativeChecks.lean','scripts/ci/check_groebner_matrix.py']:
 p=stage/file;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/file,p)
for name in ['issue-10987-pr11003-coverage-sanitize.log','issue-10987-pr11003-coverage-gcc-sanitize.log','issue-10987-pr11003-final-coverage-build.log']:shutil.copy2(Path('/tmp')/name,stage/name)
shutil.copy2(__file__,stage/Path(__file__).name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prod=Path('/tmp/hex-groebner-typed-compare-production')
meta={'production_fingerprint':'802ae51122d7','source_and_binary_equivalence':'Production fingerprint and both compiled executable hashes unchanged after test-only coverage changes.','frozen_binaries':json.load(open(prod/'binaries/manifest.json'))['binary_sha256'],'files':{str(p.relative_to(stage)):sha(p) for p in stage.rglob('*') if p.is_file()}}
(stage/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');p=root/'reports/bench-results/raw/monomial-comparison-final-coverage.tar.gz';assert not p.exists()
with tarfile.open(p,'w:gz') as t:t.add(stage,arcname=stage.name)
print(p.name,sha(p))
