from pathlib import Path
import os,json,subprocess,hashlib,sys
root=Path('/tmp/hex-groebner-wide-validation-dev');sys.path.insert(0,str(root));from scripts.bench.cpu_lease import cpu_lease
base=Path('/tmp/hex-groebner-wide-validation-production');out=base/'kernel-paired';out.mkdir(exist_ok=False)
build=json.loads((base/'bench-binaries/builds.json').read_text());binary=base/'bench-binaries/frame';assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256'];cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});load=os.getloadavg();runs=[]
try:
 for comparison in['matrixValidateWide']:
  all_points={a:[]for a in'AB'}
  for block,order in enumerate(['AB','BA']):
   for arm in order:
    name=comparison+('Reference'if arm=='A'else'');prefix=f'{comparison}-block{block}-{arm}';command=[str(binary),'run','Hex.Groebner.Bench.'+name,'--outer-trials','1','--export-file',str(out/(prefix+'.json'))]
    with(out/(prefix+'.log')).open('w')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
    runs.append(dict(comparison=comparison,block=block,arm=arm,command=command,returncode=r.returncode));assert r.returncode in[0,2]
    value=json.loads((out/(prefix+'.json')).read_text())['results'][0];points=value['points'];assert len(points)==9 and all(p['status']=='ok'for p in points);all_points[arm]+=points;print(prefix,value['verdict'],flush=True)
  for n in[1,4,16,64,256,1024,4096,16384,65536]:
   hashes={p['result_hash']for points in all_points.values()for p in points if p['param']==n};assert len(hashes)==1,(comparison,n,hashes)
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=load,load_end=os.getloadavg(),source_fingerprint=build['source_fingerprint'],binary_sha256=build['binary_sha256'],scope='First full-UInt32-column row-validation AB/BA whole-sweep campaign: nine row lengths1/4/16/64/256/1024/4096/16384/65536,36completedpoints. A original portable validator; B native row-bounded provider at4294967295columns, field65537, dense unit sparse rows prepared outside timing. Consume successful result and every exact prefix counter; build-time success/equality guards and full hash comparisons. Allsamples/RSS/floors/failures/CPUlease/hostcontextretained, onealgorithmthread,nohostfiltering,nounchangedrepeat. This microkernel creates no dense workspace at the ambient column count. No candidate certificate, native verification or kernel-checking timing.',runs=runs),indent=2)+'\n');lease.close()
(out/'measure.py').write_bytes(Path(__file__).read_bytes());(out/'builds.json').write_bytes((base/'bench-binaries/builds.json').read_bytes())
