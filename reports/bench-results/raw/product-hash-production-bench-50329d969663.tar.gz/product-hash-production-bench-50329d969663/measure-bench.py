import hashlib,json,os,pathlib,subprocess,sys,time
sys.path.insert(0,'/home/kim/worktrees/hex-dev/hex-dev-issue-10987')
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import fingerprint,index_listing
root=pathlib.Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987');dev=pathlib.Path('/tmp/hex-groebner-product-hash-production')
listing=json.loads((dev/'product-hash-production-records-50329d969663/metadata.json').read_text())['source_manifest'];fp=fingerprint(listing);assert fp=='50329d969663';out=dev/('product-hash-production-bench-'+fp);out.mkdir(exist_ok=False)
binaries={'A':pathlib.Path('/tmp/hex-groebner-spair-cache-production/binaries/hexgroebner-bench-spair'),'B':dev/'binaries/hexgroebner-bench-mixed-products'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
meta=dict(source_fingerprint=fp,source_manifest=listing,baseline_commit='373c7c1c70',baseline_source_fingerprint='a8a18555d30d',binary_sha256={a:sha(p) for a,p in binaries.items()},cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),schedule='per case, adjacent AB then BA; declared five fixed repetitions',contract='two frozen production executables; default fixed F4 cases at p65537 and cyclic6Small p32003 through canonicalization/final interreduction and full structural basis hashing; A shared S-pair row cache a8a18555d30d, B same engine with exact bounded individual-product cache and mixed pair hashes50329d969663; source manifest is the frozen build revision, not the later checkout at execution; same six fixed cases and complete hashes; certificate generation, certification and kernel checking excluded',toolchain=(root/'lean-toolchain').read_text().strip(),compiler=subprocess.check_output(['cc','--version'],text=True),script=pathlib.Path(__file__).read_text(),runs=[])
try:
 for block,order in enumerate(['AB','BA']):
  for case in ['cyclic4','cyclic5','cyclic6','katsura3','reimer5','cyclic6Small']:
   for arm in order:
    prefix=f'{case}-b{block}-{arm}';command=[str(binaries[arm]),'run','Hex.Groebner.Bench.'+case,'--export-file',str(out/(prefix+'.json'))]
    print(prefix,flush=True);start=time.monotonic_ns()
    with (out/(prefix+'.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    meta['runs'].append(dict(case=case,block=block,arm=arm,command=command,returncode=result.returncode,wall_nanos=time.monotonic_ns()-start))
finally:
 meta['load_end']=os.getloadavg();(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
