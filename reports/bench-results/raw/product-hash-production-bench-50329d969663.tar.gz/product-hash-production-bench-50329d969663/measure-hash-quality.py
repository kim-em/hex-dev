import ctypes,hashlib,json,os,pathlib,resource,select,signal,subprocess,sys,time
sys.path.insert(0,'/home/kim/worktrees/hex-dev/hex-dev-issue-10987')
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.groebner_measure import FAMILY
from scripts.bench.sweep_freshness import fingerprint,index_listing
libc=ctypes.CDLL(None,use_errno=True)
libc.pidfd_open.argtypes=[ctypes.c_int,ctypes.c_uint]
libc.pidfd_open.restype=ctypes.c_int
listing=index_listing(FAMILY);fp=fingerprint(listing)
ROOT=pathlib.Path('/tmp/hex-groebner-compare')
DEV=pathlib.Path('/tmp/hex-groebner-product-hash-production')
OUT=DEV/f'hash-quality-records-{fp}';OUT.mkdir(exist_ok=False)
plan=json.loads((ROOT/'diagnostic-suite.json').read_text()); protocol=dict(plan['protocol'],A='production F4 with bounded products and default folded pair hashes',B='same F4 with transparent mixed pair hashes and exact full-word equality')
binary=DEV/'binaries/compare-mixed-products'; baseline=pathlib.Path('/tmp/hex-groebner-product-cache-production/binaries/compare-products'); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
meta=dict(source_fingerprint=fp,source_manifest=listing,suite_sha256=sha(ROOT/'diagnostic-suite.json'),cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),binary_sha256=sha(binary),baseline_binary_sha256=sha(baseline),baseline_source_fingerprint="d87ac129f886",driver_sha256=sha(pathlib.Path('/tmp/hex-groebner-native-production/Main.lean')),script=pathlib.Path(__file__).read_text(),contract='two frozen production executables with identical product memoization, bounds and key/value payload; A default folded hash of packed pair; B transparent avalanche hash of same exact pair, with full equality; all complete bases and non-time counters must agree; candidate/process times separate, certification and kernel checking excluded',schedule='two blocks, adjacent AB then BA per input; retain every completed sample',samples=[])
sources={str(p.relative_to(DEV)):sha(p) for p in sorted(DEV.iterdir()) if p.suffix in ('.lean','.c','.h')}
meta['compiler']=subprocess.check_output(['cc','--version'],text=True)
meta['toolchain']=(pathlib.Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10987')/'lean-toolchain').read_text().strip()
meta['cpu_flags']=next((line.split(':',1)[1].strip() for line in pathlib.Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('flags')), '')
meta['baseline_commit']='5fcf4963cd'
meta['baseline_harness_commit']='bbbdde08b9'
meta['baseline_note']='Frozend87ac129f886 executable; exact source blobs identify the memoization engine before stronger key hashing.'
meta['reference_commit']='5fcf4963cd'
meta['prototype_sources']=sources
meta['prototype_fingerprint']=hashlib.sha256(json.dumps(sources,sort_keys=True).encode()).hexdigest()
(OUT/'prototype').mkdir()
for name in sources:(OUT/'prototype'/name).write_bytes((DEV/name).read_bytes())
(OUT/'diagnostic-suite.json').write_bytes((ROOT/'diagnostic-suite.json').read_bytes())
for case in plan['cases']:(OUT/(case['name']+'.json')).write_bytes((ROOT/(case['name']+'.json')).read_bytes())
meta['protocol']=protocol
def limits():
 os.setsid()
 resource.setrlimit(resource.RLIMIT_AS,(protocol['address_space_bytes'],)*2)
 resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,)*2)
try:
 for block,order in enumerate(['AB','BA']):
  for case in plan['cases']:
   outputs={}
   for arm in order:
    prefix=f"{case['name']}-b{block}-{arm}"
    command=[str(baseline if arm=='A' else binary),str(ROOT/(case['name']+'.json'))]
    start=time.monotonic_ns();timeout=False
    with (OUT/(prefix+'.stdout')).open('wb') as stdout,(OUT/(prefix+'.stderr')).open('wb') as stderr:
     proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env,preexec_fn=limits)
     fd=libc.pidfd_open(proc.pid,0)
     if fd < 0: raise OSError(ctypes.get_errno(), 'pidfd_open')
     try:
      ready,_,_=select.select([fd],[],[],protocol['timeout_seconds'])
      if not ready:
       timeout=True;os.killpg(proc.pid,signal.SIGKILL)
      _,status,usage=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status)
     finally:os.close(fd)
    elapsed=time.monotonic_ns()-start
    record=dict(case=case['name'],family=case['family'],p=case['p'],block=block,arm=arm,command=command,wall_nanos=elapsed,returncode=proc.returncode,peak_rss_kib=usage.ru_maxrss,status='timeout' if timeout else 'ok' if proc.returncode==0 else 'failed')
    if proc.returncode==0:
     data=json.loads((OUT/(prefix+'.stdout')).read_text());outputs[arm]=data['basis'];record['statistics']={k:v for k,v in data.items() if k!='basis'}
    meta['samples'].append(record);print(prefix,record['status'],round(elapsed/1e6,2),flush=True)
   if len(outputs)==2 and outputs['A']!=outputs['B']:raise RuntimeError('complete basis mismatch '+case['name'])
   for arm in order:meta['samples'][-2 if arm==order[0] else -1]['complete_basis_equal']=len(outputs)==2 and outputs['A']==outputs['B']
finally:
 meta['load_end']=os.getloadavg();(OUT/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
