from pathlib import Path
import sys,subprocess,json,hashlib,os,time,resource,signal,statistics,shutil
sys.path.insert(0,'/tmp/hex-groebner-scheduling-dev')
from scripts.bench.cpu_lease import cpu_lease
from scripts.oracle.groebner_singular import polynomial,canonical
base=Path(__file__).resolve().parent;suite=Path('/tmp/hex-groebner-medium-suite/suite.json');plan=json.loads(suite.read_text());out=base/'groebner-jl-v01012-deterministic-first';out.mkdir(exist_ok=False)
hex=Path('/tmp/hex-groebner-scheduling-strengthened-production/binaries/compute');gamba=Path('/nix/store/0sldcfi498nydx7yxfw34vrk6hq12fpa-julia-1.13.2/bin/julia');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads(Path('/tmp/hex-groebner-scheduling-strengthened-production/manifest.json').read_text());assert sha(hex)==manifest['binary_sha256']['compute'];inputs=out/'inputs';shutil.copytree(suite.parent,inputs)
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',JULIA_DEPOT_PATH='/tmp/hex-groebner-julia-current-depot:/home/kim/.julia',JULIA_NUM_THREADS='1')
meta=dict(source_fingerprint=manifest['source_fingerprint'],manifest=manifest,hex_sha256=sha(hex),gamba_sha256=sha(gamba),comparator='Groebner.jl 0.10.12',comparator_source_commit='751c90b0dd9415bab2b56980b0b34b59497ff856',julia_version='1.13.2',project_manifest_sha256=sha(Path('/tmp/hex-groebner-julia-current/Manifest.toml')),driver_sha256=sha(Path('/tmp/hex-groebner-julia-functional/driver.jl')),cpu=cpu,host=os.uname().nodename,load_start=os.getloadavg(),threads=1,gamba_seed=42,contract='Full reduced grevlex output; Hex deterministic candidate vs Groebner.jl deterministic sparse elimination, tasks 1, seed 42. Each Julia process retains a first-call computation including JIT, then a second computation with the same input; both full bases are checked. Julia candidate timer includes file read, exact polynomial parsing/construction, F4 and interreduction, excluding full output writing. Hex candidate timer excludes file/JSON parsing but includes canonicalization/F4/interreduction. Report these different boundaries explicitly. Cold Julia process time includes both computations and is not comparable to the one-computation Hex process. No process speedup claim or certification/kernel check claim. Peak child RSS includes Julia compilation. All completed first/second-call data and outliers are retained. One algorithm thread; adjacent arms AB then BA, seven balanced development families, no held-out or acceptance claim',schedule=['AB','BA'],samples=[])
def cap():
 os.setsid();resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2);resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,)*2)
try:
 for block,order in enumerate(['AB','BA']):
  for case in plan['cases']:
   outputs={};indexes=[]
   for arm in order:
    name=f"{case['name']}-b{block}-{arm}";rss=out/(name+'.rss');basis=out/(name+'.basis')
    program=[str(hex),'--scheduling','degree','--work','100000000000','--packed-bytes',str(16*1024**3),'--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000',str(inputs/(case['name']+'.json'))] if arm=='A' else [str(gamba),'--startup-file=no','--project=/tmp/hex-groebner-julia-current','/tmp/hex-groebner-julia-functional/driver.jl',str(inputs/(case['name']+'.ms')),str(basis),'deterministic','warm']
    command=['/run/current-system/sw/bin/time','-f','%M','-o',str(rss),*program];start=time.monotonic_ns();timeout=False
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
     proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env,preexec_fn=cap)
     try:proc.wait(timeout=120)
     except subprocess.TimeoutExpired:timeout=True;os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    record=dict(case=case['name'],family=case['family'],p=case['p'],block=block,arm=arm,command=command,wall_nanos=time.monotonic_ns()-start,returncode=proc.returncode,status='timeout' if timeout else 'ok' if proc.returncode==0 else 'failed',peak_rss_kib=int(rss.read_text().splitlines()[-1]) if rss.exists() and rss.read_text().splitlines()[-1].isdigit() else None)
    if record['status']=='ok':
     try:
      if arm=='A':
       payload=json.loads((out/(name+'.stdout')).read_text());assert payload['kind']=='unchecked_candidate' and payload['scheduling']=='degree';assert [payload[k] for k in ['p','variables','order']]==[case['p'],case['variables'],'grevlex'];outputs[arm]=canonical(payload['basis']);record['statistics']=payload['statistics'];record['candidate_nanos']=payload['candidateNanos']
      else:
       lines=basis.read_text().splitlines();assert [s for s in lines[0].strip(',').split(',') if s]==[f'x{i}' for i in range(case['variables'])];assert int(lines[1].strip().rstrip(','))==case['p'];outputs[arm]=sorted(p for p in [polynomial(s,case['variables'],case['p']) for s in ''.join(lines[2:]).split(',') if s.strip()] if p)
       first=basis.with_name(basis.name+'.first').read_text().splitlines();first_basis=sorted(p for p in [polynomial(s,case['variables'],case['p']) for s in ''.join(first[2:]).split(',') if s.strip()] if p);assert first_basis==outputs[arm]
       durations=[int(line.split('=',1)[1]) for line in (out/(name+'.stdout')).read_text().splitlines() if line.startswith('candidate_nanos=')];assert len(durations)==2;record['first_call_nanos'],record['candidate_nanos']=durations;record['first_second_bases_equal']=True
     except (ValueError,AssertionError,KeyError,IndexError) as e:record.update(status='invalid_output',error=repr(e))
    indexes.append(len(meta['samples']));meta['samples'].append(record);print(name,record['status'],round(record['wall_nanos']/1e6,2),flush=True)
   equal=len(outputs)==2 and outputs['A']==outputs['B']
   for i in indexes:meta['samples'][i]['complete_basis_equal']=equal
   if len(outputs)==2 and not equal:
    for i in indexes:meta['samples'][i]['status']='basis_mismatch'
finally:
 meta.update(load_end=os.getloadavg(),hex_sha256_after=sha(hex),gamba_sha256_after=sha(gamba));assert meta['hex_sha256']==meta['hex_sha256_after'] and meta['gamba_sha256']==meta['gamba_sha256_after'];(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');shutil.copy2(__file__,out/'measure-julia.py');lease.close()
groups={}
for r in meta['samples']:groups.setdefault((r['case'],r['block']),{})[r['arm']]=r
ratios=[];families={}
for pair in groups.values():
 a,b=pair['A'],pair['B']
 if a['status']==b['status']=='ok' and a['complete_basis_equal']:
  r=a['candidate_nanos']/b['candidate_nanos'];ratios.append(r);families.setdefault(a['family'],[]).append(r)
summary=dict(cpu=cpu,ratio_direction='Hex candidate/Groebner.jl second-call including file+polynomial construction; distinct boundaries, no process comparison',complete_basis_pairs=len(ratios),samples=len(meta['samples']),failed_samples=sum(s['status']!='ok' for s in meta['samples']),geomean=statistics.geometric_mean(ratios) if ratios else None,median=statistics.median(ratios) if ratios else None,minimum=min(ratios) if ratios else None,maximum=max(ratios) if ratios else None,per_family={f:statistics.geometric_mean(v) for f,v in families.items()},peak_rss_kib={a:max(r['peak_rss_kib'] or 0 for r in meta['samples'] if r['arm']==a) for a in ['A','B']})
if len(families)==7:summary['family_balanced_geomean']=statistics.geometric_mean(summary['per_family'].values())
shutil.copy2('/tmp/hex-groebner-julia-functional/driver.jl',out/'driver.jl');shutil.copy2('/tmp/hex-groebner-julia-current/Project.toml',out/'Project.toml');shutil.copy2('/tmp/hex-groebner-julia-current/Manifest.toml',out/'Manifest.toml')
(out/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));raise SystemExit(1 if summary['failed_samples'] or len(ratios)!=28 else 0)
