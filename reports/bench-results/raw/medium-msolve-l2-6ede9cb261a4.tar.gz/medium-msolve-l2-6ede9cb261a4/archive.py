from pathlib import Path
import json,tarfile,hashlib,shutil,subprocess
repo=Path('/tmp/hex-groebner-evidence-review');base=Path('/tmp/hex-groebner-medium-results');dest=repo/'reports/bench-results/raw';catalog=[]
for variant in ['msolve-l2-6ede9cb261a4','msolve-l42-6ede9cb261a4','gamba-v03-avx512-first','groebner-jl-v01012-deterministic-first','giac-v20019-first','profile-cyclic7-degree']:
 name='medium-'+variant;stage=Path('/tmp/hex-groebner-archive-staging')/name;shutil.copytree(base/variant,stage);metadata=json.loads((stage/'metadata.json').read_text());m=metadata.get('manifest') or (metadata if 'source_manifest' in metadata else json.loads(Path('/tmp/hex-groebner-scheduling-strengthened-production/manifest.json').read_text()))
 (stage/'source.manifest').write_text(m['source_manifest'])
 for line in m['source_manifest'].splitlines():
  h,n=line.split('\t',1);oid=h.split()[1];data=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid;p=stage/'root-sources'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 shutil.copytree('/tmp/hex-groebner-medium-suite',stage/'suite-provenance');shutil.copy2('/tmp/hex-groebner-gamba/LICENSE.md',stage/'suite-provenance/GamBa-LICENSE.md');shutil.copy2('/tmp/hex-groebner-gamba/README.md',stage/'suite-provenance/GamBa-README.md')
 for n in ['measure-gamba.py','measure-julia.py','measure-giac.py','profile-cyclic7.py']:shutil.copy2(base/n,stage/n)
 scope=dict(scope='Fixed balanced medium development corpus, not held-out or SPEC acceptance coverage. Every completed adjacent AB/BA sample and all output, variability, memory, failures and host context are retained. Single initial campaign, no unchanged repeat. Exact full reduced bases agree in every comparator pair. Hex computes deterministic unchecked prime-field F4 with degree scheduling and full interreduction. Certificate generation, independent final certification and kernel replay are excluded from candidate timing. One algorithm thread and one leased shared-host CPU. No fastest-open-source or language-impossibility claim. No comparator executable is redistributed.',source_fingerprint=metadata.get('source_fingerprint'))
 if variant.startswith('msolve'):
  shutil.copy2('/tmp/hex-groebner-mersenne-dispatch-production/msolve-source-3672113ee2c6.tar',stage/'msolve-source-3672113ee2c6.tar')
  for p in Path('/tmp').glob('issue-10987-msolve-native-*.log'):shutil.copy2(p,stage/p.name)
  shutil.copy2('/tmp/issue-10987-build-msolve-native.sh',stage/'build-msolve-native.sh')
  scope['comparator']='Direct msolve ELF, source 3672113ee2c696a2ac9c637636e0f7214f500ba1, Clang23.1.3 -O3 -march=native with effective znver5 recorded in ELF, GMP6.3.0/MPFR4.2.2/FLINT3.6.0. Configure does not find omp.h; both arms request one thread. Modes2/42 request complete reduced grevlex output. Native flag enforcement is NIX_ENFORCE_NO_NATIVE=0. All diagnostics are retained.'
 elif variant.startswith('gamba'):
  shutil.copy2('/tmp/hex-groebner-gamba-release.json',stage/'github-release.json');scope['comparator']='GamBa v0.3.0 official Linux AVX512 release, seed42, one thread, full reduced grevlex basis. Public source is partially closed, so the release cannot be rebuilt or classified as fully open source. Release URL/digest and measured binary digest are retained, binary excluded.'
 elif variant.startswith('groebner'):
  shutil.copytree('/tmp/hex-groebner-julia-current',stage/'julia-project');shutil.copy2('/tmp/hex-groebner-julia-functional/driver.jl',stage/'driver.jl')
  with (stage/'Groebner-jl-source-751c90b0dd94.tar').open('wb') as out:subprocess.run(['git','archive','751c90b0dd9415bab2b56980b0b34b59497ff856'],cwd='/tmp/hex-groebner-julia-source',stdout=out,check=True)
  shutil.copy2('/tmp/issue-10987-julia-current-install.log',stage/'julia-install.log')
  scope['comparator']='Groebner.jl0.10.12 source751c90b0dd9415bab2b56980b0b34b59497ff856, Julia1.13.2, Nemo0.57.1/AbstractAlgebra0.51.3, deterministic linalg, tasks1, seed42, reducedgrevlex. Every Julia process computes the same input twice; both full outputs and first/second times are retained. The ratio compares Hex candidate with Julia second-call time INCLUDING input parse and Nemo polynomial construction. Boundaries are distinct. Whole-process duration includes both computations and JIT, so no matched process ratio is claimed. Peak RSS includes compilation.'
 elif variant.startswith('giac'):
  scope['comparator']='Packaged Giac2.0.0-19, binary and engine hashes retained, upstream currency/build flags/tuning not established. threads(1) plus threads() output checked as1. Default gbasis(...,revlex) with explicit finite-field coefficient domain and complete output. No unsupported deterministic/probabilistic algorithm claim.'
 else:
  scope['profile']='Explanatory perf profile of eight cyclic7-degree calls. 1999Hz user cycles, 6421 samples, zero lost; all complete outputs and non-timing counters agree. Raw perf and flat symbol output retained. Whole-process sampling includes overhead; no scientific timing or causal/runtime-limit claim.'
 (stage/'scope.json').write_text(json.dumps(scope,indent=2)+'\n');shutil.copy2(__file__,stage/'archive.py');target=dest/(name+'.tar.gz');assert not target.exists()
 with tarfile.open(target,'w:gz') as t:t.add(stage,arcname=name)
 a=dict(archive=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest());catalog.append(a);print(a,flush=True)
Path('/tmp/issue-10987-medium-catalog.json').write_text(json.dumps(catalog,indent=2)+'\n')
