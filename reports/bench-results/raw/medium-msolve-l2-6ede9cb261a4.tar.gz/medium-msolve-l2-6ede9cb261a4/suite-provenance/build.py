from pathlib import Path
import hashlib,json,re,sys,subprocess,random
sys.path.insert(0,'/tmp/hex-groebner-scheduling-dev')
from scripts.oracle.groebner_singular import polynomial,expression
root=Path(__file__).resolve().parent;source=Path('/tmp/hex-groebner-gamba');cases=[]
assert not (root/'suite.json').exists()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=source,text=True).strip()
for family,name in [('cyclic','cyclic7'),('kat','kat8'),('eco','eco11'),('noon','noon5'),('reimer','reimer6'),('minrank','minrank_d_2_p_2_q_4_r_2'),('dense-quadratic','quadratic6')]:
 for p,bits in [(32003,15),(2147483647,31)]:
  case=f'{name}-{bits}';src=None
  if family=='dense-quadratic':
   n=6;rng=random.Random(10987);generators=[]
   for _ in range(6):
    terms=[]
    for i in range(n):
     for j in range(i,n):
      powers=[0]*n;powers[i]+=1;powers[j]+=1;terms.append([powers,(rng.randrange(-1000,1001) or 1)%p])
    terms += [[[0]*n,(rng.randrange(-1000,1001) or 1)%p]];generators.append(terms)
   provenance=dict(generator='fixed Python MT19937 seed 10987, nonzero signed integer coefficients in [-1000,1000] reduced in each field, six dense homogeneous quadratic supports plus constants; exact coefficients retained')
  else:
   src=source/'examples'/f'{case}.txt';data=src.read_text();lines=data.splitlines();names=[a.strip() for a in lines[0].split(',') if a.strip()];n=len(names);assert int(lines[1].strip().rstrip(','))==p;mapping={a:'x'+str(i) for i,a in enumerate(names)}
   def rename(m):
    assert m.group() in mapping,m.group();return mapping[m.group()]
   text=re.sub(r'[A-Za-z_][A-Za-z_0-9]*',rename,''.join(lines[2:]));generators=[[[list(e),c] for e,c in polynomial(f,n,p)] for f in text.split(',') if f.strip()]
   provenance=dict(source_commit=commit,source_path=str(src.relative_to(source)),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest())
   (root/(case+'.source.txt')).write_text(data)
  payload=dict(p=p,variables=n,order='grevlex',generators=generators);(root/(case+'.json')).write_text(json.dumps(payload,separators=(',',':'))+'\n');(root/(case+'.ms')).write_text(','.join(f'x{i}' for i in range(n))+'\n'+str(p)+'\n'+',\n'.join(expression(f) for f in generators)+'\n')
  cases.append(dict(name=case,family=family,p=p,variables=n,provenance=provenance))
suite=dict(cases=cases,protocol=dict(name='balanced medium development inputs; no held-out or acceptance claim',timeout_seconds=60,address_space_bytes=16*1024**3,output_bytes=64*1024**2,threads=1,order='grevlex',comparison='complete monic reduced bases; input generation, certificate generation, independent final certification and kernel checking excluded from candidate timings',schedule='two blocks, adjacent AB then BA per case; retain every completed sample, failure and timeout',repeats='at most one unchanged repeat after inconclusive observation'))
(root/'suite.json').write_text(json.dumps(suite,indent=2)+'\n');print('fixed medium suite',len(cases),'cases,',len(set(c['family'] for c in cases)),'equally weighted families; source',commit)
