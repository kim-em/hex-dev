set -euo pipefail
cd /tmp/hex-groebner-msolve
export NIX_ENFORCE_NO_NATIVE=0
./configure --prefix=/tmp/hex-groebner-msolve-native-install CC='clang -std=gnu23' CFLAGS='-O3 -march=native -frecord-command-line' > /tmp/issue-10987-msolve-native-configure-with-deps.log 2>&1
make -j4 V=1 > /tmp/issue-10987-msolve-native-build.log 2>&1
