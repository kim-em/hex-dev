"""Shared utilities for Hex conformance oracles.

Defines the JSONL fixture schemas, the JSON failure-record schema, and
helpers for reading Lean-emitted records, comparing oracle outputs to
the Lean values, and writing replayable failure records on mismatch.

Stdlib only.  Oracle drivers under ``scripts/oracle/`` add the
external-tool import (e.g. ``flint`` from ``python-flint``).

JSONL fixture record shape (one record per line):

* ``poly``       — ``{"kind": "poly",       "lib": str, "case": str,
                      "coeffs": [int...], "modulus": int|null}``
                     Optional BZ conformance metadata:
                     ``"modFactorPrime": int`` and
                     ``"modFactorDegrees": [int...]`` ask the oracle to
                     also check the degree multiset of the fixture reduced
                     modulo the pinned prime.
* ``matrix``     — ``{"kind": "matrix",     "lib": str, "case": str,
                      "rows": [[int...]...]}``
* ``ratmatrix``  — ``{"kind": "ratmatrix",  "lib": str, "case": str,
                      "rows": [[[num, den]...]...]}`` with positive
                     denominators
* ``modmatrix``  — ``{"kind": "modmatrix",  "lib": str, "case": str,
                      "modulus": int, "rows": [[int...]...]}`` with
                     canonical residues below the modulus
* ``polymatrix`` — ``{"kind": "polymatrix", "lib": str, "case": str,
                     "field": {"p": int}|{"rat": true}, "rows": int,
                     "cols": int, "entries": <polynomial matrix>}``
                     Modular polynomials are ascending integer coefficient
                     lists; rational polynomials have parallel ``num``/``den``
                     lists.
* ``sparsepoly`` — ``{"kind": "sparsepoly", "lib": str, "case": str,
                     "domain": "int"|"rat"|"zmod", "mod": int|None,
                     "terms": List[[exp, num, den]]}`` — ascending
                     exponents; ``den`` is 1 outside the ``rat`` domain.
* ``mvpoly``     — ``{"kind": "mvpoly",     "lib": str, "case": str,
                      "arity": int, "order": "lex"|"grlex"|"grevlex",
                      "terms": [[[exponent...], coefficient]...]}``
* ``mvpolymatrix`` — ``{"kind": "mvpolymatrix", "lib": str, "case": str,
                      "arity": int, "order": "lex"|"grlex"|"grevlex",
                      "rows": int, "cols": int,
                      "entries": [[<mvpoly terms>...]...], "r": int}``
                     (a matrix of multivariate polynomials in the ``mvpoly``
                      term encoding together with the minor size ``r``;
                      ``entries`` holds exactly ``rows`` lists of exactly
                      ``cols`` polynomials.  Matrices over ``Int`` are
                      arity-0 polynomial matrices, so one stream covers
                      integer and symbolic matrices.)
* ``mvgcd``      — two multivariate term lists plus coefficient-domain data
* ``mvsqf``      — one characteristic-zero multivariate term list
* ``mvsquarefree`` — one modular multivariate term list and its modulus
* ``mvhensel``   — one checked multivariate Hensel-lift input
* ``mvdioph``    — one recursive multivariate diophantine input
* ``mvfactor``   — one multivariate integer factorization input
* ``mvirred``    — one multivariate irreducibility-decision input
* ``mvpoint``    — one caller-selected Wang evaluation point
* ``lattice``    — ``{"kind": "lattice",    "lib": str, "case": str,
                      "basis": [[int...]...]}``
* ``prime``      — ``{"kind": "prime",      "lib": str, "case": str,
                      "p": int, "n": int}``
* ``nextprime``  — ``{"kind": "nextprime",  "lib": str, "case": str,
                      "n": nonnegative int}``
* ``symmod``     — ``{"kind": "symmod",     "lib": str, "case": str,
                      "a": int, "m": nonnegative int}``
* ``crt``        — ``{"kind": "crt",        "lib": str, "case": str,
                      "residues": [int...], "moduli": [nonnegative int...]}``
* ``ratrecon``   — ``{"kind": "ratrecon",   "lib": str, "case": str,
                      "a": int, "m": nonnegative int, "p": int, "q": int}``
* ``conway``     — ``{"kind": "conway",     "lib": str, "case": str,
                      "p": int, "n": int}``
* ``gfq_bridge`` — ``{"kind": "gfq_bridge", "lib": str, "case": str,
                      "p": int, "modulus": [int...],
                      "a": [int...], "b": [int...]}``
                     (two reduced operands `a` and `b` over `F_p[x] /
                      (modulus)`; carries the inputs both Lean
                      representations consume so the oracle can verify
                      packed and generic answers independently.)
* ``gfqring``    — ``{"kind": "gfqring",    "lib": str, "case": str,
                      "p": int, "modulus": [int...],
                      "a": [int...], "b": [int...],
                      "c": [int...], "n": int}``
                     (a, b are reduced operands; c is an unreduced
                      polynomial used for the `reduce` op; n is the
                      scalar used for the `nsmul` op.)
* ``gfqfield``   — ``{"kind": "gfqfield",   "lib": str, "case": str,
                      "p": int, "modulus": [int...],
                      "a": [int...], "b": [int...], "zexp": int}``
                     (a, b are reduced operands modulo `m(x)`; `zexp`
                      is the integer exponent for the `zpow` op.  `b`
                      must be nonzero so that `a / b` is well-defined.)
* ``rcf_sentence`` — ``{"kind": "rcf_sentence", "lib": str,
                         "case": str, "schema": 1,
                         "sentence": <recursive sentence AST>}``
                     (one univariate real sentence; atoms contain integer
                      polynomial coefficients in ascending degree order.)
* ``factor`` / ``frozen`` / ``divisorfn`` / ``order`` / ``cyclotomic`` — natural-number
  inputs for the certified integer-factorization oracle.

Result records (emitted by Lean alongside the fixture, on the same
JSONL stream) carry the operation name and Lean's computed answer:

* ``{"kind": "result", "lib": str, "case": str, "op": str,
     "value": <op-specific JSON>}``

The ``op`` strings are oracle-defined; e.g. ``poly_flint.py`` knows
``mul`` (value is the coefficient list of the product), ``gcd``
(coefficient list of the monic gcd), ``divmod`` (a ``[quot, rem]``
pair of coefficient lists).

JSON failure record shape (one file per failure, written to a
caller-supplied directory):

``{"library": str, "profile": "ci"|"local", "seed": int,
   "case_id": str, "kind": str, "input": <case object>,
   "lean_output": <serialised>, "oracle_output": <serialised>,
   "oracle_name": str, "oracle_version": str, "diff": str}``
"""

from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path
from typing import Any, Iterable, Iterator


VALID_FIXTURE_KINDS = frozenset(
    {
        "poly",
        "matrix",
        "bareiss_carrier",
        "poly_det",
        "charpoly_carrier",
        "generic_rank",
        "det",
        "ratmatrix",
        "fieldmatrix",
        "modmatrix",
        "polymatrix",
        "mvpoly",
        "mvpolymatrix",
        "mvgcd",
        "mvsqf",
        "mvsquarefree",
        "mvhensel",
        "mvdioph",
        "mvfactor",
        "mvirred",
        "mvpoint",
        "sparsepoly",
        "lattice",
        "prime",
        "symmod",
        "crt",
        "ratrecon",
        "conway",
        "isprime",
        "nextprime",
        "certcheck",
        "segment",
        "gfq_bridge",
        "gfqring",
        "gfqfield",
        "rcf_sentence",
        "factor",
        "frozen",
        "divisorfn",
        "graphiso",
        "graphisoautos",
        "graphisosparse",
        "graphisosparseautos",
        "order",
        "cyclotomic",
    }
)


class FixtureError(ValueError):
    """Raised when a JSONL record fails schema validation."""


class OracleMismatch(AssertionError):
    """Raised when an oracle output does not match the Lean output.

    Carries enough context that the failure record was written before
    re-raising; the oracle CLI converts this into a non-zero exit.
    """


def _exact_keys(value: dict[str, Any], expected: set[str], context: str) -> None:
    """Require exactly ``expected`` object fields in a versioned schema."""
    actual = set(value)
    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise FixtureError(
            f"{context} has wrong fields (missing={missing}, extra={extra}): {value!r}"
        )


def _is_int(value: Any) -> bool:
    """JSON integer check which rejects booleans (a Python ``int`` subclass)."""
    return type(value) is int


def _validate_rcf_dyadic(value: Any, context: str) -> None:
    if (
        not isinstance(value, list)
        or len(value) != 2
        or not all(_is_int(component) for component in value)
    ):
        raise FixtureError(f"{context} must be [int, int]: {value!r}")
    numerator, exponent = value
    if numerator == 0:
        if exponent != 0:
            raise FixtureError(f"{context} zero must be encoded canonically as [0, 0]")
    elif numerator % 2 == 0:
        raise FixtureError(f"{context} nonzero numerator must be odd: {value!r}")


def _validate_rcf_formula(value: Any, context: str = "rcf_sentence.formula") -> None:
    """Validate the complete, version-1 recursive RCF formula grammar."""
    if not isinstance(value, dict):
        raise FixtureError(f"{context} must be an object: {value!r}")
    tag = value.get("tag")
    if tag in {"tt", "ff"}:
        _exact_keys(value, {"tag"}, context)
    elif tag == "atom":
        _exact_keys(value, {"tag", "coeffs", "cmp"}, context)
        coeffs = value["coeffs"]
        if not isinstance(coeffs, list) or not all(_is_int(c) for c in coeffs):
            raise FixtureError(f"{context}.coeffs must be List[int]: {value!r}")
        if coeffs and coeffs[-1] == 0:
            raise FixtureError(
                f"{context}.coeffs must be canonical (empty or nonzero last): {value!r}"
            )
        if value["cmp"] not in {"lt", "le", "eq", "ge", "gt", "ne"}:
            raise FixtureError(
                f"{context}.cmp must be one of lt/le/eq/ge/gt/ne: {value!r}"
            )
    elif tag == "not":
        _exact_keys(value, {"tag", "arg"}, context)
        _validate_rcf_formula(value["arg"], f"{context}.arg")
    elif tag in {"and", "or", "imp"}:
        _exact_keys(value, {"tag", "left", "right"}, context)
        _validate_rcf_formula(value["left"], f"{context}.left")
        _validate_rcf_formula(value["right"], f"{context}.right")
    else:
        raise FixtureError(f"{context}.tag is invalid: {tag!r}")


def _validate_rcf_sentence(record: dict[str, Any]) -> None:
    _exact_keys(record, {"kind", "lib", "case", "schema", "sentence"}, "rcf_sentence")
    if not _is_int(record["schema"]) or record["schema"] != 1:
        raise FixtureError(f"rcf_sentence.schema must be exactly 1: {record!r}")
    sentence = record["sentence"]
    if not isinstance(sentence, dict):
        raise FixtureError(f"rcf_sentence.sentence must be an object: {record!r}")
    _exact_keys(sentence, {"quantifier", "bounds", "formula"}, "rcf_sentence.sentence")
    quantifier = sentence["quantifier"]
    if quantifier not in {"forall_real", "exists_real", "forall_ioc", "exists_ioc"}:
        raise FixtureError(
            f"rcf_sentence.sentence.quantifier is invalid: {quantifier!r}"
        )
    bounds = sentence["bounds"]
    if quantifier in {"forall_real", "exists_real"}:
        if bounds is not None:
            raise FixtureError(
                f"rcf_sentence.sentence.bounds must be null for {quantifier}: {bounds!r}"
            )
    else:
        if not isinstance(bounds, dict):
            raise FixtureError(
                f"rcf_sentence.sentence.bounds must be an object for {quantifier}: "
                f"{bounds!r}"
            )
        _exact_keys(bounds, {"lower", "upper"}, "rcf_sentence.sentence.bounds")
        _validate_rcf_dyadic(bounds["lower"], "rcf_sentence.sentence.bounds.lower")
        _validate_rcf_dyadic(bounds["upper"], "rcf_sentence.sentence.bounds.upper")
    _validate_rcf_formula(sentence["formula"])


def _is_nat(v: Any) -> bool:
    return _is_int(v) and v >= 0


def _validate_prime_cert(cert: Any, path: str) -> None:
    # Every serialized field is a `Nat` on the Lean side, so negatives are
    # malformed input, not merely rejectable certificates.
    if not isinstance(cert, dict):
        raise FixtureError(f"{path} must be an object: {cert!r}")
    t = cert.get("t")
    if t == "small":
        if not _is_nat(cert.get("n")):
            raise FixtureError(f"{path}.n must be a nonnegative int: {cert!r}")
        return
    if t not in {"pock", "pock3", "pock3Sieve"}:
        raise FixtureError(f"{path}.t must be small/pock/pock3/pock3Sieve: {cert!r}")
    if not _is_nat(cert.get("n")):
        raise FixtureError(f"{path}.n must be a nonnegative int: {cert!r}")
    if t in {"pock3", "pock3Sieve"}:
        for key in (("r", "s", "w", "m") if t == "pock3Sieve" else ("r", "s", "w")):
            if not _is_nat(cert.get(key)):
                raise FixtureError(
                    f"{path}.{key} must be a nonnegative int: {cert!r}")
    factors = cert.get("f")
    if not isinstance(factors, list):
        raise FixtureError(f"{path}.f must be a list: {cert!r}")
    for i, entry in enumerate(factors):
        if (
            not isinstance(entry, list)
            or len(entry) != 3
            or not _is_nat(entry[0])
            or not _is_nat(entry[1])
        ):
            raise FixtureError(
                f"{path}.f[{i}] must be [a, e, cert] with nonnegative "
                f"ints: {entry!r}")
        _validate_prime_cert(entry[2], f"{path}.f[{i}][2]")
def _validate_mv_header(record: dict[str, Any], kind: str) -> int:
    arity = record.get("arity")
    if not _is_int(arity) or arity < 0:
        raise FixtureError(f"{kind}.arity must be a nonnegative int: {record!r}")
    if record.get("order") not in {"lex", "grlex", "grevlex"}:
        raise FixtureError(f"{kind}.order must be lex/grlex/grevlex: {record!r}")
    return arity


def _validate_mv_terms(terms: Any, arity: int, context: str) -> None:
    if not isinstance(terms, list):
        raise FixtureError(f"{context} must be a list: {terms!r}")
    for term in terms:
        if (
            not isinstance(term, list)
            or len(term) != 2
            or not isinstance(term[0], list)
            or len(term[0]) != arity
            or not all(_is_int(e) and e >= 0 for e in term[0])
            or not _is_int(term[1])
        ):
            raise FixtureError(
                f"{context} terms must be [[nonnegative exponent...], int] "
                f"with exponent length arity: {term!r}"
            )


def _validate_dense_polys(polys: Any, context: str) -> None:
    if not isinstance(polys, list):
        raise FixtureError(f"{context} must be a list: {polys!r}")
    for coefficients in polys:
        if not isinstance(coefficients, list) or not all(
            _is_int(coefficient) for coefficient in coefficients
        ):
            raise FixtureError(
                f"{context} entries must be ascending List[int]: {coefficients!r}"
            )
        if coefficients and coefficients[-1] == 0:
            raise FixtureError(
                f"{context} entries must be canonical (empty or nonzero last): "
                f"{coefficients!r}"
            )


def _validate_mv_poly_list(polys: Any, arity: int, context: str) -> None:
    if not isinstance(polys, list):
        raise FixtureError(f"{context} must be a list: {polys!r}")
    for index, terms in enumerate(polys):
        _validate_mv_terms(terms, arity, f"{context}[{index}]")


def _validate_graphiso_core(record: dict[str, Any]) -> None:
    """The fields a canonical-labelling fixture record carries.

    Shared by ``graphiso`` and ``graphisoautos``: the latter is the
    former plus the automorphism fields, so a consumer reading the whole
    stream for canonical forms needs no knowledge of the second kind.
    """
    n = record.get("n")
    k = record.get("k")
    if not _is_nat(n) or not _is_nat(k):
        raise FixtureError(f"graphiso.n/k must be Nat: {record!r}")
    colors = record.get("colors")
    if not isinstance(colors, list) or len(colors) != n or not all(
        isinstance(c, int) and 0 <= c < max(k, 1) for c in colors
    ):
        raise FixtureError(f"graphiso.colors must be n colours below k: {record!r}")
    edges = record.get("edges")
    if not isinstance(edges, list) or not all(
        isinstance(e, list) and len(e) == 2
        and all(isinstance(x, int) and 0 <= x < n for x in e)
        and e[0] < e[1]
        for e in edges
    ):
        raise FixtureError(f"graphiso.edges must be i<j pairs below n: {record!r}")
    lab = record.get("canonLab")
    if not isinstance(lab, list) or len(lab) != n or sorted(lab) != list(range(n)):
        raise FixtureError(f"graphiso.canonLab must be a permutation of 0..n-1: {record!r}")
    if record["kind"] in ("graphisosparse", "graphisosparseautos"):
        canonical = record.get("canonEdges")
        if not isinstance(canonical, list) or not all(
            isinstance(e, list) and len(e) == 2 and
            all(_is_nat(v) for v in e) and 0 <= e[0] < e[1] < n
            for e in canonical
        ) or canonical != [list(e) for e in sorted(set(map(tuple, canonical)))]:
            raise FixtureError("graphisosparse.canonEdges must be sorted unique edges")
        fields = {"numorbits", "numgenerators", "numnodes", "numbadleaves",
                  "maxlevel", "tctotal", "canupdates"}
        stats = record.get("stats")
        if not isinstance(stats, dict) or set(stats) != fields or not all(
                _is_nat(x) for x in stats.values()):
            raise FixtureError("graphisosparse.stats must contain all seven Nat statistics")
    else:
        tri = record.get("canonTri")
        if not isinstance(tri, str) or len(tri) != n * (n - 1) // 2 or any(
            c not in "01" for c in tri
        ):
            raise FixtureError(f"graphiso.canonTri must be C(n,2) bits: {record!r}")
    sizes = record.get("cellSizes")
    if not isinstance(sizes, list) or len(sizes) != k or sum(sizes) != n or not all(
        isinstance(s, int) and s > 0 for s in sizes
    ):
        raise FixtureError(f"graphiso.cellSizes must be k positive sizes summing to n: {record!r}")
    if not _is_nat(record.get("numnodes")):
        raise FixtureError(f"graphiso.numnodes must be Nat: {record!r}")


def _validate_fixture(record: dict[str, Any]) -> None:
    kind = record.get("kind")
    if kind not in VALID_FIXTURE_KINDS and kind != "result":
        raise FixtureError(f"unknown fixture kind: {kind!r}")
    if kind == "det":
        # Published HexDeterminant carrier records identify the library by kind.
        _exact_keys(record, {"kind", "case", "carrier", "base", "arity", "modulus", "n",
                             "matrix", "determinant"}, kind)
        if any(not isinstance(record[k], str) for k in ("case", "carrier", "base")) or any(
                not _is_nat(record[k]) for k in ("arity", "modulus", "n")):
            raise FixtureError("invalid determinant carrier header")
        rows = record["matrix"]
        if not isinstance(rows, list) or len(rows) != record["n"] or any(
                not isinstance(row, list) or len(row) != record["n"] for row in rows):
            raise FixtureError("determinant carrier matrix must be square and match n")
        return
    for key in ("lib", "case"):
        if not isinstance(record.get(key), str):
            raise FixtureError(f"missing/invalid {key!r} in {record!r}")
    if kind in {"bareiss_carrier", "poly_det"}:
        # Complete per-library carrier records embed their canonical answer.
        # Coefficient-domain validation belongs to matrix_carriers.Carrier.
        expected = {"kind", "lib", "case", "carrier", "n", "arity", "p", "rows", "result"}
        if kind == "poly_det":
            expected |= {"checked", "entry_support"}
        _exact_keys(record, expected, kind)
        if not isinstance(record["carrier"], str) or not _is_nat(record["n"]) or not _is_nat(record["arity"]):
            raise FixtureError("invalid matrix carrier header")
        if not _is_int(record["p"]):
            raise FixtureError("invalid matrix carrier modulus")
        rows = record["rows"]
        if not isinstance(rows, list) or len(rows) != record["n"] or any(
                not isinstance(row, list) or len(row) != record["n"] for row in rows):
            raise FixtureError("matrix carrier rows must be square and match n")
    elif kind == "generic_rank":
        _exact_keys(record, {"kind", "lib", "case", "carrier", "base", "arity", "modulus",
                             "n", "m", "matrix", "support", "pivot_rows", "pivot_cols",
                             "denom", "result"}, kind)
        if record["carrier"] != "mv" or record["base"] not in {"ZZ", "QQ", "GF"}:
            raise FixtureError("invalid generic-rank coefficient domain")
        if any(not _is_nat(record[k]) for k in ("arity", "modulus", "n", "m", "result")):
            raise FixtureError("invalid generic-rank dimensions or result")
        if record["arity"] == 0:
            raise FixtureError("generic-rank arity must be positive")
        for key in ("matrix", "support"):
            rows = record[key]
            if not isinstance(rows, list) or len(rows) != record["n"] or any(
                    not isinstance(row, list) or len(row) != record["m"] for row in rows):
                raise FixtureError(f"generic-rank {key} shape does not match dimensions")
        if any(not _is_nat(x) for row in record["support"] for x in row):
            raise FixtureError("generic-rank supports must be natural numbers")
        for key in ("pivot_rows", "pivot_cols"):
            if not isinstance(record[key], list) or not all(_is_nat(x) for x in record[key]):
                raise FixtureError("generic-rank pivot indices must be natural-number lists")
    elif kind == "charpoly_carrier":
        if record.get("schema") != 1 or not _is_nat(record.get("n")):
            raise FixtureError("invalid charpoly_carrier schema or dimension")
        if not isinstance(record.get("rows"), list) or not isinstance(record.get("value"), list):
            raise FixtureError("charpoly_carrier rows/value must be arrays")
        if not isinstance(record.get("carrier"), str) or record["carrier"] not in {"dense_int", "dense_rat", "dense_mod", "mv_int", "mv_rat", "rat_fn"}:
            raise FixtureError("invalid charpoly_carrier coefficient carrier")
        if not _is_int(record.get("arity")) or record["arity"] < 1:
            raise FixtureError("charpoly_carrier arity must be positive")
        if not _is_int(record.get("modulus")) or record["modulus"] < 2:
            raise FixtureError("charpoly_carrier modulus must be an integer >= 2")
    elif kind == "poly":
        coeffs = record.get("coeffs")
        if not isinstance(coeffs, list) or not all(isinstance(c, int) for c in coeffs):
            raise FixtureError(f"poly.coeffs must be List[int]: {record!r}")
        modulus = record.get("modulus", None)
        if modulus is not None and not isinstance(modulus, int):
            raise FixtureError(f"poly.modulus must be int or null: {record!r}")
        if "modFactorPrime" in record:
            if not isinstance(record.get("modFactorPrime"), int):
                raise FixtureError(f"poly.modFactorPrime must be int: {record!r}")
            degrees = record.get("modFactorDegrees")
            if not isinstance(degrees, list) or not all(
                isinstance(d, int) and d > 0 for d in degrees
            ):
                raise FixtureError(
                    f"poly.modFactorDegrees must be positive List[int]: {record!r}"
                )
        elif "modFactorDegrees" in record:
            raise FixtureError(
                f"poly.modFactorDegrees requires modFactorPrime: {record!r}"
            )
    elif kind in ("graphiso", "graphisosparse"):
        _validate_graphiso_core(record)
    elif kind in ("graphisoautos", "graphisosparseautos"):
        # a superset of a `graphiso` record: the canonical fields are
        # validated by the same rules, so a consumer that only knows
        # canonical forms can read the whole stream
        _validate_graphiso_core(record)
        n = record["n"]
        gens = record.get("gens")
        if not isinstance(gens, list) or not all(
            isinstance(g, list) and sorted(g) == list(range(n)) for g in gens
        ):
            raise FixtureError(
                f"graphisoautos.gens must be permutations of 0..n-1: {record!r}"
            )
        orbits = record.get("orbits")
        if not isinstance(orbits, list) or len(orbits) != n or not all(
            isinstance(x, int) and 0 <= x < max(n, 1) for x in orbits
        ):
            raise FixtureError(
                f"graphisoautos.orbits must be n representatives: {record!r}"
            )
        numOrbits = record.get("numOrbits")
        if not _is_nat(numOrbits) or numOrbits > n:
            raise FixtureError(
                f"graphisoautos.numOrbits must be a Nat at most n: {record!r}"
            )
        if numOrbits != sum(1 for v in range(n) if orbits[v] == v):
            raise FixtureError(
                f"graphisoautos.numOrbits must count the orbit "
                f"representatives: {record!r}"
            )
        if not _is_nat(record.get("numGenerators")):
            raise FixtureError(
                f"graphisoautos.numGenerators must be Nat: {record!r}"
            )
        order = record.get("order")
        if not _is_nat(order) or order < 1:
            raise FixtureError(
                f"graphisoautos.order must be a positive Nat: {record!r}"
            )
    elif kind == "matrix":
        rows = record.get("rows")
        if not isinstance(rows, list) or not all(
            isinstance(row, list) and all(isinstance(x, int) for x in row)
            for row in rows
        ):
            raise FixtureError(f"matrix.rows must be List[List[int]]: {record!r}")
    elif kind == "fieldmatrix":
        n, m = record.get("n"), record.get("m")
        rows, rhs = record.get("rows"), record.get("b")
        carrier, modulus = record.get("carrier"), record.get("modulus")
        if not _is_nat(n) or not _is_nat(m):
            raise FixtureError("fieldmatrix requires explicit nonnegative dimensions")
        if carrier not in ("Rat", "ZMod64", "RationalFn") or not _is_nat(modulus):
            raise FixtureError("invalid fieldmatrix carrier")
        if carrier == "ZMod64" and modulus < 2:
            raise FixtureError("fieldmatrix modulus must be at least two")
        def rational(q):
            return (isinstance(q, list) and len(q) == 2 and
                    all(_is_int(x) for x in q) and q[1] > 0)
        def entry(q):
            if carrier == "Rat":
                return rational(q)
            if carrier == "ZMod64":
                return _is_nat(q) and q < modulus
            return (isinstance(q, list) and len(q) == 2 and
                    all(isinstance(cs, list) and all(rational(x) for x in cs) for cs in q)
                    and len(q[1]) > 0 and any(x[0] != 0 for x in q[1]))
        if (not isinstance(rows, list) or len(rows) != n or
                any(not isinstance(row, list) or len(row) != m or
                    not all(entry(x) for x in row) for row in rows) or
                not isinstance(rhs, list) or len(rhs) != n or not all(entry(x) for x in rhs)):
            raise FixtureError("invalid fieldmatrix entries or dimensions")
    elif kind == "ratmatrix":
        rows = record.get("rows")
        if not isinstance(rows, list) or not all(
            isinstance(row, list)
            and all(
                isinstance(entry, list)
                and len(entry) == 2
                and all(isinstance(x, int) for x in entry)
                and entry[1] > 0
                for entry in row
            )
            for row in rows
        ):
            raise FixtureError(
                f"ratmatrix.rows must be List[List[[num, den]]] with positive "
                f"denominators: {record!r}"
            )
    elif kind == "modmatrix":
        modulus = record.get("modulus")
        if not _is_int(modulus) or modulus < 2:
            raise FixtureError(f"modmatrix.modulus must be at least two: {record!r}")
        rows = record.get("rows")
        if not isinstance(rows, list) or not all(
            isinstance(row, list)
            and all(isinstance(x, int) and 0 <= x < modulus for x in row)
            for row in rows
        ):
            raise FixtureError(
                f"modmatrix.rows must be canonical residues below the "
                f"modulus: {record!r}"
            )
    elif kind == "polymatrix":
        rows = record.get("rows")
        cols = record.get("cols")
        if not _is_int(rows) or rows < 0 or not _is_int(cols) or cols < 0:
            raise FixtureError(
                f"polymatrix rows/cols must be nonnegative ints: {record!r}"
            )
        field = record.get("field")
        if not isinstance(field, dict) or (
            set(field) not in ({"p"}, {"rat"})
        ):
            raise FixtureError(
                f"polymatrix.field must be {{'p': p}} or {{'rat': true}}: {record!r}"
            )
        is_rat = "rat" in field
        if is_rat:
            if field["rat"] is not True:
                raise FixtureError(f"polymatrix.field.rat must be true: {record!r}")
        elif not _is_int(field["p"]) or field["p"] < 2:
            raise FixtureError(f"polymatrix.field.p must be an int >= 2: {record!r}")
        entries = record.get("entries")
        expected_rows = 0 if rows == 0 or cols == 0 else rows
        if not isinstance(entries, list) or len(entries) != expected_rows:
            raise FixtureError(
                f"polymatrix.entries has wrong row count: {record!r}"
            )
        for row in entries:
            if not isinstance(row, list) or len(row) != cols:
                raise FixtureError(
                    f"polymatrix entry row has wrong column count: {record!r}"
                )
            for poly in row:
                if is_rat:
                    if not isinstance(poly, dict) or set(poly) != {"num", "den"}:
                        raise FixtureError(
                            f"rational polynomial must have num/den arrays: {record!r}"
                        )
                    nums, dens = poly["num"], poly["den"]
                    if (
                        not isinstance(nums, list)
                        or not isinstance(dens, list)
                        or len(nums) != len(dens)
                        or not all(_is_int(x) for x in nums)
                        or not all(_is_int(x) and x > 0 for x in dens)
                        or any(math.gcd(abs(a), b) != 1 for a, b in zip(nums, dens))
                    ):
                        raise FixtureError(
                            f"invalid rational polynomial coefficients: {record!r}"
                        )
                    if nums and nums[-1] == 0:
                        raise FixtureError(
                            f"polymatrix polynomial has trailing zero: {record!r}"
                        )
                else:
                    if not isinstance(poly, list) or not all(_is_int(x) for x in poly):
                        raise FixtureError(
                            f"modular polynomial must be List[int]: {record!r}"
                        )
                    if poly and poly[-1] == 0:
                        raise FixtureError(
                            f"polymatrix polynomial has trailing zero: {record!r}"
                        )
    elif kind == "sparsepoly":
        domain = record.get("domain")
        if domain not in {"int", "rat", "zmod"}:
            raise FixtureError(f"sparsepoly.domain must be int/rat/zmod: {record!r}")
        modulus = record.get("mod", None)
        if domain == "zmod":
            if not _is_int(modulus) or modulus < 2:
                raise FixtureError(
                    f"sparsepoly.mod must be an int >= 2 for zmod: {record!r}"
                )
        elif modulus is not None:
            raise FixtureError(f"sparsepoly.mod must be null outside zmod: {record!r}")
        terms = record.get("terms")
        if not isinstance(terms, list):
            raise FixtureError(f"sparsepoly.terms must be a list: {record!r}")
        previous = -1
        for term in terms:
            if (
                not isinstance(term, list)
                or len(term) != 3
                or not all(_is_int(x) for x in term)
                or term[0] < 0
                or term[2] <= 0
            ):
                raise FixtureError(
                    f"sparsepoly term must be [exp, num, den>0]: {record!r}"
                )
            if term[0] <= previous:
                raise FixtureError(
                    f"sparsepoly.terms must have strictly increasing "
                    f"exponents: {record!r}"
                )
            previous = term[0]
    elif kind == "mvpoly":
        arity = _validate_mv_header(record, kind)
        _validate_mv_terms(record.get("terms"), arity, "mvpoly.terms")
    elif kind == "mvpolymatrix":
        arity = _validate_mv_header(record, kind)
        rows = record.get("rows")
        cols = record.get("cols")
        if not _is_nat(rows) or not _is_nat(cols):
            raise FixtureError(
                f"mvpolymatrix rows/cols must be nonnegative ints: {record!r}"
            )
        if not _is_nat(record.get("r")):
            raise FixtureError(
                f"mvpolymatrix.r must be a nonnegative int: {record!r}"
            )
        entries = record.get("entries")
        if not isinstance(entries, list) or len(entries) != rows:
            raise FixtureError(
                f"mvpolymatrix.entries must hold exactly rows rows: {record!r}"
            )
        for index, row in enumerate(entries):
            if not isinstance(row, list) or len(row) != cols:
                raise FixtureError(
                    f"mvpolymatrix.entries[{index}] must hold exactly cols "
                    f"polynomials: {record!r}"
                )
            for column, terms in enumerate(row):
                _validate_mv_terms(
                    terms, arity, f"mvpolymatrix.entries[{index}][{column}]"
                )
    elif kind == "mvgcd":
        _exact_keys(
            record,
            {"kind", "lib", "case", "arity", "order", "domain", "mod", "left", "right"},
            kind,
        )
        arity = _validate_mv_header(record, kind)
        domain = record.get("domain")
        if domain not in {"int", "zmod"}:
            raise FixtureError(f"mvgcd.domain must be int/zmod: {record!r}")
        modulus = record.get("mod")
        if domain == "zmod":
            if not _is_int(modulus) or modulus < 2:
                raise FixtureError(f"mvgcd.mod must be an int >= 2: {record!r}")
        elif modulus is not None:
            raise FixtureError(f"mvgcd.mod must be null over int: {record!r}")
        _validate_mv_terms(record.get("left"), arity, "mvgcd.left")
        _validate_mv_terms(record.get("right"), arity, "mvgcd.right")
    elif kind == "mvsqf":
        _exact_keys(
            record,
            {"kind", "lib", "case", "arity", "order", "domain", "terms"},
            kind,
        )
        arity = _validate_mv_header(record, kind)
        if record.get("domain") != "int":
            raise FixtureError(f"mvsqf.domain must be int: {record!r}")
        _validate_mv_terms(record.get("terms"), arity, "mvsqf.terms")
    elif kind == "mvsquarefree":
        _exact_keys(
            record,
            {"kind", "lib", "case", "arity", "order", "domain", "mod", "terms"},
            kind,
        )
        arity = _validate_mv_header(record, kind)
        if record.get("domain") != "zmod":
            raise FixtureError(f"mvsquarefree.domain must be zmod: {record!r}")
        modulus = record.get("mod")
        if not _is_int(modulus) or modulus < 2:
            raise FixtureError(f"mvsquarefree.mod must be an int >= 2: {record!r}")
        _validate_mv_terms(record.get("terms"), arity, "mvsquarefree.terms")
    elif kind == "mvhensel":
        _exact_keys(
            record,
            {
                "kind",
                "lib",
                "case",
                "arity",
                "order",
                "main",
                "point",
                "prime",
                "exponent",
                "target",
                "images",
                "leading",
            },
            kind,
        )
        arity = _validate_mv_header(record, kind)
        main = record.get("main")
        if arity < 1 or not _is_int(main) or not 0 <= main < arity:
            raise FixtureError(f"mvhensel.main must index a positive arity: {record!r}")
        point = record.get("point")
        if (
            not isinstance(point, list)
            or len(point) != arity - 1
            or not all(_is_int(coordinate) for coordinate in point)
        ):
            raise FixtureError(f"mvhensel.point must contain arity-1 ints: {record!r}")
        if not _is_int(record.get("prime")) or record["prime"] < 2:
            raise FixtureError(f"mvhensel.prime must be an int >= 2: {record!r}")
        if not _is_int(record.get("exponent")) or record["exponent"] < 1:
            raise FixtureError(f"mvhensel.exponent must be a positive int: {record!r}")
        _validate_mv_terms(record.get("target"), arity, "mvhensel.target")
        _validate_dense_polys(record.get("images"), "mvhensel.images")
        _validate_mv_poly_list(record.get("leading"), arity - 1, "mvhensel.leading")
        if not record["images"] or len(record["images"]) != len(record["leading"]):
            raise FixtureError(
                f"mvhensel images/leading must have the same positive length: {record!r}"
            )
    elif kind == "mvdioph":
        _exact_keys(
            record,
            {
                "kind",
                "lib",
                "case",
                "arity",
                "order",
                "main",
                "modulus",
                "degrees",
                "bases",
                "images",
                "witness",
                "rhs",
            },
            kind,
        )
        arity = _validate_mv_header(record, kind)
        main = record.get("main")
        if arity < 1 or not _is_int(main) or not 0 <= main < arity:
            raise FixtureError(f"mvdioph.main must index a positive arity: {record!r}")
        if not _is_int(record.get("modulus")) or record["modulus"] < 2:
            raise FixtureError(f"mvdioph.modulus must be an int >= 2: {record!r}")
        degrees = record.get("degrees")
        if (
            not isinstance(degrees, list)
            or len(degrees) != arity - 1
            or not all(_is_int(degree) and degree >= 0 for degree in degrees)
        ):
            raise FixtureError(
                f"mvdioph.degrees must contain arity-1 naturals: {record!r}"
            )
        _validate_mv_poly_list(record.get("bases"), arity, "mvdioph.bases")
        _validate_dense_polys(record.get("images"), "mvdioph.images")
        _validate_dense_polys(record.get("witness"), "mvdioph.witness")
        _validate_mv_terms(record.get("rhs"), arity, "mvdioph.rhs")
        lengths = {len(record["bases"]), len(record["images"]), len(record["witness"])}
        if len(lengths) != 1 or not record["images"]:
            raise FixtureError(
                f"mvdioph bases/images/witness must have the same positive length: {record!r}"
            )
    elif kind in {"mvfactor", "mvirred"}:
        _exact_keys(
            record,
            {"kind", "lib", "case", "arity", "order", "terms"},
            kind,
        )
        arity = _validate_mv_header(record, kind)
        _validate_mv_terms(record.get("terms"), arity, f"{kind}.terms")
    elif kind == "mvpoint":
        _exact_keys(
            record,
            {"kind", "lib", "case", "arity", "order", "terms", "main", "point"},
            kind,
        )
        arity = _validate_mv_header(record, kind)
        main = record.get("main")
        if arity < 1 or not _is_int(main) or not 0 <= main < arity:
            raise FixtureError(f"mvpoint.main must index a positive arity: {record!r}")
        point = record.get("point")
        if (
            not isinstance(point, list)
            or len(point) != arity - 1
            or not all(_is_int(coordinate) for coordinate in point)
        ):
            raise FixtureError(f"mvpoint.point must contain arity-1 ints: {record!r}")
        _validate_mv_terms(record.get("terms"), arity, "mvpoint.terms")
    elif kind == "lattice":
        basis = record.get("basis")
        if not isinstance(basis, list) or not all(
            isinstance(row, list) and all(isinstance(x, int) for x in row)
            for row in basis
        ):
            raise FixtureError(f"lattice.basis must be List[List[int]]: {record!r}")
    elif kind == "isprime":
        if not _is_int(record.get("n")) or record["n"] < 0:
            raise FixtureError(f"isprime.n must be a nonnegative int: {record!r}")
    elif kind == "nextprime":
        _exact_keys(record, {"kind", "lib", "case", "n"}, kind)
        if not _is_nat(record.get("n")):
            raise FixtureError(f"nextprime.n must be a nonnegative int: {record!r}")
    elif kind == "segment":
        for key in ("lo", "hi"):
            if not _is_int(record.get(key)) or record[key] < 0:
                raise FixtureError(
                    f"segment.{key} must be a nonnegative int: {record!r}"
                )
    elif kind == "certcheck":
        if not _is_int(record.get("n")) or record["n"] < 0:
            raise FixtureError(f"certcheck.n must be a nonnegative int: {record!r}")
        _validate_prime_cert(record.get("cert"), "certcheck.cert")
    elif kind in {"factor", "divisorfn", "frozen"}:
        _exact_keys(record, {"kind", "lib", "case", "n"}, kind)
        if not _is_nat(record.get("n")):
            raise FixtureError(f"{kind}.n must be a nonnegative int: {record!r}")
    elif kind == "order":
        _exact_keys(record, {"kind", "lib", "case", "base", "modulus"}, kind)
        if not _is_nat(record.get("base")) or not _is_nat(record.get("modulus")):
            raise FixtureError(f"order fields must be nonnegative ints: {record!r}")
    elif kind == "cyclotomic":
        _exact_keys(record, {"kind", "lib", "case", "b", "n", "sign"}, kind)
        if not _is_nat(record.get("b")) or not _is_nat(record.get("n")):
            raise FixtureError(f"cyclotomic b/n must be nonnegative ints: {record!r}")
        if record.get("sign") not in {"minus", "plus"}:
            raise FixtureError(f"cyclotomic.sign must be minus/plus: {record!r}")
    elif kind == "prime":
        for key in ("p", "n"):
            if not isinstance(record.get(key), int):
                raise FixtureError(f"prime.{key} must be int: {record!r}")
    elif kind == "symmod":
        if not _is_int(record.get("a")):
            raise FixtureError(f"symmod.a must be int: {record!r}")
        if not _is_int(record.get("m")) or record["m"] < 0:
            raise FixtureError(f"symmod.m must be a nonnegative int: {record!r}")
    elif kind == "crt":
        residues = record.get("residues")
        moduli = record.get("moduli")
        if not isinstance(residues, list) or not all(_is_int(x) for x in residues):
            raise FixtureError(f"crt.residues must be List[int]: {record!r}")
        if not isinstance(moduli, list) or not all(
            _is_int(x) and x >= 0 for x in moduli
        ):
            raise FixtureError(f"crt.moduli must be List[nonnegative int]: {record!r}")
        if len(residues) != len(moduli):
            raise FixtureError(
                f"crt residue and modulus lists must have equal length: {record!r}"
            )
    elif kind == "ratrecon":
        for key in ("a", "m", "p", "q"):
            if not _is_int(record.get(key)):
                raise FixtureError(f"ratrecon.{key} must be int: {record!r}")
        if record["m"] < 0:
            raise FixtureError(f"ratrecon.m must be a nonnegative int: {record!r}")
    elif kind == "conway":
        for key in ("p", "n"):
            if not isinstance(record.get(key), int):
                raise FixtureError(f"conway.{key} must be int: {record!r}")
    elif kind == "gfqring":
        if not isinstance(record.get("p"), int):
            raise FixtureError(f"gfqring.p must be int: {record!r}")
        if not isinstance(record.get("n"), int):
            raise FixtureError(f"gfqring.n must be int: {record!r}")
        for key in ("modulus", "a", "b", "c"):
            seq = record.get(key)
            if not isinstance(seq, list) or not all(isinstance(x, int) for x in seq):
                raise FixtureError(f"gfqring.{key} must be List[int]: {record!r}")
    elif kind == "gfq_bridge":
        if not isinstance(record.get("p"), int):
            raise FixtureError(f"gfq_bridge.p must be int: {record!r}")
        for key in ("modulus", "a", "b"):
            value = record.get(key)
            if not isinstance(value, list) or not all(
                isinstance(c, int) for c in value
            ):
                raise FixtureError(f"gfq_bridge.{key} must be List[int]: {record!r}")
    elif kind == "gfqfield":
        if not isinstance(record.get("p"), int):
            raise FixtureError(f"gfqfield.p must be int: {record!r}")
        if not isinstance(record.get("zexp"), int):
            raise FixtureError(f"gfqfield.zexp must be int: {record!r}")
        for key in ("modulus", "a", "b"):
            seq = record.get(key)
            if not isinstance(seq, list) or not all(isinstance(x, int) for x in seq):
                raise FixtureError(f"gfqfield.{key} must be List[int]: {record!r}")
    elif kind == "rcf_sentence":
        _validate_rcf_sentence(record)
    elif kind == "result":
        if not isinstance(record.get("op"), str):
            raise FixtureError(f"result.op must be str: {record!r}")
        if "value" not in record:
            raise FixtureError(f"result.value missing: {record!r}")


def read_fixtures(source: str | Path | None = None) -> Iterator[dict[str, Any]]:
    """Yield validated JSONL records from ``source`` (path) or stdin.

    Blank lines and ``#``-prefixed comment lines are ignored so that
    the JSONL files stay diffable with optional human annotations.
    """
    if source is None:
        stream: Iterable[str] = sys.stdin
        close = False
    else:
        path = Path(source)
        stream = path.open("r", encoding="utf-8")
        close = True
    try:
        for lineno, raw in enumerate(stream, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                raise FixtureError(
                    f"{source or '<stdin>'}:{lineno}: invalid JSON ({exc})"
                ) from exc
            if not isinstance(record, dict):
                raise FixtureError(
                    f"{source or '<stdin>'}:{lineno}: expected JSON object"
                )
            _validate_fixture(record)
            yield record
    finally:
        if close:
            stream.close()  # type: ignore[union-attr]


def split_fixtures_results(
    records: Iterable[dict[str, Any]],
) -> tuple[dict[tuple[str, str], dict[str, Any]], list[dict[str, Any]]]:
    """Partition a JSONL stream into ``(cases_by_id, results)``.

    The ``cases_by_id`` map is keyed by ``(lib, case)`` so a result
    record can recover its input.  ``results`` preserves stream order
    so the oracle reports failures in the order Lean emitted them.
    """
    cases: dict[tuple[str, str], dict[str, Any]] = {}
    results: list[dict[str, Any]] = []
    for record in records:
        if record["kind"] == "result":
            results.append(record)
        else:
            cases[(record["lib"], record["case"])] = record
    return cases, results


def write_failure(
    failure_dir: str | Path,
    *,
    library: str,
    profile: str,
    seed: int,
    case_id: str,
    kind: str,
    input_record: dict[str, Any],
    lean_output: Any,
    oracle_output: Any,
    oracle_name: str,
    oracle_version: str,
    diff: str,
) -> Path:
    """Write a JSON failure record and return its path.

    The filename is ``<library>-<seed>-<case_id>.json`` so concurrent
    oracle runs against different libraries / seeds don't collide.
    """
    out_dir = Path(failure_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    record = {
        "library": library,
        "profile": profile,
        "seed": seed,
        "case_id": case_id,
        "kind": kind,
        "input": input_record,
        "lean_output": lean_output,
        "oracle_output": oracle_output,
        "oracle_name": oracle_name,
        "oracle_version": oracle_version,
        "diff": diff,
    }
    safe_case = case_id.replace("/", "_")
    out_path = out_dir / f"{library}-{seed}-{safe_case}.json"
    out_path.write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
    return out_path


def assert_equal(
    lean: Any,
    oracle: Any,
    *,
    library: str,
    case_id: str,
    kind: str,
    input_record: dict[str, Any],
    oracle_name: str,
    oracle_version: str,
    failure_dir: str | Path | None = None,
    profile: str = "ci",
    seed: int = 0,
) -> None:
    """Assert ``lean == oracle``; on mismatch write a failure record then raise.

    ``failure_dir`` defaults to the ``HEX_FAILURE_DIR`` environment
    variable, then to ``conformance-failures`` under the current
    working directory.
    """
    if lean == oracle:
        return
    target = (
        failure_dir
        if failure_dir is not None
        else os.environ.get("HEX_FAILURE_DIR", "conformance-failures")
    )
    diff = f"lean={lean!r} oracle={oracle!r}"
    path = write_failure(
        target,
        library=library,
        profile=profile,
        seed=seed,
        case_id=case_id,
        kind=kind,
        input_record=input_record,
        lean_output=lean,
        oracle_output=oracle,
        oracle_name=oracle_name,
        oracle_version=oracle_version,
        diff=diff,
    )
    raise OracleMismatch(
        f"{library}/{case_id} ({kind}): Lean and {oracle_name} disagree.\n"
        f"  diff: {diff}\n"
        f"  failure record: {path}"
    )
