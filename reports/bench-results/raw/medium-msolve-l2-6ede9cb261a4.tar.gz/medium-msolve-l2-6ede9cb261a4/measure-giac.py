from pathlib import Path
import sys,subprocess,json,hashlib,os,time,resource,signal,statistics,shutil
sys.path.insert(0,'/tmp/hex-groebner-scheduling-dev')
from scripts.bench.cpu_lease import cpu_lease
from scripts.oracle.groebner_singular import polynomial,canonical,expression
base=Path(__file__).resolve().parent;suite=Path('/tmp/hex-groebner-medium-suite/suite.json');plan=json.loads(suite.read_text());out=base/'giac-v20019-first';out.mkdir(exist_ok=False)
hex=Path('/tmp/hex-groebner-scheduling-strengthened-production/binaries/compute');gamba=Path('/nix/store/xkfhlsq62bga859gfqras4qz9qjgcxj6-giac-2.0.0-19/bin/giac');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads(Path('/tmp/hex-groebner-scheduling-strengthened-production/manifest.json').read_text());assert sha(hex)==manifest['binary_sha256']['compute'];inputs=out/'inputs';shutil.copytree(suite.parent,inputs)
for case in plan['cases']:
 payload=json.loads((inputs/(case['name']+'.json')).read_text());cas='threads(1);\nthreads();\nB:=gbasis(['+','.join(expression(f) for f in payload['generators'])+'] % '+str(case['p'])+',['+','.join(f'x{i}' for i in range(case['variables']))+'],revlex):;\nB;\n';(inputs/(case['name']+'.cas')).write_text(cas)
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
meta=dict(source_fingerprint=manifest['source_fingerprint'],manifest=manifest,hex_sha256=sha(hex),gamba_sha256=sha(gamba),comparator='Giac 2.0.0-19 Nix package',library_sha256=sha(Path('/nix/store/xkfhlsq62bga859gfqras4qz9qjgcxj6-giac-2.0.0-19/lib/libgiac.so.0.0.0')),cpu=cpu,host=os.uname().nodename,load_start=os.getloadavg(),threads=1,gamba_seed=42,contract='Full reduced grevlex outputs, matched fields and generators; Hex deterministic unchecked candidate vs Giac default gbasis. One process per arm under identical GNU time wrappers; launch/parse/full output included. Giac calls threads(1), records threads() acknowledgment 1, then gbasis modulo p and prints the complete vector; startup maximum-thread banner and diagnostics remain. All samples/failures/timeouts retained, no probability/certification/kernel or acceptance claim. Adjacent AB then BA; one leased CPU, one algorithm thread',schedule=['AB','BA'],samples=[])
def cap():
 os.setsid();resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2);resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,)*2)
try:
 for block,order in enumerate(['AB','BA']):
  for case in plan['cases']:
   outputs={};indexes=[]
   for arm in order:
    name=f"{case['name']}-b{block}-{arm}";rss=out/(name+'.rss');basis=out/(name+'.basis')
    program=[str(hex),'--scheduling','degree','--work','100000000000','--packed-bytes',str(16*1024**3),'--pairs','100000000','--monomials','10000000','--matrix-entries','1000000000',str(inputs/(case['name']+'.json'))] if arm=='A' else [str(gamba),str(inputs/(case['name']+'.cas'))]
    command=['/run/current-system/sw/bin/time','-f','%M','-o',str(rss),*program];start=time.monotonic_ns();timeout=False
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
     proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env,preexec_fn=cap)
     try:proc.wait(timeout=60)
     except subprocess.TimeoutExpired:timeout=True;os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    record=dict(case=case['name'],family=case['family'],p=case['p'],block=block,arm=arm,command=command,wall_nanos=time.monotonic_ns()-start,returncode=proc.returncode,status='timeout' if timeout else 'ok' if proc.returncode==0 else 'failed',peak_rss_kib=int(rss.read_text().splitlines()[-1]) if rss.exists() and rss.read_text().splitlines()[-1].isdigit() else None)
    if record['status']=='ok':
     try:
      if arm=='A':
       payload=json.loads((out/(name+'.stdout')).read_text());assert payload['kind']=='unchecked_candidate' and payload['scheduling']=='degree';assert [payload[k] for k in ['p','variables','order']]==[case['p'],case['variables'],'grevlex'];outputs[arm]=canonical(payload['basis']);record['statistics']=payload['statistics'];record['candidate_nanos']=payload['candidateNanos']
      else:
       text=(out/(name+'.stdout')).read_text();lines=text.splitlines();assert lines[:2]==['1,','1,'],'Giac did not acknowledge/query one thread'
       vectors=[line.strip() for line in lines if line.startswith('[')];assert len(vectors)==1,'expected one complete Giac vector'
       outputs[arm]=sorted(p for p in [polynomial(f,case['variables'],case['p']) for f in vectors[0].strip('[],').split(',') if f.strip()] if p)
     except (ValueError,AssertionError,KeyError,IndexError) as e:record.update(status='invalid_output',error=repr(e))
    indexes.append(len(meta['samples']));meta['samples'].append(record);print(name,record['status'],round(record['wall_nanos']/1e6,2),flush=True)
   equal=len(outputs)==2 and outputs['A']==outputs['B']
   for i in indexes:meta['samples'][i]['complete_basis_equal']=equal
   if len(outputs)==2 and not equal:
    for i in indexes:meta['samples'][i]['status']='basis_mismatch'
finally:
 meta.update(load_end=os.getloadavg(),hex_sha256_after=sha(hex),gamba_sha256_after=sha(gamba));assert meta['hex_sha256']==meta['hex_sha256_after'] and meta['gamba_sha256']==meta['gamba_sha256_after'];(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');shutil.copy2(__file__,out/'measure-giac.py');lease.close()
groups={}
for r in meta['samples']:groups.setdefault((r['case'],r['block']),{})[r['arm']]=r
ratios=[];families={}
for pair in groups.values():
 a,b=pair['A'],pair['B']
 if a['status']==b['status']=='ok' and a['complete_basis_equal']:
  r=a['wall_nanos']/b['wall_nanos'];ratios.append(r);families.setdefault(a['family'],[]).append(r)
summary=dict(cpu=cpu,ratio_direction='Hex/Giac process',complete_basis_pairs=len(ratios),samples=len(meta['samples']),failed_samples=sum(s['status']!='ok' for s in meta['samples']),geomean=statistics.geometric_mean(ratios) if ratios else None,median=statistics.median(ratios) if ratios else None,minimum=min(ratios) if ratios else None,maximum=max(ratios) if ratios else None,per_family={f:statistics.geometric_mean(v) for f,v in families.items()},peak_rss_kib={a:max(r['peak_rss_kib'] or 0 for r in meta['samples'] if r['arm']==a) for a in ['A','B']})
if len(families)==7:summary['family_balanced_geomean']=statistics.geometric_mean(summary['per_family'].values())
(out/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));raise SystemExit(1 if summary['failed_samples'] or len(ratios)!=28 else 0)
