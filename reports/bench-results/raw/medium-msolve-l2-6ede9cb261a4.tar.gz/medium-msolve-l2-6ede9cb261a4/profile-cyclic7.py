from pathlib import Path
import subprocess,os,sys,json,hashlib
sys.path.insert(0,'/tmp/hex-groebner-scheduling-dev')
from scripts.bench.cpu_lease import cpu_lease
base=Path('/tmp/hex-groebner-medium-results/profile-cyclic7-degree');base.mkdir(exist_ok=False)
exe=Path('/tmp/hex-groebner-scheduling-strengthened-production/binaries/compute');input=Path('/tmp/hex-groebner-medium-suite/cyclic7-31.json');cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
batch=base/'batch.py';batch.write_text('''from pathlib import Path
import subprocess,json
base=Path(__file__).resolve().parent
for i in range(8):
 with (base/f'run-{i}.stdout').open('w') as o,(base/f'run-{i}.stderr').open('w') as e:
  r=subprocess.run(['''+repr(str(exe))+''','--scheduling','degree','--work','100000000000','--matrix-entries','1000000000','--packed-bytes','17179869184','''+repr(str(input))+'''],stdout=o,stderr=e)
 assert r.returncode==0
''')
cmd=['perf','record','-F','1999','-e','cycles:u','--call-graph','dwarf','-o',str(base/'cyclic7.perf'),'--',sys.executable,str(batch)]
meta=dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=os.getloadavg(),binary_sha256=sha(exe),input_sha256=sha(input),source_fingerprint='0cb80bf73a4a',command=cmd,scope='One explanatory profile after a roughly 5x cyclic7 msolve process gap. Eight outputs retained; profiler overhead makes this unsuitable as scientific timing evidence. All completed runs retained, no unchanged profile repeat. Flat user-cycle symbols only; no causal compiler-limit claim.')
try:
 with (base/'perf.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 meta['returncode']=r.returncode
 if r.returncode==0:
  outputs=[json.loads((base/f'run-{i}.stdout').read_text()) for i in range(8)];reference={k:v for k,v in outputs[0].items() if k!='candidateNanos'};assert all({k:v for k,v in a.items() if k!='candidateNanos'}==reference for a in outputs);meta['complete_outputs_equal']=8
  for name,args in [('flat-symbols.txt',['--no-children','--call-graph','none']),('symbols.txt',[])]:
   with (base/name).open('w') as log:subprocess.run(['perf','report','-i',str(base/'cyclic7.perf'),'--stdio','--sort','symbol',*args],stdout=log,stderr=subprocess.STDOUT,check=True)
finally:
 meta['load_end']=os.getloadavg();(base/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');lease.close()
raise SystemExit(meta['returncode'])
