#include <stdio.h>
int main(void) {volatile unsigned x=1,n=32;printf("%u\n",x<<n);return 0;}
