from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
s=Path('/home/kim/tmp/issue-10987');out=Path('/dev/shm/issue-10987-klyz31-matrix-shapes');out.mkdir(exist_ok=False);(out/'frames').mkdir()
helper=s/'lazy-hardened-production/root-sources/scripts/bench/cpu_lease.py';spec=importlib.util.spec_from_file_location('shape_cpu_lease',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
cpu,lease=module.cpu_lease();os.sched_setaffinity(0,{cpu});binary=s/'klyz31-shape-probe/.lake/build/bin/usage';input_path=s/'fixed-corpus-v2-cli-validated/KLYZ12-31.json';suite=json.loads((s/'fixed-corpus-v2-cli-validated/suite.json').read_text());options=[part for k,v in suite['protocol']['hex_limits'].items()for part in ['--'+k,str(v)]]
command=[str(binary),*options,'--scheduling','degree','--binary-pivots','true','--dense-pivots','false',str(input_path)];start=os.getloadavg();record={};sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
try:
 env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',HEX_F4_MATRIX_SHAPES=str(out/'shapes.jsonl'),HEX_F4_MATRIX_DUMPS=str(out/'frames'))
 with(out/'stdout').open('w')as stdout,(out/'stderr').open('w')as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,env=env)
 record=dict(command=command,exit_code=r.returncode)
 if r.returncode:raise RuntimeError(r.returncode)
 actual=json.loads((out/'stdout').read_text());expected=json.loads(Path('/dev/shm/issue-10987-thirdparty-giac-validated-v2/KLYZ12-31-b0-A.stdout').read_text())
 a={k:v for k,v in actual.items()if k!='candidateNanos'};b={k:v for k,v in expected.items()if k!='candidateNanos'};assert a==b,'instrumented producer differs outside timing'
 record['complete_basis_and_statistics_equal']=True
finally:
 (out/'metadata.json').write_text(json.dumps(dict(cpu=cpu,threads=1,host=os.uname().nodename,load_start=start,load_end=os.getloadavg(),run=record,binary_sha256=sha(binary),input_sha256=sha(input_path),probe_sha256=sha(s/'klyz31-shape-probe/probe.c'),scope='Instrumented shape/work capture and replay inputs, not timing. Uses the retained ordinary-prime diagnostic probe. Full output and every non-time field must equal the measured producer. Native accepted and continued matrices log exactly once on successful completion. Progressive maximum-entry input dumps are all retained.'),indent=2)+'\n');lease.close()
(out/'collector.py').write_bytes(Path(__file__).read_bytes());(out/'probe.c').write_bytes((s/'klyz31-shape-probe/probe.c').read_bytes())
