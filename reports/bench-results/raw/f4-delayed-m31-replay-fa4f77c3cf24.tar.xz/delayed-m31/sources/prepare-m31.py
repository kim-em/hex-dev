from pathlib import Path
s=Path('/home/kim/tmp/issue-10987');src=s/'matrix-replay-frozen-v2';out=s/'matrix-replay';t=(src/'delayed.c').read_text();t=t.replace('p<3 || p>65536 ||','p<65537 || p>=UINT64_C(2147483648) ||')
a='    if(c.columns && (p-1)*(p-1)>(UINT64_MAX-(p-1))/c.columns) goto defer;';assert a in t;t=t.replace(a,'    /* Each update stays below 2*p^2 < 2^63 and reduces modulo p^2. */')
a='''        if(c->width==2) {''';assert a in t;t=t.replace(a,'''        if(c->width==4) {
            coefficients=_mm256_cvtepu32_epi64(_mm_loadu_si128(
                (const __m128i_u*)(pivot->coefficients+(size_t)j*4)));
        } else if(c->width==2) {''',1)
a='    __m256i factors=_mm256_set1_epi64x((long long)factor);';assert a in t;t=t.replace(a,a+'''
    uint64_t modulus_squared=c->p*c->p;
    __m256i modulus=_mm256_set1_epi64x((long long)modulus_squared);
    __m256i threshold=_mm256_set1_epi64x((long long)(modulus_squared-1));''')
a='        __m256i updated=_mm256_add_epi64(current,products);';assert a in t;t=t.replace(a,a+'''
        /* Both summands are <p^2. Signed comparison is exact below 2^63. */
        updated=_mm256_sub_epi64(updated,_mm256_and_si256(
            _mm256_cmpgt_epi64(updated,threshold),modulus));''')
a='        delayed_write(c,k,delayed_read(c,k)+factor*b);';assert t.count(a)==2;t=t.replace(a,'''        uint64_t value=delayed_read(c,k)+factor*b;
        if(value>=modulus_squared) value-=modulus_squared;
        delayed_write(c,k,value);''')
a='        uint64_t factor=c->p-a;';assert a in t;t=t.replace(a,a+'\n        uint64_t modulus_squared=c->p*c->p;')
a='''/* Each head is visited once. Thus each cell receives at most columns
   additions <=(p-1)^2, within the explicitly checked UInt64 bound. */''';assert a in t;t=t.replace(a,'''/* Residues modulo p^2 preserve residues modulo p. Initially acc<p^2;
   one product is <p^2, so one subtraction restores acc<p^2 without overflow. */''');(out/'delayed.c').write_text(t)
t=(src/'Replay.lean').read_text().replace('p < 3 || p > 65536','p < 65537 || p ≥ 2^31');(out/'Replay.lean').write_text(t)
(out/'prepare-m31.py').write_bytes(Path(__file__).read_bytes())
print('Private mod-p-squared prototype prepared; immutable v1/v2 unchanged')
