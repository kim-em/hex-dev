from pathlib import Path
import hashlib,io,json,tarfile
s=Path('/home/kim/tmp/issue-10987');base=s/'matrix-replay-frozen-m31-v1';files={}
def add(name,path):files[name]=Path(path).read_bytes()
def tree(prefix,path):
 for p in sorted(Path(path).rglob('*')):
  if p.is_file():add(prefix+'/'+str(p.relative_to(path)),p)
for p in sorted(base.iterdir()):
 if p.is_file()and p.name!='replay':add('sources/'+p.name,p)
tree('measurements',Path('/dev/shm/issue-10987-delayed-replay-m31-v1'));tree('checks/random',Path('/dev/shm/issue-10987-delayed-m31-random-v1'));tree('checks/small',s/'replay-m31-small-v1');add('inputs/frame-000033.bin.xz',s/'delayed-m31-frame33.bin.xz');add('inputs/selected.json',s/'selected-m31-frame.json')
for name in ['metadata.json','probe.c','collector.py','shapes.jsonl']:
 add('capture/'+name,Path('/dev/shm/issue-10987-klyz31-matrix-shapes')/name)
raw=Path('/dev/shm/issue-10987-klyz31-matrix-shapes/frames/frame-000033.bin');files['scope.json']=(json.dumps(dict(scope='Private prime-square matrix replay. Four initial AB/BA observations with C monotonic provider timing and complete reference comparison outside timing. No unchanged repeat, whole-system or leadership claim. Selected highest-work frame among progressive-entry-maximum dumps; absolute highest-work frame was not dumped.',input_sha256=hashlib.file_digest(raw.open('rb'),'sha256').hexdigest(),input_bytes=raw.stat().st_size),indent=2)+'\n').encode();add('pack-script.py',Path(__file__));files['sha256.json']=(json.dumps({n:hashlib.sha256(v).hexdigest()for n,v in sorted(files.items())},indent=2)+'\n').encode();out=s/'f4-delayed-m31-replay-fa4f77c3cf24.tar.xz';assert not out.exists()
with tarfile.open(out,'w:xz',preset=1)as archive:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo('delayed-m31/'+name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
print(out,hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),out.stat().st_size)
