/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

public import HexGroebner.Runtime

public section

namespace Hex.Groebner

/-- A matrix column map. Dense identifier intervals use packed u32 positions
plus one; sparse intervals retain the hash map. Zero denotes absence. -/
inductive ColumnMap where
  | packed (positions : ByteArray)
  | hashed (positions : Std.HashMap Nat Nat)

namespace ColumnMap

@[inline] def get? (positions : @& ColumnMap) (id : Nat) : Option Nat :=
  match positions with
  | .hashed positions => positions[id]?
  | .packed positions =>
    if id >= positions.size / 4 then none else
    let value := (Packed.read .u32 positions id).toNat
    if value == 0 then none else some (value - 1)

@[inline] def getD (positions : @& ColumnMap) (id fallback : Nat) : Nat :=
  (positions.get? id).getD fallback

/-- Build a column map with at most eight packed slots per column. Initialization
and all packed payload are charged before allocation. If the extra packed
workspace does not fit the remaining allowances, retain the hash-map route.
Repeated identifiers keep the final position, as for `HashMap.insert`. -/
def build (limits : Limits) (columns : Array Nat) : Computation ColumnMap := do
  Computation.spend limits columns.size
  let count := columns.foldl (fun count id => max count (id + 1)) 0
  let s ← get
  if columns.size < 4294967296 && count <= columns.size * 8 && count * 4 < USize.size &&
      s.statistics.work + count + columns.size <= limits.work &&
      s.statistics.allocatedBytes + s.table.bytes + count * 4 <= limits.packedBytes then
    Computation.spend limits (count + columns.size)
    Computation.allocate limits (count * 4)
    let mut positions := ByteArray.emptyWithCapacity (count * 4)
    for _ in [:count * 4] do positions := positions.push 0
    for i in [:columns.size] do
      positions := Packed.set .u32 positions columns[i]! (i + 1).toUInt64
    return .packed positions
  else
    Computation.spend limits columns.size
    let mut positions : Std.HashMap Nat Nat := {}
    for i in [:columns.size] do positions := positions.insert columns[i]! i
    return .hashed positions

end ColumnMap
end Hex.Groebner
