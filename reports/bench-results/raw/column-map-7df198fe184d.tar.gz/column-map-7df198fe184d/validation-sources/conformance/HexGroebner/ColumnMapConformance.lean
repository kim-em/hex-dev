/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

import HexGroebner.ColumnMap

namespace Hex.Groebner.ColumnMapConformance

/-- Compare packed and sparse identifier ranges, repeated IDs and absent IDs
against an independently populated hash map, across exact resource boundaries. -/
def checks (seed : Nat) : Bool := Id.run do
  for columns in [#[],#[0],#[0,1,2],#[4,1,4,0],#[7],#[8],#[4294967295],
      #[2^80],(Array.range 257).map fun i => (i * 17 + seed) % 257] do
    let mut expected : Std.HashMap Nat Nat := {}
    for i in [:columns.size] do expected := expected.insert columns[i]! i
    for work in [0,1,2,3,10,100,1000,10000] do
      for bytes in [0,1,3,4,8,31,32,33,100,10000] do
        let limits : Limits := { work, packedBytes := bytes }
        let workspace : Workspace := { table := { arity := 0 } }
        let (result,state) := (ColumnMap.build limits columns).run workspace
        if state.statistics.work > work || state.statistics.allocatedBytes > bytes then
          return false
        match result with
        | .error (.exhausted .work) => pure ()
        | .error _ => return false
        | .ok positions =>
          for id in [0,1,2,3,4,7,8,257,4294967295,2^80] ++ columns.toList do
            if positions.get? id != expected[id]? then return false
  let workspace : Workspace := { table := { arity := 0 } }
  let (result,_) := (ColumnMap.build {} #[0,2,1]).run workspace
  let .ok (.packed _) := result | return false
  let (result,_) := (ColumnMap.build {} #[2^80]).run workspace
  let .ok (.hashed _) := result | return false
  let (result,_) := (ColumnMap.build { packedBytes := 0 } #[0,2,1]).run workspace
  let .ok (.hashed _) := result | return false
  return true

#guard checks 0

end Hex.Groebner.ColumnMapConformance
