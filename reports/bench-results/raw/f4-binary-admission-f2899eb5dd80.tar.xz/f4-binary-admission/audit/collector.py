from pathlib import Path
import os,json,subprocess,hashlib,csv,sys
s=Path('/home/kim/tmp/issue-10987');sys.path.insert(0,str(Path.cwd()))
from scripts.bench.groebner_checks import source_identity
identity=source_identity();root=s/'binary-review-fixed-verified-clang';out=s/'binary-pr30-admission';out.mkdir(exist_ok=False);source=s/'binary-blocks-production/f2-false';meta=json.loads((source/'metadata.json').read_text());rows=[]
loader='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2';lib='/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib';asan='/nix/store/b6zf36m0kmbhml6082yjcabv89n3zp2m-clang-wrapper-23.1.3/resource-root/lib/linux/libclang_rt.asan-x86_64.so';binary=root/'.lake/build/bin/usage';fields=['columns','reducers','targets','entries','reason','byteUpper','byteAllowance']
for sample in meta['samples']:
 if sample['arm']!='B' or sample['block']!=0:continue
 assert source_identity()==identity
 case=sample['case'];flags=sample['command'][sample['command'].index(str(s/'binary-blocks-production/binaries/compute'))+1:];inp=out/(case+'.input.json');inp.write_bytes(Path(flags[-1]).read_bytes());flags[-1]=str(inp);cmd=[loader,'--library-path',lib,'--preload',asan,str(binary),*flags];records=out/(case+'.frames.csv');assert not records.exists()
 env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1',HEX_GROEBNER_FRAME_LOG=str(records))
 r=subprocess.run(cmd,capture_output=True,text=True,env=env);(out/(case+'.stdout')).write_text(r.stdout);(out/(case+'.stderr')).write_text(r.stderr);assert r.returncode==0,(case,r.stderr)
 value=json.loads(r.stdout);before=json.loads((source/f'{case}-b0-B.stdout').read_text());assert value['basis']==before['basis'] and value['statistics']==before['statistics']
 frames=list(csv.DictReader(records.read_text().splitlines(),fieldnames=fields))if records.exists()else[]
 for frame in frames:
  for key in fields:
   if key!='reason':frame[key]=int(frame[key])
 counts=json.loads(r.stderr.splitlines()[-1]);assert sum(f['reason']=='accepted'for f in frames)==int(counts['bulkAccepted']);assert sum(f['reason']!='accepted'for f in frames)==int(counts['bulkDeclined'])
 rows.append(dict(case=case,family=sample['family'],command=cmd,exit_code=r.returncode,counts=counts,frames=frames,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),complete_basis_and_statistics_equal=True))
 assert source_identity()==identity
(out/'status.json').write_text(json.dumps(dict(identity=identity,fields=fields,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),probe_sha256=hashlib.sha256((root/'probe.c').read_bytes()).hexdigest(),scope='Non-timed admission audit. Instrumented Clang23 executable, same inputs/flags and complete bases/statistics as timed zero-block candidate. Production native C21 timing remains separate.',samples=rows),indent=2)+'\n');(out/'collector.py').write_bytes(Path(__file__).read_bytes())
for row in rows:print(row['case'],len(row['frames']),sum(f['reason']=='accepted'for f in row['frames']))
