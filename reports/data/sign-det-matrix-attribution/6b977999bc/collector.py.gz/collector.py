from pathlib import Path
import hashlib,json,os,platform,subprocess,sys
root=Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10377-matrix-wide')
sys.path.insert(0,str(root))
from scripts.bench.cpu_lease import cpu_lease
from scripts.bench.sign_det_sparse import source_hashes
out=Path('/home/kim/.local/state/hex/issue-10377-session-progress/matrix-check-attribution-6b977999bc')
out.mkdir(exist_ok=False)
exe=root/'.lake/build/bin/hexsigndet_bench'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
status=lambda:subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
assert revision=='6b977999bc5b4008cea31ce4f9edfbe1bc3c6658' and not status()
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu})
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta={'schema':'hex-matrix-check-attribution-v1','revision':revision,'cpu':cpu,'host':platform.node(),
 'binary_sha256':sha(exe),'source_sha256':source_hashes(),'collector_sha256':sha(Path(__file__)),
 'load_before':os.getloadavg(),'scope':'representative sampling attribution only; no scaling verdict or new scientific timing samples',
 'state':'running','captures':[]}
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
try:
 for r in [243,729]:
  target=out/str(r);target.mkdir()
  command=[str(exe),'profile','Hex.SignDetBench.MaximalMatrix.runTensorCheck','--param',str(r),
   '--cache-mode','cold','--profiler',f'perf record --clockid mono -e cycles:u -F 2000 --call-graph dwarf -o {target}/perf.data --']
  env=dict(os.environ,LEAN_BENCH_TIMED_REGIONS_SIDECAR=str(target/'regions-%p.jsonl'))
  save()
  with (target/'profile.log').open('w') as log:
   subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  rows=[json.loads(line) for line in (target/'profile.log').read_text().splitlines() if line.startswith('{')]
  assert len(rows)==1;row=rows[0]
  assert row['status']=='ok' and row['result_hash']=='0xb' and row['profile_kernel'] is True
  assert row['inner_repeats']==1 and row['param']==r and row['env']['git_commit']==revision and row['env']['git_dirty'] is False
  regions=[json.loads(line) for file in target.glob('regions-*.jsonl') for line in file.read_text().splitlines()
           if json.loads(line).get('kind')=='region' and json.loads(line).get('label')=='kernel']
  assert len(regions)==1
  with (target/'perf-script.txt').open('w') as log:
   subprocess.run(['perf','script','--ns','--no-demangle','-i',str(target/'perf.data'),'-F','pid,tid,time,ip,sym,dso'],stdout=log,check=True)
  meta['captures'].append({'parameter':r,'command':command,'profile_row':row,'region':regions[0],'load_after':os.getloadavg()});save()
 meta['state']='complete'
finally:
 meta['provenance_unchanged']=sha(exe)==meta['binary_sha256'] and source_hashes()==meta['source_sha256'] and not status()
 save();lease.close()
 assert meta['provenance_unchanged']
print(out)
