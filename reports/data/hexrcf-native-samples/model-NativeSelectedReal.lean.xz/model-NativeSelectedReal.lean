import HexRCF.NativeSamplesConformance
import HexRealClosureMathlib.NativeRealization
import HexRealClosure.SharedPresentation

namespace NativeSelectedReal
open Hex Hex.RealClosure Hex.RealClosure.Tower
open Hex.RCF.RealCoefficients Hex.RCF.SelectedRootTests
open Hex.RealFormula
open scoped HexMvPolyMathlib

abbrev sample := NativeSamplesConformance.Nested.sample
abbrev context := sample.input.context

private theorem originBase : context.origin.base =
    BaseContext.PackedContext.pack (BaseContext.rational Data.registry) := by
  change (Data.parent.adjoin Upper.root).context.origin.base = _
  rw [Context.origin_adjoin, Origin.snoc_base, ← Data.parent_eq]
  change (Data.base.adjoin Data.lower).context.origin.base = _
  rw [Context.origin_adjoin, Origin.snoc_base]
  change (Context.base (BaseContext.rational Data.registry)).origin.base = _
  rw [Context.origin_base]
  rfl

noncomputable def following : context.origin.base.Realization := by
  rw [originBase]
  change (BaseContext.Chain.real (.base (registry := Data.registry))).Realization Data.registry
  exact .real .base (BaseContext.RealChain.interpretBase Data.registry) .base

def joint : RealFormula.QF 2 :=
  let c : RealFormula.Poly 2 := MvPoly.X 0
  .and (.atom ⟨c^2-2, .eq⟩) (.and (.atom ⟨c-1, .gt⟩)
    (.and (.atom ⟨c-2, .lt⟩) Upper.schema))

theorem source_row : sample.signs (RepresentationSpecialize.prepare Upper.values joint) =
    [0, 1, -1, 0, 1, -1] := by
  let conversion := NativeSamplesConformance.Nested.conversion
  rw [Tower.Sample.signs_correct sample Data.original conversion]
  have evaluations := congrArg (List.map (fun x : ℝ => (SignType.sign x : Int)))
    (RepresentationSpecialize.prepare_eval Data.original.value Data.original.zero_iff
      Data.original.one Data.original.add Data.original.mul Data.original.nat Data.original.neg
      Upper.values joint (conversion.target.value sample.value))
  simp only [List.map_map, Function.comp_def, RepresentationSpecialize.evaluate] at evaluations
  rw [evaluations, NativeSamplesConformance.Nested.point]
  have square := CatalogSource.source.1
  have above := CatalogSource.source.2.1
  have below := CatalogSource.source.2.2
  have lower : 1 < Real.sqrt (2 : ℝ) := by
    rw [← Data.selectedSqrt]
    exact Data.selectedFacts.2.1
  have upper : Real.sqrt (2 : ℝ) < 2 := by
    rw [← Data.selectedSqrt]
    exact Data.selectedFacts.2.2
  dsimp only [joint, Upper.schema, RealFormula.QF.polys, RealFormula.QF.polys.go, RealFormula.Poly.eval]
  simp_rw [← HexMvPolyMathlib.eval₂_toMvPolynomial]
  simp [HexMvPolyMathlib.toMvPolynomial_X, HexMvPolyMathlib.toMvPolynomial_sub,
    HexMvPolyMathlib.toMvPolynomial_pow, HexMvPolyMathlib.toMvPolynomial_one,
    RealFormula.append, Upper.values, Data.alpha_value, square,
    show (2 : RealFormula.Poly 2) = MvPoly.C 2 from rfl,
    Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2),
    _root_.sign_pos (show 0 < Real.sqrt 2 - 1 by linarith),
    _root_.sign_neg (show Real.sqrt 2 - 2 < 0 by linarith),
    _root_.sign_pos (show 0 < CatalogSource.selected.denote Data.original - 1 by linarith),
    _root_.sign_neg (show CatalogSource.selected.denote Data.original - 2 < 0 by linarith)]

theorem truth : Samples.Row.eval joint (NativeSpecialize.row context
    (sample.input.value ∘ Upper.values) sample.value joint) = some true := by
  rw [← NativeSamples.row_converted Data.original sample
    NativeSamplesConformance.Nested.conversion, source_row]
  decide +kernel

/-- The coefficient's selected real identity and the upper sample are established
jointly at the same finite reader; no inherited-base identity for alpha is assumed. -/
theorem source_real : ∃ x : ℝ, x ^ 2 = Real.sqrt 2 ∧ 1 < x ∧ x < 2 := by
  obtain ⟨read, domain, closed, negative, members, present, guards, sizes, signs, fixed⟩ :=
    NativeSpecialize.row_real context following (sample.input.value ∘ Upper.values)
      sample.value joint
  have meaning := (Samples.Row.eval_true joint _ _ signs).mp truth
  dsimp only [joint, Upper.schema, RealFormula.QF.toProp,
    RealFormula.Atom.toProp, RealFormula.Cmp.toProp] at meaning
  unfold RealFormula.Poly.eval at meaning
  simp_rw [← HexMvPolyMathlib.eval₂_toMvPolynomial] at meaning
  have facts : (read (sample.input.value Data.alpha)) ^ 2 = 2 ∧
      1 < read (sample.input.value Data.alpha) ∧ read (sample.input.value Data.alpha) < 2 ∧
      (read sample.value) ^ 2 = read (sample.input.value Data.alpha) ∧
      1 < read sample.value ∧ read sample.value < 2 := by
    simpa [HexMvPolyMathlib.toMvPolynomial_X, HexMvPolyMathlib.toMvPolynomial_sub,
      HexMvPolyMathlib.toMvPolynomial_pow, HexMvPolyMathlib.toMvPolynomial_one,
      show (2 : RealFormula.Poly 2) = MvPoly.C 2 from rfl, RealFormula.append,
      Upper.values, Function.comp_def, sub_eq_zero, sub_pos, sub_lt_zero] using meaning
  have selected : read (sample.input.value Data.alpha) = Real.sqrt 2 := by
    nlinarith [facts.1, facts.2.1, Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2), Real.sqrt_nonneg (2 : ℝ)]
  refine ⟨read sample.value, ?_, facts.2.2.2.2.1, facts.2.2.2.2.2⟩
  exact facts.2.2.2.1.trans selected

/-- info: 'NativeSelectedReal.source_real' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms source_real
#print axioms following
end NativeSelectedReal
