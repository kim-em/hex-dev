module
public import HexRCF.RealCoefficients.NativeSpecialize
public section
namespace Hex.RCF.RealCoefficients.NativeSources
open Hex Hex.RealClosure Hex.RealClosure.Tower Hex.RealFormula

/-- Realize coefficient selection and the matrix together. A proved unique
selection identifies every coefficient at that same reader, including selected
algebraic suffix coordinates. This is a point law with an explicit selection
proof, not a frozen context checker or cell coverage theorem. -/
theorem true_real (context : Context registry) (following : context.origin.base.Realization)
    (values : Fin n → context.Value) (source : Fin n → ℝ)
    (selection : RealFormula.QF n)
    (unique : ∀ coefficients : Fin n → ℝ, selection.toProp coefficients → coefficients = source)
    (sample : context.Value) (formula : RealFormula.QF (n+1)) (guards : List context.Value)
    (nonzero : ∀ a ∈ guards, context.sign a ≠ 0)
    (truth : Samples.Row.eval (.and selection.lift formula)
      (NativeSpecialize.row context values sample (.and selection.lift formula)) = some true) :
    ∃ read : context.Value → ℝ, ∃ domain : context.Value → Prop,
      Transport.Closed read domain ∧
      (∀ a, domain a → domain (-a) ∧ read (-a) = -read a) ∧
      (∀ i, domain (values i) ∧ read (values i) = source i) ∧ domain sample ∧
      (∀ q ∈ formula.polys,
        (RepresentationSpecialize.polynomial source q).size =
          (RepresentationSpecialize.polynomial values q).size) ∧
      formula.toProp (RealFormula.append source (read sample)) ∧
      (∀ a ∈ guards, domain a ∧ read a ≠ 0) ∧
      (∀ a r, context.origin.RealValue following a r → domain a ∧ read a = r) := by
  obtain ⟨read, domain, closed, negative, members, present, guardSigns, sizes, signs, fixed⟩ :=
    NativeSpecialize.row_real context following values sample (.and selection.lift formula) guards
  have meaning := (Samples.Row.eval_true (.and selection.lift formula) _ _ signs).mp truth
  change selection.lift.toProp (RealFormula.append (read ∘ values) (read sample)) ∧
    formula.toProp (RealFormula.append (read ∘ values) (read sample)) at meaning
  have same := unique (read ∘ values)
    ((selection.lift_correct (read ∘ values) (read sample)).mp meaning.1)
  refine ⟨read, domain, closed, negative, ?_, present, ?_, ?_, ?_, fixed⟩
  · intro i
    exact ⟨members i, congrFun same i⟩
  · intro q hq
    have present := sizes q (by rw [RealFormula.QF.polys_and]; exact List.mem_append_right _ hq)
    simpa only [same] using present
  · simpa only [same] using meaning.2
  · intro a member
    obtain ⟨ha, sign⟩ := guardSigns a member
    refine ⟨ha, ?_⟩
    intro zero
    apply nonzero a member
    simpa only [zero, sign_zero, SignType.coe_zero] using sign.symm
end Hex.RCF.RealCoefficients.NativeSources
