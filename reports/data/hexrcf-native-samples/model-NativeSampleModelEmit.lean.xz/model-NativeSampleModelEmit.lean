module
public import HexRealClosure.TowerContext
public import HexSignDet.Descriptor
public import HexRealClosure.BaseInclusion
public meta import HexRealClosure.TowerContext
public meta import HexSignDet.Descriptor
public meta import HexRealClosure.BaseInclusion
import all HexRealClosure.BaseContext
public section
namespace NativeSampleModelEmit
open Hex Hex.RealClosure Hex.RealClosure.Tower
private def registry : BaseContext.Registry := fun _ => none
private abbrev staged := (BaseContext.rational registry).infinitesimal
private abbrev context := Context.base staged
private def parameter : context.Value :=
  Context.baseValue (BaseContext.PackedContext.pack staged) RationalFn.X
private def raw : Hex.SignDet.RawDescriptor context.Value Signature :=
  ⟨context.signature, DensePoly.ofCoeffs #[-parameter, 0, 1], .finite 0, .finite 1, [1, 2], [1, 1]⟩
private def root? := Hex.SignDet.Descriptor.validate context.sign context.signature raw
#eval (show IO Unit from do
  match root? with
  | none => throw (IO.userError "owner descriptor producer rejected")
  | some d =>
    IO.FS.writeBinFile "/home/kim/.codex/tasks/hex-10358/native-sample-model-pure-root.json"
      ((Tower.rootData context.codec d).writeBytes))
end NativeSampleModelEmit
