import HexRCF.NativeSamplesConformance
import HexRCF.Tactic

namespace NativeSamplesOrdinaryUse
open Hex.RCF.RealCoefficients.NativeSamplesConformance
open Hex.RCF.RealCoefficients

theorem typical :
    NativeSpecialize.row sample.input.context (sample.input.value ∘ values) sample.value formula =
      [0, 0, 0, 1, -1, -1] := native_row

theorem empty :
    NativeSpecialize.row sample.input.context (sample.input.value ∘ values)
      sample.value (.tt : Hex.RealFormula.QF 3) = [] := empty_row

theorem changed :
    NativeSpecialize.row sample.input.context (sample.input.value ∘ wrongValues)
      sample.value formula ≠
    NativeSpecialize.row sample.input.context (sample.input.value ∘ values)
      sample.value formula := changed_row

/-- info: 'NativeSamplesOrdinaryUse.typical' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms typical
/-- info: 'NativeSamplesOrdinaryUse.empty' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms empty
/-- info: 'NativeSamplesOrdinaryUse.changed' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms changed

theorem sizes :
    (RepresentationSpecialize.prepare (sample.input.value ∘ values) formula).map (fun p => p.size) =
      (RepresentationSpecialize.prepare values formula).map (fun p => p.size) :=
  Hex.RCF.RealCoefficients.NativeSamplesConformance.sizes

theorem constants :
    (RepresentationSpecialize.prepare (sample.input.value ∘ values)
      Hex.RCF.RealCoefficients.NativeSamplesConformance.constants).map (fun p => p.size) =
      (RepresentationSpecialize.prepare values
        Hex.RCF.RealCoefficients.NativeSamplesConformance.constants).map (fun p => p.size) :=
  constant_sizes

/-- info: 'NativeSamplesOrdinaryUse.sizes' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms sizes
/-- info: 'NativeSamplesOrdinaryUse.constants' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms constants

theorem coefficient :
    Nested.conversion.target.value (Nested.sample.input.value
      Hex.RCF.SelectedRootTests.Data.alpha) = Real.sqrt 2 := Nested.coefficient_fixed

theorem nested_row :
    Nested.sample.signs (RepresentationSpecialize.prepare
      Hex.RCF.SelectedRootTests.Upper.values Hex.RCF.SelectedRootTests.Upper.schema) =
      NativeSpecialize.row Nested.sample.input.context
        (Nested.sample.input.value ∘ Hex.RCF.SelectedRootTests.Upper.values)
        Nested.sample.value Hex.RCF.SelectedRootTests.Upper.schema := Nested.row_converted

theorem nested_sizes :
    (RepresentationSpecialize.prepare
      (Nested.sample.input.value ∘ Hex.RCF.SelectedRootTests.Upper.values)
      Hex.RCF.SelectedRootTests.Upper.schema).map (fun p => p.size) =
      (RepresentationSpecialize.prepare Hex.RCF.SelectedRootTests.Upper.values
        Hex.RCF.SelectedRootTests.Upper.schema).map (fun p => p.size) := Nested.sizes

/-- info: 'NativeSamplesOrdinaryUse.coefficient' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms coefficient
/-- info: 'NativeSamplesOrdinaryUse.nested_row' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms nested_row
/-- info: 'NativeSamplesOrdinaryUse.nested_sizes' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms nested_sizes

run_meta do
  for name in #[``typical, ``empty, ``changed, ``sizes, ``constants,
      ``coefficient, ``nested_row, ``nested_sizes] do
    let proof := Lean.mkConst name
    let target ← Lean.Meta.inferType proof
    let _ ← Hex.RCF.checkProof name target proof
end NativeSamplesOrdinaryUse
