import NativeSources
import NativeSelectedReal

namespace NativeSourcesTest
open Hex Hex.RCF.RealCoefficients Hex.RCF.SelectedRootTests
open Hex.RealClosure Hex.RealClosure.Tower Hex.RealFormula
open scoped HexMvPolyMathlib

def selection : RealFormula.QF 1 :=
  let c : RealFormula.Poly 1 := MvPoly.X 0
  .and (.atom ⟨c^2-2, .eq⟩) (.and (.atom ⟨c-1, .gt⟩) (.atom ⟨c-2, .lt⟩))

theorem selected (coefficients : Fin 1 → ℝ) (h : selection.toProp coefficients) :
    coefficients = fun _ => Real.sqrt 2 := by
  dsimp only [selection, RealFormula.QF.toProp, RealFormula.Atom.toProp,
    RealFormula.Cmp.toProp] at h
  unfold RealFormula.Poly.eval at h
  simp_rw [← HexMvPolyMathlib.eval₂_toMvPolynomial] at h
  have facts : (coefficients 0)^2=2 ∧ 1<coefficients 0 ∧ coefficients 0<2 := by
    simpa [HexMvPolyMathlib.toMvPolynomial_X, HexMvPolyMathlib.toMvPolynomial_sub,
      HexMvPolyMathlib.toMvPolynomial_pow, HexMvPolyMathlib.toMvPolynomial_one,
      show (2 : RealFormula.Poly 1)=MvPoly.C 2 from rfl, sub_eq_zero, sub_pos, sub_lt_zero] using h
  have same : coefficients 0 = Real.sqrt 2 := by
    nlinarith [facts.1, facts.2.1, Real.sq_sqrt (by norm_num : (0:ℝ)≤2), Real.sqrt_nonneg (2:ℝ)]
  funext i
  have index : i = 0 := Subsingleton.elim _ _
  simpa only [index] using same

theorem shape : (RealFormula.QF.and selection.lift Upper.schema).polys = NativeSelectedReal.joint.polys := by
  decide +kernel

theorem truth : Samples.Row.eval (RealFormula.QF.and selection.lift Upper.schema)
    (NativeSpecialize.row NativeSelectedReal.context
      (NativeSelectedReal.sample.input.value ∘ Upper.values) NativeSelectedReal.sample.value
      (RealFormula.QF.and selection.lift Upper.schema)) = some true := by
  have word := NativeSelectedReal.source_row
  rw [NativeSamples.row_converted Data.original NativeSelectedReal.sample
    NativeSamplesConformance.Nested.conversion] at word
  have same : NativeSpecialize.row NativeSelectedReal.context
      (NativeSelectedReal.sample.input.value ∘ Upper.values) NativeSelectedReal.sample.value
      (RealFormula.QF.and selection.lift Upper.schema) =
      NativeSpecialize.row NativeSelectedReal.context
      (NativeSelectedReal.sample.input.value ∘ Upper.values) NativeSelectedReal.sample.value
      NativeSelectedReal.joint := by
    simp only [NativeSpecialize.row, RepresentationSpecialize.prepare, shape]
  rw [same, word]
  decide +kernel

theorem source_real : ∃ x : ℝ, x^2 = Real.sqrt 2 ∧ 1<x ∧ x<2 := by
  obtain ⟨read, domain, closed, negative, fixed, present, sizes, meaning, guards, base⟩ :=
    NativeSources.true_real NativeSelectedReal.context NativeSelectedReal.following
      (NativeSelectedReal.sample.input.value ∘ Upper.values) (fun _ => Real.sqrt 2)
      selection selected NativeSelectedReal.sample.value Upper.schema [] (by simp)
      truth
  refine ⟨read NativeSelectedReal.sample.value, ?_⟩
  dsimp only [Upper.schema, RealFormula.QF.toProp, RealFormula.Atom.toProp,
    RealFormula.Cmp.toProp] at meaning
  unfold RealFormula.Poly.eval at meaning
  simp_rw [← HexMvPolyMathlib.eval₂_toMvPolynomial] at meaning
  simpa [HexMvPolyMathlib.toMvPolynomial_X, HexMvPolyMathlib.toMvPolynomial_sub,
    HexMvPolyMathlib.toMvPolynomial_pow, HexMvPolyMathlib.toMvPolynomial_one,
    show (2 : RealFormula.Poly 2)=MvPoly.C 2 from rfl, RealFormula.append,
    sub_eq_zero, sub_pos, sub_lt_zero] using meaning

/-- info: 'NativeSourcesTest.source_real' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms source_real
end NativeSourcesTest
