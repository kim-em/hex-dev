import HexRCF.NativeSampleModelConformance
import HexRCF.Tactic

namespace NativeSampleModelOrdinaryUse
open Hex.RealClosure Hex.RCF.RealCoefficients
open NativeSampleModelConformance

theorem guarded : ∃ read : sample.input.context.Value → ℝ,
    ∃ domain : sample.input.context.Value → Prop,
      Transport.Closed read domain ∧ domain sample.value ∧
      0 < read sample.value ∧ read sample.value < 1 ∧
      read sample.value * read sample.value = read (sample.input.value parameter) ∧
      domain (sample.input.value parameter) ∧ read (sample.input.value parameter) ≠ 0 :=
  guarded_reader

/-- info: 'NativeSampleModelOrdinaryUse.guarded' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms guarded

run_meta do
  let _ ← Hex.RCF.checkProof ``guarded (← Lean.Meta.inferType (Lean.mkConst ``guarded))
    (Lean.mkConst ``guarded)
  let axioms ← Lean.collectAxioms ``guarded
  unless axioms.size == 3 && axioms.all
      (fun a => [``propext, ``Classical.choice, ``Quot.sound].contains a) do
    Lean.throwError "ordinary sample model consumer has an unexpected complete axiom inventory"
end NativeSampleModelOrdinaryUse
