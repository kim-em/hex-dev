from pathlib import Path
import json,subprocess,hashlib,os,platform,sys,statistics
roots={'before':Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10377-matrix-wide'),
       'after':Path('/home/kim/worktrees/hex-dev/hex-dev-issue-10377-checker-attribution')}
sys.path.insert(0,str(roots['after']))
from scripts.bench.cpu_lease import cpu_lease
out=Path('/home/kim/.local/state/hex/issue-10377-session-progress/matrix-power-comparison-7d21b4083f');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta={'schema':'hex-matrix-power-paired-v1','scope':'short before/after comparison; no scaling verdict',
 'sizes':[243,729],'trials':6,'arms':{},'samples':[],'state':'running','host':platform.node()}
for label,root in roots.items():
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
 exe=root/'.lake/build/bin/hexsigndet_bench'
 meta['arms'][label]={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'binary_sha256':sha(exe),'matrix_sha256':sha(root/'HexSignDet/Matrix.lean'),'executable':str(exe)}
cpu,lease=cpu_lease();os.sched_setaffinity(0,{cpu});meta.update(cpu=cpu,load_before=os.getloadavg())
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
try:
 save()
 for trial in range(6):
  for size in [243,729]:
   for label in (['before','after'] if trial%2==0 else ['after','before']):
    command=[meta['arms'][label]['executable'],'_child','--bench','Hex.SignDetBench.MaximalMatrix.runTensorCheck',
      '--param',str(size),'--target-nanos','100000000','--cache-mode','warm']
    capture=f'{trial}-{size}-{label}'
    with (out/(capture+'.stdout')).open('w') as stdout,(out/(capture+'.stderr')).open('w') as stderr:
     subprocess.run(command,cwd=roots[label],stdout=stdout,stderr=stderr,check=True)
    rows=[json.loads(line) for line in (out/(capture+'.stdout')).read_text().splitlines() if line.startswith('{')]
    assert len(rows)==1;row=rows[0]
    assert row['result_hash']=='0xb' and row['status']=='ok' and row['param']==size
    assert row['cache_mode']=='warm' and row['env']['git_commit']==meta['arms'][label]['revision'] and row['env']['git_dirty'] is False
    meta['samples'].append({'trial':trial,'size':size,'arm':label,'capture':capture,'row':row,'load_after':os.getloadavg()});save()
 meta['summary']={str(size):{'median_before_after_ratio':statistics.median(
    next(r['row']['per_call_nanos'] for r in meta['samples'] if r['trial']==t and r['size']==size and r['arm']=='before')/
    next(r['row']['per_call_nanos'] for r in meta['samples'] if r['trial']==t and r['size']==size and r['arm']=='after')
    for t in range(6))} for size in [243,729]}
 meta['state']='complete'
finally:
 meta['provenance_unchanged']=all(sha(root/'.lake/build/bin/hexsigndet_bench')==meta['arms'][label]['binary_sha256'] and
   sha(root/'HexSignDet/Matrix.lean')==meta['arms'][label]['matrix_sha256'] and
   subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==meta['arms'][label]['revision'] and
   not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True) for label,root in roots.items())
 meta['load_after']=os.getloadavg();save();lease.close();assert meta['provenance_unchanged']
print(json.dumps(meta['summary']))
