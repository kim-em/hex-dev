import HexManual
import VersoManual
#eval Verso.Genre.Manual.manualMain (%doc HexManual)
  (options := ["--output", "/home/kim/.codex/tasks/hex-10358/manual-render/full-html",
    "--without-tex", "--with-html-single", "--without-html-multi"])
