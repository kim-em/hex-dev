import Lake
open Lake DSL
package rcfManualRender
require Hex from "/home/kim/worktrees/hex-dev/hex-dev-issue-10358"
lean_lib Render

lean_lib FullRender

lean_lib NativeFormula

lean_lib NativeSamples

lean_lib NativeSampleTests

lean_lib NativeSampleExample

lean_lib NativeFixture

lean_lib RootAliasProbe

lean_lib RationalRootSource

lean_lib LiteralRationalRoots

lean_lib CubeDivisionDebug

lean_lib SharedSources

lean_lib SharedSourceTests

lean_lib CheckedAlgebraicRoots

lean_lib CheckedAlgebraicRootsProbe

lean_lib RootBudgetProbe

lean_lib GatherPublic

lean_lib RootMetadata

lean_lib RootExponentBudget

lean_lib BoundedRootExponent

lean_lib FrozenRootAliases

lean_lib FrozenRootAliasesProbe

lean_lib CompiledAlgebraicBase

lean_lib GeneralRootSource

lean_lib GeneralRootTactic

lean_lib GeneralRootGoals

lean_lib GeneralRootFailures

lean_lib GeneralEnclosure

lean_lib SharedBaseFast

lean_lib GeneralAlgebraicBounds

lean_lib GeneralFinite

lean_lib GeneralMixed

lean_lib NestedRegistration

lean_lib NumberFieldSchema

lean_lib MixedRpow

lean_lib InfinitesimalFormula

lean_lib InfinitesimalFormulaTests

lean_lib RealizationProbe

lean_lib NumberFieldFormula

lean_lib NumberFieldFormulaTests

lean_lib SelectedFormula

lean_lib SelectedEmit

lean_lib SelectedLiterals

lean_lib SelectedData

lean_lib SelectedRootRead

lean_lib SelectedPackets

lean_lib SelectedCollect

lean_lib SelectedDiscover

lean_lib SelectedIntermediates

lean_lib SelectedUpper

lean_lib SelectedRow

lean_lib SelectedRowCollect

lean_lib SelectedRowDiscover

lean_lib SelectedSource

lean_lib SelectedRowIntermediates

lean_lib SelectedQuoted

lean_lib SelectedControls

lean_lib SelectedRefusals

lean_lib SelectedAudit

lean_lib SelectedChecks

lean_lib SelectedBound

lean_lib SelectedFrozen

lean_lib SelectedFrozenCollect

lean_lib SelectedPacketFields

lean_lib SelectedByteRow

lean_lib SelectedByteProofs

lean_lib SelectedByteDump

lean_lib SelectedByteData

lean_lib SelectedByteControls

lean_lib SelectedByteAudit

lean_lib SelectedByteBounds


lean_lib PackingRow

lean_lib PackingProgram

lean_lib PackingLiterals

lean_lib PackingFrozen

lean_lib PackingMissing

lean_lib PackingAudit

lean_lib PreparedPacking where
  srcDir := "../packing-tranche/probe"
  globs := #[.submodules `PreparedPacking]

lean_lib PackingVanishingProposal

lean_lib RootCatalogProbe

lean_lib RootCatalogProposal

lean_lib RootCatalogLiterals

lean_lib RootCatalogFrozen

lean_lib RootCatalogEncoding

lean_lib RootCatalogAudit

lean_lib RootCatalogBytes

lean_lib RootCatalogControls

lean_lib CommonFactoryProbe

lean_exe selected_catalog_bench where
  root := `SelectedCatalogBench

lean_lib OcticKernelProof

lean_lib KernelClosure
lean_lib OcticPublicImport

lean_lib RegisteredGatherModel
lean_lib RegisteredGatherSemantics
lean_lib OcticNormalized

lean_lib RegisteredGatherDomain

lean_lib RegisteredVector

lean_lib RegisteredVectorTests

lean_lib RegisteredVectorNative

lean_lib RegisteredGatherNext

lean_lib RegisteredGatherPrepared

lean_lib GatherCatalogPrepared

lean_lib ReorderedGather

lean_lib SuppliedInverseSource

lean_exe supplied_inverse_fixture where
  root := `SuppliedInverseFixture

lean_lib SuppliedInverseLiteral
lean_lib SuppliedInverseProof

lean_lib SuppliedInverseControls

lean_lib SourceInversePoint

lean_lib SuppliedOcticProof
lean_lib SuppliedOcticUse

lean_lib SuppliedOcticTactic

lean_lib SuppliedOcticDebug

lean_lib SuppliedOcticControls

lean_lib IrreducibilityCostReconstruct

lean_lib IrreducibilityCostReuse

lean_lib NativeJointSigns

lean_lib SuppliedInstanceBudget

lean_lib NativeRow

lean_lib NativeRowTest

lean_lib NativeFormulaOrdinaryUse

lean_lib NativeFormulaSuccessive

lean_lib NativeFormulaSelected

lean_lib NativeSpecialize

lean_lib NativeSpecializeTest

lean_lib NativeSpecializeOrdinaryUse

lean_lib SpecializeConversion

lean_lib SampleConversionFixture

lean_lib NativeSamplesOrdinaryUse

lean_lib NativeConversionDegree

lean_lib NativeNestedSample

lean_lib NativeSelectedReal where
  globs := #[`NativeSelectedReal]

lean_lib NestedSampleRows where
  globs := #[`NestedSampleRows]

lean_lib SamplePointConsumers where
  globs := #[`SamplePointConsumers]

lean_lib SampleSizeWords where
  globs := #[`SampleSizeWords]

lean_lib SampleInfinitesimal

lean_lib NativeSampleModelOrdinaryUse

lean_lib NativeSources

lean_lib SampleSelectedInfinitesimal

lean_lib NativeSourcesTest

lean_lib SampleInfinitesimalEmit

lean_lib SampleInfinitesimalFrozenEmit

lean_lib SampleInfinitesimalLiterals
lean_lib SampleFrozenInfinitesimal

lean_lib SampleFrozenLegacy

lean_lib NativeSampleModelEmit

lean_lib NativeSampleSquare

lean_lib NativeSourcesOrdinaryUse
