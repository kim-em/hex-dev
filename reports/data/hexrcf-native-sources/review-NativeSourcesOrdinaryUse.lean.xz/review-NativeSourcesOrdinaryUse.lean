import HexRCF.NativeSourcesConformance
import HexRCF.Tactic

namespace NativeSourcesOrdinaryUse
open Hex Hex.RCF.RealCoefficients Hex.RealClosure Hex.RealFormula
open NativeSourcesConformance

theorem further_root : ∃ x : ℝ, x^2 = Real.sqrt 2 ∧ 1<x ∧ x<2 := source_real

theorem selected_identity (coefficients : Fin 1 → ℝ)
    (meaning : selection.toProp coefficients) : coefficients = fun _ => Real.sqrt 2 :=
  selected coefficients meaning

theorem wrong_conjugate : ¬ selection.toProp (fun _ => -Real.sqrt 2) :=
  NativeSourcesConformance.wrong_conjugate

theorem inherited_reader : ∃ read : Inherited.stage.Value → ℝ,
    ∃ domain : Inherited.stage.Value → Prop,
      Transport.Closed read domain ∧
      read Inherited.point.value = Real.sqrt 2 ∧
      read (Inherited.point.input.value 2) = 2 ∧
      Inherited.matrix.toProp (RealFormula.append Inherited.source (read Inherited.point.value)) :=
  Inherited.reader

theorem counterexample :
    (¬ ∀ x : ℝ, falseFormula.toProp (RealFormula.append (fun _ => Real.sqrt 2) x)) ∧
    ∃ read : context.Value → ℝ, ∃ domain : context.Value → Prop,
      Transport.Closed read domain ∧
      (∀ i, domain ((sample.input.value ∘ Hex.RCF.SelectedRootTests.Upper.values) i) ∧
        read ((sample.input.value ∘ Hex.RCF.SelectedRootTests.Upper.values) i) = Real.sqrt 2) ∧
      domain sample.value ∧
      ¬ falseFormula.toProp (RealFormula.append (fun _ => Real.sqrt 2) (read sample.value)) ∧
      domain (sample.input.value Hex.RCF.SelectedRootTests.Data.alpha) ∧
      read (sample.input.value Hex.RCF.SelectedRootTests.Data.alpha) ≠ 0 := guarded_counterexample

/-- A fresh body composes the imported counterexample and shared semantics. -/
theorem false_sentence : ¬ ∀ x : ℝ, x^2 > Real.sqrt 2 := by
  intro all
  apply counterexample.1
  intro x
  dsimp only [falseFormula, RealFormula.QF.toProp, RealFormula.Atom.toProp,
    RealFormula.Cmp.toProp]
  unfold RealFormula.Poly.eval
  rw [← HexMvPolyMathlib.eval₂_toMvPolynomial]
  simpa [HexMvPolyMathlib.toMvPolynomial_X, HexMvPolyMathlib.toMvPolynomial_pow,
    HexMvPolyMathlib.toMvPolynomial_sub, RealFormula.append] using sub_pos.mpr (all x)

/-- info: 'NativeSourcesOrdinaryUse.further_root' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms further_root

/-- info: 'NativeSourcesOrdinaryUse.selected_identity' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms selected_identity

/-- info: 'NativeSourcesOrdinaryUse.wrong_conjugate' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms wrong_conjugate

/-- info: 'NativeSourcesOrdinaryUse.inherited_reader' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms inherited_reader

/-- info: 'NativeSourcesOrdinaryUse.counterexample' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms counterexample

/-- info: 'NativeSourcesOrdinaryUse.false_sentence' depends on axioms: [propext, Classical.choice, Quot.sound] -/
#guard_msgs (whitespace := lax) in
#print axioms false_sentence

run_meta do
  for name in #[``further_root, ``selected_identity, ``wrong_conjugate,
      ``inherited_reader, ``counterexample, ``false_sentence] do
    let _ ← Hex.RCF.checkProof name (← Lean.Meta.inferType (Lean.mkConst name)) (Lean.mkConst name)
    let axioms ← Lean.collectAxioms name
    unless axioms.size == 3 && axioms.all
        (fun a => [``propext, ``Classical.choice, ``Quot.sound].contains a) do
      Lean.throwError "fresh selected source consumer has an unexpected complete axiom inventory"
end NativeSourcesOrdinaryUse
