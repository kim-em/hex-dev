import HexRealClosure.RootReplay
import HexSturm.Fixtures
open Hex Hex.SignDet
open scoped Hex
namespace NativeSelectionEmit
#eval do
  let raw : RawDescriptor Rat Nat :=
    ⟨7, #p[-2,0,1], .finite (7/5), .finite (3/2), [1,2], [1,1]⟩
  let some checked := Descriptor.validate Hex.Sturm.orderSign 7 raw
    | throw (IO.userError "selection descriptor rejected")
  let data := Codec.Json.arr #[Codec.descriptor ValueCodec.rat ValueCodec.nat raw,
    Codec.graph ValueCodec.rat ValueCodec.nat (Dag.encode checked.evidence)]
  IO.FS.writeFile "/home/kim/.codex/tasks/hex-10358/native-selection-root-emitted.json"
    (String.fromUTF8! data.writeBytes)
end NativeSelectionEmit
