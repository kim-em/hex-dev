// Lean compiler output
// Module: HexSignDet.MaximalMatrix
// Imports: public import Init public meta import Init public import HexSignDet.Maximal public import LeanBench
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint64_t lp_Hex_Hex_SignDetBench_matrixHash(lean_object*, lean_object*, lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
uint64_t lean_uint64_mix_hash(uint64_t, uint64_t);
lean_object* lean_nat_to_int(lean_object*);
uint8_t lean_int_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_abs(lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* l_Id_instMonad___lam__6(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__3(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__2___boxed(lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Id_instMonad___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
lean_object* l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
lean_object* lean_int_neg(lean_object*);
lean_object* l_instDecidableEqNat___boxed(lean_object*, lean_object*);
uint8_t l_instDecidableEqList___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
size_t lean_array_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* lean_array_uget_borrowed(lean_object*, size_t);
lean_object* lean_nat_pow(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* lp_Hex_Hex_SignDet_words___redArg(lean_object*, lean_object*);
lean_object* lean_array_mk(lean_object*);
lean_object* lean_array_get_borrowed(lean_object*, lean_object*, lean_object*);
lean_object* l_Array_ofFn___redArg(lean_object*, lean_object*);
lean_object* lean_array_to_list(lean_object*);
lean_object* lp_Hex_Hex_SignDet_moments(lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_SignDet_solveSystem(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
uint8_t lp_Hex_Hex_SignDet_System_check(lean_object*, lean_object*, lean_object*);
lean_object* lean_io_mono_nanos_now();
lean_object* lp_lean_x2dbench_LeanBench_blackBox(uint64_t);
uint64_t lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(lean_object*, size_t, size_t, uint64_t);
uint8_t lean_usize_dec_eq(size_t, size_t);
uint64_t l_List_foldl___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_Elab_Tactic_Omega_Problem_insertConstraint_spec__0_spec__0(uint64_t, lean_object*);
uint64_t lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(lean_object*, size_t, size_t, uint64_t);
lean_object* l_Lean_Name_mkStr4(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Int_instDecidableEq___boxed(lean_object*, lean_object*);
double lean_float_of_nat(lean_object*);
double l_Float_ofScientific(lean_object*, uint8_t, lean_object*);
lean_object* lp_lean_x2dbench_LeanBench_register(lean_object*, lean_object*, lean_object*);
lean_object* lp_Hex_Hex_SignDetBench_entries(lean_object*, lean_object*);
lean_object* lp_lean_x2dbench_LeanBench_kernelLoop___redArg(lean_object*, lean_object*, uint8_t, uint8_t);
lean_object* l_instMonadEIO___redArg();
lean_object* lp_lean_x2dbench_LeanBench_registerKernel(lean_object*, lean_object*);
lean_object* l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_foldl___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_log2(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_uint64_to_nat(uint64_t);
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* lp_lean_x2dbench_IO_println___at___00LeanBench_Cli_runListCmd_spec__0(lean_object*);
lean_object* lean_get_stdout();
lean_object* l_List_lengthTR___redArg(lean_object*);
lean_object* lp_Hex_List_sum___at___00Hex_SignDet_moments_spec__1(lean_object*);
lean_object* l_Lean_JsonNumber_fromInt(lean_object*);
lean_object* lp_Hex_Hex_Matrix_rows___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lp_Hex_Hex_SignDetBench_buildMaximal(lean_object*);
lean_object* lp_Hex_Hex_SignDet_referencePrepared___at___00Hex_SignDetBench_buildMaximal_spec__10___redArg(lean_object*, lean_object*, lean_object*);
uint8_t l_Array_instDecidableEqImpl___redArg(lean_object*, lean_object*, lean_object*);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__0(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__0___boxed(lean_object*, lean_object*);
static const lean_ctor_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(7, 0, 0, 0, 0, 0, 0, 0)}};
LEAN_EXPORT const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1_value;
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0;
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__4(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__4___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__3(lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__3___boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__0, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__0 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__0_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__1___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__1 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__1_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__2___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__2 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__2_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__3, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__3 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__3_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__4___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__4 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__4_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__5___boxed, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__5 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__5_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Id_instMonad___lam__6, .m_arity = 4, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__6 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__6_value;
static const lean_ctor_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__0_value),((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__1_value)}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__7 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__7_value;
static const lean_ctor_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*5 + 0, .m_other = 5, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__7_value),((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__2_value),((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__3_value),((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__4_value),((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__5_value)}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__8 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__8_value;
static const lean_ctor_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__8_value),((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__6_value)}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9_value;
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__0 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__0_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__0_value)} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__1 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__1_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__2 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__2_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__4___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__3 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__3_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__3___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__3_value)} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__4 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__4_value;
static const lean_closure_object lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*4, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___boxed, .m_arity = 5, .m_num_fixed = 4, .m_objs = {((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__2_value),((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__2_value),((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__4_value),((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__1_value)} };
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__5 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__5_value;
LEAN_EXPORT const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__5_value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0;
LEAN_EXPORT uint8_t lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___boxed(lean_object*);
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 29, .m_capacity = 29, .m_length = 28, .m_data = "wrong full-system dimensions"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__0 = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__0_value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__0_value)}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__1 = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__1_value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 37, .m_capacity = 37, .m_length = 36, .m_data = "wrong full-support counts or inverse"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__2 = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__2_value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__2_value)}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__3 = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__3_value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__4 = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__4_value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__4_value)}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__5 = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__5_value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__5_value)}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__6 = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__6_value;
static lean_once_cell_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__7_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__7;
static lean_once_cell_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__8;
static lean_once_cell_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__9;
static lean_once_cell_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__10;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 25, .m_capacity = 25, .m_length = 24, .m_data = "full-system solve failed"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__11 = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__11_value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__11_value)}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__12 = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__12_value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_input(lean_object*);
LEAN_EXPORT uint64_t lp_Hex_List_foldl___at___00Hex_SignDetBench_MaximalMatrix_runSolve_spec__0(uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_SignDetBench_MaximalMatrix_runSolve_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolve(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__complexity(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__complexity___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__0(lean_object*, lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___closed__0 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed__const__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*0 + 8, .m_other = 0, .m_tag = 0}, .m_objs = {LEAN_SCALAR_PTR_LITERAL(0, 0, 0, 0, 0, 0, 0, 0)}};
LEAN_EXPORT const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed__const__1 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed__const__1_value;
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0;
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___boxed(lean_object*, lean_object*);
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static double lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__0;
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static double lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__1;
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static double lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__2;
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static double lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__3;
static const lean_array_object lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*5, .m_other = 0, .m_tag = 246}, .m_size = 5, .m_capacity = 5, .m_data = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)(((size_t)(5) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__4 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__4_value;
static const lean_ctor_object lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__4_value)}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__5 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__5_value;
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static double lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__6;
static const lean_array_object lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 246}, .m_size = 0, .m_capacity = 0, .m_data = {}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__7 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__7_value;
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__8;
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0___redArg(lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33____boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(lean_object*, size_t, size_t, uint64_t);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33____boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33____boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "Hex"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 13, .m_capacity = 13, .m_length = 12, .m_data = "SignDetBench"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "MaximalMatrix"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "runSolve"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(101, 25, 57, 154, 30, 39, 134, 251)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value_aux_0),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(3, 58, 32, 100, 199, 149, 204, 54)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value_aux_2 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value_aux_1),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(22, 91, 199, 15, 140, 86, 13, 10)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value_aux_2),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(31, 231, 224, 85, 126, 133, 254, 164)}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__6_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "27^s"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__6_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__6_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value;
static lean_once_cell_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__7_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__7_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_;
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__8_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__complexity___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__8_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__8_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_();
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33____boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0(lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37__value;
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37__value)} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37__value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_();
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__complexity(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__complexity___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked___lam__0(lean_object*, lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__config;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0___redArg(lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33____boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33____boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33____boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "runCheck"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(101, 25, 57, 154, 30, 39, 134, 251)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value_aux_0),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(3, 58, 32, 100, 199, 149, 204, 54)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value_aux_2 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value_aux_1),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(22, 91, 199, 15, 140, 86, 13, 10)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value_aux_2),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(84, 130, 149, 190, 226, 105, 250, 174)}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value;
static lean_once_cell_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_;
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__complexity___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_();
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33____boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0(lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint64_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(uint8_t);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37__value;
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37__value)} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37__value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_();
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed(lean_object*);
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0___closed__0_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_array_object lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*6, .m_other = 0, .m_tag = 246}, .m_size = 6, .m_capacity = 6, .m_data = {((lean_object*)(((size_t)(1) << 1) | 1)),((lean_object*)(((size_t)(2) << 1) | 1)),((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)(((size_t)(4) << 1) | 1)),((lean_object*)(((size_t)(5) << 1) | 1)),((lean_object*)(((size_t)(6) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__0 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__0_value;
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static size_t lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__1;
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolveDimension(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheckDimension(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheckDimension___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__complexity(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__complexity___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked___lam__0(lean_object*, lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked___boxed(lean_object*, lean_object*);
static const lean_array_object lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_array_object) + sizeof(void*)*6, .m_other = 0, .m_tag = 246}, .m_size = 6, .m_capacity = 6, .m_data = {((lean_object*)(((size_t)(3) << 1) | 1)),((lean_object*)(((size_t)(9) << 1) | 1)),((lean_object*)(((size_t)(27) << 1) | 1)),((lean_object*)(((size_t)(81) << 1) | 1)),((lean_object*)(((size_t)(243) << 1) | 1)),((lean_object*)(((size_t)(729) << 1) | 1))}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__0 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__0_value;
static const lean_ctor_object lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 2}, .m_objs = {((lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__0_value)}};
static const lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__1 = (const lean_object*)&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__1_value;
static lean_once_cell_t lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__2;
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0___redArg(lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33____boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33____boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33____boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "runSolveDimension"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(101, 25, 57, 154, 30, 39, 134, 251)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value_aux_0),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(3, 58, 32, 100, 199, 149, 204, 54)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value_aux_2 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value_aux_1),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(22, 91, 199, 15, 140, 86, 13, 10)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value_aux_2),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(234, 204, 53, 238, 32, 27, 119, 90)}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "r^3"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value;
static lean_once_cell_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_;
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__complexity___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_();
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33____boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0(lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37____boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37____boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37____boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37__value)} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37__value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_();
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37____boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__complexity(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__complexity___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked___lam__0(lean_object*, lean_object*, lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__config;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0___redArg(lean_object*, lean_object*, uint64_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33____boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33____boxed(lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33____boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value;
static const lean_string_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 18, .m_capacity = 18, .m_length = 17, .m_data = "runCheckDimension"};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value;
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(101, 25, 57, 154, 30, 39, 134, 251)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value_aux_0),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(3, 58, 32, 100, 199, 149, 204, 54)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value_aux_2 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value_aux_1),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(22, 91, 199, 15, 140, 86, 13, 10)}};
static const lean_ctor_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value_aux_2),((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value),LEAN_SCALAR_PTR_LITERAL(41, 189, 169, 46, 59, 203, 42, 147)}};
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value;
static lean_once_cell_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_;
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__complexity___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_();
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33____boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0(lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37____boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37____boxed(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37____boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37__value)} };
static const lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_ = (const lean_object*)&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37__value;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_();
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37____boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_bits(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_bits___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Lean_Option_toJson___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__3(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Lean_Option_toJson___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__3___boxed(lean_object*);
LEAN_EXPORT uint8_t lp_Hex_Option_instBEq_beq___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__5(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Option_instBEq_beq___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__5___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__0(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__4(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__2___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_List_mapTR_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__1(lean_object*, lean_object*);
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "polynomial moment system differs"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__0 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__0_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__0_value)}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__1 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__1_value;
static const lean_closure_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__2 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__2_value;
static const lean_closure_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__1___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__3 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__3_value;
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__4;
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__5;
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__6_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__6;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "solveResultHash"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__7 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__7_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "checkResultHash"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__8 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__8_value;
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__9;
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__10_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__10;
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__11;
static lean_once_cell_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__12_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__12;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "queries"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__13 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__13_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "matrixSize"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__14 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__14_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "supportSize"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__15 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__15_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "countSum"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__16 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__16_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 27, .m_capacity = 27, .m_length = 26, .m_data = "inverseIdentityScalarPairs"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__17 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__17_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "inverseBits"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__18 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__18_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 16, .m_capacity = 16, .m_length = 15, .m_data = "denominatorBits"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__19 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__19_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "valuesBits"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__20 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__20_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "matchesPolynomialSystem"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__21 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__21_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 10, .m_capacity = 10, .m_length = 9, .m_data = "inputHash"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__22 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__22_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 35, .m_capacity = 35, .m_length = 34, .m_data = "incorrect maximal matrix callback "};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__23 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__23_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 36, .m_capacity = 36, .m_length = 35, .m_data = "polynomial matrix dimension differs"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__24 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__24_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__24_value)}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__25 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__25_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = "polynomial reference failed"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__26 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__26_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__27_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__26_value)}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__27 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__27_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__28_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 26, .m_capacity = 26, .m_length = 25, .m_data = "missing polynomial domain"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__28 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__28_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__29_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__28_value)}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__29 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__29_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__30_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 32, .m_capacity = 32, .m_length = 31, .m_data = "maximal polynomial input failed"};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__30 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__30_value;
static const lean_ctor_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__31_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__30_value)}};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__31 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__31_value;
static const lean_string_object lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 30, .m_capacity = 30, .m_length = 29, .m_data = "invalid maximal matrix input "};
static const lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__32 = (const lean_object*)&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__32_value;
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor___boxed__const__1;
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor(lean_object*);
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_inspect();
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_inspect___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_inspectDimension();
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_inspectDimension___boxed(lean_object*);
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__0(uint64_t v_r_1_, lean_object* v_a_2_){
_start:
{
uint64_t v___x_3_; uint64_t v___x_4_; 
v___x_3_ = lean_uint64_of_nat(v_a_2_);
v___x_4_ = lean_uint64_mix_hash(v_r_1_, v___x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__0___boxed(lean_object* v_r_5_, lean_object* v_a_6_){
_start:
{
uint64_t v_r_boxed_7_; uint64_t v_res_8_; lean_object* v_r_9_; 
v_r_boxed_7_ = lean_unbox_uint64(v_r_5_);
lean_dec_ref(v_r_5_);
v_res_8_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__0(v_r_boxed_7_, v_a_6_);
lean_dec(v_a_6_);
v_r_9_ = lean_box_uint64(v_res_8_);
return v_r_9_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1(lean_object* v___f_12_, uint64_t v_x1_13_, lean_object* v_x2_14_){
_start:
{
lean_object* v___x_15_; lean_object* v___x_16_; uint64_t v___x_17_; uint64_t v___x_18_; 
v___x_15_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_16_ = l_List_foldl___redArg(v___f_12_, v___x_15_, v_x2_14_);
v___x_17_ = lean_unbox_uint64(v___x_16_);
lean_dec(v___x_16_);
v___x_18_ = lean_uint64_mix_hash(v_x1_13_, v___x_17_);
return v___x_18_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed(lean_object* v___f_19_, lean_object* v_x1_20_, lean_object* v_x2_21_){
_start:
{
uint64_t v_x1_697__boxed_22_; uint64_t v_res_23_; lean_object* v_r_24_; 
v_x1_697__boxed_22_ = lean_unbox_uint64(v_x1_20_);
lean_dec_ref(v_x1_20_);
v_res_23_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1(v___f_19_, v_x1_697__boxed_22_, v_x2_21_);
v_r_24_ = lean_box_uint64(v_res_23_);
return v_r_24_;
}
}
static lean_object* _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0(void){
_start:
{
lean_object* v_natZero_25_; lean_object* v_intZero_26_; 
v_natZero_25_ = lean_unsigned_to_nat(0u);
v_intZero_26_ = lean_nat_to_int(v_natZero_25_);
return v_intZero_26_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2(uint64_t v_x1_27_, lean_object* v_x2_28_){
_start:
{
lean_object* v_intZero_29_; uint8_t v_isNeg_30_; 
v_intZero_29_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_30_ = lean_int_dec_lt(v_x2_28_, v_intZero_29_);
if (v_isNeg_30_ == 0)
{
lean_object* v_a_31_; lean_object* v___x_32_; lean_object* v___x_33_; uint64_t v___x_34_; uint64_t v___x_35_; 
v_a_31_ = lean_nat_abs(v_x2_28_);
v___x_32_ = lean_unsigned_to_nat(2u);
v___x_33_ = lean_nat_mul(v___x_32_, v_a_31_);
lean_dec(v_a_31_);
v___x_34_ = lean_uint64_of_nat(v___x_33_);
lean_dec(v___x_33_);
v___x_35_ = lean_uint64_mix_hash(v_x1_27_, v___x_34_);
return v___x_35_;
}
else
{
lean_object* v_abs_36_; lean_object* v_one_37_; lean_object* v_a_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; uint64_t v___x_42_; uint64_t v___x_43_; 
v_abs_36_ = lean_nat_abs(v_x2_28_);
v_one_37_ = lean_unsigned_to_nat(1u);
v_a_38_ = lean_nat_sub(v_abs_36_, v_one_37_);
lean_dec(v_abs_36_);
v___x_39_ = lean_unsigned_to_nat(2u);
v___x_40_ = lean_nat_mul(v___x_39_, v_a_38_);
lean_dec(v_a_38_);
v___x_41_ = lean_nat_add(v___x_40_, v_one_37_);
lean_dec(v___x_40_);
v___x_42_ = lean_uint64_of_nat(v___x_41_);
lean_dec(v___x_41_);
v___x_43_ = lean_uint64_mix_hash(v_x1_27_, v___x_42_);
return v___x_43_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___boxed(lean_object* v_x1_44_, lean_object* v_x2_45_){
_start:
{
uint64_t v_x1_718__boxed_46_; uint64_t v_res_47_; lean_object* v_r_48_; 
v_x1_718__boxed_46_ = lean_unbox_uint64(v_x1_44_);
lean_dec_ref(v_x1_44_);
v_res_47_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2(v_x1_718__boxed_46_, v_x2_45_);
lean_dec(v_x2_45_);
v_r_48_ = lean_box_uint64(v_res_47_);
return v_r_48_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__4(uint64_t v_r_49_, lean_object* v_a_50_){
_start:
{
lean_object* v_intZero_51_; uint8_t v_isNeg_52_; 
v_intZero_51_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_52_ = lean_int_dec_lt(v_a_50_, v_intZero_51_);
if (v_isNeg_52_ == 0)
{
lean_object* v_a_53_; lean_object* v___x_54_; lean_object* v___x_55_; uint64_t v___x_56_; uint64_t v___x_57_; 
v_a_53_ = lean_nat_abs(v_a_50_);
v___x_54_ = lean_unsigned_to_nat(2u);
v___x_55_ = lean_nat_mul(v___x_54_, v_a_53_);
lean_dec(v_a_53_);
v___x_56_ = lean_uint64_of_nat(v___x_55_);
lean_dec(v___x_55_);
v___x_57_ = lean_uint64_mix_hash(v_r_49_, v___x_56_);
return v___x_57_;
}
else
{
lean_object* v_abs_58_; lean_object* v_one_59_; lean_object* v_a_60_; lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v___x_63_; uint64_t v___x_64_; uint64_t v___x_65_; 
v_abs_58_ = lean_nat_abs(v_a_50_);
v_one_59_ = lean_unsigned_to_nat(1u);
v_a_60_ = lean_nat_sub(v_abs_58_, v_one_59_);
lean_dec(v_abs_58_);
v___x_61_ = lean_unsigned_to_nat(2u);
v___x_62_ = lean_nat_mul(v___x_61_, v_a_60_);
lean_dec(v_a_60_);
v___x_63_ = lean_nat_add(v___x_62_, v_one_59_);
lean_dec(v___x_62_);
v___x_64_ = lean_uint64_of_nat(v___x_63_);
lean_dec(v___x_63_);
v___x_65_ = lean_uint64_mix_hash(v_r_49_, v___x_64_);
return v___x_65_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__4___boxed(lean_object* v_r_66_, lean_object* v_a_67_){
_start:
{
uint64_t v_r_boxed_68_; uint64_t v_res_69_; lean_object* v_r_70_; 
v_r_boxed_68_ = lean_unbox_uint64(v_r_66_);
lean_dec_ref(v_r_66_);
v_res_69_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__4(v_r_boxed_68_, v_a_67_);
lean_dec(v_a_67_);
v_r_70_ = lean_box_uint64(v_res_69_);
return v_r_70_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__3(lean_object* v___f_71_, uint64_t v_x1_72_, lean_object* v_x2_73_){
_start:
{
lean_object* v___x_74_; lean_object* v___x_75_; uint64_t v___x_76_; uint64_t v___x_77_; 
v___x_74_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_75_ = l_List_foldl___redArg(v___f_71_, v___x_74_, v_x2_73_);
v___x_76_ = lean_unbox_uint64(v___x_75_);
lean_dec(v___x_75_);
v___x_77_ = lean_uint64_mix_hash(v_x1_72_, v___x_76_);
return v___x_77_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__3___boxed(lean_object* v___f_78_, lean_object* v_x1_79_, lean_object* v_x2_80_){
_start:
{
uint64_t v_x1_769__boxed_81_; uint64_t v_res_82_; lean_object* v_r_83_; 
v_x1_769__boxed_81_ = lean_unbox_uint64(v_x1_79_);
lean_dec_ref(v_x1_79_);
v_res_82_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__3(v___f_78_, v_x1_769__boxed_81_, v_x2_80_);
v_r_83_ = lean_box_uint64(v_res_82_);
return v_r_83_;
}
}
LEAN_EXPORT uint64_t lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5(lean_object* v___f_103_, lean_object* v___f_104_, lean_object* v___f_105_, lean_object* v___f_106_, lean_object* v_i_107_){
_start:
{
lean_object* v_system_108_; lean_object* v_arity_109_; lean_object* v_size_110_; lean_object* v_rows_111_; lean_object* v_columns_112_; lean_object* v_counts_113_; lean_object* v_values_114_; lean_object* v_inverse_115_; lean_object* v_denominator_116_; uint64_t v___x_117_; uint64_t v___x_118_; uint64_t v___x_119_; uint64_t v___y_121_; uint64_t v___y_122_; uint64_t v___y_123_; uint64_t v___y_124_; uint64_t v___y_125_; uint64_t v___y_134_; uint64_t v___y_135_; uint64_t v___y_136_; uint64_t v___y_137_; uint64_t v___y_152_; uint64_t v___y_153_; uint64_t v___y_154_; uint64_t v___y_166_; uint64_t v___y_167_; uint64_t v___y_179_; uint64_t v___x_190_; lean_object* v___x_191_; lean_object* v___x_192_; lean_object* v___x_193_; uint8_t v___x_194_; 
v_system_108_ = lean_ctor_get(v_i_107_, 2);
lean_inc_ref(v_system_108_);
v_arity_109_ = lean_ctor_get(v_i_107_, 0);
lean_inc(v_arity_109_);
v_size_110_ = lean_ctor_get(v_i_107_, 1);
lean_inc_n(v_size_110_, 3);
lean_dec_ref(v_i_107_);
v_rows_111_ = lean_ctor_get(v_system_108_, 0);
lean_inc_ref(v_rows_111_);
v_columns_112_ = lean_ctor_get(v_system_108_, 1);
lean_inc_ref(v_columns_112_);
v_counts_113_ = lean_ctor_get(v_system_108_, 2);
lean_inc_ref(v_counts_113_);
v_values_114_ = lean_ctor_get(v_system_108_, 3);
lean_inc_ref(v_values_114_);
v_inverse_115_ = lean_ctor_get(v_system_108_, 4);
lean_inc_ref(v_inverse_115_);
v_denominator_116_ = lean_ctor_get(v_system_108_, 5);
lean_inc(v_denominator_116_);
lean_dec_ref(v_system_108_);
v___x_117_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_110_, v_size_110_, v_inverse_115_);
v___x_118_ = lean_uint64_of_nat(v_arity_109_);
lean_dec(v_arity_109_);
v___x_119_ = lean_uint64_of_nat(v_size_110_);
lean_dec(v_size_110_);
v___x_190_ = 7ULL;
v___x_191_ = lean_unsigned_to_nat(0u);
v___x_192_ = lean_array_get_size(v_rows_111_);
v___x_193_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_194_ = lean_nat_dec_lt(v___x_191_, v___x_192_);
if (v___x_194_ == 0)
{
lean_dec_ref(v_rows_111_);
lean_dec_ref(v___f_106_);
v___y_179_ = v___x_190_;
goto v___jp_178_;
}
else
{
size_t v___x_195_; size_t v___x_196_; lean_object* v___x_197_; lean_object* v___x_198_; uint64_t v___x_199_; 
v___x_195_ = ((size_t)0ULL);
v___x_196_ = lean_usize_of_nat(v___x_192_);
v___x_197_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_198_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_193_, v___f_106_, v_rows_111_, v___x_195_, v___x_196_, v___x_197_);
v___x_199_ = lean_unbox_uint64(v___x_198_);
lean_dec(v___x_198_);
v___y_179_ = v___x_199_;
goto v___jp_178_;
}
v___jp_120_:
{
uint64_t v___x_126_; uint64_t v___x_127_; uint64_t v___x_128_; uint64_t v___x_129_; uint64_t v___x_130_; uint64_t v___x_131_; uint64_t v___x_132_; 
v___x_126_ = lean_uint64_mix_hash(v___x_117_, v___y_125_);
v___x_127_ = lean_uint64_mix_hash(v___y_124_, v___x_126_);
v___x_128_ = lean_uint64_mix_hash(v___y_123_, v___x_127_);
v___x_129_ = lean_uint64_mix_hash(v___y_122_, v___x_128_);
v___x_130_ = lean_uint64_mix_hash(v___y_121_, v___x_129_);
v___x_131_ = lean_uint64_mix_hash(v___x_119_, v___x_130_);
v___x_132_ = lean_uint64_mix_hash(v___x_118_, v___x_131_);
return v___x_132_;
}
v___jp_133_:
{
lean_object* v_intZero_138_; uint8_t v_isNeg_139_; 
v_intZero_138_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_139_ = lean_int_dec_lt(v_denominator_116_, v_intZero_138_);
if (v_isNeg_139_ == 0)
{
lean_object* v_a_140_; lean_object* v___x_141_; lean_object* v___x_142_; uint64_t v___x_143_; 
v_a_140_ = lean_nat_abs(v_denominator_116_);
lean_dec(v_denominator_116_);
v___x_141_ = lean_unsigned_to_nat(2u);
v___x_142_ = lean_nat_mul(v___x_141_, v_a_140_);
lean_dec(v_a_140_);
v___x_143_ = lean_uint64_of_nat(v___x_142_);
lean_dec(v___x_142_);
v___y_121_ = v___y_134_;
v___y_122_ = v___y_135_;
v___y_123_ = v___y_136_;
v___y_124_ = v___y_137_;
v___y_125_ = v___x_143_;
goto v___jp_120_;
}
else
{
lean_object* v_abs_144_; lean_object* v_one_145_; lean_object* v_a_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; uint64_t v___x_150_; 
v_abs_144_ = lean_nat_abs(v_denominator_116_);
lean_dec(v_denominator_116_);
v_one_145_ = lean_unsigned_to_nat(1u);
v_a_146_ = lean_nat_sub(v_abs_144_, v_one_145_);
lean_dec(v_abs_144_);
v___x_147_ = lean_unsigned_to_nat(2u);
v___x_148_ = lean_nat_mul(v___x_147_, v_a_146_);
lean_dec(v_a_146_);
v___x_149_ = lean_nat_add(v___x_148_, v_one_145_);
lean_dec(v___x_148_);
v___x_150_ = lean_uint64_of_nat(v___x_149_);
lean_dec(v___x_149_);
v___y_121_ = v___y_134_;
v___y_122_ = v___y_135_;
v___y_123_ = v___y_136_;
v___y_124_ = v___y_137_;
v___y_125_ = v___x_150_;
goto v___jp_120_;
}
}
v___jp_151_:
{
uint64_t v___x_155_; lean_object* v___x_156_; lean_object* v___x_157_; lean_object* v___x_158_; uint8_t v___x_159_; 
v___x_155_ = 7ULL;
v___x_156_ = lean_unsigned_to_nat(0u);
v___x_157_ = lean_array_get_size(v_values_114_);
v___x_158_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_159_ = lean_nat_dec_lt(v___x_156_, v___x_157_);
if (v___x_159_ == 0)
{
lean_dec_ref(v_values_114_);
lean_dec_ref(v___f_103_);
v___y_134_ = v___y_152_;
v___y_135_ = v___y_153_;
v___y_136_ = v___y_154_;
v___y_137_ = v___x_155_;
goto v___jp_133_;
}
else
{
size_t v___x_160_; size_t v___x_161_; lean_object* v___x_162_; lean_object* v___x_163_; uint64_t v___x_164_; 
v___x_160_ = ((size_t)0ULL);
v___x_161_ = lean_usize_of_nat(v___x_157_);
v___x_162_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_163_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_158_, v___f_103_, v_values_114_, v___x_160_, v___x_161_, v___x_162_);
v___x_164_ = lean_unbox_uint64(v___x_163_);
lean_dec(v___x_163_);
v___y_134_ = v___y_152_;
v___y_135_ = v___y_153_;
v___y_136_ = v___y_154_;
v___y_137_ = v___x_164_;
goto v___jp_133_;
}
}
v___jp_165_:
{
uint64_t v___x_168_; lean_object* v___x_169_; lean_object* v___x_170_; lean_object* v___x_171_; uint8_t v___x_172_; 
v___x_168_ = 7ULL;
v___x_169_ = lean_unsigned_to_nat(0u);
v___x_170_ = lean_array_get_size(v_counts_113_);
v___x_171_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_172_ = lean_nat_dec_lt(v___x_169_, v___x_170_);
if (v___x_172_ == 0)
{
lean_dec_ref(v_counts_113_);
lean_dec_ref(v___f_104_);
v___y_152_ = v___y_166_;
v___y_153_ = v___y_167_;
v___y_154_ = v___x_168_;
goto v___jp_151_;
}
else
{
size_t v___x_173_; size_t v___x_174_; lean_object* v___x_175_; lean_object* v___x_176_; uint64_t v___x_177_; 
v___x_173_ = ((size_t)0ULL);
v___x_174_ = lean_usize_of_nat(v___x_170_);
v___x_175_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_176_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_171_, v___f_104_, v_counts_113_, v___x_173_, v___x_174_, v___x_175_);
v___x_177_ = lean_unbox_uint64(v___x_176_);
lean_dec(v___x_176_);
v___y_152_ = v___y_166_;
v___y_153_ = v___y_167_;
v___y_154_ = v___x_177_;
goto v___jp_151_;
}
}
v___jp_178_:
{
uint64_t v___x_180_; lean_object* v___x_181_; lean_object* v___x_182_; lean_object* v___x_183_; uint8_t v___x_184_; 
v___x_180_ = 7ULL;
v___x_181_ = lean_unsigned_to_nat(0u);
v___x_182_ = lean_array_get_size(v_columns_112_);
v___x_183_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_184_ = lean_nat_dec_lt(v___x_181_, v___x_182_);
if (v___x_184_ == 0)
{
lean_dec_ref(v_columns_112_);
lean_dec_ref(v___f_105_);
v___y_166_ = v___y_179_;
v___y_167_ = v___x_180_;
goto v___jp_165_;
}
else
{
size_t v___x_185_; size_t v___x_186_; lean_object* v___x_187_; lean_object* v___x_188_; uint64_t v___x_189_; 
v___x_185_ = ((size_t)0ULL);
v___x_186_ = lean_usize_of_nat(v___x_182_);
v___x_187_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_188_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_183_, v___f_105_, v_columns_112_, v___x_185_, v___x_186_, v___x_187_);
v___x_189_ = lean_unbox_uint64(v___x_188_);
lean_dec(v___x_188_);
v___y_166_ = v___y_179_;
v___y_167_ = v___x_189_;
goto v___jp_165_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___boxed(lean_object* v___f_200_, lean_object* v___f_201_, lean_object* v___f_202_, lean_object* v___f_203_, lean_object* v_i_204_){
_start:
{
uint64_t v_res_205_; lean_object* v_r_206_; 
v_res_205_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5(v___f_200_, v___f_201_, v___f_202_, v___f_203_, v_i_204_);
v_r_206_ = lean_box_uint64(v_res_205_);
return v_r_206_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__0(lean_object* v___x_219_, lean_object* v_es_220_, lean_object* v_i_221_){
_start:
{
lean_object* v___x_222_; 
v___x_222_ = lean_array_get_borrowed(v___x_219_, v_es_220_, v_i_221_);
lean_inc(v___x_222_);
return v___x_222_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__0___boxed(lean_object* v___x_223_, lean_object* v_es_224_, lean_object* v_i_225_){
_start:
{
lean_object* v_res_226_; 
v_res_226_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__0(v___x_223_, v_es_224_, v_i_225_);
lean_dec(v_i_225_);
lean_dec_ref(v_es_224_);
lean_dec(v___x_223_);
return v_res_226_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__1(lean_object* v___x_227_, lean_object* v_cs_228_, lean_object* v_i_229_){
_start:
{
lean_object* v___x_230_; 
v___x_230_ = lean_array_get_borrowed(v___x_227_, v_cs_228_, v_i_229_);
lean_inc(v___x_230_);
return v___x_230_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__1___boxed(lean_object* v___x_231_, lean_object* v_cs_232_, lean_object* v_i_233_){
_start:
{
lean_object* v_res_234_; 
v_res_234_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__1(v___x_231_, v_cs_232_, v_i_233_);
lean_dec(v_i_233_);
lean_dec_ref(v_cs_232_);
lean_dec(v___x_231_);
return v_res_234_;
}
}
static lean_object* _init_lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0(void){
_start:
{
lean_object* v___x_235_; lean_object* v___x_236_; 
v___x_235_ = lean_unsigned_to_nat(1u);
v___x_236_ = lean_nat_to_int(v___x_235_);
return v___x_236_;
}
}
LEAN_EXPORT uint8_t lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0(lean_object* v_x_237_){
_start:
{
if (lean_obj_tag(v_x_237_) == 0)
{
uint8_t v___x_238_; 
v___x_238_ = 1;
return v___x_238_;
}
else
{
lean_object* v_head_239_; lean_object* v_tail_240_; lean_object* v___x_241_; uint8_t v___x_242_; 
v_head_239_ = lean_ctor_get(v_x_237_, 0);
v_tail_240_ = lean_ctor_get(v_x_237_, 1);
v___x_241_ = lean_obj_once(&lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0, &lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0_once, _init_lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0);
v___x_242_ = lean_int_dec_eq(v_head_239_, v___x_241_);
if (v___x_242_ == 0)
{
return v___x_242_;
}
else
{
v_x_237_ = v_tail_240_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___boxed(lean_object* v_x_244_){
_start:
{
uint8_t v_res_245_; lean_object* v_r_246_; 
v_res_245_ = lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0(v_x_244_);
lean_dec(v_x_244_);
v_r_246_ = lean_box(v_res_245_);
return v_r_246_;
}
}
static lean_object* _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__7(void){
_start:
{
lean_object* v___x_262_; lean_object* v___x_263_; 
v___x_262_ = lean_obj_once(&lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0, &lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0_once, _init_lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0);
v___x_263_ = lean_int_neg(v___x_262_);
return v___x_263_;
}
}
static lean_object* _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__8(void){
_start:
{
lean_object* v___x_264_; lean_object* v___x_265_; lean_object* v___x_266_; 
v___x_264_ = lean_box(0);
v___x_265_ = lean_obj_once(&lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0, &lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0_once, _init_lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0);
v___x_266_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_266_, 0, v___x_265_);
lean_ctor_set(v___x_266_, 1, v___x_264_);
return v___x_266_;
}
}
static lean_object* _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__9(void){
_start:
{
lean_object* v___x_267_; lean_object* v___x_268_; lean_object* v___x_269_; 
v___x_267_ = lean_obj_once(&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__8, &lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__8_once, _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__8);
v___x_268_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v___x_269_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_269_, 0, v___x_268_);
lean_ctor_set(v___x_269_, 1, v___x_267_);
return v___x_269_;
}
}
static lean_object* _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__10(void){
_start:
{
lean_object* v___x_270_; lean_object* v___x_271_; lean_object* v___x_272_; 
v___x_270_ = lean_obj_once(&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__9, &lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__9_once, _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__9);
v___x_271_ = lean_obj_once(&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__7, &lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__7_once, _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__7);
v___x_272_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_272_, 0, v___x_271_);
lean_ctor_set(v___x_272_, 1, v___x_270_);
return v___x_272_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build(lean_object* v_s_276_){
_start:
{
lean_object* v___x_281_; lean_object* v_r_282_; lean_object* v___x_283_; lean_object* v___x_284_; lean_object* v___x_285_; lean_object* v_es_286_; lean_object* v___x_287_; uint8_t v___x_288_; 
v___x_281_ = lean_unsigned_to_nat(3u);
v_r_282_ = lean_nat_pow(v___x_281_, v_s_276_);
v___x_283_ = lean_box(0);
v___x_284_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__6));
v___x_285_ = lp_Hex_Hex_SignDet_words___redArg(v___x_284_, v_s_276_);
v_es_286_ = lean_array_mk(v___x_285_);
v___x_287_ = lean_array_get_size(v_es_286_);
v___x_288_ = lean_nat_dec_eq(v___x_287_, v_r_282_);
if (v___x_288_ == 0)
{
lean_dec_ref(v_es_286_);
lean_dec(v_r_282_);
lean_dec(v_s_276_);
goto v___jp_277_;
}
else
{
lean_object* v___x_289_; lean_object* v___x_290_; lean_object* v_cs_291_; lean_object* v___x_292_; uint8_t v___x_293_; 
v___x_289_ = lean_obj_once(&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__10, &lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__10_once, _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__10);
v___x_290_ = lp_Hex_Hex_SignDet_words___redArg(v___x_289_, v_s_276_);
v_cs_291_ = lean_array_mk(v___x_290_);
v___x_292_ = lean_array_get_size(v_cs_291_);
v___x_293_ = lean_nat_dec_eq(v___x_292_, v_r_282_);
if (v___x_293_ == 0)
{
lean_dec_ref(v_cs_291_);
lean_dec_ref(v_es_286_);
lean_dec(v_r_282_);
lean_dec(v_s_276_);
goto v___jp_277_;
}
else
{
lean_object* v___f_294_; lean_object* v___f_295_; lean_object* v_rows_296_; lean_object* v_cols_297_; lean_object* v___x_298_; lean_object* v_values_299_; lean_object* v___x_300_; 
v___f_294_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__0___boxed), 3, 2);
lean_closure_set(v___f_294_, 0, v___x_283_);
lean_closure_set(v___f_294_, 1, v_es_286_);
v___f_295_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___lam__1___boxed), 3, 2);
lean_closure_set(v___f_295_, 0, v___x_283_);
lean_closure_set(v___f_295_, 1, v_cs_291_);
lean_inc_n(v_r_282_, 4);
v_rows_296_ = l_Array_ofFn___redArg(v_r_282_, v___f_294_);
v_cols_297_ = l_Array_ofFn___redArg(v_r_282_, v___f_295_);
lean_inc_ref(v_cols_297_);
v___x_298_ = lean_array_to_list(v_cols_297_);
lean_inc_ref(v_rows_296_);
v_values_299_ = lp_Hex_Hex_SignDet_moments(v_r_282_, v_rows_296_, v___x_298_);
v___x_300_ = lp_Hex_Hex_SignDet_solveSystem(v_r_282_, v_s_276_, v_rows_296_, v_cols_297_, v_values_299_);
if (lean_obj_tag(v___x_300_) == 1)
{
lean_object* v_a_301_; lean_object* v___x_303_; uint8_t v_isShared_304_; uint8_t v_isSharedCheck_313_; 
v_a_301_ = lean_ctor_get(v___x_300_, 0);
v_isSharedCheck_313_ = !lean_is_exclusive(v___x_300_);
if (v_isSharedCheck_313_ == 0)
{
v___x_303_ = v___x_300_;
v_isShared_304_ = v_isSharedCheck_313_;
goto v_resetjp_302_;
}
else
{
lean_inc(v_a_301_);
lean_dec(v___x_300_);
v___x_303_ = lean_box(0);
v_isShared_304_ = v_isSharedCheck_313_;
goto v_resetjp_302_;
}
v_resetjp_302_:
{
lean_object* v_counts_305_; lean_object* v___x_306_; uint8_t v___x_307_; 
v_counts_305_ = lean_ctor_get(v_a_301_, 2);
lean_inc_ref(v_counts_305_);
v___x_306_ = lean_array_to_list(v_counts_305_);
v___x_307_ = lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0(v___x_306_);
lean_dec(v___x_306_);
if (v___x_307_ == 0)
{
lean_del_object(v___x_303_);
lean_dec(v_a_301_);
lean_dec(v_r_282_);
lean_dec(v_s_276_);
goto v___jp_279_;
}
else
{
uint8_t v___x_308_; 
lean_inc(v_a_301_);
lean_inc(v_r_282_);
v___x_308_ = lp_Hex_Hex_SignDet_System_check(v_r_282_, v_s_276_, v_a_301_);
if (v___x_308_ == 0)
{
lean_del_object(v___x_303_);
lean_dec(v_a_301_);
lean_dec(v_r_282_);
lean_dec(v_s_276_);
goto v___jp_279_;
}
else
{
lean_object* v___x_309_; lean_object* v___x_311_; 
v___x_309_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_309_, 0, v_s_276_);
lean_ctor_set(v___x_309_, 1, v_r_282_);
lean_ctor_set(v___x_309_, 2, v_a_301_);
if (v_isShared_304_ == 0)
{
lean_ctor_set(v___x_303_, 0, v___x_309_);
v___x_311_ = v___x_303_;
goto v_reusejp_310_;
}
else
{
lean_object* v_reuseFailAlloc_312_; 
v_reuseFailAlloc_312_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_312_, 0, v___x_309_);
v___x_311_ = v_reuseFailAlloc_312_;
goto v_reusejp_310_;
}
v_reusejp_310_:
{
return v___x_311_;
}
}
}
}
}
else
{
lean_object* v___x_314_; 
lean_dec_ref(v___x_300_);
lean_dec(v_r_282_);
lean_dec(v_s_276_);
v___x_314_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__12));
return v___x_314_;
}
}
}
v___jp_277_:
{
lean_object* v___x_278_; 
v___x_278_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__1));
return v___x_278_;
}
v___jp_279_:
{
lean_object* v___x_280_; 
v___x_280_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__3));
return v___x_280_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_input(lean_object* v_s_315_){
_start:
{
lean_object* v___x_316_; 
v___x_316_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build(v_s_315_);
if (lean_obj_tag(v___x_316_) == 0)
{
lean_object* v___x_317_; 
lean_dec_ref_known(v___x_316_, 1);
v___x_317_ = lean_box(0);
return v___x_317_;
}
else
{
lean_object* v_a_318_; lean_object* v___x_320_; uint8_t v_isShared_321_; uint8_t v_isSharedCheck_325_; 
v_a_318_ = lean_ctor_get(v___x_316_, 0);
v_isSharedCheck_325_ = !lean_is_exclusive(v___x_316_);
if (v_isSharedCheck_325_ == 0)
{
v___x_320_ = v___x_316_;
v_isShared_321_ = v_isSharedCheck_325_;
goto v_resetjp_319_;
}
else
{
lean_inc(v_a_318_);
lean_dec(v___x_316_);
v___x_320_ = lean_box(0);
v_isShared_321_ = v_isSharedCheck_325_;
goto v_resetjp_319_;
}
v_resetjp_319_:
{
lean_object* v___x_323_; 
if (v_isShared_321_ == 0)
{
v___x_323_ = v___x_320_;
goto v_reusejp_322_;
}
else
{
lean_object* v_reuseFailAlloc_324_; 
v_reuseFailAlloc_324_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_324_, 0, v_a_318_);
v___x_323_ = v_reuseFailAlloc_324_;
goto v_reusejp_322_;
}
v_reusejp_322_:
{
return v___x_323_;
}
}
}
}
}
LEAN_EXPORT uint64_t lp_Hex_List_foldl___at___00Hex_SignDetBench_MaximalMatrix_runSolve_spec__0(uint64_t v_x_326_, lean_object* v_x_327_){
_start:
{
if (lean_obj_tag(v_x_327_) == 0)
{
return v_x_326_;
}
else
{
lean_object* v_head_328_; lean_object* v_tail_329_; lean_object* v_fst_330_; lean_object* v_snd_331_; uint64_t v___x_332_; uint64_t v___x_333_; uint64_t v___y_335_; lean_object* v_intZero_339_; uint8_t v_isNeg_340_; 
v_head_328_ = lean_ctor_get(v_x_327_, 0);
v_tail_329_ = lean_ctor_get(v_x_327_, 1);
v_fst_330_ = lean_ctor_get(v_head_328_, 0);
v_snd_331_ = lean_ctor_get(v_head_328_, 1);
v___x_332_ = 7ULL;
v___x_333_ = l_List_foldl___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_Elab_Tactic_Omega_Problem_insertConstraint_spec__0_spec__0(v___x_332_, v_fst_330_);
v_intZero_339_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_340_ = lean_int_dec_lt(v_snd_331_, v_intZero_339_);
if (v_isNeg_340_ == 0)
{
lean_object* v_a_341_; lean_object* v___x_342_; lean_object* v___x_343_; uint64_t v___x_344_; 
v_a_341_ = lean_nat_abs(v_snd_331_);
v___x_342_ = lean_unsigned_to_nat(2u);
v___x_343_ = lean_nat_mul(v___x_342_, v_a_341_);
lean_dec(v_a_341_);
v___x_344_ = lean_uint64_of_nat(v___x_343_);
lean_dec(v___x_343_);
v___y_335_ = v___x_344_;
goto v___jp_334_;
}
else
{
lean_object* v_abs_345_; lean_object* v_one_346_; lean_object* v_a_347_; lean_object* v___x_348_; lean_object* v___x_349_; lean_object* v___x_350_; uint64_t v___x_351_; 
v_abs_345_ = lean_nat_abs(v_snd_331_);
v_one_346_ = lean_unsigned_to_nat(1u);
v_a_347_ = lean_nat_sub(v_abs_345_, v_one_346_);
lean_dec(v_abs_345_);
v___x_348_ = lean_unsigned_to_nat(2u);
v___x_349_ = lean_nat_mul(v___x_348_, v_a_347_);
lean_dec(v_a_347_);
v___x_350_ = lean_nat_add(v___x_349_, v_one_346_);
lean_dec(v___x_349_);
v___x_351_ = lean_uint64_of_nat(v___x_350_);
lean_dec(v___x_350_);
v___y_335_ = v___x_351_;
goto v___jp_334_;
}
v___jp_334_:
{
uint64_t v___x_336_; uint64_t v___x_337_; 
v___x_336_ = lean_uint64_mix_hash(v___x_333_, v___y_335_);
v___x_337_ = lean_uint64_mix_hash(v_x_326_, v___x_336_);
v_x_326_ = v___x_337_;
v_x_327_ = v_tail_329_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00Hex_SignDetBench_MaximalMatrix_runSolve_spec__0___boxed(lean_object* v_x_352_, lean_object* v_x_353_){
_start:
{
uint64_t v_x_251__boxed_354_; uint64_t v_res_355_; lean_object* v_r_356_; 
v_x_251__boxed_354_ = lean_unbox_uint64(v_x_352_);
lean_dec_ref(v_x_352_);
v_res_355_ = lp_Hex_List_foldl___at___00Hex_SignDetBench_MaximalMatrix_runSolve_spec__0(v_x_251__boxed_354_, v_x_353_);
lean_dec(v_x_353_);
v_r_356_ = lean_box_uint64(v_res_355_);
return v_r_356_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolve(lean_object* v_i_357_){
_start:
{
if (lean_obj_tag(v_i_357_) == 0)
{
lean_object* v___x_358_; 
v___x_358_ = lean_box(0);
return v___x_358_;
}
else
{
lean_object* v_val_359_; lean_object* v___x_361_; uint8_t v_isShared_362_; uint8_t v_isSharedCheck_379_; 
v_val_359_ = lean_ctor_get(v_i_357_, 0);
v_isSharedCheck_379_ = !lean_is_exclusive(v_i_357_);
if (v_isSharedCheck_379_ == 0)
{
v___x_361_ = v_i_357_;
v_isShared_362_ = v_isSharedCheck_379_;
goto v_resetjp_360_;
}
else
{
lean_inc(v_val_359_);
lean_dec(v_i_357_);
v___x_361_ = lean_box(0);
v_isShared_362_ = v_isSharedCheck_379_;
goto v_resetjp_360_;
}
v_resetjp_360_:
{
lean_object* v_system_363_; lean_object* v_arity_364_; lean_object* v_size_365_; lean_object* v_rows_366_; lean_object* v_columns_367_; lean_object* v_values_368_; lean_object* v___x_369_; 
v_system_363_ = lean_ctor_get(v_val_359_, 2);
lean_inc_ref(v_system_363_);
v_arity_364_ = lean_ctor_get(v_val_359_, 0);
lean_inc(v_arity_364_);
v_size_365_ = lean_ctor_get(v_val_359_, 1);
lean_inc_n(v_size_365_, 2);
lean_dec(v_val_359_);
v_rows_366_ = lean_ctor_get(v_system_363_, 0);
lean_inc_ref(v_rows_366_);
v_columns_367_ = lean_ctor_get(v_system_363_, 1);
lean_inc_ref(v_columns_367_);
v_values_368_ = lean_ctor_get(v_system_363_, 3);
lean_inc_ref(v_values_368_);
lean_dec_ref(v_system_363_);
v___x_369_ = lp_Hex_Hex_SignDet_solveSystem(v_size_365_, v_arity_364_, v_rows_366_, v_columns_367_, v_values_368_);
lean_dec(v_arity_364_);
if (lean_obj_tag(v___x_369_) == 0)
{
lean_object* v___x_370_; 
lean_dec_ref_known(v___x_369_, 1);
lean_dec(v_size_365_);
lean_del_object(v___x_361_);
v___x_370_ = lean_box(0);
return v___x_370_;
}
else
{
lean_object* v_a_371_; lean_object* v___x_372_; uint64_t v___x_373_; uint64_t v___x_374_; lean_object* v___x_375_; lean_object* v___x_377_; 
v_a_371_ = lean_ctor_get(v___x_369_, 0);
lean_inc(v_a_371_);
lean_dec_ref_known(v___x_369_, 1);
v___x_372_ = lp_Hex_Hex_SignDetBench_entries(v_size_365_, v_a_371_);
lean_dec(v_a_371_);
v___x_373_ = 7ULL;
v___x_374_ = lp_Hex_List_foldl___at___00Hex_SignDetBench_MaximalMatrix_runSolve_spec__0(v___x_373_, v___x_372_);
lean_dec(v___x_372_);
v___x_375_ = lean_box_uint64(v___x_374_);
if (v_isShared_362_ == 0)
{
lean_ctor_set(v___x_361_, 0, v___x_375_);
v___x_377_ = v___x_361_;
goto v_reusejp_376_;
}
else
{
lean_object* v_reuseFailAlloc_378_; 
v_reuseFailAlloc_378_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_378_, 0, v___x_375_);
v___x_377_ = v_reuseFailAlloc_378_;
goto v_reusejp_376_;
}
v_reusejp_376_:
{
return v___x_377_;
}
}
}
}
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck(lean_object* v_i_380_){
_start:
{
if (lean_obj_tag(v_i_380_) == 0)
{
uint8_t v___x_381_; 
v___x_381_ = 0;
return v___x_381_;
}
else
{
lean_object* v_val_382_; lean_object* v_arity_383_; lean_object* v_size_384_; lean_object* v_system_385_; uint8_t v___x_386_; 
v_val_382_ = lean_ctor_get(v_i_380_, 0);
lean_inc(v_val_382_);
lean_dec_ref_known(v_i_380_, 1);
v_arity_383_ = lean_ctor_get(v_val_382_, 0);
lean_inc(v_arity_383_);
v_size_384_ = lean_ctor_get(v_val_382_, 1);
lean_inc(v_size_384_);
v_system_385_ = lean_ctor_get(v_val_382_, 2);
lean_inc_ref(v_system_385_);
lean_dec(v_val_382_);
v___x_386_ = lp_Hex_Hex_SignDet_System_check(v_size_384_, v_arity_383_, v_system_385_);
lean_dec(v_arity_383_);
return v___x_386_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck___boxed(lean_object* v_i_387_){
_start:
{
uint8_t v_res_388_; lean_object* v_r_389_; 
v_res_388_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck(v_i_387_);
v_r_389_ = lean_box(v_res_388_);
return v_r_389_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__complexity(lean_object* v_s_390_){
_start:
{
lean_object* v___x_391_; lean_object* v___x_392_; 
v___x_391_ = lean_unsigned_to_nat(27u);
v___x_392_ = lean_nat_pow(v___x_391_, v_s_390_);
return v___x_392_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__complexity___boxed(lean_object* v_s_393_){
_start:
{
lean_object* v_res_394_; 
v_res_394_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__complexity(v_s_393_);
lean_dec(v_s_393_);
return v_res_394_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__0(lean_object* v_s_395_, lean_object* v_a_396_, lean_object* v_x_397_, uint64_t v___y_398_){
_start:
{
uint64_t v___y_401_; lean_object* v___x_413_; 
v___x_413_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolve(v_s_395_);
if (lean_obj_tag(v___x_413_) == 0)
{
uint64_t v___x_414_; 
v___x_414_ = 11ULL;
v___y_401_ = v___x_414_;
goto v___jp_400_;
}
else
{
lean_object* v_val_415_; uint64_t v___x_416_; uint64_t v___x_417_; uint64_t v___x_418_; 
v_val_415_ = lean_ctor_get(v___x_413_, 0);
lean_inc(v_val_415_);
lean_dec_ref_known(v___x_413_, 1);
v___x_416_ = 13ULL;
v___x_417_ = lean_unbox_uint64(v_val_415_);
lean_dec(v_val_415_);
v___x_418_ = lean_uint64_mix_hash(v___x_417_, v___x_416_);
v___y_401_ = v___x_418_;
goto v___jp_400_;
}
v___jp_400_:
{
lean_object* v___x_402_; lean_object* v___x_404_; uint8_t v_isShared_405_; uint8_t v_isSharedCheck_411_; 
v___x_402_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_401_);
v_isSharedCheck_411_ = !lean_is_exclusive(v___x_402_);
if (v_isSharedCheck_411_ == 0)
{
lean_object* v_unused_412_; 
v_unused_412_ = lean_ctor_get(v___x_402_, 0);
lean_dec(v_unused_412_);
v___x_404_ = v___x_402_;
v_isShared_405_ = v_isSharedCheck_411_;
goto v_resetjp_403_;
}
else
{
lean_dec(v___x_402_);
v___x_404_ = lean_box(0);
v_isShared_405_ = v_isSharedCheck_411_;
goto v_resetjp_403_;
}
v_resetjp_403_:
{
lean_object* v___x_406_; lean_object* v___x_407_; lean_object* v___x_409_; 
v___x_406_ = lean_box_uint64(v___y_401_);
v___x_407_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_407_, 0, v___x_406_);
if (v_isShared_405_ == 0)
{
lean_ctor_set(v___x_404_, 0, v___x_407_);
v___x_409_ = v___x_404_;
goto v_reusejp_408_;
}
else
{
lean_object* v_reuseFailAlloc_410_; 
v_reuseFailAlloc_410_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_410_, 0, v___x_407_);
v___x_409_ = v_reuseFailAlloc_410_;
goto v_reusejp_408_;
}
v_reusejp_408_:
{
return v___x_409_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__0___boxed(lean_object* v_s_419_, lean_object* v_a_420_, lean_object* v_x_421_, lean_object* v___y_422_, lean_object* v___y_423_){
_start:
{
uint64_t v___y_816__boxed_424_; lean_object* v_res_425_; 
v___y_816__boxed_424_ = lean_unbox_uint64(v___y_422_);
lean_dec_ref(v___y_422_);
v_res_425_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__0(v_s_419_, v_a_420_, v_x_421_, v___y_816__boxed_424_);
lean_dec(v_a_420_);
return v_res_425_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1(lean_object* v___x_431_, lean_object* v___f_432_, lean_object* v_count_433_){
_start:
{
lean_object* v___x_435_; uint8_t v___x_436_; 
v___x_435_ = lean_unsigned_to_nat(0u);
v___x_436_ = lean_nat_dec_eq(v_count_433_, v___x_435_);
if (v___x_436_ == 0)
{
lean_object* v___x_437_; lean_object* v___x_438_; lean_object* v___x_439_; lean_object* v___x_440_; lean_object* v___x_744__overap_441_; lean_object* v___x_442_; 
v___x_437_ = lean_io_mono_nanos_now();
v___x_438_ = lean_unsigned_to_nat(1u);
v___x_439_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_439_, 0, v___x_435_);
lean_ctor_set(v___x_439_, 1, v_count_433_);
lean_ctor_set(v___x_439_, 2, v___x_438_);
v___x_440_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed__const__1));
v___x_744__overap_441_ = l___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___redArg(v___x_431_, v___x_439_, v___f_432_, v___x_440_, v___x_435_);
v___x_442_ = lean_apply_1(v___x_744__overap_441_, lean_box(0));
if (lean_obj_tag(v___x_442_) == 0)
{
lean_object* v_a_443_; lean_object* v___x_445_; uint8_t v_isShared_446_; uint8_t v_isSharedCheck_454_; 
v_a_443_ = lean_ctor_get(v___x_442_, 0);
v_isSharedCheck_454_ = !lean_is_exclusive(v___x_442_);
if (v_isSharedCheck_454_ == 0)
{
v___x_445_ = v___x_442_;
v_isShared_446_ = v_isSharedCheck_454_;
goto v_resetjp_444_;
}
else
{
lean_inc(v_a_443_);
lean_dec(v___x_442_);
v___x_445_ = lean_box(0);
v_isShared_446_ = v_isSharedCheck_454_;
goto v_resetjp_444_;
}
v_resetjp_444_:
{
lean_object* v___x_447_; lean_object* v___x_448_; lean_object* v___x_449_; lean_object* v___x_450_; lean_object* v___x_452_; 
v___x_447_ = lean_io_mono_nanos_now();
v___x_448_ = lean_nat_sub(v___x_447_, v___x_437_);
lean_dec(v___x_437_);
lean_dec(v___x_447_);
v___x_449_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_449_, 0, v_a_443_);
v___x_450_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_450_, 0, v___x_448_);
lean_ctor_set(v___x_450_, 1, v___x_449_);
if (v_isShared_446_ == 0)
{
lean_ctor_set(v___x_445_, 0, v___x_450_);
v___x_452_ = v___x_445_;
goto v_reusejp_451_;
}
else
{
lean_object* v_reuseFailAlloc_453_; 
v_reuseFailAlloc_453_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_453_, 0, v___x_450_);
v___x_452_ = v_reuseFailAlloc_453_;
goto v_reusejp_451_;
}
v_reusejp_451_:
{
return v___x_452_;
}
}
}
else
{
lean_object* v_a_455_; lean_object* v___x_457_; uint8_t v_isShared_458_; uint8_t v_isSharedCheck_462_; 
lean_dec(v___x_437_);
v_a_455_ = lean_ctor_get(v___x_442_, 0);
v_isSharedCheck_462_ = !lean_is_exclusive(v___x_442_);
if (v_isSharedCheck_462_ == 0)
{
v___x_457_ = v___x_442_;
v_isShared_458_ = v_isSharedCheck_462_;
goto v_resetjp_456_;
}
else
{
lean_inc(v_a_455_);
lean_dec(v___x_442_);
v___x_457_ = lean_box(0);
v_isShared_458_ = v_isSharedCheck_462_;
goto v_resetjp_456_;
}
v_resetjp_456_:
{
lean_object* v___x_460_; 
if (v_isShared_458_ == 0)
{
v___x_460_ = v___x_457_;
goto v_reusejp_459_;
}
else
{
lean_object* v_reuseFailAlloc_461_; 
v_reuseFailAlloc_461_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_461_, 0, v_a_455_);
v___x_460_ = v_reuseFailAlloc_461_;
goto v_reusejp_459_;
}
v_reusejp_459_:
{
return v___x_460_;
}
}
}
}
else
{
lean_object* v___x_463_; lean_object* v___x_464_; 
lean_dec(v_count_433_);
lean_dec_ref(v___f_432_);
lean_dec_ref(v___x_431_);
v___x_463_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___closed__0));
v___x_464_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_464_, 0, v___x_463_);
return v___x_464_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed(lean_object* v___x_465_, lean_object* v___f_466_, lean_object* v_count_467_, lean_object* v___y_468_){
_start:
{
lean_object* v_res_469_; 
v_res_469_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1(v___x_465_, v___f_466_, v_count_467_);
return v_res_469_;
}
}
static lean_object* _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0(void){
_start:
{
lean_object* v___x_470_; 
v___x_470_ = l_instMonadEIO___redArg();
return v___x_470_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked(lean_object* v_param_471_){
_start:
{
lean_object* v___x_473_; lean_object* v_s_474_; lean_object* v___f_475_; lean_object* v___f_476_; uint64_t v___y_478_; 
v___x_473_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0);
v_s_474_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_input(v_param_471_);
lean_inc(v_s_474_);
v___f_475_ = lean_alloc_closure((void*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__0___boxed), 5, 1);
lean_closure_set(v___f_475_, 0, v_s_474_);
v___f_476_ = lean_alloc_closure((void*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed), 4, 2);
lean_closure_set(v___f_476_, 0, v___x_473_);
lean_closure_set(v___f_476_, 1, v___f_475_);
if (lean_obj_tag(v_s_474_) == 0)
{
uint64_t v___x_488_; 
v___x_488_ = 11ULL;
v___y_478_ = v___x_488_;
goto v___jp_477_;
}
else
{
lean_object* v_val_489_; lean_object* v_system_490_; lean_object* v_arity_491_; lean_object* v_size_492_; lean_object* v_rows_493_; lean_object* v_columns_494_; lean_object* v_counts_495_; lean_object* v_values_496_; lean_object* v_inverse_497_; lean_object* v_denominator_498_; lean_object* v___f_499_; lean_object* v___f_500_; uint64_t v___x_501_; uint64_t v___x_502_; uint64_t v___x_503_; uint64_t v___y_505_; uint64_t v___y_506_; uint64_t v___y_507_; uint64_t v___y_508_; uint64_t v___y_509_; uint64_t v___y_520_; uint64_t v___y_521_; uint64_t v___y_522_; uint64_t v___y_523_; uint64_t v___y_538_; uint64_t v___y_539_; uint64_t v___y_540_; uint64_t v___y_552_; uint64_t v___y_553_; uint64_t v___y_565_; uint64_t v___x_576_; lean_object* v___x_577_; lean_object* v___x_578_; lean_object* v___x_579_; uint8_t v___x_580_; 
v_val_489_ = lean_ctor_get(v_s_474_, 0);
lean_inc(v_val_489_);
lean_dec_ref_known(v_s_474_, 1);
v_system_490_ = lean_ctor_get(v_val_489_, 2);
lean_inc_ref(v_system_490_);
v_arity_491_ = lean_ctor_get(v_val_489_, 0);
lean_inc(v_arity_491_);
v_size_492_ = lean_ctor_get(v_val_489_, 1);
lean_inc_n(v_size_492_, 3);
lean_dec(v_val_489_);
v_rows_493_ = lean_ctor_get(v_system_490_, 0);
lean_inc_ref(v_rows_493_);
v_columns_494_ = lean_ctor_get(v_system_490_, 1);
lean_inc_ref(v_columns_494_);
v_counts_495_ = lean_ctor_get(v_system_490_, 2);
lean_inc_ref(v_counts_495_);
v_values_496_ = lean_ctor_get(v_system_490_, 3);
lean_inc_ref(v_values_496_);
v_inverse_497_ = lean_ctor_get(v_system_490_, 4);
lean_inc_ref(v_inverse_497_);
v_denominator_498_ = lean_ctor_get(v_system_490_, 5);
lean_inc(v_denominator_498_);
lean_dec_ref(v_system_490_);
v___f_499_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__2));
v___f_500_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__4));
v___x_501_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_492_, v_size_492_, v_inverse_497_);
v___x_502_ = lean_uint64_of_nat(v_arity_491_);
lean_dec(v_arity_491_);
v___x_503_ = lean_uint64_of_nat(v_size_492_);
lean_dec(v_size_492_);
v___x_576_ = 7ULL;
v___x_577_ = lean_unsigned_to_nat(0u);
v___x_578_ = lean_array_get_size(v_rows_493_);
v___x_579_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_580_ = lean_nat_dec_lt(v___x_577_, v___x_578_);
if (v___x_580_ == 0)
{
lean_dec_ref(v_rows_493_);
v___y_565_ = v___x_576_;
goto v___jp_564_;
}
else
{
lean_object* v___f_581_; size_t v___x_582_; size_t v___x_583_; lean_object* v___x_584_; lean_object* v___x_585_; uint64_t v___x_586_; 
v___f_581_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__1));
v___x_582_ = ((size_t)0ULL);
v___x_583_ = lean_usize_of_nat(v___x_578_);
v___x_584_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_585_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_579_, v___f_581_, v_rows_493_, v___x_582_, v___x_583_, v___x_584_);
v___x_586_ = lean_unbox_uint64(v___x_585_);
lean_dec(v___x_585_);
v___y_565_ = v___x_586_;
goto v___jp_564_;
}
v___jp_504_:
{
uint64_t v___x_510_; uint64_t v___x_511_; uint64_t v___x_512_; uint64_t v___x_513_; uint64_t v___x_514_; uint64_t v___x_515_; uint64_t v___x_516_; uint64_t v___x_517_; uint64_t v___x_518_; 
v___x_510_ = lean_uint64_mix_hash(v___x_501_, v___y_509_);
v___x_511_ = lean_uint64_mix_hash(v___y_507_, v___x_510_);
v___x_512_ = lean_uint64_mix_hash(v___y_508_, v___x_511_);
v___x_513_ = lean_uint64_mix_hash(v___y_506_, v___x_512_);
v___x_514_ = lean_uint64_mix_hash(v___y_505_, v___x_513_);
v___x_515_ = lean_uint64_mix_hash(v___x_503_, v___x_514_);
v___x_516_ = lean_uint64_mix_hash(v___x_502_, v___x_515_);
v___x_517_ = 13ULL;
v___x_518_ = lean_uint64_mix_hash(v___x_516_, v___x_517_);
v___y_478_ = v___x_518_;
goto v___jp_477_;
}
v___jp_519_:
{
lean_object* v_intZero_524_; uint8_t v_isNeg_525_; 
v_intZero_524_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_525_ = lean_int_dec_lt(v_denominator_498_, v_intZero_524_);
if (v_isNeg_525_ == 0)
{
lean_object* v_a_526_; lean_object* v___x_527_; lean_object* v___x_528_; uint64_t v___x_529_; 
v_a_526_ = lean_nat_abs(v_denominator_498_);
lean_dec(v_denominator_498_);
v___x_527_ = lean_unsigned_to_nat(2u);
v___x_528_ = lean_nat_mul(v___x_527_, v_a_526_);
lean_dec(v_a_526_);
v___x_529_ = lean_uint64_of_nat(v___x_528_);
lean_dec(v___x_528_);
v___y_505_ = v___y_521_;
v___y_506_ = v___y_520_;
v___y_507_ = v___y_523_;
v___y_508_ = v___y_522_;
v___y_509_ = v___x_529_;
goto v___jp_504_;
}
else
{
lean_object* v_abs_530_; lean_object* v_one_531_; lean_object* v_a_532_; lean_object* v___x_533_; lean_object* v___x_534_; lean_object* v___x_535_; uint64_t v___x_536_; 
v_abs_530_ = lean_nat_abs(v_denominator_498_);
lean_dec(v_denominator_498_);
v_one_531_ = lean_unsigned_to_nat(1u);
v_a_532_ = lean_nat_sub(v_abs_530_, v_one_531_);
lean_dec(v_abs_530_);
v___x_533_ = lean_unsigned_to_nat(2u);
v___x_534_ = lean_nat_mul(v___x_533_, v_a_532_);
lean_dec(v_a_532_);
v___x_535_ = lean_nat_add(v___x_534_, v_one_531_);
lean_dec(v___x_534_);
v___x_536_ = lean_uint64_of_nat(v___x_535_);
lean_dec(v___x_535_);
v___y_505_ = v___y_521_;
v___y_506_ = v___y_520_;
v___y_507_ = v___y_523_;
v___y_508_ = v___y_522_;
v___y_509_ = v___x_536_;
goto v___jp_504_;
}
}
v___jp_537_:
{
uint64_t v___x_541_; lean_object* v___x_542_; lean_object* v___x_543_; lean_object* v___x_544_; uint8_t v___x_545_; 
v___x_541_ = 7ULL;
v___x_542_ = lean_unsigned_to_nat(0u);
v___x_543_ = lean_array_get_size(v_values_496_);
v___x_544_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_545_ = lean_nat_dec_lt(v___x_542_, v___x_543_);
if (v___x_545_ == 0)
{
lean_dec_ref(v_values_496_);
v___y_520_ = v___y_539_;
v___y_521_ = v___y_538_;
v___y_522_ = v___y_540_;
v___y_523_ = v___x_541_;
goto v___jp_519_;
}
else
{
size_t v___x_546_; size_t v___x_547_; lean_object* v___x_548_; lean_object* v___x_549_; uint64_t v___x_550_; 
v___x_546_ = ((size_t)0ULL);
v___x_547_ = lean_usize_of_nat(v___x_543_);
v___x_548_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_549_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_544_, v___f_499_, v_values_496_, v___x_546_, v___x_547_, v___x_548_);
v___x_550_ = lean_unbox_uint64(v___x_549_);
lean_dec(v___x_549_);
v___y_520_ = v___y_539_;
v___y_521_ = v___y_538_;
v___y_522_ = v___y_540_;
v___y_523_ = v___x_550_;
goto v___jp_519_;
}
}
v___jp_551_:
{
uint64_t v___x_554_; lean_object* v___x_555_; lean_object* v___x_556_; lean_object* v___x_557_; uint8_t v___x_558_; 
v___x_554_ = 7ULL;
v___x_555_ = lean_unsigned_to_nat(0u);
v___x_556_ = lean_array_get_size(v_counts_495_);
v___x_557_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_558_ = lean_nat_dec_lt(v___x_555_, v___x_556_);
if (v___x_558_ == 0)
{
lean_dec_ref(v_counts_495_);
v___y_538_ = v___y_552_;
v___y_539_ = v___y_553_;
v___y_540_ = v___x_554_;
goto v___jp_537_;
}
else
{
size_t v___x_559_; size_t v___x_560_; lean_object* v___x_561_; lean_object* v___x_562_; uint64_t v___x_563_; 
v___x_559_ = ((size_t)0ULL);
v___x_560_ = lean_usize_of_nat(v___x_556_);
v___x_561_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_562_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_557_, v___f_499_, v_counts_495_, v___x_559_, v___x_560_, v___x_561_);
v___x_563_ = lean_unbox_uint64(v___x_562_);
lean_dec(v___x_562_);
v___y_538_ = v___y_552_;
v___y_539_ = v___y_553_;
v___y_540_ = v___x_563_;
goto v___jp_537_;
}
}
v___jp_564_:
{
uint64_t v___x_566_; lean_object* v___x_567_; lean_object* v___x_568_; lean_object* v___x_569_; uint8_t v___x_570_; 
v___x_566_ = 7ULL;
v___x_567_ = lean_unsigned_to_nat(0u);
v___x_568_ = lean_array_get_size(v_columns_494_);
v___x_569_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_570_ = lean_nat_dec_lt(v___x_567_, v___x_568_);
if (v___x_570_ == 0)
{
lean_dec_ref(v_columns_494_);
v___y_552_ = v___y_565_;
v___y_553_ = v___x_566_;
goto v___jp_551_;
}
else
{
size_t v___x_571_; size_t v___x_572_; lean_object* v___x_573_; lean_object* v___x_574_; uint64_t v___x_575_; 
v___x_571_ = ((size_t)0ULL);
v___x_572_ = lean_usize_of_nat(v___x_568_);
v___x_573_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_574_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_569_, v___f_500_, v_columns_494_, v___x_571_, v___x_572_, v___x_573_);
v___x_575_ = lean_unbox_uint64(v___x_574_);
lean_dec(v___x_574_);
v___y_552_ = v___y_565_;
v___y_553_ = v___x_575_;
goto v___jp_551_;
}
}
}
v___jp_477_:
{
lean_object* v___x_479_; lean_object* v___x_481_; uint8_t v_isShared_482_; uint8_t v_isSharedCheck_486_; 
v___x_479_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_478_);
v_isSharedCheck_486_ = !lean_is_exclusive(v___x_479_);
if (v_isSharedCheck_486_ == 0)
{
lean_object* v_unused_487_; 
v_unused_487_ = lean_ctor_get(v___x_479_, 0);
lean_dec(v_unused_487_);
v___x_481_ = v___x_479_;
v_isShared_482_ = v_isSharedCheck_486_;
goto v_resetjp_480_;
}
else
{
lean_dec(v___x_479_);
v___x_481_ = lean_box(0);
v_isShared_482_ = v_isSharedCheck_486_;
goto v_resetjp_480_;
}
v_resetjp_480_:
{
lean_object* v___x_484_; 
if (v_isShared_482_ == 0)
{
lean_ctor_set(v___x_481_, 0, v___f_476_);
v___x_484_ = v___x_481_;
goto v_reusejp_483_;
}
else
{
lean_object* v_reuseFailAlloc_485_; 
v_reuseFailAlloc_485_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_485_, 0, v___f_476_);
v___x_484_ = v_reuseFailAlloc_485_;
goto v_reusejp_483_;
}
v_reusejp_483_:
{
return v___x_484_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___boxed(lean_object* v_param_587_, lean_object* v_a_588_){
_start:
{
lean_object* v_res_589_; 
v_res_589_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked(v_param_587_);
return v_res_589_;
}
}
static double _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__0(void){
_start:
{
lean_object* v___x_590_; double v___x_591_; 
v___x_590_ = lean_unsigned_to_nat(180u);
v___x_591_ = lean_float_of_nat(v___x_590_);
return v___x_591_;
}
}
static double _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__1(void){
_start:
{
lean_object* v___x_592_; uint8_t v___x_593_; lean_object* v___x_594_; double v___x_595_; 
v___x_592_ = lean_unsigned_to_nat(1u);
v___x_593_ = 1;
v___x_594_ = lean_unsigned_to_nat(2u);
v___x_595_ = l_Float_ofScientific(v___x_594_, v___x_593_, v___x_592_);
return v___x_595_;
}
}
static double _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__2(void){
_start:
{
lean_object* v___x_596_; uint8_t v___x_597_; lean_object* v___x_598_; double v___x_599_; 
v___x_596_ = lean_unsigned_to_nat(2u);
v___x_597_ = 1;
v___x_598_ = lean_unsigned_to_nat(15u);
v___x_599_ = l_Float_ofScientific(v___x_598_, v___x_597_, v___x_596_);
return v___x_599_;
}
}
static double _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__3(void){
_start:
{
lean_object* v___x_600_; uint8_t v___x_601_; lean_object* v___x_602_; double v___x_603_; 
v___x_600_ = lean_unsigned_to_nat(2u);
v___x_601_ = 1;
v___x_602_ = lean_unsigned_to_nat(150u);
v___x_603_ = l_Float_ofScientific(v___x_602_, v___x_601_, v___x_600_);
return v___x_603_;
}
}
static double _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__6(void){
_start:
{
lean_object* v___x_617_; double v___x_618_; 
v___x_617_ = lean_unsigned_to_nat(1u);
v___x_618_ = lean_float_of_nat(v___x_617_);
return v___x_618_;
}
}
static lean_object* _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__8(void){
_start:
{
lean_object* v___x_621_; lean_object* v___x_622_; double v___x_623_; uint8_t v___x_624_; lean_object* v___x_625_; double v___x_626_; double v___x_627_; double v___x_628_; lean_object* v___x_629_; lean_object* v___x_630_; lean_object* v___x_631_; double v___x_632_; lean_object* v___x_633_; lean_object* v___x_634_; 
v___x_621_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__7));
v___x_622_ = lean_unsigned_to_nat(6u);
v___x_623_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__6, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__6_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__6);
v___x_624_ = 0;
v___x_625_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__5));
v___x_626_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__3, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__3_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__3);
v___x_627_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__2, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__2_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__2);
v___x_628_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__1, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__1_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__1);
v___x_629_ = lean_unsigned_to_nat(100u);
v___x_630_ = lean_unsigned_to_nat(1u);
v___x_631_ = lean_unsigned_to_nat(5u);
v___x_632_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__0);
v___x_633_ = lean_unsigned_to_nat(100000000u);
v___x_634_ = lean_alloc_ctor(0, 7, 41);
lean_ctor_set(v___x_634_, 0, v___x_633_);
lean_ctor_set(v___x_634_, 1, v___x_631_);
lean_ctor_set(v___x_634_, 2, v___x_630_);
lean_ctor_set(v___x_634_, 3, v___x_629_);
lean_ctor_set(v___x_634_, 4, v___x_625_);
lean_ctor_set(v___x_634_, 5, v___x_622_);
lean_ctor_set(v___x_634_, 6, v___x_621_);
lean_ctor_set_float(v___x_634_, sizeof(void*)*7, v___x_632_);
lean_ctor_set_float(v___x_634_, sizeof(void*)*7 + 8, v___x_628_);
lean_ctor_set_float(v___x_634_, sizeof(void*)*7 + 16, v___x_627_);
lean_ctor_set_float(v___x_634_, sizeof(void*)*7 + 24, v___x_626_);
lean_ctor_set_uint8(v___x_634_, sizeof(void*)*7 + 40, v___x_624_);
lean_ctor_set_float(v___x_634_, sizeof(void*)*7 + 32, v___x_623_);
return v___x_634_;
}
}
static lean_object* _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config(void){
_start:
{
lean_object* v___x_635_; 
v___x_635_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__8, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__8_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__8);
return v___x_635_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0___redArg(lean_object* v_s_636_, lean_object* v_range_637_, uint64_t v_b_638_, lean_object* v_i_639_){
_start:
{
lean_object* v_stop_641_; lean_object* v_step_642_; uint64_t v___y_644_; uint8_t v___x_648_; 
v_stop_641_ = lean_ctor_get(v_range_637_, 1);
v_step_642_ = lean_ctor_get(v_range_637_, 2);
v___x_648_ = lean_nat_dec_lt(v_i_639_, v_stop_641_);
if (v___x_648_ == 0)
{
lean_object* v___x_649_; lean_object* v___x_650_; 
lean_dec(v_i_639_);
lean_dec(v_s_636_);
v___x_649_ = lean_box_uint64(v_b_638_);
v___x_650_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_650_, 0, v___x_649_);
return v___x_650_;
}
else
{
lean_object* v___x_651_; 
lean_inc(v_s_636_);
v___x_651_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolve(v_s_636_);
if (lean_obj_tag(v___x_651_) == 0)
{
uint64_t v___x_652_; 
v___x_652_ = 11ULL;
v___y_644_ = v___x_652_;
goto v___jp_643_;
}
else
{
lean_object* v_val_653_; uint64_t v___x_654_; uint64_t v___x_655_; uint64_t v___x_656_; 
v_val_653_ = lean_ctor_get(v___x_651_, 0);
lean_inc(v_val_653_);
lean_dec_ref_known(v___x_651_, 1);
v___x_654_ = 13ULL;
v___x_655_ = lean_unbox_uint64(v_val_653_);
lean_dec(v_val_653_);
v___x_656_ = lean_uint64_mix_hash(v___x_655_, v___x_654_);
v___y_644_ = v___x_656_;
goto v___jp_643_;
}
}
v___jp_643_:
{
lean_object* v___x_645_; lean_object* v___x_646_; 
v___x_645_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_644_);
lean_dec_ref(v___x_645_);
v___x_646_ = lean_nat_add(v_i_639_, v_step_642_);
lean_dec(v_i_639_);
v_b_638_ = v___y_644_;
v_i_639_ = v___x_646_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0___redArg___boxed(lean_object* v_s_657_, lean_object* v_range_658_, lean_object* v_b_659_, lean_object* v_i_660_, lean_object* v___y_661_){
_start:
{
uint64_t v_b_boxed_662_; lean_object* v_res_663_; 
v_b_boxed_662_ = lean_unbox_uint64(v_b_659_);
lean_dec_ref(v_b_659_);
v_res_663_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0___redArg(v_s_657_, v_range_658_, v_b_boxed_662_, v_i_660_);
lean_dec_ref(v_range_658_);
return v_res_663_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_(lean_object* v_s_664_, lean_object* v_count_665_){
_start:
{
lean_object* v___x_667_; uint8_t v___x_668_; 
v___x_667_ = lean_unsigned_to_nat(0u);
v___x_668_ = lean_nat_dec_eq(v_count_665_, v___x_667_);
if (v___x_668_ == 0)
{
uint64_t v___x_669_; lean_object* v___x_670_; lean_object* v___x_671_; lean_object* v___x_672_; lean_object* v___x_673_; 
v___x_669_ = 0ULL;
v___x_670_ = lean_io_mono_nanos_now();
v___x_671_ = lean_unsigned_to_nat(1u);
v___x_672_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_672_, 0, v___x_667_);
lean_ctor_set(v___x_672_, 1, v_count_665_);
lean_ctor_set(v___x_672_, 2, v___x_671_);
v___x_673_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0___redArg(v_s_664_, v___x_672_, v___x_669_, v___x_667_);
lean_dec_ref_known(v___x_672_, 3);
if (lean_obj_tag(v___x_673_) == 0)
{
lean_object* v_a_674_; lean_object* v___x_676_; uint8_t v_isShared_677_; uint8_t v_isSharedCheck_685_; 
v_a_674_ = lean_ctor_get(v___x_673_, 0);
v_isSharedCheck_685_ = !lean_is_exclusive(v___x_673_);
if (v_isSharedCheck_685_ == 0)
{
v___x_676_ = v___x_673_;
v_isShared_677_ = v_isSharedCheck_685_;
goto v_resetjp_675_;
}
else
{
lean_inc(v_a_674_);
lean_dec(v___x_673_);
v___x_676_ = lean_box(0);
v_isShared_677_ = v_isSharedCheck_685_;
goto v_resetjp_675_;
}
v_resetjp_675_:
{
lean_object* v___x_678_; lean_object* v___x_679_; lean_object* v___x_680_; lean_object* v___x_681_; lean_object* v___x_683_; 
v___x_678_ = lean_io_mono_nanos_now();
v___x_679_ = lean_nat_sub(v___x_678_, v___x_670_);
lean_dec(v___x_670_);
lean_dec(v___x_678_);
v___x_680_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_680_, 0, v_a_674_);
v___x_681_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_681_, 0, v___x_679_);
lean_ctor_set(v___x_681_, 1, v___x_680_);
if (v_isShared_677_ == 0)
{
lean_ctor_set(v___x_676_, 0, v___x_681_);
v___x_683_ = v___x_676_;
goto v_reusejp_682_;
}
else
{
lean_object* v_reuseFailAlloc_684_; 
v_reuseFailAlloc_684_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_684_, 0, v___x_681_);
v___x_683_ = v_reuseFailAlloc_684_;
goto v_reusejp_682_;
}
v_reusejp_682_:
{
return v___x_683_;
}
}
}
else
{
lean_object* v_a_686_; lean_object* v___x_688_; uint8_t v_isShared_689_; uint8_t v_isSharedCheck_693_; 
lean_dec(v___x_670_);
v_a_686_ = lean_ctor_get(v___x_673_, 0);
v_isSharedCheck_693_ = !lean_is_exclusive(v___x_673_);
if (v_isSharedCheck_693_ == 0)
{
v___x_688_ = v___x_673_;
v_isShared_689_ = v_isSharedCheck_693_;
goto v_resetjp_687_;
}
else
{
lean_inc(v_a_686_);
lean_dec(v___x_673_);
v___x_688_ = lean_box(0);
v_isShared_689_ = v_isSharedCheck_693_;
goto v_resetjp_687_;
}
v_resetjp_687_:
{
lean_object* v___x_691_; 
if (v_isShared_689_ == 0)
{
v___x_691_ = v___x_688_;
goto v_reusejp_690_;
}
else
{
lean_object* v_reuseFailAlloc_692_; 
v_reuseFailAlloc_692_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_692_, 0, v_a_686_);
v___x_691_ = v_reuseFailAlloc_692_;
goto v_reusejp_690_;
}
v_reusejp_690_:
{
return v___x_691_;
}
}
}
}
else
{
lean_object* v___x_694_; lean_object* v___x_695_; 
lean_dec(v_count_665_);
lean_dec(v_s_664_);
v___x_694_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___closed__0));
v___x_695_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_695_, 0, v___x_694_);
return v___x_695_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33____boxed(lean_object* v_s_696_, lean_object* v_count_697_, lean_object* v___y_698_){
_start:
{
lean_object* v_res_699_; 
v_res_699_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_(v_s_696_, v_count_697_);
return v_res_699_;
}
}
LEAN_EXPORT uint64_t lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(lean_object* v_as_700_, size_t v_i_701_, size_t v_stop_702_, uint64_t v_b_703_){
_start:
{
uint8_t v___x_704_; 
v___x_704_ = lean_usize_dec_eq(v_i_701_, v_stop_702_);
if (v___x_704_ == 0)
{
lean_object* v___x_705_; uint64_t v___x_706_; uint64_t v___x_707_; uint64_t v___x_708_; size_t v___x_709_; size_t v___x_710_; 
v___x_705_ = lean_array_uget_borrowed(v_as_700_, v_i_701_);
v___x_706_ = 7ULL;
v___x_707_ = l_List_foldl___at___00Std_DHashMap_Internal_Raw_u2080_insert___at___00Lean_Elab_Tactic_Omega_Problem_insertConstraint_spec__0_spec__0(v___x_706_, v___x_705_);
v___x_708_ = lean_uint64_mix_hash(v_b_703_, v___x_707_);
v___x_709_ = ((size_t)1ULL);
v___x_710_ = lean_usize_add(v_i_701_, v___x_709_);
v_i_701_ = v___x_710_;
v_b_703_ = v___x_708_;
goto _start;
}
else
{
return v_b_703_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1___boxed(lean_object* v_as_712_, lean_object* v_i_713_, lean_object* v_stop_714_, lean_object* v_b_715_){
_start:
{
size_t v_i_boxed_716_; size_t v_stop_boxed_717_; uint64_t v_b_boxed_718_; uint64_t v_res_719_; lean_object* v_r_720_; 
v_i_boxed_716_ = lean_unbox_usize(v_i_713_);
lean_dec(v_i_713_);
v_stop_boxed_717_ = lean_unbox_usize(v_stop_714_);
lean_dec(v_stop_714_);
v_b_boxed_718_ = lean_unbox_uint64(v_b_715_);
lean_dec_ref(v_b_715_);
v_res_719_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v_as_712_, v_i_boxed_716_, v_stop_boxed_717_, v_b_boxed_718_);
lean_dec_ref(v_as_712_);
v_r_720_ = lean_box_uint64(v_res_719_);
return v_r_720_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_(lean_object* v___y_721_){
_start:
{
lean_object* v_s_723_; lean_object* v___f_724_; uint64_t v___y_726_; 
v_s_723_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_input(v___y_721_);
lean_inc(v_s_723_);
v___f_724_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33____boxed), 3, 1);
lean_closure_set(v___f_724_, 0, v_s_723_);
if (lean_obj_tag(v_s_723_) == 0)
{
uint64_t v___x_736_; 
v___x_736_ = 11ULL;
v___y_726_ = v___x_736_;
goto v___jp_725_;
}
else
{
lean_object* v_val_737_; lean_object* v_system_738_; lean_object* v_arity_739_; lean_object* v_size_740_; lean_object* v_rows_741_; lean_object* v_columns_742_; lean_object* v_counts_743_; lean_object* v_values_744_; lean_object* v_inverse_745_; lean_object* v_denominator_746_; uint64_t v___x_747_; uint64_t v___x_748_; uint64_t v___x_749_; uint64_t v___y_751_; uint64_t v___y_752_; uint64_t v___y_753_; uint64_t v___y_754_; uint64_t v___y_755_; uint64_t v___y_766_; uint64_t v___y_767_; uint64_t v___y_768_; uint64_t v___y_769_; uint64_t v___y_784_; uint64_t v___y_785_; uint64_t v___y_786_; uint64_t v___y_795_; uint64_t v___y_796_; uint64_t v___y_805_; uint64_t v___x_813_; lean_object* v___x_814_; lean_object* v___x_815_; uint8_t v___x_816_; 
v_val_737_ = lean_ctor_get(v_s_723_, 0);
lean_inc(v_val_737_);
lean_dec_ref_known(v_s_723_, 1);
v_system_738_ = lean_ctor_get(v_val_737_, 2);
lean_inc_ref(v_system_738_);
v_arity_739_ = lean_ctor_get(v_val_737_, 0);
lean_inc(v_arity_739_);
v_size_740_ = lean_ctor_get(v_val_737_, 1);
lean_inc_n(v_size_740_, 3);
lean_dec(v_val_737_);
v_rows_741_ = lean_ctor_get(v_system_738_, 0);
lean_inc_ref(v_rows_741_);
v_columns_742_ = lean_ctor_get(v_system_738_, 1);
lean_inc_ref(v_columns_742_);
v_counts_743_ = lean_ctor_get(v_system_738_, 2);
lean_inc_ref(v_counts_743_);
v_values_744_ = lean_ctor_get(v_system_738_, 3);
lean_inc_ref(v_values_744_);
v_inverse_745_ = lean_ctor_get(v_system_738_, 4);
lean_inc_ref(v_inverse_745_);
v_denominator_746_ = lean_ctor_get(v_system_738_, 5);
lean_inc(v_denominator_746_);
lean_dec_ref(v_system_738_);
v___x_747_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_740_, v_size_740_, v_inverse_745_);
v___x_748_ = lean_uint64_of_nat(v_arity_739_);
lean_dec(v_arity_739_);
v___x_749_ = lean_uint64_of_nat(v_size_740_);
lean_dec(v_size_740_);
v___x_813_ = 7ULL;
v___x_814_ = lean_unsigned_to_nat(0u);
v___x_815_ = lean_array_get_size(v_rows_741_);
v___x_816_ = lean_nat_dec_lt(v___x_814_, v___x_815_);
if (v___x_816_ == 0)
{
lean_dec_ref(v_rows_741_);
v___y_805_ = v___x_813_;
goto v___jp_804_;
}
else
{
size_t v___x_817_; size_t v___x_818_; uint64_t v___x_819_; 
v___x_817_ = ((size_t)0ULL);
v___x_818_ = lean_usize_of_nat(v___x_815_);
v___x_819_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(v_rows_741_, v___x_817_, v___x_818_, v___x_813_);
lean_dec_ref(v_rows_741_);
v___y_805_ = v___x_819_;
goto v___jp_804_;
}
v___jp_750_:
{
uint64_t v___x_756_; uint64_t v___x_757_; uint64_t v___x_758_; uint64_t v___x_759_; uint64_t v___x_760_; uint64_t v___x_761_; uint64_t v___x_762_; uint64_t v___x_763_; uint64_t v___x_764_; 
v___x_756_ = lean_uint64_mix_hash(v___x_747_, v___y_755_);
v___x_757_ = lean_uint64_mix_hash(v___y_754_, v___x_756_);
v___x_758_ = lean_uint64_mix_hash(v___y_753_, v___x_757_);
v___x_759_ = lean_uint64_mix_hash(v___y_751_, v___x_758_);
v___x_760_ = lean_uint64_mix_hash(v___y_752_, v___x_759_);
v___x_761_ = lean_uint64_mix_hash(v___x_749_, v___x_760_);
v___x_762_ = lean_uint64_mix_hash(v___x_748_, v___x_761_);
v___x_763_ = 13ULL;
v___x_764_ = lean_uint64_mix_hash(v___x_762_, v___x_763_);
v___y_726_ = v___x_764_;
goto v___jp_725_;
}
v___jp_765_:
{
lean_object* v_intZero_770_; uint8_t v_isNeg_771_; 
v_intZero_770_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_771_ = lean_int_dec_lt(v_denominator_746_, v_intZero_770_);
if (v_isNeg_771_ == 0)
{
lean_object* v_a_772_; lean_object* v___x_773_; lean_object* v___x_774_; uint64_t v___x_775_; 
v_a_772_ = lean_nat_abs(v_denominator_746_);
lean_dec(v_denominator_746_);
v___x_773_ = lean_unsigned_to_nat(2u);
v___x_774_ = lean_nat_mul(v___x_773_, v_a_772_);
lean_dec(v_a_772_);
v___x_775_ = lean_uint64_of_nat(v___x_774_);
lean_dec(v___x_774_);
v___y_751_ = v___y_766_;
v___y_752_ = v___y_767_;
v___y_753_ = v___y_768_;
v___y_754_ = v___y_769_;
v___y_755_ = v___x_775_;
goto v___jp_750_;
}
else
{
lean_object* v_abs_776_; lean_object* v_one_777_; lean_object* v_a_778_; lean_object* v___x_779_; lean_object* v___x_780_; lean_object* v___x_781_; uint64_t v___x_782_; 
v_abs_776_ = lean_nat_abs(v_denominator_746_);
lean_dec(v_denominator_746_);
v_one_777_ = lean_unsigned_to_nat(1u);
v_a_778_ = lean_nat_sub(v_abs_776_, v_one_777_);
lean_dec(v_abs_776_);
v___x_779_ = lean_unsigned_to_nat(2u);
v___x_780_ = lean_nat_mul(v___x_779_, v_a_778_);
lean_dec(v_a_778_);
v___x_781_ = lean_nat_add(v___x_780_, v_one_777_);
lean_dec(v___x_780_);
v___x_782_ = lean_uint64_of_nat(v___x_781_);
lean_dec(v___x_781_);
v___y_751_ = v___y_766_;
v___y_752_ = v___y_767_;
v___y_753_ = v___y_768_;
v___y_754_ = v___y_769_;
v___y_755_ = v___x_782_;
goto v___jp_750_;
}
}
v___jp_783_:
{
uint64_t v___x_787_; lean_object* v___x_788_; lean_object* v___x_789_; uint8_t v___x_790_; 
v___x_787_ = 7ULL;
v___x_788_ = lean_unsigned_to_nat(0u);
v___x_789_ = lean_array_get_size(v_values_744_);
v___x_790_ = lean_nat_dec_lt(v___x_788_, v___x_789_);
if (v___x_790_ == 0)
{
lean_dec_ref(v_values_744_);
v___y_766_ = v___y_784_;
v___y_767_ = v___y_785_;
v___y_768_ = v___y_786_;
v___y_769_ = v___x_787_;
goto v___jp_765_;
}
else
{
size_t v___x_791_; size_t v___x_792_; uint64_t v___x_793_; 
v___x_791_ = ((size_t)0ULL);
v___x_792_ = lean_usize_of_nat(v___x_789_);
v___x_793_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_values_744_, v___x_791_, v___x_792_, v___x_787_);
lean_dec_ref(v_values_744_);
v___y_766_ = v___y_784_;
v___y_767_ = v___y_785_;
v___y_768_ = v___y_786_;
v___y_769_ = v___x_793_;
goto v___jp_765_;
}
}
v___jp_794_:
{
uint64_t v___x_797_; lean_object* v___x_798_; lean_object* v___x_799_; uint8_t v___x_800_; 
v___x_797_ = 7ULL;
v___x_798_ = lean_unsigned_to_nat(0u);
v___x_799_ = lean_array_get_size(v_counts_743_);
v___x_800_ = lean_nat_dec_lt(v___x_798_, v___x_799_);
if (v___x_800_ == 0)
{
lean_dec_ref(v_counts_743_);
v___y_784_ = v___y_796_;
v___y_785_ = v___y_795_;
v___y_786_ = v___x_797_;
goto v___jp_783_;
}
else
{
size_t v___x_801_; size_t v___x_802_; uint64_t v___x_803_; 
v___x_801_ = ((size_t)0ULL);
v___x_802_ = lean_usize_of_nat(v___x_799_);
v___x_803_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_counts_743_, v___x_801_, v___x_802_, v___x_797_);
lean_dec_ref(v_counts_743_);
v___y_784_ = v___y_796_;
v___y_785_ = v___y_795_;
v___y_786_ = v___x_803_;
goto v___jp_783_;
}
}
v___jp_804_:
{
uint64_t v___x_806_; lean_object* v___x_807_; lean_object* v___x_808_; uint8_t v___x_809_; 
v___x_806_ = 7ULL;
v___x_807_ = lean_unsigned_to_nat(0u);
v___x_808_ = lean_array_get_size(v_columns_742_);
v___x_809_ = lean_nat_dec_lt(v___x_807_, v___x_808_);
if (v___x_809_ == 0)
{
lean_dec_ref(v_columns_742_);
v___y_795_ = v___y_805_;
v___y_796_ = v___x_806_;
goto v___jp_794_;
}
else
{
size_t v___x_810_; size_t v___x_811_; uint64_t v___x_812_; 
v___x_810_ = ((size_t)0ULL);
v___x_811_ = lean_usize_of_nat(v___x_808_);
v___x_812_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v_columns_742_, v___x_810_, v___x_811_, v___x_806_);
lean_dec_ref(v_columns_742_);
v___y_795_ = v___y_805_;
v___y_796_ = v___x_812_;
goto v___jp_794_;
}
}
}
v___jp_725_:
{
lean_object* v___x_727_; lean_object* v___x_729_; uint8_t v_isShared_730_; uint8_t v_isSharedCheck_734_; 
v___x_727_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_726_);
v_isSharedCheck_734_ = !lean_is_exclusive(v___x_727_);
if (v_isSharedCheck_734_ == 0)
{
lean_object* v_unused_735_; 
v_unused_735_ = lean_ctor_get(v___x_727_, 0);
lean_dec(v_unused_735_);
v___x_729_ = v___x_727_;
v_isShared_730_ = v_isSharedCheck_734_;
goto v_resetjp_728_;
}
else
{
lean_dec(v___x_727_);
v___x_729_ = lean_box(0);
v_isShared_730_ = v_isSharedCheck_734_;
goto v_resetjp_728_;
}
v_resetjp_728_:
{
lean_object* v___x_732_; 
if (v_isShared_730_ == 0)
{
lean_ctor_set(v___x_729_, 0, v___f_724_);
v___x_732_ = v___x_729_;
goto v_reusejp_731_;
}
else
{
lean_object* v_reuseFailAlloc_733_; 
v_reuseFailAlloc_733_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_733_, 0, v___f_724_);
v___x_732_ = v_reuseFailAlloc_733_;
goto v_reusejp_731_;
}
v_reusejp_731_:
{
return v___x_732_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33____boxed(lean_object* v___y_820_, lean_object* v___y_821_){
_start:
{
lean_object* v_res_822_; 
v_res_822_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_(v___y_820_);
return v_res_822_;
}
}
static lean_object* _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__7_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_(void){
_start:
{
lean_object* v___x_834_; uint8_t v___x_835_; lean_object* v___x_836_; lean_object* v___x_837_; lean_object* v___x_838_; 
v___x_834_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config;
v___x_835_ = 1;
v___x_836_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__6_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_));
v___x_837_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_));
v___x_838_ = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(v___x_838_, 0, v___x_837_);
lean_ctor_set(v___x_838_, 1, v___x_836_);
lean_ctor_set(v___x_838_, 2, v___x_834_);
lean_ctor_set_uint8(v___x_838_, sizeof(void*)*3, v___x_835_);
return v___x_838_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_(){
_start:
{
lean_object* v___f_841_; lean_object* v___x_842_; lean_object* v___x_843_; lean_object* v___x_844_; 
v___f_841_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_));
v___x_842_ = lean_obj_once(&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__7_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_, &lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__7_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__once, _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__7_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_);
v___x_843_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__8_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_));
v___x_844_ = lp_lean_x2dbench_LeanBench_register(v___x_842_, v___f_841_, v___x_843_);
return v___x_844_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33____boxed(lean_object* v_a_845_){
_start:
{
lean_object* v_res_846_; 
v_res_846_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_();
return v_res_846_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0(lean_object* v_s_847_, lean_object* v_range_848_, uint64_t v_b_849_, lean_object* v_i_850_, lean_object* v_hs_851_, lean_object* v_hl_852_){
_start:
{
lean_object* v___x_854_; 
v___x_854_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0___redArg(v_s_847_, v_range_848_, v_b_849_, v_i_850_);
return v___x_854_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0___boxed(lean_object* v_s_855_, lean_object* v_range_856_, lean_object* v_b_857_, lean_object* v_i_858_, lean_object* v_hs_859_, lean_object* v_hl_860_, lean_object* v___y_861_){
_start:
{
uint64_t v_b_boxed_862_; lean_object* v_res_863_; 
v_b_boxed_862_ = lean_unbox_uint64(v_b_857_);
lean_dec_ref(v_b_857_);
v_res_863_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__0(v_s_855_, v_range_856_, v_b_boxed_862_, v_i_858_, v_hs_859_, v_hl_860_);
lean_dec_ref(v_range_856_);
return v_res_863_;
}
}
LEAN_EXPORT uint64_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(lean_object* v_r_864_){
_start:
{
if (lean_obj_tag(v_r_864_) == 0)
{
uint64_t v___x_865_; 
v___x_865_ = 11ULL;
return v___x_865_;
}
else
{
lean_object* v_val_866_; uint64_t v___x_867_; uint64_t v___x_868_; uint64_t v___x_869_; 
v_val_866_ = lean_ctor_get(v_r_864_, 0);
v___x_867_ = 13ULL;
v___x_868_ = lean_unbox_uint64(v_val_866_);
v___x_869_ = lean_uint64_mix_hash(v___x_868_, v___x_867_);
return v___x_869_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed(lean_object* v_r_870_){
_start:
{
uint64_t v_res_871_; lean_object* v_r_872_; 
v_res_871_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(v_r_870_);
lean_dec(v_r_870_);
v_r_872_ = lean_box_uint64(v_res_871_);
return v_r_872_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(lean_object* v_s_873_, lean_object* v_x_874_){
_start:
{
lean_object* v___x_876_; lean_object* v___x_877_; 
v___x_876_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolve(v_s_873_);
v___x_877_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_877_, 0, v___x_876_);
return v___x_877_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed(lean_object* v_s_878_, lean_object* v_x_879_, lean_object* v___y_880_){
_start:
{
lean_object* v_res_881_; 
v_res_881_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(v_s_878_, v_x_879_);
return v_res_881_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(lean_object* v___f_882_, lean_object* v_param_883_){
_start:
{
lean_object* v_s_885_; lean_object* v___f_886_; uint64_t v___y_888_; 
v_s_885_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_input(v_param_883_);
lean_inc(v_s_885_);
v___f_886_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed), 3, 1);
lean_closure_set(v___f_886_, 0, v_s_885_);
if (lean_obj_tag(v_s_885_) == 0)
{
uint64_t v___x_893_; 
v___x_893_ = 11ULL;
v___y_888_ = v___x_893_;
goto v___jp_887_;
}
else
{
lean_object* v_val_894_; lean_object* v_system_895_; lean_object* v_arity_896_; lean_object* v_size_897_; lean_object* v_rows_898_; lean_object* v_columns_899_; lean_object* v_counts_900_; lean_object* v_values_901_; lean_object* v_inverse_902_; lean_object* v_denominator_903_; uint64_t v___x_904_; uint64_t v___x_905_; uint64_t v___x_906_; uint64_t v___y_908_; uint64_t v___y_909_; uint64_t v___y_910_; uint64_t v___y_911_; uint64_t v___y_912_; uint64_t v___y_923_; uint64_t v___y_924_; uint64_t v___y_925_; uint64_t v___y_926_; uint64_t v___y_941_; uint64_t v___y_942_; uint64_t v___y_943_; uint64_t v___y_952_; uint64_t v___y_953_; uint64_t v___y_962_; uint64_t v___x_970_; lean_object* v___x_971_; lean_object* v___x_972_; uint8_t v___x_973_; 
v_val_894_ = lean_ctor_get(v_s_885_, 0);
lean_inc(v_val_894_);
lean_dec_ref_known(v_s_885_, 1);
v_system_895_ = lean_ctor_get(v_val_894_, 2);
lean_inc_ref(v_system_895_);
v_arity_896_ = lean_ctor_get(v_val_894_, 0);
lean_inc(v_arity_896_);
v_size_897_ = lean_ctor_get(v_val_894_, 1);
lean_inc_n(v_size_897_, 3);
lean_dec(v_val_894_);
v_rows_898_ = lean_ctor_get(v_system_895_, 0);
lean_inc_ref(v_rows_898_);
v_columns_899_ = lean_ctor_get(v_system_895_, 1);
lean_inc_ref(v_columns_899_);
v_counts_900_ = lean_ctor_get(v_system_895_, 2);
lean_inc_ref(v_counts_900_);
v_values_901_ = lean_ctor_get(v_system_895_, 3);
lean_inc_ref(v_values_901_);
v_inverse_902_ = lean_ctor_get(v_system_895_, 4);
lean_inc_ref(v_inverse_902_);
v_denominator_903_ = lean_ctor_get(v_system_895_, 5);
lean_inc(v_denominator_903_);
lean_dec_ref(v_system_895_);
v___x_904_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_897_, v_size_897_, v_inverse_902_);
v___x_905_ = lean_uint64_of_nat(v_arity_896_);
lean_dec(v_arity_896_);
v___x_906_ = lean_uint64_of_nat(v_size_897_);
lean_dec(v_size_897_);
v___x_970_ = 7ULL;
v___x_971_ = lean_unsigned_to_nat(0u);
v___x_972_ = lean_array_get_size(v_rows_898_);
v___x_973_ = lean_nat_dec_lt(v___x_971_, v___x_972_);
if (v___x_973_ == 0)
{
lean_dec_ref(v_rows_898_);
v___y_962_ = v___x_970_;
goto v___jp_961_;
}
else
{
size_t v___x_974_; size_t v___x_975_; uint64_t v___x_976_; 
v___x_974_ = ((size_t)0ULL);
v___x_975_ = lean_usize_of_nat(v___x_972_);
v___x_976_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(v_rows_898_, v___x_974_, v___x_975_, v___x_970_);
lean_dec_ref(v_rows_898_);
v___y_962_ = v___x_976_;
goto v___jp_961_;
}
v___jp_907_:
{
uint64_t v___x_913_; uint64_t v___x_914_; uint64_t v___x_915_; uint64_t v___x_916_; uint64_t v___x_917_; uint64_t v___x_918_; uint64_t v___x_919_; uint64_t v___x_920_; uint64_t v___x_921_; 
v___x_913_ = lean_uint64_mix_hash(v___x_904_, v___y_912_);
v___x_914_ = lean_uint64_mix_hash(v___y_909_, v___x_913_);
v___x_915_ = lean_uint64_mix_hash(v___y_908_, v___x_914_);
v___x_916_ = lean_uint64_mix_hash(v___y_911_, v___x_915_);
v___x_917_ = lean_uint64_mix_hash(v___y_910_, v___x_916_);
v___x_918_ = lean_uint64_mix_hash(v___x_906_, v___x_917_);
v___x_919_ = lean_uint64_mix_hash(v___x_905_, v___x_918_);
v___x_920_ = 13ULL;
v___x_921_ = lean_uint64_mix_hash(v___x_919_, v___x_920_);
v___y_888_ = v___x_921_;
goto v___jp_887_;
}
v___jp_922_:
{
lean_object* v_intZero_927_; uint8_t v_isNeg_928_; 
v_intZero_927_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_928_ = lean_int_dec_lt(v_denominator_903_, v_intZero_927_);
if (v_isNeg_928_ == 0)
{
lean_object* v_a_929_; lean_object* v___x_930_; lean_object* v___x_931_; uint64_t v___x_932_; 
v_a_929_ = lean_nat_abs(v_denominator_903_);
lean_dec(v_denominator_903_);
v___x_930_ = lean_unsigned_to_nat(2u);
v___x_931_ = lean_nat_mul(v___x_930_, v_a_929_);
lean_dec(v_a_929_);
v___x_932_ = lean_uint64_of_nat(v___x_931_);
lean_dec(v___x_931_);
v___y_908_ = v___y_923_;
v___y_909_ = v___y_926_;
v___y_910_ = v___y_924_;
v___y_911_ = v___y_925_;
v___y_912_ = v___x_932_;
goto v___jp_907_;
}
else
{
lean_object* v_abs_933_; lean_object* v_one_934_; lean_object* v_a_935_; lean_object* v___x_936_; lean_object* v___x_937_; lean_object* v___x_938_; uint64_t v___x_939_; 
v_abs_933_ = lean_nat_abs(v_denominator_903_);
lean_dec(v_denominator_903_);
v_one_934_ = lean_unsigned_to_nat(1u);
v_a_935_ = lean_nat_sub(v_abs_933_, v_one_934_);
lean_dec(v_abs_933_);
v___x_936_ = lean_unsigned_to_nat(2u);
v___x_937_ = lean_nat_mul(v___x_936_, v_a_935_);
lean_dec(v_a_935_);
v___x_938_ = lean_nat_add(v___x_937_, v_one_934_);
lean_dec(v___x_937_);
v___x_939_ = lean_uint64_of_nat(v___x_938_);
lean_dec(v___x_938_);
v___y_908_ = v___y_923_;
v___y_909_ = v___y_926_;
v___y_910_ = v___y_924_;
v___y_911_ = v___y_925_;
v___y_912_ = v___x_939_;
goto v___jp_907_;
}
}
v___jp_940_:
{
uint64_t v___x_944_; lean_object* v___x_945_; lean_object* v___x_946_; uint8_t v___x_947_; 
v___x_944_ = 7ULL;
v___x_945_ = lean_unsigned_to_nat(0u);
v___x_946_ = lean_array_get_size(v_values_901_);
v___x_947_ = lean_nat_dec_lt(v___x_945_, v___x_946_);
if (v___x_947_ == 0)
{
lean_dec_ref(v_values_901_);
v___y_923_ = v___y_943_;
v___y_924_ = v___y_941_;
v___y_925_ = v___y_942_;
v___y_926_ = v___x_944_;
goto v___jp_922_;
}
else
{
size_t v___x_948_; size_t v___x_949_; uint64_t v___x_950_; 
v___x_948_ = ((size_t)0ULL);
v___x_949_ = lean_usize_of_nat(v___x_946_);
v___x_950_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_values_901_, v___x_948_, v___x_949_, v___x_944_);
lean_dec_ref(v_values_901_);
v___y_923_ = v___y_943_;
v___y_924_ = v___y_941_;
v___y_925_ = v___y_942_;
v___y_926_ = v___x_950_;
goto v___jp_922_;
}
}
v___jp_951_:
{
uint64_t v___x_954_; lean_object* v___x_955_; lean_object* v___x_956_; uint8_t v___x_957_; 
v___x_954_ = 7ULL;
v___x_955_ = lean_unsigned_to_nat(0u);
v___x_956_ = lean_array_get_size(v_counts_900_);
v___x_957_ = lean_nat_dec_lt(v___x_955_, v___x_956_);
if (v___x_957_ == 0)
{
lean_dec_ref(v_counts_900_);
v___y_941_ = v___y_952_;
v___y_942_ = v___y_953_;
v___y_943_ = v___x_954_;
goto v___jp_940_;
}
else
{
size_t v___x_958_; size_t v___x_959_; uint64_t v___x_960_; 
v___x_958_ = ((size_t)0ULL);
v___x_959_ = lean_usize_of_nat(v___x_956_);
v___x_960_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_counts_900_, v___x_958_, v___x_959_, v___x_954_);
lean_dec_ref(v_counts_900_);
v___y_941_ = v___y_952_;
v___y_942_ = v___y_953_;
v___y_943_ = v___x_960_;
goto v___jp_940_;
}
}
v___jp_961_:
{
uint64_t v___x_963_; lean_object* v___x_964_; lean_object* v___x_965_; uint8_t v___x_966_; 
v___x_963_ = 7ULL;
v___x_964_ = lean_unsigned_to_nat(0u);
v___x_965_ = lean_array_get_size(v_columns_899_);
v___x_966_ = lean_nat_dec_lt(v___x_964_, v___x_965_);
if (v___x_966_ == 0)
{
lean_dec_ref(v_columns_899_);
v___y_952_ = v___y_962_;
v___y_953_ = v___x_963_;
goto v___jp_951_;
}
else
{
size_t v___x_967_; size_t v___x_968_; uint64_t v___x_969_; 
v___x_967_ = ((size_t)0ULL);
v___x_968_ = lean_usize_of_nat(v___x_965_);
v___x_969_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v_columns_899_, v___x_967_, v___x_968_, v___x_963_);
lean_dec_ref(v_columns_899_);
v___y_952_ = v___y_962_;
v___y_953_ = v___x_969_;
goto v___jp_951_;
}
}
}
v___jp_887_:
{
lean_object* v___x_889_; uint8_t v___x_890_; uint8_t v___x_891_; lean_object* v___x_892_; 
v___x_889_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_888_);
lean_dec_ref(v___x_889_);
v___x_890_ = 1;
v___x_891_ = 0;
v___x_892_ = lp_lean_x2dbench_LeanBench_kernelLoop___redArg(v___f_886_, v___f_882_, v___x_890_, v___x_891_);
return v___x_892_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed(lean_object* v___f_977_, lean_object* v_param_978_, lean_object* v___y_979_){
_start:
{
lean_object* v_res_980_; 
v_res_980_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(v___f_977_, v_param_978_);
return v_res_980_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_(){
_start:
{
lean_object* v___f_985_; lean_object* v___x_986_; lean_object* v___x_987_; 
v___f_985_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_));
v___x_986_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_));
v___x_987_ = lp_lean_x2dbench_LeanBench_registerKernel(v___x_986_, v___f_985_);
return v___x_987_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37____boxed(lean_object* v_a_988_){
_start:
{
lean_object* v_res_989_; 
v_res_989_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_();
return v_res_989_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__complexity(lean_object* v_s_990_){
_start:
{
lean_object* v___x_991_; lean_object* v___x_992_; 
v___x_991_ = lean_unsigned_to_nat(27u);
v___x_992_ = lean_nat_pow(v___x_991_, v_s_990_);
return v___x_992_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__complexity___boxed(lean_object* v_s_993_){
_start:
{
lean_object* v_res_994_; 
v_res_994_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__complexity(v_s_993_);
lean_dec(v_s_993_);
return v_res_994_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked___lam__0(lean_object* v_s_995_, lean_object* v_a_996_, lean_object* v_x_997_, uint64_t v___y_998_){
_start:
{
uint64_t v___y_1001_; uint8_t v___x_1013_; 
v___x_1013_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck(v_s_995_);
if (v___x_1013_ == 0)
{
uint64_t v___x_1014_; 
v___x_1014_ = 13ULL;
v___y_1001_ = v___x_1014_;
goto v___jp_1000_;
}
else
{
uint64_t v___x_1015_; 
v___x_1015_ = 11ULL;
v___y_1001_ = v___x_1015_;
goto v___jp_1000_;
}
v___jp_1000_:
{
lean_object* v___x_1002_; lean_object* v___x_1004_; uint8_t v_isShared_1005_; uint8_t v_isSharedCheck_1011_; 
v___x_1002_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1001_);
v_isSharedCheck_1011_ = !lean_is_exclusive(v___x_1002_);
if (v_isSharedCheck_1011_ == 0)
{
lean_object* v_unused_1012_; 
v_unused_1012_ = lean_ctor_get(v___x_1002_, 0);
lean_dec(v_unused_1012_);
v___x_1004_ = v___x_1002_;
v_isShared_1005_ = v_isSharedCheck_1011_;
goto v_resetjp_1003_;
}
else
{
lean_dec(v___x_1002_);
v___x_1004_ = lean_box(0);
v_isShared_1005_ = v_isSharedCheck_1011_;
goto v_resetjp_1003_;
}
v_resetjp_1003_:
{
lean_object* v___x_1006_; lean_object* v___x_1007_; lean_object* v___x_1009_; 
v___x_1006_ = lean_box_uint64(v___y_1001_);
v___x_1007_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1007_, 0, v___x_1006_);
if (v_isShared_1005_ == 0)
{
lean_ctor_set(v___x_1004_, 0, v___x_1007_);
v___x_1009_ = v___x_1004_;
goto v_reusejp_1008_;
}
else
{
lean_object* v_reuseFailAlloc_1010_; 
v_reuseFailAlloc_1010_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1010_, 0, v___x_1007_);
v___x_1009_ = v_reuseFailAlloc_1010_;
goto v_reusejp_1008_;
}
v_reusejp_1008_:
{
return v___x_1009_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked___lam__0___boxed(lean_object* v_s_1016_, lean_object* v_a_1017_, lean_object* v_x_1018_, lean_object* v___y_1019_, lean_object* v___y_1020_){
_start:
{
uint64_t v___y_795__boxed_1021_; lean_object* v_res_1022_; 
v___y_795__boxed_1021_ = lean_unbox_uint64(v___y_1019_);
lean_dec_ref(v___y_1019_);
v_res_1022_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked___lam__0(v_s_1016_, v_a_1017_, v_x_1018_, v___y_795__boxed_1021_);
lean_dec(v_a_1017_);
return v_res_1022_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked(lean_object* v_param_1023_){
_start:
{
lean_object* v___x_1025_; lean_object* v_s_1026_; lean_object* v___f_1027_; lean_object* v___f_1028_; uint64_t v___y_1030_; 
v___x_1025_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0);
v_s_1026_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_input(v_param_1023_);
lean_inc(v_s_1026_);
v___f_1027_ = lean_alloc_closure((void*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked___lam__0___boxed), 5, 1);
lean_closure_set(v___f_1027_, 0, v_s_1026_);
v___f_1028_ = lean_alloc_closure((void*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed), 4, 2);
lean_closure_set(v___f_1028_, 0, v___x_1025_);
lean_closure_set(v___f_1028_, 1, v___f_1027_);
if (lean_obj_tag(v_s_1026_) == 0)
{
uint64_t v___x_1040_; 
v___x_1040_ = 11ULL;
v___y_1030_ = v___x_1040_;
goto v___jp_1029_;
}
else
{
lean_object* v_val_1041_; lean_object* v_system_1042_; lean_object* v_arity_1043_; lean_object* v_size_1044_; lean_object* v_rows_1045_; lean_object* v_columns_1046_; lean_object* v_counts_1047_; lean_object* v_values_1048_; lean_object* v_inverse_1049_; lean_object* v_denominator_1050_; lean_object* v___f_1051_; lean_object* v___f_1052_; uint64_t v___x_1053_; uint64_t v___x_1054_; uint64_t v___x_1055_; uint64_t v___y_1057_; uint64_t v___y_1058_; uint64_t v___y_1059_; uint64_t v___y_1060_; uint64_t v___y_1061_; uint64_t v___y_1072_; uint64_t v___y_1073_; uint64_t v___y_1074_; uint64_t v___y_1075_; uint64_t v___y_1090_; uint64_t v___y_1091_; uint64_t v___y_1092_; uint64_t v___y_1104_; uint64_t v___y_1105_; uint64_t v___y_1117_; uint64_t v___x_1128_; lean_object* v___x_1129_; lean_object* v___x_1130_; lean_object* v___x_1131_; uint8_t v___x_1132_; 
v_val_1041_ = lean_ctor_get(v_s_1026_, 0);
lean_inc(v_val_1041_);
lean_dec_ref_known(v_s_1026_, 1);
v_system_1042_ = lean_ctor_get(v_val_1041_, 2);
lean_inc_ref(v_system_1042_);
v_arity_1043_ = lean_ctor_get(v_val_1041_, 0);
lean_inc(v_arity_1043_);
v_size_1044_ = lean_ctor_get(v_val_1041_, 1);
lean_inc_n(v_size_1044_, 3);
lean_dec(v_val_1041_);
v_rows_1045_ = lean_ctor_get(v_system_1042_, 0);
lean_inc_ref(v_rows_1045_);
v_columns_1046_ = lean_ctor_get(v_system_1042_, 1);
lean_inc_ref(v_columns_1046_);
v_counts_1047_ = lean_ctor_get(v_system_1042_, 2);
lean_inc_ref(v_counts_1047_);
v_values_1048_ = lean_ctor_get(v_system_1042_, 3);
lean_inc_ref(v_values_1048_);
v_inverse_1049_ = lean_ctor_get(v_system_1042_, 4);
lean_inc_ref(v_inverse_1049_);
v_denominator_1050_ = lean_ctor_get(v_system_1042_, 5);
lean_inc(v_denominator_1050_);
lean_dec_ref(v_system_1042_);
v___f_1051_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__2));
v___f_1052_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__4));
v___x_1053_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_1044_, v_size_1044_, v_inverse_1049_);
v___x_1054_ = lean_uint64_of_nat(v_arity_1043_);
lean_dec(v_arity_1043_);
v___x_1055_ = lean_uint64_of_nat(v_size_1044_);
lean_dec(v_size_1044_);
v___x_1128_ = 7ULL;
v___x_1129_ = lean_unsigned_to_nat(0u);
v___x_1130_ = lean_array_get_size(v_rows_1045_);
v___x_1131_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_1132_ = lean_nat_dec_lt(v___x_1129_, v___x_1130_);
if (v___x_1132_ == 0)
{
lean_dec_ref(v_rows_1045_);
v___y_1117_ = v___x_1128_;
goto v___jp_1116_;
}
else
{
lean_object* v___f_1133_; size_t v___x_1134_; size_t v___x_1135_; lean_object* v___x_1136_; lean_object* v___x_1137_; uint64_t v___x_1138_; 
v___f_1133_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__1));
v___x_1134_ = ((size_t)0ULL);
v___x_1135_ = lean_usize_of_nat(v___x_1130_);
v___x_1136_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_1137_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_1131_, v___f_1133_, v_rows_1045_, v___x_1134_, v___x_1135_, v___x_1136_);
v___x_1138_ = lean_unbox_uint64(v___x_1137_);
lean_dec(v___x_1137_);
v___y_1117_ = v___x_1138_;
goto v___jp_1116_;
}
v___jp_1056_:
{
uint64_t v___x_1062_; uint64_t v___x_1063_; uint64_t v___x_1064_; uint64_t v___x_1065_; uint64_t v___x_1066_; uint64_t v___x_1067_; uint64_t v___x_1068_; uint64_t v___x_1069_; uint64_t v___x_1070_; 
v___x_1062_ = lean_uint64_mix_hash(v___x_1053_, v___y_1061_);
v___x_1063_ = lean_uint64_mix_hash(v___y_1058_, v___x_1062_);
v___x_1064_ = lean_uint64_mix_hash(v___y_1057_, v___x_1063_);
v___x_1065_ = lean_uint64_mix_hash(v___y_1059_, v___x_1064_);
v___x_1066_ = lean_uint64_mix_hash(v___y_1060_, v___x_1065_);
v___x_1067_ = lean_uint64_mix_hash(v___x_1055_, v___x_1066_);
v___x_1068_ = lean_uint64_mix_hash(v___x_1054_, v___x_1067_);
v___x_1069_ = 13ULL;
v___x_1070_ = lean_uint64_mix_hash(v___x_1068_, v___x_1069_);
v___y_1030_ = v___x_1070_;
goto v___jp_1029_;
}
v___jp_1071_:
{
lean_object* v_intZero_1076_; uint8_t v_isNeg_1077_; 
v_intZero_1076_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_1077_ = lean_int_dec_lt(v_denominator_1050_, v_intZero_1076_);
if (v_isNeg_1077_ == 0)
{
lean_object* v_a_1078_; lean_object* v___x_1079_; lean_object* v___x_1080_; uint64_t v___x_1081_; 
v_a_1078_ = lean_nat_abs(v_denominator_1050_);
lean_dec(v_denominator_1050_);
v___x_1079_ = lean_unsigned_to_nat(2u);
v___x_1080_ = lean_nat_mul(v___x_1079_, v_a_1078_);
lean_dec(v_a_1078_);
v___x_1081_ = lean_uint64_of_nat(v___x_1080_);
lean_dec(v___x_1080_);
v___y_1057_ = v___y_1072_;
v___y_1058_ = v___y_1075_;
v___y_1059_ = v___y_1073_;
v___y_1060_ = v___y_1074_;
v___y_1061_ = v___x_1081_;
goto v___jp_1056_;
}
else
{
lean_object* v_abs_1082_; lean_object* v_one_1083_; lean_object* v_a_1084_; lean_object* v___x_1085_; lean_object* v___x_1086_; lean_object* v___x_1087_; uint64_t v___x_1088_; 
v_abs_1082_ = lean_nat_abs(v_denominator_1050_);
lean_dec(v_denominator_1050_);
v_one_1083_ = lean_unsigned_to_nat(1u);
v_a_1084_ = lean_nat_sub(v_abs_1082_, v_one_1083_);
lean_dec(v_abs_1082_);
v___x_1085_ = lean_unsigned_to_nat(2u);
v___x_1086_ = lean_nat_mul(v___x_1085_, v_a_1084_);
lean_dec(v_a_1084_);
v___x_1087_ = lean_nat_add(v___x_1086_, v_one_1083_);
lean_dec(v___x_1086_);
v___x_1088_ = lean_uint64_of_nat(v___x_1087_);
lean_dec(v___x_1087_);
v___y_1057_ = v___y_1072_;
v___y_1058_ = v___y_1075_;
v___y_1059_ = v___y_1073_;
v___y_1060_ = v___y_1074_;
v___y_1061_ = v___x_1088_;
goto v___jp_1056_;
}
}
v___jp_1089_:
{
uint64_t v___x_1093_; lean_object* v___x_1094_; lean_object* v___x_1095_; lean_object* v___x_1096_; uint8_t v___x_1097_; 
v___x_1093_ = 7ULL;
v___x_1094_ = lean_unsigned_to_nat(0u);
v___x_1095_ = lean_array_get_size(v_values_1048_);
v___x_1096_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_1097_ = lean_nat_dec_lt(v___x_1094_, v___x_1095_);
if (v___x_1097_ == 0)
{
lean_dec_ref(v_values_1048_);
v___y_1072_ = v___y_1092_;
v___y_1073_ = v___y_1090_;
v___y_1074_ = v___y_1091_;
v___y_1075_ = v___x_1093_;
goto v___jp_1071_;
}
else
{
size_t v___x_1098_; size_t v___x_1099_; lean_object* v___x_1100_; lean_object* v___x_1101_; uint64_t v___x_1102_; 
v___x_1098_ = ((size_t)0ULL);
v___x_1099_ = lean_usize_of_nat(v___x_1095_);
v___x_1100_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_1101_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_1096_, v___f_1051_, v_values_1048_, v___x_1098_, v___x_1099_, v___x_1100_);
v___x_1102_ = lean_unbox_uint64(v___x_1101_);
lean_dec(v___x_1101_);
v___y_1072_ = v___y_1092_;
v___y_1073_ = v___y_1090_;
v___y_1074_ = v___y_1091_;
v___y_1075_ = v___x_1102_;
goto v___jp_1071_;
}
}
v___jp_1103_:
{
uint64_t v___x_1106_; lean_object* v___x_1107_; lean_object* v___x_1108_; lean_object* v___x_1109_; uint8_t v___x_1110_; 
v___x_1106_ = 7ULL;
v___x_1107_ = lean_unsigned_to_nat(0u);
v___x_1108_ = lean_array_get_size(v_counts_1047_);
v___x_1109_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_1110_ = lean_nat_dec_lt(v___x_1107_, v___x_1108_);
if (v___x_1110_ == 0)
{
lean_dec_ref(v_counts_1047_);
v___y_1090_ = v___y_1105_;
v___y_1091_ = v___y_1104_;
v___y_1092_ = v___x_1106_;
goto v___jp_1089_;
}
else
{
size_t v___x_1111_; size_t v___x_1112_; lean_object* v___x_1113_; lean_object* v___x_1114_; uint64_t v___x_1115_; 
v___x_1111_ = ((size_t)0ULL);
v___x_1112_ = lean_usize_of_nat(v___x_1108_);
v___x_1113_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_1114_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_1109_, v___f_1051_, v_counts_1047_, v___x_1111_, v___x_1112_, v___x_1113_);
v___x_1115_ = lean_unbox_uint64(v___x_1114_);
lean_dec(v___x_1114_);
v___y_1090_ = v___y_1105_;
v___y_1091_ = v___y_1104_;
v___y_1092_ = v___x_1115_;
goto v___jp_1089_;
}
}
v___jp_1116_:
{
uint64_t v___x_1118_; lean_object* v___x_1119_; lean_object* v___x_1120_; lean_object* v___x_1121_; uint8_t v___x_1122_; 
v___x_1118_ = 7ULL;
v___x_1119_ = lean_unsigned_to_nat(0u);
v___x_1120_ = lean_array_get_size(v_columns_1046_);
v___x_1121_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_1122_ = lean_nat_dec_lt(v___x_1119_, v___x_1120_);
if (v___x_1122_ == 0)
{
lean_dec_ref(v_columns_1046_);
v___y_1104_ = v___y_1117_;
v___y_1105_ = v___x_1118_;
goto v___jp_1103_;
}
else
{
size_t v___x_1123_; size_t v___x_1124_; lean_object* v___x_1125_; lean_object* v___x_1126_; uint64_t v___x_1127_; 
v___x_1123_ = ((size_t)0ULL);
v___x_1124_ = lean_usize_of_nat(v___x_1120_);
v___x_1125_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_1126_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_1121_, v___f_1052_, v_columns_1046_, v___x_1123_, v___x_1124_, v___x_1125_);
v___x_1127_ = lean_unbox_uint64(v___x_1126_);
lean_dec(v___x_1126_);
v___y_1104_ = v___y_1117_;
v___y_1105_ = v___x_1127_;
goto v___jp_1103_;
}
}
}
v___jp_1029_:
{
lean_object* v___x_1031_; lean_object* v___x_1033_; uint8_t v_isShared_1034_; uint8_t v_isSharedCheck_1038_; 
v___x_1031_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1030_);
v_isSharedCheck_1038_ = !lean_is_exclusive(v___x_1031_);
if (v_isSharedCheck_1038_ == 0)
{
lean_object* v_unused_1039_; 
v_unused_1039_ = lean_ctor_get(v___x_1031_, 0);
lean_dec(v_unused_1039_);
v___x_1033_ = v___x_1031_;
v_isShared_1034_ = v_isSharedCheck_1038_;
goto v_resetjp_1032_;
}
else
{
lean_dec(v___x_1031_);
v___x_1033_ = lean_box(0);
v_isShared_1034_ = v_isSharedCheck_1038_;
goto v_resetjp_1032_;
}
v_resetjp_1032_:
{
lean_object* v___x_1036_; 
if (v_isShared_1034_ == 0)
{
lean_ctor_set(v___x_1033_, 0, v___f_1028_);
v___x_1036_ = v___x_1033_;
goto v_reusejp_1035_;
}
else
{
lean_object* v_reuseFailAlloc_1037_; 
v_reuseFailAlloc_1037_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1037_, 0, v___f_1028_);
v___x_1036_ = v_reuseFailAlloc_1037_;
goto v_reusejp_1035_;
}
v_reusejp_1035_:
{
return v___x_1036_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked___boxed(lean_object* v_param_1139_, lean_object* v_a_1140_){
_start:
{
lean_object* v_res_1141_; 
v_res_1141_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__runChecked(v_param_1139_);
return v_res_1141_;
}
}
static lean_object* _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__config(void){
_start:
{
lean_object* v___x_1142_; lean_object* v___x_1143_; lean_object* v___x_1144_; 
v___x_1142_ = lean_unsigned_to_nat(5u);
v___x_1143_ = lean_mk_empty_array_with_capacity(v___x_1142_);
lean_dec_ref(v___x_1143_);
v___x_1144_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__8, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__8_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__8);
return v___x_1144_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0___redArg(lean_object* v_s_1145_, lean_object* v_range_1146_, uint64_t v_b_1147_, lean_object* v_i_1148_){
_start:
{
lean_object* v_stop_1150_; lean_object* v_step_1151_; uint64_t v___y_1153_; uint8_t v___x_1157_; 
v_stop_1150_ = lean_ctor_get(v_range_1146_, 1);
v_step_1151_ = lean_ctor_get(v_range_1146_, 2);
v___x_1157_ = lean_nat_dec_lt(v_i_1148_, v_stop_1150_);
if (v___x_1157_ == 0)
{
lean_object* v___x_1158_; lean_object* v___x_1159_; 
lean_dec(v_i_1148_);
lean_dec(v_s_1145_);
v___x_1158_ = lean_box_uint64(v_b_1147_);
v___x_1159_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1159_, 0, v___x_1158_);
return v___x_1159_;
}
else
{
uint8_t v___x_1160_; 
lean_inc(v_s_1145_);
v___x_1160_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck(v_s_1145_);
if (v___x_1160_ == 0)
{
uint64_t v___x_1161_; 
v___x_1161_ = 13ULL;
v___y_1153_ = v___x_1161_;
goto v___jp_1152_;
}
else
{
uint64_t v___x_1162_; 
v___x_1162_ = 11ULL;
v___y_1153_ = v___x_1162_;
goto v___jp_1152_;
}
}
v___jp_1152_:
{
lean_object* v___x_1154_; lean_object* v___x_1155_; 
v___x_1154_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1153_);
lean_dec_ref(v___x_1154_);
v___x_1155_ = lean_nat_add(v_i_1148_, v_step_1151_);
lean_dec(v_i_1148_);
v_b_1147_ = v___y_1153_;
v_i_1148_ = v___x_1155_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0___redArg___boxed(lean_object* v_s_1163_, lean_object* v_range_1164_, lean_object* v_b_1165_, lean_object* v_i_1166_, lean_object* v___y_1167_){
_start:
{
uint64_t v_b_boxed_1168_; lean_object* v_res_1169_; 
v_b_boxed_1168_ = lean_unbox_uint64(v_b_1165_);
lean_dec_ref(v_b_1165_);
v_res_1169_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0___redArg(v_s_1163_, v_range_1164_, v_b_boxed_1168_, v_i_1166_);
lean_dec_ref(v_range_1164_);
return v_res_1169_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_(lean_object* v_s_1170_, lean_object* v_count_1171_){
_start:
{
lean_object* v___x_1173_; uint8_t v___x_1174_; 
v___x_1173_ = lean_unsigned_to_nat(0u);
v___x_1174_ = lean_nat_dec_eq(v_count_1171_, v___x_1173_);
if (v___x_1174_ == 0)
{
uint64_t v___x_1175_; lean_object* v___x_1176_; lean_object* v___x_1177_; lean_object* v___x_1178_; lean_object* v___x_1179_; 
v___x_1175_ = 0ULL;
v___x_1176_ = lean_io_mono_nanos_now();
v___x_1177_ = lean_unsigned_to_nat(1u);
v___x_1178_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1178_, 0, v___x_1173_);
lean_ctor_set(v___x_1178_, 1, v_count_1171_);
lean_ctor_set(v___x_1178_, 2, v___x_1177_);
v___x_1179_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0___redArg(v_s_1170_, v___x_1178_, v___x_1175_, v___x_1173_);
lean_dec_ref_known(v___x_1178_, 3);
if (lean_obj_tag(v___x_1179_) == 0)
{
lean_object* v_a_1180_; lean_object* v___x_1182_; uint8_t v_isShared_1183_; uint8_t v_isSharedCheck_1191_; 
v_a_1180_ = lean_ctor_get(v___x_1179_, 0);
v_isSharedCheck_1191_ = !lean_is_exclusive(v___x_1179_);
if (v_isSharedCheck_1191_ == 0)
{
v___x_1182_ = v___x_1179_;
v_isShared_1183_ = v_isSharedCheck_1191_;
goto v_resetjp_1181_;
}
else
{
lean_inc(v_a_1180_);
lean_dec(v___x_1179_);
v___x_1182_ = lean_box(0);
v_isShared_1183_ = v_isSharedCheck_1191_;
goto v_resetjp_1181_;
}
v_resetjp_1181_:
{
lean_object* v___x_1184_; lean_object* v___x_1185_; lean_object* v___x_1186_; lean_object* v___x_1187_; lean_object* v___x_1189_; 
v___x_1184_ = lean_io_mono_nanos_now();
v___x_1185_ = lean_nat_sub(v___x_1184_, v___x_1176_);
lean_dec(v___x_1176_);
lean_dec(v___x_1184_);
v___x_1186_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1186_, 0, v_a_1180_);
v___x_1187_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1187_, 0, v___x_1185_);
lean_ctor_set(v___x_1187_, 1, v___x_1186_);
if (v_isShared_1183_ == 0)
{
lean_ctor_set(v___x_1182_, 0, v___x_1187_);
v___x_1189_ = v___x_1182_;
goto v_reusejp_1188_;
}
else
{
lean_object* v_reuseFailAlloc_1190_; 
v_reuseFailAlloc_1190_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1190_, 0, v___x_1187_);
v___x_1189_ = v_reuseFailAlloc_1190_;
goto v_reusejp_1188_;
}
v_reusejp_1188_:
{
return v___x_1189_;
}
}
}
else
{
lean_object* v_a_1192_; lean_object* v___x_1194_; uint8_t v_isShared_1195_; uint8_t v_isSharedCheck_1199_; 
lean_dec(v___x_1176_);
v_a_1192_ = lean_ctor_get(v___x_1179_, 0);
v_isSharedCheck_1199_ = !lean_is_exclusive(v___x_1179_);
if (v_isSharedCheck_1199_ == 0)
{
v___x_1194_ = v___x_1179_;
v_isShared_1195_ = v_isSharedCheck_1199_;
goto v_resetjp_1193_;
}
else
{
lean_inc(v_a_1192_);
lean_dec(v___x_1179_);
v___x_1194_ = lean_box(0);
v_isShared_1195_ = v_isSharedCheck_1199_;
goto v_resetjp_1193_;
}
v_resetjp_1193_:
{
lean_object* v___x_1197_; 
if (v_isShared_1195_ == 0)
{
v___x_1197_ = v___x_1194_;
goto v_reusejp_1196_;
}
else
{
lean_object* v_reuseFailAlloc_1198_; 
v_reuseFailAlloc_1198_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1198_, 0, v_a_1192_);
v___x_1197_ = v_reuseFailAlloc_1198_;
goto v_reusejp_1196_;
}
v_reusejp_1196_:
{
return v___x_1197_;
}
}
}
}
else
{
lean_object* v___x_1200_; lean_object* v___x_1201_; 
lean_dec(v_count_1171_);
lean_dec(v_s_1170_);
v___x_1200_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___closed__0));
v___x_1201_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1201_, 0, v___x_1200_);
return v___x_1201_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33____boxed(lean_object* v_s_1202_, lean_object* v_count_1203_, lean_object* v___y_1204_){
_start:
{
lean_object* v_res_1205_; 
v_res_1205_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_(v_s_1202_, v_count_1203_);
return v_res_1205_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_(lean_object* v___y_1206_){
_start:
{
lean_object* v_s_1208_; lean_object* v___f_1209_; uint64_t v___y_1211_; 
v_s_1208_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_input(v___y_1206_);
lean_inc(v_s_1208_);
v___f_1209_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33____boxed), 3, 1);
lean_closure_set(v___f_1209_, 0, v_s_1208_);
if (lean_obj_tag(v_s_1208_) == 0)
{
uint64_t v___x_1221_; 
v___x_1221_ = 11ULL;
v___y_1211_ = v___x_1221_;
goto v___jp_1210_;
}
else
{
lean_object* v_val_1222_; lean_object* v_system_1223_; lean_object* v_arity_1224_; lean_object* v_size_1225_; lean_object* v_rows_1226_; lean_object* v_columns_1227_; lean_object* v_counts_1228_; lean_object* v_values_1229_; lean_object* v_inverse_1230_; lean_object* v_denominator_1231_; uint64_t v___x_1232_; uint64_t v___x_1233_; uint64_t v___x_1234_; uint64_t v___y_1236_; uint64_t v___y_1237_; uint64_t v___y_1238_; uint64_t v___y_1239_; uint64_t v___y_1240_; uint64_t v___y_1251_; uint64_t v___y_1252_; uint64_t v___y_1253_; uint64_t v___y_1254_; uint64_t v___y_1269_; uint64_t v___y_1270_; uint64_t v___y_1271_; uint64_t v___y_1280_; uint64_t v___y_1281_; uint64_t v___y_1290_; uint64_t v___x_1298_; lean_object* v___x_1299_; lean_object* v___x_1300_; uint8_t v___x_1301_; 
v_val_1222_ = lean_ctor_get(v_s_1208_, 0);
lean_inc(v_val_1222_);
lean_dec_ref_known(v_s_1208_, 1);
v_system_1223_ = lean_ctor_get(v_val_1222_, 2);
lean_inc_ref(v_system_1223_);
v_arity_1224_ = lean_ctor_get(v_val_1222_, 0);
lean_inc(v_arity_1224_);
v_size_1225_ = lean_ctor_get(v_val_1222_, 1);
lean_inc_n(v_size_1225_, 3);
lean_dec(v_val_1222_);
v_rows_1226_ = lean_ctor_get(v_system_1223_, 0);
lean_inc_ref(v_rows_1226_);
v_columns_1227_ = lean_ctor_get(v_system_1223_, 1);
lean_inc_ref(v_columns_1227_);
v_counts_1228_ = lean_ctor_get(v_system_1223_, 2);
lean_inc_ref(v_counts_1228_);
v_values_1229_ = lean_ctor_get(v_system_1223_, 3);
lean_inc_ref(v_values_1229_);
v_inverse_1230_ = lean_ctor_get(v_system_1223_, 4);
lean_inc_ref(v_inverse_1230_);
v_denominator_1231_ = lean_ctor_get(v_system_1223_, 5);
lean_inc(v_denominator_1231_);
lean_dec_ref(v_system_1223_);
v___x_1232_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_1225_, v_size_1225_, v_inverse_1230_);
v___x_1233_ = lean_uint64_of_nat(v_arity_1224_);
lean_dec(v_arity_1224_);
v___x_1234_ = lean_uint64_of_nat(v_size_1225_);
lean_dec(v_size_1225_);
v___x_1298_ = 7ULL;
v___x_1299_ = lean_unsigned_to_nat(0u);
v___x_1300_ = lean_array_get_size(v_rows_1226_);
v___x_1301_ = lean_nat_dec_lt(v___x_1299_, v___x_1300_);
if (v___x_1301_ == 0)
{
lean_dec_ref(v_rows_1226_);
v___y_1290_ = v___x_1298_;
goto v___jp_1289_;
}
else
{
size_t v___x_1302_; size_t v___x_1303_; uint64_t v___x_1304_; 
v___x_1302_ = ((size_t)0ULL);
v___x_1303_ = lean_usize_of_nat(v___x_1300_);
v___x_1304_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(v_rows_1226_, v___x_1302_, v___x_1303_, v___x_1298_);
lean_dec_ref(v_rows_1226_);
v___y_1290_ = v___x_1304_;
goto v___jp_1289_;
}
v___jp_1235_:
{
uint64_t v___x_1241_; uint64_t v___x_1242_; uint64_t v___x_1243_; uint64_t v___x_1244_; uint64_t v___x_1245_; uint64_t v___x_1246_; uint64_t v___x_1247_; uint64_t v___x_1248_; uint64_t v___x_1249_; 
v___x_1241_ = lean_uint64_mix_hash(v___x_1232_, v___y_1240_);
v___x_1242_ = lean_uint64_mix_hash(v___y_1237_, v___x_1241_);
v___x_1243_ = lean_uint64_mix_hash(v___y_1236_, v___x_1242_);
v___x_1244_ = lean_uint64_mix_hash(v___y_1238_, v___x_1243_);
v___x_1245_ = lean_uint64_mix_hash(v___y_1239_, v___x_1244_);
v___x_1246_ = lean_uint64_mix_hash(v___x_1234_, v___x_1245_);
v___x_1247_ = lean_uint64_mix_hash(v___x_1233_, v___x_1246_);
v___x_1248_ = 13ULL;
v___x_1249_ = lean_uint64_mix_hash(v___x_1247_, v___x_1248_);
v___y_1211_ = v___x_1249_;
goto v___jp_1210_;
}
v___jp_1250_:
{
lean_object* v_intZero_1255_; uint8_t v_isNeg_1256_; 
v_intZero_1255_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_1256_ = lean_int_dec_lt(v_denominator_1231_, v_intZero_1255_);
if (v_isNeg_1256_ == 0)
{
lean_object* v_a_1257_; lean_object* v___x_1258_; lean_object* v___x_1259_; uint64_t v___x_1260_; 
v_a_1257_ = lean_nat_abs(v_denominator_1231_);
lean_dec(v_denominator_1231_);
v___x_1258_ = lean_unsigned_to_nat(2u);
v___x_1259_ = lean_nat_mul(v___x_1258_, v_a_1257_);
lean_dec(v_a_1257_);
v___x_1260_ = lean_uint64_of_nat(v___x_1259_);
lean_dec(v___x_1259_);
v___y_1236_ = v___y_1251_;
v___y_1237_ = v___y_1254_;
v___y_1238_ = v___y_1252_;
v___y_1239_ = v___y_1253_;
v___y_1240_ = v___x_1260_;
goto v___jp_1235_;
}
else
{
lean_object* v_abs_1261_; lean_object* v_one_1262_; lean_object* v_a_1263_; lean_object* v___x_1264_; lean_object* v___x_1265_; lean_object* v___x_1266_; uint64_t v___x_1267_; 
v_abs_1261_ = lean_nat_abs(v_denominator_1231_);
lean_dec(v_denominator_1231_);
v_one_1262_ = lean_unsigned_to_nat(1u);
v_a_1263_ = lean_nat_sub(v_abs_1261_, v_one_1262_);
lean_dec(v_abs_1261_);
v___x_1264_ = lean_unsigned_to_nat(2u);
v___x_1265_ = lean_nat_mul(v___x_1264_, v_a_1263_);
lean_dec(v_a_1263_);
v___x_1266_ = lean_nat_add(v___x_1265_, v_one_1262_);
lean_dec(v___x_1265_);
v___x_1267_ = lean_uint64_of_nat(v___x_1266_);
lean_dec(v___x_1266_);
v___y_1236_ = v___y_1251_;
v___y_1237_ = v___y_1254_;
v___y_1238_ = v___y_1252_;
v___y_1239_ = v___y_1253_;
v___y_1240_ = v___x_1267_;
goto v___jp_1235_;
}
}
v___jp_1268_:
{
uint64_t v___x_1272_; lean_object* v___x_1273_; lean_object* v___x_1274_; uint8_t v___x_1275_; 
v___x_1272_ = 7ULL;
v___x_1273_ = lean_unsigned_to_nat(0u);
v___x_1274_ = lean_array_get_size(v_values_1229_);
v___x_1275_ = lean_nat_dec_lt(v___x_1273_, v___x_1274_);
if (v___x_1275_ == 0)
{
lean_dec_ref(v_values_1229_);
v___y_1251_ = v___y_1271_;
v___y_1252_ = v___y_1269_;
v___y_1253_ = v___y_1270_;
v___y_1254_ = v___x_1272_;
goto v___jp_1250_;
}
else
{
size_t v___x_1276_; size_t v___x_1277_; uint64_t v___x_1278_; 
v___x_1276_ = ((size_t)0ULL);
v___x_1277_ = lean_usize_of_nat(v___x_1274_);
v___x_1278_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_values_1229_, v___x_1276_, v___x_1277_, v___x_1272_);
lean_dec_ref(v_values_1229_);
v___y_1251_ = v___y_1271_;
v___y_1252_ = v___y_1269_;
v___y_1253_ = v___y_1270_;
v___y_1254_ = v___x_1278_;
goto v___jp_1250_;
}
}
v___jp_1279_:
{
uint64_t v___x_1282_; lean_object* v___x_1283_; lean_object* v___x_1284_; uint8_t v___x_1285_; 
v___x_1282_ = 7ULL;
v___x_1283_ = lean_unsigned_to_nat(0u);
v___x_1284_ = lean_array_get_size(v_counts_1228_);
v___x_1285_ = lean_nat_dec_lt(v___x_1283_, v___x_1284_);
if (v___x_1285_ == 0)
{
lean_dec_ref(v_counts_1228_);
v___y_1269_ = v___y_1281_;
v___y_1270_ = v___y_1280_;
v___y_1271_ = v___x_1282_;
goto v___jp_1268_;
}
else
{
size_t v___x_1286_; size_t v___x_1287_; uint64_t v___x_1288_; 
v___x_1286_ = ((size_t)0ULL);
v___x_1287_ = lean_usize_of_nat(v___x_1284_);
v___x_1288_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_counts_1228_, v___x_1286_, v___x_1287_, v___x_1282_);
lean_dec_ref(v_counts_1228_);
v___y_1269_ = v___y_1281_;
v___y_1270_ = v___y_1280_;
v___y_1271_ = v___x_1288_;
goto v___jp_1268_;
}
}
v___jp_1289_:
{
uint64_t v___x_1291_; lean_object* v___x_1292_; lean_object* v___x_1293_; uint8_t v___x_1294_; 
v___x_1291_ = 7ULL;
v___x_1292_ = lean_unsigned_to_nat(0u);
v___x_1293_ = lean_array_get_size(v_columns_1227_);
v___x_1294_ = lean_nat_dec_lt(v___x_1292_, v___x_1293_);
if (v___x_1294_ == 0)
{
lean_dec_ref(v_columns_1227_);
v___y_1280_ = v___y_1290_;
v___y_1281_ = v___x_1291_;
goto v___jp_1279_;
}
else
{
size_t v___x_1295_; size_t v___x_1296_; uint64_t v___x_1297_; 
v___x_1295_ = ((size_t)0ULL);
v___x_1296_ = lean_usize_of_nat(v___x_1293_);
v___x_1297_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v_columns_1227_, v___x_1295_, v___x_1296_, v___x_1291_);
lean_dec_ref(v_columns_1227_);
v___y_1280_ = v___y_1290_;
v___y_1281_ = v___x_1297_;
goto v___jp_1279_;
}
}
}
v___jp_1210_:
{
lean_object* v___x_1212_; lean_object* v___x_1214_; uint8_t v_isShared_1215_; uint8_t v_isSharedCheck_1219_; 
v___x_1212_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1211_);
v_isSharedCheck_1219_ = !lean_is_exclusive(v___x_1212_);
if (v_isSharedCheck_1219_ == 0)
{
lean_object* v_unused_1220_; 
v_unused_1220_ = lean_ctor_get(v___x_1212_, 0);
lean_dec(v_unused_1220_);
v___x_1214_ = v___x_1212_;
v_isShared_1215_ = v_isSharedCheck_1219_;
goto v_resetjp_1213_;
}
else
{
lean_dec(v___x_1212_);
v___x_1214_ = lean_box(0);
v_isShared_1215_ = v_isSharedCheck_1219_;
goto v_resetjp_1213_;
}
v_resetjp_1213_:
{
lean_object* v___x_1217_; 
if (v_isShared_1215_ == 0)
{
lean_ctor_set(v___x_1214_, 0, v___f_1209_);
v___x_1217_ = v___x_1214_;
goto v_reusejp_1216_;
}
else
{
lean_object* v_reuseFailAlloc_1218_; 
v_reuseFailAlloc_1218_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1218_, 0, v___f_1209_);
v___x_1217_ = v_reuseFailAlloc_1218_;
goto v_reusejp_1216_;
}
v_reusejp_1216_:
{
return v___x_1217_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33____boxed(lean_object* v___y_1305_, lean_object* v___y_1306_){
_start:
{
lean_object* v_res_1307_; 
v_res_1307_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_(v___y_1305_);
return v_res_1307_;
}
}
static lean_object* _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_(void){
_start:
{
lean_object* v___x_1315_; uint8_t v___x_1316_; lean_object* v___x_1317_; lean_object* v___x_1318_; lean_object* v___x_1319_; 
v___x_1315_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__config;
v___x_1316_ = 1;
v___x_1317_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__6_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_));
v___x_1318_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_));
v___x_1319_ = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(v___x_1319_, 0, v___x_1318_);
lean_ctor_set(v___x_1319_, 1, v___x_1317_);
lean_ctor_set(v___x_1319_, 2, v___x_1315_);
lean_ctor_set_uint8(v___x_1319_, sizeof(void*)*3, v___x_1316_);
return v___x_1319_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_(){
_start:
{
lean_object* v___f_1322_; lean_object* v___x_1323_; lean_object* v___x_1324_; lean_object* v___x_1325_; 
v___f_1322_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_));
v___x_1323_ = lean_obj_once(&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_, &lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__once, _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_);
v___x_1324_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_));
v___x_1325_ = lp_lean_x2dbench_LeanBench_register(v___x_1323_, v___f_1322_, v___x_1324_);
return v___x_1325_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33____boxed(lean_object* v_a_1326_){
_start:
{
lean_object* v_res_1327_; 
v_res_1327_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_();
return v_res_1327_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0(lean_object* v_s_1328_, lean_object* v_range_1329_, uint64_t v_b_1330_, lean_object* v_i_1331_, lean_object* v_hs_1332_, lean_object* v_hl_1333_){
_start:
{
lean_object* v___x_1335_; 
v___x_1335_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0___redArg(v_s_1328_, v_range_1329_, v_b_1330_, v_i_1331_);
return v___x_1335_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0___boxed(lean_object* v_s_1336_, lean_object* v_range_1337_, lean_object* v_b_1338_, lean_object* v_i_1339_, lean_object* v_hs_1340_, lean_object* v_hl_1341_, lean_object* v___y_1342_){
_start:
{
uint64_t v_b_boxed_1343_; lean_object* v_res_1344_; 
v_b_boxed_1343_ = lean_unbox_uint64(v_b_1338_);
lean_dec_ref(v_b_1338_);
v_res_1344_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33__spec__0(v_s_1336_, v_range_1337_, v_b_boxed_1343_, v_i_1339_, v_hs_1340_, v_hl_1341_);
lean_dec_ref(v_range_1337_);
return v_res_1344_;
}
}
LEAN_EXPORT uint64_t lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(uint8_t v_r_1345_){
_start:
{
if (v_r_1345_ == 0)
{
uint64_t v___x_1346_; 
v___x_1346_ = 13ULL;
return v___x_1346_;
}
else
{
uint64_t v___x_1347_; 
v___x_1347_ = 11ULL;
return v___x_1347_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed(lean_object* v_r_1348_){
_start:
{
uint8_t v_r_448__boxed_1349_; uint64_t v_res_1350_; lean_object* v_r_1351_; 
v_r_448__boxed_1349_ = lean_unbox(v_r_1348_);
v_res_1350_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(v_r_448__boxed_1349_);
v_r_1351_ = lean_box_uint64(v_res_1350_);
return v_r_1351_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(lean_object* v_s_1352_, lean_object* v_x_1353_){
_start:
{
uint8_t v___x_1355_; lean_object* v___x_1356_; lean_object* v___x_1357_; 
v___x_1355_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck(v_s_1352_);
v___x_1356_ = lean_box(v___x_1355_);
v___x_1357_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1357_, 0, v___x_1356_);
return v___x_1357_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed(lean_object* v_s_1358_, lean_object* v_x_1359_, lean_object* v___y_1360_){
_start:
{
lean_object* v_res_1361_; 
v_res_1361_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(v_s_1358_, v_x_1359_);
return v_res_1361_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(lean_object* v___f_1362_, lean_object* v_param_1363_){
_start:
{
lean_object* v_s_1365_; lean_object* v___f_1366_; uint64_t v___y_1368_; 
v_s_1365_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_input(v_param_1363_);
lean_inc(v_s_1365_);
v___f_1366_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed), 3, 1);
lean_closure_set(v___f_1366_, 0, v_s_1365_);
if (lean_obj_tag(v_s_1365_) == 0)
{
uint64_t v___x_1373_; 
v___x_1373_ = 11ULL;
v___y_1368_ = v___x_1373_;
goto v___jp_1367_;
}
else
{
lean_object* v_val_1374_; lean_object* v_system_1375_; lean_object* v_arity_1376_; lean_object* v_size_1377_; lean_object* v_rows_1378_; lean_object* v_columns_1379_; lean_object* v_counts_1380_; lean_object* v_values_1381_; lean_object* v_inverse_1382_; lean_object* v_denominator_1383_; uint64_t v___x_1384_; uint64_t v___x_1385_; uint64_t v___x_1386_; uint64_t v___y_1388_; uint64_t v___y_1389_; uint64_t v___y_1390_; uint64_t v___y_1391_; uint64_t v___y_1392_; uint64_t v___y_1403_; uint64_t v___y_1404_; uint64_t v___y_1405_; uint64_t v___y_1406_; uint64_t v___y_1421_; uint64_t v___y_1422_; uint64_t v___y_1423_; uint64_t v___y_1432_; uint64_t v___y_1433_; uint64_t v___y_1442_; uint64_t v___x_1450_; lean_object* v___x_1451_; lean_object* v___x_1452_; uint8_t v___x_1453_; 
v_val_1374_ = lean_ctor_get(v_s_1365_, 0);
lean_inc(v_val_1374_);
lean_dec_ref_known(v_s_1365_, 1);
v_system_1375_ = lean_ctor_get(v_val_1374_, 2);
lean_inc_ref(v_system_1375_);
v_arity_1376_ = lean_ctor_get(v_val_1374_, 0);
lean_inc(v_arity_1376_);
v_size_1377_ = lean_ctor_get(v_val_1374_, 1);
lean_inc_n(v_size_1377_, 3);
lean_dec(v_val_1374_);
v_rows_1378_ = lean_ctor_get(v_system_1375_, 0);
lean_inc_ref(v_rows_1378_);
v_columns_1379_ = lean_ctor_get(v_system_1375_, 1);
lean_inc_ref(v_columns_1379_);
v_counts_1380_ = lean_ctor_get(v_system_1375_, 2);
lean_inc_ref(v_counts_1380_);
v_values_1381_ = lean_ctor_get(v_system_1375_, 3);
lean_inc_ref(v_values_1381_);
v_inverse_1382_ = lean_ctor_get(v_system_1375_, 4);
lean_inc_ref(v_inverse_1382_);
v_denominator_1383_ = lean_ctor_get(v_system_1375_, 5);
lean_inc(v_denominator_1383_);
lean_dec_ref(v_system_1375_);
v___x_1384_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_1377_, v_size_1377_, v_inverse_1382_);
v___x_1385_ = lean_uint64_of_nat(v_arity_1376_);
lean_dec(v_arity_1376_);
v___x_1386_ = lean_uint64_of_nat(v_size_1377_);
lean_dec(v_size_1377_);
v___x_1450_ = 7ULL;
v___x_1451_ = lean_unsigned_to_nat(0u);
v___x_1452_ = lean_array_get_size(v_rows_1378_);
v___x_1453_ = lean_nat_dec_lt(v___x_1451_, v___x_1452_);
if (v___x_1453_ == 0)
{
lean_dec_ref(v_rows_1378_);
v___y_1442_ = v___x_1450_;
goto v___jp_1441_;
}
else
{
size_t v___x_1454_; size_t v___x_1455_; uint64_t v___x_1456_; 
v___x_1454_ = ((size_t)0ULL);
v___x_1455_ = lean_usize_of_nat(v___x_1452_);
v___x_1456_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(v_rows_1378_, v___x_1454_, v___x_1455_, v___x_1450_);
lean_dec_ref(v_rows_1378_);
v___y_1442_ = v___x_1456_;
goto v___jp_1441_;
}
v___jp_1387_:
{
uint64_t v___x_1393_; uint64_t v___x_1394_; uint64_t v___x_1395_; uint64_t v___x_1396_; uint64_t v___x_1397_; uint64_t v___x_1398_; uint64_t v___x_1399_; uint64_t v___x_1400_; uint64_t v___x_1401_; 
v___x_1393_ = lean_uint64_mix_hash(v___x_1384_, v___y_1392_);
v___x_1394_ = lean_uint64_mix_hash(v___y_1390_, v___x_1393_);
v___x_1395_ = lean_uint64_mix_hash(v___y_1388_, v___x_1394_);
v___x_1396_ = lean_uint64_mix_hash(v___y_1391_, v___x_1395_);
v___x_1397_ = lean_uint64_mix_hash(v___y_1389_, v___x_1396_);
v___x_1398_ = lean_uint64_mix_hash(v___x_1386_, v___x_1397_);
v___x_1399_ = lean_uint64_mix_hash(v___x_1385_, v___x_1398_);
v___x_1400_ = 13ULL;
v___x_1401_ = lean_uint64_mix_hash(v___x_1399_, v___x_1400_);
v___y_1368_ = v___x_1401_;
goto v___jp_1367_;
}
v___jp_1402_:
{
lean_object* v_intZero_1407_; uint8_t v_isNeg_1408_; 
v_intZero_1407_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_1408_ = lean_int_dec_lt(v_denominator_1383_, v_intZero_1407_);
if (v_isNeg_1408_ == 0)
{
lean_object* v_a_1409_; lean_object* v___x_1410_; lean_object* v___x_1411_; uint64_t v___x_1412_; 
v_a_1409_ = lean_nat_abs(v_denominator_1383_);
lean_dec(v_denominator_1383_);
v___x_1410_ = lean_unsigned_to_nat(2u);
v___x_1411_ = lean_nat_mul(v___x_1410_, v_a_1409_);
lean_dec(v_a_1409_);
v___x_1412_ = lean_uint64_of_nat(v___x_1411_);
lean_dec(v___x_1411_);
v___y_1388_ = v___y_1403_;
v___y_1389_ = v___y_1404_;
v___y_1390_ = v___y_1406_;
v___y_1391_ = v___y_1405_;
v___y_1392_ = v___x_1412_;
goto v___jp_1387_;
}
else
{
lean_object* v_abs_1413_; lean_object* v_one_1414_; lean_object* v_a_1415_; lean_object* v___x_1416_; lean_object* v___x_1417_; lean_object* v___x_1418_; uint64_t v___x_1419_; 
v_abs_1413_ = lean_nat_abs(v_denominator_1383_);
lean_dec(v_denominator_1383_);
v_one_1414_ = lean_unsigned_to_nat(1u);
v_a_1415_ = lean_nat_sub(v_abs_1413_, v_one_1414_);
lean_dec(v_abs_1413_);
v___x_1416_ = lean_unsigned_to_nat(2u);
v___x_1417_ = lean_nat_mul(v___x_1416_, v_a_1415_);
lean_dec(v_a_1415_);
v___x_1418_ = lean_nat_add(v___x_1417_, v_one_1414_);
lean_dec(v___x_1417_);
v___x_1419_ = lean_uint64_of_nat(v___x_1418_);
lean_dec(v___x_1418_);
v___y_1388_ = v___y_1403_;
v___y_1389_ = v___y_1404_;
v___y_1390_ = v___y_1406_;
v___y_1391_ = v___y_1405_;
v___y_1392_ = v___x_1419_;
goto v___jp_1387_;
}
}
v___jp_1420_:
{
uint64_t v___x_1424_; lean_object* v___x_1425_; lean_object* v___x_1426_; uint8_t v___x_1427_; 
v___x_1424_ = 7ULL;
v___x_1425_ = lean_unsigned_to_nat(0u);
v___x_1426_ = lean_array_get_size(v_values_1381_);
v___x_1427_ = lean_nat_dec_lt(v___x_1425_, v___x_1426_);
if (v___x_1427_ == 0)
{
lean_dec_ref(v_values_1381_);
v___y_1403_ = v___y_1423_;
v___y_1404_ = v___y_1421_;
v___y_1405_ = v___y_1422_;
v___y_1406_ = v___x_1424_;
goto v___jp_1402_;
}
else
{
size_t v___x_1428_; size_t v___x_1429_; uint64_t v___x_1430_; 
v___x_1428_ = ((size_t)0ULL);
v___x_1429_ = lean_usize_of_nat(v___x_1426_);
v___x_1430_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_values_1381_, v___x_1428_, v___x_1429_, v___x_1424_);
lean_dec_ref(v_values_1381_);
v___y_1403_ = v___y_1423_;
v___y_1404_ = v___y_1421_;
v___y_1405_ = v___y_1422_;
v___y_1406_ = v___x_1430_;
goto v___jp_1402_;
}
}
v___jp_1431_:
{
uint64_t v___x_1434_; lean_object* v___x_1435_; lean_object* v___x_1436_; uint8_t v___x_1437_; 
v___x_1434_ = 7ULL;
v___x_1435_ = lean_unsigned_to_nat(0u);
v___x_1436_ = lean_array_get_size(v_counts_1380_);
v___x_1437_ = lean_nat_dec_lt(v___x_1435_, v___x_1436_);
if (v___x_1437_ == 0)
{
lean_dec_ref(v_counts_1380_);
v___y_1421_ = v___y_1432_;
v___y_1422_ = v___y_1433_;
v___y_1423_ = v___x_1434_;
goto v___jp_1420_;
}
else
{
size_t v___x_1438_; size_t v___x_1439_; uint64_t v___x_1440_; 
v___x_1438_ = ((size_t)0ULL);
v___x_1439_ = lean_usize_of_nat(v___x_1436_);
v___x_1440_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_counts_1380_, v___x_1438_, v___x_1439_, v___x_1434_);
lean_dec_ref(v_counts_1380_);
v___y_1421_ = v___y_1432_;
v___y_1422_ = v___y_1433_;
v___y_1423_ = v___x_1440_;
goto v___jp_1420_;
}
}
v___jp_1441_:
{
uint64_t v___x_1443_; lean_object* v___x_1444_; lean_object* v___x_1445_; uint8_t v___x_1446_; 
v___x_1443_ = 7ULL;
v___x_1444_ = lean_unsigned_to_nat(0u);
v___x_1445_ = lean_array_get_size(v_columns_1379_);
v___x_1446_ = lean_nat_dec_lt(v___x_1444_, v___x_1445_);
if (v___x_1446_ == 0)
{
lean_dec_ref(v_columns_1379_);
v___y_1432_ = v___y_1442_;
v___y_1433_ = v___x_1443_;
goto v___jp_1431_;
}
else
{
size_t v___x_1447_; size_t v___x_1448_; uint64_t v___x_1449_; 
v___x_1447_ = ((size_t)0ULL);
v___x_1448_ = lean_usize_of_nat(v___x_1445_);
v___x_1449_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v_columns_1379_, v___x_1447_, v___x_1448_, v___x_1443_);
lean_dec_ref(v_columns_1379_);
v___y_1432_ = v___y_1442_;
v___y_1433_ = v___x_1449_;
goto v___jp_1431_;
}
}
}
v___jp_1367_:
{
lean_object* v___x_1369_; uint8_t v___x_1370_; uint8_t v___x_1371_; lean_object* v___x_1372_; 
v___x_1369_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1368_);
lean_dec_ref(v___x_1369_);
v___x_1370_ = 1;
v___x_1371_ = 0;
v___x_1372_ = lp_lean_x2dbench_LeanBench_kernelLoop___redArg(v___f_1366_, v___f_1362_, v___x_1370_, v___x_1371_);
return v___x_1372_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed(lean_object* v___f_1457_, lean_object* v_param_1458_, lean_object* v___y_1459_){
_start:
{
lean_object* v_res_1460_; 
v_res_1460_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(v___f_1457_, v_param_1458_);
return v_res_1460_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_(){
_start:
{
lean_object* v___f_1465_; lean_object* v___x_1466_; lean_object* v___x_1467_; 
v___f_1465_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__1_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_));
v___x_1466_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_));
v___x_1467_ = lp_lean_x2dbench_LeanBench_registerKernel(v___x_1466_, v___f_1465_);
return v___x_1467_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37____boxed(lean_object* v_a_1468_){
_start:
{
lean_object* v_res_1469_; 
v_res_1469_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_();
return v_res_1469_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0(lean_object* v_r_1473_, lean_object* v_as_1474_, size_t v_sz_1475_, size_t v_i_1476_, lean_object* v_b_1477_){
_start:
{
uint8_t v___x_1478_; 
v___x_1478_ = lean_usize_dec_lt(v_i_1476_, v_sz_1475_);
if (v___x_1478_ == 0)
{
lean_inc_ref(v_b_1477_);
return v_b_1477_;
}
else
{
lean_object* v___x_1479_; lean_object* v_a_1480_; lean_object* v___x_1481_; lean_object* v___x_1482_; uint8_t v___x_1483_; 
v___x_1479_ = lean_box(0);
v_a_1480_ = lean_array_uget_borrowed(v_as_1474_, v_i_1476_);
v___x_1481_ = lean_unsigned_to_nat(3u);
v___x_1482_ = lean_nat_pow(v___x_1481_, v_a_1480_);
v___x_1483_ = lean_nat_dec_eq(v___x_1482_, v_r_1473_);
lean_dec(v___x_1482_);
if (v___x_1483_ == 0)
{
lean_object* v___x_1484_; size_t v___x_1485_; size_t v___x_1486_; 
v___x_1484_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0___closed__0));
v___x_1485_ = ((size_t)1ULL);
v___x_1486_ = lean_usize_add(v_i_1476_, v___x_1485_);
v_i_1476_ = v___x_1486_;
v_b_1477_ = v___x_1484_;
goto _start;
}
else
{
lean_object* v___x_1488_; lean_object* v___x_1489_; lean_object* v___x_1490_; 
lean_inc(v_a_1480_);
v___x_1488_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1488_, 0, v_a_1480_);
v___x_1489_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1489_, 0, v___x_1488_);
v___x_1490_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1490_, 0, v___x_1489_);
lean_ctor_set(v___x_1490_, 1, v___x_1479_);
return v___x_1490_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0___boxed(lean_object* v_r_1491_, lean_object* v_as_1492_, lean_object* v_sz_1493_, lean_object* v_i_1494_, lean_object* v_b_1495_){
_start:
{
size_t v_sz_boxed_1496_; size_t v_i_boxed_1497_; lean_object* v_res_1498_; 
v_sz_boxed_1496_ = lean_unbox_usize(v_sz_1493_);
lean_dec(v_sz_1493_);
v_i_boxed_1497_ = lean_unbox_usize(v_i_1494_);
lean_dec(v_i_1494_);
v_res_1498_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0(v_r_1491_, v_as_1492_, v_sz_boxed_1496_, v_i_boxed_1497_, v_b_1495_);
lean_dec_ref(v_b_1495_);
lean_dec_ref(v_as_1492_);
lean_dec(v_r_1491_);
return v_res_1498_;
}
}
static size_t _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__1(void){
_start:
{
lean_object* v___x_1512_; size_t v_sz_1513_; 
v___x_1512_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__0));
v_sz_1513_ = lean_array_size(v___x_1512_);
return v_sz_1513_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput(lean_object* v_r_1514_){
_start:
{
lean_object* v___x_1515_; lean_object* v___x_1516_; lean_object* v___x_1517_; size_t v_sz_1518_; size_t v___x_1519_; lean_object* v___x_1520_; lean_object* v_fst_1521_; 
v___x_1515_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__0));
v___x_1516_ = lean_box(0);
v___x_1517_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0___closed__0));
v_sz_1518_ = lean_usize_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__1, &lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__1_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__1);
v___x_1519_ = ((size_t)0ULL);
v___x_1520_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00Hex_SignDetBench_MaximalMatrix_dimensionInput_spec__0(v_r_1514_, v___x_1515_, v_sz_1518_, v___x_1519_, v___x_1517_);
v_fst_1521_ = lean_ctor_get(v___x_1520_, 0);
lean_inc(v_fst_1521_);
lean_dec_ref(v___x_1520_);
if (lean_obj_tag(v_fst_1521_) == 0)
{
return v___x_1516_;
}
else
{
lean_object* v_val_1522_; 
v_val_1522_ = lean_ctor_get(v_fst_1521_, 0);
lean_inc(v_val_1522_);
lean_dec_ref_known(v_fst_1521_, 1);
if (lean_obj_tag(v_val_1522_) == 0)
{
return v___x_1516_;
}
else
{
lean_object* v_val_1523_; lean_object* v___x_1524_; 
v_val_1523_ = lean_ctor_get(v_val_1522_, 0);
lean_inc(v_val_1523_);
lean_dec_ref_known(v_val_1522_, 1);
v___x_1524_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_input(v_val_1523_);
return v___x_1524_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___boxed(lean_object* v_r_1525_){
_start:
{
lean_object* v_res_1526_; 
v_res_1526_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput(v_r_1525_);
lean_dec(v_r_1525_);
return v_res_1526_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolveDimension(lean_object* v_i_1527_){
_start:
{
lean_object* v___x_1528_; 
v___x_1528_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolve(v_i_1527_);
return v___x_1528_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheckDimension(lean_object* v_i_1529_){
_start:
{
uint8_t v___x_1530_; 
v___x_1530_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck(v_i_1529_);
return v___x_1530_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheckDimension___boxed(lean_object* v_i_1531_){
_start:
{
uint8_t v_res_1532_; lean_object* v_r_1533_; 
v_res_1532_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheckDimension(v_i_1531_);
v_r_1533_ = lean_box(v_res_1532_);
return v_r_1533_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__complexity(lean_object* v_r_1534_){
_start:
{
lean_object* v___x_1535_; lean_object* v___x_1536_; 
v___x_1535_ = lean_unsigned_to_nat(3u);
v___x_1536_ = lean_nat_pow(v_r_1534_, v___x_1535_);
return v___x_1536_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__complexity___boxed(lean_object* v_r_1537_){
_start:
{
lean_object* v_res_1538_; 
v_res_1538_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__complexity(v_r_1537_);
lean_dec(v_r_1537_);
return v_res_1538_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked___lam__0(lean_object* v_s_1539_, lean_object* v_a_1540_, lean_object* v_x_1541_, uint64_t v___y_1542_){
_start:
{
uint64_t v___y_1545_; lean_object* v___x_1557_; 
v___x_1557_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolveDimension(v_s_1539_);
if (lean_obj_tag(v___x_1557_) == 0)
{
uint64_t v___x_1558_; 
v___x_1558_ = 11ULL;
v___y_1545_ = v___x_1558_;
goto v___jp_1544_;
}
else
{
lean_object* v_val_1559_; uint64_t v___x_1560_; uint64_t v___x_1561_; uint64_t v___x_1562_; 
v_val_1559_ = lean_ctor_get(v___x_1557_, 0);
lean_inc(v_val_1559_);
lean_dec_ref_known(v___x_1557_, 1);
v___x_1560_ = 13ULL;
v___x_1561_ = lean_unbox_uint64(v_val_1559_);
lean_dec(v_val_1559_);
v___x_1562_ = lean_uint64_mix_hash(v___x_1561_, v___x_1560_);
v___y_1545_ = v___x_1562_;
goto v___jp_1544_;
}
v___jp_1544_:
{
lean_object* v___x_1546_; lean_object* v___x_1548_; uint8_t v_isShared_1549_; uint8_t v_isSharedCheck_1555_; 
v___x_1546_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1545_);
v_isSharedCheck_1555_ = !lean_is_exclusive(v___x_1546_);
if (v_isSharedCheck_1555_ == 0)
{
lean_object* v_unused_1556_; 
v_unused_1556_ = lean_ctor_get(v___x_1546_, 0);
lean_dec(v_unused_1556_);
v___x_1548_ = v___x_1546_;
v_isShared_1549_ = v_isSharedCheck_1555_;
goto v_resetjp_1547_;
}
else
{
lean_dec(v___x_1546_);
v___x_1548_ = lean_box(0);
v_isShared_1549_ = v_isSharedCheck_1555_;
goto v_resetjp_1547_;
}
v_resetjp_1547_:
{
lean_object* v___x_1550_; lean_object* v___x_1551_; lean_object* v___x_1553_; 
v___x_1550_ = lean_box_uint64(v___y_1545_);
v___x_1551_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1551_, 0, v___x_1550_);
if (v_isShared_1549_ == 0)
{
lean_ctor_set(v___x_1548_, 0, v___x_1551_);
v___x_1553_ = v___x_1548_;
goto v_reusejp_1552_;
}
else
{
lean_object* v_reuseFailAlloc_1554_; 
v_reuseFailAlloc_1554_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1554_, 0, v___x_1551_);
v___x_1553_ = v_reuseFailAlloc_1554_;
goto v_reusejp_1552_;
}
v_reusejp_1552_:
{
return v___x_1553_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked___lam__0___boxed(lean_object* v_s_1563_, lean_object* v_a_1564_, lean_object* v_x_1565_, lean_object* v___y_1566_, lean_object* v___y_1567_){
_start:
{
uint64_t v___y_816__boxed_1568_; lean_object* v_res_1569_; 
v___y_816__boxed_1568_ = lean_unbox_uint64(v___y_1566_);
lean_dec_ref(v___y_1566_);
v_res_1569_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked___lam__0(v_s_1563_, v_a_1564_, v_x_1565_, v___y_816__boxed_1568_);
lean_dec(v_a_1564_);
return v_res_1569_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked(lean_object* v_param_1570_){
_start:
{
lean_object* v___x_1572_; lean_object* v_s_1573_; lean_object* v___f_1574_; lean_object* v___f_1575_; uint64_t v___y_1577_; 
v___x_1572_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0);
v_s_1573_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput(v_param_1570_);
lean_inc(v_s_1573_);
v___f_1574_ = lean_alloc_closure((void*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked___lam__0___boxed), 5, 1);
lean_closure_set(v___f_1574_, 0, v_s_1573_);
v___f_1575_ = lean_alloc_closure((void*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed), 4, 2);
lean_closure_set(v___f_1575_, 0, v___x_1572_);
lean_closure_set(v___f_1575_, 1, v___f_1574_);
if (lean_obj_tag(v_s_1573_) == 0)
{
uint64_t v___x_1587_; 
v___x_1587_ = 11ULL;
v___y_1577_ = v___x_1587_;
goto v___jp_1576_;
}
else
{
lean_object* v_val_1588_; lean_object* v_system_1589_; lean_object* v_arity_1590_; lean_object* v_size_1591_; lean_object* v_rows_1592_; lean_object* v_columns_1593_; lean_object* v_counts_1594_; lean_object* v_values_1595_; lean_object* v_inverse_1596_; lean_object* v_denominator_1597_; lean_object* v___f_1598_; lean_object* v___f_1599_; uint64_t v___x_1600_; uint64_t v___x_1601_; uint64_t v___x_1602_; uint64_t v___y_1604_; uint64_t v___y_1605_; uint64_t v___y_1606_; uint64_t v___y_1607_; uint64_t v___y_1608_; uint64_t v___y_1619_; uint64_t v___y_1620_; uint64_t v___y_1621_; uint64_t v___y_1622_; uint64_t v___y_1637_; uint64_t v___y_1638_; uint64_t v___y_1639_; uint64_t v___y_1651_; uint64_t v___y_1652_; uint64_t v___y_1664_; uint64_t v___x_1675_; lean_object* v___x_1676_; lean_object* v___x_1677_; lean_object* v___x_1678_; uint8_t v___x_1679_; 
v_val_1588_ = lean_ctor_get(v_s_1573_, 0);
lean_inc(v_val_1588_);
lean_dec_ref_known(v_s_1573_, 1);
v_system_1589_ = lean_ctor_get(v_val_1588_, 2);
lean_inc_ref(v_system_1589_);
v_arity_1590_ = lean_ctor_get(v_val_1588_, 0);
lean_inc(v_arity_1590_);
v_size_1591_ = lean_ctor_get(v_val_1588_, 1);
lean_inc_n(v_size_1591_, 3);
lean_dec(v_val_1588_);
v_rows_1592_ = lean_ctor_get(v_system_1589_, 0);
lean_inc_ref(v_rows_1592_);
v_columns_1593_ = lean_ctor_get(v_system_1589_, 1);
lean_inc_ref(v_columns_1593_);
v_counts_1594_ = lean_ctor_get(v_system_1589_, 2);
lean_inc_ref(v_counts_1594_);
v_values_1595_ = lean_ctor_get(v_system_1589_, 3);
lean_inc_ref(v_values_1595_);
v_inverse_1596_ = lean_ctor_get(v_system_1589_, 4);
lean_inc_ref(v_inverse_1596_);
v_denominator_1597_ = lean_ctor_get(v_system_1589_, 5);
lean_inc(v_denominator_1597_);
lean_dec_ref(v_system_1589_);
v___f_1598_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__2));
v___f_1599_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__4));
v___x_1600_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_1591_, v_size_1591_, v_inverse_1596_);
v___x_1601_ = lean_uint64_of_nat(v_arity_1590_);
lean_dec(v_arity_1590_);
v___x_1602_ = lean_uint64_of_nat(v_size_1591_);
lean_dec(v_size_1591_);
v___x_1675_ = 7ULL;
v___x_1676_ = lean_unsigned_to_nat(0u);
v___x_1677_ = lean_array_get_size(v_rows_1592_);
v___x_1678_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_1679_ = lean_nat_dec_lt(v___x_1676_, v___x_1677_);
if (v___x_1679_ == 0)
{
lean_dec_ref(v_rows_1592_);
v___y_1664_ = v___x_1675_;
goto v___jp_1663_;
}
else
{
lean_object* v___f_1680_; size_t v___x_1681_; size_t v___x_1682_; lean_object* v___x_1683_; lean_object* v___x_1684_; uint64_t v___x_1685_; 
v___f_1680_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__1));
v___x_1681_ = ((size_t)0ULL);
v___x_1682_ = lean_usize_of_nat(v___x_1677_);
v___x_1683_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_1684_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_1678_, v___f_1680_, v_rows_1592_, v___x_1681_, v___x_1682_, v___x_1683_);
v___x_1685_ = lean_unbox_uint64(v___x_1684_);
lean_dec(v___x_1684_);
v___y_1664_ = v___x_1685_;
goto v___jp_1663_;
}
v___jp_1603_:
{
uint64_t v___x_1609_; uint64_t v___x_1610_; uint64_t v___x_1611_; uint64_t v___x_1612_; uint64_t v___x_1613_; uint64_t v___x_1614_; uint64_t v___x_1615_; uint64_t v___x_1616_; uint64_t v___x_1617_; 
v___x_1609_ = lean_uint64_mix_hash(v___x_1600_, v___y_1608_);
v___x_1610_ = lean_uint64_mix_hash(v___y_1605_, v___x_1609_);
v___x_1611_ = lean_uint64_mix_hash(v___y_1607_, v___x_1610_);
v___x_1612_ = lean_uint64_mix_hash(v___y_1604_, v___x_1611_);
v___x_1613_ = lean_uint64_mix_hash(v___y_1606_, v___x_1612_);
v___x_1614_ = lean_uint64_mix_hash(v___x_1602_, v___x_1613_);
v___x_1615_ = lean_uint64_mix_hash(v___x_1601_, v___x_1614_);
v___x_1616_ = 13ULL;
v___x_1617_ = lean_uint64_mix_hash(v___x_1615_, v___x_1616_);
v___y_1577_ = v___x_1617_;
goto v___jp_1576_;
}
v___jp_1618_:
{
lean_object* v_intZero_1623_; uint8_t v_isNeg_1624_; 
v_intZero_1623_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_1624_ = lean_int_dec_lt(v_denominator_1597_, v_intZero_1623_);
if (v_isNeg_1624_ == 0)
{
lean_object* v_a_1625_; lean_object* v___x_1626_; lean_object* v___x_1627_; uint64_t v___x_1628_; 
v_a_1625_ = lean_nat_abs(v_denominator_1597_);
lean_dec(v_denominator_1597_);
v___x_1626_ = lean_unsigned_to_nat(2u);
v___x_1627_ = lean_nat_mul(v___x_1626_, v_a_1625_);
lean_dec(v_a_1625_);
v___x_1628_ = lean_uint64_of_nat(v___x_1627_);
lean_dec(v___x_1627_);
v___y_1604_ = v___y_1619_;
v___y_1605_ = v___y_1622_;
v___y_1606_ = v___y_1621_;
v___y_1607_ = v___y_1620_;
v___y_1608_ = v___x_1628_;
goto v___jp_1603_;
}
else
{
lean_object* v_abs_1629_; lean_object* v_one_1630_; lean_object* v_a_1631_; lean_object* v___x_1632_; lean_object* v___x_1633_; lean_object* v___x_1634_; uint64_t v___x_1635_; 
v_abs_1629_ = lean_nat_abs(v_denominator_1597_);
lean_dec(v_denominator_1597_);
v_one_1630_ = lean_unsigned_to_nat(1u);
v_a_1631_ = lean_nat_sub(v_abs_1629_, v_one_1630_);
lean_dec(v_abs_1629_);
v___x_1632_ = lean_unsigned_to_nat(2u);
v___x_1633_ = lean_nat_mul(v___x_1632_, v_a_1631_);
lean_dec(v_a_1631_);
v___x_1634_ = lean_nat_add(v___x_1633_, v_one_1630_);
lean_dec(v___x_1633_);
v___x_1635_ = lean_uint64_of_nat(v___x_1634_);
lean_dec(v___x_1634_);
v___y_1604_ = v___y_1619_;
v___y_1605_ = v___y_1622_;
v___y_1606_ = v___y_1621_;
v___y_1607_ = v___y_1620_;
v___y_1608_ = v___x_1635_;
goto v___jp_1603_;
}
}
v___jp_1636_:
{
uint64_t v___x_1640_; lean_object* v___x_1641_; lean_object* v___x_1642_; lean_object* v___x_1643_; uint8_t v___x_1644_; 
v___x_1640_ = 7ULL;
v___x_1641_ = lean_unsigned_to_nat(0u);
v___x_1642_ = lean_array_get_size(v_values_1595_);
v___x_1643_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_1644_ = lean_nat_dec_lt(v___x_1641_, v___x_1642_);
if (v___x_1644_ == 0)
{
lean_dec_ref(v_values_1595_);
v___y_1619_ = v___y_1637_;
v___y_1620_ = v___y_1639_;
v___y_1621_ = v___y_1638_;
v___y_1622_ = v___x_1640_;
goto v___jp_1618_;
}
else
{
size_t v___x_1645_; size_t v___x_1646_; lean_object* v___x_1647_; lean_object* v___x_1648_; uint64_t v___x_1649_; 
v___x_1645_ = ((size_t)0ULL);
v___x_1646_ = lean_usize_of_nat(v___x_1642_);
v___x_1647_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_1648_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_1643_, v___f_1598_, v_values_1595_, v___x_1645_, v___x_1646_, v___x_1647_);
v___x_1649_ = lean_unbox_uint64(v___x_1648_);
lean_dec(v___x_1648_);
v___y_1619_ = v___y_1637_;
v___y_1620_ = v___y_1639_;
v___y_1621_ = v___y_1638_;
v___y_1622_ = v___x_1649_;
goto v___jp_1618_;
}
}
v___jp_1650_:
{
uint64_t v___x_1653_; lean_object* v___x_1654_; lean_object* v___x_1655_; lean_object* v___x_1656_; uint8_t v___x_1657_; 
v___x_1653_ = 7ULL;
v___x_1654_ = lean_unsigned_to_nat(0u);
v___x_1655_ = lean_array_get_size(v_counts_1594_);
v___x_1656_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_1657_ = lean_nat_dec_lt(v___x_1654_, v___x_1655_);
if (v___x_1657_ == 0)
{
lean_dec_ref(v_counts_1594_);
v___y_1637_ = v___y_1652_;
v___y_1638_ = v___y_1651_;
v___y_1639_ = v___x_1653_;
goto v___jp_1636_;
}
else
{
size_t v___x_1658_; size_t v___x_1659_; lean_object* v___x_1660_; lean_object* v___x_1661_; uint64_t v___x_1662_; 
v___x_1658_ = ((size_t)0ULL);
v___x_1659_ = lean_usize_of_nat(v___x_1655_);
v___x_1660_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_1661_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_1656_, v___f_1598_, v_counts_1594_, v___x_1658_, v___x_1659_, v___x_1660_);
v___x_1662_ = lean_unbox_uint64(v___x_1661_);
lean_dec(v___x_1661_);
v___y_1637_ = v___y_1652_;
v___y_1638_ = v___y_1651_;
v___y_1639_ = v___x_1662_;
goto v___jp_1636_;
}
}
v___jp_1663_:
{
uint64_t v___x_1665_; lean_object* v___x_1666_; lean_object* v___x_1667_; lean_object* v___x_1668_; uint8_t v___x_1669_; 
v___x_1665_ = 7ULL;
v___x_1666_ = lean_unsigned_to_nat(0u);
v___x_1667_ = lean_array_get_size(v_columns_1593_);
v___x_1668_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_1669_ = lean_nat_dec_lt(v___x_1666_, v___x_1667_);
if (v___x_1669_ == 0)
{
lean_dec_ref(v_columns_1593_);
v___y_1651_ = v___y_1664_;
v___y_1652_ = v___x_1665_;
goto v___jp_1650_;
}
else
{
size_t v___x_1670_; size_t v___x_1671_; lean_object* v___x_1672_; lean_object* v___x_1673_; uint64_t v___x_1674_; 
v___x_1670_ = ((size_t)0ULL);
v___x_1671_ = lean_usize_of_nat(v___x_1667_);
v___x_1672_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_1673_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_1668_, v___f_1599_, v_columns_1593_, v___x_1670_, v___x_1671_, v___x_1672_);
v___x_1674_ = lean_unbox_uint64(v___x_1673_);
lean_dec(v___x_1673_);
v___y_1651_ = v___y_1664_;
v___y_1652_ = v___x_1674_;
goto v___jp_1650_;
}
}
}
v___jp_1576_:
{
lean_object* v___x_1578_; lean_object* v___x_1580_; uint8_t v_isShared_1581_; uint8_t v_isSharedCheck_1585_; 
v___x_1578_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1577_);
v_isSharedCheck_1585_ = !lean_is_exclusive(v___x_1578_);
if (v_isSharedCheck_1585_ == 0)
{
lean_object* v_unused_1586_; 
v_unused_1586_ = lean_ctor_get(v___x_1578_, 0);
lean_dec(v_unused_1586_);
v___x_1580_ = v___x_1578_;
v_isShared_1581_ = v_isSharedCheck_1585_;
goto v_resetjp_1579_;
}
else
{
lean_dec(v___x_1578_);
v___x_1580_ = lean_box(0);
v_isShared_1581_ = v_isSharedCheck_1585_;
goto v_resetjp_1579_;
}
v_resetjp_1579_:
{
lean_object* v___x_1583_; 
if (v_isShared_1581_ == 0)
{
lean_ctor_set(v___x_1580_, 0, v___f_1575_);
v___x_1583_ = v___x_1580_;
goto v_reusejp_1582_;
}
else
{
lean_object* v_reuseFailAlloc_1584_; 
v_reuseFailAlloc_1584_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1584_, 0, v___f_1575_);
v___x_1583_ = v_reuseFailAlloc_1584_;
goto v_reusejp_1582_;
}
v_reusejp_1582_:
{
return v___x_1583_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked___boxed(lean_object* v_param_1686_, lean_object* v_a_1687_){
_start:
{
lean_object* v_res_1688_; 
v_res_1688_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__runChecked(v_param_1686_);
lean_dec(v_param_1686_);
return v_res_1688_;
}
}
static lean_object* _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__2(void){
_start:
{
lean_object* v___x_1705_; lean_object* v___x_1706_; double v___x_1707_; uint8_t v___x_1708_; lean_object* v___x_1709_; double v___x_1710_; double v___x_1711_; double v___x_1712_; lean_object* v___x_1713_; lean_object* v___x_1714_; lean_object* v___x_1715_; double v___x_1716_; lean_object* v___x_1717_; lean_object* v___x_1718_; 
v___x_1705_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__7));
v___x_1706_ = lean_unsigned_to_nat(6u);
v___x_1707_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__6, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__6_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__6);
v___x_1708_ = 0;
v___x_1709_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__1));
v___x_1710_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__3, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__3_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__3);
v___x_1711_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__2, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__2_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__2);
v___x_1712_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__1, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__1_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__1);
v___x_1713_ = lean_unsigned_to_nat(100u);
v___x_1714_ = lean_unsigned_to_nat(3u);
v___x_1715_ = lean_unsigned_to_nat(729u);
v___x_1716_ = lean_float_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__0);
v___x_1717_ = lean_unsigned_to_nat(100000000u);
v___x_1718_ = lean_alloc_ctor(0, 7, 41);
lean_ctor_set(v___x_1718_, 0, v___x_1717_);
lean_ctor_set(v___x_1718_, 1, v___x_1715_);
lean_ctor_set(v___x_1718_, 2, v___x_1714_);
lean_ctor_set(v___x_1718_, 3, v___x_1713_);
lean_ctor_set(v___x_1718_, 4, v___x_1709_);
lean_ctor_set(v___x_1718_, 5, v___x_1706_);
lean_ctor_set(v___x_1718_, 6, v___x_1705_);
lean_ctor_set_float(v___x_1718_, sizeof(void*)*7, v___x_1716_);
lean_ctor_set_float(v___x_1718_, sizeof(void*)*7 + 8, v___x_1712_);
lean_ctor_set_float(v___x_1718_, sizeof(void*)*7 + 16, v___x_1711_);
lean_ctor_set_float(v___x_1718_, sizeof(void*)*7 + 24, v___x_1710_);
lean_ctor_set_uint8(v___x_1718_, sizeof(void*)*7 + 40, v___x_1708_);
lean_ctor_set_float(v___x_1718_, sizeof(void*)*7 + 32, v___x_1707_);
return v___x_1718_;
}
}
static lean_object* _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config(void){
_start:
{
lean_object* v___x_1719_; 
v___x_1719_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__2, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__2_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__2);
return v___x_1719_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0___redArg(lean_object* v_s_1720_, lean_object* v_range_1721_, uint64_t v_b_1722_, lean_object* v_i_1723_){
_start:
{
lean_object* v_stop_1725_; lean_object* v_step_1726_; uint64_t v___y_1728_; uint8_t v___x_1732_; 
v_stop_1725_ = lean_ctor_get(v_range_1721_, 1);
v_step_1726_ = lean_ctor_get(v_range_1721_, 2);
v___x_1732_ = lean_nat_dec_lt(v_i_1723_, v_stop_1725_);
if (v___x_1732_ == 0)
{
lean_object* v___x_1733_; lean_object* v___x_1734_; 
lean_dec(v_i_1723_);
lean_dec(v_s_1720_);
v___x_1733_ = lean_box_uint64(v_b_1722_);
v___x_1734_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1734_, 0, v___x_1733_);
return v___x_1734_;
}
else
{
lean_object* v___x_1735_; 
lean_inc(v_s_1720_);
v___x_1735_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolveDimension(v_s_1720_);
if (lean_obj_tag(v___x_1735_) == 0)
{
uint64_t v___x_1736_; 
v___x_1736_ = 11ULL;
v___y_1728_ = v___x_1736_;
goto v___jp_1727_;
}
else
{
lean_object* v_val_1737_; uint64_t v___x_1738_; uint64_t v___x_1739_; uint64_t v___x_1740_; 
v_val_1737_ = lean_ctor_get(v___x_1735_, 0);
lean_inc(v_val_1737_);
lean_dec_ref_known(v___x_1735_, 1);
v___x_1738_ = 13ULL;
v___x_1739_ = lean_unbox_uint64(v_val_1737_);
lean_dec(v_val_1737_);
v___x_1740_ = lean_uint64_mix_hash(v___x_1739_, v___x_1738_);
v___y_1728_ = v___x_1740_;
goto v___jp_1727_;
}
}
v___jp_1727_:
{
lean_object* v___x_1729_; lean_object* v___x_1730_; 
v___x_1729_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1728_);
lean_dec_ref(v___x_1729_);
v___x_1730_ = lean_nat_add(v_i_1723_, v_step_1726_);
lean_dec(v_i_1723_);
v_b_1722_ = v___y_1728_;
v_i_1723_ = v___x_1730_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0___redArg___boxed(lean_object* v_s_1741_, lean_object* v_range_1742_, lean_object* v_b_1743_, lean_object* v_i_1744_, lean_object* v___y_1745_){
_start:
{
uint64_t v_b_boxed_1746_; lean_object* v_res_1747_; 
v_b_boxed_1746_ = lean_unbox_uint64(v_b_1743_);
lean_dec_ref(v_b_1743_);
v_res_1747_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0___redArg(v_s_1741_, v_range_1742_, v_b_boxed_1746_, v_i_1744_);
lean_dec_ref(v_range_1742_);
return v_res_1747_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_(lean_object* v_s_1748_, lean_object* v_count_1749_){
_start:
{
lean_object* v___x_1751_; uint8_t v___x_1752_; 
v___x_1751_ = lean_unsigned_to_nat(0u);
v___x_1752_ = lean_nat_dec_eq(v_count_1749_, v___x_1751_);
if (v___x_1752_ == 0)
{
uint64_t v___x_1753_; lean_object* v___x_1754_; lean_object* v___x_1755_; lean_object* v___x_1756_; lean_object* v___x_1757_; 
v___x_1753_ = 0ULL;
v___x_1754_ = lean_io_mono_nanos_now();
v___x_1755_ = lean_unsigned_to_nat(1u);
v___x_1756_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_1756_, 0, v___x_1751_);
lean_ctor_set(v___x_1756_, 1, v_count_1749_);
lean_ctor_set(v___x_1756_, 2, v___x_1755_);
v___x_1757_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0___redArg(v_s_1748_, v___x_1756_, v___x_1753_, v___x_1751_);
lean_dec_ref_known(v___x_1756_, 3);
if (lean_obj_tag(v___x_1757_) == 0)
{
lean_object* v_a_1758_; lean_object* v___x_1760_; uint8_t v_isShared_1761_; uint8_t v_isSharedCheck_1769_; 
v_a_1758_ = lean_ctor_get(v___x_1757_, 0);
v_isSharedCheck_1769_ = !lean_is_exclusive(v___x_1757_);
if (v_isSharedCheck_1769_ == 0)
{
v___x_1760_ = v___x_1757_;
v_isShared_1761_ = v_isSharedCheck_1769_;
goto v_resetjp_1759_;
}
else
{
lean_inc(v_a_1758_);
lean_dec(v___x_1757_);
v___x_1760_ = lean_box(0);
v_isShared_1761_ = v_isSharedCheck_1769_;
goto v_resetjp_1759_;
}
v_resetjp_1759_:
{
lean_object* v___x_1762_; lean_object* v___x_1763_; lean_object* v___x_1764_; lean_object* v___x_1765_; lean_object* v___x_1767_; 
v___x_1762_ = lean_io_mono_nanos_now();
v___x_1763_ = lean_nat_sub(v___x_1762_, v___x_1754_);
lean_dec(v___x_1754_);
lean_dec(v___x_1762_);
v___x_1764_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_1764_, 0, v_a_1758_);
v___x_1765_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_1765_, 0, v___x_1763_);
lean_ctor_set(v___x_1765_, 1, v___x_1764_);
if (v_isShared_1761_ == 0)
{
lean_ctor_set(v___x_1760_, 0, v___x_1765_);
v___x_1767_ = v___x_1760_;
goto v_reusejp_1766_;
}
else
{
lean_object* v_reuseFailAlloc_1768_; 
v_reuseFailAlloc_1768_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1768_, 0, v___x_1765_);
v___x_1767_ = v_reuseFailAlloc_1768_;
goto v_reusejp_1766_;
}
v_reusejp_1766_:
{
return v___x_1767_;
}
}
}
else
{
lean_object* v_a_1770_; lean_object* v___x_1772_; uint8_t v_isShared_1773_; uint8_t v_isSharedCheck_1777_; 
lean_dec(v___x_1754_);
v_a_1770_ = lean_ctor_get(v___x_1757_, 0);
v_isSharedCheck_1777_ = !lean_is_exclusive(v___x_1757_);
if (v_isSharedCheck_1777_ == 0)
{
v___x_1772_ = v___x_1757_;
v_isShared_1773_ = v_isSharedCheck_1777_;
goto v_resetjp_1771_;
}
else
{
lean_inc(v_a_1770_);
lean_dec(v___x_1757_);
v___x_1772_ = lean_box(0);
v_isShared_1773_ = v_isSharedCheck_1777_;
goto v_resetjp_1771_;
}
v_resetjp_1771_:
{
lean_object* v___x_1775_; 
if (v_isShared_1773_ == 0)
{
v___x_1775_ = v___x_1772_;
goto v_reusejp_1774_;
}
else
{
lean_object* v_reuseFailAlloc_1776_; 
v_reuseFailAlloc_1776_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1776_, 0, v_a_1770_);
v___x_1775_ = v_reuseFailAlloc_1776_;
goto v_reusejp_1774_;
}
v_reusejp_1774_:
{
return v___x_1775_;
}
}
}
}
else
{
lean_object* v___x_1778_; lean_object* v___x_1779_; 
lean_dec(v_count_1749_);
lean_dec(v_s_1748_);
v___x_1778_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___closed__0));
v___x_1779_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1779_, 0, v___x_1778_);
return v___x_1779_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33____boxed(lean_object* v_s_1780_, lean_object* v_count_1781_, lean_object* v___y_1782_){
_start:
{
lean_object* v_res_1783_; 
v_res_1783_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_(v_s_1780_, v_count_1781_);
return v_res_1783_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_(lean_object* v___y_1784_){
_start:
{
lean_object* v_s_1786_; lean_object* v___f_1787_; uint64_t v___y_1789_; 
v_s_1786_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput(v___y_1784_);
lean_inc(v_s_1786_);
v___f_1787_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33____boxed), 3, 1);
lean_closure_set(v___f_1787_, 0, v_s_1786_);
if (lean_obj_tag(v_s_1786_) == 0)
{
uint64_t v___x_1799_; 
v___x_1799_ = 11ULL;
v___y_1789_ = v___x_1799_;
goto v___jp_1788_;
}
else
{
lean_object* v_val_1800_; lean_object* v_system_1801_; lean_object* v_arity_1802_; lean_object* v_size_1803_; lean_object* v_rows_1804_; lean_object* v_columns_1805_; lean_object* v_counts_1806_; lean_object* v_values_1807_; lean_object* v_inverse_1808_; lean_object* v_denominator_1809_; uint64_t v___x_1810_; uint64_t v___x_1811_; uint64_t v___x_1812_; uint64_t v___y_1814_; uint64_t v___y_1815_; uint64_t v___y_1816_; uint64_t v___y_1817_; uint64_t v___y_1818_; uint64_t v___y_1829_; uint64_t v___y_1830_; uint64_t v___y_1831_; uint64_t v___y_1832_; uint64_t v___y_1847_; uint64_t v___y_1848_; uint64_t v___y_1849_; uint64_t v___y_1858_; uint64_t v___y_1859_; uint64_t v___y_1868_; uint64_t v___x_1876_; lean_object* v___x_1877_; lean_object* v___x_1878_; uint8_t v___x_1879_; 
v_val_1800_ = lean_ctor_get(v_s_1786_, 0);
lean_inc(v_val_1800_);
lean_dec_ref_known(v_s_1786_, 1);
v_system_1801_ = lean_ctor_get(v_val_1800_, 2);
lean_inc_ref(v_system_1801_);
v_arity_1802_ = lean_ctor_get(v_val_1800_, 0);
lean_inc(v_arity_1802_);
v_size_1803_ = lean_ctor_get(v_val_1800_, 1);
lean_inc_n(v_size_1803_, 3);
lean_dec(v_val_1800_);
v_rows_1804_ = lean_ctor_get(v_system_1801_, 0);
lean_inc_ref(v_rows_1804_);
v_columns_1805_ = lean_ctor_get(v_system_1801_, 1);
lean_inc_ref(v_columns_1805_);
v_counts_1806_ = lean_ctor_get(v_system_1801_, 2);
lean_inc_ref(v_counts_1806_);
v_values_1807_ = lean_ctor_get(v_system_1801_, 3);
lean_inc_ref(v_values_1807_);
v_inverse_1808_ = lean_ctor_get(v_system_1801_, 4);
lean_inc_ref(v_inverse_1808_);
v_denominator_1809_ = lean_ctor_get(v_system_1801_, 5);
lean_inc(v_denominator_1809_);
lean_dec_ref(v_system_1801_);
v___x_1810_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_1803_, v_size_1803_, v_inverse_1808_);
v___x_1811_ = lean_uint64_of_nat(v_arity_1802_);
lean_dec(v_arity_1802_);
v___x_1812_ = lean_uint64_of_nat(v_size_1803_);
lean_dec(v_size_1803_);
v___x_1876_ = 7ULL;
v___x_1877_ = lean_unsigned_to_nat(0u);
v___x_1878_ = lean_array_get_size(v_rows_1804_);
v___x_1879_ = lean_nat_dec_lt(v___x_1877_, v___x_1878_);
if (v___x_1879_ == 0)
{
lean_dec_ref(v_rows_1804_);
v___y_1868_ = v___x_1876_;
goto v___jp_1867_;
}
else
{
size_t v___x_1880_; size_t v___x_1881_; uint64_t v___x_1882_; 
v___x_1880_ = ((size_t)0ULL);
v___x_1881_ = lean_usize_of_nat(v___x_1878_);
v___x_1882_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(v_rows_1804_, v___x_1880_, v___x_1881_, v___x_1876_);
lean_dec_ref(v_rows_1804_);
v___y_1868_ = v___x_1882_;
goto v___jp_1867_;
}
v___jp_1813_:
{
uint64_t v___x_1819_; uint64_t v___x_1820_; uint64_t v___x_1821_; uint64_t v___x_1822_; uint64_t v___x_1823_; uint64_t v___x_1824_; uint64_t v___x_1825_; uint64_t v___x_1826_; uint64_t v___x_1827_; 
v___x_1819_ = lean_uint64_mix_hash(v___x_1810_, v___y_1818_);
v___x_1820_ = lean_uint64_mix_hash(v___y_1816_, v___x_1819_);
v___x_1821_ = lean_uint64_mix_hash(v___y_1814_, v___x_1820_);
v___x_1822_ = lean_uint64_mix_hash(v___y_1815_, v___x_1821_);
v___x_1823_ = lean_uint64_mix_hash(v___y_1817_, v___x_1822_);
v___x_1824_ = lean_uint64_mix_hash(v___x_1812_, v___x_1823_);
v___x_1825_ = lean_uint64_mix_hash(v___x_1811_, v___x_1824_);
v___x_1826_ = 13ULL;
v___x_1827_ = lean_uint64_mix_hash(v___x_1825_, v___x_1826_);
v___y_1789_ = v___x_1827_;
goto v___jp_1788_;
}
v___jp_1828_:
{
lean_object* v_intZero_1833_; uint8_t v_isNeg_1834_; 
v_intZero_1833_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_1834_ = lean_int_dec_lt(v_denominator_1809_, v_intZero_1833_);
if (v_isNeg_1834_ == 0)
{
lean_object* v_a_1835_; lean_object* v___x_1836_; lean_object* v___x_1837_; uint64_t v___x_1838_; 
v_a_1835_ = lean_nat_abs(v_denominator_1809_);
lean_dec(v_denominator_1809_);
v___x_1836_ = lean_unsigned_to_nat(2u);
v___x_1837_ = lean_nat_mul(v___x_1836_, v_a_1835_);
lean_dec(v_a_1835_);
v___x_1838_ = lean_uint64_of_nat(v___x_1837_);
lean_dec(v___x_1837_);
v___y_1814_ = v___y_1829_;
v___y_1815_ = v___y_1830_;
v___y_1816_ = v___y_1832_;
v___y_1817_ = v___y_1831_;
v___y_1818_ = v___x_1838_;
goto v___jp_1813_;
}
else
{
lean_object* v_abs_1839_; lean_object* v_one_1840_; lean_object* v_a_1841_; lean_object* v___x_1842_; lean_object* v___x_1843_; lean_object* v___x_1844_; uint64_t v___x_1845_; 
v_abs_1839_ = lean_nat_abs(v_denominator_1809_);
lean_dec(v_denominator_1809_);
v_one_1840_ = lean_unsigned_to_nat(1u);
v_a_1841_ = lean_nat_sub(v_abs_1839_, v_one_1840_);
lean_dec(v_abs_1839_);
v___x_1842_ = lean_unsigned_to_nat(2u);
v___x_1843_ = lean_nat_mul(v___x_1842_, v_a_1841_);
lean_dec(v_a_1841_);
v___x_1844_ = lean_nat_add(v___x_1843_, v_one_1840_);
lean_dec(v___x_1843_);
v___x_1845_ = lean_uint64_of_nat(v___x_1844_);
lean_dec(v___x_1844_);
v___y_1814_ = v___y_1829_;
v___y_1815_ = v___y_1830_;
v___y_1816_ = v___y_1832_;
v___y_1817_ = v___y_1831_;
v___y_1818_ = v___x_1845_;
goto v___jp_1813_;
}
}
v___jp_1846_:
{
uint64_t v___x_1850_; lean_object* v___x_1851_; lean_object* v___x_1852_; uint8_t v___x_1853_; 
v___x_1850_ = 7ULL;
v___x_1851_ = lean_unsigned_to_nat(0u);
v___x_1852_ = lean_array_get_size(v_values_1807_);
v___x_1853_ = lean_nat_dec_lt(v___x_1851_, v___x_1852_);
if (v___x_1853_ == 0)
{
lean_dec_ref(v_values_1807_);
v___y_1829_ = v___y_1849_;
v___y_1830_ = v___y_1847_;
v___y_1831_ = v___y_1848_;
v___y_1832_ = v___x_1850_;
goto v___jp_1828_;
}
else
{
size_t v___x_1854_; size_t v___x_1855_; uint64_t v___x_1856_; 
v___x_1854_ = ((size_t)0ULL);
v___x_1855_ = lean_usize_of_nat(v___x_1852_);
v___x_1856_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_values_1807_, v___x_1854_, v___x_1855_, v___x_1850_);
lean_dec_ref(v_values_1807_);
v___y_1829_ = v___y_1849_;
v___y_1830_ = v___y_1847_;
v___y_1831_ = v___y_1848_;
v___y_1832_ = v___x_1856_;
goto v___jp_1828_;
}
}
v___jp_1857_:
{
uint64_t v___x_1860_; lean_object* v___x_1861_; lean_object* v___x_1862_; uint8_t v___x_1863_; 
v___x_1860_ = 7ULL;
v___x_1861_ = lean_unsigned_to_nat(0u);
v___x_1862_ = lean_array_get_size(v_counts_1806_);
v___x_1863_ = lean_nat_dec_lt(v___x_1861_, v___x_1862_);
if (v___x_1863_ == 0)
{
lean_dec_ref(v_counts_1806_);
v___y_1847_ = v___y_1859_;
v___y_1848_ = v___y_1858_;
v___y_1849_ = v___x_1860_;
goto v___jp_1846_;
}
else
{
size_t v___x_1864_; size_t v___x_1865_; uint64_t v___x_1866_; 
v___x_1864_ = ((size_t)0ULL);
v___x_1865_ = lean_usize_of_nat(v___x_1862_);
v___x_1866_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_counts_1806_, v___x_1864_, v___x_1865_, v___x_1860_);
lean_dec_ref(v_counts_1806_);
v___y_1847_ = v___y_1859_;
v___y_1848_ = v___y_1858_;
v___y_1849_ = v___x_1866_;
goto v___jp_1846_;
}
}
v___jp_1867_:
{
uint64_t v___x_1869_; lean_object* v___x_1870_; lean_object* v___x_1871_; uint8_t v___x_1872_; 
v___x_1869_ = 7ULL;
v___x_1870_ = lean_unsigned_to_nat(0u);
v___x_1871_ = lean_array_get_size(v_columns_1805_);
v___x_1872_ = lean_nat_dec_lt(v___x_1870_, v___x_1871_);
if (v___x_1872_ == 0)
{
lean_dec_ref(v_columns_1805_);
v___y_1858_ = v___y_1868_;
v___y_1859_ = v___x_1869_;
goto v___jp_1857_;
}
else
{
size_t v___x_1873_; size_t v___x_1874_; uint64_t v___x_1875_; 
v___x_1873_ = ((size_t)0ULL);
v___x_1874_ = lean_usize_of_nat(v___x_1871_);
v___x_1875_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v_columns_1805_, v___x_1873_, v___x_1874_, v___x_1869_);
lean_dec_ref(v_columns_1805_);
v___y_1858_ = v___y_1868_;
v___y_1859_ = v___x_1875_;
goto v___jp_1857_;
}
}
}
v___jp_1788_:
{
lean_object* v___x_1790_; lean_object* v___x_1792_; uint8_t v_isShared_1793_; uint8_t v_isSharedCheck_1797_; 
v___x_1790_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1789_);
v_isSharedCheck_1797_ = !lean_is_exclusive(v___x_1790_);
if (v_isSharedCheck_1797_ == 0)
{
lean_object* v_unused_1798_; 
v_unused_1798_ = lean_ctor_get(v___x_1790_, 0);
lean_dec(v_unused_1798_);
v___x_1792_ = v___x_1790_;
v_isShared_1793_ = v_isSharedCheck_1797_;
goto v_resetjp_1791_;
}
else
{
lean_dec(v___x_1790_);
v___x_1792_ = lean_box(0);
v_isShared_1793_ = v_isSharedCheck_1797_;
goto v_resetjp_1791_;
}
v_resetjp_1791_:
{
lean_object* v___x_1795_; 
if (v_isShared_1793_ == 0)
{
lean_ctor_set(v___x_1792_, 0, v___f_1787_);
v___x_1795_ = v___x_1792_;
goto v_reusejp_1794_;
}
else
{
lean_object* v_reuseFailAlloc_1796_; 
v_reuseFailAlloc_1796_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_1796_, 0, v___f_1787_);
v___x_1795_ = v_reuseFailAlloc_1796_;
goto v_reusejp_1794_;
}
v_reusejp_1794_:
{
return v___x_1795_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33____boxed(lean_object* v___y_1883_, lean_object* v___y_1884_){
_start:
{
lean_object* v_res_1885_; 
v_res_1885_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_(v___y_1883_);
lean_dec(v___y_1883_);
return v_res_1885_;
}
}
static lean_object* _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_(void){
_start:
{
lean_object* v___x_1894_; uint8_t v___x_1895_; lean_object* v___x_1896_; lean_object* v___x_1897_; lean_object* v___x_1898_; 
v___x_1894_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config;
v___x_1895_ = 1;
v___x_1896_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_));
v___x_1897_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_));
v___x_1898_ = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(v___x_1898_, 0, v___x_1897_);
lean_ctor_set(v___x_1898_, 1, v___x_1896_);
lean_ctor_set(v___x_1898_, 2, v___x_1894_);
lean_ctor_set_uint8(v___x_1898_, sizeof(void*)*3, v___x_1895_);
return v___x_1898_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_(){
_start:
{
lean_object* v___f_1901_; lean_object* v___x_1902_; lean_object* v___x_1903_; lean_object* v___x_1904_; 
v___f_1901_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_));
v___x_1902_ = lean_obj_once(&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_, &lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__once, _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_);
v___x_1903_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__5_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_));
v___x_1904_ = lp_lean_x2dbench_LeanBench_register(v___x_1902_, v___f_1901_, v___x_1903_);
return v___x_1904_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33____boxed(lean_object* v_a_1905_){
_start:
{
lean_object* v_res_1906_; 
v_res_1906_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_();
return v_res_1906_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0(lean_object* v_s_1907_, lean_object* v_range_1908_, uint64_t v_b_1909_, lean_object* v_i_1910_, lean_object* v_hs_1911_, lean_object* v_hl_1912_){
_start:
{
lean_object* v___x_1914_; 
v___x_1914_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0___redArg(v_s_1907_, v_range_1908_, v_b_1909_, v_i_1910_);
return v___x_1914_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0___boxed(lean_object* v_s_1915_, lean_object* v_range_1916_, lean_object* v_b_1917_, lean_object* v_i_1918_, lean_object* v_hs_1919_, lean_object* v_hl_1920_, lean_object* v___y_1921_){
_start:
{
uint64_t v_b_boxed_1922_; lean_object* v_res_1923_; 
v_b_boxed_1922_ = lean_unbox_uint64(v_b_1917_);
lean_dec_ref(v_b_1917_);
v_res_1923_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33__spec__0(v_s_1915_, v_range_1916_, v_b_boxed_1922_, v_i_1918_, v_hs_1919_, v_hl_1920_);
lean_dec_ref(v_range_1916_);
return v_res_1923_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_(lean_object* v_s_1924_, lean_object* v_x_1925_){
_start:
{
lean_object* v___x_1927_; lean_object* v___x_1928_; 
v___x_1927_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolveDimension(v_s_1924_);
v___x_1928_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_1928_, 0, v___x_1927_);
return v___x_1928_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37____boxed(lean_object* v_s_1929_, lean_object* v_x_1930_, lean_object* v___y_1931_){
_start:
{
lean_object* v_res_1932_; 
v_res_1932_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_(v_s_1929_, v_x_1930_);
return v_res_1932_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_(lean_object* v___f_1933_, lean_object* v_param_1934_){
_start:
{
lean_object* v_s_1936_; lean_object* v___f_1937_; uint64_t v___y_1939_; 
v_s_1936_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput(v_param_1934_);
lean_inc(v_s_1936_);
v___f_1937_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37____boxed), 3, 1);
lean_closure_set(v___f_1937_, 0, v_s_1936_);
if (lean_obj_tag(v_s_1936_) == 0)
{
uint64_t v___x_1944_; 
v___x_1944_ = 11ULL;
v___y_1939_ = v___x_1944_;
goto v___jp_1938_;
}
else
{
lean_object* v_val_1945_; lean_object* v_system_1946_; lean_object* v_arity_1947_; lean_object* v_size_1948_; lean_object* v_rows_1949_; lean_object* v_columns_1950_; lean_object* v_counts_1951_; lean_object* v_values_1952_; lean_object* v_inverse_1953_; lean_object* v_denominator_1954_; uint64_t v___x_1955_; uint64_t v___x_1956_; uint64_t v___x_1957_; uint64_t v___y_1959_; uint64_t v___y_1960_; uint64_t v___y_1961_; uint64_t v___y_1962_; uint64_t v___y_1963_; uint64_t v___y_1974_; uint64_t v___y_1975_; uint64_t v___y_1976_; uint64_t v___y_1977_; uint64_t v___y_1992_; uint64_t v___y_1993_; uint64_t v___y_1994_; uint64_t v___y_2003_; uint64_t v___y_2004_; uint64_t v___y_2013_; uint64_t v___x_2021_; lean_object* v___x_2022_; lean_object* v___x_2023_; uint8_t v___x_2024_; 
v_val_1945_ = lean_ctor_get(v_s_1936_, 0);
lean_inc(v_val_1945_);
lean_dec_ref_known(v_s_1936_, 1);
v_system_1946_ = lean_ctor_get(v_val_1945_, 2);
lean_inc_ref(v_system_1946_);
v_arity_1947_ = lean_ctor_get(v_val_1945_, 0);
lean_inc(v_arity_1947_);
v_size_1948_ = lean_ctor_get(v_val_1945_, 1);
lean_inc_n(v_size_1948_, 3);
lean_dec(v_val_1945_);
v_rows_1949_ = lean_ctor_get(v_system_1946_, 0);
lean_inc_ref(v_rows_1949_);
v_columns_1950_ = lean_ctor_get(v_system_1946_, 1);
lean_inc_ref(v_columns_1950_);
v_counts_1951_ = lean_ctor_get(v_system_1946_, 2);
lean_inc_ref(v_counts_1951_);
v_values_1952_ = lean_ctor_get(v_system_1946_, 3);
lean_inc_ref(v_values_1952_);
v_inverse_1953_ = lean_ctor_get(v_system_1946_, 4);
lean_inc_ref(v_inverse_1953_);
v_denominator_1954_ = lean_ctor_get(v_system_1946_, 5);
lean_inc(v_denominator_1954_);
lean_dec_ref(v_system_1946_);
v___x_1955_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_1948_, v_size_1948_, v_inverse_1953_);
v___x_1956_ = lean_uint64_of_nat(v_arity_1947_);
lean_dec(v_arity_1947_);
v___x_1957_ = lean_uint64_of_nat(v_size_1948_);
lean_dec(v_size_1948_);
v___x_2021_ = 7ULL;
v___x_2022_ = lean_unsigned_to_nat(0u);
v___x_2023_ = lean_array_get_size(v_rows_1949_);
v___x_2024_ = lean_nat_dec_lt(v___x_2022_, v___x_2023_);
if (v___x_2024_ == 0)
{
lean_dec_ref(v_rows_1949_);
v___y_2013_ = v___x_2021_;
goto v___jp_2012_;
}
else
{
size_t v___x_2025_; size_t v___x_2026_; uint64_t v___x_2027_; 
v___x_2025_ = ((size_t)0ULL);
v___x_2026_ = lean_usize_of_nat(v___x_2023_);
v___x_2027_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(v_rows_1949_, v___x_2025_, v___x_2026_, v___x_2021_);
lean_dec_ref(v_rows_1949_);
v___y_2013_ = v___x_2027_;
goto v___jp_2012_;
}
v___jp_1958_:
{
uint64_t v___x_1964_; uint64_t v___x_1965_; uint64_t v___x_1966_; uint64_t v___x_1967_; uint64_t v___x_1968_; uint64_t v___x_1969_; uint64_t v___x_1970_; uint64_t v___x_1971_; uint64_t v___x_1972_; 
v___x_1964_ = lean_uint64_mix_hash(v___x_1955_, v___y_1963_);
v___x_1965_ = lean_uint64_mix_hash(v___y_1959_, v___x_1964_);
v___x_1966_ = lean_uint64_mix_hash(v___y_1960_, v___x_1965_);
v___x_1967_ = lean_uint64_mix_hash(v___y_1962_, v___x_1966_);
v___x_1968_ = lean_uint64_mix_hash(v___y_1961_, v___x_1967_);
v___x_1969_ = lean_uint64_mix_hash(v___x_1957_, v___x_1968_);
v___x_1970_ = lean_uint64_mix_hash(v___x_1956_, v___x_1969_);
v___x_1971_ = 13ULL;
v___x_1972_ = lean_uint64_mix_hash(v___x_1970_, v___x_1971_);
v___y_1939_ = v___x_1972_;
goto v___jp_1938_;
}
v___jp_1973_:
{
lean_object* v_intZero_1978_; uint8_t v_isNeg_1979_; 
v_intZero_1978_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_1979_ = lean_int_dec_lt(v_denominator_1954_, v_intZero_1978_);
if (v_isNeg_1979_ == 0)
{
lean_object* v_a_1980_; lean_object* v___x_1981_; lean_object* v___x_1982_; uint64_t v___x_1983_; 
v_a_1980_ = lean_nat_abs(v_denominator_1954_);
lean_dec(v_denominator_1954_);
v___x_1981_ = lean_unsigned_to_nat(2u);
v___x_1982_ = lean_nat_mul(v___x_1981_, v_a_1980_);
lean_dec(v_a_1980_);
v___x_1983_ = lean_uint64_of_nat(v___x_1982_);
lean_dec(v___x_1982_);
v___y_1959_ = v___y_1977_;
v___y_1960_ = v___y_1974_;
v___y_1961_ = v___y_1976_;
v___y_1962_ = v___y_1975_;
v___y_1963_ = v___x_1983_;
goto v___jp_1958_;
}
else
{
lean_object* v_abs_1984_; lean_object* v_one_1985_; lean_object* v_a_1986_; lean_object* v___x_1987_; lean_object* v___x_1988_; lean_object* v___x_1989_; uint64_t v___x_1990_; 
v_abs_1984_ = lean_nat_abs(v_denominator_1954_);
lean_dec(v_denominator_1954_);
v_one_1985_ = lean_unsigned_to_nat(1u);
v_a_1986_ = lean_nat_sub(v_abs_1984_, v_one_1985_);
lean_dec(v_abs_1984_);
v___x_1987_ = lean_unsigned_to_nat(2u);
v___x_1988_ = lean_nat_mul(v___x_1987_, v_a_1986_);
lean_dec(v_a_1986_);
v___x_1989_ = lean_nat_add(v___x_1988_, v_one_1985_);
lean_dec(v___x_1988_);
v___x_1990_ = lean_uint64_of_nat(v___x_1989_);
lean_dec(v___x_1989_);
v___y_1959_ = v___y_1977_;
v___y_1960_ = v___y_1974_;
v___y_1961_ = v___y_1976_;
v___y_1962_ = v___y_1975_;
v___y_1963_ = v___x_1990_;
goto v___jp_1958_;
}
}
v___jp_1991_:
{
uint64_t v___x_1995_; lean_object* v___x_1996_; lean_object* v___x_1997_; uint8_t v___x_1998_; 
v___x_1995_ = 7ULL;
v___x_1996_ = lean_unsigned_to_nat(0u);
v___x_1997_ = lean_array_get_size(v_values_1952_);
v___x_1998_ = lean_nat_dec_lt(v___x_1996_, v___x_1997_);
if (v___x_1998_ == 0)
{
lean_dec_ref(v_values_1952_);
v___y_1974_ = v___y_1994_;
v___y_1975_ = v___y_1993_;
v___y_1976_ = v___y_1992_;
v___y_1977_ = v___x_1995_;
goto v___jp_1973_;
}
else
{
size_t v___x_1999_; size_t v___x_2000_; uint64_t v___x_2001_; 
v___x_1999_ = ((size_t)0ULL);
v___x_2000_ = lean_usize_of_nat(v___x_1997_);
v___x_2001_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_values_1952_, v___x_1999_, v___x_2000_, v___x_1995_);
lean_dec_ref(v_values_1952_);
v___y_1974_ = v___y_1994_;
v___y_1975_ = v___y_1993_;
v___y_1976_ = v___y_1992_;
v___y_1977_ = v___x_2001_;
goto v___jp_1973_;
}
}
v___jp_2002_:
{
uint64_t v___x_2005_; lean_object* v___x_2006_; lean_object* v___x_2007_; uint8_t v___x_2008_; 
v___x_2005_ = 7ULL;
v___x_2006_ = lean_unsigned_to_nat(0u);
v___x_2007_ = lean_array_get_size(v_counts_1951_);
v___x_2008_ = lean_nat_dec_lt(v___x_2006_, v___x_2007_);
if (v___x_2008_ == 0)
{
lean_dec_ref(v_counts_1951_);
v___y_1992_ = v___y_2003_;
v___y_1993_ = v___y_2004_;
v___y_1994_ = v___x_2005_;
goto v___jp_1991_;
}
else
{
size_t v___x_2009_; size_t v___x_2010_; uint64_t v___x_2011_; 
v___x_2009_ = ((size_t)0ULL);
v___x_2010_ = lean_usize_of_nat(v___x_2007_);
v___x_2011_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_counts_1951_, v___x_2009_, v___x_2010_, v___x_2005_);
lean_dec_ref(v_counts_1951_);
v___y_1992_ = v___y_2003_;
v___y_1993_ = v___y_2004_;
v___y_1994_ = v___x_2011_;
goto v___jp_1991_;
}
}
v___jp_2012_:
{
uint64_t v___x_2014_; lean_object* v___x_2015_; lean_object* v___x_2016_; uint8_t v___x_2017_; 
v___x_2014_ = 7ULL;
v___x_2015_ = lean_unsigned_to_nat(0u);
v___x_2016_ = lean_array_get_size(v_columns_1950_);
v___x_2017_ = lean_nat_dec_lt(v___x_2015_, v___x_2016_);
if (v___x_2017_ == 0)
{
lean_dec_ref(v_columns_1950_);
v___y_2003_ = v___y_2013_;
v___y_2004_ = v___x_2014_;
goto v___jp_2002_;
}
else
{
size_t v___x_2018_; size_t v___x_2019_; uint64_t v___x_2020_; 
v___x_2018_ = ((size_t)0ULL);
v___x_2019_ = lean_usize_of_nat(v___x_2016_);
v___x_2020_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v_columns_1950_, v___x_2018_, v___x_2019_, v___x_2014_);
lean_dec_ref(v_columns_1950_);
v___y_2003_ = v___y_2013_;
v___y_2004_ = v___x_2020_;
goto v___jp_2002_;
}
}
}
v___jp_1938_:
{
lean_object* v___x_1940_; uint8_t v___x_1941_; uint8_t v___x_1942_; lean_object* v___x_1943_; 
v___x_1940_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_1939_);
lean_dec_ref(v___x_1940_);
v___x_1941_ = 1;
v___x_1942_ = 0;
v___x_1943_ = lp_lean_x2dbench_LeanBench_kernelLoop___redArg(v___f_1937_, v___f_1933_, v___x_1941_, v___x_1942_);
return v___x_1943_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37____boxed(lean_object* v___f_2028_, lean_object* v_param_2029_, lean_object* v___y_2030_){
_start:
{
lean_object* v_res_2031_; 
v_res_2031_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_(v___f_2028_, v_param_2029_);
lean_dec(v_param_2029_);
return v_res_2031_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_(){
_start:
{
lean_object* v___f_2035_; lean_object* v___x_2036_; lean_object* v___x_2037_; 
v___f_2035_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_));
v___x_2036_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_));
v___x_2037_ = lp_lean_x2dbench_LeanBench_registerKernel(v___x_2036_, v___f_2035_);
return v___x_2037_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37____boxed(lean_object* v_a_2038_){
_start:
{
lean_object* v_res_2039_; 
v_res_2039_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_();
return v_res_2039_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__complexity(lean_object* v_r_2040_){
_start:
{
lean_object* v___x_2041_; lean_object* v___x_2042_; 
v___x_2041_ = lean_unsigned_to_nat(3u);
v___x_2042_ = lean_nat_pow(v_r_2040_, v___x_2041_);
return v___x_2042_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__complexity___boxed(lean_object* v_r_2043_){
_start:
{
lean_object* v_res_2044_; 
v_res_2044_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__complexity(v_r_2043_);
lean_dec(v_r_2043_);
return v_res_2044_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked___lam__0(lean_object* v_s_2045_, lean_object* v_a_2046_, lean_object* v_x_2047_, uint64_t v___y_2048_){
_start:
{
uint64_t v___y_2051_; uint8_t v___x_2063_; 
v___x_2063_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheckDimension(v_s_2045_);
if (v___x_2063_ == 0)
{
uint64_t v___x_2064_; 
v___x_2064_ = 13ULL;
v___y_2051_ = v___x_2064_;
goto v___jp_2050_;
}
else
{
uint64_t v___x_2065_; 
v___x_2065_ = 11ULL;
v___y_2051_ = v___x_2065_;
goto v___jp_2050_;
}
v___jp_2050_:
{
lean_object* v___x_2052_; lean_object* v___x_2054_; uint8_t v_isShared_2055_; uint8_t v_isSharedCheck_2061_; 
v___x_2052_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_2051_);
v_isSharedCheck_2061_ = !lean_is_exclusive(v___x_2052_);
if (v_isSharedCheck_2061_ == 0)
{
lean_object* v_unused_2062_; 
v_unused_2062_ = lean_ctor_get(v___x_2052_, 0);
lean_dec(v_unused_2062_);
v___x_2054_ = v___x_2052_;
v_isShared_2055_ = v_isSharedCheck_2061_;
goto v_resetjp_2053_;
}
else
{
lean_dec(v___x_2052_);
v___x_2054_ = lean_box(0);
v_isShared_2055_ = v_isSharedCheck_2061_;
goto v_resetjp_2053_;
}
v_resetjp_2053_:
{
lean_object* v___x_2056_; lean_object* v___x_2057_; lean_object* v___x_2059_; 
v___x_2056_ = lean_box_uint64(v___y_2051_);
v___x_2057_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2057_, 0, v___x_2056_);
if (v_isShared_2055_ == 0)
{
lean_ctor_set(v___x_2054_, 0, v___x_2057_);
v___x_2059_ = v___x_2054_;
goto v_reusejp_2058_;
}
else
{
lean_object* v_reuseFailAlloc_2060_; 
v_reuseFailAlloc_2060_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2060_, 0, v___x_2057_);
v___x_2059_ = v_reuseFailAlloc_2060_;
goto v_reusejp_2058_;
}
v_reusejp_2058_:
{
return v___x_2059_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked___lam__0___boxed(lean_object* v_s_2066_, lean_object* v_a_2067_, lean_object* v_x_2068_, lean_object* v___y_2069_, lean_object* v___y_2070_){
_start:
{
uint64_t v___y_795__boxed_2071_; lean_object* v_res_2072_; 
v___y_795__boxed_2071_ = lean_unbox_uint64(v___y_2069_);
lean_dec_ref(v___y_2069_);
v_res_2072_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked___lam__0(v_s_2066_, v_a_2067_, v_x_2068_, v___y_795__boxed_2071_);
lean_dec(v_a_2067_);
return v_res_2072_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked(lean_object* v_param_2073_){
_start:
{
lean_object* v___x_2075_; lean_object* v_s_2076_; lean_object* v___f_2077_; lean_object* v___f_2078_; uint64_t v___y_2080_; 
v___x_2075_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___closed__0);
v_s_2076_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput(v_param_2073_);
lean_inc(v_s_2076_);
v___f_2077_ = lean_alloc_closure((void*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked___lam__0___boxed), 5, 1);
lean_closure_set(v___f_2077_, 0, v_s_2076_);
v___f_2078_ = lean_alloc_closure((void*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___boxed), 4, 2);
lean_closure_set(v___f_2078_, 0, v___x_2075_);
lean_closure_set(v___f_2078_, 1, v___f_2077_);
if (lean_obj_tag(v_s_2076_) == 0)
{
uint64_t v___x_2090_; 
v___x_2090_ = 11ULL;
v___y_2080_ = v___x_2090_;
goto v___jp_2079_;
}
else
{
lean_object* v_val_2091_; lean_object* v_system_2092_; lean_object* v_arity_2093_; lean_object* v_size_2094_; lean_object* v_rows_2095_; lean_object* v_columns_2096_; lean_object* v_counts_2097_; lean_object* v_values_2098_; lean_object* v_inverse_2099_; lean_object* v_denominator_2100_; lean_object* v___f_2101_; lean_object* v___f_2102_; uint64_t v___x_2103_; uint64_t v___x_2104_; uint64_t v___x_2105_; uint64_t v___y_2107_; uint64_t v___y_2108_; uint64_t v___y_2109_; uint64_t v___y_2110_; uint64_t v___y_2111_; uint64_t v___y_2122_; uint64_t v___y_2123_; uint64_t v___y_2124_; uint64_t v___y_2125_; uint64_t v___y_2140_; uint64_t v___y_2141_; uint64_t v___y_2142_; uint64_t v___y_2154_; uint64_t v___y_2155_; uint64_t v___y_2167_; uint64_t v___x_2178_; lean_object* v___x_2179_; lean_object* v___x_2180_; lean_object* v___x_2181_; uint8_t v___x_2182_; 
v_val_2091_ = lean_ctor_get(v_s_2076_, 0);
lean_inc(v_val_2091_);
lean_dec_ref_known(v_s_2076_, 1);
v_system_2092_ = lean_ctor_get(v_val_2091_, 2);
lean_inc_ref(v_system_2092_);
v_arity_2093_ = lean_ctor_get(v_val_2091_, 0);
lean_inc(v_arity_2093_);
v_size_2094_ = lean_ctor_get(v_val_2091_, 1);
lean_inc_n(v_size_2094_, 3);
lean_dec(v_val_2091_);
v_rows_2095_ = lean_ctor_get(v_system_2092_, 0);
lean_inc_ref(v_rows_2095_);
v_columns_2096_ = lean_ctor_get(v_system_2092_, 1);
lean_inc_ref(v_columns_2096_);
v_counts_2097_ = lean_ctor_get(v_system_2092_, 2);
lean_inc_ref(v_counts_2097_);
v_values_2098_ = lean_ctor_get(v_system_2092_, 3);
lean_inc_ref(v_values_2098_);
v_inverse_2099_ = lean_ctor_get(v_system_2092_, 4);
lean_inc_ref(v_inverse_2099_);
v_denominator_2100_ = lean_ctor_get(v_system_2092_, 5);
lean_inc(v_denominator_2100_);
lean_dec_ref(v_system_2092_);
v___f_2101_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__2));
v___f_2102_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__4));
v___x_2103_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_2094_, v_size_2094_, v_inverse_2099_);
v___x_2104_ = lean_uint64_of_nat(v_arity_2093_);
lean_dec(v_arity_2093_);
v___x_2105_ = lean_uint64_of_nat(v_size_2094_);
lean_dec(v_size_2094_);
v___x_2178_ = 7ULL;
v___x_2179_ = lean_unsigned_to_nat(0u);
v___x_2180_ = lean_array_get_size(v_rows_2095_);
v___x_2181_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_2182_ = lean_nat_dec_lt(v___x_2179_, v___x_2180_);
if (v___x_2182_ == 0)
{
lean_dec_ref(v_rows_2095_);
v___y_2167_ = v___x_2178_;
goto v___jp_2166_;
}
else
{
lean_object* v___f_2183_; size_t v___x_2184_; size_t v___x_2185_; lean_object* v___x_2186_; lean_object* v___x_2187_; uint64_t v___x_2188_; 
v___f_2183_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___closed__1));
v___x_2184_ = ((size_t)0ULL);
v___x_2185_ = lean_usize_of_nat(v___x_2180_);
v___x_2186_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_2187_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_2181_, v___f_2183_, v_rows_2095_, v___x_2184_, v___x_2185_, v___x_2186_);
v___x_2188_ = lean_unbox_uint64(v___x_2187_);
lean_dec(v___x_2187_);
v___y_2167_ = v___x_2188_;
goto v___jp_2166_;
}
v___jp_2106_:
{
uint64_t v___x_2112_; uint64_t v___x_2113_; uint64_t v___x_2114_; uint64_t v___x_2115_; uint64_t v___x_2116_; uint64_t v___x_2117_; uint64_t v___x_2118_; uint64_t v___x_2119_; uint64_t v___x_2120_; 
v___x_2112_ = lean_uint64_mix_hash(v___x_2103_, v___y_2111_);
v___x_2113_ = lean_uint64_mix_hash(v___y_2107_, v___x_2112_);
v___x_2114_ = lean_uint64_mix_hash(v___y_2110_, v___x_2113_);
v___x_2115_ = lean_uint64_mix_hash(v___y_2109_, v___x_2114_);
v___x_2116_ = lean_uint64_mix_hash(v___y_2108_, v___x_2115_);
v___x_2117_ = lean_uint64_mix_hash(v___x_2105_, v___x_2116_);
v___x_2118_ = lean_uint64_mix_hash(v___x_2104_, v___x_2117_);
v___x_2119_ = 13ULL;
v___x_2120_ = lean_uint64_mix_hash(v___x_2118_, v___x_2119_);
v___y_2080_ = v___x_2120_;
goto v___jp_2079_;
}
v___jp_2121_:
{
lean_object* v_intZero_2126_; uint8_t v_isNeg_2127_; 
v_intZero_2126_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_2127_ = lean_int_dec_lt(v_denominator_2100_, v_intZero_2126_);
if (v_isNeg_2127_ == 0)
{
lean_object* v_a_2128_; lean_object* v___x_2129_; lean_object* v___x_2130_; uint64_t v___x_2131_; 
v_a_2128_ = lean_nat_abs(v_denominator_2100_);
lean_dec(v_denominator_2100_);
v___x_2129_ = lean_unsigned_to_nat(2u);
v___x_2130_ = lean_nat_mul(v___x_2129_, v_a_2128_);
lean_dec(v_a_2128_);
v___x_2131_ = lean_uint64_of_nat(v___x_2130_);
lean_dec(v___x_2130_);
v___y_2107_ = v___y_2125_;
v___y_2108_ = v___y_2122_;
v___y_2109_ = v___y_2123_;
v___y_2110_ = v___y_2124_;
v___y_2111_ = v___x_2131_;
goto v___jp_2106_;
}
else
{
lean_object* v_abs_2132_; lean_object* v_one_2133_; lean_object* v_a_2134_; lean_object* v___x_2135_; lean_object* v___x_2136_; lean_object* v___x_2137_; uint64_t v___x_2138_; 
v_abs_2132_ = lean_nat_abs(v_denominator_2100_);
lean_dec(v_denominator_2100_);
v_one_2133_ = lean_unsigned_to_nat(1u);
v_a_2134_ = lean_nat_sub(v_abs_2132_, v_one_2133_);
lean_dec(v_abs_2132_);
v___x_2135_ = lean_unsigned_to_nat(2u);
v___x_2136_ = lean_nat_mul(v___x_2135_, v_a_2134_);
lean_dec(v_a_2134_);
v___x_2137_ = lean_nat_add(v___x_2136_, v_one_2133_);
lean_dec(v___x_2136_);
v___x_2138_ = lean_uint64_of_nat(v___x_2137_);
lean_dec(v___x_2137_);
v___y_2107_ = v___y_2125_;
v___y_2108_ = v___y_2122_;
v___y_2109_ = v___y_2123_;
v___y_2110_ = v___y_2124_;
v___y_2111_ = v___x_2138_;
goto v___jp_2106_;
}
}
v___jp_2139_:
{
uint64_t v___x_2143_; lean_object* v___x_2144_; lean_object* v___x_2145_; lean_object* v___x_2146_; uint8_t v___x_2147_; 
v___x_2143_ = 7ULL;
v___x_2144_ = lean_unsigned_to_nat(0u);
v___x_2145_ = lean_array_get_size(v_values_2098_);
v___x_2146_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_2147_ = lean_nat_dec_lt(v___x_2144_, v___x_2145_);
if (v___x_2147_ == 0)
{
lean_dec_ref(v_values_2098_);
v___y_2122_ = v___y_2140_;
v___y_2123_ = v___y_2141_;
v___y_2124_ = v___y_2142_;
v___y_2125_ = v___x_2143_;
goto v___jp_2121_;
}
else
{
size_t v___x_2148_; size_t v___x_2149_; lean_object* v___x_2150_; lean_object* v___x_2151_; uint64_t v___x_2152_; 
v___x_2148_ = ((size_t)0ULL);
v___x_2149_ = lean_usize_of_nat(v___x_2145_);
v___x_2150_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_2151_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_2146_, v___f_2101_, v_values_2098_, v___x_2148_, v___x_2149_, v___x_2150_);
v___x_2152_ = lean_unbox_uint64(v___x_2151_);
lean_dec(v___x_2151_);
v___y_2122_ = v___y_2140_;
v___y_2123_ = v___y_2141_;
v___y_2124_ = v___y_2142_;
v___y_2125_ = v___x_2152_;
goto v___jp_2121_;
}
}
v___jp_2153_:
{
uint64_t v___x_2156_; lean_object* v___x_2157_; lean_object* v___x_2158_; lean_object* v___x_2159_; uint8_t v___x_2160_; 
v___x_2156_ = 7ULL;
v___x_2157_ = lean_unsigned_to_nat(0u);
v___x_2158_ = lean_array_get_size(v_counts_2097_);
v___x_2159_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_2160_ = lean_nat_dec_lt(v___x_2157_, v___x_2158_);
if (v___x_2160_ == 0)
{
lean_dec_ref(v_counts_2097_);
v___y_2140_ = v___y_2154_;
v___y_2141_ = v___y_2155_;
v___y_2142_ = v___x_2156_;
goto v___jp_2139_;
}
else
{
size_t v___x_2161_; size_t v___x_2162_; lean_object* v___x_2163_; lean_object* v___x_2164_; uint64_t v___x_2165_; 
v___x_2161_ = ((size_t)0ULL);
v___x_2162_ = lean_usize_of_nat(v___x_2158_);
v___x_2163_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_2164_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_2159_, v___f_2101_, v_counts_2097_, v___x_2161_, v___x_2162_, v___x_2163_);
v___x_2165_ = lean_unbox_uint64(v___x_2164_);
lean_dec(v___x_2164_);
v___y_2140_ = v___y_2154_;
v___y_2141_ = v___y_2155_;
v___y_2142_ = v___x_2165_;
goto v___jp_2139_;
}
}
v___jp_2166_:
{
uint64_t v___x_2168_; lean_object* v___x_2169_; lean_object* v___x_2170_; lean_object* v___x_2171_; uint8_t v___x_2172_; 
v___x_2168_ = 7ULL;
v___x_2169_ = lean_unsigned_to_nat(0u);
v___x_2170_ = lean_array_get_size(v_columns_2096_);
v___x_2171_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__5___closed__9));
v___x_2172_ = lean_nat_dec_lt(v___x_2169_, v___x_2170_);
if (v___x_2172_ == 0)
{
lean_dec_ref(v_columns_2096_);
v___y_2154_ = v___y_2167_;
v___y_2155_ = v___x_2168_;
goto v___jp_2153_;
}
else
{
size_t v___x_2173_; size_t v___x_2174_; lean_object* v___x_2175_; lean_object* v___x_2176_; uint64_t v___x_2177_; 
v___x_2173_ = ((size_t)0ULL);
v___x_2174_ = lean_usize_of_nat(v___x_2170_);
v___x_2175_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__1___boxed__const__1));
v___x_2176_ = l___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___redArg(v___x_2171_, v___f_2102_, v_columns_2096_, v___x_2173_, v___x_2174_, v___x_2175_);
v___x_2177_ = lean_unbox_uint64(v___x_2176_);
lean_dec(v___x_2176_);
v___y_2154_ = v___y_2167_;
v___y_2155_ = v___x_2177_;
goto v___jp_2153_;
}
}
}
v___jp_2079_:
{
lean_object* v___x_2081_; lean_object* v___x_2083_; uint8_t v_isShared_2084_; uint8_t v_isSharedCheck_2088_; 
v___x_2081_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_2080_);
v_isSharedCheck_2088_ = !lean_is_exclusive(v___x_2081_);
if (v_isSharedCheck_2088_ == 0)
{
lean_object* v_unused_2089_; 
v_unused_2089_ = lean_ctor_get(v___x_2081_, 0);
lean_dec(v_unused_2089_);
v___x_2083_ = v___x_2081_;
v_isShared_2084_ = v_isSharedCheck_2088_;
goto v_resetjp_2082_;
}
else
{
lean_dec(v___x_2081_);
v___x_2083_ = lean_box(0);
v_isShared_2084_ = v_isSharedCheck_2088_;
goto v_resetjp_2082_;
}
v_resetjp_2082_:
{
lean_object* v___x_2086_; 
if (v_isShared_2084_ == 0)
{
lean_ctor_set(v___x_2083_, 0, v___f_2078_);
v___x_2086_ = v___x_2083_;
goto v_reusejp_2085_;
}
else
{
lean_object* v_reuseFailAlloc_2087_; 
v_reuseFailAlloc_2087_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2087_, 0, v___f_2078_);
v___x_2086_ = v_reuseFailAlloc_2087_;
goto v_reusejp_2085_;
}
v_reusejp_2085_:
{
return v___x_2086_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked___boxed(lean_object* v_param_2189_, lean_object* v_a_2190_){
_start:
{
lean_object* v_res_2191_; 
v_res_2191_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__runChecked(v_param_2189_);
lean_dec(v_param_2189_);
return v_res_2191_;
}
}
static lean_object* _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__config(void){
_start:
{
lean_object* v___x_2192_; lean_object* v___x_2193_; lean_object* v___x_2194_; 
v___x_2192_ = lean_unsigned_to_nat(6u);
v___x_2193_ = lean_mk_empty_array_with_capacity(v___x_2192_);
lean_dec_ref(v___x_2193_);
v___x_2194_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__2, &lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__2_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config___closed__2);
return v___x_2194_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0___redArg(lean_object* v_s_2195_, lean_object* v_range_2196_, uint64_t v_b_2197_, lean_object* v_i_2198_){
_start:
{
lean_object* v_stop_2200_; lean_object* v_step_2201_; uint64_t v___y_2203_; uint8_t v___x_2207_; 
v_stop_2200_ = lean_ctor_get(v_range_2196_, 1);
v_step_2201_ = lean_ctor_get(v_range_2196_, 2);
v___x_2207_ = lean_nat_dec_lt(v_i_2198_, v_stop_2200_);
if (v___x_2207_ == 0)
{
lean_object* v___x_2208_; lean_object* v___x_2209_; 
lean_dec(v_i_2198_);
lean_dec(v_s_2195_);
v___x_2208_ = lean_box_uint64(v_b_2197_);
v___x_2209_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2209_, 0, v___x_2208_);
return v___x_2209_;
}
else
{
uint8_t v___x_2210_; 
lean_inc(v_s_2195_);
v___x_2210_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheckDimension(v_s_2195_);
if (v___x_2210_ == 0)
{
uint64_t v___x_2211_; 
v___x_2211_ = 13ULL;
v___y_2203_ = v___x_2211_;
goto v___jp_2202_;
}
else
{
uint64_t v___x_2212_; 
v___x_2212_ = 11ULL;
v___y_2203_ = v___x_2212_;
goto v___jp_2202_;
}
}
v___jp_2202_:
{
lean_object* v___x_2204_; lean_object* v___x_2205_; 
v___x_2204_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_2203_);
lean_dec_ref(v___x_2204_);
v___x_2205_ = lean_nat_add(v_i_2198_, v_step_2201_);
lean_dec(v_i_2198_);
v_b_2197_ = v___y_2203_;
v_i_2198_ = v___x_2205_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0___redArg___boxed(lean_object* v_s_2213_, lean_object* v_range_2214_, lean_object* v_b_2215_, lean_object* v_i_2216_, lean_object* v___y_2217_){
_start:
{
uint64_t v_b_boxed_2218_; lean_object* v_res_2219_; 
v_b_boxed_2218_ = lean_unbox_uint64(v_b_2215_);
lean_dec_ref(v_b_2215_);
v_res_2219_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0___redArg(v_s_2213_, v_range_2214_, v_b_boxed_2218_, v_i_2216_);
lean_dec_ref(v_range_2214_);
return v_res_2219_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_(lean_object* v_s_2220_, lean_object* v_count_2221_){
_start:
{
lean_object* v___x_2223_; uint8_t v___x_2224_; 
v___x_2223_ = lean_unsigned_to_nat(0u);
v___x_2224_ = lean_nat_dec_eq(v_count_2221_, v___x_2223_);
if (v___x_2224_ == 0)
{
uint64_t v___x_2225_; lean_object* v___x_2226_; lean_object* v___x_2227_; lean_object* v___x_2228_; lean_object* v___x_2229_; 
v___x_2225_ = 0ULL;
v___x_2226_ = lean_io_mono_nanos_now();
v___x_2227_ = lean_unsigned_to_nat(1u);
v___x_2228_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_2228_, 0, v___x_2223_);
lean_ctor_set(v___x_2228_, 1, v_count_2221_);
lean_ctor_set(v___x_2228_, 2, v___x_2227_);
v___x_2229_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0___redArg(v_s_2220_, v___x_2228_, v___x_2225_, v___x_2223_);
lean_dec_ref_known(v___x_2228_, 3);
if (lean_obj_tag(v___x_2229_) == 0)
{
lean_object* v_a_2230_; lean_object* v___x_2232_; uint8_t v_isShared_2233_; uint8_t v_isSharedCheck_2241_; 
v_a_2230_ = lean_ctor_get(v___x_2229_, 0);
v_isSharedCheck_2241_ = !lean_is_exclusive(v___x_2229_);
if (v_isSharedCheck_2241_ == 0)
{
v___x_2232_ = v___x_2229_;
v_isShared_2233_ = v_isSharedCheck_2241_;
goto v_resetjp_2231_;
}
else
{
lean_inc(v_a_2230_);
lean_dec(v___x_2229_);
v___x_2232_ = lean_box(0);
v_isShared_2233_ = v_isSharedCheck_2241_;
goto v_resetjp_2231_;
}
v_resetjp_2231_:
{
lean_object* v___x_2234_; lean_object* v___x_2235_; lean_object* v___x_2236_; lean_object* v___x_2237_; lean_object* v___x_2239_; 
v___x_2234_ = lean_io_mono_nanos_now();
v___x_2235_ = lean_nat_sub(v___x_2234_, v___x_2226_);
lean_dec(v___x_2226_);
lean_dec(v___x_2234_);
v___x_2236_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2236_, 0, v_a_2230_);
v___x_2237_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2237_, 0, v___x_2235_);
lean_ctor_set(v___x_2237_, 1, v___x_2236_);
if (v_isShared_2233_ == 0)
{
lean_ctor_set(v___x_2232_, 0, v___x_2237_);
v___x_2239_ = v___x_2232_;
goto v_reusejp_2238_;
}
else
{
lean_object* v_reuseFailAlloc_2240_; 
v_reuseFailAlloc_2240_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2240_, 0, v___x_2237_);
v___x_2239_ = v_reuseFailAlloc_2240_;
goto v_reusejp_2238_;
}
v_reusejp_2238_:
{
return v___x_2239_;
}
}
}
else
{
lean_object* v_a_2242_; lean_object* v___x_2244_; uint8_t v_isShared_2245_; uint8_t v_isSharedCheck_2249_; 
lean_dec(v___x_2226_);
v_a_2242_ = lean_ctor_get(v___x_2229_, 0);
v_isSharedCheck_2249_ = !lean_is_exclusive(v___x_2229_);
if (v_isSharedCheck_2249_ == 0)
{
v___x_2244_ = v___x_2229_;
v_isShared_2245_ = v_isSharedCheck_2249_;
goto v_resetjp_2243_;
}
else
{
lean_inc(v_a_2242_);
lean_dec(v___x_2229_);
v___x_2244_ = lean_box(0);
v_isShared_2245_ = v_isSharedCheck_2249_;
goto v_resetjp_2243_;
}
v_resetjp_2243_:
{
lean_object* v___x_2247_; 
if (v_isShared_2245_ == 0)
{
v___x_2247_ = v___x_2244_;
goto v_reusejp_2246_;
}
else
{
lean_object* v_reuseFailAlloc_2248_; 
v_reuseFailAlloc_2248_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2248_, 0, v_a_2242_);
v___x_2247_ = v_reuseFailAlloc_2248_;
goto v_reusejp_2246_;
}
v_reusejp_2246_:
{
return v___x_2247_;
}
}
}
}
else
{
lean_object* v___x_2250_; lean_object* v___x_2251_; 
lean_dec(v_count_2221_);
lean_dec(v_s_2220_);
v___x_2250_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__runChecked___lam__1___closed__0));
v___x_2251_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2251_, 0, v___x_2250_);
return v___x_2251_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33____boxed(lean_object* v_s_2252_, lean_object* v_count_2253_, lean_object* v___y_2254_){
_start:
{
lean_object* v_res_2255_; 
v_res_2255_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_(v_s_2252_, v_count_2253_);
return v_res_2255_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_(lean_object* v___y_2256_){
_start:
{
lean_object* v_s_2258_; lean_object* v___f_2259_; uint64_t v___y_2261_; 
v_s_2258_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput(v___y_2256_);
lean_inc(v_s_2258_);
v___f_2259_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33____boxed), 3, 1);
lean_closure_set(v___f_2259_, 0, v_s_2258_);
if (lean_obj_tag(v_s_2258_) == 0)
{
uint64_t v___x_2271_; 
v___x_2271_ = 11ULL;
v___y_2261_ = v___x_2271_;
goto v___jp_2260_;
}
else
{
lean_object* v_val_2272_; lean_object* v_system_2273_; lean_object* v_arity_2274_; lean_object* v_size_2275_; lean_object* v_rows_2276_; lean_object* v_columns_2277_; lean_object* v_counts_2278_; lean_object* v_values_2279_; lean_object* v_inverse_2280_; lean_object* v_denominator_2281_; uint64_t v___x_2282_; uint64_t v___x_2283_; uint64_t v___x_2284_; uint64_t v___y_2286_; uint64_t v___y_2287_; uint64_t v___y_2288_; uint64_t v___y_2289_; uint64_t v___y_2290_; uint64_t v___y_2301_; uint64_t v___y_2302_; uint64_t v___y_2303_; uint64_t v___y_2304_; uint64_t v___y_2319_; uint64_t v___y_2320_; uint64_t v___y_2321_; uint64_t v___y_2330_; uint64_t v___y_2331_; uint64_t v___y_2340_; uint64_t v___x_2348_; lean_object* v___x_2349_; lean_object* v___x_2350_; uint8_t v___x_2351_; 
v_val_2272_ = lean_ctor_get(v_s_2258_, 0);
lean_inc(v_val_2272_);
lean_dec_ref_known(v_s_2258_, 1);
v_system_2273_ = lean_ctor_get(v_val_2272_, 2);
lean_inc_ref(v_system_2273_);
v_arity_2274_ = lean_ctor_get(v_val_2272_, 0);
lean_inc(v_arity_2274_);
v_size_2275_ = lean_ctor_get(v_val_2272_, 1);
lean_inc_n(v_size_2275_, 3);
lean_dec(v_val_2272_);
v_rows_2276_ = lean_ctor_get(v_system_2273_, 0);
lean_inc_ref(v_rows_2276_);
v_columns_2277_ = lean_ctor_get(v_system_2273_, 1);
lean_inc_ref(v_columns_2277_);
v_counts_2278_ = lean_ctor_get(v_system_2273_, 2);
lean_inc_ref(v_counts_2278_);
v_values_2279_ = lean_ctor_get(v_system_2273_, 3);
lean_inc_ref(v_values_2279_);
v_inverse_2280_ = lean_ctor_get(v_system_2273_, 4);
lean_inc_ref(v_inverse_2280_);
v_denominator_2281_ = lean_ctor_get(v_system_2273_, 5);
lean_inc(v_denominator_2281_);
lean_dec_ref(v_system_2273_);
v___x_2282_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_2275_, v_size_2275_, v_inverse_2280_);
v___x_2283_ = lean_uint64_of_nat(v_arity_2274_);
lean_dec(v_arity_2274_);
v___x_2284_ = lean_uint64_of_nat(v_size_2275_);
lean_dec(v_size_2275_);
v___x_2348_ = 7ULL;
v___x_2349_ = lean_unsigned_to_nat(0u);
v___x_2350_ = lean_array_get_size(v_rows_2276_);
v___x_2351_ = lean_nat_dec_lt(v___x_2349_, v___x_2350_);
if (v___x_2351_ == 0)
{
lean_dec_ref(v_rows_2276_);
v___y_2340_ = v___x_2348_;
goto v___jp_2339_;
}
else
{
size_t v___x_2352_; size_t v___x_2353_; uint64_t v___x_2354_; 
v___x_2352_ = ((size_t)0ULL);
v___x_2353_ = lean_usize_of_nat(v___x_2350_);
v___x_2354_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(v_rows_2276_, v___x_2352_, v___x_2353_, v___x_2348_);
lean_dec_ref(v_rows_2276_);
v___y_2340_ = v___x_2354_;
goto v___jp_2339_;
}
v___jp_2285_:
{
uint64_t v___x_2291_; uint64_t v___x_2292_; uint64_t v___x_2293_; uint64_t v___x_2294_; uint64_t v___x_2295_; uint64_t v___x_2296_; uint64_t v___x_2297_; uint64_t v___x_2298_; uint64_t v___x_2299_; 
v___x_2291_ = lean_uint64_mix_hash(v___x_2282_, v___y_2290_);
v___x_2292_ = lean_uint64_mix_hash(v___y_2288_, v___x_2291_);
v___x_2293_ = lean_uint64_mix_hash(v___y_2287_, v___x_2292_);
v___x_2294_ = lean_uint64_mix_hash(v___y_2289_, v___x_2293_);
v___x_2295_ = lean_uint64_mix_hash(v___y_2286_, v___x_2294_);
v___x_2296_ = lean_uint64_mix_hash(v___x_2284_, v___x_2295_);
v___x_2297_ = lean_uint64_mix_hash(v___x_2283_, v___x_2296_);
v___x_2298_ = 13ULL;
v___x_2299_ = lean_uint64_mix_hash(v___x_2297_, v___x_2298_);
v___y_2261_ = v___x_2299_;
goto v___jp_2260_;
}
v___jp_2300_:
{
lean_object* v_intZero_2305_; uint8_t v_isNeg_2306_; 
v_intZero_2305_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_2306_ = lean_int_dec_lt(v_denominator_2281_, v_intZero_2305_);
if (v_isNeg_2306_ == 0)
{
lean_object* v_a_2307_; lean_object* v___x_2308_; lean_object* v___x_2309_; uint64_t v___x_2310_; 
v_a_2307_ = lean_nat_abs(v_denominator_2281_);
lean_dec(v_denominator_2281_);
v___x_2308_ = lean_unsigned_to_nat(2u);
v___x_2309_ = lean_nat_mul(v___x_2308_, v_a_2307_);
lean_dec(v_a_2307_);
v___x_2310_ = lean_uint64_of_nat(v___x_2309_);
lean_dec(v___x_2309_);
v___y_2286_ = v___y_2301_;
v___y_2287_ = v___y_2302_;
v___y_2288_ = v___y_2304_;
v___y_2289_ = v___y_2303_;
v___y_2290_ = v___x_2310_;
goto v___jp_2285_;
}
else
{
lean_object* v_abs_2311_; lean_object* v_one_2312_; lean_object* v_a_2313_; lean_object* v___x_2314_; lean_object* v___x_2315_; lean_object* v___x_2316_; uint64_t v___x_2317_; 
v_abs_2311_ = lean_nat_abs(v_denominator_2281_);
lean_dec(v_denominator_2281_);
v_one_2312_ = lean_unsigned_to_nat(1u);
v_a_2313_ = lean_nat_sub(v_abs_2311_, v_one_2312_);
lean_dec(v_abs_2311_);
v___x_2314_ = lean_unsigned_to_nat(2u);
v___x_2315_ = lean_nat_mul(v___x_2314_, v_a_2313_);
lean_dec(v_a_2313_);
v___x_2316_ = lean_nat_add(v___x_2315_, v_one_2312_);
lean_dec(v___x_2315_);
v___x_2317_ = lean_uint64_of_nat(v___x_2316_);
lean_dec(v___x_2316_);
v___y_2286_ = v___y_2301_;
v___y_2287_ = v___y_2302_;
v___y_2288_ = v___y_2304_;
v___y_2289_ = v___y_2303_;
v___y_2290_ = v___x_2317_;
goto v___jp_2285_;
}
}
v___jp_2318_:
{
uint64_t v___x_2322_; lean_object* v___x_2323_; lean_object* v___x_2324_; uint8_t v___x_2325_; 
v___x_2322_ = 7ULL;
v___x_2323_ = lean_unsigned_to_nat(0u);
v___x_2324_ = lean_array_get_size(v_values_2279_);
v___x_2325_ = lean_nat_dec_lt(v___x_2323_, v___x_2324_);
if (v___x_2325_ == 0)
{
lean_dec_ref(v_values_2279_);
v___y_2301_ = v___y_2319_;
v___y_2302_ = v___y_2321_;
v___y_2303_ = v___y_2320_;
v___y_2304_ = v___x_2322_;
goto v___jp_2300_;
}
else
{
size_t v___x_2326_; size_t v___x_2327_; uint64_t v___x_2328_; 
v___x_2326_ = ((size_t)0ULL);
v___x_2327_ = lean_usize_of_nat(v___x_2324_);
v___x_2328_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_values_2279_, v___x_2326_, v___x_2327_, v___x_2322_);
lean_dec_ref(v_values_2279_);
v___y_2301_ = v___y_2319_;
v___y_2302_ = v___y_2321_;
v___y_2303_ = v___y_2320_;
v___y_2304_ = v___x_2328_;
goto v___jp_2300_;
}
}
v___jp_2329_:
{
uint64_t v___x_2332_; lean_object* v___x_2333_; lean_object* v___x_2334_; uint8_t v___x_2335_; 
v___x_2332_ = 7ULL;
v___x_2333_ = lean_unsigned_to_nat(0u);
v___x_2334_ = lean_array_get_size(v_counts_2278_);
v___x_2335_ = lean_nat_dec_lt(v___x_2333_, v___x_2334_);
if (v___x_2335_ == 0)
{
lean_dec_ref(v_counts_2278_);
v___y_2319_ = v___y_2330_;
v___y_2320_ = v___y_2331_;
v___y_2321_ = v___x_2332_;
goto v___jp_2318_;
}
else
{
size_t v___x_2336_; size_t v___x_2337_; uint64_t v___x_2338_; 
v___x_2336_ = ((size_t)0ULL);
v___x_2337_ = lean_usize_of_nat(v___x_2334_);
v___x_2338_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_counts_2278_, v___x_2336_, v___x_2337_, v___x_2332_);
lean_dec_ref(v_counts_2278_);
v___y_2319_ = v___y_2330_;
v___y_2320_ = v___y_2331_;
v___y_2321_ = v___x_2338_;
goto v___jp_2318_;
}
}
v___jp_2339_:
{
uint64_t v___x_2341_; lean_object* v___x_2342_; lean_object* v___x_2343_; uint8_t v___x_2344_; 
v___x_2341_ = 7ULL;
v___x_2342_ = lean_unsigned_to_nat(0u);
v___x_2343_ = lean_array_get_size(v_columns_2277_);
v___x_2344_ = lean_nat_dec_lt(v___x_2342_, v___x_2343_);
if (v___x_2344_ == 0)
{
lean_dec_ref(v_columns_2277_);
v___y_2330_ = v___y_2340_;
v___y_2331_ = v___x_2341_;
goto v___jp_2329_;
}
else
{
size_t v___x_2345_; size_t v___x_2346_; uint64_t v___x_2347_; 
v___x_2345_ = ((size_t)0ULL);
v___x_2346_ = lean_usize_of_nat(v___x_2343_);
v___x_2347_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v_columns_2277_, v___x_2345_, v___x_2346_, v___x_2341_);
lean_dec_ref(v_columns_2277_);
v___y_2330_ = v___y_2340_;
v___y_2331_ = v___x_2347_;
goto v___jp_2329_;
}
}
}
v___jp_2260_:
{
lean_object* v___x_2262_; lean_object* v___x_2264_; uint8_t v_isShared_2265_; uint8_t v_isSharedCheck_2269_; 
v___x_2262_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_2261_);
v_isSharedCheck_2269_ = !lean_is_exclusive(v___x_2262_);
if (v_isSharedCheck_2269_ == 0)
{
lean_object* v_unused_2270_; 
v_unused_2270_ = lean_ctor_get(v___x_2262_, 0);
lean_dec(v_unused_2270_);
v___x_2264_ = v___x_2262_;
v_isShared_2265_ = v_isSharedCheck_2269_;
goto v_resetjp_2263_;
}
else
{
lean_dec(v___x_2262_);
v___x_2264_ = lean_box(0);
v_isShared_2265_ = v_isSharedCheck_2269_;
goto v_resetjp_2263_;
}
v_resetjp_2263_:
{
lean_object* v___x_2267_; 
if (v_isShared_2265_ == 0)
{
lean_ctor_set(v___x_2264_, 0, v___f_2259_);
v___x_2267_ = v___x_2264_;
goto v_reusejp_2266_;
}
else
{
lean_object* v_reuseFailAlloc_2268_; 
v_reuseFailAlloc_2268_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2268_, 0, v___f_2259_);
v___x_2267_ = v_reuseFailAlloc_2268_;
goto v_reusejp_2266_;
}
v_reusejp_2266_:
{
return v___x_2267_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33____boxed(lean_object* v___y_2355_, lean_object* v___y_2356_){
_start:
{
lean_object* v_res_2357_; 
v_res_2357_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_(v___y_2355_);
lean_dec(v___y_2355_);
return v_res_2357_;
}
}
static lean_object* _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_(void){
_start:
{
lean_object* v___x_2365_; uint8_t v___x_2366_; lean_object* v___x_2367_; lean_object* v___x_2368_; lean_object* v___x_2369_; 
v___x_2365_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__config;
v___x_2366_ = 1;
v___x_2367_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_));
v___x_2368_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_));
v___x_2369_ = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(v___x_2369_, 0, v___x_2368_);
lean_ctor_set(v___x_2369_, 1, v___x_2367_);
lean_ctor_set(v___x_2369_, 2, v___x_2365_);
lean_ctor_set_uint8(v___x_2369_, sizeof(void*)*3, v___x_2366_);
return v___x_2369_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_(){
_start:
{
lean_object* v___f_2372_; lean_object* v___x_2373_; lean_object* v___x_2374_; lean_object* v___x_2375_; 
v___f_2372_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_));
v___x_2373_ = lean_obj_once(&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_, &lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__once, _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__3_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_);
v___x_2374_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__4_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_));
v___x_2375_ = lp_lean_x2dbench_LeanBench_register(v___x_2373_, v___f_2372_, v___x_2374_);
return v___x_2375_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33____boxed(lean_object* v_a_2376_){
_start:
{
lean_object* v_res_2377_; 
v_res_2377_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_();
return v_res_2377_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0(lean_object* v_s_2378_, lean_object* v_range_2379_, uint64_t v_b_2380_, lean_object* v_i_2381_, lean_object* v_hs_2382_, lean_object* v_hl_2383_){
_start:
{
lean_object* v___x_2385_; 
v___x_2385_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0___redArg(v_s_2378_, v_range_2379_, v_b_2380_, v_i_2381_);
return v___x_2385_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0___boxed(lean_object* v_s_2386_, lean_object* v_range_2387_, lean_object* v_b_2388_, lean_object* v_i_2389_, lean_object* v_hs_2390_, lean_object* v_hl_2391_, lean_object* v___y_2392_){
_start:
{
uint64_t v_b_boxed_2393_; lean_object* v_res_2394_; 
v_b_boxed_2393_ = lean_unbox_uint64(v_b_2388_);
lean_dec_ref(v_b_2388_);
v_res_2394_ = lp_Hex___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33__spec__0(v_s_2386_, v_range_2387_, v_b_boxed_2393_, v_i_2389_, v_hs_2390_, v_hl_2391_);
lean_dec_ref(v_range_2387_);
return v_res_2394_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_(lean_object* v_s_2395_, lean_object* v_x_2396_){
_start:
{
uint8_t v___x_2398_; lean_object* v___x_2399_; lean_object* v___x_2400_; 
v___x_2398_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheckDimension(v_s_2395_);
v___x_2399_ = lean_box(v___x_2398_);
v___x_2400_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2400_, 0, v___x_2399_);
return v___x_2400_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37____boxed(lean_object* v_s_2401_, lean_object* v_x_2402_, lean_object* v___y_2403_){
_start:
{
lean_object* v_res_2404_; 
v_res_2404_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_(v_s_2401_, v_x_2402_);
return v_res_2404_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_(lean_object* v___f_2405_, lean_object* v_param_2406_){
_start:
{
lean_object* v_s_2408_; lean_object* v___f_2409_; uint64_t v___y_2411_; 
v_s_2408_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput(v_param_2406_);
lean_inc(v_s_2408_);
v___f_2409_ = lean_alloc_closure((void*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__1_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37____boxed), 3, 1);
lean_closure_set(v___f_2409_, 0, v_s_2408_);
if (lean_obj_tag(v_s_2408_) == 0)
{
uint64_t v___x_2416_; 
v___x_2416_ = 11ULL;
v___y_2411_ = v___x_2416_;
goto v___jp_2410_;
}
else
{
lean_object* v_val_2417_; lean_object* v_system_2418_; lean_object* v_arity_2419_; lean_object* v_size_2420_; lean_object* v_rows_2421_; lean_object* v_columns_2422_; lean_object* v_counts_2423_; lean_object* v_values_2424_; lean_object* v_inverse_2425_; lean_object* v_denominator_2426_; uint64_t v___x_2427_; uint64_t v___x_2428_; uint64_t v___x_2429_; uint64_t v___y_2431_; uint64_t v___y_2432_; uint64_t v___y_2433_; uint64_t v___y_2434_; uint64_t v___y_2435_; uint64_t v___y_2446_; uint64_t v___y_2447_; uint64_t v___y_2448_; uint64_t v___y_2449_; uint64_t v___y_2464_; uint64_t v___y_2465_; uint64_t v___y_2466_; uint64_t v___y_2475_; uint64_t v___y_2476_; uint64_t v___y_2485_; uint64_t v___x_2493_; lean_object* v___x_2494_; lean_object* v___x_2495_; uint8_t v___x_2496_; 
v_val_2417_ = lean_ctor_get(v_s_2408_, 0);
lean_inc(v_val_2417_);
lean_dec_ref_known(v_s_2408_, 1);
v_system_2418_ = lean_ctor_get(v_val_2417_, 2);
lean_inc_ref(v_system_2418_);
v_arity_2419_ = lean_ctor_get(v_val_2417_, 0);
lean_inc(v_arity_2419_);
v_size_2420_ = lean_ctor_get(v_val_2417_, 1);
lean_inc_n(v_size_2420_, 3);
lean_dec(v_val_2417_);
v_rows_2421_ = lean_ctor_get(v_system_2418_, 0);
lean_inc_ref(v_rows_2421_);
v_columns_2422_ = lean_ctor_get(v_system_2418_, 1);
lean_inc_ref(v_columns_2422_);
v_counts_2423_ = lean_ctor_get(v_system_2418_, 2);
lean_inc_ref(v_counts_2423_);
v_values_2424_ = lean_ctor_get(v_system_2418_, 3);
lean_inc_ref(v_values_2424_);
v_inverse_2425_ = lean_ctor_get(v_system_2418_, 4);
lean_inc_ref(v_inverse_2425_);
v_denominator_2426_ = lean_ctor_get(v_system_2418_, 5);
lean_inc(v_denominator_2426_);
lean_dec_ref(v_system_2418_);
v___x_2427_ = lp_Hex_Hex_SignDetBench_matrixHash(v_size_2420_, v_size_2420_, v_inverse_2425_);
v___x_2428_ = lean_uint64_of_nat(v_arity_2419_);
lean_dec(v_arity_2419_);
v___x_2429_ = lean_uint64_of_nat(v_size_2420_);
lean_dec(v_size_2420_);
v___x_2493_ = 7ULL;
v___x_2494_ = lean_unsigned_to_nat(0u);
v___x_2495_ = lean_array_get_size(v_rows_2421_);
v___x_2496_ = lean_nat_dec_lt(v___x_2494_, v___x_2495_);
if (v___x_2496_ == 0)
{
lean_dec_ref(v_rows_2421_);
v___y_2485_ = v___x_2493_;
goto v___jp_2484_;
}
else
{
size_t v___x_2497_; size_t v___x_2498_; uint64_t v___x_2499_; 
v___x_2497_ = ((size_t)0ULL);
v___x_2498_ = lean_usize_of_nat(v___x_2495_);
v___x_2499_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(v_rows_2421_, v___x_2497_, v___x_2498_, v___x_2493_);
lean_dec_ref(v_rows_2421_);
v___y_2485_ = v___x_2499_;
goto v___jp_2484_;
}
v___jp_2430_:
{
uint64_t v___x_2436_; uint64_t v___x_2437_; uint64_t v___x_2438_; uint64_t v___x_2439_; uint64_t v___x_2440_; uint64_t v___x_2441_; uint64_t v___x_2442_; uint64_t v___x_2443_; uint64_t v___x_2444_; 
v___x_2436_ = lean_uint64_mix_hash(v___x_2427_, v___y_2435_);
v___x_2437_ = lean_uint64_mix_hash(v___y_2433_, v___x_2436_);
v___x_2438_ = lean_uint64_mix_hash(v___y_2434_, v___x_2437_);
v___x_2439_ = lean_uint64_mix_hash(v___y_2432_, v___x_2438_);
v___x_2440_ = lean_uint64_mix_hash(v___y_2431_, v___x_2439_);
v___x_2441_ = lean_uint64_mix_hash(v___x_2429_, v___x_2440_);
v___x_2442_ = lean_uint64_mix_hash(v___x_2428_, v___x_2441_);
v___x_2443_ = 13ULL;
v___x_2444_ = lean_uint64_mix_hash(v___x_2442_, v___x_2443_);
v___y_2411_ = v___x_2444_;
goto v___jp_2410_;
}
v___jp_2445_:
{
lean_object* v_intZero_2450_; uint8_t v_isNeg_2451_; 
v_intZero_2450_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v_isNeg_2451_ = lean_int_dec_lt(v_denominator_2426_, v_intZero_2450_);
if (v_isNeg_2451_ == 0)
{
lean_object* v_a_2452_; lean_object* v___x_2453_; lean_object* v___x_2454_; uint64_t v___x_2455_; 
v_a_2452_ = lean_nat_abs(v_denominator_2426_);
lean_dec(v_denominator_2426_);
v___x_2453_ = lean_unsigned_to_nat(2u);
v___x_2454_ = lean_nat_mul(v___x_2453_, v_a_2452_);
lean_dec(v_a_2452_);
v___x_2455_ = lean_uint64_of_nat(v___x_2454_);
lean_dec(v___x_2454_);
v___y_2431_ = v___y_2447_;
v___y_2432_ = v___y_2446_;
v___y_2433_ = v___y_2449_;
v___y_2434_ = v___y_2448_;
v___y_2435_ = v___x_2455_;
goto v___jp_2430_;
}
else
{
lean_object* v_abs_2456_; lean_object* v_one_2457_; lean_object* v_a_2458_; lean_object* v___x_2459_; lean_object* v___x_2460_; lean_object* v___x_2461_; uint64_t v___x_2462_; 
v_abs_2456_ = lean_nat_abs(v_denominator_2426_);
lean_dec(v_denominator_2426_);
v_one_2457_ = lean_unsigned_to_nat(1u);
v_a_2458_ = lean_nat_sub(v_abs_2456_, v_one_2457_);
lean_dec(v_abs_2456_);
v___x_2459_ = lean_unsigned_to_nat(2u);
v___x_2460_ = lean_nat_mul(v___x_2459_, v_a_2458_);
lean_dec(v_a_2458_);
v___x_2461_ = lean_nat_add(v___x_2460_, v_one_2457_);
lean_dec(v___x_2460_);
v___x_2462_ = lean_uint64_of_nat(v___x_2461_);
lean_dec(v___x_2461_);
v___y_2431_ = v___y_2447_;
v___y_2432_ = v___y_2446_;
v___y_2433_ = v___y_2449_;
v___y_2434_ = v___y_2448_;
v___y_2435_ = v___x_2462_;
goto v___jp_2430_;
}
}
v___jp_2463_:
{
uint64_t v___x_2467_; lean_object* v___x_2468_; lean_object* v___x_2469_; uint8_t v___x_2470_; 
v___x_2467_ = 7ULL;
v___x_2468_ = lean_unsigned_to_nat(0u);
v___x_2469_ = lean_array_get_size(v_values_2424_);
v___x_2470_ = lean_nat_dec_lt(v___x_2468_, v___x_2469_);
if (v___x_2470_ == 0)
{
lean_dec_ref(v_values_2424_);
v___y_2446_ = v___y_2465_;
v___y_2447_ = v___y_2464_;
v___y_2448_ = v___y_2466_;
v___y_2449_ = v___x_2467_;
goto v___jp_2445_;
}
else
{
size_t v___x_2471_; size_t v___x_2472_; uint64_t v___x_2473_; 
v___x_2471_ = ((size_t)0ULL);
v___x_2472_ = lean_usize_of_nat(v___x_2469_);
v___x_2473_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_values_2424_, v___x_2471_, v___x_2472_, v___x_2467_);
lean_dec_ref(v_values_2424_);
v___y_2446_ = v___y_2465_;
v___y_2447_ = v___y_2464_;
v___y_2448_ = v___y_2466_;
v___y_2449_ = v___x_2473_;
goto v___jp_2445_;
}
}
v___jp_2474_:
{
uint64_t v___x_2477_; lean_object* v___x_2478_; lean_object* v___x_2479_; uint8_t v___x_2480_; 
v___x_2477_ = 7ULL;
v___x_2478_ = lean_unsigned_to_nat(0u);
v___x_2479_ = lean_array_get_size(v_counts_2423_);
v___x_2480_ = lean_nat_dec_lt(v___x_2478_, v___x_2479_);
if (v___x_2480_ == 0)
{
lean_dec_ref(v_counts_2423_);
v___y_2464_ = v___y_2475_;
v___y_2465_ = v___y_2476_;
v___y_2466_ = v___x_2477_;
goto v___jp_2463_;
}
else
{
size_t v___x_2481_; size_t v___x_2482_; uint64_t v___x_2483_; 
v___x_2481_ = ((size_t)0ULL);
v___x_2482_ = lean_usize_of_nat(v___x_2479_);
v___x_2483_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v_counts_2423_, v___x_2481_, v___x_2482_, v___x_2477_);
lean_dec_ref(v_counts_2423_);
v___y_2464_ = v___y_2475_;
v___y_2465_ = v___y_2476_;
v___y_2466_ = v___x_2483_;
goto v___jp_2463_;
}
}
v___jp_2484_:
{
uint64_t v___x_2486_; lean_object* v___x_2487_; lean_object* v___x_2488_; uint8_t v___x_2489_; 
v___x_2486_ = 7ULL;
v___x_2487_ = lean_unsigned_to_nat(0u);
v___x_2488_ = lean_array_get_size(v_columns_2422_);
v___x_2489_ = lean_nat_dec_lt(v___x_2487_, v___x_2488_);
if (v___x_2489_ == 0)
{
lean_dec_ref(v_columns_2422_);
v___y_2475_ = v___y_2485_;
v___y_2476_ = v___x_2486_;
goto v___jp_2474_;
}
else
{
size_t v___x_2490_; size_t v___x_2491_; uint64_t v___x_2492_; 
v___x_2490_ = ((size_t)0ULL);
v___x_2491_ = lean_usize_of_nat(v___x_2488_);
v___x_2492_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v_columns_2422_, v___x_2490_, v___x_2491_, v___x_2486_);
lean_dec_ref(v_columns_2422_);
v___y_2475_ = v___y_2485_;
v___y_2476_ = v___x_2492_;
goto v___jp_2474_;
}
}
}
v___jp_2410_:
{
lean_object* v___x_2412_; uint8_t v___x_2413_; uint8_t v___x_2414_; lean_object* v___x_2415_; 
v___x_2412_ = lp_lean_x2dbench_LeanBench_blackBox(v___y_2411_);
lean_dec_ref(v___x_2412_);
v___x_2413_ = 1;
v___x_2414_ = 0;
v___x_2415_ = lp_lean_x2dbench_LeanBench_kernelLoop___redArg(v___f_2409_, v___f_2405_, v___x_2413_, v___x_2414_);
return v___x_2415_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37____boxed(lean_object* v___f_2500_, lean_object* v_param_2501_, lean_object* v___y_2502_){
_start:
{
lean_object* v_res_2503_; 
v_res_2503_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___lam__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_(v___f_2500_, v_param_2501_);
lean_dec(v_param_2501_);
return v_res_2503_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_(){
_start:
{
lean_object* v___f_2507_; lean_object* v___x_2508_; lean_object* v___x_2509_; 
v___f_2507_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__0_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_));
v___x_2508_ = ((lean_object*)(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn___closed__2_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_));
v___x_2509_ = lp_lean_x2dbench_LeanBench_registerKernel(v___x_2508_, v___f_2507_);
return v___x_2509_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37____boxed(lean_object* v_a_2510_){
_start:
{
lean_object* v_res_2511_; 
v_res_2511_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_();
return v_res_2511_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_bits(lean_object* v_z_2512_){
_start:
{
lean_object* v___x_2513_; lean_object* v___x_2514_; uint8_t v___x_2515_; 
v___x_2513_ = lean_unsigned_to_nat(0u);
v___x_2514_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v___x_2515_ = lean_int_dec_eq(v_z_2512_, v___x_2514_);
if (v___x_2515_ == 0)
{
lean_object* v___x_2516_; lean_object* v___x_2517_; lean_object* v___x_2518_; lean_object* v___x_2519_; 
v___x_2516_ = lean_nat_abs(v_z_2512_);
v___x_2517_ = lean_nat_log2(v___x_2516_);
lean_dec(v___x_2516_);
v___x_2518_ = lean_unsigned_to_nat(1u);
v___x_2519_ = lean_nat_add(v___x_2517_, v___x_2518_);
lean_dec(v___x_2517_);
return v___x_2519_;
}
else
{
return v___x_2513_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_bits___boxed(lean_object* v_z_2520_){
_start:
{
lean_object* v_res_2521_; 
v_res_2521_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_bits(v_z_2520_);
lean_dec(v_z_2520_);
return v_res_2521_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Lean_Option_toJson___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__3(lean_object* v_x_2522_){
_start:
{
if (lean_obj_tag(v_x_2522_) == 0)
{
lean_object* v___x_2523_; 
v___x_2523_ = lean_box(0);
return v___x_2523_;
}
else
{
lean_object* v_val_2524_; lean_object* v___x_2525_; uint8_t v___x_2526_; 
v_val_2524_ = lean_ctor_get(v_x_2522_, 0);
v___x_2525_ = lean_alloc_ctor(1, 0, 1);
v___x_2526_ = lean_unbox(v_val_2524_);
lean_ctor_set_uint8(v___x_2525_, 0, v___x_2526_);
return v___x_2525_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Lean_Option_toJson___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__3___boxed(lean_object* v_x_2527_){
_start:
{
lean_object* v_res_2528_; 
v_res_2528_ = lp_Hex_Lean_Option_toJson___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__3(v_x_2527_);
lean_dec(v_x_2527_);
return v_res_2528_;
}
}
LEAN_EXPORT uint8_t lp_Hex_Option_instBEq_beq___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__5(lean_object* v_x_2529_, lean_object* v_x_2530_){
_start:
{
if (lean_obj_tag(v_x_2529_) == 0)
{
if (lean_obj_tag(v_x_2530_) == 0)
{
uint8_t v___x_2531_; 
v___x_2531_ = 1;
return v___x_2531_;
}
else
{
uint8_t v___x_2532_; 
v___x_2532_ = 0;
return v___x_2532_;
}
}
else
{
if (lean_obj_tag(v_x_2530_) == 0)
{
uint8_t v___x_2533_; 
v___x_2533_ = 0;
return v___x_2533_;
}
else
{
lean_object* v_val_2534_; lean_object* v_val_2535_; uint64_t v___x_2536_; uint64_t v___x_2537_; uint8_t v___x_2538_; 
v_val_2534_ = lean_ctor_get(v_x_2529_, 0);
v_val_2535_ = lean_ctor_get(v_x_2530_, 0);
v___x_2536_ = lean_unbox_uint64(v_val_2534_);
v___x_2537_ = lean_unbox_uint64(v_val_2535_);
v___x_2538_ = lean_uint64_dec_eq(v___x_2536_, v___x_2537_);
return v___x_2538_;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_Option_instBEq_beq___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__5___boxed(lean_object* v_x_2539_, lean_object* v_x_2540_){
_start:
{
uint8_t v_res_2541_; lean_object* v_r_2542_; 
v_res_2541_ = lp_Hex_Option_instBEq_beq___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__5(v_x_2539_, v_x_2540_);
lean_dec(v_x_2540_);
lean_dec(v_x_2539_);
v_r_2542_ = lean_box(v_res_2541_);
return v_r_2542_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__1(lean_object* v_a_2543_, lean_object* v_b_2544_){
_start:
{
lean_object* v___x_2545_; uint8_t v___x_2546_; 
v___x_2545_ = lean_alloc_closure((void*)(l_Int_instDecidableEq___boxed), 2, 0);
v___x_2546_ = l_instDecidableEqList___redArg(v___x_2545_, v_a_2543_, v_b_2544_);
return v___x_2546_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__1___boxed(lean_object* v_a_2547_, lean_object* v_b_2548_){
_start:
{
uint8_t v_res_2549_; lean_object* v_r_2550_; 
v_res_2549_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__1(v_a_2547_, v_b_2548_);
v_r_2550_ = lean_box(v_res_2549_);
return v_r_2550_;
}
}
LEAN_EXPORT uint8_t lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__0(lean_object* v_a_2551_, lean_object* v_b_2552_){
_start:
{
lean_object* v___x_2553_; uint8_t v___x_2554_; 
v___x_2553_ = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
v___x_2554_ = l_instDecidableEqList___redArg(v___x_2553_, v_a_2551_, v_b_2552_);
return v___x_2554_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__0___boxed(lean_object* v_a_2555_, lean_object* v_b_2556_){
_start:
{
uint8_t v_res_2557_; lean_object* v_r_2558_; 
v_res_2557_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___lam__0(v_a_2555_, v_b_2556_);
v_r_2558_ = lean_box(v_res_2557_);
return v_r_2558_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__0(lean_object* v_as_2559_, size_t v_i_2560_, size_t v_stop_2561_, lean_object* v_b_2562_){
_start:
{
lean_object* v___y_2564_; uint8_t v___x_2568_; 
v___x_2568_ = lean_usize_dec_eq(v_i_2560_, v_stop_2561_);
if (v___x_2568_ == 0)
{
lean_object* v___x_2569_; lean_object* v___x_2570_; uint8_t v___x_2571_; 
v___x_2569_ = lean_array_uget_borrowed(v_as_2559_, v_i_2560_);
v___x_2570_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_bits(v___x_2569_);
v___x_2571_ = lean_nat_dec_le(v_b_2562_, v___x_2570_);
if (v___x_2571_ == 0)
{
lean_dec(v___x_2570_);
v___y_2564_ = v_b_2562_;
goto v___jp_2563_;
}
else
{
lean_dec(v_b_2562_);
v___y_2564_ = v___x_2570_;
goto v___jp_2563_;
}
}
else
{
return v_b_2562_;
}
v___jp_2563_:
{
size_t v___x_2565_; size_t v___x_2566_; 
v___x_2565_ = ((size_t)1ULL);
v___x_2566_ = lean_usize_add(v_i_2560_, v___x_2565_);
v_i_2560_ = v___x_2566_;
v_b_2562_ = v___y_2564_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__0___boxed(lean_object* v_as_2572_, lean_object* v_i_2573_, lean_object* v_stop_2574_, lean_object* v_b_2575_){
_start:
{
size_t v_i_boxed_2576_; size_t v_stop_boxed_2577_; lean_object* v_res_2578_; 
v_i_boxed_2576_ = lean_unbox_usize(v_i_2573_);
lean_dec(v_i_2573_);
v_stop_boxed_2577_ = lean_unbox_usize(v_stop_2574_);
lean_dec(v_stop_2574_);
v_res_2578_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__0(v_as_2572_, v_i_boxed_2576_, v_stop_boxed_2577_, v_b_2575_);
lean_dec_ref(v_as_2572_);
return v_res_2578_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__4(lean_object* v_as_2579_, size_t v_i_2580_, size_t v_stop_2581_, lean_object* v_b_2582_){
_start:
{
lean_object* v___y_2584_; uint8_t v___x_2588_; 
v___x_2588_ = lean_usize_dec_eq(v_i_2580_, v_stop_2581_);
if (v___x_2588_ == 0)
{
lean_object* v___x_2589_; lean_object* v___x_2590_; lean_object* v___x_2591_; uint8_t v___x_2592_; 
v___x_2589_ = lean_unsigned_to_nat(0u);
v___x_2590_ = lean_array_uget_borrowed(v_as_2579_, v_i_2580_);
v___x_2591_ = lean_array_get_size(v___x_2590_);
v___x_2592_ = lean_nat_dec_lt(v___x_2589_, v___x_2591_);
if (v___x_2592_ == 0)
{
v___y_2584_ = v_b_2582_;
goto v___jp_2583_;
}
else
{
uint8_t v___x_2593_; 
v___x_2593_ = lean_nat_dec_le(v___x_2591_, v___x_2591_);
if (v___x_2593_ == 0)
{
if (v___x_2592_ == 0)
{
v___y_2584_ = v_b_2582_;
goto v___jp_2583_;
}
else
{
size_t v___x_2594_; size_t v___x_2595_; lean_object* v___x_2596_; 
v___x_2594_ = ((size_t)0ULL);
v___x_2595_ = lean_usize_of_nat(v___x_2591_);
v___x_2596_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__0(v___x_2590_, v___x_2594_, v___x_2595_, v_b_2582_);
v___y_2584_ = v___x_2596_;
goto v___jp_2583_;
}
}
else
{
size_t v___x_2597_; size_t v___x_2598_; lean_object* v___x_2599_; 
v___x_2597_ = ((size_t)0ULL);
v___x_2598_ = lean_usize_of_nat(v___x_2591_);
v___x_2599_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__0(v___x_2590_, v___x_2597_, v___x_2598_, v_b_2582_);
v___y_2584_ = v___x_2599_;
goto v___jp_2583_;
}
}
}
else
{
return v_b_2582_;
}
v___jp_2583_:
{
size_t v___x_2585_; size_t v___x_2586_; 
v___x_2585_ = ((size_t)1ULL);
v___x_2586_ = lean_usize_add(v_i_2580_, v___x_2585_);
v_i_2580_ = v___x_2586_;
v_b_2582_ = v___y_2584_;
goto _start;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__4___boxed(lean_object* v_as_2600_, lean_object* v_i_2601_, lean_object* v_stop_2602_, lean_object* v_b_2603_){
_start:
{
size_t v_i_boxed_2604_; size_t v_stop_boxed_2605_; lean_object* v_res_2606_; 
v_i_boxed_2604_ = lean_unbox_usize(v_i_2601_);
lean_dec(v_i_2601_);
v_stop_boxed_2605_ = lean_unbox_usize(v_stop_2602_);
lean_dec(v_stop_2602_);
v_res_2606_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__4(v_as_2600_, v_i_boxed_2604_, v_stop_boxed_2605_, v_b_2603_);
lean_dec_ref(v_as_2600_);
return v_res_2606_;
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__2(lean_object* v_x_2607_, lean_object* v_x_2608_){
_start:
{
if (lean_obj_tag(v_x_2608_) == 0)
{
return v_x_2607_;
}
else
{
lean_object* v_head_2609_; lean_object* v_tail_2610_; lean_object* v___x_2611_; uint8_t v___x_2612_; 
v_head_2609_ = lean_ctor_get(v_x_2608_, 0);
v_tail_2610_ = lean_ctor_get(v_x_2608_, 1);
v___x_2611_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_bits(v_head_2609_);
v___x_2612_ = lean_nat_dec_le(v_x_2607_, v___x_2611_);
if (v___x_2612_ == 0)
{
lean_dec(v___x_2611_);
v_x_2608_ = v_tail_2610_;
goto _start;
}
else
{
lean_dec(v_x_2607_);
v_x_2607_ = v___x_2611_;
v_x_2608_ = v_tail_2610_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex_List_foldl___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__2___boxed(lean_object* v_x_2615_, lean_object* v_x_2616_){
_start:
{
lean_object* v_res_2617_; 
v_res_2617_ = lp_Hex_List_foldl___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__2(v_x_2615_, v_x_2616_);
lean_dec(v_x_2616_);
return v_res_2617_;
}
}
LEAN_EXPORT lean_object* lp_Hex_List_mapTR_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__1(lean_object* v_a_2618_, lean_object* v_a_2619_){
_start:
{
if (lean_obj_tag(v_a_2618_) == 0)
{
lean_object* v___x_2620_; 
v___x_2620_ = l_List_reverse___redArg(v_a_2619_);
return v___x_2620_;
}
else
{
lean_object* v_head_2621_; lean_object* v_tail_2622_; lean_object* v___x_2624_; uint8_t v_isShared_2625_; uint8_t v_isSharedCheck_2632_; 
v_head_2621_ = lean_ctor_get(v_a_2618_, 0);
v_tail_2622_ = lean_ctor_get(v_a_2618_, 1);
v_isSharedCheck_2632_ = !lean_is_exclusive(v_a_2618_);
if (v_isSharedCheck_2632_ == 0)
{
v___x_2624_ = v_a_2618_;
v_isShared_2625_ = v_isSharedCheck_2632_;
goto v_resetjp_2623_;
}
else
{
lean_inc(v_tail_2622_);
lean_inc(v_head_2621_);
lean_dec(v_a_2618_);
v___x_2624_ = lean_box(0);
v_isShared_2625_ = v_isSharedCheck_2632_;
goto v_resetjp_2623_;
}
v_resetjp_2623_:
{
lean_object* v___x_2626_; lean_object* v___x_2627_; lean_object* v___x_2629_; 
v___x_2626_ = lean_obj_once(&lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0, &lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0_once, _init_lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0);
v___x_2627_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2627_, 0, v_head_2621_);
lean_ctor_set(v___x_2627_, 1, v___x_2626_);
if (v_isShared_2625_ == 0)
{
lean_ctor_set(v___x_2624_, 1, v_a_2619_);
lean_ctor_set(v___x_2624_, 0, v___x_2627_);
v___x_2629_ = v___x_2624_;
goto v_reusejp_2628_;
}
else
{
lean_object* v_reuseFailAlloc_2631_; 
v_reuseFailAlloc_2631_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_2631_, 0, v___x_2627_);
lean_ctor_set(v_reuseFailAlloc_2631_, 1, v_a_2619_);
v___x_2629_ = v_reuseFailAlloc_2631_;
goto v_reusejp_2628_;
}
v_reusejp_2628_:
{
v_a_2618_ = v_tail_2622_;
v_a_2619_ = v___x_2629_;
goto _start;
}
}
}
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__4(void){
_start:
{
lean_object* v___x_2638_; lean_object* v___x_2639_; lean_object* v___x_2640_; 
v___x_2638_ = lean_box(0);
v___x_2639_ = lean_obj_once(&lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0, &lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0_once, _init_lp_Hex_List_all___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build_spec__0___closed__0);
v___x_2640_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2640_, 0, v___x_2639_);
lean_ctor_set(v___x_2640_, 1, v___x_2638_);
return v___x_2640_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__5(void){
_start:
{
lean_object* v___x_2641_; lean_object* v___x_2642_; lean_object* v___x_2643_; 
v___x_2641_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__4, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__4_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__4);
v___x_2642_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v___x_2643_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2643_, 0, v___x_2642_);
lean_ctor_set(v___x_2643_, 1, v___x_2641_);
return v___x_2643_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__6(void){
_start:
{
lean_object* v___x_2644_; lean_object* v___x_2645_; lean_object* v___x_2646_; 
v___x_2644_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__5, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__5_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__5);
v___x_2645_ = lean_obj_once(&lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__7, &lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__7_once, _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build___closed__7);
v___x_2646_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2646_, 0, v___x_2645_);
lean_ctor_set(v___x_2646_, 1, v___x_2644_);
return v___x_2646_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__9(void){
_start:
{
lean_object* v___x_2649_; lean_object* v___x_2650_; 
v___x_2649_ = lean_unsigned_to_nat(11u);
v___x_2650_ = l_Lean_JsonNumber_fromNat(v___x_2649_);
return v___x_2650_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__10(void){
_start:
{
lean_object* v___x_2651_; lean_object* v___x_2652_; 
v___x_2651_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__9, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__9_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__9);
v___x_2652_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2652_, 0, v___x_2651_);
return v___x_2652_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__11(void){
_start:
{
lean_object* v___x_2653_; lean_object* v___x_2654_; lean_object* v___x_2655_; 
v___x_2653_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__10, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__10_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__10);
v___x_2654_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__8));
v___x_2655_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2655_, 0, v___x_2654_);
lean_ctor_set(v___x_2655_, 1, v___x_2653_);
return v___x_2655_;
}
}
static lean_object* _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__12(void){
_start:
{
lean_object* v___x_2656_; lean_object* v___x_2657_; lean_object* v___x_2658_; 
v___x_2656_ = lean_box(0);
v___x_2657_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__11, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__11_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__11);
v___x_2658_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2658_, 0, v___x_2657_);
lean_ctor_set(v___x_2658_, 1, v___x_2656_);
return v___x_2658_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6(lean_object* v_as_2683_, size_t v_sz_2684_, size_t v_i_2685_, lean_object* v_b_2686_){
_start:
{
uint8_t v___x_2691_; 
v___x_2691_ = lean_usize_dec_lt(v_i_2685_, v_sz_2684_);
if (v___x_2691_ == 0)
{
lean_object* v___x_2692_; 
v___x_2692_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2692_, 0, v_b_2686_);
return v___x_2692_;
}
else
{
lean_object* v_a_2693_; lean_object* v___x_2694_; 
v_a_2693_ = lean_array_uget_borrowed(v_as_2683_, v_i_2685_);
lean_inc(v_a_2693_);
v___x_2694_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_build(v_a_2693_);
if (lean_obj_tag(v___x_2694_) == 1)
{
lean_object* v_a_2695_; lean_object* v___x_2697_; uint8_t v_isShared_2698_; uint8_t v_isSharedCheck_3062_; 
v_a_2695_ = lean_ctor_get(v___x_2694_, 0);
v_isSharedCheck_3062_ = !lean_is_exclusive(v___x_2694_);
if (v_isSharedCheck_3062_ == 0)
{
v___x_2697_ = v___x_2694_;
v_isShared_2698_ = v_isSharedCheck_3062_;
goto v_resetjp_2696_;
}
else
{
lean_inc(v_a_2695_);
lean_dec(v___x_2694_);
v___x_2697_ = lean_box(0);
v_isShared_2698_ = v_isSharedCheck_3062_;
goto v_resetjp_2696_;
}
v_resetjp_2696_:
{
lean_object* v___f_2699_; lean_object* v___f_2700_; lean_object* v___x_2701_; lean_object* v___x_2702_; lean_object* v___x_2703_; lean_object* v___x_2704_; lean_object* v___x_2705_; lean_object* v___x_2706_; lean_object* v___x_2707_; lean_object* v___x_2708_; lean_object* v___y_2710_; lean_object* v___y_2711_; uint64_t v___y_2712_; uint64_t v___y_2713_; lean_object* v___y_2714_; lean_object* v___y_2715_; uint64_t v___y_2716_; uint64_t v___y_2717_; lean_object* v___y_2718_; lean_object* v___y_2719_; lean_object* v___y_2720_; lean_object* v___y_2721_; uint64_t v___y_2722_; lean_object* v___y_2723_; uint64_t v___y_2724_; lean_object* v___y_2725_; uint64_t v___y_2726_; uint64_t v___y_2727_; lean_object* v___y_2773_; lean_object* v___y_2774_; uint64_t v___y_2775_; uint64_t v___y_2776_; lean_object* v___y_2777_; lean_object* v___y_2778_; lean_object* v___y_2779_; uint64_t v___y_2780_; lean_object* v___y_2781_; lean_object* v___y_2782_; lean_object* v___y_2783_; lean_object* v___y_2784_; uint64_t v___y_2785_; lean_object* v___y_2786_; uint64_t v___y_2787_; lean_object* v___y_2788_; uint64_t v___y_2789_; uint64_t v___y_2790_; lean_object* v___y_2803_; lean_object* v___y_2804_; uint64_t v___y_2805_; uint64_t v___y_2806_; lean_object* v___y_2807_; lean_object* v___y_2808_; lean_object* v___y_2809_; uint64_t v___y_2810_; lean_object* v___y_2811_; lean_object* v___y_2812_; lean_object* v___y_2813_; lean_object* v___y_2814_; lean_object* v___y_2815_; uint64_t v___y_2816_; lean_object* v___y_2817_; uint64_t v___y_2818_; lean_object* v___y_2819_; uint64_t v___y_2820_; lean_object* v___y_2828_; lean_object* v___y_2829_; uint64_t v___y_2830_; uint64_t v___y_2831_; lean_object* v___y_2832_; lean_object* v___y_2833_; lean_object* v___y_2834_; lean_object* v___y_2835_; lean_object* v___y_2836_; lean_object* v___y_2837_; lean_object* v___y_2838_; lean_object* v___y_2839_; uint64_t v___y_2840_; lean_object* v___y_2841_; lean_object* v___y_2842_; uint64_t v___y_2843_; lean_object* v___y_2844_; uint64_t v___y_2845_; lean_object* v___y_2853_; lean_object* v___y_2854_; uint64_t v___y_2855_; lean_object* v___y_2856_; lean_object* v___y_2857_; lean_object* v___y_2858_; lean_object* v___y_2859_; lean_object* v___y_2860_; lean_object* v___y_2861_; lean_object* v___y_2862_; lean_object* v___y_2863_; lean_object* v___y_2864_; uint64_t v___y_2865_; lean_object* v___y_2866_; lean_object* v___y_2867_; uint64_t v___y_2868_; lean_object* v___y_2869_; uint64_t v___y_2870_; lean_object* v_rows_2878_; lean_object* v_columns_2879_; lean_object* v_counts_2880_; lean_object* v_values_2881_; lean_object* v_inverse_2882_; lean_object* v_denominator_2883_; lean_object* v___y_2884_; lean_object* v___y_2885_; lean_object* v___y_2886_; lean_object* v___y_2887_; lean_object* v_matchesPolynomial_2942_; uint8_t v___y_2963_; uint8_t v___y_2964_; uint8_t v___y_2965_; uint8_t v___y_2969_; uint8_t v___y_2970_; uint8_t v___y_2971_; uint8_t v___y_2972_; uint8_t v___y_2974_; uint8_t v___y_2975_; uint8_t v___y_2976_; uint8_t v___y_2977_; uint8_t v___y_2978_; uint8_t v___y_2980_; uint8_t v___y_2981_; uint8_t v___y_2982_; uint8_t v___y_2983_; uint8_t v___y_2984_; uint8_t v___y_2985_; uint8_t v___y_2987_; lean_object* v___x_3054_; lean_object* v___x_3055_; uint64_t v___x_3056_; uint64_t v___x_3057_; lean_object* v___x_3058_; lean_object* v___x_3059_; uint8_t v___x_3060_; 
v___f_2699_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__2));
v___f_2700_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__3));
v___x_2701_ = lean_box(0);
v___x_2702_ = lean_unsigned_to_nat(1u);
v___x_2703_ = lean_unsigned_to_nat(0u);
v___x_2704_ = lean_obj_once(&lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0, &lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0_once, _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_instHashableInput___lam__2___closed__0);
v___x_2705_ = lean_box(0);
v___x_2706_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__6, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__6_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__6);
v___x_2707_ = lp_Hex_Hex_SignDet_words___redArg(v___x_2706_, v_a_2693_);
v___x_2708_ = lp_Hex_List_mapTR_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__1(v___x_2707_, v___x_2705_);
lean_inc(v_a_2695_);
v___x_3054_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3054_, 0, v_a_2695_);
lean_inc_ref(v___x_3054_);
v___x_3055_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runSolve(v___x_3054_);
v___x_3056_ = 7ULL;
v___x_3057_ = lp_Hex_List_foldl___at___00Hex_SignDetBench_MaximalMatrix_runSolve_spec__0(v___x_3056_, v___x_2708_);
v___x_3058_ = lean_box_uint64(v___x_3057_);
v___x_3059_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3059_, 0, v___x_3058_);
v___x_3060_ = lp_Hex_Option_instBEq_beq___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__5(v___x_3055_, v___x_3059_);
lean_dec_ref_known(v___x_3059_, 1);
lean_dec(v___x_3055_);
if (v___x_3060_ == 0)
{
lean_dec_ref_known(v___x_3054_, 1);
v___y_2987_ = v___x_3060_;
goto v___jp_2986_;
}
else
{
uint8_t v___x_3061_; 
v___x_3061_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_runCheck(v___x_3054_);
v___y_2987_ = v___x_3061_;
goto v___jp_2986_;
}
v___jp_2709_:
{
uint64_t v___x_2728_; uint64_t v___x_2729_; uint64_t v___x_2730_; uint64_t v___x_2731_; uint64_t v___x_2732_; uint64_t v___x_2733_; uint64_t v___x_2734_; uint64_t v___x_2735_; uint64_t v___x_2736_; lean_object* v___x_2737_; lean_object* v___x_2738_; lean_object* v___x_2740_; 
v___x_2728_ = lean_uint64_mix_hash(v___y_2713_, v___y_2727_);
v___x_2729_ = lean_uint64_mix_hash(v___y_2716_, v___x_2728_);
v___x_2730_ = lean_uint64_mix_hash(v___y_2726_, v___x_2729_);
v___x_2731_ = lean_uint64_mix_hash(v___y_2717_, v___x_2730_);
v___x_2732_ = lean_uint64_mix_hash(v___y_2712_, v___x_2731_);
v___x_2733_ = lean_uint64_mix_hash(v___y_2722_, v___x_2732_);
v___x_2734_ = lean_uint64_mix_hash(v___y_2724_, v___x_2733_);
v___x_2735_ = 13ULL;
v___x_2736_ = lean_uint64_mix_hash(v___x_2734_, v___x_2735_);
v___x_2737_ = lean_uint64_to_nat(v___x_2736_);
v___x_2738_ = l_Lean_JsonNumber_fromNat(v___x_2737_);
if (v_isShared_2698_ == 0)
{
lean_ctor_set_tag(v___x_2697_, 2);
lean_ctor_set(v___x_2697_, 0, v___x_2738_);
v___x_2740_ = v___x_2697_;
goto v_reusejp_2739_;
}
else
{
lean_object* v_reuseFailAlloc_2771_; 
v_reuseFailAlloc_2771_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v_reuseFailAlloc_2771_, 0, v___x_2738_);
v___x_2740_ = v_reuseFailAlloc_2771_;
goto v_reusejp_2739_;
}
v_reusejp_2739_:
{
lean_object* v___x_2741_; lean_object* v___x_2742_; uint64_t v___x_2743_; uint64_t v___x_2744_; uint64_t v___x_2745_; lean_object* v___x_2746_; lean_object* v___x_2747_; lean_object* v___x_2748_; lean_object* v___x_2749_; lean_object* v___x_2750_; lean_object* v___x_2751_; lean_object* v___x_2752_; lean_object* v___x_2753_; lean_object* v___x_2754_; lean_object* v___x_2755_; lean_object* v___x_2756_; lean_object* v___x_2757_; lean_object* v___x_2758_; lean_object* v___x_2759_; lean_object* v___x_2760_; lean_object* v___x_2761_; lean_object* v___x_2762_; lean_object* v___x_2763_; lean_object* v___x_2764_; 
lean_inc_ref(v___y_2719_);
v___x_2741_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2741_, 0, v___y_2719_);
lean_ctor_set(v___x_2741_, 1, v___x_2740_);
v___x_2742_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__7));
v___x_2743_ = 7ULL;
v___x_2744_ = lp_Hex_List_foldl___at___00Hex_SignDetBench_MaximalMatrix_runSolve_spec__0(v___x_2743_, v___x_2708_);
lean_dec(v___x_2708_);
v___x_2745_ = lean_uint64_mix_hash(v___x_2744_, v___x_2735_);
v___x_2746_ = lean_uint64_to_nat(v___x_2745_);
v___x_2747_ = l_Lean_JsonNumber_fromNat(v___x_2746_);
v___x_2748_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2748_, 0, v___x_2747_);
v___x_2749_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2749_, 0, v___x_2742_);
lean_ctor_set(v___x_2749_, 1, v___x_2748_);
v___x_2750_ = lean_obj_once(&lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__12, &lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__12_once, _init_lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__12);
v___x_2751_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2751_, 0, v___x_2749_);
lean_ctor_set(v___x_2751_, 1, v___x_2750_);
v___x_2752_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2752_, 0, v___x_2741_);
lean_ctor_set(v___x_2752_, 1, v___x_2751_);
v___x_2753_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2753_, 0, v___y_2718_);
lean_ctor_set(v___x_2753_, 1, v___x_2752_);
v___x_2754_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2754_, 0, v___y_2721_);
lean_ctor_set(v___x_2754_, 1, v___x_2753_);
v___x_2755_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2755_, 0, v___y_2710_);
lean_ctor_set(v___x_2755_, 1, v___x_2754_);
v___x_2756_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2756_, 0, v___y_2725_);
lean_ctor_set(v___x_2756_, 1, v___x_2755_);
v___x_2757_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2757_, 0, v___y_2714_);
lean_ctor_set(v___x_2757_, 1, v___x_2756_);
v___x_2758_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2758_, 0, v___y_2723_);
lean_ctor_set(v___x_2758_, 1, v___x_2757_);
v___x_2759_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2759_, 0, v___y_2711_);
lean_ctor_set(v___x_2759_, 1, v___x_2758_);
v___x_2760_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2760_, 0, v___y_2720_);
lean_ctor_set(v___x_2760_, 1, v___x_2759_);
v___x_2761_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_2761_, 0, v___y_2715_);
lean_ctor_set(v___x_2761_, 1, v___x_2760_);
v___x_2762_ = l_Lean_Json_mkObj(v___x_2761_);
lean_dec_ref_known(v___x_2761_, 2);
v___x_2763_ = l_Lean_Json_compress(v___x_2762_);
v___x_2764_ = lp_lean_x2dbench_IO_println___at___00LeanBench_Cli_runListCmd_spec__0(v___x_2763_);
if (lean_obj_tag(v___x_2764_) == 0)
{
lean_object* v___x_2765_; lean_object* v_flush_2766_; lean_object* v___x_2767_; 
lean_dec_ref_known(v___x_2764_, 1);
v___x_2765_ = lean_get_stdout();
v_flush_2766_ = lean_ctor_get(v___x_2765_, 0);
lean_inc_ref(v_flush_2766_);
lean_dec_ref(v___x_2765_);
v___x_2767_ = lean_apply_1(v_flush_2766_, lean_box(0));
if (lean_obj_tag(v___x_2767_) == 0)
{
size_t v___x_2768_; size_t v___x_2769_; 
lean_dec_ref_known(v___x_2767_, 1);
v___x_2768_ = ((size_t)1ULL);
v___x_2769_ = lean_usize_add(v_i_2685_, v___x_2768_);
v_i_2685_ = v___x_2769_;
v_b_2686_ = v___x_2701_;
goto _start;
}
else
{
return v___x_2767_;
}
}
else
{
return v___x_2764_;
}
}
}
v___jp_2772_:
{
uint8_t v_isNeg_2791_; 
v_isNeg_2791_ = lean_int_dec_lt(v___y_2778_, v___x_2704_);
if (v_isNeg_2791_ == 0)
{
lean_object* v_a_2792_; lean_object* v___x_2793_; lean_object* v___x_2794_; uint64_t v___x_2795_; 
v_a_2792_ = lean_nat_abs(v___y_2778_);
lean_dec(v___y_2778_);
v___x_2793_ = lean_unsigned_to_nat(2u);
v___x_2794_ = lean_nat_mul(v___x_2793_, v_a_2792_);
lean_dec(v_a_2792_);
v___x_2795_ = lean_uint64_of_nat(v___x_2794_);
lean_dec(v___x_2794_);
v___y_2710_ = v___y_2773_;
v___y_2711_ = v___y_2774_;
v___y_2712_ = v___y_2775_;
v___y_2713_ = v___y_2776_;
v___y_2714_ = v___y_2777_;
v___y_2715_ = v___y_2779_;
v___y_2716_ = v___y_2790_;
v___y_2717_ = v___y_2780_;
v___y_2718_ = v___y_2781_;
v___y_2719_ = v___y_2782_;
v___y_2720_ = v___y_2783_;
v___y_2721_ = v___y_2784_;
v___y_2722_ = v___y_2785_;
v___y_2723_ = v___y_2786_;
v___y_2724_ = v___y_2787_;
v___y_2725_ = v___y_2788_;
v___y_2726_ = v___y_2789_;
v___y_2727_ = v___x_2795_;
goto v___jp_2709_;
}
else
{
lean_object* v_abs_2796_; lean_object* v_a_2797_; lean_object* v___x_2798_; lean_object* v___x_2799_; lean_object* v___x_2800_; uint64_t v___x_2801_; 
v_abs_2796_ = lean_nat_abs(v___y_2778_);
lean_dec(v___y_2778_);
v_a_2797_ = lean_nat_sub(v_abs_2796_, v___x_2702_);
lean_dec(v_abs_2796_);
v___x_2798_ = lean_unsigned_to_nat(2u);
v___x_2799_ = lean_nat_mul(v___x_2798_, v_a_2797_);
lean_dec(v_a_2797_);
v___x_2800_ = lean_nat_add(v___x_2799_, v___x_2702_);
lean_dec(v___x_2799_);
v___x_2801_ = lean_uint64_of_nat(v___x_2800_);
lean_dec(v___x_2800_);
v___y_2710_ = v___y_2773_;
v___y_2711_ = v___y_2774_;
v___y_2712_ = v___y_2775_;
v___y_2713_ = v___y_2776_;
v___y_2714_ = v___y_2777_;
v___y_2715_ = v___y_2779_;
v___y_2716_ = v___y_2790_;
v___y_2717_ = v___y_2780_;
v___y_2718_ = v___y_2781_;
v___y_2719_ = v___y_2782_;
v___y_2720_ = v___y_2783_;
v___y_2721_ = v___y_2784_;
v___y_2722_ = v___y_2785_;
v___y_2723_ = v___y_2786_;
v___y_2724_ = v___y_2787_;
v___y_2725_ = v___y_2788_;
v___y_2726_ = v___y_2789_;
v___y_2727_ = v___x_2801_;
goto v___jp_2709_;
}
}
v___jp_2802_:
{
uint64_t v___x_2821_; lean_object* v___x_2822_; uint8_t v___x_2823_; 
v___x_2821_ = 7ULL;
v___x_2822_ = lean_array_get_size(v___y_2815_);
v___x_2823_ = lean_nat_dec_lt(v___x_2703_, v___x_2822_);
if (v___x_2823_ == 0)
{
lean_dec_ref(v___y_2815_);
v___y_2773_ = v___y_2803_;
v___y_2774_ = v___y_2804_;
v___y_2775_ = v___y_2805_;
v___y_2776_ = v___y_2806_;
v___y_2777_ = v___y_2807_;
v___y_2778_ = v___y_2808_;
v___y_2779_ = v___y_2809_;
v___y_2780_ = v___y_2810_;
v___y_2781_ = v___y_2811_;
v___y_2782_ = v___y_2812_;
v___y_2783_ = v___y_2813_;
v___y_2784_ = v___y_2814_;
v___y_2785_ = v___y_2816_;
v___y_2786_ = v___y_2817_;
v___y_2787_ = v___y_2818_;
v___y_2788_ = v___y_2819_;
v___y_2789_ = v___y_2820_;
v___y_2790_ = v___x_2821_;
goto v___jp_2772_;
}
else
{
size_t v___x_2824_; size_t v___x_2825_; uint64_t v___x_2826_; 
v___x_2824_ = ((size_t)0ULL);
v___x_2825_ = lean_usize_of_nat(v___x_2822_);
v___x_2826_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v___y_2815_, v___x_2824_, v___x_2825_, v___x_2821_);
lean_dec_ref(v___y_2815_);
v___y_2773_ = v___y_2803_;
v___y_2774_ = v___y_2804_;
v___y_2775_ = v___y_2805_;
v___y_2776_ = v___y_2806_;
v___y_2777_ = v___y_2807_;
v___y_2778_ = v___y_2808_;
v___y_2779_ = v___y_2809_;
v___y_2780_ = v___y_2810_;
v___y_2781_ = v___y_2811_;
v___y_2782_ = v___y_2812_;
v___y_2783_ = v___y_2813_;
v___y_2784_ = v___y_2814_;
v___y_2785_ = v___y_2816_;
v___y_2786_ = v___y_2817_;
v___y_2787_ = v___y_2818_;
v___y_2788_ = v___y_2819_;
v___y_2789_ = v___y_2820_;
v___y_2790_ = v___x_2826_;
goto v___jp_2772_;
}
}
v___jp_2827_:
{
uint64_t v___x_2846_; lean_object* v___x_2847_; uint8_t v___x_2848_; 
v___x_2846_ = 7ULL;
v___x_2847_ = lean_array_get_size(v___y_2841_);
v___x_2848_ = lean_nat_dec_lt(v___x_2703_, v___x_2847_);
if (v___x_2848_ == 0)
{
lean_dec_ref(v___y_2841_);
v___y_2803_ = v___y_2828_;
v___y_2804_ = v___y_2829_;
v___y_2805_ = v___y_2830_;
v___y_2806_ = v___y_2831_;
v___y_2807_ = v___y_2832_;
v___y_2808_ = v___y_2833_;
v___y_2809_ = v___y_2834_;
v___y_2810_ = v___y_2845_;
v___y_2811_ = v___y_2835_;
v___y_2812_ = v___y_2836_;
v___y_2813_ = v___y_2837_;
v___y_2814_ = v___y_2838_;
v___y_2815_ = v___y_2839_;
v___y_2816_ = v___y_2840_;
v___y_2817_ = v___y_2842_;
v___y_2818_ = v___y_2843_;
v___y_2819_ = v___y_2844_;
v___y_2820_ = v___x_2846_;
goto v___jp_2802_;
}
else
{
size_t v___x_2849_; size_t v___x_2850_; uint64_t v___x_2851_; 
v___x_2849_ = ((size_t)0ULL);
v___x_2850_ = lean_usize_of_nat(v___x_2847_);
v___x_2851_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_certHash_spec__0(v___y_2841_, v___x_2849_, v___x_2850_, v___x_2846_);
lean_dec_ref(v___y_2841_);
v___y_2803_ = v___y_2828_;
v___y_2804_ = v___y_2829_;
v___y_2805_ = v___y_2830_;
v___y_2806_ = v___y_2831_;
v___y_2807_ = v___y_2832_;
v___y_2808_ = v___y_2833_;
v___y_2809_ = v___y_2834_;
v___y_2810_ = v___y_2845_;
v___y_2811_ = v___y_2835_;
v___y_2812_ = v___y_2836_;
v___y_2813_ = v___y_2837_;
v___y_2814_ = v___y_2838_;
v___y_2815_ = v___y_2839_;
v___y_2816_ = v___y_2840_;
v___y_2817_ = v___y_2842_;
v___y_2818_ = v___y_2843_;
v___y_2819_ = v___y_2844_;
v___y_2820_ = v___x_2851_;
goto v___jp_2802_;
}
}
v___jp_2852_:
{
uint64_t v___x_2871_; lean_object* v___x_2872_; uint8_t v___x_2873_; 
v___x_2871_ = 7ULL;
v___x_2872_ = lean_array_get_size(v___y_2863_);
v___x_2873_ = lean_nat_dec_lt(v___x_2703_, v___x_2872_);
if (v___x_2873_ == 0)
{
lean_dec_ref(v___y_2863_);
v___y_2828_ = v___y_2853_;
v___y_2829_ = v___y_2854_;
v___y_2830_ = v___y_2870_;
v___y_2831_ = v___y_2855_;
v___y_2832_ = v___y_2856_;
v___y_2833_ = v___y_2857_;
v___y_2834_ = v___y_2858_;
v___y_2835_ = v___y_2859_;
v___y_2836_ = v___y_2860_;
v___y_2837_ = v___y_2861_;
v___y_2838_ = v___y_2862_;
v___y_2839_ = v___y_2864_;
v___y_2840_ = v___y_2865_;
v___y_2841_ = v___y_2867_;
v___y_2842_ = v___y_2866_;
v___y_2843_ = v___y_2868_;
v___y_2844_ = v___y_2869_;
v___y_2845_ = v___x_2871_;
goto v___jp_2827_;
}
else
{
size_t v___x_2874_; size_t v___x_2875_; uint64_t v___x_2876_; 
v___x_2874_ = ((size_t)0ULL);
v___x_2875_ = lean_usize_of_nat(v___x_2872_);
v___x_2876_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33__spec__1(v___y_2863_, v___x_2874_, v___x_2875_, v___x_2871_);
lean_dec_ref(v___y_2863_);
v___y_2828_ = v___y_2853_;
v___y_2829_ = v___y_2854_;
v___y_2830_ = v___y_2870_;
v___y_2831_ = v___y_2855_;
v___y_2832_ = v___y_2856_;
v___y_2833_ = v___y_2857_;
v___y_2834_ = v___y_2858_;
v___y_2835_ = v___y_2859_;
v___y_2836_ = v___y_2860_;
v___y_2837_ = v___y_2861_;
v___y_2838_ = v___y_2862_;
v___y_2839_ = v___y_2864_;
v___y_2840_ = v___y_2865_;
v___y_2841_ = v___y_2867_;
v___y_2842_ = v___y_2866_;
v___y_2843_ = v___y_2868_;
v___y_2844_ = v___y_2869_;
v___y_2845_ = v___x_2876_;
goto v___jp_2827_;
}
}
v___jp_2877_:
{
lean_object* v___x_2888_; lean_object* v___x_2889_; lean_object* v___x_2890_; lean_object* v___x_2891_; lean_object* v___x_2892_; lean_object* v___x_2893_; lean_object* v___x_2894_; lean_object* v___x_2895_; lean_object* v___x_2896_; lean_object* v___x_2897_; lean_object* v___x_2898_; lean_object* v___x_2899_; lean_object* v___x_2900_; lean_object* v___x_2901_; lean_object* v___x_2902_; lean_object* v___x_2903_; lean_object* v___x_2904_; lean_object* v___x_2905_; lean_object* v___x_2906_; lean_object* v___x_2907_; lean_object* v___x_2908_; lean_object* v___x_2909_; lean_object* v___x_2910_; lean_object* v___x_2911_; lean_object* v___x_2912_; lean_object* v___x_2913_; lean_object* v___x_2914_; lean_object* v___x_2915_; lean_object* v___x_2916_; lean_object* v___x_2917_; lean_object* v___x_2918_; lean_object* v___x_2919_; lean_object* v___x_2920_; lean_object* v___x_2921_; lean_object* v___x_2922_; lean_object* v___x_2923_; lean_object* v___x_2924_; lean_object* v___x_2925_; lean_object* v___x_2926_; lean_object* v___x_2927_; lean_object* v___x_2928_; lean_object* v___x_2929_; lean_object* v___x_2930_; lean_object* v___x_2931_; uint64_t v___x_2932_; uint64_t v___x_2933_; uint64_t v___x_2934_; uint64_t v___x_2935_; lean_object* v___x_2936_; uint8_t v___x_2937_; 
v___x_2888_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__13));
lean_inc(v_a_2693_);
v___x_2889_ = l_Lean_JsonNumber_fromNat(v_a_2693_);
v___x_2890_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2890_, 0, v___x_2889_);
v___x_2891_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2891_, 0, v___x_2888_);
lean_ctor_set(v___x_2891_, 1, v___x_2890_);
v___x_2892_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__14));
lean_inc_n(v___y_2884_, 3);
v___x_2893_ = l_Lean_JsonNumber_fromNat(v___y_2884_);
v___x_2894_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2894_, 0, v___x_2893_);
v___x_2895_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2895_, 0, v___x_2892_);
lean_ctor_set(v___x_2895_, 1, v___x_2894_);
v___x_2896_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__15));
lean_inc_ref(v_counts_2880_);
v___x_2897_ = lean_array_to_list(v_counts_2880_);
v___x_2898_ = l_List_lengthTR___redArg(v___x_2897_);
v___x_2899_ = l_Lean_JsonNumber_fromNat(v___x_2898_);
v___x_2900_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2900_, 0, v___x_2899_);
v___x_2901_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2901_, 0, v___x_2896_);
lean_ctor_set(v___x_2901_, 1, v___x_2900_);
v___x_2902_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__16));
v___x_2903_ = lp_Hex_List_sum___at___00Hex_SignDet_moments_spec__1(v___x_2897_);
lean_dec(v___x_2897_);
v___x_2904_ = l_Lean_JsonNumber_fromInt(v___x_2903_);
v___x_2905_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2905_, 0, v___x_2904_);
v___x_2906_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2906_, 0, v___x_2902_);
lean_ctor_set(v___x_2906_, 1, v___x_2905_);
v___x_2907_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__17));
v___x_2908_ = lean_unsigned_to_nat(3u);
v___x_2909_ = lean_nat_pow(v___y_2884_, v___x_2908_);
v___x_2910_ = l_Lean_JsonNumber_fromNat(v___x_2909_);
v___x_2911_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2911_, 0, v___x_2910_);
v___x_2912_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2912_, 0, v___x_2907_);
lean_ctor_set(v___x_2912_, 1, v___x_2911_);
v___x_2913_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__18));
v___x_2914_ = l_Lean_JsonNumber_fromNat(v___y_2887_);
v___x_2915_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2915_, 0, v___x_2914_);
v___x_2916_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2916_, 0, v___x_2913_);
lean_ctor_set(v___x_2916_, 1, v___x_2915_);
v___x_2917_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__19));
v___x_2918_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_bits(v_denominator_2883_);
v___x_2919_ = l_Lean_JsonNumber_fromNat(v___x_2918_);
v___x_2920_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2920_, 0, v___x_2919_);
v___x_2921_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2921_, 0, v___x_2917_);
lean_ctor_set(v___x_2921_, 1, v___x_2920_);
v___x_2922_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__20));
lean_inc_ref(v_values_2881_);
v___x_2923_ = lean_array_to_list(v_values_2881_);
v___x_2924_ = lp_Hex_List_foldl___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__2(v___x_2703_, v___x_2923_);
lean_dec(v___x_2923_);
v___x_2925_ = l_Lean_JsonNumber_fromNat(v___x_2924_);
v___x_2926_ = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(v___x_2926_, 0, v___x_2925_);
v___x_2927_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2927_, 0, v___x_2922_);
lean_ctor_set(v___x_2927_, 1, v___x_2926_);
v___x_2928_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__21));
v___x_2929_ = lp_Hex_Lean_Option_toJson___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__3(v___y_2885_);
lean_dec(v___y_2885_);
v___x_2930_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_2930_, 0, v___x_2928_);
lean_ctor_set(v___x_2930_, 1, v___x_2929_);
v___x_2931_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__22));
v___x_2932_ = lp_Hex_Hex_SignDetBench_matrixHash(v___y_2884_, v___y_2884_, v_inverse_2882_);
v___x_2933_ = lean_uint64_of_nat(v___y_2886_);
lean_dec(v___y_2886_);
v___x_2934_ = lean_uint64_of_nat(v___y_2884_);
lean_dec(v___y_2884_);
v___x_2935_ = 7ULL;
v___x_2936_ = lean_array_get_size(v_rows_2878_);
v___x_2937_ = lean_nat_dec_lt(v___x_2703_, v___x_2936_);
if (v___x_2937_ == 0)
{
lean_dec_ref(v_rows_2878_);
v___y_2853_ = v___x_2921_;
v___y_2854_ = v___x_2901_;
v___y_2855_ = v___x_2932_;
v___y_2856_ = v___x_2912_;
v___y_2857_ = v_denominator_2883_;
v___y_2858_ = v___x_2891_;
v___y_2859_ = v___x_2930_;
v___y_2860_ = v___x_2931_;
v___y_2861_ = v___x_2895_;
v___y_2862_ = v___x_2927_;
v___y_2863_ = v_columns_2879_;
v___y_2864_ = v_values_2881_;
v___y_2865_ = v___x_2934_;
v___y_2866_ = v___x_2906_;
v___y_2867_ = v_counts_2880_;
v___y_2868_ = v___x_2933_;
v___y_2869_ = v___x_2916_;
v___y_2870_ = v___x_2935_;
goto v___jp_2852_;
}
else
{
size_t v___x_2938_; size_t v___x_2939_; uint64_t v___x_2940_; 
v___x_2938_ = ((size_t)0ULL);
v___x_2939_ = lean_usize_of_nat(v___x_2936_);
v___x_2940_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_Input_0__Hex_SignDetBench_nodeHash_spec__7(v_rows_2878_, v___x_2938_, v___x_2939_, v___x_2935_);
lean_dec_ref(v_rows_2878_);
v___y_2853_ = v___x_2921_;
v___y_2854_ = v___x_2901_;
v___y_2855_ = v___x_2932_;
v___y_2856_ = v___x_2912_;
v___y_2857_ = v_denominator_2883_;
v___y_2858_ = v___x_2891_;
v___y_2859_ = v___x_2930_;
v___y_2860_ = v___x_2931_;
v___y_2861_ = v___x_2895_;
v___y_2862_ = v___x_2927_;
v___y_2863_ = v_columns_2879_;
v___y_2864_ = v_values_2881_;
v___y_2865_ = v___x_2934_;
v___y_2866_ = v___x_2906_;
v___y_2867_ = v_counts_2880_;
v___y_2868_ = v___x_2933_;
v___y_2869_ = v___x_2916_;
v___y_2870_ = v___x_2940_;
goto v___jp_2852_;
}
}
v___jp_2941_:
{
lean_object* v_system_2943_; lean_object* v_arity_2944_; lean_object* v_size_2945_; lean_object* v_rows_2946_; lean_object* v_columns_2947_; lean_object* v_counts_2948_; lean_object* v_values_2949_; lean_object* v_inverse_2950_; lean_object* v_denominator_2951_; lean_object* v___x_2952_; lean_object* v___x_2953_; uint8_t v___x_2954_; 
v_system_2943_ = lean_ctor_get(v_a_2695_, 2);
lean_inc_ref(v_system_2943_);
v_arity_2944_ = lean_ctor_get(v_a_2695_, 0);
lean_inc(v_arity_2944_);
v_size_2945_ = lean_ctor_get(v_a_2695_, 1);
lean_inc_n(v_size_2945_, 3);
lean_dec(v_a_2695_);
v_rows_2946_ = lean_ctor_get(v_system_2943_, 0);
lean_inc_ref(v_rows_2946_);
v_columns_2947_ = lean_ctor_get(v_system_2943_, 1);
lean_inc_ref(v_columns_2947_);
v_counts_2948_ = lean_ctor_get(v_system_2943_, 2);
lean_inc_ref(v_counts_2948_);
v_values_2949_ = lean_ctor_get(v_system_2943_, 3);
lean_inc_ref(v_values_2949_);
v_inverse_2950_ = lean_ctor_get(v_system_2943_, 4);
lean_inc_ref_n(v_inverse_2950_, 2);
v_denominator_2951_ = lean_ctor_get(v_system_2943_, 5);
lean_inc(v_denominator_2951_);
lean_dec_ref(v_system_2943_);
v___x_2952_ = lp_Hex_Hex_Matrix_rows___redArg(v_size_2945_, v_size_2945_, v_inverse_2950_);
v___x_2953_ = lean_array_get_size(v___x_2952_);
v___x_2954_ = lean_nat_dec_lt(v___x_2703_, v___x_2953_);
if (v___x_2954_ == 0)
{
lean_dec_ref(v___x_2952_);
v_rows_2878_ = v_rows_2946_;
v_columns_2879_ = v_columns_2947_;
v_counts_2880_ = v_counts_2948_;
v_values_2881_ = v_values_2949_;
v_inverse_2882_ = v_inverse_2950_;
v_denominator_2883_ = v_denominator_2951_;
v___y_2884_ = v_size_2945_;
v___y_2885_ = v_matchesPolynomial_2942_;
v___y_2886_ = v_arity_2944_;
v___y_2887_ = v___x_2703_;
goto v___jp_2877_;
}
else
{
uint8_t v___x_2955_; 
v___x_2955_ = lean_nat_dec_le(v___x_2953_, v___x_2953_);
if (v___x_2955_ == 0)
{
if (v___x_2954_ == 0)
{
lean_dec_ref(v___x_2952_);
v_rows_2878_ = v_rows_2946_;
v_columns_2879_ = v_columns_2947_;
v_counts_2880_ = v_counts_2948_;
v_values_2881_ = v_values_2949_;
v_inverse_2882_ = v_inverse_2950_;
v_denominator_2883_ = v_denominator_2951_;
v___y_2884_ = v_size_2945_;
v___y_2885_ = v_matchesPolynomial_2942_;
v___y_2886_ = v_arity_2944_;
v___y_2887_ = v___x_2703_;
goto v___jp_2877_;
}
else
{
size_t v___x_2956_; size_t v___x_2957_; lean_object* v___x_2958_; 
v___x_2956_ = ((size_t)0ULL);
v___x_2957_ = lean_usize_of_nat(v___x_2953_);
v___x_2958_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__4(v___x_2952_, v___x_2956_, v___x_2957_, v___x_2703_);
lean_dec_ref(v___x_2952_);
v_rows_2878_ = v_rows_2946_;
v_columns_2879_ = v_columns_2947_;
v_counts_2880_ = v_counts_2948_;
v_values_2881_ = v_values_2949_;
v_inverse_2882_ = v_inverse_2950_;
v_denominator_2883_ = v_denominator_2951_;
v___y_2884_ = v_size_2945_;
v___y_2885_ = v_matchesPolynomial_2942_;
v___y_2886_ = v_arity_2944_;
v___y_2887_ = v___x_2958_;
goto v___jp_2877_;
}
}
else
{
size_t v___x_2959_; size_t v___x_2960_; lean_object* v___x_2961_; 
v___x_2959_ = ((size_t)0ULL);
v___x_2960_ = lean_usize_of_nat(v___x_2953_);
v___x_2961_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_foldlMUnsafe_fold___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__4(v___x_2952_, v___x_2959_, v___x_2960_, v___x_2703_);
lean_dec_ref(v___x_2952_);
v_rows_2878_ = v_rows_2946_;
v_columns_2879_ = v_columns_2947_;
v_counts_2880_ = v_counts_2948_;
v_values_2881_ = v_values_2949_;
v_inverse_2882_ = v_inverse_2950_;
v_denominator_2883_ = v_denominator_2951_;
v___y_2884_ = v_size_2945_;
v___y_2885_ = v_matchesPolynomial_2942_;
v___y_2886_ = v_arity_2944_;
v___y_2887_ = v___x_2961_;
goto v___jp_2877_;
}
}
}
v___jp_2962_:
{
if (v___y_2964_ == 0)
{
lean_dec(v___x_2708_);
lean_del_object(v___x_2697_);
lean_dec(v_a_2695_);
goto v___jp_2688_;
}
else
{
if (v___y_2965_ == 0)
{
lean_dec(v___x_2708_);
lean_del_object(v___x_2697_);
lean_dec(v_a_2695_);
goto v___jp_2688_;
}
else
{
lean_object* v___x_2966_; lean_object* v___x_2967_; 
v___x_2966_ = lean_box(v___y_2963_);
v___x_2967_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2967_, 0, v___x_2966_);
v_matchesPolynomial_2942_ = v___x_2967_;
goto v___jp_2941_;
}
}
}
v___jp_2968_:
{
if (v___y_2970_ == 0)
{
v___y_2963_ = v___y_2969_;
v___y_2964_ = v___y_2971_;
v___y_2965_ = v___y_2970_;
goto v___jp_2962_;
}
else
{
v___y_2963_ = v___y_2969_;
v___y_2964_ = v___y_2971_;
v___y_2965_ = v___y_2972_;
goto v___jp_2962_;
}
}
v___jp_2973_:
{
if (v___y_2974_ == 0)
{
v___y_2969_ = v___y_2975_;
v___y_2970_ = v___y_2976_;
v___y_2971_ = v___y_2977_;
v___y_2972_ = v___y_2974_;
goto v___jp_2968_;
}
else
{
v___y_2969_ = v___y_2975_;
v___y_2970_ = v___y_2976_;
v___y_2971_ = v___y_2977_;
v___y_2972_ = v___y_2978_;
goto v___jp_2968_;
}
}
v___jp_2979_:
{
if (v___y_2984_ == 0)
{
v___y_2974_ = v___y_2980_;
v___y_2975_ = v___y_2981_;
v___y_2976_ = v___y_2982_;
v___y_2977_ = v___y_2983_;
v___y_2978_ = v___y_2984_;
goto v___jp_2973_;
}
else
{
v___y_2974_ = v___y_2980_;
v___y_2975_ = v___y_2981_;
v___y_2976_ = v___y_2982_;
v___y_2977_ = v___y_2983_;
v___y_2978_ = v___y_2985_;
goto v___jp_2973_;
}
}
v___jp_2986_:
{
if (v___y_2987_ == 0)
{
lean_object* v___x_2988_; lean_object* v___x_2989_; lean_object* v___x_2990_; lean_object* v___x_2991_; lean_object* v___x_2992_; 
lean_dec(v___x_2708_);
lean_del_object(v___x_2697_);
lean_dec(v_a_2695_);
v___x_2988_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__23));
lean_inc(v_a_2693_);
v___x_2989_ = l_Nat_reprFast(v_a_2693_);
v___x_2990_ = lean_string_append(v___x_2988_, v___x_2989_);
lean_dec_ref(v___x_2989_);
v___x_2991_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_2991_, 0, v___x_2990_);
v___x_2992_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2992_, 0, v___x_2991_);
return v___x_2992_;
}
else
{
lean_object* v___x_2993_; uint8_t v___x_2994_; 
v___x_2993_ = lean_unsigned_to_nat(3u);
v___x_2994_ = lean_nat_dec_le(v_a_2693_, v___x_2993_);
if (v___x_2994_ == 0)
{
lean_object* v___x_2995_; 
v___x_2995_ = lean_box(0);
v_matchesPolynomial_2942_ = v___x_2995_;
goto v___jp_2941_;
}
else
{
lean_object* v___x_2996_; 
lean_inc(v_a_2693_);
v___x_2996_ = lp_Hex_Hex_SignDetBench_buildMaximal(v_a_2693_);
if (lean_obj_tag(v___x_2996_) == 1)
{
lean_object* v_a_2997_; lean_object* v___x_2999_; uint8_t v_isShared_3000_; uint8_t v_isSharedCheck_3051_; 
v_a_2997_ = lean_ctor_get(v___x_2996_, 0);
v_isSharedCheck_3051_ = !lean_is_exclusive(v___x_2996_);
if (v_isSharedCheck_3051_ == 0)
{
v___x_2999_ = v___x_2996_;
v_isShared_3000_ = v_isSharedCheck_3051_;
goto v_resetjp_2998_;
}
else
{
lean_inc(v_a_2997_);
lean_dec(v___x_2996_);
v___x_2999_ = lean_box(0);
v_isShared_3000_ = v_isSharedCheck_3051_;
goto v_resetjp_2998_;
}
v_resetjp_2998_:
{
lean_object* v_domain_3001_; 
v_domain_3001_ = lean_ctor_get(v_a_2997_, 2);
lean_inc(v_domain_3001_);
if (lean_obj_tag(v_domain_3001_) == 1)
{
lean_object* v_queries_3002_; lean_object* v_val_3003_; lean_object* v___x_3005_; uint8_t v_isShared_3006_; uint8_t v_isSharedCheck_3046_; 
lean_del_object(v___x_2999_);
v_queries_3002_ = lean_ctor_get(v_a_2997_, 1);
lean_inc(v_queries_3002_);
lean_dec(v_a_2997_);
v_val_3003_ = lean_ctor_get(v_domain_3001_, 0);
v_isSharedCheck_3046_ = !lean_is_exclusive(v_domain_3001_);
if (v_isSharedCheck_3046_ == 0)
{
v___x_3005_ = v_domain_3001_;
v_isShared_3006_ = v_isSharedCheck_3046_;
goto v_resetjp_3004_;
}
else
{
lean_inc(v_val_3003_);
lean_dec(v_domain_3001_);
v___x_3005_ = lean_box(0);
v_isShared_3006_ = v_isSharedCheck_3046_;
goto v_resetjp_3004_;
}
v_resetjp_3004_:
{
lean_object* v___x_3007_; lean_object* v___x_3008_; 
v___x_3007_ = lean_unsigned_to_nat(10377u);
v___x_3008_ = lp_Hex_Hex_SignDet_referencePrepared___at___00Hex_SignDetBench_buildMaximal_spec__10___redArg(v___x_3007_, v_val_3003_, v_queries_3002_);
if (lean_obj_tag(v___x_3008_) == 1)
{
lean_object* v_a_3009_; lean_object* v___x_3011_; uint8_t v_isShared_3012_; uint8_t v_isSharedCheck_3041_; 
lean_del_object(v___x_3005_);
v_a_3009_ = lean_ctor_get(v___x_3008_, 0);
v_isSharedCheck_3041_ = !lean_is_exclusive(v___x_3008_);
if (v_isSharedCheck_3041_ == 0)
{
v___x_3011_ = v___x_3008_;
v_isShared_3012_ = v_isSharedCheck_3041_;
goto v_resetjp_3010_;
}
else
{
lean_inc(v_a_3009_);
lean_dec(v___x_3008_);
v___x_3011_ = lean_box(0);
v_isShared_3012_ = v_isSharedCheck_3041_;
goto v_resetjp_3010_;
}
v_resetjp_3010_:
{
lean_object* v_size_3013_; lean_object* v_system_3014_; lean_object* v_size_3015_; lean_object* v_system_3016_; uint8_t v___x_3017_; 
v_size_3013_ = lean_ctor_get(v_a_3009_, 5);
lean_inc(v_size_3013_);
v_system_3014_ = lean_ctor_get(v_a_3009_, 6);
lean_inc_ref(v_system_3014_);
lean_dec(v_a_3009_);
v_size_3015_ = lean_ctor_get(v_a_2695_, 1);
v_system_3016_ = lean_ctor_get(v_a_2695_, 2);
v___x_3017_ = lean_nat_dec_eq(v_size_3013_, v_size_3015_);
lean_dec(v_size_3013_);
if (v___x_3017_ == 0)
{
lean_object* v___x_3018_; lean_object* v___x_3020_; 
lean_dec_ref(v_system_3014_);
lean_dec(v___x_2708_);
lean_del_object(v___x_2697_);
lean_dec(v_a_2695_);
v___x_3018_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__25));
if (v_isShared_3012_ == 0)
{
lean_ctor_set(v___x_3011_, 0, v___x_3018_);
v___x_3020_ = v___x_3011_;
goto v_reusejp_3019_;
}
else
{
lean_object* v_reuseFailAlloc_3021_; 
v_reuseFailAlloc_3021_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3021_, 0, v___x_3018_);
v___x_3020_ = v_reuseFailAlloc_3021_;
goto v_reusejp_3019_;
}
v_reusejp_3019_:
{
return v___x_3020_;
}
}
else
{
lean_object* v_rows_3022_; lean_object* v_columns_3023_; lean_object* v_counts_3024_; lean_object* v_values_3025_; lean_object* v_inverse_3026_; lean_object* v_denominator_3027_; lean_object* v_rows_3028_; lean_object* v_columns_3029_; lean_object* v_counts_3030_; lean_object* v_values_3031_; lean_object* v_inverse_3032_; lean_object* v_denominator_3033_; uint8_t v___x_3034_; uint8_t v___x_3035_; lean_object* v___x_3036_; uint8_t v___x_3037_; uint8_t v___x_3038_; uint8_t v___x_3039_; 
lean_del_object(v___x_3011_);
v_rows_3022_ = lean_ctor_get(v_system_3014_, 0);
lean_inc_ref(v_rows_3022_);
v_columns_3023_ = lean_ctor_get(v_system_3014_, 1);
lean_inc_ref(v_columns_3023_);
v_counts_3024_ = lean_ctor_get(v_system_3014_, 2);
lean_inc_ref(v_counts_3024_);
v_values_3025_ = lean_ctor_get(v_system_3014_, 3);
lean_inc_ref(v_values_3025_);
v_inverse_3026_ = lean_ctor_get(v_system_3014_, 4);
lean_inc_ref(v_inverse_3026_);
v_denominator_3027_ = lean_ctor_get(v_system_3014_, 5);
lean_inc(v_denominator_3027_);
lean_dec_ref(v_system_3014_);
v_rows_3028_ = lean_ctor_get(v_system_3016_, 0);
v_columns_3029_ = lean_ctor_get(v_system_3016_, 1);
v_counts_3030_ = lean_ctor_get(v_system_3016_, 2);
v_values_3031_ = lean_ctor_get(v_system_3016_, 3);
v_inverse_3032_ = lean_ctor_get(v_system_3016_, 4);
v_denominator_3033_ = lean_ctor_get(v_system_3016_, 5);
v___x_3034_ = l_Array_instDecidableEqImpl___redArg(v___f_2699_, v_rows_3022_, v_rows_3028_);
lean_dec_ref(v_rows_3022_);
v___x_3035_ = l_Array_instDecidableEqImpl___redArg(v___f_2700_, v_columns_3023_, v_columns_3029_);
lean_dec_ref(v_columns_3023_);
v___x_3036_ = lean_alloc_closure((void*)(l_Int_instDecidableEq___boxed), 2, 0);
lean_inc_ref_n(v___x_3036_, 2);
v___x_3037_ = l_Array_instDecidableEqImpl___redArg(v___x_3036_, v_counts_3024_, v_counts_3030_);
lean_dec_ref(v_counts_3024_);
v___x_3038_ = l_Array_instDecidableEqImpl___redArg(v___x_3036_, v_values_3025_, v_values_3031_);
lean_dec_ref(v_values_3025_);
v___x_3039_ = l_Array_instDecidableEqImpl___redArg(v___x_3036_, v_inverse_3026_, v_inverse_3032_);
lean_dec_ref(v_inverse_3026_);
if (v___x_3039_ == 0)
{
lean_dec(v_denominator_3027_);
v___y_2980_ = v___x_3037_;
v___y_2981_ = v___x_3017_;
v___y_2982_ = v___x_3035_;
v___y_2983_ = v___x_3034_;
v___y_2984_ = v___x_3038_;
v___y_2985_ = v___x_3039_;
goto v___jp_2979_;
}
else
{
uint8_t v___x_3040_; 
v___x_3040_ = lean_int_dec_eq(v_denominator_3027_, v_denominator_3033_);
lean_dec(v_denominator_3027_);
v___y_2980_ = v___x_3037_;
v___y_2981_ = v___x_3017_;
v___y_2982_ = v___x_3035_;
v___y_2983_ = v___x_3034_;
v___y_2984_ = v___x_3038_;
v___y_2985_ = v___x_3040_;
goto v___jp_2979_;
}
}
}
}
else
{
lean_object* v___x_3042_; lean_object* v___x_3044_; 
lean_dec(v___x_3008_);
lean_dec(v___x_2708_);
lean_del_object(v___x_2697_);
lean_dec(v_a_2695_);
v___x_3042_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__27));
if (v_isShared_3006_ == 0)
{
lean_ctor_set(v___x_3005_, 0, v___x_3042_);
v___x_3044_ = v___x_3005_;
goto v_reusejp_3043_;
}
else
{
lean_object* v_reuseFailAlloc_3045_; 
v_reuseFailAlloc_3045_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3045_, 0, v___x_3042_);
v___x_3044_ = v_reuseFailAlloc_3045_;
goto v_reusejp_3043_;
}
v_reusejp_3043_:
{
return v___x_3044_;
}
}
}
}
else
{
lean_object* v___x_3047_; lean_object* v___x_3049_; 
lean_dec(v_domain_3001_);
lean_dec(v_a_2997_);
lean_dec(v___x_2708_);
lean_del_object(v___x_2697_);
lean_dec(v_a_2695_);
v___x_3047_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__29));
if (v_isShared_3000_ == 0)
{
lean_ctor_set(v___x_2999_, 0, v___x_3047_);
v___x_3049_ = v___x_2999_;
goto v_reusejp_3048_;
}
else
{
lean_object* v_reuseFailAlloc_3050_; 
v_reuseFailAlloc_3050_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3050_, 0, v___x_3047_);
v___x_3049_ = v_reuseFailAlloc_3050_;
goto v_reusejp_3048_;
}
v_reusejp_3048_:
{
return v___x_3049_;
}
}
}
}
else
{
lean_object* v___x_3052_; lean_object* v___x_3053_; 
lean_dec_ref(v___x_2996_);
lean_dec(v___x_2708_);
lean_del_object(v___x_2697_);
lean_dec(v_a_2695_);
v___x_3052_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__31));
v___x_3053_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3053_, 0, v___x_3052_);
return v___x_3053_;
}
}
}
}
}
}
else
{
lean_object* v___x_3063_; lean_object* v___x_3064_; lean_object* v___x_3065_; lean_object* v___x_3066_; lean_object* v___x_3067_; 
lean_dec_ref(v___x_2694_);
v___x_3063_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__32));
lean_inc(v_a_2693_);
v___x_3064_ = l_Nat_reprFast(v_a_2693_);
v___x_3065_ = lean_string_append(v___x_3063_, v___x_3064_);
lean_dec_ref(v___x_3064_);
v___x_3066_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_3066_, 0, v___x_3065_);
v___x_3067_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_3067_, 0, v___x_3066_);
return v___x_3067_;
}
}
v___jp_2688_:
{
lean_object* v___x_2689_; lean_object* v___x_2690_; 
v___x_2689_ = ((lean_object*)(lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___closed__1));
v___x_2690_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_2690_, 0, v___x_2689_);
return v___x_2690_;
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6___boxed(lean_object* v_as_3068_, lean_object* v_sz_3069_, lean_object* v_i_3070_, lean_object* v_b_3071_, lean_object* v___y_3072_){
_start:
{
size_t v_sz_boxed_3073_; size_t v_i_boxed_3074_; lean_object* v_res_3075_; 
v_sz_boxed_3073_ = lean_unbox_usize(v_sz_3069_);
lean_dec(v_sz_3069_);
v_i_boxed_3074_ = lean_unbox_usize(v_i_3070_);
lean_dec(v_i_3070_);
v_res_3075_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6(v_as_3068_, v_sz_boxed_3073_, v_i_boxed_3074_, v_b_3071_);
lean_dec_ref(v_as_3068_);
return v_res_3075_;
}
}
static lean_object* _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor___boxed__const__1(void){
_start:
{
uint32_t v___x_3076_; lean_object* v___x_3077_; 
v___x_3076_ = 0;
v___x_3077_ = lean_box_uint32(v___x_3076_);
return v___x_3077_;
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor(lean_object* v_arities_3078_){
_start:
{
lean_object* v___x_3080_; size_t v_sz_3081_; size_t v___x_3082_; lean_object* v___x_3083_; 
v___x_3080_ = lean_box(0);
v_sz_3081_ = lean_array_size(v_arities_3078_);
v___x_3082_ = ((size_t)0ULL);
v___x_3083_ = lp_Hex___private_Init_Data_Array_Basic_0__Array_forIn_x27Unsafe_loop___at___00__private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor_spec__6(v_arities_3078_, v_sz_3081_, v___x_3082_, v___x_3080_);
if (lean_obj_tag(v___x_3083_) == 0)
{
lean_object* v___x_3085_; uint8_t v_isShared_3086_; uint8_t v_isSharedCheck_3091_; 
v_isSharedCheck_3091_ = !lean_is_exclusive(v___x_3083_);
if (v_isSharedCheck_3091_ == 0)
{
lean_object* v_unused_3092_; 
v_unused_3092_ = lean_ctor_get(v___x_3083_, 0);
lean_dec(v_unused_3092_);
v___x_3085_ = v___x_3083_;
v_isShared_3086_ = v_isSharedCheck_3091_;
goto v_resetjp_3084_;
}
else
{
lean_dec(v___x_3083_);
v___x_3085_ = lean_box(0);
v_isShared_3086_ = v_isSharedCheck_3091_;
goto v_resetjp_3084_;
}
v_resetjp_3084_:
{
lean_object* v___x_3087_; lean_object* v___x_3089_; 
v___x_3087_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor___boxed__const__1;
if (v_isShared_3086_ == 0)
{
lean_ctor_set(v___x_3085_, 0, v___x_3087_);
v___x_3089_ = v___x_3085_;
goto v_reusejp_3088_;
}
else
{
lean_object* v_reuseFailAlloc_3090_; 
v_reuseFailAlloc_3090_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3090_, 0, v___x_3087_);
v___x_3089_ = v_reuseFailAlloc_3090_;
goto v_reusejp_3088_;
}
v_reusejp_3088_:
{
return v___x_3089_;
}
}
}
else
{
lean_object* v_a_3093_; lean_object* v___x_3095_; uint8_t v_isShared_3096_; uint8_t v_isSharedCheck_3100_; 
v_a_3093_ = lean_ctor_get(v___x_3083_, 0);
v_isSharedCheck_3100_ = !lean_is_exclusive(v___x_3083_);
if (v_isSharedCheck_3100_ == 0)
{
v___x_3095_ = v___x_3083_;
v_isShared_3096_ = v_isSharedCheck_3100_;
goto v_resetjp_3094_;
}
else
{
lean_inc(v_a_3093_);
lean_dec(v___x_3083_);
v___x_3095_ = lean_box(0);
v_isShared_3096_ = v_isSharedCheck_3100_;
goto v_resetjp_3094_;
}
v_resetjp_3094_:
{
lean_object* v___x_3098_; 
if (v_isShared_3096_ == 0)
{
v___x_3098_ = v___x_3095_;
goto v_reusejp_3097_;
}
else
{
lean_object* v_reuseFailAlloc_3099_; 
v_reuseFailAlloc_3099_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_3099_, 0, v_a_3093_);
v___x_3098_ = v_reuseFailAlloc_3099_;
goto v_reusejp_3097_;
}
v_reusejp_3097_:
{
return v___x_3098_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor___boxed(lean_object* v_arities_3101_, lean_object* v_a_3102_){
_start:
{
lean_object* v_res_3103_; 
v_res_3103_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor(v_arities_3101_);
lean_dec_ref(v_arities_3101_);
return v_res_3103_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_inspect(){
_start:
{
lean_object* v___x_3105_; lean_object* v___x_3106_; lean_object* v___x_3107_; lean_object* v___x_3108_; 
v___x_3105_ = lean_unsigned_to_nat(5u);
v___x_3106_ = lean_mk_empty_array_with_capacity(v___x_3105_);
lean_dec_ref(v___x_3106_);
v___x_3107_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config___closed__4));
v___x_3108_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor(v___x_3107_);
return v___x_3108_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_inspect___boxed(lean_object* v_a_3109_){
_start:
{
lean_object* v_res_3110_; 
v_res_3110_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_inspect();
return v_res_3110_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_inspectDimension(){
_start:
{
lean_object* v___x_3112_; lean_object* v___x_3113_; lean_object* v___x_3114_; lean_object* v___x_3115_; 
v___x_3112_ = lean_unsigned_to_nat(6u);
v___x_3113_ = lean_mk_empty_array_with_capacity(v___x_3112_);
lean_dec_ref(v___x_3113_);
v___x_3114_ = ((lean_object*)(lp_Hex_Hex_SignDetBench_MaximalMatrix_dimensionInput___closed__0));
v___x_3115_ = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor(v___x_3114_);
return v___x_3115_;
}
}
LEAN_EXPORT lean_object* lp_Hex_Hex_SignDetBench_MaximalMatrix_inspectDimension___boxed(lean_object* v_a_3116_){
_start:
{
lean_object* v_res_3117_; 
v_res_3117_ = lp_Hex_Hex_SignDetBench_MaximalMatrix_inspectDimension();
return v_res_3117_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Hex_HexSignDet_Maximal(uint8_t builtin);
lean_object* initialize_lean_x2dbench_LeanBench(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Hex_HexSignDet_MaximalMatrix(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Hex_HexSignDet_Maximal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_lean_x2dbench_LeanBench(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config = _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config();
lean_mark_persistent(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolve___leanBench__config);
res = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_33_();
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_3572643847____hygCtx___hyg_37_();
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__config = _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__config();
lean_mark_persistent(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheck___leanBench__config);
res = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_33_();
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_272802029____hygCtx___hyg_37_();
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config = _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config();
lean_mark_persistent(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runSolveDimension___leanBench__config);
res = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_33_();
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_891062652____hygCtx___hyg_37_();
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__config = _init_lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__config();
lean_mark_persistent(lp_Hex_Hex_SignDetBench_MaximalMatrix_Hex_SignDetBench_MaximalMatrix_runCheckDimension___leanBench__config);
res = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_33_();
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_initFn_00___x40_HexSignDet_MaximalMatrix_4121739286____hygCtx___hyg_37_();
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor___boxed__const__1 = _init_lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor___boxed__const__1();
lean_mark_persistent(lp_Hex___private_HexSignDet_MaximalMatrix_0__Hex_SignDetBench_MaximalMatrix_inspectFor___boxed__const__1);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
