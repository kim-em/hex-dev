import HexRCF.RealCoefficients.SourceBuild
import HexRCF.RealCoefficients.SourceIdentity
import HexRealClosure.NumberFieldTower
import HexSignDet.Codec.Bytes

namespace BoundedSourceProbe
open Hex Hex.RealClosure Hex.SignDet Hex.RCF.RealCoefficients

def registry : BaseContext.Registry := fun _ => none
abbrev base := NumberField.base registry
def poly (values : List Rat) : base.Poly :=
  DensePoly.ofCoeffs (values.toArray.map fun value => ⟨value⟩)
def window (square : DyadicSquare) : base.Poly :=
  DensePoly.ofCoeffs ((SourceIdentity.margin square).coeffs.map fun value => ⟨value⟩)

def propose (polynomial : base.Poly) (square : DyadicSquare) :
    Except String (SourceBuild.Result base) := do
  let center := square.re.toRat
  let radius := 2 * square.halfWidth.toRat
  let raw : RawDescriptor base.Value Tower.Signature :=
    ⟨base.signature, polynomial, .finite ⟨center-radius⟩, .finite ⟨center+radius⟩, [], []⟩
  let root ← match Descriptor.build base.sign base.signature raw with
    | .error error => .error s!"production:{repr error}"
    | .ok (.error error) => .error s!"descriptor:{repr error}"
    | .ok (.ok root) => .ok root
  (SourceBuild.select polynomial (window square) [root]).mapError fun error => reprStr error

#eval (show IO Unit from do
  let quadratic := poly [-2,0,1]
  let square : DyadicSquare := ⟨Dyadic.ofInt 181 >>> (7 : Int),0,8⟩
  let negative := {square with re := -square.re}
  let cubic : DyadicSquare := ⟨Dyadic.ofInt 1290 >>> (10 : Int),0,12⟩
  let _ : Hashable base.Value := ⟨fun value => hash (base.codec.encode value)⟩
  let _ : Hashable Tower.Signature := ⟨fun value => hash (Tower.Signature.codec.encode value)⟩
  let mut packets := #[]
  for (name,p,s) in [("positive",quadratic,square),("negative",quadratic,negative),
      ("cubic",poly [-2,0,0,1],cubic)] do
    let .ok source := propose p s | throw (IO.userError s!"finite source failed:{name}")
    let packet := Codec.Json.arr #[Codec.descriptor base.codec Tower.Signature.codec source.root.raw,
      Codec.graph base.codec Tower.Signature.codec (Dag.encode source.root.evidence),
      source.equation.packet,source.enclosure.packet]
    IO.println s!"{name}:bytes={packet.writeBytes.size},rootNodes={(Dag.encode source.root.evidence).entries.size}"
    packets := packets.push packet
  IO.FS.writeBinFile "/home/kim/.codex/tasks/hex-10358/bounded-source.json"
    (Codec.Json.arr packets).writeBytes)
end BoundedSourceProbe
