"""Fixed nested-table allocation capture using the unchanged shared profiler."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys
ROOT = Path("/home/kim/worktrees/hex-dev/hex-dev-issue-10377-nested-tables")
sys.path.insert(0, str(ROOT))
from scripts.bench import sign_det_allocations as driver
from scripts.bench import sign_det_nested_tables as subjects
from scripts.bench.sign_det_compare import archive_sources
from scripts.bench.sign_det_joint_timing import harness_binding

OUT = Path("/home/kim/.local/state/hex/issue-10377-session-progress/nested-table-allocations")
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
original = driver.source_hashes
def sources():
    result = original()
    for name in ("HexRationalFn", "HexOrderedFn"):
        for path in [ROOT / (name + ".lean"), *(ROOT / name).rglob("*.lean")]:
            result[str(path.relative_to(ROOT))] = digest(path)
    for name in ("scripts/bench/sign_det_nested_tables.py",
                 "scripts/bench/test_sign_det_nested_tables.py",
                 "scripts/bench/fixtures/sign-det-nested-table-inputs.jsonl",
                 "scripts/bench/sign_det_nested_signs.py",
                 "reports/sign-det-nested-tables.md",
                 "scripts/bench/sign_det_compare.py", "scripts/bench/sign_det_joint_timing.py"):
        result[name] = digest(ROOT / name)
    return result
driver.source_hashes = sources
# The registered aliases are optimized away. Wrap their actual noinline helpers;
# verify the generated one-object-argument ABI and binary definition first.
FUNCTIONS = [subjects.PREFIX+op+str(depth) for depth in subjects.DEPTHS
             for op in ("runProduce", "runTree")]
PARAMETERS = [8, 32, 128]
import re
def callback_type(function):
    if function not in FUNCTIONS:
        raise ValueError("unexpected nested-table callback")
    helper = "produce" if "runProduce" in function else "checkTree"
    symbol = "lp_Hex___private_HexSignDet_NestedTables_0__Hex_SignDetBench_NestedTables_"+helper
    generated = ROOT/".lake/build/ir/HexSignDet/NestedTables.c"
    pattern = re.compile(r"LEAN_EXPORT lean_object\* " + re.escape(symbol) +
                         r"\(lean_object\*[^,)]*\)\{")
    if len(pattern.findall(generated.read_text())) != 1:
        raise ValueError("helper does not have the required one-object/pointer ABI")
    symbols = subprocess.check_output(["nm", "--defined-only", str(executable)],text=True)
    if not any(row.split()[-1] == symbol for row in symbols.splitlines() if row.split()):
        raise ValueError("actual operation helper is not present in the measured binary")
    return symbol, "void*", generated
driver.callback_type = callback_type
os.chdir(ROOT)
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
if subprocess.check_output(["git", "status", "--porcelain"], text=True):
    raise ValueError("commit sources before capture")
subprocess.run(["lake", "build", "--no-build", "hexsigndet_bench"], check=True)
executable = ROOT / ".lake/build/bin/hexsigndet_bench"
binding = {"revision": revision, "source_sha256": sources(),
           "tree": subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], text=True).strip(),
           "binary_sha256": digest(executable), "harness_binding": harness_binding(ROOT),
           "adapter_sha256": digest(Path(__file__)), "state": "running"}
preflight = OUT.parent / "nested-table-allocation-inputs.stdout"
with preflight.open("w") as output:
    subprocess.run([str(executable), "inspect-nested-tables"], stdout=output, check=True)
expected = subjects.validate_inputs(preflight)
sys.argv = [str(Path(driver.__file__)), "--functions", *FUNCTIONS,
            "--parameters", *map(str, PARAMETERS), "--trials", "3",
            "--output", str(OUT),
            "--valgrind", "/nix/store/mf7rzpknxwg0q1wf0nm8gfzikapg00h1-valgrind-3.27.1/bin/valgrind",
            "--include", "/nix/store/hwg6p9q1wnnqa0vf06lqf4ic0fm3mzdv-valgrind-3.27.1-dev/include"]
binding["driver_arguments"] = sys.argv
try:
    driver.main()
    metadata = json.loads((OUT / "metadata.json").read_text())
    samples = metadata["samples"]
    if [(r["trial"], r["parameter"], r["function"]) for r in samples] != [
            (trial, size, function) for trial in range(1, 4)
            for size in PARAMETERS for function in FUNCTIONS]:
        raise ValueError("missing or reordered nested allocation samples")
    for row in samples:
        depth = int(row["function"][-1])
        result_key = "productionResultHash" if "runProduce" in row["function"] else "replayResultHash"
        if row["state"] != "complete" or row["result_hash"] != hex(expected[depth,row["parameter"]][result_key]):
            raise ValueError("wrong literal nested-table or replay result")
    if metadata["source_unchanged"] is not True or metadata["binary_sha256"] != binding["binary_sha256"]:
        raise ValueError("allocation source binding changed")
    if sources() != binding["source_sha256"] or harness_binding(ROOT) != binding["harness_binding"]:
        raise ValueError("nested source or harness changed")
    if digest(Path(__file__)) != binding["adapter_sha256"]:
        raise ValueError("capture adapter changed")
    if subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() != revision:
        raise ValueError("source revision changed")
    if subprocess.check_output(["git", "status", "--porcelain"], text=True):
        raise ValueError("source tree became dirty")
    archive_sources(OUT, binding)
    binding["state"] = "complete"
except BaseException as error:
    binding.update(state="failed", exception=type(error).__name__, error=str(error))
    raise
finally:
    if OUT.exists():
        shutil.copyfile(preflight, OUT / "inputs.stdout")
        shutil.copyfile(__file__, OUT / "collect-nested-table-allocations.py")
        binding["file_sha256"] = {p.name: digest(p) for p in OUT.iterdir()
                                  if p.is_file() and p.name != "nested-binding.json"}
        (OUT / "nested-binding.json").write_text(json.dumps(binding, indent=2)+"\n")
