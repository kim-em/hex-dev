/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

module

import HexBasic.Fold
public import HexMvPoly.Query

@[expose] public section

/-!
Direct, fixed-variable-order Horner, and partial evaluation for
`Hex.MvPoly`.
-/

namespace Hex.MvPoly

universe u v

variable {n : Nat} {R : Type u} {S : Type v}
  {cmp : Mono n → Mono n → Ordering}
  [Std.TransCmp cmp] [Std.LawfulEqCmp cmp]

/-- Evaluate coefficients through `f` and variables through `x`. Powers are
computed by repeated squaring in `Mono.prod`. -/
def eval₂ [Zero R] [Lean.Grind.Semiring S]
    (f : R → S) (x : Fin n → S) (p : MvPoly n R cmp) : S :=
  p.foldTerms (fun acc m c => acc + f c * Mono.prod x m) 0

/-- Evaluate a polynomial at `x`. -/
def eval [Lean.Grind.Semiring R]
    (x : Fin n → R) (p : MvPoly n R cmp) : R :=
  eval₂ id x p

/-- A term whose coefficient has already been mapped into the target
semiring. -/
abbrev HornerTerm (n : Nat) (S : Type v) := Mono n × S

/-- Terms sharing one exponent in the variable currently being evaluated. -/
abbrev HornerGroup (n : Nat) (S : Type v) := Nat × List (HornerTerm n S)

/-- Read an exponent using a natural variable index, returning zero when the
index is out of range. -/
def hornerExponent (k : Nat) (m : Mono n) : Nat :=
  if h : k < n then m[(⟨k, h⟩ : Fin n)] else 0

/-- Add a term to an association list keyed by one variable exponent. -/
def insertHornerTerm (exponent : Nat) (term : HornerTerm n S) :
    List (HornerGroup n S) → List (HornerGroup n S)
  | [] => [(exponent, [term])]
  | group :: groups =>
      if group.1 = exponent then
        (group.1, term :: group.2) :: groups
      else
        group :: insertHornerTerm exponent term groups

/-- Insert an exponent group into descending exponent order. -/
def insertHornerGroupDesc (group : HornerGroup n S) :
    List (HornerGroup n S) → List (HornerGroup n S)
  | [] => [group]
  | group' :: groups =>
      if group'.1 < group.1 then
        group :: group' :: groups
      else
        group' :: insertHornerGroupDesc group groups

/-- Collect terms into groups keyed by their exponent at variable `k`. -/
def collectHornerGroups (k : Nat) (terms : List (HornerTerm n S)) :
    List (HornerGroup n S) :=
  terms.foldl
    (fun groups term => insertHornerTerm (hornerExponent k term.1) term groups) []

/-- Sort exponent groups from high exponent to low exponent. -/
def sortHornerGroups (groups : List (HornerGroup n S)) :
    List (HornerGroup n S) :=
  groups.foldl (fun sorted group => insertHornerGroupDesc group sorted) []

/-- Group terms by one variable exponent, ordered from high to low. -/
def hornerGroups (k : Nat) (terms : List (HornerTerm n S)) :
    List (HornerGroup n S) :=
  sortHornerGroups (collectHornerGroups k terms)

/-! # Horner grouping invariants -/

/-- Flatten Horner groups back to their exponent-tagged terms. -/
private def groupTerms (groups : List (HornerGroup n S)) :
    List (HornerTerm n S) :=
  groups.flatMap fun group => group.2

/-- Inserting a term into its exponent group preserves the flattened
multiset. -/
private theorem insertHornerTerm_perm (exponent : Nat)
    (term : HornerTerm n S) (groups : List (HornerGroup n S)) :
    (groupTerms (insertHornerTerm exponent term groups)).Perm
      (term :: groupTerms groups) := by
  induction groups with
  | nil => rfl
  | cons group groups ih =>
      unfold insertHornerTerm
      by_cases heq : group.1 = exponent
      · simp [heq, groupTerms]
      · rw [ite_eq_right heq]
        change
          (group.2 ++ groupTerms (insertHornerTerm exponent term groups)).Perm
            (term :: (group.2 ++ groupTerms groups))
        exact (ih.append_left group.2).trans List.perm_middle

/-- The accumulator form of group collection preserves the flattened
multiset. -/
private theorem collectHornerGroups_perm_aux (k : Nat)
    (terms : List (HornerTerm n S)) (groups : List (HornerGroup n S)) :
    (groupTerms
        (terms.foldl
          (fun groups term =>
            insertHornerTerm (hornerExponent k term.1) term groups)
          groups)).Perm
      (terms ++ groupTerms groups) := by
  induction terms generalizing groups with
  | nil => rfl
  | cons term terms ih =>
      simp only [List.foldl_cons]
      have hins :
          (terms ++
              groupTerms
                (insertHornerTerm (hornerExponent k term.1) term groups)).Perm
            (terms ++ term :: groupTerms groups) :=
        (insertHornerTerm_perm (hornerExponent k term.1) term groups).append_left
          terms
      have hfront :
          (terms ++ term :: groupTerms groups).Perm
            (term :: terms ++ groupTerms groups) :=
        List.perm_middle
      exact
        (ih
          (insertHornerTerm (hornerExponent k term.1) term groups)).trans
          (hins.trans hfront)

/-- Collecting terms into Horner groups preserves the flattened multiset. -/
private theorem collectHornerGroups_perm (k : Nat)
    (terms : List (HornerTerm n S)) :
    (groupTerms (collectHornerGroups k terms)).Perm terms := by
  simpa [collectHornerGroups, groupTerms] using
    collectHornerGroups_perm_aux k terms []

/-- Inserting a group into descending order preserves all groups. -/
private theorem insertHornerGroupDesc_perm (group : HornerGroup n S)
    (groups : List (HornerGroup n S)) :
    (groupTerms (insertHornerGroupDesc group groups)).Perm
      (group.2 ++ groupTerms groups) := by
  induction groups with
  | nil => rfl
  | cons group' groups ih =>
      unfold insertHornerGroupDesc
      by_cases hlt : group'.1 < group.1
      · simp [hlt, groupTerms]
      · rw [ite_eq_right hlt]
        change
          (group'.2 ++ groupTerms (insertHornerGroupDesc group groups)).Perm
            (group.2 ++ (group'.2 ++ groupTerms groups))
        exact
          (ih.append_left group'.2).trans
            (by
              simpa [List.append_assoc] using
                List.perm_append_comm_assoc group'.2 group.2 (groupTerms groups))

/-- The accumulator form of group sorting preserves all groups. -/
private theorem sortHornerGroups_perm_aux (groups sorted : List (HornerGroup n S)) :
    (groupTerms
        (groups.foldl
          (fun sorted group => insertHornerGroupDesc group sorted)
          sorted)).Perm
      (groupTerms groups ++ groupTerms sorted) := by
  induction groups generalizing sorted with
  | nil => rfl
  | cons group groups ih =>
      simp only [List.foldl_cons]
      have hins :
          (groupTerms groups ++
              groupTerms (insertHornerGroupDesc group sorted)).Perm
            (groupTerms groups ++ (group.2 ++ groupTerms sorted)) :=
        (insertHornerGroupDesc_perm group sorted).append_left
          (groupTerms groups)
      have hfront :
          (groupTerms groups ++ (group.2 ++ groupTerms sorted)).Perm
            (group.2 ++ (groupTerms groups ++ groupTerms sorted)) := by
        simpa [List.append_assoc] using
          List.perm_append_comm_assoc
            (groupTerms groups) group.2 (groupTerms sorted)
      exact
        (ih (insertHornerGroupDesc group sorted)).trans
          (by simpa [groupTerms] using hins.trans hfront)

/-- Sorting Horner groups preserves all groups. -/
private theorem sortHornerGroups_perm (groups : List (HornerGroup n S)) :
    (groupTerms (sortHornerGroups groups)).Perm (groupTerms groups) := by
  simpa [sortHornerGroups, groupTerms] using
    sortHornerGroups_perm_aux groups []

/-- The complete grouping pass preserves the original term multiset. -/
private theorem hornerGroups_perm (k : Nat) (terms : List (HornerTerm n S)) :
    (groupTerms (hornerGroups k terms)).Perm terms := by
  exact
    (sortHornerGroups_perm (collectHornerGroups k terms)).trans
      (collectHornerGroups_perm k terms)

/-- Membership after descending insertion is membership in the inserted group
or the original list. -/
private theorem mem_insertHornerGroupDesc
    (target group : HornerGroup n S) (groups : List (HornerGroup n S)) :
    target ∈ insertHornerGroupDesc group groups ↔
      target = group ∨ target ∈ groups := by
  induction groups with
  | nil => simp [insertHornerGroupDesc]
  | cons group' groups ih =>
      unfold insertHornerGroupDesc
      by_cases hlt : group'.1 < group.1
      · simp [hlt]
      · rw [ite_eq_right hlt]
        simp only [List.mem_cons, ih]
        constructor
        · rintro (heq | heq | hmem)
          · exact Or.inr (Or.inl heq)
          · exact Or.inl heq
          · exact Or.inr (Or.inr hmem)
        · rintro (heq | heq | hmem)
          · exact Or.inr (Or.inl heq)
          · exact Or.inl heq
          · exact Or.inr (Or.inr hmem)

/-- Descending insertion preserves descending exponent order. -/
private theorem insertHornerGroupDesc_desc (group : HornerGroup n S)
    (groups : List (HornerGroup n S))
    (hdesc : groups.Pairwise fun left right => right.1 ≤ left.1) :
    (insertHornerGroupDesc group groups).Pairwise
      fun left right => right.1 ≤ left.1 := by
  induction groups with
  | nil => simp [insertHornerGroupDesc]
  | cons group' groups ih =>
      rw [List.pairwise_cons] at hdesc
      unfold insertHornerGroupDesc
      by_cases hlt : group'.1 < group.1
      · rw [ite_eq_left hlt, List.pairwise_cons]
        constructor
        · intro target htarget
          simp only [List.mem_cons] at htarget
          rcases htarget with rfl | htarget
          · omega
          · exact Nat.le_trans (hdesc.1 target htarget) (Nat.le_of_lt hlt)
        · exact List.pairwise_cons.mpr hdesc
      · rw [ite_eq_right hlt, List.pairwise_cons]
        constructor
        · intro target htarget
          rw [mem_insertHornerGroupDesc] at htarget
          rcases htarget with rfl | htarget
          · omega
          · exact hdesc.1 target htarget
        · exact ih hdesc.2

/-- The accumulator sorting pass preserves descending exponent order. -/
private theorem sortHornerGroups_desc_aux
    (groups sorted : List (HornerGroup n S))
    (hdesc : sorted.Pairwise fun left right => right.1 ≤ left.1) :
    (groups.foldl
      (fun sorted group => insertHornerGroupDesc group sorted)
      sorted).Pairwise fun left right => right.1 ≤ left.1 := by
  induction groups generalizing sorted with
  | nil => exact hdesc
  | cons group groups ih =>
      simp only [List.foldl_cons]
      exact ih _ (insertHornerGroupDesc_desc group sorted hdesc)

/-- Sorting groups puts their exponents in descending order. -/
private theorem sortHornerGroups_desc (groups : List (HornerGroup n S)) :
    (sortHornerGroups groups).Pairwise
      fun left right => right.1 ≤ left.1 := by
  exact sortHornerGroups_desc_aux groups [] List.Pairwise.nil

/-- The complete grouping pass returns groups in descending exponent order. -/
private theorem hornerGroups_desc (k : Nat) (terms : List (HornerTerm n S)) :
    (hornerGroups k terms).Pairwise
      fun left right => right.1 ≤ left.1 :=
  sortHornerGroups_desc (collectHornerGroups k terms)

/-- Every term in a group has the exponent recorded by that group. -/
private def groupsKeyed (k : Nat) (groups : List (HornerGroup n S)) : Prop :=
  ∀ group ∈ groups, ∀ term ∈ group.2,
    hornerExponent k term.1 = group.1

/-- Inserting a term preserves the correspondence between group keys and term
exponents. -/
private theorem insertHornerTerm_at (k exponent : Nat)
    (term : HornerTerm n S) (groups : List (HornerGroup n S))
    (hterm : hornerExponent k term.1 = exponent)
    (hgroups : groupsKeyed k groups) :
    groupsKeyed k (insertHornerTerm exponent term groups) := by
  revert hgroups
  induction groups with
  | nil =>
      intro _
      intro target htarget candidate hcand
      simp only [insertHornerTerm, List.mem_singleton] at htarget
      subst target
      simp only [List.mem_singleton] at hcand
      subst candidate
      exact hterm
  | cons group groups ih =>
      intro hgroups
      have htail : groupsKeyed k groups := by
        intro target htarget candidate hcand
        exact hgroups target (List.mem_cons_of_mem group htarget) candidate hcand
      unfold insertHornerTerm
      by_cases heq : group.1 = exponent
      · rw [ite_eq_left heq]
        intro target htarget candidate hcand
        simp only [List.mem_cons] at htarget
        rcases htarget with htarget | htarget
        · subst target
          simp only [List.mem_cons] at hcand
          rcases hcand with hcand | hcand
          · subst candidate
            exact hterm.trans heq.symm
          · exact hgroups group (List.mem_cons_self ..) candidate hcand
        · exact hgroups target (List.mem_cons_of_mem group htarget) candidate hcand
      · rw [ite_eq_right heq]
        intro target htarget candidate hcand
        simp only [List.mem_cons] at htarget
        rcases htarget with htarget | htarget
        · subst target
          exact hgroups group (List.mem_cons_self ..) candidate hcand
        · exact ih htail target htarget candidate hcand

/-- The accumulator collection pass preserves the group-key invariant. -/
private theorem collectHornerGroups_at_aux (k : Nat)
    (terms : List (HornerTerm n S)) (groups : List (HornerGroup n S))
    (hgroups : groupsKeyed k groups) :
    groupsKeyed k
      (terms.foldl
        (fun groups term =>
          insertHornerTerm (hornerExponent k term.1) term groups)
        groups) := by
  induction terms generalizing groups with
  | nil => exact hgroups
  | cons term terms ih =>
      simp only [List.foldl_cons]
      exact ih _ (insertHornerTerm_at k _ term groups rfl hgroups)

/-- Collected groups satisfy the group-key invariant. -/
private theorem collectHornerGroups_at (k : Nat)
    (terms : List (HornerTerm n S)) :
    groupsKeyed k (collectHornerGroups k terms) := by
  apply collectHornerGroups_at_aux
  intro group hgroup
  simp at hgroup

/-- Descending insertion preserves the group-key invariant. -/
private theorem insertHornerGroupDesc_at (k : Nat)
    (group : HornerGroup n S) (groups : List (HornerGroup n S))
    (hgroup : ∀ term ∈ group.2, hornerExponent k term.1 = group.1)
    (hgroups : groupsKeyed k groups) :
    groupsKeyed k (insertHornerGroupDesc group groups) := by
  intro target htarget term hterm
  rw [mem_insertHornerGroupDesc] at htarget
  rcases htarget with rfl | htarget
  · exact hgroup term hterm
  · exact hgroups target htarget term hterm

/-- The accumulator sorting pass preserves the group-key invariant. -/
private theorem sortHornerGroups_at_aux (k : Nat)
    (groups sorted : List (HornerGroup n S))
    (hgroups : groupsKeyed k groups) (hsorted : groupsKeyed k sorted) :
    groupsKeyed k
      (groups.foldl
        (fun sorted group => insertHornerGroupDesc group sorted)
        sorted) := by
  induction groups generalizing sorted with
  | nil => exact hsorted
  | cons group groups ih =>
      simp only [List.foldl_cons]
      have hgroup :
          ∀ term ∈ group.2, hornerExponent k term.1 = group.1 :=
        hgroups group (List.mem_cons_self ..)
      have htail : groupsKeyed k groups := by
        intro target htarget term hterm
        exact hgroups target (List.mem_cons_of_mem group htarget) term hterm
      exact ih _ htail (insertHornerGroupDesc_at k group sorted hgroup hsorted)

/-- Sorting preserves the group-key invariant. -/
private theorem sortHornerGroups_at (k : Nat)
    (groups : List (HornerGroup n S)) (hgroups : groupsKeyed k groups) :
    groupsKeyed k (sortHornerGroups groups) := by
  apply sortHornerGroups_at_aux k groups [] hgroups
  intro group hgroup
  simp at hgroup

/-- The complete grouping pass records the selected exponent on every term. -/
private theorem hornerGroups_at (k : Nat)
    (terms : List (HornerTerm n S)) :
    groupsKeyed k (hornerGroups k terms) :=
  sortHornerGroups_at k _ (collectHornerGroups_at k terms)

/-- Advance one descending sparse-Horner exponent group. -/
def hornerStep [Lean.Grind.Semiring S]
    (x : S) (state group : Nat × S) : Nat × S :=
  (group.1,
    state.2 * Mono.powBySq x (state.1 - group.1) + group.2)

/-- Sparse Horner fold over already-evaluated coefficient groups. Callers must
supply groups in descending exponent order. Missing exponents are skipped with
repeated-squaring powers. -/
def evalSparseHornerGroups [Lean.Grind.Semiring S]
    (x : S) : List (Nat × S) → S
  | [] => 0
  | group :: groups =>
      let state := groups.foldl (hornerStep x) group
      state.2 * Mono.powBySq x state.1

/-! # Sparse Horner algebra -/

/-- Evaluate a list of descending exponent groups as a weighted sum. -/
private def weightedSum [Lean.Grind.Semiring S]
    (x : S) (groups : List (Nat × S)) : S :=
  groups.foldl
    (fun acc group => acc + group.2 * Mono.powBySq x group.1) 0

/-- Split a weighted sum at its leading exponent group. -/
private theorem weightedSum_cons [Lean.Grind.Semiring S]
    (x : S) (group : Nat × S) (groups : List (Nat × S)) :
    weightedSum x (group :: groups) =
      group.2 * Mono.powBySq x group.1 + weightedSum x groups := by
  unfold weightedSum
  simp only [List.foldl_cons]
  rw [Lean.Grind.AddCommMonoid.zero_add, List.foldl_add_eq_add_foldl]

/-- The sparse Horner fold equals the corresponding weighted sum. -/
private theorem sparseFold_eq [Lean.Grind.Semiring S]
    (x : S) (groups : List (Nat × S)) (previous : Nat) (acc : S)
    (hbound : ∀ group ∈ groups, group.1 ≤ previous)
    (hdesc : groups.Pairwise fun left right => right.1 ≤ left.1) :
    let state := groups.foldl (hornerStep x) (previous, acc)
    state.2 * Mono.powBySq x state.1 =
      acc * Mono.powBySq x previous + weightedSum x groups := by
  induction groups generalizing previous acc with
  | nil =>
      simp [weightedSum, Lean.Grind.Semiring.add_zero]
  | cons group groups ih =>
      rw [List.pairwise_cons] at hdesc
      have hle : group.1 ≤ previous :=
        hbound group (List.mem_cons_self ..)
      have htail : ∀ target ∈ groups, target.1 ≤ group.1 :=
        hdesc.1
      have hrec :=
        ih group.1
          (acc * Mono.powBySq x (previous - group.1) + group.2)
          htail hdesc.2
      have hpow :
          Mono.powBySq x (previous - group.1) *
              Mono.powBySq x group.1 =
            Mono.powBySq x previous := by
        rw [Mono.powBySq_eq_pow, Mono.powBySq_eq_pow,
          Mono.powBySq_eq_pow, ← Lean.Grind.Semiring.pow_add,
          Nat.sub_add_cancel hle]
      have hstep :
          (acc * Mono.powBySq x (previous - group.1) + group.2) *
              Mono.powBySq x group.1 =
            acc * Mono.powBySq x previous +
              group.2 * Mono.powBySq x group.1 := by
        calc
          (acc * Mono.powBySq x (previous - group.1) + group.2) *
                Mono.powBySq x group.1 =
              acc * Mono.powBySq x (previous - group.1) *
                  Mono.powBySq x group.1 +
                group.2 * Mono.powBySq x group.1 :=
            Lean.Grind.Semiring.right_distrib ..
          _ = acc *
                (Mono.powBySq x (previous - group.1) *
                  Mono.powBySq x group.1) +
                group.2 * Mono.powBySq x group.1 := by
            rw [Lean.Grind.Semiring.mul_assoc]
          _ = acc * Mono.powBySq x previous +
                group.2 * Mono.powBySq x group.1 := by rw [hpow]
      simp only [List.foldl_cons]
      rw [show hornerStep x (previous, acc) group =
        (group.1,
          acc * Mono.powBySq x (previous - group.1) + group.2) from rfl]
      rw [hrec, hstep]
      rw [weightedSum_cons, Lean.Grind.Semiring.add_assoc]

/-- Sparse Horner evaluation of valid groups equals their weighted sum. -/
private theorem evalSparseHornerGroups_eq [Lean.Grind.Semiring S]
    (x : S) (groups : List (Nat × S))
    (hdesc : groups.Pairwise fun left right => right.1 ≤ left.1) :
    evalSparseHornerGroups x groups = weightedSum x groups := by
  cases groups with
  | nil => rfl
  | cons group groups =>
      rw [List.pairwise_cons] at hdesc
      have hfold := sparseFold_eq x groups group.1 group.2 hdesc.1 hdesc.2
      have hfold' :
          let state := groups.foldl (hornerStep x) group
          state.2 * Mono.powBySq x state.1 =
            group.2 * Mono.powBySq x group.1 + weightedSum x groups := by
        simpa only [Prod.eta] using hfold
      rw [evalSparseHornerGroups]
      change
        let state := groups.foldl (hornerStep x) group
        state.2 * Mono.powBySq x state.1 =
          weightedSum x (group :: groups)
      exact hfold'.trans (weightedSum_cons x group groups).symm

/-- Evaluate sparse terms by fixed-order Horner in variables
`0, 1, ..., n - 1`. `fuel` is the number of variables left. -/
def eval₂HornerTerms [Lean.Grind.Semiring S]
    (xs : Nat → S) : Nat → Nat → List (HornerTerm n S) → S
  | 0, _, terms => terms.foldl (fun acc term => acc + term.2) 0
  | fuel + 1, k, terms =>
      let groups := hornerGroups k terms
      let evaluatedGroups := groups.map fun group =>
        (group.1, eval₂HornerTerms xs fuel (k + 1) group.2)
      evalSparseHornerGroups (xs k) evaluatedGroups

/-! # Recursive term semantics -/

/-- Evaluate one monomial term with the first `k` variables already folded. -/
private def termValue [Lean.Grind.Semiring S]
    (xs : Nat → S) : Nat → Nat → HornerTerm n S → S
  | 0, _, term => term.2
  | fuel + 1, k, term =>
      termValue xs fuel (k + 1) term *
        Mono.powBySq (xs k) (hornerExponent k term.1)

/-- The weighted grouped sum equals the sum of the individual term values. -/
private theorem weightedGroups_eq [Lean.Grind.Semiring S]
    (xs : Nat → S) (fuel k : Nat) (groups : List (HornerGroup n S))
    (hat : groupsKeyed k groups)
    (hrec : ∀ group ∈ groups,
      eval₂HornerTerms xs fuel (k + 1) group.2 =
        group.2.foldl
          (fun acc term => acc + termValue xs fuel (k + 1) term) 0) :
    weightedSum (xs k)
        (groups.map fun group =>
          (group.1, eval₂HornerTerms xs fuel (k + 1) group.2)) =
      (groupTerms groups).foldl
        (fun acc term => acc + termValue xs (fuel + 1) k term) 0 := by
  unfold weightedSum
  rw [List.foldl_map]
  unfold groupTerms
  rw [List.foldl_add_flatMap]
  apply List.foldl_congr
  intro acc group hgroup
  rw [hrec group hgroup]
  calc
    acc +
          group.2.foldl
              (fun acc term =>
                acc + termValue xs fuel (k + 1) term) 0 *
            Mono.powBySq (xs k) group.1 =
        acc +
          group.2.foldl
            (fun acc term =>
              acc + termValue xs fuel (k + 1) term *
                Mono.powBySq (xs k) group.1) 0 := by
      rw [List.foldl_add_mul_right_zero]
    _ = acc +
          group.2.foldl
            (fun acc term => acc + termValue xs (fuel + 1) k term) 0 := by
      congr 1
      apply List.foldl_add_congr
      intro term hterm
      simp only [termValue]
      rw [hat group hgroup term hterm]
    _ = group.2.foldl
          (fun acc term => acc + termValue xs (fuel + 1) k term) acc :=
      (List.foldl_add_eq_add_foldl group.2
        (termValue xs (fuel + 1) k) acc).symm

/-- Recursive sparse Horner evaluation equals the sum of its term values. -/
private theorem eval₂HornerTerms_eq [Lean.Grind.Semiring S]
    (xs : Nat → S) (fuel k : Nat) (terms : List (HornerTerm n S)) :
    eval₂HornerTerms xs fuel k terms =
      terms.foldl
        (fun acc term => acc + termValue xs fuel k term) 0 := by
  induction fuel generalizing k terms with
  | zero => rfl
  | succ fuel ih =>
      let groups := hornerGroups k terms
      have hdesc :
          (groups.map fun group =>
            (group.1, eval₂HornerTerms xs fuel (k + 1) group.2)).Pairwise
              fun left right => right.1 ≤ left.1 := by
        rw [List.pairwise_map]
        exact hornerGroups_desc k terms
      unfold eval₂HornerTerms
      rw [evalSparseHornerGroups_eq (xs k) _ hdesc]
      rw [weightedGroups_eq xs fuel k groups
        (hornerGroups_at k terms)
        (fun group _ => ih (k + 1) group.2)]
      exact List.foldl_add_perm
        (termValue xs (fuel + 1) k)
        (hornerGroups_perm k terms) 0

/-- Evaluate the suffix of a monomial beginning at variable `k`. -/
private def termProd [Lean.Grind.Semiring S]
    (xs : Nat → S) : Nat → Nat → Mono n → S
  | 0, _, _ => 1
  | fuel + 1, k, m =>
      Mono.powBySq (xs k) (hornerExponent k m) *
        termProd xs fuel (k + 1) m

/-- A term value factors as its coefficient times its monomial suffix
product. -/
private theorem termValue_eq_mul_prod [Lean.Grind.CommSemiring S]
    (xs : Nat → S) (fuel k : Nat) (term : HornerTerm n S) :
    termValue xs fuel k term =
      term.2 * termProd xs fuel k term.1 := by
  induction fuel generalizing k with
  | zero =>
      simp [termValue, termProd, Lean.Grind.Semiring.mul_one]
  | succ fuel ih =>
      rw [termValue, termProd, ih]
      calc
        term.2 * termProd xs fuel (k + 1) term.1 *
              Mono.powBySq (xs k) (hornerExponent k term.1) =
            term.2 *
              (termProd xs fuel (k + 1) term.1 *
                Mono.powBySq (xs k) (hornerExponent k term.1)) :=
          Lean.Grind.Semiring.mul_assoc ..
        _ = term.2 *
              (Mono.powBySq (xs k) (hornerExponent k term.1) *
                termProd xs fuel (k + 1) term.1) := by
          rw [Lean.Grind.CommSemiring.mul_comm
            (termProd xs fuel (k + 1) term.1)]

/-- Dropping the head shifts every later Horner exponent index down one. -/
private theorem hornerExponent_dropHead (k : Nat) (m : Mono (n + 1)) :
    hornerExponent (k + 1) m =
      hornerExponent k (Mono.dropHead m) := by
  unfold hornerExponent
  by_cases hk : k < n
  · have hk' : k + 1 < n + 1 := by omega
    simp only [hk, hk', ↓reduceDIte]
    rw [Mono.getElem_dropHead]
    congr 1
  · have hk' : ¬ k + 1 < n + 1 := by omega
    simp [hk, hk']

/-- A suffix product after the head agrees with the product on the dropped
monomial. -/
private theorem termProd_dropHead [Lean.Grind.Semiring S]
    (xs : Nat → S) (fuel k : Nat) (m : Mono (n + 1)) :
    termProd xs fuel (k + 1) m =
      termProd (fun j => xs (j + 1)) fuel k (Mono.dropHead m) := by
  induction fuel generalizing k with
  | zero => rfl
  | succ fuel ih =>
      rw [termProd, termProd, hornerExponent_dropHead, ih]

/-- The full suffix product is ordinary monomial evaluation. -/
private theorem termProd_full [Lean.Grind.Semiring S]
    (xs : Nat → S) (m : Mono n) :
    termProd xs n 0 m =
      Mono.prod (fun i => xs i.val) m := by
  letI : Std.Associative (· * · : S → S → S) :=
    ⟨Lean.Grind.Semiring.mul_assoc⟩
  letI : Std.LawfulIdentity (· * · : S → S → S) 1 :=
    { left_id := Lean.Grind.Semiring.one_mul
      right_id := Lean.Grind.Semiring.mul_one }
  induction n generalizing xs with
  | zero =>
      simp [termProd, Mono.prod]
  | succ n ih =>
      rw [termProd, termProd_dropHead,
        ih (fun j => xs (j + 1)) (Mono.dropHead m)]
      unfold Mono.prod
      rw [List.finRange_succ]
      simp only [List.foldl_cons, List.foldl_map]
      rw [Lean.Grind.Semiring.one_mul]
      simp only [hornerExponent, Nat.zero_lt_succ, ↓reduceDIte]
      have htail :
          (List.finRange n).foldl
              (fun acc i =>
                acc *
                  Mono.powBySq (xs (i.val + 1)) (Mono.dropHead m)[i]) 1 =
            (List.finRange n).foldl
              (fun acc i =>
                acc * Mono.powBySq (xs i.succ.val) m[i.succ]) 1 := by
        apply List.foldl_congr
        intro acc i _
        simp only [Mono.getElem_dropHead]
        rfl
      calc
        Mono.powBySq (xs 0) m[0] *
              (List.finRange n).foldl
                (fun acc i =>
                  acc *
                    Mono.powBySq (xs (i.val + 1)) (Mono.dropHead m)[i]) 1 =
            Mono.powBySq (xs 0) m[0] *
              (List.finRange n).foldl
                (fun acc i =>
                  acc * Mono.powBySq (xs i.succ.val) m[i.succ]) 1 := by
          rw [htail]
        _ = (List.finRange n).foldl
              (fun acc i =>
                acc * Mono.powBySq (xs i.succ.val) m[i.succ])
              (Mono.powBySq (xs 0) m[0]) :=
          (List.foldl_mul_eq_mul_foldl
            (List.finRange n)
            (fun i => Mono.powBySq (xs i.succ.val) m[i.succ])
            (Mono.powBySq (xs 0) m[0])).symm

/-- A full term value is its coefficient times ordinary monomial
evaluation. -/
private theorem termValue_full [Lean.Grind.CommSemiring S]
    (xs : Nat → S) (term : HornerTerm n S) :
    termValue xs n 0 term =
      term.2 * Mono.prod (fun i => xs i.val) term.1 := by
  rw [termValue_eq_mul_prod, termProd_full]

/-- Evaluate using fixed-variable-order sparse Horner evaluation. The target
semiring is commutative because variable nesting may reorder factors. -/
def eval₂Horner [Zero R] [Lean.Grind.CommSemiring S]
    (f : R → S) (x : Fin n → S) (p : MvPoly n R cmp) : S :=
  let xs : Nat → S := fun k => if h : k < n then x ⟨k, h⟩ else 0
  let terms := p.termsList.map fun term => (term.1, f term.2)
  eval₂HornerTerms xs n 0 terms

/-- Evaluate at `x` using fixed-variable-order sparse Horner evaluation. -/
def evalHorner [Lean.Grind.CommSemiring R]
    (x : Fin n → R) (p : MvPoly n R cmp) : R :=
  eval₂Horner id x p

/-- Erase the exponents of variables assigned by `s`. -/
def eraseAssigned (s : Fin n → Option R) (m : Mono n) : Mono n :=
  Hex.Vector.ofFn' fun i => if (s i).isSome then 0 else m[i]

/-- Evaluate the variables assigned by `s`, leaving all other variables in
the same ambient polynomial ring. Terms that collide are combined. -/
def partialEval [Lean.Grind.Semiring R] [DecidableEq R]
    (s : Fin n → Option R) (p : MvPoly n R cmp) : MvPoly n R cmp :=
  p.foldTerms
    (fun acc m c =>
      let assigned := Mono.prod (fun i => (s i).getD 1) m
      acc.addMonomial (eraseAssigned s m) (c * assigned))
    0

/-- Evaluation is the ordered term fold of mapped coefficients times
monomial values. -/
theorem eval₂_eq [Zero R] [Lean.Grind.Semiring S]
    (f : R → S) (x : Fin n → S) (p : MvPoly n R cmp) :
    eval₂ f x p =
      p.termsList.foldl (fun acc term => acc + f term.2 * Mono.prod x term.1) 0 := by
  unfold eval₂ foldTerms termsList
  rw [Std.ExtTreeMap.foldl_eq_foldl_toList]

/-- Same-ring evaluation is the ordered term fold with unchanged
coefficients. -/
theorem eval_eq [Lean.Grind.Semiring R]
    (x : Fin n → R) (p : MvPoly n R cmp) :
    eval x p =
      p.termsList.foldl (fun acc term => acc + term.2 * Mono.prod x term.1) 0 := by
  unfold eval
  simpa using eval₂_eq id x p

/-- Sparse Horner evaluation agrees with direct term evaluation. -/
theorem eval₂Horner_eq [Zero R] [Lean.Grind.CommSemiring S]
    (f : R → S) (x : Fin n → S) (p : MvPoly n R cmp) :
    eval₂Horner f x p = eval₂ f x p := by
  let xs : Nat → S := fun k => if h : k < n then x ⟨k, h⟩ else 0
  change
    eval₂HornerTerms xs n 0
        (p.termsList.map fun term => (term.1, f term.2)) =
      eval₂ f x p
  rw [eval₂HornerTerms_eq, eval₂_eq, List.foldl_map]
  have hxs : (fun i : Fin n => xs i.val) = x := by
    funext i
    simp [xs]
  apply List.foldl_congr
  intro acc term _
  rw [termValue_full, hxs]

/-- Same-ring sparse Horner evaluation agrees with ordinary evaluation. -/
theorem evalHorner_eq [Lean.Grind.CommSemiring R]
    (x : Fin n → R) (p : MvPoly n R cmp) :
    evalHorner x p = eval x p := by
  unfold evalHorner eval
  exact eval₂Horner_eq id x p

/-! # Evaluation laws -/

section EvalLaws

variable [Zero R] [Lean.Grind.Semiring S] (f : R → S) (x : Fin n → S)

/-- Evaluation is the fold over the canonical support of mapped coefficients
times monomial values. -/
theorem eval₂_eq_foldl_monomials (p : MvPoly n R cmp) :
    eval₂ f x p =
      p.monomials.foldl (fun acc m => acc + f (coeff m p) * Mono.prod x m) 0 := by
  rw [eval₂_eq, monomials, List.foldl_map]
  apply List.foldl_congr
  intro acc t ht
  obtain ⟨m, c⟩ := t
  rw [coeff_eq_of_mem_terms p ht]

/-- Evaluation may be written as a fold over any duplicate-free list of
monomials containing the support, provided `f` fixes zero. -/
theorem eval₂_eq_foldl_of_superset (hf0 : f 0 = 0) (p : MvPoly n R cmp)
    (L : List (Mono n)) (hL : L.Nodup) (hsub : ∀ m ∈ p.monomials, m ∈ L) :
    eval₂ f x p = L.foldl (fun acc m => acc + f (coeff m p) * Mono.prod x m) 0 := by
  rw [eval₂_eq_foldl_monomials]
  have hnodup : (p.monomials ++ L.filter (fun m => decide (m ∉ p.monomials))).Nodup := by
    rw [List.nodup_append]
    refine ⟨monomials_nodup p, hL.filter _, ?_⟩
    intro a ha b hb hab
    subst hab
    simp only [List.mem_filter, decide_eq_true_eq] at hb
    exact hb.2 ha
  have hperm : L.Perm (p.monomials ++ L.filter (fun m => decide (m ∉ p.monomials))) := by
    refine (List.perm_ext_iff_of_nodup hL hnodup).mpr ?_
    intro m
    simp only [List.mem_append, List.mem_filter, decide_eq_true_eq]
    constructor
    · intro hm
      by_cases hmp : m ∈ p.monomials
      · exact Or.inl hmp
      · exact Or.inr ⟨hm, hmp⟩
    · intro hm
      rcases hm with hm | ⟨hm, _⟩
      · exact hsub m hm
      · exact hm
  have hzero : ∀ m ∈ L.filter (fun m => decide (m ∉ p.monomials)),
      f (coeff m p) * Mono.prod x m = 0 := by
    intro m hm
    simp only [List.mem_filter, decide_eq_true_eq] at hm
    rw [coeff_eq_zero_of_not_mem m p hm.2, hf0, Lean.Grind.Semiring.zero_mul]
  rw [List.foldl_add_perm (fun m => f (coeff m p) * Mono.prod x m) hperm,
    List.foldl_append, List.foldl_add_eq_self _ _ _ hzero]

/-- The zero polynomial evaluates to zero. -/
theorem eval₂_zero (hf0 : f 0 = 0) : eval₂ f x (0 : MvPoly n R cmp) = 0 := by
  have hsub : ∀ m ∈ (0 : MvPoly n R cmp).monomials, m ∈ ([] : List (Mono n)) := by
    intro m hm
    rw [mem_monomials_iff, coeff_zero] at hm
    exact absurd rfl hm
  rw [eval₂_eq_foldl_of_superset f x hf0 0 [] List.nodup_nil hsub]
  rfl

/-- Adding a monomial adds its mapped value, for an additive `f` fixing
zero. -/
theorem eval₂_addMonomial [Add R] [BEq R] [LawfulBEq R] [DecidableEq R]
    (hf0 : f 0 = 0) (hfadd : ∀ a b : R, f (a + b) = f a + f b)
    (p : MvPoly n R cmp) (m : Mono n) (c : R) :
    eval₂ f x (p.addMonomial m c) = eval₂ f x p + f c * Mono.prod x m := by
  let L : List (Mono n) := p.monomials ++ (if m ∈ p.monomials then [] else [m])
  have hL : L.Nodup := by
    rw [List.nodup_append]
    refine ⟨monomials_nodup p, ?_, ?_⟩
    · split <;> simp
    · intro a ha b hb hab
      subst hab
      split at hb
      · simp at hb
      · simp only [List.mem_singleton] at hb
        subst hb
        exact ‹a ∉ p.monomials› ha
  have hmL : m ∈ L := by
    simp only [L, List.mem_append]
    by_cases hm : m ∈ p.monomials
    · exact Or.inl hm
    · simp [hm]
  have hsubp : ∀ k ∈ p.monomials, k ∈ L := fun k hk => List.mem_append_left _ hk
  have hsub : ∀ k ∈ (p.addMonomial m c).monomials, k ∈ L := by
    intro k hk
    rw [mem_monomials_iff, coeff_addMonomial] at hk
    by_cases hkm : k = m
    · subst hkm
      exact hmL
    · rw [ite_eq_right hkm] at hk
      exact hsubp k ((mem_monomials_iff k p).mpr hk)
  rw [eval₂_eq_foldl_of_superset f x hf0 _ L hL hsub,
    eval₂_eq_foldl_of_superset f x hf0 p L hL hsubp]
  have hstep : ∀ k ∈ L,
      f (coeff k (p.addMonomial m c)) * Mono.prod x k =
        f (coeff k p) * Mono.prod x k +
          (if k = m then f c * Mono.prod x m else 0) := by
    intro k _
    rw [coeff_addMonomial]
    by_cases hkm : k = m
    · subst hkm
      rw [ite_eq_left rfl, ite_eq_left rfl, hfadd, Lean.Grind.Semiring.right_distrib]
    · rw [ite_eq_right hkm, ite_eq_right hkm, Lean.Grind.Semiring.add_zero]
  rw [List.foldl_add_congr L _ _ 0 hstep, List.foldl_add_add,
    List.foldl_add_single L 0 m (fun _ => f c * Mono.prod x m) hmL hL,
    Lean.Grind.AddCommMonoid.zero_add]

/-- Building a polynomial from a term list evaluates to the fold of the
mapped terms, for an additive `f` fixing zero. -/
theorem eval₂_ofTerms [Add R] [BEq R] [LawfulBEq R] [DecidableEq R]
    (hf0 : f 0 = 0) (hfadd : ∀ a b : R, f (a + b) = f a + f b)
    (ts : List (Mono n × R)) :
    eval₂ f x (ofTerms ts : MvPoly n R cmp) =
      ts.foldl (fun acc t => acc + f t.2 * Mono.prod x t.1) 0 := by
  have aux : ∀ (us : List (Mono n × R)) (p : MvPoly n R cmp),
      eval₂ f x (us.foldl (fun q t => addMonomial q t.1 t.2) p) =
        us.foldl (fun acc t => acc + f t.2 * Mono.prod x t.1) (eval₂ f x p) := by
    intro us
    induction us with
    | nil => intro p; rfl
    | cons t us ih =>
      intro p
      rw [List.foldl_cons, List.foldl_cons, ih, eval₂_addMonomial f x hf0 hfadd]
  rw [ofTerms, aux, eval₂_zero f x hf0]

end EvalLaws

section EvalAdd

variable [Lean.Grind.Semiring R] [DecidableEq R] [Lean.Grind.Semiring S]
  (f : R → S) (x : Fin n → S)

/-- Evaluation is additive, for an additive `f` fixing zero. -/
theorem eval₂_add
    (hf0 : f 0 = 0) (hfadd : ∀ a b : R, f (a + b) = f a + f b)
    (p q : MvPoly n R cmp) :
    eval₂ f x (p + q) = eval₂ f x p + eval₂ f x q := by
  let L : List (Mono n) :=
    p.monomials ++ q.monomials.filter (fun m => decide (m ∉ p.monomials))
  have hL : L.Nodup := by
    rw [List.nodup_append]
    refine ⟨monomials_nodup p, (monomials_nodup q).filter _, ?_⟩
    intro a ha b hb hab
    subst hab
    simp only [List.mem_filter, decide_eq_true_eq] at hb
    exact hb.2 ha
  have hsubp : ∀ m ∈ p.monomials, m ∈ L := fun m hm => List.mem_append_left _ hm
  have hsubq : ∀ m ∈ q.monomials, m ∈ L := by
    intro m hm
    by_cases hmp : m ∈ p.monomials
    · exact List.mem_append_left _ hmp
    · apply List.mem_append_right
      exact List.mem_filter.mpr ⟨hm, by simpa using hmp⟩
  have hsub : ∀ m ∈ (p + q).monomials, m ∈ L := by
    intro m hm
    rw [mem_monomials_iff, coeff_add] at hm
    by_cases hmp : m ∈ p.monomials
    · exact hsubp m hmp
    · apply hsubq
      rw [mem_monomials_iff]
      intro hq
      rw [coeff_eq_zero_of_not_mem m p hmp, hq, Lean.Grind.Semiring.add_zero] at hm
      exact hm rfl
  rw [eval₂_eq_foldl_of_superset f x hf0 _ L hL hsub,
    eval₂_eq_foldl_of_superset f x hf0 p L hL hsubp,
    eval₂_eq_foldl_of_superset f x hf0 q L hL hsubq, ← List.foldl_add_add]
  apply List.foldl_add_congr
  intro m _
  rw [coeff_add, hfadd, Lean.Grind.Semiring.right_distrib]

end EvalAdd

end Hex.MvPoly
