module

public import Lake

public section

open System Lake DSL

package Hex where
  -- Parse docstrings as Verso markup. Suggestions remain opt-in because they
  -- attempt to elaborate ordinary code spans, including local expressions.
  leanOptions := #[⟨`doc.verso, true⟩, ⟨`doc.verso.suggestions, false⟩]

require verso from git
  "https://github.com/leanprover/verso.git" @ "v4.34.0-rc2"

-- Test-only native oracle. Released Hex libraries do not depend on it.
require NautyFFI from git
  "https://github.com/leanprover/nauty-ffi.git" @
    "ec8597014d0ae82490a616b855d59a35e6bfa21f"

require «lean-bench» from git
  "https://github.com/kim-em/lean-bench.git" @ "master"

require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git" @ "v4.34.0-rc2"

private def clmulOTarget (pkg : Package) : FetchM (Job FilePath) := do
  let oFile := pkg.dir / defaultBuildDir / "HexGF2" / "ffi" / "clmul.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexGF2" / "ffi" / "clmul.c"
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (← getLeanIncludeDir).toString, "-fPIC", "-O3"]
    compileO oFile srcFile flags

private def zmod64MulOTarget (pkg : Package) : FetchM (Job FilePath) := do
  let oFile := pkg.dir / defaultBuildDir / "HexModArith" / "ffi" / "zmod64_mul.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexModArith" / "ffi" / "zmod64_mul.c"
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (← getLeanIncludeDir).toString, "-fPIC", "-O3"]
    -- Mathlib's sandbox permits writes in the build directory, but not /tmp.
    -- Set TMPDIR for this compiler process only, including compiler wrappers.
    createParentDirs oFile
    proc {
      cmd := "cc"
      args := #["-c", "-o", oFile.toString, srcFile.toString] ++ flags
      env := #[("TMPDIR", some (← IO.FS.realPath (oFile.parent.getD ".")).toString)]
    }

extern_lib hexgf2ffi (pkg) := do
  let name := nameToStaticLib "hexgf2ffi"
  let oTarget ← clmulOTarget pkg
  buildStaticLib (pkg.staticLibDir / name) #[oTarget]

private def hexArithOTarget (pkg : Package) (src : String) : FetchM (Job FilePath) := do
  let stem := (src.dropEnd 2).toString
  let oFile := pkg.dir / defaultBuildDir / "HexArith" / "ffi" / s!"{stem}.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexArith" / "ffi" / src
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (← getLeanIncludeDir).toString, "-fPIC", "-O3"]
    -- Mathlib's sandbox permits writes in the build directory, but not /tmp.
    -- Set TMPDIR for this compiler process only, including compiler wrappers.
    createParentDirs oFile
    proc {
      cmd := "cc"
      args := #["-c", "-o", oFile.toString, srcFile.toString] ++ flags
      env := #[("TMPDIR", some (← IO.FS.realPath (oFile.parent.getD ".")).toString)]
    }

target hexarithffi pkg : FilePath := do
  let name := nameToStaticLib "hexarithffi"
  let oTargets ← #[ "wide_arith.c", "mpz_gcdext.c" ].mapM (hexArithOTarget pkg)
  buildStaticLib (pkg.staticLibDir / name) oTargets

target hexmodarithffi pkg : FilePath := do
  let name := nameToStaticLib "hexmodarithffi"
  let oTarget ← zmod64MulOTarget pkg
  buildStaticLib (pkg.staticLibDir / name) #[oTarget]

private def hexlllProviderOTarget (pkg : Package) : FetchM (Job FilePath) := do
  let oFile := pkg.dir / defaultBuildDir / "HexLLL" / "ffi" / "lean_hexlll_provider.o"
  let srcTarget ← inputTextFile <| pkg.dir / "HexLLL" / "ffi" / "lean_hexlll_provider.c"
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (← getLeanIncludeDir).toString, "-fPIC", "-O3"]
    compileO oFile srcFile flags

extern_lib hexlllffi (pkg) := do
  let name := nameToStaticLib "hexlllffi"
  let oTarget ← hexlllProviderOTarget pkg
  buildStaticLib (pkg.staticLibDir / name) #[oTarget]

private def nautyVendorOTarget (pkg : Package) (src : String) : FetchM (Job FilePath) := do
  let stem := (src.dropEnd 2).toString
  let oFile := pkg.dir / defaultBuildDir / "vendor" / "nauty-2.9.3" / s!"{stem}.o"
  let srcTarget ← inputTextFile <| pkg.dir / "vendor" / "nauty-2.9.3" / src
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (pkg.dir / "vendor" / "nauty-2.9.3").toString,
      "-fPIC", "-O2", "-std=c11", "-DUSE_TLS"]
    compileO oFile srcFile flags

private def nautyCanonOTarget (pkg : Package) : FetchM (Job FilePath) := do
  let oFile := pkg.dir / defaultBuildDir / "Hex" / "BenchOracle" / "ffi" /
    "nauty_canon.o"
  let srcTarget ← inputTextFile <| pkg.dir / "Hex" / "BenchOracle" / "ffi" /
    "nauty_canon.c"
  buildFileAfterDep oFile srcTarget fun srcFile => do
    let flags := #["-I", (← getLeanIncludeDir).toString,
      "-I", (pkg.dir / "vendor" / "nauty-2.9.3").toString,
      "-fPIC", "-O2", "-std=c11", "-DUSE_TLS"]
    compileO oFile srcFile flags

extern_lib hexnautyffi (pkg) := do
  let name := nameToStaticLib "hexnautyffi"
  let vendorTargets ← #["nauty.c", "nautil.c", "naugraph.c", "schreier.c",
    "naurng.c"].mapM (nautyVendorOTarget pkg)
  let shimTarget ← nautyCanonOTarget pkg
  buildStaticLib (pkg.staticLibDir / name) (vendorTargets.push shimTarget)

lean_lib Hex where

lean_lib HexBasic where

lean_lib HexTruncatedSeries where

@[default_target]
lean_lib HexTruncatedSeriesMathlib where

lean_lib HexArith where
  precompileModules := true
  moreLinkObjs := #[hexarithffi]
  moreLinkArgs := #["-lgmp"]

lean_lib HexPoly where

lean_lib HexPolyFast where

lean_lib HexMvPoly where

lean_lib HexMvGcd where

@[default_target]
lean_lib HexGenericRank where

@[default_target]
lean_lib HexGenericRankMathlib where

lean_lib HexReflect where

@[default_target]
lean_lib HexReflectMathlib where

@[default_target]
lean_lib HexKronecker where

@[default_target]
lean_lib HexKroneckerMathlib where

@[default_target]
lean_lib HexKroneckerTests where
  globs := #[.one `HexKroneckerMathlib.Tests]

lean_lib HexSparsePoly where

lean_lib HexModArith where
  precompileModules := true
  moreLinkObjs := #[hexmodarithffi]
  moreLinkArgs := #["-lgmp"]

lean_lib HexModular where

@[default_target]
lean_lib HexModularMatrix where

@[default_target]
lean_lib HexModularMatrixMathlib where

lean_lib HexGF2 where
  precompileModules := true

lean_lib HexPolyZ where

lean_lib HexPolyZGcd where

@[default_target]
lean_lib HexRationalFn where

@[default_target]
lean_lib HexRationalFnMathlib where

lean_lib HexRoots where

lean_lib HexResultant where

lean_lib HexNumberField where

lean_lib HexRealAlgebraic where

@[default_target]
lean_lib HexRealAlgebraicMathlib where

lean_lib HexNumberFieldTower where

lean_lib HexPolyFp where
  precompileModules := true

-- Fast-multiplication kernels specified by HexPolyFast/SPEC/hex-poly-fast.md
-- §"Coefficient-owner file layouts". They import HexPolyFast and HexModular,
-- which are not published, so the released umbrellas HexPolyZ.lean and
-- HexPolyFp.lean do not export them; they rejoin those umbrellas when
-- hex-poly-fast and hex-modular are admitted to scripts/release/released.yml
-- (https://github.com/kim-em/hex-dev/issues/10001).
@[default_target]
lean_lib HexPolyFastKernels where
  globs := #[`HexPolyZ.KroneckerMulti, `HexPolyZ.NttMul, `HexPolyFp.NttMul]

lean_lib HexGFqRing where

lean_lib HexGFqField where

lean_lib HexBerlekamp where

lean_lib HexHensel where
  -- `WordPoly.mul` has a native convolution extern used by downstream
  -- interpreter-time guards, so its module dynlib must export the stub.
  precompileModules := true

lean_lib HexMvHensel where

lean_lib HexMvFactor where

lean_lib HexConway where

lean_lib HexGFq where

lean_lib HexPrimality where

lean_lib HexIntFactor where

lean_lib HexBerlekampZassenhaus where

lean_lib HexRealRoots where

lean_lib HexInterval where

@[default_target]
lean_lib HexPolyMathlib where

@[default_target]
lean_lib HexMvPolyMathlib where

@[default_target]
lean_lib HexSparsePolyMathlib where

@[default_target]
lean_lib HexModArithMathlib where

@[default_target]
lean_lib HexPolyZMathlib where

@[default_target]
lean_lib HexPolyZGcdMathlib where

@[default_target]
lean_lib HexRootsMathlib where

@[default_target]
lean_lib HexResultantMathlib where

@[default_target]
lean_lib HexNumberFieldMathlib where

@[default_target]
lean_lib HexNumberFieldTowerMathlib where

@[default_target]
lean_lib HexPolyFpMathlib where

lean_lib HexBerlekampMathlib where

@[default_target]
lean_lib HexHenselMathlib where

@[default_target]
lean_lib HexGF2Mathlib where

@[default_target]
lean_lib HexGFqMathlib where

@[default_target]
lean_lib HexBerlekampZassenhausMathlib where

@[default_target]
lean_lib HexPrimalityMathlib where

@[default_target]
lean_lib HexIntFactorMathlib where

lean_lib HexMatrix where
  precompileModules := true

@[default_target]
lean_lib HexPermGroup where

@[default_target]
lean_lib HexPermGroupMathlib where

@[default_target]
lean_lib HexPermGroupTests where
  globs := #[`HexPermGroupMathlib.Tests]

lean_lib HexGraph where

lean_lib HexGraphIso where
  precompileModules := true

@[default_target]
lean_lib HexGraphIsoMathlib where

lean_lib HexCharPoly where
  precompileModules := true

lean_lib HexMinPoly where

lean_lib HexPolySmith where

@[default_target]
lean_lib HexPolySmithMathlib where

lean_lib HexRowReduce where
  precompileModules := true

lean_lib HexDeterminant where
  precompileModules := true

lean_lib HexBareiss where
  precompileModules := true

lean_lib HexDeterminantalIdeal where

lean_lib HexDet where

lean_lib HexRank where
  precompileModules := true

lean_lib HexHermite where
  precompileModules := true

lean_lib HexSmith where
  precompileModules := true

lean_lib HexHermiteMathlib where

lean_lib HexSmithMathlib where

lean_lib HexGramSchmidt where

lean_lib HexLatticeEnum where

@[default_target]
lean_lib HexLatticeEnumMathlib where

@[default_target]
lean_lib HexLatticeEnumTests where
  globs := #[`HexLatticeEnumMathlib.Tests, `HexLatticeEnumMathlib.LintTests]

lean_lib HexLLL where
  precompileModules := true
  extraDepTargets := #[`hexlllffi]
  moreLinkArgs :=
    if System.Platform.isOSX then
      #[]
    else
      #["-ldl"]

@[default_target]
lean_lib HexMatrixMathlib where

@[default_target]
lean_lib HexCharPolyMathlib where

@[default_target]
lean_lib HexMinPolyMathlib where

@[default_target]
lean_lib HexRowReduceMathlib where

@[default_target]
lean_lib HexDeterminantMathlib where

@[default_target]
lean_lib HexDeterminantalIdealMathlib where

@[default_target]
lean_lib HexDeterminantalIdealTests where
  globs := #[`HexDeterminantalIdealMathlib.Tests]

@[default_target]
lean_lib HexPolyDet where

@[default_target]
lean_lib HexPolyDetMathlib where

lean_lib HexPolyDetMathlibProofProbe where
  srcDir := "bench"
  globs := #[.submodules `HexPolyDetMathlib.ProofProbe]

@[default_target]
lean_lib HexBareissMathlib where

lean_lib HexBareissMathlibProofProbe where
  srcDir := "bench"
  globs := #[`HexBareissMathlib.ProofProbe.Baseline,
    `HexBareissMathlib.ProofProbe.MathlibBaseline,
    `HexBareissMathlib.ProofProbe.Dense8Hex,
    `HexBareissMathlib.ProofProbe.Dense8Mathlib,
    `HexBareissMathlib.ProofProbe.Dense12Hex,
    `HexBareissMathlib.ProofProbe.Dense12Mathlib,
    `HexBareissMathlib.ProofProbe.Dense16Hex,
    `HexBareissMathlib.ProofProbe.Dense16Mathlib,
    `HexBareissMathlib.ProofProbe.Dense32Hex,
    `HexBareissMathlib.ProofProbe.Tridiagonal16Hex,
    `HexBareissMathlib.ProofProbe.Tridiagonal16Mathlib,
    `HexBareissMathlib.ProofProbe.Vandermonde8Hex,
    `HexBareissMathlib.ProofProbe.Vandermonde8Mathlib,
    `HexBareissMathlib.ProofProbe.Singular16Hex,
    `HexBareissMathlib.ProofProbe.Singular16Mathlib,
    `HexBareissMathlib.ProofProbe.Large8Bits64Hex,
    `HexBareissMathlib.ProofProbe.Large8Bits64Mathlib,
    `HexBareissMathlib.ProofProbe.Large4Bits256Hex,
    `HexBareissMathlib.ProofProbe.Large4Bits256Mathlib,
    `HexBareissMathlib.ProofProbe.Rational8Hex,
    `HexBareissMathlib.ProofProbe.Rational8Mathlib]


@[default_target]
lean_lib HexDetMathlib where

lean_lib HexRankMathlib where

@[default_target]
lean_lib HexRankTests where
  globs := #[`HexRankMathlib.Tests, `HexRankMathlib.NumberFieldTests]

@[default_target]
lean_lib HexGenericRankTests where
  globs := #[`HexGenericRankMathlib.Tests]

lean_lib HexGenericRankMathlibProofProbe where
  srcDir := "bench"
  globs := #[.submodules `HexGenericRankMathlib.ProofProbe]

lean_lib HexRankMathlibProofProbe where
  srcDir := "bench"
  globs := #[`HexRankMathlib.ProofProbe.Baseline,
    `HexRankMathlib.ProofProbe.MathlibBaseline,
    `HexRankMathlib.ProofProbe.Dense8Hex,
    `HexRankMathlib.ProofProbe.Dense8Mathlib,
    `HexRankMathlib.ProofProbe.Dense16Hex,
    `HexRankMathlib.ProofProbe.Dense16Mathlib,
    `HexRankMathlib.ProofProbe.Deficient16Hex,
    `HexRankMathlib.ProofProbe.Deficient16Mathlib,
    `HexRankMathlib.ProofProbe.Dense32Hex,
    `HexRankMathlib.ProofProbe.Dense32Mathlib,
    `HexRankMathlib.ProofProbe.LowRank32Hex,
    `HexRankMathlib.ProofProbe.LowRank32Mathlib,
    `HexRankMathlib.ProofProbe.QuadraticBaseline,
    `HexRankMathlib.ProofProbe.QuadraticMathlibBaseline,
    `HexRankMathlib.ProofProbe.Rational8Hex,
    `HexRankMathlib.ProofProbe.Rational8Mathlib,
    `HexRankMathlib.ProofProbe.RationalDeficient16Hex,
    `HexRankMathlib.ProofProbe.RationalDeficient16Mathlib,
    `HexRankMathlib.ProofProbe.Quadratic8Hex,
    `HexRankMathlib.ProofProbe.Quadratic8Mathlib,
    `HexRankMathlib.ProofProbe.QuadraticDeficient16Hex,
    `HexRankMathlib.ProofProbe.QuadraticDeficient16Mathlib,
    `HexRankMathlib.ProofProbe.NumberFieldSupport,
    `HexRankMathlib.ProofProbe.NumberFieldBaseline,
    `HexRankMathlib.ProofProbe.Algebraic8Hex]

@[default_target]
lean_lib HexGramSchmidtMathlib where

@[default_target]
lean_lib HexLLLMathlib where

@[default_target]
lean_lib HexRealRootsMathlib where

@[default_target]
lean_lib HexRCF where

lean_exe hexlll_external_reduction where
  root := `HexLLL.ExternalReduction

-- Multi-file bench drivers: their modules live under `bench/` and are owned by
-- a precompiled lean_lib (mirroring the released bench sub-project), so the bench
-- exes can root into them. Single-file bench drivers instead carry
-- `srcDir := "bench"` on their own `lean_exe`.
lean_lib HexLLLBenchSupport where
  srcDir := "bench"
  globs := #[`HexLLLBench, `HexLLLBench.Inputs, `HexLLLBench.Targets]

lean_lib HexGF2BenchSupport where
  srcDir := "bench"
  globs := #[`HexGF2.Bench]

lean_lib HexBerlekampKernelProbe where
  srcDir := "bench"
  globs := #[`HexBench.BerlekampKernel]

lean_lib HexPrimalityKernelProbe where
  srcDir := "bench"
  globs := #[`HexPrimalityBench.Inputs, `HexBench.PrimalityKernel]

lean_lib HexPrimalityElabProbe where
  srcDir := "bench"
  globs := #[`HexPrimalityBench.Inputs, `HexPrimality.ProofProbe.Support,
    `HexPrimality.ProofProbe.CoreBaseline,
    `HexPrimality.ProofProbe.Core512,
    `HexPrimality.ProofProbe.CoreExhausted,
    `HexPrimality.ProofProbe.CoreOverBudget,
    `HexIntFactor.ProofProbe.PrimalityExhausted,
    `HexPrimalityMathlib.ProofProbe.MathlibBaseline,
    `HexPrimalityMathlib.ProofProbe.Mathlib512,
    `HexPrimalityMathlib.ProofProbe.MathlibExhausted,
    `HexPrimalityMathlib.ProofProbe.MathlibOverBudget,
    `HexPrimalityMathlib.ProofProbe.Negative25,
    `HexPrimalityMathlib.ProofProbe.Negative32,
    `HexPrimalityMathlib.ProofProbe.Negative64,
    `HexPrimalityMathlib.ProofProbe.Negative64Null,
    `HexPrimalityMathlib.ProofProbe.Negative65,
    `HexPrimalityMathlib.ProofProbe.Negative512,
    `HexPrimalityMathlib.ProofProbe.Negative512Odd,
    `HexPrimalityMathlib.ProofProbe.NegativeExhausted512]

lean_lib HexPrimalityMathlibProofProbe where
  srcDir := "bench"
  globs := #[`HexPrimalityMathlib.ProofProbe.Support,
    `HexPrimalityMathlib.ProofProbe.Baseline,
    `HexPrimalityMathlib.ProofProbe.Input31,
    `HexPrimalityMathlib.ProofProbe.Literal31,
    `HexPrimalityMathlib.ProofProbe.Reify31,
    `HexPrimalityMathlib.ProofProbe.Replay31,
    `HexPrimalityMathlib.ProofProbe.Primality31,
    `HexPrimalityMathlib.ProofProbe.Input512,
    `HexPrimalityMathlib.ProofProbe.Literal512,
    `HexPrimalityMathlib.ProofProbe.Reify512,
    `HexPrimalityMathlib.ProofProbe.Replay512,
    `HexPrimalityMathlib.ProofProbe.Primality512,
    `HexPrimalityMathlib.ProofProbe.NormNumTrial,
    `HexPrimalityMathlib.ProofProbe.NormNumThreshold,
    `HexPrimalityMathlib.ProofProbe.NormNum512,
    `HexPrimalityMathlib.ProofProbe.MathlibBaseline,
    `HexPrimalityMathlib.ProofProbe.Mathlib512,
    `HexPrimalityMathlib.ProofProbe.MathlibExhausted,
    `HexPrimalityMathlib.ProofProbe.MathlibOverBudget,
    `HexPrimalityMathlib.ProofProbe.Negative25,
    `HexPrimalityMathlib.ProofProbe.Negative32,
    `HexPrimalityMathlib.ProofProbe.Negative64,
    `HexPrimalityMathlib.ProofProbe.Negative64Null,
    `HexPrimalityMathlib.ProofProbe.Negative65,
    `HexPrimalityMathlib.ProofProbe.Negative512,
    `HexPrimalityMathlib.ProofProbe.Negative512Odd,
    `HexPrimalityMathlib.ProofProbe.NegativeExhausted512].map Glob.one

lean_lib HexPrimalityElabProbeScientific where
  srcDir := "bench"
  globs := #[`HexPrimalityBench.Inputs, `HexPrimality.ProofProbe.Support,
    `HexPrimality.ProofProbe.CoreBaseline,
    `HexPrimality.ProofProbe.Bit31.Input,
    `HexPrimality.ProofProbe.Bit31.Search,
    `HexPrimality.ProofProbe.Bit31.Literal,
    `HexPrimality.ProofProbe.Bit31.Replay,
    `HexPrimality.ProofProbe.Bit31.Tactic,
    `HexPrimality.ProofProbe.Bit61.Input,
    `HexPrimality.ProofProbe.Bit61.Search,
    `HexPrimality.ProofProbe.Bit61.Literal,
    `HexPrimality.ProofProbe.Bit61.Replay,
    `HexPrimality.ProofProbe.Bit61.Tactic,
    `HexPrimality.ProofProbe.Bit123.Input,
    `HexPrimality.ProofProbe.Bit123.Search,
    `HexPrimality.ProofProbe.Bit123.Literal,
    `HexPrimality.ProofProbe.Bit123.Replay,
    `HexPrimality.ProofProbe.Bit123.Tactic,
    `HexPrimality.ProofProbe.Bit256.Input,
    `HexPrimality.ProofProbe.Bit256.Search,
    `HexPrimality.ProofProbe.Bit256.Literal,
    `HexPrimality.ProofProbe.Bit256.Replay,
    `HexPrimality.ProofProbe.Bit256.Tactic,
    `HexPrimality.ProofProbe.Bit511.Input,
    `HexPrimality.ProofProbe.Bit511.Search,
    `HexPrimality.ProofProbe.Bit511.Literal,
    `HexPrimality.ProofProbe.Bit511.Replay,
    `HexPrimality.ProofProbe.Bit511.Tactic,
    `HexPrimality.ProofProbe.Bit512.Input,
    `HexPrimality.ProofProbe.Bit512.Search,
    `HexPrimality.ProofProbe.Bit512.Literal,
    `HexPrimality.ProofProbe.Bit512.Replay,
    `HexPrimality.ProofProbe.Bit512.Tactic].map Glob.one

lean_lib HexIntFactorKernelProbe where
  srcDir := "bench"
  globs := #[`HexBench.IntFactorKernel,
    `HexIntFactor.ProofProbe.Support,
    `HexIntFactor.ProofProbe.Baseline,
    `HexIntFactor.ProofProbe.Replay1,
    `HexIntFactor.ProofProbe.Replay2,
    `HexIntFactor.ProofProbe.Replay3,
    `HexIntFactor.ProofProbe.Replay4,
    `HexIntFactor.ProofProbe.Replay5,
    `HexIntFactor.ProofProbe.Replay6,
    `HexIntFactor.ProofProbe.Replay7,
    `HexIntFactor.ProofProbe.Replay8,
    `HexIntFactor.ProofProbe.Replay9,
    `HexIntFactor.ProofProbe.Replay10]

lean_lib HexMvGcdKernelProbe where
  srcDir := "bench"
  globs := #[`HexMvGcd.Kernel]

lean_lib HexMvGcdBenchSupport where
  srcDir := "bench"
  globs := #[`HexMvGcd.Families, `HexMvGcd.Matrix,
    `HexMvGcd.ComparatorCases, `HexMvGcd.Comparators,
    `HexMvGcd.Profile, `HexMvGcdFlint, `HexMvGcdSingular]

lean_lib HexMvPolyBenchSupport where
  srcDir := "bench"
  globs := #[`HexMvPolyCorpus]

lean_lib HexModularBenchSupport where
  srcDir := "bench"
  globs := #[`HexModularBench.Comparator]

lean_lib HexMvPolyMathlibProofProbe where
  srcDir := "bench"
  globs := #[`HexMvPolyMathlib.ProofProbe.Support,
    `HexMvPolyMathlib.ProofProbe.Baseline,
    `HexMvPolyMathlib.ProofProbe.HexAdditionInputs32,
    `HexMvPolyMathlib.ProofProbe.SortedAdditionInputs32,
    `HexMvPolyMathlib.ProofProbe.HexAddition32,
    `HexMvPolyMathlib.ProofProbe.SortedAddition32,
    `HexMvPolyMathlib.ProofProbe.HexAdditionInputs64,
    `HexMvPolyMathlib.ProofProbe.SortedAdditionInputs64,
    `HexMvPolyMathlib.ProofProbe.HexAddition64,
    `HexMvPolyMathlib.ProofProbe.SortedAddition64,
    `HexMvPolyMathlib.ProofProbe.HexMulSparse6,
    `HexMvPolyMathlib.ProofProbe.SortedMulSparse6,
    `HexMvPolyMathlib.ProofProbe.HexMulCollideInputs8,
    `HexMvPolyMathlib.ProofProbe.SortedMulCollideInputs8,
    `HexMvPolyMathlib.ProofProbe.HexMulCollide8,
    `HexMvPolyMathlib.ProofProbe.SortedMulCollide8,
    `HexMvPolyMathlib.ProofProbe.HexMulCollideInputs12,
    `HexMvPolyMathlib.ProofProbe.SortedMulCollideInputs12,
    `HexMvPolyMathlib.ProofProbe.HexMulCollide12,
    `HexMvPolyMathlib.ProofProbe.SortedMulCollide12,
    `HexMvPolyMathlib.ProofProbe.HexCancellation4,
    `HexMvPolyMathlib.ProofProbe.SortedCancellation4,
    `HexMvPolyMathlib.ProofProbe.HexCancellation6,
    `HexMvPolyMathlib.ProofProbe.SortedCancellation6,
    `HexMvPolyMathlib.ProofProbe.HexCancellationInputs8,
    `HexMvPolyMathlib.ProofProbe.SortedCancellationInputs8,
    `HexMvPolyMathlib.ProofProbe.HexCancellation8,
    `HexMvPolyMathlib.ProofProbe.SortedCancellation8,
    `HexMvPolyMathlib.ProofProbe.HexCancellationInputs10,
    `HexMvPolyMathlib.ProofProbe.SortedCancellationInputs10,
    `HexMvPolyMathlib.ProofProbe.HexCancellation10,
    `HexMvPolyMathlib.ProofProbe.SortedCancellation10,
    `HexMvPolyMathlib.ProofProbe.HexSos3,
    `HexMvPolyMathlib.ProofProbe.SortedSos3,
    `HexMvPolyMathlib.ProofProbe.HexSos4,
    `HexMvPolyMathlib.ProofProbe.SortedSos4,
    `HexMvPolyMathlib.ProofProbe.HexSosInputs6,
    `HexMvPolyMathlib.ProofProbe.SortedSosInputs6,
    `HexMvPolyMathlib.ProofProbe.HexSos6,
    `HexMvPolyMathlib.ProofProbe.SortedSos6,
    `HexMvPolyMathlib.ProofProbe.HexSosInputs8,
    `HexMvPolyMathlib.ProofProbe.SortedSosInputs8,
    `HexMvPolyMathlib.ProofProbe.HexSos8,
    `HexMvPolyMathlib.ProofProbe.SortedSos8,
    `HexMvPolyMathlib.ProofProbe.HexStructuralInputs8,
    `HexMvPolyMathlib.ProofProbe.SortedStructuralInputs8,
    `HexMvPolyMathlib.ProofProbe.HexStructural8,
    `HexMvPolyMathlib.ProofProbe.SortedStructural8,
    `HexMvPolyMathlib.ProofProbe.HexStructuralInputs32,
    `HexMvPolyMathlib.ProofProbe.SortedStructuralInputs32,
    `HexMvPolyMathlib.ProofProbe.HexStructural32,
    `HexMvPolyMathlib.ProofProbe.SortedStructural32].map Glob.one

lean_lib HexIntervalExperiment where
  globs := #[`HexInterval.Experiment.Representation,
    `HexInterval.Experiment.Rational, `HexInterval.Experiment.Center,
    `HexInterval.Experiment.Scale, `HexInterval.Experiment.Propagator,
    `HexInterval.Experiment.Policy, `HexInterval.Experiment.PolicyFrontier,
    `HexInterval.Experiment.PolicyDriver,
    `HexInterval.Experiment.PackageRegistry,
    `HexInterval.Experiment.DyadicInterval,
    `HexInterval.Experiment.DyadicRules,
    `HexInterval.Experiment.StructuralMatcher,
    `HexInterval.Experiment.PayloadArena,
    `HexInterval.Experiment.PayloadSession,
    `HexInterval.Experiment.PolicySession,
    `HexInterval.Experiment.TargetRun,
    `HexInterval.Experiment.StagedPolicy,
    `HexInterval.Experiment.AdaptivePolicy,
    `HexInterval.Experiment.PolicyFeature,
    `HexInterval.Experiment.FeaturePolicy,
    `HexInterval.Experiment.BranchStart,
    `HexInterval.Experiment.BranchTree,
    `HexInterval.Experiment.BranchProof,
    `HexInterval.Experiment.SemanticReplay,
    `HexInterval.Experiment.ChronologicalReplay,
    `HexInterval.Experiment.GenericInstanceReconstruction,
    `HexInterval.Experiment.OperationSemantics,
    `HexInterval.Experiment.ProofEmitter,
    `HexInterval.Experiment.ProofRegistry,
    `HexInterval.Experiment.Frontend,
    `HexInterval.Experiment.FrontendEncoder,
    `HexInterval.Experiment.ProofFrontend,
    `HexInterval.Experiment.GoalFrontend,
    `HexInterval.Experiment.GoalClosure,
    `HexInterval.Experiment.TraceReplay,
    `HexInterval.Experiment.SineSign,
    `HexInterval.Experiment.ExpSign,
    `HexInterval.Experiment.PntLogTable,
    `HexInterval.Experiment.PntNestedLog,
    `HexInterval.Experiment.PntExpTail,
    `HexInterval.Experiment.PntTable12,
    `HexInterval.Experiment.PntTable12Ordinary,
    `HexInterval.Experiment.PntTable10Shard,
    `HexInterval.Experiment.PntTable10Convex,
    `HexInterval.Experiment.PntTable10Pointwise,
    `HexInterval.Experiment.PntTable10LargePointwise,
    `HexInterval.Experiment.PntTable10LogCoupled,
    `HexInterval.Experiment.PntTable10A2,
    `HexInterval.Experiment.PntTable12Log,
    `HexInterval.Experiment.PntFks2ShardData,
    `HexInterval.Experiment.PntFks2Shard,
    `HexInterval.Experiment.PntFks2FamilyData00,
    `HexInterval.Experiment.PntFks2FamilyData01,
    `HexInterval.Experiment.PntFks2FamilyData02,
    `HexInterval.Experiment.PntFks2FamilyData03,
    `HexInterval.Experiment.PntFks2FamilyData04,
    `HexInterval.Experiment.PntFks2FamilyData05,
    `HexInterval.Experiment.PntFks2FamilyData06,
    `HexInterval.Experiment.PntFks2FamilyData07,
    `HexInterval.Experiment.PntFks2FamilyData08,
    `HexInterval.Experiment.PntFks2FamilyData09,
    `HexInterval.Experiment.PntFks2FamilyData10,
    `HexInterval.Experiment.PntFks2FamilyData12,
    `HexInterval.Experiment.PntFks2FamilyData13,
    `HexInterval.Experiment.PntFks2FamilyData,
    `HexInterval.Experiment.PntFks2Family,
    `HexInterval.Experiment.PntFks2Structure,
    `HexInterval.Experiment.PntFks2Xpow,
    `HexInterval.Experiment.CosBillion,
    `HexInterval.Experiment.LogTablePrecision,
    `HexInterval.Experiment.PntLogNatural,
    `HexInterval.Experiment.PntFks2Nested,
    `HexInterval.Experiment.PntLogRational,
    `HexInterval.Experiment.PntExpNegative,
    `HexInterval.Experiment.PntExpPoint,
    `HexInterval.Experiment.PntNestedLogTwo,
    `HexInterval.Experiment.PntPiPoint,
    `HexInterval.Experiment.IntegralCanary,
    `HexInterval.Experiment.PntBKLNWExp,
    `HexInterval.Experiment.PntBKLNWPow,
    `HexInterval.Experiment.PntDusartExp,
    `HexInterval.Experiment.PntFks2Mu,
    `HexInterval.Experiment.PntExpUpper,
    `HexInterval.Experiment.PntRamanujanTheta,
    `HexInterval.Experiment.SinTen,
    `HexInterval.Experiment.SinTenInterval,
    `HexInterval.Experiment.MixedFunctions,
    `HexInterval.Experiment.MixedInstantiation].map Glob.one

lean_lib HexIntervalMathlibExperiment where
  globs := #[`HexIntervalMathlib.Experiment.Arithmetic,
    `HexIntervalMathlib.Experiment.Center,
    `HexIntervalMathlib.Experiment.Centered,
    `HexIntervalMathlib.Experiment.DyadicInterval,
    `HexIntervalMathlib.Experiment.SineSign,
    `HexIntervalMathlib.Experiment.ExpSign,
    `HexIntervalMathlib.Experiment.PntLogTable,
    `HexIntervalMathlib.Experiment.PntNestedLog,
    `HexIntervalMathlib.Experiment.PntExpTail,
    `HexIntervalMathlib.Experiment.PntTable12,
    `HexIntervalMathlib.Experiment.PntTable12Ordinary,
    `HexIntervalMathlib.Experiment.PntTable10Shard,
    `HexIntervalMathlib.Experiment.PntTable10Convex,
    `HexIntervalMathlib.Experiment.PntTable10Pointwise,
    `HexIntervalMathlib.Experiment.PntTable10LargePointwise,
    `HexIntervalMathlib.Experiment.PntTable10LogCoupled,
    `HexIntervalMathlib.Experiment.PntTable10A2,
    `HexIntervalMathlib.Experiment.PntTable10Exact,
    `HexIntervalMathlib.Experiment.PntTable12Log,
    `HexIntervalMathlib.Experiment.PntFks2Shard,
    `HexIntervalMathlib.Experiment.PntFks2Xpow,
    `HexIntervalMathlib.Experiment.CosBillion,
    `HexIntervalMathlib.Experiment.LogTablePrecision,
    `HexIntervalMathlib.Experiment.PntLogNatural,
    `HexIntervalMathlib.Experiment.PntFks2Nested,
    `HexIntervalMathlib.Experiment.PntLogRational,
    `HexIntervalMathlib.Experiment.PntExpNegative,
    `HexIntervalMathlib.Experiment.PntExpPoint,
    `HexIntervalMathlib.Experiment.PntNestedLogTwo,
    `HexIntervalMathlib.Experiment.PntPiPoint,
    `HexIntervalMathlib.Experiment.IntegralCanary,
    `HexIntervalMathlib.Experiment.PntBKLNWExp,
    `HexIntervalMathlib.Experiment.PntBKLNWPow,
    `HexIntervalMathlib.Experiment.PntDusartExp,
    `HexIntervalMathlib.Experiment.PntFks2Mu,
    `HexIntervalMathlib.Experiment.PntExpUpper,
    `HexIntervalMathlib.Experiment.PntRamanujanTheta,
    `HexIntervalMathlib.Experiment.PntPrimeLogSmall,
    `HexIntervalMathlib.Experiment.PntChebyshev,
    `HexIntervalAlgebraic.Experiment.PolynomialDispatch,
    `HexIntervalAlgebraic.Experiment.PolynomialDispatchProof,
    `HexIntervalMathlib.Experiment.SinTen,
    `HexIntervalMathlib.Experiment.SinTenInterval,
    `HexIntervalMathlib.Experiment.MixedFunctions,
    `HexIntervalMathlib.Experiment.MixedInstantiation].map Glob.one

@[default_target]
lean_lib HexIntervalMathlib where
  globs := #[`HexIntervalMathlib, `HexIntervalMathlib.Interval,
    `HexIntervalMathlib.Addition, `HexIntervalMathlib.Subtraction,
    `HexIntervalMathlib.MinMax, `HexIntervalMathlib.Absolute,
    `HexIntervalMathlib.Multiplication,
    `HexIntervalMathlib.Power, `HexIntervalMathlib.Split,
    `HexIntervalMathlib.Inverse, `HexIntervalMathlib.Division,
    `HexIntervalMathlib.Regularize, `HexIntervalMathlib.Program,
    `HexIntervalMathlib.Proof, `HexIntervalMathlib.Rule,
    `HexIntervalMathlib.Frontend,
    `HexIntervalMathlib.Tactic].map Glob.one

lean_lib HexIntervalReplayProbe where
  srcDir := "bench"
  globs := #[`HexInterval.ReplayBaseline, `HexInterval.ReplayBundled,
    `HexInterval.ReplayChecked, `HexInterval.ReplayRationalBaseline,
    `HexInterval.ReplayRationalDirect, `HexInterval.ReplayRationalChecked,
    `HexInterval.ReplayRational, `HexInterval.ImportBundled,
    `HexInterval.ImportChecked, `HexInterval.WhnfBundled,
    `HexInterval.WhnfChecked, `HexInterval.WhnfBaseline,
    `HexInterval.WhnfRationalDirect, `HexInterval.WhnfRationalChecked,
    `HexInterval.WhnfRationalBaseline, `HexInterval.ReplayCenterBaseline,
    `HexInterval.ReplayCenterChecked, `HexInterval.WhnfCenterChecked,
    `HexInterval.WhnfCenterBaseline, `HexInterval.WhnfScaleChecked,
    `HexInterval.WhnfScaleBaseline, `HexInterval.ReplayScaleChecked,
    `HexInterval.ReplayScaleBaseline]

lean_lib HexIntervalMathlibReplayProbe where
  srcDir := "bench"
  globs := #[`HexIntervalMathlib.CenterBaseline,
    `HexIntervalMathlib.CenterReflected, `HexIntervalMathlib.CenterDirect]

lean_lib HexRealRootsMathlibReplayProbe where
  srcDir := "bench"
  globs := #[`HexRealRootsMathlib.ProofProbe.Baseline,
    `HexRealRootsMathlib.ProofProbe.Natural6,
    `HexRealRootsMathlib.ProofProbe.Refined2]

lean_lib HexRealRootsMathlibReplayProbeScientific where
  srcDir := "bench"
  globs := #[`HexRealRootsMathlib.ProofProbe.Natural8,
    `HexRealRootsMathlib.ProofProbe.Natural10,
    `HexRealRootsMathlib.ProofProbe.Refined4,
    `HexRealRootsMathlib.ProofProbe.Refined6]

lean_lib HexBerlekampZassenhausMathlibProofProbe where
  srcDir := "bench"
  globs := #[`HexBerlekampZassenhausMathlib.ProofProbe.Baseline,
    `HexBerlekampZassenhausMathlib.ProofProbe.Factor4,
    `HexBerlekampZassenhausMathlib.ProofProbe.Irreducible4]

lean_lib HexBerlekampZassenhausMathlibProofProbeScientific where
  srcDir := "bench"
  globs := #[`HexBerlekampZassenhausMathlib.ProofProbe.Factor8,
    `HexBerlekampZassenhausMathlib.ProofProbe.Factor12,
    `HexBerlekampZassenhausMathlib.ProofProbe.Repeated8,
    `HexBerlekampZassenhausMathlib.ProofProbe.Irreducible8,
    `HexBerlekampZassenhausMathlib.ProofProbe.Irreducible16,
    `HexBerlekampZassenhausMathlib.ProofProbe.Kernel4,
    `HexBerlekampZassenhausMathlib.ProofProbe.Kernel8]

lean_lib HexBerlekampMathlibProofProbe where
  srcDir := "bench"
  globs := #[`HexBerlekampMathlib.ProofProbe.Baseline,
    `HexBerlekampMathlib.ProofProbe.Factor4,
    `HexBerlekampMathlib.ProofProbe.Irreducible4]

lean_lib HexBerlekampMathlibProofProbeScientific where
  srcDir := "bench"
  globs := #[`HexBerlekampMathlib.ProofProbe.Factor8,
    `HexBerlekampMathlib.ProofProbe.Factor12,
    `HexBerlekampMathlib.ProofProbe.Repeated8,
    `HexBerlekampMathlib.ProofProbe.Irreducible8,
    `HexBerlekampMathlib.ProofProbe.Irreducible16]

lean_lib HexRCFProofProbe where
  srcDir := "bench"
  globs := #[`HexRCF.BenchHash, `HexRCF.ProofProbe.Support,
    `HexRCF.ProofProbe.Generated,
    `HexRCF.ProofProbe.Validate, `HexRCF.ProofProbe.Baseline,
    `HexRCF.ProofProbe.Quadratic.Reify, `HexRCF.ProofProbe.Quadratic.Input,
    `HexRCF.ProofProbe.Quadratic.Search, `HexRCF.ProofProbe.Quadratic.Literal,
    `HexRCF.ProofProbe.Quadratic.Replay, `HexRCF.ProofProbe.Quadratic.Tactic]

lean_lib HexRCFProofProbeScientific where
  srcDir := "bench"
  globs := #[`HexRCF.ProofProbe.Degree10.Reify,
    `HexRCF.ProofProbe.Degree10.Input, `HexRCF.ProofProbe.Degree10.Search,
    `HexRCF.ProofProbe.Degree10.Literal, `HexRCF.ProofProbe.Degree10.Replay,
    `HexRCF.ProofProbe.Degree10.Tactic, `HexRCF.ProofProbe.Degree50.Reify,
    `HexRCF.ProofProbe.Degree50.Input, `HexRCF.ProofProbe.Degree50.Search,
    `HexRCF.ProofProbe.Degree50.Literal, `HexRCF.ProofProbe.Degree50.Replay,
    `HexRCF.ProofProbe.Degree50.Tactic,
    `HexRCF.ProofProbe.DoubleDegree50]

-- Conformance #guard drivers live under `conformance/` and are built by this
-- library (mirroring the released conformance sub-projects). Alongside each
-- library's `Conformance` core module, the heavier cross-check sweeps and
-- extern-path fast checks (`CrossCheck` / `FastCheck`) also live here so the
-- implementation-vs-testing boundary stays legible; they elaborate their
-- `#guard`s in the same `lake build`. EmitFixtures drivers are the
-- `*_emit_fixtures` exes below, carrying `srcDir := "conformance"`.
lean_lib HexConformance where
  srcDir := "conformance"
  globs := #[
`HexArith.Conformance, `HexArith.CrossCheck, `HexBerlekamp.Conformance, `HexBerlekampZassenhaus.Conformance, `HexBerlekampZassenhaus.CrossCheck, `HexBerlekampZassenhausMathlib.Conformance, `HexConway.Conformance, `HexGF2.Conformance, `HexGF2.CrossCheck, `HexGF2.FastCheck, `HexGFq.Conformance, `HexGFq.CrossCheck, `HexGFqField.Conformance, `HexGFqRing.Conformance, `HexGramSchmidt.Conformance, `HexGraphIso.Conformance, `HexHensel.Conformance, `HexHensel.CrossCheck, `HexInterval.Conformance, `HexIntervalMathlib.IntervalConformance, `HexInterval.CenterConformance, `HexInterval.ScaleConformance, `HexInterval.PropagatorConformance, `HexInterval.ScopeConformance, `HexInterval.StructuralMatcherConformance, `HexInterval.MatcherSchedulerConformance, `HexInterval.NestedBranchConformance, `HexInterval.StructureViewConformance, `HexInterval.PolicyConformance, `HexInterval.PolicyFrontierConformance, `HexInterval.PolicyDriverConformance, `HexInterval.PackageRegistryConformance, `HexInterval.DyadicIntervalConformance, `HexInterval.DyadicRulesConformance, `HexInterval.PayloadArenaConformance, `HexInterval.PayloadSessionConformance, `HexInterval.PolicySessionConformance, `HexInterval.PolicyFunctionConformance, `HexInterval.SemanticReplayConformance, `HexInterval.ChronologicalReplayConformance, `HexInterval.GenericInstanceReconstructionConformance, `HexInterval.ProofEmitterConformance, `HexInterval.TraceReplayConformance, `HexInterval.SinTenIntervalConformance, `HexIntervalMathlib.DyadicIntervalConformance, `HexIntervalMathlib.CenteredConformance, `HexIntervalMathlib.SineSignConformance, `HexIntervalMathlib.SineProofConformance, `HexIntervalMathlib.SineTacticConformance, `HexIntervalMathlib.ProofRegistryConformance, `HexIntervalMathlib.ExpSignConformance, `HexIntervalMathlib.ReluConformance, `HexIntervalMathlib.RefuteConformance, `HexIntervalMathlib.PntLogTableConformance, `HexIntervalMathlib.PntNestedLogConformance, `HexIntervalMathlib.PntExpTailConformance, `HexIntervalMathlib.PntTable12Conformance, `HexIntervalMathlib.PntTable12OrdinaryConformance, `HexIntervalAlgebraic.PolynomialDispatchConformance, `HexIntervalMathlib.PntTable12LogConformance, `HexIntervalMathlib.PntFks2ShardConformance, `HexIntervalMathlib.LogTablePrecisionConformance, `HexIntervalMathlib.IntegralCanaryConformance, `HexIntervalMathlib.PntBKLNWExpConformance, `HexIntervalMathlib.PntBKLNWPowConformance, `HexIntervalMathlib.PntPrimeLogSmallConformance, `HexIntervalMathlib.PntDusartExpConformance, `HexIntervalMathlib.SinTenConformance, `HexIntervalMathlib.SinTenIntervalConformance, `HexIntervalMathlib.CosBillionConformance, `HexHermite.Conformance, `HexLLL.Conformance, `HexMatrix.Conformance, `HexMvPolyFixtures, `HexMvPoly.Conformance, `HexMvPolyMathlib.Conformance, `HexSparsePolyFixtures, `HexSparsePoly.Conformance, `HexRowReduce.Conformance, `HexDeterminant.Conformance, `HexDeterminantalIdealFixtures, `HexDeterminantalIdeal.Conformance, `HexDeterminant.Carriers, `HexBareiss.Fixtures, `HexBareiss.Conformance, `HexModularMatrix.Fixtures, `HexModularMatrix.Conformance, `HexDet.Conformance, `HexDet.Carriers, `HexCharPoly.Fixtures, `HexCharPoly.Carriers, `HexCharPoly.Conformance, `HexModArith.Conformance, `HexModArith.FastCheck, `HexModular.Conformance, `HexPolyZGcd.Conformance, `HexMvGcd.Conformance, `HexNumberField.Conformance, `HexNumberFieldTower.Conformance, `HexPoly.Conformance, `HexPrimality.Conformance, `HexPrimalityMathlib.Conformance, `HexPrimalityMathlibConformance.OptIn, `HexPolyFp.Conformance, `HexPolyZ.Conformance, `HexRCF.Conformance, `HexRealRoots.Conformance, `HexRealRootsMathlib.Conformance, `HexResultant.Conformance, `HexRoots.Conformance].map Glob.one ++
    #[`HexPolyDet.Conformance, `HexRank.Conformance, `HexGenericRank.Conformance, `HexGenericRank.Fixtures, `HexRowReduce.FieldFixtures].map Glob.one

    ++ #[`HexRealAlgebraic.Conformance, `HexRealAlgebraic.Checks, `HexNumberField.ComplexChecks, `HexRealAlgebraic.ReprChecks].map Glob.one

    ++ #[`HexReflect.TestProviders, `HexReflect.Conformance, `HexReflect.ScopeConformance, `HexReflect.ResidueConformance].map Glob.one

    ++ #[`HexKronecker.Conformance].map Glob.one

    ++ #[`HexSmith.Conformance].map Glob.one

    ++ #[`HexMinPoly.Fixtures, `HexMinPoly.Conformance].map Glob.one

    ++ #[`HexTruncatedSeries.Conformance].map Glob.one

    ++ #[`HexPolyFast.Conformance].map Glob.one

    ++ #[`HexRationalFn.Conformance, `HexRationalFn.Domains].map Glob.one

    ++ #[`HexLatticeEnum.Conformance].map Glob.one

    ++ #[`HexMvHensel.Conformance, `HexMvFactor.Conformance].map Glob.one

    ++ #[`HexIntFactor.Conformance,
      `HexIntFactor.PrimalityConformance].map Glob.one

    ++ #[`HexPolySmith.Conformance].map Glob.one

    ++ #[`HexIntervalMathlib.PntLogNaturalConformance,
      `HexIntervalMathlib.PntLogRationalConformance,
      `HexIntervalMathlib.PntExpNegativeConformance,
      `HexIntervalMathlib.PntExpPointConformance].map Glob.one

    ++ #[`HexIntervalMathlib.PntNestedLogTwoConformance,
      `HexIntervalMathlib.PntPiPointConformance].map Glob.one

    ++ #[`HexIntervalMathlib.PntChebyshevConformance].map Glob.one

    ++ #[`HexIntervalMathlib.PntFks2MuConformance,
      `HexIntervalMathlib.PntExpUpperConformance,
      `HexIntervalMathlib.PntRamanujanThetaConformance].map Glob.one

    ++ #[`HexIntervalMathlib.PntFks2NestedConformance].map Glob.one

    ++ #[`HexIntervalMathlib.PntFks2StructureConformance].map Glob.one

    ++ #[`HexIntervalMathlib.PntTable10ShardConformance,
      `HexIntervalMathlib.PntTable10ConvexConformance,
      `HexIntervalMathlib.PntTable10PointwiseConformance,
      `HexIntervalMathlib.PntTable10LargePointwiseConformance,
      `HexIntervalMathlib.PntTable10LogCoupledConformance,
      `HexIntervalMathlib.PntTable10A2Conformance,
      `HexIntervalMathlib.PntTable10ExactConformance].map Glob.one

    ++ #[`HexInterval.StagedPolicyConformance].map Glob.one

    ++ #[`HexIntervalMathlib.ArithmeticConformance].map Glob.one

    ++ #[`HexInterval.MinMaxConformance,
      `HexIntervalMathlib.MinMaxConformance].map Glob.one

    ++ #[`HexGraphIso.Cases, `HexGraphIso.SparseCases, `HexPermGroup.Conformance, `HexPermGroup.Limits].map Glob.one

    ++ #[`HexInterval.PolicyFeatureConformance,
      `HexInterval.FeaturePolicyConformance,
      `HexInterval.SearchConformance,
      `HexInterval.ExecutableConformance,
      `HexInterval.RuntimeConformance,
      `HexIntervalMathlib.RuntimeProofConformance,
      `HexIntervalMathlib.RuntimeTerminalConformance,
      `HexIntervalMathlib.RuntimeRuleConformance,
      `HexIntervalMathlib.RuntimeEmitConformance,
      `HexIntervalMathlib.ProgramProofConformance,
      `HexIntervalMathlib.DriverConformance,
      `HexIntervalMathlib.ControllerConformance,
      `HexIntervalMathlib.ExecutableControllerConformance,
      `HexIntervalMathlib.RuleConformance,
      `HexIntervalMathlib.FrontendConformance,
      `HexIntervalMathlib.TacticConformance,
      `HexIntervalMathlib.MixedFunctionsConformance,
      `HexIntervalMathlib.MixedInstantiationConformance,
      `HexIntervalMathlib.ExactBranchConformance].map Glob.one

-- The expensive complete-family Mathlib proofs are owned only by this
-- non-default library. They are excluded from both merge-gating
-- `HexIntervalMathlibExperiment` and `HexConformance`.
lean_lib HexIntervalPntFks2Local where
  globs := #[`HexIntervalMathlib.Experiment.PntFks2XpowProof00,
    `HexIntervalMathlib.Experiment.PntFks2XpowProof01,
    `HexIntervalMathlib.Experiment.PntFks2XpowProof02,
    `HexIntervalMathlib.Experiment.PntFks2XpowProof03,
    `HexIntervalMathlib.Experiment.PntFks2XpowProof04,
    `HexIntervalMathlib.Experiment.PntFks2XpowProof05,
    `HexIntervalMathlib.Experiment.PntFks2XpowResults,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof00,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof01,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof02,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof03,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof04,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof05,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof06,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof07,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof08,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof09,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof10,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof12,
    `HexIntervalMathlib.Experiment.PntFks2FamilyProof13,
    `HexIntervalMathlib.Experiment.PntFks2Family].map Glob.one

lean_lib HexIntervalPntFks2ConformanceLocal where
  srcDir := "conformance"
  globs := #[`HexIntervalMathlib.PntFks2XpowConformance].map Glob.one

-- The local executable owns the complete runtime and guarded-axiom driver.
lean_exe hex_interval_pnt_fks2_local where
  srcDir := "conformance"
  root := `HexIntervalMathlib.PntFks2FamilyConformance

-- Public umbrellas intentionally contain only the supported API. Executable
-- examples and regression tests are compiled through this separate target so
-- removing them from an umbrella cannot silently remove them from CI.
lean_lib HexReleaseTests where
  globs := #[`HexMatrixMathlib.Tests,
    `HexPolyMathlib.LiteralTests,
    `HexBareissMathlib.Tests,
    `HexBerlekamp.FactorTacticTests,
    `HexBerlekampMathlib.FactorPolyTests,
    `HexBerlekampZassenhaus.FactorTacticTests,
    `HexBerlekampZassenhausMathlib.FactorPolyTests,
    `HexBerlekampZassenhausMathlib.IrreducibilityTests,
    `HexRealRoots.ReplayTest,
    `HexRealRootsMathlib.IsolateRootsTests,
    `HexRealRootsMathlib.IsolateRootsElabTests,
    `HexRealRootsMathlib.SturmTests,
    `HexRealRootsMathlib.RealRootCountTests,
    `HexRootsMathlib.Examples,
    `HexMvPoly.KernelTests,
    `HexSparsePoly.KernelTests,
    `HexGraphIso.TestGraphs,
    `HexGraphIso.SparseTests,
    `HexGraphIso.TacticTests,
    `HexGraphIso.ModuleBoundaryTests,
    `HexGraphIsoMathlib.TacticTests,
    `HexGraphIsoMathlib.SparseTacticTests,
    `HexPermGroupMathlib.Tests,
    `HexNumberFieldTower.Embed,
    `HexRCF.LanguageTests,
    `HexRCF.SturmBuilderTests,
    `HexRCF.CarrierTests,
    `HexRCF.IsolationsTests,
    `HexRCF.SeparationTests,
    `HexRCF.CellsTests,
    `HexRCF.CommonRootTests,
    `HexRCF.SignMatrixTests,
    `HexRCF.BuilderTests,
    `HexRCF.CertificateTests,
    `HexRCF.DecisionTests,
    `HexRCF.ReifyTests,
    `HexRCF.LintTests]
    -- a name array mapped through Glob.one: an array literal this long is
    -- elaborated in chunks, on which the name-to-glob coercion fails
    |>.map Glob.one

-- Build-only regression roots for the three structural matrix frontends.
@[default_target]
lean_lib HexStructuralTacticTests where
  globs := #[`HexPolyDetMathlib.Tests, `HexMinPolyMathlib.Tests, `HexSmithMathlib.Tests, `HexHermiteMathlib.Tests]

lean_lib HexStructuralTacticProofProbe where
  srcDir := "bench"
  globs := #[.submodules `HexMinPolyMathlib.ProofProbe,
    .submodules `HexSmithMathlib.ProofProbe, .submodules `HexHermiteMathlib.ProofProbe]

-- Verification-only modules for the incubating multivariate factorization
-- stack. Keep this separate from the released-test target, whose module list
-- must exactly mirror the repositories already present in the release manifest.
lean_lib HexMvFactorizationTests where
  globs := #[`HexModular.KernelTests,
    `HexModular.LoopTests,
    `HexPolyZGcd.Kernel,
    `HexMvGcd.KernelTests,
    `HexMvGcd.CertTests,
    `HexMvGcd.Eval,
    `HexMvGcd.SquarefreeTests,
    `HexMvHensel.KernelTests,
    `HexMvHensel.ShiftTests,
    `HexMvHensel.UniTests,
    `HexMvHensel.DiophantineTests,
    `HexMvHensel.SeedTests,
    `HexMvHensel.CertTests,
    `HexMvHensel.LiftTests,
    `HexMvHensel.CompleteTests,
    `HexMvFactor.KernelTests,
    `HexMvFactor.KroneckerTests,
    `HexMvFactor.LeadingTests,
    `HexMvFactor.PointTests,
    `HexMvFactor.InputTests,
    `HexMvFactor.EezTests,
    `HexMvFactor.FactorTests,
    `HexMvFactor.CompleteTests]

-- Complete development imports for the two factorization packages. Their
-- ordinary umbrellas deliberately expose only the supported release API.
lean_lib HexFactorizationModules where
  globs := #[`HexBerlekampZassenhaus.All,
    `HexBerlekampZassenhausMathlib.All]

-- Monorepo-only lint regression for the sparse-poly pair; the kernel
-- probes live in HexReleaseTests alongside the release manifest's
-- test_modules entry.
@[default_target]
lean_lib HexSparsePolyTests where
  globs := #[`HexSparsePolyMathlib.LintTests]

-- Monorepo-only lint regression for the incubating truncated-series pair.
-- It moves into the release-manifest-backed test target when the pair is
-- published.
@[default_target]
lean_lib HexTruncatedSeriesTests where
  globs := #[`HexTruncatedSeriesMathlib.LintTests]

-- Monorepo-only lint regression for the integer Smith pair. It moves into the
-- release-manifest-backed test target when the pair is published.
@[default_target]
lean_lib HexSmithTests where
  globs := #[`HexSmith.QuickstartTests,
    `HexSmithMathlib.LintTests,
    `HexSmithMathlib.QuickstartTests]

-- HexCharPoly is not yet a published split repository (its released.yml
-- entries were withdrawn until the phase pipeline completes), so its
-- verification-only elaborator regressions stay separate from the
-- release-manifest-backed target above; they rejoin HexReleaseTests (and
-- the manifest's test_modules) at publication.
@[default_target]
lean_lib HexCharPolyTests where
  globs := #[`HexCharPoly.CharPolyElabTests,
    `HexCharPolyMathlib.CharPolyElabTests]

-- Mirrors the released aggregate's module-system umbrella, so a library that
-- never adopted the module system fails here instead of after the publish-out
-- sync. `check_released_manifest.py` keeps the import list equal to the
-- `leanprover/hex` pins in `scripts/release/released.yml`.
@[default_target]
lean_lib HexAggregateCheck where

-- Canonical end-to-end examples are release artifacts rather than public API.
-- Keep their target separate for the same reason as the regression tests.
lean_lib HexReleaseExamples where
  globs := #[`Examples.Release1, `Examples.Release3, `Examples.Release4, `Examples.Release5,
    `Examples.FiniteFields, `Examples.DeterminantKernelProof, `Examples.RowReduce]

lean_exe hexrowreduce_emit_fixtures where
  srcDir := "conformance"
  root := `HexRowReduce.EmitFixtures

lean_exe hexdeterminant_emit_fixtures where
  srcDir := "conformance"
  root := `HexDeterminant.EmitFixtures

lean_exe hexdeterminant_emit_carrier_fixtures where
  srcDir := "conformance"
  root := `HexDeterminant.EmitCarrierFixtures

lean_exe hexpolydet_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyDet.EmitFixtures

lean_exe hexbareiss_emit_carrier_fixtures where
  srcDir := "conformance"
  root := `HexBareiss.EmitCarrierFixtures

lean_exe hexmodularmatrix_emit_fixtures where
  srcDir := "conformance"
  root := `HexModularMatrix.EmitFixtures

lean_exe hexbareiss_emit_fixtures where
  srcDir := "conformance"
  root := `HexBareiss.EmitFixtures

lean_exe hexdet_emit_fixtures where
  srcDir := "conformance"
  root := `HexDet.EmitFixtures

lean_exe hexdet_emit_carrier_fixtures where
  srcDir := "conformance"
  root := `HexDet.EmitCarrierFixtures

lean_exe hexgenericrank_emit_fixtures where
  srcDir := "conformance"
  root := `HexGenericRank.EmitFixtures

lean_exe hexrank_emit_fixtures where
  srcDir := "conformance"
  root := `HexRank.EmitFixtures

lean_exe hexhermite_emit_fixtures where
  srcDir := "conformance"
  root := `HexHermite.EmitFixtures

lean_exe hexsmith_emit_fixtures where
  srcDir := "conformance"
  root := `HexSmith.EmitFixtures

lean_exe hexcharpoly_emit_carrier_fixtures where
  srcDir := "conformance"
  root := `HexCharPoly.EmitCarrierFixtures

lean_exe hexcharpoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexCharPoly.EmitFixtures

lean_exe hexminpoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexMinPoly.EmitFixtures

lean_exe hexgramschmidt_emit_fixtures where
  srcDir := "conformance"
  root := `HexGramSchmidt.EmitFixtures

lean_exe hexlll_emit_fixtures where
  srcDir := "conformance"
  root := `HexLLL.EmitFixtures

lean_exe hexlatticeenum_emit_fixtures where
  srcDir := "conformance"
  root := `HexLatticeEnum.EmitFixtures

lean_exe hexrealroots_emit_fixtures where
  srcDir := "conformance"
  root := `HexRealRoots.EmitFixtures

lean_exe hexrcf_emit_fixtures where
  srcDir := "conformance"
  root := `HexRCF.EmitFixtures

lean_exe hexroots_emit_fixtures where
  srcDir := "conformance"
  root := `HexRoots.EmitFixtures

lean_exe hexrealalgebraic_emit_fixtures where
  srcDir := "conformance"
  root := `HexRealAlgebraic.EmitFixtures

lean_exe hexrealalgebraic_conformance where
  srcDir := "conformance"
  root := `HexRealAlgebraic.RunChecks

lean_exe hexnumberfield_emit_fixtures where
  srcDir := "conformance"
  root := `HexNumberField.EmitFixtures

lean_exe hexnumberfieldtower_emit_fixtures where
  srcDir := "conformance"
  root := `HexNumberFieldTower.EmitFixtures

lean_exe hexresultant_emit_fixtures where
  srcDir := "conformance"
  root := `HexResultant.EmitFixtures

lean_exe hexsparsepoly_bench where
  srcDir := "bench"
  root := `HexSparsePoly.Bench

lean_exe hexsparsepoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexSparsePoly.EmitFixtures

lean_exe hexmvpoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexMvPoly.EmitFixtures

lean_exe hexdeterminantalideal_emit_fixtures where
  srcDir := "conformance"
  root := `HexDeterminantalIdeal.EmitFixtures

lean_exe hextruncatedseries_emit_fixtures where
  srcDir := "conformance"
  root := `HexTruncatedSeries.EmitFixtures

lean_exe hexmodular_emit_fixtures where
  srcDir := "conformance"
  root := `HexModular.EmitFixtures

lean_exe hexgraphiso_emit_fixtures where
  srcDir := "conformance"
  root := `HexGraphIso.EmitFixtures

lean_exe hexgraphiso_sparse_probe where
  srcDir := "conformance"
  root := `HexGraphIso.SparseProbe

lean_exe hexgraphiso_emit_sparse where
  srcDir := "conformance"
  root := `HexGraphIso.EmitSparse

lean_exe hexgraphiso_sparse_bench where
  srcDir := "bench"
  root := `HexGraphIso.SparseBench

lean_exe hexpermgroup_emit_fixtures where
  srcDir := "conformance"
  root := `HexPermGroup.EmitFixtures

lean_exe hexgraphiso_emit_campaign where
  srcDir := "conformance"
  root := `HexGraphIso.EmitCampaign

lean_exe hexpolyzgcd_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyZGcd.EmitFixtures

lean_exe hexpolysmith_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolySmith.EmitFixtures

lean_exe hexrationalfn_emit_fixtures where
  srcDir := "conformance"
  root := `HexRationalFn.EmitFixtures

lean_exe hexmodular_bench where
  srcDir := "bench"
  root := `HexModular.Bench
  extraDepTargets := #[`HexModularBenchSupport]

lean_exe hexmvgcd_emit_fixtures where
  srcDir := "conformance"
  root := `HexMvGcd.EmitFixtures

lean_exe hexmvhensel_emit_fixtures where
  srcDir := "conformance"
  root := `HexMvHensel.EmitFixtures

lean_exe hexmvfactor_emit_fixtures where
  srcDir := "conformance"
  root := `HexMvFactor.EmitFixtures

lean_exe hexroots_bench where
  srcDir := "bench"
  root := `HexRoots.Bench

lean_exe hexresultant_bench where
  srcDir := "bench"
  root := `HexResultant.Bench

lean_exe hexnumberfield_bench where
  srcDir := "bench"
  root := `HexNumberField.Bench

lean_exe hexnumberfieldtower_bench where
  srcDir := "bench"
  root := `HexNumberFieldTower.Bench

lean_exe hexroots_demo where
  srcDir := "examples"
  root := `HexRootsDemo

lean_exe hexmatrix_bench where
  srcDir := "bench"
  root := `HexMatrix.Bench

-- The graph_iso fresh-module probes (SPEC/hex-graph-iso § Benchmarks and
-- SPEC/hex-graph-iso-mathlib § Tests): build-only structural checks of the
-- four release probe cases on each tactic route. The scheduled-only CFI
-- pair has its own target so the merge build stays inside its budget.
lean_lib HexGraphIsoProofProbe where
  srcDir := "bench"
  globs := #[`HexGraphIso.ProofProbe.Support,
    `HexGraphIso.ProofProbe.Baseline,
    `HexGraphIso.ProofProbe.Positive12,
    `HexGraphIso.ProofProbe.Negative12,
    `HexGraphIso.ProofProbe.Coloured10Pos,
    `HexGraphIso.ProofProbe.Coloured10Neg]

lean_lib HexGraphIsoCfiProbe where
  srcDir := "bench"
  globs := #[`HexGraphIso.ProofProbe.Support, `HexGraphIso.ProofProbe.Cfi]

lean_lib HexGraphIsoSparseProofProbe where
  srcDir := "bench"
  moreLeanArgs := #["-Dprofiler=true"]
  globs := #[`HexGraphIso.SparseProofProbe.Support,
    `HexGraphIso.SparseProofProbe.Baseline,
    `HexGraphIso.SparseProofProbe.Positive12,
    `HexGraphIso.SparseProofProbe.Negative12,
    `HexGraphIso.SparseProofProbe.Coloured10Pos,
    `HexGraphIso.SparseProofProbe.Coloured10Neg]

lean_lib HexGraphIsoSparseCfiProbe where
  srcDir := "bench"
  moreLeanArgs := #["-Dprofiler=true"]
  globs := #[`HexGraphIso.SparseProofProbe.Support, `HexGraphIso.SparseProofProbe.Cfi]

lean_lib HexGraphIsoMathlibProofProbe where
  srcDir := "bench"
  globs := #[`HexGraphIsoMathlib.ProofProbe.Support,
    `HexGraphIsoMathlib.ProofProbe.MathlibBaseline,
    `HexGraphIsoMathlib.ProofProbe.MathlibPositive10,
    `HexGraphIsoMathlib.ProofProbe.MathlibNegative10,
    `HexGraphIsoMathlib.ProofProbe.MathlibPositive12,
    `HexGraphIsoMathlib.ProofProbe.MathlibNegative12]

lean_exe hexgraphiso_bench where
  srcDir := "bench"
  root := `HexGraphIso.Bench

lean_exe hexpermgroup_bench where
  srcDir := "bench"
  root := `HexPermGroup.Bench

-- Local/scheduled per-instance sweep for the cactus plots
-- (scripts/plots/hexgraphiso-cactus.py); not part of merge CI.
lean_exe hexgraphiso_cactus where
  srcDir := "bench"
  root := `HexGraphIso.Cactus

-- Stage-decomposition profiler for the canonicalization pipeline
-- (local tool; see bench/HexGraphIso/Profile.lean for methodology).
lean_exe hexgraphiso_profile where
  srcDir := "bench"
  root := `HexGraphIso.Profile

lean_exe hexrowreduce_bench where
  srcDir := "bench"
  root := `HexRowReduce.Bench

lean_exe hexdeterminant_bench where
  srcDir := "bench"
  root := `HexDeterminant.Bench

lean_exe hexdeterminantalideal_bench where
  srcDir := "bench"
  root := `HexDeterminantalIdeal.Bench

lean_exe hexmodularmatrix_bench where
  srcDir := "bench"
  root := `HexModularMatrix.Bench

lean_exe hexpolydet_bench where
  srcDir := "bench"
  root := `HexPolyDet.Bench

lean_exe hexbareiss_bench where
  srcDir := "bench"
  root := `HexBareiss.Bench

lean_exe hexdet_bench where
  srcDir := "bench"
  root := `HexDet.Bench

lean_exe hexgenericrank_bench where
  srcDir := "bench"
  root := `HexGenericRank.Bench

lean_exe hexrank_bench where
  srcDir := "bench"
  root := `HexRank.Bench

lean_exe hexhermite_bench where
  srcDir := "bench"
  root := `HexHermite.Bench

lean_exe hexsmith_bench where
  srcDir := "bench"
  root := `HexSmith.Bench

lean_exe hexcharpoly_bench where
  srcDir := "bench"
  root := `HexCharPoly.Bench

lean_exe hexminpoly_bench where
  srcDir := "bench"
  root := `HexMinPoly.Bench

lean_exe hexgramschmidt_bench where
  srcDir := "bench"
  root := `HexGramSchmidt.Bench

lean_exe hexrealroots_bench where
  srcDir := "bench"
  root := `HexRealRoots.Bench

lean_exe hexrcf_bench where
  srcDir := "bench"
  root := `HexRCF.Bench

lean_exe hexlll_bench where
  srcDir := "bench"
  supportInterpreter := true
  root := `HexLLLBench.Main

lean_exe hexlll_gram_bench where
  srcDir := "bench"
  root := `HexLLLBench.GramBench

lean_exe hex_arith_floor where
  srcDir := "bench"
  root := `HexBench.ArithFloor

lean_exe hex_interval_representation_spike where
  srcDir := "bench"
  root := `HexBench.IntervalRepresentationSpike

lean_exe hex_interval_center_spike where
  srcDir := "bench"
  root := `HexBench.IntervalCenterSpike

lean_exe hex_interval_scale_spike where
  srcDir := "bench"
  root := `HexBench.IntervalScaleSpike

lean_exe hex_interval_scheduler_spike where
  srcDir := "bench"
  root := `HexInterval.IntervalSchedulerSpike

lean_exe hex_interval_policy_frontier_spike where
  srcDir := "bench"
  root := `HexInterval.IntervalPolicyFrontierSpike

lean_exe hexinterval_decision_bench where
  srcDir := "bench"
  root := `HexInterval.DecisionBench

lean_exe hexbz_factor_service where
  srcDir := "bench"
  root := `HexBench.FactorService

lean_exe hexbz_root_split_probe where
  srcDir := "bench"
  root := `HexBench.RootSplitProbe

lean_exe hexarith_bench where
  srcDir := "bench"
  root := `HexArith.Bench

lean_exe hexpoly_bench where
  srcDir := "bench"
  root := `HexPoly.Bench

lean_exe hexpolysmith_bench where
  srcDir := "bench"
  root := `HexPolySmith.Bench

lean_exe hexmvpoly_bench where
  srcDir := "bench"
  root := `HexMvPoly.Bench

lean_exe hexreflect_bench where
  srcDir := "bench"
  root := `HexReflect.Bench

lean_exe hexmvgcd_bench where
  srcDir := "bench"
  root := `HexMvGcd.Bench

lean_exe hextruncatedseries_bench where
  srcDir := "bench"
  root := `HexTruncatedSeries.Bench

lean_exe hexpolyfast_bench where
  srcDir := "bench"
  root := `HexPolyFast.Bench

lean_exe hexrationalfn_bench where
  srcDir := "bench"
  root := `HexRationalFn.Bench

lean_lib HexRationalFnBenchSupport where
  srcDir := "bench"
  roots := #[`HexRationalFn.Scaling, `HexRationalFn.Families,
    `HexRationalFn.Workloads, `HexRationalFn.Fixtures]

lean_lib HexRationalFnKernelProbe where
  srcDir := "bench"
  globs := #[`HexRationalFn.ProofProbe.Support, `HexRationalFn.ProofProbe.Baseline,
    `HexRationalFn.ProofProbe.Replay4, `HexRationalFn.ProofProbe.Replay16,
    `HexRationalFn.ProofProbe.Replay64, `HexRationalFn.ProofProbe.Reject64]

lean_exe hexpolyfast_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyFast.EmitFixtures

lean_exe hexpoly_emit_fixtures where
  srcDir := "conformance"
  root := `HexPoly.EmitFixtures

lean_exe hexkronecker_emit_fixtures where
  srcDir := "conformance"
  root := `HexKronecker.EmitFixtures

lean_exe hexkronecker_bench where
  srcDir := "bench"
  root := `HexKronecker.Bench

lean_lib HexKroneckerMathlibProofProbe where
  srcDir := "bench"
  globs := #[.submodules `HexKroneckerMathlib.ProofProbe]

lean_exe hexpolyfp_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyFp.EmitFixtures

lean_exe hexberlekamp_emit_fixtures where
  srcDir := "conformance"
  root := `HexBerlekamp.EmitFixtures

lean_exe hexbz_emit_fixtures where
  srcDir := "conformance"
  root := `HexBerlekampZassenhaus.EmitFixtures

lean_exe hexbz_bench where
  srcDir := "bench"
  root := `HexBerlekampZassenhaus.Bench

lean_exe hexgfq_emit_fixtures where
  srcDir := "conformance"
  root := `HexGFq.EmitFixtures

lean_exe hexgf2_emit_fixtures where
  srcDir := "conformance"
  root := `HexGF2.EmitFixtures

lean_exe hexhensel_emit_fixtures where
  srcDir := "conformance"
  root := `HexHensel.EmitFixtures

lean_exe hexprimality_emit_fixtures where
  srcDir := "conformance"
  root := `HexPrimality.EmitFixtures

lean_exe hexintfactor_emit_fixtures where
  srcDir := "conformance"
  root := `HexIntFactor.EmitFixtures

lean_exe hexconway_emit_fixtures where
  srcDir := "conformance"
  root := `HexConway.EmitFixtures

lean_exe hexgfqring_emit_fixtures where
  srcDir := "conformance"
  root := `HexGFqRing.EmitFixtures

lean_exe hexgfqfield_emit_fixtures where
  srcDir := "conformance"
  root := `HexGFqField.EmitFixtures

lean_exe hexpolyz_bench where
  srcDir := "bench"
  root := `HexPolyZ.Bench

lean_exe hexpolyzgcd_bench where
  srcDir := "bench"
  root := `HexPolyZGcd.Bench

lean_exe hexpolyz_kronecker_crossover where
  srcDir := "bench"
  root := `HexPolyZ.KroneckerCrossover

lean_exe hexpolyz_emit_fixtures where
  srcDir := "conformance"
  root := `HexPolyZ.EmitFixtures

lean_exe hexmodarith_bench where
  srcDir := "bench"
  root := `HexModArith.Bench

lean_exe hexgf2_bench where
  srcDir := "bench"
  root := `HexGF2Bench

-- No bench exes for `Hex*Mathlib` libraries — see
-- SPEC/benchmarking.md §Mathlib-free benches. The Mathlib-side libraries
-- are proof-only; there is no computational kernel to benchmark.

lean_exe hexpolyfp_bench where
  srcDir := "bench"
  root := `HexPolyFp.Bench

lean_exe hexgfqring_bench where
  srcDir := "bench"
  root := `HexGFqRing.Bench

lean_exe hexgfqfield_bench where
  srcDir := "bench"
  root := `HexGFqField.Bench

lean_exe hexgfq_bench where
  srcDir := "bench"
  root := `HexGFq.Bench

lean_exe hexhensel_bench where
  srcDir := "bench"
  root := `HexHensel.Bench

lean_exe hexprimality_bench where
  srcDir := "bench"
  root := `HexPrimality.Bench

lean_exe hexprimality_policy_probe where
  srcDir := "bench"
  root := `HexPrimality.PolicyProbe

lean_exe hexprimality_fuel_probe where
  srcDir := "bench"
  root := `HexPrimality.FuelProbe

lean_exe hexintfactor_bench where
  srcDir := "bench"
  root := `HexIntFactor.Bench

lean_exe hexberlekamp_bench where
  srcDir := "bench"
  root := `HexBerlekamp.Bench

-- Local (non-CI, non-LeanBench) comparison driver for the Strassen base-kernel
-- measurement; emits JSON for `scripts/plots/strassen-base-kernel-comparison.py`.
lean_exe hexstrassen_compare where
  srcDir := "bench"
  root := `HexStrassen.Compare

lean_exe hexconway_replay where
  srcDir := "bench"
  root := `HexConway.Replay

lean_exe hexconway_bench where
  srcDir := "bench"
  root := `HexConway.Bench

@[default_target]
lean_lib HexManual where

-- Renders `HexManual` to static HTML (see `Main.lean`). Not a
-- `default_target`: the site is built explicitly by the Pages workflow
-- (`.github/workflows/pages.yml`) and on demand via `lake exe hexmanual`.
lean_exe hexmanual where
  root := `Main

lean_exe hexlatticeenum_bench where
  srcDir := "bench"
  root := `HexLatticeEnum.Bench

lean_exe tower_factor_diff where
  srcDir := "bench"
  root := `HexNumberFieldTower.FactorDiff

lean_exe hexgraphiso_emit_trace where
  srcDir := "conformance"
  root := `HexGraphIso.EmitTrace

lean_exe hexnumberfield_quadratic where
  srcDir := "bench"
  root := `HexNumberField.Quadratic

lean_lib HexCharPolyMathlibProofProbe where
  srcDir := "bench"
  globs := #[.submodules `HexCharPolyMathlib.ProofProbe]
