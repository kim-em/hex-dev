from pathlib import Path
import gzip
import hashlib
import json
import subprocess

repo = Path.cwd()
task = Path('/home/kim/.codex/tasks/hex-10358')
out = repo / 'reports/data/hexrcf-cell-quotation'
out.mkdir(parents=True, exist_ok=True)
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source = git('rev-parse', '465ee034ca').decode().strip()
old = json.loads((repo / 'reports/data/hexrcf-replay-helpers/context.json').read_text())
paths = set(old['sources']) | {
    p for p in git('diff', '--name-only', 'origin/main', source).decode().splitlines()
    if not p.startswith('reports/')}
record = dict(source_commit=source,
    source_tree=git('rev-parse', source + '^{tree}').decode().strip(),
    baseline_commit=git('rev-parse', '372368f8a5').decode().strip(),
    prior_evidence_source=old['source_commit'], sources={}, artifacts=[], validation={},
    unchanged_guards=old['unchanged_guards'], compiled_files=[],
    constant_source_accepted=True, rational_quadratic_packet_accepted=True,
    algebraic_original_source_accepted=False)
for p in sorted(paths):
    raw = git('show', source + ':' + p)
    assert (repo / p).read_bytes() == raw, p
    record['sources'][p] = sha(raw)

def retain(file, path, compress=False):
    raw = file.read_bytes()
    dest = out / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(gzip.compress(raw, mtime=0) if compress else raw)
    saved = dest.read_bytes()
    item = dict(path=path, bytes=len(saved), sha256=sha(saved))
    if compress:
        item['uncompressed_sha256'] = sha(raw)
    record['artifacts'].append(item)
    return path

for key, name in dict(integration='cell-pointwise-expanded-3.log',
    controls='cell-pointwise-quadratic-6.log', audit='cell-pointwise-audit-5.log',
    repairs='cell-pointwise-repaired-2.log', recursive='cell-recursive-repaired-1.log',
    render='cell-quotation-render-2.log', browser='cell-quotation-browser-2.log').items():
    assert 'code=exited, status=0/SUCCESS' in (task / name).read_text(), name
    record['validation'][key] = retain(task / name, 'validation/' + name + '.gz', True)
metadata = json.loads((task / 'cell-pointwise-final-metadata.json').read_text())
assert all(row['exit_code'] == 0 for row in metadata)
retain(task / 'cell-pointwise-final-metadata.json', 'validation/metadata.json')
for row in metadata:
    retain(task / row['log'], 'validation/' + row['log'] + '.gz', True)
for name in ['cell-pointwise-final-metadata.py', 'cell-pointwise-expanded-targets.txt',
             'cell-quotation-memory-policy.txt', 'collect-cell-quotation.py']:
    retain(task / name, 'validation/' + name + '.gz', True)
retain(task / 'bin/run-bounded', 'validation/run-bounded.sh')
retain(task / 'scalar-review-render/CellQuotationReviewRender.lean', 'validation/render.lean.txt')
retain(task / 'cell-quotation-browser.mjs', 'captures/browser.mjs')
for name, dest in [('cell-quotation-final-inspection.json', 'inspection.json'),
                   ('cell-quotation-final-section-overflow.json', 'section-overflow.json')]:
    retain(task / 'scalar-review-render' / name, 'captures/' + dest)
review = json.loads((task / 'cell-quotation-visual-review.json').read_text())
assert len(review['captures']) == 18
for item in review['captures']:
    file = Path(item['path'])
    assert item['viewed'] and sha(file.read_bytes()) == item['sha256']
    item['path'] = retain(file, 'captures/' + file.name)
(out / 'captures/visual-review.json').write_text(json.dumps(review, indent=2) + '\n')
retain(out / 'captures/visual-review.json', 'captures/visual-review.json')
prefixes = ['cell-pointwise-', 'cell-helper-cost-', 'cell-recursive-',
    'cell-stages-', 'fresh-staged-', 'constructor-metadata-', 'formula-shape-',
    'row-boundary-probe-', 'cell-collect-equation-', 'cell-parts-rows-',
    'cell-finite-family-', 'cell-quotation-browser-1', 'cell-quotation-render-1']
for file in sorted(task.iterdir()):
    if not any(file.name.startswith(prefix) for prefix in prefixes):
        continue
    if file.is_file() and file.suffix in ['.log', '.json', '.csv', '.txt']:
        retain(file, 'diagnostics/' + file.name + '.gz', True)
    elif file.is_dir() and file.name.endswith('-inputs'):
        for child in sorted(file.rglob('*')):
            if child.is_file():
                retain(child, 'diagnostics/' + str(child.relative_to(task)) + '.gz', True)
for name in ['CellQuoteStages', 'CellQuoteStageProofs', 'ReplayHelperProofs', 'RecursiveScalarProofs']:
    path = '.lake/build/lib/lean/HexRCF/' + name + '.olean'
    raw = (repo / path).read_bytes()
    record['compiled_files'].append(dict(path=path, bytes=len(raw), sha256=sha(raw)))
record['scope'] = 'Pointwise complete frozen cell quotation, original constant source, two-root rational packet, full37 affected targets/manual and18 actually viewed final captures.'
record['limits'] = 'Fixed inputs only. Full algebraic original-source acceptance and generic source/history assembly remain unproved here. No compiled replay timing, scaling, matched speedup, practical general cost or physical-sharing claim. Failed attempts and task-only diagnostic inputs retain their own versions. Older records keep their pins.'
(out / 'context.json').write_text(json.dumps(record, indent=2) + '\n')
print(f'Retained {len(record["artifacts"])} artifacts/{len(record["sources"])} sources at {source}')
