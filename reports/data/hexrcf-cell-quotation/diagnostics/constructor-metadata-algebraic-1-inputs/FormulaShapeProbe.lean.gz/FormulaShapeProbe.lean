import HexRCF.RealCoefficients.Reify
import HexRCF.Tactic
import Qq
open Lean Meta Qq Hex Hex.RCF.RealCoefficients
namespace FormulaShapeProbe
set_option maxRecDepth 32768
set_option maxHeartbeats 12000000
run_meta do
  withoutExporting do
    let target : Q(Prop) := q(∃ x : ℝ, x ^ 2 - Real.sqrt 2 ≥ 0 ∧
      x ^ 2 - Real.sqrt 2 ≤ 0 ∧ (0 : ℝ) = 0)
    let .ok source ← Reify.prepare target | throwError "source shape probe refused"
    let quantified ← whnf source.formula
    let matrix ← whnf quantified.appArg!
    let formula := matrix.appArg!
    let kind ← inferType formula
    let name := mkPrivateName (← getEnv) (← mkFreshUserName `SharedFormula)
    let retained ← mkAuxDefinition name kind formula (compile := false)
    let equality ← mkEq formula retained
    let proof ← Hex.RCF.checkProof `sharedFormula equality (mkExpectedPropHint (← mkEqRefl formula) equality)
    let axioms ← collectAxioms proof.getAppFn.constName!
    unless axioms.all (fun name => [``propext,``Classical.choice,``Quot.sound].contains name) do
      throwError "formula sharing diagnostic has nonstandard axioms"
    logInfo m!"original source formula shape: sourceReifyUsage={source.usage.proofNodes}; formulaNodes={Hex.Reflect.proofNodeCount #[formula] 1000000}; retainedReferenceNodes={Hex.Reflect.proofNodeCount #[retained] 1000000}; formulaTypeNodes={Hex.Reflect.proofNodeCount #[kind] 1000000}; coefficients={source.coefficients.size}; guards={source.divisors.size}; equality axioms={axioms}"
end FormulaShapeProbe
