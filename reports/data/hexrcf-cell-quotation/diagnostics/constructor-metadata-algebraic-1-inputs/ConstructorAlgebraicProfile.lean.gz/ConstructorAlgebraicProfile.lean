import HexRCF.RootTableQuote.Input
import PhaseQuote
open Lean Meta Qq Hex Hex.RealClosure Hex.SignDet Hex.RCF.RealCoefficients
namespace ConstructorAlgebraicProfile
open Hex.RCF.SelectedRootTests
open Hex.RCF.RealCoefficients.CellReplayTests.Algebraic
open Hex.RCF.RootTableQuoteTests
set_option maxHeartbeats 12000000
set_option maxRecDepth 32768
run_meta do
  withoutExporting do
    let program : Expr := q(@RootTable.read Schema.parent.Value Tower.Signature _ _ _
      (Algebraic.Element.cachedOne reduction reduction_eq Records.facts)
      (Algebraic.Element.cachedAdd reduction reduction_eq Records.facts)
      (Algebraic.Element.cachedSub reduction reduction_eq Records.facts)
      (Algebraic.Element.cachedMul reduction reduction_eq Records.facts)
      (Algebraic.Element.cachedNatCast reduction reduction_eq Records.facts)
      (Algebraic.Element.signCodec Data.base.codec Records.facts) Tower.Signature.codec
      Schema.parent.sign Schema.parent.signature [] input .negInf .posInf Literals.roots)
    PhaseQuote.constructorStats.set {}
    PhaseQuote.contextSerial.set 0
    let basic : Hex.RealFormula.Reify.Config := {}
    let config := {basic with ring := {basic.ring with budget :=
      {basic.ring.budget with proofNodes := 2000000}}}
    let .ok quoted ← PhaseQuote.run program
        (fun expression => liftM (RationalQuote.decoder (mkConst ``Data.registry) expression)) config
      | throwError "algebraic constructor metadata diagnostic refused"
    let statement ← mkEq (← mkAppM ``Except.toOption #[program])
      (← mkAppM ``Option.some #[quoted.value])
    let proof ← Hex.RCF.checkProof `constructorDiagnostic statement quoted.proof
    let axioms ← collectAxioms proof.getAppFn.constName!
    unless axioms.all (fun name => [``propext,``Classical.choice,``Quot.sound].contains name) do
      throwError "constructor diagnostic has nonstandard axioms"
    let mut calls := 0
    let mut nodes := 0
    let mut unique := 0
    let mut rows : Array String := #[]
    for ((serial,constructor),(count,cost)) in (← PhaseQuote.constructorStats.get).toArray do
      calls := calls+count
      nodes := nodes+cost
      unless cost % count == 0 do throwError "constructor metadata cost varied within its context"
      unique := unique+cost/count
      rows := rows.push s!"{serial},{constructor.getAppFn.constName!},{count},{cost},{cost/count}"
    IO.FS.writeFile "/home/kim/.codex/tasks/hex-10358/constructor-metadata-algebraic-1.csv"
      (String.intercalate "\n" rows.toList ++ "\n")
    logInfo m!"constructor metadata diagnostic: totalQuoteNodes={quoted.usage.proofNodes}; constructorTypeCalls={calls}; chargedTypeNodes={nodes}; oncePerContextTypeNodes={unique}; contexts={← PhaseQuote.contextSerial.get}; axioms={axioms}"
end ConstructorAlgebraicProfile
