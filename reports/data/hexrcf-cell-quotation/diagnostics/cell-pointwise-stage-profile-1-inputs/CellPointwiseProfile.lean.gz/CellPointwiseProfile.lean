/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/
import HexRCF.RealCoefficients.NumberField
import HexRCF.RootReplayLiterals
import HexRCF.CellReplay.ZeroLiterals
import HexRCF.CellReplay.Literals
import HexRCF.RealCoefficients.CellQuote
import PhaseCellPointwise
import HexRCF.RealCoefficients.SignatureQuote
import HexRCF.RealCoefficients.RationalQuote
import HexRCF.RealCoefficients.RowQuote
open Lean Meta Qq Hex Hex.RealClosure Hex.SignDet Hex.RCF.RealCoefficients
namespace CellPointwiseProfile
def registry : BaseContext.Registry := fun _ => none
abbrev base := Hex.RealClosure.NumberField.base registry
abbrev signatureData : Codec.Json :=
  .array (.cons RootReplayLiterals.j0
    (.cons (.number 0) (.cons RootReplayLiterals.j0 .nil)))
theorem signature_literal : signatureData = base.signature.literal.toJson := by
  rw [Tower.Context.base_signature]
  unfold BaseContext.rational
  rw [BaseContext.Context.signature_real,BaseContext.RealContext.keys_rational]
  rfl
set_option maxHeartbeats 12000000
set_option maxRecDepth 32768
def operations : Hex.RealClosure.Replay.Operations base.sign :=
  ⟨inferInstance,inferInstance,inferInstance,inferInstance,inferInstance,inferInstance,
    inferInstance,inferInstance,rfl,rfl,rfl,rfl,rfl,rfl,rfl,rfl,base.sign,rfl⟩
def values : Fin 0 → base.Value := Fin.elim0
def matrix (positive : Bool) : Hex.RealFormula.QF 1 :=
  .atom ⟨0,if positive then .eq else .gt⟩
def cert : RadicalCert base.Value Tower.Signature :=
  ⟨base.signature,1,1,1,0⟩
def cells : Codec.Json :=
  .array (.cons CellReplayTests.ZeroLiterals.sections
    (.cons CellReplayTests.ZeroLiterals.sectors .nil))
private meta def decode : RootQuote.DecoderM := fun expression => do
  if let some proof ← RowQuote.decoder expression then return some proof
  if let some proof ← SignatureQuote.decoder q(base.signature)
      (mkConst ``signatureData) (mkConst ``signature_literal) expression then
    return some proof
  liftM (RationalQuote.decoder (mkConst ``registry) expression)

private meta def restored (before : MetavarContext) (sentinel : Expr)
    (names : Option (Array Name) := none) : MetaM Unit := do
  let after ← getMCtx
  unless !(← sentinel.mvarId!.isAssigned) && before.mvarCounter == after.mvarCounter &&
      before.lmvarCounter == after.lmvarCounter && before.eAssignment.toList == after.eAssignment.toList &&
      before.lAssignment.toList == after.lAssignment.toList &&
      before.decls.toList.map Prod.fst == after.decls.toList.map Prod.fst do
    throwError "staged quotation retained caller metavariables"
  if let some names := names then
    unless (← (← getEnv).getLocalConstantInfos).map (·.name) == names do
      throwError "rejected staged quotation retained declarations"

namespace Quadratic
def polynomial : base.Poly := DensePoly.ofCoeffs #[-2,0,1]
def atom : Hex.RealFormula.Poly 1 := MvPoly.X 0 ^ 2 - 2
def matrix : Hex.RealFormula.QF 1 := .and (.atom ⟨atom,.ge⟩)
  (.and (.atom ⟨atom,.le⟩) (.atom ⟨0,.eq⟩))
def cert : RadicalCert base.Value Tower.Signature :=
  ⟨base.signature,polynomial,polynomial,polynomial,1⟩
def cells : Codec.Json := .array (.cons CellReplayTests.Literals.sections
  (.cons CellReplayTests.Literals.sectors .nil))
run_meta do
  withoutExporting do
    let basic : Hex.RealFormula.Reify.Config := {}
    let config := {basic with ring := {basic.ring with budget :=
      {basic.ring.budget with proofNodes := 5000000}}}
    for (quantifier,verdict,suffix) in
        [(Hex.RealFormula.Quantifier.existsReal,true,`existsChecked)] do
      let quantifier : Q(Hex.RealFormula.Quantifier) := match quantifier with
        | .existsReal => q(Hex.RealFormula.Quantifier.existsReal)
        | .forallReal => q(Hex.RealFormula.Quantifier.forallReal)
      let program : Q(Except Replay.Error Bool) := q(CellOperations.check operations
        base.codec values matrix [] cert $(quantifier) RootReplayLiterals.whole cells)
      let quoted ← match ← RootQuote.runWith (PhaseCellPointwise.replayWith program decode) config with
        | .ok quoted => pure quoted
        | .error error => throwError "staged quadratic reader refused {verdict}: {Hex.RealFormula.Reify.Error.toMessageData error}"
      let target ← mkEq (← mkAppM ``Except.toOption #[program])
        (← mkAppM ``Option.some #[toExpr verdict])
      let proof ← Hex.RCF.checkProof `stagedQuadratic target
        (mkExpectedPropHint quoted.proof target)
      withExporting (isExporting := true) do
        addDecl (.thmDecl {
          name := Name.append `CellPointwiseProfile.Quadratic suffix
          levelParams := [],type := target,value := proof})
      logInfo m!"staged two-root quadratic {verdict}: nodes={quoted.usage.proofNodes}"
end Quadratic
end CellPointwiseProfile
