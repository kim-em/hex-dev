import HexRCF.CellQuoteStages
import BoundaryCellQuote
open Lean Meta Qq Hex Hex.RealClosure Hex.SignDet Hex.RCF.RealCoefficients
namespace RowBoundaryProbe
open Hex.RCF.CellQuoteStages
set_option maxHeartbeats 12000000
set_option maxRecDepth 32768
run_meta do
  withoutExporting do
    let program : Q(Except Replay.Error Bool) := q(CellOperations.check operations
      base.codec values (matrix true) [] cert .forallReal RootReplayLiterals.constant cells)
    BoundaryCellQuote.rowHits.set 0
    let basic : Hex.RealFormula.Reify.Config := {}
    let config := {basic with ring := {basic.ring with budget :=
      {basic.ring.budget with proofNodes := 2000000}}}
    let .ok quoted ← RootQuote.runWith (BoundaryCellQuote.replayWith program fun expression => do
        if let some proof ← SignatureQuote.decoder q(base.signature)
            (mkConst ``signatureData) (mkConst ``signature_literal) expression then
          return some proof
        liftM (RationalQuote.decoder (mkConst ``registry) expression)) config
      | throwError "constructor metadata diagnostic refused"
    let statement ← mkEq (← mkAppM ``Except.toOption #[program])
      (← mkAppM ``Option.some #[mkConst ``Bool.true])
    let proof ← Hex.RCF.checkProof `constructorDiagnostic statement quoted.proof
    let axioms ← collectAxioms proof.getAppFn.constName!
    unless axioms.all (fun name => [``propext,``Classical.choice,``Quot.sound].contains name) do
      throwError "constructor diagnostic has nonstandard axioms"
    logInfo m!"row boundary diagnostic: nodes={quoted.usage.proofNodes}; rowHits={← BoundaryCellQuote.rowHits.get}; axioms={axioms}"
end RowBoundaryProbe
