import TowerCompileProbe
import HexRCF.SelectedRoot.Data

open Lean Meta Qq Hex Hex.RCF.RealCoefficients
open Hex.RCF.SelectedRootTests

set_option maxRecDepth 32768
set_option maxHeartbeats 8000000

private meta def leaf (source : Expr) : Hex.RealFormula.Reify.ReifyM (Option TowerCompile.Term) := do
  if source == q(Real.sqrt 2) then
    return some ⟨mkConst ``Data.alpha,mkConst ``Data.alpha_value⟩
  return none

private meta def action (source : Expr) : Hex.RealFormula.Reify.ReifyM RootQuote.Result := do
  let term ← TowerCompile.compile (mkConst ``Data.original) leaf source
  return ⟨term.expression,term.proof,(← get).budget.consumed⟩

run_meta do
  let sources : Array Expr := #[q((2 : ℝ)),q((-3 : ℝ)),q((1 / 7 : ℝ)),
    q(((3 / 2 : ℚ) : ℝ)),q(Real.sqrt 2 + 3),q(Real.sqrt 2 - 1),
    q((Real.sqrt 2 - 1)^3 / (Real.sqrt 2 + 1)),q((Real.sqrt 2)⁻¹),
    q((Real.sqrt 2)^0)]
  for source in sources do
    let .ok result ← RootQuote.runWith (action source)
      | throwError "tower arithmetic quotation declined a supported source"
    let target ← mkEq (← mkAppM ``RealClosure.Tower.Model.value
      #[mkConst ``Data.original,result.value]) source
    unless ← isDefEq (← inferType result.proof) target do
      throwError "tower arithmetic quotation changed its source"
    let name ← mkFreshUserName `towerCompiled
    addDecl (.thmDecl {name,levelParams := [],type := target,value := result.proof})
    let axioms ← collectAxioms name
    unless axioms.all (#[``propext,``Classical.choice,``Quot.sound].contains ·) do
      throwError "tower arithmetic quotation has a forbidden axiom"
    logInfo m!"tower source {source}: proofNodes={result.usage.proofNodes}"

run_meta do
  let .ok _ ← RootQuote.runWith (do
      let marker ← mkFreshExprMVar (mkConst ``Nat)
      let declaration ← mkFreshUserName `declinedLeaf
      let decline := fun (_ : Expr) => do
        marker.mvarId!.assign (mkNatLit 42)
        let _ ← mkAuxDefinition declaration (mkConst ``Nat) (mkNatLit 42) (compile := false)
        pure (none : Option TowerCompile.Term)
      let term ← TowerCompile.compile (mkConst ``Data.original) decline q((3 : ℝ))
      if ← marker.mvarId!.isAssigned then throwError "declined leaf assigned caller metavariable"
      if (← getEnv).contains declaration then throwError "declined leaf retained a declaration"
      pure ⟨term.expression,term.proof,(← get).budget.consumed⟩)
    | throwError "declining leaf unexpectedly rejected rational compilation"
  logInfo "declining leaf restored metavariables and declarations inside the request"

run_meta do
  let before ← saveState
  let rejected ← try
    let _ ← RootQuote.runWith (do
      let term ← TowerCompile.compile (mkConst ``Data.original)
        (fun _ => pure (some ⟨mkConst ``Data.alpha,mkConst ``Data.alpha_value⟩)) q((0 : ℝ))
      pure ⟨term.expression,term.proof,(← get).budget.consumed⟩)
    pure false
  catch _ => pure true
  unless rejected do throwError "wrong source identity was accepted"
  before.restore
  let config : Hex.RealFormula.Reify.Config := {}
  let config := {config with ring := {config.ring with budget :=
    {config.ring.budget with proofNodes := 1}}}
  let .error (.budget _) ← RootQuote.runWith (action q(Real.sqrt 2 + 1)) config
    | throwError "tower source quotation did not preserve budget refusal"
  logInfo "wrong source identity rejected and aggregate budget refusal retained"
