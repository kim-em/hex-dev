import HexRCF.SourceIdentityCases
import HexRCF.RealCoefficients.ScalarPacket
import HexSignDet.Codec.Bytes
open Hex Hex.RealClosure Hex.SignDet Hex.RCF.RealCoefficients
open Hex.RCF.SelectedRootTests Hex.RCF.SourceIdentityCases
#eval (show IO Unit from do
  let some equation := ScalarPacket.build Data.native Data.base.codec
      (embed (ZPoly.toRatPoly SquareTwo.polynomial))
    | throw (IO.userError "equation packet production rejected")
  let some enclosure := ScalarPacket.build Data.native Data.base.codec
      (embed (SourceIdentity.margin SquareTwo.square))
    | throw (IO.userError "enclosure packet production rejected")
  let some negative := ScalarPacket.build Data.native Data.base.codec
      (embed (SourceIdentity.margin negativeSquare))
    | throw (IO.userError "negative enclosure packet production rejected")
  let packet := Codec.Json.arr #[equation,enclosure,negative]
  IO.FS.writeBinFile "/home/kim/.codex/tasks/hex-10358/source-identity-packets.json" packet.writeBytes
  IO.println s!"Produced three source-identity proposals ({packet.writeBytes.size} bytes); not proof evidence")
