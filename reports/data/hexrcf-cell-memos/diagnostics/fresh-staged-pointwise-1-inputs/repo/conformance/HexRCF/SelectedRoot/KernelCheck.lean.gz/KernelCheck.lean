/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/

import HexRCF.SelectedRoot.Read
import HexRealClosure.RootPolicy
import Lean.Elab.Command

meta section
namespace Hex.RCF.SelectedRootTests.KernelCheck
open Hex.RCF.SelectedRootTests
open Lean Meta Hex.RealClosure Hex.SignDet
open Hex.RealClosure.Algebraic

/-- Common producer boundary for whole acceptances and their named leaves. -/
def producers : Array Name := #[``Read.rootRead, ``Hex.RealClosure.Roots.roots?, ``Hex.RealClosure.Roots.roots,
    ``Hex.RealClosure.Roots.Policy.roots?, ``Hex.RealClosure.Roots.Policy.roots,
    ``Tower.Sample.roots, ``Tower.Context.roots, ``Tower.Context.roots?, ``NumberField.roots, ``NumberField.roots?,
    ``NumberField.Presentation.roots, ``NumberField.Presentation.roots?, ``Algebraic.Context.signPoly,
    ``Algebraic.Context.buildSigns, ``Descriptor.buildSigns, ``Descriptor.buildSignsPrepared,
    ``Hex.SignDet.buildPrepared, ``Hex.SignDet.buildTree, ``Hex.SignDet.buildTreeFrom,
    ``Algebraic.Element.ofPoly, ``Descriptor.prepareQueries]

/-- Return the exact prohibited reduction observed by a checked declaration. -/
def violation? (diagnostics : Kernel.Diagnostics) (extra : Array Name := #[]) : Option (Name × Nat) :=
  (producers ++ extra).findSome? fun name =>
    (diagnostics.unfoldCounter.find? name).map (name, ·)

/-- Check generated replay acceptance with active reduction diagnostics.
The rational parent construction and separately elaborated source theorems are
outside this guard; all frozen scalar, parser, root, row and collected refusal
acceptance proofs pass through it. Shared seed declarations wrap already
checked scalar acceptances separately. Callers can extend the producer denylist
with `extra` without adding imports to this shared fixture helper. -/
def addChecked (name : Name) (type proof : Expr)
    (extra : Array Name := #[]) (required : Array Name := #[]) : MetaM Unit := do
  let options := (← getOptions).setBool `debug.skipKernelTC false
  let environment := Kernel.enableDiag (Kernel.resetDiag (← getEnv)) true
  let env ← ofExceptKernelException <| environment.addDeclCore
    (Core.getMaxHeartbeats options).toUSize (maxRecDepth.get options).toUSize
    (.thmDecl {name, levelParams := [], type, value := proof}) none (doCheck := true)
  let diagnostics := Kernel.getDiagnostics env
  unless diagnostics.enabled do throwError "kernel diagnostics disabled"
  unless !diagnostics.unfoldCounter.isEmpty do throwError "empty kernel diagnostics"
  if let some (name, count) := violation? diagnostics extra then
    throwError "native production unfolded {name}: {count}"
  for name in required do
    unless diagnostics.unfoldCounter.contains name do
      throwError "kernel diagnostics did not observe required reader {name}"
  setEnv (Kernel.enableDiag env false)

end Hex.RCF.SelectedRootTests.KernelCheck
