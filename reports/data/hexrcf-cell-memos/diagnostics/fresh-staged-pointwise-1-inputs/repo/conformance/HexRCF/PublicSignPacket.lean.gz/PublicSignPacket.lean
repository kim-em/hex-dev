/-
Copyright (c) 2026 Lean FRO, LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kim Morrison
-/
module
public import HexRCF.RealCoefficients.ScalarPacketQuote
public import HexRealClosureTheory.NumberFieldTower
public import HexRCF.RootQuoteCases
public import HexRCF.RootQuoteSource
public meta import HexRCF.RootQuoteData
public meta import HexRCF.RootQuoteCases
public meta import HexRCF.RootQuoteSource
public meta import HexRCF.RealCoefficients.ScalarPacketQuote
public meta import HexRCF.RealCoefficients.RationalQuote
public meta import HexRCF.RealCoefficients.RootQuote
public section

/-! Quote the original scalar-packet reader from a public module. Context slots
retain the canonical encoder expression; a fully numerical frozen-context
fixture requires the separate public encoding equation from the owner. -/

open Lean Meta Hex Hex.RealClosure Hex.SignDet Hex.RCF.RealCoefficients
namespace Hex.RCF.PublicSignPacket
set_option maxHeartbeats 12000000
set_option maxRecDepth 32768

@[expose] def context := Algebraic.Context.adjoin RootQuoteTests.nativeRoot RootQuoteTests.base.isClean
@[expose] def polynomial : Codec.Json :=
  .array (.cons RootQuoteTests.j5 (.cons RootQuoteTests.j6 .nil))
@[expose] noncomputable def model := RootQuoteTests.realModel

/-- Construct numerical proposal data; its computation supplies no proof. -/
private meta partial def jsonExpr : Codec.Json → MetaM Expr
  | .number n => pure (mkApp (mkConst ``Codec.Json.Value.number) (mkIntLit n))
  | .array values => do
    let items ← values.toList.mapM jsonExpr
    let data := items.foldr
      (fun item rest => mkApp2 (mkConst ``Codec.Json.Values.cons) item rest)
      (mkConst ``Codec.Json.Values.nil)
    return mkApp (mkConst ``Codec.Json.Value.array) data
  | _ => throwError "public sign fixture expected numerical array data"


/-- This public fixture uses the existing lawful signature encoder at node
contexts. The separate fully frozen public fixture still needs the owner's
encoding equation; no literal/encoding identity is assumed here. -/
private meta def graphExpr (literal expected : Codec.Json) : MetaM Expr := do
  let array := fun (items : List Expr) => mkApp (mkConst ``Codec.Json.Value.array)
    (items.foldr (fun item rest => mkApp2 (mkConst ``Codec.Json.Values.cons) item rest)
      (mkConst ``Codec.Json.Values.nil))
  let .ok graph := literal.getArr? | throwError "public graph is not an array"
  unless graph.size == 3 do throwError "public graph has the wrong width"
  let .ok entries := graph[2]!.getArr? | throwError "public graph entries are not an array"
  let signature ← mkAppM ``Tower.Context.signature #[mkConst ``RootQuoteTests.base]
  let encoded ← mkAppM ``ValueCodec.encode #[mkConst ``Tower.Signature.codec,signature]
  let entries ← entries.toList.mapM fun entry => do
    let .ok fields := entry.getArr? | throwError "public graph entry is not an array"
    unless fields.size == 2 do throwError "public graph entry has the wrong width"
    let .ok node := fields[0]!.getArr? | throwError "public graph node is not an array"
    unless node.size == 11 do throwError "public graph node has the wrong width"
    unless node[0]! == expected do throwError "public graph node changed its context"
    let .ok moments := node[7]!.getArr? | throwError "public moments are not an array"
    let moments ← moments.toList.mapM fun moment => do
      let .ok fields := moment.getArr? | throwError "public moment is not an array"
      unless fields.size == 12 do throwError "public moment has the wrong width"
      unless fields[0]! == expected do throwError "public moment changed its context"
      return array (encoded :: (← (fields.toList.drop 1).mapM jsonExpr))
    let tail ← (node.toList.drop 1).mapM jsonExpr
    let tail := tail.toArray.set! 6 (array moments)
    return array [array (encoded :: tail.toList),← jsonExpr fields[1]!]
  return array [← jsonExpr graph[0]!,← jsonExpr graph[1]!,array entries]

/-- Checked equations for the demanded root binding and encoded signatures. -/
meta def decoder : RootQuote.DecoderM := fun expression => do
  if (expression.getUsedConstants.contains ``context ||
      expression.getUsedConstants.contains ``RootQuoteTests.nativeRoot) &&
      (← withTransparency .reducible <| whnf (← inferType expression)).isConstOf ``Bool then
    let result ← liftM do
      let mut laws : SimpTheorems := {}
      laws ← laws.addDeclToUnfold ``context
      laws ← laws.addConst ``Algebraic.Context.root_adjoin
      laws ← laws.addConst ``RootQuoteTests.root_raw
      let simpContext ← Simp.mkContext {maxSteps := 100000} #[laws]
      let (result,_) ← Meta.simp expression simpContext
      pure result
    if result.expr != expression then
      return some (← liftM (result.getProof' expression))
  let codec? := match expression.getAppFn with
    | .proj ``ValueCodec 1 codec =>
      if expression.getAppNumArgs == 1 then some codec else none
    | .const ``ValueCodec.decode _ =>
      if expression.getAppNumArgs == 3 then some expression.getAppArgs[1]! else none
    | _ => none
  if let some codec := codec? then
    if codec.isConstOf ``Tower.Signature.codec then
      let payload ← withTransparency .all <| whnf expression.getAppArgs.back!
      let signature? := match payload.getAppFn with
        | .proj ``ValueCodec 0 encoder =>
          if encoder.isConstOf ``Tower.Signature.codec && payload.getAppNumArgs == 1 then
            some payload.appArg! else none
        | .const ``ValueCodec.encode _ =>
          if payload.getAppNumArgs == 3 && payload.getAppArgs[1]!.isConstOf ``Tower.Signature.codec then
            some payload.getAppArgs[2]! else none
        | _ => none
      if let some signature := signature? then
        return some (mkApp (mkConst ``Tower.Signature.codec_lawful) signature)
  liftM (RationalQuote.decoder (mkConst ``RootQuoteTests.registry) expression)

meta def quoteConfig : Hex.RealFormula.Reify.Config :=
  let basic : Hex.RealFormula.Reify.Config := {}
  {basic with ring := {basic.ring with budget :=
    {basic.ring.budget with proofNodes := 2000000}}}

run_meta do
  withExporting (isExporting := false) do
    let codec ← mkAppM ``Tower.Context.codec #[mkConst ``RootQuoteTests.base]
    let proposal ← mkAppM ``ScalarPacket.buildLiteral
      #[mkConst ``context,codec,mkConst ``polynomial]
    let some packet ← evalExpr (Option Codec.Json) (← inferType proposal) proposal
      | throwError "public sign packet producer declined"
    let .ok fields := packet.getArr? | throwError "public packet is not an array"
    unless fields.size == 3 do throwError "public packet has the wrong width"
    let .ok sign := fields[1]!.getInt? | throwError "public packet has no sign"
    unless sign == 1 do throwError "public packet has the wrong proposed sign"
    let signature ← mkAppM ``Tower.Context.signature #[mkConst ``RootQuoteTests.base]
    let encoded ← mkAppM ``ValueCodec.encode #[mkConst ``Tower.Signature.codec,signature]
    let expected ← evalExpr Codec.Json (mkConst ``Codec.Json.Value) encoded
    let evidence ← graphExpr fields[2]! expected
    withExporting (isExporting := true) do
      let declaration := Declaration.defnDecl {
        name := `Hex.RCF.PublicSignPacket.evidence,levelParams := [],
        type := mkConst ``Codec.Json.Value,value := evidence,hints := .regular 0,safety := .safe}
      addDecl declaration (forceExpose := true)
      compileDecl declaration (logErrors := true)
    let reader ← mkAppM ``ScalarPacket.read
      #[mkConst ``model,codec,mkConst ``context,mkConst ``polynomial,mkIntLit 1,
        mkConst `Hex.RCF.PublicSignPacket.evidence]
    let outcome ← RootQuote.runWith (RootQuote.quoteOptionWith reader decoder) quoteConfig
    let quoted ← match outcome with
      | .ok result => pure result
      | .error error => throwError "public sign packet quotation: {Hex.RealFormula.Reify.Error.toMessageData error}"
    logInfo m!"original optional reader quoted; nodes={quoted.usage.proofNodes}"
    let factType ← inferType quoted.value
    withExporting (isExporting := true) do
      let declaration := Declaration.defnDecl {
        name := `Hex.RCF.PublicSignPacket.fact,levelParams := [],
        type := factType,value := quoted.value,hints := .regular 0,safety := .safe}
      addDecl declaration (forceExpose := true)
      compileDecl declaration (logErrors := true)
    let statement ← mkEq reader (← mkAppM ``Option.some #[mkConst `Hex.RCF.PublicSignPacket.fact])
    let proof ← Hex.RCF.checkProof `publicSignPacket statement quoted.proof
    withExporting (isExporting := true) do
      addDecl (.thmDecl {
        name := `Hex.RCF.PublicSignPacket.read_checked,levelParams := [],type := statement,value := proof})
    logInfo m!"ordinary module sign packet proofNodes={quoted.usage.proofNodes}"

theorem accepted :
    (ScalarPacket.read model RootQuoteTests.base.codec context polynomial 1 evidence).isSome = true := by
  rw [read_checked]
  rfl

theorem sign : fact.sign = 1 :=
  (ScalarPacket.fields model RootQuoteTests.base.codec context polynomial 1 evidence fact read_checked).2

end Hex.RCF.PublicSignPacket
