import RowReadStage
import HexRCF.CellQuoteStages
import HexRCF.ProofEvidence
open Lean Meta Qq Hex Hex.SignDet Hex.RealClosure Hex.RCF.RealCoefficients
namespace RowReadStageProbe
open Hex.RCF.CellQuoteStages
set_option maxRecDepth 32768
set_option maxHeartbeats 24000000
private meta def baseDecode : RootQuote.DecoderM := fun expression => do
  if let some proof ← RowQuote.decoder expression then return some proof
  if let some proof ← SignatureQuote.decoder q(base.signature)
      (mkConst ``signatureData) (mkConst ``signature_literal) expression then return some proof
  liftM (RationalQuote.decoder (mkConst ``registry) expression)
run_meta do
  withoutExporting do
    let program : Q(Except Hex.RCF.RealCoefficients.Replay.Error Bool) :=
      q(CellOperations.check operations base.codec values Quadratic.matrix [] Quadratic.cert
        .existsReal RootReplayLiterals.whole Quadratic.cells)
    let basic : Hex.RealFormula.Reify.Config := {}
    let config := {basic with ring := {basic.ring with budget :=
      {basic.ring.budget with proofNodes := 16000000}}}
    let hits ← IO.mkRef (0 : Nat)
    let quoted ← match ← RootQuote.runWith (CellQuote.replayWith program fun expression => do
        if expression.getAppFn.isConstOf ``RowOperations.read then
          hits.modify (·+1)
          return some (← RowReadStage.quoteWith expression baseDecode)
        baseDecode expression) config with
      | .ok quoted => pure quoted
      | .error error => throwError "staged row probe refused: {Hex.RealFormula.Reify.Error.toMessageData error}"
    let target ← mkEq (← mkAppM ``Except.toOption #[program])
      (← mkAppM ``Option.some #[mkConst ``Bool.true])
    let proof ← Hex.RCF.checkProof `RowReadStageProbe.checked target
      (mkExpectedPropHint quoted.proof target)
    unless (← hits.get) > 0 do throwError "row-stage callback was not reached"
    withExporting (isExporting := true) do
      addDecl (.thmDecl {name := `RowReadStageProbe.checked,levelParams := [],type := target,value := proof})
    let dependencies ← Hex.RCF.ProofEvidence.projectDependencies #[`RowReadStageProbe.checked]
    unless dependencies.contains ``RowReadStage.read_of_parts do
      throwError "row-stage composition absent from actual checked proof"
    logInfo m!"row-stage quadratic: nodes={quoted.usage.proofNodes}; actual callbacks={← hits.get}"
end RowReadStageProbe
