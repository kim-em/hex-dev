import HexRCF.RealCoefficients.RowQuote
import HexRCF.RealCoefficients.RootQuote
open Lean Meta Hex Hex.SignDet Hex.RealClosure Hex.RCF.RealCoefficients
namespace RowReadStage
variable {E Ctx : Type} [Zero E] [DecidableEq E] [One E] [Add E] [Sub E] [Mul E] [NatCast E]
variable [DecidableEq Ctx] {sign : E → Int} {binding : Ctx}

theorem read_of_parts (value : ValueCodec E) (context : ValueCodec Ctx)
    (root : Descriptor E Ctx sign binding) (queries : List (DensePoly E))
    (packet : Codec.Json) (data : Algebraic.SignEvidence E Ctx)
    (selected : SelectedSigns root data.queries)
    (decoded : (Algebraic.SignEvidence.codec value context root.raw).decode packet = .ok data)
    (same : data.queries = queries)
    (checked : data.graph.selectedSigns? root data.queries data.values = some selected) :
    RowOperations.read value context sign binding root queries packet = .ok (same ▸ selected) := by
  simp only [RowOperations.read,decoded,bind,Except.bind]
  rw [dite_eq_left same,checked]

def queryDecision (test : Bool) : Except Hex.RCF.RealCoefficients.Replay.Error Bool :=
  if test then .ok true else .ok false

theorem queryDecision_true (test : Bool)
    (checked : (queryDecision test).toOption = some true) : test = true := by
  cases test <;> simp [queryDecision,Except.toOption] at *

meta def freeze (reader : Expr) (decode : RootQuote.DecoderM) :
    Hex.RealFormula.Reify.ReifyM (Expr × Expr) := do
  let quoted ← RootQuote.quoteWith reader decode
  let kind ← inferType quoted.value
  Hex.RealFormula.Reify.accountProof kind
  Hex.RealFormula.Reify.accountProof quoted.value
  let name := mkPrivateName (← getEnv) (← mkFreshUserName `RowStageData)
  let value ← mkAuxDefinition name kind quoted.value (compile := false)
  let strict ← mkAppM ``RootQuote.read_eq #[reader,quoted.value,quoted.proof]
  let resultType ← whnf (← inferType reader)
  let accepted ← mkAppOptM ``Except.ok
    #[some resultType.getAppArgs[0]!,some resultType.getAppArgs[1]!,some value]
  let target ← mkEq reader accepted
  Hex.RealFormula.Reify.accountProof target
  Hex.RealFormula.Reify.accountProof strict
  return (value,← Hex.RCF.checkProof `RowStage.reader target (mkExpectedPropHint strict target))

meta def quoteWith (reader : Expr) (decode : RootQuote.DecoderM) :
    Hex.RealFormula.Reify.ReifyM Expr := do
  unless reader.getAppFn.isConstOf ``RowOperations.read do throwError "expected original row reader"
  let args := reader.getAppArgs
  let info ← getFunInfoNArgs reader.getAppFn args.size
  let inputs := args.zipIdx |>.filterMap fun (arg,i) =>
    if info.paramInfo[i]!.binderInfo.isExplicit then some arg else none
  unless inputs.size == 7 do throwError "row reader explicit arity changed: {inputs.size}"
  let raw ← mkAppM ``Descriptor.raw #[inputs[4]!]
  let codec ← mkAppM ``Algebraic.SignEvidence.codec #[inputs[0]!,inputs[1]!,raw]
  let parsed ← mkAppM ``ValueCodec.decode #[codec,inputs[6]!]
  let (data,decoded) ← freeze parsed decode
  let queries ← mkAppM ``Algebraic.SignEvidence.queries #[data]
  let equality ← mkEq queries inputs[5]!
  let decision ← mkDecide equality
  let guardReader ← mkAppM ``queryDecision #[decision]
  let guarded ← RootQuote.quoteWith guardReader decode
  unless guarded.value.isConstOf ``Bool.true do
    Hex.RealFormula.Reify.abort (.providerFailure (.invalidProviderEvidence
      ⟨`RowReadStage,0⟩ "literal row query binding rejected") #[])
  let decided ← mkAppM ``queryDecision_true #[decision,guarded.proof]
  let same ← mkAppM ``of_decide_eq_true #[decided]
  Hex.RealFormula.Reify.accountProof equality
  Hex.RealFormula.Reify.accountProof same
  let same ← Hex.RCF.checkProof `RowStage.queries equality same
  let values ← mkAppM ``Algebraic.SignEvidence.values #[data]
  let graph ← mkAppM ``Algebraic.SignEvidence.graph #[data]
  let selected ← mkAppM ``Dag.selectedSigns? #[inputs[4]!,queries,values,graph]
  let quoted ← RootQuote.quoteOptionWith selected decode
  let candidate ← mkAppM ``read_of_parts
    #[inputs[0]!,inputs[1]!,inputs[4]!,inputs[5]!,inputs[6]!,data,quoted.value,
      decoded,same,quoted.proof]
  Hex.RealFormula.Reify.accountProof candidate
  let target ← inferType candidate
  Hex.RealFormula.Reify.accountProof target
  Hex.RCF.checkProof `RowStage.original target candidate
end RowReadStage
