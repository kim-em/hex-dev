import RowReadStage
open Lean Meta Hex Hex.SignDet Hex.RealClosure Hex.RCF.RealCoefficients
namespace RowReadMemo
structure Entry where
  key : Array Expr
  value : Expr
  proof : Expr
structure State where
  entries : Array Entry := #[]
  hits : Nat := 0
  misses : Nat := 0
abbrev Cache := IO.Ref State
meta def restore (cache : Cache) (reader : Expr) (decode : RootQuote.DecoderM) :
    Hex.RealFormula.Reify.ReifyM (Expr × Expr) := do
  let mut key := #[reader.getAppFn]
  for argument in reader.getAppArgs do
    Hex.RealFormula.Reify.charge .proofNodes 1
    let argument ← withTransparency .all (whnf argument)
    Hex.RealFormula.Reify.accountProof argument
    key := key.push argument
  for entry in (← cache.get).entries do
    Hex.RealFormula.Reify.charge .proofNodes 1
    if entry.key == key then
      let target ← mkEq reader (← mkAppM ``Option.some #[entry.value])
      Hex.RealFormula.Reify.accountProof target
      Hex.RealFormula.Reify.accountProof entry.proof
      let checked ← Hex.RCF.checkProof `RowMemo.reused target
        (mkExpectedPropHint entry.proof target)
      cache.modify fun s => {s with hits := s.hits+1}
      return (entry.value,checked)
  let quoted ← RootQuote.quoteOptionWith reader decode
  let kind ← inferType quoted.value
  Hex.RealFormula.Reify.accountProof kind
  Hex.RealFormula.Reify.accountProof quoted.value
  let name := mkPrivateName (← getEnv) (← mkFreshUserName `RowMemoData)
  let value ← mkAuxDefinition name kind quoted.value (compile := false)
  let target ← mkEq reader (← mkAppM ``Option.some #[value])
  Hex.RealFormula.Reify.accountProof target
  Hex.RealFormula.Reify.accountProof quoted.proof
  let checked ← Hex.RCF.checkProof `RowMemo.original target
    (mkExpectedPropHint quoted.proof target)
  cache.modify fun s => {s with
    entries := s.entries.push ⟨key,value,checked⟩
    misses := s.misses+1}
  return (value,checked)
meta def quoteWith (cache : Cache) (reader : Expr) (decode : RootQuote.DecoderM) :
    Hex.RealFormula.Reify.ReifyM Expr := do
  unless reader.getAppFn.isConstOf ``RowOperations.read do throwError "expected original row reader"
  let args := reader.getAppArgs
  let info ← getFunInfoNArgs reader.getAppFn args.size
  let inputs := args.zipIdx |>.filterMap fun (arg,i) =>
    if info.paramInfo[i]!.binderInfo.isExplicit then some arg else none
  unless inputs.size == 7 do throwError "row reader explicit arity changed: {inputs.size}"
  let raw ← mkAppM ``Descriptor.raw #[inputs[4]!]
  let codec ← mkAppM ``Algebraic.SignEvidence.codec #[inputs[0]!,inputs[1]!,raw]
  let parsed ← mkAppM ``ValueCodec.decode #[codec,inputs[6]!]
  let (data,decoded) ← RowReadStage.freeze parsed decode
  let queries ← mkAppM ``Algebraic.SignEvidence.queries #[data]
  let equality ← mkEq queries inputs[5]!
  let decision ← mkDecide equality
  let guardReader ← mkAppM ``RowReadStage.queryDecision #[decision]
  let guarded ← RootQuote.quoteWith guardReader decode
  unless guarded.value.isConstOf ``Bool.true do
    Hex.RealFormula.Reify.abort (.providerFailure (.invalidProviderEvidence
      ⟨`RowReadStage,0⟩ "literal row query binding rejected") #[])
  let decided ← mkAppM ``RowReadStage.queryDecision_true #[decision,guarded.proof]
  let same ← mkAppM ``of_decide_eq_true #[decided]
  Hex.RealFormula.Reify.accountProof equality
  Hex.RealFormula.Reify.accountProof same
  let same ← Hex.RCF.checkProof `RowStage.queries equality same
  let values ← mkAppM ``Algebraic.SignEvidence.values #[data]
  let graph ← mkAppM ``Algebraic.SignEvidence.graph #[data]
  let head ← mkAppM ``RawDescriptor.head #[raw]
  let lower ← mkAppM ``RawDescriptor.lower #[raw]
  let upper ← mkAppM ``RawDescriptor.upper #[raw]
  let validation ← mkAppM ``Dag.validate? #[inputs[2]!,inputs[3]!,head,lower,upper,graph]
  let (memo,validated) ← restore cache validation decode
  let index ← mkAppM ``Dag.root #[graph]
  let selection ← mkAppM ``SelectedSigns.ofMemo? #[inputs[4]!,queries,values,memo,index]
  let quoted ← RootQuote.quoteOptionWith selection decode
  let sameSelection ← mkAppM ``Dag.selectedSigns_memo
    #[inputs[4]!,queries,values,graph,memo,validated]
  let checked ← mkEqTrans (← mkEqSymm sameSelection) quoted.proof
  let candidate ← mkAppM ``RowReadStage.read_of_parts
    #[inputs[0]!,inputs[1]!,inputs[4]!,inputs[5]!,inputs[6]!,data,quoted.value,
      decoded,same,checked]
  Hex.RealFormula.Reify.accountProof candidate
  let target ← inferType candidate
  Hex.RealFormula.Reify.accountProof target
  Hex.RCF.checkProof `RowStage.original target candidate
end RowReadMemo
