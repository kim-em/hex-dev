import RowReadMemo
import HexRCF.CellQuoteStages
import HexRCF.ProofEvidence
open Lean Meta Qq Hex Hex.SignDet Hex.RealClosure Hex.RCF.RealCoefficients
namespace RowReadMemoProbe
open Hex.RCF.CellQuoteStages
set_option maxRecDepth 32768
set_option maxHeartbeats 24000000
private meta def baseDecode : RootQuote.DecoderM := fun expression => do
  if let some proof ← RowQuote.decoder expression then return some proof
  if let some proof ← SignatureQuote.decoder q(base.signature)
      (mkConst ``signatureData) (mkConst ``signature_literal) expression then return some proof
  liftM (RationalQuote.decoder (mkConst ``registry) expression)
run_meta do
  withoutExporting do
    let program : Q(Except Hex.RCF.RealCoefficients.Replay.Error Bool) :=
      q(CellOperations.check operations base.codec values Quadratic.matrix [] Quadratic.cert
        .existsReal RootReplayLiterals.whole Quadratic.cells)
    let basic : Hex.RealFormula.Reify.Config := {}
    let config := {basic with ring := {basic.ring with budget :=
      {basic.ring.budget with proofNodes := 16000000}}}
    let hits ← IO.mkRef (0 : Nat)
    let counts ← IO.mkRef ((0,0) : Nat × Nat)
    let action : Hex.RealFormula.Reify.ReifyM RootQuote.Result := do
      let cache ← IO.mkRef ({} : RowReadMemo.State)
      let quoted ← CellQuote.replayWith program fun expression => do
        if expression.getAppFn.isConstOf ``RowOperations.read then
          hits.modify (·+1)
          return some (← RowReadMemo.quoteWith cache expression baseDecode)
        baseDecode expression
      let state ← cache.get
      counts.set (state.hits,state.misses)
      return quoted
    let quoted ← match ← RootQuote.runWith action config with
      | .ok quoted => pure quoted
      | .error error => throwError "staged row probe refused: {Hex.RealFormula.Reify.Error.toMessageData error}"
    let target ← mkEq (← mkAppM ``Except.toOption #[program])
      (← mkAppM ``Option.some #[mkConst ``Bool.true])
    let proof ← Hex.RCF.checkProof `RowReadMemoProbe.checked target
      (mkExpectedPropHint quoted.proof target)
    unless (← hits.get) > 0 do throwError "row-stage callback was not reached"
    withExporting (isExporting := true) do
      addDecl (.thmDecl {name := `RowReadMemoProbe.checked,levelParams := [],type := target,value := proof})
    let dependencies ← Hex.RCF.ProofEvidence.projectDependencies #[`RowReadMemoProbe.checked]
    unless dependencies.contains ``RowReadStage.read_of_parts do
      throwError "row-stage composition absent from actual checked proof"
    let (reused,validated) ← counts.get
    logInfo m!"memo row quadratic: nodes={quoted.usage.proofNodes}; callbacks={← hits.get}; hits={reused}; misses={validated}"
    unless reused > 0 do throwError "no checked memo was reused"
    unless dependencies.contains ``Dag.selectedSigns_memo do
      throwError "owner memo correspondence absent from checked proof"
end RowReadMemoProbe
