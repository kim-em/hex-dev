from pathlib import Path
import gzip, hashlib, json, subprocess
repo=Path.cwd(); task=Path('/home/kim/.codex/tasks/hex-10358')
out=repo/'reports/data/hexrcf-cell-memos';out.mkdir(parents=True,exist_ok=True)
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo)
sha=lambda b:hashlib.sha256(b).hexdigest()
source=git('rev-parse','HEAD').decode().strip()
prior=json.loads((repo/'reports/data/hexrcf-cell-quotation/context.json').read_text())
paths=set(prior['sources']) | set(git('diff','--name-only',prior['source_commit'],source).decode().splitlines())
record=dict(source_commit=source,source_tree=git('rev-parse',source+'^{tree}').decode().strip(),baseline_commit=prior['baseline_commit'],unchanged_guards=prior['unchanged_guards'],sources={},artifacts=[],validation={},compiled_files=[],scope='Fixed-parent original algebraic source quotation, checked graph memos, forty affected targets/manual and ten actually inspected captures.',limits='No generic source/history assembly, strict compiled whole-reader completeness, total tactic closure, matched timing/scaling or physical-sharing claim. Older records remain immutable.')
for name in sorted(paths):
 if name.startswith('reports/'):continue
 raw=git('show',source+':'+name);assert (repo/name).read_bytes()==raw,name
 record['sources'][name]=sha(raw)
def retain(path,target,compress=False):
 raw=path.read_bytes();dest=out/target;dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_bytes(gzip.compress(raw,mtime=0) if compress else raw)
 saved=dest.read_bytes();item=dict(path=target,bytes=len(saved),sha256=sha(saved))
 if compress:item['uncompressed_sha256']=sha(raw)
 record['artifacts'].append(item);return target
for key,name in dict(integration='cell-memo-expanded-1.log',source='row-packet-production-conformance-3.log',controls='row-packet-controls-7.log',render='cell-memo-render-1.log',browser='cell-memo-browser-1.log').items():
 assert 'code=exited, status=0/SUCCESS' in (task/name).read_text(),name
 record['validation'][key]=retain(task/name,'validation/'+name+'.gz',True)
metadata=json.loads((task/'row-packet-final-metadata.json').read_text());assert all(x['exit_code']==0 for x in metadata)
retain(task/'row-packet-final-metadata.json','validation/metadata.json')
for item in metadata:retain(task/item['log'],'validation/'+item['log']+'.gz',True)
for name in ['collect-cell-memos.py','row-packet-final-metadata.py','cell-memo-expanded-targets.txt','cell-memo-memory-policy.txt','cell-memo-expanded-invocation.json']:
 retain(task/name,'validation/'+name+'.gz',True)
retain(task/'bin/run-bounded','validation/run-bounded.sh')
retain(task/'scalar-review-render/CellMemoReviewRender.lean','captures/render.lean.txt')
retain(task/'cell-memo-browser.mjs','captures/browser.mjs')
retain(task/'scalar-review-render/cell-memo-final-inspection.json','captures/inspection.json')
retain(task/'scalar-review-render/cell-memo-final-section-overflow.json','captures/section-overflow.json')
review=json.loads((task/'cell-memo-visual-review.json').read_text());assert len(review['captures'])==10
for item in review['captures']:
 path=Path(item['path']);assert item['viewed'] and sha(path.read_bytes())==item['sha256']
 item['path']=retain(path,'captures/'+path.name)
manifest=out/'captures/visual-review.json';manifest.write_text(json.dumps(review,indent=2)+'\n');retain(manifest,'captures/visual-review.json')
for path in sorted(task.iterdir()):
 if not any(path.name.startswith(p) for p in ['row-packet-','row-read-stage-','row-read-memo-','fresh-staged-pointwise-','cell-memo-expanded-1-inputs']):continue
 if path.is_file() and path.suffix in ['.log','.json']:
  retain(path,'diagnostics/'+path.name+'.gz',True)
 elif path.is_dir() and path.name.endswith('-inputs'):
  for child in sorted(path.rglob('*')):
   if child.is_file():retain(child,'diagnostics/'+str(child.relative_to(task))+'.gz',True)
for name in ['CellQuoteStages','CellQuoteStageProofs','CellSourceQuote','CellSourceProofs','RowPacketControls']:
 path='.lake/build/lib/lean/HexRCF/'+name+'.olean';raw=(repo/path).read_bytes()
 record['compiled_files'].append(dict(path=path,bytes=len(raw),sha256=sha(raw)))
(out/'context.json').write_text(json.dumps(record,indent=2)+'\n')
print(f'Retained {len(record["artifacts"])} artifacts/{len(record["sources"])} sources at {source}')
